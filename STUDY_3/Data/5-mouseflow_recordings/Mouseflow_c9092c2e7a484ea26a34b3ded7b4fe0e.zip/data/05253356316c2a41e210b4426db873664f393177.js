var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05253356316c2a41e210b4426db873664f393177"] = {
  "startTime": "2018-05-25T18:16:32.9642602Z",
  "websitePageUrl": "/16",
  "visitTime": 125568,
  "engagementTime": 105882,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "c9092c2e7a484ea26a34b3ded7b4fe0e",
    "created": "2018-05-25T18:16:32.9642602+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=55GO7",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "7ad18137cb246aa937ffbaefede0f199",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/c9092c2e7a484ea26a34b3ded7b4fe0e/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 209,
      "e": 209,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 10000,
      "e": 5209,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 18501,
      "e": 5209,
      "ty": 2,
      "x": 480,
      "y": 617
    },
    {
      "t": 18502,
      "e": 5210,
      "ty": 41,
      "x": 43042,
      "y": 63387,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 18515,
      "e": 5223,
      "ty": 6,
      "x": 479,
      "y": 600,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18601,
      "e": 5309,
      "ty": 2,
      "x": 473,
      "y": 523
    },
    {
      "t": 18614,
      "e": 5322,
      "ty": 7,
      "x": 472,
      "y": 513,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18700,
      "e": 5408,
      "ty": 2,
      "x": 469,
      "y": 478
    },
    {
      "t": 18751,
      "e": 5459,
      "ty": 41,
      "x": 41805,
      "y": 340,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 19001,
      "e": 5709,
      "ty": 2,
      "x": 470,
      "y": 503
    },
    {
      "t": 19001,
      "e": 5709,
      "ty": 41,
      "x": 41918,
      "y": 19345,
      "ta": "#.strategy > p"
    },
    {
      "t": 19081,
      "e": 5789,
      "ty": 6,
      "x": 470,
      "y": 525,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19101,
      "e": 5809,
      "ty": 2,
      "x": 470,
      "y": 527
    },
    {
      "t": 19201,
      "e": 5909,
      "ty": 2,
      "x": 470,
      "y": 528
    },
    {
      "t": 19238,
      "e": 5946,
      "ty": 3,
      "x": 470,
      "y": 528,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19238,
      "e": 5946,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19251,
      "e": 5959,
      "ty": 41,
      "x": 41918,
      "y": 4260,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19310,
      "e": 6018,
      "ty": 4,
      "x": 41918,
      "y": 4260,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19310,
      "e": 6018,
      "ty": 5,
      "x": 470,
      "y": 528,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20101,
      "e": 6809,
      "ty": 2,
      "x": 486,
      "y": 526
    },
    {
      "t": 20251,
      "e": 6959,
      "ty": 41,
      "x": 43716,
      "y": 2642,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22659,
      "e": 9367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 22659,
      "e": 9367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22770,
      "e": 9478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "g"
    },
    {
      "t": 22778,
      "e": 9486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22778,
      "e": 9486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22866,
      "e": 9574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go"
    },
    {
      "t": 23099,
      "e": 9807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23099,
      "e": 9807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23194,
      "e": 9902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go "
    },
    {
      "t": 23330,
      "e": 10038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23330,
      "e": 10038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23402,
      "e": 10110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go t"
    },
    {
      "t": 23442,
      "e": 10150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23442,
      "e": 10150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23554,
      "e": 10262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 24251,
      "e": 10959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 24252,
      "e": 10960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24330,
      "e": 11038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 24459,
      "e": 11167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 24459,
      "e": 11167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24545,
      "e": 11253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 24778,
      "e": 11486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 24780,
      "e": 11488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24891,
      "e": 11599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 25139,
      "e": 11847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 25139,
      "e": 11847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25330,
      "e": 12038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 25794,
      "e": 12502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 25795,
      "e": 12503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25930,
      "e": 12638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 26122,
      "e": 12830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26124,
      "e": 12832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26234,
      "e": 12942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26371,
      "e": 13079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26371,
      "e": 13079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26450,
      "e": 13158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26515,
      "e": 13223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 26515,
      "e": 13223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26602,
      "e": 13310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 26666,
      "e": 13374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26666,
      "e": 13374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26747,
      "e": 13455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26779,
      "e": 13487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26779,
      "e": 13487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26866,
      "e": 13574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26969,
      "e": 13677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 26969,
      "e": 13677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27041,
      "e": 13749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 27242,
      "e": 13950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27242,
      "e": 13950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27322,
      "e": 14030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 27451,
      "e": 14159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27451,
      "e": 14159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27481,
      "e": 14189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27569,
      "e": 14277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27571,
      "e": 14279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27650,
      "e": 14358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27722,
      "e": 14430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27724,
      "e": 14432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27802,
      "e": 14510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 27922,
      "e": 14630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 27923,
      "e": 14631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27994,
      "e": 14702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 28154,
      "e": 14862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28155,
      "e": 14863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28250,
      "e": 14958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30000,
      "e": 16708,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30058,
      "e": 16766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 30058,
      "e": 16766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30146,
      "e": 16854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 30378,
      "e": 17086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 30379,
      "e": 17087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30498,
      "e": 17206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 30587,
      "e": 17295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30587,
      "e": 17295,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30674,
      "e": 17382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30786,
      "e": 17494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 30786,
      "e": 17494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30865,
      "e": 17573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 30897,
      "e": 17605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 30898,
      "e": 17606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30978,
      "e": 17686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 31075,
      "e": 17783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31075,
      "e": 17783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31194,
      "e": 17902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 31258,
      "e": 17966,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 31259,
      "e": 17967,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31331,
      "e": 18039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 31459,
      "e": 18167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31459,
      "e": 18167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31530,
      "e": 18238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 31810,
      "e": 18518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31810,
      "e": 18518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31889,
      "e": 18597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32003,
      "e": 18711,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart "
    },
    {
      "t": 32370,
      "e": 19078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 32371,
      "e": 19079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32441,
      "e": 19149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 32489,
      "e": 19197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32490,
      "e": 19198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32595,
      "e": 19303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 32714,
      "e": 19422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32715,
      "e": 19423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32803,
      "e": 19511,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 32883,
      "e": 19591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 32883,
      "e": 19591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32962,
      "e": 19670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 33034,
      "e": 19742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33035,
      "e": 19743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33122,
      "e": 19830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33650,
      "e": 20358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 33651,
      "e": 20359,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33803,
      "e": 20511,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 1"
    },
    {
      "t": 33826,
      "e": 20534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 33827,
      "e": 20535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33866,
      "e": 20574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 33939,
      "e": 20647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34090,
      "e": 20798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "48"
    },
    {
      "t": 34091,
      "e": 20799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34178,
      "e": 20886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||0"
    },
    {
      "t": 34530,
      "e": 21238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 34531,
      "e": 21239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34594,
      "e": 21302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 36217,
      "e": 22925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36314,
      "e": 23022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 120"
    },
    {
      "t": 36811,
      "e": 23519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36883,
      "e": 23591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12"
    },
    {
      "t": 37004,
      "e": 23712,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12"
    },
    {
      "t": 37395,
      "e": 24103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 37395,
      "e": 24103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37474,
      "e": 24182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 37691,
      "e": 24399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 37692,
      "e": 24400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37769,
      "e": 24477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 39926,
      "e": 26634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39927,
      "e": 26635,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39997,
      "e": 26705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40004,
      "e": 26712,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40271,
      "e": 26979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40271,
      "e": 26979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40341,
      "e": 27049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 40469,
      "e": 27177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40470,
      "e": 27178,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40549,
      "e": 27257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 41262,
      "e": 27970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41309,
      "e": 28017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm n"
    },
    {
      "t": 41518,
      "e": 28226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41589,
      "e": 28297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm "
    },
    {
      "t": 41829,
      "e": 28537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41830,
      "e": 28538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41957,
      "e": 28665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 42478,
      "e": 29186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 42479,
      "e": 29187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42581,
      "e": 29289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 42669,
      "e": 29377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 42670,
      "e": 29378,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42733,
      "e": 29441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 42797,
      "e": 29505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42797,
      "e": 29505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42869,
      "e": 29577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43062,
      "e": 29770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 43063,
      "e": 29771,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43140,
      "e": 29848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 43302,
      "e": 30010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 43302,
      "e": 30010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43365,
      "e": 30073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 43477,
      "e": 30185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 43478,
      "e": 30186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43540,
      "e": 30248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 43709,
      "e": 30417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 43711,
      "e": 30419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43805,
      "e": 30513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 44486,
      "e": 31194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 44487,
      "e": 31195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44573,
      "e": 31281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 44621,
      "e": 31329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 44621,
      "e": 31329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44725,
      "e": 31433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 44807,
      "e": 31515,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 44808,
      "e": 31516,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44885,
      "e": 31593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 44973,
      "e": 31681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44974,
      "e": 31682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45060,
      "e": 31768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48974,
      "e": 35682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49069,
      "e": 35777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and lookfor"
    },
    {
      "t": 49173,
      "e": 35881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49269,
      "e": 35977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and lookfo"
    },
    {
      "t": 49358,
      "e": 36066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49468,
      "e": 36176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and lookf"
    },
    {
      "t": 49549,
      "e": 36257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49622,
      "e": 36330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and look"
    },
    {
      "t": 50004,
      "e": 36712,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50409,
      "e": 37117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50409,
      "e": 37117,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50533,
      "e": 37241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50621,
      "e": 37329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 50622,
      "e": 37330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50734,
      "e": 37442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 51270,
      "e": 37978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 51270,
      "e": 37978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51373,
      "e": 38081,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 51630,
      "e": 38338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51630,
      "e": 38338,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51749,
      "e": 38457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54117,
      "e": 40825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54205,
      "e": 40913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and look ay"
    },
    {
      "t": 54534,
      "e": 41242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 54653,
      "e": 41361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and look a"
    },
    {
      "t": 55710,
      "e": 42418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 55710,
      "e": 42418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55845,
      "e": 42553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 56022,
      "e": 42730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 56023,
      "e": 42731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56108,
      "e": 42816,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 56253,
      "e": 42961,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56254,
      "e": 42962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56388,
      "e": 43096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56742,
      "e": 43450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 56743,
      "e": 43451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56836,
      "e": 43544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 56917,
      "e": 43625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 56917,
      "e": 43625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57037,
      "e": 43745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 57109,
      "e": 43817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57110,
      "e": 43818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57196,
      "e": 43904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 57334,
      "e": 44042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57334,
      "e": 44042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57389,
      "e": 44097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57701,
      "e": 44409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 57703,
      "e": 44411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57764,
      "e": 44472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 58549,
      "e": 45257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 58550,
      "e": 45258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58669,
      "e": 45377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 59222,
      "e": 45930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 59245,
      "e": 45953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and look any dot e"
    },
    {
      "t": 59357,
      "e": 46065,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 59460,
      "e": 46168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and look any dot "
    },
    {
      "t": 59998,
      "e": 46706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 59998,
      "e": 46706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60004,
      "e": 46712,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60101,
      "e": 46809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 60285,
      "e": 46993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 60285,
      "e": 46993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60365,
      "e": 47073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 60534,
      "e": 47242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 60535,
      "e": 47243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60604,
      "e": 47312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 60797,
      "e": 47505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60798,
      "e": 47506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60941,
      "e": 47649,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 61349,
      "e": 48057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61412,
      "e": 48120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and look any dot one"
    },
    {
      "t": 61524,
      "e": 48232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61598,
      "e": 48306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and look any dot on"
    },
    {
      "t": 62029,
      "e": 48737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 62030,
      "e": 48738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62101,
      "e": 48809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 62207,
      "e": 48915,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and look any dot onb"
    },
    {
      "t": 63213,
      "e": 49921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63214,
      "e": 49922,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63293,
      "e": 50001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 63407,
      "e": 50115,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and look any dot onb "
    },
    {
      "t": 63623,
      "e": 50331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 63668,
      "e": 50376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and look any dot onb"
    },
    {
      "t": 63806,
      "e": 50514,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and look any dot onb"
    },
    {
      "t": 63966,
      "e": 50674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64117,
      "e": 50825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and look any dot on"
    },
    {
      "t": 64694,
      "e": 51402,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64694,
      "e": 51402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64806,
      "e": 51514,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and look any dot on "
    },
    {
      "t": 64812,
      "e": 51520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64942,
      "e": 51650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 64942,
      "e": 51650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65245,
      "e": 51953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 66045,
      "e": 52753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 66046,
      "e": 52754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66172,
      "e": 52880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 66765,
      "e": 53473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 66766,
      "e": 53474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66852,
      "e": 53560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 67061,
      "e": 53769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 67062,
      "e": 53770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67132,
      "e": 53840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 67733,
      "e": 54441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 67733,
      "e": 54441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67845,
      "e": 54553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 68825,
      "e": 55533,
      "ty": 7,
      "x": 458,
      "y": 519,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68904,
      "e": 55612,
      "ty": 2,
      "x": 449,
      "y": 521
    },
    {
      "t": 68908,
      "e": 55616,
      "ty": 6,
      "x": 447,
      "y": 531,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69004,
      "e": 55712,
      "ty": 2,
      "x": 438,
      "y": 596
    },
    {
      "t": 69004,
      "e": 55712,
      "ty": 41,
      "x": 38321,
      "y": 59277,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69009,
      "e": 55717,
      "ty": 7,
      "x": 433,
      "y": 608,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69104,
      "e": 55812,
      "ty": 2,
      "x": 428,
      "y": 622
    },
    {
      "t": 69176,
      "e": 55884,
      "ty": 6,
      "x": 427,
      "y": 662,
      "ta": "#strategyButton"
    },
    {
      "t": 69204,
      "e": 55912,
      "ty": 2,
      "x": 427,
      "y": 670
    },
    {
      "t": 69254,
      "e": 55962,
      "ty": 41,
      "x": 44457,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 69293,
      "e": 56001,
      "ty": 7,
      "x": 418,
      "y": 690,
      "ta": "#strategyButton"
    },
    {
      "t": 69304,
      "e": 56012,
      "ty": 2,
      "x": 418,
      "y": 690
    },
    {
      "t": 69404,
      "e": 56112,
      "ty": 2,
      "x": 418,
      "y": 692
    },
    {
      "t": 69504,
      "e": 56212,
      "ty": 41,
      "x": 46532,
      "y": 46048,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 69755,
      "e": 56463,
      "ty": 41,
      "x": 46064,
      "y": 45393,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 69793,
      "e": 56501,
      "ty": 6,
      "x": 415,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 69804,
      "e": 56512,
      "ty": 2,
      "x": 415,
      "y": 688
    },
    {
      "t": 69904,
      "e": 56612,
      "ty": 2,
      "x": 414,
      "y": 685
    },
    {
      "t": 70005,
      "e": 56613,
      "ty": 2,
      "x": 413,
      "y": 684
    },
    {
      "t": 70006,
      "e": 56614,
      "ty": 41,
      "x": 40635,
      "y": 56409,
      "ta": "#strategyButton"
    },
    {
      "t": 70104,
      "e": 56712,
      "ty": 2,
      "x": 411,
      "y": 675
    },
    {
      "t": 70204,
      "e": 56812,
      "ty": 2,
      "x": 410,
      "y": 672
    },
    {
      "t": 70254,
      "e": 56862,
      "ty": 41,
      "x": 38996,
      "y": 33279,
      "ta": "#strategyButton"
    },
    {
      "t": 70362,
      "e": 56970,
      "ty": 3,
      "x": 410,
      "y": 672,
      "ta": "#strategyButton"
    },
    {
      "t": 70364,
      "e": 56972,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "go towards the bottom of chart find 12pm and look any dot on 12pm\n"
    },
    {
      "t": 70365,
      "e": 56973,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70366,
      "e": 56974,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 70472,
      "e": 57080,
      "ty": 4,
      "x": 38996,
      "y": 33279,
      "ta": "#strategyButton"
    },
    {
      "t": 70484,
      "e": 57092,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 70486,
      "e": 57094,
      "ty": 5,
      "x": 410,
      "y": 672,
      "ta": "#strategyButton"
    },
    {
      "t": 70493,
      "e": 57101,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 71493,
      "e": 58101,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 72404,
      "e": 59012,
      "ty": 2,
      "x": 536,
      "y": 613
    },
    {
      "t": 72504,
      "e": 59112,
      "ty": 2,
      "x": 710,
      "y": 573
    },
    {
      "t": 72504,
      "e": 59112,
      "ty": 41,
      "x": 24175,
      "y": 31299,
      "ta": "html > body"
    },
    {
      "t": 72604,
      "e": 59212,
      "ty": 2,
      "x": 790,
      "y": 560
    },
    {
      "t": 72644,
      "e": 59252,
      "ty": 6,
      "x": 810,
      "y": 556,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72678,
      "e": 59286,
      "ty": 7,
      "x": 833,
      "y": 551,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 72704,
      "e": 59312,
      "ty": 2,
      "x": 839,
      "y": 549
    },
    {
      "t": 72754,
      "e": 59362,
      "ty": 41,
      "x": 11679,
      "y": 37347,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 72804,
      "e": 59412,
      "ty": 2,
      "x": 868,
      "y": 541
    },
    {
      "t": 73004,
      "e": 59612,
      "ty": 2,
      "x": 876,
      "y": 547
    },
    {
      "t": 73004,
      "e": 59612,
      "ty": 41,
      "x": 14707,
      "y": 40166,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 73012,
      "e": 59620,
      "ty": 6,
      "x": 881,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 73105,
      "e": 59713,
      "ty": 2,
      "x": 882,
      "y": 558
    },
    {
      "t": 73226,
      "e": 59834,
      "ty": 3,
      "x": 882,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 73227,
      "e": 59835,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 73254,
      "e": 59862,
      "ty": 41,
      "x": 16005,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 73337,
      "e": 59945,
      "ty": 4,
      "x": 16005,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 73337,
      "e": 59945,
      "ty": 5,
      "x": 882,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74013,
      "e": 60621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 74014,
      "e": 60622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74093,
      "e": 60701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 74205,
      "e": 60813,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 75316,
      "e": 61924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "104"
    },
    {
      "t": 75316,
      "e": 61924,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75404,
      "e": 62012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 76003,
      "e": 62611,
      "ty": 2,
      "x": 882,
      "y": 569
    },
    {
      "t": 76004,
      "e": 62612,
      "ty": 41,
      "x": 16005,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76014,
      "e": 62622,
      "ty": 7,
      "x": 887,
      "y": 579,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76103,
      "e": 62711,
      "ty": 2,
      "x": 898,
      "y": 624
    },
    {
      "t": 76148,
      "e": 62756,
      "ty": 6,
      "x": 903,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76204,
      "e": 62812,
      "ty": 2,
      "x": 904,
      "y": 661
    },
    {
      "t": 76253,
      "e": 62861,
      "ty": 41,
      "x": 20763,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76303,
      "e": 62911,
      "ty": 2,
      "x": 904,
      "y": 662
    },
    {
      "t": 76403,
      "e": 63011,
      "ty": 2,
      "x": 904,
      "y": 663
    },
    {
      "t": 76503,
      "e": 63111,
      "ty": 41,
      "x": 20763,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76504,
      "e": 63112,
      "ty": 3,
      "x": 904,
      "y": 663,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76504,
      "e": 63112,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 76505,
      "e": 63113,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76505,
      "e": 63113,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76632,
      "e": 63240,
      "ty": 4,
      "x": 20763,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76632,
      "e": 63240,
      "ty": 5,
      "x": 904,
      "y": 663,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78661,
      "e": 65269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 78662,
      "e": 65270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78805,
      "e": 65413,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": " "
    },
    {
      "t": 78901,
      "e": 65509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 78901,
      "e": 65509,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78981,
      "e": 65589,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": " m"
    },
    {
      "t": 78997,
      "e": 65605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": " m"
    },
    {
      "t": 79629,
      "e": 66237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 79630,
      "e": 66238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79732,
      "e": 66340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": " mi"
    },
    {
      "t": 79934,
      "e": 66542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 79934,
      "e": 66542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80003,
      "e": 66611,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80012,
      "e": 66620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": " min"
    },
    {
      "t": 80084,
      "e": 66692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 80084,
      "e": 66692,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80156,
      "e": 66764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||n"
    },
    {
      "t": 80701,
      "e": 67309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 80702,
      "e": 67310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80798,
      "e": 67406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 80918,
      "e": 67526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 80918,
      "e": 67526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80989,
      "e": 67597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 81341,
      "e": 67949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 81342,
      "e": 67950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81436,
      "e": 68044,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||o"
    },
    {
      "t": 81669,
      "e": 68277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 81670,
      "e": 68278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81741,
      "e": 68349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 83453,
      "e": 70061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 83455,
      "e": 70063,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83540,
      "e": 70148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 84605,
      "e": 71213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "37"
    },
    {
      "t": 85105,
      "e": 71713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "37"
    },
    {
      "t": 85137,
      "e": 71745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "37"
    },
    {
      "t": 85170,
      "e": 71778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "37"
    },
    {
      "t": 85203,
      "e": 71811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "37"
    },
    {
      "t": 85236,
      "e": 71844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "37"
    },
    {
      "t": 85269,
      "e": 71877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "37"
    },
    {
      "t": 85302,
      "e": 71910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "37"
    },
    {
      "t": 85335,
      "e": 71943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "37"
    },
    {
      "t": 85340,
      "e": 71948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 85965,
      "e": 72573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "39"
    },
    {
      "t": 86085,
      "e": 72693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 86621,
      "e": 73229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 86732,
      "e": 73340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": " innesota"
    },
    {
      "t": 87190,
      "e": 73798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 87689,
      "e": 74297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 87722,
      "e": 74330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 87755,
      "e": 74363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 87788,
      "e": 74396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 87821,
      "e": 74429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 87854,
      "e": 74462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 87887,
      "e": 74495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 87901,
      "e": 74509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 87901,
      "e": 74509,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88005,
      "e": 74613,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": " Minnesota"
    },
    {
      "t": 88069,
      "e": 74677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": " Minnesota"
    },
    {
      "t": 88110,
      "e": 74718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 90004,
      "e": 76612,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90059,
      "e": 76667,
      "ty": 7,
      "x": 904,
      "y": 671,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90076,
      "e": 76684,
      "ty": 6,
      "x": 903,
      "y": 681,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90104,
      "e": 76712,
      "ty": 2,
      "x": 903,
      "y": 687
    },
    {
      "t": 90204,
      "e": 76812,
      "ty": 2,
      "x": 903,
      "y": 693
    },
    {
      "t": 90254,
      "e": 76862,
      "ty": 41,
      "x": 3647,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90320,
      "e": 76928,
      "ty": 3,
      "x": 903,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90321,
      "e": 76929,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": " Minnesota"
    },
    {
      "t": 90321,
      "e": 76929,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90321,
      "e": 76929,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90432,
      "e": 77040,
      "ty": 4,
      "x": 3647,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90433,
      "e": 77041,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90433,
      "e": 77041,
      "ty": 5,
      "x": 903,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 90433,
      "e": 77041,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 91254,
      "e": 77862,
      "ty": 41,
      "x": 30821,
      "y": 38002,
      "ta": "html > body"
    },
    {
      "t": 91304,
      "e": 77912,
      "ty": 2,
      "x": 903,
      "y": 694
    },
    {
      "t": 91451,
      "e": 78059,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 91504,
      "e": 78112,
      "ty": 2,
      "x": 892,
      "y": 687
    },
    {
      "t": 91504,
      "e": 78112,
      "ty": 41,
      "x": 16749,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 91604,
      "e": 78212,
      "ty": 2,
      "x": 824,
      "y": 622
    },
    {
      "t": 91704,
      "e": 78312,
      "ty": 2,
      "x": 809,
      "y": 586
    },
    {
      "t": 91754,
      "e": 78362,
      "ty": 41,
      "x": 27550,
      "y": 31908,
      "ta": "html > body"
    },
    {
      "t": 91804,
      "e": 78412,
      "ty": 2,
      "x": 808,
      "y": 584
    },
    {
      "t": 92204,
      "e": 78812,
      "ty": 2,
      "x": 849,
      "y": 455
    },
    {
      "t": 92254,
      "e": 78862,
      "ty": 41,
      "x": 11766,
      "y": 14422,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 92304,
      "e": 78912,
      "ty": 2,
      "x": 880,
      "y": 281
    },
    {
      "t": 92404,
      "e": 79012,
      "ty": 2,
      "x": 879,
      "y": 232
    },
    {
      "t": 92504,
      "e": 79112,
      "ty": 2,
      "x": 876,
      "y": 226
    },
    {
      "t": 92504,
      "e": 79112,
      "ty": 41,
      "x": 12952,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 92604,
      "e": 79212,
      "ty": 2,
      "x": 873,
      "y": 223
    },
    {
      "t": 92704,
      "e": 79312,
      "ty": 2,
      "x": 858,
      "y": 200
    },
    {
      "t": 92755,
      "e": 79363,
      "ty": 41,
      "x": 8443,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 92804,
      "e": 79412,
      "ty": 2,
      "x": 857,
      "y": 198
    },
    {
      "t": 93104,
      "e": 79712,
      "ty": 2,
      "x": 851,
      "y": 222
    },
    {
      "t": 93204,
      "e": 79812,
      "ty": 2,
      "x": 845,
      "y": 229
    },
    {
      "t": 93254,
      "e": 79862,
      "ty": 41,
      "x": 19307,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 93564,
      "e": 80172,
      "ty": 6,
      "x": 838,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 93604,
      "e": 80212,
      "ty": 2,
      "x": 838,
      "y": 235
    },
    {
      "t": 93755,
      "e": 80363,
      "ty": 41,
      "x": 58367,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 93875,
      "e": 80483,
      "ty": 3,
      "x": 838,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 93875,
      "e": 80483,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 93904,
      "e": 80512,
      "ty": 2,
      "x": 836,
      "y": 235
    },
    {
      "t": 94004,
      "e": 80612,
      "ty": 41,
      "x": 48284,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 94017,
      "e": 80625,
      "ty": 4,
      "x": 48284,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 94017,
      "e": 80625,
      "ty": 5,
      "x": 836,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 94017,
      "e": 80625,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 94204,
      "e": 80812,
      "ty": 2,
      "x": 831,
      "y": 238
    },
    {
      "t": 94255,
      "e": 80863,
      "ty": 41,
      "x": 23079,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 94304,
      "e": 80912,
      "ty": 2,
      "x": 829,
      "y": 239
    },
    {
      "t": 94347,
      "e": 80955,
      "ty": 7,
      "x": 825,
      "y": 250,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 94404,
      "e": 81012,
      "ty": 2,
      "x": 825,
      "y": 266
    },
    {
      "t": 94504,
      "e": 81112,
      "ty": 2,
      "x": 857,
      "y": 304
    },
    {
      "t": 94505,
      "e": 81113,
      "ty": 41,
      "x": 11150,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 94604,
      "e": 81212,
      "ty": 2,
      "x": 922,
      "y": 351
    },
    {
      "t": 94704,
      "e": 81312,
      "ty": 2,
      "x": 949,
      "y": 378
    },
    {
      "t": 94753,
      "e": 81361,
      "ty": 41,
      "x": 30277,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 94804,
      "e": 81412,
      "ty": 2,
      "x": 949,
      "y": 385
    },
    {
      "t": 94904,
      "e": 81512,
      "ty": 2,
      "x": 939,
      "y": 394
    },
    {
      "t": 95004,
      "e": 81612,
      "ty": 2,
      "x": 923,
      "y": 404
    },
    {
      "t": 95004,
      "e": 81612,
      "ty": 41,
      "x": 24107,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 95104,
      "e": 81712,
      "ty": 2,
      "x": 900,
      "y": 406
    },
    {
      "t": 95204,
      "e": 81812,
      "ty": 2,
      "x": 891,
      "y": 408
    },
    {
      "t": 95254,
      "e": 81862,
      "ty": 41,
      "x": 14139,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 95304,
      "e": 81912,
      "ty": 2,
      "x": 873,
      "y": 411
    },
    {
      "t": 95348,
      "e": 81913,
      "ty": 6,
      "x": 834,
      "y": 409,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 95364,
      "e": 81929,
      "ty": 7,
      "x": 822,
      "y": 406,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 95404,
      "e": 81969,
      "ty": 2,
      "x": 816,
      "y": 405
    },
    {
      "t": 95504,
      "e": 82069,
      "ty": 2,
      "x": 798,
      "y": 401
    },
    {
      "t": 95504,
      "e": 82069,
      "ty": 41,
      "x": 27205,
      "y": 21771,
      "ta": "html > body"
    },
    {
      "t": 95604,
      "e": 82169,
      "ty": 2,
      "x": 721,
      "y": 410
    },
    {
      "t": 95704,
      "e": 82269,
      "ty": 2,
      "x": 691,
      "y": 408
    },
    {
      "t": 95755,
      "e": 82320,
      "ty": 41,
      "x": 23520,
      "y": 22158,
      "ta": "html > body"
    },
    {
      "t": 96104,
      "e": 82669,
      "ty": 2,
      "x": 690,
      "y": 402
    },
    {
      "t": 96204,
      "e": 82769,
      "ty": 2,
      "x": 690,
      "y": 398
    },
    {
      "t": 96254,
      "e": 82819,
      "ty": 41,
      "x": 23589,
      "y": 21549,
      "ta": "html > body"
    },
    {
      "t": 96304,
      "e": 82869,
      "ty": 2,
      "x": 703,
      "y": 391
    },
    {
      "t": 96404,
      "e": 82969,
      "ty": 2,
      "x": 762,
      "y": 384
    },
    {
      "t": 96504,
      "e": 83069,
      "ty": 2,
      "x": 812,
      "y": 384
    },
    {
      "t": 96504,
      "e": 83069,
      "ty": 41,
      "x": 27687,
      "y": 20829,
      "ta": "html > body"
    },
    {
      "t": 96603,
      "e": 83168,
      "ty": 2,
      "x": 823,
      "y": 388
    },
    {
      "t": 96704,
      "e": 83269,
      "ty": 2,
      "x": 825,
      "y": 390
    },
    {
      "t": 96754,
      "e": 83319,
      "ty": 41,
      "x": 1561,
      "y": 10832,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 96803,
      "e": 83368,
      "ty": 2,
      "x": 829,
      "y": 399
    },
    {
      "t": 96904,
      "e": 83469,
      "ty": 2,
      "x": 830,
      "y": 405
    },
    {
      "t": 97003,
      "e": 83568,
      "ty": 2,
      "x": 830,
      "y": 407
    },
    {
      "t": 97003,
      "e": 83568,
      "ty": 41,
      "x": 10041,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 97057,
      "e": 83622,
      "ty": 6,
      "x": 829,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 97103,
      "e": 83668,
      "ty": 2,
      "x": 829,
      "y": 408
    },
    {
      "t": 97201,
      "e": 83766,
      "ty": 3,
      "x": 828,
      "y": 409,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 97203,
      "e": 83768,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 97203,
      "e": 83768,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 97204,
      "e": 83769,
      "ty": 2,
      "x": 828,
      "y": 409
    },
    {
      "t": 97254,
      "e": 83819,
      "ty": 41,
      "x": 7955,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 97328,
      "e": 83893,
      "ty": 4,
      "x": 7955,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 97328,
      "e": 83893,
      "ty": 5,
      "x": 828,
      "y": 409,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 97329,
      "e": 83894,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 97504,
      "e": 84069,
      "ty": 2,
      "x": 828,
      "y": 410
    },
    {
      "t": 97504,
      "e": 84069,
      "ty": 41,
      "x": 7955,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 97604,
      "e": 84169,
      "ty": 2,
      "x": 827,
      "y": 410
    },
    {
      "t": 97754,
      "e": 84319,
      "ty": 41,
      "x": 7955,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 97783,
      "e": 84348,
      "ty": 7,
      "x": 838,
      "y": 433,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 97803,
      "e": 84368,
      "ty": 2,
      "x": 844,
      "y": 444
    },
    {
      "t": 97904,
      "e": 84469,
      "ty": 2,
      "x": 852,
      "y": 507
    },
    {
      "t": 98004,
      "e": 84569,
      "ty": 2,
      "x": 852,
      "y": 520
    },
    {
      "t": 98004,
      "e": 84569,
      "ty": 41,
      "x": 35784,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 98103,
      "e": 84668,
      "ty": 2,
      "x": 880,
      "y": 566
    },
    {
      "t": 98204,
      "e": 84769,
      "ty": 2,
      "x": 893,
      "y": 631
    },
    {
      "t": 98253,
      "e": 84818,
      "ty": 41,
      "x": 19487,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 98304,
      "e": 84869,
      "ty": 2,
      "x": 890,
      "y": 677
    },
    {
      "t": 98503,
      "e": 85068,
      "ty": 41,
      "x": 18413,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 98803,
      "e": 85368,
      "ty": 2,
      "x": 892,
      "y": 694
    },
    {
      "t": 98903,
      "e": 85468,
      "ty": 2,
      "x": 927,
      "y": 1199
    },
    {
      "t": 99003,
      "e": 85568,
      "ty": 2,
      "x": 956,
      "y": 1199
    },
    {
      "t": 99203,
      "e": 85768,
      "ty": 2,
      "x": 973,
      "y": 1168
    },
    {
      "t": 99254,
      "e": 85819,
      "ty": 41,
      "x": 49738,
      "y": 64862,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 99304,
      "e": 85869,
      "ty": 2,
      "x": 1109,
      "y": 778
    },
    {
      "t": 99403,
      "e": 85968,
      "ty": 2,
      "x": 1141,
      "y": 582
    },
    {
      "t": 99503,
      "e": 86068,
      "ty": 2,
      "x": 1090,
      "y": 483
    },
    {
      "t": 99504,
      "e": 86069,
      "ty": 41,
      "x": 63740,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 99604,
      "e": 86169,
      "ty": 2,
      "x": 950,
      "y": 519
    },
    {
      "t": 99707,
      "e": 86272,
      "ty": 2,
      "x": 945,
      "y": 526
    },
    {
      "t": 99757,
      "e": 86322,
      "ty": 41,
      "x": 37871,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 99806,
      "e": 86371,
      "ty": 2,
      "x": 1018,
      "y": 651
    },
    {
      "t": 100007,
      "e": 86572,
      "ty": 41,
      "x": 46652,
      "y": 9749,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 100257,
      "e": 86822,
      "ty": 41,
      "x": 46652,
      "y": 10019,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 100306,
      "e": 86871,
      "ty": 2,
      "x": 1017,
      "y": 653
    },
    {
      "t": 100407,
      "e": 86972,
      "ty": 2,
      "x": 1006,
      "y": 667
    },
    {
      "t": 100507,
      "e": 87072,
      "ty": 2,
      "x": 966,
      "y": 708
    },
    {
      "t": 100507,
      "e": 87072,
      "ty": 41,
      "x": 36431,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 100606,
      "e": 87171,
      "ty": 2,
      "x": 883,
      "y": 779
    },
    {
      "t": 100706,
      "e": 87271,
      "ty": 2,
      "x": 849,
      "y": 799
    },
    {
      "t": 100758,
      "e": 87273,
      "ty": 41,
      "x": 5595,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 100807,
      "e": 87322,
      "ty": 2,
      "x": 842,
      "y": 802
    },
    {
      "t": 100906,
      "e": 87421,
      "ty": 2,
      "x": 836,
      "y": 805
    },
    {
      "t": 101006,
      "e": 87521,
      "ty": 2,
      "x": 830,
      "y": 805
    },
    {
      "t": 101007,
      "e": 87522,
      "ty": 41,
      "x": 5063,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 101106,
      "e": 87621,
      "ty": 2,
      "x": 829,
      "y": 805
    },
    {
      "t": 101257,
      "e": 87772,
      "ty": 41,
      "x": 4472,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 101807,
      "e": 88322,
      "ty": 2,
      "x": 827,
      "y": 805
    },
    {
      "t": 101907,
      "e": 88422,
      "ty": 2,
      "x": 822,
      "y": 807
    },
    {
      "t": 102007,
      "e": 88522,
      "ty": 2,
      "x": 813,
      "y": 816
    },
    {
      "t": 102008,
      "e": 88523,
      "ty": 41,
      "x": 27722,
      "y": 44761,
      "ta": "html > body"
    },
    {
      "t": 102107,
      "e": 88622,
      "ty": 2,
      "x": 809,
      "y": 828
    },
    {
      "t": 102207,
      "e": 88722,
      "ty": 2,
      "x": 809,
      "y": 830
    },
    {
      "t": 102257,
      "e": 88772,
      "ty": 41,
      "x": 27584,
      "y": 45259,
      "ta": "html > body"
    },
    {
      "t": 102306,
      "e": 88821,
      "ty": 2,
      "x": 811,
      "y": 802
    },
    {
      "t": 102406,
      "e": 88921,
      "ty": 2,
      "x": 818,
      "y": 773
    },
    {
      "t": 102489,
      "e": 89004,
      "ty": 6,
      "x": 826,
      "y": 759,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 102507,
      "e": 89022,
      "ty": 2,
      "x": 828,
      "y": 752
    },
    {
      "t": 102507,
      "e": 89022,
      "ty": 41,
      "x": 7955,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 102523,
      "e": 89038,
      "ty": 7,
      "x": 830,
      "y": 747,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 102607,
      "e": 89122,
      "ty": 2,
      "x": 849,
      "y": 707
    },
    {
      "t": 102706,
      "e": 89221,
      "ty": 2,
      "x": 867,
      "y": 674
    },
    {
      "t": 102757,
      "e": 89272,
      "ty": 41,
      "x": 13311,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 102807,
      "e": 89322,
      "ty": 2,
      "x": 872,
      "y": 667
    },
    {
      "t": 103007,
      "e": 89522,
      "ty": 41,
      "x": 13580,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 105907,
      "e": 92422,
      "ty": 2,
      "x": 871,
      "y": 667
    },
    {
      "t": 106007,
      "e": 92522,
      "ty": 2,
      "x": 843,
      "y": 686
    },
    {
      "t": 106007,
      "e": 92522,
      "ty": 41,
      "x": 5121,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 106207,
      "e": 92722,
      "ty": 2,
      "x": 837,
      "y": 691
    },
    {
      "t": 106243,
      "e": 92758,
      "ty": 6,
      "x": 833,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 106257,
      "e": 92772,
      "ty": 41,
      "x": 33161,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 106307,
      "e": 92822,
      "ty": 2,
      "x": 828,
      "y": 701
    },
    {
      "t": 106407,
      "e": 92922,
      "ty": 2,
      "x": 826,
      "y": 703
    },
    {
      "t": 106507,
      "e": 93022,
      "ty": 41,
      "x": 0,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 107077,
      "e": 93592,
      "ty": 3,
      "x": 826,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 107079,
      "e": 93594,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 107079,
      "e": 93594,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 107195,
      "e": 93710,
      "ty": 4,
      "x": 0,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 107196,
      "e": 93711,
      "ty": 5,
      "x": 826,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 107196,
      "e": 93711,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 107317,
      "e": 93832,
      "ty": 7,
      "x": 824,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 107407,
      "e": 93922,
      "ty": 2,
      "x": 824,
      "y": 704
    },
    {
      "t": 107507,
      "e": 94022,
      "ty": 2,
      "x": 823,
      "y": 705
    },
    {
      "t": 107507,
      "e": 94022,
      "ty": 41,
      "x": 397,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 107607,
      "e": 94122,
      "ty": 2,
      "x": 821,
      "y": 707
    },
    {
      "t": 107707,
      "e": 94222,
      "ty": 2,
      "x": 823,
      "y": 744
    },
    {
      "t": 107757,
      "e": 94272,
      "ty": 41,
      "x": 241,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 107807,
      "e": 94322,
      "ty": 2,
      "x": 822,
      "y": 750
    },
    {
      "t": 107907,
      "e": 94422,
      "ty": 2,
      "x": 822,
      "y": 751
    },
    {
      "t": 108007,
      "e": 94522,
      "ty": 2,
      "x": 815,
      "y": 759
    },
    {
      "t": 108007,
      "e": 94522,
      "ty": 41,
      "x": 27791,
      "y": 41603,
      "ta": "html > body"
    },
    {
      "t": 108107,
      "e": 94622,
      "ty": 2,
      "x": 804,
      "y": 777
    },
    {
      "t": 108207,
      "e": 94722,
      "ty": 2,
      "x": 785,
      "y": 911
    },
    {
      "t": 108257,
      "e": 94772,
      "ty": 41,
      "x": 26103,
      "y": 54455,
      "ta": "html > body"
    },
    {
      "t": 108307,
      "e": 94822,
      "ty": 2,
      "x": 765,
      "y": 1004
    },
    {
      "t": 108407,
      "e": 94922,
      "ty": 2,
      "x": 765,
      "y": 1013
    },
    {
      "t": 108507,
      "e": 95022,
      "ty": 2,
      "x": 777,
      "y": 1010
    },
    {
      "t": 108507,
      "e": 95022,
      "ty": 41,
      "x": 26482,
      "y": 55508,
      "ta": "html > body"
    },
    {
      "t": 108607,
      "e": 95122,
      "ty": 2,
      "x": 829,
      "y": 974
    },
    {
      "t": 108661,
      "e": 95176,
      "ty": 6,
      "x": 835,
      "y": 968,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 108707,
      "e": 95222,
      "ty": 2,
      "x": 836,
      "y": 968
    },
    {
      "t": 108757,
      "e": 95272,
      "ty": 41,
      "x": 48284,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 108807,
      "e": 95322,
      "ty": 2,
      "x": 829,
      "y": 968
    },
    {
      "t": 108811,
      "e": 95326,
      "ty": 7,
      "x": 824,
      "y": 968,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 108907,
      "e": 95422,
      "ty": 2,
      "x": 824,
      "y": 968
    },
    {
      "t": 109008,
      "e": 95523,
      "ty": 41,
      "x": 2085,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 109207,
      "e": 95722,
      "ty": 2,
      "x": 825,
      "y": 968
    },
    {
      "t": 109229,
      "e": 95744,
      "ty": 6,
      "x": 827,
      "y": 966,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 109257,
      "e": 95772,
      "ty": 41,
      "x": 7955,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 109307,
      "e": 95822,
      "ty": 2,
      "x": 833,
      "y": 959
    },
    {
      "t": 109508,
      "e": 95822,
      "ty": 41,
      "x": 33161,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 109516,
      "e": 95830,
      "ty": 3,
      "x": 833,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 109518,
      "e": 95832,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 109518,
      "e": 95832,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 109628,
      "e": 95942,
      "ty": 4,
      "x": 33161,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 109628,
      "e": 95942,
      "ty": 5,
      "x": 833,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 109629,
      "e": 95943,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 109728,
      "e": 96042,
      "ty": 7,
      "x": 843,
      "y": 966,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 109757,
      "e": 96071,
      "ty": 41,
      "x": 6544,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 109807,
      "e": 96121,
      "ty": 2,
      "x": 865,
      "y": 992
    },
    {
      "t": 109907,
      "e": 96221,
      "ty": 2,
      "x": 880,
      "y": 1001
    },
    {
      "t": 109912,
      "e": 96226,
      "ty": 6,
      "x": 884,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 110007,
      "e": 96321,
      "ty": 2,
      "x": 895,
      "y": 1022
    },
    {
      "t": 110007,
      "e": 96321,
      "ty": 41,
      "x": 33798,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 110107,
      "e": 96421,
      "ty": 2,
      "x": 896,
      "y": 1024
    },
    {
      "t": 110165,
      "e": 96479,
      "ty": 3,
      "x": 896,
      "y": 1024,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 110166,
      "e": 96480,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 110166,
      "e": 96480,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 110252,
      "e": 96566,
      "ty": 4,
      "x": 34313,
      "y": 37732,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 110253,
      "e": 96567,
      "ty": 5,
      "x": 896,
      "y": 1024,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 110257,
      "e": 96571,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 110257,
      "e": 96571,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 110258,
      "e": 96572,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 110260,
      "e": 96574,
      "ty": 41,
      "x": 30580,
      "y": 56283,
      "ta": "html > body"
    },
    {
      "t": 110307,
      "e": 96621,
      "ty": 2,
      "x": 894,
      "y": 978
    },
    {
      "t": 110407,
      "e": 96721,
      "ty": 2,
      "x": 890,
      "y": 968
    },
    {
      "t": 110507,
      "e": 96821,
      "ty": 41,
      "x": 30374,
      "y": 53181,
      "ta": "html > body"
    },
    {
      "t": 111578,
      "e": 97892,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 120007,
      "e": 101821,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 121507,
      "e": 101821,
      "ty": 2,
      "x": 857,
      "y": 968
    },
    {
      "t": 121507,
      "e": 101821,
      "ty": 41,
      "x": 27724,
      "y": 58285,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 121607,
      "e": 101921,
      "ty": 2,
      "x": 812,
      "y": 967
    },
    {
      "t": 121707,
      "e": 102021,
      "ty": 2,
      "x": 811,
      "y": 967
    },
    {
      "t": 121757,
      "e": 102071,
      "ty": 41,
      "x": 25461,
      "y": 58216,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 121907,
      "e": 102221,
      "ty": 2,
      "x": 808,
      "y": 971
    },
    {
      "t": 122007,
      "e": 102321,
      "ty": 2,
      "x": 836,
      "y": 1007
    },
    {
      "t": 122007,
      "e": 102321,
      "ty": 41,
      "x": 26691,
      "y": 60986,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 122107,
      "e": 102421,
      "ty": 2,
      "x": 907,
      "y": 1049
    },
    {
      "t": 122155,
      "e": 102469,
      "ty": 6,
      "x": 942,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 122206,
      "e": 102520,
      "ty": 2,
      "x": 947,
      "y": 1078
    },
    {
      "t": 122256,
      "e": 102570,
      "ty": 41,
      "x": 22118,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 122306,
      "e": 102620,
      "ty": 2,
      "x": 957,
      "y": 1088
    },
    {
      "t": 122407,
      "e": 102721,
      "ty": 2,
      "x": 958,
      "y": 1091
    },
    {
      "t": 122507,
      "e": 102821,
      "ty": 41,
      "x": 26487,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 123149,
      "e": 103463,
      "ty": 3,
      "x": 958,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 123151,
      "e": 103465,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 123275,
      "e": 103589,
      "ty": 4,
      "x": 26487,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 123275,
      "e": 103589,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 123276,
      "e": 103590,
      "ty": 5,
      "x": 958,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 123277,
      "e": 103591,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 124309,
      "e": 104623,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 125207,
      "e": 105521,
      "ty": 2,
      "x": 950,
      "y": 1089
    },
    {
      "t": 125257,
      "e": 105571,
      "ty": 41,
      "x": 27902,
      "y": 32882,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 125306,
      "e": 105620,
      "ty": 2,
      "x": 793,
      "y": 1056
    },
    {
      "t": 125407,
      "e": 105721,
      "ty": 2,
      "x": 748,
      "y": 1050
    },
    {
      "t": 125507,
      "e": 105821,
      "ty": 2,
      "x": 746,
      "y": 1050
    },
    {
      "t": 125507,
      "e": 105821,
      "ty": 41,
      "x": 20474,
      "y": 32877,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 125568,
      "e": 105882,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 130471, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 130478, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 3420, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 135237, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 12609, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"NOVEMBER\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 148853, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 3344, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 153294, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 3848, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 158145, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 19128, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 178643, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-11 AM-A -A -A -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:943,y:1019,t:1527271733902};\\\", \\\"{x:943,y:1007,t:1527271733910};\\\", \\\"{x:941,y:995,t:1527271733921};\\\", \\\"{x:921,y:964,t:1527271733938};\\\", \\\"{x:871,y:895,t:1527271733955};\\\", \\\"{x:835,y:842,t:1527271733972};\\\", \\\"{x:817,y:812,t:1527271733989};\\\", \\\"{x:806,y:781,t:1527271734006};\\\", \\\"{x:789,y:745,t:1527271734021};\\\", \\\"{x:777,y:719,t:1527271734039};\\\", \\\"{x:767,y:688,t:1527271734056};\\\", \\\"{x:755,y:666,t:1527271734072};\\\", \\\"{x:747,y:646,t:1527271734089};\\\", \\\"{x:738,y:628,t:1527271734106};\\\", \\\"{x:725,y:613,t:1527271734122};\\\", \\\"{x:711,y:598,t:1527271734139};\\\", \\\"{x:686,y:577,t:1527271734156};\\\", \\\"{x:661,y:562,t:1527271734173};\\\", \\\"{x:634,y:545,t:1527271734188};\\\", \\\"{x:610,y:530,t:1527271734206};\\\", \\\"{x:598,y:518,t:1527271734223};\\\", \\\"{x:589,y:509,t:1527271734238};\\\", \\\"{x:585,y:507,t:1527271734255};\\\", \\\"{x:581,y:501,t:1527271734273};\\\", \\\"{x:577,y:496,t:1527271734289};\\\", \\\"{x:570,y:489,t:1527271734305};\\\", \\\"{x:561,y:478,t:1527271734322};\\\", \\\"{x:557,y:474,t:1527271734338};\\\", \\\"{x:557,y:473,t:1527271734355};\\\", \\\"{x:556,y:473,t:1527271734445};\\\", \\\"{x:556,y:472,t:1527271734455};\\\", \\\"{x:553,y:472,t:1527271734473};\\\", \\\"{x:550,y:472,t:1527271734489};\\\", \\\"{x:547,y:472,t:1527271734506};\\\", \\\"{x:543,y:472,t:1527271734523};\\\", \\\"{x:538,y:473,t:1527271734539};\\\", \\\"{x:532,y:476,t:1527271734557};\\\", \\\"{x:528,y:478,t:1527271734573};\\\", \\\"{x:525,y:479,t:1527271734589};\\\", \\\"{x:524,y:481,t:1527271734606};\\\", \\\"{x:523,y:482,t:1527271734623};\\\", \\\"{x:523,y:483,t:1527271734652};\\\", \\\"{x:523,y:484,t:1527271734660};\\\", \\\"{x:523,y:485,t:1527271734684};\\\", \\\"{x:522,y:486,t:1527271734692};\\\", \\\"{x:521,y:486,t:1527271734773};\\\", \\\"{x:521,y:485,t:1527271735077};\\\", \\\"{x:521,y:484,t:1527271735089};\\\", \\\"{x:524,y:483,t:1527271735106};\\\", \\\"{x:525,y:483,t:1527271735124};\\\", \\\"{x:525,y:482,t:1527271735139};\\\", \\\"{x:527,y:482,t:1527271735156};\\\", \\\"{x:528,y:482,t:1527271735180};\\\", \\\"{x:529,y:481,t:1527271735189};\\\", \\\"{x:530,y:481,t:1527271735206};\\\", \\\"{x:531,y:482,t:1527271735692};\\\", \\\"{x:532,y:484,t:1527271735706};\\\", \\\"{x:532,y:487,t:1527271735723};\\\", \\\"{x:534,y:489,t:1527271735739};\\\", \\\"{x:535,y:489,t:1527271736301};\\\", \\\"{x:537,y:489,t:1527271736308};\\\", \\\"{x:539,y:489,t:1527271736324};\\\", \\\"{x:540,y:489,t:1527271736339};\\\", \\\"{x:543,y:489,t:1527271736356};\\\", \\\"{x:544,y:489,t:1527271736397};\\\", \\\"{x:546,y:489,t:1527271736406};\\\", \\\"{x:551,y:489,t:1527271736424};\\\", \\\"{x:557,y:489,t:1527271736439};\\\", \\\"{x:559,y:489,t:1527271736456};\\\", \\\"{x:565,y:489,t:1527271736473};\\\", \\\"{x:566,y:489,t:1527271736488};\\\", \\\"{x:566,y:488,t:1527271736548};\\\", \\\"{x:566,y:487,t:1527271736580};\\\", \\\"{x:566,y:486,t:1527271736653};\\\", \\\"{x:566,y:485,t:1527271736701};\\\", \\\"{x:566,y:484,t:1527271736708};\\\", \\\"{x:566,y:483,t:1527271736757};\\\", \\\"{x:566,y:482,t:1527271736772};\\\", \\\"{x:567,y:482,t:1527271736805};\\\", \\\"{x:568,y:482,t:1527271736901};\\\", \\\"{x:569,y:482,t:1527271736924};\\\", \\\"{x:571,y:482,t:1527271736940};\\\", \\\"{x:579,y:484,t:1527271736956};\\\", \\\"{x:586,y:486,t:1527271736972};\\\", \\\"{x:594,y:491,t:1527271736989};\\\", \\\"{x:603,y:495,t:1527271737006};\\\", \\\"{x:616,y:503,t:1527271737022};\\\", \\\"{x:632,y:509,t:1527271737040};\\\", \\\"{x:651,y:520,t:1527271737056};\\\", \\\"{x:675,y:534,t:1527271737072};\\\", \\\"{x:730,y:558,t:1527271737092};\\\", \\\"{x:771,y:582,t:1527271737108};\\\", \\\"{x:803,y:601,t:1527271737124};\\\", \\\"{x:835,y:613,t:1527271737141};\\\", \\\"{x:857,y:627,t:1527271737157};\\\", \\\"{x:878,y:648,t:1527271737174};\\\", \\\"{x:895,y:662,t:1527271737191};\\\", \\\"{x:925,y:678,t:1527271737207};\\\", \\\"{x:944,y:681,t:1527271737224};\\\", \\\"{x:958,y:691,t:1527271737242};\\\", \\\"{x:983,y:702,t:1527271737257};\\\", \\\"{x:1001,y:712,t:1527271737274};\\\", \\\"{x:1025,y:727,t:1527271737292};\\\", \\\"{x:1036,y:736,t:1527271737308};\\\", \\\"{x:1042,y:743,t:1527271737325};\\\", \\\"{x:1048,y:747,t:1527271737341};\\\", \\\"{x:1054,y:755,t:1527271737359};\\\", \\\"{x:1062,y:761,t:1527271737374};\\\", \\\"{x:1071,y:767,t:1527271737392};\\\", \\\"{x:1080,y:773,t:1527271737409};\\\", \\\"{x:1096,y:787,t:1527271737425};\\\", \\\"{x:1115,y:806,t:1527271737441};\\\", \\\"{x:1144,y:829,t:1527271737458};\\\", \\\"{x:1169,y:849,t:1527271737475};\\\", \\\"{x:1195,y:866,t:1527271737492};\\\", \\\"{x:1200,y:874,t:1527271737508};\\\", \\\"{x:1213,y:887,t:1527271737524};\\\", \\\"{x:1230,y:900,t:1527271737542};\\\", \\\"{x:1255,y:909,t:1527271737558};\\\", \\\"{x:1274,y:923,t:1527271737574};\\\", \\\"{x:1295,y:931,t:1527271737591};\\\", \\\"{x:1307,y:936,t:1527271737608};\\\", \\\"{x:1319,y:942,t:1527271737624};\\\", \\\"{x:1324,y:945,t:1527271737641};\\\", \\\"{x:1327,y:948,t:1527271737659};\\\", \\\"{x:1329,y:951,t:1527271737674};\\\", \\\"{x:1331,y:952,t:1527271737691};\\\", \\\"{x:1331,y:953,t:1527271737708};\\\", \\\"{x:1331,y:954,t:1527271737748};\\\", \\\"{x:1327,y:954,t:1527271737759};\\\", \\\"{x:1317,y:961,t:1527271737775};\\\", \\\"{x:1313,y:963,t:1527271737792};\\\", \\\"{x:1312,y:966,t:1527271737809};\\\", \\\"{x:1310,y:966,t:1527271738093};\\\", \\\"{x:1305,y:966,t:1527271738109};\\\", \\\"{x:1301,y:966,t:1527271738127};\\\", \\\"{x:1300,y:966,t:1527271738143};\\\", \\\"{x:1299,y:967,t:1527271738164};\\\", \\\"{x:1295,y:967,t:1527271738429};\\\", \\\"{x:1294,y:967,t:1527271738444};\\\", \\\"{x:1287,y:967,t:1527271738459};\\\", \\\"{x:1282,y:970,t:1527271738476};\\\", \\\"{x:1280,y:970,t:1527271738492};\\\", \\\"{x:1279,y:970,t:1527271738723};\\\", \\\"{x:1279,y:969,t:1527271738731};\\\", \\\"{x:1279,y:968,t:1527271738743};\\\", \\\"{x:1279,y:962,t:1527271738759};\\\", \\\"{x:1279,y:959,t:1527271738775};\\\", \\\"{x:1279,y:954,t:1527271738793};\\\", \\\"{x:1279,y:951,t:1527271738810};\\\", \\\"{x:1279,y:946,t:1527271738826};\\\", \\\"{x:1279,y:942,t:1527271738843};\\\", \\\"{x:1279,y:933,t:1527271738860};\\\", \\\"{x:1279,y:923,t:1527271738876};\\\", \\\"{x:1279,y:916,t:1527271738892};\\\", \\\"{x:1277,y:909,t:1527271738909};\\\", \\\"{x:1277,y:900,t:1527271738926};\\\", \\\"{x:1277,y:889,t:1527271738943};\\\", \\\"{x:1276,y:875,t:1527271738960};\\\", \\\"{x:1275,y:864,t:1527271738975};\\\", \\\"{x:1274,y:851,t:1527271738993};\\\", \\\"{x:1273,y:843,t:1527271739010};\\\", \\\"{x:1273,y:834,t:1527271739026};\\\", \\\"{x:1270,y:832,t:1527271739043};\\\", \\\"{x:1269,y:832,t:1527271739059};\\\", \\\"{x:1269,y:830,t:1527271739076};\\\", \\\"{x:1269,y:827,t:1527271739116};\\\", \\\"{x:1269,y:826,t:1527271739147};\\\", \\\"{x:1269,y:825,t:1527271739486};\\\", \\\"{x:1262,y:819,t:1527271739493};\\\", \\\"{x:1237,y:802,t:1527271739510};\\\", \\\"{x:1170,y:771,t:1527271739527};\\\", \\\"{x:1101,y:731,t:1527271739543};\\\", \\\"{x:1001,y:697,t:1527271739561};\\\", \\\"{x:892,y:662,t:1527271739578};\\\", \\\"{x:779,y:629,t:1527271739594};\\\", \\\"{x:690,y:599,t:1527271739611};\\\", \\\"{x:631,y:582,t:1527271739626};\\\", \\\"{x:590,y:567,t:1527271739643};\\\", \\\"{x:558,y:555,t:1527271739659};\\\", \\\"{x:525,y:546,t:1527271739676};\\\", \\\"{x:498,y:540,t:1527271739694};\\\", \\\"{x:473,y:536,t:1527271739710};\\\", \\\"{x:451,y:530,t:1527271739727};\\\", \\\"{x:441,y:526,t:1527271739743};\\\", \\\"{x:429,y:525,t:1527271739760};\\\", \\\"{x:428,y:525,t:1527271739780};\\\", \\\"{x:425,y:525,t:1527271739803};\\\", \\\"{x:421,y:525,t:1527271739811};\\\", \\\"{x:417,y:525,t:1527271739827};\\\", \\\"{x:409,y:525,t:1527271739843};\\\", \\\"{x:398,y:523,t:1527271739861};\\\", \\\"{x:391,y:521,t:1527271739877};\\\", \\\"{x:379,y:519,t:1527271739894};\\\", \\\"{x:366,y:515,t:1527271739911};\\\", \\\"{x:363,y:515,t:1527271739927};\\\", \\\"{x:366,y:515,t:1527271740132};\\\", \\\"{x:369,y:515,t:1527271740145};\\\", \\\"{x:371,y:515,t:1527271740160};\\\", \\\"{x:372,y:515,t:1527271740357};\\\", \\\"{x:374,y:517,t:1527271740365};\\\", \\\"{x:376,y:517,t:1527271740379};\\\", \\\"{x:378,y:519,t:1527271740393};\\\", \\\"{x:378,y:520,t:1527271742443};\\\", \\\"{x:395,y:523,t:1527271742451};\\\", \\\"{x:417,y:528,t:1527271742462};\\\", \\\"{x:517,y:556,t:1527271742479};\\\", \\\"{x:639,y:594,t:1527271742497};\\\", \\\"{x:797,y:640,t:1527271742513};\\\", \\\"{x:953,y:694,t:1527271742528};\\\", \\\"{x:1077,y:725,t:1527271742546};\\\", \\\"{x:1168,y:767,t:1527271742563};\\\", \\\"{x:1204,y:784,t:1527271742579};\\\", \\\"{x:1225,y:796,t:1527271742595};\\\", \\\"{x:1231,y:800,t:1527271742613};\\\", \\\"{x:1238,y:806,t:1527271742629};\\\", \\\"{x:1246,y:811,t:1527271742646};\\\", \\\"{x:1248,y:814,t:1527271742663};\\\", \\\"{x:1251,y:817,t:1527271742679};\\\", \\\"{x:1251,y:818,t:1527271742733};\\\", \\\"{x:1253,y:823,t:1527271742746};\\\", \\\"{x:1255,y:831,t:1527271742763};\\\", \\\"{x:1261,y:840,t:1527271742779};\\\", \\\"{x:1278,y:857,t:1527271742796};\\\", \\\"{x:1295,y:867,t:1527271742814};\\\", \\\"{x:1313,y:876,t:1527271742829};\\\", \\\"{x:1323,y:882,t:1527271742846};\\\", \\\"{x:1331,y:886,t:1527271742864};\\\", \\\"{x:1331,y:888,t:1527271742879};\\\", \\\"{x:1331,y:890,t:1527271742900};\\\", \\\"{x:1331,y:891,t:1527271742914};\\\", \\\"{x:1331,y:892,t:1527271742930};\\\", \\\"{x:1331,y:893,t:1527271742946};\\\", \\\"{x:1330,y:894,t:1527271742963};\\\", \\\"{x:1330,y:897,t:1527271742979};\\\", \\\"{x:1327,y:902,t:1527271742996};\\\", \\\"{x:1323,y:907,t:1527271743013};\\\", \\\"{x:1320,y:913,t:1527271743030};\\\", \\\"{x:1314,y:917,t:1527271743046};\\\", \\\"{x:1305,y:926,t:1527271743063};\\\", \\\"{x:1300,y:933,t:1527271743080};\\\", \\\"{x:1290,y:939,t:1527271743096};\\\", \\\"{x:1288,y:941,t:1527271743113};\\\", \\\"{x:1288,y:943,t:1527271743130};\\\", \\\"{x:1288,y:944,t:1527271743293};\\\", \\\"{x:1290,y:944,t:1527271743317};\\\", \\\"{x:1292,y:944,t:1527271743330};\\\", \\\"{x:1298,y:936,t:1527271743346};\\\", \\\"{x:1300,y:930,t:1527271743364};\\\", \\\"{x:1303,y:915,t:1527271743380};\\\", \\\"{x:1303,y:905,t:1527271743397};\\\", \\\"{x:1301,y:896,t:1527271743413};\\\", \\\"{x:1293,y:881,t:1527271743431};\\\", \\\"{x:1289,y:874,t:1527271743447};\\\", \\\"{x:1288,y:868,t:1527271743463};\\\", \\\"{x:1288,y:863,t:1527271743480};\\\", \\\"{x:1285,y:858,t:1527271743498};\\\", \\\"{x:1285,y:853,t:1527271743513};\\\", \\\"{x:1283,y:847,t:1527271743531};\\\", \\\"{x:1282,y:843,t:1527271743547};\\\", \\\"{x:1281,y:838,t:1527271743564};\\\", \\\"{x:1279,y:833,t:1527271743584};\\\", \\\"{x:1278,y:831,t:1527271743597};\\\", \\\"{x:1277,y:827,t:1527271743613};\\\", \\\"{x:1276,y:821,t:1527271743630};\\\", \\\"{x:1274,y:816,t:1527271743647};\\\", \\\"{x:1273,y:813,t:1527271743663};\\\", \\\"{x:1272,y:812,t:1527271743680};\\\", \\\"{x:1272,y:813,t:1527271743861};\\\", \\\"{x:1272,y:815,t:1527271743868};\\\", \\\"{x:1272,y:816,t:1527271743881};\\\", \\\"{x:1272,y:817,t:1527271743897};\\\", \\\"{x:1272,y:818,t:1527271743915};\\\", \\\"{x:1272,y:820,t:1527271744013};\\\", \\\"{x:1272,y:823,t:1527271744029};\\\", \\\"{x:1272,y:825,t:1527271744061};\\\", \\\"{x:1272,y:826,t:1527271744077};\\\", \\\"{x:1273,y:827,t:1527271744085};\\\", \\\"{x:1276,y:828,t:1527271744098};\\\", \\\"{x:1277,y:830,t:1527271744114};\\\", \\\"{x:1278,y:831,t:1527271744131};\\\", \\\"{x:1279,y:831,t:1527271744253};\\\", \\\"{x:1280,y:831,t:1527271744268};\\\", \\\"{x:1281,y:830,t:1527271744282};\\\", \\\"{x:1282,y:829,t:1527271744297};\\\", \\\"{x:1286,y:824,t:1527271744316};\\\", \\\"{x:1289,y:818,t:1527271744332};\\\", \\\"{x:1290,y:812,t:1527271744348};\\\", \\\"{x:1293,y:801,t:1527271744365};\\\", \\\"{x:1297,y:796,t:1527271744382};\\\", \\\"{x:1300,y:788,t:1527271744397};\\\", \\\"{x:1302,y:781,t:1527271744415};\\\", \\\"{x:1303,y:772,t:1527271744432};\\\", \\\"{x:1304,y:762,t:1527271744447};\\\", \\\"{x:1306,y:758,t:1527271744465};\\\", \\\"{x:1306,y:754,t:1527271744482};\\\", \\\"{x:1306,y:752,t:1527271744497};\\\", \\\"{x:1306,y:751,t:1527271744514};\\\", \\\"{x:1307,y:748,t:1527271744532};\\\", \\\"{x:1307,y:747,t:1527271744548};\\\", \\\"{x:1308,y:741,t:1527271744565};\\\", \\\"{x:1308,y:735,t:1527271744582};\\\", \\\"{x:1308,y:731,t:1527271744597};\\\", \\\"{x:1308,y:726,t:1527271744614};\\\", \\\"{x:1308,y:722,t:1527271744632};\\\", \\\"{x:1308,y:719,t:1527271744648};\\\", \\\"{x:1307,y:715,t:1527271744665};\\\", \\\"{x:1306,y:712,t:1527271744684};\\\", \\\"{x:1306,y:711,t:1527271744698};\\\", \\\"{x:1305,y:708,t:1527271744715};\\\", \\\"{x:1304,y:704,t:1527271744732};\\\", \\\"{x:1304,y:701,t:1527271744748};\\\", \\\"{x:1303,y:693,t:1527271744764};\\\", \\\"{x:1300,y:680,t:1527271744782};\\\", \\\"{x:1299,y:666,t:1527271744799};\\\", \\\"{x:1299,y:651,t:1527271744815};\\\", \\\"{x:1294,y:633,t:1527271744831};\\\", \\\"{x:1294,y:613,t:1527271744848};\\\", \\\"{x:1294,y:598,t:1527271744865};\\\", \\\"{x:1294,y:587,t:1527271744882};\\\", \\\"{x:1294,y:581,t:1527271744899};\\\", \\\"{x:1294,y:578,t:1527271744915};\\\", \\\"{x:1294,y:577,t:1527271744932};\\\", \\\"{x:1293,y:576,t:1527271744981};\\\", \\\"{x:1292,y:576,t:1527271744999};\\\", \\\"{x:1289,y:575,t:1527271745015};\\\", \\\"{x:1286,y:575,t:1527271745031};\\\", \\\"{x:1284,y:575,t:1527271745049};\\\", \\\"{x:1283,y:575,t:1527271745064};\\\", \\\"{x:1282,y:578,t:1527271745133};\\\", \\\"{x:1282,y:579,t:1527271745165};\\\", \\\"{x:1282,y:581,t:1527271745182};\\\", \\\"{x:1282,y:583,t:1527271745205};\\\", \\\"{x:1282,y:584,t:1527271745215};\\\", \\\"{x:1284,y:588,t:1527271745231};\\\", \\\"{x:1289,y:592,t:1527271745249};\\\", \\\"{x:1298,y:598,t:1527271745266};\\\", \\\"{x:1307,y:606,t:1527271745282};\\\", \\\"{x:1314,y:610,t:1527271745299};\\\", \\\"{x:1318,y:613,t:1527271745316};\\\", \\\"{x:1320,y:615,t:1527271745332};\\\", \\\"{x:1322,y:618,t:1527271745348};\\\", \\\"{x:1324,y:620,t:1527271745366};\\\", \\\"{x:1324,y:621,t:1527271745381};\\\", \\\"{x:1325,y:624,t:1527271745399};\\\", \\\"{x:1325,y:626,t:1527271745421};\\\", \\\"{x:1326,y:627,t:1527271745432};\\\", \\\"{x:1327,y:628,t:1527271745448};\\\", \\\"{x:1327,y:629,t:1527271745465};\\\", \\\"{x:1327,y:630,t:1527271745485};\\\", \\\"{x:1326,y:631,t:1527271745499};\\\", \\\"{x:1324,y:632,t:1527271745516};\\\", \\\"{x:1324,y:633,t:1527271745532};\\\", \\\"{x:1323,y:634,t:1527271745565};\\\", \\\"{x:1323,y:635,t:1527271745597};\\\", \\\"{x:1321,y:635,t:1527271745661};\\\", \\\"{x:1319,y:635,t:1527271745685};\\\", \\\"{x:1318,y:637,t:1527271745717};\\\", \\\"{x:1317,y:637,t:1527271745845};\\\", \\\"{x:1315,y:637,t:1527271745925};\\\", \\\"{x:1313,y:637,t:1527271745949};\\\", \\\"{x:1312,y:637,t:1527271745965};\\\", \\\"{x:1311,y:637,t:1527271746021};\\\", \\\"{x:1310,y:637,t:1527271746051};\\\", \\\"{x:1309,y:637,t:1527271746163};\\\", \\\"{x:1308,y:637,t:1527271746445};\\\", \\\"{x:1307,y:637,t:1527271746485};\\\", \\\"{x:1306,y:637,t:1527271746501};\\\", \\\"{x:1305,y:637,t:1527271746525};\\\", \\\"{x:1303,y:637,t:1527271746540};\\\", \\\"{x:1302,y:637,t:1527271747005};\\\", \\\"{x:1302,y:638,t:1527271747053};\\\", \\\"{x:1301,y:639,t:1527271747069};\\\", \\\"{x:1300,y:639,t:1527271747084};\\\", \\\"{x:1301,y:638,t:1527271748292};\\\", \\\"{x:1302,y:638,t:1527271748325};\\\", \\\"{x:1303,y:637,t:1527271748389};\\\", \\\"{x:1304,y:637,t:1527271748412};\\\", \\\"{x:1304,y:636,t:1527271748420};\\\", \\\"{x:1305,y:636,t:1527271748460};\\\", \\\"{x:1304,y:636,t:1527271749589};\\\", \\\"{x:1302,y:635,t:1527271749628};\\\", \\\"{x:1302,y:633,t:1527271749637};\\\", \\\"{x:1302,y:632,t:1527271749707};\\\", \\\"{x:1302,y:630,t:1527271749723};\\\", \\\"{x:1302,y:629,t:1527271749735};\\\", \\\"{x:1300,y:625,t:1527271749751};\\\", \\\"{x:1298,y:621,t:1527271749768};\\\", \\\"{x:1295,y:619,t:1527271749785};\\\", \\\"{x:1295,y:616,t:1527271749802};\\\", \\\"{x:1294,y:614,t:1527271749818};\\\", \\\"{x:1293,y:612,t:1527271749835};\\\", \\\"{x:1291,y:608,t:1527271749852};\\\", \\\"{x:1288,y:605,t:1527271749868};\\\", \\\"{x:1284,y:602,t:1527271749886};\\\", \\\"{x:1279,y:600,t:1527271749901};\\\", \\\"{x:1269,y:596,t:1527271749919};\\\", \\\"{x:1260,y:592,t:1527271749936};\\\", \\\"{x:1244,y:587,t:1527271749951};\\\", \\\"{x:1225,y:584,t:1527271749968};\\\", \\\"{x:1213,y:578,t:1527271749986};\\\", \\\"{x:1184,y:574,t:1527271750002};\\\", \\\"{x:1161,y:572,t:1527271750019};\\\", \\\"{x:1139,y:567,t:1527271750036};\\\", \\\"{x:1107,y:566,t:1527271750053};\\\", \\\"{x:1090,y:569,t:1527271750069};\\\", \\\"{x:1067,y:575,t:1527271750086};\\\", \\\"{x:1037,y:590,t:1527271750103};\\\", \\\"{x:977,y:610,t:1527271750119};\\\", \\\"{x:903,y:640,t:1527271750136};\\\", \\\"{x:846,y:675,t:1527271750152};\\\", \\\"{x:806,y:713,t:1527271750168};\\\", \\\"{x:780,y:739,t:1527271750186};\\\", \\\"{x:751,y:766,t:1527271750203};\\\", \\\"{x:724,y:791,t:1527271750219};\\\", \\\"{x:690,y:817,t:1527271750236};\\\", \\\"{x:665,y:833,t:1527271750253};\\\", \\\"{x:654,y:840,t:1527271750269};\\\", \\\"{x:635,y:844,t:1527271750285};\\\", \\\"{x:613,y:845,t:1527271750303};\\\", \\\"{x:596,y:847,t:1527271750318};\\\", \\\"{x:593,y:847,t:1527271750335};\\\", \\\"{x:593,y:848,t:1527271750352};\\\", \\\"{x:592,y:848,t:1527271750369};\\\", \\\"{x:590,y:848,t:1527271750385};\\\", \\\"{x:586,y:845,t:1527271750403};\\\", \\\"{x:581,y:832,t:1527271750419};\\\", \\\"{x:574,y:808,t:1527271750436};\\\", \\\"{x:556,y:770,t:1527271750452};\\\", \\\"{x:550,y:749,t:1527271750469};\\\", \\\"{x:544,y:732,t:1527271750487};\\\", \\\"{x:539,y:717,t:1527271750502};\\\", \\\"{x:536,y:708,t:1527271750519};\\\", \\\"{x:536,y:706,t:1527271750535};\\\", \\\"{x:535,y:701,t:1527271750552};\\\", \\\"{x:535,y:699,t:1527271750569};\\\", \\\"{x:535,y:695,t:1527271750585};\\\", \\\"{x:535,y:694,t:1527271750602};\\\", \\\"{x:535,y:692,t:1527271750619};\\\", \\\"{x:535,y:691,t:1527271750668};\\\", \\\"{x:535,y:693,t:1527271750773};\\\", \\\"{x:535,y:694,t:1527271750786};\\\", \\\"{x:535,y:699,t:1527271750802};\\\", \\\"{x:535,y:700,t:1527271750819};\\\", \\\"{x:535,y:701,t:1527271751141};\\\", \\\"{x:535,y:705,t:1527271751156};\\\", \\\"{x:535,y:709,t:1527271751171};\\\", \\\"{x:536,y:710,t:1527271751186};\\\", \\\"{x:537,y:712,t:1527271751203};\\\", \\\"{x:537,y:714,t:1527271751219};\\\", \\\"{x:537,y:715,t:1527271751251};\\\", \\\"{x:537,y:717,t:1527271751699};\\\", \\\"{x:537,y:718,t:1527271751708};\\\", \\\"{x:536,y:718,t:1527271751739};\\\", \\\"{x:536,y:720,t:1527271751772};\\\", \\\"{x:535,y:721,t:1527271751787};\\\", \\\"{x:535,y:722,t:1527271751804};\\\", \\\"{x:535,y:723,t:1527271751828};\\\", \\\"{x:534,y:725,t:1527271751868};\\\" ] }, { \\\"rt\\\": 16813, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 196780, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:726,t:1527271753975};\\\", \\\"{x:535,y:726,t:1527271753990};\\\", \\\"{x:544,y:726,t:1527271753998};\\\", \\\"{x:559,y:728,t:1527271754010};\\\", \\\"{x:597,y:735,t:1527271754028};\\\", \\\"{x:650,y:743,t:1527271754044};\\\", \\\"{x:685,y:756,t:1527271754058};\\\", \\\"{x:700,y:761,t:1527271754074};\\\", \\\"{x:717,y:769,t:1527271754091};\\\", \\\"{x:722,y:771,t:1527271754108};\\\", \\\"{x:724,y:772,t:1527271754124};\\\", \\\"{x:725,y:772,t:1527271754176};\\\", \\\"{x:727,y:772,t:1527271754192};\\\", \\\"{x:728,y:772,t:1527271754224};\\\", \\\"{x:729,y:772,t:1527271754264};\\\", \\\"{x:731,y:771,t:1527271754280};\\\", \\\"{x:732,y:771,t:1527271754303};\\\", \\\"{x:733,y:771,t:1527271754311};\\\", \\\"{x:734,y:770,t:1527271754326};\\\", \\\"{x:734,y:772,t:1527271756871};\\\", \\\"{x:738,y:774,t:1527271756879};\\\", \\\"{x:749,y:778,t:1527271756894};\\\", \\\"{x:790,y:793,t:1527271756911};\\\", \\\"{x:803,y:797,t:1527271756927};\\\", \\\"{x:806,y:802,t:1527271756944};\\\", \\\"{x:809,y:804,t:1527271756961};\\\", \\\"{x:819,y:805,t:1527271756978};\\\", \\\"{x:828,y:807,t:1527271756994};\\\", \\\"{x:832,y:809,t:1527271757012};\\\", \\\"{x:846,y:812,t:1527271757028};\\\", \\\"{x:868,y:819,t:1527271757044};\\\", \\\"{x:890,y:823,t:1527271757061};\\\", \\\"{x:908,y:829,t:1527271757078};\\\", \\\"{x:933,y:833,t:1527271757094};\\\", \\\"{x:961,y:840,t:1527271757111};\\\", \\\"{x:976,y:841,t:1527271757128};\\\", \\\"{x:988,y:843,t:1527271757145};\\\", \\\"{x:994,y:844,t:1527271757161};\\\", \\\"{x:1007,y:845,t:1527271757179};\\\", \\\"{x:1025,y:851,t:1527271757195};\\\", \\\"{x:1057,y:860,t:1527271757211};\\\", \\\"{x:1086,y:862,t:1527271757228};\\\", \\\"{x:1118,y:873,t:1527271757244};\\\", \\\"{x:1160,y:879,t:1527271757261};\\\", \\\"{x:1188,y:887,t:1527271757278};\\\", \\\"{x:1229,y:899,t:1527271757296};\\\", \\\"{x:1240,y:907,t:1527271757311};\\\", \\\"{x:1260,y:913,t:1527271757328};\\\", \\\"{x:1264,y:914,t:1527271757346};\\\", \\\"{x:1268,y:917,t:1527271757361};\\\", \\\"{x:1271,y:917,t:1527271757384};\\\", \\\"{x:1272,y:918,t:1527271757396};\\\", \\\"{x:1281,y:929,t:1527271757412};\\\", \\\"{x:1281,y:932,t:1527271757428};\\\", \\\"{x:1283,y:931,t:1527271759320};\\\", \\\"{x:1284,y:921,t:1527271759329};\\\", \\\"{x:1290,y:905,t:1527271759346};\\\", \\\"{x:1295,y:888,t:1527271759364};\\\", \\\"{x:1303,y:866,t:1527271759379};\\\", \\\"{x:1309,y:844,t:1527271759396};\\\", \\\"{x:1314,y:829,t:1527271759413};\\\", \\\"{x:1319,y:812,t:1527271759429};\\\", \\\"{x:1327,y:792,t:1527271759446};\\\", \\\"{x:1334,y:772,t:1527271759462};\\\", \\\"{x:1342,y:752,t:1527271759479};\\\", \\\"{x:1347,y:735,t:1527271759496};\\\", \\\"{x:1350,y:724,t:1527271759512};\\\", \\\"{x:1354,y:715,t:1527271759530};\\\", \\\"{x:1359,y:709,t:1527271759546};\\\", \\\"{x:1362,y:706,t:1527271759563};\\\", \\\"{x:1362,y:701,t:1527271759581};\\\", \\\"{x:1362,y:699,t:1527271759596};\\\", \\\"{x:1362,y:694,t:1527271759613};\\\", \\\"{x:1362,y:689,t:1527271759630};\\\", \\\"{x:1362,y:684,t:1527271759646};\\\", \\\"{x:1362,y:678,t:1527271759663};\\\", \\\"{x:1362,y:675,t:1527271759679};\\\", \\\"{x:1362,y:669,t:1527271759697};\\\", \\\"{x:1363,y:666,t:1527271759713};\\\", \\\"{x:1363,y:663,t:1527271759730};\\\", \\\"{x:1363,y:662,t:1527271759746};\\\", \\\"{x:1364,y:660,t:1527271759763};\\\", \\\"{x:1366,y:658,t:1527271759780};\\\", \\\"{x:1367,y:655,t:1527271759796};\\\", \\\"{x:1367,y:652,t:1527271759813};\\\", \\\"{x:1369,y:648,t:1527271759831};\\\", \\\"{x:1370,y:642,t:1527271759846};\\\", \\\"{x:1376,y:629,t:1527271759864};\\\", \\\"{x:1384,y:604,t:1527271759880};\\\", \\\"{x:1401,y:575,t:1527271759896};\\\", \\\"{x:1409,y:562,t:1527271759915};\\\", \\\"{x:1425,y:538,t:1527271759930};\\\", \\\"{x:1436,y:523,t:1527271759946};\\\", \\\"{x:1442,y:512,t:1527271759962};\\\", \\\"{x:1442,y:511,t:1527271759980};\\\", \\\"{x:1442,y:512,t:1527271760038};\\\", \\\"{x:1442,y:513,t:1527271760071};\\\", \\\"{x:1440,y:516,t:1527271760086};\\\", \\\"{x:1438,y:519,t:1527271760097};\\\", \\\"{x:1432,y:525,t:1527271760113};\\\", \\\"{x:1424,y:535,t:1527271760130};\\\", \\\"{x:1414,y:543,t:1527271760147};\\\", \\\"{x:1406,y:548,t:1527271760163};\\\", \\\"{x:1397,y:557,t:1527271760180};\\\", \\\"{x:1390,y:567,t:1527271760197};\\\", \\\"{x:1384,y:574,t:1527271760213};\\\", \\\"{x:1379,y:582,t:1527271760230};\\\", \\\"{x:1371,y:590,t:1527271760247};\\\", \\\"{x:1368,y:594,t:1527271760263};\\\", \\\"{x:1365,y:597,t:1527271760280};\\\", \\\"{x:1363,y:600,t:1527271760298};\\\", \\\"{x:1363,y:601,t:1527271760313};\\\", \\\"{x:1363,y:604,t:1527271760335};\\\", \\\"{x:1363,y:606,t:1527271760351};\\\", \\\"{x:1363,y:608,t:1527271760363};\\\", \\\"{x:1363,y:612,t:1527271760380};\\\", \\\"{x:1363,y:620,t:1527271760397};\\\", \\\"{x:1369,y:631,t:1527271760413};\\\", \\\"{x:1377,y:640,t:1527271760430};\\\", \\\"{x:1395,y:658,t:1527271760447};\\\", \\\"{x:1412,y:669,t:1527271760464};\\\", \\\"{x:1424,y:682,t:1527271760480};\\\", \\\"{x:1436,y:693,t:1527271760498};\\\", \\\"{x:1451,y:703,t:1527271760514};\\\", \\\"{x:1470,y:714,t:1527271760530};\\\", \\\"{x:1481,y:722,t:1527271760548};\\\", \\\"{x:1492,y:729,t:1527271760565};\\\", \\\"{x:1498,y:731,t:1527271760581};\\\", \\\"{x:1499,y:731,t:1527271760598};\\\", \\\"{x:1501,y:731,t:1527271760712};\\\", \\\"{x:1502,y:731,t:1527271760720};\\\", \\\"{x:1503,y:729,t:1527271760730};\\\", \\\"{x:1506,y:724,t:1527271760747};\\\", \\\"{x:1510,y:720,t:1527271760764};\\\", \\\"{x:1517,y:713,t:1527271760780};\\\", \\\"{x:1523,y:709,t:1527271760798};\\\", \\\"{x:1530,y:705,t:1527271760815};\\\", \\\"{x:1537,y:700,t:1527271760831};\\\", \\\"{x:1543,y:696,t:1527271760847};\\\", \\\"{x:1545,y:695,t:1527271760864};\\\", \\\"{x:1548,y:693,t:1527271760881};\\\", \\\"{x:1551,y:689,t:1527271760903};\\\", \\\"{x:1552,y:688,t:1527271760919};\\\", \\\"{x:1553,y:688,t:1527271760967};\\\", \\\"{x:1556,y:685,t:1527271760983};\\\", \\\"{x:1557,y:682,t:1527271760996};\\\", \\\"{x:1558,y:681,t:1527271761014};\\\", \\\"{x:1561,y:678,t:1527271761031};\\\", \\\"{x:1566,y:671,t:1527271761047};\\\", \\\"{x:1570,y:665,t:1527271761064};\\\", \\\"{x:1578,y:654,t:1527271761081};\\\", \\\"{x:1581,y:646,t:1527271761097};\\\", \\\"{x:1586,y:639,t:1527271761114};\\\", \\\"{x:1588,y:634,t:1527271761132};\\\", \\\"{x:1592,y:627,t:1527271761147};\\\", \\\"{x:1595,y:621,t:1527271761165};\\\", \\\"{x:1596,y:612,t:1527271761183};\\\", \\\"{x:1597,y:610,t:1527271761197};\\\", \\\"{x:1599,y:602,t:1527271761214};\\\", \\\"{x:1600,y:593,t:1527271761231};\\\", \\\"{x:1600,y:586,t:1527271761247};\\\", \\\"{x:1600,y:583,t:1527271761264};\\\", \\\"{x:1600,y:578,t:1527271761281};\\\", \\\"{x:1599,y:573,t:1527271761298};\\\", \\\"{x:1599,y:567,t:1527271761314};\\\", \\\"{x:1598,y:560,t:1527271761331};\\\", \\\"{x:1597,y:552,t:1527271761348};\\\", \\\"{x:1597,y:544,t:1527271761365};\\\", \\\"{x:1597,y:527,t:1527271761383};\\\", \\\"{x:1597,y:520,t:1527271761399};\\\", \\\"{x:1597,y:514,t:1527271761415};\\\", \\\"{x:1601,y:514,t:1527271761431};\\\", \\\"{x:1601,y:513,t:1527271761448};\\\", \\\"{x:1602,y:507,t:1527271761464};\\\", \\\"{x:1602,y:502,t:1527271761482};\\\", \\\"{x:1602,y:500,t:1527271761499};\\\", \\\"{x:1600,y:496,t:1527271761515};\\\", \\\"{x:1600,y:495,t:1527271761532};\\\", \\\"{x:1599,y:492,t:1527271761548};\\\", \\\"{x:1597,y:490,t:1527271761565};\\\", \\\"{x:1596,y:489,t:1527271761583};\\\", \\\"{x:1595,y:486,t:1527271761598};\\\", \\\"{x:1594,y:485,t:1527271761615};\\\", \\\"{x:1594,y:482,t:1527271761631};\\\", \\\"{x:1594,y:480,t:1527271761647};\\\", \\\"{x:1594,y:479,t:1527271761686};\\\", \\\"{x:1594,y:478,t:1527271761726};\\\", \\\"{x:1595,y:478,t:1527271761864};\\\", \\\"{x:1596,y:478,t:1527271761879};\\\", \\\"{x:1596,y:476,t:1527271761896};\\\", \\\"{x:1596,y:475,t:1527271761911};\\\", \\\"{x:1597,y:474,t:1527271761919};\\\", \\\"{x:1598,y:473,t:1527271761935};\\\", \\\"{x:1599,y:473,t:1527271761960};\\\", \\\"{x:1599,y:472,t:1527271761991};\\\", \\\"{x:1600,y:471,t:1527271762000};\\\", \\\"{x:1601,y:469,t:1527271762016};\\\", \\\"{x:1603,y:466,t:1527271762031};\\\", \\\"{x:1604,y:464,t:1527271762048};\\\", \\\"{x:1604,y:462,t:1527271762065};\\\", \\\"{x:1605,y:459,t:1527271762082};\\\", \\\"{x:1605,y:454,t:1527271762099};\\\", \\\"{x:1605,y:449,t:1527271762115};\\\", \\\"{x:1605,y:445,t:1527271762131};\\\", \\\"{x:1605,y:441,t:1527271762148};\\\", \\\"{x:1606,y:440,t:1527271762165};\\\", \\\"{x:1606,y:438,t:1527271762183};\\\", \\\"{x:1606,y:436,t:1527271762199};\\\", \\\"{x:1606,y:434,t:1527271762215};\\\", \\\"{x:1606,y:433,t:1527271762232};\\\", \\\"{x:1603,y:432,t:1527271762248};\\\", \\\"{x:1599,y:433,t:1527271762265};\\\", \\\"{x:1596,y:434,t:1527271762282};\\\", \\\"{x:1596,y:435,t:1527271762319};\\\", \\\"{x:1596,y:436,t:1527271762332};\\\", \\\"{x:1596,y:441,t:1527271762349};\\\", \\\"{x:1596,y:447,t:1527271762365};\\\", \\\"{x:1595,y:455,t:1527271762383};\\\", \\\"{x:1595,y:460,t:1527271762398};\\\", \\\"{x:1595,y:478,t:1527271762415};\\\", \\\"{x:1595,y:491,t:1527271762433};\\\", \\\"{x:1594,y:497,t:1527271762448};\\\", \\\"{x:1594,y:506,t:1527271762466};\\\", \\\"{x:1591,y:523,t:1527271762483};\\\", \\\"{x:1586,y:538,t:1527271762498};\\\", \\\"{x:1586,y:544,t:1527271762516};\\\", \\\"{x:1586,y:550,t:1527271762533};\\\", \\\"{x:1586,y:555,t:1527271762549};\\\", \\\"{x:1587,y:559,t:1527271762565};\\\", \\\"{x:1589,y:561,t:1527271762583};\\\", \\\"{x:1591,y:566,t:1527271762598};\\\", \\\"{x:1592,y:568,t:1527271762615};\\\", \\\"{x:1592,y:570,t:1527271762647};\\\", \\\"{x:1593,y:570,t:1527271762662};\\\", \\\"{x:1594,y:569,t:1527271763064};\\\", \\\"{x:1595,y:569,t:1527271763143};\\\", \\\"{x:1596,y:569,t:1527271763151};\\\", \\\"{x:1599,y:570,t:1527271763280};\\\", \\\"{x:1600,y:570,t:1527271763287};\\\", \\\"{x:1600,y:571,t:1527271763299};\\\", \\\"{x:1602,y:571,t:1527271763317};\\\", \\\"{x:1603,y:571,t:1527271763368};\\\", \\\"{x:1605,y:571,t:1527271763383};\\\", \\\"{x:1605,y:572,t:1527271763448};\\\", \\\"{x:1606,y:572,t:1527271763528};\\\", \\\"{x:1609,y:572,t:1527271763535};\\\", \\\"{x:1610,y:572,t:1527271763550};\\\", \\\"{x:1619,y:574,t:1527271763567};\\\", \\\"{x:1627,y:578,t:1527271763583};\\\", \\\"{x:1621,y:578,t:1527271764136};\\\", \\\"{x:1610,y:578,t:1527271764151};\\\", \\\"{x:1575,y:577,t:1527271764166};\\\", \\\"{x:1511,y:581,t:1527271764183};\\\", \\\"{x:1462,y:593,t:1527271764200};\\\", \\\"{x:1409,y:609,t:1527271764217};\\\", \\\"{x:1347,y:629,t:1527271764233};\\\", \\\"{x:1282,y:641,t:1527271764251};\\\", \\\"{x:1236,y:650,t:1527271764267};\\\", \\\"{x:1216,y:656,t:1527271764283};\\\", \\\"{x:1190,y:671,t:1527271764301};\\\", \\\"{x:1160,y:680,t:1527271764316};\\\", \\\"{x:1125,y:691,t:1527271764333};\\\", \\\"{x:1106,y:696,t:1527271764350};\\\", \\\"{x:1080,y:708,t:1527271764367};\\\", \\\"{x:1043,y:726,t:1527271764383};\\\", \\\"{x:995,y:734,t:1527271764401};\\\", \\\"{x:931,y:742,t:1527271764418};\\\", \\\"{x:902,y:745,t:1527271764433};\\\", \\\"{x:883,y:748,t:1527271764450};\\\", \\\"{x:869,y:748,t:1527271764468};\\\", \\\"{x:854,y:742,t:1527271764484};\\\", \\\"{x:838,y:741,t:1527271764501};\\\", \\\"{x:817,y:736,t:1527271764517};\\\", \\\"{x:792,y:724,t:1527271764533};\\\", \\\"{x:767,y:708,t:1527271764550};\\\", \\\"{x:720,y:686,t:1527271764567};\\\", \\\"{x:691,y:670,t:1527271764583};\\\", \\\"{x:648,y:655,t:1527271764601};\\\", \\\"{x:611,y:642,t:1527271764620};\\\", \\\"{x:579,y:632,t:1527271764633};\\\", \\\"{x:553,y:623,t:1527271764650};\\\", \\\"{x:532,y:616,t:1527271764667};\\\", \\\"{x:512,y:608,t:1527271764685};\\\", \\\"{x:492,y:603,t:1527271764700};\\\", \\\"{x:445,y:589,t:1527271764716};\\\", \\\"{x:408,y:581,t:1527271764734};\\\", \\\"{x:398,y:574,t:1527271764751};\\\", \\\"{x:388,y:567,t:1527271764767};\\\", \\\"{x:388,y:565,t:1527271764784};\\\", \\\"{x:388,y:560,t:1527271764800};\\\", \\\"{x:390,y:560,t:1527271764816};\\\", \\\"{x:391,y:559,t:1527271764834};\\\", \\\"{x:392,y:559,t:1527271764862};\\\", \\\"{x:393,y:559,t:1527271764887};\\\", \\\"{x:396,y:559,t:1527271764901};\\\", \\\"{x:403,y:562,t:1527271764917};\\\", \\\"{x:410,y:567,t:1527271764934};\\\", \\\"{x:417,y:570,t:1527271764951};\\\", \\\"{x:419,y:571,t:1527271764967};\\\", \\\"{x:420,y:571,t:1527271764984};\\\", \\\"{x:420,y:572,t:1527271765047};\\\", \\\"{x:420,y:574,t:1527271765054};\\\", \\\"{x:418,y:575,t:1527271765068};\\\", \\\"{x:409,y:577,t:1527271765084};\\\", \\\"{x:404,y:577,t:1527271765100};\\\", \\\"{x:395,y:576,t:1527271765117};\\\", \\\"{x:388,y:574,t:1527271765134};\\\", \\\"{x:383,y:574,t:1527271765150};\\\", \\\"{x:381,y:574,t:1527271765167};\\\", \\\"{x:376,y:574,t:1527271765184};\\\", \\\"{x:370,y:574,t:1527271765201};\\\", \\\"{x:364,y:574,t:1527271765216};\\\", \\\"{x:363,y:574,t:1527271765234};\\\", \\\"{x:362,y:574,t:1527271765251};\\\", \\\"{x:360,y:574,t:1527271765267};\\\", \\\"{x:359,y:574,t:1527271765284};\\\", \\\"{x:347,y:572,t:1527271765301};\\\", \\\"{x:330,y:569,t:1527271765317};\\\", \\\"{x:311,y:566,t:1527271765334};\\\", \\\"{x:289,y:560,t:1527271765351};\\\", \\\"{x:270,y:560,t:1527271765369};\\\", \\\"{x:261,y:560,t:1527271765384};\\\", \\\"{x:252,y:562,t:1527271765401};\\\", \\\"{x:247,y:562,t:1527271765418};\\\", \\\"{x:246,y:562,t:1527271765434};\\\", \\\"{x:246,y:563,t:1527271765542};\\\", \\\"{x:244,y:565,t:1527271765551};\\\", \\\"{x:237,y:572,t:1527271765568};\\\", \\\"{x:232,y:576,t:1527271765586};\\\", \\\"{x:219,y:582,t:1527271765602};\\\", \\\"{x:210,y:585,t:1527271765618};\\\", \\\"{x:199,y:586,t:1527271765634};\\\", \\\"{x:189,y:589,t:1527271765652};\\\", \\\"{x:177,y:595,t:1527271765668};\\\", \\\"{x:168,y:599,t:1527271765684};\\\", \\\"{x:163,y:601,t:1527271765701};\\\", \\\"{x:162,y:601,t:1527271765718};\\\", \\\"{x:160,y:602,t:1527271765734};\\\", \\\"{x:159,y:603,t:1527271765750};\\\", \\\"{x:158,y:604,t:1527271765774};\\\", \\\"{x:158,y:605,t:1527271765785};\\\", \\\"{x:156,y:607,t:1527271765801};\\\", \\\"{x:155,y:607,t:1527271765818};\\\", \\\"{x:154,y:609,t:1527271765835};\\\", \\\"{x:153,y:610,t:1527271765854};\\\", \\\"{x:153,y:611,t:1527271765868};\\\", \\\"{x:153,y:612,t:1527271765885};\\\", \\\"{x:153,y:613,t:1527271765904};\\\", \\\"{x:153,y:614,t:1527271765927};\\\", \\\"{x:153,y:615,t:1527271765943};\\\", \\\"{x:152,y:616,t:1527271765974};\\\", \\\"{x:152,y:617,t:1527271765999};\\\", \\\"{x:152,y:618,t:1527271766031};\\\", \\\"{x:152,y:619,t:1527271766047};\\\", \\\"{x:152,y:620,t:1527271766105};\\\", \\\"{x:152,y:621,t:1527271766238};\\\", \\\"{x:152,y:624,t:1527271766252};\\\", \\\"{x:158,y:630,t:1527271766269};\\\", \\\"{x:161,y:634,t:1527271766285};\\\", \\\"{x:162,y:636,t:1527271766302};\\\", \\\"{x:163,y:637,t:1527271766350};\\\", \\\"{x:175,y:636,t:1527271766671};\\\", \\\"{x:203,y:617,t:1527271766685};\\\", \\\"{x:303,y:583,t:1527271766703};\\\", \\\"{x:519,y:524,t:1527271766719};\\\", \\\"{x:699,y:488,t:1527271766736};\\\", \\\"{x:871,y:464,t:1527271766752};\\\", \\\"{x:1031,y:442,t:1527271766769};\\\", \\\"{x:1133,y:435,t:1527271766785};\\\", \\\"{x:1283,y:409,t:1527271766802};\\\", \\\"{x:1437,y:376,t:1527271766819};\\\", \\\"{x:1595,y:345,t:1527271766836};\\\", \\\"{x:1733,y:313,t:1527271766852};\\\", \\\"{x:1869,y:291,t:1527271766869};\\\", \\\"{x:1919,y:258,t:1527271766886};\\\", \\\"{x:1919,y:226,t:1527271766902};\\\", \\\"{x:1919,y:215,t:1527271766919};\\\", \\\"{x:1919,y:207,t:1527271766936};\\\", \\\"{x:1919,y:206,t:1527271766953};\\\", \\\"{x:1919,y:205,t:1527271766969};\\\", \\\"{x:1919,y:207,t:1527271767007};\\\", \\\"{x:1918,y:208,t:1527271767019};\\\", \\\"{x:1906,y:214,t:1527271767035};\\\", \\\"{x:1891,y:224,t:1527271767052};\\\", \\\"{x:1876,y:230,t:1527271767069};\\\", \\\"{x:1856,y:241,t:1527271767085};\\\", \\\"{x:1825,y:257,t:1527271767102};\\\", \\\"{x:1768,y:287,t:1527271767119};\\\", \\\"{x:1735,y:307,t:1527271767135};\\\", \\\"{x:1711,y:322,t:1527271767152};\\\", \\\"{x:1703,y:329,t:1527271767169};\\\", \\\"{x:1700,y:333,t:1527271767186};\\\", \\\"{x:1699,y:337,t:1527271767202};\\\", \\\"{x:1699,y:341,t:1527271767219};\\\", \\\"{x:1699,y:349,t:1527271767237};\\\", \\\"{x:1705,y:366,t:1527271767252};\\\", \\\"{x:1714,y:393,t:1527271767270};\\\", \\\"{x:1717,y:415,t:1527271767287};\\\", \\\"{x:1717,y:431,t:1527271767302};\\\", \\\"{x:1708,y:467,t:1527271767319};\\\", \\\"{x:1699,y:491,t:1527271767336};\\\", \\\"{x:1693,y:514,t:1527271767352};\\\", \\\"{x:1687,y:533,t:1527271767370};\\\", \\\"{x:1681,y:549,t:1527271767387};\\\", \\\"{x:1671,y:566,t:1527271767402};\\\", \\\"{x:1661,y:580,t:1527271767420};\\\", \\\"{x:1656,y:589,t:1527271767436};\\\", \\\"{x:1652,y:595,t:1527271767453};\\\", \\\"{x:1648,y:601,t:1527271767470};\\\", \\\"{x:1646,y:604,t:1527271767486};\\\", \\\"{x:1643,y:606,t:1527271767503};\\\", \\\"{x:1641,y:609,t:1527271767519};\\\", \\\"{x:1637,y:615,t:1527271767536};\\\", \\\"{x:1634,y:622,t:1527271767553};\\\", \\\"{x:1628,y:636,t:1527271767570};\\\", \\\"{x:1623,y:645,t:1527271767586};\\\", \\\"{x:1617,y:654,t:1527271767602};\\\", \\\"{x:1613,y:664,t:1527271767619};\\\", \\\"{x:1610,y:673,t:1527271767636};\\\", \\\"{x:1609,y:681,t:1527271767653};\\\", \\\"{x:1608,y:691,t:1527271767669};\\\", \\\"{x:1605,y:700,t:1527271767686};\\\", \\\"{x:1604,y:709,t:1527271767703};\\\", \\\"{x:1603,y:716,t:1527271767719};\\\", \\\"{x:1600,y:725,t:1527271767737};\\\", \\\"{x:1600,y:734,t:1527271767754};\\\", \\\"{x:1600,y:740,t:1527271767770};\\\", \\\"{x:1600,y:745,t:1527271767787};\\\", \\\"{x:1600,y:751,t:1527271767803};\\\", \\\"{x:1600,y:753,t:1527271767819};\\\", \\\"{x:1602,y:757,t:1527271767836};\\\", \\\"{x:1604,y:760,t:1527271767855};\\\", \\\"{x:1605,y:761,t:1527271767869};\\\", \\\"{x:1606,y:761,t:1527271767887};\\\", \\\"{x:1606,y:766,t:1527271767904};\\\", \\\"{x:1606,y:772,t:1527271767920};\\\", \\\"{x:1608,y:777,t:1527271767937};\\\", \\\"{x:1608,y:781,t:1527271767953};\\\", \\\"{x:1609,y:787,t:1527271767970};\\\", \\\"{x:1610,y:795,t:1527271767986};\\\", \\\"{x:1612,y:799,t:1527271768004};\\\", \\\"{x:1613,y:813,t:1527271768020};\\\", \\\"{x:1613,y:826,t:1527271768037};\\\", \\\"{x:1614,y:837,t:1527271768054};\\\", \\\"{x:1614,y:846,t:1527271768070};\\\", \\\"{x:1614,y:853,t:1527271768087};\\\", \\\"{x:1614,y:859,t:1527271768104};\\\", \\\"{x:1614,y:861,t:1527271768120};\\\", \\\"{x:1614,y:868,t:1527271768137};\\\", \\\"{x:1612,y:877,t:1527271768154};\\\", \\\"{x:1604,y:889,t:1527271768171};\\\", \\\"{x:1590,y:903,t:1527271768187};\\\", \\\"{x:1556,y:907,t:1527271768203};\\\", \\\"{x:1483,y:919,t:1527271768221};\\\", \\\"{x:1433,y:935,t:1527271768237};\\\", \\\"{x:1387,y:950,t:1527271768253};\\\", \\\"{x:1344,y:973,t:1527271768271};\\\", \\\"{x:1270,y:1001,t:1527271768288};\\\", \\\"{x:1128,y:1044,t:1527271768303};\\\", \\\"{x:1010,y:1071,t:1527271768321};\\\", \\\"{x:882,y:1094,t:1527271768337};\\\", \\\"{x:751,y:1102,t:1527271768353};\\\", \\\"{x:614,y:1108,t:1527271768370};\\\", \\\"{x:515,y:1108,t:1527271768387};\\\", \\\"{x:448,y:1104,t:1527271768403};\\\", \\\"{x:433,y:1095,t:1527271768420};\\\", \\\"{x:433,y:1093,t:1527271768439};\\\", \\\"{x:434,y:1087,t:1527271768455};\\\", \\\"{x:437,y:1082,t:1527271768471};\\\", \\\"{x:445,y:1071,t:1527271768486};\\\", \\\"{x:452,y:1063,t:1527271768503};\\\", \\\"{x:461,y:1053,t:1527271768521};\\\", \\\"{x:463,y:1043,t:1527271768537};\\\", \\\"{x:466,y:1032,t:1527271768553};\\\", \\\"{x:468,y:1018,t:1527271768570};\\\", \\\"{x:476,y:998,t:1527271768588};\\\", \\\"{x:479,y:981,t:1527271768604};\\\", \\\"{x:487,y:960,t:1527271768620};\\\", \\\"{x:489,y:939,t:1527271768638};\\\", \\\"{x:489,y:923,t:1527271768653};\\\", \\\"{x:489,y:902,t:1527271768670};\\\", \\\"{x:497,y:868,t:1527271768687};\\\", \\\"{x:511,y:844,t:1527271768703};\\\", \\\"{x:531,y:818,t:1527271768721};\\\", \\\"{x:553,y:794,t:1527271768738};\\\", \\\"{x:574,y:770,t:1527271768753};\\\", \\\"{x:592,y:749,t:1527271768770};\\\", \\\"{x:604,y:734,t:1527271768787};\\\", \\\"{x:615,y:714,t:1527271768803};\\\", \\\"{x:619,y:695,t:1527271768821};\\\", \\\"{x:620,y:677,t:1527271768837};\\\", \\\"{x:622,y:663,t:1527271768854};\\\", \\\"{x:619,y:651,t:1527271768871};\\\", \\\"{x:613,y:642,t:1527271768888};\\\", \\\"{x:613,y:641,t:1527271768903};\\\", \\\"{x:611,y:641,t:1527271768958};\\\", \\\"{x:607,y:641,t:1527271768970};\\\", \\\"{x:584,y:647,t:1527271768988};\\\", \\\"{x:566,y:655,t:1527271769004};\\\", \\\"{x:546,y:658,t:1527271769019};\\\", \\\"{x:529,y:662,t:1527271769037};\\\", \\\"{x:524,y:663,t:1527271769053};\\\", \\\"{x:523,y:663,t:1527271769143};\\\", \\\"{x:523,y:665,t:1527271769154};\\\", \\\"{x:523,y:674,t:1527271769170};\\\", \\\"{x:523,y:688,t:1527271769187};\\\", \\\"{x:522,y:696,t:1527271769204};\\\", \\\"{x:520,y:705,t:1527271769221};\\\", \\\"{x:519,y:715,t:1527271769237};\\\", \\\"{x:518,y:721,t:1527271769254};\\\", \\\"{x:517,y:722,t:1527271769823};\\\", \\\"{x:516,y:723,t:1527271769839};\\\", \\\"{x:514,y:724,t:1527271769862};\\\", \\\"{x:512,y:725,t:1527271769886};\\\" ] }, { \\\"rt\\\": 34285, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 232284, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:514,y:724,t:1527271770974};\\\", \\\"{x:522,y:713,t:1527271770989};\\\", \\\"{x:559,y:624,t:1527271771013};\\\", \\\"{x:570,y:584,t:1527271771022};\\\", \\\"{x:585,y:540,t:1527271771039};\\\", \\\"{x:601,y:511,t:1527271771055};\\\", \\\"{x:622,y:487,t:1527271771072};\\\", \\\"{x:638,y:466,t:1527271771089};\\\", \\\"{x:642,y:461,t:1527271771105};\\\", \\\"{x:644,y:459,t:1527271771122};\\\", \\\"{x:644,y:458,t:1527271771518};\\\", \\\"{x:643,y:458,t:1527271771542};\\\", \\\"{x:640,y:459,t:1527271771557};\\\", \\\"{x:631,y:460,t:1527271771573};\\\", \\\"{x:623,y:465,t:1527271771589};\\\", \\\"{x:613,y:471,t:1527271771607};\\\", \\\"{x:602,y:476,t:1527271771623};\\\", \\\"{x:596,y:478,t:1527271771640};\\\", \\\"{x:591,y:482,t:1527271771656};\\\", \\\"{x:586,y:486,t:1527271771672};\\\", \\\"{x:579,y:490,t:1527271771690};\\\", \\\"{x:572,y:492,t:1527271771707};\\\", \\\"{x:564,y:493,t:1527271771722};\\\", \\\"{x:558,y:495,t:1527271771739};\\\", \\\"{x:549,y:495,t:1527271771757};\\\", \\\"{x:538,y:495,t:1527271771773};\\\", \\\"{x:529,y:495,t:1527271771790};\\\", \\\"{x:525,y:495,t:1527271771807};\\\", \\\"{x:522,y:495,t:1527271771823};\\\", \\\"{x:521,y:495,t:1527271771840};\\\", \\\"{x:517,y:497,t:1527271771857};\\\", \\\"{x:514,y:497,t:1527271771873};\\\", \\\"{x:512,y:497,t:1527271771890};\\\", \\\"{x:513,y:497,t:1527271771992};\\\", \\\"{x:515,y:497,t:1527271772007};\\\", \\\"{x:518,y:497,t:1527271772023};\\\", \\\"{x:528,y:495,t:1527271772040};\\\", \\\"{x:536,y:495,t:1527271772057};\\\", \\\"{x:539,y:495,t:1527271772074};\\\", \\\"{x:545,y:493,t:1527271772090};\\\", \\\"{x:548,y:493,t:1527271772107};\\\", \\\"{x:549,y:493,t:1527271772124};\\\", \\\"{x:550,y:493,t:1527271772199};\\\", \\\"{x:554,y:491,t:1527271772215};\\\", \\\"{x:556,y:489,t:1527271772223};\\\", \\\"{x:562,y:485,t:1527271772240};\\\", \\\"{x:563,y:483,t:1527271772257};\\\", \\\"{x:569,y:481,t:1527271772274};\\\", \\\"{x:570,y:480,t:1527271772289};\\\", \\\"{x:572,y:479,t:1527271772307};\\\", \\\"{x:575,y:477,t:1527271772351};\\\", \\\"{x:582,y:477,t:1527271772359};\\\", \\\"{x:586,y:476,t:1527271772374};\\\", \\\"{x:591,y:476,t:1527271772390};\\\", \\\"{x:596,y:475,t:1527271772407};\\\", \\\"{x:597,y:475,t:1527271772424};\\\", \\\"{x:600,y:475,t:1527271772440};\\\", \\\"{x:602,y:474,t:1527271772457};\\\", \\\"{x:607,y:474,t:1527271772473};\\\", \\\"{x:609,y:474,t:1527271772491};\\\", \\\"{x:610,y:474,t:1527271772511};\\\", \\\"{x:609,y:475,t:1527271772830};\\\", \\\"{x:607,y:477,t:1527271772847};\\\", \\\"{x:604,y:478,t:1527271772863};\\\", \\\"{x:601,y:478,t:1527271772873};\\\", \\\"{x:591,y:480,t:1527271772890};\\\", \\\"{x:583,y:482,t:1527271772907};\\\", \\\"{x:576,y:482,t:1527271772923};\\\", \\\"{x:571,y:482,t:1527271772941};\\\", \\\"{x:569,y:482,t:1527271772957};\\\", \\\"{x:567,y:482,t:1527271772973};\\\", \\\"{x:564,y:482,t:1527271772991};\\\", \\\"{x:563,y:482,t:1527271773007};\\\", \\\"{x:559,y:483,t:1527271773024};\\\", \\\"{x:555,y:483,t:1527271773041};\\\", \\\"{x:548,y:483,t:1527271773058};\\\", \\\"{x:543,y:483,t:1527271773074};\\\", \\\"{x:542,y:483,t:1527271773095};\\\", \\\"{x:540,y:483,t:1527271773107};\\\", \\\"{x:539,y:483,t:1527271773124};\\\", \\\"{x:537,y:483,t:1527271773141};\\\", \\\"{x:536,y:483,t:1527271773158};\\\", \\\"{x:535,y:483,t:1527271773173};\\\", \\\"{x:534,y:483,t:1527271773223};\\\", \\\"{x:532,y:483,t:1527271773247};\\\", \\\"{x:529,y:483,t:1527271773258};\\\", \\\"{x:523,y:483,t:1527271773274};\\\", \\\"{x:517,y:483,t:1527271773290};\\\", \\\"{x:510,y:482,t:1527271773308};\\\", \\\"{x:505,y:481,t:1527271773324};\\\", \\\"{x:500,y:481,t:1527271773341};\\\", \\\"{x:498,y:480,t:1527271773358};\\\", \\\"{x:496,y:479,t:1527271773374};\\\", \\\"{x:498,y:477,t:1527271773655};\\\", \\\"{x:500,y:477,t:1527271773719};\\\", \\\"{x:503,y:479,t:1527271773727};\\\", \\\"{x:506,y:480,t:1527271773741};\\\", \\\"{x:518,y:484,t:1527271773758};\\\", \\\"{x:542,y:489,t:1527271773776};\\\", \\\"{x:553,y:492,t:1527271773791};\\\", \\\"{x:563,y:493,t:1527271773807};\\\", \\\"{x:565,y:494,t:1527271773825};\\\", \\\"{x:566,y:494,t:1527271773928};\\\", \\\"{x:567,y:494,t:1527271773959};\\\", \\\"{x:569,y:494,t:1527271774656};\\\", \\\"{x:570,y:493,t:1527271774687};\\\", \\\"{x:571,y:492,t:1527271774703};\\\", \\\"{x:572,y:491,t:1527271774711};\\\", \\\"{x:573,y:489,t:1527271774725};\\\", \\\"{x:574,y:489,t:1527271774741};\\\", \\\"{x:575,y:489,t:1527271774759};\\\", \\\"{x:577,y:488,t:1527271774776};\\\", \\\"{x:578,y:488,t:1527271774792};\\\", \\\"{x:579,y:487,t:1527271774815};\\\", \\\"{x:581,y:486,t:1527271774831};\\\", \\\"{x:582,y:486,t:1527271774855};\\\", \\\"{x:582,y:485,t:1527271774863};\\\", \\\"{x:584,y:485,t:1527271774876};\\\", \\\"{x:585,y:484,t:1527271774892};\\\", \\\"{x:585,y:483,t:1527271774909};\\\", \\\"{x:587,y:483,t:1527271774926};\\\", \\\"{x:590,y:481,t:1527271774941};\\\", \\\"{x:592,y:480,t:1527271774959};\\\", \\\"{x:593,y:480,t:1527271775007};\\\", \\\"{x:594,y:480,t:1527271775047};\\\", \\\"{x:594,y:479,t:1527271775059};\\\", \\\"{x:596,y:479,t:1527271775076};\\\", \\\"{x:598,y:479,t:1527271775092};\\\", \\\"{x:601,y:479,t:1527271775108};\\\", \\\"{x:605,y:479,t:1527271775126};\\\", \\\"{x:609,y:479,t:1527271775142};\\\", \\\"{x:621,y:479,t:1527271775159};\\\", \\\"{x:628,y:482,t:1527271775175};\\\", \\\"{x:633,y:484,t:1527271775192};\\\", \\\"{x:635,y:485,t:1527271775209};\\\", \\\"{x:636,y:485,t:1527271775226};\\\", \\\"{x:637,y:486,t:1527271775351};\\\", \\\"{x:637,y:488,t:1527271775375};\\\", \\\"{x:641,y:490,t:1527271775393};\\\", \\\"{x:645,y:492,t:1527271775409};\\\", \\\"{x:650,y:494,t:1527271775426};\\\", \\\"{x:652,y:494,t:1527271775443};\\\", \\\"{x:656,y:495,t:1527271775459};\\\", \\\"{x:662,y:497,t:1527271775476};\\\", \\\"{x:665,y:497,t:1527271775493};\\\", \\\"{x:673,y:500,t:1527271775509};\\\", \\\"{x:684,y:501,t:1527271775525};\\\", \\\"{x:702,y:503,t:1527271775543};\\\", \\\"{x:709,y:505,t:1527271775559};\\\", \\\"{x:720,y:506,t:1527271775577};\\\", \\\"{x:731,y:509,t:1527271775593};\\\", \\\"{x:734,y:509,t:1527271775603};\\\", \\\"{x:745,y:510,t:1527271775619};\\\", \\\"{x:762,y:512,t:1527271775642};\\\", \\\"{x:768,y:515,t:1527271775659};\\\", \\\"{x:776,y:516,t:1527271775675};\\\", \\\"{x:784,y:518,t:1527271775692};\\\", \\\"{x:794,y:520,t:1527271775710};\\\", \\\"{x:803,y:521,t:1527271775725};\\\", \\\"{x:814,y:523,t:1527271775742};\\\", \\\"{x:817,y:523,t:1527271775759};\\\", \\\"{x:818,y:523,t:1527271775777};\\\", \\\"{x:821,y:523,t:1527271775793};\\\", \\\"{x:825,y:523,t:1527271775810};\\\", \\\"{x:828,y:523,t:1527271775826};\\\", \\\"{x:831,y:522,t:1527271775842};\\\", \\\"{x:834,y:522,t:1527271775859};\\\", \\\"{x:841,y:522,t:1527271775877};\\\", \\\"{x:848,y:524,t:1527271775894};\\\", \\\"{x:866,y:525,t:1527271775909};\\\", \\\"{x:905,y:534,t:1527271775926};\\\", \\\"{x:939,y:544,t:1527271775944};\\\", \\\"{x:981,y:562,t:1527271775960};\\\", \\\"{x:1037,y:580,t:1527271775976};\\\", \\\"{x:1083,y:597,t:1527271775992};\\\", \\\"{x:1118,y:609,t:1527271776009};\\\", \\\"{x:1141,y:619,t:1527271776027};\\\", \\\"{x:1164,y:624,t:1527271776043};\\\", \\\"{x:1179,y:628,t:1527271776060};\\\", \\\"{x:1192,y:636,t:1527271776077};\\\", \\\"{x:1212,y:647,t:1527271776092};\\\", \\\"{x:1240,y:659,t:1527271776110};\\\", \\\"{x:1270,y:672,t:1527271776127};\\\", \\\"{x:1288,y:680,t:1527271776143};\\\", \\\"{x:1307,y:682,t:1527271776159};\\\", \\\"{x:1326,y:686,t:1527271776177};\\\", \\\"{x:1333,y:688,t:1527271776194};\\\", \\\"{x:1340,y:690,t:1527271776210};\\\", \\\"{x:1357,y:700,t:1527271776226};\\\", \\\"{x:1378,y:703,t:1527271776244};\\\", \\\"{x:1400,y:709,t:1527271776259};\\\", \\\"{x:1418,y:716,t:1527271776277};\\\", \\\"{x:1439,y:722,t:1527271776293};\\\", \\\"{x:1454,y:725,t:1527271776310};\\\", \\\"{x:1470,y:731,t:1527271776327};\\\", \\\"{x:1481,y:734,t:1527271776343};\\\", \\\"{x:1487,y:736,t:1527271776360};\\\", \\\"{x:1494,y:738,t:1527271776377};\\\", \\\"{x:1499,y:740,t:1527271776394};\\\", \\\"{x:1503,y:741,t:1527271776410};\\\", \\\"{x:1504,y:742,t:1527271776535};\\\", \\\"{x:1507,y:743,t:1527271776551};\\\", \\\"{x:1509,y:744,t:1527271776561};\\\", \\\"{x:1515,y:746,t:1527271776578};\\\", \\\"{x:1523,y:749,t:1527271776594};\\\", \\\"{x:1536,y:753,t:1527271776611};\\\", \\\"{x:1543,y:756,t:1527271776626};\\\", \\\"{x:1552,y:759,t:1527271776644};\\\", \\\"{x:1556,y:763,t:1527271776660};\\\", \\\"{x:1561,y:765,t:1527271776677};\\\", \\\"{x:1565,y:766,t:1527271776693};\\\", \\\"{x:1573,y:770,t:1527271776711};\\\", \\\"{x:1576,y:773,t:1527271776726};\\\", \\\"{x:1579,y:774,t:1527271776744};\\\", \\\"{x:1585,y:778,t:1527271776761};\\\", \\\"{x:1592,y:781,t:1527271776776};\\\", \\\"{x:1597,y:782,t:1527271776794};\\\", \\\"{x:1605,y:787,t:1527271776811};\\\", \\\"{x:1612,y:789,t:1527271776827};\\\", \\\"{x:1615,y:790,t:1527271776843};\\\", \\\"{x:1622,y:793,t:1527271776861};\\\", \\\"{x:1624,y:795,t:1527271776877};\\\", \\\"{x:1626,y:796,t:1527271776894};\\\", \\\"{x:1626,y:797,t:1527271776960};\\\", \\\"{x:1626,y:798,t:1527271777256};\\\", \\\"{x:1625,y:798,t:1527271777264};\\\", \\\"{x:1624,y:799,t:1527271777278};\\\", \\\"{x:1621,y:800,t:1527271777293};\\\", \\\"{x:1615,y:801,t:1527271777310};\\\", \\\"{x:1611,y:803,t:1527271777327};\\\", \\\"{x:1607,y:803,t:1527271777343};\\\", \\\"{x:1603,y:804,t:1527271777360};\\\", \\\"{x:1600,y:804,t:1527271777378};\\\", \\\"{x:1599,y:805,t:1527271777394};\\\", \\\"{x:1598,y:805,t:1527271777447};\\\", \\\"{x:1597,y:805,t:1527271777479};\\\", \\\"{x:1596,y:806,t:1527271777494};\\\", \\\"{x:1590,y:809,t:1527271777510};\\\", \\\"{x:1587,y:810,t:1527271777528};\\\", \\\"{x:1576,y:810,t:1527271777544};\\\", \\\"{x:1549,y:812,t:1527271777561};\\\", \\\"{x:1543,y:815,t:1527271777577};\\\", \\\"{x:1531,y:815,t:1527271777595};\\\", \\\"{x:1531,y:816,t:1527271777611};\\\", \\\"{x:1529,y:816,t:1527271777628};\\\", \\\"{x:1529,y:818,t:1527271777759};\\\", \\\"{x:1526,y:819,t:1527271777767};\\\", \\\"{x:1523,y:820,t:1527271777778};\\\", \\\"{x:1509,y:821,t:1527271777795};\\\", \\\"{x:1488,y:824,t:1527271777811};\\\", \\\"{x:1454,y:824,t:1527271777828};\\\", \\\"{x:1426,y:824,t:1527271777845};\\\", \\\"{x:1405,y:826,t:1527271777861};\\\", \\\"{x:1392,y:832,t:1527271777878};\\\", \\\"{x:1383,y:834,t:1527271777895};\\\", \\\"{x:1379,y:835,t:1527271777911};\\\", \\\"{x:1374,y:835,t:1527271777929};\\\", \\\"{x:1368,y:838,t:1527271777945};\\\", \\\"{x:1356,y:842,t:1527271777962};\\\", \\\"{x:1338,y:847,t:1527271777977};\\\", \\\"{x:1326,y:850,t:1527271777994};\\\", \\\"{x:1309,y:854,t:1527271778011};\\\", \\\"{x:1287,y:858,t:1527271778028};\\\", \\\"{x:1272,y:858,t:1527271778044};\\\", \\\"{x:1264,y:859,t:1527271778062};\\\", \\\"{x:1251,y:864,t:1527271778078};\\\", \\\"{x:1245,y:864,t:1527271778094};\\\", \\\"{x:1232,y:864,t:1527271778112};\\\", \\\"{x:1227,y:864,t:1527271778128};\\\", \\\"{x:1215,y:864,t:1527271778144};\\\", \\\"{x:1214,y:864,t:1527271778167};\\\", \\\"{x:1215,y:864,t:1527271778264};\\\", \\\"{x:1217,y:864,t:1527271778278};\\\", \\\"{x:1220,y:860,t:1527271778295};\\\", \\\"{x:1221,y:860,t:1527271778313};\\\", \\\"{x:1221,y:859,t:1527271778367};\\\", \\\"{x:1221,y:858,t:1527271778391};\\\", \\\"{x:1221,y:857,t:1527271778448};\\\", \\\"{x:1219,y:856,t:1527271778519};\\\", \\\"{x:1217,y:855,t:1527271778530};\\\", \\\"{x:1213,y:852,t:1527271778545};\\\", \\\"{x:1211,y:849,t:1527271778562};\\\", \\\"{x:1206,y:845,t:1527271778579};\\\", \\\"{x:1202,y:841,t:1527271778595};\\\", \\\"{x:1197,y:837,t:1527271778612};\\\", \\\"{x:1194,y:836,t:1527271778629};\\\", \\\"{x:1193,y:834,t:1527271778645};\\\", \\\"{x:1192,y:834,t:1527271778663};\\\", \\\"{x:1192,y:833,t:1527271778751};\\\", \\\"{x:1193,y:834,t:1527271780830};\\\", \\\"{x:1195,y:834,t:1527271780846};\\\", \\\"{x:1196,y:834,t:1527271780864};\\\", \\\"{x:1198,y:834,t:1527271780880};\\\", \\\"{x:1199,y:834,t:1527271780983};\\\", \\\"{x:1201,y:834,t:1527271780997};\\\", \\\"{x:1206,y:835,t:1527271781015};\\\", \\\"{x:1209,y:835,t:1527271781030};\\\", \\\"{x:1212,y:836,t:1527271781047};\\\", \\\"{x:1215,y:838,t:1527271781065};\\\", \\\"{x:1218,y:838,t:1527271781081};\\\", \\\"{x:1219,y:838,t:1527271781183};\\\", \\\"{x:1220,y:838,t:1527271781198};\\\", \\\"{x:1220,y:837,t:1527271782640};\\\", \\\"{x:1220,y:836,t:1527271783159};\\\", \\\"{x:1220,y:835,t:1527271783167};\\\", \\\"{x:1219,y:835,t:1527271783614};\\\", \\\"{x:1218,y:835,t:1527271783638};\\\", \\\"{x:1216,y:833,t:1527271784890};\\\", \\\"{x:1213,y:833,t:1527271784916};\\\", \\\"{x:1212,y:833,t:1527271785143};\\\", \\\"{x:1212,y:831,t:1527271785391};\\\", \\\"{x:1213,y:831,t:1527271785504};\\\", \\\"{x:1213,y:830,t:1527271785624};\\\", \\\"{x:1214,y:830,t:1527271785639};\\\", \\\"{x:1216,y:830,t:1527271785651};\\\", \\\"{x:1219,y:830,t:1527271785667};\\\", \\\"{x:1221,y:830,t:1527271785686};\\\", \\\"{x:1222,y:830,t:1527271785702};\\\", \\\"{x:1223,y:829,t:1527271785743};\\\", \\\"{x:1225,y:829,t:1527271785903};\\\", \\\"{x:1226,y:829,t:1527271785918};\\\", \\\"{x:1229,y:831,t:1527271785934};\\\", \\\"{x:1230,y:833,t:1527271785951};\\\", \\\"{x:1231,y:833,t:1527271785969};\\\", \\\"{x:1232,y:834,t:1527271785985};\\\", \\\"{x:1233,y:834,t:1527271786064};\\\", \\\"{x:1234,y:834,t:1527271786071};\\\", \\\"{x:1235,y:835,t:1527271786087};\\\", \\\"{x:1236,y:836,t:1527271786101};\\\", \\\"{x:1237,y:836,t:1527271786118};\\\", \\\"{x:1238,y:837,t:1527271786135};\\\", \\\"{x:1239,y:838,t:1527271786151};\\\", \\\"{x:1241,y:839,t:1527271786168};\\\", \\\"{x:1243,y:841,t:1527271786185};\\\", \\\"{x:1245,y:842,t:1527271786201};\\\", \\\"{x:1247,y:843,t:1527271786219};\\\", \\\"{x:1248,y:843,t:1527271786234};\\\", \\\"{x:1250,y:844,t:1527271786251};\\\", \\\"{x:1250,y:845,t:1527271786270};\\\", \\\"{x:1251,y:845,t:1527271786285};\\\", \\\"{x:1253,y:846,t:1527271786335};\\\", \\\"{x:1254,y:846,t:1527271786351};\\\", \\\"{x:1255,y:847,t:1527271786368};\\\", \\\"{x:1257,y:849,t:1527271786390};\\\", \\\"{x:1258,y:849,t:1527271786423};\\\", \\\"{x:1259,y:851,t:1527271786463};\\\", \\\"{x:1261,y:851,t:1527271786471};\\\", \\\"{x:1262,y:852,t:1527271786487};\\\", \\\"{x:1264,y:853,t:1527271786501};\\\", \\\"{x:1266,y:854,t:1527271786519};\\\", \\\"{x:1268,y:855,t:1527271786536};\\\", \\\"{x:1269,y:856,t:1527271786559};\\\", \\\"{x:1270,y:856,t:1527271786623};\\\", \\\"{x:1271,y:856,t:1527271786703};\\\", \\\"{x:1272,y:856,t:1527271786727};\\\", \\\"{x:1273,y:856,t:1527271786911};\\\", \\\"{x:1274,y:856,t:1527271786944};\\\", \\\"{x:1274,y:857,t:1527271786959};\\\", \\\"{x:1276,y:858,t:1527271786969};\\\", \\\"{x:1278,y:859,t:1527271786985};\\\", \\\"{x:1279,y:861,t:1527271787002};\\\", \\\"{x:1280,y:861,t:1527271787056};\\\", \\\"{x:1281,y:863,t:1527271787069};\\\", \\\"{x:1283,y:864,t:1527271787086};\\\", \\\"{x:1285,y:866,t:1527271787103};\\\", \\\"{x:1289,y:866,t:1527271787119};\\\", \\\"{x:1291,y:866,t:1527271787256};\\\", \\\"{x:1292,y:865,t:1527271787271};\\\", \\\"{x:1292,y:864,t:1527271787287};\\\", \\\"{x:1293,y:863,t:1527271787319};\\\", \\\"{x:1293,y:861,t:1527271787367};\\\", \\\"{x:1295,y:860,t:1527271787392};\\\", \\\"{x:1296,y:858,t:1527271787407};\\\", \\\"{x:1297,y:858,t:1527271787420};\\\", \\\"{x:1300,y:858,t:1527271787435};\\\", \\\"{x:1301,y:857,t:1527271787452};\\\", \\\"{x:1304,y:856,t:1527271787470};\\\", \\\"{x:1305,y:855,t:1527271787485};\\\", \\\"{x:1311,y:853,t:1527271787503};\\\", \\\"{x:1314,y:852,t:1527271787519};\\\", \\\"{x:1315,y:852,t:1527271787535};\\\", \\\"{x:1318,y:851,t:1527271787553};\\\", \\\"{x:1321,y:851,t:1527271787570};\\\", \\\"{x:1323,y:850,t:1527271787586};\\\", \\\"{x:1325,y:848,t:1527271787602};\\\", \\\"{x:1327,y:847,t:1527271787619};\\\", \\\"{x:1329,y:845,t:1527271787636};\\\", \\\"{x:1332,y:843,t:1527271787653};\\\", \\\"{x:1334,y:843,t:1527271787670};\\\", \\\"{x:1335,y:843,t:1527271787703};\\\", \\\"{x:1336,y:843,t:1527271787727};\\\", \\\"{x:1337,y:843,t:1527271787752};\\\", \\\"{x:1338,y:843,t:1527271787800};\\\", \\\"{x:1339,y:843,t:1527271787815};\\\", \\\"{x:1340,y:843,t:1527271787823};\\\", \\\"{x:1341,y:843,t:1527271787856};\\\", \\\"{x:1342,y:843,t:1527271787934};\\\", \\\"{x:1343,y:843,t:1527271787942};\\\", \\\"{x:1343,y:844,t:1527271787951};\\\", \\\"{x:1344,y:845,t:1527271787969};\\\", \\\"{x:1345,y:848,t:1527271787986};\\\", \\\"{x:1346,y:850,t:1527271788003};\\\", \\\"{x:1346,y:852,t:1527271788019};\\\", \\\"{x:1346,y:856,t:1527271788036};\\\", \\\"{x:1346,y:859,t:1527271788053};\\\", \\\"{x:1346,y:863,t:1527271788069};\\\", \\\"{x:1345,y:866,t:1527271788086};\\\", \\\"{x:1344,y:867,t:1527271788102};\\\", \\\"{x:1343,y:867,t:1527271788150};\\\", \\\"{x:1343,y:869,t:1527271788183};\\\", \\\"{x:1343,y:870,t:1527271788207};\\\", \\\"{x:1343,y:872,t:1527271788219};\\\", \\\"{x:1343,y:874,t:1527271788237};\\\", \\\"{x:1342,y:875,t:1527271788254};\\\", \\\"{x:1342,y:878,t:1527271788269};\\\", \\\"{x:1341,y:882,t:1527271788286};\\\", \\\"{x:1341,y:885,t:1527271788303};\\\", \\\"{x:1340,y:887,t:1527271788320};\\\", \\\"{x:1340,y:888,t:1527271788336};\\\", \\\"{x:1340,y:890,t:1527271788354};\\\", \\\"{x:1340,y:892,t:1527271788370};\\\", \\\"{x:1340,y:894,t:1527271788386};\\\", \\\"{x:1339,y:895,t:1527271788404};\\\", \\\"{x:1339,y:897,t:1527271788419};\\\", \\\"{x:1339,y:898,t:1527271788447};\\\", \\\"{x:1338,y:899,t:1527271788463};\\\", \\\"{x:1338,y:900,t:1527271788576};\\\", \\\"{x:1338,y:901,t:1527271788647};\\\", \\\"{x:1337,y:902,t:1527271788719};\\\", \\\"{x:1337,y:903,t:1527271788737};\\\", \\\"{x:1337,y:904,t:1527271789072};\\\", \\\"{x:1341,y:905,t:1527271789087};\\\", \\\"{x:1341,y:906,t:1527271789104};\\\", \\\"{x:1342,y:907,t:1527271789208};\\\", \\\"{x:1343,y:907,t:1527271789220};\\\", \\\"{x:1344,y:907,t:1527271789237};\\\", \\\"{x:1346,y:907,t:1527271789254};\\\", \\\"{x:1347,y:907,t:1527271789407};\\\", \\\"{x:1349,y:907,t:1527271789527};\\\", \\\"{x:1350,y:907,t:1527271790215};\\\", \\\"{x:1349,y:904,t:1527271790951};\\\", \\\"{x:1343,y:902,t:1527271790958};\\\", \\\"{x:1338,y:901,t:1527271790972};\\\", \\\"{x:1327,y:896,t:1527271790989};\\\", \\\"{x:1322,y:895,t:1527271791006};\\\", \\\"{x:1320,y:893,t:1527271791022};\\\", \\\"{x:1315,y:893,t:1527271791039};\\\", \\\"{x:1313,y:893,t:1527271791055};\\\", \\\"{x:1312,y:893,t:1527271791073};\\\", \\\"{x:1311,y:893,t:1527271791088};\\\", \\\"{x:1309,y:892,t:1527271791106};\\\", \\\"{x:1307,y:891,t:1527271791122};\\\", \\\"{x:1306,y:891,t:1527271791143};\\\", \\\"{x:1304,y:891,t:1527271791159};\\\", \\\"{x:1303,y:891,t:1527271791173};\\\", \\\"{x:1300,y:891,t:1527271791189};\\\", \\\"{x:1295,y:891,t:1527271791206};\\\", \\\"{x:1286,y:891,t:1527271791223};\\\", \\\"{x:1278,y:889,t:1527271791239};\\\", \\\"{x:1270,y:885,t:1527271791255};\\\", \\\"{x:1254,y:882,t:1527271791273};\\\", \\\"{x:1242,y:877,t:1527271791288};\\\", \\\"{x:1224,y:872,t:1527271791306};\\\", \\\"{x:1207,y:866,t:1527271791323};\\\", \\\"{x:1189,y:858,t:1527271791339};\\\", \\\"{x:1170,y:850,t:1527271791355};\\\", \\\"{x:1152,y:842,t:1527271791373};\\\", \\\"{x:1131,y:832,t:1527271791388};\\\", \\\"{x:1114,y:828,t:1527271791406};\\\", \\\"{x:1081,y:816,t:1527271791424};\\\", \\\"{x:1055,y:808,t:1527271791439};\\\", \\\"{x:1033,y:800,t:1527271791456};\\\", \\\"{x:1010,y:792,t:1527271791473};\\\", \\\"{x:986,y:780,t:1527271791489};\\\", \\\"{x:958,y:767,t:1527271791505};\\\", \\\"{x:933,y:755,t:1527271791522};\\\", \\\"{x:919,y:746,t:1527271791538};\\\", \\\"{x:885,y:735,t:1527271791555};\\\", \\\"{x:840,y:719,t:1527271791572};\\\", \\\"{x:779,y:700,t:1527271791589};\\\", \\\"{x:696,y:682,t:1527271791605};\\\", \\\"{x:652,y:663,t:1527271791622};\\\", \\\"{x:651,y:663,t:1527271791639};\\\", \\\"{x:645,y:657,t:1527271791655};\\\", \\\"{x:629,y:652,t:1527271791672};\\\", \\\"{x:621,y:648,t:1527271791691};\\\", \\\"{x:620,y:647,t:1527271791705};\\\", \\\"{x:619,y:646,t:1527271791903};\\\", \\\"{x:613,y:644,t:1527271791921};\\\", \\\"{x:604,y:640,t:1527271791940};\\\", \\\"{x:595,y:637,t:1527271791957};\\\", \\\"{x:578,y:632,t:1527271791972};\\\", \\\"{x:562,y:625,t:1527271791989};\\\", \\\"{x:539,y:614,t:1527271792007};\\\", \\\"{x:520,y:610,t:1527271792023};\\\", \\\"{x:502,y:603,t:1527271792039};\\\", \\\"{x:479,y:598,t:1527271792057};\\\", \\\"{x:464,y:591,t:1527271792073};\\\", \\\"{x:453,y:587,t:1527271792089};\\\", \\\"{x:449,y:586,t:1527271792106};\\\", \\\"{x:448,y:585,t:1527271792123};\\\", \\\"{x:447,y:585,t:1527271792150};\\\", \\\"{x:445,y:585,t:1527271792190};\\\", \\\"{x:444,y:585,t:1527271792207};\\\", \\\"{x:443,y:585,t:1527271792311};\\\", \\\"{x:442,y:585,t:1527271792324};\\\", \\\"{x:438,y:583,t:1527271792339};\\\", \\\"{x:437,y:583,t:1527271792356};\\\", \\\"{x:435,y:582,t:1527271792527};\\\", \\\"{x:431,y:583,t:1527271792559};\\\", \\\"{x:426,y:586,t:1527271792573};\\\", \\\"{x:421,y:589,t:1527271792590};\\\", \\\"{x:416,y:591,t:1527271792607};\\\", \\\"{x:407,y:594,t:1527271792623};\\\", \\\"{x:396,y:595,t:1527271792640};\\\", \\\"{x:390,y:598,t:1527271792657};\\\", \\\"{x:382,y:598,t:1527271792674};\\\", \\\"{x:376,y:598,t:1527271792691};\\\", \\\"{x:368,y:599,t:1527271792707};\\\", \\\"{x:363,y:602,t:1527271792723};\\\", \\\"{x:352,y:603,t:1527271792740};\\\", \\\"{x:345,y:605,t:1527271792756};\\\", \\\"{x:331,y:607,t:1527271792774};\\\", \\\"{x:293,y:612,t:1527271792791};\\\", \\\"{x:265,y:617,t:1527271792808};\\\", \\\"{x:252,y:619,t:1527271792823};\\\", \\\"{x:240,y:621,t:1527271792842};\\\", \\\"{x:235,y:621,t:1527271792857};\\\", \\\"{x:229,y:621,t:1527271792873};\\\", \\\"{x:228,y:621,t:1527271792918};\\\", \\\"{x:225,y:621,t:1527271792950};\\\", \\\"{x:222,y:621,t:1527271792958};\\\", \\\"{x:221,y:621,t:1527271792973};\\\", \\\"{x:204,y:618,t:1527271792990};\\\", \\\"{x:196,y:615,t:1527271793007};\\\", \\\"{x:189,y:610,t:1527271793024};\\\", \\\"{x:185,y:608,t:1527271793040};\\\", \\\"{x:181,y:605,t:1527271793056};\\\", \\\"{x:174,y:604,t:1527271793073};\\\", \\\"{x:171,y:604,t:1527271793090};\\\", \\\"{x:166,y:604,t:1527271793108};\\\", \\\"{x:160,y:603,t:1527271793123};\\\", \\\"{x:156,y:599,t:1527271793140};\\\", \\\"{x:154,y:597,t:1527271793157};\\\", \\\"{x:153,y:595,t:1527271793173};\\\", \\\"{x:153,y:594,t:1527271793191};\\\", \\\"{x:153,y:593,t:1527271793263};\\\", \\\"{x:153,y:592,t:1527271793279};\\\", \\\"{x:153,y:591,t:1527271793295};\\\", \\\"{x:153,y:590,t:1527271793311};\\\", \\\"{x:153,y:587,t:1527271793399};\\\", \\\"{x:153,y:585,t:1527271793415};\\\", \\\"{x:153,y:584,t:1527271793438};\\\", \\\"{x:153,y:582,t:1527271793457};\\\", \\\"{x:153,y:581,t:1527271793478};\\\", \\\"{x:153,y:579,t:1527271793501};\\\", \\\"{x:153,y:578,t:1527271793517};\\\", \\\"{x:153,y:576,t:1527271793559};\\\", \\\"{x:153,y:575,t:1527271793871};\\\", \\\"{x:153,y:573,t:1527271793888};\\\", \\\"{x:153,y:572,t:1527271793967};\\\", \\\"{x:153,y:570,t:1527271793998};\\\", \\\"{x:155,y:569,t:1527271794583};\\\", \\\"{x:162,y:569,t:1527271794592};\\\", \\\"{x:189,y:569,t:1527271794609};\\\", \\\"{x:223,y:575,t:1527271794626};\\\", \\\"{x:276,y:585,t:1527271794641};\\\", \\\"{x:358,y:590,t:1527271794658};\\\", \\\"{x:428,y:590,t:1527271794674};\\\", \\\"{x:465,y:594,t:1527271794691};\\\", \\\"{x:474,y:597,t:1527271794708};\\\", \\\"{x:483,y:599,t:1527271794726};\\\", \\\"{x:485,y:600,t:1527271794741};\\\", \\\"{x:486,y:601,t:1527271794759};\\\", \\\"{x:487,y:603,t:1527271794855};\\\", \\\"{x:487,y:604,t:1527271794863};\\\", \\\"{x:488,y:605,t:1527271794894};\\\", \\\"{x:488,y:606,t:1527271794909};\\\", \\\"{x:489,y:606,t:1527271794975};\\\", \\\"{x:490,y:606,t:1527271794991};\\\", \\\"{x:490,y:608,t:1527271795063};\\\", \\\"{x:490,y:609,t:1527271795075};\\\", \\\"{x:494,y:616,t:1527271795092};\\\", \\\"{x:495,y:619,t:1527271795108};\\\", \\\"{x:496,y:623,t:1527271795126};\\\", \\\"{x:497,y:627,t:1527271795142};\\\", \\\"{x:499,y:630,t:1527271795159};\\\", \\\"{x:501,y:638,t:1527271795175};\\\", \\\"{x:501,y:645,t:1527271795191};\\\", \\\"{x:502,y:649,t:1527271795208};\\\", \\\"{x:505,y:653,t:1527271795225};\\\", \\\"{x:505,y:657,t:1527271795241};\\\", \\\"{x:506,y:665,t:1527271795258};\\\", \\\"{x:507,y:672,t:1527271795276};\\\", \\\"{x:507,y:677,t:1527271795293};\\\", \\\"{x:507,y:684,t:1527271795309};\\\", \\\"{x:507,y:689,t:1527271795325};\\\", \\\"{x:508,y:695,t:1527271795342};\\\", \\\"{x:508,y:698,t:1527271795359};\\\", \\\"{x:508,y:700,t:1527271795375};\\\", \\\"{x:508,y:703,t:1527271795395};\\\", \\\"{x:508,y:705,t:1527271795409};\\\", \\\"{x:508,y:707,t:1527271795425};\\\", \\\"{x:508,y:708,t:1527271795445};\\\", \\\"{x:508,y:709,t:1527271795534};\\\", \\\"{x:508,y:710,t:1527271795566};\\\", \\\"{x:508,y:711,t:1527271795576};\\\", \\\"{x:508,y:713,t:1527271795593};\\\", \\\"{x:507,y:713,t:1527271795610};\\\", \\\"{x:506,y:715,t:1527271795696};\\\", \\\"{x:505,y:715,t:1527271799815};\\\", \\\"{x:506,y:715,t:1527271803863};\\\", \\\"{x:506,y:714,t:1527271804839};\\\" ] }, { \\\"rt\\\": 48856, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 282551, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-03 PM-K -05 PM-U -U -U -U -F -F -U -H -H -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:704,t:1527271807534};\\\", \\\"{x:508,y:677,t:1527271807544};\\\", \\\"{x:508,y:662,t:1527271807554};\\\", \\\"{x:508,y:647,t:1527271807570};\\\", \\\"{x:505,y:632,t:1527271807585};\\\", \\\"{x:500,y:622,t:1527271807602};\\\", \\\"{x:499,y:615,t:1527271807619};\\\", \\\"{x:495,y:606,t:1527271807636};\\\", \\\"{x:490,y:597,t:1527271807651};\\\", \\\"{x:489,y:592,t:1527271807669};\\\", \\\"{x:486,y:584,t:1527271807686};\\\", \\\"{x:485,y:582,t:1527271807702};\\\", \\\"{x:483,y:581,t:1527271807719};\\\", \\\"{x:483,y:580,t:1527271807735};\\\", \\\"{x:482,y:580,t:1527271807752};\\\", \\\"{x:482,y:579,t:1527271807769};\\\", \\\"{x:480,y:578,t:1527271807806};\\\", \\\"{x:479,y:576,t:1527271807819};\\\", \\\"{x:466,y:570,t:1527271807837};\\\", \\\"{x:453,y:565,t:1527271807852};\\\", \\\"{x:445,y:563,t:1527271807869};\\\", \\\"{x:443,y:562,t:1527271807911};\\\", \\\"{x:441,y:560,t:1527271807926};\\\", \\\"{x:440,y:560,t:1527271807942};\\\", \\\"{x:439,y:559,t:1527271807966};\\\", \\\"{x:439,y:557,t:1527271808006};\\\", \\\"{x:439,y:554,t:1527271808019};\\\", \\\"{x:444,y:547,t:1527271808036};\\\", \\\"{x:455,y:540,t:1527271808055};\\\", \\\"{x:463,y:535,t:1527271808069};\\\", \\\"{x:470,y:530,t:1527271808085};\\\", \\\"{x:472,y:527,t:1527271808102};\\\", \\\"{x:474,y:526,t:1527271808119};\\\", \\\"{x:475,y:526,t:1527271808158};\\\", \\\"{x:476,y:525,t:1527271808169};\\\", \\\"{x:477,y:525,t:1527271808190};\\\", \\\"{x:478,y:524,t:1527271808203};\\\", \\\"{x:478,y:523,t:1527271808230};\\\", \\\"{x:479,y:523,t:1527271808238};\\\", \\\"{x:481,y:523,t:1527271808262};\\\", \\\"{x:481,y:521,t:1527271808270};\\\", \\\"{x:483,y:520,t:1527271808286};\\\", \\\"{x:485,y:520,t:1527271808311};\\\", \\\"{x:487,y:517,t:1527271808319};\\\", \\\"{x:488,y:516,t:1527271808337};\\\", \\\"{x:491,y:511,t:1527271808354};\\\", \\\"{x:494,y:509,t:1527271808370};\\\", \\\"{x:494,y:508,t:1527271808386};\\\", \\\"{x:498,y:505,t:1527271808405};\\\", \\\"{x:504,y:498,t:1527271808420};\\\", \\\"{x:506,y:496,t:1527271808435};\\\", \\\"{x:512,y:493,t:1527271808452};\\\", \\\"{x:518,y:487,t:1527271808468};\\\", \\\"{x:520,y:485,t:1527271808485};\\\", \\\"{x:523,y:483,t:1527271808502};\\\", \\\"{x:524,y:483,t:1527271808534};\\\", \\\"{x:525,y:483,t:1527271808551};\\\", \\\"{x:526,y:482,t:1527271808568};\\\", \\\"{x:528,y:481,t:1527271808585};\\\", \\\"{x:529,y:480,t:1527271808615};\\\", \\\"{x:530,y:480,t:1527271808622};\\\", \\\"{x:532,y:479,t:1527271808647};\\\", \\\"{x:533,y:478,t:1527271808687};\\\", \\\"{x:534,y:478,t:1527271808943};\\\", \\\"{x:535,y:478,t:1527271809015};\\\", \\\"{x:536,y:478,t:1527271809055};\\\", \\\"{x:537,y:478,t:1527271809070};\\\", \\\"{x:537,y:477,t:1527271809110};\\\", \\\"{x:538,y:477,t:1527271809142};\\\", \\\"{x:539,y:477,t:1527271809159};\\\", \\\"{x:540,y:477,t:1527271809166};\\\", \\\"{x:544,y:477,t:1527271809183};\\\", \\\"{x:559,y:477,t:1527271809200};\\\", \\\"{x:567,y:477,t:1527271809216};\\\", \\\"{x:584,y:477,t:1527271809233};\\\", \\\"{x:607,y:481,t:1527271809250};\\\", \\\"{x:624,y:482,t:1527271809266};\\\", \\\"{x:638,y:485,t:1527271809283};\\\", \\\"{x:648,y:487,t:1527271809300};\\\", \\\"{x:658,y:491,t:1527271809316};\\\", \\\"{x:662,y:492,t:1527271809333};\\\", \\\"{x:673,y:495,t:1527271809349};\\\", \\\"{x:696,y:501,t:1527271809366};\\\", \\\"{x:714,y:506,t:1527271809383};\\\", \\\"{x:728,y:512,t:1527271809400};\\\", \\\"{x:748,y:520,t:1527271809420};\\\", \\\"{x:769,y:524,t:1527271809437};\\\", \\\"{x:783,y:531,t:1527271809454};\\\", \\\"{x:786,y:532,t:1527271809470};\\\", \\\"{x:789,y:535,t:1527271809487};\\\", \\\"{x:790,y:536,t:1527271809504};\\\", \\\"{x:791,y:541,t:1527271809521};\\\", \\\"{x:796,y:546,t:1527271809538};\\\", \\\"{x:803,y:553,t:1527271809553};\\\", \\\"{x:812,y:560,t:1527271809570};\\\", \\\"{x:827,y:568,t:1527271809588};\\\", \\\"{x:853,y:581,t:1527271809604};\\\", \\\"{x:910,y:605,t:1527271809622};\\\", \\\"{x:963,y:626,t:1527271809638};\\\", \\\"{x:1016,y:647,t:1527271809654};\\\", \\\"{x:1028,y:655,t:1527271809670};\\\", \\\"{x:1056,y:669,t:1527271809687};\\\", \\\"{x:1083,y:685,t:1527271809705};\\\", \\\"{x:1105,y:698,t:1527271809720};\\\", \\\"{x:1119,y:706,t:1527271809737};\\\", \\\"{x:1129,y:711,t:1527271809755};\\\", \\\"{x:1132,y:713,t:1527271809770};\\\", \\\"{x:1132,y:714,t:1527271809788};\\\", \\\"{x:1132,y:716,t:1527271809822};\\\", \\\"{x:1132,y:717,t:1527271809839};\\\", \\\"{x:1130,y:717,t:1527271809967};\\\", \\\"{x:1130,y:718,t:1527271809983};\\\", \\\"{x:1129,y:718,t:1527271810007};\\\", \\\"{x:1127,y:719,t:1527271810030};\\\", \\\"{x:1126,y:719,t:1527271810039};\\\", \\\"{x:1126,y:721,t:1527271810159};\\\", \\\"{x:1126,y:723,t:1527271810172};\\\", \\\"{x:1127,y:725,t:1527271810188};\\\", \\\"{x:1128,y:726,t:1527271810204};\\\", \\\"{x:1129,y:727,t:1527271810222};\\\", \\\"{x:1130,y:728,t:1527271810238};\\\", \\\"{x:1131,y:728,t:1527271810255};\\\", \\\"{x:1133,y:730,t:1527271810272};\\\", \\\"{x:1134,y:731,t:1527271810327};\\\", \\\"{x:1135,y:731,t:1527271810339};\\\", \\\"{x:1137,y:734,t:1527271810354};\\\", \\\"{x:1140,y:737,t:1527271810372};\\\", \\\"{x:1141,y:738,t:1527271810389};\\\", \\\"{x:1145,y:742,t:1527271810405};\\\", \\\"{x:1150,y:745,t:1527271810421};\\\", \\\"{x:1155,y:749,t:1527271810439};\\\", \\\"{x:1156,y:750,t:1527271810463};\\\", \\\"{x:1157,y:751,t:1527271810471};\\\", \\\"{x:1159,y:753,t:1527271810489};\\\", \\\"{x:1161,y:756,t:1527271810505};\\\", \\\"{x:1162,y:757,t:1527271810522};\\\", \\\"{x:1162,y:759,t:1527271810538};\\\", \\\"{x:1164,y:762,t:1527271810554};\\\", \\\"{x:1164,y:763,t:1527271810571};\\\", \\\"{x:1164,y:766,t:1527271810589};\\\", \\\"{x:1164,y:769,t:1527271810605};\\\", \\\"{x:1164,y:770,t:1527271810622};\\\", \\\"{x:1164,y:772,t:1527271810638};\\\", \\\"{x:1164,y:773,t:1527271810687};\\\", \\\"{x:1164,y:774,t:1527271810706};\\\", \\\"{x:1164,y:775,t:1527271810721};\\\", \\\"{x:1164,y:776,t:1527271810872};\\\", \\\"{x:1164,y:777,t:1527271810889};\\\", \\\"{x:1164,y:779,t:1527271810906};\\\", \\\"{x:1163,y:780,t:1527271810927};\\\", \\\"{x:1163,y:781,t:1527271810942};\\\", \\\"{x:1162,y:781,t:1527271810956};\\\", \\\"{x:1161,y:781,t:1527271810975};\\\", \\\"{x:1159,y:781,t:1527271810999};\\\", \\\"{x:1158,y:781,t:1527271811086};\\\", \\\"{x:1157,y:781,t:1527271811654};\\\", \\\"{x:1156,y:781,t:1527271811662};\\\", \\\"{x:1155,y:782,t:1527271811734};\\\", \\\"{x:1151,y:781,t:1527271811981};\\\", \\\"{x:1147,y:779,t:1527271811990};\\\", \\\"{x:1137,y:770,t:1527271812006};\\\", \\\"{x:1124,y:764,t:1527271812022};\\\", \\\"{x:1112,y:756,t:1527271812039};\\\", \\\"{x:1101,y:749,t:1527271812056};\\\", \\\"{x:1090,y:741,t:1527271812072};\\\", \\\"{x:1084,y:739,t:1527271812089};\\\", \\\"{x:1079,y:735,t:1527271812106};\\\", \\\"{x:1071,y:730,t:1527271812122};\\\", \\\"{x:1062,y:725,t:1527271812139};\\\", \\\"{x:1056,y:722,t:1527271812156};\\\", \\\"{x:1054,y:722,t:1527271812173};\\\", \\\"{x:1053,y:721,t:1527271812189};\\\", \\\"{x:1053,y:720,t:1527271812282};\\\", \\\"{x:1052,y:719,t:1527271812293};\\\", \\\"{x:1052,y:717,t:1527271812322};\\\", \\\"{x:1051,y:714,t:1527271812330};\\\", \\\"{x:1050,y:713,t:1527271812343};\\\", \\\"{x:1048,y:709,t:1527271812359};\\\", \\\"{x:1046,y:706,t:1527271812376};\\\", \\\"{x:1045,y:705,t:1527271812392};\\\", \\\"{x:1045,y:704,t:1527271812410};\\\", \\\"{x:1042,y:701,t:1527271812426};\\\", \\\"{x:1042,y:698,t:1527271812458};\\\", \\\"{x:1041,y:698,t:1527271812473};\\\", \\\"{x:1040,y:696,t:1527271812489};\\\", \\\"{x:1039,y:695,t:1527271812498};\\\", \\\"{x:1038,y:695,t:1527271812714};\\\", \\\"{x:1038,y:697,t:1527271812786};\\\", \\\"{x:1037,y:698,t:1527271812793};\\\", \\\"{x:1036,y:699,t:1527271812808};\\\", \\\"{x:1035,y:700,t:1527271812841};\\\", \\\"{x:1034,y:701,t:1527271812889};\\\", \\\"{x:1032,y:703,t:1527271812993};\\\", \\\"{x:1031,y:705,t:1527271813033};\\\", \\\"{x:1030,y:707,t:1527271813072};\\\", \\\"{x:1030,y:709,t:1527271813081};\\\", \\\"{x:1030,y:711,t:1527271813093};\\\", \\\"{x:1035,y:715,t:1527271813109};\\\", \\\"{x:1038,y:717,t:1527271813126};\\\", \\\"{x:1039,y:719,t:1527271813143};\\\", \\\"{x:1043,y:721,t:1527271813159};\\\", \\\"{x:1051,y:724,t:1527271813176};\\\", \\\"{x:1062,y:730,t:1527271813193};\\\", \\\"{x:1069,y:734,t:1527271813209};\\\", \\\"{x:1073,y:735,t:1527271813226};\\\", \\\"{x:1075,y:737,t:1527271813243};\\\", \\\"{x:1079,y:739,t:1527271813259};\\\", \\\"{x:1082,y:741,t:1527271813277};\\\", \\\"{x:1083,y:741,t:1527271813293};\\\", \\\"{x:1085,y:743,t:1527271813310};\\\", \\\"{x:1086,y:744,t:1527271813395};\\\", \\\"{x:1090,y:748,t:1527271813410};\\\", \\\"{x:1094,y:752,t:1527271813427};\\\", \\\"{x:1103,y:760,t:1527271813444};\\\", \\\"{x:1112,y:769,t:1527271813460};\\\", \\\"{x:1121,y:772,t:1527271813476};\\\", \\\"{x:1130,y:775,t:1527271813494};\\\", \\\"{x:1137,y:778,t:1527271813511};\\\", \\\"{x:1142,y:780,t:1527271813526};\\\", \\\"{x:1150,y:787,t:1527271813543};\\\", \\\"{x:1155,y:788,t:1527271813560};\\\", \\\"{x:1158,y:789,t:1527271813576};\\\", \\\"{x:1160,y:789,t:1527271813593};\\\", \\\"{x:1162,y:789,t:1527271813611};\\\", \\\"{x:1164,y:791,t:1527271813626};\\\", \\\"{x:1163,y:791,t:1527271813939};\\\", \\\"{x:1160,y:791,t:1527271813946};\\\", \\\"{x:1159,y:791,t:1527271813961};\\\", \\\"{x:1156,y:792,t:1527271814074};\\\", \\\"{x:1156,y:793,t:1527271814106};\\\", \\\"{x:1156,y:794,t:1527271814114};\\\", \\\"{x:1155,y:795,t:1527271814137};\\\", \\\"{x:1155,y:796,t:1527271814162};\\\", \\\"{x:1157,y:800,t:1527271814177};\\\", \\\"{x:1185,y:816,t:1527271814194};\\\", \\\"{x:1287,y:857,t:1527271814210};\\\", \\\"{x:1371,y:904,t:1527271814228};\\\", \\\"{x:1384,y:915,t:1527271814245};\\\", \\\"{x:1396,y:930,t:1527271814260};\\\", \\\"{x:1415,y:947,t:1527271814278};\\\", \\\"{x:1431,y:957,t:1527271814295};\\\", \\\"{x:1439,y:965,t:1527271814311};\\\", \\\"{x:1452,y:975,t:1527271814327};\\\", \\\"{x:1463,y:984,t:1527271814345};\\\", \\\"{x:1487,y:992,t:1527271814362};\\\", \\\"{x:1523,y:1007,t:1527271814376};\\\", \\\"{x:1544,y:1015,t:1527271814394};\\\", \\\"{x:1558,y:1019,t:1527271814410};\\\", \\\"{x:1564,y:1020,t:1527271814426};\\\", \\\"{x:1565,y:1021,t:1527271814521};\\\", \\\"{x:1566,y:1021,t:1527271814545};\\\", \\\"{x:1567,y:1021,t:1527271814561};\\\", \\\"{x:1567,y:1019,t:1527271814577};\\\", \\\"{x:1568,y:1018,t:1527271814594};\\\", \\\"{x:1569,y:1017,t:1527271814617};\\\", \\\"{x:1569,y:1016,t:1527271814633};\\\", \\\"{x:1571,y:1015,t:1527271814657};\\\", \\\"{x:1571,y:1013,t:1527271814673};\\\", \\\"{x:1571,y:1012,t:1527271814691};\\\", \\\"{x:1572,y:1012,t:1527271814698};\\\", \\\"{x:1573,y:1012,t:1527271814729};\\\", \\\"{x:1574,y:1011,t:1527271814745};\\\", \\\"{x:1576,y:1010,t:1527271814762};\\\", \\\"{x:1579,y:1009,t:1527271814778};\\\", \\\"{x:1581,y:1009,t:1527271814794};\\\", \\\"{x:1583,y:1008,t:1527271814811};\\\", \\\"{x:1594,y:1008,t:1527271814827};\\\", \\\"{x:1611,y:1008,t:1527271814845};\\\", \\\"{x:1631,y:1008,t:1527271814861};\\\", \\\"{x:1651,y:1008,t:1527271814877};\\\", \\\"{x:1676,y:1010,t:1527271814895};\\\", \\\"{x:1690,y:1010,t:1527271814911};\\\", \\\"{x:1705,y:1010,t:1527271814928};\\\", \\\"{x:1715,y:1009,t:1527271814945};\\\", \\\"{x:1729,y:1009,t:1527271814961};\\\", \\\"{x:1733,y:1009,t:1527271814977};\\\", \\\"{x:1735,y:1009,t:1527271814995};\\\", \\\"{x:1737,y:1008,t:1527271815012};\\\", \\\"{x:1736,y:1008,t:1527271815843};\\\", \\\"{x:1735,y:1008,t:1527271815866};\\\", \\\"{x:1735,y:1009,t:1527271815879};\\\", \\\"{x:1733,y:1009,t:1527271815896};\\\", \\\"{x:1733,y:1010,t:1527271815912};\\\", \\\"{x:1732,y:1010,t:1527271815929};\\\", \\\"{x:1731,y:1010,t:1527271815945};\\\", \\\"{x:1730,y:1010,t:1527271815963};\\\", \\\"{x:1728,y:1010,t:1527271815979};\\\", \\\"{x:1727,y:1011,t:1527271816002};\\\", \\\"{x:1726,y:1011,t:1527271816026};\\\", \\\"{x:1725,y:1011,t:1527271816041};\\\", \\\"{x:1724,y:1011,t:1527271816057};\\\", \\\"{x:1721,y:1011,t:1527271816065};\\\", \\\"{x:1719,y:1012,t:1527271816079};\\\", \\\"{x:1717,y:1013,t:1527271816095};\\\", \\\"{x:1714,y:1014,t:1527271816113};\\\", \\\"{x:1712,y:1014,t:1527271816138};\\\", \\\"{x:1711,y:1015,t:1527271816161};\\\", \\\"{x:1709,y:1015,t:1527271816234};\\\", \\\"{x:1708,y:1015,t:1527271816257};\\\", \\\"{x:1706,y:1016,t:1527271816266};\\\", \\\"{x:1705,y:1016,t:1527271816282};\\\", \\\"{x:1703,y:1016,t:1527271816296};\\\", \\\"{x:1697,y:1017,t:1527271816312};\\\", \\\"{x:1695,y:1017,t:1527271816328};\\\", \\\"{x:1693,y:1017,t:1527271816345};\\\", \\\"{x:1688,y:1019,t:1527271816362};\\\", \\\"{x:1687,y:1019,t:1527271816380};\\\", \\\"{x:1685,y:1019,t:1527271816395};\\\", \\\"{x:1684,y:1019,t:1527271816440};\\\", \\\"{x:1683,y:1019,t:1527271816456};\\\", \\\"{x:1681,y:1019,t:1527271816465};\\\", \\\"{x:1680,y:1019,t:1527271816489};\\\", \\\"{x:1678,y:1019,t:1527271816496};\\\", \\\"{x:1677,y:1019,t:1527271816512};\\\", \\\"{x:1674,y:1019,t:1527271816530};\\\", \\\"{x:1672,y:1019,t:1527271816545};\\\", \\\"{x:1671,y:1019,t:1527271816602};\\\", \\\"{x:1669,y:1020,t:1527271816618};\\\", \\\"{x:1667,y:1020,t:1527271816641};\\\", \\\"{x:1664,y:1021,t:1527271816698};\\\", \\\"{x:1663,y:1021,t:1527271816713};\\\", \\\"{x:1659,y:1021,t:1527271816730};\\\", \\\"{x:1656,y:1021,t:1527271816746};\\\", \\\"{x:1654,y:1021,t:1527271816763};\\\", \\\"{x:1652,y:1022,t:1527271816780};\\\", \\\"{x:1651,y:1022,t:1527271816795};\\\", \\\"{x:1649,y:1023,t:1527271816813};\\\", \\\"{x:1648,y:1023,t:1527271816841};\\\", \\\"{x:1646,y:1023,t:1527271816898};\\\", \\\"{x:1645,y:1023,t:1527271816922};\\\", \\\"{x:1644,y:1023,t:1527271816929};\\\", \\\"{x:1643,y:1023,t:1527271816962};\\\", \\\"{x:1641,y:1023,t:1527271816980};\\\", \\\"{x:1639,y:1023,t:1527271816996};\\\", \\\"{x:1636,y:1023,t:1527271817013};\\\", \\\"{x:1632,y:1023,t:1527271817030};\\\", \\\"{x:1628,y:1022,t:1527271817047};\\\", \\\"{x:1624,y:1021,t:1527271817063};\\\", \\\"{x:1622,y:1021,t:1527271817080};\\\", \\\"{x:1621,y:1021,t:1527271817097};\\\", \\\"{x:1618,y:1021,t:1527271817113};\\\", \\\"{x:1612,y:1018,t:1527271817129};\\\", \\\"{x:1610,y:1018,t:1527271817147};\\\", \\\"{x:1607,y:1018,t:1527271817163};\\\", \\\"{x:1602,y:1017,t:1527271817179};\\\", \\\"{x:1600,y:1017,t:1527271817197};\\\", \\\"{x:1599,y:1017,t:1527271817217};\\\", \\\"{x:1597,y:1017,t:1527271817354};\\\", \\\"{x:1596,y:1017,t:1527271817386};\\\", \\\"{x:1594,y:1017,t:1527271817410};\\\", \\\"{x:1593,y:1016,t:1527271817426};\\\", \\\"{x:1592,y:1016,t:1527271817490};\\\", \\\"{x:1591,y:1016,t:1527271817650};\\\", \\\"{x:1590,y:1015,t:1527271817664};\\\", \\\"{x:1587,y:1015,t:1527271817679};\\\", \\\"{x:1586,y:1015,t:1527271817698};\\\", \\\"{x:1584,y:1015,t:1527271817882};\\\", \\\"{x:1584,y:1014,t:1527271817922};\\\", \\\"{x:1582,y:1013,t:1527271818115};\\\", \\\"{x:1581,y:1013,t:1527271818490};\\\", \\\"{x:1580,y:1013,t:1527271818546};\\\", \\\"{x:1579,y:1013,t:1527271818618};\\\", \\\"{x:1578,y:1013,t:1527271818631};\\\", \\\"{x:1576,y:1012,t:1527271818648};\\\", \\\"{x:1576,y:1010,t:1527271818665};\\\", \\\"{x:1575,y:1009,t:1527271818681};\\\", \\\"{x:1574,y:1007,t:1527271818698};\\\", \\\"{x:1574,y:1006,t:1527271818721};\\\", \\\"{x:1574,y:1004,t:1527271818738};\\\", \\\"{x:1574,y:1003,t:1527271818748};\\\", \\\"{x:1574,y:1000,t:1527271818765};\\\", \\\"{x:1574,y:997,t:1527271818781};\\\", \\\"{x:1574,y:996,t:1527271818802};\\\", \\\"{x:1574,y:995,t:1527271818834};\\\", \\\"{x:1574,y:994,t:1527271818858};\\\", \\\"{x:1575,y:992,t:1527271818898};\\\", \\\"{x:1575,y:991,t:1527271818937};\\\", \\\"{x:1576,y:990,t:1527271819226};\\\", \\\"{x:1577,y:989,t:1527271819290};\\\", \\\"{x:1578,y:989,t:1527271819386};\\\", \\\"{x:1578,y:988,t:1527271819398};\\\", \\\"{x:1580,y:987,t:1527271819415};\\\", \\\"{x:1584,y:987,t:1527271819432};\\\", \\\"{x:1587,y:986,t:1527271819448};\\\", \\\"{x:1589,y:985,t:1527271819682};\\\", \\\"{x:1589,y:984,t:1527271819826};\\\", \\\"{x:1587,y:983,t:1527271819849};\\\", \\\"{x:1587,y:982,t:1527271819866};\\\", \\\"{x:1583,y:981,t:1527271819882};\\\", \\\"{x:1582,y:981,t:1527271819899};\\\", \\\"{x:1581,y:981,t:1527271819915};\\\", \\\"{x:1579,y:980,t:1527271819932};\\\", \\\"{x:1577,y:980,t:1527271819949};\\\", \\\"{x:1575,y:979,t:1527271819966};\\\", \\\"{x:1572,y:978,t:1527271819982};\\\", \\\"{x:1570,y:978,t:1527271819999};\\\", \\\"{x:1568,y:978,t:1527271820017};\\\", \\\"{x:1566,y:977,t:1527271820032};\\\", \\\"{x:1564,y:976,t:1527271820049};\\\", \\\"{x:1563,y:975,t:1527271820073};\\\", \\\"{x:1561,y:974,t:1527271820090};\\\", \\\"{x:1560,y:973,t:1527271820106};\\\", \\\"{x:1558,y:972,t:1527271820121};\\\", \\\"{x:1557,y:971,t:1527271820132};\\\", \\\"{x:1555,y:971,t:1527271820149};\\\", \\\"{x:1554,y:971,t:1527271820166};\\\", \\\"{x:1551,y:970,t:1527271820182};\\\", \\\"{x:1551,y:969,t:1527271820410};\\\", \\\"{x:1550,y:968,t:1527271820418};\\\", \\\"{x:1550,y:965,t:1527271820434};\\\", \\\"{x:1550,y:964,t:1527271820450};\\\", \\\"{x:1550,y:955,t:1527271820466};\\\", \\\"{x:1552,y:940,t:1527271820483};\\\", \\\"{x:1558,y:923,t:1527271820499};\\\", \\\"{x:1562,y:905,t:1527271820516};\\\", \\\"{x:1563,y:885,t:1527271820533};\\\", \\\"{x:1567,y:869,t:1527271820550};\\\", \\\"{x:1571,y:855,t:1527271820566};\\\", \\\"{x:1572,y:845,t:1527271820583};\\\", \\\"{x:1574,y:835,t:1527271820599};\\\", \\\"{x:1576,y:825,t:1527271820616};\\\", \\\"{x:1576,y:817,t:1527271820633};\\\", \\\"{x:1576,y:803,t:1527271820649};\\\", \\\"{x:1567,y:787,t:1527271820666};\\\", \\\"{x:1562,y:771,t:1527271820683};\\\", \\\"{x:1556,y:757,t:1527271820700};\\\", \\\"{x:1552,y:739,t:1527271820716};\\\", \\\"{x:1552,y:726,t:1527271820733};\\\", \\\"{x:1551,y:716,t:1527271820749};\\\", \\\"{x:1551,y:708,t:1527271820766};\\\", \\\"{x:1550,y:698,t:1527271820783};\\\", \\\"{x:1549,y:687,t:1527271820800};\\\", \\\"{x:1548,y:685,t:1527271820817};\\\", \\\"{x:1547,y:677,t:1527271820833};\\\", \\\"{x:1545,y:666,t:1527271820848};\\\", \\\"{x:1542,y:661,t:1527271820865};\\\", \\\"{x:1540,y:657,t:1527271820882};\\\", \\\"{x:1539,y:654,t:1527271820900};\\\", \\\"{x:1539,y:651,t:1527271820916};\\\", \\\"{x:1538,y:650,t:1527271820932};\\\", \\\"{x:1537,y:647,t:1527271820949};\\\", \\\"{x:1537,y:645,t:1527271820966};\\\", \\\"{x:1537,y:641,t:1527271820982};\\\", \\\"{x:1536,y:640,t:1527271821000};\\\", \\\"{x:1536,y:636,t:1527271821015};\\\", \\\"{x:1535,y:633,t:1527271821033};\\\", \\\"{x:1534,y:632,t:1527271821057};\\\", \\\"{x:1533,y:632,t:1527271821115};\\\", \\\"{x:1532,y:632,t:1527271821129};\\\", \\\"{x:1530,y:632,t:1527271821154};\\\", \\\"{x:1529,y:632,t:1527271821166};\\\", \\\"{x:1523,y:632,t:1527271821183};\\\", \\\"{x:1515,y:632,t:1527271821202};\\\", \\\"{x:1505,y:634,t:1527271821216};\\\", \\\"{x:1500,y:635,t:1527271821232};\\\", \\\"{x:1495,y:635,t:1527271821250};\\\", \\\"{x:1494,y:635,t:1527271821288};\\\", \\\"{x:1495,y:635,t:1527271821530};\\\", \\\"{x:1496,y:635,t:1527271821546};\\\", \\\"{x:1497,y:635,t:1527271821642};\\\", \\\"{x:1498,y:635,t:1527271821954};\\\", \\\"{x:1500,y:635,t:1527271821967};\\\", \\\"{x:1501,y:635,t:1527271821994};\\\", \\\"{x:1502,y:635,t:1527271822186};\\\", \\\"{x:1503,y:635,t:1527271822200};\\\", \\\"{x:1504,y:635,t:1527271822305};\\\", \\\"{x:1505,y:635,t:1527271822353};\\\", \\\"{x:1507,y:634,t:1527271822366};\\\", \\\"{x:1508,y:635,t:1527271822778};\\\", \\\"{x:1509,y:635,t:1527271822802};\\\", \\\"{x:1509,y:636,t:1527271822859};\\\", \\\"{x:1509,y:637,t:1527271822868};\\\", \\\"{x:1509,y:638,t:1527271822898};\\\", \\\"{x:1510,y:638,t:1527271822906};\\\", \\\"{x:1511,y:640,t:1527271822930};\\\", \\\"{x:1511,y:641,t:1527271822946};\\\", \\\"{x:1512,y:641,t:1527271822978};\\\", \\\"{x:1515,y:641,t:1527271822993};\\\", \\\"{x:1516,y:641,t:1527271823010};\\\", \\\"{x:1519,y:642,t:1527271823017};\\\", \\\"{x:1522,y:644,t:1527271823035};\\\", \\\"{x:1523,y:644,t:1527271823051};\\\", \\\"{x:1524,y:644,t:1527271823068};\\\", \\\"{x:1527,y:645,t:1527271823086};\\\", \\\"{x:1527,y:646,t:1527271823106};\\\", \\\"{x:1528,y:646,t:1527271823202};\\\", \\\"{x:1528,y:647,t:1527271823217};\\\", \\\"{x:1528,y:648,t:1527271823235};\\\", \\\"{x:1529,y:649,t:1527271823251};\\\", \\\"{x:1529,y:650,t:1527271823290};\\\", \\\"{x:1529,y:651,t:1527271823362};\\\", \\\"{x:1528,y:653,t:1527271823378};\\\", \\\"{x:1527,y:654,t:1527271823394};\\\", \\\"{x:1526,y:655,t:1527271823507};\\\", \\\"{x:1525,y:655,t:1527271823537};\\\", \\\"{x:1524,y:656,t:1527271823554};\\\", \\\"{x:1524,y:657,t:1527271823610};\\\", \\\"{x:1523,y:657,t:1527271823650};\\\", \\\"{x:1523,y:658,t:1527271823665};\\\", \\\"{x:1521,y:658,t:1527271823698};\\\", \\\"{x:1521,y:659,t:1527271823714};\\\", \\\"{x:1521,y:660,t:1527271823737};\\\", \\\"{x:1521,y:662,t:1527271823794};\\\", \\\"{x:1521,y:663,t:1527271823842};\\\", \\\"{x:1520,y:663,t:1527271823890};\\\", \\\"{x:1519,y:663,t:1527271823902};\\\", \\\"{x:1517,y:664,t:1527271823919};\\\", \\\"{x:1515,y:664,t:1527271823935};\\\", \\\"{x:1514,y:664,t:1527271823952};\\\", \\\"{x:1511,y:665,t:1527271823970};\\\", \\\"{x:1508,y:666,t:1527271823994};\\\", \\\"{x:1507,y:667,t:1527271824002};\\\", \\\"{x:1506,y:668,t:1527271824019};\\\", \\\"{x:1505,y:669,t:1527271824036};\\\", \\\"{x:1504,y:670,t:1527271824052};\\\", \\\"{x:1503,y:675,t:1527271824069};\\\", \\\"{x:1503,y:680,t:1527271824086};\\\", \\\"{x:1503,y:686,t:1527271824102};\\\", \\\"{x:1506,y:693,t:1527271824120};\\\", \\\"{x:1511,y:699,t:1527271824135};\\\", \\\"{x:1515,y:706,t:1527271824152};\\\", \\\"{x:1523,y:717,t:1527271824170};\\\", \\\"{x:1525,y:723,t:1527271824185};\\\", \\\"{x:1527,y:730,t:1527271824202};\\\", \\\"{x:1527,y:738,t:1527271824219};\\\", \\\"{x:1528,y:742,t:1527271824235};\\\", \\\"{x:1528,y:750,t:1527271824252};\\\", \\\"{x:1528,y:754,t:1527271824268};\\\", \\\"{x:1525,y:761,t:1527271824284};\\\", \\\"{x:1525,y:766,t:1527271824302};\\\", \\\"{x:1525,y:767,t:1527271824321};\\\", \\\"{x:1525,y:770,t:1527271824336};\\\", \\\"{x:1527,y:774,t:1527271824352};\\\", \\\"{x:1532,y:786,t:1527271824369};\\\", \\\"{x:1538,y:796,t:1527271824385};\\\", \\\"{x:1541,y:800,t:1527271824402};\\\", \\\"{x:1546,y:805,t:1527271824419};\\\", \\\"{x:1550,y:812,t:1527271824436};\\\", \\\"{x:1553,y:817,t:1527271824452};\\\", \\\"{x:1555,y:823,t:1527271824469};\\\", \\\"{x:1564,y:838,t:1527271824486};\\\", \\\"{x:1572,y:851,t:1527271824502};\\\", \\\"{x:1581,y:863,t:1527271824519};\\\", \\\"{x:1588,y:869,t:1527271824536};\\\", \\\"{x:1595,y:875,t:1527271824552};\\\", \\\"{x:1600,y:885,t:1527271824569};\\\", \\\"{x:1602,y:888,t:1527271824585};\\\", \\\"{x:1602,y:891,t:1527271824602};\\\", \\\"{x:1605,y:895,t:1527271824619};\\\", \\\"{x:1610,y:903,t:1527271824636};\\\", \\\"{x:1615,y:919,t:1527271824652};\\\", \\\"{x:1626,y:935,t:1527271824669};\\\", \\\"{x:1631,y:946,t:1527271824686};\\\", \\\"{x:1636,y:955,t:1527271824703};\\\", \\\"{x:1643,y:966,t:1527271824719};\\\", \\\"{x:1652,y:974,t:1527271824736};\\\", \\\"{x:1655,y:976,t:1527271824752};\\\", \\\"{x:1665,y:983,t:1527271824770};\\\", \\\"{x:1668,y:986,t:1527271824786};\\\", \\\"{x:1672,y:989,t:1527271824802};\\\", \\\"{x:1677,y:990,t:1527271824819};\\\", \\\"{x:1678,y:992,t:1527271824836};\\\", \\\"{x:1684,y:993,t:1527271824853};\\\", \\\"{x:1689,y:994,t:1527271824869};\\\", \\\"{x:1704,y:994,t:1527271824887};\\\", \\\"{x:1712,y:994,t:1527271824904};\\\", \\\"{x:1734,y:993,t:1527271824919};\\\", \\\"{x:1756,y:993,t:1527271824936};\\\", \\\"{x:1779,y:980,t:1527271824953};\\\", \\\"{x:1783,y:980,t:1527271824969};\\\", \\\"{x:1785,y:980,t:1527271824986};\\\", \\\"{x:1785,y:979,t:1527271825004};\\\", \\\"{x:1785,y:978,t:1527271825082};\\\", \\\"{x:1785,y:977,t:1527271825114};\\\", \\\"{x:1785,y:976,t:1527271825122};\\\", \\\"{x:1776,y:976,t:1527271825136};\\\", \\\"{x:1736,y:968,t:1527271825154};\\\", \\\"{x:1717,y:962,t:1527271825170};\\\", \\\"{x:1691,y:960,t:1527271825186};\\\", \\\"{x:1669,y:956,t:1527271825203};\\\", \\\"{x:1653,y:952,t:1527271825219};\\\", \\\"{x:1649,y:948,t:1527271825237};\\\", \\\"{x:1636,y:946,t:1527271825253};\\\", \\\"{x:1623,y:943,t:1527271825270};\\\", \\\"{x:1613,y:942,t:1527271825286};\\\", \\\"{x:1603,y:940,t:1527271825304};\\\", \\\"{x:1594,y:937,t:1527271825321};\\\", \\\"{x:1578,y:933,t:1527271825336};\\\", \\\"{x:1567,y:927,t:1527271825354};\\\", \\\"{x:1558,y:920,t:1527271825370};\\\", \\\"{x:1554,y:915,t:1527271825386};\\\", \\\"{x:1553,y:911,t:1527271825404};\\\", \\\"{x:1549,y:905,t:1527271825420};\\\", \\\"{x:1540,y:889,t:1527271825437};\\\", \\\"{x:1530,y:870,t:1527271825453};\\\", \\\"{x:1523,y:856,t:1527271825470};\\\", \\\"{x:1517,y:840,t:1527271825486};\\\", \\\"{x:1506,y:828,t:1527271825503};\\\", \\\"{x:1499,y:819,t:1527271825520};\\\", \\\"{x:1490,y:808,t:1527271825536};\\\", \\\"{x:1481,y:804,t:1527271825554};\\\", \\\"{x:1480,y:804,t:1527271825570};\\\", \\\"{x:1480,y:806,t:1527271825730};\\\", \\\"{x:1480,y:808,t:1527271825738};\\\", \\\"{x:1480,y:811,t:1527271825754};\\\", \\\"{x:1480,y:814,t:1527271825770};\\\", \\\"{x:1480,y:815,t:1527271825810};\\\", \\\"{x:1480,y:817,t:1527271825882};\\\", \\\"{x:1480,y:818,t:1527271825978};\\\", \\\"{x:1480,y:822,t:1527271825993};\\\", \\\"{x:1480,y:824,t:1527271826018};\\\", \\\"{x:1480,y:825,t:1527271826035};\\\", \\\"{x:1481,y:826,t:1527271826090};\\\", \\\"{x:1481,y:827,t:1527271826138};\\\", \\\"{x:1481,y:828,t:1527271826162};\\\", \\\"{x:1481,y:830,t:1527271826171};\\\", \\\"{x:1481,y:831,t:1527271826187};\\\", \\\"{x:1482,y:831,t:1527271826204};\\\", \\\"{x:1482,y:833,t:1527271827449};\\\", \\\"{x:1482,y:834,t:1527271831650};\\\", \\\"{x:1482,y:835,t:1527271831682};\\\", \\\"{x:1482,y:836,t:1527271831692};\\\", \\\"{x:1481,y:838,t:1527271831709};\\\", \\\"{x:1472,y:838,t:1527271831725};\\\", \\\"{x:1463,y:838,t:1527271831742};\\\", \\\"{x:1462,y:838,t:1527271831759};\\\", \\\"{x:1461,y:837,t:1527271831775};\\\", \\\"{x:1459,y:836,t:1527271831914};\\\", \\\"{x:1459,y:835,t:1527271831938};\\\", \\\"{x:1457,y:835,t:1527271831946};\\\", \\\"{x:1456,y:835,t:1527271831958};\\\", \\\"{x:1447,y:832,t:1527271831975};\\\", \\\"{x:1433,y:826,t:1527271831992};\\\", \\\"{x:1415,y:820,t:1527271832008};\\\", \\\"{x:1378,y:808,t:1527271832025};\\\", \\\"{x:1351,y:798,t:1527271832041};\\\", \\\"{x:1327,y:792,t:1527271832058};\\\", \\\"{x:1317,y:786,t:1527271832076};\\\", \\\"{x:1307,y:785,t:1527271832091};\\\", \\\"{x:1284,y:781,t:1527271832109};\\\", \\\"{x:1263,y:771,t:1527271832126};\\\", \\\"{x:1243,y:764,t:1527271832142};\\\", \\\"{x:1223,y:757,t:1527271832159};\\\", \\\"{x:1206,y:751,t:1527271832176};\\\", \\\"{x:1190,y:749,t:1527271832192};\\\", \\\"{x:1177,y:746,t:1527271832209};\\\", \\\"{x:1160,y:744,t:1527271832226};\\\", \\\"{x:1146,y:743,t:1527271832242};\\\", \\\"{x:1135,y:739,t:1527271832259};\\\", \\\"{x:1115,y:738,t:1527271832275};\\\", \\\"{x:1098,y:734,t:1527271832292};\\\", \\\"{x:1082,y:734,t:1527271832309};\\\", \\\"{x:1064,y:731,t:1527271832326};\\\", \\\"{x:1037,y:731,t:1527271832343};\\\", \\\"{x:1009,y:731,t:1527271832359};\\\", \\\"{x:973,y:731,t:1527271832376};\\\", \\\"{x:895,y:739,t:1527271832392};\\\", \\\"{x:827,y:753,t:1527271832409};\\\", \\\"{x:698,y:782,t:1527271832425};\\\", \\\"{x:683,y:784,t:1527271832442};\\\", \\\"{x:675,y:785,t:1527271832459};\\\", \\\"{x:673,y:786,t:1527271832476};\\\", \\\"{x:655,y:785,t:1527271832492};\\\", \\\"{x:640,y:785,t:1527271832509};\\\", \\\"{x:628,y:778,t:1527271832525};\\\", \\\"{x:625,y:776,t:1527271832542};\\\", \\\"{x:618,y:772,t:1527271832559};\\\", \\\"{x:609,y:766,t:1527271832576};\\\", \\\"{x:604,y:759,t:1527271832593};\\\", \\\"{x:601,y:752,t:1527271832609};\\\", \\\"{x:599,y:734,t:1527271832625};\\\", \\\"{x:593,y:712,t:1527271832643};\\\", \\\"{x:583,y:692,t:1527271832659};\\\", \\\"{x:572,y:666,t:1527271832675};\\\", \\\"{x:566,y:645,t:1527271832694};\\\", \\\"{x:554,y:634,t:1527271832709};\\\", \\\"{x:549,y:614,t:1527271832725};\\\", \\\"{x:546,y:595,t:1527271832739};\\\", \\\"{x:546,y:581,t:1527271832756};\\\", \\\"{x:546,y:568,t:1527271832772};\\\", \\\"{x:547,y:556,t:1527271832791};\\\", \\\"{x:550,y:547,t:1527271832809};\\\", \\\"{x:551,y:543,t:1527271832826};\\\", \\\"{x:552,y:542,t:1527271832842};\\\", \\\"{x:554,y:540,t:1527271832859};\\\", \\\"{x:554,y:539,t:1527271832888};\\\", \\\"{x:555,y:539,t:1527271832896};\\\", \\\"{x:557,y:539,t:1527271832921};\\\", \\\"{x:559,y:539,t:1527271832929};\\\", \\\"{x:561,y:539,t:1527271832943};\\\", \\\"{x:564,y:539,t:1527271832960};\\\", \\\"{x:567,y:539,t:1527271832976};\\\", \\\"{x:571,y:539,t:1527271832992};\\\", \\\"{x:581,y:545,t:1527271833010};\\\", \\\"{x:595,y:553,t:1527271833026};\\\", \\\"{x:605,y:562,t:1527271833044};\\\", \\\"{x:620,y:573,t:1527271833059};\\\", \\\"{x:634,y:581,t:1527271833076};\\\", \\\"{x:637,y:584,t:1527271833093};\\\", \\\"{x:639,y:586,t:1527271833109};\\\", \\\"{x:639,y:588,t:1527271833153};\\\", \\\"{x:639,y:589,t:1527271833160};\\\", \\\"{x:639,y:591,t:1527271833176};\\\", \\\"{x:638,y:592,t:1527271833193};\\\", \\\"{x:638,y:593,t:1527271833225};\\\", \\\"{x:638,y:594,t:1527271833266};\\\", \\\"{x:637,y:594,t:1527271833277};\\\", \\\"{x:635,y:594,t:1527271833294};\\\", \\\"{x:633,y:595,t:1527271833310};\\\", \\\"{x:630,y:595,t:1527271833337};\\\", \\\"{x:627,y:595,t:1527271833353};\\\", \\\"{x:626,y:595,t:1527271833361};\\\", \\\"{x:622,y:595,t:1527271833377};\\\", \\\"{x:616,y:595,t:1527271833394};\\\", \\\"{x:615,y:595,t:1527271833411};\\\", \\\"{x:614,y:595,t:1527271833428};\\\", \\\"{x:612,y:596,t:1527271833457};\\\", \\\"{x:615,y:596,t:1527271833529};\\\", \\\"{x:616,y:596,t:1527271833545};\\\", \\\"{x:618,y:595,t:1527271833570};\\\", \\\"{x:619,y:595,t:1527271833578};\\\", \\\"{x:624,y:595,t:1527271833595};\\\", \\\"{x:626,y:595,t:1527271833611};\\\", \\\"{x:627,y:595,t:1527271833627};\\\", \\\"{x:622,y:599,t:1527271834090};\\\", \\\"{x:615,y:602,t:1527271834098};\\\", \\\"{x:605,y:606,t:1527271834111};\\\", \\\"{x:592,y:617,t:1527271834129};\\\", \\\"{x:576,y:626,t:1527271834143};\\\", \\\"{x:569,y:630,t:1527271834160};\\\", \\\"{x:563,y:638,t:1527271834176};\\\", \\\"{x:560,y:642,t:1527271834193};\\\", \\\"{x:556,y:647,t:1527271834210};\\\", \\\"{x:550,y:655,t:1527271834228};\\\", \\\"{x:538,y:671,t:1527271834243};\\\", \\\"{x:528,y:681,t:1527271834260};\\\", \\\"{x:519,y:687,t:1527271834276};\\\", \\\"{x:518,y:688,t:1527271834293};\\\", \\\"{x:518,y:689,t:1527271834321};\\\", \\\"{x:518,y:692,t:1527271834538};\\\", \\\"{x:518,y:694,t:1527271834545};\\\", \\\"{x:516,y:695,t:1527271834559};\\\", \\\"{x:515,y:699,t:1527271834577};\\\", \\\"{x:515,y:701,t:1527271834594};\\\", \\\"{x:515,y:702,t:1527271834609};\\\", \\\"{x:515,y:703,t:1527271834628};\\\", \\\"{x:513,y:705,t:1527271834644};\\\", \\\"{x:513,y:706,t:1527271834661};\\\", \\\"{x:512,y:707,t:1527271834677};\\\", \\\"{x:510,y:710,t:1527271834695};\\\", \\\"{x:510,y:713,t:1527271834711};\\\", \\\"{x:510,y:714,t:1527271834727};\\\", \\\"{x:510,y:716,t:1527271834744};\\\", \\\"{x:517,y:714,t:1527271836257};\\\", \\\"{x:527,y:709,t:1527271836265};\\\", \\\"{x:534,y:703,t:1527271836279};\\\", \\\"{x:552,y:694,t:1527271836296};\\\", \\\"{x:601,y:684,t:1527271836313};\\\", \\\"{x:631,y:680,t:1527271836329};\\\", \\\"{x:670,y:675,t:1527271836345};\\\", \\\"{x:713,y:669,t:1527271836362};\\\", \\\"{x:759,y:667,t:1527271836379};\\\", \\\"{x:812,y:666,t:1527271836395};\\\", \\\"{x:876,y:666,t:1527271836412};\\\", \\\"{x:911,y:666,t:1527271836429};\\\", \\\"{x:952,y:666,t:1527271836445};\\\", \\\"{x:1005,y:666,t:1527271836462};\\\", \\\"{x:1048,y:666,t:1527271836479};\\\", \\\"{x:1100,y:673,t:1527271836495};\\\", \\\"{x:1152,y:677,t:1527271836513};\\\", \\\"{x:1199,y:684,t:1527271836529};\\\", \\\"{x:1230,y:688,t:1527271836546};\\\", \\\"{x:1257,y:694,t:1527271836563};\\\", \\\"{x:1286,y:703,t:1527271836579};\\\", \\\"{x:1308,y:708,t:1527271836595};\\\", \\\"{x:1328,y:711,t:1527271836613};\\\", \\\"{x:1351,y:719,t:1527271836629};\\\", \\\"{x:1361,y:725,t:1527271836645};\\\", \\\"{x:1379,y:727,t:1527271836663};\\\", \\\"{x:1393,y:731,t:1527271836679};\\\", \\\"{x:1396,y:732,t:1527271836695};\\\", \\\"{x:1397,y:733,t:1527271836730};\\\", \\\"{x:1398,y:734,t:1527271836794};\\\", \\\"{x:1401,y:735,t:1527271836800};\\\", \\\"{x:1405,y:738,t:1527271836812};\\\", \\\"{x:1422,y:751,t:1527271836830};\\\", \\\"{x:1437,y:762,t:1527271836845};\\\", \\\"{x:1462,y:775,t:1527271836862};\\\", \\\"{x:1484,y:785,t:1527271836880};\\\", \\\"{x:1516,y:798,t:1527271836896};\\\", \\\"{x:1521,y:801,t:1527271836912};\\\", \\\"{x:1521,y:803,t:1527271836929};\\\", \\\"{x:1521,y:805,t:1527271836994};\\\", \\\"{x:1520,y:806,t:1527271837002};\\\", \\\"{x:1518,y:809,t:1527271837012};\\\", \\\"{x:1513,y:815,t:1527271837029};\\\", \\\"{x:1506,y:822,t:1527271837046};\\\", \\\"{x:1502,y:827,t:1527271837062};\\\", \\\"{x:1498,y:832,t:1527271837079};\\\", \\\"{x:1494,y:834,t:1527271837096};\\\", \\\"{x:1492,y:836,t:1527271837112};\\\", \\\"{x:1491,y:837,t:1527271837137};\\\", \\\"{x:1490,y:837,t:1527271837146};\\\", \\\"{x:1487,y:839,t:1527271837163};\\\", \\\"{x:1486,y:840,t:1527271837180};\\\", \\\"{x:1486,y:841,t:1527271837506};\\\", \\\"{x:1486,y:840,t:1527271837514};\\\", \\\"{x:1486,y:838,t:1527271837530};\\\", \\\"{x:1486,y:835,t:1527271837546};\\\", \\\"{x:1486,y:833,t:1527271837618};\\\", \\\"{x:1486,y:832,t:1527271837650};\\\", \\\"{x:1486,y:831,t:1527271837664};\\\", \\\"{x:1487,y:831,t:1527271837722};\\\", \\\"{x:1487,y:830,t:1527271837738};\\\", \\\"{x:1487,y:829,t:1527271837747};\\\", \\\"{x:1487,y:826,t:1527271837764};\\\", \\\"{x:1489,y:823,t:1527271837781};\\\", \\\"{x:1489,y:819,t:1527271837797};\\\", \\\"{x:1490,y:817,t:1527271837814};\\\", \\\"{x:1491,y:813,t:1527271837831};\\\", \\\"{x:1492,y:810,t:1527271837847};\\\", \\\"{x:1493,y:806,t:1527271837863};\\\", \\\"{x:1495,y:800,t:1527271837881};\\\", \\\"{x:1496,y:794,t:1527271837897};\\\", \\\"{x:1497,y:791,t:1527271837914};\\\", \\\"{x:1497,y:790,t:1527271837931};\\\", \\\"{x:1498,y:785,t:1527271837947};\\\", \\\"{x:1500,y:778,t:1527271837964};\\\", \\\"{x:1502,y:772,t:1527271837981};\\\", \\\"{x:1502,y:769,t:1527271837996};\\\", \\\"{x:1504,y:762,t:1527271838014};\\\", \\\"{x:1504,y:760,t:1527271838031};\\\", \\\"{x:1505,y:755,t:1527271838048};\\\", \\\"{x:1505,y:752,t:1527271838064};\\\", \\\"{x:1505,y:748,t:1527271838081};\\\", \\\"{x:1508,y:742,t:1527271838097};\\\", \\\"{x:1508,y:739,t:1527271838114};\\\", \\\"{x:1509,y:738,t:1527271838137};\\\", \\\"{x:1509,y:735,t:1527271838148};\\\", \\\"{x:1510,y:731,t:1527271838164};\\\", \\\"{x:1510,y:727,t:1527271838181};\\\", \\\"{x:1511,y:723,t:1527271838198};\\\", \\\"{x:1513,y:717,t:1527271838214};\\\", \\\"{x:1514,y:713,t:1527271838231};\\\", \\\"{x:1514,y:708,t:1527271838248};\\\", \\\"{x:1516,y:702,t:1527271838264};\\\", \\\"{x:1516,y:697,t:1527271838281};\\\", \\\"{x:1517,y:686,t:1527271838298};\\\", \\\"{x:1516,y:677,t:1527271838314};\\\", \\\"{x:1516,y:676,t:1527271838330};\\\", \\\"{x:1512,y:669,t:1527271838348};\\\", \\\"{x:1510,y:660,t:1527271838363};\\\", \\\"{x:1508,y:650,t:1527271838381};\\\", \\\"{x:1507,y:636,t:1527271838398};\\\", \\\"{x:1506,y:629,t:1527271838414};\\\", \\\"{x:1505,y:622,t:1527271838431};\\\", \\\"{x:1505,y:617,t:1527271838447};\\\", \\\"{x:1505,y:612,t:1527271838465};\\\", \\\"{x:1505,y:608,t:1527271838481};\\\", \\\"{x:1505,y:601,t:1527271838497};\\\", \\\"{x:1504,y:594,t:1527271838515};\\\", \\\"{x:1503,y:588,t:1527271838531};\\\", \\\"{x:1503,y:584,t:1527271838548};\\\", \\\"{x:1503,y:575,t:1527271838565};\\\", \\\"{x:1502,y:561,t:1527271838580};\\\", \\\"{x:1498,y:550,t:1527271838598};\\\", \\\"{x:1496,y:542,t:1527271838615};\\\", \\\"{x:1492,y:530,t:1527271838630};\\\", \\\"{x:1488,y:521,t:1527271838648};\\\", \\\"{x:1488,y:515,t:1527271838664};\\\", \\\"{x:1488,y:509,t:1527271838681};\\\", \\\"{x:1486,y:499,t:1527271838697};\\\", \\\"{x:1486,y:489,t:1527271838715};\\\", \\\"{x:1486,y:479,t:1527271838731};\\\", \\\"{x:1486,y:463,t:1527271838748};\\\", \\\"{x:1486,y:453,t:1527271838765};\\\", \\\"{x:1486,y:442,t:1527271838781};\\\", \\\"{x:1486,y:428,t:1527271838798};\\\", \\\"{x:1489,y:410,t:1527271838815};\\\", \\\"{x:1488,y:388,t:1527271838831};\\\", \\\"{x:1488,y:371,t:1527271838848};\\\", \\\"{x:1488,y:354,t:1527271838865};\\\", \\\"{x:1482,y:319,t:1527271838882};\\\", \\\"{x:1476,y:302,t:1527271838898};\\\", \\\"{x:1472,y:284,t:1527271838915};\\\", \\\"{x:1470,y:270,t:1527271838932};\\\", \\\"{x:1470,y:255,t:1527271838948};\\\", \\\"{x:1470,y:240,t:1527271838965};\\\", \\\"{x:1466,y:221,t:1527271838982};\\\", \\\"{x:1461,y:203,t:1527271838998};\\\", \\\"{x:1459,y:189,t:1527271839015};\\\", \\\"{x:1457,y:177,t:1527271839032};\\\", \\\"{x:1458,y:173,t:1527271839047};\\\", \\\"{x:1461,y:168,t:1527271839065};\\\", \\\"{x:1461,y:167,t:1527271839242};\\\", \\\"{x:1462,y:167,t:1527271839250};\\\", \\\"{x:1462,y:166,t:1527271839265};\\\", \\\"{x:1463,y:166,t:1527271839280};\\\", \\\"{x:1464,y:166,t:1527271839298};\\\", \\\"{x:1466,y:165,t:1527271839321};\\\", \\\"{x:1466,y:164,t:1527271839344};\\\", \\\"{x:1467,y:163,t:1527271839385};\\\", \\\"{x:1468,y:164,t:1527271840211};\\\", \\\"{x:1468,y:165,t:1527271840241};\\\", \\\"{x:1468,y:166,t:1527271840290};\\\", \\\"{x:1468,y:168,t:1527271840305};\\\", \\\"{x:1467,y:170,t:1527271840321};\\\", \\\"{x:1465,y:173,t:1527271840333};\\\", \\\"{x:1461,y:176,t:1527271840349};\\\", \\\"{x:1452,y:183,t:1527271840366};\\\", \\\"{x:1442,y:191,t:1527271840383};\\\", \\\"{x:1421,y:199,t:1527271840399};\\\", \\\"{x:1400,y:210,t:1527271840416};\\\", \\\"{x:1341,y:233,t:1527271840433};\\\", \\\"{x:1288,y:241,t:1527271840449};\\\", \\\"{x:1160,y:265,t:1527271840466};\\\", \\\"{x:1066,y:279,t:1527271840483};\\\", \\\"{x:957,y:299,t:1527271840499};\\\", \\\"{x:847,y:326,t:1527271840516};\\\", \\\"{x:768,y:349,t:1527271840533};\\\", \\\"{x:743,y:368,t:1527271840549};\\\", \\\"{x:723,y:383,t:1527271840565};\\\", \\\"{x:700,y:409,t:1527271840582};\\\", \\\"{x:679,y:442,t:1527271840600};\\\", \\\"{x:666,y:470,t:1527271840617};\\\", \\\"{x:654,y:505,t:1527271840633};\\\", \\\"{x:626,y:565,t:1527271840651};\\\", \\\"{x:602,y:606,t:1527271840666};\\\", \\\"{x:566,y:659,t:1527271840682};\\\", \\\"{x:503,y:738,t:1527271840715};\\\", \\\"{x:447,y:786,t:1527271840731};\\\", \\\"{x:405,y:816,t:1527271840749};\\\", \\\"{x:372,y:843,t:1527271840766};\\\", \\\"{x:356,y:855,t:1527271840782};\\\", \\\"{x:350,y:862,t:1527271840798};\\\", \\\"{x:344,y:865,t:1527271840816};\\\", \\\"{x:343,y:866,t:1527271840856};\\\", \\\"{x:343,y:864,t:1527271840905};\\\", \\\"{x:347,y:855,t:1527271840915};\\\", \\\"{x:365,y:834,t:1527271840933};\\\", \\\"{x:390,y:808,t:1527271840948};\\\", \\\"{x:420,y:782,t:1527271840965};\\\", \\\"{x:446,y:762,t:1527271840983};\\\", \\\"{x:463,y:749,t:1527271840998};\\\", \\\"{x:478,y:740,t:1527271841016};\\\", \\\"{x:490,y:731,t:1527271841034};\\\", \\\"{x:496,y:727,t:1527271841048};\\\", \\\"{x:500,y:725,t:1527271841066};\\\", \\\"{x:501,y:724,t:1527271841082};\\\", \\\"{x:501,y:723,t:1527271841099};\\\", \\\"{x:502,y:723,t:1527271841201};\\\", \\\"{x:503,y:722,t:1527271842042};\\\", \\\"{x:506,y:721,t:1527271842052};\\\", \\\"{x:528,y:714,t:1527271842069};\\\", \\\"{x:569,y:704,t:1527271842087};\\\", \\\"{x:672,y:684,t:1527271842102};\\\", \\\"{x:782,y:672,t:1527271842117};\\\", \\\"{x:839,y:674,t:1527271842134};\\\", \\\"{x:939,y:678,t:1527271842151};\\\", \\\"{x:992,y:684,t:1527271842168};\\\", \\\"{x:1050,y:691,t:1527271842184};\\\", \\\"{x:1100,y:698,t:1527271842201};\\\", \\\"{x:1105,y:702,t:1527271842217};\\\", \\\"{x:1111,y:702,t:1527271842233};\\\", \\\"{x:1113,y:702,t:1527271842251};\\\", \\\"{x:1115,y:702,t:1527271842267};\\\", \\\"{x:1118,y:701,t:1527271842284};\\\", \\\"{x:1124,y:700,t:1527271842301};\\\", \\\"{x:1130,y:700,t:1527271842316};\\\", \\\"{x:1136,y:700,t:1527271842334};\\\", \\\"{x:1145,y:700,t:1527271842351};\\\", \\\"{x:1151,y:700,t:1527271842367};\\\", \\\"{x:1169,y:704,t:1527271842384};\\\", \\\"{x:1218,y:722,t:1527271842401};\\\", \\\"{x:1257,y:736,t:1527271842416};\\\", \\\"{x:1331,y:762,t:1527271842433};\\\", \\\"{x:1400,y:781,t:1527271842451};\\\", \\\"{x:1454,y:793,t:1527271842467};\\\", \\\"{x:1499,y:811,t:1527271842484};\\\", \\\"{x:1513,y:816,t:1527271842500};\\\", \\\"{x:1515,y:817,t:1527271842516};\\\", \\\"{x:1515,y:818,t:1527271842601};\\\", \\\"{x:1515,y:819,t:1527271842618};\\\", \\\"{x:1512,y:823,t:1527271842634};\\\", \\\"{x:1509,y:825,t:1527271842651};\\\", \\\"{x:1503,y:827,t:1527271842668};\\\", \\\"{x:1494,y:829,t:1527271842683};\\\", \\\"{x:1490,y:829,t:1527271842701};\\\", \\\"{x:1479,y:831,t:1527271842718};\\\", \\\"{x:1476,y:832,t:1527271842734};\\\", \\\"{x:1474,y:833,t:1527271842752};\\\", \\\"{x:1472,y:833,t:1527271842777};\\\", \\\"{x:1470,y:834,t:1527271842794};\\\", \\\"{x:1468,y:835,t:1527271842810};\\\", \\\"{x:1465,y:835,t:1527271842817};\\\", \\\"{x:1457,y:835,t:1527271842834};\\\", \\\"{x:1445,y:833,t:1527271842851};\\\", \\\"{x:1430,y:828,t:1527271842868};\\\", \\\"{x:1420,y:825,t:1527271842884};\\\", \\\"{x:1413,y:823,t:1527271842901};\\\", \\\"{x:1408,y:821,t:1527271842918};\\\", \\\"{x:1408,y:820,t:1527271843210};\\\", \\\"{x:1407,y:818,t:1527271843218};\\\", \\\"{x:1406,y:817,t:1527271843235};\\\", \\\"{x:1405,y:816,t:1527271843425};\\\", \\\"{x:1404,y:815,t:1527271843435};\\\", \\\"{x:1401,y:812,t:1527271843451};\\\", \\\"{x:1398,y:809,t:1527271843469};\\\", \\\"{x:1396,y:807,t:1527271843485};\\\", \\\"{x:1395,y:807,t:1527271843502};\\\", \\\"{x:1395,y:806,t:1527271843518};\\\", \\\"{x:1395,y:805,t:1527271843535};\\\", \\\"{x:1394,y:804,t:1527271843730};\\\", \\\"{x:1393,y:803,t:1527271843737};\\\", \\\"{x:1392,y:802,t:1527271843752};\\\", \\\"{x:1391,y:801,t:1527271843768};\\\", \\\"{x:1391,y:800,t:1527271843785};\\\", \\\"{x:1390,y:799,t:1527271843857};\\\", \\\"{x:1390,y:798,t:1527271843867};\\\", \\\"{x:1388,y:795,t:1527271843884};\\\", \\\"{x:1387,y:793,t:1527271843920};\\\", \\\"{x:1386,y:793,t:1527271843937};\\\", \\\"{x:1385,y:793,t:1527271844554};\\\", \\\"{x:1384,y:793,t:1527271844656};\\\", \\\"{x:1380,y:792,t:1527271844668};\\\", \\\"{x:1378,y:791,t:1527271844685};\\\", \\\"{x:1375,y:790,t:1527271844702};\\\", \\\"{x:1374,y:790,t:1527271845137};\\\", \\\"{x:1378,y:793,t:1527271845153};\\\", \\\"{x:1380,y:796,t:1527271845169};\\\", \\\"{x:1386,y:801,t:1527271845186};\\\", \\\"{x:1395,y:805,t:1527271845203};\\\", \\\"{x:1412,y:816,t:1527271845220};\\\", \\\"{x:1423,y:824,t:1527271845235};\\\", \\\"{x:1443,y:834,t:1527271845253};\\\", \\\"{x:1451,y:841,t:1527271845270};\\\", \\\"{x:1468,y:852,t:1527271845285};\\\", \\\"{x:1478,y:858,t:1527271845302};\\\", \\\"{x:1480,y:860,t:1527271845320};\\\", \\\"{x:1483,y:864,t:1527271845335};\\\", \\\"{x:1484,y:877,t:1527271845352};\\\", \\\"{x:1484,y:889,t:1527271845369};\\\", \\\"{x:1484,y:897,t:1527271845386};\\\", \\\"{x:1484,y:901,t:1527271845403};\\\", \\\"{x:1484,y:908,t:1527271845420};\\\", \\\"{x:1484,y:910,t:1527271845436};\\\", \\\"{x:1483,y:913,t:1527271845453};\\\", \\\"{x:1483,y:915,t:1527271845470};\\\", \\\"{x:1483,y:916,t:1527271845489};\\\", \\\"{x:1482,y:919,t:1527271845506};\\\", \\\"{x:1481,y:921,t:1527271845520};\\\", \\\"{x:1480,y:926,t:1527271845536};\\\", \\\"{x:1480,y:929,t:1527271845553};\\\", \\\"{x:1480,y:930,t:1527271845570};\\\", \\\"{x:1480,y:932,t:1527271845586};\\\", \\\"{x:1479,y:932,t:1527271845604};\\\", \\\"{x:1479,y:933,t:1527271845620};\\\", \\\"{x:1478,y:933,t:1527271845636};\\\", \\\"{x:1477,y:933,t:1527271845653};\\\", \\\"{x:1477,y:935,t:1527271845671};\\\", \\\"{x:1476,y:937,t:1527271845706};\\\", \\\"{x:1476,y:938,t:1527271845754};\\\", \\\"{x:1475,y:938,t:1527271845771};\\\", \\\"{x:1475,y:939,t:1527271845802};\\\", \\\"{x:1474,y:940,t:1527271845850};\\\", \\\"{x:1474,y:941,t:1527271845890};\\\", \\\"{x:1474,y:942,t:1527271845993};\\\", \\\"{x:1474,y:943,t:1527271846146};\\\", \\\"{x:1472,y:943,t:1527271846337};\\\", \\\"{x:1471,y:943,t:1527271846377};\\\", \\\"{x:1469,y:942,t:1527271846387};\\\", \\\"{x:1462,y:935,t:1527271846404};\\\", \\\"{x:1452,y:921,t:1527271846420};\\\", \\\"{x:1437,y:890,t:1527271846436};\\\", \\\"{x:1421,y:869,t:1527271846454};\\\", \\\"{x:1410,y:856,t:1527271846470};\\\", \\\"{x:1407,y:854,t:1527271846487};\\\", \\\"{x:1406,y:850,t:1527271846504};\\\", \\\"{x:1404,y:848,t:1527271846520};\\\", \\\"{x:1404,y:846,t:1527271846545};\\\", \\\"{x:1403,y:844,t:1527271846561};\\\", \\\"{x:1402,y:843,t:1527271846571};\\\", \\\"{x:1399,y:839,t:1527271846587};\\\", \\\"{x:1393,y:834,t:1527271846604};\\\", \\\"{x:1388,y:832,t:1527271846622};\\\", \\\"{x:1385,y:830,t:1527271846638};\\\", \\\"{x:1380,y:825,t:1527271846654};\\\", \\\"{x:1380,y:823,t:1527271846671};\\\", \\\"{x:1379,y:820,t:1527271846687};\\\", \\\"{x:1379,y:818,t:1527271846704};\\\", \\\"{x:1377,y:816,t:1527271846721};\\\", \\\"{x:1377,y:811,t:1527271846738};\\\", \\\"{x:1376,y:808,t:1527271846754};\\\", \\\"{x:1375,y:805,t:1527271846771};\\\", \\\"{x:1375,y:804,t:1527271846787};\\\", \\\"{x:1377,y:801,t:1527271846805};\\\", \\\"{x:1378,y:801,t:1527271846821};\\\", \\\"{x:1380,y:800,t:1527271846837};\\\", \\\"{x:1381,y:800,t:1527271846856};\\\", \\\"{x:1383,y:803,t:1527271846945};\\\", \\\"{x:1386,y:810,t:1527271846954};\\\", \\\"{x:1388,y:820,t:1527271846970};\\\", \\\"{x:1388,y:829,t:1527271846988};\\\", \\\"{x:1388,y:834,t:1527271847003};\\\", \\\"{x:1388,y:839,t:1527271847021};\\\", \\\"{x:1388,y:843,t:1527271847037};\\\", \\\"{x:1388,y:850,t:1527271847054};\\\", \\\"{x:1388,y:860,t:1527271847071};\\\", \\\"{x:1388,y:866,t:1527271847088};\\\", \\\"{x:1388,y:873,t:1527271847104};\\\", \\\"{x:1388,y:882,t:1527271847121};\\\", \\\"{x:1388,y:888,t:1527271847138};\\\", \\\"{x:1388,y:892,t:1527271847153};\\\", \\\"{x:1388,y:893,t:1527271847171};\\\", \\\"{x:1388,y:899,t:1527271847188};\\\", \\\"{x:1388,y:903,t:1527271847204};\\\", \\\"{x:1388,y:907,t:1527271847221};\\\", \\\"{x:1388,y:910,t:1527271847239};\\\", \\\"{x:1388,y:913,t:1527271847255};\\\", \\\"{x:1388,y:915,t:1527271847271};\\\", \\\"{x:1388,y:917,t:1527271847289};\\\", \\\"{x:1388,y:918,t:1527271847306};\\\", \\\"{x:1388,y:920,t:1527271847321};\\\", \\\"{x:1388,y:922,t:1527271847338};\\\", \\\"{x:1390,y:923,t:1527271847354};\\\", \\\"{x:1391,y:924,t:1527271847385};\\\", \\\"{x:1391,y:925,t:1527271847393};\\\", \\\"{x:1392,y:925,t:1527271847408};\\\", \\\"{x:1392,y:926,t:1527271847420};\\\", \\\"{x:1392,y:927,t:1527271847438};\\\", \\\"{x:1392,y:928,t:1527271847455};\\\", \\\"{x:1392,y:929,t:1527271847470};\\\", \\\"{x:1398,y:927,t:1527271847562};\\\", \\\"{x:1404,y:919,t:1527271847571};\\\", \\\"{x:1414,y:905,t:1527271847588};\\\", \\\"{x:1420,y:884,t:1527271847605};\\\", \\\"{x:1421,y:866,t:1527271847621};\\\", \\\"{x:1422,y:851,t:1527271847638};\\\", \\\"{x:1423,y:834,t:1527271847656};\\\", \\\"{x:1423,y:822,t:1527271847671};\\\", \\\"{x:1421,y:809,t:1527271847688};\\\", \\\"{x:1415,y:796,t:1527271847705};\\\", \\\"{x:1407,y:779,t:1527271847721};\\\", \\\"{x:1398,y:764,t:1527271847738};\\\", \\\"{x:1390,y:753,t:1527271847756};\\\", \\\"{x:1388,y:750,t:1527271847772};\\\", \\\"{x:1385,y:742,t:1527271847789};\\\", \\\"{x:1384,y:742,t:1527271847805};\\\", \\\"{x:1384,y:741,t:1527271847822};\\\", \\\"{x:1384,y:740,t:1527271847838};\\\", \\\"{x:1384,y:739,t:1527271847856};\\\", \\\"{x:1383,y:739,t:1527271847898};\\\", \\\"{x:1382,y:741,t:1527271848010};\\\", \\\"{x:1382,y:746,t:1527271848023};\\\", \\\"{x:1381,y:752,t:1527271848039};\\\", \\\"{x:1379,y:758,t:1527271848056};\\\", \\\"{x:1379,y:763,t:1527271848072};\\\", \\\"{x:1379,y:766,t:1527271848089};\\\", \\\"{x:1379,y:770,t:1527271848106};\\\", \\\"{x:1379,y:772,t:1527271848129};\\\", \\\"{x:1379,y:773,t:1527271848139};\\\", \\\"{x:1379,y:775,t:1527271848156};\\\", \\\"{x:1381,y:777,t:1527271848172};\\\", \\\"{x:1381,y:778,t:1527271848188};\\\", \\\"{x:1382,y:779,t:1527271848205};\\\", \\\"{x:1382,y:781,t:1527271848241};\\\", \\\"{x:1382,y:782,t:1527271848265};\\\", \\\"{x:1382,y:784,t:1527271848281};\\\", \\\"{x:1382,y:786,t:1527271848289};\\\", \\\"{x:1383,y:794,t:1527271848305};\\\", \\\"{x:1386,y:807,t:1527271848323};\\\", \\\"{x:1387,y:816,t:1527271848339};\\\", \\\"{x:1388,y:825,t:1527271848355};\\\", \\\"{x:1388,y:828,t:1527271848373};\\\", \\\"{x:1388,y:834,t:1527271848389};\\\", \\\"{x:1388,y:837,t:1527271848405};\\\", \\\"{x:1388,y:839,t:1527271848423};\\\", \\\"{x:1388,y:840,t:1527271848440};\\\", \\\"{x:1388,y:843,t:1527271848455};\\\", \\\"{x:1388,y:844,t:1527271848473};\\\", \\\"{x:1388,y:849,t:1527271848490};\\\", \\\"{x:1388,y:852,t:1527271848513};\\\", \\\"{x:1388,y:853,t:1527271848523};\\\", \\\"{x:1388,y:854,t:1527271848539};\\\", \\\"{x:1387,y:857,t:1527271848555};\\\", \\\"{x:1387,y:859,t:1527271848572};\\\", \\\"{x:1386,y:863,t:1527271848589};\\\", \\\"{x:1386,y:864,t:1527271848605};\\\", \\\"{x:1384,y:869,t:1527271848622};\\\", \\\"{x:1383,y:873,t:1527271848640};\\\", \\\"{x:1382,y:877,t:1527271848656};\\\", \\\"{x:1382,y:880,t:1527271848672};\\\", \\\"{x:1379,y:885,t:1527271848690};\\\", \\\"{x:1379,y:888,t:1527271848705};\\\", \\\"{x:1379,y:891,t:1527271848722};\\\", \\\"{x:1379,y:896,t:1527271848739};\\\", \\\"{x:1379,y:898,t:1527271848756};\\\", \\\"{x:1379,y:903,t:1527271848773};\\\", \\\"{x:1379,y:905,t:1527271848789};\\\", \\\"{x:1379,y:908,t:1527271848807};\\\", \\\"{x:1380,y:910,t:1527271848822};\\\", \\\"{x:1381,y:913,t:1527271848839};\\\", \\\"{x:1381,y:915,t:1527271848857};\\\", \\\"{x:1381,y:917,t:1527271848872};\\\", \\\"{x:1381,y:920,t:1527271848890};\\\", \\\"{x:1382,y:922,t:1527271848906};\\\", \\\"{x:1382,y:923,t:1527271848922};\\\", \\\"{x:1382,y:926,t:1527271848940};\\\", \\\"{x:1382,y:930,t:1527271848957};\\\", \\\"{x:1382,y:932,t:1527271848972};\\\", \\\"{x:1382,y:935,t:1527271848989};\\\", \\\"{x:1383,y:940,t:1527271849006};\\\", \\\"{x:1384,y:943,t:1527271849023};\\\", \\\"{x:1384,y:945,t:1527271849039};\\\", \\\"{x:1384,y:946,t:1527271849056};\\\", \\\"{x:1384,y:947,t:1527271849106};\\\", \\\"{x:1384,y:948,t:1527271849123};\\\", \\\"{x:1384,y:949,t:1527271849140};\\\", \\\"{x:1384,y:950,t:1527271849156};\\\", \\\"{x:1384,y:952,t:1527271849172};\\\", \\\"{x:1384,y:953,t:1527271849190};\\\", \\\"{x:1384,y:955,t:1527271849206};\\\", \\\"{x:1384,y:957,t:1527271849223};\\\", \\\"{x:1384,y:959,t:1527271849240};\\\", \\\"{x:1383,y:961,t:1527271849256};\\\", \\\"{x:1383,y:963,t:1527271849274};\\\", \\\"{x:1383,y:964,t:1527271849289};\\\", \\\"{x:1383,y:965,t:1527271849322};\\\", \\\"{x:1383,y:966,t:1527271849339};\\\", \\\"{x:1383,y:967,t:1527271849369};\\\", \\\"{x:1383,y:968,t:1527271849602};\\\", \\\"{x:1385,y:968,t:1527271849609};\\\", \\\"{x:1387,y:968,t:1527271849624};\\\", \\\"{x:1393,y:968,t:1527271849641};\\\", \\\"{x:1399,y:966,t:1527271849656};\\\", \\\"{x:1412,y:963,t:1527271849673};\\\", \\\"{x:1425,y:959,t:1527271849689};\\\", \\\"{x:1434,y:958,t:1527271849705};\\\", \\\"{x:1439,y:957,t:1527271849723};\\\", \\\"{x:1442,y:955,t:1527271849740};\\\", \\\"{x:1444,y:954,t:1527271849756};\\\", \\\"{x:1447,y:953,t:1527271849773};\\\", \\\"{x:1448,y:953,t:1527271849793};\\\", \\\"{x:1449,y:952,t:1527271849806};\\\", \\\"{x:1449,y:949,t:1527271850001};\\\", \\\"{x:1449,y:948,t:1527271850009};\\\", \\\"{x:1449,y:944,t:1527271850023};\\\", \\\"{x:1449,y:940,t:1527271850041};\\\", \\\"{x:1449,y:939,t:1527271850056};\\\", \\\"{x:1448,y:936,t:1527271850074};\\\", \\\"{x:1448,y:935,t:1527271850090};\\\", \\\"{x:1448,y:934,t:1527271850107};\\\", \\\"{x:1445,y:934,t:1527271850210};\\\", \\\"{x:1444,y:934,t:1527271850225};\\\", \\\"{x:1443,y:934,t:1527271850249};\\\", \\\"{x:1441,y:936,t:1527271850266};\\\", \\\"{x:1441,y:939,t:1527271850282};\\\", \\\"{x:1441,y:944,t:1527271850290};\\\", \\\"{x:1441,y:953,t:1527271850307};\\\", \\\"{x:1441,y:962,t:1527271850323};\\\", \\\"{x:1441,y:968,t:1527271850340};\\\", \\\"{x:1441,y:970,t:1527271850357};\\\", \\\"{x:1441,y:971,t:1527271850374};\\\", \\\"{x:1441,y:973,t:1527271850392};\\\", \\\"{x:1441,y:974,t:1527271850407};\\\", \\\"{x:1439,y:976,t:1527271850423};\\\", \\\"{x:1438,y:977,t:1527271850449};\\\", \\\"{x:1438,y:973,t:1527271850770};\\\", \\\"{x:1439,y:970,t:1527271850777};\\\", \\\"{x:1439,y:968,t:1527271850792};\\\", \\\"{x:1439,y:965,t:1527271850808};\\\", \\\"{x:1441,y:962,t:1527271850825};\\\", \\\"{x:1442,y:961,t:1527271850849};\\\", \\\"{x:1442,y:960,t:1527271850898};\\\", \\\"{x:1441,y:960,t:1527271850922};\\\", \\\"{x:1440,y:959,t:1527271851001};\\\", \\\"{x:1440,y:958,t:1527271851009};\\\", \\\"{x:1440,y:957,t:1527271851040};\\\", \\\"{x:1439,y:957,t:1527271851105};\\\", \\\"{x:1438,y:957,t:1527271851128};\\\", \\\"{x:1437,y:957,t:1527271851161};\\\", \\\"{x:1436,y:957,t:1527271851185};\\\", \\\"{x:1435,y:955,t:1527271851338};\\\", \\\"{x:1435,y:954,t:1527271851345};\\\", \\\"{x:1435,y:952,t:1527271851358};\\\", \\\"{x:1435,y:948,t:1527271851374};\\\", \\\"{x:1435,y:940,t:1527271851392};\\\", \\\"{x:1436,y:934,t:1527271851409};\\\", \\\"{x:1438,y:926,t:1527271851424};\\\", \\\"{x:1441,y:917,t:1527271851442};\\\", \\\"{x:1451,y:901,t:1527271851458};\\\", \\\"{x:1453,y:888,t:1527271851475};\\\", \\\"{x:1459,y:876,t:1527271851491};\\\", \\\"{x:1462,y:860,t:1527271851508};\\\", \\\"{x:1468,y:846,t:1527271851525};\\\", \\\"{x:1473,y:829,t:1527271851541};\\\", \\\"{x:1478,y:814,t:1527271851558};\\\", \\\"{x:1479,y:804,t:1527271851574};\\\", \\\"{x:1482,y:787,t:1527271851591};\\\", \\\"{x:1482,y:769,t:1527271851607};\\\", \\\"{x:1483,y:751,t:1527271851624};\\\", \\\"{x:1483,y:724,t:1527271851640};\\\", \\\"{x:1483,y:705,t:1527271851658};\\\", \\\"{x:1483,y:692,t:1527271851674};\\\", \\\"{x:1484,y:681,t:1527271851691};\\\", \\\"{x:1487,y:674,t:1527271851708};\\\", \\\"{x:1487,y:671,t:1527271851724};\\\", \\\"{x:1487,y:663,t:1527271851741};\\\", \\\"{x:1487,y:659,t:1527271851758};\\\", \\\"{x:1482,y:650,t:1527271851774};\\\", \\\"{x:1478,y:646,t:1527271851791};\\\", \\\"{x:1472,y:638,t:1527271851808};\\\", \\\"{x:1466,y:629,t:1527271851824};\\\", \\\"{x:1460,y:621,t:1527271851842};\\\", \\\"{x:1456,y:618,t:1527271851859};\\\", \\\"{x:1455,y:614,t:1527271851875};\\\", \\\"{x:1452,y:610,t:1527271851892};\\\", \\\"{x:1446,y:604,t:1527271851909};\\\", \\\"{x:1440,y:601,t:1527271851925};\\\", \\\"{x:1437,y:598,t:1527271851942};\\\", \\\"{x:1436,y:597,t:1527271852058};\\\", \\\"{x:1433,y:596,t:1527271852075};\\\", \\\"{x:1431,y:593,t:1527271852091};\\\", \\\"{x:1429,y:590,t:1527271852108};\\\", \\\"{x:1426,y:584,t:1527271852126};\\\", \\\"{x:1423,y:580,t:1527271852142};\\\", \\\"{x:1422,y:575,t:1527271852158};\\\", \\\"{x:1422,y:573,t:1527271852393};\\\", \\\"{x:1422,y:571,t:1527271852409};\\\", \\\"{x:1418,y:563,t:1527271852426};\\\", \\\"{x:1411,y:555,t:1527271852443};\\\", \\\"{x:1404,y:550,t:1527271852459};\\\", \\\"{x:1401,y:549,t:1527271852475};\\\", \\\"{x:1392,y:546,t:1527271852492};\\\", \\\"{x:1373,y:544,t:1527271852508};\\\", \\\"{x:1358,y:541,t:1527271852526};\\\", \\\"{x:1347,y:540,t:1527271852543};\\\", \\\"{x:1341,y:539,t:1527271852559};\\\", \\\"{x:1340,y:539,t:1527271852690};\\\", \\\"{x:1338,y:539,t:1527271852698};\\\", \\\"{x:1337,y:541,t:1527271852710};\\\", \\\"{x:1333,y:551,t:1527271852725};\\\", \\\"{x:1329,y:564,t:1527271852743};\\\", \\\"{x:1327,y:582,t:1527271852759};\\\", \\\"{x:1327,y:596,t:1527271852776};\\\", \\\"{x:1328,y:610,t:1527271852792};\\\", \\\"{x:1335,y:626,t:1527271852809};\\\", \\\"{x:1338,y:634,t:1527271852826};\\\", \\\"{x:1344,y:640,t:1527271852843};\\\", \\\"{x:1346,y:648,t:1527271852859};\\\", \\\"{x:1349,y:662,t:1527271852876};\\\", \\\"{x:1350,y:675,t:1527271852893};\\\", \\\"{x:1352,y:689,t:1527271852910};\\\", \\\"{x:1355,y:705,t:1527271852925};\\\", \\\"{x:1356,y:717,t:1527271852942};\\\", \\\"{x:1356,y:727,t:1527271852960};\\\", \\\"{x:1357,y:731,t:1527271852975};\\\", \\\"{x:1359,y:743,t:1527271852994};\\\", \\\"{x:1359,y:753,t:1527271853009};\\\", \\\"{x:1355,y:767,t:1527271853025};\\\", \\\"{x:1355,y:786,t:1527271853043};\\\", \\\"{x:1354,y:802,t:1527271853059};\\\", \\\"{x:1353,y:817,t:1527271853076};\\\", \\\"{x:1344,y:838,t:1527271853093};\\\", \\\"{x:1335,y:850,t:1527271853109};\\\", \\\"{x:1331,y:857,t:1527271853126};\\\", \\\"{x:1328,y:860,t:1527271853142};\\\", \\\"{x:1325,y:863,t:1527271853160};\\\", \\\"{x:1325,y:866,t:1527271853176};\\\", \\\"{x:1321,y:871,t:1527271853193};\\\", \\\"{x:1320,y:875,t:1527271853209};\\\", \\\"{x:1317,y:880,t:1527271853226};\\\", \\\"{x:1313,y:885,t:1527271853243};\\\", \\\"{x:1312,y:890,t:1527271853260};\\\", \\\"{x:1310,y:891,t:1527271853276};\\\", \\\"{x:1310,y:892,t:1527271853292};\\\", \\\"{x:1309,y:893,t:1527271853310};\\\", \\\"{x:1307,y:894,t:1527271853337};\\\", \\\"{x:1306,y:895,t:1527271853385};\\\", \\\"{x:1305,y:895,t:1527271853393};\\\", \\\"{x:1304,y:893,t:1527271853466};\\\", \\\"{x:1304,y:886,t:1527271853477};\\\", \\\"{x:1303,y:870,t:1527271853492};\\\", \\\"{x:1299,y:857,t:1527271853509};\\\", \\\"{x:1294,y:846,t:1527271853527};\\\", \\\"{x:1288,y:840,t:1527271853542};\\\", \\\"{x:1277,y:832,t:1527271853560};\\\", \\\"{x:1266,y:828,t:1527271853577};\\\", \\\"{x:1253,y:826,t:1527271853594};\\\", \\\"{x:1249,y:824,t:1527271853609};\\\", \\\"{x:1247,y:824,t:1527271853626};\\\", \\\"{x:1245,y:824,t:1527271853643};\\\", \\\"{x:1243,y:825,t:1527271853730};\\\", \\\"{x:1243,y:826,t:1527271853743};\\\", \\\"{x:1243,y:830,t:1527271853760};\\\", \\\"{x:1245,y:836,t:1527271853776};\\\", \\\"{x:1261,y:850,t:1527271853793};\\\", \\\"{x:1273,y:859,t:1527271853810};\\\", \\\"{x:1282,y:869,t:1527271853827};\\\", \\\"{x:1291,y:876,t:1527271853843};\\\", \\\"{x:1295,y:884,t:1527271853859};\\\", \\\"{x:1295,y:888,t:1527271853877};\\\", \\\"{x:1292,y:895,t:1527271853893};\\\", \\\"{x:1279,y:904,t:1527271853910};\\\", \\\"{x:1272,y:906,t:1527271853926};\\\", \\\"{x:1266,y:912,t:1527271853944};\\\", \\\"{x:1213,y:919,t:1527271853960};\\\", \\\"{x:1137,y:923,t:1527271853977};\\\", \\\"{x:996,y:923,t:1527271853993};\\\", \\\"{x:953,y:925,t:1527271854011};\\\", \\\"{x:932,y:926,t:1527271854026};\\\", \\\"{x:910,y:923,t:1527271854043};\\\", \\\"{x:900,y:922,t:1527271854060};\\\", \\\"{x:887,y:922,t:1527271854076};\\\", \\\"{x:873,y:921,t:1527271854093};\\\", \\\"{x:869,y:921,t:1527271854110};\\\", \\\"{x:868,y:921,t:1527271854225};\\\", \\\"{x:868,y:919,t:1527271854243};\\\", \\\"{x:857,y:901,t:1527271854260};\\\", \\\"{x:835,y:880,t:1527271854276};\\\", \\\"{x:805,y:846,t:1527271854293};\\\", \\\"{x:757,y:802,t:1527271854310};\\\", \\\"{x:700,y:767,t:1527271854326};\\\", \\\"{x:672,y:750,t:1527271854343};\\\", \\\"{x:632,y:727,t:1527271854360};\\\", \\\"{x:613,y:715,t:1527271854376};\\\", \\\"{x:612,y:715,t:1527271854393};\\\", \\\"{x:610,y:715,t:1527271854641};\\\", \\\"{x:609,y:715,t:1527271854657};\\\", \\\"{x:607,y:715,t:1527271854666};\\\", \\\"{x:605,y:715,t:1527271854678};\\\", \\\"{x:599,y:715,t:1527271854694};\\\", \\\"{x:596,y:715,t:1527271854710};\\\", \\\"{x:593,y:715,t:1527271854727};\\\", \\\"{x:592,y:715,t:1527271854743};\\\", \\\"{x:589,y:715,t:1527271854793};\\\", \\\"{x:584,y:715,t:1527271854810};\\\", \\\"{x:573,y:718,t:1527271854827};\\\", \\\"{x:554,y:722,t:1527271854843};\\\", \\\"{x:546,y:722,t:1527271854860};\\\", \\\"{x:539,y:723,t:1527271854877};\\\", \\\"{x:535,y:723,t:1527271854894};\\\", \\\"{x:534,y:724,t:1527271854911};\\\", \\\"{x:532,y:724,t:1527271854985};\\\", \\\"{x:536,y:720,t:1527271855889};\\\", \\\"{x:539,y:715,t:1527271855896};\\\", \\\"{x:542,y:710,t:1527271855912};\\\", \\\"{x:545,y:705,t:1527271855929};\\\", \\\"{x:552,y:699,t:1527271855945};\\\", \\\"{x:554,y:697,t:1527271855962};\\\", \\\"{x:555,y:696,t:1527271855979};\\\", \\\"{x:559,y:694,t:1527271855995};\\\" ] }, { \\\"rt\\\": 41009, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 324854, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:559,y:693,t:1527271856976};\\\", \\\"{x:560,y:693,t:1527271856984};\\\", \\\"{x:561,y:693,t:1527271857041};\\\", \\\"{x:562,y:692,t:1527271857049};\\\", \\\"{x:562,y:691,t:1527271857072};\\\", \\\"{x:563,y:691,t:1527271857088};\\\", \\\"{x:563,y:690,t:1527271857097};\\\", \\\"{x:563,y:688,t:1527271857113};\\\", \\\"{x:565,y:684,t:1527271857129};\\\", \\\"{x:566,y:681,t:1527271857145};\\\", \\\"{x:566,y:668,t:1527271857309};\\\", \\\"{x:569,y:664,t:1527271857313};\\\", \\\"{x:569,y:654,t:1527271857328};\\\", \\\"{x:569,y:643,t:1527271857346};\\\", \\\"{x:571,y:634,t:1527271857361};\\\", \\\"{x:575,y:618,t:1527271857379};\\\", \\\"{x:577,y:593,t:1527271857397};\\\", \\\"{x:580,y:563,t:1527271857412};\\\", \\\"{x:586,y:515,t:1527271857429};\\\", \\\"{x:587,y:497,t:1527271857446};\\\", \\\"{x:589,y:449,t:1527271857461};\\\", \\\"{x:585,y:394,t:1527271857479};\\\", \\\"{x:580,y:350,t:1527271857496};\\\", \\\"{x:578,y:343,t:1527271857512};\\\", \\\"{x:567,y:327,t:1527271857529};\\\", \\\"{x:565,y:325,t:1527271857546};\\\", \\\"{x:563,y:325,t:1527271857576};\\\", \\\"{x:558,y:327,t:1527271857585};\\\", \\\"{x:554,y:333,t:1527271857596};\\\", \\\"{x:543,y:345,t:1527271857612};\\\", \\\"{x:531,y:357,t:1527271857629};\\\", \\\"{x:522,y:368,t:1527271857646};\\\", \\\"{x:515,y:381,t:1527271857663};\\\", \\\"{x:507,y:393,t:1527271857679};\\\", \\\"{x:502,y:400,t:1527271857696};\\\", \\\"{x:495,y:409,t:1527271857713};\\\", \\\"{x:494,y:410,t:1527271857729};\\\", \\\"{x:493,y:410,t:1527271857872};\\\", \\\"{x:492,y:410,t:1527271857888};\\\", \\\"{x:491,y:410,t:1527271857896};\\\", \\\"{x:486,y:411,t:1527271857912};\\\", \\\"{x:481,y:414,t:1527271857929};\\\", \\\"{x:479,y:416,t:1527271857946};\\\", \\\"{x:478,y:416,t:1527271857963};\\\", \\\"{x:476,y:418,t:1527271857979};\\\", \\\"{x:474,y:420,t:1527271857996};\\\", \\\"{x:473,y:420,t:1527271858017};\\\", \\\"{x:472,y:422,t:1527271858082};\\\", \\\"{x:471,y:424,t:1527271858097};\\\", \\\"{x:469,y:426,t:1527271858113};\\\", \\\"{x:468,y:426,t:1527271858131};\\\", \\\"{x:468,y:427,t:1527271858147};\\\", \\\"{x:467,y:427,t:1527271858163};\\\", \\\"{x:466,y:427,t:1527271858409};\\\", \\\"{x:465,y:428,t:1527271858418};\\\", \\\"{x:464,y:429,t:1527271858430};\\\", \\\"{x:464,y:430,t:1527271858473};\\\", \\\"{x:464,y:431,t:1527271858601};\\\", \\\"{x:464,y:432,t:1527271858625};\\\", \\\"{x:463,y:434,t:1527271858634};\\\", \\\"{x:463,y:435,t:1527271858650};\\\", \\\"{x:463,y:436,t:1527271858663};\\\", \\\"{x:463,y:437,t:1527271858681};\\\", \\\"{x:463,y:438,t:1527271858754};\\\", \\\"{x:463,y:439,t:1527271858785};\\\", \\\"{x:463,y:440,t:1527271858798};\\\", \\\"{x:464,y:440,t:1527271858890};\\\", \\\"{x:465,y:440,t:1527271858994};\\\", \\\"{x:467,y:440,t:1527271859001};\\\", \\\"{x:470,y:440,t:1527271859014};\\\", \\\"{x:487,y:445,t:1527271859031};\\\", \\\"{x:499,y:448,t:1527271859048};\\\", \\\"{x:518,y:455,t:1527271859065};\\\", \\\"{x:524,y:457,t:1527271859080};\\\", \\\"{x:542,y:463,t:1527271859097};\\\", \\\"{x:544,y:464,t:1527271859115};\\\", \\\"{x:547,y:465,t:1527271859131};\\\", \\\"{x:548,y:465,t:1527271859147};\\\", \\\"{x:548,y:466,t:1527271859177};\\\", \\\"{x:549,y:466,t:1527271859202};\\\", \\\"{x:550,y:467,t:1527271859225};\\\", \\\"{x:552,y:467,t:1527271859241};\\\", \\\"{x:553,y:467,t:1527271859250};\\\", \\\"{x:557,y:469,t:1527271859265};\\\", \\\"{x:562,y:469,t:1527271859281};\\\", \\\"{x:565,y:470,t:1527271859297};\\\", \\\"{x:570,y:470,t:1527271859314};\\\", \\\"{x:576,y:471,t:1527271859330};\\\", \\\"{x:581,y:472,t:1527271859347};\\\", \\\"{x:585,y:473,t:1527271859364};\\\", \\\"{x:587,y:473,t:1527271859381};\\\", \\\"{x:589,y:473,t:1527271859397};\\\", \\\"{x:593,y:473,t:1527271859414};\\\", \\\"{x:598,y:473,t:1527271859432};\\\", \\\"{x:603,y:473,t:1527271859447};\\\", \\\"{x:613,y:473,t:1527271859465};\\\", \\\"{x:617,y:473,t:1527271859481};\\\", \\\"{x:623,y:474,t:1527271859498};\\\", \\\"{x:626,y:474,t:1527271859514};\\\", \\\"{x:627,y:474,t:1527271859625};\\\", \\\"{x:628,y:475,t:1527271859633};\\\", \\\"{x:629,y:475,t:1527271859648};\\\", \\\"{x:634,y:475,t:1527271859665};\\\", \\\"{x:636,y:477,t:1527271859682};\\\", \\\"{x:637,y:477,t:1527271859730};\\\", \\\"{x:637,y:479,t:1527271859792};\\\", \\\"{x:637,y:480,t:1527271859816};\\\", \\\"{x:632,y:483,t:1527271859831};\\\", \\\"{x:626,y:485,t:1527271859848};\\\", \\\"{x:619,y:487,t:1527271859864};\\\", \\\"{x:607,y:488,t:1527271859880};\\\", \\\"{x:596,y:488,t:1527271859898};\\\", \\\"{x:584,y:488,t:1527271859914};\\\", \\\"{x:579,y:488,t:1527271859931};\\\", \\\"{x:575,y:488,t:1527271859948};\\\", \\\"{x:568,y:489,t:1527271859964};\\\", \\\"{x:560,y:490,t:1527271859981};\\\", \\\"{x:546,y:490,t:1527271859999};\\\", \\\"{x:536,y:490,t:1527271860014};\\\", \\\"{x:533,y:491,t:1527271860031};\\\", \\\"{x:528,y:491,t:1527271860048};\\\", \\\"{x:524,y:491,t:1527271860065};\\\", \\\"{x:522,y:491,t:1527271860112};\\\", \\\"{x:521,y:491,t:1527271860121};\\\", \\\"{x:522,y:491,t:1527271860361};\\\", \\\"{x:524,y:492,t:1527271860369};\\\", \\\"{x:525,y:492,t:1527271860385};\\\", \\\"{x:526,y:492,t:1527271860399};\\\", \\\"{x:530,y:491,t:1527271860415};\\\", \\\"{x:534,y:491,t:1527271860431};\\\", \\\"{x:533,y:491,t:1527271860680};\\\", \\\"{x:529,y:491,t:1527271860704};\\\", \\\"{x:526,y:491,t:1527271860715};\\\", \\\"{x:520,y:491,t:1527271860732};\\\", \\\"{x:515,y:491,t:1527271860748};\\\", \\\"{x:506,y:491,t:1527271860765};\\\", \\\"{x:501,y:491,t:1527271860782};\\\", \\\"{x:498,y:491,t:1527271860798};\\\", \\\"{x:497,y:491,t:1527271860832};\\\", \\\"{x:496,y:491,t:1527271860848};\\\", \\\"{x:495,y:491,t:1527271860865};\\\", \\\"{x:494,y:491,t:1527271860882};\\\", \\\"{x:492,y:491,t:1527271860898};\\\", \\\"{x:489,y:491,t:1527271860915};\\\", \\\"{x:484,y:492,t:1527271860932};\\\", \\\"{x:477,y:492,t:1527271860948};\\\", \\\"{x:473,y:493,t:1527271860965};\\\", \\\"{x:470,y:496,t:1527271860982};\\\", \\\"{x:468,y:497,t:1527271860998};\\\", \\\"{x:466,y:499,t:1527271861015};\\\", \\\"{x:465,y:500,t:1527271861032};\\\", \\\"{x:464,y:501,t:1527271861096};\\\", \\\"{x:464,y:502,t:1527271861185};\\\", \\\"{x:465,y:502,t:1527271861289};\\\", \\\"{x:467,y:502,t:1527271861299};\\\", \\\"{x:482,y:506,t:1527271861315};\\\", \\\"{x:496,y:506,t:1527271861332};\\\", \\\"{x:508,y:507,t:1527271861349};\\\", \\\"{x:518,y:507,t:1527271861365};\\\", \\\"{x:523,y:509,t:1527271861382};\\\", \\\"{x:528,y:510,t:1527271861399};\\\", \\\"{x:529,y:510,t:1527271861721};\\\", \\\"{x:530,y:510,t:1527271861745};\\\", \\\"{x:531,y:510,t:1527271861753};\\\", \\\"{x:532,y:510,t:1527271861945};\\\", \\\"{x:533,y:510,t:1527271861953};\\\", \\\"{x:533,y:509,t:1527271861969};\\\", \\\"{x:534,y:509,t:1527271862017};\\\", \\\"{x:535,y:509,t:1527271862033};\\\", \\\"{x:536,y:508,t:1527271862057};\\\", \\\"{x:537,y:507,t:1527271862105};\\\", \\\"{x:537,y:506,t:1527271862273};\\\", \\\"{x:539,y:505,t:1527271862457};\\\", \\\"{x:540,y:505,t:1527271862473};\\\", \\\"{x:541,y:504,t:1527271862484};\\\", \\\"{x:542,y:504,t:1527271862538};\\\", \\\"{x:543,y:503,t:1527271862550};\\\", \\\"{x:545,y:503,t:1527271862568};\\\", \\\"{x:547,y:503,t:1527271862583};\\\", \\\"{x:550,y:503,t:1527271862599};\\\", \\\"{x:551,y:502,t:1527271862624};\\\", \\\"{x:552,y:502,t:1527271862656};\\\", \\\"{x:555,y:502,t:1527271862696};\\\", \\\"{x:558,y:502,t:1527271862736};\\\", \\\"{x:559,y:502,t:1527271862808};\\\", \\\"{x:560,y:502,t:1527271862848};\\\", \\\"{x:561,y:502,t:1527271862856};\\\", \\\"{x:562,y:502,t:1527271862912};\\\", \\\"{x:563,y:502,t:1527271862952};\\\", \\\"{x:564,y:501,t:1527271876917};\\\", \\\"{x:573,y:501,t:1527271876931};\\\", \\\"{x:574,y:501,t:1527271876949};\\\", \\\"{x:580,y:505,t:1527271876965};\\\", \\\"{x:597,y:515,t:1527271876981};\\\", \\\"{x:655,y:528,t:1527271876999};\\\", \\\"{x:736,y:554,t:1527271877016};\\\", \\\"{x:804,y:581,t:1527271877031};\\\", \\\"{x:834,y:595,t:1527271877046};\\\", \\\"{x:847,y:598,t:1527271877063};\\\", \\\"{x:876,y:608,t:1527271877082};\\\", \\\"{x:897,y:615,t:1527271877097};\\\", \\\"{x:937,y:625,t:1527271877115};\\\", \\\"{x:954,y:634,t:1527271877131};\\\", \\\"{x:984,y:643,t:1527271877148};\\\", \\\"{x:1009,y:648,t:1527271877165};\\\", \\\"{x:1037,y:658,t:1527271877183};\\\", \\\"{x:1095,y:672,t:1527271877198};\\\", \\\"{x:1168,y:694,t:1527271877215};\\\", \\\"{x:1230,y:714,t:1527271877232};\\\", \\\"{x:1302,y:736,t:1527271877248};\\\", \\\"{x:1361,y:753,t:1527271877265};\\\", \\\"{x:1403,y:766,t:1527271877282};\\\", \\\"{x:1432,y:776,t:1527271877298};\\\", \\\"{x:1456,y:779,t:1527271877315};\\\", \\\"{x:1459,y:780,t:1527271877332};\\\", \\\"{x:1460,y:780,t:1527271877348};\\\", \\\"{x:1462,y:780,t:1527271877365};\\\", \\\"{x:1464,y:780,t:1527271877388};\\\", \\\"{x:1465,y:781,t:1527271877756};\\\", \\\"{x:1463,y:771,t:1527271880773};\\\", \\\"{x:1455,y:753,t:1527271880785};\\\", \\\"{x:1428,y:697,t:1527271880802};\\\", \\\"{x:1409,y:665,t:1527271880819};\\\", \\\"{x:1387,y:629,t:1527271880835};\\\", \\\"{x:1370,y:594,t:1527271880852};\\\", \\\"{x:1358,y:570,t:1527271880868};\\\", \\\"{x:1357,y:563,t:1527271880885};\\\", \\\"{x:1357,y:551,t:1527271880902};\\\", \\\"{x:1355,y:536,t:1527271880918};\\\", \\\"{x:1355,y:520,t:1527271880934};\\\", \\\"{x:1355,y:505,t:1527271880951};\\\", \\\"{x:1355,y:494,t:1527271880968};\\\", \\\"{x:1355,y:483,t:1527271880985};\\\", \\\"{x:1355,y:472,t:1527271881001};\\\", \\\"{x:1355,y:462,t:1527271881018};\\\", \\\"{x:1355,y:459,t:1527271881036};\\\", \\\"{x:1355,y:458,t:1527271881053};\\\", \\\"{x:1355,y:456,t:1527271881069};\\\", \\\"{x:1352,y:456,t:1527271881092};\\\", \\\"{x:1351,y:456,t:1527271881140};\\\", \\\"{x:1347,y:459,t:1527271881152};\\\", \\\"{x:1340,y:465,t:1527271881168};\\\", \\\"{x:1333,y:468,t:1527271881186};\\\", \\\"{x:1326,y:475,t:1527271881201};\\\", \\\"{x:1322,y:478,t:1527271881219};\\\", \\\"{x:1317,y:483,t:1527271881236};\\\", \\\"{x:1316,y:483,t:1527271881253};\\\", \\\"{x:1315,y:484,t:1527271881269};\\\", \\\"{x:1314,y:485,t:1527271881286};\\\", \\\"{x:1313,y:488,t:1527271881302};\\\", \\\"{x:1312,y:489,t:1527271881319};\\\", \\\"{x:1311,y:491,t:1527271881336};\\\", \\\"{x:1310,y:493,t:1527271881354};\\\", \\\"{x:1310,y:495,t:1527271881368};\\\", \\\"{x:1310,y:497,t:1527271881385};\\\", \\\"{x:1310,y:500,t:1527271881401};\\\", \\\"{x:1309,y:501,t:1527271881419};\\\", \\\"{x:1308,y:504,t:1527271881435};\\\", \\\"{x:1307,y:505,t:1527271881452};\\\", \\\"{x:1307,y:506,t:1527271881476};\\\", \\\"{x:1307,y:507,t:1527271881486};\\\", \\\"{x:1305,y:510,t:1527271881502};\\\", \\\"{x:1304,y:511,t:1527271881524};\\\", \\\"{x:1304,y:514,t:1527271881535};\\\", \\\"{x:1304,y:516,t:1527271881552};\\\", \\\"{x:1302,y:522,t:1527271881568};\\\", \\\"{x:1301,y:523,t:1527271881586};\\\", \\\"{x:1301,y:525,t:1527271881603};\\\", \\\"{x:1301,y:528,t:1527271881619};\\\", \\\"{x:1301,y:531,t:1527271881636};\\\", \\\"{x:1301,y:534,t:1527271881654};\\\", \\\"{x:1301,y:535,t:1527271881669};\\\", \\\"{x:1302,y:537,t:1527271881686};\\\", \\\"{x:1303,y:539,t:1527271881702};\\\", \\\"{x:1309,y:547,t:1527271881719};\\\", \\\"{x:1313,y:552,t:1527271881736};\\\", \\\"{x:1320,y:559,t:1527271881753};\\\", \\\"{x:1326,y:563,t:1527271881770};\\\", \\\"{x:1329,y:567,t:1527271881786};\\\", \\\"{x:1330,y:569,t:1527271881803};\\\", \\\"{x:1334,y:570,t:1527271881819};\\\", \\\"{x:1334,y:571,t:1527271881861};\\\", \\\"{x:1334,y:572,t:1527271881876};\\\", \\\"{x:1334,y:573,t:1527271881892};\\\", \\\"{x:1334,y:574,t:1527271881903};\\\", \\\"{x:1334,y:575,t:1527271881924};\\\", \\\"{x:1334,y:576,t:1527271881936};\\\", \\\"{x:1335,y:577,t:1527271881956};\\\", \\\"{x:1335,y:578,t:1527271881980};\\\", \\\"{x:1337,y:580,t:1527271881996};\\\", \\\"{x:1339,y:581,t:1527271882004};\\\", \\\"{x:1341,y:582,t:1527271882020};\\\", \\\"{x:1344,y:585,t:1527271882036};\\\", \\\"{x:1344,y:586,t:1527271882084};\\\", \\\"{x:1345,y:586,t:1527271882108};\\\", \\\"{x:1345,y:587,t:1527271882120};\\\", \\\"{x:1346,y:588,t:1527271882136};\\\", \\\"{x:1347,y:588,t:1527271882156};\\\", \\\"{x:1348,y:588,t:1527271882170};\\\", \\\"{x:1348,y:589,t:1527271882253};\\\", \\\"{x:1349,y:589,t:1527271882300};\\\", \\\"{x:1349,y:592,t:1527271882556};\\\", \\\"{x:1349,y:595,t:1527271882580};\\\", \\\"{x:1349,y:597,t:1527271882612};\\\", \\\"{x:1349,y:598,t:1527271882654};\\\", \\\"{x:1349,y:600,t:1527271882670};\\\", \\\"{x:1351,y:601,t:1527271882692};\\\", \\\"{x:1352,y:602,t:1527271882708};\\\", \\\"{x:1352,y:603,t:1527271882720};\\\", \\\"{x:1352,y:602,t:1527271883132};\\\", \\\"{x:1352,y:601,t:1527271883156};\\\", \\\"{x:1352,y:600,t:1527271883170};\\\", \\\"{x:1354,y:598,t:1527271883187};\\\", \\\"{x:1358,y:595,t:1527271883204};\\\", \\\"{x:1362,y:590,t:1527271883220};\\\", \\\"{x:1364,y:587,t:1527271883237};\\\", \\\"{x:1365,y:586,t:1527271883254};\\\", \\\"{x:1365,y:584,t:1527271883292};\\\", \\\"{x:1365,y:583,t:1527271883304};\\\", \\\"{x:1365,y:582,t:1527271883324};\\\", \\\"{x:1364,y:580,t:1527271883340};\\\", \\\"{x:1363,y:580,t:1527271883354};\\\", \\\"{x:1361,y:578,t:1527271883371};\\\", \\\"{x:1359,y:575,t:1527271883387};\\\", \\\"{x:1350,y:569,t:1527271883404};\\\", \\\"{x:1345,y:567,t:1527271883420};\\\", \\\"{x:1342,y:564,t:1527271883437};\\\", \\\"{x:1338,y:563,t:1527271883454};\\\", \\\"{x:1336,y:562,t:1527271883471};\\\", \\\"{x:1335,y:561,t:1527271883487};\\\", \\\"{x:1333,y:561,t:1527271883504};\\\", \\\"{x:1332,y:560,t:1527271883521};\\\", \\\"{x:1331,y:560,t:1527271883537};\\\", \\\"{x:1327,y:558,t:1527271883554};\\\", \\\"{x:1326,y:558,t:1527271883571};\\\", \\\"{x:1325,y:558,t:1527271883588};\\\", \\\"{x:1325,y:557,t:1527271883756};\\\", \\\"{x:1326,y:557,t:1527271883805};\\\", \\\"{x:1327,y:557,t:1527271883860};\\\", \\\"{x:1328,y:556,t:1527271883871};\\\", \\\"{x:1329,y:556,t:1527271883892};\\\", \\\"{x:1330,y:555,t:1527271883908};\\\", \\\"{x:1332,y:555,t:1527271883957};\\\", \\\"{x:1335,y:555,t:1527271883972};\\\", \\\"{x:1340,y:558,t:1527271883988};\\\", \\\"{x:1347,y:559,t:1527271884004};\\\", \\\"{x:1356,y:562,t:1527271884021};\\\", \\\"{x:1363,y:565,t:1527271884038};\\\", \\\"{x:1370,y:567,t:1527271884055};\\\", \\\"{x:1373,y:569,t:1527271884071};\\\", \\\"{x:1373,y:570,t:1527271884221};\\\", \\\"{x:1373,y:571,t:1527271884301};\\\", \\\"{x:1373,y:572,t:1527271884379};\\\", \\\"{x:1373,y:573,t:1527271884516};\\\", \\\"{x:1372,y:573,t:1527271884532};\\\", \\\"{x:1370,y:573,t:1527271884540};\\\", \\\"{x:1369,y:573,t:1527271884555};\\\", \\\"{x:1367,y:573,t:1527271884572};\\\", \\\"{x:1366,y:573,t:1527271884587};\\\", \\\"{x:1365,y:572,t:1527271884796};\\\", \\\"{x:1364,y:571,t:1527271884805};\\\", \\\"{x:1362,y:570,t:1527271884822};\\\", \\\"{x:1362,y:569,t:1527271884844};\\\", \\\"{x:1360,y:569,t:1527271884855};\\\", \\\"{x:1358,y:568,t:1527271884872};\\\", \\\"{x:1356,y:567,t:1527271884888};\\\", \\\"{x:1355,y:567,t:1527271884905};\\\", \\\"{x:1354,y:566,t:1527271884922};\\\", \\\"{x:1353,y:566,t:1527271885325};\\\", \\\"{x:1352,y:566,t:1527271885404};\\\", \\\"{x:1350,y:566,t:1527271885428};\\\", \\\"{x:1349,y:566,t:1527271885444};\\\", \\\"{x:1348,y:566,t:1527271885459};\\\", \\\"{x:1344,y:566,t:1527271885475};\\\", \\\"{x:1343,y:566,t:1527271885488};\\\", \\\"{x:1338,y:566,t:1527271885506};\\\", \\\"{x:1335,y:565,t:1527271885521};\\\", \\\"{x:1331,y:564,t:1527271885539};\\\", \\\"{x:1329,y:563,t:1527271885555};\\\", \\\"{x:1328,y:563,t:1527271885700};\\\", \\\"{x:1325,y:563,t:1527271886932};\\\", \\\"{x:1324,y:562,t:1527271886940};\\\", \\\"{x:1305,y:556,t:1527271886957};\\\", \\\"{x:1288,y:552,t:1527271886973};\\\", \\\"{x:1272,y:547,t:1527271886990};\\\", \\\"{x:1252,y:542,t:1527271887007};\\\", \\\"{x:1237,y:535,t:1527271887023};\\\", \\\"{x:1227,y:531,t:1527271887040};\\\", \\\"{x:1215,y:530,t:1527271887057};\\\", \\\"{x:1203,y:527,t:1527271887073};\\\", \\\"{x:1184,y:527,t:1527271887090};\\\", \\\"{x:1162,y:527,t:1527271887108};\\\", \\\"{x:1100,y:527,t:1527271887123};\\\", \\\"{x:852,y:572,t:1527271887141};\\\", \\\"{x:776,y:595,t:1527271887157};\\\", \\\"{x:760,y:605,t:1527271887174};\\\", \\\"{x:757,y:605,t:1527271887190};\\\", \\\"{x:750,y:605,t:1527271887206};\\\", \\\"{x:707,y:614,t:1527271887224};\\\", \\\"{x:660,y:621,t:1527271887240};\\\", \\\"{x:604,y:626,t:1527271887257};\\\", \\\"{x:568,y:626,t:1527271887273};\\\", \\\"{x:545,y:627,t:1527271887291};\\\", \\\"{x:532,y:628,t:1527271887306};\\\", \\\"{x:528,y:628,t:1527271887324};\\\", \\\"{x:527,y:628,t:1527271887340};\\\", \\\"{x:528,y:628,t:1527271887428};\\\", \\\"{x:529,y:628,t:1527271887440};\\\", \\\"{x:530,y:627,t:1527271887459};\\\", \\\"{x:530,y:626,t:1527271887474};\\\", \\\"{x:531,y:625,t:1527271887491};\\\", \\\"{x:532,y:623,t:1527271887507};\\\", \\\"{x:533,y:621,t:1527271887523};\\\", \\\"{x:533,y:620,t:1527271887612};\\\", \\\"{x:534,y:620,t:1527271891404};\\\", \\\"{x:537,y:620,t:1527271891412};\\\", \\\"{x:540,y:620,t:1527271891427};\\\", \\\"{x:545,y:618,t:1527271891443};\\\", \\\"{x:578,y:586,t:1527271891462};\\\", \\\"{x:623,y:524,t:1527271891477};\\\", \\\"{x:671,y:478,t:1527271891494};\\\", \\\"{x:702,y:450,t:1527271891510};\\\", \\\"{x:714,y:444,t:1527271891527};\\\", \\\"{x:726,y:438,t:1527271891543};\\\", \\\"{x:742,y:431,t:1527271891559};\\\", \\\"{x:764,y:428,t:1527271891576};\\\", \\\"{x:794,y:423,t:1527271891594};\\\", \\\"{x:825,y:423,t:1527271891609};\\\", \\\"{x:881,y:422,t:1527271891626};\\\", \\\"{x:993,y:423,t:1527271891643};\\\", \\\"{x:1083,y:426,t:1527271891660};\\\", \\\"{x:1167,y:443,t:1527271891677};\\\", \\\"{x:1218,y:459,t:1527271891694};\\\", \\\"{x:1262,y:467,t:1527271891711};\\\", \\\"{x:1314,y:485,t:1527271891727};\\\", \\\"{x:1352,y:504,t:1527271891744};\\\", \\\"{x:1371,y:515,t:1527271891761};\\\", \\\"{x:1382,y:521,t:1527271891777};\\\", \\\"{x:1384,y:522,t:1527271891794};\\\", \\\"{x:1384,y:523,t:1527271891900};\\\", \\\"{x:1381,y:523,t:1527271891911};\\\", \\\"{x:1368,y:520,t:1527271891927};\\\", \\\"{x:1348,y:516,t:1527271891945};\\\", \\\"{x:1338,y:513,t:1527271891962};\\\", \\\"{x:1331,y:511,t:1527271891977};\\\", \\\"{x:1329,y:511,t:1527271891994};\\\", \\\"{x:1326,y:512,t:1527271892077};\\\", \\\"{x:1323,y:514,t:1527271892095};\\\", \\\"{x:1323,y:516,t:1527271892112};\\\", \\\"{x:1322,y:519,t:1527271892127};\\\", \\\"{x:1321,y:520,t:1527271892145};\\\", \\\"{x:1320,y:520,t:1527271892162};\\\", \\\"{x:1320,y:523,t:1527271892178};\\\", \\\"{x:1316,y:528,t:1527271892195};\\\", \\\"{x:1314,y:534,t:1527271892211};\\\", \\\"{x:1311,y:539,t:1527271892228};\\\", \\\"{x:1311,y:543,t:1527271892244};\\\", \\\"{x:1310,y:550,t:1527271892262};\\\", \\\"{x:1309,y:556,t:1527271892279};\\\", \\\"{x:1306,y:566,t:1527271892295};\\\", \\\"{x:1304,y:576,t:1527271892312};\\\", \\\"{x:1304,y:584,t:1527271892328};\\\", \\\"{x:1306,y:593,t:1527271892344};\\\", \\\"{x:1308,y:599,t:1527271892361};\\\", \\\"{x:1310,y:605,t:1527271892378};\\\", \\\"{x:1310,y:608,t:1527271892394};\\\", \\\"{x:1312,y:612,t:1527271892411};\\\", \\\"{x:1312,y:615,t:1527271892428};\\\", \\\"{x:1312,y:617,t:1527271892444};\\\", \\\"{x:1312,y:619,t:1527271892461};\\\", \\\"{x:1312,y:620,t:1527271892478};\\\", \\\"{x:1312,y:622,t:1527271892494};\\\", \\\"{x:1312,y:625,t:1527271892512};\\\", \\\"{x:1311,y:627,t:1527271892528};\\\", \\\"{x:1311,y:628,t:1527271892544};\\\", \\\"{x:1311,y:629,t:1527271892561};\\\", \\\"{x:1311,y:630,t:1527271892588};\\\", \\\"{x:1311,y:631,t:1527271892612};\\\", \\\"{x:1309,y:632,t:1527271892644};\\\", \\\"{x:1309,y:633,t:1527271892669};\\\", \\\"{x:1309,y:634,t:1527271892678};\\\", \\\"{x:1309,y:638,t:1527271892700};\\\", \\\"{x:1309,y:639,t:1527271892788};\\\", \\\"{x:1309,y:640,t:1527271892796};\\\", \\\"{x:1309,y:641,t:1527271892811};\\\", \\\"{x:1309,y:644,t:1527271892829};\\\", \\\"{x:1309,y:645,t:1527271892845};\\\", \\\"{x:1308,y:648,t:1527271892861};\\\", \\\"{x:1308,y:650,t:1527271892878};\\\", \\\"{x:1308,y:655,t:1527271892896};\\\", \\\"{x:1305,y:664,t:1527271892911};\\\", \\\"{x:1303,y:679,t:1527271892928};\\\", \\\"{x:1299,y:689,t:1527271892946};\\\", \\\"{x:1295,y:695,t:1527271892961};\\\", \\\"{x:1292,y:698,t:1527271892979};\\\", \\\"{x:1291,y:699,t:1527271893092};\\\", \\\"{x:1291,y:702,t:1527271893100};\\\", \\\"{x:1291,y:705,t:1527271893112};\\\", \\\"{x:1286,y:713,t:1527271893128};\\\", \\\"{x:1284,y:721,t:1527271893146};\\\", \\\"{x:1282,y:729,t:1527271893163};\\\", \\\"{x:1278,y:738,t:1527271893178};\\\", \\\"{x:1277,y:744,t:1527271893195};\\\", \\\"{x:1275,y:750,t:1527271893211};\\\", \\\"{x:1274,y:754,t:1527271893228};\\\", \\\"{x:1273,y:758,t:1527271893245};\\\", \\\"{x:1271,y:763,t:1527271893262};\\\", \\\"{x:1270,y:769,t:1527271893279};\\\", \\\"{x:1270,y:773,t:1527271893295};\\\", \\\"{x:1267,y:778,t:1527271893312};\\\", \\\"{x:1267,y:785,t:1527271893329};\\\", \\\"{x:1277,y:794,t:1527271893345};\\\", \\\"{x:1287,y:808,t:1527271893363};\\\", \\\"{x:1300,y:820,t:1527271893378};\\\", \\\"{x:1307,y:830,t:1527271893395};\\\", \\\"{x:1309,y:852,t:1527271893412};\\\", \\\"{x:1309,y:859,t:1527271893429};\\\", \\\"{x:1309,y:860,t:1527271893445};\\\", \\\"{x:1310,y:864,t:1527271893462};\\\", \\\"{x:1310,y:865,t:1527271893628};\\\", \\\"{x:1310,y:866,t:1527271894292};\\\", \\\"{x:1303,y:861,t:1527271894300};\\\", \\\"{x:1291,y:850,t:1527271894313};\\\", \\\"{x:1261,y:837,t:1527271894329};\\\", \\\"{x:1192,y:808,t:1527271894346};\\\", \\\"{x:1050,y:760,t:1527271894363};\\\", \\\"{x:946,y:738,t:1527271894379};\\\", \\\"{x:859,y:723,t:1527271894396};\\\", \\\"{x:764,y:709,t:1527271894413};\\\", \\\"{x:705,y:698,t:1527271894428};\\\", \\\"{x:659,y:693,t:1527271894446};\\\", \\\"{x:636,y:690,t:1527271894462};\\\", \\\"{x:626,y:690,t:1527271894478};\\\", \\\"{x:623,y:690,t:1527271894496};\\\", \\\"{x:622,y:690,t:1527271894515};\\\", \\\"{x:621,y:690,t:1527271894572};\\\", \\\"{x:619,y:689,t:1527271894588};\\\", \\\"{x:611,y:686,t:1527271894596};\\\", \\\"{x:594,y:679,t:1527271894613};\\\", \\\"{x:571,y:669,t:1527271894629};\\\", \\\"{x:554,y:659,t:1527271894647};\\\", \\\"{x:539,y:649,t:1527271894663};\\\", \\\"{x:527,y:640,t:1527271894679};\\\", \\\"{x:519,y:630,t:1527271894696};\\\", \\\"{x:515,y:626,t:1527271894713};\\\", \\\"{x:513,y:623,t:1527271894730};\\\", \\\"{x:511,y:620,t:1527271894746};\\\", \\\"{x:511,y:613,t:1527271894762};\\\", \\\"{x:511,y:611,t:1527271894780};\\\", \\\"{x:514,y:605,t:1527271894796};\\\", \\\"{x:520,y:599,t:1527271894812};\\\", \\\"{x:526,y:594,t:1527271894830};\\\", \\\"{x:532,y:593,t:1527271894846};\\\", \\\"{x:540,y:589,t:1527271894863};\\\", \\\"{x:556,y:584,t:1527271894880};\\\", \\\"{x:568,y:579,t:1527271894897};\\\", \\\"{x:584,y:575,t:1527271894913};\\\", \\\"{x:607,y:571,t:1527271894931};\\\", \\\"{x:629,y:568,t:1527271894946};\\\", \\\"{x:641,y:564,t:1527271894963};\\\", \\\"{x:646,y:562,t:1527271894980};\\\", \\\"{x:648,y:560,t:1527271894995};\\\", \\\"{x:650,y:559,t:1527271895013};\\\", \\\"{x:653,y:557,t:1527271895031};\\\", \\\"{x:658,y:555,t:1527271895047};\\\", \\\"{x:665,y:552,t:1527271895063};\\\", \\\"{x:671,y:548,t:1527271895081};\\\", \\\"{x:686,y:541,t:1527271895097};\\\", \\\"{x:687,y:540,t:1527271895113};\\\", \\\"{x:687,y:539,t:1527271895130};\\\", \\\"{x:686,y:538,t:1527271895267};\\\", \\\"{x:687,y:537,t:1527271895388};\\\", \\\"{x:688,y:537,t:1527271895397};\\\", \\\"{x:692,y:535,t:1527271895415};\\\", \\\"{x:697,y:533,t:1527271895430};\\\", \\\"{x:705,y:527,t:1527271895447};\\\", \\\"{x:710,y:523,t:1527271895464};\\\", \\\"{x:720,y:520,t:1527271895480};\\\", \\\"{x:729,y:519,t:1527271895499};\\\", \\\"{x:739,y:515,t:1527271895513};\\\", \\\"{x:749,y:513,t:1527271895530};\\\", \\\"{x:760,y:510,t:1527271895545};\\\", \\\"{x:773,y:509,t:1527271895562};\\\", \\\"{x:781,y:508,t:1527271895579};\\\", \\\"{x:791,y:508,t:1527271895595};\\\", \\\"{x:805,y:511,t:1527271895613};\\\", \\\"{x:813,y:515,t:1527271895630};\\\", \\\"{x:821,y:520,t:1527271895646};\\\", \\\"{x:823,y:521,t:1527271895662};\\\", \\\"{x:824,y:524,t:1527271895764};\\\", \\\"{x:824,y:525,t:1527271895788};\\\", \\\"{x:825,y:525,t:1527271895798};\\\", \\\"{x:826,y:525,t:1527271895931};\\\", \\\"{x:826,y:526,t:1527271896013};\\\", \\\"{x:826,y:527,t:1527271896028};\\\", \\\"{x:828,y:529,t:1527271896035};\\\", \\\"{x:828,y:530,t:1527271896048};\\\", \\\"{x:828,y:531,t:1527271896100};\\\", \\\"{x:828,y:532,t:1527271896114};\\\", \\\"{x:828,y:533,t:1527271897043};\\\", \\\"{x:826,y:536,t:1527271897059};\\\", \\\"{x:822,y:539,t:1527271897068};\\\", \\\"{x:817,y:543,t:1527271897081};\\\", \\\"{x:799,y:554,t:1527271897099};\\\", \\\"{x:773,y:572,t:1527271897115};\\\", \\\"{x:749,y:586,t:1527271897131};\\\", \\\"{x:702,y:606,t:1527271897148};\\\", \\\"{x:676,y:618,t:1527271897165};\\\", \\\"{x:628,y:640,t:1527271897181};\\\", \\\"{x:586,y:660,t:1527271897198};\\\", \\\"{x:562,y:676,t:1527271897216};\\\", \\\"{x:545,y:692,t:1527271897232};\\\", \\\"{x:532,y:705,t:1527271897248};\\\", \\\"{x:523,y:715,t:1527271897265};\\\", \\\"{x:518,y:723,t:1527271897282};\\\", \\\"{x:515,y:725,t:1527271897298};\\\", \\\"{x:515,y:726,t:1527271897315};\\\", \\\"{x:515,y:727,t:1527271897491};\\\", \\\"{x:514,y:727,t:1527271897514};\\\", \\\"{x:514,y:728,t:1527271898802};\\\" ] }, { \\\"rt\\\": 13507, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 339670, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:729,t:1527271899026};\\\", \\\"{x:512,y:730,t:1527271900172};\\\", \\\"{x:511,y:731,t:1527271900203};\\\", \\\"{x:510,y:731,t:1527271902003};\\\", \\\"{x:512,y:730,t:1527271903131};\\\", \\\"{x:514,y:729,t:1527271903139};\\\", \\\"{x:518,y:725,t:1527271903153};\\\", \\\"{x:532,y:711,t:1527271903169};\\\", \\\"{x:544,y:699,t:1527271903186};\\\", \\\"{x:575,y:665,t:1527271903203};\\\", \\\"{x:601,y:647,t:1527271903218};\\\", \\\"{x:675,y:601,t:1527271903234};\\\", \\\"{x:831,y:531,t:1527271903252};\\\", \\\"{x:939,y:484,t:1527271903269};\\\", \\\"{x:1041,y:441,t:1527271903287};\\\", \\\"{x:1121,y:412,t:1527271903303};\\\", \\\"{x:1142,y:392,t:1527271903320};\\\", \\\"{x:1147,y:380,t:1527271903336};\\\", \\\"{x:1148,y:376,t:1527271903353};\\\", \\\"{x:1147,y:374,t:1527271903369};\\\", \\\"{x:1145,y:374,t:1527271903386};\\\", \\\"{x:1142,y:374,t:1527271903403};\\\", \\\"{x:1142,y:378,t:1527271903493};\\\", \\\"{x:1142,y:381,t:1527271903503};\\\", \\\"{x:1142,y:394,t:1527271903521};\\\", \\\"{x:1142,y:409,t:1527271903536};\\\", \\\"{x:1144,y:423,t:1527271903553};\\\", \\\"{x:1144,y:433,t:1527271903571};\\\", \\\"{x:1141,y:455,t:1527271903586};\\\", \\\"{x:1131,y:484,t:1527271903603};\\\", \\\"{x:1125,y:495,t:1527271903620};\\\", \\\"{x:1121,y:501,t:1527271903638};\\\", \\\"{x:1118,y:504,t:1527271903653};\\\", \\\"{x:1117,y:505,t:1527271903670};\\\", \\\"{x:1116,y:506,t:1527271903687};\\\", \\\"{x:1114,y:508,t:1527271903704};\\\", \\\"{x:1108,y:509,t:1527271903721};\\\", \\\"{x:1099,y:516,t:1527271903737};\\\", \\\"{x:1094,y:518,t:1527271903754};\\\", \\\"{x:1084,y:523,t:1527271903770};\\\", \\\"{x:1075,y:529,t:1527271903787};\\\", \\\"{x:1074,y:531,t:1527271903803};\\\", \\\"{x:1074,y:533,t:1527271903821};\\\", \\\"{x:1071,y:536,t:1527271903838};\\\", \\\"{x:1069,y:539,t:1527271903854};\\\", \\\"{x:1068,y:540,t:1527271903871};\\\", \\\"{x:1068,y:542,t:1527271903888};\\\", \\\"{x:1067,y:544,t:1527271903903};\\\", \\\"{x:1065,y:548,t:1527271903921};\\\", \\\"{x:1063,y:552,t:1527271903937};\\\", \\\"{x:1063,y:555,t:1527271903955};\\\", \\\"{x:1061,y:556,t:1527271903971};\\\", \\\"{x:1061,y:558,t:1527271904101};\\\", \\\"{x:1061,y:559,t:1527271904116};\\\", \\\"{x:1067,y:559,t:1527271904125};\\\", \\\"{x:1072,y:558,t:1527271904138};\\\", \\\"{x:1089,y:556,t:1527271904155};\\\", \\\"{x:1101,y:553,t:1527271904171};\\\", \\\"{x:1109,y:552,t:1527271904187};\\\", \\\"{x:1111,y:552,t:1527271904205};\\\", \\\"{x:1112,y:552,t:1527271904236};\\\", \\\"{x:1116,y:551,t:1527271904244};\\\", \\\"{x:1116,y:550,t:1527271904255};\\\", \\\"{x:1117,y:550,t:1527271904284};\\\", \\\"{x:1121,y:550,t:1527271904292};\\\", \\\"{x:1126,y:550,t:1527271904305};\\\", \\\"{x:1131,y:550,t:1527271904321};\\\", \\\"{x:1137,y:550,t:1527271904338};\\\", \\\"{x:1142,y:550,t:1527271904354};\\\", \\\"{x:1143,y:550,t:1527271904370};\\\", \\\"{x:1149,y:549,t:1527271904387};\\\", \\\"{x:1153,y:546,t:1527271904404};\\\", \\\"{x:1156,y:546,t:1527271904420};\\\", \\\"{x:1158,y:546,t:1527271904437};\\\", \\\"{x:1160,y:546,t:1527271904455};\\\", \\\"{x:1171,y:546,t:1527271904471};\\\", \\\"{x:1177,y:546,t:1527271904488};\\\", \\\"{x:1180,y:545,t:1527271904505};\\\", \\\"{x:1186,y:545,t:1527271904522};\\\", \\\"{x:1191,y:545,t:1527271904538};\\\", \\\"{x:1197,y:545,t:1527271904555};\\\", \\\"{x:1206,y:545,t:1527271904571};\\\", \\\"{x:1209,y:545,t:1527271904587};\\\", \\\"{x:1212,y:545,t:1527271904605};\\\", \\\"{x:1218,y:545,t:1527271904622};\\\", \\\"{x:1223,y:544,t:1527271904638};\\\", \\\"{x:1227,y:544,t:1527271904654};\\\", \\\"{x:1233,y:543,t:1527271904671};\\\", \\\"{x:1236,y:542,t:1527271904688};\\\", \\\"{x:1238,y:542,t:1527271904705};\\\", \\\"{x:1239,y:542,t:1527271904722};\\\", \\\"{x:1241,y:542,t:1527271904748};\\\", \\\"{x:1243,y:542,t:1527271904763};\\\", \\\"{x:1245,y:542,t:1527271904804};\\\", \\\"{x:1248,y:542,t:1527271904822};\\\", \\\"{x:1256,y:542,t:1527271904838};\\\", \\\"{x:1271,y:543,t:1527271904854};\\\", \\\"{x:1285,y:547,t:1527271904872};\\\", \\\"{x:1291,y:548,t:1527271904889};\\\", \\\"{x:1292,y:548,t:1527271904905};\\\", \\\"{x:1296,y:550,t:1527271905124};\\\", \\\"{x:1301,y:554,t:1527271905139};\\\", \\\"{x:1311,y:558,t:1527271905154};\\\", \\\"{x:1331,y:566,t:1527271905171};\\\", \\\"{x:1338,y:568,t:1527271905189};\\\", \\\"{x:1343,y:569,t:1527271905204};\\\", \\\"{x:1345,y:569,t:1527271905221};\\\", \\\"{x:1346,y:569,t:1527271905238};\\\", \\\"{x:1348,y:569,t:1527271905315};\\\", \\\"{x:1352,y:569,t:1527271905323};\\\", \\\"{x:1359,y:569,t:1527271905338};\\\", \\\"{x:1377,y:569,t:1527271905355};\\\", \\\"{x:1384,y:569,t:1527271905372};\\\", \\\"{x:1393,y:569,t:1527271905388};\\\", \\\"{x:1397,y:571,t:1527271905405};\\\", \\\"{x:1401,y:571,t:1527271905422};\\\", \\\"{x:1408,y:571,t:1527271905438};\\\", \\\"{x:1414,y:571,t:1527271905456};\\\", \\\"{x:1417,y:571,t:1527271905472};\\\", \\\"{x:1418,y:571,t:1527271905489};\\\", \\\"{x:1419,y:571,t:1527271905604};\\\", \\\"{x:1419,y:572,t:1527271905611};\\\", \\\"{x:1413,y:573,t:1527271905622};\\\", \\\"{x:1399,y:577,t:1527271905638};\\\", \\\"{x:1377,y:578,t:1527271905656};\\\", \\\"{x:1348,y:584,t:1527271905673};\\\", \\\"{x:1290,y:590,t:1527271905689};\\\", \\\"{x:1210,y:599,t:1527271905706};\\\", \\\"{x:1097,y:607,t:1527271905723};\\\", \\\"{x:981,y:622,t:1527271905739};\\\", \\\"{x:800,y:630,t:1527271905757};\\\", \\\"{x:669,y:632,t:1527271905772};\\\", \\\"{x:553,y:646,t:1527271905789};\\\", \\\"{x:460,y:651,t:1527271905805};\\\", \\\"{x:412,y:654,t:1527271905822};\\\", \\\"{x:362,y:658,t:1527271905839};\\\", \\\"{x:339,y:658,t:1527271905855};\\\", \\\"{x:324,y:658,t:1527271905872};\\\", \\\"{x:312,y:658,t:1527271905889};\\\", \\\"{x:307,y:657,t:1527271905905};\\\", \\\"{x:304,y:657,t:1527271905922};\\\", \\\"{x:301,y:656,t:1527271905938};\\\", \\\"{x:298,y:654,t:1527271905954};\\\", \\\"{x:298,y:651,t:1527271905979};\\\", \\\"{x:298,y:649,t:1527271905988};\\\", \\\"{x:298,y:643,t:1527271906005};\\\", \\\"{x:300,y:635,t:1527271906023};\\\", \\\"{x:305,y:628,t:1527271906040};\\\", \\\"{x:314,y:619,t:1527271906056};\\\", \\\"{x:321,y:614,t:1527271906072};\\\", \\\"{x:329,y:608,t:1527271906089};\\\", \\\"{x:340,y:601,t:1527271906106};\\\", \\\"{x:346,y:596,t:1527271906124};\\\", \\\"{x:351,y:591,t:1527271906139};\\\", \\\"{x:368,y:583,t:1527271906156};\\\", \\\"{x:380,y:577,t:1527271906173};\\\", \\\"{x:389,y:572,t:1527271906188};\\\", \\\"{x:394,y:568,t:1527271906205};\\\", \\\"{x:401,y:563,t:1527271906223};\\\", \\\"{x:408,y:559,t:1527271906239};\\\", \\\"{x:414,y:554,t:1527271906256};\\\", \\\"{x:415,y:550,t:1527271906272};\\\", \\\"{x:417,y:547,t:1527271906289};\\\", \\\"{x:418,y:542,t:1527271906305};\\\", \\\"{x:418,y:540,t:1527271906323};\\\", \\\"{x:412,y:537,t:1527271906338};\\\", \\\"{x:395,y:532,t:1527271906355};\\\", \\\"{x:390,y:531,t:1527271906372};\\\", \\\"{x:384,y:528,t:1527271906388};\\\", \\\"{x:378,y:528,t:1527271906405};\\\", \\\"{x:375,y:528,t:1527271906422};\\\", \\\"{x:373,y:528,t:1527271906438};\\\", \\\"{x:372,y:528,t:1527271906456};\\\", \\\"{x:369,y:528,t:1527271906473};\\\", \\\"{x:373,y:531,t:1527271906611};\\\", \\\"{x:375,y:533,t:1527271906621};\\\", \\\"{x:399,y:532,t:1527271906639};\\\", \\\"{x:453,y:532,t:1527271906656};\\\", \\\"{x:503,y:532,t:1527271906673};\\\", \\\"{x:528,y:531,t:1527271906690};\\\", \\\"{x:537,y:528,t:1527271906707};\\\", \\\"{x:538,y:528,t:1527271906722};\\\", \\\"{x:538,y:527,t:1527271906738};\\\", \\\"{x:532,y:520,t:1527271906758};\\\", \\\"{x:527,y:511,t:1527271906774};\\\", \\\"{x:522,y:504,t:1527271906789};\\\", \\\"{x:522,y:500,t:1527271906806};\\\", \\\"{x:523,y:499,t:1527271906823};\\\", \\\"{x:525,y:497,t:1527271906839};\\\", \\\"{x:526,y:496,t:1527271906857};\\\", \\\"{x:530,y:494,t:1527271906873};\\\", \\\"{x:532,y:490,t:1527271906889};\\\", \\\"{x:540,y:486,t:1527271906907};\\\", \\\"{x:550,y:481,t:1527271906923};\\\", \\\"{x:551,y:479,t:1527271906939};\\\", \\\"{x:558,y:478,t:1527271906956};\\\", \\\"{x:561,y:477,t:1527271906972};\\\", \\\"{x:562,y:477,t:1527271906989};\\\", \\\"{x:563,y:477,t:1527271907076};\\\", \\\"{x:564,y:477,t:1527271907092};\\\", \\\"{x:568,y:477,t:1527271907106};\\\", \\\"{x:570,y:479,t:1527271907121};\\\", \\\"{x:574,y:479,t:1527271907139};\\\", \\\"{x:583,y:486,t:1527271907155};\\\", \\\"{x:594,y:494,t:1527271907173};\\\", \\\"{x:602,y:498,t:1527271907189};\\\", \\\"{x:606,y:500,t:1527271907206};\\\", \\\"{x:606,y:501,t:1527271907764};\\\", \\\"{x:605,y:502,t:1527271907773};\\\", \\\"{x:605,y:503,t:1527271908191};\\\", \\\"{x:607,y:503,t:1527271908226};\\\", \\\"{x:617,y:503,t:1527271908240};\\\", \\\"{x:640,y:511,t:1527271908258};\\\", \\\"{x:670,y:517,t:1527271908274};\\\", \\\"{x:692,y:523,t:1527271908291};\\\", \\\"{x:723,y:525,t:1527271908307};\\\", \\\"{x:732,y:530,t:1527271908324};\\\", \\\"{x:736,y:533,t:1527271908341};\\\", \\\"{x:742,y:536,t:1527271908357};\\\", \\\"{x:744,y:537,t:1527271908403};\\\", \\\"{x:749,y:540,t:1527271908411};\\\", \\\"{x:749,y:541,t:1527271908424};\\\", \\\"{x:755,y:544,t:1527271908441};\\\", \\\"{x:756,y:545,t:1527271908475};\\\", \\\"{x:756,y:546,t:1527271908524};\\\", \\\"{x:757,y:547,t:1527271908547};\\\", \\\"{x:758,y:547,t:1527271908571};\\\", \\\"{x:759,y:547,t:1527271908578};\\\", \\\"{x:761,y:547,t:1527271908591};\\\", \\\"{x:769,y:547,t:1527271908608};\\\", \\\"{x:785,y:552,t:1527271908625};\\\", \\\"{x:788,y:554,t:1527271908640};\\\", \\\"{x:797,y:555,t:1527271908657};\\\", \\\"{x:803,y:556,t:1527271908675};\\\", \\\"{x:804,y:556,t:1527271908690};\\\", \\\"{x:806,y:556,t:1527271908924};\\\", \\\"{x:807,y:556,t:1527271908947};\\\", \\\"{x:808,y:555,t:1527271908959};\\\", \\\"{x:810,y:555,t:1527271909019};\\\", \\\"{x:813,y:554,t:1527271909027};\\\", \\\"{x:815,y:554,t:1527271909041};\\\", \\\"{x:823,y:552,t:1527271909057};\\\", \\\"{x:833,y:551,t:1527271909075};\\\", \\\"{x:846,y:547,t:1527271909091};\\\", \\\"{x:848,y:546,t:1527271909108};\\\", \\\"{x:850,y:545,t:1527271909125};\\\", \\\"{x:850,y:544,t:1527271909244};\\\", \\\"{x:847,y:544,t:1527271909267};\\\", \\\"{x:846,y:544,t:1527271909283};\\\", \\\"{x:843,y:544,t:1527271909308};\\\", \\\"{x:839,y:544,t:1527271909324};\\\", \\\"{x:831,y:544,t:1527271909342};\\\", \\\"{x:824,y:544,t:1527271909357};\\\", \\\"{x:820,y:544,t:1527271909375};\\\", \\\"{x:811,y:545,t:1527271909392};\\\", \\\"{x:810,y:547,t:1527271909408};\\\", \\\"{x:809,y:548,t:1527271909425};\\\", \\\"{x:811,y:548,t:1527271910684};\\\", \\\"{x:812,y:548,t:1527271910693};\\\", \\\"{x:816,y:548,t:1527271910710};\\\", \\\"{x:819,y:548,t:1527271910727};\\\", \\\"{x:819,y:547,t:1527271910742};\\\", \\\"{x:821,y:546,t:1527271910819};\\\", \\\"{x:822,y:546,t:1527271910826};\\\", \\\"{x:823,y:546,t:1527271910842};\\\", \\\"{x:824,y:545,t:1527271910923};\\\", \\\"{x:826,y:544,t:1527271910943};\\\", \\\"{x:828,y:544,t:1527271911268};\\\", \\\"{x:822,y:547,t:1527271911507};\\\", \\\"{x:801,y:555,t:1527271911527};\\\", \\\"{x:776,y:562,t:1527271911544};\\\", \\\"{x:748,y:569,t:1527271911560};\\\", \\\"{x:717,y:585,t:1527271911578};\\\", \\\"{x:694,y:596,t:1527271911595};\\\", \\\"{x:684,y:607,t:1527271911610};\\\", \\\"{x:657,y:626,t:1527271911626};\\\", \\\"{x:633,y:645,t:1527271911643};\\\", \\\"{x:609,y:662,t:1527271911660};\\\", \\\"{x:582,y:680,t:1527271911677};\\\", \\\"{x:560,y:691,t:1527271911693};\\\", \\\"{x:540,y:699,t:1527271911709};\\\", \\\"{x:522,y:710,t:1527271911727};\\\", \\\"{x:508,y:718,t:1527271911743};\\\", \\\"{x:496,y:726,t:1527271911760};\\\", \\\"{x:482,y:729,t:1527271911776};\\\", \\\"{x:477,y:732,t:1527271911793};\\\", \\\"{x:476,y:733,t:1527271911810};\\\", \\\"{x:476,y:735,t:1527271911899};\\\", \\\"{x:476,y:737,t:1527271911915};\\\", \\\"{x:476,y:738,t:1527271911927};\\\", \\\"{x:476,y:739,t:1527271911944};\\\", \\\"{x:476,y:740,t:1527271912083};\\\", \\\"{x:477,y:740,t:1527271912094};\\\", \\\"{x:481,y:734,t:1527271913180};\\\", \\\"{x:481,y:733,t:1527271913203};\\\", \\\"{x:480,y:728,t:1527271913211};\\\", \\\"{x:479,y:726,t:1527271913227};\\\", \\\"{x:463,y:703,t:1527271913245};\\\", \\\"{x:446,y:687,t:1527271913261};\\\", \\\"{x:440,y:681,t:1527271913277};\\\", \\\"{x:439,y:680,t:1527271913396};\\\" ] }, { \\\"rt\\\": 30663, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 371691, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:438,y:680,t:1527271915748};\\\", \\\"{x:437,y:680,t:1527271915980};\\\", \\\"{x:436,y:680,t:1527271916036};\\\", \\\"{x:435,y:680,t:1527271916047};\\\", \\\"{x:434,y:680,t:1527271916156};\\\", \\\"{x:433,y:680,t:1527271917835};\\\", \\\"{x:432,y:681,t:1527271917898};\\\", \\\"{x:431,y:681,t:1527271918572};\\\", \\\"{x:430,y:682,t:1527271919276};\\\", \\\"{x:428,y:682,t:1527271919292};\\\", \\\"{x:427,y:682,t:1527271919307};\\\", \\\"{x:426,y:682,t:1527271919323};\\\", \\\"{x:424,y:682,t:1527271920587};\\\", \\\"{x:423,y:682,t:1527271920732};\\\", \\\"{x:422,y:682,t:1527271920843};\\\", \\\"{x:421,y:682,t:1527271920858};\\\", \\\"{x:419,y:683,t:1527271921980};\\\", \\\"{x:418,y:683,t:1527271922011};\\\", \\\"{x:417,y:684,t:1527271922043};\\\", \\\"{x:420,y:685,t:1527271927597};\\\", \\\"{x:421,y:685,t:1527271927606};\\\", \\\"{x:425,y:685,t:1527271927623};\\\", \\\"{x:429,y:685,t:1527271927640};\\\", \\\"{x:432,y:686,t:1527271927657};\\\", \\\"{x:435,y:686,t:1527271927673};\\\", \\\"{x:439,y:686,t:1527271927690};\\\", \\\"{x:444,y:687,t:1527271927707};\\\", \\\"{x:448,y:687,t:1527271927724};\\\", \\\"{x:461,y:689,t:1527271927740};\\\", \\\"{x:471,y:694,t:1527271927757};\\\", \\\"{x:492,y:696,t:1527271927773};\\\", \\\"{x:527,y:704,t:1527271927790};\\\", \\\"{x:554,y:704,t:1527271927807};\\\", \\\"{x:605,y:715,t:1527271927825};\\\", \\\"{x:643,y:715,t:1527271927840};\\\", \\\"{x:681,y:716,t:1527271927857};\\\", \\\"{x:712,y:719,t:1527271927874};\\\", \\\"{x:737,y:724,t:1527271927890};\\\", \\\"{x:752,y:724,t:1527271927907};\\\", \\\"{x:773,y:729,t:1527271927923};\\\", \\\"{x:782,y:729,t:1527271927940};\\\", \\\"{x:790,y:730,t:1527271927957};\\\", \\\"{x:797,y:731,t:1527271927974};\\\", \\\"{x:807,y:734,t:1527271927990};\\\", \\\"{x:819,y:734,t:1527271928007};\\\", \\\"{x:821,y:734,t:1527271928024};\\\", \\\"{x:842,y:734,t:1527271928040};\\\", \\\"{x:866,y:728,t:1527271928057};\\\", \\\"{x:909,y:710,t:1527271928074};\\\", \\\"{x:932,y:701,t:1527271928090};\\\", \\\"{x:943,y:687,t:1527271928107};\\\", \\\"{x:966,y:667,t:1527271928124};\\\", \\\"{x:972,y:662,t:1527271928139};\\\", \\\"{x:976,y:653,t:1527271928156};\\\", \\\"{x:983,y:646,t:1527271928173};\\\", \\\"{x:989,y:640,t:1527271928189};\\\", \\\"{x:992,y:637,t:1527271928206};\\\", \\\"{x:993,y:636,t:1527271928259};\\\", \\\"{x:999,y:633,t:1527271928274};\\\", \\\"{x:1014,y:626,t:1527271928291};\\\", \\\"{x:1020,y:621,t:1527271928307};\\\", \\\"{x:1031,y:619,t:1527271928323};\\\", \\\"{x:1037,y:617,t:1527271928341};\\\", \\\"{x:1038,y:616,t:1527271928357};\\\", \\\"{x:1040,y:615,t:1527271928460};\\\", \\\"{x:1043,y:615,t:1527271928476};\\\", \\\"{x:1044,y:615,t:1527271928491};\\\", \\\"{x:1046,y:615,t:1527271928507};\\\", \\\"{x:1047,y:615,t:1527271928524};\\\", \\\"{x:1051,y:617,t:1527271928541};\\\", \\\"{x:1060,y:621,t:1527271928557};\\\", \\\"{x:1065,y:626,t:1527271928574};\\\", \\\"{x:1074,y:628,t:1527271928591};\\\", \\\"{x:1078,y:631,t:1527271928608};\\\", \\\"{x:1079,y:631,t:1527271928624};\\\", \\\"{x:1079,y:632,t:1527271928684};\\\", \\\"{x:1079,y:633,t:1527271928691};\\\", \\\"{x:1076,y:635,t:1527271928707};\\\", \\\"{x:1072,y:639,t:1527271928724};\\\", \\\"{x:1065,y:643,t:1527271928741};\\\", \\\"{x:1061,y:645,t:1527271928758};\\\", \\\"{x:1055,y:649,t:1527271928774};\\\", \\\"{x:1053,y:649,t:1527271928791};\\\", \\\"{x:1052,y:649,t:1527271928860};\\\", \\\"{x:1052,y:648,t:1527271928876};\\\", \\\"{x:1055,y:645,t:1527271928891};\\\", \\\"{x:1067,y:629,t:1527271928907};\\\", \\\"{x:1068,y:628,t:1527271928924};\\\", \\\"{x:1075,y:626,t:1527271928941};\\\", \\\"{x:1078,y:626,t:1527271929020};\\\", \\\"{x:1081,y:625,t:1527271929028};\\\", \\\"{x:1084,y:625,t:1527271929041};\\\", \\\"{x:1091,y:624,t:1527271929058};\\\", \\\"{x:1102,y:621,t:1527271929074};\\\", \\\"{x:1115,y:621,t:1527271929090};\\\", \\\"{x:1136,y:617,t:1527271929108};\\\", \\\"{x:1162,y:615,t:1527271929125};\\\", \\\"{x:1182,y:612,t:1527271929141};\\\", \\\"{x:1190,y:612,t:1527271929158};\\\", \\\"{x:1212,y:611,t:1527271929175};\\\", \\\"{x:1222,y:609,t:1527271929191};\\\", \\\"{x:1243,y:601,t:1527271929208};\\\", \\\"{x:1257,y:599,t:1527271929225};\\\", \\\"{x:1266,y:596,t:1527271929241};\\\", \\\"{x:1275,y:594,t:1527271929258};\\\", \\\"{x:1284,y:591,t:1527271929275};\\\", \\\"{x:1288,y:590,t:1527271929291};\\\", \\\"{x:1292,y:590,t:1527271929307};\\\", \\\"{x:1297,y:590,t:1527271929325};\\\", \\\"{x:1298,y:590,t:1527271929347};\\\", \\\"{x:1301,y:590,t:1527271929362};\\\", \\\"{x:1303,y:590,t:1527271929375};\\\", \\\"{x:1314,y:590,t:1527271929390};\\\", \\\"{x:1332,y:595,t:1527271929407};\\\", \\\"{x:1357,y:599,t:1527271929424};\\\", \\\"{x:1377,y:606,t:1527271929440};\\\", \\\"{x:1384,y:608,t:1527271929458};\\\", \\\"{x:1403,y:615,t:1527271929474};\\\", \\\"{x:1415,y:622,t:1527271929491};\\\", \\\"{x:1436,y:629,t:1527271929507};\\\", \\\"{x:1457,y:634,t:1527271929525};\\\", \\\"{x:1485,y:640,t:1527271929541};\\\", \\\"{x:1507,y:643,t:1527271929557};\\\", \\\"{x:1532,y:647,t:1527271929575};\\\", \\\"{x:1547,y:650,t:1527271929591};\\\", \\\"{x:1559,y:654,t:1527271929607};\\\", \\\"{x:1578,y:659,t:1527271929625};\\\", \\\"{x:1590,y:662,t:1527271929642};\\\", \\\"{x:1594,y:664,t:1527271929658};\\\", \\\"{x:1603,y:665,t:1527271929674};\\\", \\\"{x:1603,y:667,t:1527271929692};\\\", \\\"{x:1604,y:667,t:1527271929708};\\\", \\\"{x:1608,y:671,t:1527271929725};\\\", \\\"{x:1611,y:671,t:1527271929742};\\\", \\\"{x:1611,y:672,t:1527271929797};\\\", \\\"{x:1609,y:672,t:1527271929852};\\\", \\\"{x:1607,y:674,t:1527271929859};\\\", \\\"{x:1604,y:675,t:1527271929876};\\\", \\\"{x:1592,y:679,t:1527271929892};\\\", \\\"{x:1570,y:688,t:1527271929908};\\\", \\\"{x:1509,y:704,t:1527271929926};\\\", \\\"{x:1444,y:718,t:1527271929942};\\\", \\\"{x:1443,y:719,t:1527271929958};\\\", \\\"{x:1432,y:727,t:1527271929975};\\\", \\\"{x:1419,y:727,t:1527271929993};\\\", \\\"{x:1408,y:729,t:1527271930009};\\\", \\\"{x:1407,y:729,t:1527271930025};\\\", \\\"{x:1408,y:729,t:1527271930108};\\\", \\\"{x:1409,y:729,t:1527271930125};\\\", \\\"{x:1408,y:729,t:1527271930652};\\\", \\\"{x:1406,y:729,t:1527271930675};\\\", \\\"{x:1405,y:729,t:1527271930692};\\\", \\\"{x:1402,y:729,t:1527271930709};\\\", \\\"{x:1398,y:730,t:1527271930726};\\\", \\\"{x:1396,y:733,t:1527271930747};\\\", \\\"{x:1394,y:733,t:1527271930760};\\\", \\\"{x:1391,y:734,t:1527271930776};\\\", \\\"{x:1387,y:734,t:1527271930792};\\\", \\\"{x:1384,y:734,t:1527271930809};\\\", \\\"{x:1380,y:734,t:1527271930827};\\\", \\\"{x:1376,y:734,t:1527271930841};\\\", \\\"{x:1371,y:734,t:1527271930858};\\\", \\\"{x:1363,y:732,t:1527271930876};\\\", \\\"{x:1361,y:732,t:1527271930892};\\\", \\\"{x:1359,y:732,t:1527271930908};\\\", \\\"{x:1359,y:733,t:1527271931388};\\\", \\\"{x:1359,y:735,t:1527271931396};\\\", \\\"{x:1359,y:737,t:1527271931410};\\\", \\\"{x:1359,y:744,t:1527271931426};\\\", \\\"{x:1359,y:748,t:1527271931443};\\\", \\\"{x:1359,y:754,t:1527271931459};\\\", \\\"{x:1359,y:755,t:1527271931483};\\\", \\\"{x:1359,y:757,t:1527271931493};\\\", \\\"{x:1359,y:758,t:1527271931510};\\\", \\\"{x:1359,y:760,t:1527271931548};\\\", \\\"{x:1359,y:761,t:1527271931851};\\\", \\\"{x:1359,y:762,t:1527271931875};\\\", \\\"{x:1359,y:763,t:1527271931893};\\\", \\\"{x:1359,y:764,t:1527271931910};\\\", \\\"{x:1359,y:766,t:1527271931927};\\\", \\\"{x:1359,y:767,t:1527271931943};\\\", \\\"{x:1359,y:770,t:1527271931960};\\\", \\\"{x:1359,y:772,t:1527271931977};\\\", \\\"{x:1359,y:778,t:1527271931993};\\\", \\\"{x:1359,y:783,t:1527271932010};\\\", \\\"{x:1362,y:789,t:1527271932027};\\\", \\\"{x:1362,y:793,t:1527271932043};\\\", \\\"{x:1362,y:801,t:1527271932060};\\\", \\\"{x:1363,y:806,t:1527271932077};\\\", \\\"{x:1363,y:810,t:1527271932093};\\\", \\\"{x:1365,y:814,t:1527271932110};\\\", \\\"{x:1367,y:818,t:1527271932127};\\\", \\\"{x:1366,y:824,t:1527271932143};\\\", \\\"{x:1366,y:826,t:1527271932160};\\\", \\\"{x:1363,y:829,t:1527271932177};\\\", \\\"{x:1358,y:833,t:1527271932193};\\\", \\\"{x:1355,y:836,t:1527271932210};\\\", \\\"{x:1354,y:836,t:1527271932227};\\\", \\\"{x:1347,y:840,t:1527271932244};\\\", \\\"{x:1341,y:840,t:1527271932260};\\\", \\\"{x:1333,y:841,t:1527271932277};\\\", \\\"{x:1325,y:842,t:1527271932294};\\\", \\\"{x:1309,y:844,t:1527271932310};\\\", \\\"{x:1294,y:845,t:1527271932327};\\\", \\\"{x:1280,y:851,t:1527271932344};\\\", \\\"{x:1258,y:851,t:1527271932360};\\\", \\\"{x:1245,y:854,t:1527271932377};\\\", \\\"{x:1227,y:857,t:1527271932394};\\\", \\\"{x:1214,y:860,t:1527271932410};\\\", \\\"{x:1205,y:861,t:1527271932427};\\\", \\\"{x:1202,y:861,t:1527271932443};\\\", \\\"{x:1198,y:861,t:1527271932464};\\\", \\\"{x:1192,y:861,t:1527271932481};\\\", \\\"{x:1189,y:861,t:1527271932498};\\\", \\\"{x:1179,y:861,t:1527271932514};\\\", \\\"{x:1168,y:856,t:1527271932531};\\\", \\\"{x:1150,y:852,t:1527271932548};\\\", \\\"{x:1127,y:843,t:1527271932564};\\\", \\\"{x:1105,y:840,t:1527271932581};\\\", \\\"{x:1085,y:836,t:1527271932599};\\\", \\\"{x:1064,y:831,t:1527271932614};\\\", \\\"{x:1056,y:827,t:1527271932631};\\\", \\\"{x:1053,y:826,t:1527271932649};\\\", \\\"{x:1051,y:826,t:1527271932665};\\\", \\\"{x:1048,y:826,t:1527271932681};\\\", \\\"{x:1045,y:823,t:1527271932698};\\\", \\\"{x:1036,y:823,t:1527271932715};\\\", \\\"{x:1029,y:822,t:1527271932731};\\\", \\\"{x:1018,y:819,t:1527271932747};\\\", \\\"{x:1014,y:818,t:1527271932765};\\\", \\\"{x:1006,y:817,t:1527271932781};\\\", \\\"{x:999,y:815,t:1527271932798};\\\", \\\"{x:998,y:814,t:1527271932944};\\\", \\\"{x:1000,y:813,t:1527271932959};\\\", \\\"{x:1003,y:809,t:1527271932967};\\\", \\\"{x:1004,y:809,t:1527271932983};\\\", \\\"{x:1004,y:807,t:1527271933001};\\\", \\\"{x:1005,y:805,t:1527271933016};\\\", \\\"{x:1006,y:804,t:1527271933031};\\\", \\\"{x:1007,y:804,t:1527271933048};\\\", \\\"{x:1008,y:804,t:1527271933065};\\\", \\\"{x:1009,y:803,t:1527271933127};\\\", \\\"{x:1009,y:802,t:1527271933175};\\\", \\\"{x:1008,y:802,t:1527271933184};\\\", \\\"{x:1008,y:801,t:1527271933223};\\\", \\\"{x:1008,y:799,t:1527271933240};\\\", \\\"{x:1007,y:797,t:1527271933255};\\\", \\\"{x:1005,y:797,t:1527271933265};\\\", \\\"{x:1002,y:797,t:1527271933282};\\\", \\\"{x:1001,y:796,t:1527271933298};\\\", \\\"{x:1001,y:795,t:1527271933401};\\\", \\\"{x:1001,y:792,t:1527271933415};\\\", \\\"{x:1001,y:791,t:1527271933432};\\\", \\\"{x:1001,y:790,t:1527271933448};\\\", \\\"{x:1004,y:790,t:1527271933472};\\\", \\\"{x:1004,y:789,t:1527271933552};\\\", \\\"{x:1004,y:788,t:1527271933565};\\\", \\\"{x:1007,y:787,t:1527271933582};\\\", \\\"{x:1010,y:782,t:1527271933601};\\\", \\\"{x:1011,y:782,t:1527271933614};\\\", \\\"{x:1011,y:781,t:1527271933687};\\\", \\\"{x:1011,y:779,t:1527271933698};\\\", \\\"{x:1011,y:778,t:1527271933718};\\\", \\\"{x:1011,y:777,t:1527271933732};\\\", \\\"{x:1012,y:774,t:1527271933748};\\\", \\\"{x:1016,y:768,t:1527271933764};\\\", \\\"{x:1020,y:763,t:1527271933782};\\\", \\\"{x:1029,y:755,t:1527271933799};\\\", \\\"{x:1030,y:751,t:1527271933815};\\\", \\\"{x:1032,y:751,t:1527271933831};\\\", \\\"{x:1035,y:747,t:1527271933848};\\\", \\\"{x:1035,y:746,t:1527271933865};\\\", \\\"{x:1035,y:744,t:1527271933881};\\\", \\\"{x:1036,y:743,t:1527271933903};\\\", \\\"{x:1038,y:743,t:1527271933915};\\\", \\\"{x:1043,y:741,t:1527271933932};\\\", \\\"{x:1050,y:740,t:1527271933949};\\\", \\\"{x:1056,y:736,t:1527271933965};\\\", \\\"{x:1068,y:735,t:1527271933982};\\\", \\\"{x:1084,y:732,t:1527271934000};\\\", \\\"{x:1088,y:732,t:1527271934016};\\\", \\\"{x:1095,y:731,t:1527271934032};\\\", \\\"{x:1105,y:727,t:1527271934049};\\\", \\\"{x:1109,y:725,t:1527271934066};\\\", \\\"{x:1117,y:722,t:1527271934082};\\\", \\\"{x:1122,y:720,t:1527271934099};\\\", \\\"{x:1127,y:718,t:1527271934116};\\\", \\\"{x:1131,y:715,t:1527271934132};\\\", \\\"{x:1136,y:712,t:1527271934149};\\\", \\\"{x:1140,y:709,t:1527271934166};\\\", \\\"{x:1141,y:707,t:1527271934182};\\\", \\\"{x:1142,y:707,t:1527271934199};\\\", \\\"{x:1143,y:706,t:1527271934223};\\\", \\\"{x:1145,y:706,t:1527271934239};\\\", \\\"{x:1147,y:705,t:1527271934255};\\\", \\\"{x:1153,y:705,t:1527271934266};\\\", \\\"{x:1160,y:703,t:1527271934282};\\\", \\\"{x:1170,y:703,t:1527271934299};\\\", \\\"{x:1184,y:701,t:1527271934316};\\\", \\\"{x:1194,y:701,t:1527271934332};\\\", \\\"{x:1195,y:702,t:1527271934349};\\\", \\\"{x:1202,y:705,t:1527271934366};\\\", \\\"{x:1210,y:708,t:1527271934382};\\\", \\\"{x:1220,y:712,t:1527271934400};\\\", \\\"{x:1225,y:714,t:1527271934415};\\\", \\\"{x:1226,y:714,t:1527271934448};\\\", \\\"{x:1227,y:716,t:1527271934544};\\\", \\\"{x:1227,y:717,t:1527271934575};\\\", \\\"{x:1227,y:719,t:1527271934623};\\\", \\\"{x:1227,y:720,t:1527271934639};\\\", \\\"{x:1227,y:723,t:1527271934663};\\\", \\\"{x:1226,y:725,t:1527271934679};\\\", \\\"{x:1226,y:727,t:1527271934703};\\\", \\\"{x:1224,y:729,t:1527271934719};\\\", \\\"{x:1223,y:730,t:1527271934751};\\\", \\\"{x:1222,y:730,t:1527271934776};\\\", \\\"{x:1221,y:730,t:1527271934815};\\\", \\\"{x:1220,y:730,t:1527271934855};\\\", \\\"{x:1217,y:730,t:1527271935096};\\\", \\\"{x:1217,y:731,t:1527271935103};\\\", \\\"{x:1216,y:731,t:1527271935118};\\\", \\\"{x:1215,y:732,t:1527271935142};\\\", \\\"{x:1214,y:732,t:1527271935150};\\\", \\\"{x:1212,y:732,t:1527271935206};\\\", \\\"{x:1211,y:732,t:1527271935246};\\\", \\\"{x:1209,y:732,t:1527271935262};\\\", \\\"{x:1208,y:732,t:1527271935271};\\\", \\\"{x:1207,y:732,t:1527271935283};\\\", \\\"{x:1204,y:732,t:1527271935300};\\\", \\\"{x:1201,y:732,t:1527271935317};\\\", \\\"{x:1199,y:732,t:1527271935343};\\\", \\\"{x:1198,y:732,t:1527271935350};\\\", \\\"{x:1196,y:734,t:1527271935367};\\\", \\\"{x:1189,y:735,t:1527271935383};\\\", \\\"{x:1179,y:736,t:1527271935399};\\\", \\\"{x:1173,y:737,t:1527271935416};\\\", \\\"{x:1165,y:738,t:1527271935432};\\\", \\\"{x:1159,y:740,t:1527271935450};\\\", \\\"{x:1151,y:741,t:1527271935467};\\\", \\\"{x:1144,y:741,t:1527271935483};\\\", \\\"{x:1140,y:741,t:1527271935499};\\\", \\\"{x:1137,y:742,t:1527271935516};\\\", \\\"{x:1135,y:743,t:1527271935542};\\\", \\\"{x:1134,y:743,t:1527271935549};\\\", \\\"{x:1132,y:743,t:1527271935565};\\\", \\\"{x:1130,y:745,t:1527271935582};\\\", \\\"{x:1122,y:745,t:1527271935600};\\\", \\\"{x:1109,y:748,t:1527271935616};\\\", \\\"{x:1085,y:751,t:1527271935632};\\\", \\\"{x:1063,y:752,t:1527271935649};\\\", \\\"{x:1033,y:754,t:1527271935667};\\\", \\\"{x:1018,y:754,t:1527271935682};\\\", \\\"{x:1003,y:758,t:1527271935699};\\\", \\\"{x:986,y:757,t:1527271935716};\\\", \\\"{x:968,y:754,t:1527271935733};\\\", \\\"{x:962,y:754,t:1527271935749};\\\", \\\"{x:942,y:752,t:1527271935766};\\\", \\\"{x:933,y:750,t:1527271935783};\\\", \\\"{x:925,y:749,t:1527271935800};\\\", \\\"{x:921,y:749,t:1527271935816};\\\", \\\"{x:918,y:748,t:1527271935833};\\\", \\\"{x:917,y:748,t:1527271935849};\\\", \\\"{x:915,y:748,t:1527271935867};\\\", \\\"{x:911,y:746,t:1527271935884};\\\", \\\"{x:903,y:746,t:1527271935899};\\\", \\\"{x:893,y:745,t:1527271935916};\\\", \\\"{x:878,y:742,t:1527271935933};\\\", \\\"{x:869,y:738,t:1527271935950};\\\", \\\"{x:858,y:732,t:1527271935967};\\\", \\\"{x:843,y:732,t:1527271935983};\\\", \\\"{x:829,y:732,t:1527271935999};\\\", \\\"{x:821,y:730,t:1527271936017};\\\", \\\"{x:818,y:728,t:1527271936034};\\\", \\\"{x:816,y:727,t:1527271936049};\\\", \\\"{x:810,y:726,t:1527271936067};\\\", \\\"{x:804,y:725,t:1527271936084};\\\", \\\"{x:797,y:725,t:1527271936100};\\\", \\\"{x:788,y:723,t:1527271936117};\\\", \\\"{x:773,y:721,t:1527271936134};\\\", \\\"{x:755,y:719,t:1527271936150};\\\", \\\"{x:726,y:714,t:1527271936167};\\\", \\\"{x:703,y:710,t:1527271936183};\\\", \\\"{x:687,y:707,t:1527271936200};\\\", \\\"{x:671,y:703,t:1527271936217};\\\", \\\"{x:663,y:702,t:1527271936234};\\\", \\\"{x:656,y:700,t:1527271936251};\\\", \\\"{x:655,y:700,t:1527271936267};\\\", \\\"{x:653,y:700,t:1527271936284};\\\", \\\"{x:652,y:700,t:1527271936327};\\\", \\\"{x:650,y:700,t:1527271936471};\\\", \\\"{x:648,y:700,t:1527271936543};\\\", \\\"{x:647,y:700,t:1527271936550};\\\", \\\"{x:646,y:700,t:1527271936567};\\\", \\\"{x:645,y:700,t:1527271936584};\\\", \\\"{x:644,y:700,t:1527271936601};\\\", \\\"{x:643,y:700,t:1527271936617};\\\", \\\"{x:634,y:696,t:1527271936634};\\\", \\\"{x:627,y:695,t:1527271936651};\\\", \\\"{x:620,y:692,t:1527271936667};\\\", \\\"{x:611,y:691,t:1527271936684};\\\", \\\"{x:598,y:686,t:1527271936701};\\\", \\\"{x:590,y:683,t:1527271936718};\\\", \\\"{x:581,y:681,t:1527271936734};\\\", \\\"{x:567,y:677,t:1527271936751};\\\", \\\"{x:564,y:674,t:1527271936768};\\\", \\\"{x:560,y:672,t:1527271936784};\\\", \\\"{x:556,y:672,t:1527271936801};\\\", \\\"{x:553,y:670,t:1527271936817};\\\", \\\"{x:547,y:670,t:1527271936834};\\\", \\\"{x:539,y:668,t:1527271936851};\\\", \\\"{x:532,y:665,t:1527271936867};\\\", \\\"{x:526,y:662,t:1527271936884};\\\", \\\"{x:517,y:661,t:1527271936901};\\\", \\\"{x:511,y:658,t:1527271936918};\\\", \\\"{x:502,y:655,t:1527271936933};\\\", \\\"{x:491,y:650,t:1527271936952};\\\", \\\"{x:475,y:644,t:1527271936968};\\\", \\\"{x:462,y:638,t:1527271936984};\\\", \\\"{x:445,y:632,t:1527271937001};\\\", \\\"{x:429,y:627,t:1527271937018};\\\", \\\"{x:422,y:624,t:1527271937034};\\\", \\\"{x:417,y:624,t:1527271937051};\\\", \\\"{x:411,y:624,t:1527271937067};\\\", \\\"{x:410,y:624,t:1527271937183};\\\", \\\"{x:409,y:624,t:1527271937214};\\\", \\\"{x:408,y:624,t:1527271937231};\\\", \\\"{x:406,y:622,t:1527271937238};\\\", \\\"{x:405,y:620,t:1527271937254};\\\", \\\"{x:403,y:616,t:1527271937267};\\\", \\\"{x:398,y:615,t:1527271937284};\\\", \\\"{x:391,y:610,t:1527271937300};\\\", \\\"{x:390,y:608,t:1527271937318};\\\", \\\"{x:390,y:605,t:1527271937334};\\\", \\\"{x:390,y:604,t:1527271937350};\\\", \\\"{x:390,y:602,t:1527271937368};\\\", \\\"{x:389,y:601,t:1527271937384};\\\", \\\"{x:389,y:600,t:1527271937402};\\\", \\\"{x:389,y:595,t:1527271937419};\\\", \\\"{x:389,y:593,t:1527271937436};\\\", \\\"{x:389,y:591,t:1527271937470};\\\", \\\"{x:389,y:590,t:1527271937484};\\\", \\\"{x:389,y:585,t:1527271937502};\\\", \\\"{x:389,y:584,t:1527271937518};\\\", \\\"{x:389,y:581,t:1527271937534};\\\", \\\"{x:391,y:580,t:1527271937552};\\\", \\\"{x:395,y:578,t:1527271937569};\\\", \\\"{x:403,y:575,t:1527271937584};\\\", \\\"{x:419,y:566,t:1527271937602};\\\", \\\"{x:451,y:556,t:1527271937619};\\\", \\\"{x:476,y:549,t:1527271937635};\\\", \\\"{x:501,y:544,t:1527271937652};\\\", \\\"{x:506,y:540,t:1527271937668};\\\", \\\"{x:522,y:533,t:1527271937684};\\\", \\\"{x:530,y:529,t:1527271937702};\\\", \\\"{x:533,y:527,t:1527271937718};\\\", \\\"{x:533,y:525,t:1527271937751};\\\", \\\"{x:533,y:523,t:1527271937767};\\\", \\\"{x:534,y:522,t:1527271937784};\\\", \\\"{x:535,y:521,t:1527271937802};\\\", \\\"{x:537,y:519,t:1527271937818};\\\", \\\"{x:535,y:519,t:1527271938006};\\\", \\\"{x:529,y:519,t:1527271938019};\\\", \\\"{x:509,y:525,t:1527271938035};\\\", \\\"{x:478,y:533,t:1527271938053};\\\", \\\"{x:454,y:538,t:1527271938069};\\\", \\\"{x:441,y:542,t:1527271938086};\\\", \\\"{x:429,y:546,t:1527271938101};\\\", \\\"{x:423,y:548,t:1527271938118};\\\", \\\"{x:421,y:549,t:1527271938142};\\\", \\\"{x:421,y:550,t:1527271938158};\\\", \\\"{x:421,y:551,t:1527271938168};\\\", \\\"{x:421,y:554,t:1527271938185};\\\", \\\"{x:419,y:558,t:1527271938204};\\\", \\\"{x:417,y:565,t:1527271938219};\\\", \\\"{x:413,y:572,t:1527271938236};\\\", \\\"{x:411,y:574,t:1527271938252};\\\", \\\"{x:411,y:577,t:1527271938268};\\\", \\\"{x:411,y:581,t:1527271938285};\\\", \\\"{x:411,y:582,t:1527271938302};\\\", \\\"{x:411,y:586,t:1527271938318};\\\", \\\"{x:411,y:587,t:1527271938336};\\\", \\\"{x:408,y:591,t:1527271938353};\\\", \\\"{x:404,y:596,t:1527271938369};\\\", \\\"{x:401,y:598,t:1527271938385};\\\", \\\"{x:400,y:598,t:1527271938406};\\\", \\\"{x:397,y:598,t:1527271938430};\\\", \\\"{x:393,y:598,t:1527271938438};\\\", \\\"{x:393,y:599,t:1527271938452};\\\", \\\"{x:382,y:597,t:1527271938469};\\\", \\\"{x:351,y:585,t:1527271938487};\\\", \\\"{x:341,y:584,t:1527271938502};\\\", \\\"{x:335,y:586,t:1527271938520};\\\", \\\"{x:331,y:583,t:1527271938535};\\\", \\\"{x:330,y:583,t:1527271938552};\\\", \\\"{x:328,y:583,t:1527271938614};\\\", \\\"{x:327,y:584,t:1527271938630};\\\", \\\"{x:327,y:585,t:1527271938639};\\\", \\\"{x:326,y:587,t:1527271938653};\\\", \\\"{x:321,y:594,t:1527271938671};\\\", \\\"{x:314,y:601,t:1527271938686};\\\", \\\"{x:313,y:602,t:1527271938703};\\\", \\\"{x:311,y:604,t:1527271938718};\\\", \\\"{x:310,y:605,t:1527271938742};\\\", \\\"{x:304,y:610,t:1527271938752};\\\", \\\"{x:297,y:614,t:1527271938770};\\\", \\\"{x:288,y:619,t:1527271938786};\\\", \\\"{x:277,y:622,t:1527271938803};\\\", \\\"{x:272,y:624,t:1527271938821};\\\", \\\"{x:265,y:626,t:1527271938836};\\\", \\\"{x:261,y:628,t:1527271938853};\\\", \\\"{x:258,y:630,t:1527271938869};\\\", \\\"{x:256,y:630,t:1527271938886};\\\", \\\"{x:255,y:630,t:1527271938902};\\\", \\\"{x:255,y:628,t:1527271938967};\\\", \\\"{x:255,y:626,t:1527271938975};\\\", \\\"{x:254,y:623,t:1527271938986};\\\", \\\"{x:252,y:613,t:1527271939002};\\\", \\\"{x:251,y:605,t:1527271939019};\\\", \\\"{x:250,y:598,t:1527271939037};\\\", \\\"{x:250,y:593,t:1527271939052};\\\", \\\"{x:250,y:587,t:1527271939069};\\\", \\\"{x:250,y:580,t:1527271939086};\\\", \\\"{x:252,y:575,t:1527271939103};\\\", \\\"{x:254,y:573,t:1527271939119};\\\", \\\"{x:257,y:570,t:1527271939137};\\\", \\\"{x:261,y:570,t:1527271939152};\\\", \\\"{x:267,y:567,t:1527271939169};\\\", \\\"{x:283,y:563,t:1527271939187};\\\", \\\"{x:301,y:561,t:1527271939204};\\\", \\\"{x:314,y:557,t:1527271939219};\\\", \\\"{x:330,y:553,t:1527271939236};\\\", \\\"{x:343,y:550,t:1527271939253};\\\", \\\"{x:357,y:545,t:1527271939269};\\\", \\\"{x:375,y:540,t:1527271939287};\\\", \\\"{x:390,y:532,t:1527271939303};\\\", \\\"{x:411,y:525,t:1527271939320};\\\", \\\"{x:439,y:519,t:1527271939337};\\\", \\\"{x:459,y:518,t:1527271939353};\\\", \\\"{x:479,y:516,t:1527271939370};\\\", \\\"{x:493,y:514,t:1527271939387};\\\", \\\"{x:508,y:511,t:1527271939403};\\\", \\\"{x:518,y:508,t:1527271939420};\\\", \\\"{x:528,y:505,t:1527271939436};\\\", \\\"{x:536,y:500,t:1527271939453};\\\", \\\"{x:548,y:495,t:1527271939469};\\\", \\\"{x:567,y:488,t:1527271939486};\\\", \\\"{x:584,y:485,t:1527271939505};\\\", \\\"{x:626,y:477,t:1527271939520};\\\", \\\"{x:654,y:473,t:1527271939536};\\\", \\\"{x:683,y:473,t:1527271939554};\\\", \\\"{x:710,y:473,t:1527271939570};\\\", \\\"{x:741,y:474,t:1527271939587};\\\", \\\"{x:759,y:475,t:1527271939604};\\\", \\\"{x:766,y:476,t:1527271939620};\\\", \\\"{x:770,y:478,t:1527271939636};\\\", \\\"{x:773,y:478,t:1527271939654};\\\", \\\"{x:776,y:478,t:1527271939670};\\\", \\\"{x:777,y:478,t:1527271939687};\\\", \\\"{x:778,y:480,t:1527271939744};\\\", \\\"{x:781,y:481,t:1527271939754};\\\", \\\"{x:785,y:483,t:1527271939770};\\\", \\\"{x:787,y:484,t:1527271939787};\\\", \\\"{x:787,y:485,t:1527271939832};\\\", \\\"{x:793,y:490,t:1527271939841};\\\", \\\"{x:805,y:496,t:1527271939853};\\\", \\\"{x:825,y:505,t:1527271939870};\\\", \\\"{x:860,y:514,t:1527271939886};\\\", \\\"{x:870,y:516,t:1527271939903};\\\", \\\"{x:874,y:517,t:1527271939920};\\\", \\\"{x:874,y:518,t:1527271939937};\\\", \\\"{x:874,y:520,t:1527271940079};\\\", \\\"{x:872,y:520,t:1527271940087};\\\", \\\"{x:871,y:520,t:1527271940176};\\\", \\\"{x:870,y:520,t:1527271940200};\\\", \\\"{x:869,y:520,t:1527271940206};\\\", \\\"{x:868,y:520,t:1527271940220};\\\", \\\"{x:863,y:521,t:1527271940237};\\\", \\\"{x:860,y:521,t:1527271940254};\\\", \\\"{x:856,y:521,t:1527271940270};\\\", \\\"{x:854,y:521,t:1527271940286};\\\", \\\"{x:853,y:521,t:1527271940303};\\\", \\\"{x:852,y:521,t:1527271940326};\\\", \\\"{x:852,y:520,t:1527271940463};\\\", \\\"{x:852,y:519,t:1527271940591};\\\", \\\"{x:852,y:518,t:1527271940622};\\\", \\\"{x:852,y:517,t:1527271940638};\\\", \\\"{x:851,y:517,t:1527271940654};\\\", \\\"{x:850,y:516,t:1527271940686};\\\", \\\"{x:850,y:515,t:1527271940703};\\\", \\\"{x:848,y:514,t:1527271940720};\\\", \\\"{x:845,y:513,t:1527271940751};\\\", \\\"{x:845,y:512,t:1527271940775};\\\", \\\"{x:843,y:511,t:1527271940815};\\\", \\\"{x:837,y:510,t:1527271941374};\\\", \\\"{x:829,y:511,t:1527271941388};\\\", \\\"{x:813,y:518,t:1527271941404};\\\", \\\"{x:788,y:524,t:1527271941422};\\\", \\\"{x:716,y:541,t:1527271941438};\\\", \\\"{x:559,y:551,t:1527271941455};\\\", \\\"{x:425,y:558,t:1527271941472};\\\", \\\"{x:300,y:560,t:1527271941487};\\\", \\\"{x:189,y:559,t:1527271941504};\\\", \\\"{x:93,y:555,t:1527271941522};\\\", \\\"{x:39,y:552,t:1527271941538};\\\", \\\"{x:32,y:552,t:1527271941555};\\\", \\\"{x:24,y:554,t:1527271941571};\\\", \\\"{x:26,y:554,t:1527271941703};\\\", \\\"{x:27,y:554,t:1527271941711};\\\", \\\"{x:33,y:554,t:1527271941726};\\\", \\\"{x:42,y:554,t:1527271941739};\\\", \\\"{x:61,y:554,t:1527271941756};\\\", \\\"{x:65,y:554,t:1527271941772};\\\", \\\"{x:67,y:553,t:1527271941789};\\\", \\\"{x:69,y:553,t:1527271941886};\\\", \\\"{x:70,y:553,t:1527271941919};\\\", \\\"{x:72,y:553,t:1527271941926};\\\", \\\"{x:74,y:553,t:1527271941939};\\\", \\\"{x:75,y:553,t:1527271941956};\\\", \\\"{x:78,y:553,t:1527271941972};\\\", \\\"{x:86,y:551,t:1527271941989};\\\", \\\"{x:92,y:549,t:1527271942006};\\\", \\\"{x:98,y:547,t:1527271942022};\\\", \\\"{x:104,y:546,t:1527271942039};\\\", \\\"{x:111,y:546,t:1527271942056};\\\", \\\"{x:114,y:546,t:1527271942072};\\\", \\\"{x:115,y:546,t:1527271942089};\\\", \\\"{x:117,y:545,t:1527271942175};\\\", \\\"{x:117,y:544,t:1527271942207};\\\", \\\"{x:118,y:543,t:1527271942256};\\\", \\\"{x:121,y:540,t:1527271942272};\\\", \\\"{x:127,y:540,t:1527271942289};\\\", \\\"{x:135,y:536,t:1527271942306};\\\", \\\"{x:142,y:534,t:1527271942323};\\\", \\\"{x:144,y:534,t:1527271942339};\\\", \\\"{x:145,y:534,t:1527271942356};\\\", \\\"{x:146,y:531,t:1527271942373};\\\", \\\"{x:147,y:531,t:1527271942855};\\\", \\\"{x:151,y:532,t:1527271942863};\\\", \\\"{x:153,y:533,t:1527271942873};\\\", \\\"{x:158,y:536,t:1527271942888};\\\", \\\"{x:161,y:539,t:1527271942906};\\\", \\\"{x:162,y:541,t:1527271942923};\\\", \\\"{x:164,y:543,t:1527271943390};\\\", \\\"{x:174,y:547,t:1527271943406};\\\", \\\"{x:198,y:554,t:1527271943430};\\\", \\\"{x:242,y:566,t:1527271943441};\\\", \\\"{x:289,y:581,t:1527271943458};\\\", \\\"{x:362,y:604,t:1527271943473};\\\", \\\"{x:409,y:627,t:1527271943489};\\\", \\\"{x:445,y:639,t:1527271943507};\\\", \\\"{x:483,y:655,t:1527271943523};\\\", \\\"{x:513,y:668,t:1527271943540};\\\", \\\"{x:534,y:673,t:1527271943556};\\\", \\\"{x:548,y:678,t:1527271943573};\\\", \\\"{x:559,y:683,t:1527271943590};\\\", \\\"{x:568,y:687,t:1527271943606};\\\", \\\"{x:576,y:691,t:1527271943623};\\\", \\\"{x:584,y:697,t:1527271943640};\\\", \\\"{x:590,y:702,t:1527271943657};\\\", \\\"{x:596,y:707,t:1527271943674};\\\", \\\"{x:599,y:713,t:1527271943690};\\\", \\\"{x:606,y:718,t:1527271943707};\\\", \\\"{x:608,y:723,t:1527271943725};\\\", \\\"{x:609,y:723,t:1527271943740};\\\", \\\"{x:610,y:723,t:1527271943757};\\\", \\\"{x:611,y:723,t:1527271943775};\\\", \\\"{x:611,y:725,t:1527271943790};\\\", \\\"{x:608,y:727,t:1527271943807};\\\", \\\"{x:603,y:730,t:1527271943823};\\\", \\\"{x:590,y:734,t:1527271943841};\\\", \\\"{x:588,y:734,t:1527271943857};\\\", \\\"{x:587,y:736,t:1527271943874};\\\", \\\"{x:584,y:736,t:1527271943890};\\\", \\\"{x:580,y:735,t:1527271943907};\\\", \\\"{x:573,y:734,t:1527271943924};\\\", \\\"{x:569,y:734,t:1527271943940};\\\", \\\"{x:568,y:734,t:1527271944134};\\\", \\\"{x:566,y:734,t:1527271944142};\\\", \\\"{x:565,y:736,t:1527271944157};\\\", \\\"{x:563,y:737,t:1527271944175};\\\", \\\"{x:558,y:741,t:1527271944190};\\\", \\\"{x:553,y:742,t:1527271944207};\\\", \\\"{x:551,y:743,t:1527271944224};\\\", \\\"{x:549,y:744,t:1527271944686};\\\", \\\"{x:548,y:744,t:1527271944718};\\\", \\\"{x:548,y:745,t:1527271944774};\\\", \\\"{x:547,y:746,t:1527271944838};\\\", \\\"{x:546,y:746,t:1527271944870};\\\", \\\"{x:545,y:747,t:1527271944878};\\\", \\\"{x:544,y:749,t:1527271944910};\\\", \\\"{x:543,y:749,t:1527271944983};\\\", \\\"{x:542,y:750,t:1527271944991};\\\" ] }, { \\\"rt\\\": 31270, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 404167, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:544,y:750,t:1527271946551};\\\", \\\"{x:551,y:751,t:1527271946561};\\\", \\\"{x:567,y:753,t:1527271946579};\\\", \\\"{x:589,y:757,t:1527271946595};\\\", \\\"{x:600,y:759,t:1527271946609};\\\", \\\"{x:613,y:761,t:1527271946625};\\\", \\\"{x:630,y:764,t:1527271946641};\\\", \\\"{x:642,y:769,t:1527271946659};\\\", \\\"{x:651,y:771,t:1527271946676};\\\", \\\"{x:660,y:771,t:1527271946692};\\\", \\\"{x:668,y:774,t:1527271946709};\\\", \\\"{x:670,y:775,t:1527271946726};\\\", \\\"{x:670,y:776,t:1527271947031};\\\", \\\"{x:669,y:776,t:1527271947043};\\\", \\\"{x:667,y:777,t:1527271947303};\\\", \\\"{x:666,y:777,t:1527271947366};\\\", \\\"{x:665,y:777,t:1527271947414};\\\", \\\"{x:665,y:778,t:1527271947446};\\\", \\\"{x:664,y:778,t:1527271947559};\\\", \\\"{x:662,y:778,t:1527271948254};\\\", \\\"{x:661,y:778,t:1527271949014};\\\", \\\"{x:660,y:778,t:1527271949046};\\\", \\\"{x:659,y:778,t:1527271949478};\\\", \\\"{x:658,y:778,t:1527271949518};\\\", \\\"{x:657,y:778,t:1527271949542};\\\", \\\"{x:656,y:778,t:1527271949582};\\\", \\\"{x:655,y:778,t:1527271949595};\\\", \\\"{x:654,y:778,t:1527271949611};\\\", \\\"{x:653,y:778,t:1527271949627};\\\", \\\"{x:652,y:778,t:1527271949686};\\\", \\\"{x:651,y:778,t:1527271949695};\\\", \\\"{x:650,y:778,t:1527271949886};\\\", \\\"{x:650,y:779,t:1527271949909};\\\", \\\"{x:649,y:779,t:1527271950070};\\\", \\\"{x:649,y:780,t:1527271950214};\\\", \\\"{x:647,y:782,t:1527271950422};\\\", \\\"{x:646,y:782,t:1527271950437};\\\", \\\"{x:645,y:782,t:1527271950445};\\\", \\\"{x:644,y:783,t:1527271950462};\\\", \\\"{x:642,y:783,t:1527271950479};\\\", \\\"{x:641,y:784,t:1527271950494};\\\", \\\"{x:640,y:784,t:1527271951494};\\\", \\\"{x:640,y:785,t:1527271951502};\\\", \\\"{x:638,y:785,t:1527271951743};\\\", \\\"{x:637,y:785,t:1527271951758};\\\", \\\"{x:635,y:785,t:1527271951767};\\\", \\\"{x:634,y:785,t:1527271951783};\\\", \\\"{x:632,y:785,t:1527271951796};\\\", \\\"{x:631,y:787,t:1527271951814};\\\", \\\"{x:630,y:787,t:1527271951831};\\\", \\\"{x:628,y:787,t:1527271953248};\\\", \\\"{x:628,y:788,t:1527271953734};\\\", \\\"{x:627,y:788,t:1527271954055};\\\", \\\"{x:626,y:788,t:1527271954183};\\\", \\\"{x:625,y:788,t:1527271954567};\\\", \\\"{x:624,y:789,t:1527271956159};\\\", \\\"{x:622,y:791,t:1527271956166};\\\", \\\"{x:619,y:791,t:1527271956184};\\\", \\\"{x:614,y:791,t:1527271956201};\\\", \\\"{x:611,y:791,t:1527271956217};\\\", \\\"{x:609,y:791,t:1527271956262};\\\", \\\"{x:608,y:791,t:1527271958832};\\\", \\\"{x:605,y:791,t:1527271958847};\\\", \\\"{x:604,y:791,t:1527271958903};\\\", \\\"{x:601,y:791,t:1527271960903};\\\", \\\"{x:599,y:791,t:1527271966614};\\\", \\\"{x:598,y:791,t:1527271967575};\\\", \\\"{x:593,y:788,t:1527271974214};\\\", \\\"{x:542,y:776,t:1527271974231};\\\", \\\"{x:474,y:767,t:1527271974248};\\\", \\\"{x:464,y:766,t:1527271974264};\\\", \\\"{x:399,y:746,t:1527271974281};\\\", \\\"{x:273,y:721,t:1527271974298};\\\", \\\"{x:165,y:689,t:1527271974314};\\\", \\\"{x:69,y:665,t:1527271974331};\\\", \\\"{x:21,y:652,t:1527271974348};\\\", \\\"{x:4,y:647,t:1527271974364};\\\", \\\"{x:0,y:644,t:1527271974381};\\\", \\\"{x:0,y:642,t:1527271974414};\\\", \\\"{x:0,y:639,t:1527271974421};\\\", \\\"{x:0,y:636,t:1527271974431};\\\", \\\"{x:0,y:628,t:1527271974448};\\\", \\\"{x:0,y:622,t:1527271974465};\\\", \\\"{x:0,y:617,t:1527271974481};\\\", \\\"{x:3,y:609,t:1527271974498};\\\", \\\"{x:17,y:597,t:1527271974515};\\\", \\\"{x:32,y:588,t:1527271974530};\\\", \\\"{x:49,y:579,t:1527271974548};\\\", \\\"{x:76,y:565,t:1527271974565};\\\", \\\"{x:99,y:558,t:1527271974581};\\\", \\\"{x:111,y:561,t:1527271974598};\\\", \\\"{x:120,y:562,t:1527271974615};\\\", \\\"{x:136,y:553,t:1527271974633};\\\", \\\"{x:140,y:553,t:1527271974648};\\\", \\\"{x:150,y:548,t:1527271974665};\\\", \\\"{x:153,y:548,t:1527271974682};\\\", \\\"{x:155,y:546,t:1527271974698};\\\", \\\"{x:156,y:545,t:1527271974782};\\\", \\\"{x:160,y:542,t:1527271974798};\\\", \\\"{x:165,y:541,t:1527271974815};\\\", \\\"{x:178,y:538,t:1527271974832};\\\", \\\"{x:186,y:538,t:1527271974848};\\\", \\\"{x:196,y:539,t:1527271974865};\\\", \\\"{x:214,y:539,t:1527271974882};\\\", \\\"{x:230,y:535,t:1527271974899};\\\", \\\"{x:240,y:532,t:1527271974915};\\\", \\\"{x:243,y:530,t:1527271974932};\\\", \\\"{x:245,y:529,t:1527271974949};\\\", \\\"{x:246,y:528,t:1527271974964};\\\", \\\"{x:249,y:525,t:1527271974982};\\\", \\\"{x:259,y:521,t:1527271974999};\\\", \\\"{x:272,y:515,t:1527271975016};\\\", \\\"{x:292,y:509,t:1527271975033};\\\", \\\"{x:312,y:504,t:1527271975049};\\\", \\\"{x:343,y:493,t:1527271975065};\\\", \\\"{x:374,y:485,t:1527271975082};\\\", \\\"{x:401,y:478,t:1527271975099};\\\", \\\"{x:427,y:477,t:1527271975115};\\\", \\\"{x:458,y:472,t:1527271975132};\\\", \\\"{x:488,y:471,t:1527271975148};\\\", \\\"{x:514,y:466,t:1527271975166};\\\", \\\"{x:523,y:466,t:1527271975181};\\\", \\\"{x:535,y:466,t:1527271975199};\\\", \\\"{x:541,y:466,t:1527271975216};\\\", \\\"{x:549,y:466,t:1527271975231};\\\", \\\"{x:553,y:468,t:1527271975249};\\\", \\\"{x:554,y:468,t:1527271975302};\\\", \\\"{x:555,y:469,t:1527271975316};\\\", \\\"{x:561,y:473,t:1527271975332};\\\", \\\"{x:566,y:477,t:1527271975349};\\\", \\\"{x:572,y:480,t:1527271975366};\\\", \\\"{x:573,y:481,t:1527271975382};\\\", \\\"{x:573,y:482,t:1527271975399};\\\", \\\"{x:574,y:482,t:1527271975416};\\\", \\\"{x:576,y:484,t:1527271975433};\\\", \\\"{x:577,y:487,t:1527271975449};\\\", \\\"{x:581,y:489,t:1527271975466};\\\", \\\"{x:587,y:495,t:1527271975482};\\\", \\\"{x:589,y:496,t:1527271975499};\\\", \\\"{x:591,y:498,t:1527271975516};\\\", \\\"{x:593,y:500,t:1527271975532};\\\", \\\"{x:594,y:500,t:1527271975598};\\\", \\\"{x:595,y:502,t:1527271975605};\\\", \\\"{x:597,y:503,t:1527271975616};\\\", \\\"{x:599,y:506,t:1527271975632};\\\", \\\"{x:602,y:507,t:1527271975649};\\\", \\\"{x:602,y:507,t:1527271975807};\\\", \\\"{x:602,y:508,t:1527271975910};\\\", \\\"{x:601,y:509,t:1527271975918};\\\", \\\"{x:598,y:516,t:1527271975933};\\\", \\\"{x:593,y:528,t:1527271975949};\\\", \\\"{x:586,y:546,t:1527271975966};\\\", \\\"{x:577,y:569,t:1527271975983};\\\", \\\"{x:562,y:595,t:1527271976000};\\\", \\\"{x:551,y:617,t:1527271976016};\\\", \\\"{x:541,y:634,t:1527271976034};\\\", \\\"{x:528,y:656,t:1527271976049};\\\", \\\"{x:515,y:675,t:1527271976066};\\\", \\\"{x:507,y:688,t:1527271976083};\\\", \\\"{x:501,y:702,t:1527271976099};\\\", \\\"{x:495,y:715,t:1527271976116};\\\", \\\"{x:491,y:725,t:1527271976133};\\\", \\\"{x:486,y:742,t:1527271976150};\\\", \\\"{x:484,y:746,t:1527271976165};\\\", \\\"{x:481,y:755,t:1527271976184};\\\", \\\"{x:480,y:758,t:1527271976199};\\\", \\\"{x:480,y:762,t:1527271976216};\\\", \\\"{x:480,y:764,t:1527271976233};\\\", \\\"{x:479,y:767,t:1527271976250};\\\", \\\"{x:479,y:768,t:1527271976269};\\\", \\\"{x:479,y:770,t:1527271976310};\\\", \\\"{x:479,y:767,t:1527271976613};\\\", \\\"{x:479,y:764,t:1527271976622};\\\", \\\"{x:479,y:761,t:1527271976633};\\\", \\\"{x:479,y:758,t:1527271976650};\\\", \\\"{x:479,y:754,t:1527271976667};\\\", \\\"{x:479,y:751,t:1527271976683};\\\", \\\"{x:479,y:750,t:1527271976700};\\\", \\\"{x:478,y:749,t:1527271977430};\\\", \\\"{x:476,y:748,t:1527271977437};\\\", \\\"{x:476,y:747,t:1527271977450};\\\", \\\"{x:475,y:747,t:1527271977467};\\\", \\\"{x:474,y:747,t:1527271977484};\\\", \\\"{x:473,y:747,t:1527271977502};\\\", \\\"{x:472,y:747,t:1527271977518};\\\", \\\"{x:470,y:747,t:1527271977534};\\\", \\\"{x:463,y:747,t:1527271977551};\\\", \\\"{x:456,y:747,t:1527271977567};\\\", \\\"{x:451,y:747,t:1527271977584};\\\", \\\"{x:439,y:747,t:1527271977601};\\\", \\\"{x:430,y:748,t:1527271977617};\\\", \\\"{x:420,y:749,t:1527271977634};\\\", \\\"{x:411,y:752,t:1527271977651};\\\", \\\"{x:406,y:753,t:1527271977667};\\\", \\\"{x:404,y:753,t:1527271977684};\\\", \\\"{x:400,y:753,t:1527271977701};\\\", \\\"{x:398,y:753,t:1527271977717};\\\", \\\"{x:396,y:755,t:1527271977734};\\\", \\\"{x:394,y:755,t:1527271977773};\\\", \\\"{x:391,y:756,t:1527271977798};\\\", \\\"{x:390,y:756,t:1527271977806};\\\", \\\"{x:389,y:757,t:1527271977816};\\\", \\\"{x:386,y:758,t:1527271977834};\\\", \\\"{x:384,y:758,t:1527271977851};\\\", \\\"{x:383,y:759,t:1527271977878};\\\", \\\"{x:382,y:759,t:1527271977925};\\\", \\\"{x:381,y:759,t:1527271977949};\\\", \\\"{x:381,y:760,t:1527271977958};\\\", \\\"{x:378,y:760,t:1527271977973};\\\", \\\"{x:377,y:760,t:1527271977998};\\\", \\\"{x:376,y:761,t:1527271978014};\\\", \\\"{x:374,y:761,t:1527271978029};\\\", \\\"{x:372,y:761,t:1527271978049};\\\", \\\"{x:370,y:762,t:1527271978068};\\\", \\\"{x:368,y:762,t:1527271978084};\\\", \\\"{x:366,y:762,t:1527271978101};\\\", \\\"{x:363,y:763,t:1527271978133};\\\" ] }, { \\\"rt\\\": 20710, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 426083, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:355,y:765,t:1527271978237};\\\", \\\"{x:354,y:765,t:1527271978251};\\\", \\\"{x:352,y:766,t:1527271978268};\\\", \\\"{x:351,y:766,t:1527271978284};\\\", \\\"{x:348,y:767,t:1527271978331};\\\", \\\"{x:347,y:768,t:1527271978351};\\\", \\\"{x:346,y:768,t:1527271978421};\\\", \\\"{x:345,y:768,t:1527271978437};\\\", \\\"{x:344,y:768,t:1527271978485};\\\", \\\"{x:343,y:769,t:1527271978695};\\\", \\\"{x:342,y:769,t:1527271978702};\\\", \\\"{x:341,y:769,t:1527271978765};\\\", \\\"{x:339,y:771,t:1527271979126};\\\", \\\"{x:338,y:771,t:1527271979135};\\\", \\\"{x:336,y:771,t:1527271979152};\\\", \\\"{x:335,y:771,t:1527271979169};\\\", \\\"{x:334,y:771,t:1527271979189};\\\", \\\"{x:333,y:771,t:1527271979202};\\\", \\\"{x:332,y:771,t:1527271979219};\\\", \\\"{x:330,y:772,t:1527271980502};\\\", \\\"{x:329,y:772,t:1527271980509};\\\", \\\"{x:327,y:772,t:1527271980520};\\\", \\\"{x:321,y:773,t:1527271980536};\\\", \\\"{x:320,y:773,t:1527271980678};\\\", \\\"{x:319,y:773,t:1527271980709};\\\", \\\"{x:318,y:774,t:1527271980741};\\\", \\\"{x:316,y:775,t:1527271980753};\\\", \\\"{x:315,y:775,t:1527271981182};\\\", \\\"{x:313,y:776,t:1527271981206};\\\", \\\"{x:312,y:776,t:1527271981220};\\\", \\\"{x:310,y:776,t:1527271981237};\\\", \\\"{x:308,y:778,t:1527271981253};\\\", \\\"{x:307,y:778,t:1527271981270};\\\", \\\"{x:306,y:778,t:1527271986366};\\\", \\\"{x:305,y:778,t:1527271986413};\\\", \\\"{x:300,y:776,t:1527271986424};\\\", \\\"{x:293,y:773,t:1527271986442};\\\", \\\"{x:287,y:768,t:1527271986458};\\\", \\\"{x:281,y:764,t:1527271986475};\\\", \\\"{x:277,y:760,t:1527271986491};\\\", \\\"{x:274,y:756,t:1527271986507};\\\", \\\"{x:272,y:750,t:1527271986524};\\\", \\\"{x:268,y:736,t:1527271986541};\\\", \\\"{x:267,y:732,t:1527271986558};\\\", \\\"{x:265,y:721,t:1527271986575};\\\", \\\"{x:265,y:709,t:1527271986591};\\\", \\\"{x:265,y:701,t:1527271986608};\\\", \\\"{x:264,y:693,t:1527271986624};\\\", \\\"{x:265,y:679,t:1527271986642};\\\", \\\"{x:269,y:662,t:1527271986659};\\\", \\\"{x:271,y:651,t:1527271986674};\\\", \\\"{x:277,y:633,t:1527271986692};\\\", \\\"{x:279,y:623,t:1527271986709};\\\", \\\"{x:279,y:616,t:1527271986725};\\\", \\\"{x:282,y:599,t:1527271986741};\\\", \\\"{x:284,y:588,t:1527271986759};\\\", \\\"{x:289,y:580,t:1527271986774};\\\", \\\"{x:289,y:575,t:1527271986791};\\\", \\\"{x:290,y:571,t:1527271986838};\\\", \\\"{x:291,y:571,t:1527271986997};\\\", \\\"{x:293,y:571,t:1527271987008};\\\", \\\"{x:292,y:571,t:1527271987109};\\\", \\\"{x:290,y:572,t:1527271987125};\\\", \\\"{x:287,y:573,t:1527271987141};\\\", \\\"{x:289,y:573,t:1527271987542};\\\", \\\"{x:300,y:570,t:1527271987559};\\\", \\\"{x:320,y:562,t:1527271987576};\\\", \\\"{x:332,y:557,t:1527271987593};\\\", \\\"{x:358,y:550,t:1527271987609};\\\", \\\"{x:381,y:540,t:1527271987625};\\\", \\\"{x:401,y:530,t:1527271987642};\\\", \\\"{x:414,y:520,t:1527271987659};\\\", \\\"{x:432,y:509,t:1527271987677};\\\", \\\"{x:456,y:499,t:1527271987693};\\\", \\\"{x:485,y:483,t:1527271987709};\\\", \\\"{x:564,y:467,t:1527271987725};\\\", \\\"{x:647,y:457,t:1527271987743};\\\", \\\"{x:723,y:454,t:1527271987759};\\\", \\\"{x:808,y:448,t:1527271987775};\\\", \\\"{x:872,y:448,t:1527271987792};\\\", \\\"{x:938,y:448,t:1527271987809};\\\", \\\"{x:1000,y:448,t:1527271987825};\\\", \\\"{x:1039,y:451,t:1527271987843};\\\", \\\"{x:1101,y:453,t:1527271987860};\\\", \\\"{x:1150,y:466,t:1527271987876};\\\", \\\"{x:1193,y:473,t:1527271987892};\\\", \\\"{x:1240,y:479,t:1527271987909};\\\", \\\"{x:1265,y:481,t:1527271987925};\\\", \\\"{x:1293,y:487,t:1527271987942};\\\", \\\"{x:1323,y:496,t:1527271987960};\\\", \\\"{x:1360,y:507,t:1527271987975};\\\", \\\"{x:1393,y:513,t:1527271987992};\\\", \\\"{x:1428,y:525,t:1527271988009};\\\", \\\"{x:1465,y:539,t:1527271988026};\\\", \\\"{x:1498,y:550,t:1527271988042};\\\", \\\"{x:1544,y:569,t:1527271988060};\\\", \\\"{x:1604,y:591,t:1527271988075};\\\", \\\"{x:1667,y:616,t:1527271988093};\\\", \\\"{x:1710,y:642,t:1527271988109};\\\", \\\"{x:1729,y:654,t:1527271988126};\\\", \\\"{x:1736,y:660,t:1527271988142};\\\", \\\"{x:1740,y:667,t:1527271988160};\\\", \\\"{x:1741,y:668,t:1527271988176};\\\", \\\"{x:1741,y:669,t:1527271988192};\\\", \\\"{x:1741,y:671,t:1527271988209};\\\", \\\"{x:1738,y:675,t:1527271988227};\\\", \\\"{x:1731,y:680,t:1527271988242};\\\", \\\"{x:1726,y:684,t:1527271988260};\\\", \\\"{x:1722,y:688,t:1527271988276};\\\", \\\"{x:1714,y:694,t:1527271988292};\\\", \\\"{x:1706,y:700,t:1527271988309};\\\", \\\"{x:1701,y:703,t:1527271988326};\\\", \\\"{x:1695,y:707,t:1527271988343};\\\", \\\"{x:1692,y:708,t:1527271988360};\\\", \\\"{x:1690,y:709,t:1527271988377};\\\", \\\"{x:1689,y:710,t:1527271988392};\\\", \\\"{x:1687,y:711,t:1527271988409};\\\", \\\"{x:1686,y:711,t:1527271988426};\\\", \\\"{x:1683,y:713,t:1527271988442};\\\", \\\"{x:1681,y:714,t:1527271988459};\\\", \\\"{x:1676,y:717,t:1527271988477};\\\", \\\"{x:1667,y:722,t:1527271988493};\\\", \\\"{x:1651,y:724,t:1527271988509};\\\", \\\"{x:1646,y:727,t:1527271988526};\\\", \\\"{x:1642,y:728,t:1527271988544};\\\", \\\"{x:1638,y:730,t:1527271988559};\\\", \\\"{x:1633,y:731,t:1527271988577};\\\", \\\"{x:1631,y:733,t:1527271988593};\\\", \\\"{x:1627,y:734,t:1527271988610};\\\", \\\"{x:1626,y:734,t:1527271988626};\\\", \\\"{x:1623,y:734,t:1527271988644};\\\", \\\"{x:1621,y:737,t:1527271988660};\\\", \\\"{x:1620,y:737,t:1527271988677};\\\", \\\"{x:1618,y:737,t:1527271988694};\\\", \\\"{x:1617,y:737,t:1527271988709};\\\", \\\"{x:1616,y:737,t:1527271988727};\\\", \\\"{x:1615,y:738,t:1527271988750};\\\", \\\"{x:1614,y:738,t:1527271988790};\\\", \\\"{x:1613,y:738,t:1527271988797};\\\", \\\"{x:1612,y:739,t:1527271988810};\\\", \\\"{x:1612,y:740,t:1527271988827};\\\", \\\"{x:1610,y:742,t:1527271988843};\\\", \\\"{x:1606,y:744,t:1527271988859};\\\", \\\"{x:1604,y:744,t:1527271988877};\\\", \\\"{x:1601,y:744,t:1527271988894};\\\", \\\"{x:1599,y:745,t:1527271988910};\\\", \\\"{x:1598,y:745,t:1527271988950};\\\", \\\"{x:1593,y:748,t:1527271989246};\\\", \\\"{x:1591,y:749,t:1527271989260};\\\", \\\"{x:1585,y:752,t:1527271989277};\\\", \\\"{x:1568,y:757,t:1527271989294};\\\", \\\"{x:1557,y:762,t:1527271989311};\\\", \\\"{x:1549,y:767,t:1527271989327};\\\", \\\"{x:1538,y:774,t:1527271989344};\\\", \\\"{x:1527,y:785,t:1527271989361};\\\", \\\"{x:1500,y:813,t:1527271989377};\\\", \\\"{x:1489,y:823,t:1527271989393};\\\", \\\"{x:1467,y:849,t:1527271989411};\\\", \\\"{x:1442,y:876,t:1527271989428};\\\", \\\"{x:1416,y:902,t:1527271989444};\\\", \\\"{x:1392,y:921,t:1527271989461};\\\", \\\"{x:1375,y:931,t:1527271989477};\\\", \\\"{x:1368,y:933,t:1527271989493};\\\", \\\"{x:1366,y:934,t:1527271989511};\\\", \\\"{x:1364,y:934,t:1527271989528};\\\", \\\"{x:1363,y:934,t:1527271989581};\\\", \\\"{x:1359,y:934,t:1527271989645};\\\", \\\"{x:1354,y:927,t:1527271989660};\\\", \\\"{x:1346,y:906,t:1527271989677};\\\", \\\"{x:1322,y:882,t:1527271989695};\\\", \\\"{x:1303,y:856,t:1527271989710};\\\", \\\"{x:1284,y:835,t:1527271989727};\\\", \\\"{x:1267,y:820,t:1527271989745};\\\", \\\"{x:1254,y:810,t:1527271989760};\\\", \\\"{x:1245,y:801,t:1527271989778};\\\", \\\"{x:1239,y:798,t:1527271989795};\\\", \\\"{x:1234,y:798,t:1527271989811};\\\", \\\"{x:1232,y:798,t:1527271989827};\\\", \\\"{x:1230,y:798,t:1527271989894};\\\", \\\"{x:1228,y:798,t:1527271989901};\\\", \\\"{x:1226,y:800,t:1527271989911};\\\", \\\"{x:1224,y:804,t:1527271989928};\\\", \\\"{x:1220,y:814,t:1527271989945};\\\", \\\"{x:1215,y:824,t:1527271989961};\\\", \\\"{x:1210,y:835,t:1527271989978};\\\", \\\"{x:1207,y:843,t:1527271989994};\\\", \\\"{x:1204,y:847,t:1527271990011};\\\", \\\"{x:1203,y:850,t:1527271990028};\\\", \\\"{x:1201,y:852,t:1527271990044};\\\", \\\"{x:1199,y:854,t:1527271990069};\\\", \\\"{x:1198,y:853,t:1527271990430};\\\", \\\"{x:1197,y:850,t:1527271990445};\\\", \\\"{x:1193,y:841,t:1527271990461};\\\", \\\"{x:1191,y:838,t:1527271990479};\\\", \\\"{x:1191,y:836,t:1527271990495};\\\", \\\"{x:1189,y:833,t:1527271990629};\\\", \\\"{x:1189,y:832,t:1527271990644};\\\", \\\"{x:1188,y:824,t:1527271990662};\\\", \\\"{x:1184,y:812,t:1527271990678};\\\", \\\"{x:1181,y:800,t:1527271990694};\\\", \\\"{x:1179,y:790,t:1527271990712};\\\", \\\"{x:1178,y:785,t:1527271990728};\\\", \\\"{x:1176,y:783,t:1527271990744};\\\", \\\"{x:1176,y:782,t:1527271990773};\\\", \\\"{x:1176,y:781,t:1527271991022};\\\", \\\"{x:1175,y:779,t:1527271991029};\\\", \\\"{x:1172,y:773,t:1527271991045};\\\", \\\"{x:1170,y:768,t:1527271991062};\\\", \\\"{x:1167,y:764,t:1527271991079};\\\", \\\"{x:1166,y:761,t:1527271991096};\\\", \\\"{x:1165,y:758,t:1527271991111};\\\", \\\"{x:1164,y:757,t:1527271991129};\\\", \\\"{x:1162,y:757,t:1527271991494};\\\", \\\"{x:1156,y:757,t:1527271991501};\\\", \\\"{x:1151,y:758,t:1527271991513};\\\", \\\"{x:1136,y:760,t:1527271991529};\\\", \\\"{x:1122,y:763,t:1527271991545};\\\", \\\"{x:1112,y:764,t:1527271991563};\\\", \\\"{x:1108,y:764,t:1527271991580};\\\", \\\"{x:1106,y:764,t:1527271991595};\\\", \\\"{x:1106,y:763,t:1527271991957};\\\", \\\"{x:1107,y:763,t:1527271991973};\\\", \\\"{x:1108,y:762,t:1527271991989};\\\", \\\"{x:1109,y:762,t:1527271992037};\\\", \\\"{x:1110,y:762,t:1527271992046};\\\", \\\"{x:1111,y:761,t:1527271992062};\\\", \\\"{x:1111,y:760,t:1527271992102};\\\", \\\"{x:1112,y:759,t:1527271992113};\\\", \\\"{x:1115,y:759,t:1527271992130};\\\", \\\"{x:1122,y:759,t:1527271992146};\\\", \\\"{x:1124,y:758,t:1527271992163};\\\", \\\"{x:1125,y:758,t:1527271992180};\\\", \\\"{x:1126,y:758,t:1527271992341};\\\", \\\"{x:1127,y:758,t:1527271992358};\\\", \\\"{x:1129,y:758,t:1527271992366};\\\", \\\"{x:1129,y:759,t:1527271992380};\\\", \\\"{x:1131,y:761,t:1527271992398};\\\", \\\"{x:1132,y:761,t:1527271992430};\\\", \\\"{x:1132,y:762,t:1527271992521};\\\", \\\"{x:1135,y:764,t:1527271992534};\\\", \\\"{x:1139,y:767,t:1527271992550};\\\", \\\"{x:1142,y:768,t:1527271992568};\\\", \\\"{x:1144,y:769,t:1527271992584};\\\", \\\"{x:1145,y:770,t:1527271992600};\\\", \\\"{x:1146,y:770,t:1527271992617};\\\", \\\"{x:1147,y:771,t:1527271992640};\\\", \\\"{x:1148,y:772,t:1527271992657};\\\", \\\"{x:1150,y:772,t:1527271992667};\\\", \\\"{x:1150,y:773,t:1527271992683};\\\", \\\"{x:1150,y:774,t:1527271992864};\\\", \\\"{x:1150,y:775,t:1527271992873};\\\", \\\"{x:1150,y:776,t:1527271992888};\\\", \\\"{x:1149,y:777,t:1527271992904};\\\", \\\"{x:1149,y:778,t:1527271993232};\\\", \\\"{x:1148,y:779,t:1527271993240};\\\", \\\"{x:1147,y:781,t:1527271993256};\\\", \\\"{x:1146,y:781,t:1527271993273};\\\", \\\"{x:1145,y:783,t:1527271993284};\\\", \\\"{x:1142,y:783,t:1527271993301};\\\", \\\"{x:1141,y:784,t:1527271993317};\\\", \\\"{x:1139,y:786,t:1527271993553};\\\", \\\"{x:1138,y:786,t:1527271993577};\\\", \\\"{x:1137,y:786,t:1527271993600};\\\", \\\"{x:1136,y:787,t:1527271993609};\\\", \\\"{x:1135,y:787,t:1527271993618};\\\", \\\"{x:1134,y:787,t:1527271993640};\\\", \\\"{x:1132,y:787,t:1527271993833};\\\", \\\"{x:1130,y:787,t:1527271993857};\\\", \\\"{x:1129,y:788,t:1527271993873};\\\", \\\"{x:1124,y:789,t:1527271993896};\\\", \\\"{x:1123,y:789,t:1527271993912};\\\", \\\"{x:1121,y:790,t:1527271993920};\\\", \\\"{x:1119,y:790,t:1527271993936};\\\", \\\"{x:1117,y:790,t:1527271993951};\\\", \\\"{x:1114,y:790,t:1527271993968};\\\", \\\"{x:1112,y:790,t:1527271993984};\\\", \\\"{x:1110,y:790,t:1527271994001};\\\", \\\"{x:1108,y:791,t:1527271994018};\\\", \\\"{x:1107,y:792,t:1527271994113};\\\", \\\"{x:1105,y:792,t:1527271994145};\\\", \\\"{x:1104,y:792,t:1527271994160};\\\", \\\"{x:1102,y:792,t:1527271994169};\\\", \\\"{x:1101,y:793,t:1527271994193};\\\", \\\"{x:1100,y:793,t:1527271994209};\\\", \\\"{x:1099,y:793,t:1527271994248};\\\", \\\"{x:1098,y:793,t:1527271994265};\\\", \\\"{x:1097,y:793,t:1527271994272};\\\", \\\"{x:1096,y:793,t:1527271994285};\\\", \\\"{x:1095,y:793,t:1527271994433};\\\", \\\"{x:1093,y:793,t:1527271995161};\\\", \\\"{x:1091,y:793,t:1527271995169};\\\", \\\"{x:1087,y:793,t:1527271995186};\\\", \\\"{x:1084,y:794,t:1527271995202};\\\", \\\"{x:1080,y:795,t:1527271995219};\\\", \\\"{x:1075,y:795,t:1527271995236};\\\", \\\"{x:1072,y:795,t:1527271995253};\\\", \\\"{x:1071,y:795,t:1527271995269};\\\", \\\"{x:1070,y:795,t:1527271995286};\\\", \\\"{x:1069,y:795,t:1527271995408};\\\", \\\"{x:1068,y:795,t:1527271995425};\\\", \\\"{x:1067,y:795,t:1527271995436};\\\", \\\"{x:1064,y:795,t:1527271995453};\\\", \\\"{x:1062,y:795,t:1527271995469};\\\", \\\"{x:1061,y:795,t:1527271995487};\\\", \\\"{x:1060,y:795,t:1527271995512};\\\", \\\"{x:1059,y:795,t:1527271995520};\\\", \\\"{x:1059,y:794,t:1527271995536};\\\", \\\"{x:1053,y:793,t:1527271995553};\\\", \\\"{x:1045,y:791,t:1527271995569};\\\", \\\"{x:1031,y:790,t:1527271995587};\\\", \\\"{x:1024,y:788,t:1527271995603};\\\", \\\"{x:1013,y:785,t:1527271995619};\\\", \\\"{x:1002,y:779,t:1527271995636};\\\", \\\"{x:994,y:776,t:1527271995654};\\\", \\\"{x:989,y:775,t:1527271995670};\\\", \\\"{x:986,y:774,t:1527271995686};\\\", \\\"{x:982,y:772,t:1527271995704};\\\", \\\"{x:979,y:771,t:1527271995719};\\\", \\\"{x:973,y:769,t:1527271995736};\\\", \\\"{x:969,y:768,t:1527271995753};\\\", \\\"{x:966,y:767,t:1527271995770};\\\", \\\"{x:963,y:767,t:1527271995786};\\\", \\\"{x:959,y:765,t:1527271995804};\\\", \\\"{x:958,y:765,t:1527271995820};\\\", \\\"{x:956,y:765,t:1527271995836};\\\", \\\"{x:955,y:764,t:1527271995853};\\\", \\\"{x:952,y:763,t:1527271995870};\\\", \\\"{x:950,y:762,t:1527271995889};\\\", \\\"{x:949,y:761,t:1527271995913};\\\", \\\"{x:947,y:761,t:1527271995928};\\\", \\\"{x:944,y:761,t:1527271995944};\\\", \\\"{x:943,y:761,t:1527271995953};\\\", \\\"{x:942,y:760,t:1527271995970};\\\", \\\"{x:941,y:760,t:1527271996001};\\\", \\\"{x:940,y:760,t:1527271996017};\\\", \\\"{x:938,y:760,t:1527271996024};\\\", \\\"{x:936,y:758,t:1527271996036};\\\", \\\"{x:928,y:758,t:1527271996053};\\\", \\\"{x:917,y:756,t:1527271996071};\\\", \\\"{x:910,y:754,t:1527271996086};\\\", \\\"{x:901,y:751,t:1527271996103};\\\", \\\"{x:893,y:750,t:1527271996120};\\\", \\\"{x:886,y:746,t:1527271996136};\\\", \\\"{x:884,y:745,t:1527271996154};\\\", \\\"{x:882,y:744,t:1527271996170};\\\", \\\"{x:876,y:741,t:1527271996187};\\\", \\\"{x:868,y:739,t:1527271996203};\\\", \\\"{x:861,y:736,t:1527271996220};\\\", \\\"{x:858,y:735,t:1527271996237};\\\", \\\"{x:854,y:733,t:1527271996253};\\\", \\\"{x:848,y:728,t:1527271996270};\\\", \\\"{x:838,y:720,t:1527271996287};\\\", \\\"{x:824,y:713,t:1527271996303};\\\", \\\"{x:811,y:708,t:1527271996320};\\\", \\\"{x:774,y:689,t:1527271996338};\\\", \\\"{x:750,y:679,t:1527271996353};\\\", \\\"{x:734,y:672,t:1527271996370};\\\", \\\"{x:714,y:665,t:1527271996387};\\\", \\\"{x:710,y:663,t:1527271996403};\\\", \\\"{x:708,y:661,t:1527271996420};\\\", \\\"{x:706,y:659,t:1527271996480};\\\", \\\"{x:702,y:658,t:1527271996489};\\\", \\\"{x:698,y:656,t:1527271996503};\\\", \\\"{x:680,y:648,t:1527271996520};\\\", \\\"{x:659,y:631,t:1527271996538};\\\", \\\"{x:630,y:622,t:1527271996554};\\\", \\\"{x:617,y:616,t:1527271996566};\\\", \\\"{x:595,y:603,t:1527271996584};\\\", \\\"{x:578,y:593,t:1527271996600};\\\", \\\"{x:554,y:580,t:1527271996616};\\\", \\\"{x:545,y:576,t:1527271996637};\\\", \\\"{x:535,y:571,t:1527271996653};\\\", \\\"{x:523,y:568,t:1527271996669};\\\", \\\"{x:508,y:563,t:1527271996686};\\\", \\\"{x:497,y:560,t:1527271996704};\\\", \\\"{x:483,y:556,t:1527271996719};\\\", \\\"{x:472,y:555,t:1527271996737};\\\", \\\"{x:449,y:551,t:1527271996753};\\\", \\\"{x:441,y:548,t:1527271996769};\\\", \\\"{x:429,y:546,t:1527271996786};\\\", \\\"{x:417,y:545,t:1527271996804};\\\", \\\"{x:412,y:545,t:1527271996819};\\\", \\\"{x:399,y:543,t:1527271996836};\\\", \\\"{x:385,y:541,t:1527271996853};\\\", \\\"{x:371,y:538,t:1527271996871};\\\", \\\"{x:355,y:533,t:1527271996886};\\\", \\\"{x:333,y:528,t:1527271996903};\\\", \\\"{x:305,y:522,t:1527271996920};\\\", \\\"{x:266,y:513,t:1527271996937};\\\", \\\"{x:240,y:508,t:1527271996954};\\\", \\\"{x:218,y:505,t:1527271996970};\\\", \\\"{x:201,y:502,t:1527271996987};\\\", \\\"{x:191,y:501,t:1527271997003};\\\", \\\"{x:186,y:500,t:1527271997020};\\\", \\\"{x:185,y:500,t:1527271997036};\\\", \\\"{x:184,y:500,t:1527271997072};\\\", \\\"{x:183,y:500,t:1527271997129};\\\", \\\"{x:182,y:500,t:1527271997161};\\\", \\\"{x:181,y:500,t:1527271997176};\\\", \\\"{x:179,y:500,t:1527271997186};\\\", \\\"{x:176,y:500,t:1527271997203};\\\", \\\"{x:173,y:500,t:1527271997221};\\\", \\\"{x:169,y:500,t:1527271997237};\\\", \\\"{x:165,y:500,t:1527271997254};\\\", \\\"{x:162,y:500,t:1527271997270};\\\", \\\"{x:161,y:500,t:1527271997287};\\\", \\\"{x:160,y:500,t:1527271997303};\\\", \\\"{x:159,y:500,t:1527271997337};\\\", \\\"{x:158,y:500,t:1527271997360};\\\", \\\"{x:157,y:500,t:1527271997600};\\\", \\\"{x:159,y:500,t:1527271997961};\\\", \\\"{x:164,y:500,t:1527271997970};\\\", \\\"{x:177,y:504,t:1527271997987};\\\", \\\"{x:188,y:509,t:1527271998004};\\\", \\\"{x:195,y:514,t:1527271998020};\\\", \\\"{x:200,y:519,t:1527271998038};\\\", \\\"{x:206,y:526,t:1527271998055};\\\", \\\"{x:213,y:535,t:1527271998071};\\\", \\\"{x:222,y:545,t:1527271998087};\\\", \\\"{x:236,y:557,t:1527271998105};\\\", \\\"{x:244,y:563,t:1527271998121};\\\", \\\"{x:252,y:569,t:1527271998137};\\\", \\\"{x:256,y:573,t:1527271998154};\\\", \\\"{x:259,y:577,t:1527271998171};\\\", \\\"{x:262,y:579,t:1527271998188};\\\", \\\"{x:267,y:581,t:1527271998204};\\\", \\\"{x:274,y:586,t:1527271998221};\\\", \\\"{x:288,y:594,t:1527271998238};\\\", \\\"{x:308,y:604,t:1527271998254};\\\", \\\"{x:321,y:615,t:1527271998271};\\\", \\\"{x:330,y:620,t:1527271998287};\\\", \\\"{x:374,y:639,t:1527271998305};\\\", \\\"{x:388,y:650,t:1527271998321};\\\", \\\"{x:395,y:652,t:1527271998337};\\\", \\\"{x:395,y:653,t:1527271998384};\\\", \\\"{x:396,y:653,t:1527271998393};\\\", \\\"{x:398,y:656,t:1527271998424};\\\", \\\"{x:403,y:660,t:1527271998437};\\\", \\\"{x:410,y:676,t:1527271998455};\\\", \\\"{x:420,y:694,t:1527271998472};\\\", \\\"{x:429,y:704,t:1527271998488};\\\", \\\"{x:435,y:713,t:1527271998505};\\\", \\\"{x:440,y:721,t:1527271998522};\\\", \\\"{x:446,y:724,t:1527271998538};\\\", \\\"{x:447,y:726,t:1527271998554};\\\", \\\"{x:449,y:726,t:1527271998585};\\\", \\\"{x:450,y:726,t:1527271998609};\\\", \\\"{x:451,y:726,t:1527271998621};\\\", \\\"{x:453,y:726,t:1527271998640};\\\", \\\"{x:455,y:726,t:1527271998656};\\\", \\\"{x:456,y:726,t:1527271998671};\\\", \\\"{x:462,y:731,t:1527271998689};\\\", \\\"{x:467,y:733,t:1527271998704};\\\", \\\"{x:472,y:736,t:1527271998721};\\\", \\\"{x:474,y:736,t:1527271998967};\\\" ] }, { \\\"rt\\\": 46972, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 474281, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -G -E -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:474,y:732,t:1527272022912};\\\", \\\"{x:429,y:702,t:1527272022932};\\\", \\\"{x:405,y:691,t:1527272022938};\\\", \\\"{x:383,y:685,t:1527272022952};\\\", \\\"{x:342,y:675,t:1527272022968};\\\", \\\"{x:326,y:671,t:1527272022990};\\\", \\\"{x:319,y:668,t:1527272023007};\\\", \\\"{x:318,y:668,t:1527272023023};\\\", \\\"{x:319,y:671,t:1527272023064};\\\", \\\"{x:323,y:671,t:1527272023075};\\\", \\\"{x:324,y:671,t:1527272023091};\\\", \\\"{x:328,y:665,t:1527272023433};\\\", \\\"{x:331,y:661,t:1527272023441};\\\", \\\"{x:342,y:651,t:1527272023458};\\\", \\\"{x:349,y:638,t:1527272023475};\\\", \\\"{x:354,y:629,t:1527272023492};\\\", \\\"{x:359,y:621,t:1527272023509};\\\", \\\"{x:364,y:612,t:1527272023524};\\\", \\\"{x:365,y:606,t:1527272023541};\\\", \\\"{x:366,y:604,t:1527272023558};\\\", \\\"{x:367,y:601,t:1527272023576};\\\", \\\"{x:370,y:598,t:1527272023592};\\\", \\\"{x:372,y:591,t:1527272023609};\\\", \\\"{x:376,y:581,t:1527272023626};\\\", \\\"{x:379,y:568,t:1527272023641};\\\", \\\"{x:380,y:556,t:1527272023659};\\\", \\\"{x:383,y:543,t:1527272023677};\\\", \\\"{x:386,y:531,t:1527272023692};\\\", \\\"{x:386,y:521,t:1527272023709};\\\", \\\"{x:387,y:515,t:1527272023726};\\\", \\\"{x:388,y:512,t:1527272023741};\\\", \\\"{x:385,y:512,t:1527272023824};\\\", \\\"{x:382,y:514,t:1527272023833};\\\", \\\"{x:379,y:517,t:1527272023842};\\\", \\\"{x:369,y:525,t:1527272023859};\\\", \\\"{x:358,y:530,t:1527272023876};\\\", \\\"{x:346,y:538,t:1527272023891};\\\", \\\"{x:341,y:542,t:1527272023909};\\\", \\\"{x:338,y:544,t:1527272023925};\\\", \\\"{x:336,y:546,t:1527272023943};\\\", \\\"{x:331,y:550,t:1527272023959};\\\", \\\"{x:321,y:556,t:1527272023976};\\\", \\\"{x:300,y:571,t:1527272023992};\\\", \\\"{x:280,y:582,t:1527272024008};\\\", \\\"{x:260,y:589,t:1527272024026};\\\", \\\"{x:250,y:597,t:1527272024042};\\\", \\\"{x:238,y:599,t:1527272024059};\\\", \\\"{x:231,y:602,t:1527272024076};\\\", \\\"{x:227,y:605,t:1527272024092};\\\", \\\"{x:222,y:610,t:1527272024108};\\\", \\\"{x:215,y:615,t:1527272024126};\\\", \\\"{x:205,y:623,t:1527272024142};\\\", \\\"{x:197,y:629,t:1527272024158};\\\", \\\"{x:188,y:636,t:1527272024176};\\\", \\\"{x:178,y:643,t:1527272024192};\\\", \\\"{x:177,y:645,t:1527272024209};\\\", \\\"{x:177,y:644,t:1527272024336};\\\", \\\"{x:177,y:641,t:1527272024344};\\\", \\\"{x:177,y:638,t:1527272024360};\\\", \\\"{x:177,y:633,t:1527272024375};\\\", \\\"{x:179,y:621,t:1527272024393};\\\", \\\"{x:181,y:616,t:1527272024410};\\\", \\\"{x:181,y:599,t:1527272024426};\\\", \\\"{x:181,y:582,t:1527272024443};\\\", \\\"{x:181,y:567,t:1527272024460};\\\", \\\"{x:181,y:551,t:1527272024476};\\\", \\\"{x:183,y:537,t:1527272024493};\\\", \\\"{x:186,y:531,t:1527272024510};\\\", \\\"{x:188,y:528,t:1527272024526};\\\", \\\"{x:190,y:525,t:1527272024543};\\\", \\\"{x:192,y:524,t:1527272024560};\\\", \\\"{x:194,y:523,t:1527272024576};\\\", \\\"{x:200,y:519,t:1527272024592};\\\", \\\"{x:211,y:516,t:1527272024610};\\\", \\\"{x:223,y:514,t:1527272024626};\\\", \\\"{x:241,y:511,t:1527272024643};\\\", \\\"{x:261,y:508,t:1527272024659};\\\", \\\"{x:287,y:503,t:1527272024676};\\\", \\\"{x:315,y:501,t:1527272024693};\\\", \\\"{x:343,y:500,t:1527272024709};\\\", \\\"{x:357,y:500,t:1527272024726};\\\", \\\"{x:369,y:500,t:1527272024742};\\\", \\\"{x:391,y:500,t:1527272024760};\\\", \\\"{x:404,y:500,t:1527272024776};\\\", \\\"{x:432,y:498,t:1527272024793};\\\", \\\"{x:456,y:498,t:1527272024809};\\\", \\\"{x:483,y:495,t:1527272024827};\\\", \\\"{x:498,y:495,t:1527272024842};\\\", \\\"{x:512,y:494,t:1527272024860};\\\", \\\"{x:537,y:494,t:1527272024876};\\\", \\\"{x:553,y:494,t:1527272024892};\\\", \\\"{x:560,y:494,t:1527272024909};\\\", \\\"{x:563,y:494,t:1527272024927};\\\", \\\"{x:563,y:495,t:1527272024992};\\\", \\\"{x:562,y:496,t:1527272025048};\\\", \\\"{x:563,y:496,t:1527272025145};\\\", \\\"{x:571,y:496,t:1527272025159};\\\", \\\"{x:589,y:495,t:1527272025176};\\\", \\\"{x:602,y:495,t:1527272025192};\\\", \\\"{x:604,y:495,t:1527272025210};\\\", \\\"{x:605,y:495,t:1527272025227};\\\", \\\"{x:605,y:496,t:1527272025256};\\\", \\\"{x:605,y:498,t:1527272025264};\\\", \\\"{x:604,y:499,t:1527272025276};\\\", \\\"{x:594,y:505,t:1527272025294};\\\", \\\"{x:584,y:511,t:1527272025309};\\\", \\\"{x:577,y:513,t:1527272025326};\\\", \\\"{x:565,y:517,t:1527272025343};\\\", \\\"{x:558,y:518,t:1527272025360};\\\", \\\"{x:553,y:521,t:1527272025376};\\\", \\\"{x:549,y:522,t:1527272025394};\\\", \\\"{x:543,y:525,t:1527272025411};\\\", \\\"{x:531,y:531,t:1527272025427};\\\", \\\"{x:517,y:537,t:1527272025444};\\\", \\\"{x:498,y:545,t:1527272025460};\\\", \\\"{x:488,y:547,t:1527272025477};\\\", \\\"{x:476,y:555,t:1527272025494};\\\", \\\"{x:460,y:560,t:1527272025510};\\\", \\\"{x:447,y:566,t:1527272025526};\\\", \\\"{x:440,y:571,t:1527272025543};\\\", \\\"{x:428,y:579,t:1527272025559};\\\", \\\"{x:408,y:585,t:1527272025577};\\\", \\\"{x:391,y:590,t:1527272025593};\\\", \\\"{x:382,y:595,t:1527272025610};\\\", \\\"{x:374,y:598,t:1527272025626};\\\", \\\"{x:361,y:604,t:1527272025644};\\\", \\\"{x:358,y:605,t:1527272025660};\\\", \\\"{x:355,y:606,t:1527272025676};\\\", \\\"{x:359,y:606,t:1527272026081};\\\", \\\"{x:367,y:604,t:1527272026094};\\\", \\\"{x:380,y:601,t:1527272026111};\\\", \\\"{x:392,y:599,t:1527272026128};\\\", \\\"{x:407,y:594,t:1527272026144};\\\", \\\"{x:428,y:591,t:1527272026160};\\\", \\\"{x:439,y:588,t:1527272026177};\\\", \\\"{x:453,y:584,t:1527272026194};\\\", \\\"{x:475,y:578,t:1527272026210};\\\", \\\"{x:514,y:576,t:1527272026228};\\\", \\\"{x:540,y:571,t:1527272026243};\\\", \\\"{x:576,y:562,t:1527272026261};\\\", \\\"{x:594,y:553,t:1527272026278};\\\", \\\"{x:610,y:546,t:1527272026295};\\\", \\\"{x:623,y:542,t:1527272026311};\\\", \\\"{x:631,y:538,t:1527272026328};\\\", \\\"{x:633,y:538,t:1527272026344};\\\", \\\"{x:633,y:537,t:1527272026361};\\\", \\\"{x:634,y:537,t:1527272026392};\\\", \\\"{x:635,y:537,t:1527272026408};\\\", \\\"{x:635,y:536,t:1527272026424};\\\", \\\"{x:638,y:536,t:1527272026440};\\\", \\\"{x:642,y:537,t:1527272026448};\\\", \\\"{x:649,y:539,t:1527272026461};\\\", \\\"{x:659,y:542,t:1527272026478};\\\", \\\"{x:670,y:550,t:1527272026494};\\\", \\\"{x:695,y:556,t:1527272026511};\\\", \\\"{x:708,y:561,t:1527272026528};\\\", \\\"{x:722,y:565,t:1527272026545};\\\", \\\"{x:723,y:565,t:1527272026561};\\\", \\\"{x:724,y:566,t:1527272026633};\\\", \\\"{x:724,y:567,t:1527272026664};\\\", \\\"{x:724,y:568,t:1527272026680};\\\", \\\"{x:724,y:570,t:1527272026696};\\\", \\\"{x:724,y:572,t:1527272026711};\\\", \\\"{x:724,y:575,t:1527272026728};\\\", \\\"{x:718,y:581,t:1527272026745};\\\", \\\"{x:715,y:585,t:1527272026760};\\\", \\\"{x:709,y:587,t:1527272026778};\\\", \\\"{x:698,y:590,t:1527272026795};\\\", \\\"{x:685,y:591,t:1527272026811};\\\", \\\"{x:673,y:591,t:1527272026828};\\\", \\\"{x:660,y:591,t:1527272026845};\\\", \\\"{x:654,y:591,t:1527272026861};\\\", \\\"{x:641,y:588,t:1527272026878};\\\", \\\"{x:636,y:585,t:1527272026894};\\\", \\\"{x:631,y:585,t:1527272026910};\\\", \\\"{x:628,y:584,t:1527272026928};\\\", \\\"{x:627,y:583,t:1527272026945};\\\", \\\"{x:626,y:582,t:1527272026961};\\\", \\\"{x:622,y:579,t:1527272027337};\\\", \\\"{x:619,y:579,t:1527272027346};\\\", \\\"{x:613,y:579,t:1527272027361};\\\", \\\"{x:608,y:577,t:1527272027377};\\\", \\\"{x:606,y:576,t:1527272027395};\\\", \\\"{x:605,y:576,t:1527272027412};\\\", \\\"{x:610,y:576,t:1527272028289};\\\", \\\"{x:637,y:578,t:1527272028296};\\\", \\\"{x:661,y:590,t:1527272028312};\\\", \\\"{x:736,y:609,t:1527272028329};\\\", \\\"{x:860,y:647,t:1527272028346};\\\", \\\"{x:982,y:678,t:1527272028363};\\\", \\\"{x:1078,y:700,t:1527272028378};\\\", \\\"{x:1178,y:730,t:1527272028396};\\\", \\\"{x:1274,y:755,t:1527272028412};\\\", \\\"{x:1363,y:778,t:1527272028428};\\\", \\\"{x:1444,y:803,t:1527272028446};\\\", \\\"{x:1467,y:809,t:1527272028463};\\\", \\\"{x:1499,y:821,t:1527272028479};\\\", \\\"{x:1516,y:826,t:1527272028495};\\\", \\\"{x:1541,y:828,t:1527272028512};\\\", \\\"{x:1549,y:831,t:1527272028529};\\\", \\\"{x:1556,y:832,t:1527272028546};\\\", \\\"{x:1560,y:832,t:1527272028562};\\\", \\\"{x:1561,y:830,t:1527272028664};\\\", \\\"{x:1562,y:830,t:1527272028680};\\\", \\\"{x:1562,y:829,t:1527272028721};\\\", \\\"{x:1559,y:826,t:1527272028730};\\\", \\\"{x:1559,y:825,t:1527272028745};\\\", \\\"{x:1559,y:824,t:1527272028912};\\\", \\\"{x:1559,y:818,t:1527272028929};\\\", \\\"{x:1556,y:809,t:1527272028946};\\\", \\\"{x:1549,y:800,t:1527272028963};\\\", \\\"{x:1545,y:794,t:1527272028980};\\\", \\\"{x:1542,y:791,t:1527272028996};\\\", \\\"{x:1541,y:788,t:1527272029013};\\\", \\\"{x:1540,y:787,t:1527272029030};\\\", \\\"{x:1539,y:786,t:1527272029046};\\\", \\\"{x:1538,y:785,t:1527272029080};\\\", \\\"{x:1537,y:785,t:1527272029232};\\\", \\\"{x:1536,y:785,t:1527272029272};\\\", \\\"{x:1535,y:785,t:1527272029320};\\\", \\\"{x:1534,y:784,t:1527272029330};\\\", \\\"{x:1532,y:781,t:1527272029347};\\\", \\\"{x:1525,y:775,t:1527272029363};\\\", \\\"{x:1516,y:765,t:1527272029380};\\\", \\\"{x:1508,y:758,t:1527272029397};\\\", \\\"{x:1502,y:754,t:1527272029413};\\\", \\\"{x:1500,y:752,t:1527272029430};\\\", \\\"{x:1499,y:752,t:1527272029464};\\\", \\\"{x:1498,y:752,t:1527272029704};\\\", \\\"{x:1497,y:752,t:1527272029720};\\\", \\\"{x:1496,y:753,t:1527272029736};\\\", \\\"{x:1496,y:754,t:1527272029752};\\\", \\\"{x:1496,y:755,t:1527272029764};\\\", \\\"{x:1496,y:757,t:1527272029780};\\\", \\\"{x:1495,y:759,t:1527272029800};\\\", \\\"{x:1494,y:760,t:1527272029816};\\\", \\\"{x:1494,y:761,t:1527272029830};\\\", \\\"{x:1494,y:763,t:1527272029847};\\\", \\\"{x:1494,y:768,t:1527272029864};\\\", \\\"{x:1496,y:770,t:1527272029880};\\\", \\\"{x:1496,y:771,t:1527272029921};\\\", \\\"{x:1498,y:773,t:1527272030048};\\\", \\\"{x:1499,y:774,t:1527272030063};\\\", \\\"{x:1502,y:774,t:1527272031024};\\\", \\\"{x:1503,y:774,t:1527272031153};\\\", \\\"{x:1503,y:775,t:1527272031640};\\\", \\\"{x:1503,y:776,t:1527272031648};\\\", \\\"{x:1504,y:777,t:1527272031968};\\\", \\\"{x:1504,y:770,t:1527272031985};\\\", \\\"{x:1500,y:761,t:1527272031999};\\\", \\\"{x:1490,y:748,t:1527272032015};\\\", \\\"{x:1476,y:730,t:1527272032032};\\\", \\\"{x:1455,y:707,t:1527272032048};\\\", \\\"{x:1446,y:695,t:1527272032065};\\\", \\\"{x:1444,y:688,t:1527272032082};\\\", \\\"{x:1443,y:685,t:1527272032099};\\\", \\\"{x:1442,y:682,t:1527272032115};\\\", \\\"{x:1442,y:679,t:1527272032132};\\\", \\\"{x:1441,y:674,t:1527272032149};\\\", \\\"{x:1441,y:672,t:1527272032165};\\\", \\\"{x:1441,y:670,t:1527272032182};\\\", \\\"{x:1441,y:669,t:1527272032199};\\\", \\\"{x:1441,y:668,t:1527272032217};\\\", \\\"{x:1441,y:667,t:1527272032232};\\\", \\\"{x:1441,y:664,t:1527272032249};\\\", \\\"{x:1441,y:662,t:1527272032265};\\\", \\\"{x:1443,y:659,t:1527272032282};\\\", \\\"{x:1443,y:655,t:1527272032299};\\\", \\\"{x:1444,y:654,t:1527272032316};\\\", \\\"{x:1444,y:653,t:1527272032332};\\\", \\\"{x:1444,y:651,t:1527272032401};\\\", \\\"{x:1444,y:650,t:1527272033721};\\\", \\\"{x:1443,y:649,t:1527272033816};\\\", \\\"{x:1442,y:649,t:1527272033840};\\\", \\\"{x:1440,y:649,t:1527272033872};\\\", \\\"{x:1438,y:649,t:1527272033884};\\\", \\\"{x:1435,y:649,t:1527272033900};\\\", \\\"{x:1433,y:649,t:1527272033917};\\\", \\\"{x:1432,y:649,t:1527272033933};\\\", \\\"{x:1431,y:650,t:1527272033950};\\\", \\\"{x:1430,y:650,t:1527272034112};\\\", \\\"{x:1429,y:651,t:1527272034121};\\\", \\\"{x:1428,y:651,t:1527272034136};\\\", \\\"{x:1427,y:651,t:1527272034150};\\\", \\\"{x:1426,y:652,t:1527272034168};\\\", \\\"{x:1424,y:652,t:1527272034249};\\\", \\\"{x:1423,y:652,t:1527272034897};\\\", \\\"{x:1418,y:652,t:1527272034904};\\\", \\\"{x:1414,y:652,t:1527272034918};\\\", \\\"{x:1402,y:652,t:1527272034934};\\\", \\\"{x:1399,y:652,t:1527272034951};\\\", \\\"{x:1394,y:652,t:1527272034969};\\\", \\\"{x:1393,y:652,t:1527272034984};\\\", \\\"{x:1392,y:652,t:1527272035001};\\\", \\\"{x:1390,y:651,t:1527272035153};\\\", \\\"{x:1387,y:648,t:1527272035168};\\\", \\\"{x:1383,y:640,t:1527272035184};\\\", \\\"{x:1378,y:634,t:1527272035201};\\\", \\\"{x:1374,y:630,t:1527272035218};\\\", \\\"{x:1371,y:626,t:1527272035234};\\\", \\\"{x:1371,y:625,t:1527272035252};\\\", \\\"{x:1370,y:623,t:1527272035268};\\\", \\\"{x:1369,y:619,t:1527272035321};\\\", \\\"{x:1369,y:618,t:1527272035425};\\\", \\\"{x:1369,y:617,t:1527272035464};\\\", \\\"{x:1372,y:613,t:1527272035480};\\\", \\\"{x:1373,y:612,t:1527272035489};\\\", \\\"{x:1375,y:611,t:1527272035501};\\\", \\\"{x:1379,y:608,t:1527272035518};\\\", \\\"{x:1382,y:604,t:1527272035535};\\\", \\\"{x:1385,y:600,t:1527272035551};\\\", \\\"{x:1387,y:598,t:1527272035568};\\\", \\\"{x:1387,y:596,t:1527272035585};\\\", \\\"{x:1387,y:595,t:1527272035704};\\\", \\\"{x:1388,y:593,t:1527272035718};\\\", \\\"{x:1389,y:590,t:1527272035735};\\\", \\\"{x:1391,y:587,t:1527272035751};\\\", \\\"{x:1394,y:583,t:1527272035768};\\\", \\\"{x:1395,y:581,t:1527272035785};\\\", \\\"{x:1396,y:580,t:1527272035801};\\\", \\\"{x:1398,y:579,t:1527272035818};\\\", \\\"{x:1399,y:578,t:1527272035835};\\\", \\\"{x:1400,y:577,t:1527272035856};\\\", \\\"{x:1401,y:577,t:1527272035868};\\\", \\\"{x:1401,y:576,t:1527272035888};\\\", \\\"{x:1403,y:574,t:1527272035902};\\\", \\\"{x:1403,y:573,t:1527272035918};\\\", \\\"{x:1405,y:571,t:1527272035935};\\\", \\\"{x:1407,y:568,t:1527272035953};\\\", \\\"{x:1409,y:567,t:1527272035968};\\\", \\\"{x:1410,y:566,t:1527272035992};\\\", \\\"{x:1409,y:566,t:1527272036144};\\\", \\\"{x:1408,y:566,t:1527272036168};\\\", \\\"{x:1406,y:566,t:1527272036185};\\\", \\\"{x:1402,y:567,t:1527272036203};\\\", \\\"{x:1394,y:569,t:1527272036219};\\\", \\\"{x:1387,y:573,t:1527272036235};\\\", \\\"{x:1382,y:574,t:1527272036252};\\\", \\\"{x:1378,y:577,t:1527272036269};\\\", \\\"{x:1375,y:580,t:1527272036285};\\\", \\\"{x:1369,y:582,t:1527272036302};\\\", \\\"{x:1366,y:586,t:1527272036319};\\\", \\\"{x:1363,y:588,t:1527272036335};\\\", \\\"{x:1356,y:593,t:1527272036353};\\\", \\\"{x:1353,y:597,t:1527272036370};\\\", \\\"{x:1349,y:602,t:1527272036385};\\\", \\\"{x:1344,y:609,t:1527272036403};\\\", \\\"{x:1338,y:615,t:1527272036419};\\\", \\\"{x:1336,y:620,t:1527272036435};\\\", \\\"{x:1335,y:625,t:1527272036452};\\\", \\\"{x:1334,y:625,t:1527272036469};\\\", \\\"{x:1334,y:626,t:1527272036486};\\\", \\\"{x:1334,y:629,t:1527272036502};\\\", \\\"{x:1334,y:633,t:1527272036519};\\\", \\\"{x:1334,y:640,t:1527272036535};\\\", \\\"{x:1334,y:647,t:1527272036553};\\\", \\\"{x:1334,y:648,t:1527272036569};\\\", \\\"{x:1334,y:653,t:1527272036585};\\\", \\\"{x:1334,y:657,t:1527272036602};\\\", \\\"{x:1334,y:661,t:1527272036620};\\\", \\\"{x:1333,y:663,t:1527272036635};\\\", \\\"{x:1333,y:664,t:1527272036652};\\\", \\\"{x:1333,y:666,t:1527272036669};\\\", \\\"{x:1333,y:667,t:1527272036686};\\\", \\\"{x:1333,y:669,t:1527272036702};\\\", \\\"{x:1333,y:671,t:1527272036719};\\\", \\\"{x:1333,y:675,t:1527272036736};\\\", \\\"{x:1332,y:680,t:1527272036752};\\\", \\\"{x:1332,y:681,t:1527272036769};\\\", \\\"{x:1332,y:684,t:1527272036786};\\\", \\\"{x:1332,y:685,t:1527272036803};\\\", \\\"{x:1332,y:687,t:1527272036819};\\\", \\\"{x:1332,y:689,t:1527272036837};\\\", \\\"{x:1332,y:691,t:1527272036853};\\\", \\\"{x:1332,y:695,t:1527272036869};\\\", \\\"{x:1333,y:697,t:1527272036886};\\\", \\\"{x:1334,y:699,t:1527272036902};\\\", \\\"{x:1335,y:700,t:1527272036919};\\\", \\\"{x:1337,y:702,t:1527272037025};\\\", \\\"{x:1338,y:702,t:1527272037049};\\\", \\\"{x:1338,y:703,t:1527272037072};\\\", \\\"{x:1339,y:705,t:1527272037087};\\\", \\\"{x:1340,y:708,t:1527272037103};\\\", \\\"{x:1340,y:709,t:1527272037119};\\\", \\\"{x:1341,y:711,t:1527272037137};\\\", \\\"{x:1342,y:715,t:1527272037152};\\\", \\\"{x:1342,y:717,t:1527272037170};\\\", \\\"{x:1342,y:718,t:1527272037921};\\\", \\\"{x:1341,y:716,t:1527272037960};\\\", \\\"{x:1340,y:714,t:1527272037976};\\\", \\\"{x:1339,y:713,t:1527272038001};\\\", \\\"{x:1339,y:711,t:1527272038009};\\\", \\\"{x:1338,y:711,t:1527272038020};\\\", \\\"{x:1335,y:709,t:1527272038037};\\\", \\\"{x:1335,y:707,t:1527272038053};\\\", \\\"{x:1334,y:706,t:1527272038070};\\\", \\\"{x:1332,y:705,t:1527272038088};\\\", \\\"{x:1331,y:703,t:1527272038103};\\\", \\\"{x:1328,y:699,t:1527272038120};\\\", \\\"{x:1326,y:695,t:1527272038137};\\\", \\\"{x:1323,y:690,t:1527272038153};\\\", \\\"{x:1316,y:683,t:1527272038170};\\\", \\\"{x:1311,y:678,t:1527272038188};\\\", \\\"{x:1301,y:670,t:1527272038203};\\\", \\\"{x:1293,y:665,t:1527272038220};\\\", \\\"{x:1282,y:656,t:1527272038237};\\\", \\\"{x:1263,y:649,t:1527272038253};\\\", \\\"{x:1256,y:641,t:1527272038270};\\\", \\\"{x:1245,y:635,t:1527272038288};\\\", \\\"{x:1243,y:633,t:1527272038304};\\\", \\\"{x:1243,y:632,t:1527272038320};\\\", \\\"{x:1243,y:631,t:1527272038337};\\\", \\\"{x:1244,y:628,t:1527272038353};\\\", \\\"{x:1244,y:626,t:1527272038370};\\\", \\\"{x:1244,y:624,t:1527272038392};\\\", \\\"{x:1244,y:622,t:1527272038408};\\\", \\\"{x:1245,y:622,t:1527272038420};\\\", \\\"{x:1246,y:622,t:1527272038448};\\\", \\\"{x:1247,y:621,t:1527272038456};\\\", \\\"{x:1248,y:620,t:1527272038488};\\\", \\\"{x:1248,y:619,t:1527272038528};\\\", \\\"{x:1249,y:617,t:1527272038538};\\\", \\\"{x:1252,y:614,t:1527272038554};\\\", \\\"{x:1253,y:611,t:1527272038570};\\\", \\\"{x:1253,y:608,t:1527272038587};\\\", \\\"{x:1253,y:602,t:1527272038604};\\\", \\\"{x:1256,y:594,t:1527272038620};\\\", \\\"{x:1256,y:585,t:1527272038637};\\\", \\\"{x:1257,y:578,t:1527272038655};\\\", \\\"{x:1257,y:574,t:1527272038670};\\\", \\\"{x:1260,y:571,t:1527272038687};\\\", \\\"{x:1263,y:570,t:1527272038704};\\\", \\\"{x:1265,y:569,t:1527272038720};\\\", \\\"{x:1267,y:569,t:1527272038737};\\\", \\\"{x:1270,y:566,t:1527272038754};\\\", \\\"{x:1272,y:565,t:1527272038770};\\\", \\\"{x:1276,y:562,t:1527272038787};\\\", \\\"{x:1278,y:561,t:1527272038805};\\\", \\\"{x:1280,y:559,t:1527272038820};\\\", \\\"{x:1278,y:560,t:1527272039072};\\\", \\\"{x:1277,y:561,t:1527272039088};\\\", \\\"{x:1276,y:561,t:1527272039104};\\\", \\\"{x:1274,y:563,t:1527272039122};\\\", \\\"{x:1273,y:564,t:1527272039137};\\\", \\\"{x:1272,y:565,t:1527272039154};\\\", \\\"{x:1271,y:566,t:1527272039171};\\\", \\\"{x:1270,y:568,t:1527272039200};\\\", \\\"{x:1269,y:568,t:1527272039209};\\\", \\\"{x:1269,y:569,t:1527272039222};\\\", \\\"{x:1268,y:570,t:1527272039237};\\\", \\\"{x:1264,y:573,t:1527272039254};\\\", \\\"{x:1264,y:574,t:1527272039632};\\\", \\\"{x:1264,y:575,t:1527272039640};\\\", \\\"{x:1264,y:576,t:1527272039654};\\\", \\\"{x:1263,y:576,t:1527272039672};\\\", \\\"{x:1262,y:577,t:1527272039688};\\\", \\\"{x:1262,y:578,t:1527272039705};\\\", \\\"{x:1262,y:579,t:1527272039744};\\\", \\\"{x:1262,y:580,t:1527272039768};\\\", \\\"{x:1262,y:581,t:1527272039793};\\\", \\\"{x:1259,y:584,t:1527272039816};\\\", \\\"{x:1257,y:585,t:1527272039832};\\\", \\\"{x:1255,y:587,t:1527272039848};\\\", \\\"{x:1253,y:588,t:1527272039864};\\\", \\\"{x:1253,y:589,t:1527272039873};\\\", \\\"{x:1251,y:590,t:1527272039888};\\\", \\\"{x:1250,y:590,t:1527272039905};\\\", \\\"{x:1248,y:592,t:1527272039922};\\\", \\\"{x:1246,y:593,t:1527272039938};\\\", \\\"{x:1244,y:594,t:1527272039956};\\\", \\\"{x:1241,y:597,t:1527272039971};\\\", \\\"{x:1235,y:602,t:1527272039988};\\\", \\\"{x:1232,y:604,t:1527272040005};\\\", \\\"{x:1228,y:607,t:1527272040022};\\\", \\\"{x:1223,y:616,t:1527272040038};\\\", \\\"{x:1218,y:624,t:1527272040055};\\\", \\\"{x:1213,y:635,t:1527272040072};\\\", \\\"{x:1205,y:650,t:1527272040088};\\\", \\\"{x:1201,y:660,t:1527272040105};\\\", \\\"{x:1197,y:672,t:1527272040121};\\\", \\\"{x:1195,y:682,t:1527272040138};\\\", \\\"{x:1191,y:688,t:1527272040155};\\\", \\\"{x:1191,y:694,t:1527272040171};\\\", \\\"{x:1191,y:705,t:1527272040189};\\\", \\\"{x:1191,y:711,t:1527272040206};\\\", \\\"{x:1191,y:719,t:1527272040222};\\\", \\\"{x:1191,y:727,t:1527272040239};\\\", \\\"{x:1191,y:733,t:1527272040256};\\\", \\\"{x:1192,y:744,t:1527272040272};\\\", \\\"{x:1192,y:747,t:1527272040288};\\\", \\\"{x:1194,y:755,t:1527272040305};\\\", \\\"{x:1196,y:761,t:1527272040322};\\\", \\\"{x:1198,y:764,t:1527272040339};\\\", \\\"{x:1198,y:771,t:1527272040356};\\\", \\\"{x:1199,y:774,t:1527272040372};\\\", \\\"{x:1199,y:776,t:1527272040388};\\\", \\\"{x:1199,y:777,t:1527272040440};\\\", \\\"{x:1199,y:779,t:1527272040455};\\\", \\\"{x:1199,y:785,t:1527272040472};\\\", \\\"{x:1199,y:790,t:1527272040488};\\\", \\\"{x:1202,y:796,t:1527272040506};\\\", \\\"{x:1203,y:800,t:1527272040523};\\\", \\\"{x:1204,y:800,t:1527272040538};\\\", \\\"{x:1204,y:801,t:1527272040576};\\\", \\\"{x:1205,y:801,t:1527272040588};\\\", \\\"{x:1205,y:803,t:1527272040606};\\\", \\\"{x:1207,y:806,t:1527272040622};\\\", \\\"{x:1207,y:807,t:1527272040640};\\\", \\\"{x:1207,y:808,t:1527272040655};\\\", \\\"{x:1208,y:812,t:1527272040672};\\\", \\\"{x:1208,y:813,t:1527272040696};\\\", \\\"{x:1209,y:814,t:1527272040737};\\\", \\\"{x:1209,y:816,t:1527272040752};\\\", \\\"{x:1209,y:817,t:1527272040776};\\\", \\\"{x:1209,y:818,t:1527272040789};\\\", \\\"{x:1209,y:821,t:1527272040806};\\\", \\\"{x:1209,y:823,t:1527272040823};\\\", \\\"{x:1209,y:824,t:1527272040839};\\\", \\\"{x:1210,y:827,t:1527272040855};\\\", \\\"{x:1210,y:830,t:1527272040872};\\\", \\\"{x:1210,y:832,t:1527272040890};\\\", \\\"{x:1210,y:833,t:1527272040905};\\\", \\\"{x:1211,y:835,t:1527272040968};\\\", \\\"{x:1212,y:835,t:1527272040992};\\\", \\\"{x:1213,y:836,t:1527272041048};\\\", \\\"{x:1213,y:837,t:1527272041464};\\\", \\\"{x:1212,y:837,t:1527272041945};\\\", \\\"{x:1210,y:837,t:1527272042041};\\\", \\\"{x:1207,y:832,t:1527272042056};\\\", \\\"{x:1207,y:830,t:1527272042145};\\\", \\\"{x:1207,y:829,t:1527272042156};\\\", \\\"{x:1207,y:826,t:1527272042173};\\\", \\\"{x:1205,y:822,t:1527272042191};\\\", \\\"{x:1204,y:820,t:1527272042206};\\\", \\\"{x:1203,y:818,t:1527272042223};\\\", \\\"{x:1203,y:817,t:1527272042240};\\\", \\\"{x:1203,y:816,t:1527272042257};\\\", \\\"{x:1203,y:814,t:1527272042273};\\\", \\\"{x:1203,y:812,t:1527272042291};\\\", \\\"{x:1200,y:809,t:1527272042306};\\\", \\\"{x:1199,y:807,t:1527272042323};\\\", \\\"{x:1196,y:805,t:1527272042340};\\\", \\\"{x:1195,y:804,t:1527272042356};\\\", \\\"{x:1193,y:803,t:1527272042373};\\\", \\\"{x:1191,y:803,t:1527272042585};\\\", \\\"{x:1190,y:802,t:1527272042600};\\\", \\\"{x:1188,y:801,t:1527272042616};\\\", \\\"{x:1186,y:800,t:1527272042632};\\\", \\\"{x:1185,y:799,t:1527272042640};\\\", \\\"{x:1182,y:798,t:1527272042658};\\\", \\\"{x:1181,y:796,t:1527272042673};\\\", \\\"{x:1178,y:795,t:1527272042690};\\\", \\\"{x:1170,y:791,t:1527272042708};\\\", \\\"{x:1161,y:786,t:1527272042723};\\\", \\\"{x:1159,y:786,t:1527272042740};\\\", \\\"{x:1157,y:786,t:1527272042757};\\\", \\\"{x:1160,y:786,t:1527272042897};\\\", \\\"{x:1170,y:786,t:1527272042907};\\\", \\\"{x:1193,y:792,t:1527272042925};\\\", \\\"{x:1222,y:811,t:1527272042940};\\\", \\\"{x:1250,y:822,t:1527272042957};\\\", \\\"{x:1277,y:831,t:1527272042975};\\\", \\\"{x:1307,y:845,t:1527272042990};\\\", \\\"{x:1320,y:855,t:1527272043007};\\\", \\\"{x:1335,y:862,t:1527272043024};\\\", \\\"{x:1336,y:863,t:1527272043040};\\\", \\\"{x:1334,y:863,t:1527272043305};\\\", \\\"{x:1330,y:860,t:1527272043312};\\\", \\\"{x:1329,y:859,t:1527272043324};\\\", \\\"{x:1323,y:853,t:1527272043342};\\\", \\\"{x:1307,y:848,t:1527272043358};\\\", \\\"{x:1288,y:839,t:1527272043375};\\\", \\\"{x:1273,y:833,t:1527272043392};\\\", \\\"{x:1250,y:822,t:1527272043408};\\\", \\\"{x:1223,y:814,t:1527272043424};\\\", \\\"{x:1214,y:809,t:1527272043441};\\\", \\\"{x:1211,y:808,t:1527272043458};\\\", \\\"{x:1209,y:807,t:1527272043475};\\\", \\\"{x:1209,y:806,t:1527272043491};\\\", \\\"{x:1209,y:803,t:1527272043680};\\\", \\\"{x:1205,y:798,t:1527272043692};\\\", \\\"{x:1199,y:789,t:1527272043708};\\\", \\\"{x:1186,y:784,t:1527272043725};\\\", \\\"{x:1175,y:779,t:1527272043742};\\\", \\\"{x:1172,y:778,t:1527272043758};\\\", \\\"{x:1170,y:778,t:1527272044745};\\\", \\\"{x:1169,y:778,t:1527272044776};\\\", \\\"{x:1167,y:779,t:1527272044825};\\\", \\\"{x:1165,y:779,t:1527272044856};\\\", \\\"{x:1164,y:780,t:1527272044872};\\\", \\\"{x:1163,y:781,t:1527272044905};\\\", \\\"{x:1162,y:781,t:1527272044920};\\\", \\\"{x:1161,y:782,t:1527272045033};\\\", \\\"{x:1159,y:784,t:1527272045184};\\\", \\\"{x:1158,y:786,t:1527272045192};\\\", \\\"{x:1158,y:787,t:1527272045224};\\\", \\\"{x:1157,y:789,t:1527272045256};\\\", \\\"{x:1156,y:790,t:1527272045304};\\\", \\\"{x:1156,y:792,t:1527272045319};\\\", \\\"{x:1155,y:794,t:1527272045328};\\\", \\\"{x:1155,y:795,t:1527272045344};\\\", \\\"{x:1155,y:796,t:1527272045360};\\\", \\\"{x:1154,y:797,t:1527272045432};\\\", \\\"{x:1152,y:799,t:1527272045443};\\\", \\\"{x:1152,y:800,t:1527272045460};\\\", \\\"{x:1151,y:804,t:1527272045476};\\\", \\\"{x:1151,y:806,t:1527272045561};\\\", \\\"{x:1152,y:810,t:1527272045577};\\\", \\\"{x:1160,y:817,t:1527272045592};\\\", \\\"{x:1170,y:824,t:1527272045610};\\\", \\\"{x:1177,y:828,t:1527272045626};\\\", \\\"{x:1178,y:830,t:1527272045643};\\\", \\\"{x:1179,y:832,t:1527272045721};\\\", \\\"{x:1179,y:833,t:1527272045728};\\\", \\\"{x:1181,y:836,t:1527272045760};\\\", \\\"{x:1184,y:838,t:1527272045784};\\\", \\\"{x:1184,y:839,t:1527272045793};\\\", \\\"{x:1186,y:840,t:1527272045810};\\\", \\\"{x:1186,y:839,t:1527272045977};\\\", \\\"{x:1180,y:835,t:1527272045993};\\\", \\\"{x:1167,y:828,t:1527272046009};\\\", \\\"{x:1142,y:818,t:1527272046027};\\\", \\\"{x:1113,y:809,t:1527272046043};\\\", \\\"{x:1058,y:793,t:1527272046059};\\\", \\\"{x:1023,y:781,t:1527272046076};\\\", \\\"{x:968,y:768,t:1527272046093};\\\", \\\"{x:937,y:761,t:1527272046110};\\\", \\\"{x:921,y:749,t:1527272046127};\\\", \\\"{x:906,y:746,t:1527272046143};\\\", \\\"{x:891,y:744,t:1527272046159};\\\", \\\"{x:883,y:743,t:1527272046177};\\\", \\\"{x:879,y:743,t:1527272046193};\\\", \\\"{x:874,y:741,t:1527272046210};\\\", \\\"{x:866,y:741,t:1527272046227};\\\", \\\"{x:840,y:741,t:1527272046244};\\\", \\\"{x:793,y:746,t:1527272046259};\\\", \\\"{x:751,y:755,t:1527272046276};\\\", \\\"{x:728,y:761,t:1527272046294};\\\", \\\"{x:715,y:763,t:1527272046309};\\\", \\\"{x:704,y:766,t:1527272046327};\\\", \\\"{x:702,y:767,t:1527272046344};\\\", \\\"{x:702,y:768,t:1527272046544};\\\", \\\"{x:699,y:770,t:1527272046560};\\\", \\\"{x:697,y:770,t:1527272046577};\\\", \\\"{x:696,y:771,t:1527272046594};\\\", \\\"{x:693,y:772,t:1527272046611};\\\", \\\"{x:687,y:773,t:1527272046627};\\\", \\\"{x:671,y:774,t:1527272046644};\\\", \\\"{x:659,y:774,t:1527272046661};\\\", \\\"{x:640,y:774,t:1527272046676};\\\", \\\"{x:606,y:765,t:1527272046694};\\\", \\\"{x:565,y:749,t:1527272046710};\\\", \\\"{x:552,y:743,t:1527272046727};\\\", \\\"{x:549,y:743,t:1527272046744};\\\", \\\"{x:548,y:741,t:1527272046761};\\\", \\\"{x:549,y:740,t:1527272046873};\\\", \\\"{x:550,y:739,t:1527272046896};\\\", \\\"{x:550,y:738,t:1527272046910};\\\" ] }, { \\\"rt\\\": 15411, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 490901, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -01 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:550,y:737,t:1527272051016};\\\", \\\"{x:552,y:735,t:1527272051032};\\\", \\\"{x:553,y:735,t:1527272051048};\\\", \\\"{x:559,y:735,t:1527272051088};\\\", \\\"{x:573,y:735,t:1527272051098};\\\", \\\"{x:597,y:733,t:1527272051115};\\\", \\\"{x:643,y:730,t:1527272051130};\\\", \\\"{x:720,y:738,t:1527272051148};\\\", \\\"{x:843,y:763,t:1527272051165};\\\", \\\"{x:985,y:794,t:1527272051181};\\\", \\\"{x:1122,y:819,t:1527272051198};\\\", \\\"{x:1237,y:848,t:1527272051215};\\\", \\\"{x:1320,y:867,t:1527272051231};\\\", \\\"{x:1384,y:894,t:1527272051249};\\\", \\\"{x:1412,y:908,t:1527272051265};\\\", \\\"{x:1428,y:917,t:1527272051280};\\\", \\\"{x:1439,y:926,t:1527272051297};\\\", \\\"{x:1442,y:930,t:1527272051315};\\\", \\\"{x:1447,y:931,t:1527272051352};\\\", \\\"{x:1452,y:934,t:1527272051376};\\\", \\\"{x:1453,y:934,t:1527272051384};\\\", \\\"{x:1455,y:935,t:1527272051397};\\\", \\\"{x:1466,y:936,t:1527272051415};\\\", \\\"{x:1469,y:938,t:1527272051432};\\\", \\\"{x:1467,y:938,t:1527272051504};\\\", \\\"{x:1465,y:940,t:1527272051515};\\\", \\\"{x:1463,y:943,t:1527272051532};\\\", \\\"{x:1459,y:947,t:1527272051548};\\\", \\\"{x:1456,y:950,t:1527272051564};\\\", \\\"{x:1455,y:952,t:1527272051581};\\\", \\\"{x:1453,y:953,t:1527272051598};\\\", \\\"{x:1451,y:955,t:1527272051615};\\\", \\\"{x:1450,y:956,t:1527272051632};\\\", \\\"{x:1449,y:956,t:1527272051672};\\\", \\\"{x:1448,y:957,t:1527272051682};\\\", \\\"{x:1447,y:958,t:1527272051699};\\\", \\\"{x:1445,y:960,t:1527272051715};\\\", \\\"{x:1442,y:964,t:1527272051732};\\\", \\\"{x:1439,y:967,t:1527272051749};\\\", \\\"{x:1435,y:970,t:1527272051765};\\\", \\\"{x:1429,y:975,t:1527272051782};\\\", \\\"{x:1426,y:977,t:1527272051799};\\\", \\\"{x:1424,y:977,t:1527272051815};\\\", \\\"{x:1423,y:978,t:1527272051864};\\\", \\\"{x:1421,y:979,t:1527272051929};\\\", \\\"{x:1416,y:983,t:1527272051935};\\\", \\\"{x:1413,y:983,t:1527272051949};\\\", \\\"{x:1404,y:988,t:1527272051965};\\\", \\\"{x:1398,y:991,t:1527272051982};\\\", \\\"{x:1391,y:996,t:1527272051999};\\\", \\\"{x:1386,y:997,t:1527272052015};\\\", \\\"{x:1385,y:997,t:1527272052088};\\\", \\\"{x:1382,y:996,t:1527272052104};\\\", \\\"{x:1382,y:995,t:1527272052115};\\\", \\\"{x:1381,y:989,t:1527272052131};\\\", \\\"{x:1379,y:982,t:1527272052149};\\\", \\\"{x:1376,y:975,t:1527272052166};\\\", \\\"{x:1373,y:965,t:1527272052182};\\\", \\\"{x:1371,y:951,t:1527272052199};\\\", \\\"{x:1370,y:947,t:1527272052216};\\\", \\\"{x:1369,y:946,t:1527272052488};\\\", \\\"{x:1365,y:946,t:1527272052498};\\\", \\\"{x:1358,y:949,t:1527272052516};\\\", \\\"{x:1352,y:956,t:1527272052537};\\\", \\\"{x:1351,y:961,t:1527272052552};\\\", \\\"{x:1350,y:964,t:1527272052569};\\\", \\\"{x:1349,y:966,t:1527272052586};\\\", \\\"{x:1348,y:967,t:1527272052602};\\\", \\\"{x:1347,y:967,t:1527272052620};\\\", \\\"{x:1346,y:968,t:1527272052660};\\\", \\\"{x:1346,y:967,t:1527272052939};\\\", \\\"{x:1346,y:965,t:1527272052956};\\\", \\\"{x:1347,y:964,t:1527272052972};\\\", \\\"{x:1347,y:963,t:1527272052986};\\\", \\\"{x:1348,y:961,t:1527272053003};\\\", \\\"{x:1348,y:959,t:1527272053019};\\\", \\\"{x:1349,y:958,t:1527272053036};\\\", \\\"{x:1350,y:956,t:1527272053053};\\\", \\\"{x:1350,y:955,t:1527272053083};\\\", \\\"{x:1350,y:954,t:1527272053091};\\\", \\\"{x:1350,y:952,t:1527272053107};\\\", \\\"{x:1350,y:949,t:1527272053123};\\\", \\\"{x:1350,y:948,t:1527272053136};\\\", \\\"{x:1351,y:945,t:1527272053153};\\\", \\\"{x:1351,y:944,t:1527272053171};\\\", \\\"{x:1351,y:943,t:1527272053203};\\\", \\\"{x:1351,y:942,t:1527272053252};\\\", \\\"{x:1351,y:941,t:1527272053259};\\\", \\\"{x:1351,y:940,t:1527272053270};\\\", \\\"{x:1351,y:938,t:1527272053286};\\\", \\\"{x:1351,y:937,t:1527272053302};\\\", \\\"{x:1351,y:936,t:1527272053320};\\\", \\\"{x:1351,y:935,t:1527272053336};\\\", \\\"{x:1351,y:933,t:1527272053353};\\\", \\\"{x:1351,y:928,t:1527272053370};\\\", \\\"{x:1351,y:921,t:1527272053386};\\\", \\\"{x:1351,y:912,t:1527272053403};\\\", \\\"{x:1351,y:905,t:1527272053419};\\\", \\\"{x:1351,y:899,t:1527272053437};\\\", \\\"{x:1350,y:896,t:1527272053454};\\\", \\\"{x:1350,y:893,t:1527272053471};\\\", \\\"{x:1350,y:892,t:1527272053487};\\\", \\\"{x:1350,y:890,t:1527272053539};\\\", \\\"{x:1349,y:890,t:1527272053553};\\\", \\\"{x:1349,y:889,t:1527272053571};\\\", \\\"{x:1349,y:887,t:1527272053587};\\\", \\\"{x:1349,y:886,t:1527272053603};\\\", \\\"{x:1349,y:884,t:1527272053620};\\\", \\\"{x:1348,y:881,t:1527272053637};\\\", \\\"{x:1347,y:877,t:1527272053653};\\\", \\\"{x:1345,y:870,t:1527272053670};\\\", \\\"{x:1342,y:860,t:1527272053687};\\\", \\\"{x:1340,y:850,t:1527272053704};\\\", \\\"{x:1339,y:834,t:1527272053720};\\\", \\\"{x:1334,y:820,t:1527272053737};\\\", \\\"{x:1329,y:803,t:1527272053753};\\\", \\\"{x:1326,y:782,t:1527272053770};\\\", \\\"{x:1326,y:755,t:1527272053787};\\\", \\\"{x:1326,y:744,t:1527272053803};\\\", \\\"{x:1327,y:731,t:1527272053820};\\\", \\\"{x:1329,y:727,t:1527272053837};\\\", \\\"{x:1332,y:719,t:1527272053854};\\\", \\\"{x:1334,y:711,t:1527272053870};\\\", \\\"{x:1335,y:708,t:1527272053887};\\\", \\\"{x:1336,y:699,t:1527272053904};\\\", \\\"{x:1340,y:690,t:1527272053920};\\\", \\\"{x:1340,y:685,t:1527272053938};\\\", \\\"{x:1340,y:679,t:1527272053954};\\\", \\\"{x:1343,y:674,t:1527272053970};\\\", \\\"{x:1343,y:666,t:1527272053987};\\\", \\\"{x:1343,y:664,t:1527272054003};\\\", \\\"{x:1343,y:661,t:1527272054020};\\\", \\\"{x:1343,y:660,t:1527272054037};\\\", \\\"{x:1343,y:658,t:1527272054054};\\\", \\\"{x:1343,y:657,t:1527272054070};\\\", \\\"{x:1343,y:656,t:1527272054087};\\\", \\\"{x:1343,y:654,t:1527272054156};\\\", \\\"{x:1343,y:653,t:1527272054196};\\\", \\\"{x:1330,y:653,t:1527272054251};\\\", \\\"{x:1299,y:651,t:1527272054259};\\\", \\\"{x:1282,y:651,t:1527272054271};\\\", \\\"{x:1232,y:651,t:1527272054287};\\\", \\\"{x:1195,y:657,t:1527272054304};\\\", \\\"{x:1181,y:665,t:1527272054321};\\\", \\\"{x:1164,y:668,t:1527272054337};\\\", \\\"{x:1149,y:674,t:1527272054354};\\\", \\\"{x:1134,y:682,t:1527272054371};\\\", \\\"{x:1131,y:682,t:1527272054387};\\\", \\\"{x:1130,y:684,t:1527272054404};\\\", \\\"{x:1129,y:684,t:1527272054421};\\\", \\\"{x:1129,y:685,t:1527272054437};\\\", \\\"{x:1130,y:684,t:1527272054531};\\\", \\\"{x:1130,y:683,t:1527272054539};\\\", \\\"{x:1130,y:681,t:1527272054554};\\\", \\\"{x:1130,y:675,t:1527272054571};\\\", \\\"{x:1130,y:669,t:1527272054587};\\\", \\\"{x:1130,y:662,t:1527272054604};\\\", \\\"{x:1130,y:659,t:1527272054622};\\\", \\\"{x:1130,y:654,t:1527272054638};\\\", \\\"{x:1130,y:651,t:1527272054654};\\\", \\\"{x:1130,y:646,t:1527272054671};\\\", \\\"{x:1130,y:639,t:1527272054688};\\\", \\\"{x:1130,y:628,t:1527272054704};\\\", \\\"{x:1130,y:618,t:1527272054721};\\\", \\\"{x:1130,y:605,t:1527272054738};\\\", \\\"{x:1128,y:600,t:1527272054754};\\\", \\\"{x:1127,y:578,t:1527272054771};\\\", \\\"{x:1125,y:559,t:1527272054788};\\\", \\\"{x:1123,y:538,t:1527272054804};\\\", \\\"{x:1122,y:520,t:1527272054821};\\\", \\\"{x:1121,y:505,t:1527272054838};\\\", \\\"{x:1120,y:491,t:1527272054854};\\\", \\\"{x:1117,y:480,t:1527272054871};\\\", \\\"{x:1116,y:472,t:1527272054888};\\\", \\\"{x:1116,y:471,t:1527272054905};\\\", \\\"{x:1114,y:471,t:1527272055027};\\\", \\\"{x:1113,y:474,t:1527272055038};\\\", \\\"{x:1109,y:481,t:1527272055055};\\\", \\\"{x:1104,y:492,t:1527272055071};\\\", \\\"{x:1094,y:507,t:1527272055088};\\\", \\\"{x:1080,y:529,t:1527272055105};\\\", \\\"{x:1067,y:544,t:1527272055121};\\\", \\\"{x:1045,y:567,t:1527272055139};\\\", \\\"{x:991,y:604,t:1527272055156};\\\", \\\"{x:957,y:630,t:1527272055171};\\\", \\\"{x:929,y:652,t:1527272055189};\\\", \\\"{x:902,y:666,t:1527272055205};\\\", \\\"{x:884,y:684,t:1527272055221};\\\", \\\"{x:853,y:704,t:1527272055238};\\\", \\\"{x:805,y:721,t:1527272055255};\\\", \\\"{x:731,y:739,t:1527272055272};\\\", \\\"{x:646,y:758,t:1527272055288};\\\", \\\"{x:554,y:776,t:1527272055305};\\\", \\\"{x:463,y:783,t:1527272055322};\\\", \\\"{x:371,y:787,t:1527272055339};\\\", \\\"{x:187,y:784,t:1527272055355};\\\", \\\"{x:28,y:796,t:1527272055371};\\\", \\\"{x:0,y:793,t:1527272055388};\\\", \\\"{x:0,y:789,t:1527272055405};\\\", \\\"{x:0,y:785,t:1527272055422};\\\", \\\"{x:0,y:784,t:1527272055438};\\\", \\\"{x:0,y:781,t:1527272055475};\\\", \\\"{x:3,y:779,t:1527272055488};\\\", \\\"{x:15,y:767,t:1527272055505};\\\", \\\"{x:27,y:757,t:1527272055522};\\\", \\\"{x:45,y:740,t:1527272055538};\\\", \\\"{x:66,y:718,t:1527272055555};\\\", \\\"{x:86,y:703,t:1527272055572};\\\", \\\"{x:122,y:671,t:1527272055588};\\\", \\\"{x:143,y:643,t:1527272055606};\\\", \\\"{x:164,y:617,t:1527272055623};\\\", \\\"{x:179,y:594,t:1527272055638};\\\", \\\"{x:184,y:580,t:1527272055655};\\\", \\\"{x:191,y:567,t:1527272055671};\\\", \\\"{x:196,y:558,t:1527272055688};\\\", \\\"{x:200,y:551,t:1527272055704};\\\", \\\"{x:206,y:547,t:1527272055721};\\\", \\\"{x:214,y:543,t:1527272055738};\\\", \\\"{x:224,y:538,t:1527272055754};\\\", \\\"{x:254,y:528,t:1527272055771};\\\", \\\"{x:278,y:525,t:1527272055789};\\\", \\\"{x:302,y:518,t:1527272055805};\\\", \\\"{x:323,y:511,t:1527272055822};\\\", \\\"{x:339,y:508,t:1527272055838};\\\", \\\"{x:342,y:507,t:1527272055854};\\\", \\\"{x:346,y:506,t:1527272055871};\\\", \\\"{x:350,y:505,t:1527272055888};\\\", \\\"{x:359,y:504,t:1527272055904};\\\", \\\"{x:379,y:501,t:1527272055922};\\\", \\\"{x:416,y:495,t:1527272055939};\\\", \\\"{x:468,y:487,t:1527272055955};\\\", \\\"{x:491,y:483,t:1527272055971};\\\", \\\"{x:507,y:477,t:1527272055989};\\\", \\\"{x:513,y:477,t:1527272056004};\\\", \\\"{x:515,y:474,t:1527272056021};\\\", \\\"{x:516,y:475,t:1527272056131};\\\", \\\"{x:517,y:478,t:1527272056139};\\\", \\\"{x:517,y:480,t:1527272056154};\\\", \\\"{x:512,y:492,t:1527272056171};\\\", \\\"{x:503,y:503,t:1527272056187};\\\", \\\"{x:491,y:512,t:1527272056205};\\\", \\\"{x:473,y:521,t:1527272056223};\\\", \\\"{x:455,y:527,t:1527272056238};\\\", \\\"{x:434,y:533,t:1527272056255};\\\", \\\"{x:413,y:538,t:1527272056271};\\\", \\\"{x:397,y:543,t:1527272056288};\\\", \\\"{x:388,y:544,t:1527272056305};\\\", \\\"{x:388,y:545,t:1527272056322};\\\", \\\"{x:385,y:546,t:1527272056387};\\\", \\\"{x:384,y:548,t:1527272056402};\\\", \\\"{x:382,y:550,t:1527272056411};\\\", \\\"{x:380,y:552,t:1527272056422};\\\", \\\"{x:371,y:554,t:1527272056439};\\\", \\\"{x:363,y:556,t:1527272056456};\\\", \\\"{x:346,y:561,t:1527272056471};\\\", \\\"{x:320,y:562,t:1527272056488};\\\", \\\"{x:297,y:567,t:1527272056505};\\\", \\\"{x:275,y:567,t:1527272056522};\\\", \\\"{x:265,y:567,t:1527272056538};\\\", \\\"{x:249,y:566,t:1527272056555};\\\", \\\"{x:246,y:566,t:1527272056572};\\\", \\\"{x:244,y:567,t:1527272056588};\\\", \\\"{x:239,y:569,t:1527272056605};\\\", \\\"{x:237,y:569,t:1527272056683};\\\", \\\"{x:234,y:569,t:1527272056690};\\\", \\\"{x:232,y:569,t:1527272056705};\\\", \\\"{x:220,y:567,t:1527272056722};\\\", \\\"{x:216,y:563,t:1527272056738};\\\", \\\"{x:197,y:561,t:1527272056756};\\\", \\\"{x:195,y:561,t:1527272056772};\\\", \\\"{x:193,y:561,t:1527272056788};\\\", \\\"{x:191,y:561,t:1527272056805};\\\", \\\"{x:189,y:560,t:1527272056822};\\\", \\\"{x:189,y:559,t:1527272056851};\\\", \\\"{x:189,y:558,t:1527272056859};\\\", \\\"{x:188,y:558,t:1527272057068};\\\", \\\"{x:186,y:558,t:1527272057075};\\\", \\\"{x:184,y:558,t:1527272057089};\\\", \\\"{x:173,y:557,t:1527272057105};\\\", \\\"{x:156,y:555,t:1527272057122};\\\", \\\"{x:149,y:553,t:1527272057139};\\\", \\\"{x:148,y:553,t:1527272057155};\\\", \\\"{x:147,y:553,t:1527272057172};\\\", \\\"{x:154,y:553,t:1527272057859};\\\", \\\"{x:163,y:553,t:1527272057873};\\\", \\\"{x:202,y:553,t:1527272057889};\\\", \\\"{x:257,y:553,t:1527272057906};\\\", \\\"{x:336,y:553,t:1527272057923};\\\", \\\"{x:380,y:552,t:1527272057941};\\\", \\\"{x:403,y:549,t:1527272057956};\\\", \\\"{x:420,y:547,t:1527272057973};\\\", \\\"{x:433,y:545,t:1527272057989};\\\", \\\"{x:438,y:543,t:1527272058006};\\\", \\\"{x:446,y:541,t:1527272058023};\\\", \\\"{x:450,y:539,t:1527272058039};\\\", \\\"{x:456,y:536,t:1527272058056};\\\", \\\"{x:462,y:532,t:1527272058074};\\\", \\\"{x:470,y:529,t:1527272058091};\\\", \\\"{x:479,y:525,t:1527272058106};\\\", \\\"{x:506,y:519,t:1527272058123};\\\", \\\"{x:520,y:514,t:1527272058141};\\\", \\\"{x:524,y:513,t:1527272058156};\\\", \\\"{x:525,y:512,t:1527272058174};\\\", \\\"{x:522,y:512,t:1527272058275};\\\", \\\"{x:516,y:515,t:1527272058289};\\\", \\\"{x:502,y:524,t:1527272058307};\\\", \\\"{x:471,y:534,t:1527272058323};\\\", \\\"{x:443,y:540,t:1527272058340};\\\", \\\"{x:404,y:543,t:1527272058356};\\\", \\\"{x:378,y:547,t:1527272058374};\\\", \\\"{x:315,y:552,t:1527272058390};\\\", \\\"{x:270,y:552,t:1527272058408};\\\", \\\"{x:237,y:552,t:1527272058423};\\\", \\\"{x:216,y:549,t:1527272058440};\\\", \\\"{x:210,y:549,t:1527272058457};\\\", \\\"{x:209,y:549,t:1527272058473};\\\", \\\"{x:207,y:549,t:1527272058588};\\\", \\\"{x:205,y:551,t:1527272058594};\\\", \\\"{x:203,y:551,t:1527272058610};\\\", \\\"{x:202,y:552,t:1527272058623};\\\", \\\"{x:201,y:552,t:1527272058640};\\\", \\\"{x:200,y:552,t:1527272058657};\\\", \\\"{x:199,y:552,t:1527272058683};\\\", \\\"{x:198,y:553,t:1527272058691};\\\", \\\"{x:192,y:555,t:1527272058707};\\\", \\\"{x:183,y:556,t:1527272058724};\\\", \\\"{x:172,y:558,t:1527272058740};\\\", \\\"{x:164,y:560,t:1527272058757};\\\", \\\"{x:161,y:560,t:1527272058773};\\\", \\\"{x:160,y:560,t:1527272058790};\\\", \\\"{x:158,y:560,t:1527272058843};\\\", \\\"{x:157,y:560,t:1527272058899};\\\", \\\"{x:154,y:559,t:1527272058939};\\\", \\\"{x:154,y:558,t:1527272058947};\\\", \\\"{x:153,y:557,t:1527272058957};\\\", \\\"{x:152,y:556,t:1527272058973};\\\", \\\"{x:152,y:555,t:1527272058990};\\\", \\\"{x:152,y:554,t:1527272059007};\\\", \\\"{x:152,y:553,t:1527272059084};\\\", \\\"{x:152,y:552,t:1527272059115};\\\", \\\"{x:152,y:551,t:1527272059139};\\\", \\\"{x:153,y:551,t:1527272059339};\\\", \\\"{x:154,y:551,t:1527272059347};\\\", \\\"{x:155,y:551,t:1527272059379};\\\", \\\"{x:155,y:552,t:1527272059876};\\\", \\\"{x:155,y:553,t:1527272059891};\\\", \\\"{x:153,y:554,t:1527272059908};\\\", \\\"{x:152,y:556,t:1527272059924};\\\", \\\"{x:152,y:561,t:1527272059941};\\\", \\\"{x:150,y:568,t:1527272059958};\\\", \\\"{x:150,y:575,t:1527272059974};\\\", \\\"{x:149,y:575,t:1527272059992};\\\", \\\"{x:149,y:577,t:1527272060019};\\\", \\\"{x:148,y:577,t:1527272060099};\\\", \\\"{x:147,y:580,t:1527272060211};\\\", \\\"{x:147,y:581,t:1527272060235};\\\", \\\"{x:147,y:582,t:1527272060243};\\\", \\\"{x:147,y:583,t:1527272060259};\\\", \\\"{x:147,y:585,t:1527272060275};\\\", \\\"{x:148,y:586,t:1527272060299};\\\", \\\"{x:148,y:587,t:1527272060322};\\\", \\\"{x:148,y:589,t:1527272060331};\\\", \\\"{x:149,y:589,t:1527272060341};\\\", \\\"{x:150,y:590,t:1527272060358};\\\", \\\"{x:151,y:590,t:1527272060387};\\\", \\\"{x:151,y:592,t:1527272060395};\\\", \\\"{x:152,y:592,t:1527272060419};\\\", \\\"{x:153,y:593,t:1527272060426};\\\", \\\"{x:155,y:594,t:1527272060451};\\\", \\\"{x:156,y:596,t:1527272060474};\\\", \\\"{x:157,y:596,t:1527272060491};\\\", \\\"{x:158,y:598,t:1527272060509};\\\", \\\"{x:160,y:600,t:1527272060525};\\\", \\\"{x:165,y:603,t:1527272060543};\\\", \\\"{x:172,y:606,t:1527272060558};\\\", \\\"{x:177,y:608,t:1527272060575};\\\", \\\"{x:184,y:608,t:1527272060591};\\\", \\\"{x:192,y:611,t:1527272060608};\\\", \\\"{x:194,y:612,t:1527272060625};\\\", \\\"{x:195,y:612,t:1527272060641};\\\", \\\"{x:196,y:612,t:1527272060675};\\\", \\\"{x:203,y:610,t:1527272060692};\\\", \\\"{x:213,y:610,t:1527272060708};\\\", \\\"{x:220,y:610,t:1527272060725};\\\", \\\"{x:236,y:609,t:1527272060742};\\\", \\\"{x:253,y:609,t:1527272060758};\\\", \\\"{x:260,y:609,t:1527272060775};\\\", \\\"{x:263,y:610,t:1527272060792};\\\", \\\"{x:268,y:612,t:1527272060808};\\\", \\\"{x:270,y:612,t:1527272060825};\\\", \\\"{x:272,y:612,t:1527272060843};\\\", \\\"{x:273,y:612,t:1527272060859};\\\", \\\"{x:276,y:612,t:1527272060875};\\\", \\\"{x:279,y:612,t:1527272060892};\\\", \\\"{x:285,y:613,t:1527272060908};\\\", \\\"{x:292,y:613,t:1527272060925};\\\", \\\"{x:298,y:613,t:1527272060942};\\\", \\\"{x:302,y:613,t:1527272060959};\\\", \\\"{x:307,y:613,t:1527272060975};\\\", \\\"{x:311,y:613,t:1527272060992};\\\", \\\"{x:315,y:613,t:1527272061008};\\\", \\\"{x:318,y:613,t:1527272061025};\\\", \\\"{x:329,y:613,t:1527272061042};\\\", \\\"{x:345,y:613,t:1527272061059};\\\", \\\"{x:360,y:613,t:1527272061075};\\\", \\\"{x:373,y:613,t:1527272061092};\\\", \\\"{x:385,y:613,t:1527272061110};\\\", \\\"{x:390,y:613,t:1527272061125};\\\", \\\"{x:393,y:613,t:1527272061142};\\\", \\\"{x:394,y:613,t:1527272061159};\\\", \\\"{x:397,y:613,t:1527272061175};\\\", \\\"{x:398,y:613,t:1527272061192};\\\", \\\"{x:402,y:613,t:1527272061209};\\\", \\\"{x:404,y:613,t:1527272061225};\\\", \\\"{x:414,y:610,t:1527272061242};\\\", \\\"{x:434,y:605,t:1527272061259};\\\", \\\"{x:455,y:600,t:1527272061276};\\\", \\\"{x:479,y:596,t:1527272061293};\\\", \\\"{x:516,y:591,t:1527272061310};\\\", \\\"{x:545,y:588,t:1527272061326};\\\", \\\"{x:586,y:581,t:1527272061342};\\\", \\\"{x:620,y:576,t:1527272061360};\\\", \\\"{x:646,y:572,t:1527272061376};\\\", \\\"{x:679,y:563,t:1527272061392};\\\", \\\"{x:717,y:554,t:1527272061411};\\\", \\\"{x:746,y:542,t:1527272061427};\\\", \\\"{x:779,y:531,t:1527272061442};\\\", \\\"{x:805,y:521,t:1527272061459};\\\", \\\"{x:809,y:518,t:1527272061476};\\\", \\\"{x:809,y:517,t:1527272061555};\\\", \\\"{x:807,y:516,t:1527272061571};\\\", \\\"{x:798,y:514,t:1527272061579};\\\", \\\"{x:786,y:511,t:1527272061592};\\\", \\\"{x:759,y:509,t:1527272061609};\\\", \\\"{x:732,y:509,t:1527272061626};\\\", \\\"{x:706,y:509,t:1527272061643};\\\", \\\"{x:705,y:509,t:1527272061659};\\\", \\\"{x:707,y:509,t:1527272061755};\\\", \\\"{x:710,y:509,t:1527272061763};\\\", \\\"{x:718,y:509,t:1527272061776};\\\", \\\"{x:745,y:505,t:1527272061793};\\\", \\\"{x:781,y:505,t:1527272061809};\\\", \\\"{x:823,y:505,t:1527272061827};\\\", \\\"{x:848,y:498,t:1527272061843};\\\", \\\"{x:866,y:498,t:1527272061859};\\\", \\\"{x:867,y:498,t:1527272061876};\\\", \\\"{x:866,y:498,t:1527272062043};\\\", \\\"{x:865,y:498,t:1527272062059};\\\", \\\"{x:864,y:498,t:1527272062076};\\\", \\\"{x:863,y:499,t:1527272062093};\\\", \\\"{x:862,y:499,t:1527272062122};\\\", \\\"{x:861,y:500,t:1527272062155};\\\", \\\"{x:860,y:500,t:1527272062171};\\\", \\\"{x:859,y:501,t:1527272062179};\\\", \\\"{x:856,y:502,t:1527272062193};\\\", \\\"{x:853,y:503,t:1527272062210};\\\", \\\"{x:850,y:503,t:1527272062226};\\\", \\\"{x:848,y:504,t:1527272062323};\\\", \\\"{x:845,y:504,t:1527272062330};\\\", \\\"{x:844,y:504,t:1527272062344};\\\", \\\"{x:842,y:506,t:1527272062360};\\\", \\\"{x:841,y:506,t:1527272062376};\\\", \\\"{x:840,y:506,t:1527272062395};\\\", \\\"{x:839,y:506,t:1527272062467};\\\", \\\"{x:838,y:506,t:1527272062476};\\\", \\\"{x:837,y:506,t:1527272062493};\\\", \\\"{x:836,y:507,t:1527272062699};\\\", \\\"{x:835,y:507,t:1527272062710};\\\", \\\"{x:824,y:516,t:1527272062726};\\\", \\\"{x:815,y:522,t:1527272062744};\\\", \\\"{x:796,y:532,t:1527272062761};\\\", \\\"{x:780,y:543,t:1527272062777};\\\", \\\"{x:760,y:551,t:1527272062794};\\\", \\\"{x:739,y:558,t:1527272062811};\\\", \\\"{x:697,y:575,t:1527272062827};\\\", \\\"{x:674,y:586,t:1527272062843};\\\", \\\"{x:658,y:596,t:1527272062861};\\\", \\\"{x:642,y:603,t:1527272062878};\\\", \\\"{x:631,y:610,t:1527272062894};\\\", \\\"{x:628,y:614,t:1527272062910};\\\", \\\"{x:621,y:622,t:1527272062927};\\\", \\\"{x:615,y:630,t:1527272062943};\\\", \\\"{x:608,y:639,t:1527272062961};\\\", \\\"{x:598,y:651,t:1527272062977};\\\", \\\"{x:584,y:662,t:1527272062994};\\\", \\\"{x:568,y:674,t:1527272063010};\\\", \\\"{x:545,y:690,t:1527272063027};\\\", \\\"{x:530,y:697,t:1527272063043};\\\", \\\"{x:522,y:703,t:1527272063061};\\\", \\\"{x:511,y:710,t:1527272063077};\\\", \\\"{x:497,y:723,t:1527272063094};\\\", \\\"{x:487,y:732,t:1527272063111};\\\", \\\"{x:480,y:739,t:1527272063128};\\\", \\\"{x:477,y:742,t:1527272063144};\\\", \\\"{x:476,y:743,t:1527272063161};\\\" ] }, { \\\"rt\\\": 11256, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 503356, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:476,y:742,t:1527272070523};\\\", \\\"{x:476,y:741,t:1527272072955};\\\", \\\"{x:477,y:736,t:1527272072964};\\\", \\\"{x:480,y:724,t:1527272072980};\\\", \\\"{x:482,y:716,t:1527272072997};\\\", \\\"{x:483,y:709,t:1527272073014};\\\", \\\"{x:486,y:702,t:1527272073031};\\\", \\\"{x:487,y:698,t:1527272073052};\\\", \\\"{x:490,y:694,t:1527272073069};\\\", \\\"{x:492,y:692,t:1527272073086};\\\", \\\"{x:493,y:688,t:1527272073101};\\\", \\\"{x:493,y:683,t:1527272073119};\\\", \\\"{x:494,y:676,t:1527272073136};\\\", \\\"{x:497,y:672,t:1527272073163};\\\", \\\"{x:497,y:668,t:1527272073171};\\\", \\\"{x:497,y:662,t:1527272073186};\\\", \\\"{x:497,y:653,t:1527272073201};\\\", \\\"{x:497,y:637,t:1527272073219};\\\", \\\"{x:493,y:623,t:1527272073237};\\\", \\\"{x:489,y:612,t:1527272073252};\\\", \\\"{x:485,y:603,t:1527272073268};\\\", \\\"{x:483,y:598,t:1527272073286};\\\", \\\"{x:481,y:596,t:1527272073302};\\\", \\\"{x:479,y:592,t:1527272073319};\\\", \\\"{x:473,y:588,t:1527272073336};\\\", \\\"{x:460,y:586,t:1527272073352};\\\", \\\"{x:440,y:577,t:1527272073369};\\\", \\\"{x:435,y:575,t:1527272073386};\\\", \\\"{x:418,y:571,t:1527272073402};\\\", \\\"{x:390,y:561,t:1527272073419};\\\", \\\"{x:379,y:558,t:1527272073436};\\\", \\\"{x:372,y:558,t:1527272073452};\\\", \\\"{x:364,y:558,t:1527272073468};\\\", \\\"{x:355,y:557,t:1527272073486};\\\", \\\"{x:350,y:557,t:1527272073502};\\\", \\\"{x:343,y:557,t:1527272073518};\\\", \\\"{x:337,y:557,t:1527272073536};\\\", \\\"{x:332,y:557,t:1527272073552};\\\", \\\"{x:323,y:557,t:1527272073569};\\\", \\\"{x:310,y:557,t:1527272073586};\\\", \\\"{x:295,y:557,t:1527272073602};\\\", \\\"{x:262,y:557,t:1527272073619};\\\", \\\"{x:248,y:552,t:1527272073636};\\\", \\\"{x:238,y:552,t:1527272073652};\\\", \\\"{x:233,y:551,t:1527272073669};\\\", \\\"{x:229,y:550,t:1527272073686};\\\", \\\"{x:224,y:550,t:1527272073703};\\\", \\\"{x:211,y:548,t:1527272073719};\\\", \\\"{x:199,y:546,t:1527272073736};\\\", \\\"{x:194,y:546,t:1527272073753};\\\", \\\"{x:188,y:545,t:1527272073769};\\\", \\\"{x:186,y:545,t:1527272073786};\\\", \\\"{x:185,y:544,t:1527272073867};\\\", \\\"{x:184,y:544,t:1527272073931};\\\", \\\"{x:183,y:544,t:1527272074043};\\\", \\\"{x:181,y:544,t:1527272074371};\\\", \\\"{x:180,y:544,t:1527272074475};\\\", \\\"{x:178,y:544,t:1527272074811};\\\", \\\"{x:177,y:544,t:1527272074827};\\\", \\\"{x:176,y:544,t:1527272074899};\\\", \\\"{x:175,y:544,t:1527272074915};\\\", \\\"{x:177,y:544,t:1527272075139};\\\", \\\"{x:179,y:543,t:1527272075154};\\\", \\\"{x:187,y:541,t:1527272075170};\\\", \\\"{x:213,y:554,t:1527272075187};\\\", \\\"{x:277,y:606,t:1527272075204};\\\", \\\"{x:374,y:672,t:1527272075220};\\\", \\\"{x:477,y:750,t:1527272075237};\\\", \\\"{x:548,y:803,t:1527272075255};\\\", \\\"{x:607,y:848,t:1527272075271};\\\", \\\"{x:643,y:877,t:1527272075286};\\\", \\\"{x:667,y:900,t:1527272075304};\\\", \\\"{x:685,y:912,t:1527272075320};\\\", \\\"{x:687,y:914,t:1527272075337};\\\", \\\"{x:688,y:915,t:1527272075354};\\\", \\\"{x:689,y:915,t:1527272075411};\\\", \\\"{x:690,y:914,t:1527272075451};\\\", \\\"{x:690,y:908,t:1527272075507};\\\", \\\"{x:688,y:898,t:1527272075520};\\\", \\\"{x:675,y:879,t:1527272075537};\\\", \\\"{x:665,y:863,t:1527272075553};\\\", \\\"{x:650,y:844,t:1527272075570};\\\", \\\"{x:627,y:824,t:1527272075587};\\\", \\\"{x:612,y:813,t:1527272075604};\\\", \\\"{x:602,y:806,t:1527272075620};\\\", \\\"{x:596,y:800,t:1527272075637};\\\", \\\"{x:594,y:799,t:1527272075654};\\\", \\\"{x:591,y:798,t:1527272075670};\\\", \\\"{x:590,y:797,t:1527272075687};\\\", \\\"{x:587,y:796,t:1527272075703};\\\", \\\"{x:582,y:795,t:1527272075721};\\\", \\\"{x:576,y:793,t:1527272075737};\\\", \\\"{x:565,y:790,t:1527272075754};\\\", \\\"{x:553,y:785,t:1527272075770};\\\", \\\"{x:530,y:772,t:1527272075787};\\\", \\\"{x:522,y:765,t:1527272075804};\\\", \\\"{x:512,y:758,t:1527272075820};\\\", \\\"{x:506,y:752,t:1527272075838};\\\", \\\"{x:499,y:747,t:1527272075853};\\\", \\\"{x:493,y:743,t:1527272075871};\\\", \\\"{x:492,y:742,t:1527272075888};\\\" ] }, { \\\"rt\\\": 35014, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 539573, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-N -N -04 PM-04 PM-X -Z -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:740,t:1527272082499};\\\", \\\"{x:518,y:736,t:1527272082524};\\\", \\\"{x:535,y:736,t:1527272082532};\\\", \\\"{x:585,y:741,t:1527272082550};\\\", \\\"{x:617,y:750,t:1527272082566};\\\", \\\"{x:651,y:763,t:1527272082582};\\\", \\\"{x:674,y:772,t:1527272082593};\\\", \\\"{x:701,y:780,t:1527272082609};\\\", \\\"{x:719,y:786,t:1527272082626};\\\", \\\"{x:732,y:790,t:1527272082642};\\\", \\\"{x:739,y:790,t:1527272082660};\\\", \\\"{x:743,y:790,t:1527272082676};\\\", \\\"{x:749,y:792,t:1527272082693};\\\", \\\"{x:759,y:793,t:1527272082710};\\\", \\\"{x:784,y:801,t:1527272082726};\\\", \\\"{x:813,y:811,t:1527272082744};\\\", \\\"{x:854,y:820,t:1527272082760};\\\", \\\"{x:891,y:831,t:1527272082776};\\\", \\\"{x:937,y:846,t:1527272082793};\\\", \\\"{x:990,y:861,t:1527272082810};\\\", \\\"{x:1041,y:876,t:1527272082826};\\\", \\\"{x:1157,y:894,t:1527272082843};\\\", \\\"{x:1249,y:912,t:1527272082860};\\\", \\\"{x:1335,y:923,t:1527272082876};\\\", \\\"{x:1388,y:931,t:1527272082893};\\\", \\\"{x:1458,y:939,t:1527272082910};\\\", \\\"{x:1490,y:945,t:1527272082926};\\\", \\\"{x:1541,y:949,t:1527272082944};\\\", \\\"{x:1587,y:945,t:1527272082960};\\\", \\\"{x:1623,y:948,t:1527272082976};\\\", \\\"{x:1648,y:950,t:1527272082993};\\\", \\\"{x:1652,y:950,t:1527272083010};\\\", \\\"{x:1654,y:950,t:1527272083027};\\\", \\\"{x:1655,y:950,t:1527272083067};\\\", \\\"{x:1657,y:950,t:1527272083115};\\\", \\\"{x:1652,y:949,t:1527272083307};\\\", \\\"{x:1647,y:945,t:1527272083315};\\\", \\\"{x:1641,y:941,t:1527272083327};\\\", \\\"{x:1624,y:933,t:1527272083344};\\\", \\\"{x:1605,y:925,t:1527272083360};\\\", \\\"{x:1590,y:922,t:1527272083377};\\\", \\\"{x:1579,y:916,t:1527272083394};\\\", \\\"{x:1572,y:914,t:1527272083411};\\\", \\\"{x:1564,y:910,t:1527272083428};\\\", \\\"{x:1562,y:910,t:1527272083444};\\\", \\\"{x:1558,y:909,t:1527272083867};\\\", \\\"{x:1552,y:907,t:1527272083877};\\\", \\\"{x:1549,y:907,t:1527272083894};\\\", \\\"{x:1546,y:905,t:1527272083911};\\\", \\\"{x:1544,y:902,t:1527272083927};\\\", \\\"{x:1544,y:894,t:1527272083945};\\\", \\\"{x:1545,y:887,t:1527272083961};\\\", \\\"{x:1550,y:880,t:1527272083978};\\\", \\\"{x:1554,y:877,t:1527272083994};\\\", \\\"{x:1558,y:869,t:1527272084011};\\\", \\\"{x:1564,y:857,t:1527272084028};\\\", \\\"{x:1567,y:850,t:1527272084044};\\\", \\\"{x:1571,y:845,t:1527272084062};\\\", \\\"{x:1573,y:842,t:1527272084077};\\\", \\\"{x:1573,y:841,t:1527272084095};\\\", \\\"{x:1574,y:840,t:1527272084111};\\\", \\\"{x:1580,y:835,t:1527272084307};\\\", \\\"{x:1580,y:832,t:1527272084314};\\\", \\\"{x:1584,y:828,t:1527272084328};\\\", \\\"{x:1586,y:824,t:1527272084345};\\\", \\\"{x:1591,y:814,t:1527272084362};\\\", \\\"{x:1594,y:808,t:1527272084378};\\\", \\\"{x:1597,y:798,t:1527272084395};\\\", \\\"{x:1602,y:782,t:1527272084411};\\\", \\\"{x:1607,y:766,t:1527272084428};\\\", \\\"{x:1611,y:758,t:1527272084444};\\\", \\\"{x:1618,y:745,t:1527272084461};\\\", \\\"{x:1623,y:733,t:1527272084478};\\\", \\\"{x:1627,y:720,t:1527272084494};\\\", \\\"{x:1629,y:711,t:1527272084512};\\\", \\\"{x:1632,y:704,t:1527272084529};\\\", \\\"{x:1633,y:697,t:1527272084545};\\\", \\\"{x:1633,y:692,t:1527272084561};\\\", \\\"{x:1633,y:687,t:1527272084578};\\\", \\\"{x:1633,y:684,t:1527272084594};\\\", \\\"{x:1633,y:682,t:1527272084611};\\\", \\\"{x:1633,y:681,t:1527272084707};\\\", \\\"{x:1632,y:682,t:1527272084730};\\\", \\\"{x:1630,y:686,t:1527272084744};\\\", \\\"{x:1627,y:691,t:1527272084762};\\\", \\\"{x:1625,y:695,t:1527272084778};\\\", \\\"{x:1624,y:697,t:1527272084794};\\\", \\\"{x:1624,y:698,t:1527272084818};\\\", \\\"{x:1624,y:699,t:1527272084834};\\\", \\\"{x:1624,y:702,t:1527272084845};\\\", \\\"{x:1625,y:711,t:1527272084862};\\\", \\\"{x:1639,y:735,t:1527272084879};\\\", \\\"{x:1651,y:757,t:1527272084895};\\\", \\\"{x:1662,y:782,t:1527272084912};\\\", \\\"{x:1671,y:807,t:1527272084929};\\\", \\\"{x:1678,y:821,t:1527272084946};\\\", \\\"{x:1678,y:831,t:1527272084963};\\\", \\\"{x:1678,y:842,t:1527272084979};\\\", \\\"{x:1678,y:847,t:1527272084994};\\\", \\\"{x:1678,y:853,t:1527272085011};\\\", \\\"{x:1674,y:860,t:1527272085028};\\\", \\\"{x:1669,y:866,t:1527272085045};\\\", \\\"{x:1665,y:869,t:1527272085062};\\\", \\\"{x:1659,y:876,t:1527272085079};\\\", \\\"{x:1656,y:878,t:1527272085095};\\\", \\\"{x:1654,y:880,t:1527272085171};\\\", \\\"{x:1653,y:882,t:1527272085178};\\\", \\\"{x:1648,y:889,t:1527272085195};\\\", \\\"{x:1646,y:894,t:1527272085211};\\\", \\\"{x:1645,y:898,t:1527272085229};\\\", \\\"{x:1645,y:899,t:1527272085246};\\\", \\\"{x:1644,y:902,t:1527272085261};\\\", \\\"{x:1642,y:905,t:1527272085279};\\\", \\\"{x:1642,y:908,t:1527272085295};\\\", \\\"{x:1641,y:912,t:1527272085311};\\\", \\\"{x:1639,y:918,t:1527272085329};\\\", \\\"{x:1636,y:926,t:1527272085345};\\\", \\\"{x:1632,y:930,t:1527272085362};\\\", \\\"{x:1629,y:935,t:1527272085379};\\\", \\\"{x:1628,y:936,t:1527272085396};\\\", \\\"{x:1628,y:937,t:1527272086163};\\\", \\\"{x:1627,y:937,t:1527272086355};\\\", \\\"{x:1626,y:940,t:1527272086362};\\\", \\\"{x:1626,y:945,t:1527272086379};\\\", \\\"{x:1626,y:948,t:1527272086396};\\\", \\\"{x:1626,y:949,t:1527272086412};\\\", \\\"{x:1625,y:951,t:1527272086515};\\\", \\\"{x:1625,y:952,t:1527272086547};\\\", \\\"{x:1625,y:953,t:1527272087347};\\\", \\\"{x:1625,y:954,t:1527272087363};\\\", \\\"{x:1625,y:955,t:1527272087380};\\\", \\\"{x:1625,y:956,t:1527272087418};\\\", \\\"{x:1625,y:957,t:1527272087498};\\\", \\\"{x:1624,y:957,t:1527272087513};\\\", \\\"{x:1623,y:960,t:1527272087530};\\\", \\\"{x:1623,y:962,t:1527272087547};\\\", \\\"{x:1623,y:963,t:1527272087563};\\\", \\\"{x:1623,y:965,t:1527272087581};\\\", \\\"{x:1623,y:966,t:1527272087597};\\\", \\\"{x:1623,y:968,t:1527272087614};\\\", \\\"{x:1622,y:970,t:1527272087631};\\\", \\\"{x:1622,y:972,t:1527272087647};\\\", \\\"{x:1622,y:974,t:1527272087667};\\\", \\\"{x:1620,y:976,t:1527272087682};\\\", \\\"{x:1619,y:978,t:1527272087698};\\\", \\\"{x:1619,y:981,t:1527272087713};\\\", \\\"{x:1619,y:985,t:1527272087731};\\\", \\\"{x:1618,y:986,t:1527272088042};\\\", \\\"{x:1617,y:986,t:1527272088051};\\\", \\\"{x:1614,y:986,t:1527272088064};\\\", \\\"{x:1603,y:980,t:1527272088080};\\\", \\\"{x:1594,y:974,t:1527272088098};\\\", \\\"{x:1589,y:968,t:1527272088114};\\\", \\\"{x:1588,y:965,t:1527272088131};\\\", \\\"{x:1586,y:963,t:1527272088163};\\\", \\\"{x:1586,y:962,t:1527272088170};\\\", \\\"{x:1585,y:960,t:1527272088181};\\\", \\\"{x:1583,y:955,t:1527272088198};\\\", \\\"{x:1581,y:949,t:1527272088214};\\\", \\\"{x:1576,y:942,t:1527272088230};\\\", \\\"{x:1574,y:936,t:1527272088247};\\\", \\\"{x:1574,y:933,t:1527272088265};\\\", \\\"{x:1572,y:931,t:1527272088281};\\\", \\\"{x:1568,y:925,t:1527272088297};\\\", \\\"{x:1564,y:923,t:1527272088315};\\\", \\\"{x:1564,y:922,t:1527272088331};\\\", \\\"{x:1564,y:920,t:1527272088883};\\\", \\\"{x:1567,y:926,t:1527272088914};\\\", \\\"{x:1568,y:930,t:1527272088932};\\\", \\\"{x:1571,y:931,t:1527272088948};\\\", \\\"{x:1571,y:932,t:1527272088964};\\\", \\\"{x:1572,y:932,t:1527272088994};\\\", \\\"{x:1575,y:934,t:1527272089002};\\\", \\\"{x:1576,y:934,t:1527272089051};\\\", \\\"{x:1576,y:933,t:1527272089139};\\\", \\\"{x:1575,y:929,t:1527272089148};\\\", \\\"{x:1556,y:916,t:1527272089164};\\\", \\\"{x:1537,y:898,t:1527272089181};\\\", \\\"{x:1513,y:879,t:1527272089198};\\\", \\\"{x:1491,y:860,t:1527272089216};\\\", \\\"{x:1480,y:852,t:1527272089231};\\\", \\\"{x:1471,y:843,t:1527272089248};\\\", \\\"{x:1469,y:840,t:1527272089266};\\\", \\\"{x:1469,y:838,t:1527272089281};\\\", \\\"{x:1469,y:834,t:1527272089299};\\\", \\\"{x:1469,y:829,t:1527272089316};\\\", \\\"{x:1469,y:823,t:1527272089332};\\\", \\\"{x:1472,y:819,t:1527272089348};\\\", \\\"{x:1475,y:815,t:1527272089366};\\\", \\\"{x:1475,y:813,t:1527272089381};\\\", \\\"{x:1476,y:811,t:1527272089398};\\\", \\\"{x:1478,y:808,t:1527272089416};\\\", \\\"{x:1478,y:805,t:1527272089432};\\\", \\\"{x:1480,y:801,t:1527272089448};\\\", \\\"{x:1480,y:798,t:1527272089466};\\\", \\\"{x:1482,y:794,t:1527272089481};\\\", \\\"{x:1487,y:783,t:1527272089499};\\\", \\\"{x:1490,y:773,t:1527272089516};\\\", \\\"{x:1493,y:766,t:1527272089531};\\\", \\\"{x:1496,y:758,t:1527272089548};\\\", \\\"{x:1497,y:756,t:1527272089566};\\\", \\\"{x:1497,y:755,t:1527272089581};\\\", \\\"{x:1497,y:754,t:1527272089643};\\\", \\\"{x:1498,y:754,t:1527272090242};\\\", \\\"{x:1499,y:754,t:1527272090250};\\\", \\\"{x:1499,y:755,t:1527272090275};\\\", \\\"{x:1499,y:756,t:1527272090515};\\\", \\\"{x:1499,y:757,t:1527272090547};\\\", \\\"{x:1499,y:758,t:1527272090579};\\\", \\\"{x:1499,y:759,t:1527272091027};\\\", \\\"{x:1499,y:761,t:1527272091051};\\\", \\\"{x:1499,y:764,t:1527272091066};\\\", \\\"{x:1499,y:765,t:1527272091083};\\\", \\\"{x:1498,y:766,t:1527272091100};\\\", \\\"{x:1497,y:767,t:1527272091122};\\\", \\\"{x:1496,y:768,t:1527272091155};\\\", \\\"{x:1495,y:769,t:1527272091178};\\\", \\\"{x:1494,y:772,t:1527272091195};\\\", \\\"{x:1492,y:773,t:1527272091219};\\\", \\\"{x:1492,y:774,t:1527272091251};\\\", \\\"{x:1491,y:775,t:1527272091283};\\\", \\\"{x:1491,y:776,t:1527272091299};\\\", \\\"{x:1489,y:776,t:1527272091314};\\\", \\\"{x:1487,y:778,t:1527272091322};\\\", \\\"{x:1486,y:778,t:1527272091334};\\\", \\\"{x:1483,y:781,t:1527272091350};\\\", \\\"{x:1482,y:782,t:1527272091367};\\\", \\\"{x:1481,y:783,t:1527272091384};\\\", \\\"{x:1480,y:783,t:1527272091419};\\\", \\\"{x:1480,y:782,t:1527272091554};\\\", \\\"{x:1480,y:780,t:1527272091567};\\\", \\\"{x:1483,y:777,t:1527272091584};\\\", \\\"{x:1484,y:777,t:1527272091611};\\\", \\\"{x:1483,y:777,t:1527272093483};\\\", \\\"{x:1482,y:777,t:1527272093587};\\\", \\\"{x:1480,y:777,t:1527272093602};\\\", \\\"{x:1479,y:778,t:1527272093618};\\\", \\\"{x:1476,y:778,t:1527272093706};\\\", \\\"{x:1475,y:778,t:1527272094043};\\\", \\\"{x:1474,y:778,t:1527272094059};\\\", \\\"{x:1473,y:778,t:1527272094098};\\\", \\\"{x:1472,y:779,t:1527272094130};\\\", \\\"{x:1470,y:781,t:1527272094146};\\\", \\\"{x:1470,y:783,t:1527272094178};\\\", \\\"{x:1469,y:785,t:1527272094194};\\\", \\\"{x:1469,y:787,t:1527272094202};\\\", \\\"{x:1467,y:790,t:1527272094218};\\\", \\\"{x:1465,y:793,t:1527272094236};\\\", \\\"{x:1465,y:795,t:1527272094253};\\\", \\\"{x:1465,y:796,t:1527272094269};\\\", \\\"{x:1465,y:797,t:1527272094286};\\\", \\\"{x:1465,y:800,t:1527272094303};\\\", \\\"{x:1465,y:802,t:1527272094319};\\\", \\\"{x:1465,y:808,t:1527272094336};\\\", \\\"{x:1463,y:814,t:1527272094353};\\\", \\\"{x:1463,y:819,t:1527272094369};\\\", \\\"{x:1463,y:820,t:1527272094385};\\\", \\\"{x:1463,y:821,t:1527272094859};\\\", \\\"{x:1465,y:822,t:1527272094874};\\\", \\\"{x:1466,y:823,t:1527272094890};\\\", \\\"{x:1467,y:823,t:1527272094903};\\\", \\\"{x:1467,y:824,t:1527272094963};\\\", \\\"{x:1469,y:827,t:1527272094970};\\\", \\\"{x:1470,y:829,t:1527272094986};\\\", \\\"{x:1476,y:835,t:1527272095003};\\\", \\\"{x:1478,y:837,t:1527272095019};\\\", \\\"{x:1479,y:837,t:1527272095051};\\\", \\\"{x:1480,y:837,t:1527272095075};\\\", \\\"{x:1481,y:837,t:1527272096595};\\\", \\\"{x:1482,y:837,t:1527272096611};\\\", \\\"{x:1483,y:837,t:1527272096621};\\\", \\\"{x:1484,y:836,t:1527272096638};\\\", \\\"{x:1488,y:834,t:1527272096654};\\\", \\\"{x:1518,y:831,t:1527272096671};\\\", \\\"{x:1530,y:829,t:1527272096688};\\\", \\\"{x:1539,y:829,t:1527272096703};\\\", \\\"{x:1548,y:832,t:1527272096721};\\\", \\\"{x:1553,y:835,t:1527272096738};\\\", \\\"{x:1561,y:838,t:1527272096755};\\\", \\\"{x:1562,y:838,t:1527272096778};\\\", \\\"{x:1564,y:838,t:1527272096794};\\\", \\\"{x:1566,y:838,t:1527272096805};\\\", \\\"{x:1568,y:838,t:1527272096821};\\\", \\\"{x:1571,y:838,t:1527272096838};\\\", \\\"{x:1575,y:844,t:1527272096855};\\\", \\\"{x:1580,y:851,t:1527272096871};\\\", \\\"{x:1580,y:853,t:1527272096887};\\\", \\\"{x:1580,y:854,t:1527272096930};\\\", \\\"{x:1580,y:855,t:1527272096939};\\\", \\\"{x:1580,y:860,t:1527272096954};\\\", \\\"{x:1580,y:865,t:1527272096971};\\\", \\\"{x:1580,y:868,t:1527272096988};\\\", \\\"{x:1583,y:875,t:1527272097004};\\\", \\\"{x:1588,y:884,t:1527272097021};\\\", \\\"{x:1595,y:890,t:1527272097038};\\\", \\\"{x:1601,y:901,t:1527272097055};\\\", \\\"{x:1606,y:908,t:1527272097071};\\\", \\\"{x:1608,y:913,t:1527272097087};\\\", \\\"{x:1609,y:914,t:1527272097106};\\\", \\\"{x:1609,y:915,t:1527272097379};\\\", \\\"{x:1609,y:917,t:1527272097388};\\\", \\\"{x:1608,y:919,t:1527272097410};\\\", \\\"{x:1608,y:922,t:1527272097422};\\\", \\\"{x:1608,y:927,t:1527272097438};\\\", \\\"{x:1608,y:934,t:1527272097455};\\\", \\\"{x:1604,y:940,t:1527272097472};\\\", \\\"{x:1602,y:944,t:1527272097488};\\\", \\\"{x:1597,y:949,t:1527272097505};\\\", \\\"{x:1592,y:955,t:1527272097522};\\\", \\\"{x:1589,y:958,t:1527272097538};\\\", \\\"{x:1588,y:958,t:1527272097555};\\\", \\\"{x:1586,y:958,t:1527272097572};\\\", \\\"{x:1584,y:961,t:1527272097589};\\\", \\\"{x:1584,y:963,t:1527272097611};\\\", \\\"{x:1586,y:963,t:1527272097622};\\\", \\\"{x:1590,y:963,t:1527272097639};\\\", \\\"{x:1593,y:962,t:1527272097655};\\\", \\\"{x:1598,y:959,t:1527272097672};\\\", \\\"{x:1611,y:948,t:1527272097689};\\\", \\\"{x:1629,y:931,t:1527272097705};\\\", \\\"{x:1648,y:911,t:1527272097722};\\\", \\\"{x:1693,y:862,t:1527272097738};\\\", \\\"{x:1709,y:840,t:1527272097754};\\\", \\\"{x:1720,y:822,t:1527272097772};\\\", \\\"{x:1727,y:805,t:1527272097789};\\\", \\\"{x:1728,y:788,t:1527272097805};\\\", \\\"{x:1720,y:766,t:1527272097822};\\\", \\\"{x:1710,y:750,t:1527272097839};\\\", \\\"{x:1701,y:737,t:1527272097855};\\\", \\\"{x:1692,y:724,t:1527272097872};\\\", \\\"{x:1682,y:710,t:1527272097890};\\\", \\\"{x:1672,y:697,t:1527272097905};\\\", \\\"{x:1661,y:686,t:1527272097922};\\\", \\\"{x:1658,y:682,t:1527272097938};\\\", \\\"{x:1658,y:681,t:1527272097955};\\\", \\\"{x:1657,y:681,t:1527272098067};\\\", \\\"{x:1656,y:680,t:1527272098091};\\\", \\\"{x:1655,y:680,t:1527272098123};\\\", \\\"{x:1654,y:680,t:1527272098154};\\\", \\\"{x:1653,y:680,t:1527272098163};\\\", \\\"{x:1652,y:680,t:1527272098172};\\\", \\\"{x:1648,y:680,t:1527272098189};\\\", \\\"{x:1644,y:679,t:1527272098205};\\\", \\\"{x:1635,y:679,t:1527272098222};\\\", \\\"{x:1627,y:679,t:1527272098239};\\\", \\\"{x:1612,y:687,t:1527272098256};\\\", \\\"{x:1603,y:689,t:1527272098272};\\\", \\\"{x:1586,y:698,t:1527272098289};\\\", \\\"{x:1564,y:706,t:1527272098306};\\\", \\\"{x:1553,y:710,t:1527272098322};\\\", \\\"{x:1550,y:712,t:1527272098339};\\\", \\\"{x:1545,y:715,t:1527272098356};\\\", \\\"{x:1538,y:721,t:1527272098372};\\\", \\\"{x:1532,y:725,t:1527272098388};\\\", \\\"{x:1525,y:731,t:1527272098406};\\\", \\\"{x:1516,y:740,t:1527272098422};\\\", \\\"{x:1511,y:747,t:1527272098439};\\\", \\\"{x:1502,y:754,t:1527272098456};\\\", \\\"{x:1495,y:759,t:1527272098473};\\\", \\\"{x:1491,y:762,t:1527272098489};\\\", \\\"{x:1489,y:766,t:1527272098506};\\\", \\\"{x:1489,y:784,t:1527272098523};\\\", \\\"{x:1495,y:803,t:1527272098539};\\\", \\\"{x:1504,y:816,t:1527272098556};\\\", \\\"{x:1507,y:824,t:1527272098573};\\\", \\\"{x:1507,y:829,t:1527272098589};\\\", \\\"{x:1507,y:831,t:1527272098606};\\\", \\\"{x:1507,y:832,t:1527272098623};\\\", \\\"{x:1507,y:834,t:1527272098639};\\\", \\\"{x:1506,y:835,t:1527272098656};\\\", \\\"{x:1505,y:837,t:1527272098672};\\\", \\\"{x:1503,y:838,t:1527272098689};\\\", \\\"{x:1502,y:839,t:1527272098714};\\\", \\\"{x:1500,y:839,t:1527272098731};\\\", \\\"{x:1493,y:842,t:1527272098739};\\\", \\\"{x:1477,y:842,t:1527272098756};\\\", \\\"{x:1443,y:842,t:1527272098773};\\\", \\\"{x:1376,y:822,t:1527272098789};\\\", \\\"{x:1328,y:807,t:1527272098806};\\\", \\\"{x:1213,y:782,t:1527272098823};\\\", \\\"{x:1093,y:742,t:1527272098839};\\\", \\\"{x:955,y:701,t:1527272098856};\\\", \\\"{x:852,y:669,t:1527272098873};\\\", \\\"{x:741,y:638,t:1527272098889};\\\", \\\"{x:644,y:610,t:1527272098907};\\\", \\\"{x:563,y:591,t:1527272098924};\\\", \\\"{x:544,y:589,t:1527272098940};\\\", \\\"{x:538,y:588,t:1527272098956};\\\", \\\"{x:537,y:588,t:1527272098973};\\\", \\\"{x:535,y:588,t:1527272099003};\\\", \\\"{x:534,y:588,t:1527272099018};\\\", \\\"{x:530,y:591,t:1527272099027};\\\", \\\"{x:527,y:591,t:1527272099040};\\\", \\\"{x:518,y:594,t:1527272099056};\\\", \\\"{x:504,y:597,t:1527272099073};\\\", \\\"{x:495,y:599,t:1527272099090};\\\", \\\"{x:490,y:599,t:1527272099107};\\\", \\\"{x:489,y:599,t:1527272099154};\\\", \\\"{x:489,y:598,t:1527272099178};\\\", \\\"{x:491,y:597,t:1527272099190};\\\", \\\"{x:497,y:595,t:1527272099206};\\\", \\\"{x:499,y:594,t:1527272099223};\\\", \\\"{x:508,y:590,t:1527272099240};\\\", \\\"{x:520,y:588,t:1527272099257};\\\", \\\"{x:529,y:584,t:1527272099273};\\\", \\\"{x:535,y:581,t:1527272099290};\\\", \\\"{x:548,y:576,t:1527272099307};\\\", \\\"{x:557,y:571,t:1527272099322};\\\", \\\"{x:570,y:567,t:1527272099340};\\\", \\\"{x:580,y:562,t:1527272099357};\\\", \\\"{x:583,y:562,t:1527272099373};\\\", \\\"{x:587,y:562,t:1527272099390};\\\", \\\"{x:591,y:562,t:1527272099407};\\\", \\\"{x:600,y:562,t:1527272099422};\\\", \\\"{x:607,y:561,t:1527272099440};\\\", \\\"{x:618,y:561,t:1527272099457};\\\", \\\"{x:623,y:561,t:1527272099473};\\\", \\\"{x:625,y:561,t:1527272099490};\\\", \\\"{x:626,y:561,t:1527272099531};\\\", \\\"{x:626,y:562,t:1527272099563};\\\", \\\"{x:625,y:563,t:1527272099575};\\\", \\\"{x:624,y:563,t:1527272099699};\\\", \\\"{x:622,y:565,t:1527272099707};\\\", \\\"{x:619,y:567,t:1527272099724};\\\", \\\"{x:617,y:569,t:1527272099741};\\\", \\\"{x:616,y:569,t:1527272099811};\\\", \\\"{x:615,y:569,t:1527272100124};\\\", \\\"{x:614,y:570,t:1527272100595};\\\", \\\"{x:614,y:571,t:1527272100723};\\\", \\\"{x:613,y:571,t:1527272100738};\\\", \\\"{x:612,y:571,t:1527272100755};\\\", \\\"{x:611,y:571,t:1527272100762};\\\", \\\"{x:610,y:571,t:1527272102587};\\\", \\\"{x:607,y:573,t:1527272111490};\\\", \\\"{x:591,y:589,t:1527272111499};\\\", \\\"{x:579,y:607,t:1527272111517};\\\", \\\"{x:568,y:619,t:1527272111534};\\\", \\\"{x:562,y:626,t:1527272111549};\\\", \\\"{x:561,y:627,t:1527272111566};\\\", \\\"{x:560,y:628,t:1527272111714};\\\", \\\"{x:558,y:628,t:1527272111730};\\\", \\\"{x:555,y:631,t:1527272111738};\\\", \\\"{x:552,y:632,t:1527272111755};\\\", \\\"{x:548,y:635,t:1527272111767};\\\", \\\"{x:540,y:644,t:1527272111784};\\\", \\\"{x:533,y:655,t:1527272111800};\\\", \\\"{x:528,y:666,t:1527272111818};\\\", \\\"{x:525,y:673,t:1527272111834};\\\", \\\"{x:520,y:684,t:1527272111850};\\\", \\\"{x:518,y:689,t:1527272111868};\\\", \\\"{x:516,y:695,t:1527272111884};\\\", \\\"{x:516,y:697,t:1527272111901};\\\", \\\"{x:515,y:701,t:1527272111918};\\\", \\\"{x:514,y:704,t:1527272111934};\\\", \\\"{x:514,y:709,t:1527272111951};\\\", \\\"{x:514,y:711,t:1527272111968};\\\", \\\"{x:513,y:713,t:1527272111983};\\\", \\\"{x:513,y:714,t:1527272112000};\\\", \\\"{x:512,y:717,t:1527272112017};\\\", \\\"{x:510,y:721,t:1527272112034};\\\", \\\"{x:510,y:722,t:1527272112051};\\\", \\\"{x:508,y:723,t:1527272112468};\\\", \\\"{x:507,y:723,t:1527272112484};\\\", \\\"{x:506,y:723,t:1527272112500};\\\", \\\"{x:504,y:723,t:1527272112517};\\\", \\\"{x:503,y:723,t:1527272112535};\\\", \\\"{x:502,y:725,t:1527272112554};\\\", \\\"{x:501,y:725,t:1527272112571};\\\", \\\"{x:500,y:725,t:1527272112588};\\\", \\\"{x:499,y:726,t:1527272112605};\\\", \\\"{x:497,y:726,t:1527272112621};\\\", \\\"{x:497,y:727,t:1527272112638};\\\", \\\"{x:496,y:728,t:1527272112974};\\\", \\\"{x:495,y:727,t:1527272113342};\\\", \\\"{x:494,y:726,t:1527272113358};\\\", \\\"{x:494,y:725,t:1527272113372};\\\", \\\"{x:494,y:724,t:1527272113389};\\\" ] }, { \\\"rt\\\": 48103, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 588872, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:722,t:1527272113632};\\\", \\\"{x:494,y:719,t:1527272113660};\\\", \\\"{x:494,y:716,t:1527272113673};\\\", \\\"{x:494,y:715,t:1527272113766};\\\", \\\"{x:494,y:712,t:1527272113783};\\\", \\\"{x:495,y:709,t:1527272114079};\\\", \\\"{x:496,y:709,t:1527272114119};\\\", \\\"{x:505,y:701,t:1527272114216};\\\", \\\"{x:505,y:699,t:1527272114302};\\\", \\\"{x:505,y:698,t:1527272114446};\\\", \\\"{x:506,y:697,t:1527272117942};\\\", \\\"{x:507,y:697,t:1527272117951};\\\", \\\"{x:509,y:695,t:1527272117968};\\\", \\\"{x:510,y:694,t:1527272117985};\\\", \\\"{x:512,y:692,t:1527272118000};\\\", \\\"{x:514,y:691,t:1527272118017};\\\", \\\"{x:515,y:690,t:1527272118035};\\\", \\\"{x:519,y:687,t:1527272118051};\\\", \\\"{x:526,y:682,t:1527272118068};\\\", \\\"{x:536,y:676,t:1527272118084};\\\", \\\"{x:545,y:671,t:1527272118101};\\\", \\\"{x:546,y:671,t:1527272118118};\\\", \\\"{x:553,y:667,t:1527272118134};\\\", \\\"{x:561,y:665,t:1527272118151};\\\", \\\"{x:570,y:662,t:1527272118168};\\\", \\\"{x:582,y:658,t:1527272118184};\\\", \\\"{x:591,y:655,t:1527272118200};\\\", \\\"{x:612,y:651,t:1527272118218};\\\", \\\"{x:632,y:651,t:1527272118235};\\\", \\\"{x:658,y:650,t:1527272118251};\\\", \\\"{x:683,y:647,t:1527272118267};\\\", \\\"{x:708,y:647,t:1527272118284};\\\", \\\"{x:740,y:647,t:1527272118300};\\\", \\\"{x:767,y:646,t:1527272118318};\\\", \\\"{x:790,y:647,t:1527272118334};\\\", \\\"{x:839,y:655,t:1527272118350};\\\", \\\"{x:869,y:660,t:1527272118368};\\\", \\\"{x:895,y:662,t:1527272118383};\\\", \\\"{x:920,y:667,t:1527272118400};\\\", \\\"{x:934,y:668,t:1527272118418};\\\", \\\"{x:938,y:669,t:1527272118434};\\\", \\\"{x:947,y:671,t:1527272118450};\\\", \\\"{x:957,y:672,t:1527272118467};\\\", \\\"{x:970,y:675,t:1527272118483};\\\", \\\"{x:972,y:676,t:1527272118501};\\\", \\\"{x:985,y:679,t:1527272118518};\\\", \\\"{x:997,y:681,t:1527272118533};\\\", \\\"{x:1008,y:685,t:1527272118550};\\\", \\\"{x:1012,y:685,t:1527272118566};\\\", \\\"{x:1014,y:685,t:1527272118584};\\\", \\\"{x:1015,y:685,t:1527272118601};\\\", \\\"{x:1017,y:687,t:1527272118616};\\\", \\\"{x:1019,y:687,t:1527272118634};\\\", \\\"{x:1023,y:687,t:1527272118651};\\\", \\\"{x:1026,y:688,t:1527272118666};\\\", \\\"{x:1030,y:689,t:1527272118684};\\\", \\\"{x:1037,y:690,t:1527272118701};\\\", \\\"{x:1042,y:691,t:1527272118717};\\\", \\\"{x:1052,y:691,t:1527272118734};\\\", \\\"{x:1076,y:693,t:1527272118750};\\\", \\\"{x:1086,y:696,t:1527272118767};\\\", \\\"{x:1097,y:698,t:1527272118784};\\\", \\\"{x:1103,y:700,t:1527272118801};\\\", \\\"{x:1109,y:701,t:1527272118817};\\\", \\\"{x:1117,y:704,t:1527272118834};\\\", \\\"{x:1127,y:705,t:1527272118851};\\\", \\\"{x:1136,y:707,t:1527272118867};\\\", \\\"{x:1144,y:709,t:1527272118884};\\\", \\\"{x:1152,y:711,t:1527272118899};\\\", \\\"{x:1161,y:715,t:1527272118917};\\\", \\\"{x:1171,y:719,t:1527272118934};\\\", \\\"{x:1187,y:725,t:1527272118949};\\\", \\\"{x:1214,y:731,t:1527272118966};\\\", \\\"{x:1235,y:740,t:1527272118984};\\\", \\\"{x:1251,y:752,t:1527272118999};\\\", \\\"{x:1278,y:768,t:1527272119017};\\\", \\\"{x:1307,y:783,t:1527272119034};\\\", \\\"{x:1338,y:802,t:1527272119049};\\\", \\\"{x:1368,y:821,t:1527272119067};\\\", \\\"{x:1415,y:852,t:1527272119084};\\\", \\\"{x:1433,y:869,t:1527272119100};\\\", \\\"{x:1459,y:882,t:1527272119116};\\\", \\\"{x:1473,y:893,t:1527272119134};\\\", \\\"{x:1492,y:906,t:1527272119150};\\\", \\\"{x:1503,y:914,t:1527272119167};\\\", \\\"{x:1519,y:926,t:1527272119183};\\\", \\\"{x:1532,y:935,t:1527272119200};\\\", \\\"{x:1537,y:939,t:1527272119217};\\\", \\\"{x:1542,y:944,t:1527272119233};\\\", \\\"{x:1543,y:944,t:1527272119250};\\\", \\\"{x:1543,y:945,t:1527272119266};\\\", \\\"{x:1546,y:950,t:1527272119283};\\\", \\\"{x:1550,y:955,t:1527272119299};\\\", \\\"{x:1553,y:957,t:1527272119317};\\\", \\\"{x:1554,y:958,t:1527272119333};\\\", \\\"{x:1555,y:959,t:1527272119366};\\\", \\\"{x:1557,y:961,t:1527272119382};\\\", \\\"{x:1559,y:969,t:1527272119399};\\\", \\\"{x:1561,y:976,t:1527272119416};\\\", \\\"{x:1563,y:979,t:1527272119432};\\\", \\\"{x:1563,y:980,t:1527272119450};\\\", \\\"{x:1563,y:976,t:1527272119687};\\\", \\\"{x:1563,y:975,t:1527272119702};\\\", \\\"{x:1563,y:974,t:1527272119716};\\\", \\\"{x:1563,y:973,t:1527272119733};\\\", \\\"{x:1563,y:971,t:1527272119750};\\\", \\\"{x:1563,y:969,t:1527272119766};\\\", \\\"{x:1563,y:958,t:1527272119783};\\\", \\\"{x:1561,y:951,t:1527272119799};\\\", \\\"{x:1559,y:945,t:1527272119816};\\\", \\\"{x:1559,y:941,t:1527272119833};\\\", \\\"{x:1558,y:937,t:1527272119848};\\\", \\\"{x:1557,y:933,t:1527272119866};\\\", \\\"{x:1554,y:926,t:1527272119883};\\\", \\\"{x:1546,y:916,t:1527272119899};\\\", \\\"{x:1537,y:901,t:1527272119916};\\\", \\\"{x:1536,y:899,t:1527272119932};\\\", \\\"{x:1535,y:897,t:1527272119949};\\\", \\\"{x:1532,y:893,t:1527272119966};\\\", \\\"{x:1531,y:891,t:1527272119982};\\\", \\\"{x:1528,y:887,t:1527272119998};\\\", \\\"{x:1525,y:880,t:1527272120016};\\\", \\\"{x:1523,y:877,t:1527272120032};\\\", \\\"{x:1522,y:873,t:1527272120049};\\\", \\\"{x:1520,y:871,t:1527272120065};\\\", \\\"{x:1518,y:868,t:1527272120082};\\\", \\\"{x:1518,y:867,t:1527272120099};\\\", \\\"{x:1517,y:866,t:1527272120116};\\\", \\\"{x:1513,y:864,t:1527272120131};\\\", \\\"{x:1510,y:862,t:1527272120149};\\\", \\\"{x:1510,y:861,t:1527272120166};\\\", \\\"{x:1509,y:861,t:1527272120303};\\\", \\\"{x:1507,y:861,t:1527272120326};\\\", \\\"{x:1506,y:861,t:1527272120478};\\\", \\\"{x:1505,y:862,t:1527272120502};\\\", \\\"{x:1503,y:863,t:1527272120606};\\\", \\\"{x:1501,y:863,t:1527272120615};\\\", \\\"{x:1494,y:863,t:1527272120632};\\\", \\\"{x:1480,y:863,t:1527272120647};\\\", \\\"{x:1465,y:863,t:1527272120664};\\\", \\\"{x:1442,y:861,t:1527272120682};\\\", \\\"{x:1422,y:858,t:1527272120698};\\\", \\\"{x:1402,y:855,t:1527272120715};\\\", \\\"{x:1398,y:855,t:1527272120732};\\\", \\\"{x:1397,y:856,t:1527272120748};\\\", \\\"{x:1392,y:856,t:1527272120764};\\\", \\\"{x:1383,y:856,t:1527272120781};\\\", \\\"{x:1379,y:855,t:1527272120798};\\\", \\\"{x:1371,y:856,t:1527272120815};\\\", \\\"{x:1368,y:856,t:1527272120832};\\\", \\\"{x:1364,y:858,t:1527272120848};\\\", \\\"{x:1361,y:858,t:1527272120865};\\\", \\\"{x:1356,y:859,t:1527272120882};\\\", \\\"{x:1354,y:859,t:1527272120898};\\\", \\\"{x:1352,y:860,t:1527272120915};\\\", \\\"{x:1344,y:855,t:1527272149158};\\\", \\\"{x:1276,y:825,t:1527272149169};\\\", \\\"{x:1140,y:774,t:1527272149185};\\\", \\\"{x:986,y:742,t:1527272149201};\\\", \\\"{x:819,y:706,t:1527272149218};\\\", \\\"{x:670,y:688,t:1527272149235};\\\", \\\"{x:547,y:680,t:1527272149251};\\\", \\\"{x:444,y:680,t:1527272149267};\\\", \\\"{x:394,y:677,t:1527272149284};\\\", \\\"{x:367,y:672,t:1527272149301};\\\", \\\"{x:349,y:667,t:1527272149318};\\\", \\\"{x:343,y:657,t:1527272149334};\\\", \\\"{x:331,y:638,t:1527272149351};\\\", \\\"{x:314,y:619,t:1527272149369};\\\", \\\"{x:295,y:590,t:1527272149385};\\\", \\\"{x:276,y:558,t:1527272149402};\\\", \\\"{x:251,y:525,t:1527272149418};\\\", \\\"{x:231,y:507,t:1527272149436};\\\", \\\"{x:218,y:486,t:1527272149452};\\\", \\\"{x:208,y:468,t:1527272149468};\\\", \\\"{x:199,y:447,t:1527272149485};\\\", \\\"{x:192,y:432,t:1527272149501};\\\", \\\"{x:182,y:415,t:1527272149518};\\\", \\\"{x:178,y:410,t:1527272149535};\\\", \\\"{x:177,y:410,t:1527272149552};\\\", \\\"{x:176,y:410,t:1527272149605};\\\", \\\"{x:174,y:412,t:1527272149622};\\\", \\\"{x:172,y:413,t:1527272149635};\\\", \\\"{x:168,y:419,t:1527272149651};\\\", \\\"{x:164,y:430,t:1527272149668};\\\", \\\"{x:159,y:438,t:1527272149685};\\\", \\\"{x:158,y:440,t:1527272149701};\\\", \\\"{x:155,y:455,t:1527272149718};\\\", \\\"{x:154,y:465,t:1527272149735};\\\", \\\"{x:154,y:470,t:1527272149751};\\\", \\\"{x:154,y:480,t:1527272149768};\\\", \\\"{x:154,y:486,t:1527272149785};\\\", \\\"{x:153,y:494,t:1527272149801};\\\", \\\"{x:153,y:498,t:1527272149818};\\\", \\\"{x:153,y:504,t:1527272149834};\\\", \\\"{x:153,y:507,t:1527272149850};\\\", \\\"{x:153,y:510,t:1527272149867};\\\", \\\"{x:155,y:511,t:1527272149909};\\\", \\\"{x:155,y:512,t:1527272149941};\\\", \\\"{x:155,y:513,t:1527272149982};\\\", \\\"{x:155,y:515,t:1527272149990};\\\", \\\"{x:156,y:517,t:1527272150001};\\\", \\\"{x:156,y:521,t:1527272150019};\\\", \\\"{x:158,y:525,t:1527272150035};\\\", \\\"{x:158,y:528,t:1527272150052};\\\", \\\"{x:159,y:531,t:1527272150069};\\\", \\\"{x:159,y:532,t:1527272150085};\\\", \\\"{x:159,y:534,t:1527272150103};\\\", \\\"{x:159,y:535,t:1527272150126};\\\", \\\"{x:166,y:536,t:1527272150822};\\\", \\\"{x:188,y:533,t:1527272150836};\\\", \\\"{x:274,y:508,t:1527272150854};\\\", \\\"{x:369,y:488,t:1527272150869};\\\", \\\"{x:581,y:463,t:1527272150887};\\\", \\\"{x:751,y:445,t:1527272150902};\\\", \\\"{x:937,y:441,t:1527272150919};\\\", \\\"{x:1094,y:444,t:1527272150936};\\\", \\\"{x:1236,y:465,t:1527272150953};\\\", \\\"{x:1346,y:479,t:1527272150970};\\\", \\\"{x:1426,y:498,t:1527272150986};\\\", \\\"{x:1451,y:513,t:1527272151003};\\\", \\\"{x:1469,y:527,t:1527272151019};\\\", \\\"{x:1479,y:538,t:1527272151037};\\\", \\\"{x:1488,y:547,t:1527272151053};\\\", \\\"{x:1491,y:550,t:1527272151069};\\\", \\\"{x:1496,y:558,t:1527272151086};\\\", \\\"{x:1501,y:567,t:1527272151103};\\\", \\\"{x:1508,y:579,t:1527272151119};\\\", \\\"{x:1516,y:589,t:1527272151136};\\\", \\\"{x:1522,y:601,t:1527272151153};\\\", \\\"{x:1526,y:611,t:1527272151169};\\\", \\\"{x:1525,y:623,t:1527272151186};\\\", \\\"{x:1523,y:628,t:1527272151203};\\\", \\\"{x:1512,y:643,t:1527272151220};\\\", \\\"{x:1500,y:659,t:1527272151236};\\\", \\\"{x:1486,y:675,t:1527272151253};\\\", \\\"{x:1470,y:696,t:1527272151270};\\\", \\\"{x:1461,y:709,t:1527272151286};\\\", \\\"{x:1456,y:717,t:1527272151303};\\\", \\\"{x:1449,y:727,t:1527272151320};\\\", \\\"{x:1446,y:732,t:1527272151336};\\\", \\\"{x:1443,y:736,t:1527272151353};\\\", \\\"{x:1443,y:738,t:1527272151370};\\\", \\\"{x:1442,y:739,t:1527272151386};\\\", \\\"{x:1441,y:741,t:1527272151422};\\\", \\\"{x:1441,y:742,t:1527272151436};\\\", \\\"{x:1437,y:747,t:1527272151453};\\\", \\\"{x:1431,y:752,t:1527272151470};\\\", \\\"{x:1427,y:755,t:1527272151486};\\\", \\\"{x:1425,y:759,t:1527272151503};\\\", \\\"{x:1423,y:763,t:1527272151520};\\\", \\\"{x:1422,y:764,t:1527272151536};\\\", \\\"{x:1420,y:766,t:1527272151553};\\\", \\\"{x:1420,y:767,t:1527272151830};\\\", \\\"{x:1417,y:767,t:1527272151838};\\\", \\\"{x:1415,y:764,t:1527272151853};\\\", \\\"{x:1411,y:758,t:1527272151870};\\\", \\\"{x:1408,y:755,t:1527272151887};\\\", \\\"{x:1405,y:752,t:1527272151903};\\\", \\\"{x:1405,y:751,t:1527272151920};\\\", \\\"{x:1403,y:751,t:1527272151937};\\\", \\\"{x:1399,y:751,t:1527272151953};\\\", \\\"{x:1392,y:749,t:1527272151970};\\\", \\\"{x:1383,y:748,t:1527272151987};\\\", \\\"{x:1381,y:748,t:1527272152004};\\\", \\\"{x:1375,y:749,t:1527272152020};\\\", \\\"{x:1370,y:749,t:1527272152037};\\\", \\\"{x:1368,y:750,t:1527272152053};\\\", \\\"{x:1367,y:750,t:1527272152085};\\\", \\\"{x:1365,y:750,t:1527272152302};\\\", \\\"{x:1364,y:750,t:1527272152317};\\\", \\\"{x:1363,y:751,t:1527272152325};\\\", \\\"{x:1363,y:752,t:1527272152389};\\\", \\\"{x:1363,y:754,t:1527272152422};\\\", \\\"{x:1363,y:755,t:1527272152454};\\\", \\\"{x:1361,y:759,t:1527272152471};\\\", \\\"{x:1360,y:760,t:1527272152487};\\\", \\\"{x:1358,y:762,t:1527272152504};\\\", \\\"{x:1355,y:766,t:1527272152521};\\\", \\\"{x:1354,y:766,t:1527272152537};\\\", \\\"{x:1350,y:770,t:1527272152554};\\\", \\\"{x:1347,y:775,t:1527272152571};\\\", \\\"{x:1344,y:779,t:1527272152587};\\\", \\\"{x:1340,y:785,t:1527272152604};\\\", \\\"{x:1337,y:789,t:1527272152621};\\\", \\\"{x:1334,y:794,t:1527272152637};\\\", \\\"{x:1331,y:798,t:1527272152654};\\\", \\\"{x:1329,y:800,t:1527272152671};\\\", \\\"{x:1326,y:803,t:1527272152687};\\\", \\\"{x:1325,y:804,t:1527272152704};\\\", \\\"{x:1323,y:807,t:1527272152721};\\\", \\\"{x:1320,y:810,t:1527272152738};\\\", \\\"{x:1319,y:811,t:1527272152754};\\\", \\\"{x:1316,y:815,t:1527272152771};\\\", \\\"{x:1314,y:817,t:1527272152787};\\\", \\\"{x:1310,y:821,t:1527272152804};\\\", \\\"{x:1306,y:824,t:1527272152822};\\\", \\\"{x:1300,y:829,t:1527272152837};\\\", \\\"{x:1298,y:834,t:1527272152854};\\\", \\\"{x:1295,y:838,t:1527272152871};\\\", \\\"{x:1292,y:844,t:1527272152887};\\\", \\\"{x:1286,y:850,t:1527272152904};\\\", \\\"{x:1278,y:858,t:1527272152921};\\\", \\\"{x:1270,y:864,t:1527272152938};\\\", \\\"{x:1261,y:870,t:1527272152954};\\\", \\\"{x:1254,y:877,t:1527272152971};\\\", \\\"{x:1247,y:883,t:1527272152988};\\\", \\\"{x:1243,y:886,t:1527272153004};\\\", \\\"{x:1242,y:887,t:1527272153022};\\\", \\\"{x:1242,y:888,t:1527272153046};\\\", \\\"{x:1241,y:888,t:1527272153070};\\\", \\\"{x:1240,y:889,t:1527272154022};\\\", \\\"{x:1239,y:889,t:1527272154054};\\\", \\\"{x:1237,y:891,t:1527272154069};\\\", \\\"{x:1236,y:893,t:1527272154078};\\\", \\\"{x:1233,y:894,t:1527272154088};\\\", \\\"{x:1233,y:895,t:1527272154105};\\\", \\\"{x:1233,y:896,t:1527272154122};\\\", \\\"{x:1231,y:898,t:1527272154142};\\\", \\\"{x:1231,y:899,t:1527272154174};\\\", \\\"{x:1230,y:900,t:1527272154223};\\\", \\\"{x:1229,y:901,t:1527272154278};\\\", \\\"{x:1228,y:902,t:1527272154302};\\\", \\\"{x:1227,y:903,t:1527272154318};\\\", \\\"{x:1226,y:903,t:1527272154325};\\\", \\\"{x:1226,y:904,t:1527272154339};\\\", \\\"{x:1225,y:906,t:1527272154355};\\\", \\\"{x:1224,y:907,t:1527272154373};\\\", \\\"{x:1223,y:909,t:1527272154389};\\\", \\\"{x:1222,y:911,t:1527272154405};\\\", \\\"{x:1219,y:915,t:1527272154422};\\\", \\\"{x:1218,y:915,t:1527272154453};\\\", \\\"{x:1218,y:917,t:1527272154478};\\\", \\\"{x:1218,y:918,t:1527272154622};\\\", \\\"{x:1216,y:919,t:1527272154709};\\\", \\\"{x:1215,y:921,t:1527272154782};\\\", \\\"{x:1213,y:922,t:1527272155262};\\\", \\\"{x:1212,y:923,t:1527272155350};\\\", \\\"{x:1211,y:923,t:1527272155678};\\\", \\\"{x:1210,y:923,t:1527272155702};\\\", \\\"{x:1210,y:924,t:1527272155742};\\\", \\\"{x:1207,y:925,t:1527272158046};\\\", \\\"{x:1201,y:927,t:1527272158059};\\\", \\\"{x:1182,y:928,t:1527272158075};\\\", \\\"{x:1131,y:928,t:1527272158091};\\\", \\\"{x:1047,y:913,t:1527272158109};\\\", \\\"{x:907,y:904,t:1527272158126};\\\", \\\"{x:812,y:890,t:1527272158142};\\\", \\\"{x:736,y:874,t:1527272158159};\\\", \\\"{x:667,y:858,t:1527272158175};\\\", \\\"{x:638,y:849,t:1527272158191};\\\", \\\"{x:629,y:844,t:1527272158208};\\\", \\\"{x:624,y:840,t:1527272158225};\\\", \\\"{x:623,y:837,t:1527272158243};\\\", \\\"{x:623,y:835,t:1527272158259};\\\", \\\"{x:620,y:826,t:1527272158275};\\\", \\\"{x:617,y:818,t:1527272158292};\\\", \\\"{x:612,y:812,t:1527272158308};\\\", \\\"{x:607,y:800,t:1527272158325};\\\", \\\"{x:606,y:796,t:1527272158342};\\\", \\\"{x:603,y:792,t:1527272158358};\\\", \\\"{x:599,y:785,t:1527272158376};\\\", \\\"{x:595,y:777,t:1527272158392};\\\", \\\"{x:595,y:772,t:1527272158409};\\\", \\\"{x:591,y:767,t:1527272158425};\\\", \\\"{x:591,y:763,t:1527272158442};\\\", \\\"{x:590,y:760,t:1527272158458};\\\", \\\"{x:590,y:759,t:1527272160670};\\\", \\\"{x:588,y:759,t:1527272160678};\\\", \\\"{x:587,y:759,t:1527272160710};\\\", \\\"{x:586,y:759,t:1527272160758};\\\", \\\"{x:585,y:759,t:1527272160846};\\\", \\\"{x:582,y:758,t:1527272160861};\\\", \\\"{x:570,y:756,t:1527272160877};\\\", \\\"{x:545,y:755,t:1527272160894};\\\", \\\"{x:511,y:747,t:1527272160911};\\\", \\\"{x:511,y:744,t:1527272160927};\\\", \\\"{x:511,y:740,t:1527272160945};\\\", \\\"{x:510,y:737,t:1527272160957};\\\", \\\"{x:504,y:730,t:1527272160973};\\\", \\\"{x:504,y:728,t:1527272160989};\\\", \\\"{x:506,y:725,t:1527272161006};\\\", \\\"{x:516,y:724,t:1527272161024};\\\", \\\"{x:525,y:723,t:1527272161040};\\\", \\\"{x:533,y:722,t:1527272161056};\\\", \\\"{x:538,y:722,t:1527272161074};\\\", \\\"{x:540,y:722,t:1527272161090};\\\", \\\"{x:541,y:722,t:1527272161107};\\\", \\\"{x:542,y:723,t:1527272161124};\\\", \\\"{x:543,y:723,t:1527272161158};\\\" ] }, { \\\"rt\\\": 29062, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 619139, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-01 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:723,t:1527272168326};\\\", \\\"{x:538,y:726,t:1527272168334};\\\", \\\"{x:533,y:729,t:1527272168350};\\\", \\\"{x:528,y:733,t:1527272168366};\\\", \\\"{x:523,y:735,t:1527272168384};\\\", \\\"{x:520,y:737,t:1527272168400};\\\", \\\"{x:520,y:738,t:1527272168417};\\\", \\\"{x:519,y:738,t:1527272168433};\\\", \\\"{x:518,y:738,t:1527272168451};\\\", \\\"{x:518,y:739,t:1527272171541};\\\", \\\"{x:517,y:740,t:1527272171554};\\\", \\\"{x:514,y:743,t:1527272171570};\\\", \\\"{x:509,y:747,t:1527272171587};\\\", \\\"{x:506,y:750,t:1527272171604};\\\", \\\"{x:505,y:753,t:1527272171620};\\\", \\\"{x:503,y:754,t:1527272171637};\\\", \\\"{x:502,y:756,t:1527272171654};\\\", \\\"{x:502,y:757,t:1527272171750};\\\", \\\"{x:498,y:764,t:1527272171825};\\\", \\\"{x:497,y:767,t:1527272171837};\\\", \\\"{x:496,y:768,t:1527272171853};\\\", \\\"{x:496,y:769,t:1527272171871};\\\", \\\"{x:496,y:768,t:1527272172929};\\\", \\\"{x:496,y:767,t:1527272172940};\\\", \\\"{x:496,y:766,t:1527272172957};\\\", \\\"{x:496,y:764,t:1527272172974};\\\", \\\"{x:496,y:763,t:1527272173001};\\\", \\\"{x:497,y:761,t:1527272173017};\\\", \\\"{x:498,y:760,t:1527272173176};\\\", \\\"{x:501,y:759,t:1527272173191};\\\", \\\"{x:503,y:757,t:1527272173207};\\\", \\\"{x:509,y:754,t:1527272173224};\\\", \\\"{x:531,y:747,t:1527272173240};\\\", \\\"{x:555,y:743,t:1527272173257};\\\", \\\"{x:586,y:743,t:1527272173275};\\\", \\\"{x:630,y:740,t:1527272173291};\\\", \\\"{x:685,y:735,t:1527272173307};\\\", \\\"{x:768,y:735,t:1527272173324};\\\", \\\"{x:844,y:738,t:1527272173341};\\\", \\\"{x:939,y:739,t:1527272173357};\\\", \\\"{x:1023,y:737,t:1527272173374};\\\", \\\"{x:1060,y:738,t:1527272173391};\\\", \\\"{x:1107,y:736,t:1527272173407};\\\", \\\"{x:1123,y:736,t:1527272173425};\\\", \\\"{x:1125,y:736,t:1527272173441};\\\", \\\"{x:1129,y:736,t:1527272173457};\\\", \\\"{x:1130,y:734,t:1527272173474};\\\", \\\"{x:1130,y:733,t:1527272173491};\\\", \\\"{x:1131,y:733,t:1527272173569};\\\", \\\"{x:1132,y:733,t:1527272173712};\\\", \\\"{x:1132,y:731,t:1527272173745};\\\", \\\"{x:1133,y:730,t:1527272173768};\\\", \\\"{x:1133,y:728,t:1527272173793};\\\", \\\"{x:1133,y:725,t:1527272173808};\\\", \\\"{x:1133,y:719,t:1527272173824};\\\", \\\"{x:1133,y:704,t:1527272173841};\\\", \\\"{x:1133,y:697,t:1527272173858};\\\", \\\"{x:1133,y:685,t:1527272173874};\\\", \\\"{x:1133,y:680,t:1527272173891};\\\", \\\"{x:1133,y:676,t:1527272173908};\\\", \\\"{x:1133,y:671,t:1527272173925};\\\", \\\"{x:1132,y:667,t:1527272173941};\\\", \\\"{x:1132,y:666,t:1527272173958};\\\", \\\"{x:1131,y:665,t:1527272174160};\\\", \\\"{x:1133,y:665,t:1527272174425};\\\", \\\"{x:1153,y:658,t:1527272174442};\\\", \\\"{x:1157,y:657,t:1527272174458};\\\", \\\"{x:1163,y:648,t:1527272174489};\\\", \\\"{x:1192,y:634,t:1527272174496};\\\", \\\"{x:1220,y:619,t:1527272174508};\\\", \\\"{x:1264,y:592,t:1527272174525};\\\", \\\"{x:1298,y:568,t:1527272174542};\\\", \\\"{x:1325,y:552,t:1527272174558};\\\", \\\"{x:1355,y:530,t:1527272174575};\\\", \\\"{x:1375,y:515,t:1527272174592};\\\", \\\"{x:1392,y:501,t:1527272174608};\\\", \\\"{x:1412,y:474,t:1527272174625};\\\", \\\"{x:1413,y:473,t:1527272174642};\\\", \\\"{x:1413,y:472,t:1527272174658};\\\", \\\"{x:1414,y:471,t:1527272174753};\\\", \\\"{x:1415,y:468,t:1527272174792};\\\", \\\"{x:1424,y:458,t:1527272174809};\\\", \\\"{x:1433,y:444,t:1527272174825};\\\", \\\"{x:1446,y:430,t:1527272174842};\\\", \\\"{x:1465,y:417,t:1527272174858};\\\", \\\"{x:1480,y:403,t:1527272174875};\\\", \\\"{x:1500,y:389,t:1527272174892};\\\", \\\"{x:1512,y:378,t:1527272174909};\\\", \\\"{x:1520,y:369,t:1527272174926};\\\", \\\"{x:1530,y:356,t:1527272174942};\\\", \\\"{x:1533,y:352,t:1527272174959};\\\", \\\"{x:1535,y:350,t:1527272174975};\\\", \\\"{x:1536,y:350,t:1527272175096};\\\", \\\"{x:1538,y:350,t:1527272175109};\\\", \\\"{x:1539,y:350,t:1527272175128};\\\", \\\"{x:1544,y:350,t:1527272175142};\\\", \\\"{x:1556,y:372,t:1527272175159};\\\", \\\"{x:1593,y:423,t:1527272175175};\\\", \\\"{x:1727,y:573,t:1527272175192};\\\", \\\"{x:1812,y:677,t:1527272175209};\\\", \\\"{x:1901,y:782,t:1527272175225};\\\", \\\"{x:1919,y:854,t:1527272175242};\\\", \\\"{x:1919,y:877,t:1527272175259};\\\", \\\"{x:1919,y:880,t:1527272175275};\\\", \\\"{x:1912,y:884,t:1527272175897};\\\", \\\"{x:1901,y:887,t:1527272175909};\\\", \\\"{x:1893,y:889,t:1527272175926};\\\", \\\"{x:1887,y:890,t:1527272175943};\\\", \\\"{x:1883,y:890,t:1527272175959};\\\", \\\"{x:1877,y:890,t:1527272176049};\\\", \\\"{x:1872,y:890,t:1527272176060};\\\", \\\"{x:1860,y:893,t:1527272176076};\\\", \\\"{x:1846,y:895,t:1527272176093};\\\", \\\"{x:1831,y:895,t:1527272176109};\\\", \\\"{x:1814,y:896,t:1527272176127};\\\", \\\"{x:1791,y:898,t:1527272176143};\\\", \\\"{x:1767,y:900,t:1527272176160};\\\", \\\"{x:1753,y:900,t:1527272176176};\\\", \\\"{x:1746,y:900,t:1527272176193};\\\", \\\"{x:1739,y:900,t:1527272176210};\\\", \\\"{x:1737,y:901,t:1527272176227};\\\", \\\"{x:1736,y:902,t:1527272176360};\\\", \\\"{x:1733,y:902,t:1527272176377};\\\", \\\"{x:1727,y:903,t:1527272176393};\\\", \\\"{x:1722,y:904,t:1527272176411};\\\", \\\"{x:1711,y:904,t:1527272176426};\\\", \\\"{x:1702,y:906,t:1527272176443};\\\", \\\"{x:1695,y:908,t:1527272176460};\\\", \\\"{x:1690,y:908,t:1527272176476};\\\", \\\"{x:1688,y:909,t:1527272176493};\\\", \\\"{x:1687,y:910,t:1527272176510};\\\", \\\"{x:1686,y:910,t:1527272176865};\\\", \\\"{x:1682,y:911,t:1527272176877};\\\", \\\"{x:1670,y:912,t:1527272176894};\\\", \\\"{x:1662,y:914,t:1527272176911};\\\", \\\"{x:1653,y:916,t:1527272176928};\\\", \\\"{x:1646,y:918,t:1527272176944};\\\", \\\"{x:1645,y:918,t:1527272176960};\\\", \\\"{x:1643,y:918,t:1527272176976};\\\", \\\"{x:1642,y:919,t:1527272176994};\\\", \\\"{x:1640,y:919,t:1527272177033};\\\", \\\"{x:1639,y:919,t:1527272177048};\\\", \\\"{x:1636,y:919,t:1527272177060};\\\", \\\"{x:1632,y:920,t:1527272177077};\\\", \\\"{x:1629,y:921,t:1527272177095};\\\", \\\"{x:1625,y:922,t:1527272177110};\\\", \\\"{x:1622,y:922,t:1527272177127};\\\", \\\"{x:1620,y:925,t:1527272177145};\\\", \\\"{x:1616,y:927,t:1527272177160};\\\", \\\"{x:1614,y:929,t:1527272177177};\\\", \\\"{x:1608,y:933,t:1527272177194};\\\", \\\"{x:1599,y:937,t:1527272177210};\\\", \\\"{x:1592,y:939,t:1527272177227};\\\", \\\"{x:1584,y:941,t:1527272177244};\\\", \\\"{x:1580,y:943,t:1527272177260};\\\", \\\"{x:1575,y:945,t:1527272177277};\\\", \\\"{x:1568,y:948,t:1527272177294};\\\", \\\"{x:1560,y:949,t:1527272177310};\\\", \\\"{x:1552,y:950,t:1527272177327};\\\", \\\"{x:1544,y:951,t:1527272177344};\\\", \\\"{x:1539,y:952,t:1527272177360};\\\", \\\"{x:1538,y:952,t:1527272177384};\\\", \\\"{x:1537,y:952,t:1527272177401};\\\", \\\"{x:1536,y:952,t:1527272177449};\\\", \\\"{x:1534,y:952,t:1527272177473};\\\", \\\"{x:1533,y:953,t:1527272177481};\\\", \\\"{x:1531,y:953,t:1527272177496};\\\", \\\"{x:1530,y:954,t:1527272177511};\\\", \\\"{x:1529,y:954,t:1527272177527};\\\", \\\"{x:1527,y:954,t:1527272177544};\\\", \\\"{x:1526,y:954,t:1527272177616};\\\", \\\"{x:1524,y:955,t:1527272177627};\\\", \\\"{x:1524,y:956,t:1527272177644};\\\", \\\"{x:1523,y:956,t:1527272178169};\\\", \\\"{x:1522,y:957,t:1527272178584};\\\", \\\"{x:1519,y:958,t:1527272178600};\\\", \\\"{x:1518,y:958,t:1527272178611};\\\", \\\"{x:1517,y:958,t:1527272178629};\\\", \\\"{x:1516,y:958,t:1527272178645};\\\", \\\"{x:1515,y:958,t:1527272178661};\\\", \\\"{x:1514,y:958,t:1527272179049};\\\", \\\"{x:1513,y:958,t:1527272179072};\\\", \\\"{x:1512,y:958,t:1527272179096};\\\", \\\"{x:1511,y:958,t:1527272179344};\\\", \\\"{x:1510,y:958,t:1527272179360};\\\", \\\"{x:1508,y:958,t:1527272179401};\\\", \\\"{x:1504,y:960,t:1527272179412};\\\", \\\"{x:1503,y:961,t:1527272179430};\\\", \\\"{x:1501,y:961,t:1527272179445};\\\", \\\"{x:1499,y:961,t:1527272179472};\\\", \\\"{x:1497,y:962,t:1527272179665};\\\", \\\"{x:1495,y:963,t:1527272179681};\\\", \\\"{x:1494,y:964,t:1527272179696};\\\", \\\"{x:1490,y:964,t:1527272179713};\\\", \\\"{x:1487,y:965,t:1527272179729};\\\", \\\"{x:1486,y:965,t:1527272179746};\\\", \\\"{x:1483,y:965,t:1527272179763};\\\", \\\"{x:1481,y:965,t:1527272179780};\\\", \\\"{x:1479,y:965,t:1527272179796};\\\", \\\"{x:1477,y:967,t:1527272179813};\\\", \\\"{x:1476,y:967,t:1527272179832};\\\", \\\"{x:1475,y:967,t:1527272179881};\\\", \\\"{x:1473,y:968,t:1527272180633};\\\", \\\"{x:1472,y:969,t:1527272180646};\\\", \\\"{x:1470,y:971,t:1527272180663};\\\", \\\"{x:1460,y:975,t:1527272180680};\\\", \\\"{x:1454,y:975,t:1527272180696};\\\", \\\"{x:1452,y:975,t:1527272180713};\\\", \\\"{x:1451,y:975,t:1527272180730};\\\", \\\"{x:1450,y:975,t:1527272180928};\\\", \\\"{x:1448,y:975,t:1527272180936};\\\", \\\"{x:1446,y:975,t:1527272180946};\\\", \\\"{x:1439,y:975,t:1527272180964};\\\", \\\"{x:1433,y:975,t:1527272180981};\\\", \\\"{x:1430,y:975,t:1527272180997};\\\", \\\"{x:1428,y:975,t:1527272181013};\\\", \\\"{x:1426,y:975,t:1527272181030};\\\", \\\"{x:1425,y:975,t:1527272181047};\\\", \\\"{x:1423,y:975,t:1527272181064};\\\", \\\"{x:1415,y:975,t:1527272181081};\\\", \\\"{x:1391,y:974,t:1527272181098};\\\", \\\"{x:1363,y:967,t:1527272181114};\\\", \\\"{x:1296,y:956,t:1527272181131};\\\", \\\"{x:1201,y:941,t:1527272181148};\\\", \\\"{x:1100,y:919,t:1527272181163};\\\", \\\"{x:975,y:898,t:1527272181180};\\\", \\\"{x:844,y:875,t:1527272181197};\\\", \\\"{x:713,y:847,t:1527272181214};\\\", \\\"{x:582,y:826,t:1527272181230};\\\", \\\"{x:518,y:816,t:1527272181247};\\\", \\\"{x:504,y:811,t:1527272181264};\\\", \\\"{x:504,y:810,t:1527272181280};\\\", \\\"{x:501,y:801,t:1527272181585};\\\", \\\"{x:488,y:785,t:1527272181598};\\\", \\\"{x:470,y:768,t:1527272181616};\\\", \\\"{x:416,y:744,t:1527272181631};\\\", \\\"{x:339,y:723,t:1527272181647};\\\", \\\"{x:258,y:699,t:1527272181663};\\\", \\\"{x:152,y:678,t:1527272181681};\\\", \\\"{x:105,y:664,t:1527272181697};\\\", \\\"{x:80,y:655,t:1527272181715};\\\", \\\"{x:65,y:650,t:1527272181732};\\\", \\\"{x:62,y:649,t:1527272181748};\\\", \\\"{x:62,y:648,t:1527272181833};\\\", \\\"{x:62,y:647,t:1527272181848};\\\", \\\"{x:64,y:645,t:1527272181865};\\\", \\\"{x:66,y:644,t:1527272181882};\\\", \\\"{x:71,y:642,t:1527272181897};\\\", \\\"{x:72,y:641,t:1527272181915};\\\", \\\"{x:74,y:640,t:1527272181931};\\\", \\\"{x:75,y:640,t:1527272181947};\\\", \\\"{x:78,y:638,t:1527272181965};\\\", \\\"{x:79,y:638,t:1527272181981};\\\", \\\"{x:81,y:636,t:1527272181998};\\\", \\\"{x:87,y:632,t:1527272182014};\\\", \\\"{x:95,y:628,t:1527272182031};\\\", \\\"{x:108,y:621,t:1527272182048};\\\", \\\"{x:130,y:615,t:1527272182065};\\\", \\\"{x:138,y:613,t:1527272182082};\\\", \\\"{x:148,y:609,t:1527272182098};\\\", \\\"{x:164,y:604,t:1527272182116};\\\", \\\"{x:167,y:602,t:1527272182132};\\\", \\\"{x:171,y:601,t:1527272182148};\\\", \\\"{x:179,y:601,t:1527272182164};\\\", \\\"{x:182,y:601,t:1527272182181};\\\", \\\"{x:190,y:601,t:1527272182198};\\\", \\\"{x:201,y:601,t:1527272182215};\\\", \\\"{x:210,y:601,t:1527272182231};\\\", \\\"{x:234,y:601,t:1527272182248};\\\", \\\"{x:241,y:601,t:1527272182264};\\\", \\\"{x:246,y:601,t:1527272182282};\\\", \\\"{x:257,y:601,t:1527272182298};\\\", \\\"{x:267,y:601,t:1527272182315};\\\", \\\"{x:283,y:596,t:1527272182332};\\\", \\\"{x:290,y:595,t:1527272182347};\\\", \\\"{x:303,y:592,t:1527272182364};\\\", \\\"{x:308,y:592,t:1527272182381};\\\", \\\"{x:310,y:592,t:1527272182398};\\\", \\\"{x:311,y:592,t:1527272182504};\\\", \\\"{x:313,y:592,t:1527272182576};\\\", \\\"{x:314,y:592,t:1527272182600};\\\", \\\"{x:314,y:591,t:1527272182616};\\\", \\\"{x:317,y:591,t:1527272182656};\\\", \\\"{x:321,y:591,t:1527272182665};\\\", \\\"{x:325,y:590,t:1527272182681};\\\", \\\"{x:329,y:589,t:1527272182698};\\\", \\\"{x:336,y:587,t:1527272182714};\\\", \\\"{x:340,y:585,t:1527272182732};\\\", \\\"{x:343,y:584,t:1527272182748};\\\", \\\"{x:347,y:583,t:1527272182764};\\\", \\\"{x:348,y:582,t:1527272182816};\\\", \\\"{x:349,y:582,t:1527272182848};\\\", \\\"{x:350,y:582,t:1527272182888};\\\", \\\"{x:351,y:581,t:1527272182898};\\\", \\\"{x:352,y:581,t:1527272182936};\\\", \\\"{x:355,y:580,t:1527272182993};\\\", \\\"{x:356,y:580,t:1527272183000};\\\", \\\"{x:359,y:580,t:1527272183014};\\\", \\\"{x:364,y:580,t:1527272183032};\\\", \\\"{x:369,y:580,t:1527272183048};\\\", \\\"{x:372,y:580,t:1527272183224};\\\", \\\"{x:381,y:580,t:1527272183232};\\\", \\\"{x:396,y:585,t:1527272183248};\\\", \\\"{x:408,y:589,t:1527272183265};\\\", \\\"{x:414,y:591,t:1527272183282};\\\", \\\"{x:421,y:593,t:1527272183298};\\\", \\\"{x:423,y:593,t:1527272183315};\\\", \\\"{x:424,y:593,t:1527272183333};\\\", \\\"{x:424,y:594,t:1527272183537};\\\", \\\"{x:424,y:595,t:1527272183745};\\\", \\\"{x:424,y:596,t:1527272183832};\\\", \\\"{x:422,y:599,t:1527272183849};\\\", \\\"{x:420,y:600,t:1527272183865};\\\", \\\"{x:417,y:602,t:1527272183882};\\\", \\\"{x:416,y:603,t:1527272183936};\\\", \\\"{x:413,y:604,t:1527272184497};\\\", \\\"{x:412,y:604,t:1527272184569};\\\", \\\"{x:410,y:605,t:1527272184600};\\\", \\\"{x:408,y:606,t:1527272184641};\\\", \\\"{x:407,y:606,t:1527272184672};\\\", \\\"{x:406,y:606,t:1527272184728};\\\", \\\"{x:404,y:606,t:1527272184760};\\\", \\\"{x:403,y:606,t:1527272184792};\\\", \\\"{x:402,y:606,t:1527272184800};\\\", \\\"{x:400,y:606,t:1527272184824};\\\", \\\"{x:399,y:606,t:1527272184888};\\\", \\\"{x:398,y:606,t:1527272184913};\\\", \\\"{x:397,y:608,t:1527272184977};\\\", \\\"{x:391,y:609,t:1527272185642};\\\", \\\"{x:382,y:613,t:1527272185650};\\\", \\\"{x:365,y:617,t:1527272185668};\\\", \\\"{x:349,y:624,t:1527272185684};\\\", \\\"{x:336,y:629,t:1527272185701};\\\", \\\"{x:321,y:635,t:1527272185717};\\\", \\\"{x:314,y:635,t:1527272185734};\\\", \\\"{x:312,y:635,t:1527272185750};\\\", \\\"{x:311,y:635,t:1527272185767};\\\", \\\"{x:310,y:636,t:1527272186008};\\\", \\\"{x:309,y:636,t:1527272186032};\\\", \\\"{x:308,y:636,t:1527272186224};\\\", \\\"{x:307,y:637,t:1527272186235};\\\", \\\"{x:306,y:637,t:1527272186297};\\\", \\\"{x:306,y:638,t:1527272186393};\\\", \\\"{x:305,y:638,t:1527272186473};\\\", \\\"{x:303,y:638,t:1527272186496};\\\", \\\"{x:301,y:639,t:1527272186520};\\\", \\\"{x:298,y:639,t:1527272186534};\\\", \\\"{x:295,y:639,t:1527272186552};\\\", \\\"{x:292,y:641,t:1527272186568};\\\", \\\"{x:290,y:641,t:1527272187569};\\\", \\\"{x:286,y:642,t:1527272187586};\\\", \\\"{x:282,y:645,t:1527272187603};\\\", \\\"{x:279,y:645,t:1527272187619};\\\", \\\"{x:273,y:647,t:1527272187636};\\\", \\\"{x:265,y:651,t:1527272187653};\\\", \\\"{x:258,y:654,t:1527272187669};\\\", \\\"{x:256,y:655,t:1527272187685};\\\", \\\"{x:254,y:655,t:1527272187702};\\\", \\\"{x:252,y:657,t:1527272187719};\\\", \\\"{x:252,y:654,t:1527272188880};\\\", \\\"{x:252,y:648,t:1527272188888};\\\", \\\"{x:251,y:644,t:1527272188904};\\\", \\\"{x:244,y:635,t:1527272188920};\\\", \\\"{x:235,y:612,t:1527272188936};\\\", \\\"{x:233,y:600,t:1527272188954};\\\", \\\"{x:233,y:594,t:1527272188970};\\\", \\\"{x:233,y:591,t:1527272188986};\\\", \\\"{x:233,y:590,t:1527272189004};\\\", \\\"{x:233,y:589,t:1527272189020};\\\", \\\"{x:235,y:587,t:1527272189036};\\\", \\\"{x:239,y:585,t:1527272189054};\\\", \\\"{x:241,y:585,t:1527272189072};\\\", \\\"{x:243,y:585,t:1527272189129};\\\", \\\"{x:245,y:584,t:1527272189136};\\\", \\\"{x:248,y:583,t:1527272189154};\\\", \\\"{x:250,y:583,t:1527272189170};\\\", \\\"{x:251,y:582,t:1527272189187};\\\", \\\"{x:252,y:582,t:1527272189204};\\\", \\\"{x:253,y:582,t:1527272189221};\\\", \\\"{x:254,y:581,t:1527272189236};\\\", \\\"{x:266,y:577,t:1527272189254};\\\", \\\"{x:302,y:570,t:1527272189270};\\\", \\\"{x:345,y:563,t:1527272189287};\\\", \\\"{x:359,y:555,t:1527272189304};\\\", \\\"{x:369,y:551,t:1527272189320};\\\", \\\"{x:370,y:551,t:1527272189368};\\\", \\\"{x:369,y:551,t:1527272189384};\\\", \\\"{x:368,y:552,t:1527272189425};\\\", \\\"{x:366,y:554,t:1527272189456};\\\", \\\"{x:364,y:559,t:1527272189471};\\\", \\\"{x:363,y:560,t:1527272189487};\\\", \\\"{x:364,y:565,t:1527272189504};\\\", \\\"{x:369,y:570,t:1527272189523};\\\", \\\"{x:375,y:575,t:1527272189538};\\\", \\\"{x:376,y:575,t:1527272189554};\\\", \\\"{x:377,y:576,t:1527272189571};\\\", \\\"{x:378,y:578,t:1527272189589};\\\", \\\"{x:382,y:581,t:1527272189604};\\\", \\\"{x:385,y:585,t:1527272189621};\\\", \\\"{x:387,y:586,t:1527272189638};\\\", \\\"{x:388,y:587,t:1527272189653};\\\", \\\"{x:388,y:588,t:1527272189671};\\\", \\\"{x:389,y:589,t:1527272189696};\\\", \\\"{x:392,y:592,t:1527272189720};\\\", \\\"{x:394,y:593,t:1527272189737};\\\", \\\"{x:395,y:594,t:1527272189842};\\\", \\\"{x:395,y:597,t:1527272189854};\\\", \\\"{x:394,y:600,t:1527272189872};\\\", \\\"{x:394,y:601,t:1527272189888};\\\", \\\"{x:393,y:603,t:1527272189904};\\\", \\\"{x:392,y:603,t:1527272190208};\\\", \\\"{x:390,y:604,t:1527272190360};\\\", \\\"{x:390,y:604,t:1527272190370};\\\", \\\"{x:388,y:604,t:1527272190387};\\\", \\\"{x:388,y:606,t:1527272190576};\\\", \\\"{x:388,y:610,t:1527272190588};\\\", \\\"{x:391,y:617,t:1527272190605};\\\", \\\"{x:394,y:625,t:1527272190622};\\\", \\\"{x:398,y:630,t:1527272190639};\\\", \\\"{x:398,y:631,t:1527272190655};\\\", \\\"{x:398,y:630,t:1527272190848};\\\", \\\"{x:398,y:628,t:1527272190856};\\\", \\\"{x:401,y:624,t:1527272190871};\\\", \\\"{x:401,y:622,t:1527272190888};\\\", \\\"{x:402,y:620,t:1527272190905};\\\", \\\"{x:403,y:619,t:1527272190922};\\\", \\\"{x:403,y:618,t:1527272190938};\\\", \\\"{x:404,y:616,t:1527272190956};\\\", \\\"{x:404,y:615,t:1527272190971};\\\", \\\"{x:404,y:612,t:1527272190990};\\\", \\\"{x:403,y:608,t:1527272191005};\\\", \\\"{x:402,y:605,t:1527272191022};\\\", \\\"{x:400,y:603,t:1527272191039};\\\", \\\"{x:399,y:602,t:1527272191064};\\\", \\\"{x:398,y:599,t:1527272191121};\\\", \\\"{x:396,y:597,t:1527272191138};\\\", \\\"{x:393,y:593,t:1527272191155};\\\", \\\"{x:391,y:591,t:1527272191172};\\\", \\\"{x:389,y:589,t:1527272191189};\\\", \\\"{x:387,y:588,t:1527272191208};\\\", \\\"{x:390,y:595,t:1527272191480};\\\", \\\"{x:396,y:606,t:1527272191489};\\\", \\\"{x:402,y:621,t:1527272191506};\\\", \\\"{x:414,y:641,t:1527272191522};\\\", \\\"{x:425,y:655,t:1527272191539};\\\", \\\"{x:436,y:668,t:1527272191556};\\\", \\\"{x:448,y:683,t:1527272191572};\\\", \\\"{x:458,y:703,t:1527272191590};\\\", \\\"{x:468,y:719,t:1527272191606};\\\", \\\"{x:474,y:733,t:1527272191623};\\\", \\\"{x:480,y:746,t:1527272191639};\\\", \\\"{x:483,y:754,t:1527272191656};\\\", \\\"{x:489,y:756,t:1527272191672};\\\", \\\"{x:490,y:756,t:1527272191688};\\\" ] }, { \\\"rt\\\": 70266, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 690672, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"go towards the bottom of chart find 12pm and look any dot on 12pm\\\\n\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 18940, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"18\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\" Minnesota\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 710619, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 18806, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 730443, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 11704, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 743462, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"55GO7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"55GO7\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 174, dom: 682, initialDom: 791",
  "javascriptErrors": []
}