var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "22fc40d20df824b48e4b4201a328bfcf",
  "created": "2018-05-29T12:15:25.1513003-07:00",
  "lastActivity": "2018-05-29T12:18:16.919634-07:00",
  "pageViews": [
    {
      "id": "052925873a50a0c2fae12399b32881f1b06f2212",
      "startTime": "2018-05-29T12:15:25.5784552-07:00",
      "endTime": "2018-05-29T12:18:16.919634-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 171796,
      "engagementTime": 141039,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 171796,
  "engagementTime": 141039,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=BWVFU",
    "CONDITION=114\n114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6337bb81fd58710fe526571364661b77",
  "gdpr": false
}