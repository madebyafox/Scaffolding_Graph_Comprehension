var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "2f88c00f5bb9518fcd4139dc5a40b6e0",
  "created": "2018-05-29T10:11:22.4374061-07:00",
  "lastActivity": "2018-05-29T10:11:40.056492-07:00",
  "pageViews": [
    {
      "id": "05292281a79d470cef4a925f90aa34cfdc071313",
      "startTime": "2018-05-29T10:11:22.5770302-07:00",
      "endTime": "2018-05-29T10:11:40.056492-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 17699,
      "engagementTime": 17398,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 17699,
  "engagementTime": 17398,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8GUB2",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e7e3ef841d2f1c7b9e0dfb4419b06747",
  "gdpr": false
}