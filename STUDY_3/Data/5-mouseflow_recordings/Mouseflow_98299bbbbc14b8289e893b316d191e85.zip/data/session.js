var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "98299bbbbc14b8289e893b316d191e85",
  "created": "2018-05-21T12:11:04.1282831-07:00",
  "lastActivity": "2018-05-21T12:11:23.1524594-07:00",
  "pageViews": [
    {
      "id": "052104506821bb06ee41867a5fc25be202a4a679",
      "startTime": "2018-05-21T12:11:04.1282831-07:00",
      "endTime": "2018-05-21T12:11:23.1524594-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 19243,
      "engagementTime": 19243,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 19243,
  "engagementTime": 19243,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=9BBMD",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ee76ca006e40cbabebf8b4fd5b37d269",
  "gdpr": false
}