var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f7cc3836266ead6700678238d6653f7d",
  "created": "2018-06-04T13:21:54.6650194-07:00",
  "lastActivity": "2018-06-04T13:22:27.8157134-07:00",
  "pageViews": [
    {
      "id": "06045477c134ef4e9bca26b7e89fc049bc5f2650",
      "startTime": "2018-06-04T13:21:54.6827134-07:00",
      "endTime": "2018-06-04T13:22:27.8157134-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 33133,
      "engagementTime": 24132,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 33133,
  "engagementTime": 24132,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.38",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MUULG",
    "CONDITION=211",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0def81973c8da9e9ba68b3894d1a6b9b",
  "gdpr": false
}