var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05242711c99f159a83e9b2d299991f72aa703790"] = {
  "startTime": "2018-05-24T19:03:27.8953407Z",
  "websitePageUrl": "/",
  "visitTime": 122536,
  "engagementTime": 52858,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "c11bd7183023a81774df52781d37d9d7",
    "created": "2018-05-24T19:03:27.8953407+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "434bd2e70827e7afe7135a4932c3a43b",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/c11bd7183023a81774df52781d37d9d7/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 304,
      "e": 304,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 3300,
      "e": 3300,
      "ty": 2,
      "x": 379,
      "y": 170
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 2,
      "x": 527,
      "y": 662
    },
    {
      "t": 3497,
      "e": 3497,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 849,
      "y": 1064
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 41,
      "x": 28962,
      "y": 64257,
      "ta": "html > body"
    },
    {
      "t": 3800,
      "e": 3800,
      "ty": 2,
      "x": 1919,
      "y": 1035
    },
    {
      "t": 3900,
      "e": 3900,
      "ty": 2,
      "x": 1919,
      "y": 917
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 2,
      "x": 1919,
      "y": 879
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 1835,
      "y": 855
    },
    {
      "t": 4200,
      "e": 4200,
      "ty": 2,
      "x": 1833,
      "y": 854
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 62504,
      "y": 51296,
      "ta": "html > body"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 1812,
      "y": 848
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 1807,
      "y": 848
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 61953,
      "y": 51113,
      "ta": "html > body"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 1,
      "x": 0,
      "y": 6
    },
    {
      "t": 4900,
      "e": 4900,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 5100,
      "e": 5100,
      "ty": 2,
      "x": 1791,
      "y": 864
    },
    {
      "t": 5201,
      "e": 5201,
      "ty": 2,
      "x": 1204,
      "y": 852
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 30282,
      "y": 60415,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5300,
      "e": 5300,
      "ty": 2,
      "x": 786,
      "y": 888
    },
    {
      "t": 5300,
      "e": 5300,
      "ty": 1,
      "x": 0,
      "y": 12
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 2,
      "x": 746,
      "y": 871
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 2,
      "x": 792,
      "y": 836
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 23619,
      "y": 56482,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5600,
      "e": 5600,
      "ty": 2,
      "x": 795,
      "y": 833
    },
    {
      "t": 5700,
      "e": 5700,
      "ty": 2,
      "x": 810,
      "y": 825
    },
    {
      "t": 5750,
      "e": 5750,
      "ty": 41,
      "x": 25695,
      "y": 54025,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5800,
      "e": 5800,
      "ty": 2,
      "x": 832,
      "y": 803
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 25804,
      "y": 53779,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 19502,
      "e": 11001,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 19502,
      "e": 11001,
      "ty": 2,
      "x": 832,
      "y": 869
    },
    {
      "t": 19502,
      "e": 11001,
      "ty": 41,
      "x": 25804,
      "y": 54844,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 30000,
      "e": 16001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 34751,
      "e": 16001,
      "ty": 41,
      "x": 31484,
      "y": 53124,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 34801,
      "e": 16051,
      "ty": 2,
      "x": 1250,
      "y": 851
    },
    {
      "t": 34900,
      "e": 16150,
      "ty": 2,
      "x": 1735,
      "y": 1199
    },
    {
      "t": 35001,
      "e": 16251,
      "ty": 2,
      "x": 1708,
      "y": 1199
    },
    {
      "t": 40001,
      "e": 21251,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 75199,
      "e": 21251,
      "ty": 2,
      "x": 1863,
      "y": 1199
    },
    {
      "t": 75299,
      "e": 21351,
      "ty": 2,
      "x": 1917,
      "y": 1199
    },
    {
      "t": 75608,
      "e": 21660,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 75899,
      "e": 21951,
      "ty": 2,
      "x": 1919,
      "y": 1134
    },
    {
      "t": 75999,
      "e": 22051,
      "ty": 2,
      "x": 1919,
      "y": 1070
    },
    {
      "t": 76099,
      "e": 22151,
      "ty": 2,
      "x": 1919,
      "y": 1079
    },
    {
      "t": 76199,
      "e": 22251,
      "ty": 2,
      "x": 1919,
      "y": 1123
    },
    {
      "t": 76299,
      "e": 22351,
      "ty": 2,
      "x": 1919,
      "y": 1189
    },
    {
      "t": 76399,
      "e": 22451,
      "ty": 2,
      "x": 1919,
      "y": 1199
    },
    {
      "t": 76499,
      "e": 22551,
      "ty": 2,
      "x": 1701,
      "y": 1199
    },
    {
      "t": 76599,
      "e": 22651,
      "ty": 2,
      "x": 1125,
      "y": 1199
    },
    {
      "t": 76699,
      "e": 22751,
      "ty": 2,
      "x": 647,
      "y": 1067
    },
    {
      "t": 76750,
      "e": 22802,
      "ty": 41,
      "x": 14589,
      "y": 59878,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76800,
      "e": 22852,
      "ty": 2,
      "x": 615,
      "y": 940
    },
    {
      "t": 76899,
      "e": 22951,
      "ty": 2,
      "x": 732,
      "y": 843
    },
    {
      "t": 76999,
      "e": 23051,
      "ty": 2,
      "x": 758,
      "y": 902
    },
    {
      "t": 77000,
      "e": 23052,
      "ty": 41,
      "x": 22854,
      "y": 62223,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 77099,
      "e": 23151,
      "ty": 2,
      "x": 767,
      "y": 934
    },
    {
      "t": 77200,
      "e": 23252,
      "ty": 2,
      "x": 784,
      "y": 945
    },
    {
      "t": 77249,
      "e": 23301,
      "ty": 41,
      "x": 24231,
      "y": 56692,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 77300,
      "e": 23352,
      "ty": 2,
      "x": 788,
      "y": 941
    },
    {
      "t": 77399,
      "e": 23451,
      "ty": 2,
      "x": 793,
      "y": 935
    },
    {
      "t": 77499,
      "e": 23551,
      "ty": 2,
      "x": 798,
      "y": 928
    },
    {
      "t": 77500,
      "e": 23552,
      "ty": 41,
      "x": 24822,
      "y": 52011,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 77599,
      "e": 23651,
      "ty": 2,
      "x": 799,
      "y": 927
    },
    {
      "t": 77699,
      "e": 23751,
      "ty": 2,
      "x": 811,
      "y": 920
    },
    {
      "t": 77750,
      "e": 23802,
      "ty": 41,
      "x": 44440,
      "y": 19711,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 77799,
      "e": 23851,
      "ty": 2,
      "x": 819,
      "y": 913
    },
    {
      "t": 77854,
      "e": 23906,
      "ty": 3,
      "x": 819,
      "y": 913,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 77918,
      "e": 23970,
      "ty": 4,
      "x": 50994,
      "y": 6604,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 77919,
      "e": 23971,
      "ty": 5,
      "x": 819,
      "y": 913,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 77920,
      "e": 23972,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 77924,
      "e": 23976,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 77999,
      "e": 24051,
      "ty": 41,
      "x": 50994,
      "y": 6604,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 78099,
      "e": 24151,
      "ty": 2,
      "x": 829,
      "y": 966
    },
    {
      "t": 78199,
      "e": 24251,
      "ty": 2,
      "x": 899,
      "y": 1046
    },
    {
      "t": 78249,
      "e": 24301,
      "ty": 41,
      "x": 31316,
      "y": 64933,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 78300,
      "e": 24352,
      "ty": 2,
      "x": 930,
      "y": 1064
    },
    {
      "t": 78391,
      "e": 24443,
      "ty": 6,
      "x": 938,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 78399,
      "e": 24451,
      "ty": 2,
      "x": 938,
      "y": 1074
    },
    {
      "t": 78499,
      "e": 24551,
      "ty": 2,
      "x": 950,
      "y": 1088
    },
    {
      "t": 78499,
      "e": 24551,
      "ty": 41,
      "x": 22118,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 78599,
      "e": 24651,
      "ty": 2,
      "x": 952,
      "y": 1090
    },
    {
      "t": 78671,
      "e": 24723,
      "ty": 3,
      "x": 952,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 78673,
      "e": 24725,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 78674,
      "e": 24726,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 78750,
      "e": 24802,
      "ty": 41,
      "x": 23210,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 78766,
      "e": 24818,
      "ty": 4,
      "x": 23210,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 78767,
      "e": 24819,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 78767,
      "e": 24819,
      "ty": 5,
      "x": 952,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 78768,
      "e": 24820,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 79200,
      "e": 25252,
      "ty": 2,
      "x": 941,
      "y": 1082
    },
    {
      "t": 79248,
      "e": 25300,
      "ty": 41,
      "x": 32061,
      "y": 59441,
      "ta": "html > body"
    },
    {
      "t": 79299,
      "e": 25351,
      "ty": 2,
      "x": 939,
      "y": 1081
    },
    {
      "t": 79399,
      "e": 25451,
      "ty": 2,
      "x": 937,
      "y": 1062
    },
    {
      "t": 79499,
      "e": 25551,
      "ty": 2,
      "x": 935,
      "y": 1053
    },
    {
      "t": 79499,
      "e": 25551,
      "ty": 41,
      "x": 31923,
      "y": 57890,
      "ta": "html > body"
    },
    {
      "t": 79775,
      "e": 25827,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 80399,
      "e": 26451,
      "ty": 2,
      "x": 906,
      "y": 942
    },
    {
      "t": 80498,
      "e": 26550,
      "ty": 2,
      "x": 858,
      "y": 752
    },
    {
      "t": 80498,
      "e": 26550,
      "ty": 41,
      "x": 29272,
      "y": 41215,
      "ta": "html > body"
    },
    {
      "t": 80591,
      "e": 26643,
      "ty": 6,
      "x": 861,
      "y": 690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80598,
      "e": 26650,
      "ty": 2,
      "x": 861,
      "y": 690
    },
    {
      "t": 80608,
      "e": 26660,
      "ty": 7,
      "x": 862,
      "y": 675,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80698,
      "e": 26750,
      "ty": 2,
      "x": 866,
      "y": 652
    },
    {
      "t": 80749,
      "e": 26801,
      "ty": 41,
      "x": 13409,
      "y": 30426,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 80798,
      "e": 26850,
      "ty": 2,
      "x": 876,
      "y": 641
    },
    {
      "t": 80899,
      "e": 26951,
      "ty": 2,
      "x": 890,
      "y": 620
    },
    {
      "t": 80998,
      "e": 27050,
      "ty": 2,
      "x": 890,
      "y": 616
    },
    {
      "t": 80999,
      "e": 27051,
      "ty": 41,
      "x": 17735,
      "y": 704,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 81092,
      "e": 27144,
      "ty": 6,
      "x": 890,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 81098,
      "e": 27150,
      "ty": 2,
      "x": 890,
      "y": 606
    },
    {
      "t": 81198,
      "e": 27250,
      "ty": 2,
      "x": 890,
      "y": 599
    },
    {
      "t": 81249,
      "e": 27301,
      "ty": 41,
      "x": 17951,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 81299,
      "e": 27351,
      "ty": 2,
      "x": 891,
      "y": 588
    },
    {
      "t": 81359,
      "e": 27411,
      "ty": 7,
      "x": 891,
      "y": 585,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 81399,
      "e": 27451,
      "ty": 2,
      "x": 891,
      "y": 585
    },
    {
      "t": 81472,
      "e": 27524,
      "ty": 6,
      "x": 884,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 81499,
      "e": 27551,
      "ty": 2,
      "x": 864,
      "y": 598
    },
    {
      "t": 81499,
      "e": 27551,
      "ty": 41,
      "x": 12112,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 81598,
      "e": 27650,
      "ty": 2,
      "x": 861,
      "y": 598
    },
    {
      "t": 81719,
      "e": 27771,
      "ty": 3,
      "x": 861,
      "y": 598,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 81720,
      "e": 27772,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 81748,
      "e": 27800,
      "ty": 41,
      "x": 11463,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 81790,
      "e": 27842,
      "ty": 4,
      "x": 11463,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 81790,
      "e": 27842,
      "ty": 5,
      "x": 861,
      "y": 598,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 82954,
      "e": 29006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "75"
    },
    {
      "t": 82954,
      "e": 29006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 83058,
      "e": 29110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "k"
    },
    {
      "t": 83211,
      "e": 29263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 83212,
      "e": 29264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 83290,
      "e": 29342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ki"
    },
    {
      "t": 83404,
      "e": 29456,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ki"
    },
    {
      "t": 83498,
      "e": 29550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 83499,
      "e": 29551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 83586,
      "e": 29638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "kil"
    },
    {
      "t": 83905,
      "e": 29957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 83905,
      "e": 29957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 83978,
      "e": 30030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "kilo"
    },
    {
      "t": 84699,
      "e": 30751,
      "ty": 2,
      "x": 861,
      "y": 599
    },
    {
      "t": 84729,
      "e": 30781,
      "ty": 7,
      "x": 861,
      "y": 610,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 84748,
      "e": 30800,
      "ty": 41,
      "x": 11463,
      "y": 4932,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 84799,
      "e": 30851,
      "ty": 2,
      "x": 860,
      "y": 662
    },
    {
      "t": 84829,
      "e": 30881,
      "ty": 6,
      "x": 855,
      "y": 687,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84862,
      "e": 30914,
      "ty": 7,
      "x": 854,
      "y": 705,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84899,
      "e": 30951,
      "ty": 2,
      "x": 853,
      "y": 713
    },
    {
      "t": 84998,
      "e": 31050,
      "ty": 41,
      "x": 29099,
      "y": 39055,
      "ta": "html > body"
    },
    {
      "t": 85062,
      "e": 31114,
      "ty": 6,
      "x": 851,
      "y": 698,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 85095,
      "e": 31147,
      "ty": 7,
      "x": 846,
      "y": 676,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 85098,
      "e": 31150,
      "ty": 2,
      "x": 846,
      "y": 676
    },
    {
      "t": 85198,
      "e": 31250,
      "ty": 2,
      "x": 838,
      "y": 667
    },
    {
      "t": 85249,
      "e": 31301,
      "ty": 41,
      "x": 5407,
      "y": 40871,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 85298,
      "e": 31350,
      "ty": 2,
      "x": 832,
      "y": 676
    },
    {
      "t": 85351,
      "e": 31403,
      "ty": 6,
      "x": 832,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 85399,
      "e": 31403,
      "ty": 2,
      "x": 832,
      "y": 687
    },
    {
      "t": 85499,
      "e": 31503,
      "ty": 2,
      "x": 834,
      "y": 697
    },
    {
      "t": 85499,
      "e": 31503,
      "ty": 41,
      "x": 5623,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 85663,
      "e": 31667,
      "ty": 3,
      "x": 834,
      "y": 697,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 85664,
      "e": 31668,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "kilo"
    },
    {
      "t": 85665,
      "e": 31669,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 85665,
      "e": 31669,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 85693,
      "e": 31697,
      "ty": 4,
      "x": 5623,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 85693,
      "e": 31697,
      "ty": 5,
      "x": 834,
      "y": 697,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86339,
      "e": 32343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 86339,
      "e": 32343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86434,
      "e": 32438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 86522,
      "e": 32526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 86523,
      "e": 32527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86578,
      "e": 32582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 86803,
      "e": 32807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "99"
    },
    {
      "t": 86803,
      "e": 32807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86897,
      "e": 32901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 87999,
      "e": 34003,
      "ty": 2,
      "x": 855,
      "y": 696
    },
    {
      "t": 87999,
      "e": 34003,
      "ty": 41,
      "x": 10165,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88048,
      "e": 34052,
      "ty": 7,
      "x": 899,
      "y": 706,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88064,
      "e": 34068,
      "ty": 6,
      "x": 926,
      "y": 722,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 88098,
      "e": 34102,
      "ty": 2,
      "x": 955,
      "y": 735
    },
    {
      "t": 88198,
      "e": 34202,
      "ty": 2,
      "x": 958,
      "y": 737
    },
    {
      "t": 88249,
      "e": 34253,
      "ty": 41,
      "x": 31994,
      "y": 57591,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 88487,
      "e": 34491,
      "ty": 3,
      "x": 958,
      "y": 737,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 88488,
      "e": 34492,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 88489,
      "e": 34493,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88490,
      "e": 34494,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 88550,
      "e": 34554,
      "ty": 4,
      "x": 31994,
      "y": 57591,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 88552,
      "e": 34556,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 88553,
      "e": 34557,
      "ty": 5,
      "x": 958,
      "y": 737,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 88554,
      "e": 34558,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 88899,
      "e": 34903,
      "ty": 2,
      "x": 959,
      "y": 736
    },
    {
      "t": 88999,
      "e": 35003,
      "ty": 2,
      "x": 690,
      "y": 0
    },
    {
      "t": 88999,
      "e": 35003,
      "ty": 41,
      "x": 23762,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 89099,
      "e": 35103,
      "ty": 2,
      "x": 758,
      "y": 0
    },
    {
      "t": 89199,
      "e": 35203,
      "ty": 2,
      "x": 827,
      "y": 0
    },
    {
      "t": 89248,
      "e": 35252,
      "ty": 41,
      "x": 28204,
      "y": 3600,
      "ta": "html > body"
    },
    {
      "t": 89299,
      "e": 35303,
      "ty": 2,
      "x": 774,
      "y": 176
    },
    {
      "t": 89399,
      "e": 35403,
      "ty": 2,
      "x": 763,
      "y": 216
    },
    {
      "t": 89498,
      "e": 35502,
      "ty": 2,
      "x": 757,
      "y": 232
    },
    {
      "t": 89499,
      "e": 35503,
      "ty": 41,
      "x": 25793,
      "y": 12408,
      "ta": "html > body"
    },
    {
      "t": 89598,
      "e": 35602,
      "ty": 2,
      "x": 753,
      "y": 238
    },
    {
      "t": 89648,
      "e": 35652,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 89698,
      "e": 35702,
      "ty": 2,
      "x": 749,
      "y": 243
    },
    {
      "t": 89749,
      "e": 35753,
      "ty": 41,
      "x": 22116,
      "y": 8843,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 89798,
      "e": 35802,
      "ty": 2,
      "x": 724,
      "y": 281
    },
    {
      "t": 89898,
      "e": 35902,
      "ty": 2,
      "x": 694,
      "y": 347
    },
    {
      "t": 89999,
      "e": 36003,
      "ty": 2,
      "x": 694,
      "y": 351
    },
    {
      "t": 89999,
      "e": 36003,
      "ty": 41,
      "x": 19705,
      "y": 15560,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 90200,
      "e": 36204,
      "ty": 2,
      "x": 700,
      "y": 384
    },
    {
      "t": 90249,
      "e": 36253,
      "ty": 41,
      "x": 20197,
      "y": 19160,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 90299,
      "e": 36303,
      "ty": 2,
      "x": 717,
      "y": 436
    },
    {
      "t": 90398,
      "e": 36402,
      "ty": 2,
      "x": 732,
      "y": 474
    },
    {
      "t": 90483,
      "e": 36487,
      "ty": 6,
      "x": 737,
      "y": 512,
      "ta": "#da1"
    },
    {
      "t": 90498,
      "e": 36502,
      "ty": 2,
      "x": 737,
      "y": 512
    },
    {
      "t": 90499,
      "e": 36503,
      "ty": 41,
      "x": 44052,
      "y": 51,
      "ta": "#da1"
    },
    {
      "t": 90599,
      "e": 36603,
      "ty": 2,
      "x": 731,
      "y": 530
    },
    {
      "t": 90600,
      "e": 36604,
      "ty": 7,
      "x": 724,
      "y": 534,
      "ta": "#da1"
    },
    {
      "t": 90699,
      "e": 36703,
      "ty": 2,
      "x": 651,
      "y": 559
    },
    {
      "t": 90749,
      "e": 36753,
      "ty": 41,
      "x": 30264,
      "y": 39825,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[4] > td:[2]"
    },
    {
      "t": 90799,
      "e": 36803,
      "ty": 2,
      "x": 556,
      "y": 570
    },
    {
      "t": 90899,
      "e": 36903,
      "ty": 2,
      "x": 547,
      "y": 574
    },
    {
      "t": 90999,
      "e": 37003,
      "ty": 2,
      "x": 514,
      "y": 604
    },
    {
      "t": 91000,
      "e": 37004,
      "ty": 41,
      "x": 19687,
      "y": 58549,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[5] > td"
    },
    {
      "t": 91099,
      "e": 37103,
      "ty": 2,
      "x": 522,
      "y": 660
    },
    {
      "t": 91101,
      "e": 37105,
      "ty": 6,
      "x": 528,
      "y": 680,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 91133,
      "e": 37137,
      "ty": 7,
      "x": 537,
      "y": 711,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 91134,
      "e": 37138,
      "ty": 6,
      "x": 537,
      "y": 711,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 91167,
      "e": 37171,
      "ty": 7,
      "x": 549,
      "y": 730,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 91167,
      "e": 37171,
      "ty": 6,
      "x": 549,
      "y": 730,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 91199,
      "e": 37203,
      "ty": 2,
      "x": 555,
      "y": 743
    },
    {
      "t": 91217,
      "e": 37221,
      "ty": 7,
      "x": 563,
      "y": 759,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 91217,
      "e": 37221,
      "ty": 6,
      "x": 563,
      "y": 759,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 91249,
      "e": 37253,
      "ty": 41,
      "x": 11753,
      "y": 14079,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 91298,
      "e": 37302,
      "ty": 2,
      "x": 565,
      "y": 764
    },
    {
      "t": 91399,
      "e": 37403,
      "ty": 2,
      "x": 581,
      "y": 773
    },
    {
      "t": 91500,
      "e": 37504,
      "ty": 41,
      "x": 12614,
      "y": 42166,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 92599,
      "e": 38603,
      "ty": 2,
      "x": 584,
      "y": 773
    },
    {
      "t": 92699,
      "e": 38703,
      "ty": 2,
      "x": 594,
      "y": 774
    },
    {
      "t": 92749,
      "e": 38753,
      "ty": 41,
      "x": 13577,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 92770,
      "e": 38774,
      "ty": 7,
      "x": 607,
      "y": 785,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 92799,
      "e": 38803,
      "ty": 2,
      "x": 609,
      "y": 786
    },
    {
      "t": 92899,
      "e": 38903,
      "ty": 2,
      "x": 670,
      "y": 818
    },
    {
      "t": 92999,
      "e": 39003,
      "ty": 2,
      "x": 763,
      "y": 865
    },
    {
      "t": 92999,
      "e": 39003,
      "ty": 41,
      "x": 23100,
      "y": 51153,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93099,
      "e": 39103,
      "ty": 2,
      "x": 870,
      "y": 926
    },
    {
      "t": 93198,
      "e": 39202,
      "ty": 2,
      "x": 937,
      "y": 979
    },
    {
      "t": 93249,
      "e": 39253,
      "ty": 41,
      "x": 33087,
      "y": 60917,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93299,
      "e": 39303,
      "ty": 2,
      "x": 980,
      "y": 1023
    },
    {
      "t": 93398,
      "e": 39402,
      "ty": 2,
      "x": 984,
      "y": 1047
    },
    {
      "t": 93471,
      "e": 39475,
      "ty": 6,
      "x": 988,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 93498,
      "e": 39502,
      "ty": 2,
      "x": 988,
      "y": 1075
    },
    {
      "t": 93499,
      "e": 39503,
      "ty": 41,
      "x": 42870,
      "y": 4457,
      "ta": "#start"
    },
    {
      "t": 93599,
      "e": 39603,
      "ty": 2,
      "x": 988,
      "y": 1084
    },
    {
      "t": 93699,
      "e": 39703,
      "ty": 2,
      "x": 984,
      "y": 1090
    },
    {
      "t": 93749,
      "e": 39753,
      "ty": 41,
      "x": 34678,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 93799,
      "e": 39803,
      "ty": 2,
      "x": 970,
      "y": 1097
    },
    {
      "t": 93999,
      "e": 40003,
      "ty": 41,
      "x": 33040,
      "y": 46862,
      "ta": "#start"
    },
    {
      "t": 99399,
      "e": 45003,
      "ty": 2,
      "x": 969,
      "y": 1097
    },
    {
      "t": 99499,
      "e": 45103,
      "ty": 2,
      "x": 967,
      "y": 1098
    },
    {
      "t": 99499,
      "e": 45103,
      "ty": 41,
      "x": 31402,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 99999,
      "e": 45603,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 102135,
      "e": 47739,
      "ty": 3,
      "x": 967,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 102136,
      "e": 47740,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 102253,
      "e": 47857,
      "ty": 4,
      "x": 31402,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 102254,
      "e": 47858,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 102254,
      "e": 47858,
      "ty": 5,
      "x": 967,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 102255,
      "e": 47859,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 103258,
      "e": 48862,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 109999,
      "e": 52858,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 121530,
      "e": 52858,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 122536,
      "e": 52858,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 278, dom: 956, initialDom: 961",
  "javascriptErrors": []
}