var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c11bd7183023a81774df52781d37d9d7",
  "created": "2018-05-24T12:03:27.8953407-07:00",
  "lastActivity": "2018-05-24T12:05:30.4313407-07:00",
  "pageViews": [
    {
      "id": "05242711c99f159a83e9b2d299991f72aa703790",
      "startTime": "2018-05-24T12:03:27.8953407-07:00",
      "endTime": "2018-05-24T12:05:30.4313407-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 122536,
      "engagementTime": 52858,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 122536,
  "engagementTime": 52858,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "434bd2e70827e7afe7135a4932c3a43b",
  "gdpr": false
}