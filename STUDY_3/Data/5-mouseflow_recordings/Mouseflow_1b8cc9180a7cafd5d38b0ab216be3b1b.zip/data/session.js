var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1b8cc9180a7cafd5d38b0ab216be3b1b",
  "created": "2018-05-18T11:07:52.6013539-07:00",
  "lastActivity": "2018-05-18T11:10:46.1272154-07:00",
  "pageViews": [
    {
      "id": "05185294f4bc7c982254376627a9455c1d53f10a",
      "startTime": "2018-05-18T11:07:52.6013539-07:00",
      "endTime": "2018-05-18T11:10:46.1272154-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 173677,
      "engagementTime": 73907,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 173677,
  "engagementTime": 73907,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "3b560accc9d85636509ab9128ea21e32",
  "gdpr": false
}