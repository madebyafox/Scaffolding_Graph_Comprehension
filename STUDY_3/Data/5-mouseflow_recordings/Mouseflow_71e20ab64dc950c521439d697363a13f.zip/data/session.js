var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "71e20ab64dc950c521439d697363a13f",
  "created": "2018-06-04T12:27:04.2644221-07:00",
  "lastActivity": "2018-06-04T12:28:11.0054221-07:00",
  "pageViews": [
    {
      "id": "060404836e0570a731d347efc78e0343864d31b4",
      "startTime": "2018-06-04T12:27:04.2644221-07:00",
      "endTime": "2018-06-04T12:28:11.0054221-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 66741,
      "engagementTime": 66741,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 66741,
  "engagementTime": 66741,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=74OF5",
    "CONDITION=311\n311",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "06de25abe2bf9360c9e920fd48dc9dab",
  "gdpr": false
}