var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "39d8b6a2ebc9a0fafa2ccc7301f6dd0b",
  "created": "2018-06-04T13:21:53.7297659-07:00",
  "lastActivity": "2018-06-04T13:22:18.5637659-07:00",
  "pageViews": [
    {
      "id": "06045457a04b4a3c7f02d8e6ffe5563704a52ad2",
      "startTime": "2018-06-04T13:21:53.7297659-07:00",
      "endTime": "2018-06-04T13:22:18.5637659-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 24834,
      "engagementTime": 24734,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 24834,
  "engagementTime": 24734,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=VHSFM",
    "CONDITION=211",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "2f7f5222c15c6fc21088e5562261da0b",
  "gdpr": false
}