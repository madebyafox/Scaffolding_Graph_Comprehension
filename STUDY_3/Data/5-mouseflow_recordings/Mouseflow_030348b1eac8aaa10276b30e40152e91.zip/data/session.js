var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "030348b1eac8aaa10276b30e40152e91",
  "created": "2018-05-18T10:15:40.1461332-07:00",
  "lastActivity": "2018-05-18T10:16:06.0693248-07:00",
  "pageViews": [
    {
      "id": "0518403591c1f501c91575e3dbc1191b4e0f58cb",
      "startTime": "2018-05-18T10:15:40.1461332-07:00",
      "endTime": "2018-05-18T10:16:06.0693248-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 26026,
      "engagementTime": 24726,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 26026,
  "engagementTime": 24726,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=PQN6T",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "eb813ac581bf9b9ec9222b5f401944da",
  "gdpr": false
}