var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8a2ed6bdc3730fa36f2b1691cadb34d6",
  "created": "2018-06-04T12:17:49.3572317-07:00",
  "lastActivity": "2018-06-04T12:18:02.6200431-07:00",
  "pageViews": [
    {
      "id": "060449135b8d4a437faec2578046882a46c0fa2e",
      "startTime": "2018-06-04T12:17:49.55927-07:00",
      "endTime": "2018-06-04T12:18:02.6200431-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 13228,
      "engagementTime": 13176,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 13228,
  "engagementTime": 13176,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=1N65C",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "dd8b6d15aada2b494d3f554280100423",
  "gdpr": false
}