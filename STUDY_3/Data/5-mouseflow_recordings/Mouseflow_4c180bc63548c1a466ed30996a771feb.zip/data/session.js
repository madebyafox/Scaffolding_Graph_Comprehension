var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4c180bc63548c1a466ed30996a771feb",
  "created": "2018-06-04T12:14:05.4462874-07:00",
  "lastActivity": "2018-06-04T12:14:19.8780647-07:00",
  "pageViews": [
    {
      "id": "06040533a64037fb896c871d78b277fa0fce7214",
      "startTime": "2018-06-04T12:14:05.5943048-07:00",
      "endTime": "2018-06-04T12:14:19.8780647-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 14338,
      "engagementTime": 14338,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 14338,
  "engagementTime": 14338,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=6GNVQ",
    "CONDITION=311",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e9bd532c82c10d955a05e9bdb6ad145d",
  "gdpr": false
}