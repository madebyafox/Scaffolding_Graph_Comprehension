var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "44b4186931e7db1941fb659cf738bcd1",
  "created": "2018-06-04T12:14:05.6704359-07:00",
  "lastActivity": "2018-06-04T12:14:13.8434359-07:00",
  "pageViews": [
    {
      "id": "0604057178650b01d5161269835cc661df83e239",
      "startTime": "2018-06-04T12:14:05.6704359-07:00",
      "endTime": "2018-06-04T12:14:13.8434359-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 8173,
      "engagementTime": 8139,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 8173,
  "engagementTime": 8139,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ZEPVG",
    "CONDITION=311",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "533b16b7a5acc989a2529ec9f7e5ab98",
  "gdpr": false
}