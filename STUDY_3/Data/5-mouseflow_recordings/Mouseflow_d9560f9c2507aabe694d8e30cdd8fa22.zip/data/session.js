var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d9560f9c2507aabe694d8e30cdd8fa22",
  "created": "2018-05-24T12:23:54.0875582-07:00",
  "lastActivity": "2018-05-24T12:24:16.9265582-07:00",
  "pageViews": [
    {
      "id": "05245485051510c0669e63dbe4760ddf3fd6bc82",
      "startTime": "2018-05-24T12:23:54.0875582-07:00",
      "endTime": "2018-05-24T12:24:16.9265582-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 22839,
      "engagementTime": 22839,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 22839,
  "engagementTime": 22839,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=F98S2",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0822630c3c9ae554f3d2a9cd730fb55c",
  "gdpr": false
}