var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05215416fb4db966f7289739dc7935809c53f216"] = {
  "startTime": "2018-05-21T19:17:54.5569041Z",
  "websitePageUrl": "/16",
  "visitTime": 159149,
  "engagementTime": 97544,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "8596a14a4e3ba175c9720014bbeece75",
    "created": "2018-05-21T19:17:54.5569041+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=W7EBS",
      "CONDITION=111"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "b9f5c39da5c5929b3d388b8558c6e314",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/8596a14a4e3ba175c9720014bbeece75/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 238,
      "e": 238,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 410,
      "e": 410,
      "ty": 2,
      "x": 781,
      "y": 727
    },
    {
      "t": 500,
      "e": 500,
      "ty": 2,
      "x": 781,
      "y": 726
    },
    {
      "t": 500,
      "e": 500,
      "ty": 41,
      "x": 5791,
      "y": 41749,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 781,
      "y": 725
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 781,
      "y": 722
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 781,
      "y": 721
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 41,
      "x": 5791,
      "y": 41394,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 741,
      "y": 683
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 666,
      "y": 629
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 63051,
      "y": 65201,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 635,
      "y": 608
    },
    {
      "t": 1338,
      "e": 1338,
      "ty": 6,
      "x": 626,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 605,
      "y": 587
    },
    {
      "t": 1472,
      "e": 1472,
      "ty": 3,
      "x": 595,
      "y": 580,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1474,
      "e": 1474,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 595,
      "y": 580
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 41,
      "x": 55969,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1560,
      "e": 1560,
      "ty": 4,
      "x": 55969,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1560,
      "e": 1560,
      "ty": 5,
      "x": 595,
      "y": 580,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 604,
      "y": 578
    },
    {
      "t": 1739,
      "e": 1739,
      "ty": 7,
      "x": 703,
      "y": 578,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 1314,
      "y": 31240,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 2,
      "x": 783,
      "y": 578
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 810,
      "y": 578
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 2,
      "x": 811,
      "y": 578
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 3327,
      "y": 23451,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > g:[14] > text"
    },
    {
      "t": 2600,
      "e": 2600,
      "ty": 2,
      "x": 812,
      "y": 578
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 6604,
      "y": 23451,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > g:[14] > text"
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 813,
      "y": 578
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 9881,
      "y": 23451,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > g:[14] > text"
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 2,
      "x": 814,
      "y": 578
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 41,
      "x": 13158,
      "y": 23451,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > g:[14] > text"
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 815,
      "y": 578
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 22988,
      "y": 23451,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > g:[14] > text"
    },
    {
      "t": 3800,
      "e": 3800,
      "ty": 2,
      "x": 817,
      "y": 578
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 824,
      "y": 582
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 5990,
      "y": 33877,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5300,
      "e": 5300,
      "ty": 2,
      "x": 1025,
      "y": 720
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 1080,
      "y": 831
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 2,
      "x": 1088,
      "y": 873
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 21282,
      "y": 52642,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5600,
      "e": 5600,
      "ty": 2,
      "x": 1092,
      "y": 912
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 1098,
      "y": 928
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 3061,
      "y": 62476,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[7]"
    },
    {
      "t": 5800,
      "e": 5800,
      "ty": 2,
      "x": 1103,
      "y": 943
    },
    {
      "t": 5900,
      "e": 5900,
      "ty": 2,
      "x": 1114,
      "y": 952
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 2,
      "x": 1119,
      "y": 953
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 23466,
      "y": 58372,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6200,
      "e": 6200,
      "ty": 2,
      "x": 1123,
      "y": 951
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 24171,
      "y": 58014,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 1136,
      "y": 939
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 1214,
      "y": 834
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 1247,
      "y": 774
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 23186,
      "y": 42311,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[9]"
    },
    {
      "t": 6600,
      "e": 6600,
      "ty": 2,
      "x": 1249,
      "y": 768
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 32627,
      "y": 45122,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 1249,
      "y": 767
    },
    {
      "t": 7700,
      "e": 7700,
      "ty": 2,
      "x": 1249,
      "y": 764
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 32627,
      "y": 44692,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 2,
      "x": 1249,
      "y": 760
    },
    {
      "t": 7900,
      "e": 7900,
      "ty": 2,
      "x": 1249,
      "y": 758
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 2,
      "x": 1249,
      "y": 755
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 41,
      "x": 36423,
      "y": 36325,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[12]"
    },
    {
      "t": 8101,
      "e": 8101,
      "ty": 2,
      "x": 1249,
      "y": 751
    },
    {
      "t": 8201,
      "e": 8201,
      "ty": 2,
      "x": 1249,
      "y": 747
    },
    {
      "t": 8251,
      "e": 8251,
      "ty": 41,
      "x": 32627,
      "y": 43546,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8300,
      "e": 8300,
      "ty": 2,
      "x": 1249,
      "y": 746
    },
    {
      "t": 8401,
      "e": 8401,
      "ty": 2,
      "x": 1249,
      "y": 743
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 2,
      "x": 1250,
      "y": 742
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 41,
      "x": 32698,
      "y": 43260,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8700,
      "e": 8700,
      "ty": 2,
      "x": 1250,
      "y": 741
    },
    {
      "t": 8751,
      "e": 8751,
      "ty": 41,
      "x": 32698,
      "y": 43188,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8801,
      "e": 8801,
      "ty": 2,
      "x": 1251,
      "y": 739
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 2,
      "x": 1252,
      "y": 738
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 41,
      "x": 32839,
      "y": 42973,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9300,
      "e": 9300,
      "ty": 2,
      "x": 1253,
      "y": 738
    },
    {
      "t": 9501,
      "e": 9501,
      "ty": 41,
      "x": 32909,
      "y": 42973,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10601,
      "e": 10601,
      "ty": 2,
      "x": 1254,
      "y": 737
    },
    {
      "t": 10751,
      "e": 10751,
      "ty": 41,
      "x": 32980,
      "y": 42902,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 12401,
      "e": 12401,
      "ty": 2,
      "x": 1257,
      "y": 727
    },
    {
      "t": 12501,
      "e": 12501,
      "ty": 2,
      "x": 1258,
      "y": 724
    },
    {
      "t": 12501,
      "e": 12501,
      "ty": 41,
      "x": 33261,
      "y": 41971,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 12601,
      "e": 12601,
      "ty": 2,
      "x": 1258,
      "y": 722
    },
    {
      "t": 12701,
      "e": 12701,
      "ty": 2,
      "x": 1258,
      "y": 721
    },
    {
      "t": 12751,
      "e": 12751,
      "ty": 41,
      "x": 33261,
      "y": 41756,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 14200,
      "e": 14200,
      "ty": 2,
      "x": 1263,
      "y": 713
    },
    {
      "t": 14251,
      "e": 14251,
      "ty": 41,
      "x": 33755,
      "y": 40395,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 14300,
      "e": 14300,
      "ty": 2,
      "x": 1257,
      "y": 687
    },
    {
      "t": 14401,
      "e": 14401,
      "ty": 2,
      "x": 773,
      "y": 512
    },
    {
      "t": 14501,
      "e": 14501,
      "ty": 2,
      "x": 571,
      "y": 482
    },
    {
      "t": 14502,
      "e": 14502,
      "ty": 41,
      "x": 53271,
      "y": 2154,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 14582,
      "e": 14582,
      "ty": 6,
      "x": 499,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14601,
      "e": 14601,
      "ty": 2,
      "x": 464,
      "y": 554
    },
    {
      "t": 14701,
      "e": 14701,
      "ty": 2,
      "x": 414,
      "y": 594
    },
    {
      "t": 14751,
      "e": 14751,
      "ty": 41,
      "x": 35623,
      "y": 57659,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14785,
      "e": 14785,
      "ty": 3,
      "x": 414,
      "y": 594,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14870,
      "e": 14870,
      "ty": 4,
      "x": 35623,
      "y": 57659,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14870,
      "e": 14870,
      "ty": 5,
      "x": 414,
      "y": 594,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16196,
      "e": 16196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16292,
      "e": 16292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 16292,
      "e": 16292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16363,
      "e": 16363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 16387,
      "e": 16387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 16699,
      "e": 16699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16700,
      "e": 16700,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16770,
      "e": 16770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fi"
    },
    {
      "t": 16811,
      "e": 16811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 16811,
      "e": 16811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16898,
      "e": 16898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16899,
      "e": 16899,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16914,
      "e": 16914,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fid "
    },
    {
      "t": 16994,
      "e": 16994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17604,
      "e": 17604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17666,
      "e": 17666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fid"
    },
    {
      "t": 17762,
      "e": 17762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17939,
      "e": 17939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fi"
    },
    {
      "t": 18195,
      "e": 18195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18196,
      "e": 18196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18298,
      "e": 18298,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fin"
    },
    {
      "t": 18914,
      "e": 18914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 18914,
      "e": 18914,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18995,
      "e": 18995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18995,
      "e": 18995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19006,
      "e": 19006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find "
    },
    {
      "t": 19075,
      "e": 19075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19170,
      "e": 19170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19171,
      "e": 19171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19234,
      "e": 19234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19332,
      "e": 19332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 19332,
      "e": 19332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19386,
      "e": 19386,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 19418,
      "e": 19418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19418,
      "e": 19418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19458,
      "e": 19458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 19571,
      "e": 19571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19571,
      "e": 19571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19643,
      "e": 19643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19971,
      "e": 19971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 19972,
      "e": 19972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20082,
      "e": 20082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 20106,
      "e": 20106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 20106,
      "e": 20106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20258,
      "e": 20258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 20419,
      "e": 20419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20419,
      "e": 20419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20515,
      "e": 20515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 20620,
      "e": 20620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20620,
      "e": 20620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20690,
      "e": 20690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 20803,
      "e": 20803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the poin"
    },
    {
      "t": 20804,
      "e": 20804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20804,
      "e": 20804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20875,
      "e": 20875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 20907,
      "e": 20907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20908,
      "e": 20908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20978,
      "e": 20978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21428,
      "e": 21428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21428,
      "e": 21428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21522,
      "e": 21522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 21539,
      "e": 21539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 21539,
      "e": 21539,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21610,
      "e": 21610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 21651,
      "e": 21651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21651,
      "e": 21651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21722,
      "e": 21722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24982,
      "e": 24982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 24983,
      "e": 24983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25087,
      "e": 25087,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 25470,
      "e": 25470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 25472,
      "e": 25472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25541,
      "e": 25541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 25622,
      "e": 25622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25622,
      "e": 25622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25686,
      "e": 25686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25807,
      "e": 25807,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 "
    },
    {
      "t": 26375,
      "e": 26375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 26479,
      "e": 26479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 26479,
      "e": 26479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26542,
      "e": 26542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 26654,
      "e": 26654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 26655,
      "e": 26655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26742,
      "e": 26742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 26862,
      "e": 26862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26927,
      "e": 26927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26928,
      "e": 26928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26982,
      "e": 26982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27117,
      "e": 27117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27118,
      "e": 27118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27246,
      "e": 27246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 27326,
      "e": 27326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 27326,
      "e": 27326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27390,
      "e": 27390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 27814,
      "e": 27814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27877,
      "e": 27877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM a"
    },
    {
      "t": 28005,
      "e": 28005,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM a"
    },
    {
      "t": 28022,
      "e": 28022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28022,
      "e": 28022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28119,
      "e": 28119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28174,
      "e": 28174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28176,
      "e": 28176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28246,
      "e": 28246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29863,
      "e": 29863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 29864,
      "e": 29864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29942,
      "e": 29942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 29974,
      "e": 29974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29974,
      "e": 29974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30003,
      "e": 30003,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30062,
      "e": 30062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30479,
      "e": 30479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30479,
      "e": 30479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30558,
      "e": 30558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 30678,
      "e": 30678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 30679,
      "e": 30679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30766,
      "e": 30766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 30807,
      "e": 30807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30808,
      "e": 30808,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30870,
      "e": 30870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 30885,
      "e": 30885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 30885,
      "e": 30885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30950,
      "e": 30950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 30998,
      "e": 30998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30999,
      "e": 30999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31037,
      "e": 31037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31278,
      "e": 31278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31333,
      "e": 31333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis"
    },
    {
      "t": 31710,
      "e": 31710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31711,
      "e": 31711,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31765,
      "e": 31765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32101,
      "e": 32101,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32166,
      "e": 32166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis"
    },
    {
      "t": 32326,
      "e": 32326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 32326,
      "e": 32326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32407,
      "e": 32407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 32478,
      "e": 32478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32479,
      "e": 32479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32549,
      "e": 32549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32581,
      "e": 32581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32582,
      "e": 32582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32678,
      "e": 32678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32678,
      "e": 32678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32694,
      "e": 32694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 32727,
      "e": 32727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 32727,
      "e": 32727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32781,
      "e": 32781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 32822,
      "e": 32822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32870,
      "e": 32870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32870,
      "e": 32870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32917,
      "e": 32917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35752,
      "e": 35752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35752,
      "e": 35752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35854,
      "e": 35854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 35982,
      "e": 35982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 35983,
      "e": 35983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36061,
      "e": 36061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 36093,
      "e": 36093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36093,
      "e": 36093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36158,
      "e": 36158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 36198,
      "e": 36198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36198,
      "e": 36198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36253,
      "e": 36253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36414,
      "e": 36414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36417,
      "e": 36417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36502,
      "e": 36502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 36607,
      "e": 36607,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the l"
    },
    {
      "t": 36614,
      "e": 36614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36615,
      "e": 36615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36678,
      "e": 36678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 36758,
      "e": 36758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36758,
      "e": 36758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36830,
      "e": 36830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36831,
      "e": 36831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36838,
      "e": 36838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 36895,
      "e": 36895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36911,
      "e": 36911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36912,
      "e": 36912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36966,
      "e": 36966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37598,
      "e": 37598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37599,
      "e": 37599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37677,
      "e": 37677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 37766,
      "e": 37766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 37767,
      "e": 37767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37846,
      "e": 37846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37847,
      "e": 37847,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37854,
      "e": 37854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 37942,
      "e": 37942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37942,
      "e": 37942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37942,
      "e": 37942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38006,
      "e": 38006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38029,
      "e": 38029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38030,
      "e": 38030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38101,
      "e": 38101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38207,
      "e": 38207,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the line that "
    },
    {
      "t": 40004,
      "e": 40004,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 66423,
      "e": 43207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 66423,
      "e": 43207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66517,
      "e": 43301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 66533,
      "e": 43317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 66533,
      "e": 43317,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66590,
      "e": 43374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 66678,
      "e": 43462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 66678,
      "e": 43462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66757,
      "e": 43541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 66853,
      "e": 43637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 66853,
      "e": 43637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66942,
      "e": 43726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 67014,
      "e": 43798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 67015,
      "e": 43799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67101,
      "e": 43885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 67206,
      "e": 43990,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the line that begin"
    },
    {
      "t": 67214,
      "e": 43998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 67214,
      "e": 43998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67278,
      "e": 44062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 67350,
      "e": 44134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67353,
      "e": 44137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67404,
      "e": 44188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68030,
      "e": 44814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 68031,
      "e": 44815,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68102,
      "e": 44886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 68110,
      "e": 44894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68110,
      "e": 44894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68197,
      "e": 44981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 68229,
      "e": 45013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68229,
      "e": 45013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68366,
      "e": 45150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68750,
      "e": 45534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68751,
      "e": 45535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68830,
      "e": 45614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 68974,
      "e": 45758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 68974,
      "e": 45758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69054,
      "e": 45838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 69598,
      "e": 46382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 69599,
      "e": 46383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69693,
      "e": 46477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 69701,
      "e": 46485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 69702,
      "e": 46486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69774,
      "e": 46558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 69838,
      "e": 46622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69839,
      "e": 46623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69917,
      "e": 46701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 70230,
      "e": 47014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70269,
      "e": 47053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the line that begins at thus"
    },
    {
      "t": 70357,
      "e": 47141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70421,
      "e": 47205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the line that begins at thu"
    },
    {
      "t": 70453,
      "e": 47237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70549,
      "e": 47333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the line that begins at th"
    },
    {
      "t": 71038,
      "e": 47822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 71039,
      "e": 47823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71077,
      "e": 47861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 71206,
      "e": 47990,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the line that begins at tho"
    },
    {
      "t": 71325,
      "e": 48109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71397,
      "e": 48181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the line that begins at th"
    },
    {
      "t": 71518,
      "e": 48302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 71518,
      "e": 48302,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71590,
      "e": 48374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 71598,
      "e": 48382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 71599,
      "e": 48383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71669,
      "e": 48453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 71790,
      "e": 48574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71791,
      "e": 48575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71861,
      "e": 48645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 72038,
      "e": 48822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 72039,
      "e": 48823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72093,
      "e": 48877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 72207,
      "e": 48991,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the line that begins at this p"
    },
    {
      "t": 72297,
      "e": 48994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 72298,
      "e": 48995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72381,
      "e": 49078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 72541,
      "e": 49238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 72541,
      "e": 49238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72613,
      "e": 49310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 73007,
      "e": 49704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 73060,
      "e": 49757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the line that begins at this po"
    },
    {
      "t": 73207,
      "e": 49904,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the line that begins at this po"
    },
    {
      "t": 73582,
      "e": 50279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 73582,
      "e": 50279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73636,
      "e": 50333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 73741,
      "e": 50438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 73741,
      "e": 50438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73829,
      "e": 50526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 73981,
      "e": 50678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 73981,
      "e": 50678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74037,
      "e": 50734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 74101,
      "e": 50798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 74101,
      "e": 50798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74158,
      "e": 50855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 74350,
      "e": 51047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 74350,
      "e": 51047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74437,
      "e": 51134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 74437,
      "e": 51134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 74437,
      "e": 51134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74533,
      "e": 51230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 74549,
      "e": 51246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 74550,
      "e": 51247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74612,
      "e": 51309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 74613,
      "e": 51310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74629,
      "e": 51326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 74685,
      "e": 51382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 74806,
      "e": 51503,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the line that begins at this point and "
    },
    {
      "t": 80004,
      "e": 56503,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 106394,
      "e": 56503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 106394,
      "e": 56503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106536,
      "e": 56645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 106545,
      "e": 56654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 106545,
      "e": 56654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106673,
      "e": 56782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 106985,
      "e": 57094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 106986,
      "e": 57095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107040,
      "e": 57149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 107088,
      "e": 57197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 107089,
      "e": 57198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107209,
      "e": 57318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 107377,
      "e": 57486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 107377,
      "e": 57486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107448,
      "e": 57557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 107649,
      "e": 57758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 107649,
      "e": 57758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107761,
      "e": 57870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 108073,
      "e": 58182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 108128,
      "e": 58237,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the line that begins at this point and posit"
    },
    {
      "t": 108305,
      "e": 58414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 108306,
      "e": 58415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108409,
      "e": 58518,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the line that begins at this point and positi"
    },
    {
      "t": 108416,
      "e": 58525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 108424,
      "e": 58533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 108425,
      "e": 58534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108464,
      "e": 58573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 108465,
      "e": 58574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108488,
      "e": 58597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 108569,
      "e": 58678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 108585,
      "e": 58694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 108586,
      "e": 58695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108648,
      "e": 58757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 109881,
      "e": 59990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 109882,
      "e": 59991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109976,
      "e": 60085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 109984,
      "e": 60093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 109984,
      "e": 60093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110072,
      "e": 60181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 110177,
      "e": 60286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 110178,
      "e": 60287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110240,
      "e": 60349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 110344,
      "e": 60453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 110345,
      "e": 60454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110448,
      "e": 60557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 110538,
      "e": 60647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 110540,
      "e": 60649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110616,
      "e": 60725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 110688,
      "e": 60797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 110688,
      "e": 60797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110793,
      "e": 60902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 110809,
      "e": 60918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 110810,
      "e": 60919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110880,
      "e": 60989,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 111217,
      "e": 61326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 111218,
      "e": 61327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111296,
      "e": 61405,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 111352,
      "e": 61461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 111353,
      "e": 61462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111416,
      "e": 61525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 111456,
      "e": 61565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 111456,
      "e": 61565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111545,
      "e": 61654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 111769,
      "e": 61878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 111770,
      "e": 61879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111840,
      "e": 61949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 111952,
      "e": 62061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 111952,
      "e": 62061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111993,
      "e": 62102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 111993,
      "e": 62102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112016,
      "e": 62125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 112056,
      "e": 62165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 112136,
      "e": 62245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 112136,
      "e": 62245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112208,
      "e": 62317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 112553,
      "e": 62662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 113052,
      "e": 63161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 113084,
      "e": 63193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 113117,
      "e": 63226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 113150,
      "e": 63259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 113183,
      "e": 63292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 113216,
      "e": 63325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 113249,
      "e": 63358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 113282,
      "e": 63391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 113315,
      "e": 63424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 113348,
      "e": 63457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 113382,
      "e": 63491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 113414,
      "e": 63523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 113416,
      "e": 63525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the line that begins at this point and positive c"
    },
    {
      "t": 113560,
      "e": 63669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 113617,
      "e": 63670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the line that begins at this point and positive "
    },
    {
      "t": 120008,
      "e": 68670,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 130244,
      "e": 68670,
      "ty": 7,
      "x": 413,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130259,
      "e": 68685,
      "ty": 41,
      "x": 35511,
      "y": 61119,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 130307,
      "e": 68733,
      "ty": 2,
      "x": 411,
      "y": 631
    },
    {
      "t": 130408,
      "e": 68834,
      "ty": 2,
      "x": 410,
      "y": 637
    },
    {
      "t": 130450,
      "e": 68876,
      "ty": 6,
      "x": 406,
      "y": 656,
      "ta": "#strategyButton"
    },
    {
      "t": 130508,
      "e": 68934,
      "ty": 2,
      "x": 403,
      "y": 661
    },
    {
      "t": 130509,
      "e": 68935,
      "ty": 41,
      "x": 35173,
      "y": 12076,
      "ta": "#strategyButton"
    },
    {
      "t": 130607,
      "e": 69033,
      "ty": 2,
      "x": 388,
      "y": 680
    },
    {
      "t": 130662,
      "e": 69088,
      "ty": 3,
      "x": 388,
      "y": 680,
      "ta": "#strategyButton"
    },
    {
      "t": 130663,
      "e": 69089,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the point of 12 PM at x axis, and the line that begins at this point and positive "
    },
    {
      "t": 130664,
      "e": 69090,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130664,
      "e": 69090,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 130739,
      "e": 69165,
      "ty": 4,
      "x": 26981,
      "y": 48699,
      "ta": "#strategyButton"
    },
    {
      "t": 130751,
      "e": 69177,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 130752,
      "e": 69178,
      "ty": 5,
      "x": 388,
      "y": 680,
      "ta": "#strategyButton"
    },
    {
      "t": 130757,
      "e": 69183,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 130759,
      "e": 69185,
      "ty": 41,
      "x": 13086,
      "y": 37226,
      "ta": "html > body"
    },
    {
      "t": 131008,
      "e": 69434,
      "ty": 2,
      "x": 510,
      "y": 662
    },
    {
      "t": 131008,
      "e": 69434,
      "ty": 41,
      "x": 17287,
      "y": 36229,
      "ta": "html > body"
    },
    {
      "t": 131107,
      "e": 69533,
      "ty": 2,
      "x": 573,
      "y": 643
    },
    {
      "t": 131208,
      "e": 69634,
      "ty": 2,
      "x": 583,
      "y": 639
    },
    {
      "t": 131258,
      "e": 69684,
      "ty": 41,
      "x": 19801,
      "y": 34955,
      "ta": "html > body"
    },
    {
      "t": 131508,
      "e": 69934,
      "ty": 2,
      "x": 584,
      "y": 629
    },
    {
      "t": 131508,
      "e": 69934,
      "ty": 41,
      "x": 19836,
      "y": 34401,
      "ta": "html > body"
    },
    {
      "t": 131608,
      "e": 70034,
      "ty": 2,
      "x": 584,
      "y": 627
    },
    {
      "t": 131759,
      "e": 70185,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 131767,
      "e": 70193,
      "ty": 41,
      "x": 19836,
      "y": 34290,
      "ta": "html > body"
    },
    {
      "t": 132208,
      "e": 70634,
      "ty": 2,
      "x": 587,
      "y": 624
    },
    {
      "t": 132271,
      "e": 70697,
      "ty": 41,
      "x": 19973,
      "y": 34124,
      "ta": "html > body"
    },
    {
      "t": 132307,
      "e": 70733,
      "ty": 2,
      "x": 588,
      "y": 624
    },
    {
      "t": 132507,
      "e": 70933,
      "ty": 2,
      "x": 707,
      "y": 583
    },
    {
      "t": 132507,
      "e": 70933,
      "ty": 41,
      "x": 24071,
      "y": 31853,
      "ta": "html > body"
    },
    {
      "t": 132568,
      "e": 70994,
      "ty": 6,
      "x": 836,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 132608,
      "e": 71034,
      "ty": 2,
      "x": 899,
      "y": 559
    },
    {
      "t": 132707,
      "e": 71133,
      "ty": 2,
      "x": 924,
      "y": 558
    },
    {
      "t": 132758,
      "e": 71184,
      "ty": 41,
      "x": 25089,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 132813,
      "e": 71239,
      "ty": 3,
      "x": 924,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 132814,
      "e": 71240,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 132883,
      "e": 71309,
      "ty": 4,
      "x": 25089,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 132884,
      "e": 71310,
      "ty": 5,
      "x": 924,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 133640,
      "e": 72066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 133641,
      "e": 72067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 133728,
      "e": 72154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 133776,
      "e": 72202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "104"
    },
    {
      "t": 133776,
      "e": 72202,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 133848,
      "e": 72274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 134336,
      "e": 72762,
      "ty": 7,
      "x": 922,
      "y": 576,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 134408,
      "e": 72834,
      "ty": 2,
      "x": 913,
      "y": 645
    },
    {
      "t": 134419,
      "e": 72845,
      "ty": 6,
      "x": 913,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134508,
      "e": 72934,
      "ty": 2,
      "x": 913,
      "y": 651
    },
    {
      "t": 134508,
      "e": 72934,
      "ty": 41,
      "x": 22710,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134669,
      "e": 73095,
      "ty": 3,
      "x": 913,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134669,
      "e": 73095,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 134671,
      "e": 73097,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 134671,
      "e": 73097,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134708,
      "e": 73134,
      "ty": 2,
      "x": 913,
      "y": 653
    },
    {
      "t": 134758,
      "e": 73184,
      "ty": 41,
      "x": 22710,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134763,
      "e": 73189,
      "ty": 4,
      "x": 22710,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 134764,
      "e": 73190,
      "ty": 5,
      "x": 913,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 135107,
      "e": 73533,
      "ty": 7,
      "x": 904,
      "y": 642,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 135108,
      "e": 73534,
      "ty": 2,
      "x": 904,
      "y": 642
    },
    {
      "t": 135208,
      "e": 73634,
      "ty": 2,
      "x": 882,
      "y": 595
    },
    {
      "t": 135258,
      "e": 73684,
      "ty": 41,
      "x": 16005,
      "y": 8456,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 135308,
      "e": 73734,
      "ty": 2,
      "x": 882,
      "y": 587
    },
    {
      "t": 135337,
      "e": 73763,
      "ty": 6,
      "x": 886,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 135369,
      "e": 73795,
      "ty": 7,
      "x": 888,
      "y": 552,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 135407,
      "e": 73833,
      "ty": 2,
      "x": 888,
      "y": 552
    },
    {
      "t": 135460,
      "e": 73886,
      "ty": 3,
      "x": 888,
      "y": 552,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 135462,
      "e": 73888,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 135508,
      "e": 73934,
      "ty": 41,
      "x": 17302,
      "y": 43690,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 135540,
      "e": 73966,
      "ty": 4,
      "x": 17302,
      "y": 43690,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 135540,
      "e": 73966,
      "ty": 5,
      "x": 888,
      "y": 552,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 135670,
      "e": 74096,
      "ty": 6,
      "x": 885,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 135707,
      "e": 74133,
      "ty": 2,
      "x": 885,
      "y": 557
    },
    {
      "t": 135757,
      "e": 74183,
      "ty": 3,
      "x": 885,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 135758,
      "e": 74184,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 135760,
      "e": 74186,
      "ty": 41,
      "x": 16654,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 135868,
      "e": 74294,
      "ty": 4,
      "x": 16654,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 135868,
      "e": 74294,
      "ty": 5,
      "x": 885,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 136361,
      "e": 74787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 136431,
      "e": 74857,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 136672,
      "e": 75098,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "105"
    },
    {
      "t": 136673,
      "e": 75099,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 136736,
      "e": 75162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 137305,
      "e": 75731,
      "ty": 7,
      "x": 878,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 137308,
      "e": 75734,
      "ty": 2,
      "x": 878,
      "y": 588
    },
    {
      "t": 137339,
      "e": 75765,
      "ty": 6,
      "x": 839,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 137408,
      "e": 75834,
      "ty": 2,
      "x": 835,
      "y": 665
    },
    {
      "t": 137508,
      "e": 75934,
      "ty": 41,
      "x": 5839,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 137637,
      "e": 76063,
      "ty": 3,
      "x": 835,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 137638,
      "e": 76064,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 137638,
      "e": 76064,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 137639,
      "e": 76065,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 137707,
      "e": 76133,
      "ty": 4,
      "x": 5839,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 137707,
      "e": 76133,
      "ty": 5,
      "x": 835,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 138041,
      "e": 76467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 138289,
      "e": 76715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 138289,
      "e": 76715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 138343,
      "e": 76769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 138399,
      "e": 76825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 138400,
      "e": 76826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 138448,
      "e": 76874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ch"
    },
    {
      "t": 138488,
      "e": 76914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 138488,
      "e": 76914,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 138503,
      "e": 76929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chi"
    },
    {
      "t": 138610,
      "e": 77036,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chi"
    },
    {
      "t": 138617,
      "e": 77043,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chi"
    },
    {
      "t": 138617,
      "e": 77043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 138618,
      "e": 77044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 138727,
      "e": 77153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chin"
    },
    {
      "t": 138759,
      "e": 77185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 138760,
      "e": 77186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 138848,
      "e": 77274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 139306,
      "e": 77732,
      "ty": 7,
      "x": 841,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 139307,
      "e": 77733,
      "ty": 2,
      "x": 841,
      "y": 668
    },
    {
      "t": 139408,
      "e": 77834,
      "ty": 2,
      "x": 895,
      "y": 712
    },
    {
      "t": 139423,
      "e": 77835,
      "ty": 6,
      "x": 900,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 139508,
      "e": 77920,
      "ty": 2,
      "x": 908,
      "y": 699
    },
    {
      "t": 139508,
      "e": 77920,
      "ty": 41,
      "x": 6224,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 139608,
      "e": 78020,
      "ty": 2,
      "x": 915,
      "y": 699
    },
    {
      "t": 139708,
      "e": 78120,
      "ty": 2,
      "x": 919,
      "y": 698
    },
    {
      "t": 139758,
      "e": 78170,
      "ty": 41,
      "x": 11894,
      "y": 43690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 140173,
      "e": 78585,
      "ty": 3,
      "x": 919,
      "y": 698,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 140174,
      "e": 78586,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "China"
    },
    {
      "t": 140174,
      "e": 78586,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 140175,
      "e": 78587,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 140243,
      "e": 78655,
      "ty": 4,
      "x": 11894,
      "y": 43690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 140244,
      "e": 78656,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 140244,
      "e": 78656,
      "ty": 5,
      "x": 919,
      "y": 698,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 140244,
      "e": 78656,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 140508,
      "e": 78920,
      "ty": 2,
      "x": 961,
      "y": 711
    },
    {
      "t": 140508,
      "e": 78920,
      "ty": 41,
      "x": 32819,
      "y": 38944,
      "ta": "html > body"
    },
    {
      "t": 140607,
      "e": 79019,
      "ty": 2,
      "x": 969,
      "y": 715
    },
    {
      "t": 140758,
      "e": 79170,
      "ty": 41,
      "x": 33094,
      "y": 39165,
      "ta": "html > body"
    },
    {
      "t": 141259,
      "e": 79671,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 142112,
      "e": 80524,
      "ty": 2,
      "x": 958,
      "y": 680
    },
    {
      "t": 142212,
      "e": 80624,
      "ty": 2,
      "x": 913,
      "y": 493
    },
    {
      "t": 142262,
      "e": 80674,
      "ty": 41,
      "x": 14614,
      "y": 10832,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 142311,
      "e": 80723,
      "ty": 2,
      "x": 867,
      "y": 368
    },
    {
      "t": 142411,
      "e": 80823,
      "ty": 2,
      "x": 779,
      "y": 266
    },
    {
      "t": 142512,
      "e": 80924,
      "ty": 2,
      "x": 778,
      "y": 263
    },
    {
      "t": 142512,
      "e": 80924,
      "ty": 41,
      "x": 26517,
      "y": 14126,
      "ta": "html > body"
    },
    {
      "t": 142712,
      "e": 81124,
      "ty": 2,
      "x": 783,
      "y": 262
    },
    {
      "t": 142762,
      "e": 81174,
      "ty": 41,
      "x": 26930,
      "y": 14070,
      "ta": "html > body"
    },
    {
      "t": 142812,
      "e": 81224,
      "ty": 2,
      "x": 794,
      "y": 262
    },
    {
      "t": 142912,
      "e": 81324,
      "ty": 2,
      "x": 808,
      "y": 267
    },
    {
      "t": 143012,
      "e": 81424,
      "ty": 2,
      "x": 822,
      "y": 268
    },
    {
      "t": 143012,
      "e": 81424,
      "ty": 41,
      "x": 440,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 143111,
      "e": 81523,
      "ty": 2,
      "x": 823,
      "y": 264
    },
    {
      "t": 143211,
      "e": 81623,
      "ty": 2,
      "x": 824,
      "y": 260
    },
    {
      "t": 143262,
      "e": 81674,
      "ty": 41,
      "x": 2725,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 143264,
      "e": 81676,
      "ty": 6,
      "x": 826,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 143312,
      "e": 81724,
      "ty": 2,
      "x": 828,
      "y": 263
    },
    {
      "t": 143363,
      "e": 81775,
      "ty": 7,
      "x": 830,
      "y": 273,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 143412,
      "e": 81824,
      "ty": 2,
      "x": 832,
      "y": 278
    },
    {
      "t": 143511,
      "e": 81923,
      "ty": 2,
      "x": 832,
      "y": 285
    },
    {
      "t": 143512,
      "e": 81924,
      "ty": 41,
      "x": 3315,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 143612,
      "e": 82024,
      "ty": 2,
      "x": 832,
      "y": 287
    },
    {
      "t": 143761,
      "e": 82173,
      "ty": 3,
      "x": 832,
      "y": 287,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 143763,
      "e": 82175,
      "ty": 41,
      "x": 3315,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 143856,
      "e": 82268,
      "ty": 4,
      "x": 3315,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 143857,
      "e": 82269,
      "ty": 5,
      "x": 832,
      "y": 287,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 143857,
      "e": 82269,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 143859,
      "e": 82271,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 143860,
      "e": 82272,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 143911,
      "e": 82323,
      "ty": 6,
      "x": 832,
      "y": 288,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 143911,
      "e": 82323,
      "ty": 2,
      "x": 832,
      "y": 288
    },
    {
      "t": 143946,
      "e": 82358,
      "ty": 7,
      "x": 840,
      "y": 288,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 144012,
      "e": 82424,
      "ty": 2,
      "x": 855,
      "y": 289
    },
    {
      "t": 144012,
      "e": 82424,
      "ty": 41,
      "x": 10523,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 144112,
      "e": 82524,
      "ty": 2,
      "x": 856,
      "y": 292
    },
    {
      "t": 144212,
      "e": 82624,
      "ty": 2,
      "x": 862,
      "y": 297
    },
    {
      "t": 144262,
      "e": 82674,
      "ty": 41,
      "x": 22445,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 144312,
      "e": 82724,
      "ty": 2,
      "x": 966,
      "y": 331
    },
    {
      "t": 144412,
      "e": 82824,
      "ty": 2,
      "x": 969,
      "y": 335
    },
    {
      "t": 144511,
      "e": 82923,
      "ty": 2,
      "x": 969,
      "y": 353
    },
    {
      "t": 144512,
      "e": 82924,
      "ty": 41,
      "x": 35023,
      "y": 14347,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 144612,
      "e": 83024,
      "ty": 2,
      "x": 971,
      "y": 356
    },
    {
      "t": 144712,
      "e": 83124,
      "ty": 2,
      "x": 975,
      "y": 366
    },
    {
      "t": 144762,
      "e": 83174,
      "ty": 41,
      "x": 36922,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 144812,
      "e": 83224,
      "ty": 2,
      "x": 977,
      "y": 372
    },
    {
      "t": 145112,
      "e": 83524,
      "ty": 2,
      "x": 978,
      "y": 376
    },
    {
      "t": 145211,
      "e": 83623,
      "ty": 2,
      "x": 990,
      "y": 379
    },
    {
      "t": 145262,
      "e": 83674,
      "ty": 41,
      "x": 41194,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 145312,
      "e": 83724,
      "ty": 2,
      "x": 1000,
      "y": 380
    },
    {
      "t": 145411,
      "e": 83823,
      "ty": 2,
      "x": 1039,
      "y": 387
    },
    {
      "t": 145512,
      "e": 83924,
      "ty": 2,
      "x": 1040,
      "y": 387
    },
    {
      "t": 145512,
      "e": 83924,
      "ty": 41,
      "x": 51873,
      "y": 8665,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 145711,
      "e": 84123,
      "ty": 2,
      "x": 1043,
      "y": 387
    },
    {
      "t": 145762,
      "e": 84174,
      "ty": 41,
      "x": 53060,
      "y": 8665,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 145812,
      "e": 84224,
      "ty": 2,
      "x": 1046,
      "y": 388
    },
    {
      "t": 145911,
      "e": 84323,
      "ty": 2,
      "x": 1046,
      "y": 389
    },
    {
      "t": 146012,
      "e": 84424,
      "ty": 2,
      "x": 948,
      "y": 403
    },
    {
      "t": 146017,
      "e": 84429,
      "ty": 41,
      "x": 30040,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 146111,
      "e": 84523,
      "ty": 2,
      "x": 908,
      "y": 406
    },
    {
      "t": 146212,
      "e": 84624,
      "ty": 2,
      "x": 890,
      "y": 409
    },
    {
      "t": 146262,
      "e": 84674,
      "ty": 41,
      "x": 58035,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 146311,
      "e": 84723,
      "ty": 2,
      "x": 850,
      "y": 418
    },
    {
      "t": 146412,
      "e": 84824,
      "ty": 2,
      "x": 843,
      "y": 425
    },
    {
      "t": 146512,
      "e": 84924,
      "ty": 2,
      "x": 842,
      "y": 425
    },
    {
      "t": 146512,
      "e": 84924,
      "ty": 41,
      "x": 4883,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 147212,
      "e": 85624,
      "ty": 2,
      "x": 828,
      "y": 423
    },
    {
      "t": 147262,
      "e": 85674,
      "ty": 41,
      "x": 4188,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 147312,
      "e": 85724,
      "ty": 2,
      "x": 825,
      "y": 420
    },
    {
      "t": 147376,
      "e": 85788,
      "ty": 3,
      "x": 825,
      "y": 420,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 147377,
      "e": 85789,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 147463,
      "e": 85875,
      "ty": 4,
      "x": 4188,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 147463,
      "e": 85875,
      "ty": 5,
      "x": 825,
      "y": 420,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 147463,
      "e": 85875,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 147464,
      "e": 85876,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 147762,
      "e": 86174,
      "ty": 41,
      "x": 3017,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 147812,
      "e": 86224,
      "ty": 2,
      "x": 845,
      "y": 444
    },
    {
      "t": 147912,
      "e": 86324,
      "ty": 2,
      "x": 884,
      "y": 521
    },
    {
      "t": 148011,
      "e": 86423,
      "ty": 2,
      "x": 902,
      "y": 606
    },
    {
      "t": 148011,
      "e": 86423,
      "ty": 41,
      "x": 19123,
      "y": 33253,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 148112,
      "e": 86524,
      "ty": 2,
      "x": 943,
      "y": 600
    },
    {
      "t": 148212,
      "e": 86624,
      "ty": 2,
      "x": 944,
      "y": 600
    },
    {
      "t": 148262,
      "e": 86674,
      "ty": 41,
      "x": 29090,
      "y": 32804,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 148512,
      "e": 86924,
      "ty": 2,
      "x": 945,
      "y": 599
    },
    {
      "t": 148512,
      "e": 86924,
      "ty": 41,
      "x": 29328,
      "y": 32730,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 148611,
      "e": 87023,
      "ty": 2,
      "x": 918,
      "y": 619
    },
    {
      "t": 148711,
      "e": 87123,
      "ty": 2,
      "x": 890,
      "y": 654
    },
    {
      "t": 148762,
      "e": 87174,
      "ty": 41,
      "x": 14851,
      "y": 11103,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 148812,
      "e": 87224,
      "ty": 2,
      "x": 878,
      "y": 660
    },
    {
      "t": 148912,
      "e": 87324,
      "ty": 2,
      "x": 860,
      "y": 673
    },
    {
      "t": 149012,
      "e": 87424,
      "ty": 2,
      "x": 843,
      "y": 690
    },
    {
      "t": 149013,
      "e": 87425,
      "ty": 41,
      "x": 5121,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 149212,
      "e": 87624,
      "ty": 2,
      "x": 842,
      "y": 695
    },
    {
      "t": 149262,
      "e": 87674,
      "ty": 41,
      "x": 5185,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 149312,
      "e": 87724,
      "ty": 2,
      "x": 842,
      "y": 710
    },
    {
      "t": 149411,
      "e": 87823,
      "ty": 2,
      "x": 842,
      "y": 721
    },
    {
      "t": 149512,
      "e": 87924,
      "ty": 2,
      "x": 842,
      "y": 728
    },
    {
      "t": 149512,
      "e": 87924,
      "ty": 41,
      "x": 5164,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 149612,
      "e": 88024,
      "ty": 2,
      "x": 842,
      "y": 740
    },
    {
      "t": 149667,
      "e": 88079,
      "ty": 6,
      "x": 837,
      "y": 758,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 149701,
      "e": 88113,
      "ty": 7,
      "x": 834,
      "y": 770,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 149712,
      "e": 88124,
      "ty": 2,
      "x": 834,
      "y": 770
    },
    {
      "t": 149734,
      "e": 88146,
      "ty": 6,
      "x": 831,
      "y": 780,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 149762,
      "e": 88174,
      "ty": 41,
      "x": 18037,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 149812,
      "e": 88224,
      "ty": 2,
      "x": 830,
      "y": 785
    },
    {
      "t": 149912,
      "e": 88324,
      "ty": 2,
      "x": 830,
      "y": 781
    },
    {
      "t": 149919,
      "e": 88331,
      "ty": 7,
      "x": 830,
      "y": 772,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 149935,
      "e": 88347,
      "ty": 6,
      "x": 830,
      "y": 761,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 149952,
      "e": 88364,
      "ty": 7,
      "x": 830,
      "y": 742,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 149969,
      "e": 88364,
      "ty": 6,
      "x": 830,
      "y": 732,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 150002,
      "e": 88397,
      "ty": 7,
      "x": 830,
      "y": 723,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 150012,
      "e": 88407,
      "ty": 2,
      "x": 830,
      "y": 723
    },
    {
      "t": 150012,
      "e": 88407,
      "ty": 41,
      "x": 2152,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 150102,
      "e": 88497,
      "ty": 6,
      "x": 831,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 150112,
      "e": 88507,
      "ty": 2,
      "x": 831,
      "y": 708
    },
    {
      "t": 150212,
      "e": 88607,
      "ty": 2,
      "x": 831,
      "y": 706
    },
    {
      "t": 150262,
      "e": 88657,
      "ty": 41,
      "x": 23079,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 150412,
      "e": 88807,
      "ty": 2,
      "x": 834,
      "y": 706
    },
    {
      "t": 150431,
      "e": 88826,
      "ty": 3,
      "x": 834,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 150432,
      "e": 88827,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 150432,
      "e": 88827,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 150513,
      "e": 88908,
      "ty": 41,
      "x": 38202,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 150527,
      "e": 88922,
      "ty": 4,
      "x": 38202,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 150528,
      "e": 88923,
      "ty": 5,
      "x": 834,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 150529,
      "e": 88924,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 150703,
      "e": 89098,
      "ty": 7,
      "x": 841,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 150712,
      "e": 89107,
      "ty": 2,
      "x": 841,
      "y": 706
    },
    {
      "t": 150762,
      "e": 89157,
      "ty": 41,
      "x": 9469,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 150812,
      "e": 89207,
      "ty": 2,
      "x": 860,
      "y": 708
    },
    {
      "t": 150912,
      "e": 89307,
      "ty": 2,
      "x": 862,
      "y": 746
    },
    {
      "t": 151012,
      "e": 89407,
      "ty": 2,
      "x": 863,
      "y": 756
    },
    {
      "t": 151012,
      "e": 89407,
      "ty": 41,
      "x": 17348,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 151112,
      "e": 89507,
      "ty": 2,
      "x": 863,
      "y": 780
    },
    {
      "t": 151212,
      "e": 89607,
      "ty": 2,
      "x": 865,
      "y": 794
    },
    {
      "t": 151262,
      "e": 89657,
      "ty": 41,
      "x": 10579,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 151312,
      "e": 89707,
      "ty": 2,
      "x": 866,
      "y": 802
    },
    {
      "t": 151412,
      "e": 89807,
      "ty": 2,
      "x": 867,
      "y": 838
    },
    {
      "t": 151512,
      "e": 89907,
      "ty": 2,
      "x": 868,
      "y": 844
    },
    {
      "t": 151512,
      "e": 89907,
      "ty": 41,
      "x": 32817,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 151612,
      "e": 90007,
      "ty": 2,
      "x": 869,
      "y": 851
    },
    {
      "t": 151712,
      "e": 90107,
      "ty": 2,
      "x": 870,
      "y": 872
    },
    {
      "t": 151762,
      "e": 90157,
      "ty": 41,
      "x": 11528,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 151812,
      "e": 90207,
      "ty": 2,
      "x": 870,
      "y": 881
    },
    {
      "t": 151912,
      "e": 90307,
      "ty": 2,
      "x": 869,
      "y": 899
    },
    {
      "t": 152012,
      "e": 90407,
      "ty": 2,
      "x": 862,
      "y": 912
    },
    {
      "t": 152012,
      "e": 90407,
      "ty": 41,
      "x": 9630,
      "y": 18652,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 152112,
      "e": 90507,
      "ty": 2,
      "x": 843,
      "y": 938
    },
    {
      "t": 152212,
      "e": 90607,
      "ty": 2,
      "x": 838,
      "y": 947
    },
    {
      "t": 152262,
      "e": 90657,
      "ty": 41,
      "x": 3934,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 152511,
      "e": 90906,
      "ty": 2,
      "x": 834,
      "y": 946
    },
    {
      "t": 152511,
      "e": 90906,
      "ty": 41,
      "x": 2985,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 152612,
      "e": 91007,
      "ty": 2,
      "x": 831,
      "y": 942
    },
    {
      "t": 152762,
      "e": 91157,
      "ty": 41,
      "x": 10461,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 152812,
      "e": 91207,
      "ty": 2,
      "x": 831,
      "y": 943
    },
    {
      "t": 152912,
      "e": 91307,
      "ty": 2,
      "x": 831,
      "y": 952
    },
    {
      "t": 152970,
      "e": 91365,
      "ty": 6,
      "x": 831,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 153012,
      "e": 91407,
      "ty": 2,
      "x": 831,
      "y": 958
    },
    {
      "t": 153012,
      "e": 91407,
      "ty": 41,
      "x": 23079,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 153071,
      "e": 91466,
      "ty": 3,
      "x": 831,
      "y": 958,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 153071,
      "e": 91466,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 153073,
      "e": 91468,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 153150,
      "e": 91545,
      "ty": 4,
      "x": 23079,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 153150,
      "e": 91545,
      "ty": 5,
      "x": 831,
      "y": 958,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 153151,
      "e": 91546,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 153262,
      "e": 91657,
      "ty": 41,
      "x": 48284,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 153271,
      "e": 91666,
      "ty": 7,
      "x": 838,
      "y": 971,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 153312,
      "e": 91707,
      "ty": 2,
      "x": 854,
      "y": 995
    },
    {
      "t": 153321,
      "e": 91716,
      "ty": 6,
      "x": 867,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 153412,
      "e": 91807,
      "ty": 2,
      "x": 885,
      "y": 1022
    },
    {
      "t": 153512,
      "e": 91907,
      "ty": 41,
      "x": 28644,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 153528,
      "e": 91923,
      "ty": 3,
      "x": 885,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 153529,
      "e": 91924,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 153530,
      "e": 91925,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 153623,
      "e": 92018,
      "ty": 4,
      "x": 28644,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 153623,
      "e": 92018,
      "ty": 5,
      "x": 885,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 153625,
      "e": 92020,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 153627,
      "e": 92022,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 153627,
      "e": 92022,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 153712,
      "e": 92107,
      "ty": 2,
      "x": 885,
      "y": 1012
    },
    {
      "t": 153762,
      "e": 92157,
      "ty": 41,
      "x": 30167,
      "y": 55452,
      "ta": "html > body"
    },
    {
      "t": 153812,
      "e": 92207,
      "ty": 2,
      "x": 884,
      "y": 1009
    },
    {
      "t": 154979,
      "e": 93374,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 155112,
      "e": 93507,
      "ty": 2,
      "x": 876,
      "y": 1000
    },
    {
      "t": 155262,
      "e": 93657,
      "ty": 41,
      "x": 28659,
      "y": 60501,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 156212,
      "e": 94607,
      "ty": 2,
      "x": 923,
      "y": 1053
    },
    {
      "t": 156262,
      "e": 94657,
      "ty": 41,
      "x": 31808,
      "y": 65418,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 156279,
      "e": 94674,
      "ty": 6,
      "x": 941,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 156312,
      "e": 94707,
      "ty": 2,
      "x": 946,
      "y": 1078
    },
    {
      "t": 156411,
      "e": 94806,
      "ty": 2,
      "x": 962,
      "y": 1086
    },
    {
      "t": 156512,
      "e": 94907,
      "ty": 41,
      "x": 28671,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 156720,
      "e": 95115,
      "ty": 3,
      "x": 962,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 156722,
      "e": 95117,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 156815,
      "e": 95210,
      "ty": 4,
      "x": 28671,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 156815,
      "e": 95210,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 156815,
      "e": 95210,
      "ty": 5,
      "x": 962,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 156816,
      "e": 95211,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 156911,
      "e": 95306,
      "ty": 2,
      "x": 1000,
      "y": 1074
    },
    {
      "t": 157011,
      "e": 95406,
      "ty": 2,
      "x": 1104,
      "y": 1049
    },
    {
      "t": 157012,
      "e": 95407,
      "ty": 41,
      "x": 37743,
      "y": 57668,
      "ta": "html > body"
    },
    {
      "t": 157111,
      "e": 95506,
      "ty": 2,
      "x": 1155,
      "y": 1036
    },
    {
      "t": 157211,
      "e": 95606,
      "ty": 2,
      "x": 1156,
      "y": 1036
    },
    {
      "t": 157261,
      "e": 95656,
      "ty": 41,
      "x": 39500,
      "y": 56782,
      "ta": "html > body"
    },
    {
      "t": 157311,
      "e": 95706,
      "ty": 2,
      "x": 1153,
      "y": 1033
    },
    {
      "t": 157512,
      "e": 95907,
      "ty": 41,
      "x": 39431,
      "y": 56782,
      "ta": "html > body"
    },
    {
      "t": 157761,
      "e": 96156,
      "ty": 41,
      "x": 39431,
      "y": 56726,
      "ta": "html > body"
    },
    {
      "t": 157811,
      "e": 96206,
      "ty": 2,
      "x": 1153,
      "y": 1032
    },
    {
      "t": 157850,
      "e": 96245,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 159149,
      "e": 97544,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 156672, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 156679, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 4831, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 162849, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 13614, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"CHARLIE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"111\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 177471, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 16313, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 194876, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 11766, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 207645, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 30410, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 239424, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-A -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1038,y:1002,t:1526929850724};\\\", \\\"{x:1063,y:992,t:1526929850738};\\\", \\\"{x:1123,y:968,t:1526929850754};\\\", \\\"{x:1189,y:950,t:1526929850770};\\\", \\\"{x:1304,y:927,t:1526929850787};\\\", \\\"{x:1366,y:916,t:1526929850804};\\\", \\\"{x:1402,y:911,t:1526929850820};\\\", \\\"{x:1420,y:906,t:1526929850837};\\\", \\\"{x:1430,y:902,t:1526929850854};\\\", \\\"{x:1433,y:900,t:1526929850870};\\\", \\\"{x:1434,y:900,t:1526929850887};\\\", \\\"{x:1435,y:899,t:1526929850906};\\\", \\\"{x:1437,y:898,t:1526929850920};\\\", \\\"{x:1440,y:898,t:1526929850937};\\\", \\\"{x:1448,y:898,t:1526929850954};\\\", \\\"{x:1450,y:898,t:1526929850970};\\\", \\\"{x:1452,y:898,t:1526929850986};\\\", \\\"{x:1453,y:898,t:1526929851034};\\\", \\\"{x:1453,y:899,t:1526929851058};\\\", \\\"{x:1453,y:900,t:1526929851070};\\\", \\\"{x:1453,y:902,t:1526929851087};\\\", \\\"{x:1452,y:903,t:1526929851104};\\\", \\\"{x:1452,y:904,t:1526929851120};\\\", \\\"{x:1450,y:907,t:1526929851138};\\\", \\\"{x:1450,y:908,t:1526929851154};\\\", \\\"{x:1446,y:915,t:1526929851171};\\\", \\\"{x:1436,y:922,t:1526929851187};\\\", \\\"{x:1429,y:927,t:1526929851205};\\\", \\\"{x:1425,y:931,t:1526929851220};\\\", \\\"{x:1418,y:936,t:1526929851237};\\\", \\\"{x:1413,y:940,t:1526929851254};\\\", \\\"{x:1406,y:944,t:1526929851271};\\\", \\\"{x:1399,y:946,t:1526929851287};\\\", \\\"{x:1396,y:947,t:1526929851304};\\\", \\\"{x:1392,y:947,t:1526929851322};\\\", \\\"{x:1387,y:948,t:1526929851337};\\\", \\\"{x:1380,y:948,t:1526929851355};\\\", \\\"{x:1367,y:951,t:1526929851370};\\\", \\\"{x:1356,y:955,t:1526929851387};\\\", \\\"{x:1346,y:957,t:1526929851404};\\\", \\\"{x:1332,y:961,t:1526929851421};\\\", \\\"{x:1321,y:963,t:1526929851438};\\\", \\\"{x:1318,y:964,t:1526929851454};\\\", \\\"{x:1318,y:965,t:1526929851472};\\\", \\\"{x:1317,y:965,t:1526929851515};\\\", \\\"{x:1315,y:965,t:1526929851524};\\\", \\\"{x:1313,y:965,t:1526929851540};\\\", \\\"{x:1311,y:965,t:1526929851555};\\\", \\\"{x:1306,y:965,t:1526929851572};\\\", \\\"{x:1304,y:965,t:1526929851587};\\\", \\\"{x:1301,y:965,t:1526929851605};\\\", \\\"{x:1298,y:965,t:1526929851622};\\\", \\\"{x:1294,y:965,t:1526929851638};\\\", \\\"{x:1291,y:965,t:1526929851655};\\\", \\\"{x:1291,y:966,t:1526929851672};\\\", \\\"{x:1290,y:967,t:1526929851691};\\\", \\\"{x:1289,y:967,t:1526929851931};\\\", \\\"{x:1288,y:967,t:1526929851948};\\\", \\\"{x:1287,y:967,t:1526929851955};\\\", \\\"{x:1286,y:967,t:1526929851972};\\\", \\\"{x:1285,y:966,t:1526929851988};\\\", \\\"{x:1284,y:966,t:1526929852187};\\\", \\\"{x:1284,y:965,t:1526929852211};\\\", \\\"{x:1284,y:964,t:1526929852284};\\\", \\\"{x:1284,y:963,t:1526929852307};\\\", \\\"{x:1284,y:962,t:1526929852347};\\\", \\\"{x:1284,y:960,t:1526929852755};\\\", \\\"{x:1284,y:958,t:1526929852772};\\\", \\\"{x:1284,y:956,t:1526929852789};\\\", \\\"{x:1284,y:955,t:1526929852805};\\\", \\\"{x:1284,y:953,t:1526929852826};\\\", \\\"{x:1284,y:952,t:1526929852850};\\\", \\\"{x:1284,y:950,t:1526929852858};\\\", \\\"{x:1285,y:949,t:1526929852872};\\\", \\\"{x:1286,y:945,t:1526929852888};\\\", \\\"{x:1286,y:941,t:1526929852905};\\\", \\\"{x:1286,y:933,t:1526929852922};\\\", \\\"{x:1286,y:931,t:1526929852938};\\\", \\\"{x:1286,y:928,t:1526929852955};\\\", \\\"{x:1287,y:927,t:1526929852972};\\\", \\\"{x:1287,y:928,t:1526929853284};\\\", \\\"{x:1287,y:931,t:1526929853292};\\\", \\\"{x:1287,y:934,t:1526929853305};\\\", \\\"{x:1289,y:944,t:1526929853323};\\\", \\\"{x:1289,y:948,t:1526929853339};\\\", \\\"{x:1289,y:951,t:1526929853355};\\\", \\\"{x:1288,y:954,t:1526929853372};\\\", \\\"{x:1288,y:955,t:1526929853390};\\\", \\\"{x:1288,y:956,t:1526929853405};\\\", \\\"{x:1288,y:957,t:1526929853435};\\\", \\\"{x:1288,y:958,t:1526929853443};\\\", \\\"{x:1288,y:960,t:1526929853456};\\\", \\\"{x:1288,y:961,t:1526929853473};\\\", \\\"{x:1288,y:962,t:1526929853489};\\\", \\\"{x:1288,y:963,t:1526929853506};\\\", \\\"{x:1288,y:965,t:1526929853523};\\\", \\\"{x:1288,y:966,t:1526929853540};\\\", \\\"{x:1288,y:967,t:1526929853556};\\\", \\\"{x:1288,y:969,t:1526929853573};\\\", \\\"{x:1287,y:970,t:1526929853590};\\\", \\\"{x:1286,y:970,t:1526929853619};\\\", \\\"{x:1285,y:971,t:1526929853643};\\\", \\\"{x:1285,y:972,t:1526929853657};\\\", \\\"{x:1284,y:972,t:1526929853672};\\\", \\\"{x:1283,y:972,t:1526929853691};\\\", \\\"{x:1282,y:972,t:1526929853707};\\\", \\\"{x:1281,y:973,t:1526929853722};\\\", \\\"{x:1280,y:973,t:1526929853740};\\\", \\\"{x:1278,y:973,t:1526929853756};\\\", \\\"{x:1277,y:973,t:1526929853811};\\\", \\\"{x:1276,y:973,t:1526929853876};\\\", \\\"{x:1276,y:972,t:1526929854331};\\\", \\\"{x:1276,y:971,t:1526929854486};\\\", \\\"{x:1276,y:970,t:1526929854498};\\\", \\\"{x:1276,y:969,t:1526929854531};\\\", \\\"{x:1276,y:968,t:1526929854540};\\\", \\\"{x:1276,y:967,t:1526929854556};\\\", \\\"{x:1276,y:966,t:1526929854573};\\\", \\\"{x:1276,y:965,t:1526929854590};\\\", \\\"{x:1276,y:964,t:1526929854610};\\\", \\\"{x:1276,y:963,t:1526929854666};\\\", \\\"{x:1276,y:962,t:1526929854683};\\\", \\\"{x:1276,y:961,t:1526929854698};\\\", \\\"{x:1276,y:960,t:1526929854706};\\\", \\\"{x:1276,y:958,t:1526929854723};\\\", \\\"{x:1276,y:954,t:1526929854740};\\\", \\\"{x:1276,y:949,t:1526929854756};\\\", \\\"{x:1276,y:940,t:1526929854774};\\\", \\\"{x:1279,y:926,t:1526929854791};\\\", \\\"{x:1280,y:912,t:1526929854807};\\\", \\\"{x:1280,y:897,t:1526929854824};\\\", \\\"{x:1280,y:887,t:1526929854841};\\\", \\\"{x:1280,y:878,t:1526929854857};\\\", \\\"{x:1280,y:870,t:1526929854874};\\\", \\\"{x:1280,y:863,t:1526929854891};\\\", \\\"{x:1280,y:859,t:1526929854907};\\\", \\\"{x:1280,y:854,t:1526929854923};\\\", \\\"{x:1280,y:852,t:1526929854940};\\\", \\\"{x:1280,y:850,t:1526929854957};\\\", \\\"{x:1280,y:848,t:1526929854973};\\\", \\\"{x:1280,y:846,t:1526929854991};\\\", \\\"{x:1280,y:845,t:1526929855007};\\\", \\\"{x:1280,y:843,t:1526929855024};\\\", \\\"{x:1280,y:842,t:1526929855041};\\\", \\\"{x:1280,y:841,t:1526929855057};\\\", \\\"{x:1280,y:840,t:1526929855073};\\\", \\\"{x:1280,y:839,t:1526929855091};\\\", \\\"{x:1280,y:838,t:1526929855146};\\\", \\\"{x:1280,y:837,t:1526929855157};\\\", \\\"{x:1280,y:836,t:1526929855173};\\\", \\\"{x:1280,y:833,t:1526929855191};\\\", \\\"{x:1280,y:831,t:1526929855223};\\\", \\\"{x:1280,y:830,t:1526929855282};\\\", \\\"{x:1262,y:830,t:1526929874860};\\\", \\\"{x:1220,y:830,t:1526929874873};\\\", \\\"{x:1129,y:821,t:1526929874890};\\\", \\\"{x:1005,y:805,t:1526929874905};\\\", \\\"{x:866,y:783,t:1526929874922};\\\", \\\"{x:664,y:745,t:1526929874939};\\\", \\\"{x:538,y:713,t:1526929874957};\\\", \\\"{x:413,y:673,t:1526929874972};\\\", \\\"{x:298,y:636,t:1526929874988};\\\", \\\"{x:196,y:608,t:1526929875007};\\\", \\\"{x:88,y:577,t:1526929875023};\\\", \\\"{x:0,y:547,t:1526929875040};\\\", \\\"{x:0,y:522,t:1526929875057};\\\", \\\"{x:0,y:508,t:1526929875073};\\\", \\\"{x:0,y:507,t:1526929875089};\\\", \\\"{x:2,y:503,t:1526929875106};\\\", \\\"{x:28,y:496,t:1526929875124};\\\", \\\"{x:59,y:488,t:1526929875140};\\\", \\\"{x:87,y:485,t:1526929875156};\\\", \\\"{x:107,y:482,t:1526929875174};\\\", \\\"{x:123,y:480,t:1526929875189};\\\", \\\"{x:142,y:480,t:1526929875207};\\\", \\\"{x:161,y:480,t:1526929875224};\\\", \\\"{x:181,y:480,t:1526929875241};\\\", \\\"{x:203,y:480,t:1526929875256};\\\", \\\"{x:238,y:475,t:1526929875274};\\\", \\\"{x:258,y:474,t:1526929875291};\\\", \\\"{x:277,y:474,t:1526929875307};\\\", \\\"{x:292,y:474,t:1526929875325};\\\", \\\"{x:303,y:474,t:1526929875341};\\\", \\\"{x:311,y:474,t:1526929875357};\\\", \\\"{x:315,y:476,t:1526929875375};\\\", \\\"{x:319,y:477,t:1526929875391};\\\", \\\"{x:323,y:479,t:1526929875407};\\\", \\\"{x:326,y:481,t:1526929875425};\\\", \\\"{x:327,y:482,t:1526929875441};\\\", \\\"{x:327,y:484,t:1526929875458};\\\", \\\"{x:330,y:490,t:1526929875475};\\\", \\\"{x:331,y:498,t:1526929875491};\\\", \\\"{x:333,y:503,t:1526929875508};\\\", \\\"{x:334,y:505,t:1526929875524};\\\", \\\"{x:337,y:506,t:1526929875545};\\\", \\\"{x:341,y:507,t:1526929875558};\\\", \\\"{x:347,y:507,t:1526929875574};\\\", \\\"{x:353,y:507,t:1526929875590};\\\", \\\"{x:361,y:510,t:1526929875606};\\\", \\\"{x:367,y:510,t:1526929875624};\\\", \\\"{x:373,y:510,t:1526929875640};\\\", \\\"{x:379,y:511,t:1526929875657};\\\", \\\"{x:384,y:512,t:1526929875674};\\\", \\\"{x:386,y:512,t:1526929875698};\\\", \\\"{x:386,y:513,t:1526929875722};\\\", \\\"{x:386,y:514,t:1526929875754};\\\", \\\"{x:386,y:515,t:1526929875787};\\\", \\\"{x:386,y:516,t:1526929875795};\\\", \\\"{x:385,y:518,t:1526929875818};\\\", \\\"{x:385,y:519,t:1526929875993};\\\", \\\"{x:388,y:521,t:1526929876008};\\\", \\\"{x:399,y:527,t:1526929876024};\\\", \\\"{x:422,y:539,t:1526929876041};\\\", \\\"{x:482,y:577,t:1526929876057};\\\", \\\"{x:522,y:605,t:1526929876074};\\\", \\\"{x:543,y:621,t:1526929876091};\\\", \\\"{x:555,y:637,t:1526929876108};\\\", \\\"{x:563,y:652,t:1526929876124};\\\", \\\"{x:565,y:663,t:1526929876141};\\\", \\\"{x:566,y:668,t:1526929876158};\\\", \\\"{x:566,y:670,t:1526929876174};\\\", \\\"{x:566,y:673,t:1526929876191};\\\", \\\"{x:566,y:676,t:1526929876208};\\\", \\\"{x:566,y:679,t:1526929876225};\\\", \\\"{x:562,y:684,t:1526929876241};\\\", \\\"{x:551,y:696,t:1526929876258};\\\", \\\"{x:538,y:706,t:1526929876276};\\\", \\\"{x:527,y:714,t:1526929876290};\\\", \\\"{x:521,y:718,t:1526929876307};\\\", \\\"{x:516,y:722,t:1526929876325};\\\", \\\"{x:515,y:723,t:1526929876345};\\\", \\\"{x:514,y:723,t:1526929876613};\\\", \\\"{x:516,y:722,t:1526929876918};\\\", \\\"{x:517,y:722,t:1526929877222};\\\", \\\"{x:517,y:721,t:1526929877229};\\\", \\\"{x:517,y:720,t:1526929877246};\\\", \\\"{x:518,y:719,t:1526929877262};\\\", \\\"{x:518,y:718,t:1526929877382};\\\", \\\"{x:518,y:716,t:1526929877398};\\\", \\\"{x:518,y:715,t:1526929877413};\\\", \\\"{x:519,y:715,t:1526929877429};\\\", \\\"{x:519,y:714,t:1526929877445};\\\", \\\"{x:520,y:713,t:1526929877486};\\\" ] }, { \\\"rt\\\": 46563, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 287232, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -7-D -11 AM-K -K -D -D -D -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:709,t:1526929878582};\\\", \\\"{x:518,y:705,t:1526929878594};\\\", \\\"{x:518,y:707,t:1526929879534};\\\", \\\"{x:521,y:708,t:1526929879542};\\\", \\\"{x:560,y:714,t:1526929879557};\\\", \\\"{x:644,y:725,t:1526929879576};\\\", \\\"{x:739,y:729,t:1526929879591};\\\", \\\"{x:852,y:743,t:1526929879608};\\\", \\\"{x:1016,y:747,t:1526929879630};\\\", \\\"{x:1115,y:753,t:1526929879647};\\\", \\\"{x:1222,y:764,t:1526929879664};\\\", \\\"{x:1327,y:776,t:1526929879681};\\\", \\\"{x:1430,y:792,t:1526929879698};\\\", \\\"{x:1526,y:802,t:1526929879713};\\\", \\\"{x:1628,y:807,t:1526929879730};\\\", \\\"{x:1725,y:811,t:1526929879748};\\\", \\\"{x:1818,y:817,t:1526929879763};\\\", \\\"{x:1893,y:817,t:1526929879780};\\\", \\\"{x:1919,y:817,t:1526929879790};\\\", \\\"{x:1916,y:631,t:1526929880046};\\\", \\\"{x:1909,y:611,t:1526929880064};\\\", \\\"{x:1901,y:599,t:1526929880081};\\\", \\\"{x:1896,y:591,t:1526929880098};\\\", \\\"{x:1891,y:577,t:1526929880115};\\\", \\\"{x:1885,y:564,t:1526929880131};\\\", \\\"{x:1880,y:552,t:1526929880147};\\\", \\\"{x:1871,y:539,t:1526929880165};\\\", \\\"{x:1858,y:528,t:1526929880181};\\\", \\\"{x:1817,y:505,t:1526929880197};\\\", \\\"{x:1790,y:495,t:1526929880215};\\\", \\\"{x:1767,y:489,t:1526929880232};\\\", \\\"{x:1752,y:484,t:1526929880248};\\\", \\\"{x:1736,y:482,t:1526929880265};\\\", \\\"{x:1718,y:478,t:1526929880281};\\\", \\\"{x:1709,y:478,t:1526929880298};\\\", \\\"{x:1705,y:477,t:1526929880315};\\\", \\\"{x:1704,y:477,t:1526929880331};\\\", \\\"{x:1702,y:476,t:1526929880358};\\\", \\\"{x:1700,y:475,t:1526929880365};\\\", \\\"{x:1690,y:470,t:1526929880382};\\\", \\\"{x:1678,y:466,t:1526929880398};\\\", \\\"{x:1672,y:465,t:1526929880415};\\\", \\\"{x:1668,y:465,t:1526929880431};\\\", \\\"{x:1664,y:465,t:1526929880448};\\\", \\\"{x:1656,y:465,t:1526929880465};\\\", \\\"{x:1649,y:465,t:1526929880482};\\\", \\\"{x:1640,y:464,t:1526929880498};\\\", \\\"{x:1633,y:461,t:1526929880515};\\\", \\\"{x:1622,y:457,t:1526929880532};\\\", \\\"{x:1614,y:453,t:1526929880548};\\\", \\\"{x:1612,y:449,t:1526929880565};\\\", \\\"{x:1612,y:441,t:1526929880582};\\\", \\\"{x:1612,y:437,t:1526929880598};\\\", \\\"{x:1615,y:433,t:1526929880617};\\\", \\\"{x:1616,y:433,t:1526929880631};\\\", \\\"{x:1616,y:432,t:1526929880648};\\\", \\\"{x:1616,y:431,t:1526929880798};\\\", \\\"{x:1616,y:430,t:1526929880894};\\\", \\\"{x:1615,y:431,t:1526929885319};\\\", \\\"{x:1615,y:432,t:1526929886174};\\\", \\\"{x:1615,y:433,t:1526929886186};\\\", \\\"{x:1615,y:434,t:1526929886203};\\\", \\\"{x:1615,y:435,t:1526929886219};\\\", \\\"{x:1615,y:437,t:1526929886238};\\\", \\\"{x:1616,y:438,t:1526929886253};\\\", \\\"{x:1616,y:439,t:1526929886326};\\\", \\\"{x:1616,y:440,t:1526929886774};\\\", \\\"{x:1617,y:441,t:1526929886790};\\\", \\\"{x:1617,y:442,t:1526929886813};\\\", \\\"{x:1617,y:443,t:1526929886822};\\\", \\\"{x:1618,y:443,t:1526929886935};\\\", \\\"{x:1618,y:444,t:1526929886974};\\\", \\\"{x:1619,y:445,t:1526929886988};\\\", \\\"{x:1619,y:446,t:1526929887005};\\\", \\\"{x:1619,y:447,t:1526929887310};\\\", \\\"{x:1619,y:448,t:1526929887326};\\\", \\\"{x:1619,y:449,t:1526929887338};\\\", \\\"{x:1619,y:450,t:1526929887357};\\\", \\\"{x:1619,y:451,t:1526929887370};\\\", \\\"{x:1620,y:452,t:1526929887388};\\\", \\\"{x:1620,y:453,t:1526929887413};\\\", \\\"{x:1620,y:454,t:1526929896422};\\\", \\\"{x:1620,y:458,t:1526929896446};\\\", \\\"{x:1620,y:461,t:1526929896461};\\\", \\\"{x:1618,y:472,t:1526929896477};\\\", \\\"{x:1616,y:485,t:1526929896495};\\\", \\\"{x:1615,y:502,t:1526929896510};\\\", \\\"{x:1606,y:522,t:1526929896528};\\\", \\\"{x:1602,y:539,t:1526929896545};\\\", \\\"{x:1595,y:551,t:1526929896562};\\\", \\\"{x:1589,y:548,t:1526929896578};\\\", \\\"{x:1588,y:548,t:1526929897286};\\\", \\\"{x:1588,y:547,t:1526929897374};\\\", \\\"{x:1588,y:545,t:1526929897486};\\\", \\\"{x:1588,y:543,t:1526929897496};\\\", \\\"{x:1588,y:542,t:1526929897518};\\\", \\\"{x:1588,y:538,t:1526929897813};\\\", \\\"{x:1587,y:538,t:1526929897829};\\\", \\\"{x:1586,y:537,t:1526929897877};\\\", \\\"{x:1583,y:537,t:1526929898126};\\\", \\\"{x:1574,y:537,t:1526929898134};\\\", \\\"{x:1562,y:537,t:1526929898145};\\\", \\\"{x:1516,y:537,t:1526929898163};\\\", \\\"{x:1446,y:537,t:1526929898179};\\\", \\\"{x:1352,y:537,t:1526929898196};\\\", \\\"{x:1294,y:531,t:1526929898213};\\\", \\\"{x:1265,y:529,t:1526929898229};\\\", \\\"{x:1200,y:510,t:1526929898245};\\\", \\\"{x:1168,y:502,t:1526929898263};\\\", \\\"{x:1136,y:498,t:1526929898280};\\\", \\\"{x:1100,y:496,t:1526929898296};\\\", \\\"{x:1076,y:496,t:1526929898313};\\\", \\\"{x:1058,y:496,t:1526929898330};\\\", \\\"{x:1045,y:497,t:1526929898346};\\\", \\\"{x:1037,y:499,t:1526929898362};\\\", \\\"{x:1026,y:502,t:1526929898380};\\\", \\\"{x:1021,y:505,t:1526929898396};\\\", \\\"{x:1016,y:508,t:1526929898413};\\\", \\\"{x:1009,y:517,t:1526929898429};\\\", \\\"{x:1004,y:528,t:1526929898446};\\\", \\\"{x:1000,y:538,t:1526929898463};\\\", \\\"{x:997,y:544,t:1526929898479};\\\", \\\"{x:994,y:558,t:1526929898495};\\\", \\\"{x:994,y:579,t:1526929898512};\\\", \\\"{x:994,y:596,t:1526929898529};\\\", \\\"{x:992,y:606,t:1526929898545};\\\", \\\"{x:994,y:620,t:1526929898562};\\\", \\\"{x:996,y:636,t:1526929898579};\\\", \\\"{x:998,y:653,t:1526929898595};\\\", \\\"{x:1001,y:667,t:1526929898612};\\\", \\\"{x:1004,y:674,t:1526929898629};\\\", \\\"{x:1005,y:675,t:1526929898669};\\\", \\\"{x:1007,y:675,t:1526929898773};\\\", \\\"{x:1007,y:676,t:1526929898902};\\\", \\\"{x:1008,y:679,t:1526929899150};\\\", \\\"{x:1009,y:679,t:1526929899189};\\\", \\\"{x:1011,y:679,t:1526929899237};\\\", \\\"{x:1012,y:678,t:1526929899253};\\\", \\\"{x:1013,y:678,t:1526929899269};\\\", \\\"{x:1014,y:676,t:1526929899292};\\\", \\\"{x:1014,y:675,t:1526929899324};\\\", \\\"{x:1015,y:674,t:1526929899333};\\\", \\\"{x:1015,y:673,t:1526929899349};\\\", \\\"{x:1016,y:671,t:1526929899365};\\\", \\\"{x:1016,y:670,t:1526929899379};\\\", \\\"{x:1016,y:669,t:1526929899396};\\\", \\\"{x:1018,y:666,t:1526929899413};\\\", \\\"{x:1018,y:664,t:1526929899429};\\\", \\\"{x:1020,y:662,t:1526929899446};\\\", \\\"{x:1021,y:659,t:1526929899469};\\\", \\\"{x:1022,y:659,t:1526929899480};\\\", \\\"{x:1022,y:658,t:1526929899497};\\\", \\\"{x:1023,y:655,t:1526929899514};\\\", \\\"{x:1024,y:654,t:1526929899530};\\\", \\\"{x:1024,y:652,t:1526929899547};\\\", \\\"{x:1025,y:652,t:1526929899564};\\\", \\\"{x:1025,y:649,t:1526929899582};\\\", \\\"{x:1026,y:649,t:1526929899605};\\\", \\\"{x:1027,y:648,t:1526929899629};\\\", \\\"{x:1027,y:647,t:1526929899637};\\\", \\\"{x:1028,y:646,t:1526929899647};\\\", \\\"{x:1029,y:646,t:1526929899664};\\\", \\\"{x:1030,y:645,t:1526929899681};\\\", \\\"{x:1030,y:644,t:1526929899697};\\\", \\\"{x:1031,y:643,t:1526929899713};\\\", \\\"{x:1032,y:643,t:1526929899731};\\\", \\\"{x:1033,y:641,t:1526929899757};\\\", \\\"{x:1034,y:640,t:1526929899773};\\\", \\\"{x:1034,y:639,t:1526929899798};\\\", \\\"{x:1034,y:637,t:1526929899829};\\\", \\\"{x:1034,y:636,t:1526929899886};\\\", \\\"{x:1035,y:636,t:1526929899896};\\\", \\\"{x:1036,y:636,t:1526929900182};\\\", \\\"{x:1037,y:634,t:1526929900197};\\\", \\\"{x:1043,y:630,t:1526929900213};\\\", \\\"{x:1055,y:618,t:1526929900231};\\\", \\\"{x:1084,y:600,t:1526929900248};\\\", \\\"{x:1157,y:561,t:1526929900264};\\\", \\\"{x:1253,y:523,t:1526929900280};\\\", \\\"{x:1375,y:491,t:1526929900298};\\\", \\\"{x:1494,y:456,t:1526929900315};\\\", \\\"{x:1596,y:428,t:1526929900331};\\\", \\\"{x:1663,y:408,t:1526929900348};\\\", \\\"{x:1705,y:389,t:1526929900364};\\\", \\\"{x:1724,y:378,t:1526929900381};\\\", \\\"{x:1735,y:370,t:1526929900398};\\\", \\\"{x:1737,y:368,t:1526929900415};\\\", \\\"{x:1740,y:366,t:1526929900430};\\\", \\\"{x:1741,y:366,t:1526929900447};\\\", \\\"{x:1742,y:366,t:1526929900464};\\\", \\\"{x:1743,y:366,t:1526929900534};\\\", \\\"{x:1740,y:367,t:1526929900550};\\\", \\\"{x:1732,y:371,t:1526929900565};\\\", \\\"{x:1714,y:378,t:1526929900581};\\\", \\\"{x:1662,y:402,t:1526929900598};\\\", \\\"{x:1624,y:418,t:1526929900614};\\\", \\\"{x:1598,y:435,t:1526929900631};\\\", \\\"{x:1583,y:448,t:1526929900648};\\\", \\\"{x:1574,y:456,t:1526929900665};\\\", \\\"{x:1570,y:461,t:1526929900680};\\\", \\\"{x:1568,y:464,t:1526929900698};\\\", \\\"{x:1569,y:464,t:1526929900822};\\\", \\\"{x:1572,y:462,t:1526929900831};\\\", \\\"{x:1582,y:456,t:1526929900848};\\\", \\\"{x:1591,y:451,t:1526929900864};\\\", \\\"{x:1599,y:447,t:1526929900881};\\\", \\\"{x:1603,y:445,t:1526929900898};\\\", \\\"{x:1606,y:444,t:1526929900915};\\\", \\\"{x:1607,y:444,t:1526929900932};\\\", \\\"{x:1609,y:442,t:1526929900948};\\\", \\\"{x:1611,y:442,t:1526929900965};\\\", \\\"{x:1613,y:441,t:1526929900982};\\\", \\\"{x:1613,y:440,t:1526929900997};\\\", \\\"{x:1615,y:439,t:1526929901020};\\\", \\\"{x:1616,y:439,t:1526929901076};\\\", \\\"{x:1617,y:438,t:1526929901117};\\\", \\\"{x:1618,y:437,t:1526929901157};\\\", \\\"{x:1618,y:436,t:1526929901366};\\\", \\\"{x:1617,y:436,t:1526929901397};\\\", \\\"{x:1617,y:435,t:1526929901430};\\\", \\\"{x:1616,y:435,t:1526929901486};\\\", \\\"{x:1612,y:436,t:1526929902087};\\\", \\\"{x:1606,y:443,t:1526929902099};\\\", \\\"{x:1587,y:461,t:1526929902116};\\\", \\\"{x:1554,y:492,t:1526929902132};\\\", \\\"{x:1517,y:534,t:1526929902148};\\\", \\\"{x:1478,y:588,t:1526929902166};\\\", \\\"{x:1458,y:623,t:1526929902181};\\\", \\\"{x:1440,y:665,t:1526929902198};\\\", \\\"{x:1415,y:704,t:1526929902216};\\\", \\\"{x:1390,y:750,t:1526929902232};\\\", \\\"{x:1358,y:799,t:1526929902249};\\\", \\\"{x:1334,y:838,t:1526929902266};\\\", \\\"{x:1320,y:869,t:1526929902283};\\\", \\\"{x:1309,y:886,t:1526929902299};\\\", \\\"{x:1305,y:896,t:1526929902316};\\\", \\\"{x:1302,y:902,t:1526929902333};\\\", \\\"{x:1300,y:906,t:1526929902350};\\\", \\\"{x:1298,y:909,t:1526929902365};\\\", \\\"{x:1298,y:910,t:1526929902383};\\\", \\\"{x:1297,y:912,t:1526929902399};\\\", \\\"{x:1296,y:912,t:1526929902421};\\\", \\\"{x:1295,y:912,t:1526929902433};\\\", \\\"{x:1294,y:912,t:1526929902470};\\\", \\\"{x:1292,y:908,t:1526929902486};\\\", \\\"{x:1291,y:905,t:1526929902499};\\\", \\\"{x:1290,y:896,t:1526929902516};\\\", \\\"{x:1288,y:887,t:1526929902532};\\\", \\\"{x:1286,y:873,t:1526929902548};\\\", \\\"{x:1285,y:866,t:1526929902565};\\\", \\\"{x:1285,y:862,t:1526929902582};\\\", \\\"{x:1285,y:859,t:1526929902598};\\\", \\\"{x:1285,y:857,t:1526929902615};\\\", \\\"{x:1285,y:855,t:1526929902632};\\\", \\\"{x:1285,y:853,t:1526929902649};\\\", \\\"{x:1285,y:852,t:1526929902668};\\\", \\\"{x:1285,y:851,t:1526929902683};\\\", \\\"{x:1285,y:850,t:1526929902699};\\\", \\\"{x:1285,y:848,t:1526929902716};\\\", \\\"{x:1285,y:847,t:1526929902733};\\\", \\\"{x:1285,y:846,t:1526929902790};\\\", \\\"{x:1285,y:844,t:1526929903246};\\\", \\\"{x:1285,y:843,t:1526929903262};\\\", \\\"{x:1285,y:842,t:1526929903277};\\\", \\\"{x:1285,y:841,t:1526929903286};\\\", \\\"{x:1285,y:840,t:1526929903300};\\\", \\\"{x:1285,y:838,t:1526929903317};\\\", \\\"{x:1285,y:837,t:1526929903333};\\\", \\\"{x:1284,y:837,t:1526929903351};\\\", \\\"{x:1284,y:836,t:1526929904358};\\\", \\\"{x:1283,y:836,t:1526929904566};\\\", \\\"{x:1283,y:837,t:1526929904597};\\\", \\\"{x:1281,y:838,t:1526929904606};\\\", \\\"{x:1280,y:841,t:1526929904630};\\\", \\\"{x:1280,y:843,t:1526929904646};\\\", \\\"{x:1280,y:844,t:1526929904653};\\\", \\\"{x:1279,y:845,t:1526929904668};\\\", \\\"{x:1278,y:847,t:1526929904684};\\\", \\\"{x:1276,y:851,t:1526929904701};\\\", \\\"{x:1276,y:853,t:1526929904717};\\\", \\\"{x:1274,y:855,t:1526929904734};\\\", \\\"{x:1274,y:857,t:1526929904751};\\\", \\\"{x:1273,y:860,t:1526929904768};\\\", \\\"{x:1273,y:861,t:1526929904784};\\\", \\\"{x:1272,y:864,t:1526929904801};\\\", \\\"{x:1271,y:865,t:1526929904818};\\\", \\\"{x:1270,y:868,t:1526929904835};\\\", \\\"{x:1270,y:871,t:1526929904851};\\\", \\\"{x:1269,y:874,t:1526929904868};\\\", \\\"{x:1267,y:879,t:1526929904885};\\\", \\\"{x:1266,y:882,t:1526929904901};\\\", \\\"{x:1264,y:887,t:1526929904917};\\\", \\\"{x:1263,y:888,t:1526929904935};\\\", \\\"{x:1263,y:889,t:1526929904951};\\\", \\\"{x:1263,y:890,t:1526929904968};\\\", \\\"{x:1262,y:891,t:1526929904985};\\\", \\\"{x:1261,y:894,t:1526929905002};\\\", \\\"{x:1259,y:898,t:1526929905018};\\\", \\\"{x:1257,y:901,t:1526929905035};\\\", \\\"{x:1255,y:907,t:1526929905051};\\\", \\\"{x:1253,y:911,t:1526929905068};\\\", \\\"{x:1249,y:918,t:1526929905085};\\\", \\\"{x:1248,y:921,t:1526929905101};\\\", \\\"{x:1245,y:927,t:1526929905118};\\\", \\\"{x:1243,y:931,t:1526929905135};\\\", \\\"{x:1241,y:936,t:1526929905151};\\\", \\\"{x:1240,y:940,t:1526929905168};\\\", \\\"{x:1237,y:944,t:1526929905185};\\\", \\\"{x:1236,y:947,t:1526929905201};\\\", \\\"{x:1234,y:950,t:1526929905218};\\\", \\\"{x:1232,y:953,t:1526929905235};\\\", \\\"{x:1231,y:955,t:1526929905251};\\\", \\\"{x:1230,y:956,t:1526929905268};\\\", \\\"{x:1229,y:958,t:1526929905285};\\\", \\\"{x:1228,y:960,t:1526929905301};\\\", \\\"{x:1227,y:961,t:1526929905350};\\\", \\\"{x:1228,y:961,t:1526929905510};\\\", \\\"{x:1230,y:960,t:1526929905517};\\\", \\\"{x:1240,y:946,t:1526929905535};\\\", \\\"{x:1255,y:930,t:1526929905552};\\\", \\\"{x:1276,y:906,t:1526929905568};\\\", \\\"{x:1297,y:883,t:1526929905585};\\\", \\\"{x:1332,y:842,t:1526929905602};\\\", \\\"{x:1382,y:777,t:1526929905618};\\\", \\\"{x:1443,y:712,t:1526929905635};\\\", \\\"{x:1493,y:666,t:1526929905652};\\\", \\\"{x:1533,y:626,t:1526929905667};\\\", \\\"{x:1565,y:594,t:1526929905685};\\\", \\\"{x:1597,y:544,t:1526929905701};\\\", \\\"{x:1607,y:520,t:1526929905719};\\\", \\\"{x:1616,y:500,t:1526929905735};\\\", \\\"{x:1618,y:490,t:1526929905751};\\\", \\\"{x:1621,y:481,t:1526929905768};\\\", \\\"{x:1627,y:470,t:1526929905784};\\\", \\\"{x:1633,y:455,t:1526929905801};\\\", \\\"{x:1640,y:442,t:1526929905819};\\\", \\\"{x:1643,y:434,t:1526929905835};\\\", \\\"{x:1645,y:426,t:1526929905852};\\\", \\\"{x:1645,y:425,t:1526929905869};\\\", \\\"{x:1645,y:424,t:1526929905894};\\\", \\\"{x:1643,y:424,t:1526929905990};\\\", \\\"{x:1642,y:424,t:1526929906002};\\\", \\\"{x:1634,y:428,t:1526929906019};\\\", \\\"{x:1630,y:429,t:1526929906035};\\\", \\\"{x:1625,y:433,t:1526929906052};\\\", \\\"{x:1618,y:438,t:1526929906069};\\\", \\\"{x:1616,y:439,t:1526929906086};\\\", \\\"{x:1614,y:440,t:1526929906102};\\\", \\\"{x:1613,y:440,t:1526929906156};\\\", \\\"{x:1612,y:440,t:1526929906189};\\\", \\\"{x:1611,y:441,t:1526929906202};\\\", \\\"{x:1610,y:441,t:1526929906285};\\\", \\\"{x:1608,y:442,t:1526929906302};\\\", \\\"{x:1605,y:446,t:1526929906319};\\\", \\\"{x:1601,y:452,t:1526929906336};\\\", \\\"{x:1597,y:457,t:1526929906351};\\\", \\\"{x:1594,y:462,t:1526929906369};\\\", \\\"{x:1593,y:464,t:1526929906386};\\\", \\\"{x:1593,y:466,t:1526929906402};\\\", \\\"{x:1592,y:466,t:1526929906419};\\\", \\\"{x:1591,y:468,t:1526929906469};\\\", \\\"{x:1590,y:470,t:1526929906486};\\\", \\\"{x:1590,y:473,t:1526929906502};\\\", \\\"{x:1587,y:477,t:1526929906519};\\\", \\\"{x:1587,y:479,t:1526929906536};\\\", \\\"{x:1587,y:482,t:1526929906552};\\\", \\\"{x:1586,y:483,t:1526929906568};\\\", \\\"{x:1585,y:491,t:1526929906585};\\\", \\\"{x:1582,y:497,t:1526929906602};\\\", \\\"{x:1580,y:501,t:1526929906618};\\\", \\\"{x:1579,y:502,t:1526929906635};\\\", \\\"{x:1579,y:503,t:1526929906869};\\\", \\\"{x:1579,y:506,t:1526929906886};\\\", \\\"{x:1577,y:512,t:1526929906903};\\\", \\\"{x:1571,y:520,t:1526929906919};\\\", \\\"{x:1565,y:530,t:1526929906936};\\\", \\\"{x:1559,y:541,t:1526929906953};\\\", \\\"{x:1554,y:551,t:1526929906969};\\\", \\\"{x:1549,y:558,t:1526929906986};\\\", \\\"{x:1546,y:564,t:1526929907002};\\\", \\\"{x:1544,y:569,t:1526929907020};\\\", \\\"{x:1542,y:572,t:1526929907035};\\\", \\\"{x:1540,y:575,t:1526929907053};\\\", \\\"{x:1540,y:576,t:1526929907070};\\\", \\\"{x:1540,y:577,t:1526929907085};\\\", \\\"{x:1539,y:578,t:1526929907110};\\\", \\\"{x:1539,y:579,t:1526929907534};\\\", \\\"{x:1539,y:581,t:1526929907541};\\\", \\\"{x:1538,y:582,t:1526929907552};\\\", \\\"{x:1538,y:585,t:1526929907570};\\\", \\\"{x:1536,y:589,t:1526929907587};\\\", \\\"{x:1536,y:592,t:1526929907604};\\\", \\\"{x:1533,y:597,t:1526929907619};\\\", \\\"{x:1533,y:602,t:1526929907636};\\\", \\\"{x:1532,y:605,t:1526929907652};\\\", \\\"{x:1530,y:610,t:1526929907669};\\\", \\\"{x:1528,y:613,t:1526929907687};\\\", \\\"{x:1528,y:617,t:1526929907702};\\\", \\\"{x:1526,y:621,t:1526929907719};\\\", \\\"{x:1525,y:624,t:1526929907737};\\\", \\\"{x:1524,y:625,t:1526929907752};\\\", \\\"{x:1524,y:626,t:1526929907769};\\\", \\\"{x:1524,y:624,t:1526929909685};\\\", \\\"{x:1526,y:618,t:1526929909694};\\\", \\\"{x:1529,y:609,t:1526929909705};\\\", \\\"{x:1537,y:592,t:1526929909722};\\\", \\\"{x:1546,y:571,t:1526929909738};\\\", \\\"{x:1553,y:549,t:1526929909755};\\\", \\\"{x:1560,y:531,t:1526929909773};\\\", \\\"{x:1564,y:516,t:1526929909788};\\\", \\\"{x:1566,y:502,t:1526929909805};\\\", \\\"{x:1567,y:499,t:1526929909821};\\\", \\\"{x:1567,y:498,t:1526929909838};\\\", \\\"{x:1569,y:497,t:1526929909909};\\\", \\\"{x:1571,y:495,t:1526929909922};\\\", \\\"{x:1574,y:491,t:1526929909938};\\\", \\\"{x:1578,y:487,t:1526929909955};\\\", \\\"{x:1585,y:482,t:1526929909972};\\\", \\\"{x:1594,y:476,t:1526929909988};\\\", \\\"{x:1603,y:468,t:1526929910005};\\\", \\\"{x:1606,y:466,t:1526929910022};\\\", \\\"{x:1606,y:464,t:1526929910158};\\\", \\\"{x:1606,y:463,t:1526929910173};\\\", \\\"{x:1606,y:461,t:1526929910189};\\\", \\\"{x:1606,y:458,t:1526929910205};\\\", \\\"{x:1606,y:456,t:1526929910222};\\\", \\\"{x:1606,y:454,t:1526929910239};\\\", \\\"{x:1606,y:452,t:1526929910255};\\\", \\\"{x:1606,y:451,t:1526929910272};\\\", \\\"{x:1605,y:449,t:1526929910289};\\\", \\\"{x:1605,y:447,t:1526929910306};\\\", \\\"{x:1605,y:445,t:1526929910323};\\\", \\\"{x:1605,y:444,t:1526929910339};\\\", \\\"{x:1605,y:443,t:1526929910357};\\\", \\\"{x:1605,y:442,t:1526929910381};\\\", \\\"{x:1605,y:441,t:1526929910398};\\\", \\\"{x:1605,y:440,t:1526929910413};\\\", \\\"{x:1605,y:439,t:1526929910422};\\\", \\\"{x:1605,y:438,t:1526929910439};\\\", \\\"{x:1606,y:435,t:1526929910455};\\\", \\\"{x:1607,y:434,t:1526929910472};\\\", \\\"{x:1608,y:433,t:1526929910489};\\\", \\\"{x:1605,y:442,t:1526929910758};\\\", \\\"{x:1600,y:449,t:1526929910773};\\\", \\\"{x:1567,y:496,t:1526929910789};\\\", \\\"{x:1531,y:542,t:1526929910806};\\\", \\\"{x:1484,y:593,t:1526929910822};\\\", \\\"{x:1439,y:655,t:1526929910839};\\\", \\\"{x:1399,y:708,t:1526929910856};\\\", \\\"{x:1362,y:759,t:1526929910872};\\\", \\\"{x:1325,y:808,t:1526929910889};\\\", \\\"{x:1302,y:837,t:1526929910906};\\\", \\\"{x:1283,y:859,t:1526929910922};\\\", \\\"{x:1273,y:871,t:1526929910939};\\\", \\\"{x:1265,y:880,t:1526929910956};\\\", \\\"{x:1264,y:882,t:1526929910972};\\\", \\\"{x:1264,y:883,t:1526929911012};\\\", \\\"{x:1265,y:884,t:1526929911036};\\\", \\\"{x:1266,y:884,t:1526929911068};\\\", \\\"{x:1267,y:884,t:1526929911116};\\\", \\\"{x:1269,y:884,t:1526929911124};\\\", \\\"{x:1270,y:881,t:1526929911139};\\\", \\\"{x:1272,y:873,t:1526929911156};\\\", \\\"{x:1275,y:863,t:1526929911172};\\\", \\\"{x:1276,y:857,t:1526929911188};\\\", \\\"{x:1278,y:853,t:1526929911206};\\\", \\\"{x:1278,y:851,t:1526929911223};\\\", \\\"{x:1278,y:849,t:1526929911239};\\\", \\\"{x:1283,y:848,t:1526929911525};\\\", \\\"{x:1290,y:845,t:1526929911540};\\\", \\\"{x:1306,y:843,t:1526929911556};\\\", \\\"{x:1333,y:838,t:1526929911573};\\\", \\\"{x:1341,y:838,t:1526929911589};\\\", \\\"{x:1342,y:838,t:1526929911606};\\\", \\\"{x:1344,y:839,t:1526929911629};\\\", \\\"{x:1344,y:840,t:1526929911640};\\\", \\\"{x:1344,y:847,t:1526929911656};\\\", \\\"{x:1344,y:856,t:1526929911673};\\\", \\\"{x:1338,y:867,t:1526929911690};\\\", \\\"{x:1327,y:882,t:1526929911706};\\\", \\\"{x:1313,y:893,t:1526929911723};\\\", \\\"{x:1295,y:910,t:1526929911741};\\\", \\\"{x:1281,y:926,t:1526929911756};\\\", \\\"{x:1263,y:942,t:1526929911774};\\\", \\\"{x:1255,y:953,t:1526929911791};\\\", \\\"{x:1252,y:961,t:1526929911806};\\\", \\\"{x:1251,y:967,t:1526929911823};\\\", \\\"{x:1251,y:972,t:1526929911840};\\\", \\\"{x:1251,y:975,t:1526929911858};\\\", \\\"{x:1253,y:978,t:1526929911873};\\\", \\\"{x:1257,y:981,t:1526929911890};\\\", \\\"{x:1259,y:983,t:1526929911907};\\\", \\\"{x:1260,y:983,t:1526929911934};\\\", \\\"{x:1262,y:983,t:1526929911942};\\\", \\\"{x:1268,y:983,t:1526929911957};\\\", \\\"{x:1283,y:978,t:1526929911973};\\\", \\\"{x:1304,y:968,t:1526929911991};\\\", \\\"{x:1323,y:953,t:1526929912007};\\\", \\\"{x:1339,y:939,t:1526929912023};\\\", \\\"{x:1350,y:924,t:1526929912040};\\\", \\\"{x:1358,y:907,t:1526929912057};\\\", \\\"{x:1359,y:897,t:1526929912073};\\\", \\\"{x:1360,y:890,t:1526929912090};\\\", \\\"{x:1360,y:887,t:1526929912107};\\\", \\\"{x:1360,y:884,t:1526929912123};\\\", \\\"{x:1360,y:882,t:1526929912140};\\\", \\\"{x:1360,y:881,t:1526929912166};\\\", \\\"{x:1360,y:880,t:1526929912173};\\\", \\\"{x:1360,y:877,t:1526929912190};\\\", \\\"{x:1361,y:872,t:1526929912208};\\\", \\\"{x:1362,y:867,t:1526929912224};\\\", \\\"{x:1363,y:864,t:1526929912240};\\\", \\\"{x:1363,y:860,t:1526929912257};\\\", \\\"{x:1363,y:857,t:1526929912273};\\\", \\\"{x:1363,y:856,t:1526929912291};\\\", \\\"{x:1365,y:852,t:1526929912307};\\\", \\\"{x:1365,y:850,t:1526929912324};\\\", \\\"{x:1366,y:848,t:1526929912340};\\\", \\\"{x:1367,y:844,t:1526929912357};\\\", \\\"{x:1367,y:841,t:1526929912373};\\\", \\\"{x:1369,y:837,t:1526929912391};\\\", \\\"{x:1370,y:836,t:1526929912408};\\\", \\\"{x:1370,y:834,t:1526929912425};\\\", \\\"{x:1370,y:833,t:1526929912461};\\\", \\\"{x:1371,y:833,t:1526929912476};\\\", \\\"{x:1371,y:831,t:1526929912490};\\\", \\\"{x:1372,y:830,t:1526929912506};\\\", \\\"{x:1372,y:829,t:1526929912533};\\\", \\\"{x:1372,y:828,t:1526929912581};\\\", \\\"{x:1373,y:827,t:1526929912789};\\\", \\\"{x:1374,y:824,t:1526929912808};\\\", \\\"{x:1375,y:822,t:1526929912823};\\\", \\\"{x:1375,y:820,t:1526929912841};\\\", \\\"{x:1376,y:820,t:1526929912857};\\\", \\\"{x:1376,y:818,t:1526929912873};\\\", \\\"{x:1376,y:817,t:1526929912891};\\\", \\\"{x:1378,y:815,t:1526929912907};\\\", \\\"{x:1378,y:814,t:1526929912924};\\\", \\\"{x:1378,y:813,t:1526929912988};\\\", \\\"{x:1379,y:813,t:1526929913004};\\\", \\\"{x:1379,y:812,t:1526929913012};\\\", \\\"{x:1380,y:810,t:1526929913036};\\\", \\\"{x:1380,y:809,t:1526929913053};\\\", \\\"{x:1382,y:808,t:1526929913060};\\\", \\\"{x:1384,y:806,t:1526929913073};\\\", \\\"{x:1392,y:798,t:1526929913090};\\\", \\\"{x:1398,y:793,t:1526929913107};\\\", \\\"{x:1407,y:788,t:1526929913124};\\\", \\\"{x:1411,y:786,t:1526929913141};\\\", \\\"{x:1412,y:786,t:1526929913181};\\\", \\\"{x:1413,y:786,t:1526929913190};\\\", \\\"{x:1415,y:786,t:1526929913207};\\\", \\\"{x:1417,y:786,t:1526929913236};\\\", \\\"{x:1419,y:786,t:1526929913244};\\\", \\\"{x:1422,y:785,t:1526929913258};\\\", \\\"{x:1436,y:781,t:1526929913273};\\\", \\\"{x:1451,y:774,t:1526929913290};\\\", \\\"{x:1463,y:771,t:1526929913308};\\\", \\\"{x:1478,y:766,t:1526929913323};\\\", \\\"{x:1493,y:764,t:1526929913340};\\\", \\\"{x:1498,y:762,t:1526929913358};\\\", \\\"{x:1510,y:758,t:1526929913374};\\\", \\\"{x:1512,y:757,t:1526929913391};\\\", \\\"{x:1514,y:757,t:1526929913408};\\\", \\\"{x:1514,y:756,t:1526929913693};\\\", \\\"{x:1514,y:755,t:1526929913717};\\\", \\\"{x:1514,y:752,t:1526929913829};\\\", \\\"{x:1514,y:751,t:1526929913841};\\\", \\\"{x:1515,y:747,t:1526929913859};\\\", \\\"{x:1520,y:737,t:1526929913875};\\\", \\\"{x:1525,y:722,t:1526929913891};\\\", \\\"{x:1534,y:700,t:1526929913908};\\\", \\\"{x:1547,y:655,t:1526929913925};\\\", \\\"{x:1555,y:619,t:1526929913941};\\\", \\\"{x:1560,y:587,t:1526929913958};\\\", \\\"{x:1563,y:560,t:1526929913976};\\\", \\\"{x:1571,y:535,t:1526929913991};\\\", \\\"{x:1576,y:510,t:1526929914008};\\\", \\\"{x:1579,y:498,t:1526929914025};\\\", \\\"{x:1582,y:489,t:1526929914042};\\\", \\\"{x:1583,y:482,t:1526929914058};\\\", \\\"{x:1584,y:477,t:1526929914075};\\\", \\\"{x:1585,y:473,t:1526929914092};\\\", \\\"{x:1587,y:469,t:1526929914109};\\\", \\\"{x:1587,y:468,t:1526929914125};\\\", \\\"{x:1587,y:467,t:1526929914141};\\\", \\\"{x:1587,y:465,t:1526929914158};\\\", \\\"{x:1587,y:462,t:1526929914176};\\\", \\\"{x:1587,y:458,t:1526929914192};\\\", \\\"{x:1587,y:456,t:1526929914208};\\\", \\\"{x:1587,y:454,t:1526929914226};\\\", \\\"{x:1587,y:452,t:1526929914242};\\\", \\\"{x:1587,y:450,t:1526929914258};\\\", \\\"{x:1589,y:447,t:1526929914275};\\\", \\\"{x:1591,y:444,t:1526929914292};\\\", \\\"{x:1595,y:440,t:1526929914308};\\\", \\\"{x:1598,y:434,t:1526929914325};\\\", \\\"{x:1600,y:432,t:1526929914342};\\\", \\\"{x:1601,y:432,t:1526929914358};\\\", \\\"{x:1602,y:431,t:1526929914381};\\\", \\\"{x:1604,y:432,t:1526929915334};\\\", \\\"{x:1604,y:433,t:1526929915350};\\\", \\\"{x:1605,y:433,t:1526929915360};\\\", \\\"{x:1607,y:435,t:1526929915376};\\\", \\\"{x:1607,y:436,t:1526929915393};\\\", \\\"{x:1608,y:436,t:1526929915581};\\\", \\\"{x:1609,y:436,t:1526929915593};\\\", \\\"{x:1610,y:436,t:1526929915613};\\\", \\\"{x:1612,y:436,t:1526929915626};\\\", \\\"{x:1613,y:436,t:1526929915644};\\\", \\\"{x:1616,y:436,t:1526929915659};\\\", \\\"{x:1619,y:436,t:1526929915676};\\\", \\\"{x:1620,y:435,t:1526929915717};\\\", \\\"{x:1621,y:436,t:1526929915957};\\\", \\\"{x:1621,y:437,t:1526929915973};\\\", \\\"{x:1621,y:438,t:1526929915981};\\\", \\\"{x:1621,y:439,t:1526929915993};\\\", \\\"{x:1621,y:442,t:1526929916010};\\\", \\\"{x:1621,y:446,t:1526929916027};\\\", \\\"{x:1621,y:448,t:1526929916043};\\\", \\\"{x:1621,y:451,t:1526929916060};\\\", \\\"{x:1621,y:455,t:1526929916076};\\\", \\\"{x:1618,y:461,t:1526929916093};\\\", \\\"{x:1616,y:465,t:1526929916110};\\\", \\\"{x:1613,y:468,t:1526929916126};\\\", \\\"{x:1611,y:473,t:1526929916143};\\\", \\\"{x:1609,y:475,t:1526929916161};\\\", \\\"{x:1607,y:477,t:1526929916177};\\\", \\\"{x:1605,y:479,t:1526929916194};\\\", \\\"{x:1603,y:481,t:1526929916210};\\\", \\\"{x:1601,y:483,t:1526929916228};\\\", \\\"{x:1601,y:484,t:1526929916244};\\\", \\\"{x:1600,y:485,t:1526929916261};\\\", \\\"{x:1598,y:486,t:1526929916276};\\\", \\\"{x:1595,y:489,t:1526929916293};\\\", \\\"{x:1594,y:490,t:1526929916310};\\\", \\\"{x:1591,y:491,t:1526929916327};\\\", \\\"{x:1589,y:492,t:1526929916343};\\\", \\\"{x:1587,y:494,t:1526929916360};\\\", \\\"{x:1585,y:495,t:1526929916377};\\\", \\\"{x:1584,y:496,t:1526929916486};\\\", \\\"{x:1583,y:497,t:1526929916510};\\\", \\\"{x:1583,y:499,t:1526929916527};\\\", \\\"{x:1582,y:501,t:1526929916544};\\\", \\\"{x:1582,y:503,t:1526929916560};\\\", \\\"{x:1581,y:507,t:1526929916578};\\\", \\\"{x:1581,y:510,t:1526929916594};\\\", \\\"{x:1581,y:515,t:1526929916610};\\\", \\\"{x:1578,y:519,t:1526929916628};\\\", \\\"{x:1578,y:522,t:1526929916644};\\\", \\\"{x:1575,y:527,t:1526929916660};\\\", \\\"{x:1573,y:531,t:1526929916677};\\\", \\\"{x:1571,y:533,t:1526929916694};\\\", \\\"{x:1571,y:535,t:1526929916710};\\\", \\\"{x:1569,y:537,t:1526929916727};\\\", \\\"{x:1568,y:538,t:1526929916745};\\\", \\\"{x:1567,y:540,t:1526929916760};\\\", \\\"{x:1565,y:542,t:1526929916777};\\\", \\\"{x:1564,y:544,t:1526929916795};\\\", \\\"{x:1561,y:546,t:1526929916810};\\\", \\\"{x:1558,y:548,t:1526929916828};\\\", \\\"{x:1556,y:550,t:1526929916844};\\\", \\\"{x:1553,y:553,t:1526929916860};\\\", \\\"{x:1549,y:556,t:1526929916877};\\\", \\\"{x:1549,y:557,t:1526929916894};\\\", \\\"{x:1547,y:558,t:1526929916910};\\\", \\\"{x:1547,y:559,t:1526929916928};\\\", \\\"{x:1546,y:560,t:1526929916945};\\\", \\\"{x:1545,y:561,t:1526929916961};\\\", \\\"{x:1543,y:562,t:1526929916977};\\\", \\\"{x:1541,y:563,t:1526929917158};\\\", \\\"{x:1541,y:564,t:1526929917173};\\\", \\\"{x:1541,y:565,t:1526929917181};\\\", \\\"{x:1541,y:567,t:1526929917195};\\\", \\\"{x:1542,y:570,t:1526929917211};\\\", \\\"{x:1542,y:571,t:1526929917226};\\\", \\\"{x:1543,y:575,t:1526929917244};\\\", \\\"{x:1543,y:579,t:1526929917260};\\\", \\\"{x:1543,y:584,t:1526929917277};\\\", \\\"{x:1543,y:585,t:1526929917294};\\\", \\\"{x:1543,y:589,t:1526929917310};\\\", \\\"{x:1542,y:590,t:1526929917327};\\\", \\\"{x:1542,y:592,t:1526929917344};\\\", \\\"{x:1542,y:594,t:1526929917361};\\\", \\\"{x:1542,y:597,t:1526929917377};\\\", \\\"{x:1541,y:598,t:1526929917394};\\\", \\\"{x:1540,y:599,t:1526929917411};\\\", \\\"{x:1539,y:601,t:1526929917427};\\\", \\\"{x:1539,y:602,t:1526929917444};\\\", \\\"{x:1537,y:604,t:1526929917461};\\\", \\\"{x:1534,y:607,t:1526929917477};\\\", \\\"{x:1527,y:611,t:1526929917494};\\\", \\\"{x:1519,y:617,t:1526929917511};\\\", \\\"{x:1515,y:621,t:1526929917527};\\\", \\\"{x:1513,y:621,t:1526929917544};\\\", \\\"{x:1513,y:622,t:1526929917660};\\\", \\\"{x:1512,y:622,t:1526929917684};\\\", \\\"{x:1512,y:623,t:1526929917796};\\\", \\\"{x:1512,y:624,t:1526929917811};\\\", \\\"{x:1512,y:626,t:1526929917828};\\\", \\\"{x:1512,y:627,t:1526929917844};\\\", \\\"{x:1513,y:633,t:1526929917861};\\\", \\\"{x:1513,y:639,t:1526929917885};\\\", \\\"{x:1514,y:646,t:1526929917894};\\\", \\\"{x:1515,y:655,t:1526929917911};\\\", \\\"{x:1516,y:661,t:1526929917928};\\\", \\\"{x:1516,y:666,t:1526929917944};\\\", \\\"{x:1516,y:670,t:1526929917961};\\\", \\\"{x:1516,y:673,t:1526929917978};\\\", \\\"{x:1516,y:677,t:1526929917995};\\\", \\\"{x:1515,y:679,t:1526929918020};\\\", \\\"{x:1514,y:680,t:1526929918036};\\\", \\\"{x:1512,y:681,t:1526929918052};\\\", \\\"{x:1511,y:681,t:1526929918069};\\\", \\\"{x:1508,y:683,t:1526929918078};\\\", \\\"{x:1505,y:685,t:1526929918095};\\\", \\\"{x:1500,y:687,t:1526929918111};\\\", \\\"{x:1496,y:690,t:1526929918128};\\\", \\\"{x:1492,y:692,t:1526929918145};\\\", \\\"{x:1486,y:696,t:1526929918162};\\\", \\\"{x:1482,y:700,t:1526929918178};\\\", \\\"{x:1478,y:704,t:1526929918195};\\\", \\\"{x:1475,y:706,t:1526929918211};\\\", \\\"{x:1474,y:707,t:1526929918228};\\\", \\\"{x:1474,y:709,t:1526929918445};\\\", \\\"{x:1474,y:712,t:1526929918463};\\\", \\\"{x:1474,y:717,t:1526929918479};\\\", \\\"{x:1475,y:719,t:1526929918495};\\\", \\\"{x:1475,y:720,t:1526929918512};\\\", \\\"{x:1475,y:722,t:1526929918528};\\\", \\\"{x:1475,y:724,t:1526929918545};\\\", \\\"{x:1475,y:725,t:1526929918563};\\\", \\\"{x:1475,y:726,t:1526929918578};\\\", \\\"{x:1475,y:729,t:1526929918595};\\\", \\\"{x:1475,y:734,t:1526929918612};\\\", \\\"{x:1473,y:740,t:1526929918628};\\\", \\\"{x:1465,y:752,t:1526929918645};\\\", \\\"{x:1460,y:758,t:1526929918663};\\\", \\\"{x:1456,y:763,t:1526929918679};\\\", \\\"{x:1454,y:765,t:1526929918696};\\\", \\\"{x:1453,y:766,t:1526929918713};\\\", \\\"{x:1451,y:768,t:1526929918728};\\\", \\\"{x:1450,y:769,t:1526929918746};\\\", \\\"{x:1450,y:770,t:1526929919006};\\\", \\\"{x:1450,y:771,t:1526929919014};\\\", \\\"{x:1450,y:776,t:1526929919030};\\\", \\\"{x:1451,y:781,t:1526929919046};\\\", \\\"{x:1451,y:787,t:1526929919062};\\\", \\\"{x:1451,y:791,t:1526929919079};\\\", \\\"{x:1451,y:794,t:1526929919096};\\\", \\\"{x:1451,y:797,t:1526929919112};\\\", \\\"{x:1451,y:798,t:1526929919130};\\\", \\\"{x:1450,y:799,t:1526929919146};\\\", \\\"{x:1447,y:800,t:1526929919163};\\\", \\\"{x:1445,y:801,t:1526929919179};\\\", \\\"{x:1441,y:802,t:1526929919195};\\\", \\\"{x:1437,y:804,t:1526929919213};\\\", \\\"{x:1431,y:806,t:1526929919229};\\\", \\\"{x:1428,y:807,t:1526929919247};\\\", \\\"{x:1427,y:808,t:1526929919262};\\\", \\\"{x:1425,y:808,t:1526929919280};\\\", \\\"{x:1424,y:809,t:1526929919297};\\\", \\\"{x:1423,y:809,t:1526929919509};\\\", \\\"{x:1423,y:810,t:1526929919517};\\\", \\\"{x:1423,y:812,t:1526929919530};\\\", \\\"{x:1421,y:818,t:1526929919546};\\\", \\\"{x:1420,y:823,t:1526929919563};\\\", \\\"{x:1419,y:830,t:1526929919579};\\\", \\\"{x:1419,y:834,t:1526929919597};\\\", \\\"{x:1417,y:838,t:1526929919613};\\\", \\\"{x:1415,y:844,t:1526929919630};\\\", \\\"{x:1412,y:850,t:1526929919646};\\\", \\\"{x:1411,y:856,t:1526929919662};\\\", \\\"{x:1408,y:861,t:1526929919679};\\\", \\\"{x:1407,y:863,t:1526929919696};\\\", \\\"{x:1405,y:865,t:1526929919713};\\\", \\\"{x:1404,y:867,t:1526929919729};\\\", \\\"{x:1401,y:870,t:1526929919746};\\\", \\\"{x:1399,y:871,t:1526929919764};\\\", \\\"{x:1398,y:872,t:1526929919780};\\\", \\\"{x:1398,y:873,t:1526929919797};\\\", \\\"{x:1396,y:876,t:1526929919814};\\\", \\\"{x:1391,y:880,t:1526929919829};\\\", \\\"{x:1387,y:884,t:1526929919846};\\\", \\\"{x:1382,y:889,t:1526929919864};\\\", \\\"{x:1379,y:894,t:1526929919880};\\\", \\\"{x:1379,y:896,t:1526929919897};\\\", \\\"{x:1378,y:897,t:1526929919914};\\\", \\\"{x:1378,y:899,t:1526929920060};\\\", \\\"{x:1378,y:900,t:1526929920076};\\\", \\\"{x:1379,y:901,t:1526929920084};\\\", \\\"{x:1379,y:902,t:1526929920096};\\\", \\\"{x:1380,y:903,t:1526929920113};\\\", \\\"{x:1380,y:906,t:1526929920129};\\\", \\\"{x:1380,y:909,t:1526929920145};\\\", \\\"{x:1378,y:914,t:1526929920163};\\\", \\\"{x:1368,y:925,t:1526929920180};\\\", \\\"{x:1357,y:936,t:1526929920196};\\\", \\\"{x:1345,y:946,t:1526929920213};\\\", \\\"{x:1328,y:961,t:1526929920230};\\\", \\\"{x:1317,y:970,t:1526929920246};\\\", \\\"{x:1310,y:976,t:1526929920263};\\\", \\\"{x:1308,y:977,t:1526929920279};\\\", \\\"{x:1308,y:978,t:1526929920295};\\\", \\\"{x:1309,y:978,t:1526929920413};\\\", \\\"{x:1313,y:974,t:1526929920431};\\\", \\\"{x:1321,y:963,t:1526929920447};\\\", \\\"{x:1329,y:952,t:1526929920464};\\\", \\\"{x:1340,y:940,t:1526929920481};\\\", \\\"{x:1351,y:922,t:1526929920497};\\\", \\\"{x:1364,y:903,t:1526929920513};\\\", \\\"{x:1373,y:884,t:1526929920531};\\\", \\\"{x:1382,y:866,t:1526929920547};\\\", \\\"{x:1384,y:857,t:1526929920564};\\\", \\\"{x:1387,y:846,t:1526929920580};\\\", \\\"{x:1387,y:836,t:1526929920597};\\\", \\\"{x:1388,y:829,t:1526929920613};\\\", \\\"{x:1390,y:816,t:1526929920631};\\\", \\\"{x:1392,y:807,t:1526929920648};\\\", \\\"{x:1394,y:800,t:1526929920664};\\\", \\\"{x:1396,y:795,t:1526929920680};\\\", \\\"{x:1399,y:788,t:1526929920698};\\\", \\\"{x:1404,y:780,t:1526929920714};\\\", \\\"{x:1408,y:772,t:1526929920731};\\\", \\\"{x:1414,y:760,t:1526929920748};\\\", \\\"{x:1418,y:750,t:1526929920763};\\\", \\\"{x:1424,y:738,t:1526929920780};\\\", \\\"{x:1428,y:732,t:1526929920796};\\\", \\\"{x:1433,y:724,t:1526929920813};\\\", \\\"{x:1441,y:715,t:1526929920830};\\\", \\\"{x:1450,y:704,t:1526929920847};\\\", \\\"{x:1458,y:692,t:1526929920863};\\\", \\\"{x:1468,y:678,t:1526929920880};\\\", \\\"{x:1476,y:664,t:1526929920897};\\\", \\\"{x:1482,y:651,t:1526929920913};\\\", \\\"{x:1487,y:638,t:1526929920929};\\\", \\\"{x:1496,y:625,t:1526929920947};\\\", \\\"{x:1499,y:615,t:1526929920963};\\\", \\\"{x:1507,y:601,t:1526929920980};\\\", \\\"{x:1512,y:592,t:1526929920997};\\\", \\\"{x:1513,y:587,t:1526929921013};\\\", \\\"{x:1516,y:580,t:1526929921030};\\\", \\\"{x:1517,y:578,t:1526929921047};\\\", \\\"{x:1519,y:574,t:1526929921064};\\\", \\\"{x:1521,y:571,t:1526929921081};\\\", \\\"{x:1522,y:568,t:1526929921097};\\\", \\\"{x:1523,y:565,t:1526929921114};\\\", \\\"{x:1527,y:559,t:1526929921131};\\\", \\\"{x:1531,y:551,t:1526929921148};\\\", \\\"{x:1535,y:544,t:1526929921164};\\\", \\\"{x:1541,y:536,t:1526929921181};\\\", \\\"{x:1552,y:521,t:1526929921197};\\\", \\\"{x:1560,y:509,t:1526929921215};\\\", \\\"{x:1571,y:495,t:1526929921231};\\\", \\\"{x:1577,y:483,t:1526929921247};\\\", \\\"{x:1585,y:469,t:1526929921264};\\\", \\\"{x:1594,y:455,t:1526929921281};\\\", \\\"{x:1600,y:444,t:1526929921298};\\\", \\\"{x:1605,y:434,t:1526929921314};\\\", \\\"{x:1610,y:426,t:1526929921331};\\\", \\\"{x:1615,y:419,t:1526929921348};\\\", \\\"{x:1620,y:413,t:1526929921365};\\\", \\\"{x:1621,y:411,t:1526929921380};\\\", \\\"{x:1622,y:409,t:1526929921397};\\\", \\\"{x:1619,y:413,t:1526929921829};\\\", \\\"{x:1612,y:421,t:1526929921836};\\\", \\\"{x:1604,y:431,t:1526929921847};\\\", \\\"{x:1587,y:451,t:1526929921864};\\\", \\\"{x:1573,y:471,t:1526929921881};\\\", \\\"{x:1560,y:487,t:1526929921898};\\\", \\\"{x:1552,y:501,t:1526929921915};\\\", \\\"{x:1546,y:513,t:1526929921931};\\\", \\\"{x:1544,y:522,t:1526929921949};\\\", \\\"{x:1541,y:530,t:1526929921965};\\\", \\\"{x:1536,y:542,t:1526929921981};\\\", \\\"{x:1532,y:549,t:1526929921998};\\\", \\\"{x:1530,y:553,t:1526929922014};\\\", \\\"{x:1530,y:554,t:1526929922031};\\\", \\\"{x:1529,y:556,t:1526929922048};\\\", \\\"{x:1529,y:557,t:1526929922108};\\\", \\\"{x:1529,y:558,t:1526929922261};\\\", \\\"{x:1529,y:559,t:1526929922285};\\\", \\\"{x:1529,y:560,t:1526929922358};\\\", \\\"{x:1529,y:561,t:1526929922365};\\\", \\\"{x:1529,y:567,t:1526929922382};\\\", \\\"{x:1531,y:573,t:1526929922399};\\\", \\\"{x:1531,y:579,t:1526929922416};\\\", \\\"{x:1533,y:585,t:1526929922432};\\\", \\\"{x:1533,y:589,t:1526929922449};\\\", \\\"{x:1533,y:590,t:1526929922465};\\\", \\\"{x:1533,y:592,t:1526929922482};\\\", \\\"{x:1534,y:596,t:1526929922499};\\\", \\\"{x:1534,y:597,t:1526929922515};\\\", \\\"{x:1534,y:599,t:1526929922531};\\\", \\\"{x:1534,y:601,t:1526929922549};\\\", \\\"{x:1534,y:605,t:1526929922565};\\\", \\\"{x:1534,y:606,t:1526929922589};\\\", \\\"{x:1534,y:608,t:1526929922629};\\\", \\\"{x:1534,y:609,t:1526929922637};\\\", \\\"{x:1533,y:610,t:1526929922648};\\\", \\\"{x:1528,y:613,t:1526929922665};\\\", \\\"{x:1520,y:616,t:1526929922681};\\\", \\\"{x:1518,y:617,t:1526929922699};\\\", \\\"{x:1517,y:618,t:1526929922742};\\\", \\\"{x:1516,y:618,t:1526929922773};\\\", \\\"{x:1514,y:618,t:1526929922789};\\\", \\\"{x:1514,y:620,t:1526929922799};\\\", \\\"{x:1513,y:620,t:1526929922821};\\\", \\\"{x:1512,y:621,t:1526929922916};\\\", \\\"{x:1496,y:621,t:1526929922932};\\\", \\\"{x:1443,y:621,t:1526929922948};\\\", \\\"{x:1356,y:621,t:1526929922965};\\\", \\\"{x:1265,y:621,t:1526929922982};\\\", \\\"{x:1147,y:629,t:1526929922998};\\\", \\\"{x:1037,y:641,t:1526929923015};\\\", \\\"{x:949,y:647,t:1526929923032};\\\", \\\"{x:929,y:647,t:1526929923048};\\\", \\\"{x:908,y:648,t:1526929923065};\\\", \\\"{x:894,y:647,t:1526929923082};\\\", \\\"{x:867,y:654,t:1526929923098};\\\", \\\"{x:816,y:664,t:1526929923115};\\\", \\\"{x:727,y:664,t:1526929923132};\\\", \\\"{x:684,y:664,t:1526929923148};\\\", \\\"{x:655,y:662,t:1526929923165};\\\", \\\"{x:624,y:656,t:1526929923183};\\\", \\\"{x:602,y:656,t:1526929923198};\\\", \\\"{x:588,y:657,t:1526929923216};\\\", \\\"{x:574,y:658,t:1526929923232};\\\", \\\"{x:564,y:658,t:1526929923250};\\\", \\\"{x:548,y:658,t:1526929923266};\\\", \\\"{x:527,y:658,t:1526929923283};\\\", \\\"{x:504,y:658,t:1526929923299};\\\", \\\"{x:486,y:658,t:1526929923316};\\\", \\\"{x:474,y:655,t:1526929923333};\\\", \\\"{x:467,y:650,t:1526929923351};\\\", \\\"{x:459,y:647,t:1526929923365};\\\", \\\"{x:449,y:640,t:1526929923382};\\\", \\\"{x:443,y:636,t:1526929923391};\\\", \\\"{x:427,y:630,t:1526929923407};\\\", \\\"{x:412,y:622,t:1526929923424};\\\", \\\"{x:401,y:616,t:1526929923442};\\\", \\\"{x:398,y:613,t:1526929923457};\\\", \\\"{x:397,y:613,t:1526929923482};\\\", \\\"{x:395,y:611,t:1526929923500};\\\", \\\"{x:393,y:610,t:1526929923515};\\\", \\\"{x:389,y:609,t:1526929923532};\\\", \\\"{x:387,y:608,t:1526929923550};\\\", \\\"{x:387,y:607,t:1526929923589};\\\", \\\"{x:387,y:606,t:1526929923600};\\\", \\\"{x:387,y:604,t:1526929923621};\\\", \\\"{x:387,y:603,t:1526929923636};\\\", \\\"{x:387,y:601,t:1526929923661};\\\", \\\"{x:389,y:602,t:1526929923812};\\\", \\\"{x:395,y:607,t:1526929923820};\\\", \\\"{x:406,y:615,t:1526929923833};\\\", \\\"{x:429,y:632,t:1526929923849};\\\", \\\"{x:458,y:655,t:1526929923866};\\\", \\\"{x:478,y:675,t:1526929923883};\\\", \\\"{x:486,y:684,t:1526929923899};\\\", \\\"{x:487,y:686,t:1526929923916};\\\", \\\"{x:488,y:687,t:1526929923933};\\\", \\\"{x:489,y:687,t:1526929923949};\\\", \\\"{x:490,y:687,t:1526929923966};\\\", \\\"{x:491,y:689,t:1526929923989};\\\", \\\"{x:493,y:690,t:1526929924028};\\\", \\\"{x:493,y:691,t:1526929924037};\\\", \\\"{x:495,y:693,t:1526929924049};\\\", \\\"{x:496,y:696,t:1526929924066};\\\", \\\"{x:497,y:697,t:1526929924084};\\\", \\\"{x:498,y:698,t:1526929924101};\\\", \\\"{x:500,y:699,t:1526929924116};\\\", \\\"{x:502,y:700,t:1526929924133};\\\", \\\"{x:503,y:702,t:1526929924150};\\\", \\\"{x:505,y:706,t:1526929924166};\\\", \\\"{x:506,y:709,t:1526929924183};\\\", \\\"{x:506,y:711,t:1526929924200};\\\", \\\"{x:506,y:712,t:1526929924661};\\\", \\\"{x:510,y:712,t:1526929924669};\\\", \\\"{x:512,y:713,t:1526929924683};\\\", \\\"{x:516,y:711,t:1526929924701};\\\", \\\"{x:523,y:710,t:1526929924716};\\\", \\\"{x:537,y:709,t:1526929924733};\\\", \\\"{x:557,y:707,t:1526929924750};\\\", \\\"{x:603,y:703,t:1526929924767};\\\", \\\"{x:675,y:696,t:1526929924783};\\\", \\\"{x:759,y:690,t:1526929924800};\\\", \\\"{x:848,y:690,t:1526929924817};\\\", \\\"{x:923,y:690,t:1526929924833};\\\", \\\"{x:979,y:690,t:1526929924850};\\\", \\\"{x:1011,y:690,t:1526929924867};\\\", \\\"{x:1033,y:690,t:1526929924883};\\\", \\\"{x:1042,y:690,t:1526929924900};\\\", \\\"{x:1044,y:690,t:1526929924917};\\\", \\\"{x:1044,y:689,t:1526929924949};\\\", \\\"{x:1045,y:688,t:1526929924957};\\\", \\\"{x:1046,y:688,t:1526929925005};\\\", \\\"{x:1047,y:688,t:1526929925021};\\\", \\\"{x:1048,y:688,t:1526929925053};\\\", \\\"{x:1048,y:687,t:1526929925124};\\\", \\\"{x:1048,y:686,t:1526929925148};\\\", \\\"{x:1048,y:685,t:1526929925156};\\\", \\\"{x:1048,y:684,t:1526929925204};\\\", \\\"{x:1048,y:683,t:1526929925308};\\\" ] }, { \\\"rt\\\": 70472, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 358980, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A -C -C -10 AM-K -U -1-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1049,y:682,t:1526929925628};\\\", \\\"{x:1049,y:681,t:1526929927046};\\\", \\\"{x:1049,y:680,t:1526929927301};\\\", \\\"{x:1053,y:677,t:1526929927309};\\\", \\\"{x:1063,y:673,t:1526929927319};\\\", \\\"{x:1077,y:670,t:1526929927336};\\\", \\\"{x:1091,y:665,t:1526929927353};\\\", \\\"{x:1099,y:662,t:1526929927369};\\\", \\\"{x:1104,y:660,t:1526929927385};\\\", \\\"{x:1109,y:657,t:1526929927402};\\\", \\\"{x:1110,y:657,t:1526929927419};\\\", \\\"{x:1111,y:656,t:1526929927435};\\\", \\\"{x:1117,y:656,t:1526929927452};\\\", \\\"{x:1129,y:656,t:1526929927468};\\\", \\\"{x:1140,y:656,t:1526929927486};\\\", \\\"{x:1147,y:655,t:1526929927502};\\\", \\\"{x:1161,y:655,t:1526929927520};\\\", \\\"{x:1173,y:659,t:1526929927536};\\\", \\\"{x:1186,y:662,t:1526929927553};\\\", \\\"{x:1194,y:664,t:1526929927570};\\\", \\\"{x:1203,y:667,t:1526929927586};\\\", \\\"{x:1209,y:668,t:1526929927603};\\\", \\\"{x:1209,y:669,t:1526929927748};\\\", \\\"{x:1209,y:670,t:1526929927796};\\\", \\\"{x:1212,y:670,t:1526929927892};\\\", \\\"{x:1224,y:670,t:1526929927902};\\\", \\\"{x:1250,y:670,t:1526929927919};\\\", \\\"{x:1287,y:669,t:1526929927935};\\\", \\\"{x:1323,y:663,t:1526929927952};\\\", \\\"{x:1352,y:661,t:1526929927969};\\\", \\\"{x:1384,y:658,t:1526929927986};\\\", \\\"{x:1415,y:652,t:1526929928002};\\\", \\\"{x:1445,y:645,t:1526929928019};\\\", \\\"{x:1495,y:638,t:1526929928036};\\\", \\\"{x:1523,y:635,t:1526929928052};\\\", \\\"{x:1537,y:632,t:1526929928069};\\\", \\\"{x:1548,y:631,t:1526929928087};\\\", \\\"{x:1552,y:631,t:1526929928102};\\\", \\\"{x:1557,y:631,t:1526929928119};\\\", \\\"{x:1563,y:631,t:1526929928136};\\\", \\\"{x:1570,y:631,t:1526929928153};\\\", \\\"{x:1578,y:631,t:1526929928169};\\\", \\\"{x:1585,y:631,t:1526929928187};\\\", \\\"{x:1589,y:629,t:1526929928203};\\\", \\\"{x:1590,y:629,t:1526929928219};\\\", \\\"{x:1591,y:629,t:1526929928237};\\\", \\\"{x:1592,y:629,t:1526929928261};\\\", \\\"{x:1593,y:629,t:1526929928301};\\\", \\\"{x:1594,y:628,t:1526929928309};\\\", \\\"{x:1595,y:627,t:1526929929101};\\\", \\\"{x:1593,y:627,t:1526929929117};\\\", \\\"{x:1592,y:627,t:1526929929132};\\\", \\\"{x:1590,y:625,t:1526929929149};\\\", \\\"{x:1588,y:624,t:1526929929381};\\\", \\\"{x:1588,y:623,t:1526929931917};\\\", \\\"{x:1589,y:618,t:1526929931924};\\\", \\\"{x:1593,y:613,t:1526929931939};\\\", \\\"{x:1597,y:608,t:1526929931955};\\\", \\\"{x:1601,y:595,t:1526929931972};\\\", \\\"{x:1602,y:590,t:1526929931989};\\\", \\\"{x:1604,y:582,t:1526929932006};\\\", \\\"{x:1604,y:576,t:1526929932023};\\\", \\\"{x:1605,y:569,t:1526929932039};\\\", \\\"{x:1605,y:563,t:1526929932056};\\\", \\\"{x:1605,y:555,t:1526929932073};\\\", \\\"{x:1605,y:549,t:1526929932088};\\\", \\\"{x:1605,y:542,t:1526929932106};\\\", \\\"{x:1599,y:526,t:1526929932123};\\\", \\\"{x:1591,y:507,t:1526929932138};\\\", \\\"{x:1583,y:484,t:1526929932155};\\\", \\\"{x:1571,y:456,t:1526929932173};\\\", \\\"{x:1564,y:441,t:1526929932189};\\\", \\\"{x:1553,y:427,t:1526929932205};\\\", \\\"{x:1543,y:416,t:1526929932222};\\\", \\\"{x:1534,y:402,t:1526929932239};\\\", \\\"{x:1522,y:390,t:1526929932257};\\\", \\\"{x:1513,y:377,t:1526929932273};\\\", \\\"{x:1505,y:371,t:1526929932289};\\\", \\\"{x:1501,y:365,t:1526929932306};\\\", \\\"{x:1499,y:360,t:1526929932322};\\\", \\\"{x:1495,y:354,t:1526929932339};\\\", \\\"{x:1488,y:346,t:1526929932356};\\\", \\\"{x:1478,y:336,t:1526929932372};\\\", \\\"{x:1475,y:332,t:1526929932390};\\\", \\\"{x:1471,y:330,t:1526929932406};\\\", \\\"{x:1470,y:329,t:1526929932423};\\\", \\\"{x:1467,y:332,t:1526929932542};\\\", \\\"{x:1466,y:338,t:1526929932556};\\\", \\\"{x:1456,y:366,t:1526929932573};\\\", \\\"{x:1448,y:388,t:1526929932590};\\\", \\\"{x:1444,y:407,t:1526929932606};\\\", \\\"{x:1440,y:425,t:1526929932623};\\\", \\\"{x:1435,y:444,t:1526929932640};\\\", \\\"{x:1434,y:456,t:1526929932656};\\\", \\\"{x:1433,y:472,t:1526929932673};\\\", \\\"{x:1429,y:487,t:1526929932690};\\\", \\\"{x:1428,y:503,t:1526929932706};\\\", \\\"{x:1427,y:518,t:1526929932723};\\\", \\\"{x:1427,y:533,t:1526929932740};\\\", \\\"{x:1427,y:548,t:1526929932757};\\\", \\\"{x:1429,y:556,t:1526929932773};\\\", \\\"{x:1431,y:561,t:1526929932790};\\\", \\\"{x:1431,y:563,t:1526929932807};\\\", \\\"{x:1431,y:565,t:1526929933077};\\\", \\\"{x:1429,y:566,t:1526929933090};\\\", \\\"{x:1421,y:568,t:1526929933107};\\\", \\\"{x:1412,y:571,t:1526929933123};\\\", \\\"{x:1404,y:572,t:1526929933141};\\\", \\\"{x:1401,y:573,t:1526929933157};\\\", \\\"{x:1400,y:573,t:1526929933197};\\\", \\\"{x:1400,y:574,t:1526929933596};\\\", \\\"{x:1400,y:575,t:1526929933645};\\\", \\\"{x:1400,y:577,t:1526929933717};\\\", \\\"{x:1401,y:578,t:1526929933805};\\\", \\\"{x:1402,y:578,t:1526929933829};\\\", \\\"{x:1402,y:580,t:1526929933841};\\\", \\\"{x:1402,y:584,t:1526929933857};\\\", \\\"{x:1402,y:588,t:1526929933874};\\\", \\\"{x:1403,y:596,t:1526929933891};\\\", \\\"{x:1403,y:603,t:1526929933907};\\\", \\\"{x:1403,y:611,t:1526929933924};\\\", \\\"{x:1403,y:621,t:1526929933941};\\\", \\\"{x:1403,y:627,t:1526929933957};\\\", \\\"{x:1403,y:630,t:1526929933974};\\\", \\\"{x:1403,y:634,t:1526929933991};\\\", \\\"{x:1403,y:636,t:1526929934007};\\\", \\\"{x:1403,y:639,t:1526929934024};\\\", \\\"{x:1402,y:646,t:1526929934041};\\\", \\\"{x:1393,y:657,t:1526929934057};\\\", \\\"{x:1382,y:672,t:1526929934074};\\\", \\\"{x:1370,y:692,t:1526929934091};\\\", \\\"{x:1349,y:717,t:1526929934107};\\\", \\\"{x:1331,y:737,t:1526929934125};\\\", \\\"{x:1311,y:760,t:1526929934141};\\\", \\\"{x:1303,y:771,t:1526929934157};\\\", \\\"{x:1296,y:780,t:1526929934174};\\\", \\\"{x:1291,y:786,t:1526929934190};\\\", \\\"{x:1285,y:794,t:1526929934207};\\\", \\\"{x:1282,y:799,t:1526929934224};\\\", \\\"{x:1281,y:800,t:1526929934240};\\\", \\\"{x:1279,y:802,t:1526929934308};\\\", \\\"{x:1277,y:803,t:1526929934323};\\\", \\\"{x:1271,y:807,t:1526929934340};\\\", \\\"{x:1260,y:813,t:1526929934358};\\\", \\\"{x:1248,y:819,t:1526929934373};\\\", \\\"{x:1238,y:824,t:1526929934391};\\\", \\\"{x:1233,y:827,t:1526929934408};\\\", \\\"{x:1229,y:828,t:1526929934423};\\\", \\\"{x:1229,y:829,t:1526929934440};\\\", \\\"{x:1228,y:829,t:1526929934457};\\\", \\\"{x:1227,y:829,t:1526929934685};\\\", \\\"{x:1226,y:829,t:1526929934732};\\\", \\\"{x:1224,y:829,t:1526929934748};\\\", \\\"{x:1223,y:829,t:1526929934772};\\\", \\\"{x:1221,y:829,t:1526929934893};\\\", \\\"{x:1220,y:829,t:1526929934935};\\\", \\\"{x:1218,y:829,t:1526929934964};\\\", \\\"{x:1218,y:830,t:1526929939104};\\\", \\\"{x:1218,y:835,t:1526929939115};\\\", \\\"{x:1220,y:849,t:1526929939131};\\\", \\\"{x:1224,y:864,t:1526929939147};\\\", \\\"{x:1228,y:877,t:1526929939164};\\\", \\\"{x:1232,y:890,t:1526929939181};\\\", \\\"{x:1234,y:899,t:1526929939197};\\\", \\\"{x:1235,y:905,t:1526929939214};\\\", \\\"{x:1237,y:910,t:1526929939232};\\\", \\\"{x:1237,y:913,t:1526929939247};\\\", \\\"{x:1238,y:916,t:1526929939264};\\\", \\\"{x:1238,y:920,t:1526929939281};\\\", \\\"{x:1238,y:924,t:1526929939297};\\\", \\\"{x:1238,y:926,t:1526929939314};\\\", \\\"{x:1237,y:932,t:1526929939331};\\\", \\\"{x:1236,y:941,t:1526929939348};\\\", \\\"{x:1235,y:946,t:1526929939364};\\\", \\\"{x:1232,y:953,t:1526929939381};\\\", \\\"{x:1231,y:956,t:1526929939397};\\\", \\\"{x:1231,y:959,t:1526929939414};\\\", \\\"{x:1231,y:961,t:1526929939432};\\\", \\\"{x:1229,y:962,t:1526929939448};\\\", \\\"{x:1229,y:963,t:1526929939464};\\\", \\\"{x:1228,y:965,t:1526929939481};\\\", \\\"{x:1227,y:967,t:1526929939498};\\\", \\\"{x:1226,y:968,t:1526929939514};\\\", \\\"{x:1225,y:968,t:1526929939735};\\\", \\\"{x:1225,y:967,t:1526929939775};\\\", \\\"{x:1225,y:966,t:1526929940976};\\\", \\\"{x:1224,y:965,t:1526929941129};\\\", \\\"{x:1223,y:964,t:1526929941793};\\\", \\\"{x:1220,y:962,t:1526929941801};\\\", \\\"{x:1202,y:947,t:1526929941816};\\\", \\\"{x:1163,y:918,t:1526929941834};\\\", \\\"{x:1082,y:865,t:1526929941850};\\\", \\\"{x:979,y:807,t:1526929941867};\\\", \\\"{x:863,y:739,t:1526929941883};\\\", \\\"{x:755,y:682,t:1526929941900};\\\", \\\"{x:656,y:623,t:1526929941917};\\\", \\\"{x:574,y:576,t:1526929941934};\\\", \\\"{x:515,y:544,t:1526929941950};\\\", \\\"{x:450,y:508,t:1526929941968};\\\", \\\"{x:422,y:496,t:1526929941984};\\\", \\\"{x:405,y:490,t:1526929942000};\\\", \\\"{x:397,y:487,t:1526929942017};\\\", \\\"{x:394,y:486,t:1526929942034};\\\", \\\"{x:392,y:485,t:1526929942050};\\\", \\\"{x:388,y:483,t:1526929942068};\\\", \\\"{x:387,y:483,t:1526929942084};\\\", \\\"{x:384,y:484,t:1526929942127};\\\", \\\"{x:383,y:487,t:1526929942135};\\\", \\\"{x:382,y:491,t:1526929942151};\\\", \\\"{x:380,y:501,t:1526929942167};\\\", \\\"{x:379,y:507,t:1526929942184};\\\", \\\"{x:379,y:513,t:1526929942201};\\\", \\\"{x:378,y:517,t:1526929942217};\\\", \\\"{x:378,y:518,t:1526929942235};\\\", \\\"{x:378,y:520,t:1526929942251};\\\", \\\"{x:378,y:521,t:1526929942267};\\\", \\\"{x:378,y:522,t:1526929942295};\\\", \\\"{x:378,y:524,t:1526929942312};\\\", \\\"{x:378,y:525,t:1526929942320};\\\", \\\"{x:378,y:526,t:1526929942334};\\\", \\\"{x:379,y:531,t:1526929942352};\\\", \\\"{x:380,y:532,t:1526929942368};\\\", \\\"{x:380,y:534,t:1526929942384};\\\", \\\"{x:381,y:536,t:1526929942401};\\\", \\\"{x:382,y:536,t:1526929942465};\\\", \\\"{x:383,y:536,t:1526929942513};\\\", \\\"{x:385,y:536,t:1526929942520};\\\", \\\"{x:387,y:536,t:1526929942535};\\\", \\\"{x:392,y:527,t:1526929942553};\\\", \\\"{x:392,y:522,t:1526929942568};\\\", \\\"{x:394,y:520,t:1526929942584};\\\", \\\"{x:394,y:519,t:1526929942602};\\\", \\\"{x:401,y:517,t:1526929942831};\\\", \\\"{x:415,y:517,t:1526929942839};\\\", \\\"{x:433,y:517,t:1526929942851};\\\", \\\"{x:472,y:522,t:1526929942868};\\\", \\\"{x:518,y:529,t:1526929942885};\\\", \\\"{x:563,y:543,t:1526929942902};\\\", \\\"{x:592,y:552,t:1526929942919};\\\", \\\"{x:609,y:557,t:1526929942935};\\\", \\\"{x:614,y:560,t:1526929942951};\\\", \\\"{x:616,y:560,t:1526929943295};\\\", \\\"{x:621,y:561,t:1526929943303};\\\", \\\"{x:626,y:562,t:1526929943318};\\\", \\\"{x:646,y:567,t:1526929943336};\\\", \\\"{x:673,y:570,t:1526929943352};\\\", \\\"{x:704,y:575,t:1526929943368};\\\", \\\"{x:732,y:578,t:1526929943385};\\\", \\\"{x:754,y:582,t:1526929943402};\\\", \\\"{x:767,y:584,t:1526929943418};\\\", \\\"{x:774,y:587,t:1526929943436};\\\", \\\"{x:775,y:587,t:1526929943455};\\\", \\\"{x:777,y:587,t:1526929943479};\\\", \\\"{x:778,y:588,t:1526929943495};\\\", \\\"{x:779,y:589,t:1526929943504};\\\", \\\"{x:780,y:590,t:1526929943518};\\\", \\\"{x:791,y:598,t:1526929943535};\\\", \\\"{x:809,y:603,t:1526929943552};\\\", \\\"{x:837,y:607,t:1526929943569};\\\", \\\"{x:911,y:610,t:1526929943585};\\\", \\\"{x:992,y:612,t:1526929943602};\\\", \\\"{x:1092,y:614,t:1526929943618};\\\", \\\"{x:1203,y:630,t:1526929943635};\\\", \\\"{x:1300,y:641,t:1526929943653};\\\", \\\"{x:1343,y:648,t:1526929943668};\\\", \\\"{x:1374,y:657,t:1526929943685};\\\", \\\"{x:1390,y:666,t:1526929943702};\\\", \\\"{x:1396,y:671,t:1526929943719};\\\", \\\"{x:1396,y:685,t:1526929943735};\\\", \\\"{x:1395,y:699,t:1526929943752};\\\", \\\"{x:1388,y:712,t:1526929943769};\\\", \\\"{x:1382,y:727,t:1526929943785};\\\", \\\"{x:1377,y:739,t:1526929943803};\\\", \\\"{x:1374,y:747,t:1526929943818};\\\", \\\"{x:1369,y:756,t:1526929943835};\\\", \\\"{x:1361,y:768,t:1526929943852};\\\", \\\"{x:1354,y:778,t:1526929943868};\\\", \\\"{x:1349,y:786,t:1526929943886};\\\", \\\"{x:1344,y:792,t:1526929943902};\\\", \\\"{x:1341,y:794,t:1526929943919};\\\", \\\"{x:1338,y:794,t:1526929943936};\\\", \\\"{x:1326,y:796,t:1526929943952};\\\", \\\"{x:1310,y:802,t:1526929943968};\\\", \\\"{x:1291,y:810,t:1526929943986};\\\", \\\"{x:1276,y:814,t:1526929944003};\\\", \\\"{x:1272,y:815,t:1526929944019};\\\", \\\"{x:1270,y:815,t:1526929944036};\\\", \\\"{x:1269,y:815,t:1526929944064};\\\", \\\"{x:1264,y:816,t:1526929944072};\\\", \\\"{x:1260,y:816,t:1526929944086};\\\", \\\"{x:1250,y:820,t:1526929944103};\\\", \\\"{x:1242,y:822,t:1526929944119};\\\", \\\"{x:1224,y:829,t:1526929944135};\\\", \\\"{x:1214,y:830,t:1526929944153};\\\", \\\"{x:1208,y:833,t:1526929944169};\\\", \\\"{x:1206,y:833,t:1526929944185};\\\", \\\"{x:1205,y:833,t:1526929944216};\\\", \\\"{x:1204,y:833,t:1526929944264};\\\", \\\"{x:1206,y:832,t:1526929944592};\\\", \\\"{x:1207,y:832,t:1526929944603};\\\", \\\"{x:1209,y:831,t:1526929944621};\\\", \\\"{x:1210,y:830,t:1526929944636};\\\", \\\"{x:1211,y:830,t:1526929944653};\\\", \\\"{x:1211,y:829,t:1526929945265};\\\", \\\"{x:1212,y:829,t:1526929945336};\\\", \\\"{x:1213,y:830,t:1526929945425};\\\", \\\"{x:1213,y:832,t:1526929945440};\\\", \\\"{x:1213,y:834,t:1526929945452};\\\", \\\"{x:1213,y:840,t:1526929945469};\\\", \\\"{x:1211,y:851,t:1526929945486};\\\", \\\"{x:1208,y:863,t:1526929945503};\\\", \\\"{x:1206,y:875,t:1526929945519};\\\", \\\"{x:1206,y:882,t:1526929945536};\\\", \\\"{x:1206,y:888,t:1526929945552};\\\", \\\"{x:1206,y:895,t:1526929945569};\\\", \\\"{x:1204,y:902,t:1526929945586};\\\", \\\"{x:1204,y:908,t:1526929945602};\\\", \\\"{x:1204,y:913,t:1526929945619};\\\", \\\"{x:1204,y:915,t:1526929945637};\\\", \\\"{x:1204,y:917,t:1526929945652};\\\", \\\"{x:1204,y:919,t:1526929945669};\\\", \\\"{x:1204,y:923,t:1526929945687};\\\", \\\"{x:1204,y:927,t:1526929945703};\\\", \\\"{x:1204,y:932,t:1526929945720};\\\", \\\"{x:1204,y:934,t:1526929945736};\\\", \\\"{x:1204,y:937,t:1526929945753};\\\", \\\"{x:1204,y:939,t:1526929945769};\\\", \\\"{x:1204,y:944,t:1526929945786};\\\", \\\"{x:1204,y:950,t:1526929945802};\\\", \\\"{x:1204,y:955,t:1526929945819};\\\", \\\"{x:1204,y:959,t:1526929945836};\\\", \\\"{x:1204,y:961,t:1526929945852};\\\", \\\"{x:1204,y:962,t:1526929945870};\\\", \\\"{x:1204,y:964,t:1526929945903};\\\", \\\"{x:1204,y:965,t:1526929945927};\\\", \\\"{x:1204,y:967,t:1526929945943};\\\", \\\"{x:1204,y:968,t:1526929945975};\\\", \\\"{x:1205,y:970,t:1526929946025};\\\", \\\"{x:1206,y:970,t:1526929946240};\\\", \\\"{x:1207,y:970,t:1526929949184};\\\", \\\"{x:1209,y:970,t:1526929949263};\\\", \\\"{x:1210,y:969,t:1526929949311};\\\", \\\"{x:1210,y:968,t:1526929949322};\\\", \\\"{x:1212,y:968,t:1526929949400};\\\", \\\"{x:1213,y:967,t:1526929949432};\\\", \\\"{x:1214,y:967,t:1526929949601};\\\", \\\"{x:1215,y:967,t:1526929949608};\\\", \\\"{x:1215,y:966,t:1526929949624};\\\", \\\"{x:1216,y:965,t:1526929949665};\\\", \\\"{x:1218,y:965,t:1526929949825};\\\", \\\"{x:1219,y:965,t:1526929950281};\\\", \\\"{x:1220,y:964,t:1526929950369};\\\", \\\"{x:1223,y:962,t:1526929950776};\\\", \\\"{x:1223,y:961,t:1526929950789};\\\", \\\"{x:1225,y:959,t:1526929950805};\\\", \\\"{x:1229,y:953,t:1526929950822};\\\", \\\"{x:1233,y:945,t:1526929950839};\\\", \\\"{x:1236,y:940,t:1526929950856};\\\", \\\"{x:1240,y:931,t:1526929950872};\\\", \\\"{x:1244,y:923,t:1526929950890};\\\", \\\"{x:1247,y:916,t:1526929950906};\\\", \\\"{x:1250,y:909,t:1526929950922};\\\", \\\"{x:1251,y:905,t:1526929950939};\\\", \\\"{x:1252,y:902,t:1526929950955};\\\", \\\"{x:1252,y:901,t:1526929950972};\\\", \\\"{x:1252,y:899,t:1526929950990};\\\", \\\"{x:1252,y:898,t:1526929951007};\\\", \\\"{x:1252,y:897,t:1526929951022};\\\", \\\"{x:1252,y:895,t:1526929951039};\\\", \\\"{x:1254,y:892,t:1526929951056};\\\", \\\"{x:1255,y:888,t:1526929951072};\\\", \\\"{x:1255,y:886,t:1526929951089};\\\", \\\"{x:1256,y:885,t:1526929951107};\\\", \\\"{x:1256,y:884,t:1526929951122};\\\", \\\"{x:1257,y:884,t:1526929951139};\\\", \\\"{x:1257,y:883,t:1526929951156};\\\", \\\"{x:1257,y:882,t:1526929951984};\\\", \\\"{x:1256,y:883,t:1526929952008};\\\", \\\"{x:1255,y:883,t:1526929952023};\\\", \\\"{x:1254,y:885,t:1526929952039};\\\", \\\"{x:1254,y:886,t:1526929952112};\\\", \\\"{x:1254,y:887,t:1526929952136};\\\", \\\"{x:1253,y:888,t:1526929952144};\\\", \\\"{x:1252,y:889,t:1526929952231};\\\", \\\"{x:1252,y:890,t:1526929952263};\\\", \\\"{x:1252,y:891,t:1526929952287};\\\", \\\"{x:1251,y:891,t:1526929952311};\\\", \\\"{x:1251,y:892,t:1526929952336};\\\", \\\"{x:1251,y:893,t:1526929952352};\\\", \\\"{x:1251,y:894,t:1526929952359};\\\", \\\"{x:1250,y:895,t:1526929952416};\\\", \\\"{x:1250,y:896,t:1526929953337};\\\", \\\"{x:1250,y:897,t:1526929953616};\\\", \\\"{x:1249,y:899,t:1526929953705};\\\", \\\"{x:1248,y:899,t:1526929956121};\\\", \\\"{x:1248,y:898,t:1526929956128};\\\", \\\"{x:1248,y:895,t:1526929956141};\\\", \\\"{x:1249,y:886,t:1526929956158};\\\", \\\"{x:1250,y:875,t:1526929956175};\\\", \\\"{x:1253,y:855,t:1526929956190};\\\", \\\"{x:1261,y:827,t:1526929956207};\\\", \\\"{x:1268,y:807,t:1526929956224};\\\", \\\"{x:1277,y:788,t:1526929956241};\\\", \\\"{x:1285,y:763,t:1526929956258};\\\", \\\"{x:1293,y:741,t:1526929956273};\\\", \\\"{x:1299,y:718,t:1526929956291};\\\", \\\"{x:1307,y:690,t:1526929956308};\\\", \\\"{x:1313,y:670,t:1526929956324};\\\", \\\"{x:1316,y:663,t:1526929956341};\\\", \\\"{x:1326,y:652,t:1526929962872};\\\", \\\"{x:1366,y:635,t:1526929962881};\\\", \\\"{x:1403,y:624,t:1526929962895};\\\", \\\"{x:1448,y:611,t:1526929962911};\\\", \\\"{x:1462,y:609,t:1526929962928};\\\", \\\"{x:1464,y:609,t:1526929962968};\\\", \\\"{x:1467,y:609,t:1526929962984};\\\", \\\"{x:1468,y:609,t:1526929962995};\\\", \\\"{x:1471,y:609,t:1526929963011};\\\", \\\"{x:1479,y:612,t:1526929963028};\\\", \\\"{x:1484,y:614,t:1526929963045};\\\", \\\"{x:1488,y:616,t:1526929963061};\\\", \\\"{x:1493,y:619,t:1526929963078};\\\", \\\"{x:1501,y:623,t:1526929963094};\\\", \\\"{x:1517,y:629,t:1526929963111};\\\", \\\"{x:1537,y:634,t:1526929963129};\\\", \\\"{x:1545,y:637,t:1526929963144};\\\", \\\"{x:1549,y:639,t:1526929963160};\\\", \\\"{x:1552,y:640,t:1526929963178};\\\", \\\"{x:1554,y:642,t:1526929963592};\\\", \\\"{x:1557,y:643,t:1526929963600};\\\", \\\"{x:1559,y:646,t:1526929963612};\\\", \\\"{x:1564,y:656,t:1526929963628};\\\", \\\"{x:1565,y:668,t:1526929963645};\\\", \\\"{x:1562,y:680,t:1526929963662};\\\", \\\"{x:1552,y:694,t:1526929963677};\\\", \\\"{x:1544,y:705,t:1526929963695};\\\", \\\"{x:1540,y:713,t:1526929963711};\\\", \\\"{x:1537,y:722,t:1526929963727};\\\", \\\"{x:1535,y:724,t:1526929963744};\\\", \\\"{x:1533,y:727,t:1526929963762};\\\", \\\"{x:1532,y:729,t:1526929963778};\\\", \\\"{x:1531,y:731,t:1526929963795};\\\", \\\"{x:1531,y:732,t:1526929963824};\\\", \\\"{x:1531,y:735,t:1526929963831};\\\", \\\"{x:1531,y:737,t:1526929963845};\\\", \\\"{x:1528,y:744,t:1526929963862};\\\", \\\"{x:1523,y:755,t:1526929963878};\\\", \\\"{x:1516,y:769,t:1526929963895};\\\", \\\"{x:1506,y:787,t:1526929963912};\\\", \\\"{x:1501,y:795,t:1526929963928};\\\", \\\"{x:1496,y:806,t:1526929963945};\\\", \\\"{x:1493,y:810,t:1526929963962};\\\", \\\"{x:1490,y:814,t:1526929963978};\\\", \\\"{x:1488,y:815,t:1526929963995};\\\", \\\"{x:1487,y:817,t:1526929964012};\\\", \\\"{x:1485,y:819,t:1526929964028};\\\", \\\"{x:1476,y:824,t:1526929964045};\\\", \\\"{x:1466,y:827,t:1526929964062};\\\", \\\"{x:1456,y:832,t:1526929964078};\\\", \\\"{x:1447,y:836,t:1526929964095};\\\", \\\"{x:1442,y:839,t:1526929964112};\\\", \\\"{x:1441,y:841,t:1526929964127};\\\", \\\"{x:1441,y:843,t:1526929964145};\\\", \\\"{x:1439,y:846,t:1526929964162};\\\", \\\"{x:1439,y:848,t:1526929964178};\\\", \\\"{x:1438,y:849,t:1526929964195};\\\", \\\"{x:1438,y:850,t:1526929964212};\\\", \\\"{x:1444,y:853,t:1526929964228};\\\", \\\"{x:1473,y:853,t:1526929964245};\\\", \\\"{x:1479,y:854,t:1526929964261};\\\", \\\"{x:1478,y:854,t:1526929964840};\\\", \\\"{x:1477,y:854,t:1526929964856};\\\", \\\"{x:1474,y:854,t:1526929964864};\\\", \\\"{x:1472,y:854,t:1526929964888};\\\", \\\"{x:1471,y:854,t:1526929964912};\\\", \\\"{x:1469,y:854,t:1526929964929};\\\", \\\"{x:1468,y:853,t:1526929964945};\\\", \\\"{x:1466,y:853,t:1526929964978};\\\", \\\"{x:1465,y:853,t:1526929964983};\\\", \\\"{x:1462,y:852,t:1526929964994};\\\", \\\"{x:1458,y:850,t:1526929965011};\\\", \\\"{x:1447,y:846,t:1526929965028};\\\", \\\"{x:1436,y:844,t:1526929965044};\\\", \\\"{x:1424,y:841,t:1526929965061};\\\", \\\"{x:1411,y:840,t:1526929965078};\\\", \\\"{x:1402,y:839,t:1526929965094};\\\", \\\"{x:1390,y:837,t:1526929965111};\\\", \\\"{x:1385,y:837,t:1526929965128};\\\", \\\"{x:1381,y:837,t:1526929965145};\\\", \\\"{x:1377,y:837,t:1526929965162};\\\", \\\"{x:1373,y:837,t:1526929965178};\\\", \\\"{x:1368,y:837,t:1526929965195};\\\", \\\"{x:1364,y:837,t:1526929965211};\\\", \\\"{x:1363,y:837,t:1526929965229};\\\", \\\"{x:1361,y:837,t:1526929965245};\\\", \\\"{x:1362,y:837,t:1526929966287};\\\", \\\"{x:1363,y:837,t:1526929966416};\\\", \\\"{x:1364,y:837,t:1526929966873};\\\", \\\"{x:1365,y:837,t:1526929966911};\\\", \\\"{x:1366,y:837,t:1526929966935};\\\", \\\"{x:1367,y:836,t:1526929968048};\\\", \\\"{x:1367,y:835,t:1526929968063};\\\", \\\"{x:1367,y:834,t:1526929968080};\\\", \\\"{x:1367,y:833,t:1526929968096};\\\", \\\"{x:1367,y:832,t:1526929968113};\\\", \\\"{x:1368,y:831,t:1526929968130};\\\", \\\"{x:1369,y:831,t:1526929968456};\\\", \\\"{x:1369,y:830,t:1526929968496};\\\", \\\"{x:1369,y:829,t:1526929968536};\\\", \\\"{x:1368,y:828,t:1526929969208};\\\", \\\"{x:1364,y:828,t:1526929969216};\\\", \\\"{x:1354,y:825,t:1526929969231};\\\", \\\"{x:1291,y:800,t:1526929969247};\\\", \\\"{x:1094,y:715,t:1526929969262};\\\", \\\"{x:945,y:649,t:1526929969280};\\\", \\\"{x:804,y:587,t:1526929969297};\\\", \\\"{x:713,y:526,t:1526929969314};\\\", \\\"{x:659,y:484,t:1526929969330};\\\", \\\"{x:601,y:428,t:1526929969355};\\\", \\\"{x:572,y:411,t:1526929969373};\\\", \\\"{x:563,y:406,t:1526929969389};\\\", \\\"{x:553,y:404,t:1526929969405};\\\", \\\"{x:546,y:404,t:1526929969422};\\\", \\\"{x:542,y:405,t:1526929969438};\\\", \\\"{x:542,y:432,t:1526929969455};\\\", \\\"{x:542,y:455,t:1526929969472};\\\", \\\"{x:552,y:486,t:1526929969488};\\\", \\\"{x:568,y:518,t:1526929969506};\\\", \\\"{x:575,y:534,t:1526929969523};\\\", \\\"{x:578,y:543,t:1526929969539};\\\", \\\"{x:579,y:552,t:1526929969556};\\\", \\\"{x:580,y:556,t:1526929969572};\\\", \\\"{x:581,y:560,t:1526929969589};\\\", \\\"{x:583,y:563,t:1526929969607};\\\", \\\"{x:584,y:564,t:1526929969622};\\\", \\\"{x:584,y:565,t:1526929969655};\\\", \\\"{x:585,y:565,t:1526929969671};\\\", \\\"{x:586,y:565,t:1526929969678};\\\", \\\"{x:588,y:565,t:1526929969695};\\\", \\\"{x:589,y:567,t:1526929969706};\\\", \\\"{x:593,y:567,t:1526929969723};\\\", \\\"{x:599,y:565,t:1526929969740};\\\", \\\"{x:604,y:563,t:1526929969756};\\\", \\\"{x:608,y:561,t:1526929969773};\\\", \\\"{x:609,y:561,t:1526929969790};\\\", \\\"{x:610,y:560,t:1526929969806};\\\", \\\"{x:611,y:560,t:1526929969831};\\\", \\\"{x:612,y:560,t:1526929969841};\\\", \\\"{x:614,y:560,t:1526929969857};\\\", \\\"{x:615,y:559,t:1526929969999};\\\", \\\"{x:611,y:557,t:1526929970007};\\\", \\\"{x:587,y:553,t:1526929970023};\\\", \\\"{x:558,y:549,t:1526929970040};\\\", \\\"{x:530,y:544,t:1526929970056};\\\", \\\"{x:506,y:542,t:1526929970074};\\\", \\\"{x:489,y:539,t:1526929970090};\\\", \\\"{x:477,y:538,t:1526929970106};\\\", \\\"{x:466,y:538,t:1526929970123};\\\", \\\"{x:452,y:538,t:1526929970140};\\\", \\\"{x:438,y:537,t:1526929970157};\\\", \\\"{x:428,y:535,t:1526929970174};\\\", \\\"{x:425,y:534,t:1526929970190};\\\", \\\"{x:424,y:534,t:1526929970223};\\\", \\\"{x:423,y:534,t:1526929970241};\\\", \\\"{x:420,y:534,t:1526929970256};\\\", \\\"{x:415,y:534,t:1526929970273};\\\", \\\"{x:409,y:534,t:1526929970291};\\\", \\\"{x:404,y:534,t:1526929970307};\\\", \\\"{x:401,y:534,t:1526929970324};\\\", \\\"{x:399,y:533,t:1526929970340};\\\", \\\"{x:395,y:533,t:1526929970356};\\\", \\\"{x:390,y:530,t:1526929970375};\\\", \\\"{x:383,y:528,t:1526929970391};\\\", \\\"{x:382,y:527,t:1526929970406};\\\", \\\"{x:382,y:526,t:1526929970423};\\\", \\\"{x:383,y:526,t:1526929970639};\\\", \\\"{x:397,y:526,t:1526929970647};\\\", \\\"{x:431,y:526,t:1526929970658};\\\", \\\"{x:520,y:527,t:1526929970674};\\\", \\\"{x:655,y:544,t:1526929970691};\\\", \\\"{x:796,y:564,t:1526929970709};\\\", \\\"{x:935,y:583,t:1526929970724};\\\", \\\"{x:1051,y:601,t:1526929970741};\\\", \\\"{x:1146,y:615,t:1526929970758};\\\", \\\"{x:1215,y:623,t:1526929970773};\\\", \\\"{x:1273,y:638,t:1526929970791};\\\", \\\"{x:1345,y:655,t:1526929970807};\\\", \\\"{x:1384,y:667,t:1526929970824};\\\", \\\"{x:1414,y:676,t:1526929970841};\\\", \\\"{x:1435,y:682,t:1526929970858};\\\", \\\"{x:1449,y:686,t:1526929970874};\\\", \\\"{x:1460,y:689,t:1526929970890};\\\", \\\"{x:1475,y:690,t:1526929970908};\\\", \\\"{x:1484,y:690,t:1526929970925};\\\", \\\"{x:1485,y:690,t:1526929971111};\\\", \\\"{x:1485,y:689,t:1526929971125};\\\", \\\"{x:1485,y:688,t:1526929971140};\\\", \\\"{x:1485,y:687,t:1526929971158};\\\", \\\"{x:1487,y:687,t:1526929971231};\\\", \\\"{x:1490,y:687,t:1526929971241};\\\", \\\"{x:1495,y:687,t:1526929971258};\\\", \\\"{x:1494,y:687,t:1526929971488};\\\", \\\"{x:1493,y:687,t:1526929971511};\\\", \\\"{x:1492,y:688,t:1526929971576};\\\", \\\"{x:1491,y:690,t:1526929982344};\\\", \\\"{x:1491,y:691,t:1526929982360};\\\", \\\"{x:1491,y:692,t:1526929982375};\\\", \\\"{x:1492,y:693,t:1526929982552};\\\", \\\"{x:1492,y:694,t:1526929982632};\\\", \\\"{x:1492,y:695,t:1526929982744};\\\", \\\"{x:1492,y:696,t:1526929982977};\\\", \\\"{x:1492,y:697,t:1526929983144};\\\", \\\"{x:1491,y:697,t:1526929983159};\\\", \\\"{x:1491,y:698,t:1526929983183};\\\", \\\"{x:1490,y:699,t:1526929983200};\\\", \\\"{x:1490,y:700,t:1526929983217};\\\", \\\"{x:1489,y:701,t:1526929983233};\\\", \\\"{x:1487,y:702,t:1526929983250};\\\", \\\"{x:1485,y:703,t:1526929983266};\\\", \\\"{x:1484,y:705,t:1526929983284};\\\", \\\"{x:1483,y:706,t:1526929983301};\\\", \\\"{x:1482,y:706,t:1526929983352};\\\", \\\"{x:1480,y:707,t:1526929983416};\\\", \\\"{x:1479,y:708,t:1526929983527};\\\", \\\"{x:1479,y:709,t:1526929983584};\\\", \\\"{x:1477,y:710,t:1526929984328};\\\", \\\"{x:1477,y:711,t:1526929984344};\\\", \\\"{x:1477,y:712,t:1526929984383};\\\", \\\"{x:1476,y:715,t:1526929984401};\\\", \\\"{x:1473,y:718,t:1526929984417};\\\", \\\"{x:1472,y:718,t:1526929984435};\\\", \\\"{x:1471,y:718,t:1526929985792};\\\", \\\"{x:1470,y:718,t:1526929985803};\\\", \\\"{x:1469,y:720,t:1526929985819};\\\", \\\"{x:1467,y:721,t:1526929985836};\\\", \\\"{x:1466,y:721,t:1526929986031};\\\", \\\"{x:1464,y:721,t:1526929986038};\\\", \\\"{x:1462,y:721,t:1526929986052};\\\", \\\"{x:1455,y:722,t:1526929986068};\\\", \\\"{x:1451,y:722,t:1526929986085};\\\", \\\"{x:1445,y:723,t:1526929986102};\\\", \\\"{x:1444,y:723,t:1526929986118};\\\", \\\"{x:1443,y:724,t:1526929986167};\\\", \\\"{x:1442,y:724,t:1526929986183};\\\", \\\"{x:1441,y:724,t:1526929986191};\\\", \\\"{x:1439,y:724,t:1526929986202};\\\", \\\"{x:1436,y:724,t:1526929986219};\\\", \\\"{x:1433,y:724,t:1526929986236};\\\", \\\"{x:1431,y:724,t:1526929986253};\\\", \\\"{x:1428,y:725,t:1526929986270};\\\", \\\"{x:1427,y:725,t:1526929986286};\\\", \\\"{x:1425,y:726,t:1526929986302};\\\", \\\"{x:1424,y:726,t:1526929986456};\\\", \\\"{x:1422,y:729,t:1526929987160};\\\", \\\"{x:1420,y:732,t:1526929987176};\\\", \\\"{x:1416,y:738,t:1526929987187};\\\", \\\"{x:1410,y:745,t:1526929987204};\\\", \\\"{x:1402,y:754,t:1526929987219};\\\", \\\"{x:1396,y:761,t:1526929987237};\\\", \\\"{x:1389,y:770,t:1526929987253};\\\", \\\"{x:1378,y:777,t:1526929987270};\\\", \\\"{x:1362,y:789,t:1526929987286};\\\", \\\"{x:1305,y:814,t:1526929987303};\\\", \\\"{x:1218,y:843,t:1526929987320};\\\", \\\"{x:1126,y:870,t:1526929987337};\\\", \\\"{x:1060,y:888,t:1526929987354};\\\", \\\"{x:1019,y:898,t:1526929987370};\\\", \\\"{x:997,y:902,t:1526929987386};\\\", \\\"{x:982,y:906,t:1526929987404};\\\", \\\"{x:979,y:908,t:1526929987420};\\\", \\\"{x:977,y:910,t:1526929987436};\\\", \\\"{x:976,y:913,t:1526929987453};\\\", \\\"{x:973,y:915,t:1526929987470};\\\", \\\"{x:970,y:916,t:1526929987487};\\\", \\\"{x:960,y:918,t:1526929987503};\\\", \\\"{x:954,y:918,t:1526929987519};\\\", \\\"{x:948,y:918,t:1526929987536};\\\", \\\"{x:945,y:918,t:1526929987553};\\\", \\\"{x:939,y:918,t:1526929987569};\\\", \\\"{x:933,y:916,t:1526929987586};\\\", \\\"{x:929,y:915,t:1526929987604};\\\", \\\"{x:927,y:913,t:1526929987620};\\\", \\\"{x:924,y:913,t:1526929987976};\\\", \\\"{x:922,y:913,t:1526929987986};\\\", \\\"{x:918,y:912,t:1526929988003};\\\", \\\"{x:917,y:911,t:1526929988048};\\\", \\\"{x:917,y:910,t:1526929988104};\\\", \\\"{x:917,y:909,t:1526929988127};\\\", \\\"{x:917,y:908,t:1526929988159};\\\", \\\"{x:917,y:906,t:1526929988170};\\\", \\\"{x:917,y:900,t:1526929988188};\\\", \\\"{x:915,y:893,t:1526929988204};\\\", \\\"{x:915,y:892,t:1526929988221};\\\", \\\"{x:915,y:891,t:1526929990528};\\\", \\\"{x:919,y:891,t:1526929990544};\\\", \\\"{x:920,y:891,t:1526929990556};\\\", \\\"{x:928,y:889,t:1526929990573};\\\", \\\"{x:934,y:887,t:1526929990588};\\\", \\\"{x:943,y:886,t:1526929990605};\\\", \\\"{x:954,y:886,t:1526929990622};\\\", \\\"{x:976,y:888,t:1526929990638};\\\", \\\"{x:1028,y:895,t:1526929990655};\\\", \\\"{x:1058,y:899,t:1526929990673};\\\", \\\"{x:1084,y:901,t:1526929990690};\\\", \\\"{x:1104,y:901,t:1526929990705};\\\", \\\"{x:1121,y:902,t:1526929990722};\\\", \\\"{x:1137,y:905,t:1526929990737};\\\", \\\"{x:1144,y:909,t:1526929990755};\\\", \\\"{x:1157,y:915,t:1526929990772};\\\", \\\"{x:1166,y:921,t:1526929990788};\\\", \\\"{x:1170,y:924,t:1526929990805};\\\", \\\"{x:1172,y:926,t:1526929990822};\\\", \\\"{x:1172,y:927,t:1526929990838};\\\", \\\"{x:1172,y:929,t:1526929990886};\\\", \\\"{x:1171,y:930,t:1526929990901};\\\", \\\"{x:1169,y:931,t:1526929990910};\\\", \\\"{x:1169,y:932,t:1526929990975};\\\", \\\"{x:1167,y:933,t:1526929990988};\\\", \\\"{x:1163,y:935,t:1526929991005};\\\", \\\"{x:1149,y:941,t:1526929991022};\\\", \\\"{x:1146,y:943,t:1526929991038};\\\", \\\"{x:1145,y:944,t:1526929991055};\\\", \\\"{x:1143,y:945,t:1526929991134};\\\", \\\"{x:1142,y:946,t:1526929991142};\\\", \\\"{x:1141,y:946,t:1526929991155};\\\", \\\"{x:1138,y:948,t:1526929991172};\\\", \\\"{x:1137,y:949,t:1526929991189};\\\", \\\"{x:1135,y:950,t:1526929991204};\\\", \\\"{x:1134,y:951,t:1526929991222};\\\", \\\"{x:1133,y:953,t:1526929991238};\\\", \\\"{x:1131,y:954,t:1526929991255};\\\", \\\"{x:1129,y:955,t:1526929991271};\\\", \\\"{x:1129,y:956,t:1526929991289};\\\", \\\"{x:1129,y:955,t:1526929991406};\\\", \\\"{x:1138,y:941,t:1526929991422};\\\", \\\"{x:1154,y:916,t:1526929991439};\\\", \\\"{x:1181,y:882,t:1526929991456};\\\", \\\"{x:1203,y:840,t:1526929991471};\\\", \\\"{x:1219,y:799,t:1526929991489};\\\", \\\"{x:1227,y:770,t:1526929991506};\\\", \\\"{x:1233,y:751,t:1526929991522};\\\", \\\"{x:1235,y:735,t:1526929991539};\\\", \\\"{x:1236,y:725,t:1526929991556};\\\", \\\"{x:1236,y:719,t:1526929991572};\\\", \\\"{x:1239,y:716,t:1526929991589};\\\", \\\"{x:1239,y:715,t:1526929991679};\\\", \\\"{x:1237,y:715,t:1526929991695};\\\", \\\"{x:1235,y:717,t:1526929991707};\\\", \\\"{x:1230,y:726,t:1526929991723};\\\", \\\"{x:1226,y:740,t:1526929991740};\\\", \\\"{x:1223,y:750,t:1526929991757};\\\", \\\"{x:1221,y:758,t:1526929991773};\\\", \\\"{x:1221,y:764,t:1526929991790};\\\", \\\"{x:1221,y:767,t:1526929991806};\\\", \\\"{x:1221,y:769,t:1526929991822};\\\", \\\"{x:1221,y:770,t:1526929991879};\\\", \\\"{x:1221,y:771,t:1526929991890};\\\", \\\"{x:1221,y:772,t:1526929991911};\\\", \\\"{x:1222,y:773,t:1526929991928};\\\", \\\"{x:1222,y:774,t:1526929991939};\\\", \\\"{x:1223,y:781,t:1526929991957};\\\", \\\"{x:1226,y:800,t:1526929991973};\\\", \\\"{x:1229,y:816,t:1526929991990};\\\", \\\"{x:1236,y:843,t:1526929992007};\\\", \\\"{x:1249,y:882,t:1526929992024};\\\", \\\"{x:1257,y:909,t:1526929992040};\\\", \\\"{x:1264,y:931,t:1526929992057};\\\", \\\"{x:1272,y:948,t:1526929992074};\\\", \\\"{x:1275,y:963,t:1526929992090};\\\", \\\"{x:1278,y:972,t:1526929992107};\\\", \\\"{x:1278,y:975,t:1526929992124};\\\", \\\"{x:1279,y:976,t:1526929992140};\\\", \\\"{x:1279,y:977,t:1526929992156};\\\", \\\"{x:1279,y:978,t:1526929992199};\\\", \\\"{x:1280,y:979,t:1526929992216};\\\", \\\"{x:1280,y:980,t:1526929992223};\\\", \\\"{x:1280,y:979,t:1526929992439};\\\", \\\"{x:1281,y:978,t:1526929992463};\\\", \\\"{x:1281,y:976,t:1526929992671};\\\", \\\"{x:1281,y:975,t:1526929992704};\\\", \\\"{x:1281,y:973,t:1526929992727};\\\", \\\"{x:1281,y:972,t:1526929992776};\\\", \\\"{x:1281,y:970,t:1526929992848};\\\", \\\"{x:1282,y:970,t:1526929992863};\\\", \\\"{x:1282,y:969,t:1526929993111};\\\", \\\"{x:1282,y:967,t:1526929993144};\\\", \\\"{x:1282,y:966,t:1526929993183};\\\", \\\"{x:1282,y:964,t:1526929994598};\\\", \\\"{x:1282,y:962,t:1526929994808};\\\", \\\"{x:1267,y:954,t:1526929994826};\\\", \\\"{x:1250,y:944,t:1526929994842};\\\", \\\"{x:1223,y:922,t:1526929994859};\\\", \\\"{x:1177,y:882,t:1526929994876};\\\", \\\"{x:1102,y:834,t:1526929994892};\\\", \\\"{x:1008,y:770,t:1526929994908};\\\", \\\"{x:881,y:683,t:1526929994926};\\\", \\\"{x:750,y:615,t:1526929994941};\\\", \\\"{x:561,y:531,t:1526929994959};\\\", \\\"{x:454,y:488,t:1526929994975};\\\", \\\"{x:373,y:452,t:1526929994992};\\\", \\\"{x:338,y:433,t:1526929995010};\\\", \\\"{x:330,y:429,t:1526929995026};\\\", \\\"{x:330,y:437,t:1526929995111};\\\", \\\"{x:332,y:459,t:1526929995127};\\\", \\\"{x:335,y:485,t:1526929995143};\\\", \\\"{x:344,y:516,t:1526929995161};\\\", \\\"{x:352,y:543,t:1526929995178};\\\", \\\"{x:362,y:564,t:1526929995194};\\\", \\\"{x:371,y:578,t:1526929995211};\\\", \\\"{x:374,y:582,t:1526929995228};\\\", \\\"{x:374,y:584,t:1526929995244};\\\", \\\"{x:375,y:584,t:1526929995335};\\\", \\\"{x:377,y:584,t:1526929995351};\\\", \\\"{x:378,y:584,t:1526929995361};\\\", \\\"{x:382,y:582,t:1526929995378};\\\", \\\"{x:385,y:577,t:1526929995393};\\\", \\\"{x:387,y:572,t:1526929995411};\\\", \\\"{x:388,y:569,t:1526929995428};\\\", \\\"{x:388,y:566,t:1526929995443};\\\", \\\"{x:388,y:562,t:1526929995460};\\\", \\\"{x:388,y:560,t:1526929995477};\\\", \\\"{x:388,y:559,t:1526929995493};\\\", \\\"{x:389,y:567,t:1526929995662};\\\", \\\"{x:398,y:581,t:1526929995678};\\\", \\\"{x:429,y:624,t:1526929995694};\\\", \\\"{x:481,y:683,t:1526929995711};\\\", \\\"{x:503,y:700,t:1526929995727};\\\", \\\"{x:505,y:704,t:1526929995744};\\\", \\\"{x:506,y:705,t:1526929995766};\\\", \\\"{x:508,y:705,t:1526929995777};\\\", \\\"{x:511,y:707,t:1526929995795};\\\", \\\"{x:514,y:708,t:1526929995810};\\\", \\\"{x:514,y:709,t:1526929995887};\\\", \\\"{x:515,y:710,t:1526929995903};\\\", \\\"{x:516,y:710,t:1526929996174};\\\", \\\"{x:517,y:711,t:1526929996455};\\\", \\\"{x:518,y:712,t:1526929996462};\\\", \\\"{x:522,y:713,t:1526929996478};\\\", \\\"{x:541,y:716,t:1526929996495};\\\", \\\"{x:561,y:716,t:1526929996512};\\\", \\\"{x:588,y:716,t:1526929996528};\\\", \\\"{x:620,y:716,t:1526929996544};\\\", \\\"{x:676,y:716,t:1526929996562};\\\", \\\"{x:747,y:719,t:1526929996582};\\\", \\\"{x:815,y:725,t:1526929996599};\\\", \\\"{x:873,y:730,t:1526929996615};\\\", \\\"{x:921,y:731,t:1526929996632};\\\", \\\"{x:961,y:732,t:1526929996648};\\\", \\\"{x:987,y:737,t:1526929996665};\\\", \\\"{x:1013,y:740,t:1526929996682};\\\", \\\"{x:1020,y:741,t:1526929996698};\\\", \\\"{x:1024,y:741,t:1526929996715};\\\", \\\"{x:1027,y:742,t:1526929996732};\\\", \\\"{x:1030,y:742,t:1526929996749};\\\", \\\"{x:1031,y:742,t:1526929996765};\\\", \\\"{x:1033,y:742,t:1526929996782};\\\", \\\"{x:1035,y:744,t:1526929996798};\\\" ] }, { \\\"rt\\\": 12816, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 373334, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1034,y:744,t:1526929999514};\\\", \\\"{x:1030,y:744,t:1526929999522};\\\", \\\"{x:1029,y:744,t:1526929999534};\\\", \\\"{x:1028,y:744,t:1526929999551};\\\", \\\"{x:1027,y:744,t:1526929999787};\\\", \\\"{x:1026,y:744,t:1526929999843};\\\", \\\"{x:1029,y:744,t:1526930000188};\\\", \\\"{x:1035,y:744,t:1526930000202};\\\", \\\"{x:1059,y:752,t:1526930000218};\\\", \\\"{x:1130,y:782,t:1526930000235};\\\", \\\"{x:1218,y:812,t:1526930000252};\\\", \\\"{x:1311,y:850,t:1526930000268};\\\", \\\"{x:1407,y:890,t:1526930000285};\\\", \\\"{x:1495,y:923,t:1526930000302};\\\", \\\"{x:1568,y:949,t:1526930000318};\\\", \\\"{x:1629,y:975,t:1526930000336};\\\", \\\"{x:1660,y:991,t:1526930000353};\\\", \\\"{x:1679,y:1003,t:1526930000369};\\\", \\\"{x:1687,y:1009,t:1526930000386};\\\", \\\"{x:1689,y:1013,t:1526930000402};\\\", \\\"{x:1688,y:1016,t:1526930000427};\\\", \\\"{x:1688,y:1018,t:1526930000443};\\\", \\\"{x:1688,y:1019,t:1526930000452};\\\", \\\"{x:1688,y:1020,t:1526930000469};\\\", \\\"{x:1687,y:1017,t:1526930000532};\\\", \\\"{x:1682,y:1013,t:1526930000540};\\\", \\\"{x:1676,y:1009,t:1526930000552};\\\", \\\"{x:1663,y:1000,t:1526930000569};\\\", \\\"{x:1651,y:992,t:1526930000585};\\\", \\\"{x:1637,y:982,t:1526930000602};\\\", \\\"{x:1617,y:968,t:1526930000619};\\\", \\\"{x:1610,y:964,t:1526930000636};\\\", \\\"{x:1608,y:963,t:1526930000652};\\\", \\\"{x:1607,y:963,t:1526930000844};\\\", \\\"{x:1607,y:964,t:1526930000876};\\\", \\\"{x:1608,y:964,t:1526930000908};\\\", \\\"{x:1609,y:964,t:1526930000940};\\\", \\\"{x:1610,y:964,t:1526930000964};\\\", \\\"{x:1610,y:965,t:1526930000971};\\\", \\\"{x:1611,y:965,t:1526930000987};\\\", \\\"{x:1612,y:965,t:1526930001002};\\\", \\\"{x:1613,y:967,t:1526930001019};\\\", \\\"{x:1614,y:967,t:1526930001076};\\\", \\\"{x:1615,y:967,t:1526930001091};\\\", \\\"{x:1616,y:967,t:1526930001108};\\\", \\\"{x:1617,y:967,t:1526930001756};\\\", \\\"{x:1617,y:966,t:1526930001770};\\\", \\\"{x:1616,y:963,t:1526930001785};\\\", \\\"{x:1614,y:957,t:1526930001802};\\\", \\\"{x:1613,y:954,t:1526930001820};\\\", \\\"{x:1612,y:954,t:1526930001836};\\\", \\\"{x:1612,y:953,t:1526930001852};\\\", \\\"{x:1612,y:952,t:1526930001923};\\\", \\\"{x:1612,y:951,t:1526930001947};\\\", \\\"{x:1611,y:950,t:1526930001970};\\\", \\\"{x:1610,y:949,t:1526930001987};\\\", \\\"{x:1610,y:948,t:1526930002003};\\\", \\\"{x:1610,y:947,t:1526930002019};\\\", \\\"{x:1609,y:946,t:1526930002036};\\\", \\\"{x:1609,y:945,t:1526930002053};\\\", \\\"{x:1609,y:944,t:1526930002075};\\\", \\\"{x:1608,y:943,t:1526930002130};\\\", \\\"{x:1607,y:943,t:1526930002139};\\\", \\\"{x:1607,y:942,t:1526930002152};\\\", \\\"{x:1606,y:941,t:1526930002169};\\\", \\\"{x:1605,y:940,t:1526930002185};\\\", \\\"{x:1603,y:937,t:1526930002203};\\\", \\\"{x:1601,y:934,t:1526930002220};\\\", \\\"{x:1600,y:932,t:1526930002237};\\\", \\\"{x:1597,y:929,t:1526930002253};\\\", \\\"{x:1596,y:926,t:1526930002269};\\\", \\\"{x:1594,y:923,t:1526930002287};\\\", \\\"{x:1591,y:921,t:1526930002303};\\\", \\\"{x:1587,y:917,t:1526930002320};\\\", \\\"{x:1586,y:916,t:1526930002337};\\\", \\\"{x:1584,y:914,t:1526930002353};\\\", \\\"{x:1583,y:913,t:1526930002370};\\\", \\\"{x:1582,y:909,t:1526930002387};\\\", \\\"{x:1580,y:908,t:1526930002403};\\\", \\\"{x:1580,y:906,t:1526930002420};\\\", \\\"{x:1578,y:903,t:1526930002437};\\\", \\\"{x:1575,y:898,t:1526930002453};\\\", \\\"{x:1572,y:893,t:1526930002470};\\\", \\\"{x:1570,y:886,t:1526930002487};\\\", \\\"{x:1567,y:880,t:1526930002503};\\\", \\\"{x:1564,y:868,t:1526930002521};\\\", \\\"{x:1559,y:856,t:1526930002538};\\\", \\\"{x:1555,y:846,t:1526930002553};\\\", \\\"{x:1553,y:839,t:1526930002570};\\\", \\\"{x:1550,y:830,t:1526930002588};\\\", \\\"{x:1547,y:826,t:1526930002604};\\\", \\\"{x:1546,y:824,t:1526930002620};\\\", \\\"{x:1544,y:821,t:1526930002637};\\\", \\\"{x:1543,y:820,t:1526930002653};\\\", \\\"{x:1542,y:817,t:1526930002671};\\\", \\\"{x:1541,y:815,t:1526930002687};\\\", \\\"{x:1539,y:813,t:1526930002704};\\\", \\\"{x:1538,y:806,t:1526930002720};\\\", \\\"{x:1537,y:803,t:1526930002737};\\\", \\\"{x:1535,y:799,t:1526930002754};\\\", \\\"{x:1533,y:796,t:1526930002770};\\\", \\\"{x:1532,y:793,t:1526930002788};\\\", \\\"{x:1529,y:789,t:1526930002804};\\\", \\\"{x:1529,y:787,t:1526930002820};\\\", \\\"{x:1527,y:784,t:1526930002837};\\\", \\\"{x:1526,y:782,t:1526930002855};\\\", \\\"{x:1526,y:780,t:1526930002870};\\\", \\\"{x:1524,y:778,t:1526930002887};\\\", \\\"{x:1522,y:774,t:1526930002904};\\\", \\\"{x:1519,y:770,t:1526930002920};\\\", \\\"{x:1517,y:764,t:1526930002937};\\\", \\\"{x:1514,y:759,t:1526930002954};\\\", \\\"{x:1512,y:756,t:1526930002970};\\\", \\\"{x:1511,y:753,t:1526930002986};\\\", \\\"{x:1510,y:750,t:1526930003004};\\\", \\\"{x:1508,y:747,t:1526930003020};\\\", \\\"{x:1508,y:746,t:1526930003036};\\\", \\\"{x:1507,y:744,t:1526930003054};\\\", \\\"{x:1507,y:742,t:1526930003070};\\\", \\\"{x:1506,y:742,t:1526930003087};\\\", \\\"{x:1505,y:741,t:1526930003104};\\\", \\\"{x:1505,y:740,t:1526930003120};\\\", \\\"{x:1505,y:738,t:1526930003137};\\\", \\\"{x:1503,y:735,t:1526930003154};\\\", \\\"{x:1502,y:733,t:1526930003170};\\\", \\\"{x:1499,y:727,t:1526930003186};\\\", \\\"{x:1497,y:722,t:1526930003205};\\\", \\\"{x:1497,y:719,t:1526930003221};\\\", \\\"{x:1495,y:716,t:1526930003237};\\\", \\\"{x:1493,y:714,t:1526930003254};\\\", \\\"{x:1492,y:711,t:1526930003271};\\\", \\\"{x:1489,y:707,t:1526930003287};\\\", \\\"{x:1487,y:704,t:1526930003304};\\\", \\\"{x:1484,y:699,t:1526930003321};\\\", \\\"{x:1478,y:690,t:1526930003338};\\\", \\\"{x:1473,y:681,t:1526930003354};\\\", \\\"{x:1466,y:672,t:1526930003372};\\\", \\\"{x:1465,y:669,t:1526930003387};\\\", \\\"{x:1462,y:666,t:1526930003404};\\\", \\\"{x:1458,y:660,t:1526930003421};\\\", \\\"{x:1454,y:651,t:1526930003438};\\\", \\\"{x:1448,y:644,t:1526930003454};\\\", \\\"{x:1441,y:634,t:1526930003471};\\\", \\\"{x:1434,y:626,t:1526930003487};\\\", \\\"{x:1429,y:616,t:1526930003505};\\\", \\\"{x:1421,y:606,t:1526930003522};\\\", \\\"{x:1417,y:599,t:1526930003537};\\\", \\\"{x:1413,y:591,t:1526930003554};\\\", \\\"{x:1409,y:585,t:1526930003571};\\\", \\\"{x:1408,y:583,t:1526930003587};\\\", \\\"{x:1407,y:582,t:1526930003604};\\\", \\\"{x:1406,y:580,t:1526930003621};\\\", \\\"{x:1406,y:578,t:1526930003637};\\\", \\\"{x:1405,y:576,t:1526930003654};\\\", \\\"{x:1405,y:575,t:1526930003690};\\\", \\\"{x:1404,y:575,t:1526930003704};\\\", \\\"{x:1404,y:573,t:1526930003721};\\\", \\\"{x:1403,y:571,t:1526930003738};\\\", \\\"{x:1403,y:569,t:1526930003754};\\\", \\\"{x:1402,y:566,t:1526930003771};\\\", \\\"{x:1402,y:564,t:1526930003788};\\\", \\\"{x:1402,y:563,t:1526930003805};\\\", \\\"{x:1402,y:561,t:1526930003822};\\\", \\\"{x:1403,y:558,t:1526930003838};\\\", \\\"{x:1403,y:557,t:1526930003867};\\\", \\\"{x:1404,y:556,t:1526930003908};\\\", \\\"{x:1405,y:556,t:1526930004539};\\\", \\\"{x:1406,y:556,t:1526930004571};\\\", \\\"{x:1407,y:556,t:1526930004588};\\\", \\\"{x:1407,y:557,t:1526930004605};\\\", \\\"{x:1408,y:557,t:1526930004716};\\\", \\\"{x:1409,y:557,t:1526930005899};\\\", \\\"{x:1411,y:558,t:1526930005915};\\\", \\\"{x:1412,y:558,t:1526930006134};\\\", \\\"{x:1413,y:559,t:1526930007539};\\\", \\\"{x:1413,y:560,t:1526930007571};\\\", \\\"{x:1408,y:562,t:1526930008508};\\\", \\\"{x:1357,y:569,t:1526930008524};\\\", \\\"{x:1240,y:586,t:1526930008541};\\\", \\\"{x:1107,y:607,t:1526930008558};\\\", \\\"{x:933,y:629,t:1526930008574};\\\", \\\"{x:762,y:649,t:1526930008590};\\\", \\\"{x:598,y:654,t:1526930008607};\\\", \\\"{x:476,y:654,t:1526930008623};\\\", \\\"{x:411,y:652,t:1526930008641};\\\", \\\"{x:393,y:650,t:1526930008658};\\\", \\\"{x:392,y:649,t:1526930008674};\\\", \\\"{x:391,y:648,t:1526930008698};\\\", \\\"{x:391,y:647,t:1526930008730};\\\", \\\"{x:392,y:647,t:1526930008738};\\\", \\\"{x:393,y:644,t:1526930008754};\\\", \\\"{x:395,y:641,t:1526930008771};\\\", \\\"{x:395,y:637,t:1526930008792};\\\", \\\"{x:395,y:632,t:1526930008809};\\\", \\\"{x:398,y:625,t:1526930008825};\\\", \\\"{x:404,y:618,t:1526930008843};\\\", \\\"{x:426,y:597,t:1526930008858};\\\", \\\"{x:429,y:594,t:1526930008875};\\\", \\\"{x:430,y:590,t:1526930008892};\\\", \\\"{x:430,y:588,t:1526930008909};\\\", \\\"{x:429,y:587,t:1526930008925};\\\", \\\"{x:428,y:587,t:1526930008946};\\\", \\\"{x:427,y:586,t:1526930008962};\\\", \\\"{x:426,y:586,t:1526930008986};\\\", \\\"{x:425,y:586,t:1526930008994};\\\", \\\"{x:424,y:586,t:1526930009009};\\\", \\\"{x:422,y:586,t:1526930009026};\\\", \\\"{x:418,y:586,t:1526930009042};\\\", \\\"{x:413,y:586,t:1526930009060};\\\", \\\"{x:411,y:586,t:1526930009075};\\\", \\\"{x:410,y:585,t:1526930009107};\\\", \\\"{x:409,y:585,t:1526930009123};\\\", \\\"{x:409,y:584,t:1526930009131};\\\", \\\"{x:409,y:582,t:1526930009146};\\\", \\\"{x:409,y:581,t:1526930009163};\\\", \\\"{x:409,y:579,t:1526930009174};\\\", \\\"{x:409,y:577,t:1526930009192};\\\", \\\"{x:422,y:574,t:1526930009209};\\\", \\\"{x:467,y:573,t:1526930009225};\\\", \\\"{x:577,y:567,t:1526930009242};\\\", \\\"{x:632,y:567,t:1526930009259};\\\", \\\"{x:663,y:569,t:1526930009276};\\\", \\\"{x:671,y:570,t:1526930009291};\\\", \\\"{x:673,y:571,t:1526930009309};\\\", \\\"{x:671,y:571,t:1526930009411};\\\", \\\"{x:670,y:571,t:1526930009425};\\\", \\\"{x:667,y:571,t:1526930009442};\\\", \\\"{x:663,y:570,t:1526930009459};\\\", \\\"{x:660,y:570,t:1526930009475};\\\", \\\"{x:657,y:570,t:1526930009492};\\\", \\\"{x:651,y:570,t:1526930009509};\\\", \\\"{x:645,y:570,t:1526930009525};\\\", \\\"{x:640,y:570,t:1526930009541};\\\", \\\"{x:637,y:570,t:1526930009559};\\\", \\\"{x:635,y:570,t:1526930009575};\\\", \\\"{x:633,y:570,t:1526930009592};\\\", \\\"{x:629,y:570,t:1526930009609};\\\", \\\"{x:625,y:570,t:1526930009625};\\\", \\\"{x:618,y:570,t:1526930009642};\\\", \\\"{x:609,y:568,t:1526930009659};\\\", \\\"{x:605,y:567,t:1526930009675};\\\", \\\"{x:602,y:567,t:1526930009693};\\\", \\\"{x:601,y:567,t:1526930009709};\\\", \\\"{x:602,y:567,t:1526930009759};\\\", \\\"{x:602,y:567,t:1526930009848};\\\", \\\"{x:602,y:568,t:1526930009874};\\\", \\\"{x:602,y:572,t:1526930009882};\\\", \\\"{x:602,y:577,t:1526930009893};\\\", \\\"{x:601,y:593,t:1526930009910};\\\", \\\"{x:597,y:614,t:1526930009927};\\\", \\\"{x:589,y:637,t:1526930009943};\\\", \\\"{x:579,y:664,t:1526930009959};\\\", \\\"{x:568,y:686,t:1526930009975};\\\", \\\"{x:555,y:705,t:1526930009993};\\\", \\\"{x:545,y:720,t:1526930010008};\\\", \\\"{x:531,y:739,t:1526930010026};\\\", \\\"{x:526,y:748,t:1526930010042};\\\", \\\"{x:525,y:749,t:1526930010059};\\\", \\\"{x:525,y:750,t:1526930010076};\\\", \\\"{x:524,y:745,t:1526930010203};\\\", \\\"{x:524,y:743,t:1526930010211};\\\", \\\"{x:524,y:742,t:1526930010226};\\\", \\\"{x:522,y:736,t:1526930010243};\\\", \\\"{x:521,y:734,t:1526930010261};\\\", \\\"{x:518,y:731,t:1526930010276};\\\", \\\"{x:517,y:727,t:1526930010293};\\\", \\\"{x:517,y:724,t:1526930010310};\\\", \\\"{x:517,y:722,t:1526930010326};\\\", \\\"{x:510,y:729,t:1526930010476};\\\", \\\"{x:522,y:728,t:1526930010883};\\\", \\\"{x:531,y:726,t:1526930010893};\\\", \\\"{x:553,y:724,t:1526930010910};\\\", \\\"{x:577,y:722,t:1526930010927};\\\", \\\"{x:604,y:721,t:1526930010943};\\\", \\\"{x:634,y:721,t:1526930010960};\\\", \\\"{x:664,y:721,t:1526930010977};\\\", \\\"{x:710,y:721,t:1526930010994};\\\", \\\"{x:742,y:721,t:1526930011010};\\\", \\\"{x:765,y:721,t:1526930011027};\\\", \\\"{x:787,y:721,t:1526930011044};\\\", \\\"{x:803,y:721,t:1526930011060};\\\", \\\"{x:816,y:721,t:1526930011078};\\\", \\\"{x:830,y:724,t:1526930011094};\\\", \\\"{x:847,y:725,t:1526930011110};\\\", \\\"{x:862,y:728,t:1526930011127};\\\", \\\"{x:880,y:730,t:1526930011144};\\\", \\\"{x:899,y:730,t:1526930011161};\\\", \\\"{x:924,y:735,t:1526930011177};\\\", \\\"{x:956,y:739,t:1526930011195};\\\", \\\"{x:967,y:740,t:1526930011210};\\\", \\\"{x:1005,y:745,t:1526930011227};\\\", \\\"{x:1029,y:747,t:1526930011245};\\\", \\\"{x:1050,y:748,t:1526930011260};\\\", \\\"{x:1068,y:750,t:1526930011277};\\\", \\\"{x:1078,y:750,t:1526930011294};\\\", \\\"{x:1083,y:751,t:1526930011310};\\\", \\\"{x:1084,y:751,t:1526930011331};\\\", \\\"{x:1085,y:751,t:1526930011347};\\\", \\\"{x:1086,y:751,t:1526930011371};\\\", \\\"{x:1087,y:752,t:1526930011395};\\\", \\\"{x:1088,y:752,t:1526930011419};\\\", \\\"{x:1089,y:752,t:1526930011427};\\\", \\\"{x:1090,y:753,t:1526930011444};\\\" ] }, { \\\"rt\\\": 54540, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 429101, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -O -O -O -01 PM-02 PM-O -O -O -I -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1090,y:754,t:1526930025044};\\\", \\\"{x:1090,y:756,t:1526930025054};\\\", \\\"{x:1090,y:757,t:1526930025075};\\\", \\\"{x:1090,y:758,t:1526930025147};\\\", \\\"{x:1090,y:759,t:1526930025155};\\\", \\\"{x:1090,y:760,t:1526930025212};\\\", \\\"{x:1090,y:762,t:1526930025307};\\\", \\\"{x:1090,y:763,t:1526930025331};\\\", \\\"{x:1090,y:765,t:1526930025348};\\\", \\\"{x:1089,y:766,t:1526930025363};\\\", \\\"{x:1089,y:768,t:1526930025387};\\\", \\\"{x:1088,y:769,t:1526930025405};\\\", \\\"{x:1088,y:771,t:1526930025421};\\\", \\\"{x:1088,y:773,t:1526930025438};\\\", \\\"{x:1085,y:774,t:1526930025456};\\\", \\\"{x:1085,y:776,t:1526930025471};\\\", \\\"{x:1082,y:777,t:1526930025491};\\\", \\\"{x:1082,y:779,t:1526930025514};\\\", \\\"{x:1081,y:779,t:1526930026659};\\\", \\\"{x:1081,y:778,t:1526930026763};\\\", \\\"{x:1083,y:777,t:1526930026773};\\\", \\\"{x:1085,y:775,t:1526930026789};\\\", \\\"{x:1089,y:771,t:1526930026806};\\\", \\\"{x:1094,y:768,t:1526930026822};\\\", \\\"{x:1104,y:763,t:1526930026840};\\\", \\\"{x:1121,y:759,t:1526930026856};\\\", \\\"{x:1142,y:753,t:1526930026872};\\\", \\\"{x:1168,y:751,t:1526930026889};\\\", \\\"{x:1204,y:745,t:1526930026906};\\\", \\\"{x:1215,y:744,t:1526930026922};\\\", \\\"{x:1247,y:733,t:1526930026939};\\\", \\\"{x:1268,y:727,t:1526930026956};\\\", \\\"{x:1292,y:723,t:1526930026972};\\\", \\\"{x:1325,y:713,t:1526930026989};\\\", \\\"{x:1356,y:702,t:1526930027006};\\\", \\\"{x:1383,y:691,t:1526930027022};\\\", \\\"{x:1407,y:679,t:1526930027039};\\\", \\\"{x:1421,y:669,t:1526930027056};\\\", \\\"{x:1431,y:660,t:1526930027073};\\\", \\\"{x:1435,y:654,t:1526930027090};\\\", \\\"{x:1437,y:648,t:1526930027107};\\\", \\\"{x:1440,y:637,t:1526930027122};\\\", \\\"{x:1435,y:625,t:1526930027138};\\\", \\\"{x:1427,y:611,t:1526930027156};\\\", \\\"{x:1412,y:600,t:1526930027173};\\\", \\\"{x:1395,y:588,t:1526930027189};\\\", \\\"{x:1379,y:576,t:1526930027206};\\\", \\\"{x:1368,y:568,t:1526930027222};\\\", \\\"{x:1362,y:562,t:1526930027239};\\\", \\\"{x:1358,y:556,t:1526930027256};\\\", \\\"{x:1356,y:553,t:1526930027273};\\\", \\\"{x:1354,y:551,t:1526930027289};\\\", \\\"{x:1354,y:549,t:1526930027306};\\\", \\\"{x:1354,y:548,t:1526930027362};\\\", \\\"{x:1353,y:547,t:1526930027373};\\\", \\\"{x:1351,y:543,t:1526930027389};\\\", \\\"{x:1348,y:539,t:1526930027406};\\\", \\\"{x:1344,y:534,t:1526930027423};\\\", \\\"{x:1340,y:529,t:1526930027439};\\\", \\\"{x:1333,y:520,t:1526930027456};\\\", \\\"{x:1330,y:518,t:1526930027473};\\\", \\\"{x:1327,y:515,t:1526930027489};\\\", \\\"{x:1327,y:513,t:1526930027506};\\\", \\\"{x:1326,y:513,t:1526930027524};\\\", \\\"{x:1325,y:512,t:1526930027659};\\\", \\\"{x:1324,y:511,t:1526930027674};\\\", \\\"{x:1323,y:509,t:1526930027690};\\\", \\\"{x:1321,y:505,t:1526930027707};\\\", \\\"{x:1319,y:502,t:1526930027723};\\\", \\\"{x:1319,y:500,t:1526930027743};\\\", \\\"{x:1319,y:499,t:1526930027756};\\\", \\\"{x:1318,y:498,t:1526930030579};\\\", \\\"{x:1318,y:497,t:1526930034435};\\\", \\\"{x:1317,y:497,t:1526930034444};\\\", \\\"{x:1316,y:497,t:1526930043706};\\\", \\\"{x:1316,y:498,t:1526930043717};\\\", \\\"{x:1313,y:503,t:1526930043735};\\\", \\\"{x:1312,y:508,t:1526930043752};\\\", \\\"{x:1310,y:511,t:1526930043769};\\\", \\\"{x:1310,y:512,t:1526930043785};\\\", \\\"{x:1310,y:514,t:1526930043801};\\\", \\\"{x:1309,y:515,t:1526930043923};\\\", \\\"{x:1309,y:513,t:1526930044531};\\\", \\\"{x:1309,y:512,t:1526930044538};\\\", \\\"{x:1309,y:511,t:1526930044551};\\\", \\\"{x:1309,y:509,t:1526930044568};\\\", \\\"{x:1309,y:506,t:1526930044586};\\\", \\\"{x:1309,y:505,t:1526930044602};\\\", \\\"{x:1309,y:503,t:1526930044619};\\\", \\\"{x:1309,y:502,t:1526930044636};\\\", \\\"{x:1309,y:500,t:1526930044699};\\\", \\\"{x:1309,y:499,t:1526930044820};\\\", \\\"{x:1309,y:497,t:1526930044858};\\\", \\\"{x:1311,y:497,t:1526930045747};\\\", \\\"{x:1313,y:497,t:1526930045762};\\\", \\\"{x:1314,y:498,t:1526930045786};\\\", \\\"{x:1315,y:500,t:1526930045802};\\\", \\\"{x:1315,y:504,t:1526930045821};\\\", \\\"{x:1316,y:510,t:1526930045837};\\\", \\\"{x:1317,y:519,t:1526930045853};\\\", \\\"{x:1317,y:527,t:1526930045870};\\\", \\\"{x:1318,y:536,t:1526930045887};\\\", \\\"{x:1318,y:544,t:1526930045903};\\\", \\\"{x:1318,y:551,t:1526930045920};\\\", \\\"{x:1318,y:557,t:1526930045937};\\\", \\\"{x:1318,y:561,t:1526930045953};\\\", \\\"{x:1318,y:566,t:1526930045970};\\\", \\\"{x:1318,y:575,t:1526930045987};\\\", \\\"{x:1318,y:582,t:1526930046003};\\\", \\\"{x:1318,y:587,t:1526930046020};\\\", \\\"{x:1318,y:593,t:1526930046037};\\\", \\\"{x:1318,y:600,t:1526930046053};\\\", \\\"{x:1318,y:607,t:1526930046070};\\\", \\\"{x:1318,y:613,t:1526930046087};\\\", \\\"{x:1318,y:616,t:1526930046103};\\\", \\\"{x:1318,y:622,t:1526930046120};\\\", \\\"{x:1318,y:629,t:1526930046138};\\\", \\\"{x:1318,y:637,t:1526930046155};\\\", \\\"{x:1318,y:645,t:1526930046170};\\\", \\\"{x:1318,y:649,t:1526930046187};\\\", \\\"{x:1318,y:651,t:1526930046204};\\\", \\\"{x:1317,y:652,t:1526930046307};\\\", \\\"{x:1316,y:652,t:1526930046320};\\\", \\\"{x:1315,y:652,t:1526930046337};\\\", \\\"{x:1314,y:652,t:1526930046354};\\\", \\\"{x:1313,y:651,t:1526930046370};\\\", \\\"{x:1311,y:648,t:1526930046386};\\\", \\\"{x:1309,y:644,t:1526930046404};\\\", \\\"{x:1309,y:641,t:1526930046420};\\\", \\\"{x:1309,y:640,t:1526930046437};\\\", \\\"{x:1308,y:638,t:1526930046455};\\\", \\\"{x:1308,y:636,t:1526930046490};\\\", \\\"{x:1308,y:635,t:1526930046514};\\\", \\\"{x:1308,y:634,t:1526930046523};\\\", \\\"{x:1308,y:633,t:1526930046537};\\\", \\\"{x:1308,y:632,t:1526930046554};\\\", \\\"{x:1308,y:630,t:1526930046571};\\\", \\\"{x:1307,y:630,t:1526930046867};\\\", \\\"{x:1306,y:630,t:1526930046874};\\\", \\\"{x:1304,y:632,t:1526930046887};\\\", \\\"{x:1299,y:640,t:1526930046904};\\\", \\\"{x:1290,y:653,t:1526930046921};\\\", \\\"{x:1282,y:665,t:1526930046937};\\\", \\\"{x:1266,y:690,t:1526930046954};\\\", \\\"{x:1254,y:707,t:1526930046970};\\\", \\\"{x:1245,y:724,t:1526930046987};\\\", \\\"{x:1234,y:741,t:1526930047004};\\\", \\\"{x:1225,y:758,t:1526930047021};\\\", \\\"{x:1218,y:773,t:1526930047037};\\\", \\\"{x:1209,y:788,t:1526930047054};\\\", \\\"{x:1202,y:800,t:1526930047071};\\\", \\\"{x:1197,y:808,t:1526930047088};\\\", \\\"{x:1192,y:818,t:1526930047103};\\\", \\\"{x:1185,y:829,t:1526930047120};\\\", \\\"{x:1180,y:840,t:1526930047137};\\\", \\\"{x:1177,y:845,t:1526930047154};\\\", \\\"{x:1173,y:851,t:1526930047170};\\\", \\\"{x:1171,y:854,t:1526930047188};\\\", \\\"{x:1170,y:858,t:1526930047204};\\\", \\\"{x:1167,y:862,t:1526930047221};\\\", \\\"{x:1164,y:865,t:1526930047238};\\\", \\\"{x:1161,y:869,t:1526930047254};\\\", \\\"{x:1158,y:875,t:1526930047271};\\\", \\\"{x:1153,y:881,t:1526930047288};\\\", \\\"{x:1152,y:885,t:1526930047303};\\\", \\\"{x:1149,y:892,t:1526930047321};\\\", \\\"{x:1147,y:899,t:1526930047338};\\\", \\\"{x:1145,y:904,t:1526930047353};\\\", \\\"{x:1145,y:909,t:1526930047371};\\\", \\\"{x:1144,y:914,t:1526930047387};\\\", \\\"{x:1143,y:919,t:1526930047404};\\\", \\\"{x:1141,y:925,t:1526930047420};\\\", \\\"{x:1140,y:929,t:1526930047438};\\\", \\\"{x:1139,y:935,t:1526930047453};\\\", \\\"{x:1139,y:939,t:1526930047471};\\\", \\\"{x:1139,y:942,t:1526930047488};\\\", \\\"{x:1138,y:945,t:1526930047503};\\\", \\\"{x:1138,y:949,t:1526930047521};\\\", \\\"{x:1138,y:956,t:1526930047538};\\\", \\\"{x:1138,y:961,t:1526930047554};\\\", \\\"{x:1138,y:964,t:1526930047571};\\\", \\\"{x:1138,y:965,t:1526930047589};\\\", \\\"{x:1138,y:967,t:1526930047605};\\\", \\\"{x:1139,y:966,t:1526930047746};\\\", \\\"{x:1140,y:965,t:1526930047851};\\\", \\\"{x:1140,y:964,t:1526930047859};\\\", \\\"{x:1141,y:962,t:1526930047871};\\\", \\\"{x:1142,y:960,t:1526930047888};\\\", \\\"{x:1144,y:959,t:1526930047905};\\\", \\\"{x:1144,y:958,t:1526930047921};\\\", \\\"{x:1146,y:958,t:1526930047938};\\\", \\\"{x:1147,y:958,t:1526930047971};\\\", \\\"{x:1149,y:958,t:1526930048027};\\\", \\\"{x:1149,y:957,t:1526930048038};\\\", \\\"{x:1150,y:957,t:1526930048055};\\\", \\\"{x:1151,y:955,t:1526930048071};\\\", \\\"{x:1152,y:955,t:1526930048089};\\\", \\\"{x:1153,y:954,t:1526930048106};\\\", \\\"{x:1155,y:954,t:1526930048122};\\\", \\\"{x:1156,y:953,t:1526930048138};\\\", \\\"{x:1156,y:952,t:1526930048155};\\\", \\\"{x:1157,y:952,t:1526930048202};\\\", \\\"{x:1157,y:951,t:1526930048275};\\\", \\\"{x:1157,y:949,t:1526930048288};\\\", \\\"{x:1157,y:948,t:1526930048305};\\\", \\\"{x:1161,y:937,t:1526930048322};\\\", \\\"{x:1164,y:925,t:1526930048339};\\\", \\\"{x:1170,y:912,t:1526930048355};\\\", \\\"{x:1175,y:901,t:1526930048372};\\\", \\\"{x:1178,y:893,t:1526930048388};\\\", \\\"{x:1181,y:888,t:1526930048405};\\\", \\\"{x:1183,y:880,t:1526930048422};\\\", \\\"{x:1186,y:872,t:1526930048438};\\\", \\\"{x:1188,y:867,t:1526930048455};\\\", \\\"{x:1191,y:863,t:1526930048472};\\\", \\\"{x:1192,y:859,t:1526930048489};\\\", \\\"{x:1193,y:857,t:1526930048505};\\\", \\\"{x:1194,y:855,t:1526930048522};\\\", \\\"{x:1195,y:853,t:1526930048539};\\\", \\\"{x:1196,y:850,t:1526930048555};\\\", \\\"{x:1197,y:848,t:1526930048572};\\\", \\\"{x:1198,y:846,t:1526930048589};\\\", \\\"{x:1198,y:845,t:1526930048605};\\\", \\\"{x:1198,y:847,t:1526930048755};\\\", \\\"{x:1198,y:848,t:1526930048772};\\\", \\\"{x:1198,y:850,t:1526930048789};\\\", \\\"{x:1198,y:852,t:1526930048805};\\\", \\\"{x:1198,y:858,t:1526930048822};\\\", \\\"{x:1198,y:864,t:1526930048839};\\\", \\\"{x:1197,y:870,t:1526930048855};\\\", \\\"{x:1194,y:878,t:1526930048872};\\\", \\\"{x:1193,y:882,t:1526930048889};\\\", \\\"{x:1192,y:886,t:1526930048905};\\\", \\\"{x:1190,y:892,t:1526930048923};\\\", \\\"{x:1190,y:894,t:1526930048939};\\\", \\\"{x:1189,y:896,t:1526930048955};\\\", \\\"{x:1187,y:899,t:1526930048972};\\\", \\\"{x:1186,y:901,t:1526930048990};\\\", \\\"{x:1185,y:903,t:1526930049006};\\\", \\\"{x:1185,y:905,t:1526930049022};\\\", \\\"{x:1183,y:904,t:1526930049234};\\\", \\\"{x:1183,y:903,t:1526930049249};\\\", \\\"{x:1183,y:902,t:1526930049314};\\\", \\\"{x:1184,y:901,t:1526930049354};\\\", \\\"{x:1184,y:900,t:1526930049370};\\\", \\\"{x:1185,y:899,t:1526930049387};\\\", \\\"{x:1186,y:898,t:1526930049394};\\\", \\\"{x:1186,y:897,t:1526930049406};\\\", \\\"{x:1187,y:894,t:1526930049422};\\\", \\\"{x:1190,y:892,t:1526930049439};\\\", \\\"{x:1191,y:887,t:1526930049456};\\\", \\\"{x:1194,y:883,t:1526930049473};\\\", \\\"{x:1196,y:879,t:1526930049489};\\\", \\\"{x:1200,y:872,t:1526930049506};\\\", \\\"{x:1202,y:867,t:1526930049522};\\\", \\\"{x:1206,y:863,t:1526930049539};\\\", \\\"{x:1209,y:858,t:1526930049556};\\\", \\\"{x:1212,y:851,t:1526930049574};\\\", \\\"{x:1214,y:848,t:1526930049589};\\\", \\\"{x:1216,y:845,t:1526930049606};\\\", \\\"{x:1218,y:840,t:1526930049623};\\\", \\\"{x:1221,y:836,t:1526930049639};\\\", \\\"{x:1225,y:828,t:1526930049656};\\\", \\\"{x:1228,y:821,t:1526930049673};\\\", \\\"{x:1231,y:813,t:1526930049689};\\\", \\\"{x:1239,y:798,t:1526930049707};\\\", \\\"{x:1248,y:783,t:1526930049723};\\\", \\\"{x:1255,y:767,t:1526930049739};\\\", \\\"{x:1263,y:749,t:1526930049756};\\\", \\\"{x:1270,y:732,t:1526930049773};\\\", \\\"{x:1278,y:716,t:1526930049789};\\\", \\\"{x:1284,y:700,t:1526930049806};\\\", \\\"{x:1287,y:689,t:1526930049823};\\\", \\\"{x:1290,y:674,t:1526930049839};\\\", \\\"{x:1292,y:666,t:1526930049856};\\\", \\\"{x:1295,y:657,t:1526930049873};\\\", \\\"{x:1296,y:652,t:1526930049889};\\\", \\\"{x:1299,y:647,t:1526930049906};\\\", \\\"{x:1300,y:644,t:1526930049922};\\\", \\\"{x:1302,y:642,t:1526930049940};\\\", \\\"{x:1302,y:641,t:1526930049956};\\\", \\\"{x:1303,y:640,t:1526930049973};\\\", \\\"{x:1305,y:638,t:1526930050074};\\\", \\\"{x:1306,y:637,t:1526930050090};\\\", \\\"{x:1307,y:635,t:1526930050106};\\\", \\\"{x:1310,y:632,t:1526930050124};\\\", \\\"{x:1312,y:630,t:1526930050140};\\\", \\\"{x:1313,y:629,t:1526930050156};\\\", \\\"{x:1313,y:628,t:1526930050173};\\\", \\\"{x:1313,y:632,t:1526930050387};\\\", \\\"{x:1313,y:637,t:1526930050395};\\\", \\\"{x:1313,y:641,t:1526930050408};\\\", \\\"{x:1311,y:656,t:1526930050423};\\\", \\\"{x:1311,y:670,t:1526930050441};\\\", \\\"{x:1311,y:684,t:1526930050458};\\\", \\\"{x:1311,y:694,t:1526930050473};\\\", \\\"{x:1311,y:706,t:1526930050489};\\\", \\\"{x:1311,y:716,t:1526930050506};\\\", \\\"{x:1311,y:723,t:1526930050523};\\\", \\\"{x:1311,y:733,t:1526930050540};\\\", \\\"{x:1311,y:742,t:1526930050556};\\\", \\\"{x:1311,y:749,t:1526930050572};\\\", \\\"{x:1311,y:756,t:1526930050589};\\\", \\\"{x:1311,y:763,t:1526930050606};\\\", \\\"{x:1307,y:774,t:1526930050623};\\\", \\\"{x:1306,y:782,t:1526930050639};\\\", \\\"{x:1305,y:792,t:1526930050656};\\\", \\\"{x:1305,y:802,t:1526930050673};\\\", \\\"{x:1302,y:817,t:1526930050690};\\\", \\\"{x:1300,y:826,t:1526930050707};\\\", \\\"{x:1300,y:833,t:1526930050723};\\\", \\\"{x:1300,y:839,t:1526930050740};\\\", \\\"{x:1300,y:845,t:1526930050756};\\\", \\\"{x:1300,y:851,t:1526930050773};\\\", \\\"{x:1300,y:856,t:1526930050790};\\\", \\\"{x:1300,y:862,t:1526930050807};\\\", \\\"{x:1300,y:867,t:1526930050822};\\\", \\\"{x:1300,y:871,t:1526930050839};\\\", \\\"{x:1300,y:874,t:1526930050856};\\\", \\\"{x:1300,y:879,t:1526930050874};\\\", \\\"{x:1301,y:881,t:1526930050890};\\\", \\\"{x:1301,y:884,t:1526930050907};\\\", \\\"{x:1302,y:887,t:1526930050923};\\\", \\\"{x:1303,y:888,t:1526930050940};\\\", \\\"{x:1303,y:890,t:1526930050957};\\\", \\\"{x:1305,y:894,t:1526930050974};\\\", \\\"{x:1305,y:897,t:1526930050990};\\\", \\\"{x:1306,y:900,t:1526930051007};\\\", \\\"{x:1306,y:901,t:1526930051024};\\\", \\\"{x:1306,y:903,t:1526930051040};\\\", \\\"{x:1306,y:906,t:1526930051057};\\\", \\\"{x:1306,y:910,t:1526930051075};\\\", \\\"{x:1306,y:914,t:1526930051091};\\\", \\\"{x:1306,y:917,t:1526930051108};\\\", \\\"{x:1306,y:918,t:1526930051251};\\\", \\\"{x:1306,y:919,t:1526930051258};\\\", \\\"{x:1306,y:920,t:1526930051283};\\\", \\\"{x:1306,y:921,t:1526930051298};\\\", \\\"{x:1306,y:922,t:1526930051307};\\\", \\\"{x:1306,y:923,t:1526930051324};\\\", \\\"{x:1306,y:925,t:1526930051340};\\\", \\\"{x:1306,y:928,t:1526930051357};\\\", \\\"{x:1306,y:930,t:1526930051374};\\\", \\\"{x:1305,y:935,t:1526930051390};\\\", \\\"{x:1303,y:939,t:1526930051407};\\\", \\\"{x:1299,y:944,t:1526930051424};\\\", \\\"{x:1287,y:949,t:1526930051441};\\\", \\\"{x:1260,y:955,t:1526930051457};\\\", \\\"{x:1222,y:960,t:1526930051474};\\\", \\\"{x:1202,y:966,t:1526930051490};\\\", \\\"{x:1194,y:969,t:1526930051507};\\\", \\\"{x:1191,y:971,t:1526930051524};\\\", \\\"{x:1190,y:971,t:1526930051540};\\\", \\\"{x:1189,y:972,t:1526930051556};\\\", \\\"{x:1187,y:972,t:1526930051574};\\\", \\\"{x:1185,y:973,t:1526930051591};\\\", \\\"{x:1184,y:973,t:1526930051606};\\\", \\\"{x:1182,y:973,t:1526930051624};\\\", \\\"{x:1181,y:973,t:1526930051641};\\\", \\\"{x:1180,y:973,t:1526930051666};\\\", \\\"{x:1179,y:973,t:1526930051706};\\\", \\\"{x:1177,y:973,t:1526930051729};\\\", \\\"{x:1175,y:972,t:1526930051740};\\\", \\\"{x:1167,y:968,t:1526930051757};\\\", \\\"{x:1154,y:964,t:1526930051774};\\\", \\\"{x:1142,y:960,t:1526930051791};\\\", \\\"{x:1136,y:959,t:1526930051808};\\\", \\\"{x:1135,y:959,t:1526930051824};\\\", \\\"{x:1135,y:958,t:1526930052186};\\\", \\\"{x:1135,y:957,t:1526930052194};\\\", \\\"{x:1136,y:956,t:1526930052209};\\\", \\\"{x:1146,y:954,t:1526930052225};\\\", \\\"{x:1158,y:954,t:1526930052241};\\\", \\\"{x:1179,y:954,t:1526930052259};\\\", \\\"{x:1194,y:958,t:1526930052274};\\\", \\\"{x:1208,y:963,t:1526930052292};\\\", \\\"{x:1211,y:964,t:1526930052308};\\\", \\\"{x:1212,y:965,t:1526930052355};\\\", \\\"{x:1212,y:966,t:1526930052442};\\\", \\\"{x:1226,y:966,t:1526930052458};\\\", \\\"{x:1245,y:966,t:1526930052475};\\\", \\\"{x:1272,y:966,t:1526930052491};\\\", \\\"{x:1296,y:966,t:1526930052508};\\\", \\\"{x:1313,y:966,t:1526930052525};\\\", \\\"{x:1321,y:966,t:1526930052541};\\\", \\\"{x:1327,y:966,t:1526930052558};\\\", \\\"{x:1334,y:966,t:1526930052575};\\\", \\\"{x:1342,y:966,t:1526930052591};\\\", \\\"{x:1356,y:966,t:1526930052608};\\\", \\\"{x:1372,y:966,t:1526930052625};\\\", \\\"{x:1389,y:966,t:1526930052641};\\\", \\\"{x:1416,y:972,t:1526930052659};\\\", \\\"{x:1428,y:973,t:1526930052675};\\\", \\\"{x:1437,y:977,t:1526930052691};\\\", \\\"{x:1439,y:977,t:1526930052708};\\\", \\\"{x:1440,y:977,t:1526930052725};\\\", \\\"{x:1441,y:977,t:1526930052753};\\\", \\\"{x:1443,y:977,t:1526930052761};\\\", \\\"{x:1444,y:977,t:1526930052775};\\\", \\\"{x:1447,y:977,t:1526930052792};\\\", \\\"{x:1450,y:977,t:1526930052808};\\\", \\\"{x:1451,y:977,t:1526930052825};\\\", \\\"{x:1452,y:977,t:1526930052915};\\\", \\\"{x:1454,y:977,t:1526930052925};\\\", \\\"{x:1455,y:976,t:1526930052942};\\\", \\\"{x:1459,y:974,t:1526930052957};\\\", \\\"{x:1465,y:972,t:1526930052975};\\\", \\\"{x:1470,y:970,t:1526930052992};\\\", \\\"{x:1474,y:969,t:1526930053008};\\\", \\\"{x:1476,y:968,t:1526930053025};\\\", \\\"{x:1477,y:968,t:1526930053083};\\\", \\\"{x:1478,y:967,t:1526930053155};\\\", \\\"{x:1479,y:967,t:1526930055603};\\\", \\\"{x:1479,y:966,t:1526930058222};\\\", \\\"{x:1477,y:966,t:1526930058470};\\\", \\\"{x:1476,y:966,t:1526930058660};\\\", \\\"{x:1475,y:963,t:1526930058669};\\\", \\\"{x:1471,y:958,t:1526930058682};\\\", \\\"{x:1462,y:947,t:1526930058699};\\\", \\\"{x:1452,y:932,t:1526930058715};\\\", \\\"{x:1443,y:915,t:1526930058732};\\\", \\\"{x:1431,y:892,t:1526930058748};\\\", \\\"{x:1423,y:875,t:1526930058766};\\\", \\\"{x:1412,y:856,t:1526930058782};\\\", \\\"{x:1401,y:837,t:1526930058799};\\\", \\\"{x:1391,y:819,t:1526930058815};\\\", \\\"{x:1379,y:797,t:1526930058833};\\\", \\\"{x:1367,y:773,t:1526930058850};\\\", \\\"{x:1358,y:755,t:1526930058865};\\\", \\\"{x:1351,y:736,t:1526930058883};\\\", \\\"{x:1344,y:719,t:1526930058899};\\\", \\\"{x:1335,y:700,t:1526930058915};\\\", \\\"{x:1329,y:686,t:1526930058932};\\\", \\\"{x:1318,y:661,t:1526930058948};\\\", \\\"{x:1313,y:645,t:1526930058966};\\\", \\\"{x:1308,y:632,t:1526930058983};\\\", \\\"{x:1300,y:616,t:1526930059000};\\\", \\\"{x:1295,y:604,t:1526930059017};\\\", \\\"{x:1295,y:602,t:1526930059032};\\\", \\\"{x:1294,y:601,t:1526930059049};\\\", \\\"{x:1294,y:600,t:1526930059253};\\\", \\\"{x:1295,y:600,t:1526930059293};\\\", \\\"{x:1296,y:600,t:1526930059317};\\\", \\\"{x:1297,y:600,t:1526930059494};\\\", \\\"{x:1297,y:601,t:1526930059557};\\\", \\\"{x:1298,y:603,t:1526930059567};\\\", \\\"{x:1298,y:604,t:1526930059583};\\\", \\\"{x:1299,y:605,t:1526930059798};\\\", \\\"{x:1302,y:608,t:1526930059822};\\\", \\\"{x:1302,y:609,t:1526930059838};\\\", \\\"{x:1304,y:609,t:1526930059850};\\\", \\\"{x:1306,y:611,t:1526930059867};\\\", \\\"{x:1307,y:611,t:1526930059884};\\\", \\\"{x:1307,y:612,t:1526930059910};\\\", \\\"{x:1308,y:612,t:1526930059925};\\\", \\\"{x:1309,y:612,t:1526930059966};\\\", \\\"{x:1310,y:612,t:1526930060086};\\\", \\\"{x:1310,y:613,t:1526930060101};\\\", \\\"{x:1312,y:614,t:1526930060117};\\\", \\\"{x:1312,y:615,t:1526930060134};\\\", \\\"{x:1312,y:616,t:1526930060150};\\\", \\\"{x:1312,y:617,t:1526930060167};\\\", \\\"{x:1313,y:619,t:1526930060214};\\\", \\\"{x:1314,y:619,t:1526930060229};\\\", \\\"{x:1314,y:620,t:1526930060237};\\\", \\\"{x:1314,y:621,t:1526930060261};\\\", \\\"{x:1314,y:623,t:1526930060269};\\\", \\\"{x:1314,y:624,t:1526930060293};\\\", \\\"{x:1313,y:625,t:1526930060310};\\\", \\\"{x:1313,y:624,t:1526930061247};\\\", \\\"{x:1313,y:623,t:1526930061269};\\\", \\\"{x:1313,y:621,t:1526930061285};\\\", \\\"{x:1311,y:618,t:1526930061301};\\\", \\\"{x:1311,y:615,t:1526930061318};\\\", \\\"{x:1311,y:614,t:1526930061335};\\\", \\\"{x:1311,y:611,t:1526930061351};\\\", \\\"{x:1310,y:610,t:1526930061369};\\\", \\\"{x:1310,y:609,t:1526930061390};\\\", \\\"{x:1310,y:608,t:1526930061422};\\\", \\\"{x:1310,y:607,t:1526930061445};\\\", \\\"{x:1310,y:606,t:1526930061581};\\\", \\\"{x:1310,y:604,t:1526930061637};\\\", \\\"{x:1310,y:602,t:1526930061653};\\\", \\\"{x:1310,y:601,t:1526930061668};\\\", \\\"{x:1310,y:599,t:1526930061685};\\\", \\\"{x:1310,y:598,t:1526930061702};\\\", \\\"{x:1310,y:596,t:1526930061717};\\\", \\\"{x:1310,y:595,t:1526930061735};\\\", \\\"{x:1310,y:593,t:1526930061751};\\\", \\\"{x:1310,y:590,t:1526930061768};\\\", \\\"{x:1310,y:587,t:1526930061785};\\\", \\\"{x:1310,y:582,t:1526930061801};\\\", \\\"{x:1310,y:577,t:1526930061818};\\\", \\\"{x:1310,y:570,t:1526930061835};\\\", \\\"{x:1310,y:560,t:1526930061852};\\\", \\\"{x:1310,y:550,t:1526930061869};\\\", \\\"{x:1310,y:541,t:1526930061885};\\\", \\\"{x:1310,y:528,t:1526930061901};\\\", \\\"{x:1310,y:519,t:1526930061919};\\\", \\\"{x:1310,y:511,t:1526930061935};\\\", \\\"{x:1311,y:502,t:1526930061952};\\\", \\\"{x:1311,y:498,t:1526930061969};\\\", \\\"{x:1312,y:496,t:1526930061985};\\\", \\\"{x:1312,y:494,t:1526930062002};\\\", \\\"{x:1312,y:493,t:1526930062029};\\\", \\\"{x:1313,y:493,t:1526930062045};\\\", \\\"{x:1313,y:494,t:1526930063045};\\\", \\\"{x:1313,y:497,t:1526930063054};\\\", \\\"{x:1313,y:498,t:1526930063069};\\\", \\\"{x:1315,y:503,t:1526930063086};\\\", \\\"{x:1315,y:505,t:1526930063103};\\\", \\\"{x:1315,y:508,t:1526930063118};\\\", \\\"{x:1315,y:510,t:1526930063136};\\\", \\\"{x:1315,y:514,t:1526930063152};\\\", \\\"{x:1315,y:518,t:1526930063168};\\\", \\\"{x:1315,y:521,t:1526930063186};\\\", \\\"{x:1315,y:525,t:1526930063203};\\\", \\\"{x:1315,y:528,t:1526930063218};\\\", \\\"{x:1315,y:531,t:1526930063236};\\\", \\\"{x:1315,y:534,t:1526930063253};\\\", \\\"{x:1315,y:537,t:1526930063270};\\\", \\\"{x:1315,y:539,t:1526930063286};\\\", \\\"{x:1315,y:541,t:1526930063303};\\\", \\\"{x:1315,y:543,t:1526930063320};\\\", \\\"{x:1315,y:544,t:1526930063336};\\\", \\\"{x:1315,y:545,t:1526930063358};\\\", \\\"{x:1315,y:546,t:1526930063390};\\\", \\\"{x:1314,y:547,t:1526930063403};\\\", \\\"{x:1307,y:549,t:1526930063420};\\\", \\\"{x:1285,y:553,t:1526930063436};\\\", \\\"{x:1184,y:560,t:1526930063451};\\\", \\\"{x:1076,y:560,t:1526930063468};\\\", \\\"{x:962,y:560,t:1526930063485};\\\", \\\"{x:857,y:560,t:1526930063502};\\\", \\\"{x:771,y:550,t:1526930063520};\\\", \\\"{x:707,y:539,t:1526930063536};\\\", \\\"{x:665,y:534,t:1526930063555};\\\", \\\"{x:633,y:531,t:1526930063572};\\\", \\\"{x:622,y:528,t:1526930063588};\\\", \\\"{x:614,y:528,t:1526930063606};\\\", \\\"{x:609,y:529,t:1526930063622};\\\", \\\"{x:602,y:530,t:1526930063639};\\\", \\\"{x:592,y:530,t:1526930063656};\\\", \\\"{x:578,y:532,t:1526930063672};\\\", \\\"{x:567,y:532,t:1526930063689};\\\", \\\"{x:558,y:532,t:1526930063707};\\\", \\\"{x:556,y:532,t:1526930063724};\\\", \\\"{x:554,y:532,t:1526930063739};\\\", \\\"{x:556,y:531,t:1526930063950};\\\", \\\"{x:562,y:529,t:1526930063957};\\\", \\\"{x:586,y:527,t:1526930063973};\\\", \\\"{x:638,y:525,t:1526930063992};\\\", \\\"{x:746,y:525,t:1526930064008};\\\", \\\"{x:882,y:525,t:1526930064022};\\\", \\\"{x:1026,y:525,t:1526930064040};\\\", \\\"{x:1161,y:525,t:1526930064056};\\\", \\\"{x:1247,y:525,t:1526930064072};\\\", \\\"{x:1294,y:528,t:1526930064090};\\\", \\\"{x:1305,y:531,t:1526930064106};\\\", \\\"{x:1305,y:532,t:1526930064140};\\\", \\\"{x:1304,y:533,t:1526930064156};\\\", \\\"{x:1303,y:533,t:1526930064172};\\\", \\\"{x:1300,y:534,t:1526930064189};\\\", \\\"{x:1296,y:536,t:1526930064207};\\\", \\\"{x:1292,y:540,t:1526930064222};\\\", \\\"{x:1290,y:545,t:1526930064239};\\\", \\\"{x:1288,y:551,t:1526930064256};\\\", \\\"{x:1288,y:556,t:1526930064272};\\\", \\\"{x:1288,y:560,t:1526930064290};\\\", \\\"{x:1291,y:563,t:1526930064307};\\\", \\\"{x:1299,y:565,t:1526930064322};\\\", \\\"{x:1306,y:566,t:1526930064340};\\\", \\\"{x:1311,y:568,t:1526930064357};\\\", \\\"{x:1313,y:571,t:1526930064373};\\\", \\\"{x:1316,y:574,t:1526930064389};\\\", \\\"{x:1320,y:580,t:1526930064406};\\\", \\\"{x:1323,y:583,t:1526930064423};\\\", \\\"{x:1323,y:586,t:1526930064440};\\\", \\\"{x:1324,y:589,t:1526930064456};\\\", \\\"{x:1324,y:592,t:1526930064472};\\\", \\\"{x:1324,y:595,t:1526930064489};\\\", \\\"{x:1324,y:597,t:1526930064506};\\\", \\\"{x:1324,y:602,t:1526930064522};\\\", \\\"{x:1324,y:606,t:1526930064540};\\\", \\\"{x:1321,y:615,t:1526930064557};\\\", \\\"{x:1320,y:619,t:1526930064573};\\\", \\\"{x:1317,y:622,t:1526930064589};\\\", \\\"{x:1317,y:624,t:1526930064607};\\\", \\\"{x:1316,y:626,t:1526930064623};\\\", \\\"{x:1315,y:626,t:1526930064656};\\\", \\\"{x:1314,y:628,t:1526930064672};\\\", \\\"{x:1313,y:630,t:1526930064690};\\\", \\\"{x:1311,y:632,t:1526930064707};\\\", \\\"{x:1304,y:636,t:1526930064724};\\\", \\\"{x:1290,y:639,t:1526930064740};\\\", \\\"{x:1265,y:641,t:1526930064757};\\\", \\\"{x:1190,y:641,t:1526930064773};\\\", \\\"{x:1114,y:638,t:1526930064790};\\\", \\\"{x:1026,y:629,t:1526930064806};\\\", \\\"{x:940,y:618,t:1526930064824};\\\", \\\"{x:859,y:605,t:1526930064840};\\\", \\\"{x:806,y:597,t:1526930064858};\\\", \\\"{x:777,y:593,t:1526930064873};\\\", \\\"{x:761,y:588,t:1526930064891};\\\", \\\"{x:749,y:584,t:1526930064908};\\\", \\\"{x:743,y:582,t:1526930064923};\\\", \\\"{x:732,y:578,t:1526930064940};\\\", \\\"{x:729,y:577,t:1526930064956};\\\", \\\"{x:725,y:576,t:1526930064974};\\\", \\\"{x:727,y:574,t:1526930065020};\\\", \\\"{x:734,y:574,t:1526930065028};\\\", \\\"{x:744,y:571,t:1526930065040};\\\", \\\"{x:764,y:569,t:1526930065058};\\\", \\\"{x:790,y:564,t:1526930065073};\\\", \\\"{x:811,y:562,t:1526930065090};\\\", \\\"{x:837,y:558,t:1526930065107};\\\", \\\"{x:858,y:557,t:1526930065124};\\\", \\\"{x:866,y:554,t:1526930065140};\\\", \\\"{x:866,y:552,t:1526930065229};\\\", \\\"{x:866,y:551,t:1526930065245};\\\", \\\"{x:866,y:549,t:1526930065257};\\\", \\\"{x:866,y:545,t:1526930065274};\\\", \\\"{x:866,y:544,t:1526930065291};\\\", \\\"{x:860,y:536,t:1526930065308};\\\", \\\"{x:856,y:534,t:1526930065323};\\\", \\\"{x:851,y:532,t:1526930065340};\\\", \\\"{x:849,y:532,t:1526930065357};\\\", \\\"{x:847,y:531,t:1526930065373};\\\", \\\"{x:846,y:531,t:1526930065391};\\\", \\\"{x:844,y:531,t:1526930065409};\\\", \\\"{x:841,y:531,t:1526930065424};\\\", \\\"{x:839,y:531,t:1526930065441};\\\", \\\"{x:837,y:531,t:1526930065457};\\\", \\\"{x:835,y:531,t:1526930065473};\\\", \\\"{x:835,y:530,t:1526930065581};\\\", \\\"{x:834,y:530,t:1526930065619};\\\", \\\"{x:817,y:540,t:1526930065641};\\\", \\\"{x:789,y:559,t:1526930065658};\\\", \\\"{x:734,y:592,t:1526930065674};\\\", \\\"{x:674,y:625,t:1526930065691};\\\", \\\"{x:626,y:660,t:1526930065708};\\\", \\\"{x:576,y:699,t:1526930065725};\\\", \\\"{x:565,y:709,t:1526930065740};\\\", \\\"{x:559,y:716,t:1526930065758};\\\", \\\"{x:558,y:718,t:1526930065775};\\\", \\\"{x:557,y:719,t:1526930065792};\\\", \\\"{x:555,y:722,t:1526930065807};\\\", \\\"{x:551,y:725,t:1526930065824};\\\", \\\"{x:548,y:728,t:1526930065842};\\\", \\\"{x:542,y:732,t:1526930065857};\\\", \\\"{x:537,y:737,t:1526930065874};\\\", \\\"{x:535,y:740,t:1526930065891};\\\", \\\"{x:534,y:741,t:1526930065908};\\\", \\\"{x:533,y:742,t:1526930066405};\\\", \\\"{x:534,y:741,t:1526930066558};\\\", \\\"{x:550,y:740,t:1526930066575};\\\", \\\"{x:582,y:740,t:1526930066592};\\\", \\\"{x:616,y:740,t:1526930066609};\\\", \\\"{x:646,y:740,t:1526930066625};\\\", \\\"{x:673,y:738,t:1526930066641};\\\", \\\"{x:690,y:736,t:1526930066658};\\\", \\\"{x:697,y:733,t:1526930066674};\\\", \\\"{x:703,y:732,t:1526930066691};\\\", \\\"{x:714,y:732,t:1526930066708};\\\", \\\"{x:720,y:731,t:1526930066724};\\\", \\\"{x:732,y:728,t:1526930066742};\\\", \\\"{x:736,y:727,t:1526930066758};\\\", \\\"{x:738,y:727,t:1526930066774};\\\", \\\"{x:740,y:725,t:1526930066792};\\\" ] }, { \\\"rt\\\": 16494, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 446813, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -G -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:741,y:725,t:1526930068542};\\\", \\\"{x:742,y:725,t:1526930068597};\\\", \\\"{x:743,y:725,t:1526930068628};\\\", \\\"{x:744,y:725,t:1526930068974};\\\", \\\"{x:745,y:725,t:1526930069997};\\\", \\\"{x:746,y:726,t:1526930070397};\\\", \\\"{x:747,y:726,t:1526930070413};\\\", \\\"{x:748,y:726,t:1526930070428};\\\", \\\"{x:749,y:726,t:1526930070445};\\\", \\\"{x:750,y:728,t:1526930070469};\\\", \\\"{x:752,y:728,t:1526930070477};\\\", \\\"{x:760,y:733,t:1526930070495};\\\", \\\"{x:771,y:738,t:1526930070512};\\\", \\\"{x:786,y:744,t:1526930070527};\\\", \\\"{x:809,y:753,t:1526930070545};\\\", \\\"{x:838,y:760,t:1526930070562};\\\", \\\"{x:871,y:769,t:1526930070578};\\\", \\\"{x:899,y:777,t:1526930070595};\\\", \\\"{x:927,y:786,t:1526930070612};\\\", \\\"{x:961,y:796,t:1526930070628};\\\", \\\"{x:1000,y:802,t:1526930070646};\\\", \\\"{x:1019,y:804,t:1526930070662};\\\", \\\"{x:1035,y:807,t:1526930070678};\\\", \\\"{x:1046,y:808,t:1526930070695};\\\", \\\"{x:1059,y:810,t:1526930070712};\\\", \\\"{x:1074,y:813,t:1526930070728};\\\", \\\"{x:1099,y:815,t:1526930070746};\\\", \\\"{x:1127,y:820,t:1526930070762};\\\", \\\"{x:1153,y:823,t:1526930070778};\\\", \\\"{x:1176,y:825,t:1526930070795};\\\", \\\"{x:1190,y:829,t:1526930070812};\\\", \\\"{x:1199,y:829,t:1526930070828};\\\", \\\"{x:1201,y:830,t:1526930070845};\\\", \\\"{x:1202,y:830,t:1526930070862};\\\", \\\"{x:1209,y:829,t:1526930070881};\\\", \\\"{x:1214,y:827,t:1526930070894};\\\", \\\"{x:1215,y:825,t:1526930071317};\\\", \\\"{x:1218,y:819,t:1526930071331};\\\", \\\"{x:1229,y:798,t:1526930071346};\\\", \\\"{x:1241,y:777,t:1526930071363};\\\", \\\"{x:1245,y:771,t:1526930071379};\\\", \\\"{x:1264,y:735,t:1526930071395};\\\", \\\"{x:1275,y:714,t:1526930071412};\\\", \\\"{x:1295,y:684,t:1526930071429};\\\", \\\"{x:1307,y:649,t:1526930071445};\\\", \\\"{x:1314,y:614,t:1526930071462};\\\", \\\"{x:1325,y:580,t:1526930071479};\\\", \\\"{x:1332,y:556,t:1526930071497};\\\", \\\"{x:1334,y:538,t:1526930071512};\\\", \\\"{x:1334,y:527,t:1526930071530};\\\", \\\"{x:1334,y:523,t:1526930071547};\\\", \\\"{x:1333,y:521,t:1526930071562};\\\", \\\"{x:1330,y:521,t:1526930071579};\\\", \\\"{x:1328,y:521,t:1526930071596};\\\", \\\"{x:1326,y:521,t:1526930071612};\\\", \\\"{x:1321,y:528,t:1526930071628};\\\", \\\"{x:1316,y:534,t:1526930071646};\\\", \\\"{x:1313,y:541,t:1526930071662};\\\", \\\"{x:1313,y:544,t:1526930071678};\\\", \\\"{x:1314,y:548,t:1526930071696};\\\", \\\"{x:1314,y:549,t:1526930071712};\\\", \\\"{x:1314,y:551,t:1526930071729};\\\", \\\"{x:1314,y:552,t:1526930071745};\\\", \\\"{x:1314,y:553,t:1526930071838};\\\", \\\"{x:1314,y:554,t:1526930071846};\\\", \\\"{x:1313,y:554,t:1526930071869};\\\", \\\"{x:1312,y:554,t:1526930071909};\\\", \\\"{x:1311,y:554,t:1526930071925};\\\", \\\"{x:1310,y:554,t:1526930071933};\\\", \\\"{x:1308,y:555,t:1526930071946};\\\", \\\"{x:1307,y:555,t:1526930071963};\\\", \\\"{x:1303,y:556,t:1526930071979};\\\", \\\"{x:1302,y:556,t:1526930071997};\\\", \\\"{x:1300,y:557,t:1526930072013};\\\", \\\"{x:1298,y:558,t:1526930072030};\\\", \\\"{x:1297,y:558,t:1526930072046};\\\", \\\"{x:1295,y:558,t:1526930072069};\\\", \\\"{x:1298,y:558,t:1526930072166};\\\", \\\"{x:1301,y:558,t:1526930072179};\\\", \\\"{x:1311,y:558,t:1526930072196};\\\", \\\"{x:1340,y:558,t:1526930072213};\\\", \\\"{x:1354,y:558,t:1526930072229};\\\", \\\"{x:1359,y:558,t:1526930072246};\\\", \\\"{x:1362,y:558,t:1526930072263};\\\", \\\"{x:1363,y:558,t:1526930072414};\\\", \\\"{x:1365,y:559,t:1526930072437};\\\", \\\"{x:1366,y:559,t:1526930072446};\\\", \\\"{x:1371,y:559,t:1526930072463};\\\", \\\"{x:1377,y:560,t:1526930072480};\\\", \\\"{x:1384,y:560,t:1526930072496};\\\", \\\"{x:1392,y:560,t:1526930072513};\\\", \\\"{x:1402,y:560,t:1526930072531};\\\", \\\"{x:1412,y:560,t:1526930072547};\\\", \\\"{x:1416,y:560,t:1526930072563};\\\", \\\"{x:1418,y:560,t:1526930072580};\\\", \\\"{x:1419,y:560,t:1526930072621};\\\", \\\"{x:1421,y:560,t:1526930072639};\\\", \\\"{x:1423,y:560,t:1526930072647};\\\", \\\"{x:1425,y:560,t:1526930072663};\\\", \\\"{x:1426,y:560,t:1526930072757};\\\", \\\"{x:1425,y:564,t:1526930077917};\\\", \\\"{x:1413,y:579,t:1526930077934};\\\", \\\"{x:1397,y:599,t:1526930077951};\\\", \\\"{x:1378,y:620,t:1526930077968};\\\", \\\"{x:1358,y:639,t:1526930077983};\\\", \\\"{x:1337,y:658,t:1526930078000};\\\", \\\"{x:1321,y:676,t:1526930078017};\\\", \\\"{x:1307,y:692,t:1526930078033};\\\", \\\"{x:1296,y:706,t:1526930078051};\\\", \\\"{x:1287,y:718,t:1526930078068};\\\", \\\"{x:1276,y:733,t:1526930078084};\\\", \\\"{x:1267,y:743,t:1526930078100};\\\", \\\"{x:1255,y:763,t:1526930078117};\\\", \\\"{x:1247,y:773,t:1526930078134};\\\", \\\"{x:1236,y:788,t:1526930078150};\\\", \\\"{x:1227,y:800,t:1526930078168};\\\", \\\"{x:1216,y:816,t:1526930078185};\\\", \\\"{x:1207,y:830,t:1526930078201};\\\", \\\"{x:1197,y:843,t:1526930078218};\\\", \\\"{x:1187,y:854,t:1526930078234};\\\", \\\"{x:1178,y:868,t:1526930078250};\\\", \\\"{x:1168,y:877,t:1526930078267};\\\", \\\"{x:1158,y:885,t:1526930078284};\\\", \\\"{x:1147,y:893,t:1526930078301};\\\", \\\"{x:1138,y:899,t:1526930078317};\\\", \\\"{x:1133,y:902,t:1526930078334};\\\", \\\"{x:1127,y:906,t:1526930078350};\\\", \\\"{x:1124,y:909,t:1526930078367};\\\", \\\"{x:1119,y:912,t:1526930078385};\\\", \\\"{x:1117,y:914,t:1526930078400};\\\", \\\"{x:1113,y:917,t:1526930078417};\\\", \\\"{x:1108,y:920,t:1526930078434};\\\", \\\"{x:1105,y:923,t:1526930078450};\\\", \\\"{x:1102,y:926,t:1526930078468};\\\", \\\"{x:1102,y:927,t:1526930078485};\\\", \\\"{x:1100,y:929,t:1526930078501};\\\", \\\"{x:1099,y:931,t:1526930078517};\\\", \\\"{x:1097,y:933,t:1526930078535};\\\", \\\"{x:1095,y:934,t:1526930078552};\\\", \\\"{x:1093,y:936,t:1526930078568};\\\", \\\"{x:1091,y:938,t:1526930078584};\\\", \\\"{x:1089,y:940,t:1526930078601};\\\", \\\"{x:1088,y:942,t:1526930078618};\\\", \\\"{x:1087,y:943,t:1526930078634};\\\", \\\"{x:1086,y:944,t:1526930078652};\\\", \\\"{x:1085,y:944,t:1526930078667};\\\", \\\"{x:1085,y:945,t:1526930078684};\\\", \\\"{x:1084,y:946,t:1526930078701};\\\", \\\"{x:1083,y:946,t:1526930078789};\\\", \\\"{x:1083,y:945,t:1526930078821};\\\", \\\"{x:1084,y:940,t:1526930078835};\\\", \\\"{x:1091,y:924,t:1526930078852};\\\", \\\"{x:1104,y:907,t:1526930078868};\\\", \\\"{x:1130,y:868,t:1526930078885};\\\", \\\"{x:1150,y:840,t:1526930078901};\\\", \\\"{x:1167,y:813,t:1526930078918};\\\", \\\"{x:1182,y:789,t:1526930078935};\\\", \\\"{x:1199,y:756,t:1526930078952};\\\", \\\"{x:1208,y:732,t:1526930078967};\\\", \\\"{x:1213,y:710,t:1526930078985};\\\", \\\"{x:1222,y:689,t:1526930079002};\\\", \\\"{x:1230,y:670,t:1526930079018};\\\", \\\"{x:1236,y:654,t:1526930079035};\\\", \\\"{x:1243,y:640,t:1526930079051};\\\", \\\"{x:1245,y:631,t:1526930079068};\\\", \\\"{x:1249,y:624,t:1526930079085};\\\", \\\"{x:1254,y:613,t:1526930079101};\\\", \\\"{x:1258,y:607,t:1526930079118};\\\", \\\"{x:1261,y:601,t:1526930079134};\\\", \\\"{x:1263,y:594,t:1526930079152};\\\", \\\"{x:1264,y:591,t:1526930079168};\\\", \\\"{x:1266,y:585,t:1526930079185};\\\", \\\"{x:1268,y:580,t:1526930079202};\\\", \\\"{x:1270,y:575,t:1526930079218};\\\", \\\"{x:1272,y:571,t:1526930079234};\\\", \\\"{x:1273,y:567,t:1526930079252};\\\", \\\"{x:1273,y:565,t:1526930079269};\\\", \\\"{x:1274,y:563,t:1526930079285};\\\", \\\"{x:1274,y:562,t:1526930079310};\\\", \\\"{x:1275,y:561,t:1526930079319};\\\", \\\"{x:1275,y:560,t:1526930079341};\\\", \\\"{x:1275,y:559,t:1526930079357};\\\", \\\"{x:1276,y:558,t:1526930079677};\\\", \\\"{x:1277,y:559,t:1526930079685};\\\", \\\"{x:1280,y:565,t:1526930079701};\\\", \\\"{x:1282,y:575,t:1526930079720};\\\", \\\"{x:1285,y:580,t:1526930079736};\\\", \\\"{x:1287,y:588,t:1526930079751};\\\", \\\"{x:1290,y:596,t:1526930079769};\\\", \\\"{x:1293,y:603,t:1526930079785};\\\", \\\"{x:1294,y:608,t:1526930079802};\\\", \\\"{x:1296,y:615,t:1526930079818};\\\", \\\"{x:1298,y:619,t:1526930079835};\\\", \\\"{x:1299,y:621,t:1526930079851};\\\", \\\"{x:1300,y:624,t:1526930079868};\\\", \\\"{x:1302,y:629,t:1526930079885};\\\", \\\"{x:1304,y:634,t:1526930079901};\\\", \\\"{x:1307,y:641,t:1526930079919};\\\", \\\"{x:1309,y:645,t:1526930079936};\\\", \\\"{x:1312,y:651,t:1526930079952};\\\", \\\"{x:1315,y:656,t:1526930079969};\\\", \\\"{x:1318,y:661,t:1526930079986};\\\", \\\"{x:1322,y:668,t:1526930080003};\\\", \\\"{x:1324,y:673,t:1526930080019};\\\", \\\"{x:1327,y:679,t:1526930080036};\\\", \\\"{x:1329,y:680,t:1526930080052};\\\", \\\"{x:1329,y:682,t:1526930080069};\\\", \\\"{x:1331,y:685,t:1526930080085};\\\", \\\"{x:1332,y:688,t:1526930080103};\\\", \\\"{x:1335,y:691,t:1526930080119};\\\", \\\"{x:1337,y:694,t:1526930080136};\\\", \\\"{x:1340,y:699,t:1526930080153};\\\", \\\"{x:1344,y:703,t:1526930080168};\\\", \\\"{x:1344,y:706,t:1526930080186};\\\", \\\"{x:1346,y:711,t:1526930080203};\\\", \\\"{x:1348,y:714,t:1526930080218};\\\", \\\"{x:1350,y:718,t:1526930080236};\\\", \\\"{x:1351,y:720,t:1526930080252};\\\", \\\"{x:1352,y:722,t:1526930080269};\\\", \\\"{x:1353,y:724,t:1526930080285};\\\", \\\"{x:1353,y:727,t:1526930080302};\\\", \\\"{x:1353,y:729,t:1526930080319};\\\", \\\"{x:1355,y:732,t:1526930080335};\\\", \\\"{x:1358,y:739,t:1526930080353};\\\", \\\"{x:1361,y:744,t:1526930080369};\\\", \\\"{x:1363,y:750,t:1526930080386};\\\", \\\"{x:1366,y:756,t:1526930080402};\\\", \\\"{x:1367,y:760,t:1526930080419};\\\", \\\"{x:1370,y:767,t:1526930080435};\\\", \\\"{x:1373,y:773,t:1526930080452};\\\", \\\"{x:1375,y:779,t:1526930080469};\\\", \\\"{x:1376,y:780,t:1526930080486};\\\", \\\"{x:1377,y:782,t:1526930080503};\\\", \\\"{x:1378,y:783,t:1526930080573};\\\", \\\"{x:1378,y:785,t:1526930080621};\\\", \\\"{x:1378,y:782,t:1526930080773};\\\", \\\"{x:1377,y:776,t:1526930080785};\\\", \\\"{x:1373,y:763,t:1526930080803};\\\", \\\"{x:1369,y:747,t:1526930080820};\\\", \\\"{x:1364,y:729,t:1526930080836};\\\", \\\"{x:1357,y:696,t:1526930080853};\\\", \\\"{x:1347,y:674,t:1526930080869};\\\", \\\"{x:1338,y:659,t:1526930080885};\\\", \\\"{x:1328,y:647,t:1526930080903};\\\", \\\"{x:1319,y:640,t:1526930080920};\\\", \\\"{x:1316,y:637,t:1526930080936};\\\", \\\"{x:1314,y:635,t:1526930080952};\\\", \\\"{x:1313,y:634,t:1526930080970};\\\", \\\"{x:1310,y:632,t:1526930080987};\\\", \\\"{x:1308,y:630,t:1526930081003};\\\", \\\"{x:1308,y:629,t:1526930081020};\\\", \\\"{x:1308,y:628,t:1526930081037};\\\", \\\"{x:1307,y:624,t:1526930081053};\\\", \\\"{x:1306,y:617,t:1526930081069};\\\", \\\"{x:1305,y:607,t:1526930081086};\\\", \\\"{x:1300,y:592,t:1526930081103};\\\", \\\"{x:1293,y:582,t:1526930081119};\\\", \\\"{x:1290,y:577,t:1526930081136};\\\", \\\"{x:1286,y:573,t:1526930081152};\\\", \\\"{x:1284,y:571,t:1526930081170};\\\", \\\"{x:1283,y:570,t:1526930081186};\\\", \\\"{x:1282,y:570,t:1526930081213};\\\", \\\"{x:1279,y:570,t:1526930081220};\\\", \\\"{x:1271,y:568,t:1526930081237};\\\", \\\"{x:1253,y:568,t:1526930081253};\\\", \\\"{x:1227,y:566,t:1526930081270};\\\", \\\"{x:1196,y:561,t:1526930081287};\\\", \\\"{x:1147,y:552,t:1526930081302};\\\", \\\"{x:1083,y:541,t:1526930081319};\\\", \\\"{x:1013,y:533,t:1526930081336};\\\", \\\"{x:939,y:526,t:1526930081354};\\\", \\\"{x:871,y:512,t:1526930081369};\\\", \\\"{x:724,y:512,t:1526930081403};\\\", \\\"{x:637,y:512,t:1526930081420};\\\", \\\"{x:600,y:512,t:1526930081437};\\\", \\\"{x:573,y:512,t:1526930081453};\\\", \\\"{x:555,y:512,t:1526930081470};\\\", \\\"{x:541,y:512,t:1526930081487};\\\", \\\"{x:525,y:512,t:1526930081504};\\\", \\\"{x:505,y:514,t:1526930081519};\\\", \\\"{x:487,y:517,t:1526930081537};\\\", \\\"{x:478,y:519,t:1526930081555};\\\", \\\"{x:476,y:521,t:1526930081570};\\\", \\\"{x:475,y:521,t:1526930081612};\\\", \\\"{x:475,y:523,t:1526930081629};\\\", \\\"{x:475,y:524,t:1526930081636};\\\", \\\"{x:476,y:528,t:1526930081655};\\\", \\\"{x:483,y:529,t:1526930081670};\\\", \\\"{x:495,y:529,t:1526930081687};\\\", \\\"{x:510,y:529,t:1526930081705};\\\", \\\"{x:523,y:529,t:1526930081720};\\\", \\\"{x:533,y:529,t:1526930081737};\\\", \\\"{x:542,y:529,t:1526930081754};\\\", \\\"{x:551,y:526,t:1526930081770};\\\", \\\"{x:560,y:523,t:1526930081787};\\\", \\\"{x:572,y:520,t:1526930081804};\\\", \\\"{x:576,y:520,t:1526930081819};\\\", \\\"{x:588,y:520,t:1526930081837};\\\", \\\"{x:589,y:520,t:1526930081853};\\\", \\\"{x:590,y:519,t:1526930081917};\\\", \\\"{x:591,y:518,t:1526930081949};\\\", \\\"{x:592,y:517,t:1526930081981};\\\", \\\"{x:593,y:516,t:1526930081988};\\\", \\\"{x:596,y:514,t:1526930082004};\\\", \\\"{x:599,y:511,t:1526930082020};\\\", \\\"{x:603,y:507,t:1526930082037};\\\", \\\"{x:605,y:506,t:1526930082054};\\\", \\\"{x:605,y:505,t:1526930082084};\\\", \\\"{x:606,y:505,t:1526930082100};\\\", \\\"{x:610,y:506,t:1526930082348};\\\", \\\"{x:621,y:512,t:1526930082357};\\\", \\\"{x:634,y:515,t:1526930082371};\\\", \\\"{x:664,y:522,t:1526930082388};\\\", \\\"{x:721,y:539,t:1526930082404};\\\", \\\"{x:745,y:546,t:1526930082422};\\\", \\\"{x:759,y:549,t:1526930082438};\\\", \\\"{x:761,y:549,t:1526930082454};\\\", \\\"{x:764,y:549,t:1526930082492};\\\", \\\"{x:768,y:549,t:1526930082504};\\\", \\\"{x:798,y:549,t:1526930082521};\\\", \\\"{x:843,y:549,t:1526930082538};\\\", \\\"{x:870,y:547,t:1526930082554};\\\", \\\"{x:873,y:546,t:1526930082571};\\\", \\\"{x:875,y:546,t:1526930082588};\\\", \\\"{x:874,y:544,t:1526930082717};\\\", \\\"{x:872,y:543,t:1526930082725};\\\", \\\"{x:868,y:542,t:1526930082739};\\\", \\\"{x:865,y:541,t:1526930082754};\\\", \\\"{x:861,y:539,t:1526930082771};\\\", \\\"{x:858,y:538,t:1526930082787};\\\", \\\"{x:852,y:535,t:1526930082804};\\\", \\\"{x:847,y:535,t:1526930082821};\\\", \\\"{x:845,y:534,t:1526930082837};\\\", \\\"{x:843,y:533,t:1526930082854};\\\", \\\"{x:842,y:533,t:1526930082884};\\\", \\\"{x:840,y:535,t:1526930083084};\\\", \\\"{x:830,y:538,t:1526930083092};\\\", \\\"{x:819,y:544,t:1526930083105};\\\", \\\"{x:778,y:562,t:1526930083121};\\\", \\\"{x:728,y:582,t:1526930083139};\\\", \\\"{x:683,y:599,t:1526930083155};\\\", \\\"{x:654,y:611,t:1526930083171};\\\", \\\"{x:637,y:627,t:1526930083187};\\\", \\\"{x:633,y:636,t:1526930083205};\\\", \\\"{x:631,y:646,t:1526930083221};\\\", \\\"{x:627,y:655,t:1526930083238};\\\", \\\"{x:623,y:661,t:1526930083255};\\\", \\\"{x:617,y:669,t:1526930083271};\\\", \\\"{x:612,y:675,t:1526930083288};\\\", \\\"{x:607,y:681,t:1526930083305};\\\", \\\"{x:602,y:687,t:1526930083321};\\\", \\\"{x:599,y:692,t:1526930083338};\\\", \\\"{x:597,y:695,t:1526930083355};\\\", \\\"{x:592,y:699,t:1526930083371};\\\", \\\"{x:584,y:704,t:1526930083388};\\\", \\\"{x:576,y:707,t:1526930083405};\\\", \\\"{x:566,y:710,t:1526930083422};\\\", \\\"{x:563,y:713,t:1526930083439};\\\", \\\"{x:561,y:715,t:1526930083454};\\\", \\\"{x:558,y:717,t:1526930083472};\\\", \\\"{x:557,y:718,t:1526930083488};\\\", \\\"{x:555,y:719,t:1526930083505};\\\", \\\"{x:551,y:720,t:1526930083522};\\\", \\\"{x:549,y:721,t:1526930083538};\\\", \\\"{x:548,y:722,t:1526930083717};\\\", \\\"{x:547,y:722,t:1526930083725};\\\", \\\"{x:547,y:724,t:1526930083740};\\\", \\\"{x:545,y:726,t:1526930083755};\\\", \\\"{x:543,y:729,t:1526930083772};\\\", \\\"{x:543,y:730,t:1526930083790};\\\", \\\"{x:542,y:730,t:1526930083996};\\\", \\\"{x:542,y:731,t:1526930084397};\\\", \\\"{x:545,y:732,t:1526930084406};\\\", \\\"{x:549,y:736,t:1526930084422};\\\", \\\"{x:549,y:738,t:1526930084440};\\\", \\\"{x:550,y:739,t:1526930084457};\\\", \\\"{x:550,y:740,t:1526930084472};\\\", \\\"{x:550,y:741,t:1526930084489};\\\", \\\"{x:560,y:748,t:1526930084507};\\\", \\\"{x:564,y:751,t:1526930084522};\\\" ] }, { \\\"rt\\\": 28062, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 476148, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -O -O -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:564,y:752,t:1526930085191};\\\", \\\"{x:564,y:753,t:1526930085836};\\\", \\\"{x:564,y:752,t:1526930086917};\\\", \\\"{x:564,y:751,t:1526930086924};\\\", \\\"{x:566,y:748,t:1526930086941};\\\", \\\"{x:570,y:743,t:1526930086959};\\\", \\\"{x:576,y:739,t:1526930086974};\\\", \\\"{x:588,y:732,t:1526930086991};\\\", \\\"{x:598,y:728,t:1526930087008};\\\", \\\"{x:621,y:719,t:1526930087025};\\\", \\\"{x:638,y:710,t:1526930087041};\\\", \\\"{x:658,y:701,t:1526930087059};\\\", \\\"{x:677,y:690,t:1526930087074};\\\", \\\"{x:699,y:681,t:1526930087091};\\\", \\\"{x:726,y:670,t:1526930087109};\\\", \\\"{x:746,y:660,t:1526930087125};\\\", \\\"{x:763,y:655,t:1526930087141};\\\", \\\"{x:782,y:647,t:1526930087159};\\\", \\\"{x:803,y:638,t:1526930087174};\\\", \\\"{x:824,y:628,t:1526930087193};\\\", \\\"{x:849,y:621,t:1526930087208};\\\", \\\"{x:894,y:606,t:1526930087241};\\\", \\\"{x:907,y:601,t:1526930087258};\\\", \\\"{x:925,y:596,t:1526930087275};\\\", \\\"{x:940,y:590,t:1526930087291};\\\", \\\"{x:964,y:583,t:1526930087308};\\\", \\\"{x:975,y:577,t:1526930087325};\\\", \\\"{x:997,y:572,t:1526930087341};\\\", \\\"{x:1009,y:568,t:1526930087358};\\\", \\\"{x:1023,y:563,t:1526930087375};\\\", \\\"{x:1044,y:557,t:1526930087392};\\\", \\\"{x:1075,y:553,t:1526930087408};\\\", \\\"{x:1101,y:548,t:1526930087425};\\\", \\\"{x:1128,y:541,t:1526930087441};\\\", \\\"{x:1154,y:535,t:1526930087458};\\\", \\\"{x:1175,y:529,t:1526930087476};\\\", \\\"{x:1200,y:523,t:1526930087492};\\\", \\\"{x:1227,y:514,t:1526930087508};\\\", \\\"{x:1237,y:512,t:1526930087525};\\\", \\\"{x:1250,y:507,t:1526930087542};\\\", \\\"{x:1256,y:504,t:1526930087559};\\\", \\\"{x:1260,y:503,t:1526930087575};\\\", \\\"{x:1262,y:501,t:1526930087592};\\\", \\\"{x:1263,y:500,t:1526930087608};\\\", \\\"{x:1265,y:500,t:1526930087625};\\\", \\\"{x:1265,y:499,t:1526930087710};\\\", \\\"{x:1264,y:498,t:1526930087750};\\\", \\\"{x:1261,y:497,t:1526930087758};\\\", \\\"{x:1254,y:496,t:1526930087776};\\\", \\\"{x:1249,y:493,t:1526930087793};\\\", \\\"{x:1244,y:492,t:1526930087808};\\\", \\\"{x:1243,y:492,t:1526930087826};\\\", \\\"{x:1242,y:492,t:1526930087861};\\\", \\\"{x:1244,y:492,t:1526930088429};\\\", \\\"{x:1245,y:492,t:1526930088443};\\\", \\\"{x:1246,y:493,t:1526930091309};\\\", \\\"{x:1246,y:494,t:1526930091317};\\\", \\\"{x:1246,y:497,t:1526930091329};\\\", \\\"{x:1247,y:504,t:1526930091346};\\\", \\\"{x:1248,y:510,t:1526930091363};\\\", \\\"{x:1248,y:517,t:1526930091379};\\\", \\\"{x:1248,y:522,t:1526930091396};\\\", \\\"{x:1248,y:529,t:1526930091413};\\\", \\\"{x:1247,y:532,t:1526930091429};\\\", \\\"{x:1245,y:535,t:1526930091446};\\\", \\\"{x:1243,y:538,t:1526930091463};\\\", \\\"{x:1240,y:542,t:1526930091479};\\\", \\\"{x:1230,y:551,t:1526930091496};\\\", \\\"{x:1218,y:559,t:1526930091513};\\\", \\\"{x:1207,y:568,t:1526930091529};\\\", \\\"{x:1191,y:574,t:1526930091546};\\\", \\\"{x:1176,y:583,t:1526930091563};\\\", \\\"{x:1168,y:587,t:1526930091579};\\\", \\\"{x:1162,y:590,t:1526930091596};\\\", \\\"{x:1158,y:592,t:1526930091613};\\\", \\\"{x:1156,y:592,t:1526930091645};\\\", \\\"{x:1155,y:593,t:1526930091663};\\\", \\\"{x:1154,y:595,t:1526930091679};\\\", \\\"{x:1152,y:597,t:1526930091696};\\\", \\\"{x:1148,y:600,t:1526930091713};\\\", \\\"{x:1144,y:603,t:1526930091729};\\\", \\\"{x:1136,y:610,t:1526930091746};\\\", \\\"{x:1130,y:614,t:1526930091762};\\\", \\\"{x:1128,y:616,t:1526930091779};\\\", \\\"{x:1124,y:619,t:1526930091796};\\\", \\\"{x:1121,y:620,t:1526930091813};\\\", \\\"{x:1120,y:620,t:1526930091829};\\\", \\\"{x:1120,y:621,t:1526930091933};\\\", \\\"{x:1120,y:622,t:1526930091946};\\\", \\\"{x:1120,y:623,t:1526930091963};\\\", \\\"{x:1120,y:624,t:1526930092020};\\\", \\\"{x:1121,y:624,t:1526930092036};\\\", \\\"{x:1122,y:624,t:1526930092045};\\\", \\\"{x:1123,y:624,t:1526930092062};\\\", \\\"{x:1124,y:623,t:1526930092079};\\\", \\\"{x:1125,y:623,t:1526930092095};\\\", \\\"{x:1126,y:622,t:1526930092113};\\\", \\\"{x:1128,y:622,t:1526930092366};\\\", \\\"{x:1130,y:621,t:1526930092380};\\\", \\\"{x:1145,y:619,t:1526930092397};\\\", \\\"{x:1161,y:619,t:1526930092413};\\\", \\\"{x:1181,y:617,t:1526930092430};\\\", \\\"{x:1197,y:616,t:1526930092447};\\\", \\\"{x:1219,y:616,t:1526930092463};\\\", \\\"{x:1242,y:616,t:1526930092480};\\\", \\\"{x:1262,y:616,t:1526930092497};\\\", \\\"{x:1282,y:616,t:1526930092513};\\\", \\\"{x:1295,y:616,t:1526930092529};\\\", \\\"{x:1306,y:616,t:1526930092547};\\\", \\\"{x:1313,y:615,t:1526930092564};\\\", \\\"{x:1321,y:615,t:1526930092580};\\\", \\\"{x:1336,y:615,t:1526930092597};\\\", \\\"{x:1345,y:615,t:1526930092614};\\\", \\\"{x:1355,y:615,t:1526930092630};\\\", \\\"{x:1364,y:615,t:1526930092647};\\\", \\\"{x:1380,y:615,t:1526930092664};\\\", \\\"{x:1396,y:615,t:1526930092680};\\\", \\\"{x:1411,y:615,t:1526930092697};\\\", \\\"{x:1422,y:615,t:1526930092714};\\\", \\\"{x:1432,y:615,t:1526930092730};\\\", \\\"{x:1437,y:615,t:1526930092747};\\\", \\\"{x:1444,y:615,t:1526930092764};\\\", \\\"{x:1459,y:617,t:1526930092781};\\\", \\\"{x:1485,y:621,t:1526930092797};\\\", \\\"{x:1496,y:622,t:1526930092814};\\\", \\\"{x:1498,y:622,t:1526930092830};\\\", \\\"{x:1499,y:623,t:1526930092847};\\\", \\\"{x:1499,y:626,t:1526930093077};\\\", \\\"{x:1495,y:627,t:1526930093085};\\\", \\\"{x:1494,y:627,t:1526930093097};\\\", \\\"{x:1490,y:628,t:1526930093114};\\\", \\\"{x:1490,y:629,t:1526930093131};\\\", \\\"{x:1489,y:629,t:1526930093149};\\\", \\\"{x:1488,y:630,t:1526930093254};\\\", \\\"{x:1487,y:630,t:1526930093264};\\\", \\\"{x:1485,y:630,t:1526930093281};\\\", \\\"{x:1482,y:630,t:1526930093298};\\\", \\\"{x:1478,y:630,t:1526930093314};\\\", \\\"{x:1470,y:630,t:1526930093331};\\\", \\\"{x:1462,y:630,t:1526930093348};\\\", \\\"{x:1455,y:630,t:1526930093364};\\\", \\\"{x:1450,y:629,t:1526930093383};\\\", \\\"{x:1451,y:629,t:1526930099253};\\\", \\\"{x:1453,y:630,t:1526930099269};\\\", \\\"{x:1454,y:630,t:1526930099294};\\\", \\\"{x:1455,y:632,t:1526930099304};\\\", \\\"{x:1457,y:633,t:1526930099319};\\\", \\\"{x:1461,y:637,t:1526930099336};\\\", \\\"{x:1469,y:644,t:1526930099353};\\\", \\\"{x:1483,y:657,t:1526930099370};\\\", \\\"{x:1502,y:673,t:1526930099387};\\\", \\\"{x:1525,y:687,t:1526930099403};\\\", \\\"{x:1549,y:702,t:1526930099421};\\\", \\\"{x:1554,y:706,t:1526930099436};\\\", \\\"{x:1556,y:707,t:1526930099454};\\\", \\\"{x:1557,y:708,t:1526930099525};\\\", \\\"{x:1557,y:709,t:1526930099537};\\\", \\\"{x:1556,y:711,t:1526930099554};\\\", \\\"{x:1551,y:713,t:1526930099570};\\\", \\\"{x:1546,y:715,t:1526930099586};\\\", \\\"{x:1537,y:717,t:1526930099604};\\\", \\\"{x:1526,y:722,t:1526930099621};\\\", \\\"{x:1524,y:722,t:1526930099636};\\\", \\\"{x:1519,y:723,t:1526930099653};\\\", \\\"{x:1518,y:724,t:1526930099670};\\\", \\\"{x:1517,y:724,t:1526930099686};\\\", \\\"{x:1513,y:727,t:1526930099703};\\\", \\\"{x:1512,y:728,t:1526930099721};\\\", \\\"{x:1508,y:731,t:1526930099737};\\\", \\\"{x:1506,y:733,t:1526930099752};\\\", \\\"{x:1506,y:734,t:1526930099770};\\\", \\\"{x:1506,y:735,t:1526930099787};\\\", \\\"{x:1506,y:736,t:1526930099803};\\\", \\\"{x:1506,y:737,t:1526930099819};\\\", \\\"{x:1506,y:738,t:1526930099844};\\\", \\\"{x:1505,y:739,t:1526930099853};\\\", \\\"{x:1505,y:740,t:1526930099870};\\\", \\\"{x:1505,y:742,t:1526930099887};\\\", \\\"{x:1504,y:744,t:1526930099903};\\\", \\\"{x:1504,y:745,t:1526930100309};\\\", \\\"{x:1505,y:745,t:1526930103549};\\\", \\\"{x:1506,y:745,t:1526930103565};\\\", \\\"{x:1507,y:746,t:1526930103613};\\\", \\\"{x:1508,y:747,t:1526930103637};\\\", \\\"{x:1509,y:747,t:1526930103652};\\\", \\\"{x:1510,y:747,t:1526930103667};\\\", \\\"{x:1512,y:748,t:1526930103683};\\\", \\\"{x:1513,y:749,t:1526930103740};\\\", \\\"{x:1514,y:750,t:1526930103788};\\\", \\\"{x:1515,y:750,t:1526930103829};\\\", \\\"{x:1515,y:751,t:1526930103844};\\\", \\\"{x:1516,y:752,t:1526930103885};\\\", \\\"{x:1516,y:753,t:1526930106365};\\\", \\\"{x:1516,y:755,t:1526930106377};\\\", \\\"{x:1516,y:760,t:1526930106393};\\\", \\\"{x:1516,y:762,t:1526930106410};\\\", \\\"{x:1516,y:765,t:1526930106426};\\\", \\\"{x:1516,y:766,t:1526930106442};\\\", \\\"{x:1516,y:767,t:1526930106459};\\\", \\\"{x:1516,y:768,t:1526930106477};\\\", \\\"{x:1516,y:769,t:1526930106501};\\\", \\\"{x:1516,y:770,t:1526930106516};\\\", \\\"{x:1516,y:771,t:1526930106533};\\\", \\\"{x:1515,y:772,t:1526930106542};\\\", \\\"{x:1514,y:776,t:1526930106559};\\\", \\\"{x:1514,y:778,t:1526930106576};\\\", \\\"{x:1512,y:781,t:1526930106593};\\\", \\\"{x:1512,y:783,t:1526930106609};\\\", \\\"{x:1512,y:784,t:1526930106627};\\\", \\\"{x:1511,y:785,t:1526930106644};\\\", \\\"{x:1508,y:788,t:1526930106660};\\\", \\\"{x:1507,y:792,t:1526930106677};\\\", \\\"{x:1506,y:794,t:1526930106693};\\\", \\\"{x:1503,y:798,t:1526930106710};\\\", \\\"{x:1500,y:801,t:1526930106727};\\\", \\\"{x:1498,y:808,t:1526930106743};\\\", \\\"{x:1492,y:817,t:1526930106760};\\\", \\\"{x:1486,y:828,t:1526930106776};\\\", \\\"{x:1482,y:840,t:1526930106794};\\\", \\\"{x:1478,y:849,t:1526930106809};\\\", \\\"{x:1476,y:856,t:1526930106826};\\\", \\\"{x:1474,y:860,t:1526930106844};\\\", \\\"{x:1473,y:863,t:1526930106860};\\\", \\\"{x:1472,y:865,t:1526930106876};\\\", \\\"{x:1472,y:866,t:1526930106933};\\\", \\\"{x:1472,y:867,t:1526930106957};\\\", \\\"{x:1472,y:868,t:1526930106965};\\\", \\\"{x:1472,y:869,t:1526930106976};\\\", \\\"{x:1471,y:869,t:1526930106993};\\\", \\\"{x:1471,y:870,t:1526930107011};\\\", \\\"{x:1471,y:871,t:1526930107026};\\\", \\\"{x:1470,y:872,t:1526930107043};\\\", \\\"{x:1469,y:875,t:1526930107060};\\\", \\\"{x:1468,y:875,t:1526930107076};\\\", \\\"{x:1468,y:878,t:1526930107093};\\\", \\\"{x:1467,y:880,t:1526930107111};\\\", \\\"{x:1466,y:883,t:1526930107127};\\\", \\\"{x:1464,y:885,t:1526930107144};\\\", \\\"{x:1461,y:891,t:1526930107160};\\\", \\\"{x:1459,y:896,t:1526930107177};\\\", \\\"{x:1457,y:898,t:1526930107194};\\\", \\\"{x:1456,y:901,t:1526930107210};\\\", \\\"{x:1456,y:902,t:1526930107227};\\\", \\\"{x:1455,y:903,t:1526930107243};\\\", \\\"{x:1453,y:906,t:1526930107260};\\\", \\\"{x:1453,y:907,t:1526930107276};\\\", \\\"{x:1452,y:909,t:1526930107294};\\\", \\\"{x:1451,y:911,t:1526930107311};\\\", \\\"{x:1450,y:913,t:1526930107327};\\\", \\\"{x:1449,y:915,t:1526930107349};\\\", \\\"{x:1447,y:917,t:1526930107361};\\\", \\\"{x:1445,y:921,t:1526930107378};\\\", \\\"{x:1443,y:924,t:1526930107393};\\\", \\\"{x:1441,y:928,t:1526930107411};\\\", \\\"{x:1438,y:932,t:1526930107427};\\\", \\\"{x:1436,y:935,t:1526930107444};\\\", \\\"{x:1433,y:939,t:1526930107460};\\\", \\\"{x:1432,y:940,t:1526930107478};\\\", \\\"{x:1431,y:942,t:1526930107494};\\\", \\\"{x:1430,y:943,t:1526930107510};\\\", \\\"{x:1430,y:945,t:1526930107527};\\\", \\\"{x:1429,y:946,t:1526930107544};\\\", \\\"{x:1428,y:948,t:1526930107560};\\\", \\\"{x:1427,y:948,t:1526930107580};\\\", \\\"{x:1427,y:949,t:1526930107597};\\\", \\\"{x:1427,y:950,t:1526930107637};\\\", \\\"{x:1426,y:951,t:1526930107645};\\\", \\\"{x:1426,y:953,t:1526930107669};\\\", \\\"{x:1425,y:953,t:1526930107685};\\\", \\\"{x:1424,y:954,t:1526930107717};\\\", \\\"{x:1424,y:956,t:1526930107728};\\\", \\\"{x:1423,y:956,t:1526930107744};\\\", \\\"{x:1422,y:957,t:1526930107761};\\\", \\\"{x:1422,y:958,t:1526930107777};\\\", \\\"{x:1422,y:959,t:1526930107794};\\\", \\\"{x:1421,y:959,t:1526930107810};\\\", \\\"{x:1421,y:960,t:1526930107827};\\\", \\\"{x:1420,y:962,t:1526930107845};\\\", \\\"{x:1418,y:962,t:1526930107957};\\\", \\\"{x:1416,y:962,t:1526930107964};\\\", \\\"{x:1415,y:962,t:1526930107978};\\\", \\\"{x:1415,y:961,t:1526930107994};\\\", \\\"{x:1414,y:960,t:1526930108061};\\\", \\\"{x:1414,y:959,t:1526930108093};\\\", \\\"{x:1415,y:958,t:1526930108109};\\\", \\\"{x:1415,y:957,t:1526930108125};\\\", \\\"{x:1415,y:956,t:1526930108141};\\\", \\\"{x:1416,y:955,t:1526930108149};\\\", \\\"{x:1416,y:954,t:1526930108165};\\\", \\\"{x:1417,y:953,t:1526930108189};\\\", \\\"{x:1417,y:951,t:1526930108437};\\\", \\\"{x:1406,y:941,t:1526930108444};\\\", \\\"{x:1349,y:896,t:1526930108462};\\\", \\\"{x:1224,y:832,t:1526930108479};\\\", \\\"{x:1049,y:735,t:1526930108495};\\\", \\\"{x:845,y:639,t:1526930108512};\\\", \\\"{x:663,y:558,t:1526930108528};\\\", \\\"{x:522,y:494,t:1526930108547};\\\", \\\"{x:436,y:455,t:1526930108562};\\\", \\\"{x:411,y:442,t:1526930108578};\\\", \\\"{x:406,y:437,t:1526930108591};\\\", \\\"{x:406,y:435,t:1526930108608};\\\", \\\"{x:406,y:433,t:1526930108625};\\\", \\\"{x:406,y:432,t:1526930108641};\\\", \\\"{x:406,y:431,t:1526930108675};\\\", \\\"{x:405,y:431,t:1526930108690};\\\", \\\"{x:403,y:433,t:1526930108708};\\\", \\\"{x:401,y:439,t:1526930108725};\\\", \\\"{x:397,y:452,t:1526930108742};\\\", \\\"{x:392,y:468,t:1526930108758};\\\", \\\"{x:389,y:478,t:1526930108776};\\\", \\\"{x:387,y:488,t:1526930108793};\\\", \\\"{x:387,y:496,t:1526930108808};\\\", \\\"{x:387,y:497,t:1526930108826};\\\", \\\"{x:387,y:498,t:1526930108842};\\\", \\\"{x:387,y:499,t:1526930108860};\\\", \\\"{x:386,y:499,t:1526930108973};\\\", \\\"{x:384,y:499,t:1526930108980};\\\", \\\"{x:382,y:498,t:1526930108993};\\\", \\\"{x:376,y:497,t:1526930109011};\\\", \\\"{x:372,y:495,t:1526930109027};\\\", \\\"{x:370,y:494,t:1526930109043};\\\", \\\"{x:364,y:493,t:1526930109059};\\\", \\\"{x:355,y:488,t:1526930109076};\\\", \\\"{x:346,y:487,t:1526930109093};\\\", \\\"{x:336,y:486,t:1526930109111};\\\", \\\"{x:327,y:484,t:1526930109126};\\\", \\\"{x:313,y:484,t:1526930109142};\\\", \\\"{x:290,y:484,t:1526930109159};\\\", \\\"{x:266,y:484,t:1526930109175};\\\", \\\"{x:241,y:484,t:1526930109191};\\\", \\\"{x:222,y:484,t:1526930109209};\\\", \\\"{x:208,y:485,t:1526930109226};\\\", \\\"{x:195,y:489,t:1526930109243};\\\", \\\"{x:183,y:491,t:1526930109259};\\\", \\\"{x:169,y:496,t:1526930109276};\\\", \\\"{x:157,y:501,t:1526930109292};\\\", \\\"{x:146,y:505,t:1526930109309};\\\", \\\"{x:135,y:511,t:1526930109326};\\\", \\\"{x:127,y:516,t:1526930109342};\\\", \\\"{x:126,y:517,t:1526930109360};\\\", \\\"{x:125,y:517,t:1526930109387};\\\", \\\"{x:125,y:518,t:1526930109421};\\\", \\\"{x:124,y:519,t:1526930109428};\\\", \\\"{x:124,y:520,t:1526930109443};\\\", \\\"{x:124,y:522,t:1526930109467};\\\", \\\"{x:125,y:523,t:1526930109491};\\\", \\\"{x:126,y:523,t:1526930109499};\\\", \\\"{x:126,y:524,t:1526930109509};\\\", \\\"{x:130,y:528,t:1526930109526};\\\", \\\"{x:131,y:529,t:1526930109543};\\\", \\\"{x:136,y:536,t:1526930109559};\\\", \\\"{x:142,y:542,t:1526930109576};\\\", \\\"{x:148,y:550,t:1526930109593};\\\", \\\"{x:152,y:556,t:1526930109609};\\\", \\\"{x:158,y:565,t:1526930109626};\\\", \\\"{x:165,y:577,t:1526930109643};\\\", \\\"{x:168,y:585,t:1526930109659};\\\", \\\"{x:171,y:596,t:1526930109676};\\\", \\\"{x:173,y:599,t:1526930109693};\\\", \\\"{x:173,y:601,t:1526930109709};\\\", \\\"{x:174,y:603,t:1526930109726};\\\", \\\"{x:175,y:600,t:1526930109901};\\\", \\\"{x:175,y:597,t:1526930109911};\\\", \\\"{x:176,y:589,t:1526930109927};\\\", \\\"{x:178,y:581,t:1526930109943};\\\", \\\"{x:180,y:574,t:1526930109960};\\\", \\\"{x:183,y:569,t:1526930109975};\\\", \\\"{x:187,y:564,t:1526930109993};\\\", \\\"{x:194,y:559,t:1526930110011};\\\", \\\"{x:213,y:552,t:1526930110027};\\\", \\\"{x:241,y:548,t:1526930110043};\\\", \\\"{x:305,y:548,t:1526930110060};\\\", \\\"{x:350,y:548,t:1526930110076};\\\", \\\"{x:395,y:548,t:1526930110093};\\\", \\\"{x:425,y:548,t:1526930110110};\\\", \\\"{x:447,y:548,t:1526930110126};\\\", \\\"{x:452,y:548,t:1526930110143};\\\", \\\"{x:453,y:548,t:1526930110160};\\\", \\\"{x:454,y:548,t:1526930110177};\\\", \\\"{x:452,y:554,t:1526930110193};\\\", \\\"{x:450,y:559,t:1526930110211};\\\", \\\"{x:445,y:570,t:1526930110228};\\\", \\\"{x:440,y:583,t:1526930110243};\\\", \\\"{x:424,y:604,t:1526930110262};\\\", \\\"{x:410,y:613,t:1526930110277};\\\", \\\"{x:396,y:621,t:1526930110293};\\\", \\\"{x:382,y:627,t:1526930110310};\\\", \\\"{x:375,y:631,t:1526930110326};\\\", \\\"{x:372,y:632,t:1526930110344};\\\", \\\"{x:375,y:630,t:1526930110446};\\\", \\\"{x:393,y:618,t:1526930110460};\\\", \\\"{x:426,y:604,t:1526930110477};\\\", \\\"{x:484,y:589,t:1526930110494};\\\", \\\"{x:554,y:570,t:1526930110511};\\\", \\\"{x:611,y:556,t:1526930110528};\\\", \\\"{x:637,y:552,t:1526930110544};\\\", \\\"{x:650,y:550,t:1526930110559};\\\", \\\"{x:655,y:547,t:1526930110577};\\\", \\\"{x:659,y:547,t:1526930110593};\\\", \\\"{x:661,y:546,t:1526930110609};\\\", \\\"{x:668,y:546,t:1526930110627};\\\", \\\"{x:687,y:545,t:1526930110643};\\\", \\\"{x:721,y:543,t:1526930110660};\\\", \\\"{x:743,y:543,t:1526930110678};\\\", \\\"{x:760,y:543,t:1526930110694};\\\", \\\"{x:773,y:543,t:1526930110710};\\\", \\\"{x:782,y:543,t:1526930110727};\\\", \\\"{x:784,y:543,t:1526930110744};\\\", \\\"{x:785,y:544,t:1526930110771};\\\", \\\"{x:787,y:545,t:1526930110779};\\\", \\\"{x:788,y:545,t:1526930110794};\\\", \\\"{x:802,y:546,t:1526930110810};\\\", \\\"{x:813,y:547,t:1526930110827};\\\", \\\"{x:816,y:547,t:1526930110844};\\\", \\\"{x:817,y:547,t:1526930110868};\\\", \\\"{x:818,y:547,t:1526930110877};\\\", \\\"{x:821,y:547,t:1526930110894};\\\", \\\"{x:822,y:546,t:1526930110910};\\\", \\\"{x:823,y:546,t:1526930110928};\\\", \\\"{x:825,y:546,t:1526930110945};\\\", \\\"{x:826,y:547,t:1526930110960};\\\", \\\"{x:827,y:548,t:1526930110977};\\\", \\\"{x:828,y:550,t:1526930110994};\\\", \\\"{x:829,y:552,t:1526930111010};\\\", \\\"{x:829,y:554,t:1526930111027};\\\", \\\"{x:829,y:557,t:1526930111044};\\\", \\\"{x:829,y:561,t:1526930111060};\\\", \\\"{x:828,y:566,t:1526930111077};\\\", \\\"{x:828,y:569,t:1526930111094};\\\", \\\"{x:827,y:573,t:1526930111110};\\\", \\\"{x:827,y:574,t:1526930111127};\\\", \\\"{x:825,y:577,t:1526930111403};\\\", \\\"{x:816,y:581,t:1526930111411};\\\", \\\"{x:809,y:584,t:1526930111427};\\\", \\\"{x:780,y:595,t:1526930111445};\\\", \\\"{x:762,y:601,t:1526930111461};\\\", \\\"{x:749,y:606,t:1526930111477};\\\", \\\"{x:730,y:610,t:1526930111493};\\\", \\\"{x:712,y:611,t:1526930111512};\\\", \\\"{x:700,y:613,t:1526930111527};\\\", \\\"{x:694,y:613,t:1526930111544};\\\", \\\"{x:690,y:613,t:1526930111561};\\\", \\\"{x:684,y:612,t:1526930111578};\\\", \\\"{x:673,y:607,t:1526930111594};\\\", \\\"{x:657,y:600,t:1526930111613};\\\", \\\"{x:637,y:592,t:1526930111628};\\\", \\\"{x:627,y:591,t:1526930111644};\\\", \\\"{x:623,y:589,t:1526930111661};\\\", \\\"{x:619,y:588,t:1526930111678};\\\", \\\"{x:615,y:585,t:1526930111694};\\\", \\\"{x:613,y:584,t:1526930111711};\\\", \\\"{x:612,y:584,t:1526930111727};\\\", \\\"{x:609,y:582,t:1526930111744};\\\", \\\"{x:608,y:582,t:1526930111763};\\\", \\\"{x:607,y:582,t:1526930111779};\\\", \\\"{x:606,y:581,t:1526930111804};\\\", \\\"{x:605,y:581,t:1526930112044};\\\", \\\"{x:605,y:582,t:1526930112052};\\\", \\\"{x:606,y:584,t:1526930112067};\\\", \\\"{x:606,y:585,t:1526930112079};\\\", \\\"{x:606,y:589,t:1526930112095};\\\", \\\"{x:607,y:591,t:1526930112112};\\\", \\\"{x:608,y:594,t:1526930112129};\\\", \\\"{x:608,y:595,t:1526930112146};\\\", \\\"{x:608,y:596,t:1526930112161};\\\", \\\"{x:609,y:598,t:1526930112381};\\\", \\\"{x:609,y:601,t:1526930112396};\\\", \\\"{x:608,y:611,t:1526930112412};\\\", \\\"{x:603,y:636,t:1526930112429};\\\", \\\"{x:596,y:655,t:1526930112445};\\\", \\\"{x:589,y:672,t:1526930112461};\\\", \\\"{x:583,y:687,t:1526930112478};\\\", \\\"{x:575,y:700,t:1526930112495};\\\", \\\"{x:571,y:710,t:1526930112512};\\\", \\\"{x:566,y:717,t:1526930112528};\\\", \\\"{x:561,y:724,t:1526930112546};\\\", \\\"{x:556,y:726,t:1526930112561};\\\", \\\"{x:551,y:729,t:1526930112578};\\\", \\\"{x:537,y:735,t:1526930112595};\\\", \\\"{x:523,y:740,t:1526930112611};\\\", \\\"{x:498,y:751,t:1526930112628};\\\", \\\"{x:480,y:757,t:1526930112646};\\\", \\\"{x:464,y:764,t:1526930112662};\\\", \\\"{x:453,y:770,t:1526930112678};\\\", \\\"{x:442,y:775,t:1526930112695};\\\", \\\"{x:434,y:780,t:1526930112712};\\\", \\\"{x:429,y:783,t:1526930112728};\\\", \\\"{x:423,y:785,t:1526930112745};\\\", \\\"{x:416,y:789,t:1526930112762};\\\", \\\"{x:407,y:791,t:1526930112779};\\\", \\\"{x:404,y:792,t:1526930112795};\\\", \\\"{x:400,y:795,t:1526930112812};\\\", \\\"{x:404,y:794,t:1526930112892};\\\", \\\"{x:414,y:788,t:1526930112901};\\\", \\\"{x:425,y:783,t:1526930112913};\\\", \\\"{x:452,y:765,t:1526930112929};\\\", \\\"{x:482,y:750,t:1526930112947};\\\", \\\"{x:503,y:739,t:1526930112962};\\\", \\\"{x:511,y:735,t:1526930112979};\\\", \\\"{x:513,y:734,t:1526930112995};\\\", \\\"{x:513,y:732,t:1526930113012};\\\", \\\"{x:515,y:731,t:1526930113029};\\\", \\\"{x:519,y:728,t:1526930113045};\\\", \\\"{x:524,y:725,t:1526930113062};\\\", \\\"{x:525,y:724,t:1526930113079};\\\", \\\"{x:526,y:724,t:1526930114037};\\\", \\\"{x:525,y:724,t:1526930114052};\\\", \\\"{x:525,y:725,t:1526930114068};\\\", \\\"{x:524,y:726,t:1526930114084};\\\", \\\"{x:523,y:726,t:1526930114116};\\\", \\\"{x:521,y:726,t:1526930114172};\\\" ] }, { \\\"rt\\\": 41710, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 519232, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 4, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"G\\\", \\\"C\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -X -F -F -F -G -G -F -F -G -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:521,y:725,t:1526930115084};\\\", \\\"{x:520,y:724,t:1526930115661};\\\", \\\"{x:520,y:723,t:1526930115917};\\\", \\\"{x:520,y:722,t:1526930116052};\\\", \\\"{x:520,y:721,t:1526930116093};\\\", \\\"{x:520,y:720,t:1526930116124};\\\", \\\"{x:520,y:719,t:1526930116518};\\\", \\\"{x:520,y:716,t:1526930116532};\\\", \\\"{x:520,y:715,t:1526930118385};\\\", \\\"{x:521,y:715,t:1526930118816};\\\", \\\"{x:522,y:715,t:1526930118840};\\\", \\\"{x:523,y:715,t:1526930118856};\\\", \\\"{x:524,y:714,t:1526930118889};\\\", \\\"{x:525,y:713,t:1526930118912};\\\", \\\"{x:526,y:712,t:1526930118920};\\\", \\\"{x:527,y:712,t:1526930118936};\\\", \\\"{x:528,y:712,t:1526930118954};\\\", \\\"{x:530,y:712,t:1526930118984};\\\", \\\"{x:530,y:711,t:1526930118992};\\\", \\\"{x:531,y:711,t:1526930119004};\\\", \\\"{x:536,y:711,t:1526930119020};\\\", \\\"{x:538,y:710,t:1526930119037};\\\", \\\"{x:544,y:709,t:1526930119054};\\\", \\\"{x:553,y:708,t:1526930119070};\\\", \\\"{x:571,y:706,t:1526930119086};\\\", \\\"{x:599,y:703,t:1526930119104};\\\", \\\"{x:621,y:703,t:1526930119120};\\\", \\\"{x:633,y:702,t:1526930119137};\\\", \\\"{x:649,y:702,t:1526930119153};\\\", \\\"{x:661,y:702,t:1526930119171};\\\", \\\"{x:670,y:702,t:1526930119187};\\\", \\\"{x:678,y:702,t:1526930119203};\\\", \\\"{x:688,y:702,t:1526930119221};\\\", \\\"{x:691,y:702,t:1526930119236};\\\", \\\"{x:695,y:702,t:1526930119254};\\\", \\\"{x:697,y:702,t:1526930119271};\\\", \\\"{x:701,y:702,t:1526930119287};\\\", \\\"{x:710,y:702,t:1526930119304};\\\", \\\"{x:721,y:702,t:1526930119320};\\\", \\\"{x:730,y:702,t:1526930119337};\\\", \\\"{x:736,y:702,t:1526930119353};\\\", \\\"{x:746,y:704,t:1526930119371};\\\", \\\"{x:771,y:702,t:1526930119386};\\\", \\\"{x:816,y:696,t:1526930119404};\\\", \\\"{x:851,y:695,t:1526930119421};\\\", \\\"{x:880,y:695,t:1526930119437};\\\", \\\"{x:920,y:694,t:1526930119454};\\\", \\\"{x:958,y:694,t:1526930119470};\\\", \\\"{x:1014,y:694,t:1526930119487};\\\", \\\"{x:1117,y:694,t:1526930119504};\\\", \\\"{x:1198,y:694,t:1526930119521};\\\", \\\"{x:1262,y:694,t:1526930119537};\\\", \\\"{x:1323,y:685,t:1526930119553};\\\", \\\"{x:1376,y:679,t:1526930119571};\\\", \\\"{x:1403,y:672,t:1526930119588};\\\", \\\"{x:1418,y:668,t:1526930119604};\\\", \\\"{x:1424,y:664,t:1526930119621};\\\", \\\"{x:1429,y:662,t:1526930119637};\\\", \\\"{x:1431,y:661,t:1526930119654};\\\", \\\"{x:1432,y:660,t:1526930119671};\\\", \\\"{x:1432,y:659,t:1526930119688};\\\", \\\"{x:1434,y:655,t:1526930119705};\\\", \\\"{x:1434,y:652,t:1526930119721};\\\", \\\"{x:1434,y:647,t:1526930119738};\\\", \\\"{x:1421,y:624,t:1526930119753};\\\", \\\"{x:1402,y:598,t:1526930119771};\\\", \\\"{x:1389,y:575,t:1526930119788};\\\", \\\"{x:1370,y:552,t:1526930119804};\\\", \\\"{x:1355,y:537,t:1526930119821};\\\", \\\"{x:1341,y:524,t:1526930119837};\\\", \\\"{x:1330,y:514,t:1526930119853};\\\", \\\"{x:1318,y:506,t:1526930119871};\\\", \\\"{x:1301,y:494,t:1526930119887};\\\", \\\"{x:1298,y:492,t:1526930119904};\\\", \\\"{x:1296,y:492,t:1526930119921};\\\", \\\"{x:1296,y:491,t:1526930120025};\\\", \\\"{x:1296,y:495,t:1526930126625};\\\", \\\"{x:1301,y:504,t:1526930126642};\\\", \\\"{x:1308,y:515,t:1526930126658};\\\", \\\"{x:1318,y:532,t:1526930126676};\\\", \\\"{x:1326,y:546,t:1526930126691};\\\", \\\"{x:1334,y:558,t:1526930126708};\\\", \\\"{x:1340,y:573,t:1526930126726};\\\", \\\"{x:1349,y:591,t:1526930126741};\\\", \\\"{x:1360,y:609,t:1526930126758};\\\", \\\"{x:1368,y:625,t:1526930126775};\\\", \\\"{x:1379,y:643,t:1526930126792};\\\", \\\"{x:1394,y:670,t:1526930126808};\\\", \\\"{x:1405,y:688,t:1526930126826};\\\", \\\"{x:1416,y:705,t:1526930126841};\\\", \\\"{x:1427,y:724,t:1526930126858};\\\", \\\"{x:1437,y:740,t:1526930126875};\\\", \\\"{x:1450,y:760,t:1526930126891};\\\", \\\"{x:1464,y:777,t:1526930126908};\\\", \\\"{x:1476,y:794,t:1526930126925};\\\", \\\"{x:1485,y:805,t:1526930126942};\\\", \\\"{x:1489,y:812,t:1526930126958};\\\", \\\"{x:1490,y:813,t:1526930126976};\\\", \\\"{x:1490,y:814,t:1526930126991};\\\", \\\"{x:1491,y:816,t:1526930127016};\\\", \\\"{x:1491,y:817,t:1526930127040};\\\", \\\"{x:1492,y:819,t:1526930127059};\\\", \\\"{x:1492,y:820,t:1526930127088};\\\", \\\"{x:1492,y:821,t:1526930127177};\\\", \\\"{x:1489,y:821,t:1526930127208};\\\", \\\"{x:1475,y:816,t:1526930127225};\\\", \\\"{x:1457,y:807,t:1526930127241};\\\", \\\"{x:1438,y:800,t:1526930127258};\\\", \\\"{x:1417,y:788,t:1526930127275};\\\", \\\"{x:1397,y:780,t:1526930127291};\\\", \\\"{x:1385,y:774,t:1526930127308};\\\", \\\"{x:1382,y:771,t:1526930127326};\\\", \\\"{x:1381,y:770,t:1526930127341};\\\", \\\"{x:1380,y:768,t:1526930127360};\\\", \\\"{x:1380,y:767,t:1526930127375};\\\", \\\"{x:1379,y:767,t:1526930127393};\\\", \\\"{x:1378,y:765,t:1526930127409};\\\", \\\"{x:1376,y:763,t:1526930127426};\\\", \\\"{x:1376,y:762,t:1526930127443};\\\", \\\"{x:1374,y:761,t:1526930127459};\\\", \\\"{x:1369,y:760,t:1526930127476};\\\", \\\"{x:1360,y:760,t:1526930127493};\\\", \\\"{x:1351,y:757,t:1526930127508};\\\", \\\"{x:1338,y:756,t:1526930127525};\\\", \\\"{x:1332,y:755,t:1526930127543};\\\", \\\"{x:1328,y:754,t:1526930127559};\\\", \\\"{x:1326,y:754,t:1526930127575};\\\", \\\"{x:1326,y:753,t:1526930127592};\\\", \\\"{x:1328,y:753,t:1526930127713};\\\", \\\"{x:1330,y:754,t:1526930127725};\\\", \\\"{x:1336,y:754,t:1526930127743};\\\", \\\"{x:1340,y:757,t:1526930127759};\\\", \\\"{x:1341,y:757,t:1526930127775};\\\", \\\"{x:1342,y:757,t:1526930127792};\\\", \\\"{x:1343,y:758,t:1526930127824};\\\", \\\"{x:1344,y:758,t:1526930127843};\\\", \\\"{x:1346,y:759,t:1526930127861};\\\", \\\"{x:1347,y:760,t:1526930127875};\\\", \\\"{x:1351,y:759,t:1526930131105};\\\", \\\"{x:1358,y:757,t:1526930131114};\\\", \\\"{x:1363,y:754,t:1526930131128};\\\", \\\"{x:1372,y:750,t:1526930131144};\\\", \\\"{x:1386,y:744,t:1526930131161};\\\", \\\"{x:1391,y:741,t:1526930131177};\\\", \\\"{x:1394,y:741,t:1526930131194};\\\", \\\"{x:1394,y:740,t:1526930131211};\\\", \\\"{x:1395,y:740,t:1526930131228};\\\", \\\"{x:1397,y:740,t:1526930131244};\\\", \\\"{x:1409,y:740,t:1526930131260};\\\", \\\"{x:1430,y:741,t:1526930131277};\\\", \\\"{x:1453,y:749,t:1526930131295};\\\", \\\"{x:1474,y:755,t:1526930131311};\\\", \\\"{x:1488,y:760,t:1526930131327};\\\", \\\"{x:1495,y:766,t:1526930131344};\\\", \\\"{x:1498,y:769,t:1526930131361};\\\", \\\"{x:1500,y:773,t:1526930131378};\\\", \\\"{x:1501,y:775,t:1526930131395};\\\", \\\"{x:1502,y:779,t:1526930131411};\\\", \\\"{x:1505,y:784,t:1526930131427};\\\", \\\"{x:1505,y:786,t:1526930131445};\\\", \\\"{x:1505,y:789,t:1526930131461};\\\", \\\"{x:1505,y:791,t:1526930131477};\\\", \\\"{x:1506,y:792,t:1526930131494};\\\", \\\"{x:1506,y:794,t:1526930131511};\\\", \\\"{x:1506,y:795,t:1526930131536};\\\", \\\"{x:1506,y:797,t:1526930131560};\\\", \\\"{x:1504,y:800,t:1526930131578};\\\", \\\"{x:1503,y:802,t:1526930131595};\\\", \\\"{x:1499,y:805,t:1526930131611};\\\", \\\"{x:1496,y:808,t:1526930131628};\\\", \\\"{x:1494,y:810,t:1526930131644};\\\", \\\"{x:1494,y:811,t:1526930131660};\\\", \\\"{x:1494,y:812,t:1526930131677};\\\", \\\"{x:1494,y:814,t:1526930132921};\\\", \\\"{x:1494,y:815,t:1526930133617};\\\", \\\"{x:1494,y:817,t:1526930133759};\\\", \\\"{x:1494,y:818,t:1526930134001};\\\", \\\"{x:1494,y:820,t:1526930134177};\\\", \\\"{x:1494,y:821,t:1526930134471};\\\", \\\"{x:1493,y:821,t:1526930134535};\\\", \\\"{x:1492,y:822,t:1526930134551};\\\", \\\"{x:1491,y:822,t:1526930134567};\\\", \\\"{x:1491,y:823,t:1526930134579};\\\", \\\"{x:1489,y:824,t:1526930134599};\\\", \\\"{x:1488,y:824,t:1526930134632};\\\", \\\"{x:1487,y:824,t:1526930134664};\\\", \\\"{x:1486,y:824,t:1526930134680};\\\", \\\"{x:1485,y:825,t:1526930134696};\\\", \\\"{x:1484,y:825,t:1526930134713};\\\", \\\"{x:1481,y:826,t:1526930134746};\\\", \\\"{x:1477,y:826,t:1526930138104};\\\", \\\"{x:1469,y:826,t:1526930138116};\\\", \\\"{x:1458,y:826,t:1526930138131};\\\", \\\"{x:1442,y:823,t:1526930138148};\\\", \\\"{x:1430,y:821,t:1526930138165};\\\", \\\"{x:1424,y:820,t:1526930138181};\\\", \\\"{x:1422,y:819,t:1526930138198};\\\", \\\"{x:1420,y:817,t:1526930138215};\\\", \\\"{x:1415,y:815,t:1526930138232};\\\", \\\"{x:1410,y:814,t:1526930138248};\\\", \\\"{x:1403,y:811,t:1526930138265};\\\", \\\"{x:1392,y:804,t:1526930138282};\\\", \\\"{x:1380,y:797,t:1526930138298};\\\", \\\"{x:1366,y:789,t:1526930138315};\\\", \\\"{x:1358,y:781,t:1526930138332};\\\", \\\"{x:1348,y:774,t:1526930138348};\\\", \\\"{x:1343,y:771,t:1526930138365};\\\", \\\"{x:1338,y:768,t:1526930138382};\\\", \\\"{x:1337,y:767,t:1526930138397};\\\", \\\"{x:1336,y:766,t:1526930138415};\\\", \\\"{x:1334,y:766,t:1526930138432};\\\", \\\"{x:1332,y:766,t:1526930138449};\\\", \\\"{x:1331,y:764,t:1526930138465};\\\", \\\"{x:1331,y:763,t:1526930139225};\\\", \\\"{x:1331,y:762,t:1526930139249};\\\", \\\"{x:1332,y:762,t:1526930139265};\\\", \\\"{x:1332,y:761,t:1526930139289};\\\", \\\"{x:1333,y:760,t:1526930139304};\\\", \\\"{x:1333,y:759,t:1526930139329};\\\", \\\"{x:1334,y:758,t:1526930139520};\\\", \\\"{x:1335,y:758,t:1526930139532};\\\", \\\"{x:1338,y:757,t:1526930139549};\\\", \\\"{x:1340,y:756,t:1526930139566};\\\", \\\"{x:1341,y:756,t:1526930139582};\\\", \\\"{x:1341,y:754,t:1526930139833};\\\", \\\"{x:1347,y:741,t:1526930139849};\\\", \\\"{x:1352,y:726,t:1526930139866};\\\", \\\"{x:1353,y:714,t:1526930139882};\\\", \\\"{x:1353,y:702,t:1526930139899};\\\", \\\"{x:1353,y:697,t:1526930139917};\\\", \\\"{x:1353,y:693,t:1526930139933};\\\", \\\"{x:1352,y:692,t:1526930139949};\\\", \\\"{x:1350,y:692,t:1526930140033};\\\", \\\"{x:1346,y:692,t:1526930140066};\\\", \\\"{x:1344,y:692,t:1526930140082};\\\", \\\"{x:1338,y:694,t:1526930140100};\\\", \\\"{x:1334,y:696,t:1526930140116};\\\", \\\"{x:1327,y:700,t:1526930140132};\\\", \\\"{x:1321,y:704,t:1526930140149};\\\", \\\"{x:1319,y:706,t:1526930140166};\\\", \\\"{x:1318,y:708,t:1526930140183};\\\", \\\"{x:1318,y:710,t:1526930140199};\\\", \\\"{x:1318,y:711,t:1526930140224};\\\", \\\"{x:1318,y:712,t:1526930140401};\\\", \\\"{x:1319,y:712,t:1526930140416};\\\", \\\"{x:1321,y:711,t:1526930140432};\\\", \\\"{x:1322,y:711,t:1526930140569};\\\", \\\"{x:1323,y:711,t:1526930140624};\\\", \\\"{x:1325,y:709,t:1526930140880};\\\", \\\"{x:1328,y:706,t:1526930140888};\\\", \\\"{x:1331,y:702,t:1526930140900};\\\", \\\"{x:1344,y:689,t:1526930140916};\\\", \\\"{x:1356,y:676,t:1526930140933};\\\", \\\"{x:1365,y:662,t:1526930140950};\\\", \\\"{x:1371,y:648,t:1526930140966};\\\", \\\"{x:1375,y:639,t:1526930140983};\\\", \\\"{x:1378,y:624,t:1526930141000};\\\", \\\"{x:1383,y:612,t:1526930141017};\\\", \\\"{x:1386,y:605,t:1526930141033};\\\", \\\"{x:1390,y:596,t:1526930141051};\\\", \\\"{x:1393,y:589,t:1526930141066};\\\", \\\"{x:1398,y:585,t:1526930141083};\\\", \\\"{x:1402,y:581,t:1526930141100};\\\", \\\"{x:1403,y:577,t:1526930141116};\\\", \\\"{x:1406,y:573,t:1526930141133};\\\", \\\"{x:1407,y:569,t:1526930141150};\\\", \\\"{x:1408,y:567,t:1526930141166};\\\", \\\"{x:1408,y:566,t:1526930141183};\\\", \\\"{x:1409,y:565,t:1526930141233};\\\", \\\"{x:1410,y:562,t:1526930141250};\\\", \\\"{x:1410,y:559,t:1526930141266};\\\", \\\"{x:1410,y:558,t:1526930141291};\\\", \\\"{x:1410,y:557,t:1526930141311};\\\", \\\"{x:1410,y:556,t:1526930141327};\\\", \\\"{x:1412,y:554,t:1526930141335};\\\", \\\"{x:1412,y:553,t:1526930141349};\\\", \\\"{x:1413,y:552,t:1526930141366};\\\", \\\"{x:1413,y:550,t:1526930141382};\\\", \\\"{x:1414,y:549,t:1526930141400};\\\", \\\"{x:1415,y:549,t:1526930141696};\\\", \\\"{x:1417,y:550,t:1526930141704};\\\", \\\"{x:1420,y:555,t:1526930141717};\\\", \\\"{x:1425,y:563,t:1526930141733};\\\", \\\"{x:1430,y:571,t:1526930141751};\\\", \\\"{x:1435,y:580,t:1526930141767};\\\", \\\"{x:1440,y:588,t:1526930141783};\\\", \\\"{x:1448,y:600,t:1526930141800};\\\", \\\"{x:1450,y:604,t:1526930141816};\\\", \\\"{x:1453,y:611,t:1526930141833};\\\", \\\"{x:1456,y:618,t:1526930141850};\\\", \\\"{x:1459,y:623,t:1526930141867};\\\", \\\"{x:1460,y:627,t:1526930141883};\\\", \\\"{x:1461,y:630,t:1526930141901};\\\", \\\"{x:1462,y:632,t:1526930141917};\\\", \\\"{x:1463,y:634,t:1526930141933};\\\", \\\"{x:1463,y:638,t:1526930143089};\\\", \\\"{x:1463,y:645,t:1526930143101};\\\", \\\"{x:1463,y:655,t:1526930143117};\\\", \\\"{x:1465,y:662,t:1526930143134};\\\", \\\"{x:1467,y:669,t:1526930143151};\\\", \\\"{x:1468,y:675,t:1526930143167};\\\", \\\"{x:1470,y:680,t:1526930143184};\\\", \\\"{x:1472,y:685,t:1526930143200};\\\", \\\"{x:1475,y:693,t:1526930143217};\\\", \\\"{x:1477,y:703,t:1526930143233};\\\", \\\"{x:1482,y:714,t:1526930143250};\\\", \\\"{x:1487,y:724,t:1526930143266};\\\", \\\"{x:1489,y:731,t:1526930143284};\\\", \\\"{x:1492,y:737,t:1526930143301};\\\", \\\"{x:1493,y:739,t:1526930143317};\\\", \\\"{x:1494,y:740,t:1526930143334};\\\", \\\"{x:1494,y:742,t:1526930143351};\\\", \\\"{x:1496,y:745,t:1526930143368};\\\", \\\"{x:1493,y:746,t:1526930143481};\\\", \\\"{x:1482,y:746,t:1526930143488};\\\", \\\"{x:1461,y:746,t:1526930143501};\\\", \\\"{x:1382,y:741,t:1526930143518};\\\", \\\"{x:1254,y:720,t:1526930143534};\\\", \\\"{x:1113,y:703,t:1526930143550};\\\", \\\"{x:924,y:664,t:1526930143567};\\\", \\\"{x:844,y:643,t:1526930143583};\\\", \\\"{x:806,y:629,t:1526930143602};\\\", \\\"{x:780,y:619,t:1526930143617};\\\", \\\"{x:754,y:607,t:1526930143633};\\\", \\\"{x:699,y:586,t:1526930143658};\\\", \\\"{x:660,y:573,t:1526930143674};\\\", \\\"{x:626,y:562,t:1526930143691};\\\", \\\"{x:596,y:557,t:1526930143708};\\\", \\\"{x:580,y:554,t:1526930143724};\\\", \\\"{x:575,y:554,t:1526930143741};\\\", \\\"{x:574,y:553,t:1526930143757};\\\", \\\"{x:572,y:553,t:1526930143790};\\\", \\\"{x:560,y:553,t:1526930143808};\\\", \\\"{x:536,y:552,t:1526930143825};\\\", \\\"{x:510,y:549,t:1526930143842};\\\", \\\"{x:478,y:549,t:1526930143858};\\\", \\\"{x:438,y:548,t:1526930143874};\\\", \\\"{x:402,y:548,t:1526930143892};\\\", \\\"{x:377,y:548,t:1526930143907};\\\", \\\"{x:357,y:548,t:1526930143925};\\\", \\\"{x:342,y:548,t:1526930143941};\\\", \\\"{x:336,y:548,t:1526930143958};\\\", \\\"{x:337,y:548,t:1526930144032};\\\", \\\"{x:343,y:546,t:1526930144042};\\\", \\\"{x:360,y:545,t:1526930144057};\\\", \\\"{x:388,y:545,t:1526930144075};\\\", \\\"{x:425,y:545,t:1526930144091};\\\", \\\"{x:471,y:547,t:1526930144108};\\\", \\\"{x:503,y:552,t:1526930144125};\\\", \\\"{x:523,y:555,t:1526930144141};\\\", \\\"{x:529,y:557,t:1526930144158};\\\", \\\"{x:530,y:558,t:1526930144174};\\\", \\\"{x:531,y:558,t:1526930144215};\\\", \\\"{x:528,y:558,t:1526930144961};\\\", \\\"{x:521,y:557,t:1526930144976};\\\", \\\"{x:514,y:556,t:1526930144992};\\\", \\\"{x:507,y:556,t:1526930145009};\\\", \\\"{x:504,y:555,t:1526930145027};\\\", \\\"{x:500,y:555,t:1526930145042};\\\", \\\"{x:497,y:555,t:1526930145058};\\\", \\\"{x:493,y:554,t:1526930145075};\\\", \\\"{x:492,y:554,t:1526930145091};\\\", \\\"{x:491,y:554,t:1526930145108};\\\", \\\"{x:494,y:552,t:1526930145223};\\\", \\\"{x:496,y:552,t:1526930145232};\\\", \\\"{x:503,y:551,t:1526930145244};\\\", \\\"{x:523,y:548,t:1526930145258};\\\", \\\"{x:540,y:546,t:1526930145275};\\\", \\\"{x:558,y:542,t:1526930145293};\\\", \\\"{x:579,y:541,t:1526930145308};\\\", \\\"{x:604,y:537,t:1526930145326};\\\", \\\"{x:629,y:529,t:1526930145342};\\\", \\\"{x:646,y:524,t:1526930145358};\\\", \\\"{x:650,y:523,t:1526930145375};\\\", \\\"{x:650,y:522,t:1526930145456};\\\", \\\"{x:651,y:520,t:1526930145472};\\\", \\\"{x:654,y:519,t:1526930145479};\\\", \\\"{x:659,y:518,t:1526930145493};\\\", \\\"{x:664,y:518,t:1526930145509};\\\", \\\"{x:668,y:517,t:1526930145527};\\\", \\\"{x:670,y:517,t:1526930145542};\\\", \\\"{x:671,y:517,t:1526930145559};\\\", \\\"{x:673,y:517,t:1526930145929};\\\", \\\"{x:674,y:517,t:1526930145984};\\\", \\\"{x:674,y:518,t:1526930146929};\\\", \\\"{x:669,y:519,t:1526930146943};\\\", \\\"{x:657,y:522,t:1526930146960};\\\", \\\"{x:640,y:524,t:1526930146976};\\\", \\\"{x:619,y:524,t:1526930146994};\\\", \\\"{x:602,y:524,t:1526930147011};\\\", \\\"{x:588,y:524,t:1526930147026};\\\", \\\"{x:575,y:524,t:1526930147044};\\\", \\\"{x:567,y:524,t:1526930147060};\\\", \\\"{x:559,y:524,t:1526930147077};\\\", \\\"{x:549,y:524,t:1526930147094};\\\", \\\"{x:542,y:524,t:1526930147111};\\\", \\\"{x:533,y:524,t:1526930147126};\\\", \\\"{x:513,y:524,t:1526930147143};\\\", \\\"{x:495,y:524,t:1526930147161};\\\", \\\"{x:474,y:524,t:1526930147177};\\\", \\\"{x:455,y:524,t:1526930147194};\\\", \\\"{x:439,y:524,t:1526930147211};\\\", \\\"{x:424,y:525,t:1526930147227};\\\", \\\"{x:415,y:527,t:1526930147244};\\\", \\\"{x:406,y:528,t:1526930147261};\\\", \\\"{x:399,y:531,t:1526930147276};\\\", \\\"{x:390,y:534,t:1526930147294};\\\", \\\"{x:383,y:537,t:1526930147311};\\\", \\\"{x:363,y:545,t:1526930147327};\\\", \\\"{x:346,y:550,t:1526930147343};\\\", \\\"{x:330,y:556,t:1526930147360};\\\", \\\"{x:320,y:563,t:1526930147377};\\\", \\\"{x:313,y:567,t:1526930147394};\\\", \\\"{x:312,y:573,t:1526930147410};\\\", \\\"{x:309,y:576,t:1526930147427};\\\", \\\"{x:307,y:580,t:1526930147444};\\\", \\\"{x:304,y:583,t:1526930147461};\\\", \\\"{x:299,y:585,t:1526930147477};\\\", \\\"{x:289,y:589,t:1526930147493};\\\", \\\"{x:267,y:591,t:1526930147512};\\\", \\\"{x:213,y:592,t:1526930147527};\\\", \\\"{x:177,y:592,t:1526930147543};\\\", \\\"{x:152,y:594,t:1526930147561};\\\", \\\"{x:138,y:594,t:1526930147578};\\\", \\\"{x:131,y:594,t:1526930147594};\\\", \\\"{x:129,y:594,t:1526930147610};\\\", \\\"{x:129,y:595,t:1526930147627};\\\", \\\"{x:130,y:595,t:1526930147688};\\\", \\\"{x:133,y:596,t:1526930147695};\\\", \\\"{x:135,y:596,t:1526930147711};\\\", \\\"{x:152,y:598,t:1526930147727};\\\", \\\"{x:167,y:599,t:1526930147744};\\\", \\\"{x:212,y:599,t:1526930147760};\\\", \\\"{x:257,y:599,t:1526930147778};\\\", \\\"{x:281,y:599,t:1526930147795};\\\", \\\"{x:293,y:598,t:1526930147811};\\\", \\\"{x:296,y:595,t:1526930147828};\\\", \\\"{x:297,y:594,t:1526930147844};\\\", \\\"{x:297,y:591,t:1526930147862};\\\", \\\"{x:285,y:586,t:1526930147878};\\\", \\\"{x:276,y:584,t:1526930147895};\\\", \\\"{x:269,y:579,t:1526930147912};\\\", \\\"{x:263,y:575,t:1526930147927};\\\", \\\"{x:261,y:571,t:1526930147945};\\\", \\\"{x:261,y:568,t:1526930147960};\\\", \\\"{x:281,y:559,t:1526930147979};\\\", \\\"{x:332,y:548,t:1526930147995};\\\", \\\"{x:420,y:541,t:1526930148010};\\\", \\\"{x:503,y:541,t:1526930148028};\\\", \\\"{x:584,y:539,t:1526930148044};\\\", \\\"{x:648,y:539,t:1526930148060};\\\", \\\"{x:682,y:539,t:1526930148077};\\\", \\\"{x:694,y:539,t:1526930148095};\\\", \\\"{x:696,y:540,t:1526930148110};\\\", \\\"{x:697,y:541,t:1526930148143};\\\", \\\"{x:698,y:541,t:1526930148159};\\\", \\\"{x:700,y:543,t:1526930148167};\\\", \\\"{x:704,y:543,t:1526930148177};\\\", \\\"{x:715,y:544,t:1526930148194};\\\", \\\"{x:731,y:545,t:1526930148212};\\\", \\\"{x:746,y:547,t:1526930148227};\\\", \\\"{x:768,y:551,t:1526930148244};\\\", \\\"{x:781,y:553,t:1526930148262};\\\", \\\"{x:784,y:553,t:1526930148278};\\\", \\\"{x:788,y:553,t:1526930148294};\\\", \\\"{x:796,y:552,t:1526930148311};\\\", \\\"{x:804,y:552,t:1526930148328};\\\", \\\"{x:810,y:552,t:1526930148345};\\\", \\\"{x:816,y:552,t:1526930148362};\\\", \\\"{x:823,y:555,t:1526930148377};\\\", \\\"{x:828,y:557,t:1526930148396};\\\", \\\"{x:832,y:559,t:1526930148411};\\\", \\\"{x:836,y:559,t:1526930148428};\\\", \\\"{x:840,y:559,t:1526930148444};\\\", \\\"{x:844,y:555,t:1526930148462};\\\", \\\"{x:849,y:545,t:1526930148477};\\\", \\\"{x:853,y:532,t:1526930148494};\\\", \\\"{x:858,y:515,t:1526930148511};\\\", \\\"{x:858,y:507,t:1526930148528};\\\", \\\"{x:858,y:502,t:1526930148545};\\\", \\\"{x:858,y:499,t:1526930148561};\\\", \\\"{x:858,y:497,t:1526930148583};\\\", \\\"{x:856,y:497,t:1526930148639};\\\", \\\"{x:855,y:497,t:1526930148647};\\\", \\\"{x:853,y:496,t:1526930148660};\\\", \\\"{x:851,y:495,t:1526930148678};\\\", \\\"{x:850,y:495,t:1526930148695};\\\", \\\"{x:848,y:495,t:1526930148743};\\\", \\\"{x:845,y:495,t:1526930148760};\\\", \\\"{x:844,y:496,t:1526930148775};\\\", \\\"{x:841,y:499,t:1526930148930};\\\", \\\"{x:840,y:506,t:1526930148946};\\\", \\\"{x:839,y:514,t:1526930148962};\\\", \\\"{x:837,y:523,t:1526930148979};\\\", \\\"{x:835,y:529,t:1526930148995};\\\", \\\"{x:835,y:532,t:1526930149011};\\\", \\\"{x:835,y:533,t:1526930149029};\\\", \\\"{x:835,y:534,t:1526930149046};\\\", \\\"{x:835,y:535,t:1526930149096};\\\", \\\"{x:835,y:536,t:1526930149112};\\\", \\\"{x:835,y:537,t:1526930149135};\\\", \\\"{x:835,y:538,t:1526930149319};\\\", \\\"{x:834,y:540,t:1526930149334};\\\", \\\"{x:830,y:543,t:1526930149346};\\\", \\\"{x:804,y:548,t:1526930149362};\\\", \\\"{x:743,y:554,t:1526930149379};\\\", \\\"{x:635,y:554,t:1526930149396};\\\", \\\"{x:488,y:554,t:1526930149412};\\\", \\\"{x:339,y:554,t:1526930149428};\\\", \\\"{x:231,y:554,t:1526930149446};\\\", \\\"{x:172,y:554,t:1526930149463};\\\", \\\"{x:154,y:554,t:1526930149479};\\\", \\\"{x:148,y:554,t:1526930149495};\\\", \\\"{x:144,y:554,t:1526930149513};\\\", \\\"{x:141,y:554,t:1526930149528};\\\", \\\"{x:128,y:558,t:1526930149546};\\\", \\\"{x:108,y:562,t:1526930149563};\\\", \\\"{x:86,y:566,t:1526930149579};\\\", \\\"{x:69,y:569,t:1526930149596};\\\", \\\"{x:65,y:570,t:1526930149613};\\\", \\\"{x:65,y:571,t:1526930149671};\\\", \\\"{x:66,y:572,t:1526930149711};\\\", \\\"{x:68,y:574,t:1526930149727};\\\", \\\"{x:74,y:576,t:1526930149735};\\\", \\\"{x:80,y:578,t:1526930149745};\\\", \\\"{x:102,y:584,t:1526930149762};\\\", \\\"{x:131,y:590,t:1526930149779};\\\", \\\"{x:151,y:593,t:1526930149795};\\\", \\\"{x:160,y:593,t:1526930149813};\\\", \\\"{x:161,y:593,t:1526930149829};\\\", \\\"{x:163,y:593,t:1526930149879};\\\", \\\"{x:163,y:592,t:1526930149944};\\\", \\\"{x:161,y:591,t:1526930149960};\\\", \\\"{x:159,y:590,t:1526930149968};\\\", \\\"{x:158,y:589,t:1526930149979};\\\", \\\"{x:154,y:588,t:1526930149995};\\\", \\\"{x:153,y:587,t:1526930150015};\\\", \\\"{x:152,y:587,t:1526930150159};\\\", \\\"{x:153,y:586,t:1526930150167};\\\", \\\"{x:161,y:586,t:1526930150180};\\\", \\\"{x:190,y:586,t:1526930150196};\\\", \\\"{x:243,y:586,t:1526930150212};\\\", \\\"{x:326,y:586,t:1526930150230};\\\", \\\"{x:419,y:578,t:1526930150246};\\\", \\\"{x:508,y:578,t:1526930150263};\\\", \\\"{x:622,y:576,t:1526930150279};\\\", \\\"{x:667,y:576,t:1526930150296};\\\", \\\"{x:691,y:572,t:1526930150312};\\\", \\\"{x:713,y:571,t:1526930150329};\\\", \\\"{x:740,y:570,t:1526930150346};\\\", \\\"{x:763,y:570,t:1526930150362};\\\", \\\"{x:782,y:570,t:1526930150380};\\\", \\\"{x:798,y:570,t:1526930150395};\\\", \\\"{x:807,y:570,t:1526930150413};\\\", \\\"{x:811,y:570,t:1526930150429};\\\", \\\"{x:812,y:570,t:1526930150471};\\\", \\\"{x:814,y:570,t:1526930150504};\\\", \\\"{x:817,y:570,t:1526930150513};\\\", \\\"{x:825,y:570,t:1526930150531};\\\", \\\"{x:832,y:570,t:1526930150546};\\\", \\\"{x:833,y:570,t:1526930150562};\\\", \\\"{x:834,y:570,t:1526930150631};\\\", \\\"{x:835,y:571,t:1526930150663};\\\", \\\"{x:837,y:571,t:1526930150855};\\\", \\\"{x:845,y:571,t:1526930150863};\\\", \\\"{x:881,y:571,t:1526930150880};\\\", \\\"{x:945,y:571,t:1526930150896};\\\", \\\"{x:1034,y:575,t:1526930150913};\\\", \\\"{x:1136,y:584,t:1526930150929};\\\", \\\"{x:1234,y:600,t:1526930150946};\\\", \\\"{x:1320,y:611,t:1526930150964};\\\", \\\"{x:1381,y:619,t:1526930150980};\\\", \\\"{x:1429,y:627,t:1526930150997};\\\", \\\"{x:1456,y:634,t:1526930151014};\\\", \\\"{x:1466,y:634,t:1526930151030};\\\", \\\"{x:1469,y:635,t:1526930151046};\\\", \\\"{x:1472,y:636,t:1526930151063};\\\", \\\"{x:1474,y:637,t:1526930151120};\\\", \\\"{x:1476,y:640,t:1526930151136};\\\", \\\"{x:1476,y:641,t:1526930151147};\\\", \\\"{x:1477,y:643,t:1526930151164};\\\", \\\"{x:1477,y:647,t:1526930151180};\\\", \\\"{x:1474,y:652,t:1526930151197};\\\", \\\"{x:1461,y:661,t:1526930151215};\\\", \\\"{x:1440,y:666,t:1526930151230};\\\", \\\"{x:1415,y:672,t:1526930151247};\\\", \\\"{x:1375,y:676,t:1526930151264};\\\", \\\"{x:1356,y:678,t:1526930151280};\\\", \\\"{x:1347,y:678,t:1526930151298};\\\", \\\"{x:1344,y:678,t:1526930151314};\\\", \\\"{x:1343,y:678,t:1526930151330};\\\", \\\"{x:1341,y:678,t:1526930151377};\\\", \\\"{x:1340,y:678,t:1526930151400};\\\", \\\"{x:1339,y:679,t:1526930151416};\\\", \\\"{x:1338,y:681,t:1526930151432};\\\", \\\"{x:1338,y:683,t:1526930151456};\\\", \\\"{x:1338,y:684,t:1526930151472};\\\", \\\"{x:1338,y:686,t:1526930151496};\\\", \\\"{x:1338,y:687,t:1526930151625};\\\", \\\"{x:1339,y:687,t:1526930151665};\\\", \\\"{x:1340,y:687,t:1526930151681};\\\", \\\"{x:1340,y:688,t:1526930151697};\\\", \\\"{x:1341,y:688,t:1526930151728};\\\", \\\"{x:1343,y:689,t:1526930151768};\\\", \\\"{x:1343,y:688,t:1526930151881};\\\", \\\"{x:1345,y:683,t:1526930151898};\\\", \\\"{x:1347,y:679,t:1526930151914};\\\", \\\"{x:1349,y:675,t:1526930151931};\\\", \\\"{x:1350,y:673,t:1526930151947};\\\", \\\"{x:1352,y:669,t:1526930151965};\\\", \\\"{x:1356,y:665,t:1526930151981};\\\", \\\"{x:1361,y:655,t:1526930151997};\\\", \\\"{x:1371,y:640,t:1526930152015};\\\", \\\"{x:1384,y:621,t:1526930152031};\\\", \\\"{x:1397,y:602,t:1526930152048};\\\", \\\"{x:1412,y:579,t:1526930152064};\\\", \\\"{x:1419,y:566,t:1526930152080};\\\", \\\"{x:1423,y:559,t:1526930152099};\\\", \\\"{x:1424,y:556,t:1526930152115};\\\", \\\"{x:1424,y:555,t:1526930152131};\\\", \\\"{x:1425,y:557,t:1526930152368};\\\", \\\"{x:1426,y:559,t:1526930152381};\\\", \\\"{x:1430,y:567,t:1526930152398};\\\", \\\"{x:1435,y:575,t:1526930152414};\\\", \\\"{x:1438,y:581,t:1526930152430};\\\", \\\"{x:1440,y:584,t:1526930152447};\\\", \\\"{x:1443,y:586,t:1526930152464};\\\", \\\"{x:1443,y:587,t:1526930152481};\\\", \\\"{x:1444,y:590,t:1526930152497};\\\", \\\"{x:1447,y:594,t:1526930152513};\\\", \\\"{x:1450,y:600,t:1526930152531};\\\", \\\"{x:1454,y:609,t:1526930152547};\\\", \\\"{x:1457,y:617,t:1526930152564};\\\", \\\"{x:1461,y:626,t:1526930152581};\\\", \\\"{x:1464,y:632,t:1526930152597};\\\", \\\"{x:1465,y:636,t:1526930152614};\\\", \\\"{x:1467,y:639,t:1526930152632};\\\", \\\"{x:1467,y:640,t:1526930152656};\\\", \\\"{x:1468,y:640,t:1526930152672};\\\", \\\"{x:1469,y:641,t:1526930152687};\\\", \\\"{x:1469,y:642,t:1526930152777};\\\", \\\"{x:1469,y:643,t:1526930152800};\\\", \\\"{x:1470,y:644,t:1526930152814};\\\", \\\"{x:1471,y:647,t:1526930152831};\\\", \\\"{x:1473,y:655,t:1526930152848};\\\", \\\"{x:1474,y:662,t:1526930152864};\\\", \\\"{x:1478,y:673,t:1526930152882};\\\", \\\"{x:1484,y:686,t:1526930152898};\\\", \\\"{x:1489,y:699,t:1526930152915};\\\", \\\"{x:1493,y:711,t:1526930152932};\\\", \\\"{x:1496,y:722,t:1526930152947};\\\", \\\"{x:1500,y:734,t:1526930152965};\\\", \\\"{x:1503,y:741,t:1526930152982};\\\", \\\"{x:1508,y:751,t:1526930152997};\\\", \\\"{x:1509,y:756,t:1526930153014};\\\", \\\"{x:1510,y:759,t:1526930153032};\\\", \\\"{x:1511,y:760,t:1526930153088};\\\", \\\"{x:1510,y:760,t:1526930153272};\\\", \\\"{x:1508,y:760,t:1526930155529};\\\", \\\"{x:1498,y:762,t:1526930155535};\\\", \\\"{x:1475,y:764,t:1526930155548};\\\", \\\"{x:1382,y:769,t:1526930155565};\\\", \\\"{x:1240,y:778,t:1526930155581};\\\", \\\"{x:1063,y:780,t:1526930155598};\\\", \\\"{x:776,y:780,t:1526930155614};\\\", \\\"{x:621,y:780,t:1526930155631};\\\", \\\"{x:507,y:782,t:1526930155648};\\\", \\\"{x:459,y:789,t:1526930155665};\\\", \\\"{x:429,y:800,t:1526930155681};\\\", \\\"{x:414,y:811,t:1526930155698};\\\", \\\"{x:406,y:819,t:1526930155715};\\\", \\\"{x:403,y:824,t:1526930155730};\\\", \\\"{x:402,y:826,t:1526930155748};\\\", \\\"{x:401,y:828,t:1526930155765};\\\", \\\"{x:400,y:829,t:1526930155781};\\\", \\\"{x:400,y:830,t:1526930155808};\\\", \\\"{x:404,y:829,t:1526930155848};\\\", \\\"{x:425,y:819,t:1526930155865};\\\", \\\"{x:463,y:804,t:1526930155881};\\\", \\\"{x:516,y:781,t:1526930155899};\\\", \\\"{x:558,y:760,t:1526930155915};\\\", \\\"{x:578,y:751,t:1526930155932};\\\", \\\"{x:582,y:748,t:1526930155948};\\\", \\\"{x:580,y:747,t:1526930156088};\\\", \\\"{x:576,y:746,t:1526930156098};\\\", \\\"{x:572,y:745,t:1526930156115};\\\", \\\"{x:568,y:744,t:1526930156131};\\\", \\\"{x:563,y:742,t:1526930156150};\\\", \\\"{x:561,y:741,t:1526930156165};\\\", \\\"{x:557,y:740,t:1526930156180};\\\", \\\"{x:555,y:739,t:1526930156198};\\\", \\\"{x:554,y:739,t:1526930156217};\\\", \\\"{x:553,y:739,t:1526930156368};\\\", \\\"{x:553,y:741,t:1526930156383};\\\", \\\"{x:553,y:742,t:1526930156400};\\\", \\\"{x:554,y:745,t:1526930156418};\\\", \\\"{x:578,y:749,t:1526930156434};\\\", \\\"{x:647,y:752,t:1526930156451};\\\", \\\"{x:736,y:754,t:1526930156468};\\\", \\\"{x:839,y:768,t:1526930156484};\\\", \\\"{x:927,y:779,t:1526930156501};\\\", \\\"{x:1023,y:787,t:1526930156517};\\\", \\\"{x:1095,y:796,t:1526930156534};\\\", \\\"{x:1146,y:798,t:1526930156551};\\\", \\\"{x:1149,y:798,t:1526930156568};\\\", \\\"{x:1150,y:798,t:1526930156664};\\\", \\\"{x:1151,y:798,t:1526930157264};\\\", \\\"{x:1152,y:797,t:1526930157343};\\\" ] }, { \\\"rt\\\": 35313, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 555819, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -J -J -I -B -10 AM-B -B -B -11 AM-B -10 AM-I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1152,y:794,t:1526930157612};\\\", \\\"{x:1152,y:793,t:1526930157638};\\\", \\\"{x:1152,y:792,t:1526930157655};\\\", \\\"{x:1152,y:791,t:1526930157695};\\\", \\\"{x:1153,y:791,t:1526930157726};\\\", \\\"{x:1153,y:790,t:1526930157743};\\\", \\\"{x:1153,y:789,t:1526930157770};\\\", \\\"{x:1153,y:788,t:1526930157786};\\\", \\\"{x:1153,y:787,t:1526930157807};\\\", \\\"{x:1154,y:786,t:1526930157823};\\\", \\\"{x:1154,y:785,t:1526930157839};\\\", \\\"{x:1154,y:784,t:1526930157871};\\\", \\\"{x:1154,y:783,t:1526930157911};\\\", \\\"{x:1154,y:780,t:1526930158004};\\\", \\\"{x:1154,y:779,t:1526930158033};\\\", \\\"{x:1154,y:778,t:1526930158063};\\\", \\\"{x:1154,y:777,t:1526930158079};\\\", \\\"{x:1154,y:776,t:1526930158095};\\\", \\\"{x:1154,y:775,t:1526930158135};\\\", \\\"{x:1154,y:774,t:1526930158159};\\\", \\\"{x:1153,y:774,t:1526930159904};\\\", \\\"{x:1152,y:774,t:1526930159968};\\\", \\\"{x:1150,y:774,t:1526930160024};\\\", \\\"{x:1150,y:775,t:1526930160064};\\\", \\\"{x:1149,y:776,t:1526930160080};\\\", \\\"{x:1148,y:776,t:1526930160096};\\\", \\\"{x:1147,y:777,t:1526930160208};\\\", \\\"{x:1146,y:777,t:1526930160336};\\\", \\\"{x:1146,y:779,t:1526930161576};\\\", \\\"{x:1146,y:780,t:1526930161640};\\\", \\\"{x:1147,y:779,t:1526930161655};\\\", \\\"{x:1150,y:776,t:1526930163104};\\\", \\\"{x:1152,y:775,t:1526930163111};\\\", \\\"{x:1152,y:772,t:1526930163124};\\\", \\\"{x:1154,y:769,t:1526930163140};\\\", \\\"{x:1155,y:768,t:1526930163157};\\\", \\\"{x:1155,y:766,t:1526930163174};\\\", \\\"{x:1157,y:763,t:1526930163190};\\\", \\\"{x:1160,y:761,t:1526930163207};\\\", \\\"{x:1161,y:759,t:1526930163224};\\\", \\\"{x:1162,y:756,t:1526930163240};\\\", \\\"{x:1162,y:752,t:1526930163257};\\\", \\\"{x:1164,y:749,t:1526930163274};\\\", \\\"{x:1166,y:743,t:1526930163290};\\\", \\\"{x:1167,y:736,t:1526930163307};\\\", \\\"{x:1171,y:729,t:1526930163323};\\\", \\\"{x:1174,y:723,t:1526930163340};\\\", \\\"{x:1179,y:714,t:1526930163357};\\\", \\\"{x:1184,y:705,t:1526930163374};\\\", \\\"{x:1197,y:698,t:1526930163390};\\\", \\\"{x:1208,y:690,t:1526930163407};\\\", \\\"{x:1233,y:681,t:1526930163423};\\\", \\\"{x:1251,y:673,t:1526930163440};\\\", \\\"{x:1260,y:671,t:1526930163457};\\\", \\\"{x:1270,y:669,t:1526930163473};\\\", \\\"{x:1277,y:668,t:1526930163491};\\\", \\\"{x:1282,y:667,t:1526930163507};\\\", \\\"{x:1286,y:667,t:1526930163524};\\\", \\\"{x:1291,y:667,t:1526930163540};\\\", \\\"{x:1297,y:667,t:1526930163557};\\\", \\\"{x:1300,y:667,t:1526930163574};\\\", \\\"{x:1308,y:668,t:1526930163591};\\\", \\\"{x:1317,y:673,t:1526930163607};\\\", \\\"{x:1336,y:675,t:1526930163624};\\\", \\\"{x:1350,y:676,t:1526930163641};\\\", \\\"{x:1361,y:676,t:1526930163657};\\\", \\\"{x:1367,y:676,t:1526930163674};\\\", \\\"{x:1368,y:676,t:1526930163691};\\\", \\\"{x:1368,y:675,t:1526930163712};\\\", \\\"{x:1369,y:675,t:1526930163724};\\\", \\\"{x:1370,y:675,t:1526930163741};\\\", \\\"{x:1371,y:674,t:1526930163757};\\\", \\\"{x:1378,y:674,t:1526930163774};\\\", \\\"{x:1380,y:673,t:1526930163790};\\\", \\\"{x:1384,y:671,t:1526930163807};\\\", \\\"{x:1385,y:671,t:1526930163824};\\\", \\\"{x:1386,y:671,t:1526930163976};\\\", \\\"{x:1388,y:672,t:1526930163991};\\\", \\\"{x:1393,y:675,t:1526930164007};\\\", \\\"{x:1395,y:676,t:1526930164024};\\\", \\\"{x:1397,y:678,t:1526930164041};\\\", \\\"{x:1397,y:680,t:1526930164063};\\\", \\\"{x:1397,y:681,t:1526930164074};\\\", \\\"{x:1397,y:682,t:1526930164091};\\\", \\\"{x:1397,y:685,t:1526930164108};\\\", \\\"{x:1397,y:692,t:1526930164124};\\\", \\\"{x:1391,y:705,t:1526930164141};\\\", \\\"{x:1381,y:721,t:1526930164158};\\\", \\\"{x:1371,y:736,t:1526930164174};\\\", \\\"{x:1361,y:752,t:1526930164190};\\\", \\\"{x:1353,y:765,t:1526930164207};\\\", \\\"{x:1347,y:772,t:1526930164223};\\\", \\\"{x:1341,y:780,t:1526930164240};\\\", \\\"{x:1328,y:790,t:1526930164257};\\\", \\\"{x:1314,y:798,t:1526930164273};\\\", \\\"{x:1291,y:806,t:1526930164290};\\\", \\\"{x:1272,y:815,t:1526930164308};\\\", \\\"{x:1253,y:821,t:1526930164324};\\\", \\\"{x:1234,y:827,t:1526930164340};\\\", \\\"{x:1220,y:829,t:1526930164358};\\\", \\\"{x:1213,y:831,t:1526930164373};\\\", \\\"{x:1211,y:832,t:1526930164390};\\\", \\\"{x:1208,y:832,t:1526930164408};\\\", \\\"{x:1208,y:831,t:1526930164425};\\\", \\\"{x:1212,y:829,t:1526930164441};\\\", \\\"{x:1213,y:827,t:1526930164457};\\\", \\\"{x:1214,y:827,t:1526930164475};\\\", \\\"{x:1215,y:826,t:1526930164490};\\\", \\\"{x:1216,y:825,t:1526930164511};\\\", \\\"{x:1217,y:825,t:1526930164551};\\\", \\\"{x:1219,y:825,t:1526930164617};\\\", \\\"{x:1220,y:825,t:1526930165457};\\\", \\\"{x:1221,y:825,t:1526930168576};\\\", \\\"{x:1221,y:821,t:1526930173352};\\\", \\\"{x:1221,y:817,t:1526930173364};\\\", \\\"{x:1221,y:810,t:1526930173381};\\\", \\\"{x:1220,y:804,t:1526930173396};\\\", \\\"{x:1216,y:795,t:1526930173413};\\\", \\\"{x:1209,y:782,t:1526930173430};\\\", \\\"{x:1204,y:775,t:1526930173447};\\\", \\\"{x:1203,y:772,t:1526930173463};\\\", \\\"{x:1202,y:771,t:1526930173481};\\\", \\\"{x:1201,y:769,t:1526930173498};\\\", \\\"{x:1200,y:768,t:1526930173514};\\\", \\\"{x:1199,y:767,t:1526930173530};\\\", \\\"{x:1196,y:765,t:1526930173548};\\\", \\\"{x:1194,y:764,t:1526930173564};\\\", \\\"{x:1193,y:764,t:1526930173581};\\\", \\\"{x:1192,y:764,t:1526930173598};\\\", \\\"{x:1190,y:764,t:1526930173614};\\\", \\\"{x:1187,y:762,t:1526930173631};\\\", \\\"{x:1186,y:761,t:1526930173743};\\\", \\\"{x:1190,y:760,t:1526930173764};\\\", \\\"{x:1226,y:759,t:1526930173780};\\\", \\\"{x:1271,y:759,t:1526930173797};\\\", \\\"{x:1307,y:759,t:1526930173814};\\\", \\\"{x:1342,y:759,t:1526930173830};\\\", \\\"{x:1352,y:758,t:1526930173847};\\\", \\\"{x:1353,y:758,t:1526930173952};\\\", \\\"{x:1354,y:758,t:1526930173965};\\\", \\\"{x:1356,y:758,t:1526930173981};\\\", \\\"{x:1357,y:758,t:1526930173998};\\\", \\\"{x:1358,y:758,t:1526930174015};\\\", \\\"{x:1358,y:759,t:1526930174048};\\\", \\\"{x:1358,y:760,t:1526930174128};\\\", \\\"{x:1358,y:761,t:1526930174136};\\\", \\\"{x:1357,y:761,t:1526930174151};\\\", \\\"{x:1356,y:761,t:1526930174168};\\\", \\\"{x:1355,y:761,t:1526930174232};\\\", \\\"{x:1354,y:761,t:1526930174271};\\\", \\\"{x:1353,y:761,t:1526930174609};\\\", \\\"{x:1352,y:761,t:1526930174648};\\\", \\\"{x:1351,y:761,t:1526930174687};\\\", \\\"{x:1349,y:761,t:1526930174699};\\\", \\\"{x:1349,y:762,t:1526930174715};\\\", \\\"{x:1348,y:763,t:1526930174732};\\\", \\\"{x:1347,y:765,t:1526930174752};\\\", \\\"{x:1346,y:766,t:1526930174775};\\\", \\\"{x:1345,y:767,t:1526930174800};\\\", \\\"{x:1345,y:768,t:1526930174815};\\\", \\\"{x:1345,y:770,t:1526930174834};\\\", \\\"{x:1344,y:771,t:1526930174849};\\\", \\\"{x:1344,y:772,t:1526930174872};\\\", \\\"{x:1343,y:773,t:1526930174883};\\\", \\\"{x:1342,y:773,t:1526930174898};\\\", \\\"{x:1342,y:775,t:1526930174914};\\\", \\\"{x:1342,y:776,t:1526930174932};\\\", \\\"{x:1342,y:777,t:1526930174948};\\\", \\\"{x:1340,y:779,t:1526930174964};\\\", \\\"{x:1340,y:781,t:1526930174998};\\\", \\\"{x:1339,y:781,t:1526930175015};\\\", \\\"{x:1338,y:784,t:1526930175032};\\\", \\\"{x:1337,y:785,t:1526930175049};\\\", \\\"{x:1336,y:788,t:1526930175065};\\\", \\\"{x:1335,y:789,t:1526930175082};\\\", \\\"{x:1333,y:793,t:1526930175099};\\\", \\\"{x:1332,y:796,t:1526930175115};\\\", \\\"{x:1329,y:800,t:1526930175132};\\\", \\\"{x:1328,y:803,t:1526930175149};\\\", \\\"{x:1326,y:806,t:1526930175165};\\\", \\\"{x:1324,y:810,t:1526930175182};\\\", \\\"{x:1322,y:813,t:1526930175199};\\\", \\\"{x:1322,y:814,t:1526930175215};\\\", \\\"{x:1321,y:816,t:1526930175232};\\\", \\\"{x:1318,y:819,t:1526930175249};\\\", \\\"{x:1316,y:821,t:1526930175266};\\\", \\\"{x:1314,y:824,t:1526930175282};\\\", \\\"{x:1312,y:827,t:1526930175300};\\\", \\\"{x:1311,y:830,t:1526930175315};\\\", \\\"{x:1308,y:833,t:1526930175333};\\\", \\\"{x:1307,y:835,t:1526930175349};\\\", \\\"{x:1306,y:837,t:1526930175365};\\\", \\\"{x:1306,y:838,t:1526930175381};\\\", \\\"{x:1305,y:838,t:1526930175399};\\\", \\\"{x:1304,y:839,t:1526930175416};\\\", \\\"{x:1302,y:841,t:1526930175432};\\\", \\\"{x:1302,y:843,t:1526930175463};\\\", \\\"{x:1301,y:843,t:1526930175470};\\\", \\\"{x:1301,y:844,t:1526930175487};\\\", \\\"{x:1299,y:845,t:1526930175499};\\\", \\\"{x:1299,y:846,t:1526930175515};\\\", \\\"{x:1298,y:847,t:1526930175532};\\\", \\\"{x:1297,y:849,t:1526930175549};\\\", \\\"{x:1295,y:851,t:1526930175566};\\\", \\\"{x:1294,y:854,t:1526930175582};\\\", \\\"{x:1292,y:859,t:1526930175599};\\\", \\\"{x:1289,y:863,t:1526930175616};\\\", \\\"{x:1288,y:865,t:1526930175632};\\\", \\\"{x:1287,y:868,t:1526930175648};\\\", \\\"{x:1285,y:872,t:1526930175666};\\\", \\\"{x:1284,y:875,t:1526930175682};\\\", \\\"{x:1283,y:878,t:1526930175699};\\\", \\\"{x:1281,y:881,t:1526930175716};\\\", \\\"{x:1280,y:884,t:1526930175732};\\\", \\\"{x:1280,y:886,t:1526930175750};\\\", \\\"{x:1278,y:889,t:1526930175766};\\\", \\\"{x:1278,y:890,t:1526930175783};\\\", \\\"{x:1277,y:892,t:1526930175799};\\\", \\\"{x:1277,y:893,t:1526930175816};\\\", \\\"{x:1277,y:894,t:1526930175832};\\\", \\\"{x:1275,y:895,t:1526930175849};\\\", \\\"{x:1275,y:897,t:1526930175866};\\\", \\\"{x:1275,y:898,t:1526930175882};\\\", \\\"{x:1274,y:899,t:1526930175899};\\\", \\\"{x:1274,y:901,t:1526930175916};\\\", \\\"{x:1273,y:902,t:1526930175933};\\\", \\\"{x:1272,y:904,t:1526930175950};\\\", \\\"{x:1271,y:905,t:1526930175967};\\\", \\\"{x:1271,y:906,t:1526930175991};\\\", \\\"{x:1271,y:907,t:1526930176007};\\\", \\\"{x:1269,y:908,t:1526930176024};\\\", \\\"{x:1269,y:909,t:1526930176055};\\\", \\\"{x:1269,y:910,t:1526930176066};\\\", \\\"{x:1268,y:910,t:1526930176111};\\\", \\\"{x:1267,y:911,t:1526930176160};\\\", \\\"{x:1267,y:912,t:1526930176184};\\\", \\\"{x:1266,y:913,t:1526930176208};\\\", \\\"{x:1266,y:914,t:1526930176217};\\\", \\\"{x:1265,y:915,t:1526930176234};\\\", \\\"{x:1264,y:916,t:1526930176249};\\\", \\\"{x:1262,y:919,t:1526930176267};\\\", \\\"{x:1262,y:921,t:1526930176283};\\\", \\\"{x:1259,y:923,t:1526930176299};\\\", \\\"{x:1258,y:926,t:1526930176316};\\\", \\\"{x:1257,y:929,t:1526930176333};\\\", \\\"{x:1255,y:933,t:1526930176350};\\\", \\\"{x:1253,y:937,t:1526930176367};\\\", \\\"{x:1251,y:941,t:1526930176383};\\\", \\\"{x:1250,y:942,t:1526930176400};\\\", \\\"{x:1248,y:943,t:1526930176416};\\\", \\\"{x:1247,y:944,t:1526930176433};\\\", \\\"{x:1247,y:946,t:1526930176451};\\\", \\\"{x:1245,y:948,t:1526930176466};\\\", \\\"{x:1244,y:951,t:1526930176484};\\\", \\\"{x:1243,y:953,t:1526930176500};\\\", \\\"{x:1241,y:955,t:1526930176516};\\\", \\\"{x:1241,y:957,t:1526930176533};\\\", \\\"{x:1239,y:959,t:1526930176551};\\\", \\\"{x:1238,y:960,t:1526930176568};\\\", \\\"{x:1238,y:961,t:1526930176583};\\\", \\\"{x:1237,y:962,t:1526930176600};\\\", \\\"{x:1235,y:965,t:1526930176616};\\\", \\\"{x:1234,y:966,t:1526930176633};\\\", \\\"{x:1233,y:967,t:1526930176651};\\\", \\\"{x:1232,y:969,t:1526930176667};\\\", \\\"{x:1231,y:970,t:1526930176683};\\\", \\\"{x:1229,y:972,t:1526930176701};\\\", \\\"{x:1228,y:973,t:1526930176720};\\\", \\\"{x:1228,y:974,t:1526930176737};\\\", \\\"{x:1226,y:975,t:1526930176754};\\\", \\\"{x:1229,y:972,t:1526930176940};\\\", \\\"{x:1230,y:971,t:1526930176954};\\\", \\\"{x:1240,y:963,t:1526930176972};\\\", \\\"{x:1246,y:959,t:1526930176988};\\\", \\\"{x:1252,y:952,t:1526930177004};\\\", \\\"{x:1257,y:942,t:1526930177021};\\\", \\\"{x:1265,y:930,t:1526930177038};\\\", \\\"{x:1270,y:915,t:1526930177055};\\\", \\\"{x:1278,y:899,t:1526930177071};\\\", \\\"{x:1286,y:879,t:1526930177087};\\\", \\\"{x:1295,y:861,t:1526930177104};\\\", \\\"{x:1303,y:843,t:1526930177122};\\\", \\\"{x:1309,y:827,t:1526930177138};\\\", \\\"{x:1315,y:809,t:1526930177154};\\\", \\\"{x:1318,y:794,t:1526930177172};\\\", \\\"{x:1320,y:790,t:1526930177187};\\\", \\\"{x:1320,y:786,t:1526930177205};\\\", \\\"{x:1322,y:784,t:1526930177222};\\\", \\\"{x:1322,y:783,t:1526930177238};\\\", \\\"{x:1323,y:782,t:1526930177254};\\\", \\\"{x:1324,y:780,t:1526930177272};\\\", \\\"{x:1326,y:779,t:1526930177288};\\\", \\\"{x:1326,y:776,t:1526930177304};\\\", \\\"{x:1328,y:774,t:1526930177322};\\\", \\\"{x:1329,y:771,t:1526930177338};\\\", \\\"{x:1331,y:769,t:1526930177355};\\\", \\\"{x:1333,y:767,t:1526930177371};\\\", \\\"{x:1334,y:765,t:1526930177387};\\\", \\\"{x:1335,y:762,t:1526930177404};\\\", \\\"{x:1336,y:761,t:1526930177420};\\\", \\\"{x:1338,y:758,t:1526930177438};\\\", \\\"{x:1340,y:756,t:1526930177453};\\\", \\\"{x:1341,y:755,t:1526930177507};\\\", \\\"{x:1342,y:755,t:1526930177748};\\\", \\\"{x:1343,y:755,t:1526930177772};\\\", \\\"{x:1344,y:755,t:1526930177836};\\\", \\\"{x:1345,y:755,t:1526930177916};\\\", \\\"{x:1346,y:756,t:1526930177931};\\\", \\\"{x:1347,y:756,t:1526930177939};\\\", \\\"{x:1348,y:757,t:1526930177956};\\\", \\\"{x:1349,y:757,t:1526930177979};\\\", \\\"{x:1351,y:758,t:1526930177996};\\\", \\\"{x:1351,y:759,t:1526930178045};\\\", \\\"{x:1352,y:759,t:1526930178292};\\\", \\\"{x:1352,y:760,t:1526930178305};\\\", \\\"{x:1353,y:761,t:1526930178322};\\\", \\\"{x:1354,y:762,t:1526930178340};\\\", \\\"{x:1354,y:765,t:1526930178356};\\\", \\\"{x:1355,y:766,t:1526930178372};\\\", \\\"{x:1355,y:767,t:1526930178388};\\\", \\\"{x:1356,y:769,t:1526930178406};\\\", \\\"{x:1357,y:771,t:1526930178423};\\\", \\\"{x:1358,y:772,t:1526930178438};\\\", \\\"{x:1359,y:775,t:1526930178455};\\\", \\\"{x:1360,y:778,t:1526930178473};\\\", \\\"{x:1361,y:780,t:1526930178489};\\\", \\\"{x:1361,y:781,t:1526930178508};\\\", \\\"{x:1361,y:782,t:1526930178522};\\\", \\\"{x:1361,y:783,t:1526930178538};\\\", \\\"{x:1362,y:785,t:1526930178555};\\\", \\\"{x:1363,y:789,t:1526930178573};\\\", \\\"{x:1364,y:789,t:1526930178589};\\\", \\\"{x:1365,y:792,t:1526930178606};\\\", \\\"{x:1365,y:793,t:1526930178623};\\\", \\\"{x:1366,y:795,t:1526930178639};\\\", \\\"{x:1367,y:797,t:1526930178655};\\\", \\\"{x:1369,y:802,t:1526930178672};\\\", \\\"{x:1370,y:804,t:1526930178688};\\\", \\\"{x:1372,y:810,t:1526930178705};\\\", \\\"{x:1375,y:813,t:1526930178723};\\\", \\\"{x:1375,y:817,t:1526930178739};\\\", \\\"{x:1377,y:821,t:1526930178755};\\\", \\\"{x:1379,y:823,t:1526930178772};\\\", \\\"{x:1380,y:826,t:1526930178789};\\\", \\\"{x:1381,y:827,t:1526930178805};\\\", \\\"{x:1382,y:829,t:1526930178822};\\\", \\\"{x:1384,y:831,t:1526930178839};\\\", \\\"{x:1384,y:833,t:1526930178855};\\\", \\\"{x:1385,y:834,t:1526930178872};\\\", \\\"{x:1386,y:837,t:1526930178889};\\\", \\\"{x:1388,y:840,t:1526930178905};\\\", \\\"{x:1389,y:842,t:1526930178922};\\\", \\\"{x:1392,y:846,t:1526930178939};\\\", \\\"{x:1394,y:849,t:1526930178955};\\\", \\\"{x:1396,y:851,t:1526930178972};\\\", \\\"{x:1399,y:855,t:1526930178989};\\\", \\\"{x:1403,y:859,t:1526930179005};\\\", \\\"{x:1406,y:863,t:1526930179023};\\\", \\\"{x:1409,y:867,t:1526930179040};\\\", \\\"{x:1412,y:870,t:1526930179055};\\\", \\\"{x:1417,y:874,t:1526930179072};\\\", \\\"{x:1418,y:877,t:1526930179089};\\\", \\\"{x:1420,y:880,t:1526930179106};\\\", \\\"{x:1422,y:884,t:1526930179123};\\\", \\\"{x:1423,y:887,t:1526930179139};\\\", \\\"{x:1425,y:891,t:1526930179156};\\\", \\\"{x:1429,y:899,t:1526930179172};\\\", \\\"{x:1431,y:906,t:1526930179189};\\\", \\\"{x:1434,y:913,t:1526930179206};\\\", \\\"{x:1437,y:921,t:1526930179223};\\\", \\\"{x:1438,y:928,t:1526930179240};\\\", \\\"{x:1441,y:934,t:1526930179256};\\\", \\\"{x:1441,y:936,t:1526930179272};\\\", \\\"{x:1442,y:940,t:1526930179289};\\\", \\\"{x:1442,y:942,t:1526930179307};\\\", \\\"{x:1442,y:943,t:1526930179324};\\\", \\\"{x:1443,y:945,t:1526930179340};\\\", \\\"{x:1444,y:946,t:1526930179356};\\\", \\\"{x:1444,y:947,t:1526930179373};\\\", \\\"{x:1445,y:948,t:1526930179389};\\\", \\\"{x:1447,y:950,t:1526930179406};\\\", \\\"{x:1447,y:952,t:1526930179423};\\\", \\\"{x:1448,y:953,t:1526930179443};\\\", \\\"{x:1449,y:954,t:1526930179457};\\\", \\\"{x:1450,y:956,t:1526930179472};\\\", \\\"{x:1451,y:958,t:1526930179490};\\\", \\\"{x:1452,y:959,t:1526930179506};\\\", \\\"{x:1452,y:960,t:1526930179523};\\\", \\\"{x:1454,y:962,t:1526930179539};\\\", \\\"{x:1454,y:960,t:1526930179668};\\\", \\\"{x:1454,y:957,t:1526930179675};\\\", \\\"{x:1454,y:951,t:1526930179689};\\\", \\\"{x:1448,y:932,t:1526930179706};\\\", \\\"{x:1438,y:909,t:1526930179722};\\\", \\\"{x:1418,y:877,t:1526930179739};\\\", \\\"{x:1408,y:859,t:1526930179757};\\\", \\\"{x:1402,y:847,t:1526930179774};\\\", \\\"{x:1397,y:839,t:1526930179790};\\\", \\\"{x:1393,y:830,t:1526930179807};\\\", \\\"{x:1389,y:821,t:1526930179824};\\\", \\\"{x:1387,y:813,t:1526930179839};\\\", \\\"{x:1385,y:811,t:1526930179856};\\\", \\\"{x:1384,y:809,t:1526930179873};\\\", \\\"{x:1382,y:808,t:1526930179955};\\\", \\\"{x:1378,y:806,t:1526930179974};\\\", \\\"{x:1375,y:805,t:1526930179989};\\\", \\\"{x:1372,y:804,t:1526930180006};\\\", \\\"{x:1370,y:804,t:1526930180023};\\\", \\\"{x:1368,y:802,t:1526930180040};\\\", \\\"{x:1367,y:802,t:1526930180056};\\\", \\\"{x:1365,y:801,t:1526930180073};\\\", \\\"{x:1363,y:800,t:1526930180091};\\\", \\\"{x:1362,y:799,t:1526930180107};\\\", \\\"{x:1361,y:798,t:1526930180124};\\\", \\\"{x:1360,y:797,t:1526930180140};\\\", \\\"{x:1360,y:795,t:1526930180156};\\\", \\\"{x:1359,y:792,t:1526930180174};\\\", \\\"{x:1358,y:788,t:1526930180190};\\\", \\\"{x:1357,y:783,t:1526930180207};\\\", \\\"{x:1355,y:779,t:1526930180223};\\\", \\\"{x:1355,y:778,t:1526930180244};\\\", \\\"{x:1355,y:776,t:1526930180267};\\\", \\\"{x:1354,y:776,t:1526930180275};\\\", \\\"{x:1354,y:775,t:1526930180428};\\\", \\\"{x:1353,y:774,t:1526930180443};\\\", \\\"{x:1352,y:773,t:1526930180456};\\\", \\\"{x:1352,y:772,t:1526930180473};\\\", \\\"{x:1352,y:770,t:1526930180491};\\\", \\\"{x:1352,y:769,t:1526930180516};\\\", \\\"{x:1352,y:767,t:1526930180531};\\\", \\\"{x:1352,y:766,t:1526930180557};\\\", \\\"{x:1352,y:764,t:1526930180579};\\\", \\\"{x:1351,y:764,t:1526930181523};\\\", \\\"{x:1350,y:763,t:1526930181540};\\\", \\\"{x:1349,y:763,t:1526930181557};\\\", \\\"{x:1348,y:763,t:1526930181574};\\\", \\\"{x:1347,y:762,t:1526930181591};\\\", \\\"{x:1346,y:762,t:1526930181607};\\\", \\\"{x:1345,y:761,t:1526930181628};\\\", \\\"{x:1345,y:763,t:1526930186276};\\\", \\\"{x:1342,y:770,t:1526930186284};\\\", \\\"{x:1339,y:777,t:1526930186295};\\\", \\\"{x:1334,y:789,t:1526930186311};\\\", \\\"{x:1330,y:805,t:1526930186328};\\\", \\\"{x:1324,y:823,t:1526930186344};\\\", \\\"{x:1319,y:840,t:1526930186362};\\\", \\\"{x:1315,y:852,t:1526930186378};\\\", \\\"{x:1311,y:864,t:1526930186395};\\\", \\\"{x:1307,y:880,t:1526930186411};\\\", \\\"{x:1305,y:894,t:1526930186427};\\\", \\\"{x:1300,y:906,t:1526930186444};\\\", \\\"{x:1296,y:922,t:1526930186462};\\\", \\\"{x:1294,y:932,t:1526930186478};\\\", \\\"{x:1288,y:944,t:1526930186494};\\\", \\\"{x:1284,y:952,t:1526930186512};\\\", \\\"{x:1280,y:959,t:1526930186527};\\\", \\\"{x:1279,y:964,t:1526930186544};\\\", \\\"{x:1277,y:970,t:1526930186562};\\\", \\\"{x:1274,y:975,t:1526930186578};\\\", \\\"{x:1272,y:978,t:1526930186595};\\\", \\\"{x:1270,y:981,t:1526930186612};\\\", \\\"{x:1269,y:982,t:1526930186835};\\\", \\\"{x:1268,y:982,t:1526930186844};\\\", \\\"{x:1266,y:982,t:1526930186861};\\\", \\\"{x:1264,y:982,t:1526930186879};\\\", \\\"{x:1264,y:977,t:1526930186895};\\\", \\\"{x:1264,y:969,t:1526930186912};\\\", \\\"{x:1264,y:958,t:1526930186929};\\\", \\\"{x:1264,y:945,t:1526930186944};\\\", \\\"{x:1264,y:936,t:1526930186962};\\\", \\\"{x:1265,y:923,t:1526930186979};\\\", \\\"{x:1269,y:912,t:1526930186994};\\\", \\\"{x:1275,y:892,t:1526930187011};\\\", \\\"{x:1278,y:878,t:1526930187028};\\\", \\\"{x:1281,y:866,t:1526930187045};\\\", \\\"{x:1285,y:853,t:1526930187062};\\\", \\\"{x:1289,y:842,t:1526930187079};\\\", \\\"{x:1290,y:831,t:1526930187095};\\\", \\\"{x:1293,y:822,t:1526930187112};\\\", \\\"{x:1295,y:816,t:1526930187128};\\\", \\\"{x:1296,y:812,t:1526930187145};\\\", \\\"{x:1298,y:809,t:1526930187162};\\\", \\\"{x:1300,y:805,t:1526930187179};\\\", \\\"{x:1301,y:802,t:1526930187195};\\\", \\\"{x:1306,y:795,t:1526930187212};\\\", \\\"{x:1308,y:792,t:1526930187228};\\\", \\\"{x:1311,y:790,t:1526930187245};\\\", \\\"{x:1318,y:782,t:1526930187262};\\\", \\\"{x:1326,y:776,t:1526930187278};\\\", \\\"{x:1331,y:769,t:1526930187294};\\\", \\\"{x:1336,y:764,t:1526930187312};\\\", \\\"{x:1337,y:761,t:1526930187328};\\\", \\\"{x:1338,y:760,t:1526930187346};\\\", \\\"{x:1339,y:759,t:1526930187466};\\\", \\\"{x:1340,y:759,t:1526930187563};\\\", \\\"{x:1341,y:759,t:1526930187587};\\\", \\\"{x:1342,y:759,t:1526930187620};\\\", \\\"{x:1343,y:759,t:1526930187708};\\\", \\\"{x:1344,y:759,t:1526930187716};\\\", \\\"{x:1345,y:759,t:1526930187746};\\\", \\\"{x:1345,y:760,t:1526930187772};\\\", \\\"{x:1345,y:761,t:1526930187779};\\\", \\\"{x:1344,y:763,t:1526930187795};\\\", \\\"{x:1339,y:768,t:1526930187813};\\\", \\\"{x:1335,y:772,t:1526930187829};\\\", \\\"{x:1329,y:779,t:1526930187846};\\\", \\\"{x:1323,y:786,t:1526930187862};\\\", \\\"{x:1318,y:793,t:1526930187879};\\\", \\\"{x:1314,y:799,t:1526930187895};\\\", \\\"{x:1310,y:806,t:1526930187913};\\\", \\\"{x:1306,y:811,t:1526930187929};\\\", \\\"{x:1302,y:817,t:1526930187946};\\\", \\\"{x:1297,y:826,t:1526930187962};\\\", \\\"{x:1293,y:832,t:1526930187979};\\\", \\\"{x:1282,y:845,t:1526930187996};\\\", \\\"{x:1273,y:857,t:1526930188013};\\\", \\\"{x:1264,y:870,t:1526930188028};\\\", \\\"{x:1257,y:880,t:1526930188046};\\\", \\\"{x:1251,y:889,t:1526930188063};\\\", \\\"{x:1248,y:896,t:1526930188078};\\\", \\\"{x:1245,y:900,t:1526930188096};\\\", \\\"{x:1243,y:904,t:1526930188112};\\\", \\\"{x:1241,y:907,t:1526930188128};\\\", \\\"{x:1238,y:913,t:1526930188145};\\\", \\\"{x:1236,y:919,t:1526930188163};\\\", \\\"{x:1235,y:923,t:1526930188178};\\\", \\\"{x:1234,y:926,t:1526930188195};\\\", \\\"{x:1233,y:929,t:1526930188212};\\\", \\\"{x:1230,y:936,t:1526930188228};\\\", \\\"{x:1229,y:940,t:1526930188245};\\\", \\\"{x:1228,y:945,t:1526930188262};\\\", \\\"{x:1226,y:949,t:1526930188279};\\\", \\\"{x:1226,y:952,t:1526930188295};\\\", \\\"{x:1226,y:953,t:1526930188312};\\\", \\\"{x:1225,y:956,t:1526930188329};\\\", \\\"{x:1224,y:959,t:1526930188345};\\\", \\\"{x:1222,y:962,t:1526930188362};\\\", \\\"{x:1222,y:963,t:1526930188378};\\\", \\\"{x:1222,y:965,t:1526930188395};\\\", \\\"{x:1222,y:967,t:1526930188418};\\\", \\\"{x:1221,y:968,t:1526930188429};\\\", \\\"{x:1221,y:969,t:1526930188445};\\\", \\\"{x:1220,y:970,t:1526930188462};\\\", \\\"{x:1219,y:971,t:1526930188479};\\\", \\\"{x:1219,y:972,t:1526930188495};\\\", \\\"{x:1219,y:967,t:1526930188604};\\\", \\\"{x:1220,y:962,t:1526930188613};\\\", \\\"{x:1230,y:947,t:1526930188630};\\\", \\\"{x:1237,y:929,t:1526930188646};\\\", \\\"{x:1247,y:909,t:1526930188663};\\\", \\\"{x:1255,y:892,t:1526930188680};\\\", \\\"{x:1262,y:876,t:1526930188696};\\\", \\\"{x:1267,y:863,t:1526930188712};\\\", \\\"{x:1273,y:849,t:1526930188730};\\\", \\\"{x:1273,y:839,t:1526930188746};\\\", \\\"{x:1273,y:835,t:1526930188763};\\\", \\\"{x:1270,y:829,t:1526930188779};\\\", \\\"{x:1263,y:825,t:1526930188796};\\\", \\\"{x:1255,y:820,t:1526930188812};\\\", \\\"{x:1239,y:813,t:1526930188829};\\\", \\\"{x:1230,y:808,t:1526930188847};\\\", \\\"{x:1219,y:804,t:1526930188862};\\\", \\\"{x:1211,y:799,t:1526930188879};\\\", \\\"{x:1205,y:795,t:1526930188896};\\\", \\\"{x:1202,y:793,t:1526930188912};\\\", \\\"{x:1196,y:789,t:1526930188930};\\\", \\\"{x:1189,y:786,t:1526930188947};\\\", \\\"{x:1187,y:785,t:1526930188963};\\\", \\\"{x:1186,y:783,t:1526930188979};\\\", \\\"{x:1184,y:782,t:1526930188996};\\\", \\\"{x:1182,y:780,t:1526930189012};\\\", \\\"{x:1180,y:778,t:1526930189030};\\\", \\\"{x:1179,y:776,t:1526930189046};\\\", \\\"{x:1178,y:775,t:1526930189063};\\\", \\\"{x:1178,y:774,t:1526930189080};\\\", \\\"{x:1177,y:773,t:1526930189097};\\\", \\\"{x:1177,y:771,t:1526930189113};\\\", \\\"{x:1177,y:770,t:1526930189130};\\\", \\\"{x:1177,y:769,t:1526930189212};\\\", \\\"{x:1177,y:768,t:1526930189219};\\\", \\\"{x:1177,y:767,t:1526930189231};\\\", \\\"{x:1177,y:766,t:1526930189247};\\\", \\\"{x:1177,y:764,t:1526930189264};\\\", \\\"{x:1178,y:761,t:1526930189279};\\\", \\\"{x:1178,y:759,t:1526930189296};\\\", \\\"{x:1179,y:759,t:1526930189313};\\\", \\\"{x:1174,y:758,t:1526930189476};\\\", \\\"{x:1143,y:755,t:1526930189482};\\\", \\\"{x:1083,y:744,t:1526930189496};\\\", \\\"{x:969,y:728,t:1526930189514};\\\", \\\"{x:843,y:699,t:1526930189530};\\\", \\\"{x:660,y:642,t:1526930189546};\\\", \\\"{x:577,y:605,t:1526930189564};\\\", \\\"{x:547,y:585,t:1526930189581};\\\", \\\"{x:542,y:578,t:1526930189596};\\\", \\\"{x:540,y:576,t:1526930189615};\\\", \\\"{x:540,y:573,t:1526930189811};\\\", \\\"{x:546,y:573,t:1526930189819};\\\", \\\"{x:559,y:573,t:1526930189832};\\\", \\\"{x:583,y:571,t:1526930189849};\\\", \\\"{x:604,y:568,t:1526930189866};\\\", \\\"{x:624,y:567,t:1526930189881};\\\", \\\"{x:661,y:566,t:1526930189899};\\\", \\\"{x:664,y:566,t:1526930189915};\\\", \\\"{x:661,y:566,t:1526930189938};\\\", \\\"{x:634,y:566,t:1526930189949};\\\", \\\"{x:515,y:566,t:1526930189966};\\\", \\\"{x:406,y:569,t:1526930189983};\\\", \\\"{x:364,y:577,t:1526930189999};\\\", \\\"{x:354,y:579,t:1526930190015};\\\", \\\"{x:353,y:580,t:1526930190032};\\\", \\\"{x:350,y:581,t:1526930190074};\\\", \\\"{x:342,y:586,t:1526930190082};\\\", \\\"{x:314,y:597,t:1526930190099};\\\", \\\"{x:283,y:606,t:1526930190116};\\\", \\\"{x:244,y:612,t:1526930190132};\\\", \\\"{x:229,y:617,t:1526930190149};\\\", \\\"{x:228,y:618,t:1526930190165};\\\", \\\"{x:228,y:619,t:1526930190183};\\\", \\\"{x:237,y:619,t:1526930190199};\\\", \\\"{x:255,y:615,t:1526930190215};\\\", \\\"{x:269,y:609,t:1526930190233};\\\", \\\"{x:280,y:601,t:1526930190251};\\\", \\\"{x:288,y:591,t:1526930190266};\\\", \\\"{x:296,y:575,t:1526930190282};\\\", \\\"{x:300,y:565,t:1526930190299};\\\", \\\"{x:301,y:561,t:1526930190318};\\\", \\\"{x:304,y:557,t:1526930190332};\\\", \\\"{x:306,y:555,t:1526930190350};\\\", \\\"{x:309,y:550,t:1526930190365};\\\", \\\"{x:312,y:549,t:1526930190382};\\\", \\\"{x:318,y:542,t:1526930190399};\\\", \\\"{x:327,y:538,t:1526930190416};\\\", \\\"{x:331,y:534,t:1526930190432};\\\", \\\"{x:336,y:532,t:1526930190449};\\\", \\\"{x:341,y:526,t:1526930190466};\\\", \\\"{x:347,y:522,t:1526930190483};\\\", \\\"{x:353,y:517,t:1526930190499};\\\", \\\"{x:356,y:516,t:1526930190516};\\\", \\\"{x:358,y:514,t:1526930190532};\\\", \\\"{x:359,y:513,t:1526930190562};\\\", \\\"{x:360,y:512,t:1526930190570};\\\", \\\"{x:361,y:511,t:1526930190586};\\\", \\\"{x:363,y:510,t:1526930190599};\\\", \\\"{x:365,y:510,t:1526930190617};\\\", \\\"{x:367,y:509,t:1526930190633};\\\", \\\"{x:368,y:508,t:1526930190650};\\\", \\\"{x:368,y:507,t:1526930190731};\\\", \\\"{x:365,y:507,t:1526930190739};\\\", \\\"{x:358,y:506,t:1526930190750};\\\", \\\"{x:339,y:503,t:1526930190767};\\\", \\\"{x:323,y:502,t:1526930190784};\\\", \\\"{x:310,y:500,t:1526930190800};\\\", \\\"{x:302,y:498,t:1526930190817};\\\", \\\"{x:300,y:497,t:1526930190834};\\\", \\\"{x:299,y:497,t:1526930190891};\\\", \\\"{x:296,y:497,t:1526930190907};\\\", \\\"{x:292,y:497,t:1526930190916};\\\", \\\"{x:277,y:497,t:1526930190933};\\\", \\\"{x:259,y:497,t:1526930190953};\\\", \\\"{x:244,y:497,t:1526930190966};\\\", \\\"{x:236,y:497,t:1526930190983};\\\", \\\"{x:229,y:497,t:1526930191000};\\\", \\\"{x:227,y:497,t:1526930191016};\\\", \\\"{x:226,y:497,t:1526930191033};\\\", \\\"{x:222,y:496,t:1526930191050};\\\", \\\"{x:218,y:495,t:1526930191066};\\\", \\\"{x:215,y:494,t:1526930191083};\\\", \\\"{x:212,y:493,t:1526930191100};\\\", \\\"{x:205,y:491,t:1526930191116};\\\", \\\"{x:197,y:490,t:1526930191133};\\\", \\\"{x:188,y:490,t:1526930191151};\\\", \\\"{x:184,y:489,t:1526930191168};\\\", \\\"{x:183,y:489,t:1526930191235};\\\", \\\"{x:187,y:491,t:1526930191397};\\\", \\\"{x:192,y:497,t:1526930191403};\\\", \\\"{x:200,y:505,t:1526930191418};\\\", \\\"{x:223,y:521,t:1526930191434};\\\", \\\"{x:268,y:547,t:1526930191450};\\\", \\\"{x:295,y:567,t:1526930191466};\\\", \\\"{x:319,y:585,t:1526930191483};\\\", \\\"{x:350,y:609,t:1526930191501};\\\", \\\"{x:387,y:636,t:1526930191516};\\\", \\\"{x:408,y:651,t:1526930191533};\\\", \\\"{x:420,y:662,t:1526930191551};\\\", \\\"{x:424,y:665,t:1526930191566};\\\", \\\"{x:426,y:667,t:1526930191583};\\\", \\\"{x:431,y:674,t:1526930191601};\\\", \\\"{x:441,y:684,t:1526930191616};\\\", \\\"{x:454,y:697,t:1526930191634};\\\", \\\"{x:479,y:715,t:1526930191650};\\\", \\\"{x:490,y:721,t:1526930191667};\\\", \\\"{x:493,y:723,t:1526930191683};\\\", \\\"{x:488,y:723,t:1526930191739};\\\", \\\"{x:479,y:711,t:1526930191751};\\\", \\\"{x:444,y:678,t:1526930191767};\\\", \\\"{x:395,y:635,t:1526930191783};\\\", \\\"{x:343,y:596,t:1526930191800};\\\", \\\"{x:293,y:561,t:1526930191818};\\\", \\\"{x:262,y:539,t:1526930191835};\\\", \\\"{x:243,y:524,t:1526930191851};\\\", \\\"{x:239,y:519,t:1526930191867};\\\", \\\"{x:236,y:516,t:1526930191884};\\\", \\\"{x:236,y:514,t:1526930191901};\\\", \\\"{x:235,y:512,t:1526930191917};\\\", \\\"{x:234,y:511,t:1526930191938};\\\", \\\"{x:233,y:510,t:1526930191951};\\\", \\\"{x:229,y:508,t:1526930191968};\\\", \\\"{x:225,y:507,t:1526930191984};\\\", \\\"{x:217,y:505,t:1526930192001};\\\", \\\"{x:211,y:503,t:1526930192017};\\\", \\\"{x:200,y:500,t:1526930192034};\\\", \\\"{x:194,y:499,t:1526930192051};\\\", \\\"{x:189,y:497,t:1526930192068};\\\", \\\"{x:184,y:495,t:1526930192085};\\\", \\\"{x:177,y:494,t:1526930192101};\\\", \\\"{x:171,y:493,t:1526930192117};\\\", \\\"{x:166,y:491,t:1526930192133};\\\", \\\"{x:163,y:490,t:1526930192150};\\\", \\\"{x:163,y:491,t:1526930192363};\\\", \\\"{x:171,y:497,t:1526930192371};\\\", \\\"{x:193,y:510,t:1526930192385};\\\", \\\"{x:240,y:534,t:1526930192401};\\\", \\\"{x:272,y:550,t:1526930192417};\\\", \\\"{x:297,y:569,t:1526930192435};\\\", \\\"{x:310,y:579,t:1526930192450};\\\", \\\"{x:317,y:586,t:1526930192467};\\\", \\\"{x:329,y:600,t:1526930192485};\\\", \\\"{x:345,y:618,t:1526930192500};\\\", \\\"{x:363,y:640,t:1526930192518};\\\", \\\"{x:384,y:665,t:1526930192535};\\\", \\\"{x:406,y:688,t:1526930192552};\\\", \\\"{x:421,y:702,t:1526930192567};\\\", \\\"{x:436,y:713,t:1526930192584};\\\", \\\"{x:441,y:717,t:1526930192600};\\\", \\\"{x:445,y:719,t:1526930192617};\\\", \\\"{x:449,y:722,t:1526930192635};\\\", \\\"{x:452,y:724,t:1526930192651};\\\", \\\"{x:456,y:725,t:1526930192668};\\\", \\\"{x:459,y:727,t:1526930192685};\\\", \\\"{x:462,y:727,t:1526930192702};\\\", \\\"{x:463,y:727,t:1526930192718};\\\", \\\"{x:464,y:727,t:1526930192795};\\\", \\\"{x:465,y:727,t:1526930192803};\\\", \\\"{x:467,y:730,t:1526930192817};\\\", \\\"{x:468,y:730,t:1526930192834};\\\", \\\"{x:468,y:731,t:1526930192859};\\\", \\\"{x:468,y:732,t:1526930192867};\\\", \\\"{x:467,y:733,t:1526930192884};\\\", \\\"{x:466,y:733,t:1526930192901};\\\", \\\"{x:466,y:733,t:1526930192941};\\\", \\\"{x:466,y:735,t:1526930192970};\\\", \\\"{x:466,y:738,t:1526930192985};\\\", \\\"{x:466,y:743,t:1526930193001};\\\", \\\"{x:464,y:746,t:1526930193017};\\\", \\\"{x:464,y:745,t:1526930193579};\\\", \\\"{x:464,y:744,t:1526930193586};\\\", \\\"{x:464,y:743,t:1526930193601};\\\", \\\"{x:466,y:737,t:1526930193618};\\\", \\\"{x:469,y:732,t:1526930193635};\\\", \\\"{x:470,y:732,t:1526930193651};\\\", \\\"{x:471,y:732,t:1526930193787};\\\" ] }, { \\\"rt\\\": 8466, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 565587, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:473,y:732,t:1526930196428};\\\", \\\"{x:480,y:732,t:1526930196440};\\\", \\\"{x:491,y:732,t:1526930196464};\\\", \\\"{x:494,y:732,t:1526930196473};\\\", \\\"{x:508,y:727,t:1526930196489};\\\", \\\"{x:571,y:718,t:1526930196506};\\\", \\\"{x:603,y:713,t:1526930196523};\\\", \\\"{x:616,y:711,t:1526930196539};\\\", \\\"{x:623,y:708,t:1526930196554};\\\", \\\"{x:648,y:705,t:1526930196570};\\\", \\\"{x:687,y:701,t:1526930196588};\\\", \\\"{x:753,y:701,t:1526930196604};\\\", \\\"{x:845,y:701,t:1526930196620};\\\", \\\"{x:939,y:701,t:1526930196638};\\\", \\\"{x:1050,y:701,t:1526930196654};\\\", \\\"{x:1191,y:701,t:1526930196670};\\\", \\\"{x:1320,y:706,t:1526930196687};\\\", \\\"{x:1428,y:720,t:1526930196704};\\\", \\\"{x:1503,y:731,t:1526930196720};\\\", \\\"{x:1540,y:736,t:1526930196738};\\\", \\\"{x:1569,y:745,t:1526930196754};\\\", \\\"{x:1576,y:745,t:1526930196771};\\\", \\\"{x:1577,y:745,t:1526930196788};\\\", \\\"{x:1579,y:746,t:1526930196805};\\\", \\\"{x:1579,y:745,t:1526930196955};\\\", \\\"{x:1578,y:741,t:1526930196971};\\\", \\\"{x:1576,y:734,t:1526930196988};\\\", \\\"{x:1574,y:727,t:1526930197005};\\\", \\\"{x:1572,y:720,t:1526930197021};\\\", \\\"{x:1570,y:709,t:1526930197038};\\\", \\\"{x:1566,y:698,t:1526930197055};\\\", \\\"{x:1565,y:688,t:1526930197072};\\\", \\\"{x:1562,y:674,t:1526930197088};\\\", \\\"{x:1558,y:659,t:1526930197106};\\\", \\\"{x:1556,y:644,t:1526930197122};\\\", \\\"{x:1549,y:629,t:1526930197139};\\\", \\\"{x:1534,y:604,t:1526930197154};\\\", \\\"{x:1526,y:589,t:1526930197172};\\\", \\\"{x:1521,y:579,t:1526930197188};\\\", \\\"{x:1518,y:574,t:1526930197205};\\\", \\\"{x:1515,y:570,t:1526930197222};\\\", \\\"{x:1510,y:567,t:1526930197238};\\\", \\\"{x:1506,y:566,t:1526930197256};\\\", \\\"{x:1504,y:565,t:1526930197273};\\\", \\\"{x:1503,y:565,t:1526930197308};\\\", \\\"{x:1501,y:564,t:1526930197322};\\\", \\\"{x:1501,y:563,t:1526930197339};\\\", \\\"{x:1496,y:559,t:1526930197355};\\\", \\\"{x:1494,y:557,t:1526930197373};\\\", \\\"{x:1492,y:554,t:1526930197387};\\\", \\\"{x:1490,y:552,t:1526930197405};\\\", \\\"{x:1490,y:551,t:1526930197422};\\\", \\\"{x:1490,y:550,t:1526930197438};\\\", \\\"{x:1490,y:549,t:1526930197459};\\\", \\\"{x:1490,y:548,t:1526930197492};\\\", \\\"{x:1490,y:547,t:1526930197506};\\\", \\\"{x:1490,y:546,t:1526930197546};\\\", \\\"{x:1491,y:546,t:1526930197554};\\\", \\\"{x:1495,y:547,t:1526930197572};\\\", \\\"{x:1497,y:548,t:1526930197588};\\\", \\\"{x:1499,y:550,t:1526930197604};\\\", \\\"{x:1499,y:553,t:1526930197621};\\\", \\\"{x:1499,y:557,t:1526930197639};\\\", \\\"{x:1499,y:561,t:1526930197654};\\\", \\\"{x:1499,y:568,t:1526930197672};\\\", \\\"{x:1499,y:573,t:1526930197688};\\\", \\\"{x:1499,y:579,t:1526930197705};\\\", \\\"{x:1499,y:584,t:1526930197722};\\\", \\\"{x:1500,y:595,t:1526930197739};\\\", \\\"{x:1503,y:602,t:1526930197754};\\\", \\\"{x:1510,y:616,t:1526930197771};\\\", \\\"{x:1517,y:632,t:1526930197789};\\\", \\\"{x:1526,y:652,t:1526930197805};\\\", \\\"{x:1535,y:676,t:1526930197823};\\\", \\\"{x:1543,y:701,t:1526930197839};\\\", \\\"{x:1550,y:725,t:1526930197855};\\\", \\\"{x:1554,y:747,t:1526930197872};\\\", \\\"{x:1557,y:768,t:1526930197889};\\\", \\\"{x:1558,y:789,t:1526930197904};\\\", \\\"{x:1559,y:809,t:1526930197922};\\\", \\\"{x:1559,y:831,t:1526930197938};\\\", \\\"{x:1559,y:845,t:1526930197955};\\\", \\\"{x:1559,y:853,t:1526930197972};\\\", \\\"{x:1558,y:857,t:1526930197989};\\\", \\\"{x:1556,y:861,t:1526930198006};\\\", \\\"{x:1556,y:862,t:1526930198027};\\\", \\\"{x:1555,y:864,t:1526930198039};\\\", \\\"{x:1554,y:865,t:1526930198056};\\\", \\\"{x:1554,y:867,t:1526930198072};\\\", \\\"{x:1551,y:868,t:1526930198089};\\\", \\\"{x:1548,y:869,t:1526930198106};\\\", \\\"{x:1543,y:870,t:1526930198122};\\\", \\\"{x:1529,y:870,t:1526930198139};\\\", \\\"{x:1524,y:872,t:1526930198156};\\\", \\\"{x:1523,y:872,t:1526930198172};\\\", \\\"{x:1522,y:872,t:1526930198243};\\\", \\\"{x:1521,y:871,t:1526930198299};\\\", \\\"{x:1519,y:869,t:1526930198307};\\\", \\\"{x:1518,y:867,t:1526930198322};\\\", \\\"{x:1508,y:860,t:1526930198339};\\\", \\\"{x:1502,y:854,t:1526930198356};\\\", \\\"{x:1498,y:850,t:1526930198372};\\\", \\\"{x:1495,y:845,t:1526930198389};\\\", \\\"{x:1493,y:842,t:1526930198407};\\\", \\\"{x:1490,y:838,t:1526930198422};\\\", \\\"{x:1490,y:836,t:1526930198440};\\\", \\\"{x:1487,y:834,t:1526930198456};\\\", \\\"{x:1482,y:831,t:1526930198476};\\\", \\\"{x:1480,y:830,t:1526930198488};\\\", \\\"{x:1470,y:827,t:1526930198506};\\\", \\\"{x:1452,y:822,t:1526930198522};\\\", \\\"{x:1438,y:814,t:1526930198538};\\\", \\\"{x:1426,y:809,t:1526930198555};\\\", \\\"{x:1416,y:805,t:1526930198573};\\\", \\\"{x:1410,y:801,t:1526930198589};\\\", \\\"{x:1408,y:799,t:1526930198606};\\\", \\\"{x:1405,y:795,t:1526930198623};\\\", \\\"{x:1402,y:791,t:1526930198638};\\\", \\\"{x:1400,y:787,t:1526930198655};\\\", \\\"{x:1396,y:783,t:1526930198673};\\\", \\\"{x:1392,y:779,t:1526930198689};\\\", \\\"{x:1390,y:777,t:1526930198705};\\\", \\\"{x:1388,y:773,t:1526930198722};\\\", \\\"{x:1386,y:770,t:1526930198739};\\\", \\\"{x:1382,y:764,t:1526930198756};\\\", \\\"{x:1378,y:761,t:1526930198773};\\\", \\\"{x:1375,y:757,t:1526930198789};\\\", \\\"{x:1373,y:754,t:1526930198806};\\\", \\\"{x:1370,y:751,t:1526930198823};\\\", \\\"{x:1364,y:748,t:1526930198839};\\\", \\\"{x:1359,y:745,t:1526930198855};\\\", \\\"{x:1350,y:742,t:1526930198873};\\\", \\\"{x:1336,y:737,t:1526930198890};\\\", \\\"{x:1331,y:734,t:1526930198906};\\\", \\\"{x:1327,y:731,t:1526930198923};\\\", \\\"{x:1325,y:730,t:1526930198939};\\\", \\\"{x:1324,y:728,t:1526930198956};\\\", \\\"{x:1322,y:724,t:1526930198973};\\\", \\\"{x:1322,y:722,t:1526930198995};\\\", \\\"{x:1322,y:721,t:1526930199006};\\\", \\\"{x:1321,y:720,t:1526930199023};\\\", \\\"{x:1321,y:719,t:1526930199040};\\\", \\\"{x:1321,y:717,t:1526930199056};\\\", \\\"{x:1321,y:716,t:1526930199073};\\\", \\\"{x:1321,y:715,t:1526930199115};\\\", \\\"{x:1321,y:714,t:1526930199123};\\\", \\\"{x:1321,y:713,t:1526930199140};\\\", \\\"{x:1321,y:712,t:1526930199163};\\\", \\\"{x:1321,y:711,t:1526930199173};\\\", \\\"{x:1322,y:711,t:1526930199190};\\\", \\\"{x:1322,y:710,t:1526930199206};\\\", \\\"{x:1324,y:709,t:1526930199223};\\\", \\\"{x:1325,y:708,t:1526930199240};\\\", \\\"{x:1327,y:706,t:1526930199256};\\\", \\\"{x:1328,y:705,t:1526930199273};\\\", \\\"{x:1329,y:705,t:1526930199290};\\\", \\\"{x:1330,y:705,t:1526930199306};\\\", \\\"{x:1331,y:705,t:1526930199355};\\\", \\\"{x:1332,y:704,t:1526930199363};\\\", \\\"{x:1333,y:702,t:1526930199374};\\\", \\\"{x:1336,y:701,t:1526930199390};\\\", \\\"{x:1337,y:701,t:1526930199407};\\\", \\\"{x:1338,y:701,t:1526930199423};\\\", \\\"{x:1339,y:701,t:1526930199828};\\\", \\\"{x:1340,y:701,t:1526930199840};\\\", \\\"{x:1341,y:700,t:1526930199875};\\\", \\\"{x:1342,y:699,t:1526930200115};\\\", \\\"{x:1343,y:699,t:1526930200132};\\\", \\\"{x:1343,y:698,t:1526930200140};\\\", \\\"{x:1344,y:698,t:1526930200243};\\\", \\\"{x:1345,y:698,t:1526930200274};\\\", \\\"{x:1346,y:697,t:1526930200643};\\\", \\\"{x:1346,y:696,t:1526930200779};\\\", \\\"{x:1346,y:695,t:1526930200819};\\\", \\\"{x:1346,y:694,t:1526930200835};\\\", \\\"{x:1346,y:693,t:1526930200859};\\\", \\\"{x:1346,y:692,t:1526930200874};\\\", \\\"{x:1346,y:691,t:1526930200956};\\\", \\\"{x:1345,y:688,t:1526930200974};\\\", \\\"{x:1344,y:686,t:1526930200991};\\\", \\\"{x:1342,y:684,t:1526930201009};\\\", \\\"{x:1338,y:680,t:1526930201025};\\\", \\\"{x:1334,y:674,t:1526930201041};\\\", \\\"{x:1320,y:658,t:1526930201058};\\\", \\\"{x:1290,y:632,t:1526930201074};\\\", \\\"{x:1242,y:591,t:1526930201091};\\\", \\\"{x:1223,y:569,t:1526930201109};\\\", \\\"{x:1218,y:552,t:1526930201125};\\\", \\\"{x:1214,y:538,t:1526930201141};\\\", \\\"{x:1213,y:528,t:1526930201158};\\\", \\\"{x:1212,y:522,t:1526930201174};\\\", \\\"{x:1210,y:518,t:1526930201191};\\\", \\\"{x:1208,y:515,t:1526930201208};\\\", \\\"{x:1203,y:512,t:1526930201224};\\\", \\\"{x:1195,y:509,t:1526930201241};\\\", \\\"{x:1182,y:507,t:1526930201258};\\\", \\\"{x:1157,y:506,t:1526930201274};\\\", \\\"{x:1097,y:503,t:1526930201291};\\\", \\\"{x:1044,y:503,t:1526930201308};\\\", \\\"{x:993,y:503,t:1526930201325};\\\", \\\"{x:956,y:503,t:1526930201342};\\\", \\\"{x:923,y:505,t:1526930201359};\\\", \\\"{x:900,y:509,t:1526930201374};\\\", \\\"{x:885,y:511,t:1526930201391};\\\", \\\"{x:875,y:514,t:1526930201408};\\\", \\\"{x:861,y:518,t:1526930201425};\\\", \\\"{x:841,y:524,t:1526930201440};\\\", \\\"{x:823,y:526,t:1526930201458};\\\", \\\"{x:795,y:530,t:1526930201475};\\\", \\\"{x:777,y:533,t:1526930201492};\\\", \\\"{x:758,y:533,t:1526930201508};\\\", \\\"{x:734,y:533,t:1526930201524};\\\", \\\"{x:705,y:533,t:1526930201543};\\\", \\\"{x:677,y:533,t:1526930201558};\\\", \\\"{x:654,y:533,t:1526930201575};\\\", \\\"{x:637,y:533,t:1526930201592};\\\", \\\"{x:634,y:533,t:1526930201608};\\\", \\\"{x:633,y:533,t:1526930201625};\\\", \\\"{x:631,y:532,t:1526930201651};\\\", \\\"{x:630,y:532,t:1526930201659};\\\", \\\"{x:629,y:530,t:1526930201675};\\\", \\\"{x:626,y:528,t:1526930201692};\\\", \\\"{x:624,y:526,t:1526930201709};\\\", \\\"{x:619,y:522,t:1526930201725};\\\", \\\"{x:614,y:518,t:1526930201742};\\\", \\\"{x:607,y:514,t:1526930201759};\\\", \\\"{x:601,y:508,t:1526930201775};\\\", \\\"{x:600,y:505,t:1526930201791};\\\", \\\"{x:600,y:504,t:1526930201808};\\\", \\\"{x:600,y:503,t:1526930201825};\\\", \\\"{x:600,y:501,t:1526930201841};\\\", \\\"{x:600,y:498,t:1526930201858};\\\", \\\"{x:600,y:497,t:1526930201874};\\\", \\\"{x:600,y:499,t:1526930202081};\\\", \\\"{x:600,y:506,t:1526930202091};\\\", \\\"{x:600,y:529,t:1526930202109};\\\", \\\"{x:598,y:552,t:1526930202126};\\\", \\\"{x:591,y:575,t:1526930202142};\\\", \\\"{x:582,y:601,t:1526930202159};\\\", \\\"{x:574,y:625,t:1526930202175};\\\", \\\"{x:568,y:642,t:1526930202192};\\\", \\\"{x:563,y:657,t:1526930202209};\\\", \\\"{x:561,y:663,t:1526930202225};\\\", \\\"{x:561,y:665,t:1526930202241};\\\", \\\"{x:558,y:669,t:1526930202258};\\\", \\\"{x:557,y:672,t:1526930202276};\\\", \\\"{x:553,y:679,t:1526930202291};\\\", \\\"{x:549,y:687,t:1526930202309};\\\", \\\"{x:543,y:695,t:1526930202325};\\\", \\\"{x:540,y:702,t:1526930202342};\\\", \\\"{x:536,y:709,t:1526930202359};\\\", \\\"{x:534,y:711,t:1526930202375};\\\", \\\"{x:533,y:713,t:1526930202392};\\\", \\\"{x:532,y:714,t:1526930202409};\\\", \\\"{x:531,y:715,t:1526930202426};\\\", \\\"{x:528,y:718,t:1526930202442};\\\", \\\"{x:524,y:723,t:1526930202460};\\\", \\\"{x:521,y:727,t:1526930202475};\\\", \\\"{x:518,y:731,t:1526930202491};\\\", \\\"{x:516,y:736,t:1526930202509};\\\", \\\"{x:515,y:737,t:1526930202524};\\\", \\\"{x:515,y:738,t:1526930202541};\\\", \\\"{x:517,y:739,t:1526930202762};\\\", \\\"{x:529,y:739,t:1526930202775};\\\", \\\"{x:585,y:731,t:1526930202792};\\\", \\\"{x:684,y:721,t:1526930202809};\\\", \\\"{x:805,y:709,t:1526930202825};\\\", \\\"{x:953,y:691,t:1526930202842};\\\", \\\"{x:1026,y:680,t:1526930202859};\\\", \\\"{x:1074,y:673,t:1526930202876};\\\", \\\"{x:1100,y:668,t:1526930202893};\\\", \\\"{x:1115,y:666,t:1526930202908};\\\", \\\"{x:1123,y:664,t:1526930202926};\\\", \\\"{x:1126,y:663,t:1526930202943};\\\", \\\"{x:1127,y:663,t:1526930203067};\\\", \\\"{x:1128,y:663,t:1526930203179};\\\", \\\"{x:1127,y:664,t:1526930203283};\\\", \\\"{x:1126,y:665,t:1526930203299};\\\", \\\"{x:1124,y:666,t:1526930203322};\\\", \\\"{x:1123,y:667,t:1526930203339};\\\" ] }, { \\\"rt\\\": 7071, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 573875, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1122,y:667,t:1526930203909};\\\", \\\"{x:1125,y:668,t:1526930204811};\\\", \\\"{x:1128,y:668,t:1526930204827};\\\", \\\"{x:1134,y:666,t:1526930204844};\\\", \\\"{x:1142,y:661,t:1526930204861};\\\", \\\"{x:1166,y:656,t:1526930204878};\\\", \\\"{x:1208,y:652,t:1526930204894};\\\", \\\"{x:1222,y:651,t:1526930204911};\\\", \\\"{x:1290,y:653,t:1526930204928};\\\", \\\"{x:1300,y:654,t:1526930204944};\\\", \\\"{x:1302,y:657,t:1526930204961};\\\", \\\"{x:1304,y:657,t:1526930204978};\\\", \\\"{x:1304,y:658,t:1526930205595};\\\", \\\"{x:1315,y:661,t:1526930205611};\\\", \\\"{x:1337,y:663,t:1526930205628};\\\", \\\"{x:1358,y:668,t:1526930205645};\\\", \\\"{x:1383,y:674,t:1526930205662};\\\", \\\"{x:1400,y:683,t:1526930205678};\\\", \\\"{x:1422,y:693,t:1526930205695};\\\", \\\"{x:1442,y:697,t:1526930205713};\\\", \\\"{x:1468,y:701,t:1526930205729};\\\", \\\"{x:1485,y:707,t:1526930205746};\\\", \\\"{x:1516,y:718,t:1526930205762};\\\", \\\"{x:1518,y:720,t:1526930205779};\\\", \\\"{x:1538,y:735,t:1526930205795};\\\", \\\"{x:1547,y:744,t:1526930205812};\\\", \\\"{x:1547,y:750,t:1526930205829};\\\", \\\"{x:1546,y:757,t:1526930205845};\\\", \\\"{x:1541,y:764,t:1526930205862};\\\", \\\"{x:1536,y:771,t:1526930205878};\\\", \\\"{x:1533,y:778,t:1526930205895};\\\", \\\"{x:1529,y:785,t:1526930205913};\\\", \\\"{x:1523,y:794,t:1526930205929};\\\", \\\"{x:1513,y:809,t:1526930205945};\\\", \\\"{x:1509,y:821,t:1526930205963};\\\", \\\"{x:1509,y:822,t:1526930206027};\\\", \\\"{x:1508,y:823,t:1526930206045};\\\", \\\"{x:1508,y:826,t:1526930206139};\\\", \\\"{x:1508,y:829,t:1526930206146};\\\", \\\"{x:1508,y:831,t:1526930206171};\\\", \\\"{x:1508,y:833,t:1526930206187};\\\", \\\"{x:1508,y:837,t:1526930206195};\\\", \\\"{x:1507,y:841,t:1526930206212};\\\", \\\"{x:1503,y:845,t:1526930206229};\\\", \\\"{x:1501,y:848,t:1526930206246};\\\", \\\"{x:1499,y:852,t:1526930206263};\\\", \\\"{x:1498,y:855,t:1526930206280};\\\", \\\"{x:1496,y:858,t:1526930206295};\\\", \\\"{x:1495,y:860,t:1526930206313};\\\", \\\"{x:1492,y:866,t:1526930206330};\\\", \\\"{x:1485,y:871,t:1526930206346};\\\", \\\"{x:1463,y:884,t:1526930206363};\\\", \\\"{x:1443,y:895,t:1526930206379};\\\", \\\"{x:1421,y:910,t:1526930206395};\\\", \\\"{x:1396,y:928,t:1526930206412};\\\", \\\"{x:1382,y:938,t:1526930206429};\\\", \\\"{x:1376,y:945,t:1526930206445};\\\", \\\"{x:1374,y:948,t:1526930206462};\\\", \\\"{x:1372,y:951,t:1526930206479};\\\", \\\"{x:1371,y:957,t:1526930206496};\\\", \\\"{x:1369,y:963,t:1526930206513};\\\", \\\"{x:1367,y:971,t:1526930206530};\\\", \\\"{x:1366,y:978,t:1526930206546};\\\", \\\"{x:1366,y:981,t:1526930206563};\\\", \\\"{x:1366,y:983,t:1526930206579};\\\", \\\"{x:1365,y:983,t:1526930206667};\\\", \\\"{x:1364,y:983,t:1526930206679};\\\", \\\"{x:1362,y:981,t:1526930206697};\\\", \\\"{x:1360,y:977,t:1526930206712};\\\", \\\"{x:1358,y:974,t:1526930206729};\\\", \\\"{x:1357,y:974,t:1526930206746};\\\", \\\"{x:1357,y:972,t:1526930206763};\\\", \\\"{x:1356,y:972,t:1526930206787};\\\", \\\"{x:1355,y:971,t:1526930206796};\\\", \\\"{x:1354,y:971,t:1526930206819};\\\", \\\"{x:1351,y:970,t:1526930206842};\\\", \\\"{x:1350,y:970,t:1526930206923};\\\", \\\"{x:1347,y:970,t:1526930206947};\\\", \\\"{x:1346,y:970,t:1526930206962};\\\", \\\"{x:1343,y:970,t:1526930206979};\\\", \\\"{x:1341,y:970,t:1526930207059};\\\", \\\"{x:1340,y:970,t:1526930207251};\\\", \\\"{x:1339,y:969,t:1526930207299};\\\", \\\"{x:1338,y:969,t:1526930207443};\\\", \\\"{x:1337,y:968,t:1526930207500};\\\", \\\"{x:1337,y:967,t:1526930207636};\\\", \\\"{x:1337,y:966,t:1526930207646};\\\", \\\"{x:1337,y:965,t:1526930207667};\\\", \\\"{x:1337,y:964,t:1526930207681};\\\", \\\"{x:1338,y:963,t:1526930207696};\\\", \\\"{x:1338,y:961,t:1526930207715};\\\", \\\"{x:1339,y:959,t:1526930207731};\\\", \\\"{x:1340,y:958,t:1526930207755};\\\", \\\"{x:1340,y:957,t:1526930207763};\\\", \\\"{x:1341,y:957,t:1526930207780};\\\", \\\"{x:1341,y:956,t:1526930207797};\\\", \\\"{x:1341,y:955,t:1526930207835};\\\", \\\"{x:1342,y:955,t:1526930207850};\\\", \\\"{x:1342,y:954,t:1526930207863};\\\", \\\"{x:1342,y:953,t:1526930207881};\\\", \\\"{x:1343,y:952,t:1526930207897};\\\", \\\"{x:1344,y:951,t:1526930207963};\\\", \\\"{x:1344,y:950,t:1526930207995};\\\", \\\"{x:1344,y:949,t:1526930208011};\\\", \\\"{x:1344,y:948,t:1526930208019};\\\", \\\"{x:1344,y:947,t:1526930208031};\\\", \\\"{x:1346,y:945,t:1526930208047};\\\", \\\"{x:1347,y:943,t:1526930208063};\\\", \\\"{x:1350,y:937,t:1526930208080};\\\", \\\"{x:1352,y:932,t:1526930208097};\\\", \\\"{x:1358,y:921,t:1526930208113};\\\", \\\"{x:1366,y:908,t:1526930208131};\\\", \\\"{x:1371,y:900,t:1526930208147};\\\", \\\"{x:1375,y:894,t:1526930208164};\\\", \\\"{x:1383,y:886,t:1526930208180};\\\", \\\"{x:1387,y:879,t:1526930208198};\\\", \\\"{x:1394,y:871,t:1526930208213};\\\", \\\"{x:1400,y:863,t:1526930208231};\\\", \\\"{x:1407,y:851,t:1526930208247};\\\", \\\"{x:1414,y:837,t:1526930208264};\\\", \\\"{x:1420,y:825,t:1526930208280};\\\", \\\"{x:1427,y:812,t:1526930208297};\\\", \\\"{x:1436,y:794,t:1526930208313};\\\", \\\"{x:1451,y:765,t:1526930208331};\\\", \\\"{x:1461,y:744,t:1526930208348};\\\", \\\"{x:1471,y:725,t:1526930208365};\\\", \\\"{x:1482,y:706,t:1526930208381};\\\", \\\"{x:1492,y:684,t:1526930208398};\\\", \\\"{x:1497,y:668,t:1526930208414};\\\", \\\"{x:1505,y:652,t:1526930208431};\\\", \\\"{x:1515,y:636,t:1526930208447};\\\", \\\"{x:1521,y:625,t:1526930208464};\\\", \\\"{x:1530,y:612,t:1526930208480};\\\", \\\"{x:1534,y:605,t:1526930208497};\\\", \\\"{x:1543,y:592,t:1526930208515};\\\", \\\"{x:1553,y:580,t:1526930208531};\\\", \\\"{x:1561,y:566,t:1526930208548};\\\", \\\"{x:1574,y:548,t:1526930208564};\\\", \\\"{x:1588,y:533,t:1526930208580};\\\", \\\"{x:1602,y:515,t:1526930208598};\\\", \\\"{x:1619,y:496,t:1526930208615};\\\", \\\"{x:1630,y:479,t:1526930208631};\\\", \\\"{x:1637,y:464,t:1526930208648};\\\", \\\"{x:1644,y:450,t:1526930208665};\\\", \\\"{x:1649,y:436,t:1526930208680};\\\", \\\"{x:1651,y:429,t:1526930208697};\\\", \\\"{x:1650,y:423,t:1526930208714};\\\", \\\"{x:1643,y:423,t:1526930208731};\\\", \\\"{x:1611,y:423,t:1526930208748};\\\", \\\"{x:1521,y:430,t:1526930208765};\\\", \\\"{x:1393,y:449,t:1526930208781};\\\", \\\"{x:1241,y:469,t:1526930208797};\\\", \\\"{x:1066,y:480,t:1526930208815};\\\", \\\"{x:900,y:484,t:1526930208831};\\\", \\\"{x:749,y:490,t:1526930208849};\\\", \\\"{x:631,y:505,t:1526930208864};\\\", \\\"{x:511,y:510,t:1526930208897};\\\", \\\"{x:486,y:517,t:1526930208914};\\\", \\\"{x:479,y:524,t:1526930208930};\\\", \\\"{x:475,y:533,t:1526930208948};\\\", \\\"{x:475,y:536,t:1526930208964};\\\", \\\"{x:475,y:537,t:1526930208981};\\\", \\\"{x:475,y:539,t:1526930208998};\\\", \\\"{x:476,y:544,t:1526930209013};\\\", \\\"{x:487,y:550,t:1526930209031};\\\", \\\"{x:503,y:559,t:1526930209049};\\\", \\\"{x:527,y:562,t:1526930209064};\\\", \\\"{x:549,y:565,t:1526930209081};\\\", \\\"{x:567,y:565,t:1526930209097};\\\", \\\"{x:585,y:564,t:1526930209113};\\\", \\\"{x:595,y:558,t:1526930209131};\\\", \\\"{x:603,y:549,t:1526930209148};\\\", \\\"{x:620,y:538,t:1526930209164};\\\", \\\"{x:636,y:526,t:1526930209181};\\\", \\\"{x:647,y:517,t:1526930209198};\\\", \\\"{x:654,y:513,t:1526930209214};\\\", \\\"{x:655,y:510,t:1526930209230};\\\", \\\"{x:656,y:509,t:1526930209248};\\\", \\\"{x:656,y:508,t:1526930209299};\\\", \\\"{x:658,y:507,t:1526930209314};\\\", \\\"{x:668,y:503,t:1526930209331};\\\", \\\"{x:690,y:500,t:1526930209348};\\\", \\\"{x:727,y:496,t:1526930209366};\\\", \\\"{x:773,y:489,t:1526930209381};\\\", \\\"{x:804,y:484,t:1526930209399};\\\", \\\"{x:821,y:481,t:1526930209413};\\\", \\\"{x:829,y:478,t:1526930209431};\\\", \\\"{x:830,y:477,t:1526930209466};\\\", \\\"{x:830,y:479,t:1526930209523};\\\", \\\"{x:827,y:483,t:1526930209531};\\\", \\\"{x:804,y:492,t:1526930209549};\\\", \\\"{x:748,y:505,t:1526930209564};\\\", \\\"{x:664,y:518,t:1526930209582};\\\", \\\"{x:559,y:532,t:1526930209599};\\\", \\\"{x:475,y:543,t:1526930209617};\\\", \\\"{x:441,y:546,t:1526930209631};\\\", \\\"{x:434,y:546,t:1526930209648};\\\", \\\"{x:433,y:546,t:1526930209665};\\\", \\\"{x:432,y:546,t:1526930209706};\\\", \\\"{x:430,y:546,t:1526930209714};\\\", \\\"{x:426,y:547,t:1526930209730};\\\", \\\"{x:421,y:547,t:1526930209748};\\\", \\\"{x:419,y:547,t:1526930209765};\\\", \\\"{x:418,y:547,t:1526930209802};\\\", \\\"{x:416,y:547,t:1526930209818};\\\", \\\"{x:413,y:547,t:1526930209831};\\\", \\\"{x:407,y:546,t:1526930209848};\\\", \\\"{x:404,y:545,t:1526930209865};\\\", \\\"{x:402,y:545,t:1526930209881};\\\", \\\"{x:402,y:546,t:1526930210105};\\\", \\\"{x:404,y:552,t:1526930210115};\\\", \\\"{x:406,y:561,t:1526930210132};\\\", \\\"{x:406,y:570,t:1526930210148};\\\", \\\"{x:406,y:576,t:1526930210165};\\\", \\\"{x:406,y:581,t:1526930210182};\\\", \\\"{x:406,y:587,t:1526930210197};\\\", \\\"{x:405,y:593,t:1526930210216};\\\", \\\"{x:404,y:600,t:1526930210232};\\\", \\\"{x:400,y:607,t:1526930210248};\\\", \\\"{x:398,y:613,t:1526930210265};\\\", \\\"{x:396,y:615,t:1526930210282};\\\", \\\"{x:395,y:617,t:1526930210298};\\\", \\\"{x:395,y:619,t:1526930210315};\\\", \\\"{x:395,y:620,t:1526930210332};\\\", \\\"{x:394,y:622,t:1526930210348};\\\", \\\"{x:394,y:623,t:1526930210385};\\\", \\\"{x:394,y:625,t:1526930210546};\\\", \\\"{x:400,y:627,t:1526930210554};\\\", \\\"{x:406,y:632,t:1526930210565};\\\", \\\"{x:419,y:641,t:1526930210582};\\\", \\\"{x:433,y:648,t:1526930210599};\\\", \\\"{x:439,y:654,t:1526930210615};\\\", \\\"{x:441,y:656,t:1526930210632};\\\", \\\"{x:444,y:662,t:1526930210649};\\\", \\\"{x:451,y:673,t:1526930210665};\\\", \\\"{x:459,y:687,t:1526930210682};\\\", \\\"{x:465,y:695,t:1526930210699};\\\", \\\"{x:469,y:704,t:1526930210715};\\\", \\\"{x:471,y:709,t:1526930210732};\\\", \\\"{x:473,y:713,t:1526930210749};\\\", \\\"{x:476,y:719,t:1526930210765};\\\", \\\"{x:480,y:726,t:1526930210783};\\\", \\\"{x:482,y:730,t:1526930210799};\\\", \\\"{x:482,y:732,t:1526930210815};\\\", \\\"{x:483,y:732,t:1526930210832};\\\", \\\"{x:483,y:734,t:1526930210849};\\\", \\\"{x:484,y:734,t:1526930211042};\\\", \\\"{x:487,y:734,t:1526930211049};\\\", \\\"{x:503,y:734,t:1526930211066};\\\", \\\"{x:533,y:734,t:1526930211082};\\\", \\\"{x:577,y:734,t:1526930211099};\\\", \\\"{x:628,y:734,t:1526930211116};\\\", \\\"{x:670,y:734,t:1526930211131};\\\", \\\"{x:712,y:734,t:1526930211149};\\\", \\\"{x:741,y:734,t:1526930211166};\\\", \\\"{x:757,y:734,t:1526930211182};\\\", \\\"{x:761,y:734,t:1526930211199};\\\", \\\"{x:762,y:734,t:1526930211216};\\\", \\\"{x:762,y:735,t:1526930211443};\\\", \\\"{x:762,y:736,t:1526930211458};\\\", \\\"{x:762,y:737,t:1526930211474};\\\", \\\"{x:762,y:738,t:1526930211499};\\\", \\\"{x:762,y:739,t:1526930211538};\\\" ] }, { \\\"rt\\\": 7287, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 582415, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:763,y:738,t:1526930212946};\\\", \\\"{x:764,y:737,t:1526930212953};\\\", \\\"{x:765,y:737,t:1526930212967};\\\", \\\"{x:766,y:737,t:1526930212986};\\\", \\\"{x:767,y:737,t:1526930214267};\\\", \\\"{x:768,y:737,t:1526930214274};\\\", \\\"{x:769,y:737,t:1526930214285};\\\", \\\"{x:771,y:735,t:1526930214301};\\\", \\\"{x:775,y:733,t:1526930214318};\\\", \\\"{x:778,y:733,t:1526930214335};\\\", \\\"{x:790,y:733,t:1526930214351};\\\", \\\"{x:797,y:735,t:1526930214369};\\\", \\\"{x:807,y:735,t:1526930214386};\\\", \\\"{x:814,y:736,t:1526930214401};\\\", \\\"{x:826,y:741,t:1526930214418};\\\", \\\"{x:830,y:742,t:1526930214436};\\\", \\\"{x:841,y:745,t:1526930214451};\\\", \\\"{x:851,y:747,t:1526930214469};\\\", \\\"{x:863,y:749,t:1526930214486};\\\", \\\"{x:873,y:750,t:1526930214502};\\\", \\\"{x:886,y:753,t:1526930214519};\\\", \\\"{x:898,y:753,t:1526930214535};\\\", \\\"{x:912,y:753,t:1526930214552};\\\", \\\"{x:933,y:752,t:1526930214568};\\\", \\\"{x:951,y:749,t:1526930214586};\\\", \\\"{x:971,y:747,t:1526930214602};\\\", \\\"{x:991,y:744,t:1526930214619};\\\", \\\"{x:1007,y:743,t:1526930214636};\\\", \\\"{x:1025,y:741,t:1526930214653};\\\", \\\"{x:1043,y:741,t:1526930214669};\\\", \\\"{x:1064,y:741,t:1526930214685};\\\", \\\"{x:1087,y:741,t:1526930214703};\\\", \\\"{x:1115,y:741,t:1526930214719};\\\", \\\"{x:1151,y:741,t:1526930214736};\\\", \\\"{x:1199,y:733,t:1526930214753};\\\", \\\"{x:1253,y:726,t:1526930214769};\\\", \\\"{x:1313,y:719,t:1526930214785};\\\", \\\"{x:1413,y:704,t:1526930214804};\\\", \\\"{x:1500,y:700,t:1526930214819};\\\", \\\"{x:1561,y:700,t:1526930214836};\\\", \\\"{x:1589,y:700,t:1526930214853};\\\", \\\"{x:1607,y:697,t:1526930214869};\\\", \\\"{x:1625,y:693,t:1526930214886};\\\", \\\"{x:1643,y:688,t:1526930214902};\\\", \\\"{x:1650,y:689,t:1526930214919};\\\", \\\"{x:1651,y:689,t:1526930214936};\\\", \\\"{x:1652,y:688,t:1526930214953};\\\", \\\"{x:1653,y:688,t:1526930214971};\\\", \\\"{x:1653,y:687,t:1526930214995};\\\", \\\"{x:1653,y:686,t:1526930215004};\\\", \\\"{x:1648,y:683,t:1526930215018};\\\", \\\"{x:1642,y:683,t:1526930215036};\\\", \\\"{x:1624,y:677,t:1526930215053};\\\", \\\"{x:1607,y:672,t:1526930215069};\\\", \\\"{x:1588,y:669,t:1526930215086};\\\", \\\"{x:1569,y:667,t:1526930215102};\\\", \\\"{x:1544,y:663,t:1526930215119};\\\", \\\"{x:1521,y:663,t:1526930215136};\\\", \\\"{x:1498,y:663,t:1526930215153};\\\", \\\"{x:1471,y:663,t:1526930215170};\\\", \\\"{x:1459,y:663,t:1526930215186};\\\", \\\"{x:1453,y:663,t:1526930215204};\\\", \\\"{x:1452,y:663,t:1526930215220};\\\", \\\"{x:1449,y:665,t:1526930215236};\\\", \\\"{x:1444,y:668,t:1526930215253};\\\", \\\"{x:1437,y:671,t:1526930215270};\\\", \\\"{x:1427,y:675,t:1526930215286};\\\", \\\"{x:1406,y:681,t:1526930215303};\\\", \\\"{x:1381,y:683,t:1526930215320};\\\", \\\"{x:1356,y:688,t:1526930215336};\\\", \\\"{x:1331,y:692,t:1526930215353};\\\", \\\"{x:1321,y:693,t:1526930215370};\\\", \\\"{x:1310,y:694,t:1526930215386};\\\", \\\"{x:1302,y:694,t:1526930215404};\\\", \\\"{x:1301,y:694,t:1526930215419};\\\", \\\"{x:1301,y:695,t:1526930215516};\\\", \\\"{x:1303,y:696,t:1526930215523};\\\", \\\"{x:1304,y:696,t:1526930215539};\\\", \\\"{x:1307,y:696,t:1526930215552};\\\", \\\"{x:1315,y:696,t:1526930215570};\\\", \\\"{x:1320,y:696,t:1526930215586};\\\", \\\"{x:1323,y:696,t:1526930215604};\\\", \\\"{x:1324,y:696,t:1526930215620};\\\", \\\"{x:1326,y:696,t:1526930215787};\\\", \\\"{x:1330,y:696,t:1526930215804};\\\", \\\"{x:1331,y:696,t:1526930215820};\\\", \\\"{x:1332,y:696,t:1526930215837};\\\", \\\"{x:1333,y:696,t:1526930215923};\\\", \\\"{x:1335,y:696,t:1526930215938};\\\", \\\"{x:1336,y:696,t:1526930215953};\\\", \\\"{x:1339,y:695,t:1526930215970};\\\", \\\"{x:1341,y:693,t:1526930215987};\\\", \\\"{x:1342,y:693,t:1526930216004};\\\", \\\"{x:1343,y:691,t:1526930216940};\\\", \\\"{x:1344,y:689,t:1526930216954};\\\", \\\"{x:1346,y:684,t:1526930216971};\\\", \\\"{x:1348,y:679,t:1526930216986};\\\", \\\"{x:1350,y:675,t:1526930217005};\\\", \\\"{x:1351,y:670,t:1526930217020};\\\", \\\"{x:1355,y:663,t:1526930217038};\\\", \\\"{x:1356,y:658,t:1526930217053};\\\", \\\"{x:1360,y:651,t:1526930217070};\\\", \\\"{x:1362,y:646,t:1526930217087};\\\", \\\"{x:1364,y:641,t:1526930217103};\\\", \\\"{x:1366,y:635,t:1526930217120};\\\", \\\"{x:1368,y:629,t:1526930217137};\\\", \\\"{x:1371,y:625,t:1526930217153};\\\", \\\"{x:1374,y:619,t:1526930217170};\\\", \\\"{x:1375,y:617,t:1526930217188};\\\", \\\"{x:1377,y:614,t:1526930217203};\\\", \\\"{x:1378,y:612,t:1526930217221};\\\", \\\"{x:1381,y:607,t:1526930217237};\\\", \\\"{x:1384,y:603,t:1526930217254};\\\", \\\"{x:1386,y:600,t:1526930217271};\\\", \\\"{x:1390,y:595,t:1526930217288};\\\", \\\"{x:1392,y:591,t:1526930217303};\\\", \\\"{x:1395,y:587,t:1526930217320};\\\", \\\"{x:1398,y:584,t:1526930217337};\\\", \\\"{x:1402,y:578,t:1526930217354};\\\", \\\"{x:1410,y:568,t:1526930217371};\\\", \\\"{x:1413,y:563,t:1526930217390};\\\", \\\"{x:1414,y:559,t:1526930217403};\\\", \\\"{x:1417,y:555,t:1526930217421};\\\", \\\"{x:1417,y:554,t:1526930217437};\\\", \\\"{x:1418,y:553,t:1526930217453};\\\", \\\"{x:1410,y:557,t:1526930217987};\\\", \\\"{x:1361,y:571,t:1526930218005};\\\", \\\"{x:1258,y:587,t:1526930218022};\\\", \\\"{x:1117,y:606,t:1526930218038};\\\", \\\"{x:976,y:625,t:1526930218055};\\\", \\\"{x:852,y:640,t:1526930218071};\\\", \\\"{x:752,y:644,t:1526930218087};\\\", \\\"{x:712,y:644,t:1526930218104};\\\", \\\"{x:700,y:644,t:1526930218122};\\\", \\\"{x:698,y:644,t:1526930218137};\\\", \\\"{x:697,y:644,t:1526930218155};\\\", \\\"{x:695,y:644,t:1526930218211};\\\", \\\"{x:693,y:643,t:1526930218222};\\\", \\\"{x:682,y:637,t:1526930218238};\\\", \\\"{x:668,y:628,t:1526930218257};\\\", \\\"{x:644,y:613,t:1526930218271};\\\", \\\"{x:625,y:599,t:1526930218287};\\\", \\\"{x:611,y:591,t:1526930218305};\\\", \\\"{x:604,y:584,t:1526930218322};\\\", \\\"{x:591,y:575,t:1526930218338};\\\", \\\"{x:589,y:573,t:1526930218355};\\\", \\\"{x:587,y:572,t:1526930218371};\\\", \\\"{x:585,y:571,t:1526930218388};\\\", \\\"{x:582,y:571,t:1526930218404};\\\", \\\"{x:584,y:568,t:1526930218466};\\\", \\\"{x:599,y:566,t:1526930218474};\\\", \\\"{x:631,y:563,t:1526930218488};\\\", \\\"{x:723,y:551,t:1526930218505};\\\", \\\"{x:812,y:534,t:1526930218522};\\\", \\\"{x:866,y:526,t:1526930218538};\\\", \\\"{x:874,y:525,t:1526930218555};\\\", \\\"{x:876,y:525,t:1526930218571};\\\", \\\"{x:872,y:525,t:1526930218682};\\\", \\\"{x:870,y:526,t:1526930218691};\\\", \\\"{x:866,y:527,t:1526930218706};\\\", \\\"{x:847,y:533,t:1526930218723};\\\", \\\"{x:840,y:535,t:1526930218739};\\\", \\\"{x:839,y:536,t:1526930218755};\\\", \\\"{x:837,y:536,t:1526930218778};\\\", \\\"{x:836,y:536,t:1526930218842};\\\", \\\"{x:835,y:538,t:1526930218970};\\\", \\\"{x:830,y:547,t:1526930218978};\\\", \\\"{x:824,y:555,t:1526930218988};\\\", \\\"{x:798,y:576,t:1526930219006};\\\", \\\"{x:755,y:606,t:1526930219023};\\\", \\\"{x:700,y:629,t:1526930219038};\\\", \\\"{x:658,y:650,t:1526930219055};\\\", \\\"{x:624,y:665,t:1526930219072};\\\", \\\"{x:596,y:678,t:1526930219088};\\\", \\\"{x:581,y:688,t:1526930219105};\\\", \\\"{x:573,y:695,t:1526930219121};\\\", \\\"{x:569,y:701,t:1526930219138};\\\", \\\"{x:565,y:709,t:1526930219155};\\\", \\\"{x:560,y:716,t:1526930219172};\\\", \\\"{x:557,y:719,t:1526930219189};\\\", \\\"{x:557,y:720,t:1526930219259};\\\", \\\"{x:556,y:721,t:1526930219274};\\\", \\\"{x:556,y:722,t:1526930219290};\\\", \\\"{x:555,y:724,t:1526930219305};\\\", \\\"{x:552,y:728,t:1526930219323};\\\", \\\"{x:547,y:733,t:1526930219339};\\\", \\\"{x:545,y:735,t:1526930219355};\\\", \\\"{x:544,y:736,t:1526930219372};\\\", \\\"{x:542,y:736,t:1526930219426};\\\", \\\"{x:544,y:736,t:1526930219570};\\\", \\\"{x:548,y:738,t:1526930219577};\\\", \\\"{x:555,y:739,t:1526930219589};\\\", \\\"{x:581,y:741,t:1526930219606};\\\", \\\"{x:622,y:743,t:1526930219622};\\\", \\\"{x:689,y:743,t:1526930219639};\\\", \\\"{x:764,y:743,t:1526930219656};\\\", \\\"{x:838,y:747,t:1526930219673};\\\", \\\"{x:887,y:751,t:1526930219689};\\\", \\\"{x:934,y:759,t:1526930219706};\\\", \\\"{x:957,y:761,t:1526930219722};\\\", \\\"{x:974,y:765,t:1526930219739};\\\", \\\"{x:985,y:768,t:1526930219756};\\\", \\\"{x:992,y:770,t:1526930219772};\\\", \\\"{x:998,y:772,t:1526930219789};\\\", \\\"{x:1002,y:774,t:1526930219807};\\\", \\\"{x:1005,y:776,t:1526930219822};\\\", \\\"{x:1007,y:777,t:1526930219840};\\\", \\\"{x:1007,y:778,t:1526930219857};\\\" ] }, { \\\"rt\\\": 23251, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 606940, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-F -Z -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1014,y:778,t:1526930222828};\\\", \\\"{x:1030,y:769,t:1526930222842};\\\", \\\"{x:1042,y:764,t:1526930222858};\\\", \\\"{x:1046,y:762,t:1526930222875};\\\", \\\"{x:1049,y:761,t:1526930222891};\\\", \\\"{x:1054,y:760,t:1526930222908};\\\", \\\"{x:1063,y:756,t:1526930222925};\\\", \\\"{x:1077,y:752,t:1526930222942};\\\", \\\"{x:1097,y:747,t:1526930222958};\\\", \\\"{x:1115,y:744,t:1526930222976};\\\", \\\"{x:1128,y:740,t:1526930222991};\\\", \\\"{x:1141,y:738,t:1526930223009};\\\", \\\"{x:1165,y:731,t:1526930223026};\\\", \\\"{x:1177,y:731,t:1526930223042};\\\", \\\"{x:1247,y:727,t:1526930223059};\\\", \\\"{x:1323,y:724,t:1526930223076};\\\", \\\"{x:1395,y:722,t:1526930223092};\\\", \\\"{x:1442,y:724,t:1526930223109};\\\", \\\"{x:1464,y:726,t:1526930223126};\\\", \\\"{x:1471,y:727,t:1526930223142};\\\", \\\"{x:1473,y:728,t:1526930223159};\\\", \\\"{x:1474,y:728,t:1526930223187};\\\", \\\"{x:1475,y:728,t:1526930223195};\\\", \\\"{x:1476,y:728,t:1526930223209};\\\", \\\"{x:1479,y:729,t:1526930223226};\\\", \\\"{x:1480,y:729,t:1526930223242};\\\", \\\"{x:1481,y:729,t:1526930223259};\\\", \\\"{x:1482,y:732,t:1526930225411};\\\", \\\"{x:1483,y:735,t:1526930225428};\\\", \\\"{x:1484,y:738,t:1526930225444};\\\", \\\"{x:1484,y:742,t:1526930225462};\\\", \\\"{x:1484,y:744,t:1526930225477};\\\", \\\"{x:1484,y:747,t:1526930225494};\\\", \\\"{x:1484,y:749,t:1526930225511};\\\", \\\"{x:1484,y:750,t:1526930225527};\\\", \\\"{x:1483,y:752,t:1526930225544};\\\", \\\"{x:1482,y:753,t:1526930225561};\\\", \\\"{x:1479,y:754,t:1526930225577};\\\", \\\"{x:1477,y:755,t:1526930225594};\\\", \\\"{x:1471,y:755,t:1526930225611};\\\", \\\"{x:1467,y:757,t:1526930225628};\\\", \\\"{x:1464,y:758,t:1526930225644};\\\", \\\"{x:1459,y:758,t:1526930225662};\\\", \\\"{x:1457,y:758,t:1526930225677};\\\", \\\"{x:1456,y:758,t:1526930225694};\\\", \\\"{x:1455,y:758,t:1526930225723};\\\", \\\"{x:1454,y:758,t:1526930225730};\\\", \\\"{x:1451,y:758,t:1526930225745};\\\", \\\"{x:1442,y:752,t:1526930225761};\\\", \\\"{x:1427,y:740,t:1526930225778};\\\", \\\"{x:1416,y:732,t:1526930225794};\\\", \\\"{x:1409,y:726,t:1526930225811};\\\", \\\"{x:1399,y:717,t:1526930225828};\\\", \\\"{x:1389,y:708,t:1526930225844};\\\", \\\"{x:1381,y:702,t:1526930225861};\\\", \\\"{x:1370,y:697,t:1526930225879};\\\", \\\"{x:1361,y:697,t:1526930225894};\\\", \\\"{x:1353,y:695,t:1526930225914};\\\", \\\"{x:1343,y:695,t:1526930225927};\\\", \\\"{x:1327,y:695,t:1526930225944};\\\", \\\"{x:1312,y:696,t:1526930225961};\\\", \\\"{x:1281,y:706,t:1526930225977};\\\", \\\"{x:1265,y:712,t:1526930225993};\\\", \\\"{x:1256,y:718,t:1526930226010};\\\", \\\"{x:1250,y:723,t:1526930226028};\\\", \\\"{x:1246,y:729,t:1526930226044};\\\", \\\"{x:1242,y:734,t:1526930226060};\\\", \\\"{x:1238,y:741,t:1526930226078};\\\", \\\"{x:1230,y:752,t:1526930226094};\\\", \\\"{x:1221,y:762,t:1526930226111};\\\", \\\"{x:1211,y:775,t:1526930226127};\\\", \\\"{x:1206,y:783,t:1526930226144};\\\", \\\"{x:1204,y:787,t:1526930226160};\\\", \\\"{x:1201,y:794,t:1526930226177};\\\", \\\"{x:1199,y:799,t:1526930226194};\\\", \\\"{x:1197,y:803,t:1526930226211};\\\", \\\"{x:1197,y:805,t:1526930226227};\\\", \\\"{x:1197,y:806,t:1526930226244};\\\", \\\"{x:1197,y:807,t:1526930226260};\\\", \\\"{x:1197,y:808,t:1526930226305};\\\", \\\"{x:1199,y:808,t:1526930226314};\\\", \\\"{x:1201,y:808,t:1526930226327};\\\", \\\"{x:1212,y:809,t:1526930226344};\\\", \\\"{x:1234,y:811,t:1526930226360};\\\", \\\"{x:1291,y:812,t:1526930226378};\\\", \\\"{x:1333,y:812,t:1526930226395};\\\", \\\"{x:1361,y:813,t:1526930226411};\\\", \\\"{x:1384,y:817,t:1526930226427};\\\", \\\"{x:1395,y:821,t:1526930226445};\\\", \\\"{x:1400,y:824,t:1526930226461};\\\", \\\"{x:1401,y:826,t:1526930226478};\\\", \\\"{x:1403,y:829,t:1526930226495};\\\", \\\"{x:1405,y:838,t:1526930226511};\\\", \\\"{x:1407,y:846,t:1526930226527};\\\", \\\"{x:1410,y:851,t:1526930226545};\\\", \\\"{x:1410,y:853,t:1526930226561};\\\", \\\"{x:1410,y:862,t:1526930226578};\\\", \\\"{x:1409,y:867,t:1526930226595};\\\", \\\"{x:1406,y:870,t:1526930226611};\\\", \\\"{x:1404,y:873,t:1526930226628};\\\", \\\"{x:1403,y:875,t:1526930226645};\\\", \\\"{x:1403,y:876,t:1526930226723};\\\", \\\"{x:1406,y:876,t:1526930226787};\\\", \\\"{x:1410,y:875,t:1526930226795};\\\", \\\"{x:1422,y:869,t:1526930226812};\\\", \\\"{x:1445,y:859,t:1526930226828};\\\", \\\"{x:1472,y:847,t:1526930226845};\\\", \\\"{x:1501,y:835,t:1526930226861};\\\", \\\"{x:1527,y:828,t:1526930226877};\\\", \\\"{x:1547,y:822,t:1526930226894};\\\", \\\"{x:1561,y:817,t:1526930226911};\\\", \\\"{x:1574,y:813,t:1526930226928};\\\", \\\"{x:1594,y:808,t:1526930226945};\\\", \\\"{x:1627,y:804,t:1526930226962};\\\", \\\"{x:1642,y:803,t:1526930226978};\\\", \\\"{x:1651,y:802,t:1526930226995};\\\", \\\"{x:1654,y:802,t:1526930227012};\\\", \\\"{x:1658,y:802,t:1526930227028};\\\", \\\"{x:1665,y:802,t:1526930227045};\\\", \\\"{x:1675,y:802,t:1526930227062};\\\", \\\"{x:1686,y:801,t:1526930227078};\\\", \\\"{x:1691,y:799,t:1526930227095};\\\", \\\"{x:1692,y:799,t:1526930227112};\\\", \\\"{x:1692,y:798,t:1526930227227};\\\", \\\"{x:1692,y:797,t:1526930227242};\\\", \\\"{x:1692,y:796,t:1526930227251};\\\", \\\"{x:1692,y:794,t:1526930227262};\\\", \\\"{x:1692,y:792,t:1526930227279};\\\", \\\"{x:1692,y:786,t:1526930227295};\\\", \\\"{x:1690,y:773,t:1526930227312};\\\", \\\"{x:1686,y:763,t:1526930227330};\\\", \\\"{x:1686,y:760,t:1526930227345};\\\", \\\"{x:1684,y:756,t:1526930227363};\\\", \\\"{x:1684,y:755,t:1526930227387};\\\", \\\"{x:1683,y:754,t:1526930227396};\\\", \\\"{x:1683,y:753,t:1526930227413};\\\", \\\"{x:1682,y:751,t:1526930227429};\\\", \\\"{x:1680,y:749,t:1526930227445};\\\", \\\"{x:1680,y:747,t:1526930227462};\\\", \\\"{x:1679,y:746,t:1526930227479};\\\", \\\"{x:1677,y:743,t:1526930227495};\\\", \\\"{x:1676,y:741,t:1526930227512};\\\", \\\"{x:1673,y:737,t:1526930227529};\\\", \\\"{x:1669,y:732,t:1526930227546};\\\", \\\"{x:1666,y:724,t:1526930227563};\\\", \\\"{x:1661,y:719,t:1526930227579};\\\", \\\"{x:1657,y:715,t:1526930227597};\\\", \\\"{x:1653,y:712,t:1526930227612};\\\", \\\"{x:1652,y:711,t:1526930227629};\\\", \\\"{x:1651,y:711,t:1526930227646};\\\", \\\"{x:1650,y:711,t:1526930227663};\\\", \\\"{x:1648,y:710,t:1526930227680};\\\", \\\"{x:1645,y:708,t:1526930227696};\\\", \\\"{x:1644,y:707,t:1526930227712};\\\", \\\"{x:1643,y:707,t:1526930227763};\\\", \\\"{x:1641,y:707,t:1526930227779};\\\", \\\"{x:1640,y:706,t:1526930227796};\\\", \\\"{x:1640,y:705,t:1526930227835};\\\", \\\"{x:1639,y:705,t:1526930227846};\\\", \\\"{x:1638,y:705,t:1526930227862};\\\", \\\"{x:1635,y:704,t:1526930227880};\\\", \\\"{x:1634,y:704,t:1526930227897};\\\", \\\"{x:1633,y:704,t:1526930227914};\\\", \\\"{x:1631,y:702,t:1526930227954};\\\", \\\"{x:1629,y:702,t:1526930227979};\\\", \\\"{x:1629,y:701,t:1526930227996};\\\", \\\"{x:1628,y:701,t:1526930228012};\\\", \\\"{x:1626,y:701,t:1526930228030};\\\", \\\"{x:1625,y:701,t:1526930228058};\\\", \\\"{x:1623,y:701,t:1526930228090};\\\", \\\"{x:1622,y:700,t:1526930228106};\\\", \\\"{x:1621,y:699,t:1526930228122};\\\", \\\"{x:1620,y:699,t:1526930228163};\\\", \\\"{x:1619,y:699,t:1526930228180};\\\", \\\"{x:1618,y:699,t:1526930228218};\\\", \\\"{x:1618,y:698,t:1526930228234};\\\", \\\"{x:1617,y:698,t:1526930228266};\\\", \\\"{x:1616,y:698,t:1526930233355};\\\", \\\"{x:1615,y:699,t:1526930233366};\\\", \\\"{x:1613,y:702,t:1526930233383};\\\", \\\"{x:1609,y:708,t:1526930233401};\\\", \\\"{x:1607,y:711,t:1526930233416};\\\", \\\"{x:1606,y:712,t:1526930233434};\\\", \\\"{x:1605,y:714,t:1526930233450};\\\", \\\"{x:1604,y:715,t:1526930233474};\\\", \\\"{x:1604,y:716,t:1526930233491};\\\", \\\"{x:1603,y:717,t:1526930233500};\\\", \\\"{x:1601,y:718,t:1526930233517};\\\", \\\"{x:1599,y:721,t:1526930233534};\\\", \\\"{x:1596,y:724,t:1526930233552};\\\", \\\"{x:1594,y:727,t:1526930233567};\\\", \\\"{x:1593,y:729,t:1526930233584};\\\", \\\"{x:1591,y:731,t:1526930233600};\\\", \\\"{x:1590,y:734,t:1526930233617};\\\", \\\"{x:1588,y:736,t:1526930233634};\\\", \\\"{x:1585,y:740,t:1526930233651};\\\", \\\"{x:1584,y:742,t:1526930233666};\\\", \\\"{x:1583,y:744,t:1526930233683};\\\", \\\"{x:1581,y:747,t:1526930233701};\\\", \\\"{x:1579,y:751,t:1526930233717};\\\", \\\"{x:1577,y:755,t:1526930233734};\\\", \\\"{x:1574,y:760,t:1526930233753};\\\", \\\"{x:1571,y:764,t:1526930233766};\\\", \\\"{x:1570,y:768,t:1526930233783};\\\", \\\"{x:1567,y:771,t:1526930233800};\\\", \\\"{x:1566,y:774,t:1526930233817};\\\", \\\"{x:1565,y:776,t:1526930233832};\\\", \\\"{x:1564,y:779,t:1526930233849};\\\", \\\"{x:1563,y:781,t:1526930233867};\\\", \\\"{x:1561,y:785,t:1526930233883};\\\", \\\"{x:1559,y:789,t:1526930233900};\\\", \\\"{x:1555,y:794,t:1526930233917};\\\", \\\"{x:1553,y:798,t:1526930233933};\\\", \\\"{x:1551,y:803,t:1526930233951};\\\", \\\"{x:1547,y:809,t:1526930233967};\\\", \\\"{x:1544,y:813,t:1526930233983};\\\", \\\"{x:1544,y:817,t:1526930234000};\\\", \\\"{x:1541,y:824,t:1526930234017};\\\", \\\"{x:1539,y:827,t:1526930234033};\\\", \\\"{x:1536,y:836,t:1526930234049};\\\", \\\"{x:1533,y:842,t:1526930234067};\\\", \\\"{x:1531,y:849,t:1526930234083};\\\", \\\"{x:1528,y:859,t:1526930234101};\\\", \\\"{x:1524,y:868,t:1526930234118};\\\", \\\"{x:1522,y:871,t:1526930234133};\\\", \\\"{x:1519,y:878,t:1526930234151};\\\", \\\"{x:1518,y:883,t:1526930234167};\\\", \\\"{x:1515,y:889,t:1526930234183};\\\", \\\"{x:1514,y:895,t:1526930234201};\\\", \\\"{x:1510,y:902,t:1526930234218};\\\", \\\"{x:1507,y:907,t:1526930234233};\\\", \\\"{x:1504,y:914,t:1526930234250};\\\", \\\"{x:1503,y:916,t:1526930234268};\\\", \\\"{x:1502,y:918,t:1526930234283};\\\", \\\"{x:1501,y:921,t:1526930234300};\\\", \\\"{x:1499,y:924,t:1526930234317};\\\", \\\"{x:1499,y:926,t:1526930234334};\\\", \\\"{x:1496,y:929,t:1526930234352};\\\", \\\"{x:1495,y:931,t:1526930234370};\\\", \\\"{x:1495,y:932,t:1526930234385};\\\", \\\"{x:1493,y:935,t:1526930234400};\\\", \\\"{x:1492,y:936,t:1526930234418};\\\", \\\"{x:1491,y:938,t:1526930234435};\\\", \\\"{x:1490,y:940,t:1526930234451};\\\", \\\"{x:1488,y:942,t:1526930234468};\\\", \\\"{x:1484,y:946,t:1526930234484};\\\", \\\"{x:1483,y:947,t:1526930234501};\\\", \\\"{x:1483,y:948,t:1526930234517};\\\", \\\"{x:1482,y:949,t:1526930234534};\\\", \\\"{x:1482,y:950,t:1526930234587};\\\", \\\"{x:1481,y:952,t:1526930234602};\\\", \\\"{x:1480,y:953,t:1526930234626};\\\", \\\"{x:1479,y:954,t:1526930234650};\\\", \\\"{x:1479,y:955,t:1526930234691};\\\", \\\"{x:1478,y:956,t:1526930234714};\\\", \\\"{x:1477,y:957,t:1526930234739};\\\", \\\"{x:1477,y:958,t:1526930234795};\\\", \\\"{x:1476,y:959,t:1526930234810};\\\", \\\"{x:1476,y:960,t:1526930234907};\\\", \\\"{x:1475,y:960,t:1526930234947};\\\", \\\"{x:1474,y:961,t:1526930234971};\\\", \\\"{x:1474,y:962,t:1526930235010};\\\", \\\"{x:1474,y:963,t:1526930235387};\\\", \\\"{x:1474,y:964,t:1526930235763};\\\", \\\"{x:1475,y:964,t:1526930235786};\\\", \\\"{x:1475,y:965,t:1526930235827};\\\", \\\"{x:1475,y:966,t:1526930235859};\\\", \\\"{x:1475,y:967,t:1526930235907};\\\", \\\"{x:1476,y:966,t:1526930238302};\\\", \\\"{x:1477,y:965,t:1526930238317};\\\", \\\"{x:1478,y:963,t:1526930238326};\\\", \\\"{x:1481,y:962,t:1526930238340};\\\", \\\"{x:1482,y:961,t:1526930238357};\\\", \\\"{x:1485,y:959,t:1526930238374};\\\", \\\"{x:1486,y:958,t:1526930238389};\\\", \\\"{x:1486,y:957,t:1526930240270};\\\", \\\"{x:1486,y:955,t:1526930240542};\\\", \\\"{x:1451,y:932,t:1526930240558};\\\", \\\"{x:1380,y:893,t:1526930240574};\\\", \\\"{x:1285,y:840,t:1526930240591};\\\", \\\"{x:1163,y:787,t:1526930240608};\\\", \\\"{x:1034,y:733,t:1526930240624};\\\", \\\"{x:910,y:680,t:1526930240641};\\\", \\\"{x:775,y:623,t:1526930240659};\\\", \\\"{x:673,y:576,t:1526930240674};\\\", \\\"{x:589,y:533,t:1526930240692};\\\", \\\"{x:506,y:482,t:1526930240708};\\\", \\\"{x:478,y:458,t:1526930240726};\\\", \\\"{x:463,y:446,t:1526930240742};\\\", \\\"{x:459,y:439,t:1526930240759};\\\", \\\"{x:459,y:434,t:1526930240776};\\\", \\\"{x:459,y:430,t:1526930240792};\\\", \\\"{x:463,y:425,t:1526930240809};\\\", \\\"{x:473,y:420,t:1526930240826};\\\", \\\"{x:485,y:416,t:1526930240842};\\\", \\\"{x:503,y:413,t:1526930240859};\\\", \\\"{x:536,y:418,t:1526930240876};\\\", \\\"{x:549,y:421,t:1526930240892};\\\", \\\"{x:575,y:436,t:1526930240909};\\\", \\\"{x:587,y:448,t:1526930240927};\\\", \\\"{x:595,y:461,t:1526930240942};\\\", \\\"{x:604,y:474,t:1526930240959};\\\", \\\"{x:618,y:486,t:1526930240976};\\\", \\\"{x:635,y:495,t:1526930240993};\\\", \\\"{x:645,y:500,t:1526930241009};\\\", \\\"{x:648,y:500,t:1526930241026};\\\", \\\"{x:646,y:500,t:1526930241182};\\\", \\\"{x:642,y:500,t:1526930241194};\\\", \\\"{x:634,y:498,t:1526930241209};\\\", \\\"{x:629,y:497,t:1526930241225};\\\", \\\"{x:628,y:496,t:1526930241242};\\\", \\\"{x:626,y:496,t:1526930241259};\\\", \\\"{x:625,y:496,t:1526930241300};\\\", \\\"{x:623,y:496,t:1526930241316};\\\", \\\"{x:631,y:496,t:1526930241445};\\\", \\\"{x:648,y:496,t:1526930241460};\\\", \\\"{x:718,y:496,t:1526930241476};\\\", \\\"{x:760,y:496,t:1526930241494};\\\", \\\"{x:794,y:496,t:1526930241510};\\\", \\\"{x:807,y:494,t:1526930241526};\\\", \\\"{x:811,y:494,t:1526930241543};\\\", \\\"{x:812,y:493,t:1526930241565};\\\", \\\"{x:813,y:493,t:1526930241576};\\\", \\\"{x:816,y:492,t:1526930241594};\\\", \\\"{x:826,y:492,t:1526930241610};\\\", \\\"{x:839,y:492,t:1526930241626};\\\", \\\"{x:857,y:492,t:1526930241643};\\\", \\\"{x:880,y:492,t:1526930241661};\\\", \\\"{x:883,y:492,t:1526930241677};\\\", \\\"{x:882,y:491,t:1526930241780};\\\", \\\"{x:880,y:491,t:1526930241794};\\\", \\\"{x:872,y:491,t:1526930241810};\\\", \\\"{x:864,y:491,t:1526930241828};\\\", \\\"{x:858,y:492,t:1526930241843};\\\", \\\"{x:855,y:492,t:1526930241861};\\\", \\\"{x:854,y:492,t:1526930241876};\\\", \\\"{x:853,y:492,t:1526930241894};\\\", \\\"{x:851,y:493,t:1526930241910};\\\", \\\"{x:850,y:494,t:1526930242093};\\\", \\\"{x:849,y:495,t:1526930242108};\\\", \\\"{x:848,y:495,t:1526930242116};\\\", \\\"{x:848,y:496,t:1526930242132};\\\", \\\"{x:848,y:497,t:1526930242269};\\\", \\\"{x:847,y:498,t:1526930242285};\\\", \\\"{x:844,y:500,t:1526930243406};\\\", \\\"{x:837,y:510,t:1526930243413};\\\", \\\"{x:829,y:519,t:1526930243429};\\\", \\\"{x:804,y:542,t:1526930243445};\\\", \\\"{x:781,y:561,t:1526930243462};\\\", \\\"{x:763,y:577,t:1526930243479};\\\", \\\"{x:744,y:590,t:1526930243494};\\\", \\\"{x:726,y:601,t:1526930243511};\\\", \\\"{x:708,y:612,t:1526930243529};\\\", \\\"{x:693,y:619,t:1526930243544};\\\", \\\"{x:676,y:626,t:1526930243561};\\\", \\\"{x:647,y:636,t:1526930243578};\\\", \\\"{x:620,y:644,t:1526930243594};\\\", \\\"{x:593,y:652,t:1526930243611};\\\", \\\"{x:574,y:660,t:1526930243628};\\\", \\\"{x:558,y:669,t:1526930243644};\\\", \\\"{x:542,y:674,t:1526930243661};\\\", \\\"{x:534,y:677,t:1526930243678};\\\", \\\"{x:533,y:678,t:1526930243695};\\\", \\\"{x:532,y:679,t:1526930243716};\\\", \\\"{x:530,y:679,t:1526930243729};\\\", \\\"{x:527,y:681,t:1526930243746};\\\", \\\"{x:521,y:686,t:1526930243761};\\\", \\\"{x:515,y:691,t:1526930243778};\\\", \\\"{x:510,y:698,t:1526930243795};\\\", \\\"{x:506,y:704,t:1526930243812};\\\", \\\"{x:506,y:709,t:1526930243828};\\\", \\\"{x:506,y:712,t:1526930243845};\\\", \\\"{x:506,y:716,t:1526930243861};\\\", \\\"{x:506,y:719,t:1526930243878};\\\", \\\"{x:506,y:721,t:1526930243896};\\\", \\\"{x:506,y:723,t:1526930243912};\\\", \\\"{x:506,y:724,t:1526930243929};\\\", \\\"{x:506,y:725,t:1526930243957};\\\", \\\"{x:506,y:726,t:1526930244029};\\\", \\\"{x:506,y:726,t:1526930244064};\\\", \\\"{x:511,y:726,t:1526930244116};\\\", \\\"{x:518,y:724,t:1526930244128};\\\", \\\"{x:543,y:716,t:1526930244145};\\\", \\\"{x:595,y:711,t:1526930244162};\\\", \\\"{x:653,y:705,t:1526930244178};\\\", \\\"{x:700,y:698,t:1526930244195};\\\", \\\"{x:738,y:698,t:1526930244212};\\\", \\\"{x:753,y:698,t:1526930244228};\\\", \\\"{x:766,y:697,t:1526930244246};\\\", \\\"{x:771,y:697,t:1526930244262};\\\", \\\"{x:775,y:697,t:1526930244278};\\\", \\\"{x:779,y:697,t:1526930244295};\\\", \\\"{x:783,y:695,t:1526930244311};\\\", \\\"{x:790,y:695,t:1526930244329};\\\", \\\"{x:793,y:695,t:1526930244669};\\\", \\\"{x:794,y:695,t:1526930244709};\\\", \\\"{x:795,y:695,t:1526930244741};\\\", \\\"{x:796,y:695,t:1526930244749};\\\", \\\"{x:797,y:695,t:1526930244813};\\\", \\\"{x:798,y:695,t:1526930244844};\\\" ] }, { \\\"rt\\\": 6769, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 615041, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:799,y:693,t:1526930245374};\\\", \\\"{x:799,y:692,t:1526930245486};\\\", \\\"{x:800,y:692,t:1526930245500};\\\", \\\"{x:802,y:692,t:1526930246725};\\\", \\\"{x:808,y:692,t:1526930246733};\\\", \\\"{x:824,y:692,t:1526930246747};\\\", \\\"{x:847,y:692,t:1526930246763};\\\", \\\"{x:883,y:687,t:1526930246780};\\\", \\\"{x:913,y:681,t:1526930246797};\\\", \\\"{x:957,y:669,t:1526930246814};\\\", \\\"{x:1009,y:658,t:1526930246830};\\\", \\\"{x:1053,y:646,t:1526930246848};\\\", \\\"{x:1090,y:635,t:1526930246864};\\\", \\\"{x:1120,y:628,t:1526930246880};\\\", \\\"{x:1155,y:620,t:1526930246898};\\\", \\\"{x:1184,y:616,t:1526930246915};\\\", \\\"{x:1214,y:612,t:1526930246931};\\\", \\\"{x:1242,y:612,t:1526930246948};\\\", \\\"{x:1286,y:612,t:1526930246965};\\\", \\\"{x:1317,y:612,t:1526930246981};\\\", \\\"{x:1360,y:612,t:1526930246998};\\\", \\\"{x:1397,y:614,t:1526930247014};\\\", \\\"{x:1427,y:618,t:1526930247031};\\\", \\\"{x:1464,y:627,t:1526930247047};\\\", \\\"{x:1492,y:634,t:1526930247064};\\\", \\\"{x:1512,y:644,t:1526930247081};\\\", \\\"{x:1528,y:654,t:1526930247098};\\\", \\\"{x:1542,y:662,t:1526930247115};\\\", \\\"{x:1556,y:672,t:1526930247131};\\\", \\\"{x:1567,y:682,t:1526930247148};\\\", \\\"{x:1584,y:695,t:1526930247165};\\\", \\\"{x:1591,y:700,t:1526930247180};\\\", \\\"{x:1593,y:702,t:1526930247198};\\\", \\\"{x:1594,y:705,t:1526930247215};\\\", \\\"{x:1596,y:709,t:1526930247231};\\\", \\\"{x:1599,y:716,t:1526930247248};\\\", \\\"{x:1604,y:727,t:1526930247265};\\\", \\\"{x:1607,y:733,t:1526930247281};\\\", \\\"{x:1611,y:741,t:1526930247298};\\\", \\\"{x:1612,y:746,t:1526930247316};\\\", \\\"{x:1613,y:751,t:1526930247332};\\\", \\\"{x:1613,y:755,t:1526930247348};\\\", \\\"{x:1615,y:759,t:1526930247365};\\\", \\\"{x:1615,y:761,t:1526930247381};\\\", \\\"{x:1616,y:763,t:1526930247398};\\\", \\\"{x:1616,y:764,t:1526930247416};\\\", \\\"{x:1617,y:767,t:1526930247432};\\\", \\\"{x:1618,y:767,t:1526930247448};\\\", \\\"{x:1618,y:768,t:1526930247465};\\\", \\\"{x:1618,y:769,t:1526930247482};\\\", \\\"{x:1618,y:770,t:1526930247498};\\\", \\\"{x:1619,y:770,t:1526930247516};\\\", \\\"{x:1619,y:771,t:1526930247557};\\\", \\\"{x:1619,y:772,t:1526930247565};\\\", \\\"{x:1619,y:773,t:1526930247582};\\\", \\\"{x:1619,y:776,t:1526930247598};\\\", \\\"{x:1619,y:779,t:1526930247615};\\\", \\\"{x:1614,y:784,t:1526930247632};\\\", \\\"{x:1604,y:792,t:1526930247648};\\\", \\\"{x:1597,y:798,t:1526930247665};\\\", \\\"{x:1589,y:810,t:1526930247682};\\\", \\\"{x:1582,y:828,t:1526930247698};\\\", \\\"{x:1577,y:841,t:1526930247716};\\\", \\\"{x:1573,y:858,t:1526930247733};\\\", \\\"{x:1571,y:874,t:1526930247748};\\\", \\\"{x:1568,y:894,t:1526930247765};\\\", \\\"{x:1567,y:906,t:1526930247782};\\\", \\\"{x:1567,y:914,t:1526930247799};\\\", \\\"{x:1567,y:919,t:1526930247815};\\\", \\\"{x:1567,y:922,t:1526930247832};\\\", \\\"{x:1568,y:924,t:1526930247849};\\\", \\\"{x:1569,y:926,t:1526930247865};\\\", \\\"{x:1569,y:928,t:1526930247882};\\\", \\\"{x:1571,y:931,t:1526930247899};\\\", \\\"{x:1571,y:933,t:1526930247916};\\\", \\\"{x:1571,y:934,t:1526930247932};\\\", \\\"{x:1573,y:937,t:1526930247949};\\\", \\\"{x:1573,y:940,t:1526930247965};\\\", \\\"{x:1573,y:943,t:1526930247982};\\\", \\\"{x:1573,y:948,t:1526930247999};\\\", \\\"{x:1573,y:951,t:1526930248015};\\\", \\\"{x:1573,y:954,t:1526930248032};\\\", \\\"{x:1573,y:955,t:1526930248061};\\\", \\\"{x:1573,y:956,t:1526930248126};\\\", \\\"{x:1573,y:957,t:1526930248134};\\\", \\\"{x:1573,y:958,t:1526930248173};\\\", \\\"{x:1572,y:958,t:1526930248205};\\\", \\\"{x:1571,y:959,t:1526930248221};\\\", \\\"{x:1571,y:960,t:1526930248232};\\\", \\\"{x:1568,y:961,t:1526930248249};\\\", \\\"{x:1565,y:962,t:1526930248266};\\\", \\\"{x:1562,y:964,t:1526930248282};\\\", \\\"{x:1561,y:964,t:1526930248299};\\\", \\\"{x:1559,y:966,t:1526930248316};\\\", \\\"{x:1558,y:967,t:1526930248332};\\\", \\\"{x:1557,y:967,t:1526930248436};\\\", \\\"{x:1556,y:967,t:1526930248476};\\\", \\\"{x:1555,y:967,t:1526930248484};\\\", \\\"{x:1554,y:965,t:1526930248500};\\\", \\\"{x:1554,y:964,t:1526930248516};\\\", \\\"{x:1554,y:963,t:1526930248531};\\\", \\\"{x:1553,y:960,t:1526930248549};\\\", \\\"{x:1552,y:960,t:1526930248572};\\\", \\\"{x:1552,y:958,t:1526930248700};\\\", \\\"{x:1552,y:957,t:1526930248716};\\\", \\\"{x:1551,y:953,t:1526930248733};\\\", \\\"{x:1550,y:951,t:1526930248748};\\\", \\\"{x:1548,y:947,t:1526930248766};\\\", \\\"{x:1546,y:943,t:1526930248783};\\\", \\\"{x:1545,y:939,t:1526930248798};\\\", \\\"{x:1544,y:937,t:1526930248815};\\\", \\\"{x:1543,y:935,t:1526930248832};\\\", \\\"{x:1541,y:931,t:1526930248848};\\\", \\\"{x:1540,y:929,t:1526930248865};\\\", \\\"{x:1539,y:927,t:1526930248883};\\\", \\\"{x:1537,y:922,t:1526930248898};\\\", \\\"{x:1535,y:918,t:1526930248915};\\\", \\\"{x:1529,y:909,t:1526930248933};\\\", \\\"{x:1527,y:903,t:1526930248949};\\\", \\\"{x:1524,y:897,t:1526930248966};\\\", \\\"{x:1521,y:887,t:1526930248983};\\\", \\\"{x:1519,y:879,t:1526930248999};\\\", \\\"{x:1516,y:870,t:1526930249016};\\\", \\\"{x:1514,y:860,t:1526930249033};\\\", \\\"{x:1511,y:852,t:1526930249049};\\\", \\\"{x:1509,y:844,t:1526930249066};\\\", \\\"{x:1506,y:838,t:1526930249083};\\\", \\\"{x:1505,y:833,t:1526930249099};\\\", \\\"{x:1503,y:829,t:1526930249116};\\\", \\\"{x:1501,y:824,t:1526930249133};\\\", \\\"{x:1499,y:822,t:1526930249149};\\\", \\\"{x:1498,y:821,t:1526930249166};\\\", \\\"{x:1492,y:817,t:1526930249183};\\\", \\\"{x:1480,y:811,t:1526930249200};\\\", \\\"{x:1453,y:801,t:1526930249217};\\\", \\\"{x:1408,y:779,t:1526930249233};\\\", \\\"{x:1345,y:755,t:1526930249250};\\\", \\\"{x:1273,y:724,t:1526930249267};\\\", \\\"{x:1215,y:698,t:1526930249283};\\\", \\\"{x:1152,y:672,t:1526930249301};\\\", \\\"{x:1094,y:646,t:1526930249316};\\\", \\\"{x:1017,y:619,t:1526930249333};\\\", \\\"{x:985,y:604,t:1526930249350};\\\", \\\"{x:968,y:597,t:1526930249366};\\\", \\\"{x:954,y:592,t:1526930249383};\\\", \\\"{x:938,y:587,t:1526930249402};\\\", \\\"{x:912,y:580,t:1526930249415};\\\", \\\"{x:887,y:576,t:1526930249432};\\\", \\\"{x:839,y:568,t:1526930249449};\\\", \\\"{x:756,y:557,t:1526930249467};\\\", \\\"{x:678,y:546,t:1526930249483};\\\", \\\"{x:627,y:538,t:1526930249499};\\\", \\\"{x:587,y:533,t:1526930249516};\\\", \\\"{x:574,y:531,t:1526930249532};\\\", \\\"{x:570,y:531,t:1526930249550};\\\", \\\"{x:569,y:531,t:1526930249580};\\\", \\\"{x:568,y:531,t:1526930249596};\\\", \\\"{x:567,y:531,t:1526930249621};\\\", \\\"{x:567,y:533,t:1526930249781};\\\", \\\"{x:563,y:534,t:1526930249788};\\\", \\\"{x:557,y:538,t:1526930249799};\\\", \\\"{x:541,y:543,t:1526930249816};\\\", \\\"{x:523,y:547,t:1526930249833};\\\", \\\"{x:503,y:549,t:1526930249849};\\\", \\\"{x:477,y:553,t:1526930249866};\\\", \\\"{x:449,y:555,t:1526930249883};\\\", \\\"{x:427,y:556,t:1526930249900};\\\", \\\"{x:413,y:557,t:1526930249916};\\\", \\\"{x:411,y:558,t:1526930249934};\\\", \\\"{x:410,y:558,t:1526930249949};\\\", \\\"{x:408,y:558,t:1526930249966};\\\", \\\"{x:403,y:559,t:1526930249983};\\\", \\\"{x:395,y:562,t:1526930250000};\\\", \\\"{x:390,y:564,t:1526930250017};\\\", \\\"{x:388,y:564,t:1526930250034};\\\", \\\"{x:387,y:564,t:1526930250050};\\\", \\\"{x:386,y:564,t:1526930250076};\\\", \\\"{x:384,y:564,t:1526930250085};\\\", \\\"{x:383,y:564,t:1526930250317};\\\", \\\"{x:382,y:569,t:1526930250335};\\\", \\\"{x:377,y:575,t:1526930250350};\\\", \\\"{x:365,y:580,t:1526930250367};\\\", \\\"{x:344,y:585,t:1526930250384};\\\", \\\"{x:322,y:586,t:1526930250401};\\\", \\\"{x:299,y:589,t:1526930250417};\\\", \\\"{x:267,y:589,t:1526930250434};\\\", \\\"{x:233,y:589,t:1526930250451};\\\", \\\"{x:210,y:589,t:1526930250467};\\\", \\\"{x:193,y:589,t:1526930250484};\\\", \\\"{x:191,y:589,t:1526930250501};\\\", \\\"{x:190,y:589,t:1526930250661};\\\", \\\"{x:187,y:593,t:1526930250669};\\\", \\\"{x:185,y:599,t:1526930250684};\\\", \\\"{x:171,y:617,t:1526930250700};\\\", \\\"{x:159,y:630,t:1526930250717};\\\", \\\"{x:152,y:640,t:1526930250733};\\\", \\\"{x:151,y:645,t:1526930250751};\\\", \\\"{x:151,y:648,t:1526930250767};\\\", \\\"{x:151,y:649,t:1526930250804};\\\", \\\"{x:153,y:649,t:1526930250817};\\\", \\\"{x:176,y:649,t:1526930250834};\\\", \\\"{x:225,y:643,t:1526930250851};\\\", \\\"{x:314,y:631,t:1526930250869};\\\", \\\"{x:420,y:613,t:1526930250883};\\\", \\\"{x:573,y:593,t:1526930250901};\\\", \\\"{x:649,y:579,t:1526930250918};\\\", \\\"{x:698,y:568,t:1526930250933};\\\", \\\"{x:714,y:564,t:1526930250951};\\\", \\\"{x:722,y:562,t:1526930250968};\\\", \\\"{x:726,y:561,t:1526930250984};\\\", \\\"{x:731,y:561,t:1526930251001};\\\", \\\"{x:738,y:561,t:1526930251018};\\\", \\\"{x:743,y:561,t:1526930251034};\\\", \\\"{x:746,y:561,t:1526930251051};\\\", \\\"{x:749,y:562,t:1526930251067};\\\", \\\"{x:752,y:565,t:1526930251086};\\\", \\\"{x:755,y:565,t:1526930251102};\\\", \\\"{x:756,y:567,t:1526930251118};\\\", \\\"{x:756,y:568,t:1526930251165};\\\", \\\"{x:755,y:571,t:1526930251181};\\\", \\\"{x:745,y:573,t:1526930251189};\\\", \\\"{x:735,y:576,t:1526930251201};\\\", \\\"{x:708,y:582,t:1526930251220};\\\", \\\"{x:682,y:588,t:1526930251234};\\\", \\\"{x:662,y:590,t:1526930251251};\\\", \\\"{x:657,y:591,t:1526930251267};\\\", \\\"{x:654,y:591,t:1526930251284};\\\", \\\"{x:651,y:591,t:1526930251300};\\\", \\\"{x:646,y:589,t:1526930251317};\\\", \\\"{x:643,y:588,t:1526930251334};\\\", \\\"{x:642,y:587,t:1526930251352};\\\", \\\"{x:641,y:587,t:1526930251368};\\\", \\\"{x:639,y:587,t:1526930251389};\\\", \\\"{x:637,y:587,t:1526930251420};\\\", \\\"{x:636,y:585,t:1526930251435};\\\", \\\"{x:634,y:584,t:1526930251451};\\\", \\\"{x:631,y:589,t:1526930251589};\\\", \\\"{x:630,y:595,t:1526930251602};\\\", \\\"{x:625,y:612,t:1526930251618};\\\", \\\"{x:616,y:633,t:1526930251635};\\\", \\\"{x:608,y:654,t:1526930251651};\\\", \\\"{x:597,y:676,t:1526930251668};\\\", \\\"{x:594,y:684,t:1526930251685};\\\", \\\"{x:590,y:690,t:1526930251702};\\\", \\\"{x:585,y:696,t:1526930251719};\\\", \\\"{x:580,y:701,t:1526930251735};\\\", \\\"{x:573,y:706,t:1526930251751};\\\", \\\"{x:565,y:710,t:1526930251769};\\\", \\\"{x:556,y:715,t:1526930251785};\\\", \\\"{x:551,y:717,t:1526930251802};\\\", \\\"{x:544,y:719,t:1526930251818};\\\", \\\"{x:538,y:720,t:1526930251837};\\\", \\\"{x:532,y:720,t:1526930251852};\\\", \\\"{x:527,y:720,t:1526930251867};\\\", \\\"{x:514,y:720,t:1526930251884};\\\", \\\"{x:503,y:721,t:1526930251901};\\\", \\\"{x:491,y:724,t:1526930251918};\\\", \\\"{x:484,y:726,t:1526930251934};\\\", \\\"{x:482,y:727,t:1526930251951};\\\", \\\"{x:481,y:728,t:1526930251967};\\\", \\\"{x:480,y:729,t:1526930251985};\\\", \\\"{x:480,y:730,t:1526930252005};\\\", \\\"{x:480,y:731,t:1526930252068};\\\", \\\"{x:480,y:731,t:1526930252161};\\\", \\\"{x:481,y:730,t:1526930252228};\\\", \\\"{x:499,y:727,t:1526930252236};\\\", \\\"{x:531,y:722,t:1526930252251};\\\", \\\"{x:730,y:708,t:1526930252268};\\\", \\\"{x:902,y:704,t:1526930252285};\\\", \\\"{x:1074,y:707,t:1526930252302};\\\", \\\"{x:1201,y:707,t:1526930252318};\\\", \\\"{x:1277,y:709,t:1526930252335};\\\", \\\"{x:1304,y:711,t:1526930252352};\\\", \\\"{x:1311,y:711,t:1526930252368};\\\", \\\"{x:1312,y:711,t:1526930252385};\\\" ] }, { \\\"rt\\\": 20437, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 636773, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-X -X -K -K -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1295,y:721,t:1526930253441};\\\", \\\"{x:1293,y:722,t:1526930253452};\\\", \\\"{x:1292,y:723,t:1526930253470};\\\", \\\"{x:1291,y:723,t:1526930253486};\\\", \\\"{x:1290,y:723,t:1526930253614};\\\", \\\"{x:1281,y:729,t:1526930253874};\\\", \\\"{x:1279,y:730,t:1526930253887};\\\", \\\"{x:1277,y:730,t:1526930253902};\\\", \\\"{x:1276,y:732,t:1526930253919};\\\", \\\"{x:1275,y:732,t:1526930253937};\\\", \\\"{x:1274,y:733,t:1526930253952};\\\", \\\"{x:1272,y:733,t:1526930254053};\\\", \\\"{x:1270,y:735,t:1526930254068};\\\", \\\"{x:1269,y:735,t:1526930254189};\\\", \\\"{x:1267,y:736,t:1526930254204};\\\", \\\"{x:1267,y:737,t:1526930254220};\\\", \\\"{x:1264,y:739,t:1526930254236};\\\", \\\"{x:1263,y:740,t:1526930254261};\\\", \\\"{x:1262,y:741,t:1526930254284};\\\", \\\"{x:1261,y:742,t:1526930254309};\\\", \\\"{x:1260,y:743,t:1526930254373};\\\", \\\"{x:1259,y:743,t:1526930254389};\\\", \\\"{x:1258,y:743,t:1526930254453};\\\", \\\"{x:1258,y:744,t:1526930254470};\\\", \\\"{x:1259,y:744,t:1526930254813};\\\", \\\"{x:1260,y:744,t:1526930254821};\\\", \\\"{x:1261,y:744,t:1526930254853};\\\", \\\"{x:1263,y:743,t:1526930254871};\\\", \\\"{x:1264,y:742,t:1526930254887};\\\", \\\"{x:1265,y:741,t:1526930254909};\\\", \\\"{x:1266,y:741,t:1526930254925};\\\", \\\"{x:1266,y:740,t:1526930254938};\\\", \\\"{x:1268,y:739,t:1526930254955};\\\", \\\"{x:1268,y:738,t:1526930254971};\\\", \\\"{x:1269,y:738,t:1526930254987};\\\", \\\"{x:1270,y:737,t:1526930255004};\\\", \\\"{x:1273,y:735,t:1526930255021};\\\", \\\"{x:1275,y:733,t:1526930255039};\\\", \\\"{x:1275,y:732,t:1526930255054};\\\", \\\"{x:1277,y:731,t:1526930255101};\\\", \\\"{x:1277,y:730,t:1526930255109};\\\", \\\"{x:1278,y:729,t:1526930255121};\\\", \\\"{x:1280,y:726,t:1526930255138};\\\", \\\"{x:1282,y:725,t:1526930255154};\\\", \\\"{x:1283,y:723,t:1526930255171};\\\", \\\"{x:1285,y:721,t:1526930255189};\\\", \\\"{x:1285,y:720,t:1526930255204};\\\", \\\"{x:1287,y:718,t:1526930255220};\\\", \\\"{x:1288,y:716,t:1526930255238};\\\", \\\"{x:1290,y:713,t:1526930255254};\\\", \\\"{x:1292,y:711,t:1526930255271};\\\", \\\"{x:1294,y:708,t:1526930255288};\\\", \\\"{x:1295,y:708,t:1526930255382};\\\", \\\"{x:1298,y:705,t:1526930255389};\\\", \\\"{x:1302,y:704,t:1526930255405};\\\", \\\"{x:1304,y:703,t:1526930255421};\\\", \\\"{x:1312,y:698,t:1526930255439};\\\", \\\"{x:1314,y:696,t:1526930255454};\\\", \\\"{x:1305,y:692,t:1526930255471};\\\", \\\"{x:1290,y:688,t:1526930255488};\\\", \\\"{x:1275,y:686,t:1526930255505};\\\", \\\"{x:1265,y:685,t:1526930255521};\\\", \\\"{x:1256,y:682,t:1526930255538};\\\", \\\"{x:1251,y:679,t:1526930255556};\\\", \\\"{x:1249,y:678,t:1526930255572};\\\", \\\"{x:1249,y:677,t:1526930255589};\\\", \\\"{x:1259,y:674,t:1526930255605};\\\", \\\"{x:1279,y:667,t:1526930255621};\\\", \\\"{x:1288,y:662,t:1526930255638};\\\", \\\"{x:1289,y:662,t:1526930257309};\\\", \\\"{x:1292,y:662,t:1526930257322};\\\", \\\"{x:1295,y:662,t:1526930257339};\\\", \\\"{x:1302,y:662,t:1526930257356};\\\", \\\"{x:1306,y:662,t:1526930257372};\\\", \\\"{x:1314,y:662,t:1526930257390};\\\", \\\"{x:1326,y:660,t:1526930257407};\\\", \\\"{x:1336,y:659,t:1526930257422};\\\", \\\"{x:1348,y:658,t:1526930257440};\\\", \\\"{x:1356,y:657,t:1526930257457};\\\", \\\"{x:1365,y:657,t:1526930257474};\\\", \\\"{x:1379,y:657,t:1526930257490};\\\", \\\"{x:1394,y:657,t:1526930257506};\\\", \\\"{x:1413,y:657,t:1526930257523};\\\", \\\"{x:1434,y:657,t:1526930257540};\\\", \\\"{x:1455,y:655,t:1526930257558};\\\", \\\"{x:1468,y:653,t:1526930257573};\\\", \\\"{x:1473,y:651,t:1526930257589};\\\", \\\"{x:1477,y:650,t:1526930257607};\\\", \\\"{x:1478,y:649,t:1526930257623};\\\", \\\"{x:1480,y:648,t:1526930257640};\\\", \\\"{x:1481,y:647,t:1526930257657};\\\", \\\"{x:1485,y:646,t:1526930257674};\\\", \\\"{x:1486,y:646,t:1526930257690};\\\", \\\"{x:1487,y:646,t:1526930257706};\\\", \\\"{x:1488,y:646,t:1526930257724};\\\", \\\"{x:1489,y:646,t:1526930257765};\\\", \\\"{x:1486,y:649,t:1526930258765};\\\", \\\"{x:1483,y:652,t:1526930258774};\\\", \\\"{x:1479,y:657,t:1526930258790};\\\", \\\"{x:1477,y:662,t:1526930258807};\\\", \\\"{x:1476,y:665,t:1526930258823};\\\", \\\"{x:1476,y:667,t:1526930258839};\\\", \\\"{x:1476,y:668,t:1526930258857};\\\", \\\"{x:1476,y:669,t:1526930258874};\\\", \\\"{x:1475,y:669,t:1526930261021};\\\", \\\"{x:1472,y:669,t:1526930261029};\\\", \\\"{x:1466,y:669,t:1526930261042};\\\", \\\"{x:1448,y:671,t:1526930261059};\\\", \\\"{x:1426,y:671,t:1526930261076};\\\", \\\"{x:1409,y:671,t:1526930261093};\\\", \\\"{x:1392,y:672,t:1526930261109};\\\", \\\"{x:1385,y:673,t:1526930261125};\\\", \\\"{x:1381,y:674,t:1526930261143};\\\", \\\"{x:1379,y:675,t:1526930261159};\\\", \\\"{x:1377,y:676,t:1526930261175};\\\", \\\"{x:1373,y:677,t:1526930261193};\\\", \\\"{x:1365,y:679,t:1526930261209};\\\", \\\"{x:1360,y:681,t:1526930261225};\\\", \\\"{x:1357,y:685,t:1526930261243};\\\", \\\"{x:1356,y:689,t:1526930261259};\\\", \\\"{x:1360,y:698,t:1526930261275};\\\", \\\"{x:1370,y:708,t:1526930261293};\\\", \\\"{x:1390,y:726,t:1526930261309};\\\", \\\"{x:1404,y:737,t:1526930261326};\\\", \\\"{x:1412,y:746,t:1526930261342};\\\", \\\"{x:1417,y:758,t:1526930261360};\\\", \\\"{x:1417,y:767,t:1526930261376};\\\", \\\"{x:1417,y:784,t:1526930261392};\\\", \\\"{x:1415,y:808,t:1526930261410};\\\", \\\"{x:1415,y:836,t:1526930261425};\\\", \\\"{x:1415,y:864,t:1526930261443};\\\", \\\"{x:1416,y:885,t:1526930261460};\\\", \\\"{x:1421,y:900,t:1526930261476};\\\", \\\"{x:1424,y:914,t:1526930261493};\\\", \\\"{x:1426,y:918,t:1526930261509};\\\", \\\"{x:1431,y:921,t:1526930261525};\\\", \\\"{x:1442,y:923,t:1526930261542};\\\", \\\"{x:1458,y:926,t:1526930261560};\\\", \\\"{x:1475,y:931,t:1526930261575};\\\", \\\"{x:1488,y:932,t:1526930261592};\\\", \\\"{x:1500,y:936,t:1526930261610};\\\", \\\"{x:1507,y:937,t:1526930261626};\\\", \\\"{x:1512,y:940,t:1526930261642};\\\", \\\"{x:1515,y:942,t:1526930261659};\\\", \\\"{x:1517,y:942,t:1526930261675};\\\", \\\"{x:1519,y:943,t:1526930261692};\\\", \\\"{x:1521,y:946,t:1526930261709};\\\", \\\"{x:1525,y:950,t:1526930261726};\\\", \\\"{x:1526,y:951,t:1526930261742};\\\", \\\"{x:1526,y:952,t:1526930261759};\\\", \\\"{x:1526,y:953,t:1526930261776};\\\", \\\"{x:1525,y:955,t:1526930261792};\\\", \\\"{x:1521,y:958,t:1526930261809};\\\", \\\"{x:1515,y:960,t:1526930261826};\\\", \\\"{x:1511,y:962,t:1526930261842};\\\", \\\"{x:1507,y:962,t:1526930261859};\\\", \\\"{x:1504,y:962,t:1526930261876};\\\", \\\"{x:1502,y:962,t:1526930261892};\\\", \\\"{x:1499,y:964,t:1526930261909};\\\", \\\"{x:1497,y:966,t:1526930261926};\\\", \\\"{x:1495,y:968,t:1526930261943};\\\", \\\"{x:1493,y:970,t:1526930261959};\\\", \\\"{x:1493,y:971,t:1526930261976};\\\", \\\"{x:1492,y:972,t:1526930261992};\\\", \\\"{x:1491,y:972,t:1526930262013};\\\", \\\"{x:1490,y:972,t:1526930262028};\\\", \\\"{x:1489,y:972,t:1526930262045};\\\", \\\"{x:1487,y:972,t:1526930262061};\\\", \\\"{x:1485,y:972,t:1526930262085};\\\", \\\"{x:1484,y:972,t:1526930262101};\\\", \\\"{x:1484,y:971,t:1526930262125};\\\", \\\"{x:1484,y:970,t:1526930262197};\\\", \\\"{x:1484,y:969,t:1526930262220};\\\", \\\"{x:1484,y:968,t:1526930262263};\\\", \\\"{x:1484,y:967,t:1526930262284};\\\", \\\"{x:1484,y:966,t:1526930262293};\\\", \\\"{x:1484,y:965,t:1526930262309};\\\", \\\"{x:1484,y:963,t:1526930262327};\\\", \\\"{x:1484,y:961,t:1526930262344};\\\", \\\"{x:1484,y:959,t:1526930262359};\\\", \\\"{x:1484,y:956,t:1526930262377};\\\", \\\"{x:1484,y:953,t:1526930262394};\\\", \\\"{x:1484,y:949,t:1526930262410};\\\", \\\"{x:1484,y:947,t:1526930262426};\\\", \\\"{x:1484,y:945,t:1526930262443};\\\", \\\"{x:1484,y:943,t:1526930262460};\\\", \\\"{x:1484,y:941,t:1526930262477};\\\", \\\"{x:1484,y:939,t:1526930262493};\\\", \\\"{x:1484,y:938,t:1526930262510};\\\", \\\"{x:1484,y:936,t:1526930262527};\\\", \\\"{x:1484,y:935,t:1526930262544};\\\", \\\"{x:1484,y:931,t:1526930262560};\\\", \\\"{x:1483,y:931,t:1526930262577};\\\", \\\"{x:1483,y:930,t:1526930262594};\\\", \\\"{x:1483,y:928,t:1526930262701};\\\", \\\"{x:1483,y:927,t:1526930262725};\\\", \\\"{x:1483,y:926,t:1526930262741};\\\", \\\"{x:1483,y:925,t:1526930262749};\\\", \\\"{x:1483,y:924,t:1526930262760};\\\", \\\"{x:1483,y:922,t:1526930262777};\\\", \\\"{x:1483,y:921,t:1526930262793};\\\", \\\"{x:1483,y:919,t:1526930262810};\\\", \\\"{x:1483,y:918,t:1526930262828};\\\", \\\"{x:1483,y:916,t:1526930262843};\\\", \\\"{x:1483,y:913,t:1526930262861};\\\", \\\"{x:1483,y:910,t:1526930262877};\\\", \\\"{x:1483,y:905,t:1526930262893};\\\", \\\"{x:1483,y:901,t:1526930262910};\\\", \\\"{x:1483,y:896,t:1526930262927};\\\", \\\"{x:1483,y:893,t:1526930262944};\\\", \\\"{x:1483,y:889,t:1526930262960};\\\", \\\"{x:1483,y:887,t:1526930262976};\\\", \\\"{x:1483,y:883,t:1526930262993};\\\", \\\"{x:1483,y:881,t:1526930263010};\\\", \\\"{x:1483,y:880,t:1526930263027};\\\", \\\"{x:1483,y:878,t:1526930263044};\\\", \\\"{x:1483,y:876,t:1526930263061};\\\", \\\"{x:1483,y:875,t:1526930263076};\\\", \\\"{x:1483,y:874,t:1526930263094};\\\", \\\"{x:1482,y:871,t:1526930263110};\\\", \\\"{x:1482,y:870,t:1526930263128};\\\", \\\"{x:1482,y:867,t:1526930263143};\\\", \\\"{x:1482,y:865,t:1526930263160};\\\", \\\"{x:1480,y:863,t:1526930263177};\\\", \\\"{x:1480,y:861,t:1526930263193};\\\", \\\"{x:1480,y:860,t:1526930263212};\\\", \\\"{x:1480,y:859,t:1526930263227};\\\", \\\"{x:1480,y:858,t:1526930263243};\\\", \\\"{x:1480,y:857,t:1526930263276};\\\", \\\"{x:1480,y:856,t:1526930263300};\\\", \\\"{x:1480,y:855,t:1526930263437};\\\", \\\"{x:1480,y:854,t:1526930263469};\\\", \\\"{x:1480,y:853,t:1526930263477};\\\", \\\"{x:1480,y:852,t:1526930263494};\\\", \\\"{x:1479,y:851,t:1526930263511};\\\", \\\"{x:1478,y:850,t:1526930263533};\\\", \\\"{x:1478,y:849,t:1526930263544};\\\", \\\"{x:1478,y:848,t:1526930263560};\\\", \\\"{x:1478,y:847,t:1526930263577};\\\", \\\"{x:1478,y:846,t:1526930263593};\\\", \\\"{x:1478,y:844,t:1526930263717};\\\", \\\"{x:1478,y:843,t:1526930263727};\\\", \\\"{x:1478,y:840,t:1526930263744};\\\", \\\"{x:1478,y:839,t:1526930263760};\\\", \\\"{x:1478,y:836,t:1526930263777};\\\", \\\"{x:1478,y:835,t:1526930263794};\\\", \\\"{x:1478,y:833,t:1526930263812};\\\", \\\"{x:1478,y:831,t:1526930263844};\\\", \\\"{x:1478,y:830,t:1526930264109};\\\", \\\"{x:1478,y:829,t:1526930264132};\\\", \\\"{x:1478,y:828,t:1526930264145};\\\", \\\"{x:1478,y:827,t:1526930264165};\\\", \\\"{x:1478,y:826,t:1526930264197};\\\", \\\"{x:1478,y:825,t:1526930264221};\\\", \\\"{x:1479,y:824,t:1526930264229};\\\", \\\"{x:1479,y:823,t:1526930264293};\\\", \\\"{x:1479,y:822,t:1526930264309};\\\", \\\"{x:1479,y:821,t:1526930264325};\\\", \\\"{x:1479,y:820,t:1526930264333};\\\", \\\"{x:1480,y:820,t:1526930264348};\\\", \\\"{x:1480,y:819,t:1526930264361};\\\", \\\"{x:1480,y:818,t:1526930264377};\\\", \\\"{x:1480,y:817,t:1526930264394};\\\", \\\"{x:1480,y:815,t:1526930264411};\\\", \\\"{x:1480,y:812,t:1526930264427};\\\", \\\"{x:1480,y:810,t:1526930264444};\\\", \\\"{x:1480,y:809,t:1526930264461};\\\", \\\"{x:1480,y:807,t:1526930264477};\\\", \\\"{x:1480,y:805,t:1526930264494};\\\", \\\"{x:1480,y:804,t:1526930264511};\\\", \\\"{x:1480,y:802,t:1526930264527};\\\", \\\"{x:1480,y:800,t:1526930264544};\\\", \\\"{x:1481,y:798,t:1526930264561};\\\", \\\"{x:1481,y:794,t:1526930264577};\\\", \\\"{x:1481,y:792,t:1526930264594};\\\", \\\"{x:1481,y:789,t:1526930264611};\\\", \\\"{x:1481,y:782,t:1526930264629};\\\", \\\"{x:1481,y:780,t:1526930264644};\\\", \\\"{x:1481,y:774,t:1526930264661};\\\", \\\"{x:1481,y:768,t:1526930264679};\\\", \\\"{x:1481,y:764,t:1526930264694};\\\", \\\"{x:1481,y:759,t:1526930264712};\\\", \\\"{x:1481,y:754,t:1526930264728};\\\", \\\"{x:1481,y:751,t:1526930264745};\\\", \\\"{x:1481,y:748,t:1526930264762};\\\", \\\"{x:1481,y:746,t:1526930264778};\\\", \\\"{x:1481,y:740,t:1526930264795};\\\", \\\"{x:1481,y:737,t:1526930264812};\\\", \\\"{x:1481,y:732,t:1526930264829};\\\", \\\"{x:1481,y:730,t:1526930264845};\\\", \\\"{x:1481,y:727,t:1526930264862};\\\", \\\"{x:1481,y:723,t:1526930264878};\\\", \\\"{x:1481,y:722,t:1526930264895};\\\", \\\"{x:1481,y:718,t:1526930264912};\\\", \\\"{x:1481,y:713,t:1526930264929};\\\", \\\"{x:1481,y:711,t:1526930264944};\\\", \\\"{x:1481,y:708,t:1526930264961};\\\", \\\"{x:1481,y:707,t:1526930264978};\\\", \\\"{x:1481,y:705,t:1526930264995};\\\", \\\"{x:1481,y:703,t:1526930265012};\\\", \\\"{x:1480,y:700,t:1526930265029};\\\", \\\"{x:1480,y:699,t:1526930265077};\\\", \\\"{x:1480,y:697,t:1526930265118};\\\", \\\"{x:1480,y:696,t:1526930265133};\\\", \\\"{x:1480,y:694,t:1526930265146};\\\", \\\"{x:1480,y:692,t:1526930265162};\\\", \\\"{x:1480,y:690,t:1526930265178};\\\", \\\"{x:1480,y:683,t:1526930265196};\\\", \\\"{x:1480,y:679,t:1526930265212};\\\", \\\"{x:1479,y:666,t:1526930265229};\\\", \\\"{x:1479,y:656,t:1526930265245};\\\", \\\"{x:1479,y:645,t:1526930265261};\\\", \\\"{x:1479,y:638,t:1526930265278};\\\", \\\"{x:1479,y:631,t:1526930265296};\\\", \\\"{x:1479,y:625,t:1526930265312};\\\", \\\"{x:1479,y:622,t:1526930265329};\\\", \\\"{x:1479,y:618,t:1526930265346};\\\", \\\"{x:1479,y:617,t:1526930265362};\\\", \\\"{x:1479,y:614,t:1526930265379};\\\", \\\"{x:1479,y:611,t:1526930265396};\\\", \\\"{x:1479,y:606,t:1526930265411};\\\", \\\"{x:1479,y:600,t:1526930265429};\\\", \\\"{x:1479,y:593,t:1526930265445};\\\", \\\"{x:1479,y:588,t:1526930265462};\\\", \\\"{x:1479,y:582,t:1526930265479};\\\", \\\"{x:1479,y:576,t:1526930265496};\\\", \\\"{x:1479,y:570,t:1526930265512};\\\", \\\"{x:1479,y:564,t:1526930265529};\\\", \\\"{x:1478,y:559,t:1526930265546};\\\", \\\"{x:1478,y:554,t:1526930265562};\\\", \\\"{x:1478,y:550,t:1526930265579};\\\", \\\"{x:1478,y:547,t:1526930265596};\\\", \\\"{x:1478,y:543,t:1526930265613};\\\", \\\"{x:1478,y:541,t:1526930265629};\\\", \\\"{x:1478,y:540,t:1526930265645};\\\", \\\"{x:1478,y:538,t:1526930265662};\\\", \\\"{x:1478,y:537,t:1526930265679};\\\", \\\"{x:1478,y:534,t:1526930265696};\\\", \\\"{x:1478,y:531,t:1526930265713};\\\", \\\"{x:1478,y:528,t:1526930265729};\\\", \\\"{x:1478,y:524,t:1526930265746};\\\", \\\"{x:1478,y:520,t:1526930265763};\\\", \\\"{x:1478,y:517,t:1526930265779};\\\", \\\"{x:1478,y:512,t:1526930265795};\\\", \\\"{x:1478,y:509,t:1526930265813};\\\", \\\"{x:1479,y:506,t:1526930265829};\\\", \\\"{x:1479,y:503,t:1526930265846};\\\", \\\"{x:1480,y:499,t:1526930265862};\\\", \\\"{x:1480,y:496,t:1526930265879};\\\", \\\"{x:1481,y:492,t:1526930265896};\\\", \\\"{x:1481,y:488,t:1526930265913};\\\", \\\"{x:1483,y:481,t:1526930265929};\\\", \\\"{x:1484,y:476,t:1526930265945};\\\", \\\"{x:1485,y:471,t:1526930265963};\\\", \\\"{x:1485,y:465,t:1526930265979};\\\", \\\"{x:1487,y:460,t:1526930265996};\\\", \\\"{x:1488,y:454,t:1526930266012};\\\", \\\"{x:1488,y:450,t:1526930266029};\\\", \\\"{x:1488,y:445,t:1526930266045};\\\", \\\"{x:1489,y:441,t:1526930266062};\\\", \\\"{x:1489,y:436,t:1526930266079};\\\", \\\"{x:1491,y:433,t:1526930266095};\\\", \\\"{x:1491,y:428,t:1526930266112};\\\", \\\"{x:1491,y:426,t:1526930266129};\\\", \\\"{x:1491,y:421,t:1526930266145};\\\", \\\"{x:1491,y:418,t:1526930266162};\\\", \\\"{x:1491,y:414,t:1526930266179};\\\", \\\"{x:1492,y:412,t:1526930266195};\\\", \\\"{x:1493,y:408,t:1526930266212};\\\", \\\"{x:1494,y:404,t:1526930266229};\\\", \\\"{x:1494,y:401,t:1526930266246};\\\", \\\"{x:1495,y:397,t:1526930266262};\\\", \\\"{x:1495,y:393,t:1526930266280};\\\", \\\"{x:1495,y:387,t:1526930266295};\\\", \\\"{x:1495,y:383,t:1526930266313};\\\", \\\"{x:1495,y:379,t:1526930266329};\\\", \\\"{x:1496,y:375,t:1526930266345};\\\", \\\"{x:1496,y:367,t:1526930266362};\\\", \\\"{x:1496,y:363,t:1526930266380};\\\", \\\"{x:1496,y:357,t:1526930266396};\\\", \\\"{x:1496,y:349,t:1526930266413};\\\", \\\"{x:1496,y:344,t:1526930266430};\\\", \\\"{x:1496,y:340,t:1526930266445};\\\", \\\"{x:1496,y:334,t:1526930266463};\\\", \\\"{x:1496,y:330,t:1526930266480};\\\", \\\"{x:1496,y:327,t:1526930266496};\\\", \\\"{x:1496,y:322,t:1526930266512};\\\", \\\"{x:1496,y:320,t:1526930266529};\\\", \\\"{x:1496,y:316,t:1526930266546};\\\", \\\"{x:1496,y:314,t:1526930266562};\\\", \\\"{x:1496,y:310,t:1526930266580};\\\", \\\"{x:1496,y:307,t:1526930266596};\\\", \\\"{x:1496,y:305,t:1526930266612};\\\", \\\"{x:1496,y:303,t:1526930266629};\\\", \\\"{x:1496,y:302,t:1526930266647};\\\", \\\"{x:1496,y:299,t:1526930266663};\\\", \\\"{x:1496,y:297,t:1526930266680};\\\", \\\"{x:1496,y:296,t:1526930266696};\\\", \\\"{x:1496,y:293,t:1526930266713};\\\", \\\"{x:1496,y:291,t:1526930266729};\\\", \\\"{x:1496,y:290,t:1526930266749};\\\", \\\"{x:1496,y:289,t:1526930266764};\\\", \\\"{x:1496,y:287,t:1526930266780};\\\", \\\"{x:1495,y:285,t:1526930266796};\\\", \\\"{x:1494,y:282,t:1526930266813};\\\", \\\"{x:1493,y:280,t:1526930266829};\\\", \\\"{x:1492,y:278,t:1526930266847};\\\", \\\"{x:1491,y:277,t:1526930266863};\\\", \\\"{x:1491,y:276,t:1526930266879};\\\", \\\"{x:1490,y:275,t:1526930266897};\\\", \\\"{x:1489,y:273,t:1526930266916};\\\", \\\"{x:1488,y:273,t:1526930267229};\\\", \\\"{x:1486,y:273,t:1526930267261};\\\", \\\"{x:1485,y:273,t:1526930267276};\\\", \\\"{x:1484,y:273,t:1526930267293};\\\", \\\"{x:1483,y:273,t:1526930267445};\\\", \\\"{x:1482,y:273,t:1526930267501};\\\", \\\"{x:1482,y:274,t:1526930267514};\\\", \\\"{x:1482,y:278,t:1526930267531};\\\", \\\"{x:1482,y:280,t:1526930267547};\\\", \\\"{x:1482,y:284,t:1526930267564};\\\", \\\"{x:1482,y:287,t:1526930267581};\\\", \\\"{x:1482,y:289,t:1526930267597};\\\", \\\"{x:1483,y:290,t:1526930267614};\\\", \\\"{x:1483,y:292,t:1526930267662};\\\", \\\"{x:1483,y:293,t:1526930267701};\\\", \\\"{x:1484,y:294,t:1526930267717};\\\", \\\"{x:1485,y:295,t:1526930267731};\\\", \\\"{x:1485,y:296,t:1526930267749};\\\", \\\"{x:1485,y:298,t:1526930267764};\\\", \\\"{x:1486,y:301,t:1526930267782};\\\", \\\"{x:1486,y:302,t:1526930267796};\\\", \\\"{x:1486,y:305,t:1526930267814};\\\", \\\"{x:1486,y:306,t:1526930267831};\\\", \\\"{x:1486,y:307,t:1526930267847};\\\", \\\"{x:1486,y:308,t:1526930267865};\\\", \\\"{x:1486,y:309,t:1526930267881};\\\", \\\"{x:1486,y:310,t:1526930267901};\\\", \\\"{x:1486,y:311,t:1526930267916};\\\", \\\"{x:1486,y:312,t:1526930267933};\\\", \\\"{x:1486,y:313,t:1526930267948};\\\", \\\"{x:1486,y:315,t:1526930267964};\\\", \\\"{x:1486,y:318,t:1526930267981};\\\", \\\"{x:1486,y:319,t:1526930267997};\\\", \\\"{x:1486,y:321,t:1526930268013};\\\", \\\"{x:1486,y:323,t:1526930268031};\\\", \\\"{x:1486,y:325,t:1526930268048};\\\", \\\"{x:1486,y:328,t:1526930268064};\\\", \\\"{x:1486,y:331,t:1526930268080};\\\", \\\"{x:1486,y:335,t:1526930268098};\\\", \\\"{x:1486,y:338,t:1526930268114};\\\", \\\"{x:1486,y:342,t:1526930268131};\\\", \\\"{x:1486,y:348,t:1526930268148};\\\", \\\"{x:1486,y:353,t:1526930268164};\\\", \\\"{x:1486,y:359,t:1526930268181};\\\", \\\"{x:1486,y:363,t:1526930268198};\\\", \\\"{x:1486,y:365,t:1526930268214};\\\", \\\"{x:1486,y:367,t:1526930268231};\\\", \\\"{x:1486,y:368,t:1526930268248};\\\", \\\"{x:1486,y:370,t:1526930268264};\\\", \\\"{x:1486,y:373,t:1526930268281};\\\", \\\"{x:1486,y:376,t:1526930268298};\\\", \\\"{x:1486,y:379,t:1526930268314};\\\", \\\"{x:1486,y:382,t:1526930268331};\\\", \\\"{x:1486,y:385,t:1526930268348};\\\", \\\"{x:1486,y:387,t:1526930268364};\\\", \\\"{x:1486,y:391,t:1526930268381};\\\", \\\"{x:1486,y:393,t:1526930268398};\\\", \\\"{x:1486,y:394,t:1526930268414};\\\", \\\"{x:1486,y:396,t:1526930268430};\\\", \\\"{x:1486,y:398,t:1526930268447};\\\", \\\"{x:1486,y:401,t:1526930268465};\\\", \\\"{x:1486,y:402,t:1526930268481};\\\", \\\"{x:1486,y:404,t:1526930268498};\\\", \\\"{x:1486,y:405,t:1526930268514};\\\", \\\"{x:1486,y:407,t:1526930268531};\\\", \\\"{x:1485,y:410,t:1526930268547};\\\", \\\"{x:1484,y:414,t:1526930268565};\\\", \\\"{x:1484,y:417,t:1526930268580};\\\", \\\"{x:1484,y:422,t:1526930268597};\\\", \\\"{x:1482,y:425,t:1526930268615};\\\", \\\"{x:1482,y:427,t:1526930268631};\\\", \\\"{x:1482,y:428,t:1526930268647};\\\", \\\"{x:1481,y:432,t:1526930268665};\\\", \\\"{x:1481,y:434,t:1526930268685};\\\", \\\"{x:1480,y:434,t:1526930268698};\\\", \\\"{x:1480,y:435,t:1526930268715};\\\", \\\"{x:1480,y:437,t:1526930268733};\\\", \\\"{x:1479,y:438,t:1526930268748};\\\", \\\"{x:1479,y:440,t:1526930268796};\\\", \\\"{x:1479,y:441,t:1526930268821};\\\", \\\"{x:1479,y:443,t:1526930268837};\\\", \\\"{x:1479,y:444,t:1526930268853};\\\", \\\"{x:1479,y:447,t:1526930268865};\\\", \\\"{x:1479,y:448,t:1526930268882};\\\", \\\"{x:1479,y:451,t:1526930268898};\\\", \\\"{x:1479,y:453,t:1526930268915};\\\", \\\"{x:1478,y:456,t:1526930268932};\\\", \\\"{x:1478,y:458,t:1526930268948};\\\", \\\"{x:1478,y:460,t:1526930268965};\\\", \\\"{x:1478,y:463,t:1526930268981};\\\", \\\"{x:1478,y:465,t:1526930268998};\\\", \\\"{x:1478,y:466,t:1526930269037};\\\", \\\"{x:1478,y:467,t:1526930269048};\\\", \\\"{x:1478,y:470,t:1526930269065};\\\", \\\"{x:1478,y:473,t:1526930269082};\\\", \\\"{x:1478,y:477,t:1526930269097};\\\", \\\"{x:1477,y:480,t:1526930269115};\\\", \\\"{x:1477,y:482,t:1526930269132};\\\", \\\"{x:1477,y:483,t:1526930269148};\\\", \\\"{x:1476,y:487,t:1526930269165};\\\", \\\"{x:1475,y:490,t:1526930269182};\\\", \\\"{x:1475,y:492,t:1526930269198};\\\", \\\"{x:1475,y:494,t:1526930269215};\\\", \\\"{x:1475,y:497,t:1526930269232};\\\", \\\"{x:1475,y:499,t:1526930269248};\\\", \\\"{x:1474,y:503,t:1526930269265};\\\", \\\"{x:1474,y:507,t:1526930269282};\\\", \\\"{x:1474,y:514,t:1526930269298};\\\", \\\"{x:1474,y:521,t:1526930269315};\\\", \\\"{x:1472,y:529,t:1526930269332};\\\", \\\"{x:1472,y:535,t:1526930269348};\\\", \\\"{x:1470,y:542,t:1526930269365};\\\", \\\"{x:1470,y:546,t:1526930269382};\\\", \\\"{x:1470,y:553,t:1526930269399};\\\", \\\"{x:1470,y:555,t:1526930269415};\\\", \\\"{x:1470,y:560,t:1526930269432};\\\", \\\"{x:1470,y:563,t:1526930269448};\\\", \\\"{x:1470,y:567,t:1526930269464};\\\", \\\"{x:1470,y:570,t:1526930269481};\\\", \\\"{x:1470,y:572,t:1526930269499};\\\", \\\"{x:1470,y:576,t:1526930269514};\\\", \\\"{x:1470,y:579,t:1526930269531};\\\", \\\"{x:1470,y:584,t:1526930269548};\\\", \\\"{x:1470,y:588,t:1526930269564};\\\", \\\"{x:1470,y:591,t:1526930269581};\\\", \\\"{x:1470,y:596,t:1526930269599};\\\", \\\"{x:1470,y:601,t:1526930269614};\\\", \\\"{x:1470,y:606,t:1526930269632};\\\", \\\"{x:1471,y:615,t:1526930269648};\\\", \\\"{x:1472,y:623,t:1526930269664};\\\", \\\"{x:1474,y:633,t:1526930269682};\\\", \\\"{x:1475,y:641,t:1526930269698};\\\", \\\"{x:1476,y:648,t:1526930269714};\\\", \\\"{x:1477,y:652,t:1526930269732};\\\", \\\"{x:1477,y:658,t:1526930269748};\\\", \\\"{x:1478,y:662,t:1526930269766};\\\", \\\"{x:1479,y:665,t:1526930269781};\\\", \\\"{x:1479,y:667,t:1526930269798};\\\", \\\"{x:1480,y:670,t:1526930269815};\\\", \\\"{x:1480,y:673,t:1526930269831};\\\", \\\"{x:1480,y:675,t:1526930269849};\\\", \\\"{x:1481,y:678,t:1526930269866};\\\", \\\"{x:1481,y:679,t:1526930269882};\\\", \\\"{x:1481,y:681,t:1526930269899};\\\", \\\"{x:1481,y:685,t:1526930269916};\\\", \\\"{x:1481,y:687,t:1526930269932};\\\", \\\"{x:1481,y:694,t:1526930269949};\\\", \\\"{x:1481,y:700,t:1526930269966};\\\", \\\"{x:1481,y:707,t:1526930269981};\\\", \\\"{x:1481,y:713,t:1526930269998};\\\", \\\"{x:1481,y:720,t:1526930270016};\\\", \\\"{x:1481,y:725,t:1526930270032};\\\", \\\"{x:1481,y:728,t:1526930270048};\\\", \\\"{x:1481,y:731,t:1526930270066};\\\", \\\"{x:1481,y:732,t:1526930270081};\\\", \\\"{x:1481,y:734,t:1526930270099};\\\", \\\"{x:1481,y:735,t:1526930270116};\\\", \\\"{x:1481,y:736,t:1526930270132};\\\", \\\"{x:1481,y:738,t:1526930270148};\\\", \\\"{x:1481,y:740,t:1526930270173};\\\", \\\"{x:1481,y:741,t:1526930270182};\\\", \\\"{x:1481,y:743,t:1526930270198};\\\", \\\"{x:1481,y:746,t:1526930270216};\\\", \\\"{x:1481,y:749,t:1526930270231};\\\", \\\"{x:1481,y:753,t:1526930270249};\\\", \\\"{x:1481,y:756,t:1526930270266};\\\", \\\"{x:1481,y:763,t:1526930270282};\\\", \\\"{x:1481,y:769,t:1526930270299};\\\", \\\"{x:1481,y:776,t:1526930270316};\\\", \\\"{x:1481,y:785,t:1526930270333};\\\", \\\"{x:1481,y:792,t:1526930270348};\\\", \\\"{x:1481,y:798,t:1526930270365};\\\", \\\"{x:1481,y:804,t:1526930270383};\\\", \\\"{x:1481,y:806,t:1526930270399};\\\", \\\"{x:1481,y:808,t:1526930270416};\\\", \\\"{x:1481,y:809,t:1526930270437};\\\", \\\"{x:1482,y:811,t:1526930270461};\\\", \\\"{x:1483,y:811,t:1526930270468};\\\", \\\"{x:1483,y:813,t:1526930270500};\\\", \\\"{x:1483,y:814,t:1526930270524};\\\", \\\"{x:1483,y:816,t:1526930270565};\\\", \\\"{x:1483,y:817,t:1526930270583};\\\", \\\"{x:1483,y:819,t:1526930270604};\\\", \\\"{x:1483,y:820,t:1526930270629};\\\", \\\"{x:1483,y:822,t:1526930270645};\\\", \\\"{x:1483,y:823,t:1526930270661};\\\", \\\"{x:1483,y:825,t:1526930270677};\\\", \\\"{x:1483,y:826,t:1526930270698};\\\", \\\"{x:1483,y:828,t:1526930270716};\\\", \\\"{x:1483,y:831,t:1526930270733};\\\", \\\"{x:1483,y:832,t:1526930270749};\\\", \\\"{x:1483,y:835,t:1526930270766};\\\", \\\"{x:1483,y:837,t:1526930270784};\\\", \\\"{x:1483,y:841,t:1526930270800};\\\", \\\"{x:1483,y:844,t:1526930270816};\\\", \\\"{x:1483,y:848,t:1526930270833};\\\", \\\"{x:1483,y:851,t:1526930270850};\\\", \\\"{x:1483,y:855,t:1526930270866};\\\", \\\"{x:1483,y:857,t:1526930270883};\\\", \\\"{x:1483,y:862,t:1526930270900};\\\", \\\"{x:1483,y:866,t:1526930270915};\\\", \\\"{x:1483,y:873,t:1526930270933};\\\", \\\"{x:1483,y:876,t:1526930270950};\\\", \\\"{x:1483,y:880,t:1526930270965};\\\", \\\"{x:1483,y:883,t:1526930270982};\\\", \\\"{x:1483,y:885,t:1526930271000};\\\", \\\"{x:1483,y:890,t:1526930271016};\\\", \\\"{x:1482,y:895,t:1526930271033};\\\", \\\"{x:1479,y:904,t:1526930271050};\\\", \\\"{x:1479,y:911,t:1526930271065};\\\", \\\"{x:1479,y:917,t:1526930271082};\\\", \\\"{x:1478,y:924,t:1526930271100};\\\", \\\"{x:1477,y:928,t:1526930271115};\\\", \\\"{x:1477,y:935,t:1526930271132};\\\", \\\"{x:1477,y:941,t:1526930271150};\\\", \\\"{x:1477,y:944,t:1526930271166};\\\", \\\"{x:1477,y:946,t:1526930271182};\\\", \\\"{x:1477,y:949,t:1526930271199};\\\", \\\"{x:1476,y:950,t:1526930271350};\\\", \\\"{x:1475,y:950,t:1526930271373};\\\", \\\"{x:1474,y:948,t:1526930271444};\\\", \\\"{x:1474,y:946,t:1526930271453};\\\", \\\"{x:1473,y:944,t:1526930271467};\\\", \\\"{x:1471,y:937,t:1526930271483};\\\", \\\"{x:1463,y:930,t:1526930271500};\\\", \\\"{x:1462,y:927,t:1526930271517};\\\", \\\"{x:1462,y:924,t:1526930271781};\\\", \\\"{x:1459,y:918,t:1526930271789};\\\", \\\"{x:1456,y:915,t:1526930271800};\\\", \\\"{x:1437,y:900,t:1526930271817};\\\", \\\"{x:1410,y:880,t:1526930271834};\\\", \\\"{x:1367,y:849,t:1526930271850};\\\", \\\"{x:1296,y:806,t:1526930271867};\\\", \\\"{x:1202,y:761,t:1526930271884};\\\", \\\"{x:1095,y:718,t:1526930271900};\\\", \\\"{x:943,y:664,t:1526930271917};\\\", \\\"{x:881,y:639,t:1526930271935};\\\", \\\"{x:847,y:625,t:1526930271949};\\\", \\\"{x:836,y:616,t:1526930271967};\\\", \\\"{x:834,y:613,t:1526930271983};\\\", \\\"{x:833,y:608,t:1526930272001};\\\", \\\"{x:830,y:601,t:1526930272019};\\\", \\\"{x:826,y:595,t:1526930272034};\\\", \\\"{x:816,y:585,t:1526930272051};\\\", \\\"{x:797,y:574,t:1526930272068};\\\", \\\"{x:777,y:569,t:1526930272085};\\\", \\\"{x:765,y:567,t:1526930272101};\\\", \\\"{x:753,y:567,t:1526930272117};\\\", \\\"{x:737,y:568,t:1526930272134};\\\", \\\"{x:715,y:571,t:1526930272152};\\\", \\\"{x:681,y:574,t:1526930272168};\\\", \\\"{x:650,y:574,t:1526930272184};\\\", \\\"{x:628,y:574,t:1526930272201};\\\", \\\"{x:613,y:574,t:1526930272217};\\\", \\\"{x:603,y:579,t:1526930272234};\\\", \\\"{x:598,y:583,t:1526930272252};\\\", \\\"{x:595,y:586,t:1526930272267};\\\", \\\"{x:595,y:588,t:1526930272284};\\\", \\\"{x:595,y:589,t:1526930272388};\\\", \\\"{x:596,y:589,t:1526930272421};\\\", \\\"{x:597,y:590,t:1526930272435};\\\", \\\"{x:598,y:590,t:1526930272460};\\\", \\\"{x:600,y:591,t:1526930272493};\\\", \\\"{x:602,y:592,t:1526930272508};\\\", \\\"{x:603,y:593,t:1526930272523};\\\", \\\"{x:604,y:593,t:1526930272540};\\\", \\\"{x:604,y:594,t:1526930272700};\\\", \\\"{x:604,y:597,t:1526930272707};\\\", \\\"{x:603,y:598,t:1526930272718};\\\", \\\"{x:590,y:603,t:1526930272735};\\\", \\\"{x:567,y:609,t:1526930272752};\\\", \\\"{x:537,y:615,t:1526930272769};\\\", \\\"{x:506,y:618,t:1526930272785};\\\", \\\"{x:467,y:624,t:1526930272802};\\\", \\\"{x:436,y:628,t:1526930272818};\\\", \\\"{x:411,y:628,t:1526930272836};\\\", \\\"{x:402,y:628,t:1526930272852};\\\", \\\"{x:400,y:628,t:1526930272868};\\\", \\\"{x:399,y:628,t:1526930272886};\\\", \\\"{x:397,y:628,t:1526930272902};\\\", \\\"{x:394,y:625,t:1526930272919};\\\", \\\"{x:392,y:623,t:1526930272935};\\\", \\\"{x:390,y:620,t:1526930272952};\\\", \\\"{x:388,y:617,t:1526930272969};\\\", \\\"{x:388,y:616,t:1526930272985};\\\", \\\"{x:388,y:612,t:1526930273002};\\\", \\\"{x:388,y:611,t:1526930273018};\\\", \\\"{x:388,y:609,t:1526930273036};\\\", \\\"{x:388,y:608,t:1526930273052};\\\", \\\"{x:388,y:607,t:1526930273085};\\\", \\\"{x:388,y:605,t:1526930273102};\\\", \\\"{x:388,y:603,t:1526930273119};\\\", \\\"{x:388,y:599,t:1526930273135};\\\", \\\"{x:388,y:597,t:1526930273152};\\\", \\\"{x:388,y:595,t:1526930273168};\\\", \\\"{x:387,y:593,t:1526930273185};\\\", \\\"{x:388,y:599,t:1526930273323};\\\", \\\"{x:391,y:607,t:1526930273335};\\\", \\\"{x:401,y:625,t:1526930273353};\\\", \\\"{x:416,y:652,t:1526930273369};\\\", \\\"{x:433,y:684,t:1526930273386};\\\", \\\"{x:443,y:706,t:1526930273402};\\\", \\\"{x:448,y:721,t:1526930273419};\\\", \\\"{x:452,y:734,t:1526930273435};\\\", \\\"{x:459,y:752,t:1526930273452};\\\", \\\"{x:463,y:758,t:1526930273468};\\\", \\\"{x:468,y:763,t:1526930273485};\\\", \\\"{x:468,y:762,t:1526930273605};\\\", \\\"{x:468,y:761,t:1526930273620};\\\", \\\"{x:468,y:759,t:1526930273637};\\\", \\\"{x:468,y:758,t:1526930273669};\\\", \\\"{x:468,y:757,t:1526930273676};\\\", \\\"{x:468,y:756,t:1526930273686};\\\", \\\"{x:471,y:752,t:1526930273704};\\\", \\\"{x:472,y:746,t:1526930273720};\\\", \\\"{x:474,y:744,t:1526930273736};\\\", \\\"{x:475,y:744,t:1526930273980};\\\", \\\"{x:491,y:747,t:1526930273987};\\\", \\\"{x:541,y:749,t:1526930274002};\\\", \\\"{x:584,y:745,t:1526930274020};\\\", \\\"{x:691,y:743,t:1526930274035};\\\", \\\"{x:766,y:740,t:1526930274052};\\\", \\\"{x:771,y:737,t:1526930274069};\\\", \\\"{x:772,y:736,t:1526930274085};\\\", \\\"{x:773,y:735,t:1526930274103};\\\", \\\"{x:774,y:734,t:1526930274156};\\\", \\\"{x:775,y:734,t:1526930274172};\\\", \\\"{x:776,y:734,t:1526930274188};\\\", \\\"{x:776,y:733,t:1526930274202};\\\", \\\"{x:778,y:733,t:1526930274219};\\\", \\\"{x:779,y:733,t:1526930274325};\\\", \\\"{x:780,y:733,t:1526930274372};\\\", \\\"{x:781,y:733,t:1526930274421};\\\", \\\"{x:782,y:733,t:1526930274541};\\\" ] }, { \\\"rt\\\": 130506, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 768554, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Find the point of 12 PM at x axis, and the line that begins at this point and positive \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 8486, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"China\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 778046, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 12369, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 791428, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" }, { \\\"rt\\\": 1846, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 794617, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"W7EBS\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"charlie\\\", \\\"condition\\\": \\\"111\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"W7EBS\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 158, dom: 731, initialDom: 797",
  "javascriptErrors": []
}