var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05215361e05fbc6be974d8f304bc1d47540e623b"] = {
  "startTime": "2018-05-21T17:16:53.4461458Z",
  "websitePageUrl": "/16",
  "visitTime": 95208,
  "engagementTime": 88173,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "ea47120def15dec9eef2fd373a503e6d",
    "created": "2018-05-21T17:16:53.4461458+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=9BCHA",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "37d8b52cad85f79f7b6ece0a42c4082d",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/ea47120def15dec9eef2fd373a503e6d/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 250,
      "e": 250,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 250,
      "e": 250,
      "ty": 1,
      "x": 8,
      "y": 0
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 2,
      "x": 513,
      "y": 764
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 41,
      "x": 46752,
      "y": 41880,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 552,
      "y": 623
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 6,
      "x": 558,
      "y": 596,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 565,
      "y": 577
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 52597,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2367,
      "e": 2367,
      "ty": 3,
      "x": 565,
      "y": 577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2368,
      "e": 2368,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2519,
      "e": 2519,
      "ty": 4,
      "x": 52597,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2520,
      "e": 2520,
      "ty": 5,
      "x": 565,
      "y": 577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6572,
      "e": 6572,
      "ty": 7,
      "x": 788,
      "y": 560,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 959,
      "y": 560
    },
    {
      "t": 6702,
      "e": 6702,
      "ty": 2,
      "x": 1638,
      "y": 566
    },
    {
      "t": 6752,
      "e": 6752,
      "ty": 41,
      "x": 60110,
      "y": 30654,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 1639,
      "y": 566
    },
    {
      "t": 8300,
      "e": 8300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8799,
      "e": 8799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8831,
      "e": 8831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8864,
      "e": 8864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8898,
      "e": 8898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8931,
      "e": 8931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8964,
      "e": 8964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8996,
      "e": 8996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9030,
      "e": 9030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9063,
      "e": 9063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9095,
      "e": 9095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9129,
      "e": 9129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9162,
      "e": 9162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9195,
      "e": 9195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9228,
      "e": 9228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9261,
      "e": 9261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9293,
      "e": 9293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9326,
      "e": 9326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9359,
      "e": 9359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9392,
      "e": 9392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9425,
      "e": 9425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9458,
      "e": 9458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9492,
      "e": 9492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9525,
      "e": 9525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9558,
      "e": 9558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9571,
      "e": 9571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 9572,
      "e": 9572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9699,
      "e": 9699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "E"
    },
    {
      "t": 9738,
      "e": 9738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "E"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10347,
      "e": 10347,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 10348,
      "e": 10348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10410,
      "e": 10410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Ev"
    },
    {
      "t": 10450,
      "e": 10450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 10450,
      "e": 10450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10539,
      "e": 10539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Eve"
    },
    {
      "t": 10587,
      "e": 10587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 10588,
      "e": 10588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10643,
      "e": 10643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Even"
    },
    {
      "t": 10787,
      "e": 10787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10788,
      "e": 10788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10867,
      "e": 10867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 10900,
      "e": 10900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 10900,
      "e": 10900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10995,
      "e": 10995,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 11006,
      "e": 11006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11006,
      "e": 11006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11083,
      "e": 11083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11154,
      "e": 11154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11154,
      "e": 11154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11243,
      "e": 11243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 11346,
      "e": 11346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 11347,
      "e": 11347,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11442,
      "e": 11442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 11450,
      "e": 11450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11451,
      "e": 11451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11570,
      "e": 11570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 11595,
      "e": 11595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11595,
      "e": 11595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11699,
      "e": 11699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 11812,
      "e": 11812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11812,
      "e": 11812,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11930,
      "e": 11930,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12059,
      "e": 12059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 12060,
      "e": 12060,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12163,
      "e": 12163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 12218,
      "e": 12218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12219,
      "e": 12219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12315,
      "e": 12315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12332,
      "e": 12332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 12332,
      "e": 12332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12435,
      "e": 12435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 12498,
      "e": 12498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 12499,
      "e": 12499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12579,
      "e": 12579,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 12674,
      "e": 12674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12674,
      "e": 12674,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12787,
      "e": 12787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12804,
      "e": 12804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12804,
      "e": 12804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12892,
      "e": 12892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13004,
      "e": 13004,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start "
    },
    {
      "t": 13067,
      "e": 13067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13068,
      "e": 13068,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13194,
      "e": 13194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 13202,
      "e": 13202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13203,
      "e": 13203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13205,
      "e": 13205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 13205,
      "e": 13205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13267,
      "e": 13267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ty"
    },
    {
      "t": 13275,
      "e": 13275,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13404,
      "e": 13404,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start aty"
    },
    {
      "t": 13971,
      "e": 13971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14059,
      "e": 14059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at"
    },
    {
      "t": 14147,
      "e": 14147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14148,
      "e": 14148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14234,
      "e": 14234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14564,
      "e": 14564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "97"
    },
    {
      "t": 14564,
      "e": 14564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14699,
      "e": 14699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "98"
    },
    {
      "t": 14699,
      "e": 14699,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14715,
      "e": 14715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 14811,
      "e": 14811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15580,
      "e": 15580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 15581,
      "e": 15581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15587,
      "e": 15587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15587,
      "e": 15587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15634,
      "e": 15634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 15643,
      "e": 15643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16052,
      "e": 16052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16130,
      "e": 16130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12p"
    },
    {
      "t": 16723,
      "e": 16723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 16724,
      "e": 16724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16810,
      "e": 16810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 16971,
      "e": 16971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16971,
      "e": 16971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17114,
      "e": 17114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20002,
      "e": 20002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 24468,
      "e": 22114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 24468,
      "e": 22114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24604,
      "e": 22250,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12pm a"
    },
    {
      "t": 24611,
      "e": 22257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 24819,
      "e": 22465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 24819,
      "e": 22465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24962,
      "e": 22608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24962,
      "e": 22608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25026,
      "e": 22672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 25147,
      "e": 22793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25195,
      "e": 22841,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25196,
      "e": 22842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25323,
      "e": 22969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26835,
      "e": 24481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 26838,
      "e": 24484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26898,
      "e": 24544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 27005,
      "e": 24651,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12pm are p"
    },
    {
      "t": 27026,
      "e": 24672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 27026,
      "e": 24672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27098,
      "e": 24744,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 27203,
      "e": 24849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27203,
      "e": 24849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27266,
      "e": 24912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 27491,
      "e": 25137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27492,
      "e": 25138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27578,
      "e": 25224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27763,
      "e": 25409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27764,
      "e": 25410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27858,
      "e": 25504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27858,
      "e": 25504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27866,
      "e": 25512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||te"
    },
    {
      "t": 27979,
      "e": 25625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28403,
      "e": 26049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 28404,
      "e": 26050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28498,
      "e": 26144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 28605,
      "e": 26251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28605,
      "e": 26251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28666,
      "e": 26312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28746,
      "e": 26392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28747,
      "e": 26393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28859,
      "e": 26505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 28971,
      "e": 26617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28971,
      "e": 26617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29018,
      "e": 26664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 29315,
      "e": 26961,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 29434,
      "e": 27080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12pm are plotted a"
    },
    {
      "t": 30001,
      "e": 27647,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30122,
      "e": 27768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 30122,
      "e": 27768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30203,
      "e": 27849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 30283,
      "e": 27929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 30284,
      "e": 27930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30370,
      "e": 28016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30370,
      "e": 28016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30378,
      "e": 28024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 30442,
      "e": 28088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30915,
      "e": 28561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 30916,
      "e": 28562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30986,
      "e": 28632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 31034,
      "e": 28680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31034,
      "e": 28680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31106,
      "e": 28752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 31227,
      "e": 28873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 31228,
      "e": 28874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31298,
      "e": 28944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 31354,
      "e": 29000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31355,
      "e": 29001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31442,
      "e": 29088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 31514,
      "e": 29160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 31515,
      "e": 29161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31602,
      "e": 29248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 31746,
      "e": 29392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31748,
      "e": 29394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31843,
      "e": 29489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 32043,
      "e": 29689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 32044,
      "e": 29690,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32138,
      "e": 29784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 33314,
      "e": 30960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33316,
      "e": 30962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33386,
      "e": 31032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34667,
      "e": 32313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34668,
      "e": 32314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34807,
      "e": 32453,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12pm are plotted and labeled a"
    },
    {
      "t": 34846,
      "e": 32492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 35215,
      "e": 32861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35215,
      "e": 32861,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35221,
      "e": 32867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 35222,
      "e": 32868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35270,
      "e": 32916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ty"
    },
    {
      "t": 35278,
      "e": 32924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35407,
      "e": 33053,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12pm are plotted and labeled aty"
    },
    {
      "t": 35933,
      "e": 33579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "187"
    },
    {
      "t": 35934,
      "e": 33580,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36045,
      "e": 33691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||="
    },
    {
      "t": 36438,
      "e": 34084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36550,
      "e": 34196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12pm are plotted and labeled aty"
    },
    {
      "t": 36646,
      "e": 34292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36775,
      "e": 34421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12pm are plotted and labeled at"
    },
    {
      "t": 39662,
      "e": 37308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39807,
      "e": 37453,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12pm are plotted and labeled a"
    },
    {
      "t": 39862,
      "e": 37508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12pm are plotted and labeled a"
    },
    {
      "t": 39990,
      "e": 37636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40005,
      "e": 37651,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40125,
      "e": 37771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12pm are plotted and labeled "
    },
    {
      "t": 49704,
      "e": 42771,
      "ty": 2,
      "x": 1927,
      "y": 541
    },
    {
      "t": 49804,
      "e": 42871,
      "ty": 2,
      "x": 1927,
      "y": 629
    },
    {
      "t": 49905,
      "e": 42972,
      "ty": 2,
      "x": 1855,
      "y": 673
    },
    {
      "t": 50004,
      "e": 43071,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50007,
      "e": 43074,
      "ty": 41,
      "x": 63606,
      "y": 36839,
      "ta": "> div.stimulus"
    },
    {
      "t": 50904,
      "e": 43971,
      "ty": 2,
      "x": 1865,
      "y": 668
    },
    {
      "t": 51005,
      "e": 44072,
      "ty": 41,
      "x": 63950,
      "y": 36562,
      "ta": "> div.stimulus"
    },
    {
      "t": 51239,
      "e": 44306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 51239,
      "e": 44306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51366,
      "e": 44433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 51438,
      "e": 44505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51438,
      "e": 44505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51510,
      "e": 44577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 51622,
      "e": 44689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51623,
      "e": 44690,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51725,
      "e": 44792,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51822,
      "e": 44889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51822,
      "e": 44889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51886,
      "e": 44953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 51990,
      "e": 45057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 51991,
      "e": 45058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51998,
      "e": 45065,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51999,
      "e": 45066,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52061,
      "e": 45128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||gt"
    },
    {
      "t": 52093,
      "e": 45160,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52125,
      "e": 45192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 52126,
      "e": 45193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52205,
      "e": 45272,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 52526,
      "e": 45593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52597,
      "e": 45664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12pm are plotted and labeled at tgt"
    },
    {
      "t": 52726,
      "e": 45793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52798,
      "e": 45865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12pm are plotted and labeled at tg"
    },
    {
      "t": 52925,
      "e": 45992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 53013,
      "e": 46080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12pm are plotted and labeled at t"
    },
    {
      "t": 54366,
      "e": 47433,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 54367,
      "e": 47434,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54453,
      "e": 47520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 54461,
      "e": 47528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 54461,
      "e": 47528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54549,
      "e": 47616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54550,
      "e": 47617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54565,
      "e": 47632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 54638,
      "e": 47705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55342,
      "e": 48409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 55343,
      "e": 48410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55478,
      "e": 48545,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 55478,
      "e": 48545,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55533,
      "e": 48600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 55638,
      "e": 48705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55639,
      "e": 48706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55646,
      "e": 48713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55773,
      "e": 48840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 55878,
      "e": 48945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 55879,
      "e": 48946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55973,
      "e": 49040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 56070,
      "e": 49137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 56071,
      "e": 49138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56206,
      "e": 49273,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12pm are plotted and labeled at the 12 pm"
    },
    {
      "t": 56286,
      "e": 49353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 56470,
      "e": 49537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "9"
    },
    {
      "t": 56472,
      "e": 49539,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Events that start at 12pm are plotted and labeled at the 12 pm"
    },
    {
      "t": 56472,
      "e": 49539,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56473,
      "e": 49540,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 56581,
      "e": 49648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton",
      "v": "32"
    },
    {
      "t": 56581,
      "e": 49648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 56654,
      "e": 49721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton",
      "v": ""
    },
    {
      "t": 56742,
      "e": 49809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton",
      "v": ""
    },
    {
      "t": 56758,
      "e": 49825,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 56759,
      "e": 49826,
      "ty": 5,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 56764,
      "e": 49831,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 57604,
      "e": 50671,
      "ty": 2,
      "x": 1849,
      "y": 604
    },
    {
      "t": 57705,
      "e": 50772,
      "ty": 2,
      "x": 1581,
      "y": 177
    },
    {
      "t": 57755,
      "e": 50822,
      "ty": 41,
      "x": 29926,
      "y": 7700,
      "ta": "html > body"
    },
    {
      "t": 57765,
      "e": 50832,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 57804,
      "e": 50871,
      "ty": 2,
      "x": 590,
      "y": 175
    },
    {
      "t": 57905,
      "e": 50972,
      "ty": 2,
      "x": 695,
      "y": 273
    },
    {
      "t": 58005,
      "e": 51072,
      "ty": 2,
      "x": 773,
      "y": 394
    },
    {
      "t": 58005,
      "e": 51072,
      "ty": 41,
      "x": 26344,
      "y": 21383,
      "ta": "html > body"
    },
    {
      "t": 58058,
      "e": 51125,
      "ty": 3,
      "x": 773,
      "y": 394,
      "ta": "html > body"
    },
    {
      "t": 58146,
      "e": 51213,
      "ty": 4,
      "x": 26344,
      "y": 21383,
      "ta": "html > body"
    },
    {
      "t": 58146,
      "e": 51213,
      "ty": 5,
      "x": 773,
      "y": 394,
      "ta": "html > body"
    },
    {
      "t": 58504,
      "e": 51571,
      "ty": 2,
      "x": 774,
      "y": 395
    },
    {
      "t": 58505,
      "e": 51572,
      "ty": 41,
      "x": 26379,
      "y": 21438,
      "ta": "html > body"
    },
    {
      "t": 58604,
      "e": 51671,
      "ty": 2,
      "x": 1001,
      "y": 542
    },
    {
      "t": 58618,
      "e": 51685,
      "ty": 6,
      "x": 1017,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58705,
      "e": 51772,
      "ty": 2,
      "x": 1025,
      "y": 565
    },
    {
      "t": 58755,
      "e": 51822,
      "ty": 41,
      "x": 46934,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58785,
      "e": 51852,
      "ty": 7,
      "x": 1023,
      "y": 577,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58804,
      "e": 51871,
      "ty": 2,
      "x": 1023,
      "y": 577
    },
    {
      "t": 58890,
      "e": 51957,
      "ty": 3,
      "x": 1023,
      "y": 577,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 58986,
      "e": 52053,
      "ty": 4,
      "x": 46501,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 58987,
      "e": 52053,
      "ty": 5,
      "x": 1023,
      "y": 577,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 59005,
      "e": 52071,
      "ty": 41,
      "x": 46501,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 59085,
      "e": 52151,
      "ty": 6,
      "x": 1036,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59105,
      "e": 52171,
      "ty": 2,
      "x": 1038,
      "y": 573
    },
    {
      "t": 59204,
      "e": 52270,
      "ty": 2,
      "x": 1042,
      "y": 572
    },
    {
      "t": 59234,
      "e": 52300,
      "ty": 3,
      "x": 1042,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59235,
      "e": 52301,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59255,
      "e": 52321,
      "ty": 41,
      "x": 50611,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59345,
      "e": 52411,
      "ty": 4,
      "x": 50611,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59345,
      "e": 52411,
      "ty": 5,
      "x": 1042,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59504,
      "e": 52570,
      "ty": 2,
      "x": 1099,
      "y": 554
    },
    {
      "t": 59505,
      "e": 52571,
      "ty": 41,
      "x": 62939,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59519,
      "e": 52585,
      "ty": 7,
      "x": 1116,
      "y": 547,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59605,
      "e": 52671,
      "ty": 2,
      "x": 1155,
      "y": 534
    },
    {
      "t": 59755,
      "e": 52821,
      "ty": 41,
      "x": 39500,
      "y": 29138,
      "ta": "html > body"
    },
    {
      "t": 60245,
      "e": 53311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 60246,
      "e": 53312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60316,
      "e": 53382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 60445,
      "e": 53511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "100"
    },
    {
      "t": 60445,
      "e": 53511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60501,
      "e": 53567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "24"
    },
    {
      "t": 60606,
      "e": 53672,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "24"
    },
    {
      "t": 60804,
      "e": 53870,
      "ty": 2,
      "x": 1177,
      "y": 522
    },
    {
      "t": 60904,
      "e": 53970,
      "ty": 2,
      "x": 1288,
      "y": 446
    },
    {
      "t": 61005,
      "e": 54071,
      "ty": 2,
      "x": 1161,
      "y": 575
    },
    {
      "t": 61005,
      "e": 54071,
      "ty": 41,
      "x": 39706,
      "y": 31410,
      "ta": "html > body"
    },
    {
      "t": 61070,
      "e": 54136,
      "ty": 6,
      "x": 1100,
      "y": 652,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61103,
      "e": 54169,
      "ty": 7,
      "x": 1091,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61104,
      "e": 54170,
      "ty": 2,
      "x": 1091,
      "y": 668
    },
    {
      "t": 61204,
      "e": 54270,
      "ty": 2,
      "x": 1084,
      "y": 696
    },
    {
      "t": 61256,
      "e": 54322,
      "ty": 41,
      "x": 37054,
      "y": 37836,
      "ta": "html > body"
    },
    {
      "t": 61304,
      "e": 54370,
      "ty": 6,
      "x": 1093,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61306,
      "e": 54372,
      "ty": 2,
      "x": 1093,
      "y": 659
    },
    {
      "t": 61405,
      "e": 54471,
      "ty": 2,
      "x": 1094,
      "y": 655
    },
    {
      "t": 61411,
      "e": 54477,
      "ty": 3,
      "x": 1094,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61505,
      "e": 54571,
      "ty": 41,
      "x": 61858,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61545,
      "e": 54611,
      "ty": 4,
      "x": 61858,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61545,
      "e": 54611,
      "ty": 5,
      "x": 1094,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61705,
      "e": 54771,
      "ty": 2,
      "x": 1073,
      "y": 658
    },
    {
      "t": 61754,
      "e": 54820,
      "ty": 41,
      "x": 48015,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61805,
      "e": 54871,
      "ty": 2,
      "x": 1030,
      "y": 664
    },
    {
      "t": 61842,
      "e": 54908,
      "ty": 3,
      "x": 1030,
      "y": 664,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61844,
      "e": 54910,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "24"
    },
    {
      "t": 61844,
      "e": 54910,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 61845,
      "e": 54911,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61961,
      "e": 55027,
      "ty": 4,
      "x": 48015,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61961,
      "e": 55027,
      "ty": 5,
      "x": 1030,
      "y": 664,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62702,
      "e": 55768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 62854,
      "e": 55920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 62855,
      "e": 55921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62933,
      "e": 55999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "P"
    },
    {
      "t": 62981,
      "e": 56047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "P"
    },
    {
      "t": 63350,
      "e": 56416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 63351,
      "e": 56417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63429,
      "e": 56495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ph"
    },
    {
      "t": 63469,
      "e": 56535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 63470,
      "e": 56536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63550,
      "e": 56616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Phi"
    },
    {
      "t": 63662,
      "e": 56728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "76"
    },
    {
      "t": 63662,
      "e": 56728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63733,
      "e": 56799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Phil"
    },
    {
      "t": 63853,
      "e": 56919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 63854,
      "e": 56920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63862,
      "e": 56928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 63862,
      "e": 56928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63901,
      "e": 56967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||iu"
    },
    {
      "t": 63933,
      "e": 56999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 64086,
      "e": 57152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 64087,
      "e": 57153,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64149,
      "e": 57215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||p"
    },
    {
      "t": 64245,
      "e": 57311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 64245,
      "e": 57311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64390,
      "e": 57456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||p"
    },
    {
      "t": 64710,
      "e": 57776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 64797,
      "e": 57863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Philiup"
    },
    {
      "t": 64909,
      "e": 57975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 64998,
      "e": 58064,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Philiu"
    },
    {
      "t": 65309,
      "e": 58375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 65390,
      "e": 58456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Phili"
    },
    {
      "t": 65926,
      "e": 58992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 65927,
      "e": 58993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65989,
      "e": 59055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||p"
    },
    {
      "t": 66069,
      "e": 59135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "80"
    },
    {
      "t": 66069,
      "e": 59135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66141,
      "e": 59207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||p"
    },
    {
      "t": 66286,
      "e": 59352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 66286,
      "e": 59352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66357,
      "e": 59423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 66502,
      "e": 59568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 66502,
      "e": 59568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66581,
      "e": 59647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||n"
    },
    {
      "t": 66629,
      "e": 59695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 66630,
      "e": 59696,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66701,
      "e": 59767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 66807,
      "e": 59873,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Philippine"
    },
    {
      "t": 66838,
      "e": 59904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 66839,
      "e": 59905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66974,
      "e": 60040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 67105,
      "e": 60171,
      "ty": 2,
      "x": 1029,
      "y": 664
    },
    {
      "t": 67108,
      "e": 60174,
      "ty": 7,
      "x": 983,
      "y": 565,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67108,
      "e": 60174,
      "ty": 6,
      "x": 983,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67125,
      "e": 60191,
      "ty": 7,
      "x": 894,
      "y": 393,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67205,
      "e": 60271,
      "ty": 2,
      "x": 756,
      "y": 271
    },
    {
      "t": 67255,
      "e": 60321,
      "ty": 41,
      "x": 26310,
      "y": 15400,
      "ta": "html > body"
    },
    {
      "t": 67305,
      "e": 60371,
      "ty": 2,
      "x": 787,
      "y": 345
    },
    {
      "t": 67392,
      "e": 60458,
      "ty": 6,
      "x": 881,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67405,
      "e": 60471,
      "ty": 2,
      "x": 881,
      "y": 562
    },
    {
      "t": 67408,
      "e": 60474,
      "ty": 7,
      "x": 911,
      "y": 590,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 67505,
      "e": 60571,
      "ty": 2,
      "x": 963,
      "y": 632
    },
    {
      "t": 67505,
      "e": 60571,
      "ty": 41,
      "x": 33524,
      "y": 34529,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 67592,
      "e": 60658,
      "ty": 6,
      "x": 971,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67605,
      "e": 60671,
      "ty": 2,
      "x": 971,
      "y": 654
    },
    {
      "t": 67624,
      "e": 60690,
      "ty": 7,
      "x": 975,
      "y": 671,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67658,
      "e": 60724,
      "ty": 6,
      "x": 977,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67705,
      "e": 60771,
      "ty": 2,
      "x": 979,
      "y": 685
    },
    {
      "t": 67755,
      "e": 60821,
      "ty": 41,
      "x": 43332,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67805,
      "e": 60871,
      "ty": 2,
      "x": 980,
      "y": 687
    },
    {
      "t": 67818,
      "e": 60884,
      "ty": 3,
      "x": 980,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67818,
      "e": 60884,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Philippines"
    },
    {
      "t": 67820,
      "e": 60886,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67820,
      "e": 60886,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67905,
      "e": 60971,
      "ty": 4,
      "x": 43332,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67905,
      "e": 60971,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67906,
      "e": 60972,
      "ty": 5,
      "x": 980,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67907,
      "e": 60973,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 68606,
      "e": 61672,
      "ty": 2,
      "x": 980,
      "y": 688
    },
    {
      "t": 68705,
      "e": 61771,
      "ty": 2,
      "x": 979,
      "y": 689
    },
    {
      "t": 68755,
      "e": 61821,
      "ty": 41,
      "x": 33439,
      "y": 37725,
      "ta": "html > body"
    },
    {
      "t": 68905,
      "e": 61971,
      "ty": 2,
      "x": 976,
      "y": 691
    },
    {
      "t": 68929,
      "e": 61995,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 69005,
      "e": 61971,
      "ty": 41,
      "x": 36685,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 69405,
      "e": 62371,
      "ty": 2,
      "x": 975,
      "y": 692
    },
    {
      "t": 69505,
      "e": 62471,
      "ty": 2,
      "x": 975,
      "y": 630
    },
    {
      "t": 69505,
      "e": 62471,
      "ty": 41,
      "x": 36447,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 69605,
      "e": 62571,
      "ty": 2,
      "x": 937,
      "y": 201
    },
    {
      "t": 69705,
      "e": 62671,
      "ty": 2,
      "x": 933,
      "y": 183
    },
    {
      "t": 69756,
      "e": 62722,
      "ty": 41,
      "x": 26480,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 69905,
      "e": 62871,
      "ty": 2,
      "x": 925,
      "y": 193
    },
    {
      "t": 70006,
      "e": 62972,
      "ty": 2,
      "x": 877,
      "y": 228
    },
    {
      "t": 70006,
      "e": 62972,
      "ty": 41,
      "x": 13190,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 70205,
      "e": 63171,
      "ty": 2,
      "x": 876,
      "y": 270
    },
    {
      "t": 70256,
      "e": 63222,
      "ty": 41,
      "x": 41567,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 70305,
      "e": 63271,
      "ty": 2,
      "x": 878,
      "y": 272
    },
    {
      "t": 70405,
      "e": 63371,
      "ty": 2,
      "x": 892,
      "y": 238
    },
    {
      "t": 70506,
      "e": 63472,
      "ty": 41,
      "x": 57794,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70586,
      "e": 63552,
      "ty": 3,
      "x": 892,
      "y": 238,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70658,
      "e": 63624,
      "ty": 4,
      "x": 57794,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70659,
      "e": 63625,
      "ty": 5,
      "x": 892,
      "y": 238,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70659,
      "e": 63625,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 70661,
      "e": 63627,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 71405,
      "e": 64371,
      "ty": 2,
      "x": 892,
      "y": 249
    },
    {
      "t": 71505,
      "e": 64471,
      "ty": 2,
      "x": 893,
      "y": 260
    },
    {
      "t": 71506,
      "e": 64472,
      "ty": 41,
      "x": 54515,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 71605,
      "e": 64571,
      "ty": 2,
      "x": 893,
      "y": 302
    },
    {
      "t": 71705,
      "e": 64671,
      "ty": 2,
      "x": 871,
      "y": 409
    },
    {
      "t": 71755,
      "e": 64721,
      "ty": 41,
      "x": 10104,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 71805,
      "e": 64771,
      "ty": 2,
      "x": 864,
      "y": 427
    },
    {
      "t": 72806,
      "e": 65772,
      "ty": 2,
      "x": 870,
      "y": 468
    },
    {
      "t": 72906,
      "e": 65872,
      "ty": 2,
      "x": 878,
      "y": 495
    },
    {
      "t": 73005,
      "e": 65971,
      "ty": 2,
      "x": 879,
      "y": 496
    },
    {
      "t": 73005,
      "e": 65971,
      "ty": 41,
      "x": 51679,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 73205,
      "e": 66171,
      "ty": 2,
      "x": 880,
      "y": 497
    },
    {
      "t": 73256,
      "e": 66222,
      "ty": 41,
      "x": 54371,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 73305,
      "e": 66271,
      "ty": 2,
      "x": 884,
      "y": 502
    },
    {
      "t": 73406,
      "e": 66372,
      "ty": 2,
      "x": 884,
      "y": 503
    },
    {
      "t": 73505,
      "e": 66471,
      "ty": 2,
      "x": 884,
      "y": 501
    },
    {
      "t": 73506,
      "e": 66472,
      "ty": 41,
      "x": 56166,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 73605,
      "e": 66571,
      "ty": 2,
      "x": 881,
      "y": 472
    },
    {
      "t": 73705,
      "e": 66671,
      "ty": 2,
      "x": 880,
      "y": 469
    },
    {
      "t": 73756,
      "e": 66722,
      "ty": 41,
      "x": 61918,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 73851,
      "e": 66817,
      "ty": 3,
      "x": 880,
      "y": 469,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 73852,
      "e": 66818,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 73969,
      "e": 66935,
      "ty": 4,
      "x": 61918,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 73969,
      "e": 66935,
      "ty": 5,
      "x": 880,
      "y": 469,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 73969,
      "e": 66935,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 73970,
      "e": 66935,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 74406,
      "e": 67371,
      "ty": 2,
      "x": 881,
      "y": 466
    },
    {
      "t": 74506,
      "e": 67471,
      "ty": 41,
      "x": 62975,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 75106,
      "e": 68071,
      "ty": 2,
      "x": 840,
      "y": 576
    },
    {
      "t": 75205,
      "e": 68170,
      "ty": 2,
      "x": 824,
      "y": 658
    },
    {
      "t": 75256,
      "e": 68221,
      "ty": 41,
      "x": 611,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 75306,
      "e": 68271,
      "ty": 2,
      "x": 827,
      "y": 659
    },
    {
      "t": 75405,
      "e": 68370,
      "ty": 2,
      "x": 838,
      "y": 657
    },
    {
      "t": 75505,
      "e": 68470,
      "ty": 2,
      "x": 856,
      "y": 664
    },
    {
      "t": 75505,
      "e": 68470,
      "ty": 41,
      "x": 8206,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 75604,
      "e": 68569,
      "ty": 2,
      "x": 919,
      "y": 685
    },
    {
      "t": 75705,
      "e": 68670,
      "ty": 2,
      "x": 959,
      "y": 678
    },
    {
      "t": 75754,
      "e": 68719,
      "ty": 41,
      "x": 39624,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 75804,
      "e": 68769,
      "ty": 2,
      "x": 980,
      "y": 675
    },
    {
      "t": 75906,
      "e": 68871,
      "ty": 2,
      "x": 1030,
      "y": 675
    },
    {
      "t": 76005,
      "e": 68970,
      "ty": 2,
      "x": 1083,
      "y": 703
    },
    {
      "t": 76005,
      "e": 68970,
      "ty": 41,
      "x": 62078,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 76105,
      "e": 69070,
      "ty": 2,
      "x": 1100,
      "y": 745
    },
    {
      "t": 76205,
      "e": 69170,
      "ty": 2,
      "x": 1092,
      "y": 749
    },
    {
      "t": 76254,
      "e": 69219,
      "ty": 41,
      "x": 63028,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 76305,
      "e": 69270,
      "ty": 2,
      "x": 1084,
      "y": 748
    },
    {
      "t": 76404,
      "e": 69369,
      "ty": 2,
      "x": 1081,
      "y": 742
    },
    {
      "t": 76504,
      "e": 69469,
      "ty": 2,
      "x": 1075,
      "y": 724
    },
    {
      "t": 76505,
      "e": 69470,
      "ty": 41,
      "x": 63644,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 76605,
      "e": 69570,
      "ty": 2,
      "x": 1068,
      "y": 719
    },
    {
      "t": 76705,
      "e": 69670,
      "ty": 2,
      "x": 1064,
      "y": 717
    },
    {
      "t": 76755,
      "e": 69720,
      "ty": 41,
      "x": 57332,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 76804,
      "e": 69769,
      "ty": 2,
      "x": 1063,
      "y": 716
    },
    {
      "t": 77105,
      "e": 70070,
      "ty": 2,
      "x": 1069,
      "y": 720
    },
    {
      "t": 77204,
      "e": 70169,
      "ty": 2,
      "x": 1087,
      "y": 781
    },
    {
      "t": 77255,
      "e": 70220,
      "ty": 41,
      "x": 63028,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 77305,
      "e": 70270,
      "ty": 2,
      "x": 1079,
      "y": 777
    },
    {
      "t": 77404,
      "e": 70369,
      "ty": 2,
      "x": 1060,
      "y": 737
    },
    {
      "t": 77504,
      "e": 70469,
      "ty": 2,
      "x": 1053,
      "y": 703
    },
    {
      "t": 77505,
      "e": 70470,
      "ty": 41,
      "x": 58353,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 77730,
      "e": 70695,
      "ty": 3,
      "x": 1053,
      "y": 703,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 77731,
      "e": 70696,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 77816,
      "e": 70781,
      "ty": 4,
      "x": 58353,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 77816,
      "e": 70781,
      "ty": 5,
      "x": 1053,
      "y": 703,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 77817,
      "e": 70782,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 77818,
      "e": 70783,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 80005,
      "e": 72970,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80504,
      "e": 73469,
      "ty": 2,
      "x": 1005,
      "y": 809
    },
    {
      "t": 80505,
      "e": 73470,
      "ty": 41,
      "x": 43567,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 80605,
      "e": 73570,
      "ty": 2,
      "x": 958,
      "y": 906
    },
    {
      "t": 80704,
      "e": 73669,
      "ty": 2,
      "x": 944,
      "y": 924
    },
    {
      "t": 80754,
      "e": 73719,
      "ty": 41,
      "x": 21733,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 80805,
      "e": 73770,
      "ty": 2,
      "x": 906,
      "y": 969
    },
    {
      "t": 81005,
      "e": 73970,
      "ty": 2,
      "x": 905,
      "y": 966
    },
    {
      "t": 81005,
      "e": 73970,
      "ty": 41,
      "x": 19835,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 81104,
      "e": 74069,
      "ty": 2,
      "x": 901,
      "y": 960
    },
    {
      "t": 81136,
      "e": 74101,
      "ty": 3,
      "x": 901,
      "y": 960,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 81138,
      "e": 74103,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 81217,
      "e": 74182,
      "ty": 4,
      "x": 64372,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 81217,
      "e": 74182,
      "ty": 5,
      "x": 901,
      "y": 960,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 81217,
      "e": 74182,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 81218,
      "e": 74183,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 81255,
      "e": 74220,
      "ty": 41,
      "x": 64372,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 81305,
      "e": 74270,
      "ty": 2,
      "x": 906,
      "y": 968
    },
    {
      "t": 81353,
      "e": 74318,
      "ty": 6,
      "x": 926,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81404,
      "e": 74369,
      "ty": 2,
      "x": 931,
      "y": 1018
    },
    {
      "t": 81505,
      "e": 74470,
      "ty": 2,
      "x": 934,
      "y": 1024
    },
    {
      "t": 81505,
      "e": 74470,
      "ty": 41,
      "x": 53898,
      "y": 37732,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81650,
      "e": 74615,
      "ty": 3,
      "x": 935,
      "y": 1024,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81651,
      "e": 74616,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 81652,
      "e": 74617,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81689,
      "e": 74654,
      "ty": 4,
      "x": 54413,
      "y": 37732,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81689,
      "e": 74654,
      "ty": 5,
      "x": 935,
      "y": 1024,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81691,
      "e": 74656,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81692,
      "e": 74657,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 81692,
      "e": 74657,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 81704,
      "e": 74669,
      "ty": 2,
      "x": 935,
      "y": 1024
    },
    {
      "t": 81755,
      "e": 74720,
      "ty": 41,
      "x": 31923,
      "y": 56283,
      "ta": "html > body"
    },
    {
      "t": 81905,
      "e": 74870,
      "ty": 2,
      "x": 936,
      "y": 1024
    },
    {
      "t": 82004,
      "e": 74969,
      "ty": 2,
      "x": 936,
      "y": 1019
    },
    {
      "t": 82005,
      "e": 74970,
      "ty": 41,
      "x": 31958,
      "y": 56006,
      "ta": "html > body"
    },
    {
      "t": 82105,
      "e": 75070,
      "ty": 2,
      "x": 937,
      "y": 1015
    },
    {
      "t": 82204,
      "e": 75169,
      "ty": 2,
      "x": 937,
      "y": 1013
    },
    {
      "t": 82255,
      "e": 75220,
      "ty": 41,
      "x": 31992,
      "y": 55618,
      "ta": "html > body"
    },
    {
      "t": 82305,
      "e": 75270,
      "ty": 2,
      "x": 937,
      "y": 1012
    },
    {
      "t": 82404,
      "e": 75369,
      "ty": 2,
      "x": 937,
      "y": 1010
    },
    {
      "t": 82504,
      "e": 75469,
      "ty": 2,
      "x": 937,
      "y": 1009
    },
    {
      "t": 82505,
      "e": 75470,
      "ty": 41,
      "x": 31992,
      "y": 55452,
      "ta": "html > body"
    },
    {
      "t": 82604,
      "e": 75569,
      "ty": 2,
      "x": 937,
      "y": 1007
    },
    {
      "t": 82755,
      "e": 75720,
      "ty": 41,
      "x": 31992,
      "y": 55341,
      "ta": "html > body"
    },
    {
      "t": 83024,
      "e": 75989,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 83805,
      "e": 76770,
      "ty": 2,
      "x": 957,
      "y": 938
    },
    {
      "t": 83905,
      "e": 76870,
      "ty": 2,
      "x": 977,
      "y": 396
    },
    {
      "t": 84004,
      "e": 76969,
      "ty": 2,
      "x": 964,
      "y": 221
    },
    {
      "t": 84005,
      "e": 76970,
      "ty": 41,
      "x": 32988,
      "y": 6557,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 84104,
      "e": 77069,
      "ty": 2,
      "x": 892,
      "y": 116
    },
    {
      "t": 84205,
      "e": 77170,
      "ty": 2,
      "x": 864,
      "y": 43
    },
    {
      "t": 84254,
      "e": 77219,
      "ty": 41,
      "x": 29203,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 84304,
      "e": 77269,
      "ty": 2,
      "x": 835,
      "y": 0
    },
    {
      "t": 84405,
      "e": 77370,
      "ty": 2,
      "x": 852,
      "y": 0
    },
    {
      "t": 84504,
      "e": 77469,
      "ty": 2,
      "x": 931,
      "y": 0
    },
    {
      "t": 84505,
      "e": 77470,
      "ty": 41,
      "x": 32061,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 84605,
      "e": 77570,
      "ty": 2,
      "x": 1064,
      "y": 0
    },
    {
      "t": 84704,
      "e": 77669,
      "ty": 2,
      "x": 1139,
      "y": 0
    },
    {
      "t": 84755,
      "e": 77720,
      "ty": 41,
      "x": 39534,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 84805,
      "e": 77770,
      "ty": 2,
      "x": 1144,
      "y": 0
    },
    {
      "t": 84905,
      "e": 77870,
      "ty": 2,
      "x": 1046,
      "y": 0
    },
    {
      "t": 85005,
      "e": 77970,
      "ty": 2,
      "x": 979,
      "y": 0
    },
    {
      "t": 85005,
      "e": 77970,
      "ty": 41,
      "x": 33714,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 85105,
      "e": 78070,
      "ty": 2,
      "x": 962,
      "y": 0
    },
    {
      "t": 85255,
      "e": 78220,
      "ty": 41,
      "x": 33060,
      "y": 110,
      "ta": "html"
    },
    {
      "t": 85304,
      "e": 78269,
      "ty": 2,
      "x": 953,
      "y": 20
    },
    {
      "t": 85405,
      "e": 78370,
      "ty": 2,
      "x": 946,
      "y": 42
    },
    {
      "t": 85505,
      "e": 78470,
      "ty": 41,
      "x": 25960,
      "y": 18835,
      "ta": "> div.masterdiv > div"
    },
    {
      "t": 85805,
      "e": 78770,
      "ty": 2,
      "x": 945,
      "y": 43
    },
    {
      "t": 86006,
      "e": 78971,
      "ty": 41,
      "x": 25455,
      "y": 19389,
      "ta": "> div.masterdiv > div"
    },
    {
      "t": 86105,
      "e": 79070,
      "ty": 2,
      "x": 942,
      "y": 51
    },
    {
      "t": 86204,
      "e": 79169,
      "ty": 2,
      "x": 931,
      "y": 83
    },
    {
      "t": 86255,
      "e": 79220,
      "ty": 41,
      "x": 18392,
      "y": 41549,
      "ta": "> div.masterdiv > div"
    },
    {
      "t": 90005,
      "e": 82970,
      "ty": 2,
      "x": 967,
      "y": 249
    },
    {
      "t": 90005,
      "e": 82970,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90008,
      "e": 82973,
      "ty": 41,
      "x": 33136,
      "y": 8496,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 90105,
      "e": 83070,
      "ty": 2,
      "x": 1140,
      "y": 856
    },
    {
      "t": 90205,
      "e": 83170,
      "ty": 2,
      "x": 1229,
      "y": 1136
    },
    {
      "t": 90305,
      "e": 83270,
      "ty": 2,
      "x": 1237,
      "y": 1199
    },
    {
      "t": 90405,
      "e": 83370,
      "ty": 2,
      "x": 1081,
      "y": 1163
    },
    {
      "t": 90505,
      "e": 83470,
      "ty": 2,
      "x": 988,
      "y": 1125
    },
    {
      "t": 90505,
      "e": 83470,
      "ty": 41,
      "x": 46108,
      "y": 28980,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 90605,
      "e": 83570,
      "ty": 2,
      "x": 983,
      "y": 1122
    },
    {
      "t": 90755,
      "e": 83720,
      "ty": 41,
      "x": 43768,
      "y": 26210,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 90805,
      "e": 83770,
      "ty": 2,
      "x": 986,
      "y": 1116
    },
    {
      "t": 90876,
      "e": 83841,
      "ty": 6,
      "x": 994,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 90905,
      "e": 83870,
      "ty": 2,
      "x": 998,
      "y": 1102
    },
    {
      "t": 90943,
      "e": 83908,
      "ty": 7,
      "x": 1028,
      "y": 1053,
      "ta": "#start"
    },
    {
      "t": 91005,
      "e": 83970,
      "ty": 2,
      "x": 1060,
      "y": 944
    },
    {
      "t": 91005,
      "e": 83970,
      "ty": 41,
      "x": 37711,
      "y": 56623,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 91105,
      "e": 84070,
      "ty": 2,
      "x": 1036,
      "y": 862
    },
    {
      "t": 91205,
      "e": 84170,
      "ty": 2,
      "x": 1005,
      "y": 871
    },
    {
      "t": 91255,
      "e": 84220,
      "ty": 41,
      "x": 34022,
      "y": 33974,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 91305,
      "e": 84270,
      "ty": 2,
      "x": 984,
      "y": 889
    },
    {
      "t": 91315,
      "e": 84280,
      "ty": 3,
      "x": 984,
      "y": 889,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 91425,
      "e": 84390,
      "ty": 4,
      "x": 33972,
      "y": 38655,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 91427,
      "e": 84392,
      "ty": 5,
      "x": 984,
      "y": 889,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 91505,
      "e": 84470,
      "ty": 2,
      "x": 984,
      "y": 893
    },
    {
      "t": 91505,
      "e": 84470,
      "ty": 41,
      "x": 33972,
      "y": 48017,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 91605,
      "e": 84570,
      "ty": 2,
      "x": 978,
      "y": 962
    },
    {
      "t": 91705,
      "e": 84670,
      "ty": 2,
      "x": 962,
      "y": 1002
    },
    {
      "t": 91756,
      "e": 84721,
      "ty": 41,
      "x": 32890,
      "y": 60640,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92005,
      "e": 84970,
      "ty": 2,
      "x": 956,
      "y": 1026
    },
    {
      "t": 92005,
      "e": 84970,
      "ty": 41,
      "x": 32595,
      "y": 62302,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92105,
      "e": 85070,
      "ty": 2,
      "x": 954,
      "y": 1039
    },
    {
      "t": 92205,
      "e": 85170,
      "ty": 2,
      "x": 956,
      "y": 1045
    },
    {
      "t": 92255,
      "e": 85220,
      "ty": 41,
      "x": 32595,
      "y": 63617,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92304,
      "e": 85269,
      "ty": 2,
      "x": 960,
      "y": 1047
    },
    {
      "t": 92362,
      "e": 85327,
      "ty": 6,
      "x": 976,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 92405,
      "e": 85370,
      "ty": 2,
      "x": 980,
      "y": 1087
    },
    {
      "t": 92505,
      "e": 85470,
      "ty": 2,
      "x": 980,
      "y": 1088
    },
    {
      "t": 92505,
      "e": 85470,
      "ty": 41,
      "x": 38501,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 92554,
      "e": 85519,
      "ty": 3,
      "x": 980,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 92555,
      "e": 85520,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 92605,
      "e": 85570,
      "ty": 2,
      "x": 980,
      "y": 1089
    },
    {
      "t": 92656,
      "e": 85621,
      "ty": 4,
      "x": 38501,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 92657,
      "e": 85622,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 92657,
      "e": 85622,
      "ty": 5,
      "x": 980,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 92658,
      "e": 85623,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 92755,
      "e": 85720,
      "ty": 41,
      "x": 33473,
      "y": 59884,
      "ta": "html > body"
    },
    {
      "t": 93005,
      "e": 85970,
      "ty": 2,
      "x": 981,
      "y": 1089
    },
    {
      "t": 93005,
      "e": 85970,
      "ty": 41,
      "x": 33507,
      "y": 59884,
      "ta": "html > body"
    },
    {
      "t": 93105,
      "e": 86070,
      "ty": 2,
      "x": 982,
      "y": 1089
    },
    {
      "t": 93205,
      "e": 86170,
      "ty": 2,
      "x": 985,
      "y": 1086
    },
    {
      "t": 93256,
      "e": 86221,
      "ty": 41,
      "x": 33645,
      "y": 59607,
      "ta": "html > body"
    },
    {
      "t": 93305,
      "e": 86270,
      "ty": 2,
      "x": 987,
      "y": 1083
    },
    {
      "t": 93506,
      "e": 86471,
      "ty": 41,
      "x": 33714,
      "y": 59552,
      "ta": "html > body"
    },
    {
      "t": 93695,
      "e": 86660,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 94513,
      "e": 87478,
      "ty": 2,
      "x": 800,
      "y": 45
    },
    {
      "t": 94513,
      "e": 87478,
      "ty": 41,
      "x": 23583,
      "y": 32647,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 95208,
      "e": 88173,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 112492, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 112499, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 26247, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 140080, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 8653, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"bravo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 149737, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 25346, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 176173, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 25016, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 202192, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 55618, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 259187, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-12 PM-12 PM-11 AM-11 AM-6-11 AM-11 AM-11 AM-02 PM-10 AM-11 AM-10 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:915,y:446,t:1526922592824};\\\", \\\"{x:915,y:447,t:1526922592835};\\\", \\\"{x:915,y:449,t:1526922592852};\\\", \\\"{x:914,y:451,t:1526922592867};\\\", \\\"{x:914,y:452,t:1526922592885};\\\", \\\"{x:914,y:453,t:1526922592901};\\\", \\\"{x:912,y:453,t:1526922593144};\\\", \\\"{x:911,y:452,t:1526922593159};\\\", \\\"{x:909,y:451,t:1526922593169};\\\", \\\"{x:908,y:450,t:1526922593185};\\\", \\\"{x:905,y:447,t:1526922593202};\\\", \\\"{x:903,y:445,t:1526922593219};\\\", \\\"{x:900,y:441,t:1526922593235};\\\", \\\"{x:896,y:437,t:1526922593252};\\\", \\\"{x:892,y:432,t:1526922593269};\\\", \\\"{x:885,y:423,t:1526922593285};\\\", \\\"{x:881,y:418,t:1526922593302};\\\", \\\"{x:873,y:409,t:1526922593320};\\\", \\\"{x:870,y:407,t:1526922593336};\\\", \\\"{x:864,y:401,t:1526922593352};\\\", \\\"{x:861,y:398,t:1526922593369};\\\", \\\"{x:860,y:396,t:1526922593386};\\\", \\\"{x:859,y:394,t:1526922593402};\\\", \\\"{x:857,y:393,t:1526922593419};\\\", \\\"{x:856,y:392,t:1526922593435};\\\", \\\"{x:854,y:391,t:1526922593452};\\\", \\\"{x:853,y:389,t:1526922593470};\\\", \\\"{x:850,y:387,t:1526922593486};\\\", \\\"{x:847,y:385,t:1526922593503};\\\", \\\"{x:842,y:381,t:1526922593519};\\\", \\\"{x:838,y:380,t:1526922593536};\\\", \\\"{x:836,y:377,t:1526922593553};\\\", \\\"{x:834,y:376,t:1526922593570};\\\", \\\"{x:833,y:376,t:1526922593586};\\\", \\\"{x:832,y:374,t:1526922593603};\\\", \\\"{x:831,y:374,t:1526922593705};\\\", \\\"{x:830,y:374,t:1526922593744};\\\", \\\"{x:829,y:375,t:1526922593760};\\\", \\\"{x:828,y:375,t:1526922593985};\\\", \\\"{x:827,y:376,t:1526922594033};\\\", \\\"{x:826,y:376,t:1526922594064};\\\", \\\"{x:826,y:377,t:1526922594072};\\\", \\\"{x:826,y:378,t:1526922594096};\\\", \\\"{x:825,y:379,t:1526922594120};\\\", \\\"{x:824,y:379,t:1526922594168};\\\", \\\"{x:823,y:380,t:1526922595033};\\\", \\\"{x:823,y:378,t:1526922595049};\\\", \\\"{x:822,y:376,t:1526922595056};\\\", \\\"{x:820,y:373,t:1526922595071};\\\", \\\"{x:819,y:365,t:1526922595087};\\\", \\\"{x:816,y:361,t:1526922595104};\\\", \\\"{x:813,y:355,t:1526922595120};\\\", \\\"{x:812,y:351,t:1526922595137};\\\", \\\"{x:811,y:350,t:1526922595153};\\\", \\\"{x:810,y:349,t:1526922595170};\\\", \\\"{x:810,y:351,t:1526922595288};\\\", \\\"{x:812,y:361,t:1526922595304};\\\", \\\"{x:821,y:374,t:1526922595321};\\\", \\\"{x:831,y:389,t:1526922595338};\\\", \\\"{x:846,y:405,t:1526922595354};\\\", \\\"{x:865,y:421,t:1526922595371};\\\", \\\"{x:886,y:435,t:1526922595388};\\\", \\\"{x:903,y:447,t:1526922595405};\\\", \\\"{x:926,y:458,t:1526922595421};\\\", \\\"{x:944,y:464,t:1526922595437};\\\", \\\"{x:965,y:470,t:1526922595455};\\\", \\\"{x:986,y:473,t:1526922595471};\\\", \\\"{x:1004,y:474,t:1526922595487};\\\", \\\"{x:1012,y:474,t:1526922595504};\\\", \\\"{x:1018,y:473,t:1526922595521};\\\", \\\"{x:1030,y:466,t:1526922595537};\\\", \\\"{x:1055,y:456,t:1526922595554};\\\", \\\"{x:1096,y:442,t:1526922595571};\\\", \\\"{x:1171,y:429,t:1526922595587};\\\", \\\"{x:1256,y:424,t:1526922595604};\\\", \\\"{x:1335,y:420,t:1526922595621};\\\", \\\"{x:1407,y:420,t:1526922595638};\\\", \\\"{x:1474,y:420,t:1526922595655};\\\", \\\"{x:1527,y:420,t:1526922595671};\\\", \\\"{x:1559,y:424,t:1526922595688};\\\", \\\"{x:1558,y:424,t:1526922595761};\\\", \\\"{x:1555,y:424,t:1526922595770};\\\", \\\"{x:1546,y:435,t:1526922595788};\\\", \\\"{x:1535,y:447,t:1526922595805};\\\", \\\"{x:1526,y:457,t:1526922595821};\\\", \\\"{x:1517,y:471,t:1526922595838};\\\", \\\"{x:1502,y:489,t:1526922595855};\\\", \\\"{x:1456,y:519,t:1526922595872};\\\", \\\"{x:1408,y:535,t:1526922595889};\\\", \\\"{x:1358,y:547,t:1526922595905};\\\", \\\"{x:1295,y:554,t:1526922595922};\\\", \\\"{x:1239,y:554,t:1526922595938};\\\", \\\"{x:1171,y:550,t:1526922595955};\\\", \\\"{x:1100,y:554,t:1526922595972};\\\", \\\"{x:1077,y:544,t:1526922595988};\\\", \\\"{x:1047,y:518,t:1526922596005};\\\", \\\"{x:1025,y:496,t:1526922596022};\\\", \\\"{x:976,y:428,t:1526922596038};\\\", \\\"{x:951,y:334,t:1526922596054};\\\", \\\"{x:945,y:211,t:1526922596072};\\\", \\\"{x:965,y:126,t:1526922596088};\\\", \\\"{x:999,y:43,t:1526922596105};\\\", \\\"{x:1042,y:0,t:1526922596122};\\\", \\\"{x:1084,y:0,t:1526922596138};\\\", \\\"{x:1126,y:0,t:1526922596154};\\\", \\\"{x:1152,y:0,t:1526922596172};\\\", \\\"{x:1177,y:0,t:1526922596187};\\\", \\\"{x:1189,y:0,t:1526922596204};\\\", \\\"{x:1193,y:0,t:1526922596222};\\\", \\\"{x:1194,y:0,t:1526922596238};\\\", \\\"{x:1195,y:0,t:1526922596345};\\\", \\\"{x:1199,y:0,t:1526922596355};\\\", \\\"{x:1221,y:11,t:1526922596372};\\\", \\\"{x:1246,y:34,t:1526922596389};\\\", \\\"{x:1260,y:48,t:1526922596404};\\\", \\\"{x:1265,y:55,t:1526922596422};\\\", \\\"{x:1265,y:56,t:1526922596513};\\\", \\\"{x:1265,y:58,t:1526922596577};\\\", \\\"{x:1263,y:59,t:1526922596657};\\\", \\\"{x:1262,y:60,t:1526922596743};\\\", \\\"{x:1261,y:61,t:1526922596754};\\\", \\\"{x:1260,y:63,t:1526922596771};\\\", \\\"{x:1259,y:64,t:1526922596788};\\\", \\\"{x:1258,y:64,t:1526922596805};\\\", \\\"{x:1258,y:65,t:1526922596847};\\\", \\\"{x:1257,y:65,t:1526922596904};\\\", \\\"{x:1256,y:65,t:1526922596944};\\\", \\\"{x:1255,y:66,t:1526922596992};\\\", \\\"{x:1253,y:66,t:1526922597040};\\\", \\\"{x:1252,y:66,t:1526922597072};\\\", \\\"{x:1250,y:66,t:1526922597088};\\\", \\\"{x:1249,y:66,t:1526922597105};\\\", \\\"{x:1247,y:66,t:1526922597122};\\\", \\\"{x:1244,y:66,t:1526922597139};\\\", \\\"{x:1242,y:66,t:1526922597156};\\\", \\\"{x:1240,y:66,t:1526922597172};\\\", \\\"{x:1238,y:67,t:1526922597189};\\\", \\\"{x:1237,y:67,t:1526922597232};\\\", \\\"{x:1236,y:68,t:1526922597248};\\\", \\\"{x:1234,y:68,t:1526922597264};\\\", \\\"{x:1233,y:68,t:1526922597272};\\\", \\\"{x:1227,y:69,t:1526922597289};\\\", \\\"{x:1221,y:72,t:1526922597306};\\\", \\\"{x:1209,y:76,t:1526922597323};\\\", \\\"{x:1196,y:82,t:1526922597339};\\\", \\\"{x:1177,y:89,t:1526922597356};\\\", \\\"{x:1157,y:99,t:1526922597373};\\\", \\\"{x:1138,y:104,t:1526922597389};\\\", \\\"{x:1122,y:110,t:1526922597406};\\\", \\\"{x:1106,y:117,t:1526922597422};\\\", \\\"{x:1092,y:123,t:1526922597438};\\\", \\\"{x:1073,y:132,t:1526922597455};\\\", \\\"{x:1064,y:137,t:1526922597472};\\\", \\\"{x:1057,y:140,t:1526922597488};\\\", \\\"{x:1055,y:142,t:1526922597505};\\\", \\\"{x:1053,y:143,t:1526922597522};\\\", \\\"{x:1061,y:143,t:1526922597737};\\\", \\\"{x:1068,y:143,t:1526922597744};\\\", \\\"{x:1076,y:143,t:1526922597756};\\\", \\\"{x:1090,y:144,t:1526922597772};\\\", \\\"{x:1102,y:147,t:1526922597789};\\\", \\\"{x:1104,y:148,t:1526922597805};\\\", \\\"{x:1107,y:149,t:1526922597822};\\\", \\\"{x:1108,y:150,t:1526922599793};\\\", \\\"{x:1142,y:204,t:1526922599808};\\\", \\\"{x:1209,y:334,t:1526922599824};\\\", \\\"{x:1266,y:480,t:1526922599841};\\\", \\\"{x:1306,y:626,t:1526922599858};\\\", \\\"{x:1337,y:747,t:1526922599874};\\\", \\\"{x:1357,y:851,t:1526922599891};\\\", \\\"{x:1372,y:938,t:1526922599908};\\\", \\\"{x:1380,y:994,t:1526922599924};\\\", \\\"{x:1385,y:1046,t:1526922599941};\\\", \\\"{x:1385,y:1069,t:1526922599958};\\\", \\\"{x:1383,y:1086,t:1526922599974};\\\", \\\"{x:1380,y:1091,t:1526922599991};\\\", \\\"{x:1379,y:1096,t:1526922600008};\\\", \\\"{x:1379,y:1100,t:1526922600024};\\\", \\\"{x:1383,y:1110,t:1526922600041};\\\", \\\"{x:1395,y:1124,t:1526922600058};\\\", \\\"{x:1406,y:1141,t:1526922600074};\\\", \\\"{x:1414,y:1156,t:1526922600091};\\\", \\\"{x:1423,y:1168,t:1526922600107};\\\", \\\"{x:1427,y:1181,t:1526922600124};\\\", \\\"{x:1430,y:1193,t:1526922600141};\\\", \\\"{x:1432,y:1199,t:1526922600157};\\\", \\\"{x:1433,y:1199,t:1526922600175};\\\", \\\"{x:1435,y:1199,t:1526922600231};\\\", \\\"{x:1439,y:1199,t:1526922600241};\\\", \\\"{x:1448,y:1199,t:1526922600259};\\\", \\\"{x:1462,y:1199,t:1526922600274};\\\", \\\"{x:1476,y:1199,t:1526922600291};\\\", \\\"{x:1487,y:1199,t:1526922600308};\\\", \\\"{x:1494,y:1199,t:1526922600325};\\\", \\\"{x:1495,y:1199,t:1526922600495};\\\", \\\"{x:1495,y:1198,t:1526922600519};\\\", \\\"{x:1625,y:1176,t:1526922601192};\\\", \\\"{x:1617,y:1175,t:1526922601248};\\\", \\\"{x:1606,y:1175,t:1526922601259};\\\", \\\"{x:1581,y:1172,t:1526922601276};\\\", \\\"{x:1547,y:1172,t:1526922601293};\\\", \\\"{x:1503,y:1168,t:1526922601309};\\\", \\\"{x:1467,y:1165,t:1526922601326};\\\", \\\"{x:1436,y:1162,t:1526922601343};\\\", \\\"{x:1413,y:1157,t:1526922601359};\\\", \\\"{x:1375,y:1147,t:1526922601376};\\\", \\\"{x:1351,y:1135,t:1526922601393};\\\", \\\"{x:1318,y:1116,t:1526922601408};\\\", \\\"{x:1279,y:1089,t:1526922601426};\\\", \\\"{x:1252,y:1069,t:1526922601443};\\\", \\\"{x:1232,y:1053,t:1526922601459};\\\", \\\"{x:1218,y:1040,t:1526922601476};\\\", \\\"{x:1210,y:1031,t:1526922601492};\\\", \\\"{x:1207,y:1026,t:1526922601508};\\\", \\\"{x:1206,y:1022,t:1526922601526};\\\", \\\"{x:1206,y:1014,t:1526922601542};\\\", \\\"{x:1206,y:1001,t:1526922601559};\\\", \\\"{x:1216,y:983,t:1526922601576};\\\", \\\"{x:1228,y:973,t:1526922601593};\\\", \\\"{x:1241,y:965,t:1526922601610};\\\", \\\"{x:1258,y:962,t:1526922601625};\\\", \\\"{x:1284,y:961,t:1526922601643};\\\", \\\"{x:1315,y:961,t:1526922601660};\\\", \\\"{x:1352,y:968,t:1526922601677};\\\", \\\"{x:1392,y:981,t:1526922601693};\\\", \\\"{x:1416,y:993,t:1526922601710};\\\", \\\"{x:1432,y:998,t:1526922601725};\\\", \\\"{x:1433,y:999,t:1526922601742};\\\", \\\"{x:1428,y:999,t:1526922601791};\\\", \\\"{x:1420,y:997,t:1526922601799};\\\", \\\"{x:1409,y:995,t:1526922601810};\\\", \\\"{x:1381,y:988,t:1526922601825};\\\", \\\"{x:1338,y:975,t:1526922601842};\\\", \\\"{x:1296,y:963,t:1526922601859};\\\", \\\"{x:1266,y:955,t:1526922601877};\\\", \\\"{x:1245,y:948,t:1526922601893};\\\", \\\"{x:1226,y:943,t:1526922601910};\\\", \\\"{x:1208,y:937,t:1526922601926};\\\", \\\"{x:1188,y:926,t:1526922601943};\\\", \\\"{x:1165,y:913,t:1526922601959};\\\", \\\"{x:1171,y:918,t:1526922602073};\\\", \\\"{x:1184,y:928,t:1526922602082};\\\", \\\"{x:1198,y:936,t:1526922602092};\\\", \\\"{x:1245,y:967,t:1526922602110};\\\", \\\"{x:1295,y:1002,t:1526922602126};\\\", \\\"{x:1345,y:1035,t:1526922602142};\\\", \\\"{x:1375,y:1052,t:1526922602159};\\\", \\\"{x:1377,y:1052,t:1526922602176};\\\", \\\"{x:1378,y:1052,t:1526922602192};\\\", \\\"{x:1378,y:1051,t:1526922602224};\\\", \\\"{x:1375,y:1047,t:1526922602231};\\\", \\\"{x:1371,y:1041,t:1526922602243};\\\", \\\"{x:1354,y:1010,t:1526922602260};\\\", \\\"{x:1325,y:972,t:1526922602276};\\\", \\\"{x:1291,y:933,t:1526922602292};\\\", \\\"{x:1269,y:910,t:1526922602309};\\\", \\\"{x:1236,y:881,t:1526922602326};\\\", \\\"{x:1216,y:869,t:1526922602343};\\\", \\\"{x:1207,y:865,t:1526922602360};\\\", \\\"{x:1207,y:867,t:1526922602417};\\\", \\\"{x:1211,y:876,t:1526922602427};\\\", \\\"{x:1248,y:906,t:1526922602445};\\\", \\\"{x:1287,y:941,t:1526922602460};\\\", \\\"{x:1322,y:976,t:1526922602478};\\\", \\\"{x:1346,y:995,t:1526922602494};\\\", \\\"{x:1362,y:1006,t:1526922602510};\\\", \\\"{x:1371,y:1009,t:1526922602527};\\\", \\\"{x:1372,y:1009,t:1526922602607};\\\", \\\"{x:1372,y:1008,t:1526922602623};\\\", \\\"{x:1372,y:1007,t:1526922602631};\\\", \\\"{x:1372,y:1005,t:1526922602643};\\\", \\\"{x:1370,y:1001,t:1526922602659};\\\", \\\"{x:1366,y:997,t:1526922602677};\\\", \\\"{x:1363,y:995,t:1526922602694};\\\", \\\"{x:1347,y:988,t:1526922602709};\\\", \\\"{x:1328,y:983,t:1526922602727};\\\", \\\"{x:1311,y:978,t:1526922602744};\\\", \\\"{x:1304,y:975,t:1526922602761};\\\", \\\"{x:1300,y:975,t:1526922602777};\\\", \\\"{x:1298,y:974,t:1526922602794};\\\", \\\"{x:1297,y:974,t:1526922602881};\\\", \\\"{x:1296,y:974,t:1526922602894};\\\", \\\"{x:1295,y:974,t:1526922602911};\\\", \\\"{x:1294,y:974,t:1526922602952};\\\", \\\"{x:1295,y:973,t:1526922603056};\\\", \\\"{x:1296,y:973,t:1526922603064};\\\", \\\"{x:1296,y:972,t:1526922603077};\\\", \\\"{x:1297,y:971,t:1526922603094};\\\", \\\"{x:1298,y:970,t:1526922603144};\\\", \\\"{x:1299,y:971,t:1526922603161};\\\", \\\"{x:1299,y:974,t:1526922603177};\\\", \\\"{x:1300,y:978,t:1526922603194};\\\", \\\"{x:1300,y:981,t:1526922603211};\\\", \\\"{x:1300,y:982,t:1526922603227};\\\", \\\"{x:1300,y:983,t:1526922603352};\\\", \\\"{x:1299,y:983,t:1526922603361};\\\", \\\"{x:1292,y:980,t:1526922603378};\\\", \\\"{x:1288,y:976,t:1526922603394};\\\", \\\"{x:1282,y:972,t:1526922603411};\\\", \\\"{x:1279,y:970,t:1526922603428};\\\", \\\"{x:1278,y:969,t:1526922603444};\\\", \\\"{x:1277,y:968,t:1526922603461};\\\", \\\"{x:1277,y:967,t:1526922603478};\\\", \\\"{x:1276,y:966,t:1526922603512};\\\", \\\"{x:1276,y:964,t:1526922603536};\\\", \\\"{x:1276,y:963,t:1526922603544};\\\", \\\"{x:1276,y:960,t:1526922603562};\\\", \\\"{x:1276,y:958,t:1526922603578};\\\", \\\"{x:1276,y:956,t:1526922603594};\\\", \\\"{x:1276,y:954,t:1526922603611};\\\", \\\"{x:1276,y:953,t:1526922603628};\\\", \\\"{x:1276,y:950,t:1526922603644};\\\", \\\"{x:1276,y:949,t:1526922603661};\\\", \\\"{x:1276,y:947,t:1526922603678};\\\", \\\"{x:1276,y:946,t:1526922603694};\\\", \\\"{x:1276,y:944,t:1526922603712};\\\", \\\"{x:1276,y:938,t:1526922603728};\\\", \\\"{x:1276,y:933,t:1526922603745};\\\", \\\"{x:1276,y:927,t:1526922603761};\\\", \\\"{x:1276,y:919,t:1526922603778};\\\", \\\"{x:1276,y:909,t:1526922603795};\\\", \\\"{x:1275,y:898,t:1526922603811};\\\", \\\"{x:1274,y:885,t:1526922603828};\\\", \\\"{x:1274,y:875,t:1526922603845};\\\", \\\"{x:1274,y:865,t:1526922603861};\\\", \\\"{x:1274,y:854,t:1526922603878};\\\", \\\"{x:1274,y:848,t:1526922603896};\\\", \\\"{x:1274,y:842,t:1526922603911};\\\", \\\"{x:1274,y:839,t:1526922603928};\\\", \\\"{x:1274,y:838,t:1526922603945};\\\", \\\"{x:1274,y:836,t:1526922603961};\\\", \\\"{x:1274,y:835,t:1526922603978};\\\", \\\"{x:1274,y:833,t:1526922603995};\\\", \\\"{x:1274,y:832,t:1526922604012};\\\", \\\"{x:1274,y:830,t:1526922604028};\\\", \\\"{x:1274,y:829,t:1526922604044};\\\", \\\"{x:1274,y:827,t:1526922604061};\\\", \\\"{x:1275,y:825,t:1526922604077};\\\", \\\"{x:1275,y:824,t:1526922604094};\\\", \\\"{x:1275,y:820,t:1526922604111};\\\", \\\"{x:1276,y:819,t:1526922604127};\\\", \\\"{x:1276,y:817,t:1526922604144};\\\", \\\"{x:1276,y:814,t:1526922604161};\\\", \\\"{x:1276,y:812,t:1526922604177};\\\", \\\"{x:1277,y:810,t:1526922604194};\\\", \\\"{x:1277,y:807,t:1526922604211};\\\", \\\"{x:1278,y:804,t:1526922604227};\\\", \\\"{x:1278,y:801,t:1526922604245};\\\", \\\"{x:1278,y:797,t:1526922604261};\\\", \\\"{x:1278,y:795,t:1526922604277};\\\", \\\"{x:1278,y:793,t:1526922604294};\\\", \\\"{x:1278,y:788,t:1526922604311};\\\", \\\"{x:1278,y:787,t:1526922604327};\\\", \\\"{x:1278,y:784,t:1526922604345};\\\", \\\"{x:1278,y:783,t:1526922604375};\\\", \\\"{x:1279,y:781,t:1526922604422};\\\", \\\"{x:1279,y:779,t:1526922604519};\\\", \\\"{x:1279,y:778,t:1526922604535};\\\", \\\"{x:1279,y:777,t:1526922604550};\\\", \\\"{x:1279,y:776,t:1526922604561};\\\", \\\"{x:1279,y:775,t:1526922604579};\\\", \\\"{x:1279,y:773,t:1526922604594};\\\", \\\"{x:1279,y:772,t:1526922604612};\\\", \\\"{x:1279,y:769,t:1526922604629};\\\", \\\"{x:1278,y:766,t:1526922604644};\\\", \\\"{x:1278,y:765,t:1526922604662};\\\", \\\"{x:1278,y:761,t:1526922604679};\\\", \\\"{x:1277,y:759,t:1526922604695};\\\", \\\"{x:1276,y:755,t:1526922604711};\\\", \\\"{x:1276,y:753,t:1526922604728};\\\", \\\"{x:1275,y:750,t:1526922604744};\\\", \\\"{x:1275,y:749,t:1526922604761};\\\", \\\"{x:1275,y:747,t:1526922604778};\\\", \\\"{x:1274,y:745,t:1526922604795};\\\", \\\"{x:1274,y:742,t:1526922604811};\\\", \\\"{x:1274,y:741,t:1526922604828};\\\", \\\"{x:1274,y:740,t:1526922604844};\\\", \\\"{x:1274,y:737,t:1526922604861};\\\", \\\"{x:1274,y:734,t:1526922604879};\\\", \\\"{x:1274,y:732,t:1526922604895};\\\", \\\"{x:1274,y:730,t:1526922604911};\\\", \\\"{x:1274,y:728,t:1526922604928};\\\", \\\"{x:1274,y:724,t:1526922604945};\\\", \\\"{x:1274,y:721,t:1526922604961};\\\", \\\"{x:1274,y:717,t:1526922604978};\\\", \\\"{x:1274,y:714,t:1526922604995};\\\", \\\"{x:1272,y:709,t:1526922605012};\\\", \\\"{x:1272,y:706,t:1526922605028};\\\", \\\"{x:1272,y:701,t:1526922605046};\\\", \\\"{x:1271,y:698,t:1526922605061};\\\", \\\"{x:1270,y:692,t:1526922605079};\\\", \\\"{x:1270,y:689,t:1526922605095};\\\", \\\"{x:1270,y:687,t:1526922605111};\\\", \\\"{x:1270,y:684,t:1526922605129};\\\", \\\"{x:1270,y:680,t:1526922605145};\\\", \\\"{x:1271,y:677,t:1526922605161};\\\", \\\"{x:1271,y:673,t:1526922605179};\\\", \\\"{x:1273,y:668,t:1526922605196};\\\", \\\"{x:1274,y:662,t:1526922605211};\\\", \\\"{x:1276,y:654,t:1526922605228};\\\", \\\"{x:1278,y:650,t:1526922605245};\\\", \\\"{x:1280,y:646,t:1526922605262};\\\", \\\"{x:1281,y:642,t:1526922605278};\\\", \\\"{x:1283,y:640,t:1526922605295};\\\", \\\"{x:1283,y:638,t:1526922605312};\\\", \\\"{x:1284,y:636,t:1526922605328};\\\", \\\"{x:1284,y:634,t:1526922605346};\\\", \\\"{x:1284,y:633,t:1526922605361};\\\", \\\"{x:1284,y:632,t:1526922605383};\\\", \\\"{x:1284,y:631,t:1526922605395};\\\", \\\"{x:1284,y:629,t:1526922605412};\\\", \\\"{x:1284,y:628,t:1526922605429};\\\", \\\"{x:1284,y:627,t:1526922605445};\\\", \\\"{x:1284,y:626,t:1526922605463};\\\", \\\"{x:1284,y:625,t:1526922605478};\\\", \\\"{x:1284,y:624,t:1526922605495};\\\", \\\"{x:1284,y:623,t:1526922605512};\\\", \\\"{x:1285,y:621,t:1526922605529};\\\", \\\"{x:1286,y:621,t:1526922605546};\\\", \\\"{x:1286,y:618,t:1526922605562};\\\", \\\"{x:1286,y:616,t:1526922605578};\\\", \\\"{x:1286,y:615,t:1526922605595};\\\", \\\"{x:1286,y:613,t:1526922605613};\\\", \\\"{x:1286,y:612,t:1526922605628};\\\", \\\"{x:1287,y:610,t:1526922605645};\\\", \\\"{x:1287,y:608,t:1526922605663};\\\", \\\"{x:1287,y:605,t:1526922605679};\\\", \\\"{x:1287,y:603,t:1526922605695};\\\", \\\"{x:1287,y:600,t:1526922605712};\\\", \\\"{x:1287,y:599,t:1526922605729};\\\", \\\"{x:1287,y:596,t:1526922605746};\\\", \\\"{x:1287,y:593,t:1526922605762};\\\", \\\"{x:1287,y:590,t:1526922605780};\\\", \\\"{x:1287,y:587,t:1526922605795};\\\", \\\"{x:1287,y:584,t:1526922605813};\\\", \\\"{x:1287,y:583,t:1526922605829};\\\", \\\"{x:1287,y:580,t:1526922605845};\\\", \\\"{x:1287,y:578,t:1526922605863};\\\", \\\"{x:1287,y:575,t:1526922605879};\\\", \\\"{x:1287,y:574,t:1526922605896};\\\", \\\"{x:1287,y:572,t:1526922605913};\\\", \\\"{x:1287,y:571,t:1526922605929};\\\", \\\"{x:1287,y:570,t:1526922605959};\\\", \\\"{x:1287,y:569,t:1526922605975};\\\", \\\"{x:1287,y:568,t:1526922605999};\\\", \\\"{x:1287,y:567,t:1526922606048};\\\", \\\"{x:1287,y:566,t:1526922606063};\\\", \\\"{x:1287,y:565,t:1526922606079};\\\", \\\"{x:1287,y:564,t:1526922606095};\\\", \\\"{x:1287,y:563,t:1526922606112};\\\", \\\"{x:1287,y:562,t:1526922606129};\\\", \\\"{x:1287,y:561,t:1526922606146};\\\", \\\"{x:1287,y:560,t:1526922606162};\\\", \\\"{x:1287,y:559,t:1526922606179};\\\", \\\"{x:1287,y:558,t:1526922606503};\\\", \\\"{x:1287,y:557,t:1526922607039};\\\", \\\"{x:1287,y:556,t:1526922607054};\\\", \\\"{x:1287,y:555,t:1526922607079};\\\", \\\"{x:1287,y:553,t:1526922607097};\\\", \\\"{x:1287,y:552,t:1526922607114};\\\", \\\"{x:1287,y:536,t:1526922607129};\\\", \\\"{x:1287,y:528,t:1526922607147};\\\", \\\"{x:1287,y:526,t:1526922607163};\\\", \\\"{x:1288,y:522,t:1526922607180};\\\", \\\"{x:1288,y:518,t:1526922607197};\\\", \\\"{x:1288,y:516,t:1526922607215};\\\", \\\"{x:1289,y:515,t:1526922607231};\\\", \\\"{x:1289,y:516,t:1526922607759};\\\", \\\"{x:1289,y:519,t:1526922607767};\\\", \\\"{x:1290,y:522,t:1526922607780};\\\", \\\"{x:1290,y:526,t:1526922607798};\\\", \\\"{x:1293,y:533,t:1526922607814};\\\", \\\"{x:1294,y:537,t:1526922607831};\\\", \\\"{x:1295,y:545,t:1526922607846};\\\", \\\"{x:1298,y:554,t:1526922607864};\\\", \\\"{x:1299,y:563,t:1526922607880};\\\", \\\"{x:1307,y:580,t:1526922607898};\\\", \\\"{x:1315,y:604,t:1526922607913};\\\", \\\"{x:1320,y:620,t:1526922607930};\\\", \\\"{x:1329,y:638,t:1526922607948};\\\", \\\"{x:1337,y:659,t:1526922607963};\\\", \\\"{x:1341,y:673,t:1526922607981};\\\", \\\"{x:1345,y:687,t:1526922607997};\\\", \\\"{x:1347,y:702,t:1526922608015};\\\", \\\"{x:1351,y:720,t:1526922608031};\\\", \\\"{x:1352,y:731,t:1526922608047};\\\", \\\"{x:1353,y:738,t:1526922608065};\\\", \\\"{x:1353,y:745,t:1526922608081};\\\", \\\"{x:1353,y:756,t:1526922608098};\\\", \\\"{x:1353,y:764,t:1526922608115};\\\", \\\"{x:1353,y:774,t:1526922608130};\\\", \\\"{x:1353,y:783,t:1526922608147};\\\", \\\"{x:1349,y:793,t:1526922608165};\\\", \\\"{x:1348,y:802,t:1526922608180};\\\", \\\"{x:1345,y:815,t:1526922608197};\\\", \\\"{x:1343,y:829,t:1526922608214};\\\", \\\"{x:1340,y:841,t:1526922608231};\\\", \\\"{x:1336,y:859,t:1526922608247};\\\", \\\"{x:1334,y:871,t:1526922608264};\\\", \\\"{x:1330,y:881,t:1526922608281};\\\", \\\"{x:1328,y:893,t:1526922608298};\\\", \\\"{x:1324,y:904,t:1526922608314};\\\", \\\"{x:1321,y:915,t:1526922608330};\\\", \\\"{x:1318,y:925,t:1526922608348};\\\", \\\"{x:1314,y:932,t:1526922608364};\\\", \\\"{x:1310,y:938,t:1526922608380};\\\", \\\"{x:1307,y:943,t:1526922608397};\\\", \\\"{x:1305,y:945,t:1526922608415};\\\", \\\"{x:1302,y:949,t:1526922608431};\\\", \\\"{x:1300,y:951,t:1526922608447};\\\", \\\"{x:1298,y:953,t:1526922608464};\\\", \\\"{x:1297,y:954,t:1526922608481};\\\", \\\"{x:1296,y:955,t:1526922608498};\\\", \\\"{x:1295,y:956,t:1526922608515};\\\", \\\"{x:1294,y:957,t:1526922608531};\\\", \\\"{x:1293,y:957,t:1526922608547};\\\", \\\"{x:1292,y:958,t:1526922608564};\\\", \\\"{x:1292,y:959,t:1526922608581};\\\", \\\"{x:1291,y:961,t:1526922608598};\\\", \\\"{x:1291,y:963,t:1526922608615};\\\", \\\"{x:1290,y:965,t:1526922608631};\\\", \\\"{x:1288,y:970,t:1526922608647};\\\", \\\"{x:1288,y:971,t:1526922608665};\\\", \\\"{x:1287,y:974,t:1526922608681};\\\", \\\"{x:1287,y:975,t:1526922608698};\\\", \\\"{x:1285,y:977,t:1526922608714};\\\", \\\"{x:1284,y:977,t:1526922608831};\\\", \\\"{x:1283,y:976,t:1526922608849};\\\", \\\"{x:1283,y:975,t:1526922608865};\\\", \\\"{x:1283,y:974,t:1526922608881};\\\", \\\"{x:1283,y:972,t:1526922608899};\\\", \\\"{x:1283,y:970,t:1526922608915};\\\", \\\"{x:1283,y:968,t:1526922608932};\\\", \\\"{x:1284,y:967,t:1526922608949};\\\", \\\"{x:1285,y:966,t:1526922608965};\\\", \\\"{x:1285,y:964,t:1526922609087};\\\", \\\"{x:1285,y:962,t:1526922609103};\\\", \\\"{x:1285,y:961,t:1526922609114};\\\", \\\"{x:1285,y:959,t:1526922609132};\\\", \\\"{x:1285,y:958,t:1526922609148};\\\", \\\"{x:1285,y:954,t:1526922609164};\\\", \\\"{x:1285,y:951,t:1526922609181};\\\", \\\"{x:1285,y:948,t:1526922609198};\\\", \\\"{x:1285,y:944,t:1526922609215};\\\", \\\"{x:1285,y:942,t:1526922609231};\\\", \\\"{x:1285,y:939,t:1526922609248};\\\", \\\"{x:1285,y:936,t:1526922609265};\\\", \\\"{x:1284,y:932,t:1526922609282};\\\", \\\"{x:1284,y:928,t:1526922609298};\\\", \\\"{x:1284,y:921,t:1526922609315};\\\", \\\"{x:1283,y:912,t:1526922609331};\\\", \\\"{x:1283,y:902,t:1526922609349};\\\", \\\"{x:1281,y:895,t:1526922609366};\\\", \\\"{x:1280,y:887,t:1526922609381};\\\", \\\"{x:1279,y:878,t:1526922609398};\\\", \\\"{x:1276,y:868,t:1526922609415};\\\", \\\"{x:1274,y:861,t:1526922609432};\\\", \\\"{x:1272,y:852,t:1526922609449};\\\", \\\"{x:1270,y:846,t:1526922609465};\\\", \\\"{x:1270,y:841,t:1526922609481};\\\", \\\"{x:1269,y:838,t:1526922609499};\\\", \\\"{x:1269,y:837,t:1526922609516};\\\", \\\"{x:1269,y:836,t:1526922609532};\\\", \\\"{x:1269,y:835,t:1526922609550};\\\", \\\"{x:1269,y:834,t:1526922609574};\\\", \\\"{x:1269,y:833,t:1526922609606};\\\", \\\"{x:1269,y:832,t:1526922609647};\\\", \\\"{x:1270,y:830,t:1526922609903};\\\", \\\"{x:1271,y:830,t:1526922609916};\\\", \\\"{x:1272,y:829,t:1526922609942};\\\", \\\"{x:1274,y:828,t:1526922609967};\\\", \\\"{x:1275,y:828,t:1526922609982};\\\", \\\"{x:1275,y:827,t:1526922609998};\\\", \\\"{x:1276,y:827,t:1526922610047};\\\", \\\"{x:1277,y:825,t:1526922610087};\\\", \\\"{x:1277,y:824,t:1526922610111};\\\", \\\"{x:1278,y:823,t:1526922610151};\\\", \\\"{x:1278,y:822,t:1526922610215};\\\", \\\"{x:1278,y:821,t:1526922610535};\\\", \\\"{x:1278,y:817,t:1526922610550};\\\", \\\"{x:1278,y:811,t:1526922610566};\\\", \\\"{x:1278,y:801,t:1526922610583};\\\", \\\"{x:1278,y:794,t:1526922610599};\\\", \\\"{x:1278,y:787,t:1526922610616};\\\", \\\"{x:1278,y:781,t:1526922610632};\\\", \\\"{x:1279,y:774,t:1526922610649};\\\", \\\"{x:1279,y:767,t:1526922610666};\\\", \\\"{x:1279,y:759,t:1526922610683};\\\", \\\"{x:1281,y:754,t:1526922610700};\\\", \\\"{x:1281,y:751,t:1526922610717};\\\", \\\"{x:1282,y:747,t:1526922610733};\\\", \\\"{x:1282,y:745,t:1526922610750};\\\", \\\"{x:1282,y:742,t:1526922610766};\\\", \\\"{x:1282,y:740,t:1526922610782};\\\", \\\"{x:1282,y:738,t:1526922610799};\\\", \\\"{x:1282,y:737,t:1526922610816};\\\", \\\"{x:1282,y:735,t:1526922610833};\\\", \\\"{x:1282,y:734,t:1526922610850};\\\", \\\"{x:1282,y:732,t:1526922610867};\\\", \\\"{x:1282,y:727,t:1526922610882};\\\", \\\"{x:1284,y:723,t:1526922610900};\\\", \\\"{x:1284,y:721,t:1526922610917};\\\", \\\"{x:1285,y:717,t:1526922610932};\\\", \\\"{x:1285,y:716,t:1526922610950};\\\", \\\"{x:1285,y:712,t:1526922610966};\\\", \\\"{x:1286,y:710,t:1526922610983};\\\", \\\"{x:1286,y:708,t:1526922611000};\\\", \\\"{x:1286,y:707,t:1526922611016};\\\", \\\"{x:1286,y:703,t:1526922611032};\\\", \\\"{x:1286,y:702,t:1526922611055};\\\", \\\"{x:1286,y:701,t:1526922611066};\\\", \\\"{x:1286,y:700,t:1526922611083};\\\", \\\"{x:1286,y:699,t:1526922611151};\\\", \\\"{x:1286,y:698,t:1526922611167};\\\", \\\"{x:1286,y:697,t:1526922611191};\\\", \\\"{x:1286,y:696,t:1526922611231};\\\", \\\"{x:1286,y:695,t:1526922611247};\\\", \\\"{x:1286,y:694,t:1526922611271};\\\", \\\"{x:1286,y:692,t:1526922611287};\\\", \\\"{x:1286,y:691,t:1526922611319};\\\", \\\"{x:1286,y:690,t:1526922611333};\\\", \\\"{x:1286,y:689,t:1526922611350};\\\", \\\"{x:1285,y:686,t:1526922611366};\\\", \\\"{x:1284,y:685,t:1526922611383};\\\", \\\"{x:1284,y:682,t:1526922611400};\\\", \\\"{x:1284,y:678,t:1526922611417};\\\", \\\"{x:1283,y:676,t:1526922611433};\\\", \\\"{x:1283,y:675,t:1526922611449};\\\", \\\"{x:1283,y:673,t:1526922611467};\\\", \\\"{x:1283,y:672,t:1526922611484};\\\", \\\"{x:1283,y:670,t:1526922611503};\\\", \\\"{x:1282,y:669,t:1526922611519};\\\", \\\"{x:1282,y:668,t:1526922611535};\\\", \\\"{x:1282,y:667,t:1526922611551};\\\", \\\"{x:1281,y:664,t:1526922611566};\\\", \\\"{x:1281,y:663,t:1526922611583};\\\", \\\"{x:1280,y:662,t:1526922611600};\\\", \\\"{x:1280,y:659,t:1526922611967};\\\", \\\"{x:1280,y:651,t:1526922611983};\\\", \\\"{x:1282,y:642,t:1526922612001};\\\", \\\"{x:1284,y:630,t:1526922612018};\\\", \\\"{x:1285,y:622,t:1526922612034};\\\", \\\"{x:1285,y:617,t:1526922612050};\\\", \\\"{x:1285,y:614,t:1526922612068};\\\", \\\"{x:1285,y:608,t:1526922612084};\\\", \\\"{x:1283,y:601,t:1526922612101};\\\", \\\"{x:1283,y:598,t:1526922612117};\\\", \\\"{x:1281,y:593,t:1526922612133};\\\", \\\"{x:1281,y:587,t:1526922612150};\\\", \\\"{x:1279,y:582,t:1526922612167};\\\", \\\"{x:1279,y:579,t:1526922612183};\\\", \\\"{x:1279,y:574,t:1526922612201};\\\", \\\"{x:1278,y:571,t:1526922612217};\\\", \\\"{x:1278,y:569,t:1526922612234};\\\", \\\"{x:1278,y:567,t:1526922612251};\\\", \\\"{x:1278,y:564,t:1526922612268};\\\", \\\"{x:1276,y:563,t:1526922612283};\\\", \\\"{x:1276,y:559,t:1526922612300};\\\", \\\"{x:1276,y:558,t:1526922612317};\\\", \\\"{x:1276,y:557,t:1526922612351};\\\", \\\"{x:1274,y:557,t:1526922612631};\\\", \\\"{x:1270,y:557,t:1526922612639};\\\", \\\"{x:1267,y:559,t:1526922612651};\\\", \\\"{x:1242,y:565,t:1526922612668};\\\", \\\"{x:1211,y:567,t:1526922612685};\\\", \\\"{x:1176,y:570,t:1526922612700};\\\", \\\"{x:1142,y:570,t:1526922612718};\\\", \\\"{x:1099,y:570,t:1526922612734};\\\", \\\"{x:1056,y:559,t:1526922612751};\\\", \\\"{x:1008,y:545,t:1526922612768};\\\", \\\"{x:979,y:540,t:1526922612785};\\\", \\\"{x:950,y:536,t:1526922612802};\\\", \\\"{x:928,y:536,t:1526922612818};\\\", \\\"{x:909,y:536,t:1526922612835};\\\", \\\"{x:891,y:540,t:1526922612852};\\\", \\\"{x:879,y:548,t:1526922612868};\\\", \\\"{x:866,y:560,t:1526922612885};\\\", \\\"{x:856,y:579,t:1526922612902};\\\", \\\"{x:850,y:607,t:1526922612919};\\\", \\\"{x:847,y:650,t:1526922612935};\\\", \\\"{x:839,y:670,t:1526922612952};\\\", \\\"{x:832,y:681,t:1526922612967};\\\", \\\"{x:827,y:684,t:1526922612984};\\\", \\\"{x:822,y:686,t:1526922613001};\\\", \\\"{x:813,y:688,t:1526922613018};\\\", \\\"{x:801,y:688,t:1526922613035};\\\", \\\"{x:778,y:688,t:1526922613051};\\\", \\\"{x:753,y:688,t:1526922613067};\\\", \\\"{x:722,y:682,t:1526922613084};\\\", \\\"{x:677,y:668,t:1526922613102};\\\", \\\"{x:641,y:659,t:1526922613117};\\\", \\\"{x:595,y:641,t:1526922613135};\\\", \\\"{x:559,y:632,t:1526922613151};\\\", \\\"{x:533,y:626,t:1526922613168};\\\", \\\"{x:512,y:617,t:1526922613185};\\\", \\\"{x:487,y:613,t:1526922613202};\\\", \\\"{x:467,y:609,t:1526922613219};\\\", \\\"{x:434,y:604,t:1526922613235};\\\", \\\"{x:391,y:591,t:1526922613252};\\\", \\\"{x:343,y:582,t:1526922613269};\\\", \\\"{x:279,y:574,t:1526922613285};\\\", \\\"{x:203,y:559,t:1526922613302};\\\", \\\"{x:72,y:544,t:1526922613318};\\\", \\\"{x:8,y:529,t:1526922613335};\\\", \\\"{x:8,y:520,t:1526922613352};\\\", \\\"{x:8,y:513,t:1526922614615};\\\", \\\"{x:12,y:506,t:1526922614622};\\\", \\\"{x:15,y:496,t:1526922614634};\\\", \\\"{x:23,y:476,t:1526922614651};\\\", \\\"{x:30,y:456,t:1526922614666};\\\", \\\"{x:37,y:440,t:1526922614684};\\\", \\\"{x:40,y:425,t:1526922614699};\\\", \\\"{x:44,y:410,t:1526922614717};\\\", \\\"{x:44,y:402,t:1526922614734};\\\", \\\"{x:42,y:393,t:1526922614750};\\\", \\\"{x:39,y:388,t:1526922614766};\\\", \\\"{x:38,y:387,t:1526922614790};\\\", \\\"{x:36,y:387,t:1526922614871};\\\", \\\"{x:34,y:390,t:1526922614884};\\\", \\\"{x:29,y:395,t:1526922614900};\\\", \\\"{x:24,y:399,t:1526922614917};\\\", \\\"{x:18,y:405,t:1526922614934};\\\", \\\"{x:15,y:407,t:1526922614950};\\\", \\\"{x:12,y:409,t:1526922614966};\\\", \\\"{x:11,y:410,t:1526922614983};\\\", \\\"{x:9,y:409,t:1526922615112};\\\", \\\"{x:8,y:408,t:1526922615120};\\\", \\\"{x:8,y:406,t:1526922615135};\\\", \\\"{x:8,y:404,t:1526922615150};\\\", \\\"{x:8,y:401,t:1526922615167};\\\", \\\"{x:8,y:398,t:1526922615184};\\\", \\\"{x:8,y:395,t:1526922615200};\\\", \\\"{x:8,y:392,t:1526922615218};\\\", \\\"{x:8,y:388,t:1526922615233};\\\", \\\"{x:8,y:386,t:1526922615256};\\\", \\\"{x:8,y:384,t:1526922615267};\\\", \\\"{x:8,y:379,t:1526922615283};\\\", \\\"{x:8,y:375,t:1526922615300};\\\", \\\"{x:8,y:370,t:1526922615316};\\\", \\\"{x:8,y:367,t:1526922615334};\\\", \\\"{x:8,y:364,t:1526922615350};\\\", \\\"{x:8,y:362,t:1526922615366};\\\", \\\"{x:8,y:358,t:1526922615383};\\\", \\\"{x:8,y:356,t:1526922615400};\\\", \\\"{x:9,y:354,t:1526922615416};\\\", \\\"{x:11,y:353,t:1526922615434};\\\", \\\"{x:13,y:353,t:1526922615450};\\\", \\\"{x:22,y:356,t:1526922615467};\\\", \\\"{x:47,y:364,t:1526922615484};\\\", \\\"{x:111,y:381,t:1526922615500};\\\", \\\"{x:230,y:415,t:1526922615517};\\\", \\\"{x:379,y:452,t:1526922615534};\\\", \\\"{x:549,y:488,t:1526922615551};\\\", \\\"{x:727,y:526,t:1526922615567};\\\", \\\"{x:988,y:564,t:1526922615584};\\\", \\\"{x:1282,y:609,t:1526922615616};\\\", \\\"{x:1379,y:619,t:1526922615637};\\\", \\\"{x:1422,y:622,t:1526922615654};\\\", \\\"{x:1429,y:622,t:1526922615670};\\\", \\\"{x:1423,y:620,t:1526922615735};\\\", \\\"{x:1416,y:618,t:1526922615743};\\\", \\\"{x:1405,y:614,t:1526922615754};\\\", \\\"{x:1380,y:609,t:1526922615771};\\\", \\\"{x:1361,y:606,t:1526922615787};\\\", \\\"{x:1343,y:605,t:1526922615804};\\\", \\\"{x:1334,y:604,t:1526922615821};\\\", \\\"{x:1332,y:603,t:1526922615837};\\\", \\\"{x:1330,y:602,t:1526922615854};\\\", \\\"{x:1334,y:616,t:1526922617825};\\\", \\\"{x:1360,y:674,t:1526922617841};\\\", \\\"{x:1389,y:728,t:1526922617858};\\\", \\\"{x:1416,y:776,t:1526922617874};\\\", \\\"{x:1433,y:802,t:1526922617891};\\\", \\\"{x:1445,y:818,t:1526922617908};\\\", \\\"{x:1449,y:826,t:1526922617924};\\\", \\\"{x:1451,y:830,t:1526922617941};\\\", \\\"{x:1451,y:832,t:1526922617960};\\\", \\\"{x:1451,y:834,t:1526922618016};\\\", \\\"{x:1449,y:836,t:1526922618040};\\\", \\\"{x:1442,y:840,t:1526922618057};\\\", \\\"{x:1428,y:844,t:1526922618075};\\\", \\\"{x:1408,y:852,t:1526922618090};\\\", \\\"{x:1390,y:859,t:1526922618108};\\\", \\\"{x:1363,y:875,t:1526922618125};\\\", \\\"{x:1325,y:899,t:1526922618141};\\\", \\\"{x:1294,y:919,t:1526922618158};\\\", \\\"{x:1268,y:940,t:1526922618175};\\\", \\\"{x:1253,y:960,t:1526922618192};\\\", \\\"{x:1247,y:966,t:1526922618208};\\\", \\\"{x:1244,y:969,t:1526922618224};\\\", \\\"{x:1244,y:970,t:1526922618288};\\\", \\\"{x:1244,y:971,t:1526922618296};\\\", \\\"{x:1245,y:971,t:1526922618320};\\\", \\\"{x:1246,y:972,t:1526922618327};\\\", \\\"{x:1248,y:972,t:1526922618342};\\\", \\\"{x:1250,y:975,t:1526922618358};\\\", \\\"{x:1253,y:978,t:1526922618375};\\\", \\\"{x:1259,y:984,t:1526922618391};\\\", \\\"{x:1264,y:991,t:1526922618408};\\\", \\\"{x:1266,y:995,t:1526922618425};\\\", \\\"{x:1267,y:998,t:1526922618442};\\\", \\\"{x:1267,y:1001,t:1526922618458};\\\", \\\"{x:1268,y:1001,t:1526922618474};\\\", \\\"{x:1268,y:999,t:1526922618575};\\\", \\\"{x:1268,y:995,t:1526922618590};\\\", \\\"{x:1268,y:989,t:1526922618608};\\\", \\\"{x:1268,y:983,t:1526922618624};\\\", \\\"{x:1268,y:978,t:1526922618641};\\\", \\\"{x:1268,y:973,t:1526922618658};\\\", \\\"{x:1268,y:971,t:1526922618676};\\\", \\\"{x:1269,y:967,t:1526922618691};\\\", \\\"{x:1270,y:964,t:1526922618708};\\\", \\\"{x:1272,y:960,t:1526922618725};\\\", \\\"{x:1273,y:957,t:1526922618741};\\\", \\\"{x:1274,y:956,t:1526922618758};\\\", \\\"{x:1275,y:954,t:1526922618775};\\\", \\\"{x:1276,y:954,t:1526922618832};\\\", \\\"{x:1278,y:956,t:1526922618841};\\\", \\\"{x:1281,y:965,t:1526922618859};\\\", \\\"{x:1282,y:971,t:1526922618876};\\\", \\\"{x:1282,y:975,t:1526922618892};\\\", \\\"{x:1282,y:977,t:1526922618908};\\\", \\\"{x:1282,y:978,t:1526922618925};\\\", \\\"{x:1282,y:979,t:1526922618943};\\\", \\\"{x:1283,y:978,t:1526922619008};\\\", \\\"{x:1285,y:974,t:1526922619025};\\\", \\\"{x:1286,y:971,t:1526922619042};\\\", \\\"{x:1287,y:968,t:1526922619059};\\\", \\\"{x:1287,y:967,t:1526922619161};\\\", \\\"{x:1288,y:966,t:1526922619176};\\\", \\\"{x:1288,y:965,t:1526922619193};\\\", \\\"{x:1288,y:964,t:1526922619240};\\\", \\\"{x:1288,y:963,t:1526922619264};\\\", \\\"{x:1288,y:962,t:1526922619287};\\\", \\\"{x:1288,y:961,t:1526922619521};\\\", \\\"{x:1287,y:961,t:1526922619552};\\\", \\\"{x:1286,y:961,t:1526922619560};\\\", \\\"{x:1285,y:961,t:1526922619576};\\\", \\\"{x:1283,y:961,t:1526922619593};\\\", \\\"{x:1282,y:961,t:1526922619609};\\\", \\\"{x:1281,y:961,t:1526922619626};\\\", \\\"{x:1280,y:961,t:1526922619643};\\\", \\\"{x:1280,y:962,t:1526922619659};\\\", \\\"{x:1279,y:962,t:1526922619718};\\\", \\\"{x:1278,y:962,t:1526922619727};\\\", \\\"{x:1277,y:962,t:1526922619742};\\\", \\\"{x:1276,y:962,t:1526922619823};\\\", \\\"{x:1275,y:961,t:1526922622376};\\\", \\\"{x:1275,y:959,t:1526922622384};\\\", \\\"{x:1275,y:955,t:1526922622397};\\\", \\\"{x:1275,y:950,t:1526922622414};\\\", \\\"{x:1275,y:942,t:1526922622431};\\\", \\\"{x:1275,y:935,t:1526922622447};\\\", \\\"{x:1275,y:927,t:1526922622463};\\\", \\\"{x:1275,y:922,t:1526922622481};\\\", \\\"{x:1275,y:919,t:1526922622497};\\\", \\\"{x:1275,y:917,t:1526922622514};\\\", \\\"{x:1275,y:915,t:1526922622530};\\\", \\\"{x:1275,y:911,t:1526922622548};\\\", \\\"{x:1275,y:910,t:1526922622563};\\\", \\\"{x:1275,y:907,t:1526922622580};\\\", \\\"{x:1275,y:903,t:1526922622598};\\\", \\\"{x:1275,y:901,t:1526922622613};\\\", \\\"{x:1275,y:900,t:1526922622632};\\\", \\\"{x:1275,y:899,t:1526922622649};\\\", \\\"{x:1275,y:898,t:1526922622664};\\\", \\\"{x:1275,y:895,t:1526922622681};\\\", \\\"{x:1275,y:893,t:1526922622697};\\\", \\\"{x:1275,y:890,t:1526922622713};\\\", \\\"{x:1275,y:884,t:1526922622730};\\\", \\\"{x:1275,y:879,t:1526922622747};\\\", \\\"{x:1275,y:875,t:1526922622763};\\\", \\\"{x:1275,y:870,t:1526922622780};\\\", \\\"{x:1275,y:864,t:1526922622797};\\\", \\\"{x:1275,y:861,t:1526922622814};\\\", \\\"{x:1275,y:857,t:1526922622830};\\\", \\\"{x:1275,y:850,t:1526922622847};\\\", \\\"{x:1275,y:846,t:1526922622865};\\\", \\\"{x:1275,y:842,t:1526922622881};\\\", \\\"{x:1275,y:839,t:1526922622898};\\\", \\\"{x:1275,y:836,t:1526922622915};\\\", \\\"{x:1275,y:833,t:1526922622930};\\\", \\\"{x:1275,y:832,t:1526922622951};\\\", \\\"{x:1275,y:831,t:1526922622964};\\\", \\\"{x:1275,y:830,t:1526922622980};\\\", \\\"{x:1275,y:829,t:1526922623000};\\\", \\\"{x:1275,y:828,t:1526922623015};\\\", \\\"{x:1275,y:827,t:1526922623063};\\\", \\\"{x:1275,y:826,t:1526922623128};\\\", \\\"{x:1275,y:825,t:1526922623144};\\\", \\\"{x:1275,y:824,t:1526922623160};\\\", \\\"{x:1275,y:823,t:1526922623184};\\\", \\\"{x:1275,y:822,t:1526922623198};\\\", \\\"{x:1276,y:821,t:1526922623214};\\\", \\\"{x:1276,y:818,t:1526922623231};\\\", \\\"{x:1277,y:817,t:1526922623249};\\\", \\\"{x:1277,y:815,t:1526922623265};\\\", \\\"{x:1278,y:812,t:1526922623281};\\\", \\\"{x:1279,y:808,t:1526922623298};\\\", \\\"{x:1280,y:804,t:1526922623315};\\\", \\\"{x:1280,y:800,t:1526922623331};\\\", \\\"{x:1280,y:792,t:1526922623349};\\\", \\\"{x:1281,y:789,t:1526922623364};\\\", \\\"{x:1283,y:782,t:1526922623382};\\\", \\\"{x:1283,y:779,t:1526922623398};\\\", \\\"{x:1283,y:777,t:1526922623415};\\\", \\\"{x:1283,y:774,t:1526922623431};\\\", \\\"{x:1283,y:770,t:1526922623449};\\\", \\\"{x:1283,y:767,t:1526922623465};\\\", \\\"{x:1283,y:764,t:1526922623482};\\\", \\\"{x:1283,y:762,t:1526922623499};\\\", \\\"{x:1283,y:759,t:1526922623515};\\\", \\\"{x:1283,y:758,t:1526922623532};\\\", \\\"{x:1283,y:755,t:1526922623549};\\\", \\\"{x:1283,y:752,t:1526922623566};\\\", \\\"{x:1283,y:749,t:1526922623582};\\\", \\\"{x:1283,y:746,t:1526922623599};\\\", \\\"{x:1283,y:741,t:1526922623615};\\\", \\\"{x:1283,y:738,t:1526922623631};\\\", \\\"{x:1283,y:733,t:1526922623648};\\\", \\\"{x:1283,y:728,t:1526922623666};\\\", \\\"{x:1283,y:724,t:1526922623682};\\\", \\\"{x:1283,y:723,t:1526922623699};\\\", \\\"{x:1283,y:721,t:1526922623716};\\\", \\\"{x:1283,y:718,t:1526922623731};\\\", \\\"{x:1283,y:717,t:1526922623749};\\\", \\\"{x:1283,y:715,t:1526922623766};\\\", \\\"{x:1283,y:713,t:1526922623783};\\\", \\\"{x:1283,y:712,t:1526922623799};\\\", \\\"{x:1283,y:711,t:1526922623824};\\\", \\\"{x:1284,y:710,t:1526922623833};\\\", \\\"{x:1284,y:709,t:1526922624081};\\\", \\\"{x:1284,y:707,t:1526922624087};\\\", \\\"{x:1284,y:705,t:1526922624099};\\\", \\\"{x:1283,y:698,t:1526922624115};\\\", \\\"{x:1283,y:694,t:1526922624132};\\\", \\\"{x:1281,y:690,t:1526922624149};\\\", \\\"{x:1279,y:687,t:1526922624165};\\\", \\\"{x:1278,y:685,t:1526922624183};\\\", \\\"{x:1277,y:681,t:1526922624199};\\\", \\\"{x:1276,y:681,t:1526922624215};\\\", \\\"{x:1276,y:683,t:1526922624400};\\\", \\\"{x:1276,y:699,t:1526922624416};\\\", \\\"{x:1279,y:727,t:1526922624433};\\\", \\\"{x:1284,y:758,t:1526922624449};\\\", \\\"{x:1290,y:806,t:1526922624467};\\\", \\\"{x:1296,y:832,t:1526922624483};\\\", \\\"{x:1301,y:864,t:1526922624500};\\\", \\\"{x:1308,y:904,t:1526922624517};\\\", \\\"{x:1309,y:941,t:1526922624534};\\\", \\\"{x:1311,y:966,t:1526922624550};\\\", \\\"{x:1311,y:986,t:1526922624566};\\\", \\\"{x:1311,y:1005,t:1526922624583};\\\", \\\"{x:1311,y:1008,t:1526922624600};\\\", \\\"{x:1311,y:1006,t:1526922624720};\\\", \\\"{x:1309,y:1000,t:1526922624734};\\\", \\\"{x:1308,y:990,t:1526922624751};\\\", \\\"{x:1306,y:973,t:1526922624766};\\\", \\\"{x:1301,y:949,t:1526922624783};\\\", \\\"{x:1298,y:935,t:1526922624800};\\\", \\\"{x:1296,y:926,t:1526922624816};\\\", \\\"{x:1294,y:921,t:1526922624833};\\\", \\\"{x:1292,y:927,t:1526922624911};\\\", \\\"{x:1289,y:936,t:1526922624919};\\\", \\\"{x:1289,y:944,t:1526922624933};\\\", \\\"{x:1284,y:968,t:1526922624950};\\\", \\\"{x:1283,y:974,t:1526922624967};\\\", \\\"{x:1281,y:981,t:1526922624983};\\\", \\\"{x:1280,y:981,t:1526922625081};\\\", \\\"{x:1278,y:981,t:1526922625088};\\\", \\\"{x:1277,y:981,t:1526922625101};\\\", \\\"{x:1273,y:974,t:1526922625118};\\\", \\\"{x:1271,y:967,t:1526922625134};\\\", \\\"{x:1269,y:962,t:1526922625151};\\\", \\\"{x:1268,y:950,t:1526922625167};\\\", \\\"{x:1268,y:946,t:1526922625184};\\\", \\\"{x:1268,y:941,t:1526922625201};\\\", \\\"{x:1268,y:937,t:1526922625218};\\\", \\\"{x:1268,y:934,t:1526922625235};\\\", \\\"{x:1268,y:930,t:1526922625250};\\\", \\\"{x:1268,y:926,t:1526922625268};\\\", \\\"{x:1268,y:919,t:1526922625284};\\\", \\\"{x:1268,y:910,t:1526922625301};\\\", \\\"{x:1270,y:900,t:1526922625317};\\\", \\\"{x:1270,y:895,t:1526922625334};\\\", \\\"{x:1271,y:889,t:1526922625350};\\\", \\\"{x:1273,y:881,t:1526922625367};\\\", \\\"{x:1273,y:876,t:1526922625385};\\\", \\\"{x:1273,y:873,t:1526922625401};\\\", \\\"{x:1273,y:869,t:1526922625418};\\\", \\\"{x:1273,y:867,t:1526922625434};\\\", \\\"{x:1273,y:863,t:1526922625451};\\\", \\\"{x:1273,y:861,t:1526922625468};\\\", \\\"{x:1273,y:859,t:1526922625485};\\\", \\\"{x:1273,y:857,t:1526922625502};\\\", \\\"{x:1272,y:856,t:1526922625518};\\\", \\\"{x:1272,y:855,t:1526922625535};\\\", \\\"{x:1272,y:853,t:1526922625552};\\\", \\\"{x:1272,y:849,t:1526922625567};\\\", \\\"{x:1270,y:844,t:1526922625585};\\\", \\\"{x:1269,y:839,t:1526922625602};\\\", \\\"{x:1268,y:836,t:1526922625618};\\\", \\\"{x:1268,y:835,t:1526922625635};\\\", \\\"{x:1268,y:832,t:1526922625652};\\\", \\\"{x:1267,y:830,t:1526922625669};\\\", \\\"{x:1267,y:829,t:1526922625684};\\\", \\\"{x:1266,y:827,t:1526922625701};\\\", \\\"{x:1266,y:826,t:1526922626008};\\\", \\\"{x:1267,y:826,t:1526922626168};\\\", \\\"{x:1268,y:826,t:1526922626192};\\\", \\\"{x:1269,y:826,t:1526922626224};\\\", \\\"{x:1270,y:826,t:1526922626240};\\\", \\\"{x:1272,y:826,t:1526922626264};\\\", \\\"{x:1273,y:826,t:1526922626271};\\\", \\\"{x:1274,y:826,t:1526922626296};\\\", \\\"{x:1274,y:828,t:1526922626528};\\\", \\\"{x:1274,y:829,t:1526922626536};\\\", \\\"{x:1274,y:831,t:1526922626559};\\\", \\\"{x:1274,y:832,t:1526922626569};\\\", \\\"{x:1274,y:833,t:1526922626586};\\\", \\\"{x:1274,y:835,t:1526922626603};\\\", \\\"{x:1274,y:836,t:1526922626620};\\\", \\\"{x:1275,y:836,t:1526922626800};\\\", \\\"{x:1276,y:836,t:1526922626815};\\\", \\\"{x:1277,y:836,t:1526922626824};\\\", \\\"{x:1277,y:835,t:1526922626837};\\\", \\\"{x:1278,y:834,t:1526922626853};\\\", \\\"{x:1278,y:833,t:1526922626870};\\\", \\\"{x:1279,y:832,t:1526922626887};\\\", \\\"{x:1282,y:830,t:1526922627136};\\\", \\\"{x:1283,y:829,t:1526922627160};\\\", \\\"{x:1284,y:828,t:1526922627192};\\\", \\\"{x:1285,y:827,t:1526922627216};\\\", \\\"{x:1283,y:827,t:1526922627456};\\\", \\\"{x:1282,y:827,t:1526922627480};\\\", \\\"{x:1282,y:828,t:1526922627487};\\\", \\\"{x:1283,y:828,t:1526922627715};\\\", \\\"{x:1284,y:828,t:1526922627747};\\\", \\\"{x:1284,y:827,t:1526922629338};\\\", \\\"{x:1284,y:826,t:1526922629347};\\\", \\\"{x:1284,y:824,t:1526922629360};\\\", \\\"{x:1284,y:823,t:1526922629376};\\\", \\\"{x:1284,y:822,t:1526922629393};\\\", \\\"{x:1284,y:820,t:1526922629410};\\\", \\\"{x:1284,y:819,t:1526922629459};\\\", \\\"{x:1284,y:818,t:1526922629483};\\\", \\\"{x:1284,y:815,t:1526922629850};\\\", \\\"{x:1284,y:812,t:1526922629859};\\\", \\\"{x:1284,y:805,t:1526922629877};\\\", \\\"{x:1285,y:798,t:1526922629893};\\\", \\\"{x:1285,y:788,t:1526922629910};\\\", \\\"{x:1285,y:781,t:1526922629926};\\\", \\\"{x:1286,y:774,t:1526922629943};\\\", \\\"{x:1288,y:770,t:1526922629960};\\\", \\\"{x:1288,y:765,t:1526922629976};\\\", \\\"{x:1289,y:759,t:1526922629993};\\\", \\\"{x:1289,y:758,t:1526922630011};\\\", \\\"{x:1289,y:756,t:1526922630026};\\\", \\\"{x:1289,y:755,t:1526922630043};\\\", \\\"{x:1289,y:753,t:1526922630066};\\\", \\\"{x:1288,y:753,t:1526922630395};\\\", \\\"{x:1287,y:752,t:1526922633891};\\\", \\\"{x:1286,y:750,t:1526922633899};\\\", \\\"{x:1286,y:745,t:1526922633916};\\\", \\\"{x:1286,y:742,t:1526922633933};\\\", \\\"{x:1286,y:738,t:1526922633949};\\\", \\\"{x:1286,y:735,t:1526922633966};\\\", \\\"{x:1286,y:732,t:1526922633983};\\\", \\\"{x:1286,y:731,t:1526922633999};\\\", \\\"{x:1286,y:729,t:1526922634016};\\\", \\\"{x:1286,y:728,t:1526922634034};\\\", \\\"{x:1286,y:725,t:1526922634051};\\\", \\\"{x:1286,y:724,t:1526922634066};\\\", \\\"{x:1285,y:722,t:1526922634084};\\\", \\\"{x:1285,y:720,t:1526922634100};\\\", \\\"{x:1285,y:719,t:1526922634116};\\\", \\\"{x:1284,y:718,t:1526922634132};\\\", \\\"{x:1284,y:716,t:1526922634150};\\\", \\\"{x:1284,y:715,t:1526922634166};\\\", \\\"{x:1284,y:713,t:1526922634182};\\\", \\\"{x:1284,y:711,t:1526922634199};\\\", \\\"{x:1284,y:710,t:1526922634216};\\\", \\\"{x:1282,y:706,t:1526922634233};\\\", \\\"{x:1282,y:704,t:1526922634250};\\\", \\\"{x:1282,y:702,t:1526922634266};\\\", \\\"{x:1281,y:699,t:1526922634283};\\\", \\\"{x:1281,y:698,t:1526922634300};\\\", \\\"{x:1281,y:696,t:1526922634317};\\\", \\\"{x:1279,y:693,t:1526922634332};\\\", \\\"{x:1279,y:690,t:1526922634350};\\\", \\\"{x:1279,y:689,t:1526922634367};\\\", \\\"{x:1278,y:687,t:1526922634382};\\\", \\\"{x:1278,y:686,t:1526922634410};\\\", \\\"{x:1277,y:684,t:1526922634418};\\\", \\\"{x:1277,y:683,t:1526922634514};\\\", \\\"{x:1277,y:681,t:1526922634634};\\\", \\\"{x:1277,y:680,t:1526922634649};\\\", \\\"{x:1277,y:677,t:1526922634666};\\\", \\\"{x:1277,y:673,t:1526922634683};\\\", \\\"{x:1279,y:667,t:1526922634699};\\\", \\\"{x:1279,y:664,t:1526922634717};\\\", \\\"{x:1279,y:660,t:1526922634733};\\\", \\\"{x:1280,y:657,t:1526922634750};\\\", \\\"{x:1280,y:656,t:1526922634766};\\\", \\\"{x:1280,y:655,t:1526922634784};\\\", \\\"{x:1280,y:654,t:1526922634800};\\\", \\\"{x:1280,y:653,t:1526922634874};\\\", \\\"{x:1281,y:652,t:1526922634890};\\\", \\\"{x:1281,y:651,t:1526922635458};\\\", \\\"{x:1281,y:650,t:1526922635468};\\\", \\\"{x:1282,y:647,t:1526922635484};\\\", \\\"{x:1282,y:644,t:1526922635501};\\\", \\\"{x:1283,y:640,t:1526922635518};\\\", \\\"{x:1283,y:635,t:1526922635535};\\\", \\\"{x:1283,y:631,t:1526922635551};\\\", \\\"{x:1283,y:628,t:1526922635567};\\\", \\\"{x:1283,y:622,t:1526922635585};\\\", \\\"{x:1283,y:617,t:1526922635602};\\\", \\\"{x:1283,y:614,t:1526922635618};\\\", \\\"{x:1283,y:611,t:1526922635635};\\\", \\\"{x:1283,y:610,t:1526922635652};\\\", \\\"{x:1283,y:608,t:1526922635668};\\\", \\\"{x:1283,y:606,t:1526922635685};\\\", \\\"{x:1283,y:604,t:1526922635702};\\\", \\\"{x:1283,y:601,t:1526922635718};\\\", \\\"{x:1283,y:599,t:1526922635735};\\\", \\\"{x:1283,y:595,t:1526922635752};\\\", \\\"{x:1283,y:591,t:1526922635769};\\\", \\\"{x:1283,y:588,t:1526922635785};\\\", \\\"{x:1283,y:584,t:1526922635801};\\\", \\\"{x:1283,y:580,t:1526922635818};\\\", \\\"{x:1282,y:577,t:1526922635834};\\\", \\\"{x:1282,y:575,t:1526922635852};\\\", \\\"{x:1281,y:573,t:1526922635869};\\\", \\\"{x:1281,y:571,t:1526922635885};\\\", \\\"{x:1281,y:569,t:1526922635902};\\\", \\\"{x:1280,y:567,t:1526922635919};\\\", \\\"{x:1280,y:566,t:1526922635935};\\\", \\\"{x:1280,y:565,t:1526922635951};\\\", \\\"{x:1279,y:564,t:1526922635968};\\\", \\\"{x:1279,y:562,t:1526922635985};\\\", \\\"{x:1279,y:561,t:1526922636026};\\\", \\\"{x:1279,y:560,t:1526922636091};\\\", \\\"{x:1279,y:559,t:1526922636114};\\\", \\\"{x:1279,y:558,t:1526922636146};\\\", \\\"{x:1279,y:557,t:1526922636162};\\\", \\\"{x:1279,y:556,t:1526922636170};\\\", \\\"{x:1279,y:555,t:1526922636186};\\\", \\\"{x:1279,y:552,t:1526922636202};\\\", \\\"{x:1279,y:549,t:1526922636219};\\\", \\\"{x:1279,y:546,t:1526922636236};\\\", \\\"{x:1278,y:542,t:1526922636253};\\\", \\\"{x:1278,y:537,t:1526922636269};\\\", \\\"{x:1278,y:532,t:1526922636286};\\\", \\\"{x:1276,y:523,t:1526922636302};\\\", \\\"{x:1275,y:516,t:1526922636319};\\\", \\\"{x:1275,y:507,t:1526922636336};\\\", \\\"{x:1275,y:499,t:1526922636353};\\\", \\\"{x:1274,y:490,t:1526922636368};\\\", \\\"{x:1274,y:480,t:1526922636386};\\\", \\\"{x:1272,y:472,t:1526922636403};\\\", \\\"{x:1272,y:466,t:1526922636419};\\\", \\\"{x:1272,y:460,t:1526922636435};\\\", \\\"{x:1272,y:453,t:1526922636452};\\\", \\\"{x:1271,y:446,t:1526922636469};\\\", \\\"{x:1270,y:440,t:1526922636486};\\\", \\\"{x:1269,y:434,t:1526922636503};\\\", \\\"{x:1268,y:426,t:1526922636520};\\\", \\\"{x:1268,y:420,t:1526922636536};\\\", \\\"{x:1268,y:413,t:1526922636554};\\\", \\\"{x:1267,y:400,t:1526922636570};\\\", \\\"{x:1266,y:391,t:1526922636586};\\\", \\\"{x:1266,y:381,t:1526922636603};\\\", \\\"{x:1266,y:372,t:1526922636620};\\\", \\\"{x:1265,y:362,t:1526922636636};\\\", \\\"{x:1263,y:350,t:1526922636653};\\\", \\\"{x:1262,y:337,t:1526922636670};\\\", \\\"{x:1262,y:326,t:1526922636686};\\\", \\\"{x:1262,y:313,t:1526922636703};\\\", \\\"{x:1262,y:301,t:1526922636720};\\\", \\\"{x:1262,y:289,t:1526922636737};\\\", \\\"{x:1262,y:279,t:1526922636753};\\\", \\\"{x:1262,y:261,t:1526922636770};\\\", \\\"{x:1262,y:250,t:1526922636786};\\\", \\\"{x:1262,y:238,t:1526922636803};\\\", \\\"{x:1262,y:227,t:1526922636820};\\\", \\\"{x:1262,y:214,t:1526922636837};\\\", \\\"{x:1262,y:203,t:1526922636853};\\\", \\\"{x:1262,y:191,t:1526922636870};\\\", \\\"{x:1262,y:181,t:1526922636887};\\\", \\\"{x:1262,y:167,t:1526922636903};\\\", \\\"{x:1262,y:157,t:1526922636920};\\\", \\\"{x:1262,y:146,t:1526922636937};\\\", \\\"{x:1262,y:134,t:1526922636953};\\\", \\\"{x:1262,y:120,t:1526922636969};\\\", \\\"{x:1262,y:109,t:1526922636987};\\\", \\\"{x:1262,y:100,t:1526922637004};\\\", \\\"{x:1262,y:92,t:1526922637019};\\\", \\\"{x:1262,y:85,t:1526922637037};\\\", \\\"{x:1262,y:79,t:1526922637054};\\\", \\\"{x:1262,y:74,t:1526922637070};\\\", \\\"{x:1262,y:71,t:1526922637086};\\\", \\\"{x:1262,y:69,t:1526922637103};\\\", \\\"{x:1262,y:70,t:1526922637209};\\\", \\\"{x:1262,y:74,t:1526922637219};\\\", \\\"{x:1259,y:83,t:1526922637237};\\\", \\\"{x:1257,y:97,t:1526922637253};\\\", \\\"{x:1256,y:112,t:1526922637270};\\\", \\\"{x:1254,y:133,t:1526922637286};\\\", \\\"{x:1252,y:157,t:1526922637303};\\\", \\\"{x:1252,y:182,t:1526922637320};\\\", \\\"{x:1252,y:211,t:1526922637336};\\\", \\\"{x:1252,y:256,t:1526922637353};\\\", \\\"{x:1252,y:290,t:1526922637371};\\\", \\\"{x:1252,y:324,t:1526922637386};\\\", \\\"{x:1252,y:360,t:1526922637404};\\\", \\\"{x:1252,y:393,t:1526922637420};\\\", \\\"{x:1252,y:425,t:1526922637436};\\\", \\\"{x:1252,y:453,t:1526922637453};\\\", \\\"{x:1252,y:482,t:1526922637471};\\\", \\\"{x:1252,y:509,t:1526922637488};\\\", \\\"{x:1252,y:533,t:1526922637503};\\\", \\\"{x:1255,y:555,t:1526922637521};\\\", \\\"{x:1260,y:592,t:1526922637537};\\\", \\\"{x:1265,y:616,t:1526922637554};\\\", \\\"{x:1270,y:642,t:1526922637571};\\\", \\\"{x:1273,y:672,t:1526922637588};\\\", \\\"{x:1279,y:717,t:1526922637604};\\\", \\\"{x:1287,y:770,t:1526922637620};\\\", \\\"{x:1297,y:838,t:1526922637638};\\\", \\\"{x:1306,y:920,t:1526922637653};\\\", \\\"{x:1320,y:1018,t:1526922637671};\\\", \\\"{x:1334,y:1123,t:1526922637687};\\\", \\\"{x:1344,y:1199,t:1526922637704};\\\", \\\"{x:1354,y:1199,t:1526922637721};\\\", \\\"{x:1364,y:1199,t:1526922637741};\\\", \\\"{x:1367,y:1199,t:1526922637757};\\\", \\\"{x:1371,y:1199,t:1526922637785};\\\", \\\"{x:1375,y:1199,t:1526922637794};\\\", \\\"{x:1380,y:1199,t:1526922637808};\\\", \\\"{x:1378,y:1199,t:1526922637826};\\\", \\\"{x:1376,y:1199,t:1526922637874};\\\", \\\"{x:1365,y:1199,t:1526922637892};\\\", \\\"{x:1365,y:1199,t:1526922637908};\\\", \\\"{x:1361,y:1199,t:1526922637925};\\\", \\\"{x:1358,y:1199,t:1526922637942};\\\", \\\"{x:1350,y:1199,t:1526922637958};\\\", \\\"{x:1339,y:1199,t:1526922637974};\\\", \\\"{x:1332,y:1199,t:1526922637992};\\\", \\\"{x:1314,y:1199,t:1526922638008};\\\", \\\"{x:1312,y:1199,t:1526922638025};\\\", \\\"{x:1288,y:1199,t:1526922638042};\\\", \\\"{x:1272,y:1199,t:1526922638058};\\\", \\\"{x:1266,y:1199,t:1526922638074};\\\", \\\"{x:1273,y:1199,t:1526922638114};\\\", \\\"{x:1280,y:1199,t:1526922638125};\\\", \\\"{x:1299,y:1199,t:1526922638142};\\\", \\\"{x:1316,y:1199,t:1526922638159};\\\", \\\"{x:1329,y:1199,t:1526922638175};\\\", \\\"{x:1338,y:1199,t:1526922638191};\\\", \\\"{x:1342,y:1199,t:1526922638209};\\\", \\\"{x:1343,y:1199,t:1526922638225};\\\", \\\"{x:1345,y:1199,t:1526922638291};\\\", \\\"{x:1346,y:1197,t:1526922638298};\\\", \\\"{x:1350,y:1193,t:1526922638308};\\\", \\\"{x:1360,y:1180,t:1526922638324};\\\", \\\"{x:1371,y:1164,t:1526922638342};\\\", \\\"{x:1382,y:1142,t:1526922638357};\\\", \\\"{x:1398,y:1118,t:1526922638374};\\\", \\\"{x:1415,y:1086,t:1526922638392};\\\", \\\"{x:1427,y:1061,t:1526922638408};\\\", \\\"{x:1437,y:1041,t:1526922638424};\\\", \\\"{x:1452,y:1012,t:1526922638442};\\\", \\\"{x:1464,y:983,t:1526922638459};\\\", \\\"{x:1484,y:929,t:1526922638475};\\\", \\\"{x:1508,y:853,t:1526922638491};\\\", \\\"{x:1531,y:760,t:1526922638509};\\\", \\\"{x:1543,y:657,t:1526922638525};\\\", \\\"{x:1544,y:562,t:1526922638541};\\\", \\\"{x:1542,y:473,t:1526922638558};\\\", \\\"{x:1528,y:378,t:1526922638575};\\\", \\\"{x:1509,y:314,t:1526922638592};\\\", \\\"{x:1479,y:250,t:1526922638609};\\\", \\\"{x:1440,y:167,t:1526922638624};\\\", \\\"{x:1365,y:51,t:1526922638641};\\\", \\\"{x:1312,y:0,t:1526922638659};\\\", \\\"{x:1263,y:0,t:1526922638675};\\\", \\\"{x:1224,y:0,t:1526922638692};\\\", \\\"{x:1190,y:0,t:1526922638708};\\\", \\\"{x:1145,y:16,t:1526922638725};\\\", \\\"{x:1080,y:62,t:1526922638742};\\\", \\\"{x:991,y:143,t:1526922638758};\\\", \\\"{x:916,y:226,t:1526922638775};\\\", \\\"{x:876,y:286,t:1526922638791};\\\", \\\"{x:867,y:329,t:1526922638808};\\\", \\\"{x:864,y:390,t:1526922638825};\\\", \\\"{x:856,y:430,t:1526922638841};\\\", \\\"{x:848,y:457,t:1526922638859};\\\", \\\"{x:843,y:474,t:1526922638876};\\\", \\\"{x:843,y:483,t:1526922638892};\\\", \\\"{x:843,y:488,t:1526922638908};\\\", \\\"{x:843,y:490,t:1526922638925};\\\", \\\"{x:843,y:491,t:1526922638961};\\\", \\\"{x:843,y:497,t:1526922639042};\\\", \\\"{x:843,y:500,t:1526922639059};\\\", \\\"{x:843,y:503,t:1526922639076};\\\", \\\"{x:843,y:510,t:1526922639092};\\\", \\\"{x:843,y:516,t:1526922639108};\\\", \\\"{x:845,y:525,t:1526922639126};\\\", \\\"{x:848,y:532,t:1526922639142};\\\", \\\"{x:851,y:542,t:1526922639159};\\\", \\\"{x:856,y:552,t:1526922639176};\\\", \\\"{x:860,y:561,t:1526922639192};\\\", \\\"{x:866,y:577,t:1526922639208};\\\", \\\"{x:875,y:604,t:1526922639225};\\\", \\\"{x:887,y:631,t:1526922639242};\\\", \\\"{x:902,y:666,t:1526922639258};\\\", \\\"{x:920,y:708,t:1526922639275};\\\", \\\"{x:937,y:754,t:1526922639292};\\\", \\\"{x:954,y:795,t:1526922639308};\\\", \\\"{x:971,y:846,t:1526922639325};\\\", \\\"{x:982,y:884,t:1526922639342};\\\", \\\"{x:992,y:930,t:1526922639359};\\\", \\\"{x:1003,y:967,t:1526922639376};\\\", \\\"{x:1012,y:1000,t:1526922639393};\\\", \\\"{x:1019,y:1023,t:1526922639408};\\\", \\\"{x:1033,y:1052,t:1526922639425};\\\", \\\"{x:1038,y:1058,t:1526922639458};\\\", \\\"{x:1041,y:1060,t:1526922639476};\\\", \\\"{x:1041,y:1060,t:1526922639561};\\\", \\\"{x:1042,y:1060,t:1526922639575};\\\", \\\"{x:1043,y:1060,t:1526922639593};\\\", \\\"{x:1047,y:1060,t:1526922639802};\\\", \\\"{x:1079,y:1070,t:1526922639810};\\\", \\\"{x:1184,y:1113,t:1526922639826};\\\", \\\"{x:1312,y:1158,t:1526922639843};\\\", \\\"{x:1420,y:1188,t:1526922639861};\\\", \\\"{x:1509,y:1199,t:1526922639877};\\\", \\\"{x:1584,y:1199,t:1526922639893};\\\", \\\"{x:1640,y:1199,t:1526922639909};\\\", \\\"{x:1677,y:1198,t:1526922639926};\\\", \\\"{x:1698,y:1194,t:1526922639943};\\\", \\\"{x:1705,y:1192,t:1526922639959};\\\", \\\"{x:1705,y:1190,t:1526922639977};\\\", \\\"{x:1705,y:1184,t:1526922639993};\\\", \\\"{x:1705,y:1180,t:1526922640011};\\\", \\\"{x:1703,y:1177,t:1526922640026};\\\", \\\"{x:1702,y:1175,t:1526922640042};\\\", \\\"{x:1702,y:1174,t:1526922640059};\\\", \\\"{x:1701,y:1172,t:1526922640075};\\\", \\\"{x:1700,y:1170,t:1526922640092};\\\", \\\"{x:1699,y:1169,t:1526922640109};\\\", \\\"{x:1698,y:1168,t:1526922640127};\\\", \\\"{x:1698,y:1167,t:1526922640169};\\\", \\\"{x:1698,y:1166,t:1526922640177};\\\", \\\"{x:1698,y:1165,t:1526922640193};\\\", \\\"{x:1697,y:1164,t:1526922640210};\\\", \\\"{x:1697,y:1163,t:1526922640226};\\\", \\\"{x:1697,y:1162,t:1526922640315};\\\", \\\"{x:1696,y:1163,t:1526922640426};\\\", \\\"{x:1696,y:1169,t:1526922640443};\\\", \\\"{x:1698,y:1176,t:1526922640460};\\\", \\\"{x:1702,y:1184,t:1526922640477};\\\", \\\"{x:1704,y:1188,t:1526922640493};\\\", \\\"{x:1706,y:1190,t:1526922640509};\\\", \\\"{x:1706,y:1191,t:1526922640527};\\\", \\\"{x:1708,y:1190,t:1526922640585};\\\", \\\"{x:1708,y:1189,t:1526922640592};\\\", \\\"{x:1711,y:1186,t:1526922640609};\\\", \\\"{x:1714,y:1182,t:1526922640627};\\\", \\\"{x:1717,y:1179,t:1526922640644};\\\", \\\"{x:1718,y:1178,t:1526922640660};\\\", \\\"{x:1718,y:1177,t:1526922640698};\\\", \\\"{x:1720,y:1176,t:1526922640727};\\\", \\\"{x:1723,y:1175,t:1526922640744};\\\", \\\"{x:1735,y:1170,t:1526922640760};\\\", \\\"{x:1783,y:1168,t:1526922640777};\\\", \\\"{x:1820,y:1168,t:1526922640793};\\\", \\\"{x:1850,y:1163,t:1526922640809};\\\", \\\"{x:1877,y:1161,t:1526922640826};\\\", \\\"{x:1921,y:1155,t:1526922640843};\\\", \\\"{x:1927,y:1151,t:1526922640860};\\\", \\\"{x:1927,y:1149,t:1526922640876};\\\", \\\"{x:1927,y:1148,t:1526922640893};\\\", \\\"{x:1927,y:1148,t:1526922641051};\\\", \\\"{x:1924,y:1148,t:1526922641097};\\\", \\\"{x:1922,y:1148,t:1526922641111};\\\", \\\"{x:1922,y:1149,t:1526922641127};\\\", \\\"{x:1920,y:1149,t:1526922641143};\\\", \\\"{x:1919,y:1149,t:1526922641160};\\\", \\\"{x:1913,y:1149,t:1526922641906};\\\", \\\"{x:1903,y:1148,t:1526922641914};\\\", \\\"{x:1891,y:1146,t:1526922641928};\\\", \\\"{x:1864,y:1140,t:1526922641944};\\\", \\\"{x:1836,y:1136,t:1526922641961};\\\", \\\"{x:1808,y:1131,t:1526922641978};\\\", \\\"{x:1798,y:1131,t:1526922641995};\\\", \\\"{x:1795,y:1131,t:1526922642011};\\\", \\\"{x:1794,y:1130,t:1526922642028};\\\", \\\"{x:1793,y:1130,t:1526922642084};\\\", \\\"{x:1789,y:1130,t:1526922642289};\\\", \\\"{x:1781,y:1130,t:1526922642296};\\\", \\\"{x:1772,y:1130,t:1526922642311};\\\", \\\"{x:1747,y:1130,t:1526922642327};\\\", \\\"{x:1719,y:1129,t:1526922642345};\\\", \\\"{x:1671,y:1125,t:1526922642361};\\\", \\\"{x:1642,y:1120,t:1526922642377};\\\", \\\"{x:1617,y:1117,t:1526922642395};\\\", \\\"{x:1597,y:1114,t:1526922642412};\\\", \\\"{x:1575,y:1111,t:1526922642427};\\\", \\\"{x:1550,y:1109,t:1526922642444};\\\", \\\"{x:1526,y:1109,t:1526922642461};\\\", \\\"{x:1497,y:1108,t:1526922642478};\\\", \\\"{x:1457,y:1108,t:1526922642494};\\\", \\\"{x:1407,y:1108,t:1526922642512};\\\", \\\"{x:1346,y:1108,t:1526922642527};\\\", \\\"{x:1276,y:1108,t:1526922642544};\\\", \\\"{x:1166,y:1101,t:1526922642561};\\\", \\\"{x:1099,y:1090,t:1526922642578};\\\", \\\"{x:1053,y:1083,t:1526922642595};\\\", \\\"{x:1025,y:1076,t:1526922642612};\\\", \\\"{x:1014,y:1070,t:1526922642628};\\\", \\\"{x:1013,y:1067,t:1526922642645};\\\", \\\"{x:1013,y:1064,t:1526922642662};\\\", \\\"{x:1013,y:1060,t:1526922642679};\\\", \\\"{x:1022,y:1056,t:1526922642694};\\\", \\\"{x:1034,y:1047,t:1526922642711};\\\", \\\"{x:1045,y:1041,t:1526922642728};\\\", \\\"{x:1064,y:1030,t:1526922642745};\\\", \\\"{x:1101,y:1013,t:1526922642761};\\\", \\\"{x:1124,y:1002,t:1526922642779};\\\", \\\"{x:1156,y:986,t:1526922642795};\\\", \\\"{x:1185,y:972,t:1526922642812};\\\", \\\"{x:1203,y:966,t:1526922642829};\\\", \\\"{x:1213,y:961,t:1526922642845};\\\", \\\"{x:1219,y:961,t:1526922642862};\\\", \\\"{x:1220,y:960,t:1526922642879};\\\", \\\"{x:1221,y:960,t:1526922642895};\\\", \\\"{x:1221,y:959,t:1526922642914};\\\", \\\"{x:1221,y:960,t:1526922642994};\\\", \\\"{x:1223,y:965,t:1526922643012};\\\", \\\"{x:1230,y:970,t:1526922643029};\\\", \\\"{x:1246,y:980,t:1526922643046};\\\", \\\"{x:1271,y:988,t:1526922643062};\\\", \\\"{x:1302,y:997,t:1526922643079};\\\", \\\"{x:1333,y:1003,t:1526922643095};\\\", \\\"{x:1355,y:1005,t:1526922643112};\\\", \\\"{x:1370,y:1006,t:1526922643129};\\\", \\\"{x:1373,y:1006,t:1526922643145};\\\", \\\"{x:1371,y:1006,t:1526922643218};\\\", \\\"{x:1368,y:1006,t:1526922643229};\\\", \\\"{x:1361,y:1006,t:1526922643246};\\\", \\\"{x:1354,y:1006,t:1526922643262};\\\", \\\"{x:1348,y:1008,t:1526922643279};\\\", \\\"{x:1341,y:1008,t:1526922643296};\\\", \\\"{x:1336,y:1009,t:1526922643311};\\\", \\\"{x:1330,y:1010,t:1526922643329};\\\", \\\"{x:1320,y:1013,t:1526922643345};\\\", \\\"{x:1313,y:1016,t:1526922643362};\\\", \\\"{x:1308,y:1018,t:1526922643379};\\\", \\\"{x:1306,y:1018,t:1526922643396};\\\", \\\"{x:1304,y:1018,t:1526922643412};\\\", \\\"{x:1303,y:1017,t:1526922643490};\\\", \\\"{x:1301,y:1007,t:1526922643512};\\\", \\\"{x:1295,y:970,t:1526922643528};\\\", \\\"{x:1292,y:940,t:1526922643545};\\\", \\\"{x:1291,y:903,t:1526922643561};\\\", \\\"{x:1291,y:855,t:1526922643578};\\\", \\\"{x:1291,y:811,t:1526922643595};\\\", \\\"{x:1295,y:771,t:1526922643613};\\\", \\\"{x:1296,y:734,t:1526922643628};\\\", \\\"{x:1301,y:700,t:1526922643645};\\\", \\\"{x:1306,y:674,t:1526922643663};\\\", \\\"{x:1308,y:651,t:1526922643679};\\\", \\\"{x:1311,y:632,t:1526922643695};\\\", \\\"{x:1313,y:618,t:1526922643713};\\\", \\\"{x:1316,y:602,t:1526922643729};\\\", \\\"{x:1316,y:594,t:1526922643746};\\\", \\\"{x:1317,y:588,t:1526922643763};\\\", \\\"{x:1317,y:583,t:1526922643779};\\\", \\\"{x:1318,y:579,t:1526922643796};\\\", \\\"{x:1319,y:576,t:1526922643813};\\\", \\\"{x:1319,y:574,t:1526922643830};\\\", \\\"{x:1320,y:569,t:1526922643846};\\\", \\\"{x:1320,y:565,t:1526922643863};\\\", \\\"{x:1321,y:560,t:1526922643879};\\\", \\\"{x:1321,y:554,t:1526922643896};\\\", \\\"{x:1321,y:545,t:1526922643913};\\\", \\\"{x:1321,y:530,t:1526922643929};\\\", \\\"{x:1321,y:515,t:1526922643946};\\\", \\\"{x:1321,y:496,t:1526922643963};\\\", \\\"{x:1321,y:477,t:1526922643979};\\\", \\\"{x:1321,y:455,t:1526922643996};\\\", \\\"{x:1321,y:429,t:1526922644013};\\\", \\\"{x:1321,y:406,t:1526922644030};\\\", \\\"{x:1321,y:376,t:1526922644045};\\\", \\\"{x:1321,y:345,t:1526922644062};\\\", \\\"{x:1322,y:322,t:1526922644080};\\\", \\\"{x:1324,y:298,t:1526922644096};\\\", \\\"{x:1326,y:266,t:1526922644113};\\\", \\\"{x:1328,y:246,t:1526922644129};\\\", \\\"{x:1328,y:231,t:1526922644145};\\\", \\\"{x:1331,y:221,t:1526922644162};\\\", \\\"{x:1331,y:215,t:1526922644179};\\\", \\\"{x:1331,y:213,t:1526922644196};\\\", \\\"{x:1331,y:213,t:1526922644251};\\\", \\\"{x:1332,y:212,t:1526922644298};\\\", \\\"{x:1332,y:213,t:1526922644314};\\\", \\\"{x:1332,y:233,t:1526922644329};\\\", \\\"{x:1332,y:264,t:1526922644346};\\\", \\\"{x:1332,y:312,t:1526922644363};\\\", \\\"{x:1332,y:365,t:1526922644380};\\\", \\\"{x:1341,y:435,t:1526922644396};\\\", \\\"{x:1360,y:525,t:1526922644413};\\\", \\\"{x:1375,y:606,t:1526922644430};\\\", \\\"{x:1384,y:663,t:1526922644446};\\\", \\\"{x:1394,y:716,t:1526922644463};\\\", \\\"{x:1398,y:749,t:1526922644480};\\\", \\\"{x:1400,y:775,t:1526922644497};\\\", \\\"{x:1403,y:797,t:1526922644513};\\\", \\\"{x:1403,y:824,t:1526922644530};\\\", \\\"{x:1402,y:834,t:1526922644546};\\\", \\\"{x:1397,y:844,t:1526922644563};\\\", \\\"{x:1388,y:855,t:1526922644581};\\\", \\\"{x:1374,y:868,t:1526922644596};\\\", \\\"{x:1355,y:885,t:1526922644613};\\\", \\\"{x:1332,y:904,t:1526922644631};\\\", \\\"{x:1298,y:920,t:1526922644647};\\\", \\\"{x:1265,y:933,t:1526922644663};\\\", \\\"{x:1241,y:942,t:1526922644680};\\\", \\\"{x:1218,y:952,t:1526922644697};\\\", \\\"{x:1215,y:954,t:1526922644712};\\\", \\\"{x:1210,y:957,t:1526922644730};\\\", \\\"{x:1210,y:959,t:1526922644857};\\\", \\\"{x:1210,y:960,t:1526922644865};\\\", \\\"{x:1210,y:962,t:1526922644881};\\\", \\\"{x:1210,y:962,t:1526922644882};\\\", \\\"{x:1210,y:964,t:1526922644897};\\\", \\\"{x:1210,y:966,t:1526922644914};\\\", \\\"{x:1212,y:968,t:1526922644930};\\\", \\\"{x:1213,y:970,t:1526922644947};\\\", \\\"{x:1214,y:970,t:1526922644964};\\\", \\\"{x:1215,y:970,t:1526922645043};\\\", \\\"{x:1215,y:971,t:1526922645050};\\\", \\\"{x:1216,y:971,t:1526922645211};\\\", \\\"{x:1217,y:970,t:1526922645234};\\\", \\\"{x:1218,y:970,t:1526922645247};\\\", \\\"{x:1219,y:968,t:1526922645265};\\\", \\\"{x:1222,y:965,t:1526922645282};\\\", \\\"{x:1232,y:949,t:1526922645298};\\\", \\\"{x:1242,y:930,t:1526922645314};\\\", \\\"{x:1253,y:901,t:1526922645331};\\\", \\\"{x:1260,y:859,t:1526922645347};\\\", \\\"{x:1253,y:749,t:1526922645364};\\\", \\\"{x:1201,y:636,t:1526922645381};\\\", \\\"{x:1121,y:535,t:1526922645398};\\\", \\\"{x:1003,y:439,t:1526922645414};\\\", \\\"{x:865,y:354,t:1526922645431};\\\", \\\"{x:740,y:307,t:1526922645448};\\\", \\\"{x:644,y:288,t:1526922645464};\\\", \\\"{x:590,y:286,t:1526922645481};\\\", \\\"{x:547,y:298,t:1526922645497};\\\", \\\"{x:535,y:316,t:1526922645514};\\\", \\\"{x:530,y:341,t:1526922645531};\\\", \\\"{x:531,y:364,t:1526922645548};\\\", \\\"{x:543,y:391,t:1526922645564};\\\", \\\"{x:562,y:417,t:1526922645581};\\\", \\\"{x:589,y:444,t:1526922645598};\\\", \\\"{x:606,y:464,t:1526922645613};\\\", \\\"{x:626,y:485,t:1526922645631};\\\", \\\"{x:649,y:500,t:1526922645648};\\\", \\\"{x:666,y:508,t:1526922645664};\\\", \\\"{x:680,y:513,t:1526922645680};\\\", \\\"{x:685,y:515,t:1526922645697};\\\", \\\"{x:681,y:516,t:1526922645770};\\\", \\\"{x:674,y:516,t:1526922645781};\\\", \\\"{x:654,y:516,t:1526922645798};\\\", \\\"{x:626,y:515,t:1526922645814};\\\", \\\"{x:600,y:509,t:1526922645831};\\\", \\\"{x:583,y:505,t:1526922645849};\\\", \\\"{x:580,y:504,t:1526922645864};\\\", \\\"{x:581,y:504,t:1526922645962};\\\", \\\"{x:582,y:504,t:1526922645970};\\\", \\\"{x:585,y:505,t:1526922645981};\\\", \\\"{x:592,y:508,t:1526922646000};\\\", \\\"{x:603,y:513,t:1526922646015};\\\", \\\"{x:620,y:517,t:1526922646031};\\\", \\\"{x:632,y:521,t:1526922646048};\\\", \\\"{x:637,y:523,t:1526922646064};\\\", \\\"{x:637,y:524,t:1526922646369};\\\", \\\"{x:636,y:526,t:1526922646938};\\\", \\\"{x:636,y:528,t:1526922646948};\\\", \\\"{x:631,y:541,t:1526922646966};\\\", \\\"{x:620,y:558,t:1526922646982};\\\", \\\"{x:602,y:582,t:1526922647000};\\\", \\\"{x:576,y:623,t:1526922647015};\\\", \\\"{x:555,y:655,t:1526922647032};\\\", \\\"{x:533,y:688,t:1526922647049};\\\", \\\"{x:520,y:706,t:1526922647065};\\\", \\\"{x:514,y:719,t:1526922647082};\\\", \\\"{x:506,y:735,t:1526922647098};\\\", \\\"{x:499,y:748,t:1526922647115};\\\", \\\"{x:492,y:759,t:1526922647131};\\\", \\\"{x:487,y:768,t:1526922647149};\\\", \\\"{x:484,y:771,t:1526922647165};\\\", \\\"{x:482,y:776,t:1526922647182};\\\", \\\"{x:481,y:777,t:1526922647198};\\\", \\\"{x:480,y:779,t:1526922647215};\\\", \\\"{x:478,y:781,t:1526922647232};\\\", \\\"{x:477,y:782,t:1526922647249};\\\", \\\"{x:477,y:783,t:1526922647265};\\\", \\\"{x:477,y:782,t:1526922647330};\\\", \\\"{x:477,y:781,t:1526922647337};\\\", \\\"{x:477,y:777,t:1526922647348};\\\", \\\"{x:477,y:770,t:1526922647366};\\\", \\\"{x:477,y:762,t:1526922647382};\\\", \\\"{x:479,y:749,t:1526922647398};\\\", \\\"{x:481,y:741,t:1526922647415};\\\", \\\"{x:484,y:736,t:1526922647433};\\\", \\\"{x:485,y:734,t:1526922647449};\\\", \\\"{x:486,y:732,t:1526922647466};\\\", \\\"{x:486,y:731,t:1526922647483};\\\", \\\"{x:486,y:730,t:1526922647633};\\\", \\\"{x:486,y:730,t:1526922647667};\\\" ] }, { \\\"rt\\\": 8293, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 268735, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:488,y:729,t:1526922651130};\\\", \\\"{x:499,y:726,t:1526922651137};\\\", \\\"{x:522,y:721,t:1526922651152};\\\", \\\"{x:654,y:706,t:1526922651171};\\\", \\\"{x:761,y:692,t:1526922651185};\\\", \\\"{x:870,y:688,t:1526922651202};\\\", \\\"{x:976,y:688,t:1526922651218};\\\", \\\"{x:1053,y:688,t:1526922651235};\\\", \\\"{x:1103,y:684,t:1526922651251};\\\", \\\"{x:1123,y:682,t:1526922651267};\\\", \\\"{x:1130,y:681,t:1526922651285};\\\", \\\"{x:1132,y:679,t:1526922651301};\\\", \\\"{x:1133,y:679,t:1526922651319};\\\", \\\"{x:1134,y:679,t:1526922651335};\\\", \\\"{x:1135,y:678,t:1526922651352};\\\", \\\"{x:1138,y:677,t:1526922651409};\\\", \\\"{x:1143,y:676,t:1526922651419};\\\", \\\"{x:1151,y:674,t:1526922651435};\\\", \\\"{x:1155,y:673,t:1526922651452};\\\", \\\"{x:1159,y:671,t:1526922651469};\\\", \\\"{x:1161,y:671,t:1526922651485};\\\", \\\"{x:1164,y:670,t:1526922651502};\\\", \\\"{x:1165,y:670,t:1526922651522};\\\", \\\"{x:1169,y:668,t:1526922651534};\\\", \\\"{x:1169,y:667,t:1526922651552};\\\", \\\"{x:1172,y:667,t:1526922651569};\\\", \\\"{x:1174,y:666,t:1526922651585};\\\", \\\"{x:1177,y:665,t:1526922651602};\\\", \\\"{x:1183,y:662,t:1526922651619};\\\", \\\"{x:1191,y:660,t:1526922651635};\\\", \\\"{x:1201,y:658,t:1526922651652};\\\", \\\"{x:1214,y:654,t:1526922651669};\\\", \\\"{x:1232,y:649,t:1526922651685};\\\", \\\"{x:1254,y:643,t:1526922651702};\\\", \\\"{x:1283,y:634,t:1526922651720};\\\", \\\"{x:1329,y:621,t:1526922651735};\\\", \\\"{x:1396,y:593,t:1526922651752};\\\", \\\"{x:1516,y:541,t:1526922651769};\\\", \\\"{x:1582,y:515,t:1526922651785};\\\", \\\"{x:1632,y:499,t:1526922651802};\\\", \\\"{x:1669,y:487,t:1526922651819};\\\", \\\"{x:1695,y:477,t:1526922651835};\\\", \\\"{x:1706,y:474,t:1526922651851};\\\", \\\"{x:1715,y:469,t:1526922651868};\\\", \\\"{x:1717,y:467,t:1526922651886};\\\", \\\"{x:1718,y:467,t:1526922651902};\\\", \\\"{x:1716,y:467,t:1526922652042};\\\", \\\"{x:1712,y:467,t:1526922652052};\\\", \\\"{x:1706,y:467,t:1526922652069};\\\", \\\"{x:1699,y:467,t:1526922652086};\\\", \\\"{x:1696,y:467,t:1526922652102};\\\", \\\"{x:1693,y:467,t:1526922652119};\\\", \\\"{x:1691,y:467,t:1526922652135};\\\", \\\"{x:1690,y:467,t:1526922652152};\\\", \\\"{x:1689,y:467,t:1526922652169};\\\", \\\"{x:1686,y:467,t:1526922652186};\\\", \\\"{x:1684,y:467,t:1526922652203};\\\", \\\"{x:1682,y:467,t:1526922652218};\\\", \\\"{x:1680,y:467,t:1526922652236};\\\", \\\"{x:1679,y:467,t:1526922652252};\\\", \\\"{x:1677,y:467,t:1526922652269};\\\", \\\"{x:1676,y:467,t:1526922652723};\\\", \\\"{x:1670,y:463,t:1526922652736};\\\", \\\"{x:1655,y:449,t:1526922652753};\\\", \\\"{x:1642,y:441,t:1526922652770};\\\", \\\"{x:1624,y:431,t:1526922652787};\\\", \\\"{x:1609,y:425,t:1526922652803};\\\", \\\"{x:1603,y:422,t:1526922652820};\\\", \\\"{x:1599,y:420,t:1526922652836};\\\", \\\"{x:1597,y:419,t:1526922652854};\\\", \\\"{x:1595,y:419,t:1526922652946};\\\", \\\"{x:1594,y:419,t:1526922652961};\\\", \\\"{x:1592,y:419,t:1526922652985};\\\", \\\"{x:1591,y:419,t:1526922653073};\\\", \\\"{x:1590,y:420,t:1526922653112};\\\", \\\"{x:1587,y:421,t:1526922653120};\\\", \\\"{x:1585,y:422,t:1526922653136};\\\", \\\"{x:1578,y:425,t:1526922653152};\\\", \\\"{x:1573,y:426,t:1526922653170};\\\", \\\"{x:1565,y:428,t:1526922653187};\\\", \\\"{x:1554,y:429,t:1526922653202};\\\", \\\"{x:1539,y:431,t:1526922653220};\\\", \\\"{x:1520,y:434,t:1526922653237};\\\", \\\"{x:1503,y:434,t:1526922653253};\\\", \\\"{x:1486,y:435,t:1526922653270};\\\", \\\"{x:1470,y:440,t:1526922653287};\\\", \\\"{x:1453,y:440,t:1526922653303};\\\", \\\"{x:1435,y:440,t:1526922653320};\\\", \\\"{x:1409,y:440,t:1526922653337};\\\", \\\"{x:1389,y:440,t:1526922653353};\\\", \\\"{x:1375,y:440,t:1526922653370};\\\", \\\"{x:1363,y:438,t:1526922653387};\\\", \\\"{x:1359,y:437,t:1526922653403};\\\", \\\"{x:1360,y:435,t:1526922653482};\\\", \\\"{x:1361,y:435,t:1526922653490};\\\", \\\"{x:1363,y:434,t:1526922653503};\\\", \\\"{x:1368,y:431,t:1526922653521};\\\", \\\"{x:1381,y:426,t:1526922653538};\\\", \\\"{x:1386,y:423,t:1526922653554};\\\", \\\"{x:1391,y:422,t:1526922653570};\\\", \\\"{x:1395,y:419,t:1526922653587};\\\", \\\"{x:1397,y:419,t:1526922653604};\\\", \\\"{x:1400,y:417,t:1526922653620};\\\", \\\"{x:1404,y:417,t:1526922653638};\\\", \\\"{x:1407,y:417,t:1526922653654};\\\", \\\"{x:1410,y:417,t:1526922653670};\\\", \\\"{x:1411,y:417,t:1526922653687};\\\", \\\"{x:1410,y:419,t:1526922653786};\\\", \\\"{x:1406,y:420,t:1526922653795};\\\", \\\"{x:1400,y:423,t:1526922653804};\\\", \\\"{x:1383,y:429,t:1526922653820};\\\", \\\"{x:1329,y:441,t:1526922653838};\\\", \\\"{x:1249,y:450,t:1526922653855};\\\", \\\"{x:1147,y:450,t:1526922653870};\\\", \\\"{x:1028,y:450,t:1526922653888};\\\", \\\"{x:922,y:450,t:1526922653905};\\\", \\\"{x:866,y:450,t:1526922653921};\\\", \\\"{x:842,y:450,t:1526922653937};\\\", \\\"{x:839,y:450,t:1526922653955};\\\", \\\"{x:838,y:450,t:1526922653971};\\\", \\\"{x:831,y:456,t:1526922653994};\\\", \\\"{x:818,y:462,t:1526922654005};\\\", \\\"{x:799,y:472,t:1526922654021};\\\", \\\"{x:797,y:480,t:1526922654037};\\\", \\\"{x:797,y:485,t:1526922654054};\\\", \\\"{x:799,y:489,t:1526922654072};\\\", \\\"{x:801,y:493,t:1526922654087};\\\", \\\"{x:801,y:494,t:1526922654105};\\\", \\\"{x:801,y:499,t:1526922654122};\\\", \\\"{x:796,y:507,t:1526922654139};\\\", \\\"{x:784,y:515,t:1526922654153};\\\", \\\"{x:764,y:526,t:1526922654171};\\\", \\\"{x:742,y:535,t:1526922654186};\\\", \\\"{x:718,y:544,t:1526922654204};\\\", \\\"{x:692,y:555,t:1526922654221};\\\", \\\"{x:663,y:566,t:1526922654237};\\\", \\\"{x:643,y:574,t:1526922654254};\\\", \\\"{x:637,y:578,t:1526922654271};\\\", \\\"{x:631,y:582,t:1526922654288};\\\", \\\"{x:625,y:586,t:1526922654304};\\\", \\\"{x:623,y:588,t:1526922654321};\\\", \\\"{x:621,y:590,t:1526922654337};\\\", \\\"{x:620,y:591,t:1526922654353};\\\", \\\"{x:619,y:592,t:1526922654371};\\\", \\\"{x:619,y:593,t:1526922654387};\\\", \\\"{x:618,y:594,t:1526922654404};\\\", \\\"{x:617,y:595,t:1526922654466};\\\", \\\"{x:616,y:595,t:1526922654473};\\\", \\\"{x:614,y:595,t:1526922654488};\\\", \\\"{x:607,y:595,t:1526922654505};\\\", \\\"{x:581,y:594,t:1526922654523};\\\", \\\"{x:559,y:588,t:1526922654537};\\\", \\\"{x:529,y:579,t:1526922654554};\\\", \\\"{x:490,y:560,t:1526922654572};\\\", \\\"{x:451,y:544,t:1526922654588};\\\", \\\"{x:428,y:539,t:1526922654604};\\\", \\\"{x:395,y:543,t:1526922654621};\\\", \\\"{x:357,y:556,t:1526922654639};\\\", \\\"{x:332,y:561,t:1526922654654};\\\", \\\"{x:323,y:564,t:1526922654671};\\\", \\\"{x:320,y:565,t:1526922654687};\\\", \\\"{x:324,y:566,t:1526922654874};\\\", \\\"{x:332,y:568,t:1526922654889};\\\", \\\"{x:350,y:570,t:1526922654905};\\\", \\\"{x:353,y:570,t:1526922654922};\\\", \\\"{x:355,y:570,t:1526922654938};\\\", \\\"{x:356,y:570,t:1526922654955};\\\", \\\"{x:358,y:570,t:1526922654977};\\\", \\\"{x:359,y:570,t:1526922655009};\\\", \\\"{x:362,y:570,t:1526922655025};\\\", \\\"{x:363,y:569,t:1526922655042};\\\", \\\"{x:365,y:569,t:1526922655056};\\\", \\\"{x:368,y:568,t:1526922655071};\\\", \\\"{x:375,y:564,t:1526922655089};\\\", \\\"{x:382,y:557,t:1526922655105};\\\", \\\"{x:386,y:554,t:1526922655122};\\\", \\\"{x:388,y:550,t:1526922655138};\\\", \\\"{x:389,y:546,t:1526922655155};\\\", \\\"{x:389,y:542,t:1526922655171};\\\", \\\"{x:389,y:538,t:1526922655188};\\\", \\\"{x:376,y:532,t:1526922655206};\\\", \\\"{x:354,y:521,t:1526922655222};\\\", \\\"{x:323,y:512,t:1526922655238};\\\", \\\"{x:290,y:508,t:1526922655254};\\\", \\\"{x:256,y:504,t:1526922655272};\\\", \\\"{x:229,y:504,t:1526922655288};\\\", \\\"{x:210,y:506,t:1526922655305};\\\", \\\"{x:208,y:507,t:1526922655321};\\\", \\\"{x:206,y:509,t:1526922655338};\\\", \\\"{x:205,y:515,t:1526922655355};\\\", \\\"{x:203,y:524,t:1526922655371};\\\", \\\"{x:203,y:540,t:1526922655388};\\\", \\\"{x:204,y:563,t:1526922655405};\\\", \\\"{x:215,y:592,t:1526922655423};\\\", \\\"{x:226,y:616,t:1526922655439};\\\", \\\"{x:245,y:641,t:1526922655457};\\\", \\\"{x:265,y:664,t:1526922655473};\\\", \\\"{x:294,y:685,t:1526922655488};\\\", \\\"{x:369,y:707,t:1526922655505};\\\", \\\"{x:434,y:717,t:1526922655522};\\\", \\\"{x:517,y:728,t:1526922655538};\\\", \\\"{x:602,y:734,t:1526922655555};\\\", \\\"{x:677,y:734,t:1526922655572};\\\", \\\"{x:738,y:734,t:1526922655588};\\\", \\\"{x:819,y:722,t:1526922655605};\\\", \\\"{x:874,y:709,t:1526922655621};\\\", \\\"{x:929,y:687,t:1526922655638};\\\", \\\"{x:983,y:655,t:1526922655655};\\\", \\\"{x:1023,y:626,t:1526922655671};\\\", \\\"{x:1048,y:589,t:1526922655688};\\\", \\\"{x:1064,y:545,t:1526922655704};\\\", \\\"{x:1070,y:521,t:1526922655721};\\\", \\\"{x:1070,y:507,t:1526922655738};\\\", \\\"{x:1064,y:495,t:1526922655754};\\\", \\\"{x:1053,y:487,t:1526922655771};\\\", \\\"{x:1037,y:482,t:1526922655788};\\\", \\\"{x:1022,y:482,t:1526922655804};\\\", \\\"{x:1012,y:484,t:1526922655821};\\\", \\\"{x:1003,y:488,t:1526922655838};\\\", \\\"{x:988,y:498,t:1526922655854};\\\", \\\"{x:972,y:509,t:1526922655871};\\\", \\\"{x:964,y:519,t:1526922655888};\\\", \\\"{x:956,y:532,t:1526922655904};\\\", \\\"{x:950,y:543,t:1526922655922};\\\", \\\"{x:947,y:548,t:1526922655938};\\\", \\\"{x:946,y:552,t:1526922655954};\\\", \\\"{x:946,y:553,t:1526922655972};\\\", \\\"{x:945,y:555,t:1526922655989};\\\", \\\"{x:943,y:557,t:1526922656005};\\\", \\\"{x:938,y:560,t:1526922656022};\\\", \\\"{x:931,y:563,t:1526922656039};\\\", \\\"{x:917,y:565,t:1526922656056};\\\", \\\"{x:903,y:565,t:1526922656072};\\\", \\\"{x:876,y:565,t:1526922656089};\\\", \\\"{x:859,y:563,t:1526922656107};\\\", \\\"{x:840,y:560,t:1526922656122};\\\", \\\"{x:832,y:558,t:1526922656139};\\\", \\\"{x:830,y:558,t:1526922656156};\\\", \\\"{x:829,y:557,t:1526922656216};\\\", \\\"{x:824,y:555,t:1526922656433};\\\", \\\"{x:820,y:555,t:1526922656440};\\\", \\\"{x:816,y:555,t:1526922656456};\\\", \\\"{x:799,y:559,t:1526922656472};\\\", \\\"{x:740,y:587,t:1526922656490};\\\", \\\"{x:677,y:621,t:1526922656506};\\\", \\\"{x:621,y:659,t:1526922656523};\\\", \\\"{x:584,y:703,t:1526922656539};\\\", \\\"{x:572,y:725,t:1526922656556};\\\", \\\"{x:564,y:739,t:1526922656572};\\\", \\\"{x:563,y:745,t:1526922656589};\\\", \\\"{x:562,y:747,t:1526922656606};\\\", \\\"{x:561,y:748,t:1526922656622};\\\", \\\"{x:561,y:749,t:1526922656639};\\\", \\\"{x:560,y:749,t:1526922656672};\\\", \\\"{x:558,y:749,t:1526922656689};\\\", \\\"{x:552,y:749,t:1526922656706};\\\", \\\"{x:540,y:750,t:1526922656723};\\\", \\\"{x:526,y:753,t:1526922656739};\\\", \\\"{x:516,y:753,t:1526922656756};\\\", \\\"{x:505,y:753,t:1526922656773};\\\", \\\"{x:500,y:753,t:1526922656789};\\\", \\\"{x:498,y:753,t:1526922656806};\\\", \\\"{x:495,y:753,t:1526922656823};\\\", \\\"{x:493,y:753,t:1526922656874};\\\", \\\"{x:493,y:752,t:1526922656898};\\\", \\\"{x:493,y:750,t:1526922656907};\\\", \\\"{x:496,y:746,t:1526922656923};\\\", \\\"{x:498,y:742,t:1526922656939};\\\", \\\"{x:501,y:737,t:1526922656956};\\\", \\\"{x:501,y:734,t:1526922656973};\\\", \\\"{x:501,y:733,t:1526922656992};\\\", \\\"{x:502,y:731,t:1526922657006};\\\", \\\"{x:503,y:730,t:1526922657023};\\\", \\\"{x:503,y:729,t:1526922657737};\\\", \\\"{x:504,y:729,t:1526922657769};\\\", \\\"{x:505,y:728,t:1526922657818};\\\" ] }, { \\\"rt\\\": 23331, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 293295, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -C -B \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:727,t:1526922659545};\\\", \\\"{x:508,y:727,t:1526922661722};\\\", \\\"{x:514,y:727,t:1526922661730};\\\", \\\"{x:529,y:721,t:1526922661747};\\\", \\\"{x:553,y:711,t:1526922661763};\\\", \\\"{x:578,y:706,t:1526922661781};\\\", \\\"{x:615,y:700,t:1526922661796};\\\", \\\"{x:663,y:699,t:1526922661813};\\\", \\\"{x:722,y:691,t:1526922661827};\\\", \\\"{x:782,y:684,t:1526922661843};\\\", \\\"{x:864,y:667,t:1526922661860};\\\", \\\"{x:930,y:650,t:1526922661877};\\\", \\\"{x:1000,y:628,t:1526922661893};\\\", \\\"{x:1073,y:604,t:1526922661910};\\\", \\\"{x:1143,y:572,t:1526922661928};\\\", \\\"{x:1207,y:541,t:1526922661944};\\\", \\\"{x:1247,y:521,t:1526922661960};\\\", \\\"{x:1285,y:490,t:1526922661977};\\\", \\\"{x:1303,y:477,t:1526922661994};\\\", \\\"{x:1316,y:469,t:1526922662010};\\\", \\\"{x:1327,y:463,t:1526922662027};\\\", \\\"{x:1335,y:460,t:1526922662045};\\\", \\\"{x:1339,y:459,t:1526922662061};\\\", \\\"{x:1342,y:457,t:1526922662077};\\\", \\\"{x:1346,y:456,t:1526922662095};\\\", \\\"{x:1350,y:454,t:1526922662110};\\\", \\\"{x:1351,y:454,t:1526922662128};\\\", \\\"{x:1353,y:454,t:1526922662144};\\\", \\\"{x:1351,y:455,t:1526922662194};\\\", \\\"{x:1348,y:458,t:1526922662211};\\\", \\\"{x:1344,y:465,t:1526922662228};\\\", \\\"{x:1337,y:475,t:1526922662245};\\\", \\\"{x:1332,y:483,t:1526922662262};\\\", \\\"{x:1326,y:495,t:1526922662277};\\\", \\\"{x:1318,y:510,t:1526922662295};\\\", \\\"{x:1314,y:519,t:1526922662312};\\\", \\\"{x:1312,y:527,t:1526922662328};\\\", \\\"{x:1312,y:531,t:1526922662344};\\\", \\\"{x:1312,y:537,t:1526922662362};\\\", \\\"{x:1312,y:539,t:1526922662378};\\\", \\\"{x:1312,y:542,t:1526922662395};\\\", \\\"{x:1312,y:545,t:1526922662411};\\\", \\\"{x:1312,y:549,t:1526922662429};\\\", \\\"{x:1306,y:558,t:1526922662445};\\\", \\\"{x:1297,y:567,t:1526922662461};\\\", \\\"{x:1289,y:572,t:1526922662478};\\\", \\\"{x:1276,y:580,t:1526922662495};\\\", \\\"{x:1264,y:587,t:1526922662512};\\\", \\\"{x:1249,y:594,t:1526922662529};\\\", \\\"{x:1243,y:598,t:1526922662545};\\\", \\\"{x:1236,y:602,t:1526922662561};\\\", \\\"{x:1235,y:603,t:1526922662578};\\\", \\\"{x:1234,y:605,t:1526922662595};\\\", \\\"{x:1233,y:606,t:1526922662611};\\\", \\\"{x:1233,y:607,t:1526922662666};\\\", \\\"{x:1233,y:609,t:1526922662678};\\\", \\\"{x:1233,y:614,t:1526922662695};\\\", \\\"{x:1233,y:616,t:1526922662712};\\\", \\\"{x:1233,y:618,t:1526922662729};\\\", \\\"{x:1234,y:621,t:1526922662745};\\\", \\\"{x:1235,y:624,t:1526922662761};\\\", \\\"{x:1236,y:625,t:1526922662778};\\\", \\\"{x:1236,y:626,t:1526922662796};\\\", \\\"{x:1236,y:627,t:1526922662812};\\\", \\\"{x:1236,y:630,t:1526922662829};\\\", \\\"{x:1236,y:632,t:1526922662846};\\\", \\\"{x:1235,y:632,t:1526922662862};\\\", \\\"{x:1232,y:635,t:1526922662879};\\\", \\\"{x:1229,y:637,t:1526922662896};\\\", \\\"{x:1226,y:640,t:1526922662913};\\\", \\\"{x:1224,y:642,t:1526922662929};\\\", \\\"{x:1224,y:644,t:1526922662945};\\\", \\\"{x:1222,y:646,t:1526922662962};\\\", \\\"{x:1222,y:650,t:1526922662978};\\\", \\\"{x:1222,y:656,t:1526922662996};\\\", \\\"{x:1222,y:669,t:1526922663013};\\\", \\\"{x:1225,y:690,t:1526922663029};\\\", \\\"{x:1232,y:713,t:1526922663046};\\\", \\\"{x:1240,y:730,t:1526922663062};\\\", \\\"{x:1241,y:737,t:1526922663079};\\\", \\\"{x:1244,y:746,t:1526922663096};\\\", \\\"{x:1245,y:757,t:1526922663113};\\\", \\\"{x:1246,y:774,t:1526922663130};\\\", \\\"{x:1246,y:782,t:1526922663146};\\\", \\\"{x:1244,y:787,t:1526922663163};\\\", \\\"{x:1241,y:791,t:1526922663180};\\\", \\\"{x:1237,y:794,t:1526922663196};\\\", \\\"{x:1234,y:797,t:1526922663213};\\\", \\\"{x:1230,y:798,t:1526922663230};\\\", \\\"{x:1230,y:799,t:1526922663246};\\\", \\\"{x:1228,y:799,t:1526922663265};\\\", \\\"{x:1227,y:800,t:1526922663314};\\\", \\\"{x:1226,y:800,t:1526922663329};\\\", \\\"{x:1225,y:802,t:1526922663345};\\\", \\\"{x:1224,y:804,t:1526922663362};\\\", \\\"{x:1222,y:806,t:1526922663380};\\\", \\\"{x:1221,y:808,t:1526922663396};\\\", \\\"{x:1220,y:816,t:1526922663412};\\\", \\\"{x:1219,y:820,t:1526922663429};\\\", \\\"{x:1217,y:824,t:1526922663446};\\\", \\\"{x:1217,y:826,t:1526922663464};\\\", \\\"{x:1216,y:828,t:1526922663479};\\\", \\\"{x:1213,y:832,t:1526922663496};\\\", \\\"{x:1213,y:834,t:1526922663513};\\\", \\\"{x:1213,y:833,t:1526922663658};\\\", \\\"{x:1213,y:832,t:1526922663666};\\\", \\\"{x:1214,y:830,t:1526922663680};\\\", \\\"{x:1216,y:829,t:1526922663697};\\\", \\\"{x:1220,y:827,t:1526922663715};\\\", \\\"{x:1221,y:827,t:1526922663730};\\\", \\\"{x:1222,y:826,t:1526922663747};\\\", \\\"{x:1223,y:825,t:1526922663930};\\\", \\\"{x:1226,y:825,t:1526922663947};\\\", \\\"{x:1230,y:825,t:1526922663964};\\\", \\\"{x:1231,y:825,t:1526922663981};\\\", \\\"{x:1233,y:825,t:1526922663997};\\\", \\\"{x:1230,y:825,t:1526922664194};\\\", \\\"{x:1228,y:825,t:1526922664201};\\\", \\\"{x:1227,y:825,t:1526922664214};\\\", \\\"{x:1224,y:825,t:1526922664232};\\\", \\\"{x:1223,y:825,t:1526922664248};\\\", \\\"{x:1221,y:825,t:1526922664266};\\\", \\\"{x:1220,y:825,t:1526922664289};\\\", \\\"{x:1219,y:826,t:1526922664338};\\\", \\\"{x:1219,y:827,t:1526922664365};\\\", \\\"{x:1218,y:828,t:1526922664380};\\\", \\\"{x:1217,y:828,t:1526922664409};\\\", \\\"{x:1216,y:830,t:1526922664482};\\\", \\\"{x:1214,y:831,t:1526922664521};\\\", \\\"{x:1214,y:832,t:1526922664537};\\\", \\\"{x:1213,y:833,t:1526922664547};\\\", \\\"{x:1213,y:834,t:1526922664569};\\\", \\\"{x:1212,y:834,t:1526922664581};\\\", \\\"{x:1212,y:833,t:1526922666481};\\\", \\\"{x:1212,y:832,t:1526922666890};\\\", \\\"{x:1212,y:831,t:1526922666902};\\\", \\\"{x:1212,y:830,t:1526922666945};\\\", \\\"{x:1212,y:829,t:1526922667449};\\\", \\\"{x:1212,y:828,t:1526922667457};\\\", \\\"{x:1212,y:827,t:1526922667474};\\\", \\\"{x:1212,y:826,t:1526922667489};\\\", \\\"{x:1212,y:825,t:1526922667501};\\\", \\\"{x:1212,y:824,t:1526922667978};\\\", \\\"{x:1213,y:823,t:1526922668017};\\\", \\\"{x:1214,y:822,t:1526922669498};\\\", \\\"{x:1216,y:820,t:1526922669513};\\\", \\\"{x:1217,y:819,t:1526922669522};\\\", \\\"{x:1218,y:819,t:1526922669540};\\\", \\\"{x:1218,y:818,t:1526922669555};\\\", \\\"{x:1219,y:816,t:1526922669572};\\\", \\\"{x:1219,y:815,t:1526922669593};\\\", \\\"{x:1220,y:815,t:1526922669605};\\\", \\\"{x:1220,y:814,t:1526922669642};\\\", \\\"{x:1221,y:814,t:1526922669673};\\\", \\\"{x:1221,y:813,t:1526922669689};\\\", \\\"{x:1221,y:812,t:1526922669730};\\\", \\\"{x:1221,y:811,t:1526922670754};\\\", \\\"{x:1222,y:811,t:1526922672001};\\\", \\\"{x:1223,y:811,t:1526922672010};\\\", \\\"{x:1228,y:808,t:1526922672025};\\\", \\\"{x:1232,y:807,t:1526922672042};\\\", \\\"{x:1235,y:805,t:1526922672060};\\\", \\\"{x:1240,y:805,t:1526922672076};\\\", \\\"{x:1247,y:805,t:1526922672092};\\\", \\\"{x:1257,y:805,t:1526922672109};\\\", \\\"{x:1270,y:808,t:1526922672126};\\\", \\\"{x:1285,y:812,t:1526922672142};\\\", \\\"{x:1304,y:818,t:1526922672159};\\\", \\\"{x:1323,y:823,t:1526922672176};\\\", \\\"{x:1348,y:831,t:1526922672192};\\\", \\\"{x:1383,y:838,t:1526922672209};\\\", \\\"{x:1404,y:843,t:1526922672226};\\\", \\\"{x:1425,y:849,t:1526922672242};\\\", \\\"{x:1442,y:853,t:1526922672259};\\\", \\\"{x:1463,y:857,t:1526922672276};\\\", \\\"{x:1481,y:860,t:1526922672293};\\\", \\\"{x:1500,y:862,t:1526922672309};\\\", \\\"{x:1516,y:865,t:1526922672326};\\\", \\\"{x:1531,y:867,t:1526922672343};\\\", \\\"{x:1541,y:867,t:1526922672359};\\\", \\\"{x:1547,y:867,t:1526922672376};\\\", \\\"{x:1551,y:867,t:1526922672393};\\\", \\\"{x:1552,y:867,t:1526922672417};\\\", \\\"{x:1553,y:867,t:1526922672434};\\\", \\\"{x:1554,y:867,t:1526922672443};\\\", \\\"{x:1556,y:867,t:1526922672459};\\\", \\\"{x:1558,y:867,t:1526922672476};\\\", \\\"{x:1561,y:865,t:1526922672493};\\\", \\\"{x:1564,y:864,t:1526922672510};\\\", \\\"{x:1569,y:861,t:1526922672526};\\\", \\\"{x:1573,y:858,t:1526922672543};\\\", \\\"{x:1576,y:857,t:1526922672560};\\\", \\\"{x:1579,y:855,t:1526922672576};\\\", \\\"{x:1586,y:851,t:1526922672594};\\\", \\\"{x:1592,y:847,t:1526922672610};\\\", \\\"{x:1595,y:846,t:1526922672626};\\\", \\\"{x:1603,y:842,t:1526922672643};\\\", \\\"{x:1611,y:840,t:1526922672660};\\\", \\\"{x:1620,y:837,t:1526922672676};\\\", \\\"{x:1629,y:834,t:1526922672693};\\\", \\\"{x:1634,y:831,t:1526922672710};\\\", \\\"{x:1643,y:829,t:1526922672727};\\\", \\\"{x:1649,y:828,t:1526922672743};\\\", \\\"{x:1658,y:825,t:1526922672760};\\\", \\\"{x:1671,y:824,t:1526922672777};\\\", \\\"{x:1678,y:823,t:1526922672794};\\\", \\\"{x:1682,y:823,t:1526922672810};\\\", \\\"{x:1683,y:823,t:1526922672827};\\\", \\\"{x:1684,y:821,t:1526922673930};\\\", \\\"{x:1659,y:809,t:1526922673945};\\\", \\\"{x:1571,y:786,t:1526922673962};\\\", \\\"{x:1439,y:754,t:1526922673979};\\\", \\\"{x:1290,y:714,t:1526922673995};\\\", \\\"{x:1161,y:685,t:1526922674012};\\\", \\\"{x:1045,y:654,t:1526922674028};\\\", \\\"{x:948,y:638,t:1526922674046};\\\", \\\"{x:871,y:624,t:1526922674062};\\\", \\\"{x:818,y:614,t:1526922674078};\\\", \\\"{x:778,y:601,t:1526922674097};\\\", \\\"{x:747,y:593,t:1526922674112};\\\", \\\"{x:709,y:589,t:1526922674129};\\\", \\\"{x:698,y:587,t:1526922674137};\\\", \\\"{x:674,y:583,t:1526922674153};\\\", \\\"{x:648,y:581,t:1526922674170};\\\", \\\"{x:603,y:574,t:1526922674187};\\\", \\\"{x:558,y:568,t:1526922674203};\\\", \\\"{x:524,y:562,t:1526922674220};\\\", \\\"{x:497,y:557,t:1526922674237};\\\", \\\"{x:469,y:554,t:1526922674254};\\\", \\\"{x:441,y:552,t:1526922674270};\\\", \\\"{x:420,y:552,t:1526922674287};\\\", \\\"{x:404,y:552,t:1526922674304};\\\", \\\"{x:389,y:555,t:1526922674320};\\\", \\\"{x:387,y:557,t:1526922674336};\\\", \\\"{x:393,y:560,t:1526922674401};\\\", \\\"{x:410,y:567,t:1526922674409};\\\", \\\"{x:439,y:581,t:1526922674422};\\\", \\\"{x:511,y:611,t:1526922674437};\\\", \\\"{x:574,y:635,t:1526922674454};\\\", \\\"{x:612,y:645,t:1526922674471};\\\", \\\"{x:638,y:656,t:1526922674487};\\\", \\\"{x:650,y:661,t:1526922674503};\\\", \\\"{x:656,y:665,t:1526922674520};\\\", \\\"{x:657,y:665,t:1526922674592};\\\", \\\"{x:657,y:666,t:1526922674722};\\\", \\\"{x:656,y:666,t:1526922674738};\\\", \\\"{x:650,y:666,t:1526922674755};\\\", \\\"{x:645,y:662,t:1526922674770};\\\", \\\"{x:637,y:658,t:1526922674788};\\\", \\\"{x:631,y:653,t:1526922674805};\\\", \\\"{x:628,y:652,t:1526922674821};\\\", \\\"{x:627,y:651,t:1526922674838};\\\", \\\"{x:627,y:650,t:1526922674939};\\\", \\\"{x:627,y:649,t:1526922675024};\\\", \\\"{x:627,y:648,t:1526922675032};\\\", \\\"{x:627,y:648,t:1526922675035};\\\", \\\"{x:629,y:648,t:1526922675052};\\\", \\\"{x:629,y:647,t:1526922675069};\\\", \\\"{x:630,y:645,t:1526922675475};\\\", \\\"{x:630,y:642,t:1526922675484};\\\", \\\"{x:630,y:636,t:1526922675504};\\\", \\\"{x:630,y:634,t:1526922675521};\\\", \\\"{x:630,y:633,t:1526922675538};\\\", \\\"{x:630,y:632,t:1526922675555};\\\", \\\"{x:630,y:631,t:1526922675622};\\\", \\\"{x:632,y:631,t:1526922675638};\\\", \\\"{x:633,y:630,t:1526922675655};\\\", \\\"{x:635,y:630,t:1526922675671};\\\", \\\"{x:635,y:630,t:1526922675738};\\\", \\\"{x:635,y:629,t:1526922676098};\\\", \\\"{x:633,y:629,t:1526922676113};\\\", \\\"{x:632,y:629,t:1526922676129};\\\", \\\"{x:631,y:629,t:1526922676424};\\\", \\\"{x:630,y:629,t:1526922676456};\\\", \\\"{x:629,y:629,t:1526922676472};\\\", \\\"{x:627,y:630,t:1526922676488};\\\", \\\"{x:625,y:632,t:1526922676505};\\\", \\\"{x:622,y:632,t:1526922676522};\\\", \\\"{x:620,y:632,t:1526922676540};\\\", \\\"{x:618,y:633,t:1526922676556};\\\", \\\"{x:617,y:633,t:1526922676572};\\\", \\\"{x:616,y:633,t:1526922676588};\\\", \\\"{x:614,y:633,t:1526922676606};\\\", \\\"{x:612,y:633,t:1526922676621};\\\", \\\"{x:610,y:633,t:1526922676639};\\\", \\\"{x:608,y:633,t:1526922676656};\\\", \\\"{x:606,y:633,t:1526922676672};\\\", \\\"{x:600,y:630,t:1526922676688};\\\", \\\"{x:596,y:628,t:1526922676707};\\\", \\\"{x:594,y:626,t:1526922676722};\\\", \\\"{x:590,y:624,t:1526922676739};\\\", \\\"{x:588,y:623,t:1526922676755};\\\", \\\"{x:586,y:622,t:1526922676772};\\\", \\\"{x:585,y:621,t:1526922676789};\\\", \\\"{x:583,y:620,t:1526922676808};\\\", \\\"{x:582,y:620,t:1526922677041};\\\", \\\"{x:582,y:619,t:1526922677057};\\\", \\\"{x:581,y:615,t:1526922677073};\\\", \\\"{x:577,y:609,t:1526922677090};\\\", \\\"{x:575,y:606,t:1526922677106};\\\", \\\"{x:572,y:601,t:1526922677123};\\\", \\\"{x:571,y:599,t:1526922677138};\\\", \\\"{x:570,y:597,t:1526922677156};\\\", \\\"{x:568,y:595,t:1526922677173};\\\", \\\"{x:568,y:593,t:1526922677189};\\\", \\\"{x:567,y:590,t:1526922677205};\\\", \\\"{x:566,y:589,t:1526922677223};\\\", \\\"{x:565,y:587,t:1526922677240};\\\", \\\"{x:564,y:586,t:1526922677256};\\\", \\\"{x:563,y:583,t:1526922677272};\\\", \\\"{x:561,y:582,t:1526922677288};\\\", \\\"{x:561,y:580,t:1526922677306};\\\", \\\"{x:560,y:580,t:1526922677323};\\\", \\\"{x:560,y:579,t:1526922677339};\\\", \\\"{x:558,y:577,t:1526922677393};\\\", \\\"{x:558,y:576,t:1526922677409};\\\", \\\"{x:557,y:575,t:1526922677424};\\\", \\\"{x:555,y:575,t:1526922677441};\\\", \\\"{x:554,y:575,t:1526922677465};\\\", \\\"{x:553,y:573,t:1526922677474};\\\", \\\"{x:552,y:573,t:1526922677496};\\\", \\\"{x:551,y:572,t:1526922677520};\\\", \\\"{x:550,y:571,t:1526922677552};\\\", \\\"{x:549,y:571,t:1526922677608};\\\", \\\"{x:548,y:571,t:1526922677622};\\\", \\\"{x:548,y:570,t:1526922677640};\\\", \\\"{x:547,y:570,t:1526922677664};\\\", \\\"{x:546,y:568,t:1526922677696};\\\", \\\"{x:544,y:567,t:1526922677737};\\\", \\\"{x:544,y:566,t:1526922677745};\\\", \\\"{x:543,y:565,t:1526922677809};\\\", \\\"{x:543,y:564,t:1526922677833};\\\", \\\"{x:542,y:563,t:1526922677840};\\\", \\\"{x:541,y:560,t:1526922677857};\\\", \\\"{x:541,y:557,t:1526922677873};\\\", \\\"{x:541,y:553,t:1526922677890};\\\", \\\"{x:541,y:550,t:1526922677907};\\\", \\\"{x:544,y:545,t:1526922677923};\\\", \\\"{x:550,y:541,t:1526922677941};\\\", \\\"{x:556,y:535,t:1526922677959};\\\", \\\"{x:563,y:528,t:1526922677973};\\\", \\\"{x:573,y:519,t:1526922677990};\\\", \\\"{x:587,y:507,t:1526922678007};\\\", \\\"{x:606,y:496,t:1526922678024};\\\", \\\"{x:628,y:486,t:1526922678040};\\\", \\\"{x:675,y:465,t:1526922678056};\\\", \\\"{x:710,y:453,t:1526922678074};\\\", \\\"{x:740,y:448,t:1526922678090};\\\", \\\"{x:767,y:448,t:1526922678107};\\\", \\\"{x:791,y:452,t:1526922678123};\\\", \\\"{x:814,y:460,t:1526922678141};\\\", \\\"{x:838,y:470,t:1526922678157};\\\", \\\"{x:850,y:477,t:1526922678173};\\\", \\\"{x:856,y:482,t:1526922678190};\\\", \\\"{x:858,y:487,t:1526922678207};\\\", \\\"{x:858,y:495,t:1526922678224};\\\", \\\"{x:853,y:501,t:1526922678240};\\\", \\\"{x:820,y:513,t:1526922678257};\\\", \\\"{x:779,y:518,t:1526922678274};\\\", \\\"{x:737,y:518,t:1526922678290};\\\", \\\"{x:700,y:518,t:1526922678307};\\\", \\\"{x:675,y:518,t:1526922678323};\\\", \\\"{x:659,y:519,t:1526922678339};\\\", \\\"{x:654,y:520,t:1526922678356};\\\", \\\"{x:650,y:522,t:1526922678373};\\\", \\\"{x:646,y:525,t:1526922678390};\\\", \\\"{x:642,y:529,t:1526922678406};\\\", \\\"{x:637,y:535,t:1526922678424};\\\", \\\"{x:630,y:548,t:1526922678441};\\\", \\\"{x:628,y:556,t:1526922678456};\\\", \\\"{x:625,y:568,t:1526922678474};\\\", \\\"{x:624,y:577,t:1526922678490};\\\", \\\"{x:623,y:582,t:1526922678507};\\\", \\\"{x:623,y:583,t:1526922678524};\\\", \\\"{x:623,y:585,t:1526922678541};\\\", \\\"{x:618,y:587,t:1526922678556};\\\", \\\"{x:603,y:591,t:1526922678574};\\\", \\\"{x:565,y:591,t:1526922678590};\\\", \\\"{x:503,y:582,t:1526922678607};\\\", \\\"{x:441,y:568,t:1526922678624};\\\", \\\"{x:357,y:544,t:1526922678640};\\\", \\\"{x:317,y:531,t:1526922678658};\\\", \\\"{x:304,y:525,t:1526922678674};\\\", \\\"{x:300,y:521,t:1526922678690};\\\", \\\"{x:298,y:519,t:1526922678707};\\\", \\\"{x:294,y:517,t:1526922678724};\\\", \\\"{x:288,y:514,t:1526922678740};\\\", \\\"{x:285,y:512,t:1526922678757};\\\", \\\"{x:282,y:509,t:1526922678774};\\\", \\\"{x:280,y:508,t:1526922678790};\\\", \\\"{x:277,y:504,t:1526922678807};\\\", \\\"{x:275,y:503,t:1526922678824};\\\", \\\"{x:269,y:502,t:1526922678840};\\\", \\\"{x:259,y:502,t:1526922678857};\\\", \\\"{x:252,y:502,t:1526922678874};\\\", \\\"{x:246,y:502,t:1526922678891};\\\", \\\"{x:242,y:502,t:1526922678907};\\\", \\\"{x:234,y:505,t:1526922678924};\\\", \\\"{x:221,y:509,t:1526922678942};\\\", \\\"{x:209,y:511,t:1526922678958};\\\", \\\"{x:197,y:516,t:1526922678974};\\\", \\\"{x:188,y:520,t:1526922678991};\\\", \\\"{x:182,y:525,t:1526922679006};\\\", \\\"{x:177,y:529,t:1526922679024};\\\", \\\"{x:171,y:539,t:1526922679041};\\\", \\\"{x:167,y:550,t:1526922679058};\\\", \\\"{x:166,y:560,t:1526922679073};\\\", \\\"{x:164,y:573,t:1526922679091};\\\", \\\"{x:164,y:580,t:1526922679108};\\\", \\\"{x:162,y:587,t:1526922679125};\\\", \\\"{x:162,y:593,t:1526922679141};\\\", \\\"{x:162,y:597,t:1526922679158};\\\", \\\"{x:163,y:601,t:1526922679173};\\\", \\\"{x:165,y:606,t:1526922679191};\\\", \\\"{x:165,y:608,t:1526922679208};\\\", \\\"{x:166,y:611,t:1526922679225};\\\", \\\"{x:166,y:614,t:1526922679241};\\\", \\\"{x:167,y:616,t:1526922679257};\\\", \\\"{x:168,y:618,t:1526922679273};\\\", \\\"{x:169,y:619,t:1526922679291};\\\", \\\"{x:169,y:620,t:1526922679308};\\\", \\\"{x:171,y:620,t:1526922679385};\\\", \\\"{x:172,y:620,t:1526922679425};\\\", \\\"{x:172,y:621,t:1526922679609};\\\", \\\"{x:171,y:624,t:1526922679627};\\\", \\\"{x:170,y:626,t:1526922679641};\\\", \\\"{x:169,y:628,t:1526922679658};\\\", \\\"{x:168,y:630,t:1526922679674};\\\", \\\"{x:168,y:631,t:1526922679691};\\\", \\\"{x:167,y:632,t:1526922679720};\\\", \\\"{x:166,y:632,t:1526922679728};\\\", \\\"{x:165,y:633,t:1526922679752};\\\", \\\"{x:166,y:633,t:1526922679952};\\\", \\\"{x:169,y:633,t:1526922679968};\\\", \\\"{x:172,y:634,t:1526922679984};\\\", \\\"{x:173,y:634,t:1526922680007};\\\", \\\"{x:176,y:635,t:1526922680025};\\\", \\\"{x:181,y:638,t:1526922680041};\\\", \\\"{x:186,y:641,t:1526922680057};\\\", \\\"{x:197,y:644,t:1526922680075};\\\", \\\"{x:214,y:649,t:1526922680091};\\\", \\\"{x:235,y:654,t:1526922680109};\\\", \\\"{x:263,y:660,t:1526922680125};\\\", \\\"{x:289,y:665,t:1526922680141};\\\", \\\"{x:317,y:669,t:1526922680158};\\\", \\\"{x:343,y:669,t:1526922680175};\\\", \\\"{x:365,y:669,t:1526922680192};\\\", \\\"{x:383,y:669,t:1526922680208};\\\", \\\"{x:407,y:669,t:1526922680225};\\\", \\\"{x:420,y:669,t:1526922680242};\\\", \\\"{x:430,y:669,t:1526922680258};\\\", \\\"{x:438,y:669,t:1526922680275};\\\", \\\"{x:442,y:669,t:1526922680292};\\\", \\\"{x:449,y:669,t:1526922680308};\\\", \\\"{x:459,y:668,t:1526922680325};\\\", \\\"{x:471,y:664,t:1526922680342};\\\", \\\"{x:492,y:657,t:1526922680358};\\\", \\\"{x:521,y:646,t:1526922680376};\\\", \\\"{x:556,y:632,t:1526922680392};\\\", \\\"{x:619,y:610,t:1526922680410};\\\", \\\"{x:659,y:598,t:1526922680425};\\\", \\\"{x:686,y:591,t:1526922680441};\\\", \\\"{x:698,y:590,t:1526922680458};\\\", \\\"{x:701,y:589,t:1526922680475};\\\", \\\"{x:703,y:589,t:1526922680492};\\\", \\\"{x:702,y:589,t:1526922680536};\\\", \\\"{x:700,y:589,t:1526922680544};\\\", \\\"{x:696,y:590,t:1526922680559};\\\", \\\"{x:691,y:592,t:1526922680574};\\\", \\\"{x:676,y:598,t:1526922680592};\\\", \\\"{x:647,y:608,t:1526922680609};\\\", \\\"{x:634,y:612,t:1526922680625};\\\", \\\"{x:624,y:616,t:1526922680643};\\\", \\\"{x:621,y:617,t:1526922680659};\\\", \\\"{x:620,y:618,t:1526922680675};\\\", \\\"{x:616,y:620,t:1526922680693};\\\", \\\"{x:615,y:620,t:1526922680709};\\\", \\\"{x:611,y:622,t:1526922680725};\\\", \\\"{x:610,y:624,t:1526922680743};\\\", \\\"{x:609,y:625,t:1526922680759};\\\", \\\"{x:609,y:626,t:1526922680776};\\\", \\\"{x:609,y:629,t:1526922680792};\\\", \\\"{x:608,y:633,t:1526922680808};\\\", \\\"{x:608,y:636,t:1526922680825};\\\", \\\"{x:608,y:637,t:1526922680842};\\\", \\\"{x:607,y:639,t:1526922681144};\\\", \\\"{x:607,y:640,t:1526922681159};\\\", \\\"{x:606,y:641,t:1526922681176};\\\", \\\"{x:604,y:642,t:1526922681192};\\\", \\\"{x:599,y:644,t:1526922681209};\\\", \\\"{x:594,y:648,t:1526922681226};\\\", \\\"{x:579,y:656,t:1526922681243};\\\", \\\"{x:564,y:663,t:1526922681259};\\\", \\\"{x:548,y:669,t:1526922681276};\\\", \\\"{x:533,y:677,t:1526922681293};\\\", \\\"{x:527,y:682,t:1526922681309};\\\", \\\"{x:525,y:682,t:1526922681326};\\\", \\\"{x:524,y:684,t:1526922681343};\\\", \\\"{x:523,y:684,t:1526922681359};\\\", \\\"{x:522,y:685,t:1526922681376};\\\", \\\"{x:520,y:688,t:1526922681393};\\\", \\\"{x:520,y:690,t:1526922681409};\\\", \\\"{x:519,y:695,t:1526922681426};\\\", \\\"{x:517,y:702,t:1526922681443};\\\", \\\"{x:516,y:707,t:1526922681458};\\\", \\\"{x:515,y:711,t:1526922681476};\\\", \\\"{x:515,y:713,t:1526922681492};\\\", \\\"{x:514,y:714,t:1526922681509};\\\", \\\"{x:513,y:715,t:1526922681526};\\\", \\\"{x:513,y:716,t:1526922681736};\\\", \\\"{x:513,y:716,t:1526922681770};\\\", \\\"{x:513,y:715,t:1526922681913};\\\", \\\"{x:514,y:713,t:1526922681926};\\\", \\\"{x:514,y:712,t:1526922681943};\\\", \\\"{x:514,y:709,t:1526922681960};\\\", \\\"{x:515,y:709,t:1526922681975};\\\", \\\"{x:515,y:708,t:1526922681993};\\\", \\\"{x:516,y:706,t:1526922682010};\\\", \\\"{x:516,y:705,t:1526922682026};\\\" ] }, { \\\"rt\\\": 25342, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 319872, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-06 PM-04 PM-2-08 PM-08 PM-07 PM-06 PM-05 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:705,t:1526922688683};\\\", \\\"{x:545,y:712,t:1526922688697};\\\", \\\"{x:632,y:741,t:1526922688708};\\\", \\\"{x:767,y:780,t:1526922688724};\\\", \\\"{x:935,y:822,t:1526922688739};\\\", \\\"{x:1117,y:870,t:1526922688758};\\\", \\\"{x:1298,y:908,t:1526922688775};\\\", \\\"{x:1459,y:935,t:1526922688792};\\\", \\\"{x:1603,y:956,t:1526922688808};\\\", \\\"{x:1709,y:974,t:1526922688826};\\\", \\\"{x:1759,y:981,t:1526922688842};\\\", \\\"{x:1760,y:981,t:1526922688971};\\\", \\\"{x:1765,y:986,t:1526922688979};\\\", \\\"{x:1774,y:995,t:1526922688992};\\\", \\\"{x:1789,y:1006,t:1526922689008};\\\", \\\"{x:1796,y:1011,t:1526922689026};\\\", \\\"{x:1798,y:1011,t:1526922689042};\\\", \\\"{x:1790,y:1011,t:1526922689114};\\\", \\\"{x:1777,y:1004,t:1526922689126};\\\", \\\"{x:1738,y:987,t:1526922689142};\\\", \\\"{x:1705,y:973,t:1526922689159};\\\", \\\"{x:1683,y:966,t:1526922689175};\\\", \\\"{x:1667,y:964,t:1526922689193};\\\", \\\"{x:1665,y:963,t:1526922689210};\\\", \\\"{x:1662,y:961,t:1526922689225};\\\", \\\"{x:1663,y:961,t:1526922689323};\\\", \\\"{x:1665,y:960,t:1526922689331};\\\", \\\"{x:1667,y:958,t:1526922689343};\\\", \\\"{x:1670,y:957,t:1526922689359};\\\", \\\"{x:1671,y:957,t:1526922689395};\\\", \\\"{x:1670,y:957,t:1526922689434};\\\", \\\"{x:1669,y:957,t:1526922689442};\\\", \\\"{x:1657,y:962,t:1526922689459};\\\", \\\"{x:1642,y:968,t:1526922689476};\\\", \\\"{x:1633,y:972,t:1526922689493};\\\", \\\"{x:1629,y:974,t:1526922689509};\\\", \\\"{x:1625,y:976,t:1526922689526};\\\", \\\"{x:1624,y:977,t:1526922689543};\\\", \\\"{x:1622,y:977,t:1526922689560};\\\", \\\"{x:1618,y:978,t:1526922689576};\\\", \\\"{x:1616,y:980,t:1526922689593};\\\", \\\"{x:1613,y:980,t:1526922689610};\\\", \\\"{x:1610,y:982,t:1526922689627};\\\", \\\"{x:1608,y:983,t:1526922689642};\\\", \\\"{x:1606,y:984,t:1526922689691};\\\", \\\"{x:1605,y:984,t:1526922689707};\\\", \\\"{x:1603,y:984,t:1526922689714};\\\", \\\"{x:1602,y:984,t:1526922689731};\\\", \\\"{x:1601,y:984,t:1526922689747};\\\", \\\"{x:1601,y:983,t:1526922689843};\\\", \\\"{x:1601,y:979,t:1526922689859};\\\", \\\"{x:1601,y:976,t:1526922689877};\\\", \\\"{x:1601,y:970,t:1526922689893};\\\", \\\"{x:1601,y:965,t:1526922689910};\\\", \\\"{x:1601,y:961,t:1526922689927};\\\", \\\"{x:1602,y:955,t:1526922689942};\\\", \\\"{x:1602,y:951,t:1526922689960};\\\", \\\"{x:1602,y:946,t:1526922689977};\\\", \\\"{x:1602,y:939,t:1526922689993};\\\", \\\"{x:1602,y:932,t:1526922690010};\\\", \\\"{x:1602,y:925,t:1526922690026};\\\", \\\"{x:1601,y:924,t:1526922690043};\\\", \\\"{x:1601,y:921,t:1526922690059};\\\", \\\"{x:1601,y:918,t:1526922690077};\\\", \\\"{x:1601,y:915,t:1526922690094};\\\", \\\"{x:1601,y:911,t:1526922690110};\\\", \\\"{x:1601,y:907,t:1526922690126};\\\", \\\"{x:1601,y:905,t:1526922690144};\\\", \\\"{x:1601,y:904,t:1526922690160};\\\", \\\"{x:1601,y:902,t:1526922690251};\\\", \\\"{x:1601,y:900,t:1526922690259};\\\", \\\"{x:1601,y:894,t:1526922690277};\\\", \\\"{x:1601,y:885,t:1526922690294};\\\", \\\"{x:1601,y:874,t:1526922690310};\\\", \\\"{x:1601,y:860,t:1526922690327};\\\", \\\"{x:1601,y:846,t:1526922690343};\\\", \\\"{x:1601,y:835,t:1526922690360};\\\", \\\"{x:1601,y:825,t:1526922690377};\\\", \\\"{x:1601,y:818,t:1526922690394};\\\", \\\"{x:1601,y:809,t:1526922690410};\\\", \\\"{x:1601,y:798,t:1526922690427};\\\", \\\"{x:1601,y:791,t:1526922690444};\\\", \\\"{x:1601,y:782,t:1526922690459};\\\", \\\"{x:1601,y:774,t:1526922690477};\\\", \\\"{x:1601,y:767,t:1526922690494};\\\", \\\"{x:1601,y:758,t:1526922690510};\\\", \\\"{x:1601,y:749,t:1526922690527};\\\", \\\"{x:1601,y:740,t:1526922690544};\\\", \\\"{x:1601,y:730,t:1526922690561};\\\", \\\"{x:1601,y:717,t:1526922690577};\\\", \\\"{x:1601,y:707,t:1526922690593};\\\", \\\"{x:1598,y:689,t:1526922690611};\\\", \\\"{x:1596,y:678,t:1526922690627};\\\", \\\"{x:1594,y:667,t:1526922690644};\\\", \\\"{x:1593,y:657,t:1526922690661};\\\", \\\"{x:1592,y:648,t:1526922690676};\\\", \\\"{x:1592,y:642,t:1526922690693};\\\", \\\"{x:1590,y:638,t:1526922690711};\\\", \\\"{x:1589,y:633,t:1526922690727};\\\", \\\"{x:1589,y:631,t:1526922690744};\\\", \\\"{x:1588,y:627,t:1526922690761};\\\", \\\"{x:1587,y:625,t:1526922690777};\\\", \\\"{x:1586,y:622,t:1526922690794};\\\", \\\"{x:1586,y:620,t:1526922690811};\\\", \\\"{x:1585,y:616,t:1526922690827};\\\", \\\"{x:1585,y:613,t:1526922690844};\\\", \\\"{x:1585,y:609,t:1526922690861};\\\", \\\"{x:1585,y:605,t:1526922690877};\\\", \\\"{x:1583,y:601,t:1526922690894};\\\", \\\"{x:1582,y:597,t:1526922690911};\\\", \\\"{x:1582,y:594,t:1526922690927};\\\", \\\"{x:1581,y:589,t:1526922690943};\\\", \\\"{x:1579,y:583,t:1526922690960};\\\", \\\"{x:1579,y:579,t:1526922690977};\\\", \\\"{x:1579,y:574,t:1526922690994};\\\", \\\"{x:1578,y:566,t:1526922691011};\\\", \\\"{x:1577,y:561,t:1526922691027};\\\", \\\"{x:1575,y:554,t:1526922691043};\\\", \\\"{x:1575,y:548,t:1526922691060};\\\", \\\"{x:1573,y:540,t:1526922691078};\\\", \\\"{x:1571,y:532,t:1526922691094};\\\", \\\"{x:1571,y:523,t:1526922691111};\\\", \\\"{x:1569,y:513,t:1526922691128};\\\", \\\"{x:1569,y:502,t:1526922691144};\\\", \\\"{x:1568,y:491,t:1526922691161};\\\", \\\"{x:1568,y:478,t:1526922691178};\\\", \\\"{x:1565,y:465,t:1526922691194};\\\", \\\"{x:1564,y:443,t:1526922691211};\\\", \\\"{x:1564,y:429,t:1526922691227};\\\", \\\"{x:1563,y:413,t:1526922691244};\\\", \\\"{x:1563,y:396,t:1526922691260};\\\", \\\"{x:1561,y:380,t:1526922691277};\\\", \\\"{x:1560,y:363,t:1526922691294};\\\", \\\"{x:1558,y:348,t:1526922691311};\\\", \\\"{x:1558,y:331,t:1526922691328};\\\", \\\"{x:1558,y:312,t:1526922691344};\\\", \\\"{x:1558,y:296,t:1526922691361};\\\", \\\"{x:1558,y:278,t:1526922691378};\\\", \\\"{x:1558,y:263,t:1526922691394};\\\", \\\"{x:1558,y:237,t:1526922691410};\\\", \\\"{x:1558,y:223,t:1526922691428};\\\", \\\"{x:1558,y:208,t:1526922691444};\\\", \\\"{x:1558,y:193,t:1526922691461};\\\", \\\"{x:1558,y:179,t:1526922691478};\\\", \\\"{x:1558,y:165,t:1526922691495};\\\", \\\"{x:1558,y:154,t:1526922691510};\\\", \\\"{x:1558,y:140,t:1526922691528};\\\", \\\"{x:1558,y:129,t:1526922691546};\\\", \\\"{x:1558,y:117,t:1526922691561};\\\", \\\"{x:1558,y:107,t:1526922691578};\\\", \\\"{x:1558,y:93,t:1526922691595};\\\", \\\"{x:1558,y:86,t:1526922691610};\\\", \\\"{x:1558,y:82,t:1526922691628};\\\", \\\"{x:1558,y:78,t:1526922691644};\\\", \\\"{x:1558,y:76,t:1526922691660};\\\", \\\"{x:1557,y:77,t:1526922691859};\\\", \\\"{x:1556,y:82,t:1526922691866};\\\", \\\"{x:1555,y:90,t:1526922691878};\\\", \\\"{x:1554,y:113,t:1526922691894};\\\", \\\"{x:1552,y:139,t:1526922691911};\\\", \\\"{x:1550,y:160,t:1526922691928};\\\", \\\"{x:1549,y:179,t:1526922691945};\\\", \\\"{x:1548,y:194,t:1526922691961};\\\", \\\"{x:1548,y:208,t:1526922691978};\\\", \\\"{x:1548,y:222,t:1526922691996};\\\", \\\"{x:1548,y:231,t:1526922692011};\\\", \\\"{x:1548,y:244,t:1526922692028};\\\", \\\"{x:1552,y:260,t:1526922692045};\\\", \\\"{x:1554,y:281,t:1526922692062};\\\", \\\"{x:1557,y:305,t:1526922692078};\\\", \\\"{x:1560,y:352,t:1526922692094};\\\", \\\"{x:1572,y:414,t:1526922692112};\\\", \\\"{x:1577,y:499,t:1526922692128};\\\", \\\"{x:1585,y:592,t:1526922692145};\\\", \\\"{x:1593,y:696,t:1526922692162};\\\", \\\"{x:1595,y:799,t:1526922692178};\\\", \\\"{x:1597,y:966,t:1526922692194};\\\", \\\"{x:1597,y:1063,t:1526922692212};\\\", \\\"{x:1597,y:1141,t:1526922692228};\\\", \\\"{x:1597,y:1186,t:1526922692245};\\\", \\\"{x:1591,y:1199,t:1526922692262};\\\", \\\"{x:1587,y:1199,t:1526922692278};\\\", \\\"{x:1586,y:1199,t:1526922692299};\\\", \\\"{x:1584,y:1198,t:1526922692312};\\\", \\\"{x:1575,y:1188,t:1526922692329};\\\", \\\"{x:1553,y:1170,t:1526922692345};\\\", \\\"{x:1508,y:1136,t:1526922692361};\\\", \\\"{x:1404,y:1075,t:1526922692378};\\\", \\\"{x:1321,y:1039,t:1526922692395};\\\", \\\"{x:1240,y:998,t:1526922692412};\\\", \\\"{x:1151,y:955,t:1526922692428};\\\", \\\"{x:1083,y:918,t:1526922692445};\\\", \\\"{x:1044,y:891,t:1526922692461};\\\", \\\"{x:1032,y:880,t:1526922692479};\\\", \\\"{x:1031,y:873,t:1526922692494};\\\", \\\"{x:1031,y:869,t:1526922692512};\\\", \\\"{x:1033,y:862,t:1526922692528};\\\", \\\"{x:1039,y:853,t:1526922692545};\\\", \\\"{x:1045,y:846,t:1526922692562};\\\", \\\"{x:1056,y:832,t:1526922692579};\\\", \\\"{x:1066,y:828,t:1526922692597};\\\", \\\"{x:1075,y:825,t:1526922692612};\\\", \\\"{x:1081,y:822,t:1526922692629};\\\", \\\"{x:1089,y:822,t:1526922692647};\\\", \\\"{x:1098,y:825,t:1526922692662};\\\", \\\"{x:1110,y:830,t:1526922692679};\\\", \\\"{x:1119,y:834,t:1526922692696};\\\", \\\"{x:1126,y:835,t:1526922692712};\\\", \\\"{x:1131,y:837,t:1526922692729};\\\", \\\"{x:1132,y:837,t:1526922692746};\\\", \\\"{x:1133,y:837,t:1526922692762};\\\", \\\"{x:1135,y:837,t:1526922692850};\\\", \\\"{x:1142,y:838,t:1526922692861};\\\", \\\"{x:1175,y:846,t:1526922692878};\\\", \\\"{x:1260,y:860,t:1526922692896};\\\", \\\"{x:1357,y:878,t:1526922692911};\\\", \\\"{x:1464,y:900,t:1526922692928};\\\", \\\"{x:1576,y:921,t:1526922692945};\\\", \\\"{x:1681,y:934,t:1526922692961};\\\", \\\"{x:1831,y:962,t:1526922692978};\\\", \\\"{x:1888,y:975,t:1526922692996};\\\", \\\"{x:1918,y:981,t:1526922693012};\\\", \\\"{x:1923,y:983,t:1526922693028};\\\", \\\"{x:1925,y:984,t:1526922693046};\\\", \\\"{x:1924,y:984,t:1526922693063};\\\", \\\"{x:1913,y:981,t:1526922693078};\\\", \\\"{x:1900,y:979,t:1526922693095};\\\", \\\"{x:1889,y:979,t:1526922693113};\\\", \\\"{x:1875,y:979,t:1526922693129};\\\", \\\"{x:1856,y:979,t:1526922693146};\\\", \\\"{x:1826,y:979,t:1526922693162};\\\", \\\"{x:1806,y:979,t:1526922693178};\\\", \\\"{x:1787,y:979,t:1526922693197};\\\", \\\"{x:1766,y:979,t:1526922693213};\\\", \\\"{x:1750,y:976,t:1526922693228};\\\", \\\"{x:1733,y:974,t:1526922693245};\\\", \\\"{x:1719,y:971,t:1526922693262};\\\", \\\"{x:1706,y:970,t:1526922693278};\\\", \\\"{x:1698,y:969,t:1526922693295};\\\", \\\"{x:1690,y:969,t:1526922693312};\\\", \\\"{x:1684,y:967,t:1526922693330};\\\", \\\"{x:1678,y:967,t:1526922693345};\\\", \\\"{x:1668,y:967,t:1526922693362};\\\", \\\"{x:1657,y:965,t:1526922693379};\\\", \\\"{x:1646,y:965,t:1526922693396};\\\", \\\"{x:1638,y:965,t:1526922693412};\\\", \\\"{x:1631,y:965,t:1526922693429};\\\", \\\"{x:1626,y:965,t:1526922693445};\\\", \\\"{x:1617,y:965,t:1526922693462};\\\", \\\"{x:1606,y:964,t:1526922693482};\\\", \\\"{x:1597,y:961,t:1526922693495};\\\", \\\"{x:1589,y:957,t:1526922693512};\\\", \\\"{x:1586,y:956,t:1526922693530};\\\", \\\"{x:1583,y:956,t:1526922693545};\\\", \\\"{x:1582,y:956,t:1526922693578};\\\", \\\"{x:1582,y:955,t:1526922693586};\\\", \\\"{x:1582,y:954,t:1526922693626};\\\", \\\"{x:1582,y:953,t:1526922693634};\\\", \\\"{x:1583,y:953,t:1526922693650};\\\", \\\"{x:1583,y:952,t:1526922693663};\\\", \\\"{x:1584,y:951,t:1526922693679};\\\", \\\"{x:1586,y:951,t:1526922693696};\\\", \\\"{x:1591,y:950,t:1526922693712};\\\", \\\"{x:1597,y:950,t:1526922693729};\\\", \\\"{x:1604,y:950,t:1526922693746};\\\", \\\"{x:1612,y:950,t:1526922693763};\\\", \\\"{x:1615,y:950,t:1526922693779};\\\", \\\"{x:1616,y:950,t:1526922693971};\\\", \\\"{x:1616,y:949,t:1526922693980};\\\", \\\"{x:1616,y:944,t:1526922693997};\\\", \\\"{x:1615,y:936,t:1526922694013};\\\", \\\"{x:1611,y:928,t:1526922694030};\\\", \\\"{x:1610,y:922,t:1526922694047};\\\", \\\"{x:1609,y:915,t:1526922694063};\\\", \\\"{x:1609,y:909,t:1526922694080};\\\", \\\"{x:1609,y:902,t:1526922694097};\\\", \\\"{x:1609,y:897,t:1526922694113};\\\", \\\"{x:1609,y:893,t:1526922694130};\\\", \\\"{x:1610,y:885,t:1526922694146};\\\", \\\"{x:1612,y:880,t:1526922694163};\\\", \\\"{x:1612,y:876,t:1526922694180};\\\", \\\"{x:1614,y:872,t:1526922694197};\\\", \\\"{x:1615,y:869,t:1526922694213};\\\", \\\"{x:1616,y:866,t:1526922694230};\\\", \\\"{x:1617,y:862,t:1526922694246};\\\", \\\"{x:1617,y:860,t:1526922694262};\\\", \\\"{x:1617,y:857,t:1526922694279};\\\", \\\"{x:1618,y:855,t:1526922694296};\\\", \\\"{x:1618,y:853,t:1526922694313};\\\", \\\"{x:1618,y:852,t:1526922694329};\\\", \\\"{x:1618,y:849,t:1526922694346};\\\", \\\"{x:1618,y:846,t:1526922694363};\\\", \\\"{x:1618,y:840,t:1526922694379};\\\", \\\"{x:1618,y:835,t:1526922694396};\\\", \\\"{x:1618,y:829,t:1526922694414};\\\", \\\"{x:1618,y:824,t:1526922694430};\\\", \\\"{x:1618,y:819,t:1526922694447};\\\", \\\"{x:1618,y:814,t:1526922694463};\\\", \\\"{x:1618,y:810,t:1526922694479};\\\", \\\"{x:1618,y:807,t:1526922694496};\\\", \\\"{x:1618,y:803,t:1526922694513};\\\", \\\"{x:1617,y:800,t:1526922694529};\\\", \\\"{x:1617,y:798,t:1526922694546};\\\", \\\"{x:1616,y:796,t:1526922694570};\\\", \\\"{x:1615,y:794,t:1526922694587};\\\", \\\"{x:1614,y:794,t:1526922694597};\\\", \\\"{x:1613,y:792,t:1526922694613};\\\", \\\"{x:1612,y:789,t:1526922694629};\\\", \\\"{x:1611,y:788,t:1526922694650};\\\", \\\"{x:1610,y:788,t:1526922694664};\\\", \\\"{x:1610,y:787,t:1526922694680};\\\", \\\"{x:1610,y:785,t:1526922694696};\\\", \\\"{x:1608,y:783,t:1526922694713};\\\", \\\"{x:1608,y:782,t:1526922694729};\\\", \\\"{x:1606,y:776,t:1526922694746};\\\", \\\"{x:1605,y:774,t:1526922694763};\\\", \\\"{x:1604,y:772,t:1526922694780};\\\", \\\"{x:1603,y:770,t:1526922694798};\\\", \\\"{x:1603,y:766,t:1526922694813};\\\", \\\"{x:1601,y:762,t:1526922694830};\\\", \\\"{x:1600,y:757,t:1526922694847};\\\", \\\"{x:1599,y:751,t:1526922694864};\\\", \\\"{x:1599,y:744,t:1526922694881};\\\", \\\"{x:1597,y:736,t:1526922694896};\\\", \\\"{x:1596,y:731,t:1526922694913};\\\", \\\"{x:1595,y:726,t:1526922694930};\\\", \\\"{x:1595,y:723,t:1526922694947};\\\", \\\"{x:1595,y:720,t:1526922694964};\\\", \\\"{x:1593,y:718,t:1526922694981};\\\", \\\"{x:1593,y:716,t:1526922694997};\\\", \\\"{x:1593,y:714,t:1526922695014};\\\", \\\"{x:1593,y:713,t:1526922695034};\\\", \\\"{x:1592,y:712,t:1526922695047};\\\", \\\"{x:1592,y:711,t:1526922695066};\\\", \\\"{x:1592,y:710,t:1526922695091};\\\", \\\"{x:1592,y:709,t:1526922695098};\\\", \\\"{x:1591,y:708,t:1526922695114};\\\", \\\"{x:1591,y:707,t:1526922695146};\\\", \\\"{x:1591,y:706,t:1526922695170};\\\", \\\"{x:1591,y:705,t:1526922695299};\\\", \\\"{x:1591,y:704,t:1526922695322};\\\", \\\"{x:1591,y:703,t:1526922695346};\\\", \\\"{x:1592,y:702,t:1526922695354};\\\", \\\"{x:1594,y:701,t:1526922695363};\\\", \\\"{x:1600,y:699,t:1526922695380};\\\", \\\"{x:1606,y:697,t:1526922695397};\\\", \\\"{x:1619,y:694,t:1526922695413};\\\", \\\"{x:1643,y:687,t:1526922695430};\\\", \\\"{x:1680,y:680,t:1526922695448};\\\", \\\"{x:1744,y:663,t:1526922695463};\\\", \\\"{x:1809,y:651,t:1526922695480};\\\", \\\"{x:1902,y:628,t:1526922695497};\\\", \\\"{x:1927,y:591,t:1526922695513};\\\", \\\"{x:1927,y:579,t:1526922695530};\\\", \\\"{x:1927,y:577,t:1526922695547};\\\", \\\"{x:1927,y:558,t:1526922700786};\\\", \\\"{x:1914,y:505,t:1526922700803};\\\", \\\"{x:1906,y:477,t:1526922700819};\\\", \\\"{x:1899,y:466,t:1526922700836};\\\", \\\"{x:1896,y:463,t:1526922700852};\\\", \\\"{x:1895,y:463,t:1526922702411};\\\", \\\"{x:1894,y:463,t:1526922702451};\\\", \\\"{x:1893,y:463,t:1526922702459};\\\", \\\"{x:1892,y:463,t:1526922702470};\\\", \\\"{x:1891,y:462,t:1526922702611};\\\", \\\"{x:1890,y:461,t:1526922702786};\\\", \\\"{x:1864,y:453,t:1526922702803};\\\", \\\"{x:1836,y:448,t:1526922702820};\\\", \\\"{x:1814,y:445,t:1526922702836};\\\", \\\"{x:1794,y:441,t:1526922702852};\\\", \\\"{x:1778,y:439,t:1526922702870};\\\", \\\"{x:1766,y:436,t:1526922702886};\\\", \\\"{x:1759,y:435,t:1526922702902};\\\", \\\"{x:1754,y:434,t:1526922702920};\\\", \\\"{x:1751,y:434,t:1526922702936};\\\", \\\"{x:1749,y:434,t:1526922702953};\\\", \\\"{x:1748,y:433,t:1526922702970};\\\", \\\"{x:1747,y:433,t:1526922702986};\\\", \\\"{x:1746,y:433,t:1526922703003};\\\", \\\"{x:1745,y:433,t:1526922703019};\\\", \\\"{x:1742,y:432,t:1526922703036};\\\", \\\"{x:1741,y:432,t:1526922703058};\\\", \\\"{x:1739,y:432,t:1526922703069};\\\", \\\"{x:1738,y:432,t:1526922703086};\\\", \\\"{x:1736,y:432,t:1526922703103};\\\", \\\"{x:1726,y:432,t:1526922705987};\\\", \\\"{x:1701,y:433,t:1526922705994};\\\", \\\"{x:1659,y:435,t:1526922706006};\\\", \\\"{x:1553,y:437,t:1526922706022};\\\", \\\"{x:1429,y:437,t:1526922706040};\\\", \\\"{x:1287,y:437,t:1526922706056};\\\", \\\"{x:1144,y:437,t:1526922706073};\\\", \\\"{x:986,y:437,t:1526922706089};\\\", \\\"{x:787,y:454,t:1526922706106};\\\", \\\"{x:688,y:476,t:1526922706122};\\\", \\\"{x:625,y:500,t:1526922706139};\\\", \\\"{x:593,y:517,t:1526922706158};\\\", \\\"{x:577,y:532,t:1526922706171};\\\", \\\"{x:570,y:551,t:1526922706189};\\\", \\\"{x:567,y:568,t:1526922706206};\\\", \\\"{x:566,y:591,t:1526922706223};\\\", \\\"{x:564,y:619,t:1526922706239};\\\", \\\"{x:564,y:646,t:1526922706257};\\\", \\\"{x:564,y:668,t:1526922706273};\\\", \\\"{x:563,y:683,t:1526922706289};\\\", \\\"{x:562,y:690,t:1526922706306};\\\", \\\"{x:562,y:692,t:1526922706323};\\\", \\\"{x:562,y:695,t:1526922706340};\\\", \\\"{x:562,y:698,t:1526922706355};\\\", \\\"{x:560,y:702,t:1526922706373};\\\", \\\"{x:557,y:704,t:1526922706389};\\\", \\\"{x:554,y:705,t:1526922706406};\\\", \\\"{x:551,y:706,t:1526922706423};\\\", \\\"{x:547,y:706,t:1526922706439};\\\", \\\"{x:544,y:706,t:1526922706456};\\\", \\\"{x:546,y:706,t:1526922706547};\\\", \\\"{x:552,y:704,t:1526922706557};\\\", \\\"{x:561,y:699,t:1526922706575};\\\", \\\"{x:571,y:695,t:1526922706588};\\\", \\\"{x:578,y:691,t:1526922706605};\\\", \\\"{x:585,y:686,t:1526922706623};\\\", \\\"{x:588,y:683,t:1526922706640};\\\", \\\"{x:589,y:681,t:1526922706655};\\\", \\\"{x:590,y:680,t:1526922706672};\\\", \\\"{x:587,y:672,t:1526922706689};\\\", \\\"{x:570,y:662,t:1526922706705};\\\", \\\"{x:547,y:650,t:1526922706723};\\\", \\\"{x:515,y:637,t:1526922706739};\\\", \\\"{x:488,y:629,t:1526922706757};\\\", \\\"{x:463,y:623,t:1526922706773};\\\", \\\"{x:438,y:619,t:1526922706790};\\\", \\\"{x:420,y:615,t:1526922706807};\\\", \\\"{x:405,y:613,t:1526922706823};\\\", \\\"{x:398,y:613,t:1526922706840};\\\", \\\"{x:394,y:613,t:1526922706856};\\\", \\\"{x:393,y:613,t:1526922706962};\\\", \\\"{x:391,y:613,t:1526922706973};\\\", \\\"{x:376,y:614,t:1526922706990};\\\", \\\"{x:358,y:617,t:1526922707007};\\\", \\\"{x:319,y:620,t:1526922707023};\\\", \\\"{x:269,y:620,t:1526922707041};\\\", \\\"{x:237,y:619,t:1526922707057};\\\", \\\"{x:206,y:614,t:1526922707072};\\\", \\\"{x:180,y:614,t:1526922707089};\\\", \\\"{x:167,y:614,t:1526922707106};\\\", \\\"{x:153,y:614,t:1526922707123};\\\", \\\"{x:144,y:614,t:1526922707140};\\\", \\\"{x:136,y:614,t:1526922707157};\\\", \\\"{x:132,y:614,t:1526922707173};\\\", \\\"{x:129,y:614,t:1526922707190};\\\", \\\"{x:124,y:614,t:1526922707207};\\\", \\\"{x:121,y:613,t:1526922707223};\\\", \\\"{x:119,y:613,t:1526922707240};\\\", \\\"{x:118,y:612,t:1526922707258};\\\", \\\"{x:117,y:612,t:1526922707273};\\\", \\\"{x:117,y:611,t:1526922707290};\\\", \\\"{x:117,y:610,t:1526922707314};\\\", \\\"{x:117,y:608,t:1526922707323};\\\", \\\"{x:120,y:605,t:1526922707340};\\\", \\\"{x:124,y:603,t:1526922707357};\\\", \\\"{x:129,y:601,t:1526922707373};\\\", \\\"{x:131,y:600,t:1526922707390};\\\", \\\"{x:132,y:600,t:1526922707406};\\\", \\\"{x:134,y:598,t:1526922707423};\\\", \\\"{x:136,y:597,t:1526922707440};\\\", \\\"{x:138,y:596,t:1526922707457};\\\", \\\"{x:141,y:594,t:1526922707473};\\\", \\\"{x:145,y:593,t:1526922707490};\\\", \\\"{x:146,y:592,t:1526922707507};\\\", \\\"{x:149,y:592,t:1526922707524};\\\", \\\"{x:150,y:591,t:1526922707539};\\\", \\\"{x:151,y:591,t:1526922707665};\\\", \\\"{x:155,y:591,t:1526922707673};\\\", \\\"{x:163,y:593,t:1526922707691};\\\", \\\"{x:184,y:600,t:1526922707707};\\\", \\\"{x:222,y:614,t:1526922707724};\\\", \\\"{x:273,y:632,t:1526922707741};\\\", \\\"{x:319,y:647,t:1526922707757};\\\", \\\"{x:349,y:660,t:1526922707774};\\\", \\\"{x:361,y:665,t:1526922707791};\\\", \\\"{x:364,y:666,t:1526922707806};\\\", \\\"{x:367,y:667,t:1526922707842};\\\", \\\"{x:369,y:669,t:1526922707857};\\\", \\\"{x:374,y:670,t:1526922707874};\\\", \\\"{x:376,y:670,t:1526922707891};\\\", \\\"{x:381,y:673,t:1526922707906};\\\", \\\"{x:388,y:676,t:1526922707924};\\\", \\\"{x:401,y:683,t:1526922707940};\\\", \\\"{x:418,y:693,t:1526922707957};\\\", \\\"{x:436,y:704,t:1526922707974};\\\", \\\"{x:454,y:714,t:1526922707992};\\\", \\\"{x:461,y:717,t:1526922708008};\\\", \\\"{x:466,y:720,t:1526922708024};\\\", \\\"{x:467,y:720,t:1526922708041};\\\", \\\"{x:469,y:720,t:1526922708058};\\\", \\\"{x:470,y:720,t:1526922708074};\\\", \\\"{x:475,y:723,t:1526922708091};\\\", \\\"{x:483,y:725,t:1526922708108};\\\", \\\"{x:488,y:726,t:1526922708124};\\\", \\\"{x:493,y:728,t:1526922708141};\\\", \\\"{x:496,y:729,t:1526922708158};\\\", \\\"{x:499,y:729,t:1526922708257};\\\", \\\"{x:501,y:729,t:1526922708273};\\\", \\\"{x:502,y:729,t:1526922708291};\\\", \\\"{x:502,y:729,t:1526922708348};\\\" ] }, { \\\"rt\\\": 18928, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 340031, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:729,t:1526922716866};\\\", \\\"{x:509,y:725,t:1526922716881};\\\", \\\"{x:537,y:713,t:1526922716900};\\\", \\\"{x:561,y:701,t:1526922716915};\\\", \\\"{x:606,y:673,t:1526922716932};\\\", \\\"{x:669,y:633,t:1526922716948};\\\", \\\"{x:776,y:565,t:1526922716965};\\\", \\\"{x:910,y:470,t:1526922716982};\\\", \\\"{x:1038,y:423,t:1526922716998};\\\", \\\"{x:1153,y:400,t:1526922717014};\\\", \\\"{x:1290,y:389,t:1526922717031};\\\", \\\"{x:1423,y:389,t:1526922717048};\\\", \\\"{x:1535,y:394,t:1526922717064};\\\", \\\"{x:1699,y:431,t:1526922717082};\\\", \\\"{x:1794,y:465,t:1526922717098};\\\", \\\"{x:1851,y:505,t:1526922717114};\\\", \\\"{x:1889,y:535,t:1526922717131};\\\", \\\"{x:1900,y:552,t:1526922717148};\\\", \\\"{x:1900,y:567,t:1526922717164};\\\", \\\"{x:1896,y:590,t:1526922717181};\\\", \\\"{x:1874,y:609,t:1526922717198};\\\", \\\"{x:1833,y:627,t:1526922717215};\\\", \\\"{x:1786,y:639,t:1526922717231};\\\", \\\"{x:1726,y:651,t:1526922717248};\\\", \\\"{x:1645,y:659,t:1526922717265};\\\", \\\"{x:1609,y:659,t:1526922717282};\\\", \\\"{x:1518,y:655,t:1526922717298};\\\", \\\"{x:1459,y:635,t:1526922717316};\\\", \\\"{x:1394,y:614,t:1526922717331};\\\", \\\"{x:1328,y:585,t:1526922717349};\\\", \\\"{x:1273,y:562,t:1526922717366};\\\", \\\"{x:1241,y:549,t:1526922717382};\\\", \\\"{x:1228,y:537,t:1526922717399};\\\", \\\"{x:1217,y:520,t:1526922717415};\\\", \\\"{x:1213,y:507,t:1526922717431};\\\", \\\"{x:1212,y:487,t:1526922717449};\\\", \\\"{x:1213,y:466,t:1526922717466};\\\", \\\"{x:1215,y:463,t:1526922717482};\\\", \\\"{x:1223,y:451,t:1526922717498};\\\", \\\"{x:1225,y:449,t:1526922717516};\\\", \\\"{x:1226,y:449,t:1526922717532};\\\", \\\"{x:1227,y:449,t:1526922717548};\\\", \\\"{x:1230,y:449,t:1526922717565};\\\", \\\"{x:1247,y:456,t:1526922717582};\\\", \\\"{x:1274,y:475,t:1526922717599};\\\", \\\"{x:1299,y:489,t:1526922717616};\\\", \\\"{x:1336,y:508,t:1526922717631};\\\", \\\"{x:1372,y:525,t:1526922717648};\\\", \\\"{x:1416,y:547,t:1526922717666};\\\", \\\"{x:1432,y:550,t:1526922717683};\\\", \\\"{x:1443,y:552,t:1526922717699};\\\", \\\"{x:1444,y:552,t:1526922717716};\\\", \\\"{x:1446,y:552,t:1526922717803};\\\", \\\"{x:1448,y:551,t:1526922717815};\\\", \\\"{x:1448,y:549,t:1526922717833};\\\", \\\"{x:1452,y:540,t:1526922717849};\\\", \\\"{x:1457,y:533,t:1526922717866};\\\", \\\"{x:1460,y:528,t:1526922717882};\\\", \\\"{x:1461,y:525,t:1526922717898};\\\", \\\"{x:1463,y:522,t:1526922717916};\\\", \\\"{x:1465,y:519,t:1526922717933};\\\", \\\"{x:1466,y:517,t:1526922717949};\\\", \\\"{x:1467,y:516,t:1526922717966};\\\", \\\"{x:1468,y:515,t:1526922717982};\\\", \\\"{x:1469,y:514,t:1526922717999};\\\", \\\"{x:1471,y:512,t:1526922718016};\\\", \\\"{x:1472,y:511,t:1526922718034};\\\", \\\"{x:1472,y:510,t:1526922718049};\\\", \\\"{x:1477,y:508,t:1526922718066};\\\", \\\"{x:1478,y:507,t:1526922718090};\\\", \\\"{x:1479,y:507,t:1526922718100};\\\", \\\"{x:1480,y:505,t:1526922718116};\\\", \\\"{x:1482,y:505,t:1526922718132};\\\", \\\"{x:1486,y:503,t:1526922718149};\\\", \\\"{x:1489,y:502,t:1526922718166};\\\", \\\"{x:1492,y:501,t:1526922718183};\\\", \\\"{x:1493,y:500,t:1526922718200};\\\", \\\"{x:1494,y:500,t:1526922718216};\\\", \\\"{x:1492,y:499,t:1526922718315};\\\", \\\"{x:1483,y:497,t:1526922718333};\\\", \\\"{x:1476,y:493,t:1526922718350};\\\", \\\"{x:1475,y:498,t:1526922719218};\\\", \\\"{x:1475,y:509,t:1526922719234};\\\", \\\"{x:1475,y:518,t:1526922719251};\\\", \\\"{x:1475,y:525,t:1526922719267};\\\", \\\"{x:1474,y:529,t:1526922719284};\\\", \\\"{x:1474,y:531,t:1526922719300};\\\", \\\"{x:1474,y:532,t:1526922719338};\\\", \\\"{x:1474,y:534,t:1526922719666};\\\", \\\"{x:1474,y:536,t:1526922719683};\\\", \\\"{x:1474,y:537,t:1526922719701};\\\", \\\"{x:1474,y:542,t:1526922720251};\\\", \\\"{x:1474,y:548,t:1526922720268};\\\", \\\"{x:1474,y:555,t:1526922720284};\\\", \\\"{x:1474,y:562,t:1526922720300};\\\", \\\"{x:1475,y:566,t:1526922720318};\\\", \\\"{x:1475,y:570,t:1526922720334};\\\", \\\"{x:1475,y:573,t:1526922720351};\\\", \\\"{x:1475,y:574,t:1526922720368};\\\", \\\"{x:1475,y:576,t:1526922720383};\\\", \\\"{x:1475,y:577,t:1526922720401};\\\", \\\"{x:1475,y:579,t:1526922720523};\\\", \\\"{x:1475,y:581,t:1526922720535};\\\", \\\"{x:1475,y:586,t:1526922720551};\\\", \\\"{x:1475,y:591,t:1526922720568};\\\", \\\"{x:1475,y:596,t:1526922720585};\\\", \\\"{x:1475,y:602,t:1526922720600};\\\", \\\"{x:1475,y:606,t:1526922720617};\\\", \\\"{x:1475,y:610,t:1526922720634};\\\", \\\"{x:1475,y:612,t:1526922720650};\\\", \\\"{x:1475,y:613,t:1526922720668};\\\", \\\"{x:1475,y:615,t:1526922720684};\\\", \\\"{x:1475,y:616,t:1526922720705};\\\", \\\"{x:1475,y:618,t:1526922720717};\\\", \\\"{x:1475,y:622,t:1526922720734};\\\", \\\"{x:1475,y:623,t:1526922720750};\\\", \\\"{x:1475,y:624,t:1526922720768};\\\", \\\"{x:1475,y:625,t:1526922720784};\\\", \\\"{x:1475,y:626,t:1526922720801};\\\", \\\"{x:1475,y:627,t:1526922720834};\\\", \\\"{x:1475,y:630,t:1526922720882};\\\", \\\"{x:1472,y:633,t:1526922720889};\\\", \\\"{x:1466,y:638,t:1526922720900};\\\", \\\"{x:1428,y:653,t:1526922720917};\\\", \\\"{x:1333,y:683,t:1526922720934};\\\", \\\"{x:1224,y:742,t:1526922720951};\\\", \\\"{x:1099,y:808,t:1526922720967};\\\", \\\"{x:936,y:886,t:1526922720984};\\\", \\\"{x:595,y:997,t:1526922721001};\\\", \\\"{x:368,y:1077,t:1526922721017};\\\", \\\"{x:179,y:1149,t:1526922721034};\\\", \\\"{x:34,y:1199,t:1526922721052};\\\", \\\"{x:8,y:1199,t:1526922721067};\\\", \\\"{x:9,y:1199,t:1526922721106};\\\", \\\"{x:14,y:1199,t:1526922721118};\\\", \\\"{x:29,y:1199,t:1526922721135};\\\", \\\"{x:50,y:1199,t:1526922721152};\\\", \\\"{x:68,y:1199,t:1526922721168};\\\", \\\"{x:94,y:1199,t:1526922721185};\\\", \\\"{x:140,y:1199,t:1526922721201};\\\", \\\"{x:169,y:1192,t:1526922721218};\\\", \\\"{x:195,y:1166,t:1526922721234};\\\", \\\"{x:221,y:1115,t:1526922721251};\\\", \\\"{x:253,y:1051,t:1526922721268};\\\", \\\"{x:290,y:993,t:1526922721285};\\\", \\\"{x:329,y:941,t:1526922721301};\\\", \\\"{x:366,y:900,t:1526922721318};\\\", \\\"{x:399,y:877,t:1526922721336};\\\", \\\"{x:415,y:863,t:1526922721351};\\\", \\\"{x:425,y:856,t:1526922721368};\\\", \\\"{x:448,y:843,t:1526922721385};\\\", \\\"{x:479,y:831,t:1526922721401};\\\", \\\"{x:534,y:809,t:1526922721419};\\\", \\\"{x:587,y:793,t:1526922721435};\\\", \\\"{x:614,y:784,t:1526922721451};\\\", \\\"{x:640,y:777,t:1526922721469};\\\", \\\"{x:683,y:762,t:1526922721486};\\\", \\\"{x:744,y:745,t:1526922721502};\\\", \\\"{x:797,y:729,t:1526922721518};\\\", \\\"{x:843,y:713,t:1526922721535};\\\", \\\"{x:867,y:703,t:1526922721553};\\\", \\\"{x:880,y:693,t:1526922721568};\\\", \\\"{x:891,y:673,t:1526922721585};\\\", \\\"{x:891,y:659,t:1526922721603};\\\", \\\"{x:891,y:646,t:1526922721618};\\\", \\\"{x:887,y:632,t:1526922721636};\\\", \\\"{x:876,y:619,t:1526922721653};\\\", \\\"{x:866,y:611,t:1526922721669};\\\", \\\"{x:855,y:602,t:1526922721685};\\\", \\\"{x:849,y:594,t:1526922721701};\\\", \\\"{x:846,y:589,t:1526922721719};\\\", \\\"{x:845,y:586,t:1526922721735};\\\", \\\"{x:845,y:583,t:1526922721751};\\\", \\\"{x:845,y:581,t:1526922721768};\\\", \\\"{x:849,y:576,t:1526922721785};\\\", \\\"{x:851,y:574,t:1526922721800};\\\", \\\"{x:852,y:573,t:1526922721818};\\\", \\\"{x:854,y:572,t:1526922721986};\\\", \\\"{x:859,y:568,t:1526922722002};\\\", \\\"{x:864,y:565,t:1526922722019};\\\", \\\"{x:869,y:562,t:1526922722036};\\\", \\\"{x:873,y:559,t:1526922722052};\\\", \\\"{x:877,y:556,t:1526922722069};\\\", \\\"{x:879,y:556,t:1526922722086};\\\", \\\"{x:879,y:554,t:1526922722102};\\\", \\\"{x:879,y:553,t:1526922722119};\\\", \\\"{x:879,y:551,t:1526922722136};\\\", \\\"{x:879,y:550,t:1526922722153};\\\", \\\"{x:879,y:544,t:1526922722168};\\\", \\\"{x:876,y:534,t:1526922722185};\\\", \\\"{x:867,y:526,t:1526922722203};\\\", \\\"{x:857,y:518,t:1526922722219};\\\", \\\"{x:853,y:515,t:1526922722235};\\\", \\\"{x:850,y:512,t:1526922722252};\\\", \\\"{x:849,y:513,t:1526922722419};\\\", \\\"{x:848,y:515,t:1526922722426};\\\", \\\"{x:848,y:516,t:1526922722435};\\\", \\\"{x:846,y:522,t:1526922722454};\\\", \\\"{x:844,y:526,t:1526922722469};\\\", \\\"{x:843,y:528,t:1526922722486};\\\", \\\"{x:842,y:529,t:1526922722586};\\\", \\\"{x:841,y:528,t:1526922722609};\\\", \\\"{x:840,y:528,t:1526922722625};\\\", \\\"{x:840,y:527,t:1526922723474};\\\", \\\"{x:842,y:526,t:1526922723489};\\\", \\\"{x:834,y:528,t:1526922725723};\\\", \\\"{x:794,y:543,t:1526922725740};\\\", \\\"{x:720,y:563,t:1526922725757};\\\", \\\"{x:624,y:585,t:1526922725772};\\\", \\\"{x:499,y:604,t:1526922725788};\\\", \\\"{x:376,y:612,t:1526922725805};\\\", \\\"{x:265,y:612,t:1526922725822};\\\", \\\"{x:174,y:621,t:1526922725839};\\\", \\\"{x:136,y:628,t:1526922725856};\\\", \\\"{x:117,y:630,t:1526922725871};\\\", \\\"{x:114,y:630,t:1526922725888};\\\", \\\"{x:114,y:629,t:1526922725946};\\\", \\\"{x:115,y:629,t:1526922725961};\\\", \\\"{x:117,y:628,t:1526922725977};\\\", \\\"{x:120,y:627,t:1526922725988};\\\", \\\"{x:127,y:625,t:1526922726005};\\\", \\\"{x:142,y:620,t:1526922726021};\\\", \\\"{x:167,y:615,t:1526922726039};\\\", \\\"{x:229,y:605,t:1526922726055};\\\", \\\"{x:320,y:593,t:1526922726071};\\\", \\\"{x:442,y:591,t:1526922726089};\\\", \\\"{x:578,y:591,t:1526922726105};\\\", \\\"{x:659,y:591,t:1526922726121};\\\", \\\"{x:704,y:591,t:1526922726138};\\\", \\\"{x:725,y:591,t:1526922726155};\\\", \\\"{x:729,y:590,t:1526922726171};\\\", \\\"{x:729,y:589,t:1526922726193};\\\", \\\"{x:726,y:589,t:1526922726206};\\\", \\\"{x:704,y:587,t:1526922726222};\\\", \\\"{x:669,y:584,t:1526922726238};\\\", \\\"{x:627,y:583,t:1526922726256};\\\", \\\"{x:585,y:583,t:1526922726272};\\\", \\\"{x:553,y:583,t:1526922726288};\\\", \\\"{x:511,y:583,t:1526922726306};\\\", \\\"{x:488,y:583,t:1526922726324};\\\", \\\"{x:469,y:583,t:1526922726338};\\\", \\\"{x:454,y:590,t:1526922726356};\\\", \\\"{x:442,y:603,t:1526922726374};\\\", \\\"{x:437,y:614,t:1526922726389};\\\", \\\"{x:437,y:619,t:1526922726405};\\\", \\\"{x:437,y:625,t:1526922726422};\\\", \\\"{x:437,y:628,t:1526922726439};\\\", \\\"{x:437,y:630,t:1526922726456};\\\", \\\"{x:438,y:634,t:1526922726474};\\\", \\\"{x:438,y:641,t:1526922726489};\\\", \\\"{x:438,y:648,t:1526922726505};\\\", \\\"{x:438,y:653,t:1526922726522};\\\", \\\"{x:432,y:662,t:1526922726539};\\\", \\\"{x:412,y:671,t:1526922726556};\\\", \\\"{x:372,y:679,t:1526922726574};\\\", \\\"{x:297,y:679,t:1526922726588};\\\", \\\"{x:197,y:679,t:1526922726605};\\\", \\\"{x:93,y:674,t:1526922726623};\\\", \\\"{x:8,y:657,t:1526922726638};\\\", \\\"{x:8,y:644,t:1526922726655};\\\", \\\"{x:8,y:636,t:1526922726672};\\\", \\\"{x:8,y:634,t:1526922726689};\\\", \\\"{x:17,y:630,t:1526922726706};\\\", \\\"{x:31,y:630,t:1526922726722};\\\", \\\"{x:50,y:630,t:1526922726739};\\\", \\\"{x:70,y:630,t:1526922726755};\\\", \\\"{x:89,y:630,t:1526922726774};\\\", \\\"{x:106,y:630,t:1526922726789};\\\", \\\"{x:125,y:630,t:1526922726806};\\\", \\\"{x:143,y:627,t:1526922726823};\\\", \\\"{x:164,y:623,t:1526922726840};\\\", \\\"{x:183,y:623,t:1526922726856};\\\", \\\"{x:198,y:620,t:1526922726872};\\\", \\\"{x:210,y:618,t:1526922726889};\\\", \\\"{x:216,y:616,t:1526922726905};\\\", \\\"{x:227,y:612,t:1526922726923};\\\", \\\"{x:235,y:609,t:1526922726939};\\\", \\\"{x:238,y:607,t:1526922726956};\\\", \\\"{x:239,y:606,t:1526922726973};\\\", \\\"{x:234,y:601,t:1526922726990};\\\", \\\"{x:210,y:593,t:1526922727007};\\\", \\\"{x:182,y:586,t:1526922727023};\\\", \\\"{x:146,y:571,t:1526922727039};\\\", \\\"{x:122,y:560,t:1526922727056};\\\", \\\"{x:101,y:545,t:1526922727073};\\\", \\\"{x:90,y:535,t:1526922727089};\\\", \\\"{x:90,y:532,t:1526922727107};\\\", \\\"{x:90,y:527,t:1526922727123};\\\", \\\"{x:96,y:519,t:1526922727141};\\\", \\\"{x:102,y:515,t:1526922727157};\\\", \\\"{x:107,y:513,t:1526922727174};\\\", \\\"{x:108,y:513,t:1526922727193};\\\", \\\"{x:109,y:511,t:1526922727206};\\\", \\\"{x:110,y:511,t:1526922727258};\\\", \\\"{x:112,y:513,t:1526922727273};\\\", \\\"{x:114,y:521,t:1526922727291};\\\", \\\"{x:117,y:526,t:1526922727306};\\\", \\\"{x:120,y:531,t:1526922727322};\\\", \\\"{x:121,y:533,t:1526922727339};\\\", \\\"{x:121,y:535,t:1526922727356};\\\", \\\"{x:122,y:537,t:1526922727417};\\\", \\\"{x:123,y:538,t:1526922727425};\\\", \\\"{x:123,y:539,t:1526922727439};\\\", \\\"{x:125,y:541,t:1526922727456};\\\", \\\"{x:128,y:543,t:1526922727473};\\\", \\\"{x:133,y:544,t:1526922727489};\\\", \\\"{x:137,y:544,t:1526922727506};\\\", \\\"{x:142,y:544,t:1526922727523};\\\", \\\"{x:144,y:544,t:1526922727539};\\\", \\\"{x:148,y:543,t:1526922727556};\\\", \\\"{x:152,y:541,t:1526922727574};\\\", \\\"{x:155,y:539,t:1526922727590};\\\", \\\"{x:158,y:539,t:1526922727606};\\\", \\\"{x:162,y:539,t:1526922727849};\\\", \\\"{x:173,y:542,t:1526922727857};\\\", \\\"{x:208,y:562,t:1526922727874};\\\", \\\"{x:250,y:583,t:1526922727889};\\\", \\\"{x:301,y:631,t:1526922727907};\\\", \\\"{x:370,y:686,t:1526922727924};\\\", \\\"{x:454,y:729,t:1526922727941};\\\", \\\"{x:513,y:760,t:1526922727957};\\\", \\\"{x:553,y:773,t:1526922727974};\\\", \\\"{x:564,y:776,t:1526922727991};\\\", \\\"{x:564,y:777,t:1526922728057};\\\", \\\"{x:561,y:777,t:1526922728073};\\\", \\\"{x:559,y:777,t:1526922728091};\\\", \\\"{x:558,y:777,t:1526922728106};\\\", \\\"{x:555,y:778,t:1526922728124};\\\", \\\"{x:554,y:778,t:1526922728141};\\\", \\\"{x:551,y:778,t:1526922728156};\\\", \\\"{x:550,y:777,t:1526922728174};\\\", \\\"{x:549,y:775,t:1526922728191};\\\", \\\"{x:549,y:771,t:1526922728207};\\\", \\\"{x:549,y:764,t:1526922728224};\\\", \\\"{x:549,y:759,t:1526922728240};\\\", \\\"{x:551,y:747,t:1526922728258};\\\", \\\"{x:553,y:743,t:1526922728273};\\\", \\\"{x:555,y:738,t:1526922728291};\\\", \\\"{x:556,y:731,t:1526922728306};\\\", \\\"{x:556,y:727,t:1526922728323};\\\", \\\"{x:556,y:725,t:1526922728340};\\\" ] }, { \\\"rt\\\": 89926, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 431178, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 5.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\", \\\"E\\\", \\\"F\\\", \\\"M\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-03 PM-M -J -J -X -X -X -X -N -D -D -10 AM-M -C -C -C -H -H -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:557,y:725,t:1526922736194};\\\", \\\"{x:558,y:725,t:1526922736202};\\\", \\\"{x:559,y:724,t:1526922736214};\\\", \\\"{x:563,y:723,t:1526922736231};\\\", \\\"{x:564,y:722,t:1526922736538};\\\", \\\"{x:565,y:718,t:1526922741507};\\\", \\\"{x:565,y:711,t:1526922741518};\\\", \\\"{x:565,y:694,t:1526922741535};\\\", \\\"{x:565,y:676,t:1526922741552};\\\", \\\"{x:565,y:650,t:1526922741569};\\\", \\\"{x:565,y:633,t:1526922741585};\\\", \\\"{x:565,y:617,t:1526922741602};\\\", \\\"{x:567,y:602,t:1526922741619};\\\", \\\"{x:572,y:586,t:1526922741635};\\\", \\\"{x:576,y:571,t:1526922741651};\\\", \\\"{x:581,y:554,t:1526922741668};\\\", \\\"{x:586,y:540,t:1526922741684};\\\", \\\"{x:590,y:528,t:1526922741701};\\\", \\\"{x:598,y:516,t:1526922741718};\\\", \\\"{x:602,y:507,t:1526922741734};\\\", \\\"{x:606,y:499,t:1526922741751};\\\", \\\"{x:608,y:495,t:1526922741768};\\\", \\\"{x:610,y:493,t:1526922741784};\\\", \\\"{x:611,y:492,t:1526922741801};\\\", \\\"{x:612,y:492,t:1526922742226};\\\", \\\"{x:613,y:492,t:1526922742265};\\\", \\\"{x:613,y:494,t:1526922742281};\\\", \\\"{x:613,y:496,t:1526922742297};\\\", \\\"{x:612,y:499,t:1526922742305};\\\", \\\"{x:610,y:502,t:1526922742318};\\\", \\\"{x:605,y:511,t:1526922742335};\\\", \\\"{x:597,y:522,t:1526922742353};\\\", \\\"{x:592,y:533,t:1526922742368};\\\", \\\"{x:582,y:550,t:1526922742385};\\\", \\\"{x:577,y:564,t:1526922742402};\\\", \\\"{x:569,y:577,t:1526922742417};\\\", \\\"{x:563,y:589,t:1526922742435};\\\", \\\"{x:558,y:595,t:1526922742453};\\\", \\\"{x:556,y:598,t:1526922742468};\\\", \\\"{x:559,y:598,t:1526922742545};\\\", \\\"{x:560,y:598,t:1526922742553};\\\", \\\"{x:566,y:596,t:1526922742569};\\\", \\\"{x:571,y:595,t:1526922742584};\\\", \\\"{x:574,y:593,t:1526922742602};\\\", \\\"{x:576,y:593,t:1526922742619};\\\", \\\"{x:577,y:593,t:1526922742635};\\\", \\\"{x:577,y:597,t:1526922742715};\\\", \\\"{x:577,y:605,t:1526922742735};\\\", \\\"{x:577,y:617,t:1526922742752};\\\", \\\"{x:576,y:629,t:1526922742768};\\\", \\\"{x:572,y:649,t:1526922742785};\\\", \\\"{x:570,y:661,t:1526922742802};\\\", \\\"{x:566,y:674,t:1526922742819};\\\", \\\"{x:565,y:684,t:1526922742835};\\\", \\\"{x:563,y:694,t:1526922742852};\\\", \\\"{x:563,y:701,t:1526922742869};\\\", \\\"{x:563,y:710,t:1526922742885};\\\", \\\"{x:563,y:718,t:1526922742903};\\\", \\\"{x:564,y:730,t:1526922742919};\\\", \\\"{x:564,y:743,t:1526922742935};\\\", \\\"{x:564,y:757,t:1526922742952};\\\", \\\"{x:553,y:779,t:1526922742968};\\\", \\\"{x:539,y:795,t:1526922742985};\\\", \\\"{x:526,y:809,t:1526922743002};\\\", \\\"{x:508,y:823,t:1526922743019};\\\", \\\"{x:489,y:835,t:1526922743036};\\\", \\\"{x:473,y:844,t:1526922743053};\\\", \\\"{x:460,y:851,t:1526922743069};\\\", \\\"{x:449,y:855,t:1526922743086};\\\", \\\"{x:442,y:857,t:1526922743103};\\\", \\\"{x:437,y:859,t:1526922743119};\\\", \\\"{x:434,y:860,t:1526922743136};\\\", \\\"{x:433,y:861,t:1526922743152};\\\", \\\"{x:431,y:862,t:1526922743169};\\\", \\\"{x:430,y:862,t:1526922743187};\\\", \\\"{x:428,y:863,t:1526922743202};\\\", \\\"{x:426,y:866,t:1526922743219};\\\", \\\"{x:422,y:869,t:1526922743236};\\\", \\\"{x:418,y:874,t:1526922743252};\\\", \\\"{x:410,y:885,t:1526922743269};\\\", \\\"{x:403,y:895,t:1526922743287};\\\", \\\"{x:390,y:910,t:1526922743303};\\\", \\\"{x:376,y:928,t:1526922743320};\\\", \\\"{x:356,y:946,t:1526922743336};\\\", \\\"{x:329,y:963,t:1526922743352};\\\", \\\"{x:267,y:1000,t:1526922743369};\\\", \\\"{x:222,y:1021,t:1526922743385};\\\", \\\"{x:175,y:1042,t:1526922743403};\\\", \\\"{x:125,y:1056,t:1526922743419};\\\", \\\"{x:78,y:1068,t:1526922743436};\\\", \\\"{x:41,y:1074,t:1526922743452};\\\", \\\"{x:19,y:1078,t:1526922743469};\\\", \\\"{x:8,y:1078,t:1526922743486};\\\", \\\"{x:8,y:1077,t:1526922743634};\\\", \\\"{x:8,y:1076,t:1526922743641};\\\", \\\"{x:8,y:1023,t:1526922768602};\\\", \\\"{x:23,y:901,t:1526922768610};\\\", \\\"{x:57,y:763,t:1526922768621};\\\", \\\"{x:146,y:564,t:1526922768639};\\\", \\\"{x:250,y:383,t:1526922768656};\\\", \\\"{x:338,y:233,t:1526922768672};\\\", \\\"{x:425,y:113,t:1526922768682};\\\", \\\"{x:487,y:39,t:1526922768699};\\\", \\\"{x:541,y:0,t:1526922768716};\\\", \\\"{x:594,y:0,t:1526922768732};\\\", \\\"{x:679,y:0,t:1526922768749};\\\", \\\"{x:790,y:15,t:1526922768766};\\\", \\\"{x:941,y:101,t:1526922768783};\\\", \\\"{x:1094,y:189,t:1526922768799};\\\", \\\"{x:1258,y:280,t:1526922768816};\\\", \\\"{x:1417,y:361,t:1526922768833};\\\", \\\"{x:1579,y:427,t:1526922768849};\\\", \\\"{x:1773,y:487,t:1526922768866};\\\", \\\"{x:1851,y:504,t:1526922768882};\\\", \\\"{x:1875,y:504,t:1526922768899};\\\", \\\"{x:1880,y:504,t:1526922768916};\\\", \\\"{x:1881,y:500,t:1526922768933};\\\", \\\"{x:1867,y:491,t:1526922768949};\\\", \\\"{x:1838,y:479,t:1526922768965};\\\", \\\"{x:1796,y:467,t:1526922768983};\\\", \\\"{x:1743,y:466,t:1526922768999};\\\", \\\"{x:1688,y:470,t:1526922769016};\\\", \\\"{x:1644,y:484,t:1526922769033};\\\", \\\"{x:1597,y:502,t:1526922769048};\\\", \\\"{x:1558,y:521,t:1526922769066};\\\", \\\"{x:1500,y:559,t:1526922769082};\\\", \\\"{x:1454,y:595,t:1526922769099};\\\", \\\"{x:1407,y:645,t:1526922769116};\\\", \\\"{x:1372,y:693,t:1526922769133};\\\", \\\"{x:1326,y:746,t:1526922769149};\\\", \\\"{x:1296,y:790,t:1526922769166};\\\", \\\"{x:1269,y:837,t:1526922769183};\\\", \\\"{x:1251,y:888,t:1526922769199};\\\", \\\"{x:1244,y:933,t:1526922769216};\\\", \\\"{x:1240,y:964,t:1526922769233};\\\", \\\"{x:1240,y:990,t:1526922769249};\\\", \\\"{x:1237,y:1008,t:1526922769266};\\\", \\\"{x:1230,y:1023,t:1526922769282};\\\", \\\"{x:1226,y:1027,t:1526922769298};\\\", \\\"{x:1215,y:1030,t:1526922769315};\\\", \\\"{x:1194,y:1030,t:1526922769332};\\\", \\\"{x:1168,y:1030,t:1526922769349};\\\", \\\"{x:1153,y:1030,t:1526922769365};\\\", \\\"{x:1149,y:1030,t:1526922769382};\\\", \\\"{x:1148,y:1030,t:1526922769402};\\\", \\\"{x:1148,y:1028,t:1526922769416};\\\", \\\"{x:1148,y:1021,t:1526922769432};\\\", \\\"{x:1148,y:1008,t:1526922769449};\\\", \\\"{x:1150,y:988,t:1526922769466};\\\", \\\"{x:1162,y:962,t:1526922769482};\\\", \\\"{x:1174,y:940,t:1526922769499};\\\", \\\"{x:1192,y:911,t:1526922769516};\\\", \\\"{x:1206,y:879,t:1526922769531};\\\", \\\"{x:1219,y:848,t:1526922769549};\\\", \\\"{x:1228,y:825,t:1526922769566};\\\", \\\"{x:1232,y:805,t:1526922769582};\\\", \\\"{x:1233,y:788,t:1526922769599};\\\", \\\"{x:1233,y:768,t:1526922769616};\\\", \\\"{x:1233,y:760,t:1526922769631};\\\", \\\"{x:1233,y:758,t:1526922769648};\\\", \\\"{x:1235,y:766,t:1526922769730};\\\", \\\"{x:1241,y:781,t:1526922769738};\\\", \\\"{x:1255,y:810,t:1526922769749};\\\", \\\"{x:1293,y:873,t:1526922769766};\\\", \\\"{x:1338,y:925,t:1526922769781};\\\", \\\"{x:1408,y:958,t:1526922769799};\\\", \\\"{x:1485,y:980,t:1526922769816};\\\", \\\"{x:1545,y:992,t:1526922769832};\\\", \\\"{x:1576,y:998,t:1526922769849};\\\", \\\"{x:1586,y:998,t:1526922769866};\\\", \\\"{x:1587,y:998,t:1526922769890};\\\", \\\"{x:1587,y:997,t:1526922769906};\\\", \\\"{x:1583,y:992,t:1526922769916};\\\", \\\"{x:1569,y:984,t:1526922769932};\\\", \\\"{x:1553,y:973,t:1526922769949};\\\", \\\"{x:1542,y:964,t:1526922769966};\\\", \\\"{x:1531,y:957,t:1526922769982};\\\", \\\"{x:1522,y:948,t:1526922769999};\\\", \\\"{x:1511,y:937,t:1526922770016};\\\", \\\"{x:1501,y:929,t:1526922770032};\\\", \\\"{x:1491,y:923,t:1526922770049};\\\", \\\"{x:1486,y:921,t:1526922770066};\\\", \\\"{x:1484,y:920,t:1526922770082};\\\", \\\"{x:1483,y:919,t:1526922770099};\\\", \\\"{x:1479,y:917,t:1526922770116};\\\", \\\"{x:1475,y:915,t:1526922770132};\\\", \\\"{x:1469,y:913,t:1526922770149};\\\", \\\"{x:1464,y:911,t:1526922770166};\\\", \\\"{x:1458,y:909,t:1526922770182};\\\", \\\"{x:1455,y:909,t:1526922770199};\\\", \\\"{x:1451,y:909,t:1526922770215};\\\", \\\"{x:1447,y:909,t:1526922770232};\\\", \\\"{x:1441,y:909,t:1526922770249};\\\", \\\"{x:1428,y:909,t:1526922770264};\\\", \\\"{x:1414,y:909,t:1526922770282};\\\", \\\"{x:1412,y:910,t:1526922770298};\\\", \\\"{x:1411,y:910,t:1526922770386};\\\", \\\"{x:1409,y:909,t:1526922770402};\\\", \\\"{x:1408,y:907,t:1526922770415};\\\", \\\"{x:1407,y:903,t:1526922770431};\\\", \\\"{x:1405,y:899,t:1526922770449};\\\", \\\"{x:1404,y:897,t:1526922770465};\\\", \\\"{x:1403,y:896,t:1526922770554};\\\", \\\"{x:1402,y:896,t:1526922770565};\\\", \\\"{x:1401,y:896,t:1526922770582};\\\", \\\"{x:1399,y:896,t:1526922770599};\\\", \\\"{x:1398,y:896,t:1526922770615};\\\", \\\"{x:1395,y:896,t:1526922770632};\\\", \\\"{x:1392,y:896,t:1526922770648};\\\", \\\"{x:1391,y:896,t:1526922770666};\\\", \\\"{x:1390,y:896,t:1526922770681};\\\", \\\"{x:1389,y:897,t:1526922770699};\\\", \\\"{x:1388,y:897,t:1526922770722};\\\", \\\"{x:1386,y:897,t:1526922770739};\\\", \\\"{x:1385,y:897,t:1526922770842};\\\", \\\"{x:1383,y:897,t:1526922770867};\\\", \\\"{x:1381,y:897,t:1526922770898};\\\", \\\"{x:1381,y:896,t:1526922770922};\\\", \\\"{x:1382,y:896,t:1526922771010};\\\", \\\"{x:1385,y:896,t:1526922771018};\\\", \\\"{x:1387,y:896,t:1526922771033};\\\", \\\"{x:1395,y:896,t:1526922771048};\\\", \\\"{x:1407,y:895,t:1526922771065};\\\", \\\"{x:1416,y:895,t:1526922771082};\\\", \\\"{x:1419,y:895,t:1526922771098};\\\", \\\"{x:1420,y:895,t:1526922771162};\\\", \\\"{x:1423,y:894,t:1526922771170};\\\", \\\"{x:1429,y:892,t:1526922771182};\\\", \\\"{x:1442,y:892,t:1526922771198};\\\", \\\"{x:1453,y:892,t:1526922771215};\\\", \\\"{x:1464,y:892,t:1526922771232};\\\", \\\"{x:1466,y:892,t:1526922771248};\\\", \\\"{x:1467,y:892,t:1526922771266};\\\", \\\"{x:1468,y:892,t:1526922771306};\\\", \\\"{x:1468,y:894,t:1526922771378};\\\", \\\"{x:1466,y:895,t:1526922771402};\\\", \\\"{x:1464,y:896,t:1526922771418};\\\", \\\"{x:1461,y:896,t:1526922771450};\\\", \\\"{x:1460,y:896,t:1526922771465};\\\", \\\"{x:1455,y:898,t:1526922771482};\\\", \\\"{x:1451,y:898,t:1526922771498};\\\", \\\"{x:1448,y:898,t:1526922771515};\\\", \\\"{x:1444,y:898,t:1526922771532};\\\", \\\"{x:1443,y:898,t:1526922771548};\\\", \\\"{x:1441,y:898,t:1526922771565};\\\", \\\"{x:1440,y:898,t:1526922771586};\\\", \\\"{x:1438,y:898,t:1526922771610};\\\", \\\"{x:1438,y:897,t:1526922771747};\\\", \\\"{x:1439,y:897,t:1526922771754};\\\", \\\"{x:1442,y:897,t:1526922771765};\\\", \\\"{x:1450,y:897,t:1526922771781};\\\", \\\"{x:1459,y:897,t:1526922771797};\\\", \\\"{x:1470,y:897,t:1526922771815};\\\", \\\"{x:1480,y:896,t:1526922771831};\\\", \\\"{x:1488,y:894,t:1526922771848};\\\", \\\"{x:1492,y:894,t:1526922771865};\\\", \\\"{x:1494,y:894,t:1526922771880};\\\", \\\"{x:1499,y:894,t:1526922771898};\\\", \\\"{x:1501,y:893,t:1526922771915};\\\", \\\"{x:1502,y:893,t:1526922771938};\\\", \\\"{x:1503,y:893,t:1526922772034};\\\", \\\"{x:1504,y:892,t:1526922772048};\\\", \\\"{x:1504,y:891,t:1526922772065};\\\", \\\"{x:1506,y:891,t:1526922772081};\\\", \\\"{x:1507,y:891,t:1526922772146};\\\", \\\"{x:1509,y:891,t:1526922772162};\\\", \\\"{x:1512,y:891,t:1526922772178};\\\", \\\"{x:1513,y:892,t:1526922772186};\\\", \\\"{x:1514,y:892,t:1526922772202};\\\", \\\"{x:1515,y:892,t:1526922772330};\\\", \\\"{x:1518,y:894,t:1526922772658};\\\", \\\"{x:1519,y:895,t:1526922772666};\\\", \\\"{x:1519,y:896,t:1526922772683};\\\", \\\"{x:1523,y:898,t:1526922772698};\\\", \\\"{x:1524,y:898,t:1526922772730};\\\", \\\"{x:1526,y:899,t:1526922772738};\\\", \\\"{x:1529,y:899,t:1526922772754};\\\", \\\"{x:1531,y:899,t:1526922772764};\\\", \\\"{x:1532,y:899,t:1526922772786};\\\", \\\"{x:1535,y:899,t:1526922772819};\\\", \\\"{x:1536,y:899,t:1526922772850};\\\", \\\"{x:1537,y:899,t:1526922772864};\\\", \\\"{x:1538,y:899,t:1526922772881};\\\", \\\"{x:1544,y:898,t:1526922772899};\\\", \\\"{x:1547,y:897,t:1526922772914};\\\", \\\"{x:1551,y:897,t:1526922772931};\\\", \\\"{x:1556,y:894,t:1526922772948};\\\", \\\"{x:1558,y:894,t:1526922772964};\\\", \\\"{x:1559,y:894,t:1526922773074};\\\", \\\"{x:1561,y:894,t:1526922773090};\\\", \\\"{x:1563,y:894,t:1526922773106};\\\", \\\"{x:1566,y:894,t:1526922773114};\\\", \\\"{x:1568,y:894,t:1526922773131};\\\", \\\"{x:1569,y:894,t:1526922773148};\\\", \\\"{x:1571,y:894,t:1526922773186};\\\", \\\"{x:1574,y:893,t:1526922773202};\\\", \\\"{x:1577,y:892,t:1526922773214};\\\", \\\"{x:1578,y:892,t:1526922773231};\\\", \\\"{x:1584,y:892,t:1526922773666};\\\", \\\"{x:1595,y:892,t:1526922773681};\\\", \\\"{x:1604,y:892,t:1526922773696};\\\", \\\"{x:1616,y:894,t:1526922773713};\\\", \\\"{x:1617,y:894,t:1526922773731};\\\", \\\"{x:1618,y:894,t:1526922773898};\\\", \\\"{x:1630,y:894,t:1526922773914};\\\", \\\"{x:1639,y:894,t:1526922773930};\\\", \\\"{x:1642,y:894,t:1526922773946};\\\", \\\"{x:1650,y:894,t:1526922773964};\\\", \\\"{x:1653,y:894,t:1526922773980};\\\", \\\"{x:1655,y:895,t:1526922773997};\\\", \\\"{x:1656,y:895,t:1526922774014};\\\", \\\"{x:1654,y:895,t:1526922774194};\\\", \\\"{x:1653,y:895,t:1526922774202};\\\", \\\"{x:1652,y:895,t:1526922774214};\\\", \\\"{x:1650,y:895,t:1526922774230};\\\", \\\"{x:1648,y:894,t:1526922774247};\\\", \\\"{x:1647,y:893,t:1526922774264};\\\", \\\"{x:1646,y:893,t:1526922774282};\\\", \\\"{x:1645,y:893,t:1526922774314};\\\", \\\"{x:1643,y:891,t:1526922774330};\\\", \\\"{x:1642,y:891,t:1526922774347};\\\", \\\"{x:1641,y:891,t:1526922774364};\\\", \\\"{x:1640,y:891,t:1526922774498};\\\", \\\"{x:1640,y:892,t:1526922774514};\\\", \\\"{x:1641,y:894,t:1526922774530};\\\", \\\"{x:1642,y:895,t:1526922774547};\\\", \\\"{x:1645,y:896,t:1526922774564};\\\", \\\"{x:1648,y:897,t:1526922774580};\\\", \\\"{x:1650,y:898,t:1526922774602};\\\", \\\"{x:1651,y:899,t:1526922774614};\\\", \\\"{x:1653,y:899,t:1526922774630};\\\", \\\"{x:1657,y:901,t:1526922774647};\\\", \\\"{x:1661,y:902,t:1526922774663};\\\", \\\"{x:1663,y:902,t:1526922774680};\\\", \\\"{x:1664,y:904,t:1526922774697};\\\", \\\"{x:1666,y:904,t:1526922774714};\\\", \\\"{x:1667,y:904,t:1526922774738};\\\", \\\"{x:1670,y:904,t:1526922774754};\\\", \\\"{x:1672,y:904,t:1526922774763};\\\", \\\"{x:1678,y:904,t:1526922774780};\\\", \\\"{x:1684,y:904,t:1526922774797};\\\", \\\"{x:1691,y:904,t:1526922774814};\\\", \\\"{x:1696,y:904,t:1526922774830};\\\", \\\"{x:1697,y:904,t:1526922774846};\\\", \\\"{x:1700,y:904,t:1526922774863};\\\", \\\"{x:1701,y:904,t:1526922774880};\\\", \\\"{x:1703,y:903,t:1526922774896};\\\", \\\"{x:1705,y:903,t:1526922774913};\\\", \\\"{x:1707,y:903,t:1526922774930};\\\", \\\"{x:1708,y:902,t:1526922774947};\\\", \\\"{x:1709,y:902,t:1526922774963};\\\", \\\"{x:1709,y:901,t:1526922775002};\\\", \\\"{x:1710,y:901,t:1526922775013};\\\", \\\"{x:1711,y:900,t:1526922775030};\\\", \\\"{x:1713,y:900,t:1526922775047};\\\", \\\"{x:1714,y:899,t:1526922775064};\\\", \\\"{x:1715,y:898,t:1526922775098};\\\", \\\"{x:1715,y:897,t:1526922775170};\\\", \\\"{x:1715,y:896,t:1526922775180};\\\", \\\"{x:1715,y:895,t:1526922775197};\\\", \\\"{x:1715,y:894,t:1526922775213};\\\", \\\"{x:1715,y:893,t:1526922775230};\\\", \\\"{x:1715,y:897,t:1526922775403};\\\", \\\"{x:1715,y:904,t:1526922775414};\\\", \\\"{x:1717,y:914,t:1526922775430};\\\", \\\"{x:1723,y:928,t:1526922775446};\\\", \\\"{x:1734,y:940,t:1526922775464};\\\", \\\"{x:1743,y:947,t:1526922775480};\\\", \\\"{x:1754,y:951,t:1526922775497};\\\", \\\"{x:1763,y:952,t:1526922775513};\\\", \\\"{x:1773,y:952,t:1526922775530};\\\", \\\"{x:1776,y:952,t:1526922775546};\\\", \\\"{x:1778,y:951,t:1526922775563};\\\", \\\"{x:1779,y:946,t:1526922775581};\\\", \\\"{x:1779,y:944,t:1526922775596};\\\", \\\"{x:1779,y:940,t:1526922775613};\\\", \\\"{x:1781,y:935,t:1526922775630};\\\", \\\"{x:1781,y:932,t:1526922775646};\\\", \\\"{x:1781,y:927,t:1526922775663};\\\", \\\"{x:1781,y:924,t:1526922775680};\\\", \\\"{x:1781,y:920,t:1526922775696};\\\", \\\"{x:1780,y:916,t:1526922775713};\\\", \\\"{x:1779,y:911,t:1526922775730};\\\", \\\"{x:1779,y:910,t:1526922775746};\\\", \\\"{x:1778,y:907,t:1526922775763};\\\", \\\"{x:1778,y:905,t:1526922775780};\\\", \\\"{x:1778,y:904,t:1526922775802};\\\", \\\"{x:1778,y:902,t:1526922775835};\\\", \\\"{x:1778,y:901,t:1526922775851};\\\", \\\"{x:1779,y:900,t:1526922775867};\\\", \\\"{x:1779,y:899,t:1526922775881};\\\", \\\"{x:1779,y:898,t:1526922775896};\\\", \\\"{x:1780,y:897,t:1526922775914};\\\", \\\"{x:1781,y:894,t:1526922775931};\\\", \\\"{x:1781,y:888,t:1526922775946};\\\", \\\"{x:1781,y:887,t:1526922775963};\\\", \\\"{x:1781,y:885,t:1526922775981};\\\", \\\"{x:1775,y:884,t:1526922776067};\\\", \\\"{x:1760,y:884,t:1526922776080};\\\", \\\"{x:1703,y:884,t:1526922776096};\\\", \\\"{x:1598,y:884,t:1526922776114};\\\", \\\"{x:1415,y:884,t:1526922776131};\\\", \\\"{x:1321,y:884,t:1526922776146};\\\", \\\"{x:1270,y:884,t:1526922776163};\\\", \\\"{x:1249,y:882,t:1526922776180};\\\", \\\"{x:1246,y:881,t:1526922776196};\\\", \\\"{x:1246,y:880,t:1526922776213};\\\", \\\"{x:1248,y:877,t:1526922776230};\\\", \\\"{x:1252,y:874,t:1526922776246};\\\", \\\"{x:1255,y:870,t:1526922776263};\\\", \\\"{x:1255,y:866,t:1526922776279};\\\", \\\"{x:1255,y:861,t:1526922776296};\\\", \\\"{x:1255,y:856,t:1526922776313};\\\", \\\"{x:1254,y:853,t:1526922776329};\\\", \\\"{x:1254,y:851,t:1526922776346};\\\", \\\"{x:1254,y:849,t:1526922776363};\\\", \\\"{x:1254,y:848,t:1526922776380};\\\", \\\"{x:1254,y:846,t:1526922776396};\\\", \\\"{x:1254,y:845,t:1526922776413};\\\", \\\"{x:1254,y:843,t:1526922776430};\\\", \\\"{x:1254,y:841,t:1526922776451};\\\", \\\"{x:1254,y:840,t:1526922776463};\\\", \\\"{x:1251,y:837,t:1526922776480};\\\", \\\"{x:1246,y:836,t:1526922776497};\\\", \\\"{x:1240,y:832,t:1526922776513};\\\", \\\"{x:1235,y:830,t:1526922776529};\\\", \\\"{x:1230,y:828,t:1526922776546};\\\", \\\"{x:1229,y:827,t:1526922776563};\\\", \\\"{x:1228,y:827,t:1526922776595};\\\", \\\"{x:1225,y:826,t:1526922776603};\\\", \\\"{x:1224,y:826,t:1526922776613};\\\", \\\"{x:1216,y:825,t:1526922776630};\\\", \\\"{x:1208,y:825,t:1526922776648};\\\", \\\"{x:1200,y:825,t:1526922776663};\\\", \\\"{x:1196,y:825,t:1526922776679};\\\", \\\"{x:1199,y:825,t:1526922777227};\\\", \\\"{x:1203,y:825,t:1526922777235};\\\", \\\"{x:1209,y:825,t:1526922777247};\\\", \\\"{x:1216,y:825,t:1526922777263};\\\", \\\"{x:1220,y:825,t:1526922777281};\\\", \\\"{x:1223,y:824,t:1526922777297};\\\", \\\"{x:1224,y:824,t:1526922777355};\\\", \\\"{x:1226,y:824,t:1526922777371};\\\", \\\"{x:1227,y:823,t:1526922777380};\\\", \\\"{x:1230,y:823,t:1526922777403};\\\", \\\"{x:1234,y:823,t:1526922777412};\\\", \\\"{x:1249,y:823,t:1526922777430};\\\", \\\"{x:1263,y:823,t:1526922777447};\\\", \\\"{x:1274,y:823,t:1526922777463};\\\", \\\"{x:1278,y:823,t:1526922777480};\\\", \\\"{x:1279,y:823,t:1526922777497};\\\", \\\"{x:1282,y:824,t:1526922777988};\\\", \\\"{x:1286,y:824,t:1526922777996};\\\", \\\"{x:1307,y:826,t:1526922778013};\\\", \\\"{x:1336,y:830,t:1526922778030};\\\", \\\"{x:1372,y:836,t:1526922778046};\\\", \\\"{x:1409,y:842,t:1526922778063};\\\", \\\"{x:1438,y:848,t:1526922778080};\\\", \\\"{x:1458,y:850,t:1526922778096};\\\", \\\"{x:1461,y:852,t:1526922778113};\\\", \\\"{x:1463,y:852,t:1526922778129};\\\", \\\"{x:1463,y:853,t:1526922778219};\\\", \\\"{x:1462,y:854,t:1526922778230};\\\", \\\"{x:1463,y:854,t:1526922778490};\\\", \\\"{x:1464,y:854,t:1526922778522};\\\", \\\"{x:1465,y:854,t:1526922778603};\\\", \\\"{x:1466,y:854,t:1526922778613};\\\", \\\"{x:1469,y:854,t:1526922778629};\\\", \\\"{x:1473,y:852,t:1526922778645};\\\", \\\"{x:1478,y:849,t:1526922778663};\\\", \\\"{x:1481,y:846,t:1526922778678};\\\", \\\"{x:1484,y:844,t:1526922778696};\\\", \\\"{x:1489,y:840,t:1526922778712};\\\", \\\"{x:1491,y:837,t:1526922778728};\\\", \\\"{x:1494,y:832,t:1526922778746};\\\", \\\"{x:1495,y:830,t:1526922778763};\\\", \\\"{x:1496,y:829,t:1526922778779};\\\", \\\"{x:1496,y:828,t:1526922778900};\\\", \\\"{x:1495,y:826,t:1526922778931};\\\", \\\"{x:1493,y:826,t:1526922778945};\\\", \\\"{x:1483,y:823,t:1526922778962};\\\", \\\"{x:1475,y:821,t:1526922778978};\\\", \\\"{x:1472,y:819,t:1526922778995};\\\", \\\"{x:1469,y:818,t:1526922779012};\\\", \\\"{x:1469,y:817,t:1526922779148};\\\", \\\"{x:1469,y:816,t:1526922779162};\\\", \\\"{x:1471,y:816,t:1526922779178};\\\", \\\"{x:1474,y:816,t:1526922779195};\\\", \\\"{x:1480,y:816,t:1526922779212};\\\", \\\"{x:1489,y:818,t:1526922779228};\\\", \\\"{x:1501,y:822,t:1526922779246};\\\", \\\"{x:1517,y:826,t:1526922779261};\\\", \\\"{x:1530,y:829,t:1526922779278};\\\", \\\"{x:1537,y:831,t:1526922779295};\\\", \\\"{x:1539,y:832,t:1526922779311};\\\", \\\"{x:1540,y:832,t:1526922779524};\\\", \\\"{x:1540,y:831,t:1526922779538};\\\", \\\"{x:1540,y:830,t:1526922779561};\\\", \\\"{x:1540,y:828,t:1526922779586};\\\", \\\"{x:1541,y:828,t:1526922779762};\\\", \\\"{x:1542,y:828,t:1526922779795};\\\", \\\"{x:1541,y:839,t:1526922789643};\\\", \\\"{x:1533,y:901,t:1526922789659};\\\", \\\"{x:1523,y:961,t:1526922789674};\\\", \\\"{x:1507,y:997,t:1526922789690};\\\", \\\"{x:1491,y:1019,t:1526922789707};\\\", \\\"{x:1480,y:1028,t:1526922789724};\\\", \\\"{x:1478,y:1028,t:1526922789741};\\\", \\\"{x:1477,y:1028,t:1526922789770};\\\", \\\"{x:1472,y:1026,t:1526922789778};\\\", \\\"{x:1467,y:1013,t:1526922789790};\\\", \\\"{x:1452,y:980,t:1526922789808};\\\", \\\"{x:1441,y:958,t:1526922789825};\\\", \\\"{x:1437,y:951,t:1526922789841};\\\", \\\"{x:1437,y:939,t:1526922789858};\\\", \\\"{x:1437,y:921,t:1526922789873};\\\", \\\"{x:1439,y:891,t:1526922789891};\\\", \\\"{x:1462,y:839,t:1526922789908};\\\", \\\"{x:1492,y:775,t:1526922789925};\\\", \\\"{x:1519,y:721,t:1526922789940};\\\", \\\"{x:1544,y:675,t:1526922789958};\\\", \\\"{x:1566,y:633,t:1526922789974};\\\", \\\"{x:1582,y:599,t:1526922789991};\\\", \\\"{x:1589,y:588,t:1526922790008};\\\", \\\"{x:1593,y:582,t:1526922790024};\\\", \\\"{x:1593,y:581,t:1526922790040};\\\", \\\"{x:1593,y:582,t:1526922790074};\\\", \\\"{x:1585,y:609,t:1526922790090};\\\", \\\"{x:1567,y:648,t:1526922790108};\\\", \\\"{x:1546,y:684,t:1526922790124};\\\", \\\"{x:1530,y:707,t:1526922790140};\\\", \\\"{x:1524,y:721,t:1526922790158};\\\", \\\"{x:1524,y:731,t:1526922790173};\\\", \\\"{x:1524,y:738,t:1526922790191};\\\", \\\"{x:1524,y:740,t:1526922790208};\\\", \\\"{x:1524,y:742,t:1526922790224};\\\", \\\"{x:1524,y:745,t:1526922790241};\\\", \\\"{x:1524,y:764,t:1526922790258};\\\", \\\"{x:1512,y:796,t:1526922790274};\\\", \\\"{x:1484,y:844,t:1526922790291};\\\", \\\"{x:1463,y:872,t:1526922790308};\\\", \\\"{x:1448,y:884,t:1526922790324};\\\", \\\"{x:1438,y:897,t:1526922790341};\\\", \\\"{x:1429,y:899,t:1526922790358};\\\", \\\"{x:1429,y:900,t:1526922790374};\\\", \\\"{x:1429,y:901,t:1526922790391};\\\", \\\"{x:1429,y:899,t:1526922790467};\\\", \\\"{x:1431,y:896,t:1526922790475};\\\", \\\"{x:1436,y:889,t:1526922790490};\\\", \\\"{x:1445,y:877,t:1526922790508};\\\", \\\"{x:1458,y:863,t:1526922790524};\\\", \\\"{x:1472,y:852,t:1526922790542};\\\", \\\"{x:1481,y:844,t:1526922790558};\\\", \\\"{x:1484,y:841,t:1526922790575};\\\", \\\"{x:1487,y:838,t:1526922790592};\\\", \\\"{x:1488,y:837,t:1526922790608};\\\", \\\"{x:1488,y:836,t:1526922790624};\\\", \\\"{x:1490,y:834,t:1526922790641};\\\", \\\"{x:1490,y:833,t:1526922790826};\\\", \\\"{x:1489,y:830,t:1526922790841};\\\", \\\"{x:1484,y:827,t:1526922790857};\\\", \\\"{x:1483,y:826,t:1526922790874};\\\", \\\"{x:1482,y:823,t:1526922790891};\\\", \\\"{x:1481,y:822,t:1526922790907};\\\", \\\"{x:1480,y:820,t:1526922790924};\\\", \\\"{x:1481,y:820,t:1526922791066};\\\", \\\"{x:1482,y:820,t:1526922791074};\\\", \\\"{x:1486,y:820,t:1526922791091};\\\", \\\"{x:1500,y:820,t:1526922791108};\\\", \\\"{x:1520,y:824,t:1526922791124};\\\", \\\"{x:1543,y:827,t:1526922791141};\\\", \\\"{x:1561,y:829,t:1526922791157};\\\", \\\"{x:1582,y:829,t:1526922791173};\\\", \\\"{x:1595,y:829,t:1526922791191};\\\", \\\"{x:1603,y:829,t:1526922791207};\\\", \\\"{x:1604,y:829,t:1526922791223};\\\", \\\"{x:1606,y:829,t:1526922791241};\\\", \\\"{x:1607,y:829,t:1526922791256};\\\", \\\"{x:1608,y:829,t:1526922791290};\\\", \\\"{x:1606,y:829,t:1526922791386};\\\", \\\"{x:1604,y:829,t:1526922791394};\\\", \\\"{x:1602,y:829,t:1526922791407};\\\", \\\"{x:1595,y:830,t:1526922791424};\\\", \\\"{x:1591,y:830,t:1526922791441};\\\", \\\"{x:1590,y:830,t:1526922791457};\\\", \\\"{x:1589,y:830,t:1526922791482};\\\", \\\"{x:1587,y:830,t:1526922791498};\\\", \\\"{x:1584,y:830,t:1526922791507};\\\", \\\"{x:1579,y:828,t:1526922791525};\\\", \\\"{x:1574,y:827,t:1526922791540};\\\", \\\"{x:1567,y:823,t:1526922791557};\\\", \\\"{x:1561,y:821,t:1526922791574};\\\", \\\"{x:1557,y:820,t:1526922791590};\\\", \\\"{x:1552,y:817,t:1526922791607};\\\", \\\"{x:1549,y:816,t:1526922791624};\\\", \\\"{x:1544,y:814,t:1526922791640};\\\", \\\"{x:1540,y:812,t:1526922791657};\\\", \\\"{x:1538,y:811,t:1526922791675};\\\", \\\"{x:1538,y:812,t:1526922791779};\\\", \\\"{x:1538,y:813,t:1526922791803};\\\", \\\"{x:1538,y:815,t:1526922791827};\\\", \\\"{x:1538,y:816,t:1526922791858};\\\", \\\"{x:1540,y:816,t:1526922791963};\\\", \\\"{x:1540,y:817,t:1526922791975};\\\", \\\"{x:1546,y:820,t:1526922791990};\\\", \\\"{x:1547,y:822,t:1526922792008};\\\", \\\"{x:1549,y:824,t:1526922792024};\\\", \\\"{x:1551,y:826,t:1526922792040};\\\", \\\"{x:1552,y:826,t:1526922792123};\\\", \\\"{x:1553,y:826,t:1526922792140};\\\", \\\"{x:1554,y:826,t:1526922792157};\\\", \\\"{x:1558,y:826,t:1526922792174};\\\", \\\"{x:1562,y:826,t:1526922792190};\\\", \\\"{x:1568,y:826,t:1526922792207};\\\", \\\"{x:1573,y:826,t:1526922792224};\\\", \\\"{x:1580,y:826,t:1526922792240};\\\", \\\"{x:1588,y:826,t:1526922792258};\\\", \\\"{x:1596,y:826,t:1526922792274};\\\", \\\"{x:1598,y:826,t:1526922792291};\\\", \\\"{x:1599,y:826,t:1526922792307};\\\", \\\"{x:1600,y:826,t:1526922792371};\\\", \\\"{x:1601,y:827,t:1526922792419};\\\", \\\"{x:1603,y:828,t:1526922792435};\\\", \\\"{x:1603,y:829,t:1526922792443};\\\", \\\"{x:1606,y:830,t:1526922792457};\\\", \\\"{x:1616,y:836,t:1526922792473};\\\", \\\"{x:1619,y:839,t:1526922792490};\\\", \\\"{x:1622,y:840,t:1526922792506};\\\", \\\"{x:1623,y:840,t:1526922792579};\\\", \\\"{x:1625,y:839,t:1526922792590};\\\", \\\"{x:1626,y:838,t:1526922792607};\\\", \\\"{x:1627,y:835,t:1526922792623};\\\", \\\"{x:1628,y:834,t:1526922792640};\\\", \\\"{x:1628,y:832,t:1526922792657};\\\", \\\"{x:1628,y:831,t:1526922792731};\\\", \\\"{x:1627,y:830,t:1526922792746};\\\", \\\"{x:1626,y:830,t:1526922792770};\\\", \\\"{x:1625,y:830,t:1526922792802};\\\", \\\"{x:1624,y:831,t:1526922792810};\\\", \\\"{x:1623,y:831,t:1526922792823};\\\", \\\"{x:1623,y:832,t:1526922792839};\\\", \\\"{x:1619,y:834,t:1526922792857};\\\", \\\"{x:1617,y:834,t:1526922792873};\\\", \\\"{x:1616,y:835,t:1526922792890};\\\", \\\"{x:1614,y:836,t:1526922792907};\\\", \\\"{x:1613,y:836,t:1526922792937};\\\", \\\"{x:1612,y:836,t:1526922792945};\\\", \\\"{x:1610,y:836,t:1526922792957};\\\", \\\"{x:1608,y:836,t:1526922792993};\\\", \\\"{x:1607,y:836,t:1526922793010};\\\", \\\"{x:1605,y:835,t:1526922793025};\\\", \\\"{x:1606,y:835,t:1526922793099};\\\", \\\"{x:1607,y:835,t:1526922793122};\\\", \\\"{x:1611,y:835,t:1526922793140};\\\", \\\"{x:1617,y:835,t:1526922793156};\\\", \\\"{x:1625,y:835,t:1526922793173};\\\", \\\"{x:1634,y:835,t:1526922793190};\\\", \\\"{x:1642,y:835,t:1526922793205};\\\", \\\"{x:1648,y:835,t:1526922793223};\\\", \\\"{x:1653,y:835,t:1526922793240};\\\", \\\"{x:1657,y:835,t:1526922793256};\\\", \\\"{x:1659,y:835,t:1526922793273};\\\", \\\"{x:1666,y:835,t:1526922793290};\\\", \\\"{x:1670,y:834,t:1526922793306};\\\", \\\"{x:1672,y:833,t:1526922793323};\\\", \\\"{x:1673,y:833,t:1526922793346};\\\", \\\"{x:1674,y:833,t:1526922793362};\\\", \\\"{x:1675,y:832,t:1526922793373};\\\", \\\"{x:1675,y:831,t:1526922793390};\\\", \\\"{x:1676,y:831,t:1526922793419};\\\", \\\"{x:1677,y:831,t:1526922793442};\\\", \\\"{x:1678,y:830,t:1526922793457};\\\", \\\"{x:1679,y:830,t:1526922793481};\\\", \\\"{x:1680,y:830,t:1526922793498};\\\", \\\"{x:1681,y:828,t:1526922793537};\\\", \\\"{x:1682,y:828,t:1526922793546};\\\", \\\"{x:1683,y:827,t:1526922793556};\\\", \\\"{x:1684,y:826,t:1526922793573};\\\", \\\"{x:1685,y:825,t:1526922793772};\\\", \\\"{x:1686,y:825,t:1526922793788};\\\", \\\"{x:1687,y:825,t:1526922793818};\\\", \\\"{x:1690,y:825,t:1526922793826};\\\", \\\"{x:1695,y:825,t:1526922793839};\\\", \\\"{x:1706,y:825,t:1526922793856};\\\", \\\"{x:1717,y:825,t:1526922793873};\\\", \\\"{x:1726,y:825,t:1526922793889};\\\", \\\"{x:1731,y:825,t:1526922793906};\\\", \\\"{x:1735,y:825,t:1526922793924};\\\", \\\"{x:1738,y:824,t:1526922793939};\\\", \\\"{x:1740,y:824,t:1526922793956};\\\", \\\"{x:1742,y:824,t:1526922793973};\\\", \\\"{x:1743,y:824,t:1526922793990};\\\", \\\"{x:1745,y:824,t:1526922794006};\\\", \\\"{x:1746,y:824,t:1526922794026};\\\", \\\"{x:1747,y:824,t:1526922794131};\\\", \\\"{x:1748,y:826,t:1526922794411};\\\", \\\"{x:1749,y:828,t:1526922794423};\\\", \\\"{x:1751,y:831,t:1526922794439};\\\", \\\"{x:1752,y:835,t:1526922794457};\\\", \\\"{x:1756,y:840,t:1526922794473};\\\", \\\"{x:1765,y:844,t:1526922794489};\\\", \\\"{x:1775,y:846,t:1526922794506};\\\", \\\"{x:1782,y:846,t:1526922794523};\\\", \\\"{x:1788,y:846,t:1526922794539};\\\", \\\"{x:1799,y:846,t:1526922794557};\\\", \\\"{x:1811,y:844,t:1526922794572};\\\", \\\"{x:1821,y:843,t:1526922794590};\\\", \\\"{x:1830,y:842,t:1526922794606};\\\", \\\"{x:1835,y:840,t:1526922794623};\\\", \\\"{x:1836,y:839,t:1526922794639};\\\", \\\"{x:1836,y:838,t:1526922794803};\\\", \\\"{x:1835,y:838,t:1526922794811};\\\", \\\"{x:1833,y:838,t:1526922794823};\\\", \\\"{x:1828,y:838,t:1526922794840};\\\", \\\"{x:1824,y:838,t:1526922794856};\\\", \\\"{x:1821,y:838,t:1526922794873};\\\", \\\"{x:1819,y:838,t:1526922794889};\\\", \\\"{x:1818,y:838,t:1526922794907};\\\", \\\"{x:1818,y:837,t:1526922794938};\\\", \\\"{x:1813,y:838,t:1526922795131};\\\", \\\"{x:1803,y:842,t:1526922795139};\\\", \\\"{x:1760,y:855,t:1526922795156};\\\", \\\"{x:1698,y:876,t:1526922795171};\\\", \\\"{x:1608,y:899,t:1526922795189};\\\", \\\"{x:1528,y:919,t:1526922795205};\\\", \\\"{x:1444,y:932,t:1526922795222};\\\", \\\"{x:1374,y:944,t:1526922795238};\\\", \\\"{x:1325,y:954,t:1526922795256};\\\", \\\"{x:1282,y:963,t:1526922795272};\\\", \\\"{x:1253,y:970,t:1526922795289};\\\", \\\"{x:1236,y:971,t:1526922795306};\\\", \\\"{x:1232,y:971,t:1526922795322};\\\", \\\"{x:1231,y:971,t:1526922795339};\\\", \\\"{x:1230,y:971,t:1526922795355};\\\", \\\"{x:1229,y:969,t:1526922795395};\\\", \\\"{x:1229,y:968,t:1526922795406};\\\", \\\"{x:1229,y:962,t:1526922795422};\\\", \\\"{x:1230,y:955,t:1526922795440};\\\", \\\"{x:1236,y:947,t:1526922795455};\\\", \\\"{x:1245,y:940,t:1526922795472};\\\", \\\"{x:1255,y:932,t:1526922795489};\\\", \\\"{x:1268,y:923,t:1526922795505};\\\", \\\"{x:1294,y:910,t:1526922795522};\\\", \\\"{x:1314,y:900,t:1526922795539};\\\", \\\"{x:1351,y:886,t:1526922795556};\\\", \\\"{x:1391,y:871,t:1526922795573};\\\", \\\"{x:1425,y:861,t:1526922795590};\\\", \\\"{x:1466,y:851,t:1526922795605};\\\", \\\"{x:1499,y:841,t:1526922795622};\\\", \\\"{x:1521,y:834,t:1526922795639};\\\", \\\"{x:1534,y:829,t:1526922795655};\\\", \\\"{x:1541,y:824,t:1526922795672};\\\", \\\"{x:1543,y:822,t:1526922795689};\\\", \\\"{x:1544,y:820,t:1526922795705};\\\", \\\"{x:1544,y:819,t:1526922795722};\\\", \\\"{x:1544,y:818,t:1526922795740};\\\", \\\"{x:1544,y:816,t:1526922795756};\\\", \\\"{x:1544,y:815,t:1526922795772};\\\", \\\"{x:1543,y:812,t:1526922795789};\\\", \\\"{x:1541,y:811,t:1526922795806};\\\", \\\"{x:1538,y:809,t:1526922795822};\\\", \\\"{x:1533,y:808,t:1526922795839};\\\", \\\"{x:1529,y:808,t:1526922795855};\\\", \\\"{x:1519,y:808,t:1526922795873};\\\", \\\"{x:1503,y:808,t:1526922795890};\\\", \\\"{x:1481,y:810,t:1526922795905};\\\", \\\"{x:1443,y:811,t:1526922795922};\\\", \\\"{x:1417,y:811,t:1526922795939};\\\", \\\"{x:1398,y:811,t:1526922795955};\\\", \\\"{x:1389,y:811,t:1526922795973};\\\", \\\"{x:1386,y:811,t:1526922795988};\\\", \\\"{x:1385,y:811,t:1526922796005};\\\", \\\"{x:1385,y:810,t:1526922796023};\\\", \\\"{x:1385,y:807,t:1526922796039};\\\", \\\"{x:1385,y:804,t:1526922796055};\\\", \\\"{x:1385,y:801,t:1526922796072};\\\", \\\"{x:1385,y:799,t:1526922796089};\\\", \\\"{x:1388,y:790,t:1526922796106};\\\", \\\"{x:1388,y:781,t:1526922796123};\\\", \\\"{x:1388,y:780,t:1526922796138};\\\", \\\"{x:1388,y:779,t:1526922796162};\\\", \\\"{x:1388,y:778,t:1526922796267};\\\", \\\"{x:1388,y:777,t:1526922796275};\\\", \\\"{x:1388,y:776,t:1526922796315};\\\", \\\"{x:1388,y:775,t:1526922796339};\\\", \\\"{x:1388,y:774,t:1526922796362};\\\", \\\"{x:1388,y:773,t:1526922796386};\\\", \\\"{x:1388,y:772,t:1526922796402};\\\", \\\"{x:1388,y:771,t:1526922796411};\\\", \\\"{x:1389,y:770,t:1526922796450};\\\", \\\"{x:1390,y:768,t:1526922796491};\\\", \\\"{x:1391,y:769,t:1526922796578};\\\", \\\"{x:1391,y:775,t:1526922796589};\\\", \\\"{x:1391,y:798,t:1526922796606};\\\", \\\"{x:1387,y:830,t:1526922796623};\\\", \\\"{x:1382,y:866,t:1526922796639};\\\", \\\"{x:1377,y:896,t:1526922796656};\\\", \\\"{x:1374,y:918,t:1526922796674};\\\", \\\"{x:1371,y:931,t:1526922796689};\\\", \\\"{x:1371,y:936,t:1526922796705};\\\", \\\"{x:1371,y:939,t:1526922796722};\\\", \\\"{x:1371,y:940,t:1526922796787};\\\", \\\"{x:1372,y:939,t:1526922796802};\\\", \\\"{x:1372,y:937,t:1526922796811};\\\", \\\"{x:1375,y:933,t:1526922796822};\\\", \\\"{x:1380,y:922,t:1526922796838};\\\", \\\"{x:1386,y:901,t:1526922796855};\\\", \\\"{x:1392,y:879,t:1526922796872};\\\", \\\"{x:1399,y:856,t:1526922796887};\\\", \\\"{x:1402,y:842,t:1526922796905};\\\", \\\"{x:1403,y:828,t:1526922796921};\\\", \\\"{x:1405,y:820,t:1526922796938};\\\", \\\"{x:1406,y:813,t:1526922796954};\\\", \\\"{x:1407,y:808,t:1526922796971};\\\", \\\"{x:1407,y:806,t:1526922796988};\\\", \\\"{x:1407,y:805,t:1526922797005};\\\", \\\"{x:1408,y:803,t:1526922797021};\\\", \\\"{x:1408,y:802,t:1526922797038};\\\", \\\"{x:1408,y:800,t:1526922797055};\\\", \\\"{x:1408,y:798,t:1526922797070};\\\", \\\"{x:1409,y:796,t:1526922797087};\\\", \\\"{x:1409,y:795,t:1526922797105};\\\", \\\"{x:1409,y:793,t:1526922797121};\\\", \\\"{x:1409,y:790,t:1526922797137};\\\", \\\"{x:1405,y:787,t:1526922797155};\\\", \\\"{x:1404,y:785,t:1526922797171};\\\", \\\"{x:1403,y:782,t:1526922797188};\\\", \\\"{x:1401,y:780,t:1526922797205};\\\", \\\"{x:1401,y:778,t:1526922797221};\\\", \\\"{x:1399,y:776,t:1526922797238};\\\", \\\"{x:1399,y:775,t:1526922797255};\\\", \\\"{x:1398,y:773,t:1526922797271};\\\", \\\"{x:1396,y:770,t:1526922797288};\\\", \\\"{x:1395,y:768,t:1526922797305};\\\", \\\"{x:1395,y:766,t:1526922797322};\\\", \\\"{x:1395,y:764,t:1526922797337};\\\", \\\"{x:1395,y:763,t:1526922797355};\\\", \\\"{x:1395,y:762,t:1526922797371};\\\", \\\"{x:1395,y:761,t:1526922797388};\\\", \\\"{x:1395,y:760,t:1526922797405};\\\", \\\"{x:1394,y:761,t:1526922797523};\\\", \\\"{x:1385,y:780,t:1526922797537};\\\", \\\"{x:1373,y:811,t:1526922797555};\\\", \\\"{x:1361,y:849,t:1526922797571};\\\", \\\"{x:1353,y:887,t:1526922797588};\\\", \\\"{x:1352,y:910,t:1526922797604};\\\", \\\"{x:1351,y:926,t:1526922797621};\\\", \\\"{x:1351,y:935,t:1526922797638};\\\", \\\"{x:1351,y:941,t:1526922797654};\\\", \\\"{x:1351,y:944,t:1526922797672};\\\", \\\"{x:1352,y:945,t:1526922797689};\\\", \\\"{x:1353,y:945,t:1526922797778};\\\", \\\"{x:1357,y:945,t:1526922797788};\\\", \\\"{x:1365,y:943,t:1526922797804};\\\", \\\"{x:1381,y:936,t:1526922797821};\\\", \\\"{x:1394,y:928,t:1526922797838};\\\", \\\"{x:1404,y:920,t:1526922797854};\\\", \\\"{x:1409,y:912,t:1526922797871};\\\", \\\"{x:1412,y:904,t:1526922797888};\\\", \\\"{x:1415,y:898,t:1526922797904};\\\", \\\"{x:1417,y:888,t:1526922797921};\\\", \\\"{x:1418,y:878,t:1526922797938};\\\", \\\"{x:1418,y:874,t:1526922797955};\\\", \\\"{x:1418,y:868,t:1526922797971};\\\", \\\"{x:1418,y:860,t:1526922797989};\\\", \\\"{x:1418,y:852,t:1526922798004};\\\", \\\"{x:1418,y:845,t:1526922798021};\\\", \\\"{x:1418,y:837,t:1526922798038};\\\", \\\"{x:1417,y:833,t:1526922798054};\\\", \\\"{x:1416,y:831,t:1526922798071};\\\", \\\"{x:1416,y:830,t:1526922798115};\\\", \\\"{x:1415,y:830,t:1526922798323};\\\", \\\"{x:1415,y:826,t:1526922798338};\\\", \\\"{x:1414,y:813,t:1526922798354};\\\", \\\"{x:1414,y:807,t:1526922798371};\\\", \\\"{x:1414,y:796,t:1526922798389};\\\", \\\"{x:1413,y:786,t:1526922798405};\\\", \\\"{x:1411,y:779,t:1526922798422};\\\", \\\"{x:1411,y:775,t:1526922798438};\\\", \\\"{x:1411,y:772,t:1526922798454};\\\", \\\"{x:1411,y:770,t:1526922798471};\\\", \\\"{x:1411,y:769,t:1526922798755};\\\", \\\"{x:1411,y:763,t:1526922798772};\\\", \\\"{x:1411,y:751,t:1526922798787};\\\", \\\"{x:1416,y:734,t:1526922798805};\\\", \\\"{x:1417,y:720,t:1526922798822};\\\", \\\"{x:1421,y:705,t:1526922798838};\\\", \\\"{x:1423,y:690,t:1526922798855};\\\", \\\"{x:1426,y:682,t:1526922798872};\\\", \\\"{x:1426,y:676,t:1526922798887};\\\", \\\"{x:1427,y:670,t:1526922798904};\\\", \\\"{x:1429,y:665,t:1526922798922};\\\", \\\"{x:1429,y:662,t:1526922798937};\\\", \\\"{x:1429,y:660,t:1526922798955};\\\", \\\"{x:1429,y:659,t:1526922798972};\\\", \\\"{x:1430,y:658,t:1526922798988};\\\", \\\"{x:1430,y:657,t:1526922799004};\\\", \\\"{x:1431,y:656,t:1526922799022};\\\", \\\"{x:1431,y:653,t:1526922799038};\\\", \\\"{x:1432,y:649,t:1526922799054};\\\", \\\"{x:1434,y:645,t:1526922799072};\\\", \\\"{x:1434,y:642,t:1526922799087};\\\", \\\"{x:1436,y:638,t:1526922799105};\\\", \\\"{x:1438,y:634,t:1526922799121};\\\", \\\"{x:1439,y:632,t:1526922799138};\\\", \\\"{x:1441,y:629,t:1526922799155};\\\", \\\"{x:1441,y:628,t:1526922799171};\\\", \\\"{x:1443,y:626,t:1526922799188};\\\", \\\"{x:1444,y:626,t:1526922799234};\\\", \\\"{x:1445,y:626,t:1526922799250};\\\", \\\"{x:1446,y:626,t:1526922799258};\\\", \\\"{x:1446,y:627,t:1526922799270};\\\", \\\"{x:1446,y:628,t:1526922799287};\\\", \\\"{x:1446,y:632,t:1526922799304};\\\", \\\"{x:1446,y:635,t:1526922799321};\\\", \\\"{x:1446,y:639,t:1526922799338};\\\", \\\"{x:1442,y:649,t:1526922799355};\\\", \\\"{x:1435,y:663,t:1526922799370};\\\", \\\"{x:1429,y:682,t:1526922799387};\\\", \\\"{x:1419,y:701,t:1526922799404};\\\", \\\"{x:1412,y:722,t:1526922799421};\\\", \\\"{x:1401,y:738,t:1526922799438};\\\", \\\"{x:1396,y:752,t:1526922799455};\\\", \\\"{x:1393,y:764,t:1526922799470};\\\", \\\"{x:1392,y:773,t:1526922799488};\\\", \\\"{x:1392,y:784,t:1526922799504};\\\", \\\"{x:1393,y:793,t:1526922799521};\\\", \\\"{x:1396,y:802,t:1526922799537};\\\", \\\"{x:1404,y:812,t:1526922799553};\\\", \\\"{x:1408,y:817,t:1526922799570};\\\", \\\"{x:1410,y:821,t:1526922799587};\\\", \\\"{x:1411,y:822,t:1526922799603};\\\", \\\"{x:1412,y:823,t:1526922799620};\\\", \\\"{x:1416,y:821,t:1526922799658};\\\", \\\"{x:1423,y:816,t:1526922799669};\\\", \\\"{x:1444,y:800,t:1526922799687};\\\", \\\"{x:1464,y:782,t:1526922799704};\\\", \\\"{x:1478,y:761,t:1526922799720};\\\", \\\"{x:1487,y:740,t:1526922799737};\\\", \\\"{x:1491,y:715,t:1526922799754};\\\", \\\"{x:1487,y:701,t:1526922799770};\\\", \\\"{x:1481,y:691,t:1526922799787};\\\", \\\"{x:1475,y:683,t:1526922799805};\\\", \\\"{x:1466,y:676,t:1526922799820};\\\", \\\"{x:1459,y:671,t:1526922799837};\\\", \\\"{x:1454,y:665,t:1526922799853};\\\", \\\"{x:1451,y:660,t:1526922799871};\\\", \\\"{x:1449,y:657,t:1526922799888};\\\", \\\"{x:1449,y:654,t:1526922799903};\\\", \\\"{x:1449,y:652,t:1526922799921};\\\", \\\"{x:1449,y:648,t:1526922799938};\\\", \\\"{x:1447,y:643,t:1526922799954};\\\", \\\"{x:1447,y:638,t:1526922799970};\\\", \\\"{x:1447,y:634,t:1526922799988};\\\", \\\"{x:1447,y:630,t:1526922800004};\\\", \\\"{x:1447,y:628,t:1526922800020};\\\", \\\"{x:1447,y:624,t:1526922800038};\\\", \\\"{x:1447,y:623,t:1526922800053};\\\", \\\"{x:1447,y:620,t:1526922800071};\\\", \\\"{x:1448,y:618,t:1526922800087};\\\", \\\"{x:1450,y:616,t:1526922800103};\\\", \\\"{x:1451,y:616,t:1526922800163};\\\", \\\"{x:1452,y:616,t:1526922800187};\\\", \\\"{x:1453,y:616,t:1526922800210};\\\", \\\"{x:1454,y:616,t:1526922800235};\\\", \\\"{x:1457,y:616,t:1526922800251};\\\", \\\"{x:1458,y:616,t:1526922800299};\\\", \\\"{x:1459,y:617,t:1526922800307};\\\", \\\"{x:1460,y:617,t:1526922800322};\\\", \\\"{x:1462,y:618,t:1526922800337};\\\", \\\"{x:1466,y:618,t:1526922800353};\\\", \\\"{x:1474,y:618,t:1526922800370};\\\", \\\"{x:1481,y:621,t:1526922800387};\\\", \\\"{x:1490,y:621,t:1526922800403};\\\", \\\"{x:1498,y:621,t:1526922800420};\\\", \\\"{x:1506,y:621,t:1526922800437};\\\", \\\"{x:1509,y:621,t:1526922800453};\\\", \\\"{x:1510,y:621,t:1526922800470};\\\", \\\"{x:1510,y:623,t:1526922800586};\\\", \\\"{x:1505,y:625,t:1526922800604};\\\", \\\"{x:1500,y:625,t:1526922800620};\\\", \\\"{x:1499,y:625,t:1526922800637};\\\", \\\"{x:1499,y:626,t:1526922800653};\\\", \\\"{x:1499,y:627,t:1526922800671};\\\", \\\"{x:1499,y:628,t:1526922800688};\\\", \\\"{x:1503,y:630,t:1526922800704};\\\", \\\"{x:1510,y:631,t:1526922800721};\\\", \\\"{x:1515,y:632,t:1526922800736};\\\", \\\"{x:1517,y:632,t:1526922800754};\\\", \\\"{x:1520,y:632,t:1526922800770};\\\", \\\"{x:1521,y:632,t:1526922800834};\\\", \\\"{x:1523,y:632,t:1526922800866};\\\", \\\"{x:1524,y:631,t:1526922800890};\\\", \\\"{x:1524,y:630,t:1526922800906};\\\", \\\"{x:1524,y:629,t:1526922800922};\\\", \\\"{x:1524,y:627,t:1526922800946};\\\", \\\"{x:1522,y:626,t:1526922800978};\\\", \\\"{x:1521,y:626,t:1526922800994};\\\", \\\"{x:1520,y:626,t:1526922801003};\\\", \\\"{x:1518,y:626,t:1526922801021};\\\", \\\"{x:1514,y:626,t:1526922801036};\\\", \\\"{x:1510,y:628,t:1526922801053};\\\", \\\"{x:1507,y:629,t:1526922801070};\\\", \\\"{x:1505,y:630,t:1526922801086};\\\", \\\"{x:1506,y:630,t:1526922801443};\\\", \\\"{x:1507,y:630,t:1526922801454};\\\", \\\"{x:1509,y:630,t:1526922801469};\\\", \\\"{x:1510,y:630,t:1526922801490};\\\", \\\"{x:1510,y:631,t:1526922801731};\\\", \\\"{x:1511,y:632,t:1526922801738};\\\", \\\"{x:1512,y:632,t:1526922801754};\\\", \\\"{x:1516,y:632,t:1526922801769};\\\", \\\"{x:1520,y:633,t:1526922801787};\\\", \\\"{x:1522,y:633,t:1526922801804};\\\", \\\"{x:1526,y:633,t:1526922801820};\\\", \\\"{x:1529,y:633,t:1526922801837};\\\", \\\"{x:1536,y:633,t:1526922801853};\\\", \\\"{x:1541,y:633,t:1526922801870};\\\", \\\"{x:1544,y:633,t:1526922801887};\\\", \\\"{x:1545,y:633,t:1526922801903};\\\", \\\"{x:1549,y:633,t:1526922801919};\\\", \\\"{x:1551,y:633,t:1526922801937};\\\", \\\"{x:1552,y:633,t:1526922801953};\\\", \\\"{x:1553,y:633,t:1526922801970};\\\", \\\"{x:1554,y:633,t:1526922802035};\\\", \\\"{x:1555,y:633,t:1526922802083};\\\", \\\"{x:1555,y:632,t:1526922802098};\\\", \\\"{x:1556,y:632,t:1526922802115};\\\", \\\"{x:1556,y:631,t:1526922802123};\\\", \\\"{x:1558,y:631,t:1526922802145};\\\", \\\"{x:1560,y:631,t:1526922802161};\\\", \\\"{x:1561,y:629,t:1526922802169};\\\", \\\"{x:1563,y:629,t:1526922802185};\\\", \\\"{x:1566,y:629,t:1526922802203};\\\", \\\"{x:1568,y:629,t:1526922802305};\\\", \\\"{x:1570,y:629,t:1526922802319};\\\", \\\"{x:1575,y:629,t:1526922802336};\\\", \\\"{x:1580,y:629,t:1526922802352};\\\", \\\"{x:1582,y:629,t:1526922802369};\\\", \\\"{x:1584,y:629,t:1526922802386};\\\", \\\"{x:1582,y:629,t:1526922802514};\\\", \\\"{x:1579,y:629,t:1526922802521};\\\", \\\"{x:1577,y:629,t:1526922802536};\\\", \\\"{x:1575,y:629,t:1526922802553};\\\", \\\"{x:1576,y:629,t:1526922802681};\\\", \\\"{x:1577,y:629,t:1526922802702};\\\", \\\"{x:1578,y:629,t:1526922802753};\\\", \\\"{x:1579,y:628,t:1526922802769};\\\", \\\"{x:1580,y:627,t:1526922802785};\\\", \\\"{x:1581,y:627,t:1526922802826};\\\", \\\"{x:1583,y:627,t:1526922802841};\\\", \\\"{x:1584,y:626,t:1526922802857};\\\", \\\"{x:1586,y:626,t:1526922803058};\\\", \\\"{x:1588,y:626,t:1526922803069};\\\", \\\"{x:1595,y:626,t:1526922803085};\\\", \\\"{x:1602,y:626,t:1526922803102};\\\", \\\"{x:1606,y:626,t:1526922803119};\\\", \\\"{x:1610,y:626,t:1526922803136};\\\", \\\"{x:1612,y:625,t:1526922803153};\\\", \\\"{x:1613,y:625,t:1526922803170};\\\", \\\"{x:1615,y:625,t:1526922803186};\\\", \\\"{x:1618,y:625,t:1526922803202};\\\", \\\"{x:1619,y:625,t:1526922803234};\\\", \\\"{x:1620,y:624,t:1526922803251};\\\", \\\"{x:1622,y:623,t:1526922803273};\\\", \\\"{x:1623,y:623,t:1526922803290};\\\", \\\"{x:1625,y:623,t:1526922803321};\\\", \\\"{x:1627,y:623,t:1526922803335};\\\", \\\"{x:1630,y:622,t:1526922803352};\\\", \\\"{x:1633,y:622,t:1526922803369};\\\", \\\"{x:1635,y:622,t:1526922803402};\\\", \\\"{x:1635,y:623,t:1526922803579};\\\", \\\"{x:1636,y:623,t:1526922803586};\\\", \\\"{x:1636,y:624,t:1526922803603};\\\", \\\"{x:1636,y:625,t:1526922803650};\\\", \\\"{x:1636,y:626,t:1526922803682};\\\", \\\"{x:1636,y:627,t:1526922803698};\\\", \\\"{x:1637,y:627,t:1526922803714};\\\", \\\"{x:1638,y:628,t:1526922803731};\\\", \\\"{x:1639,y:629,t:1526922803738};\\\", \\\"{x:1641,y:630,t:1526922803763};\\\", \\\"{x:1642,y:630,t:1526922803835};\\\", \\\"{x:1644,y:630,t:1526922803853};\\\", \\\"{x:1649,y:630,t:1526922803868};\\\", \\\"{x:1655,y:630,t:1526922803886};\\\", \\\"{x:1664,y:627,t:1526922803903};\\\", \\\"{x:1675,y:624,t:1526922803919};\\\", \\\"{x:1679,y:623,t:1526922803936};\\\", \\\"{x:1683,y:621,t:1526922803952};\\\", \\\"{x:1687,y:619,t:1526922803969};\\\", \\\"{x:1689,y:618,t:1526922803986};\\\", \\\"{x:1691,y:617,t:1526922804003};\\\", \\\"{x:1692,y:616,t:1526922804018};\\\", \\\"{x:1693,y:615,t:1526922804036};\\\", \\\"{x:1694,y:615,t:1526922804052};\\\", \\\"{x:1695,y:615,t:1526922804069};\\\", \\\"{x:1696,y:614,t:1526922804107};\\\", \\\"{x:1697,y:614,t:1526922804130};\\\", \\\"{x:1698,y:613,t:1526922804185};\\\", \\\"{x:1699,y:613,t:1526922804234};\\\", \\\"{x:1701,y:613,t:1526922804257};\\\", \\\"{x:1704,y:613,t:1526922804274};\\\", \\\"{x:1705,y:613,t:1526922804286};\\\", \\\"{x:1710,y:614,t:1526922804302};\\\", \\\"{x:1714,y:616,t:1526922804319};\\\", \\\"{x:1717,y:618,t:1526922804335};\\\", \\\"{x:1721,y:619,t:1526922804352};\\\", \\\"{x:1724,y:621,t:1526922804369};\\\", \\\"{x:1727,y:621,t:1526922804385};\\\", \\\"{x:1730,y:623,t:1526922804403};\\\", \\\"{x:1732,y:624,t:1526922804418};\\\", \\\"{x:1733,y:625,t:1526922804579};\\\", \\\"{x:1730,y:632,t:1526922805083};\\\", \\\"{x:1715,y:647,t:1526922805091};\\\", \\\"{x:1696,y:665,t:1526922805101};\\\", \\\"{x:1639,y:710,t:1526922805119};\\\", \\\"{x:1583,y:750,t:1526922805135};\\\", \\\"{x:1530,y:788,t:1526922805151};\\\", \\\"{x:1498,y:813,t:1526922805169};\\\", \\\"{x:1474,y:832,t:1526922805186};\\\", \\\"{x:1465,y:841,t:1526922805201};\\\", \\\"{x:1464,y:843,t:1526922805219};\\\", \\\"{x:1463,y:844,t:1526922805275};\\\", \\\"{x:1463,y:845,t:1526922805322};\\\", \\\"{x:1463,y:846,t:1526922805334};\\\", \\\"{x:1463,y:842,t:1526922805641};\\\", \\\"{x:1463,y:837,t:1526922805651};\\\", \\\"{x:1463,y:824,t:1526922805668};\\\", \\\"{x:1463,y:809,t:1526922805684};\\\", \\\"{x:1463,y:791,t:1526922805701};\\\", \\\"{x:1463,y:771,t:1526922805718};\\\", \\\"{x:1459,y:749,t:1526922805734};\\\", \\\"{x:1453,y:725,t:1526922805751};\\\", \\\"{x:1448,y:709,t:1526922805768};\\\", \\\"{x:1441,y:693,t:1526922805784};\\\", \\\"{x:1436,y:681,t:1526922805802};\\\", \\\"{x:1429,y:671,t:1526922805817};\\\", \\\"{x:1425,y:664,t:1526922805835};\\\", \\\"{x:1422,y:660,t:1526922805851};\\\", \\\"{x:1421,y:658,t:1526922805869};\\\", \\\"{x:1420,y:657,t:1526922805885};\\\", \\\"{x:1418,y:655,t:1526922805902};\\\", \\\"{x:1418,y:653,t:1526922805919};\\\", \\\"{x:1417,y:653,t:1526922805934};\\\", \\\"{x:1417,y:652,t:1526922805951};\\\", \\\"{x:1417,y:651,t:1526922805967};\\\", \\\"{x:1417,y:650,t:1526922805986};\\\", \\\"{x:1417,y:649,t:1526922806035};\\\", \\\"{x:1417,y:648,t:1526922806058};\\\", \\\"{x:1418,y:655,t:1526922806194};\\\", \\\"{x:1421,y:663,t:1526922806202};\\\", \\\"{x:1422,y:673,t:1526922806218};\\\", \\\"{x:1432,y:710,t:1526922806235};\\\", \\\"{x:1439,y:734,t:1526922806252};\\\", \\\"{x:1444,y:755,t:1526922806268};\\\", \\\"{x:1452,y:777,t:1526922806285};\\\", \\\"{x:1460,y:796,t:1526922806302};\\\", \\\"{x:1466,y:811,t:1526922806318};\\\", \\\"{x:1469,y:819,t:1526922806335};\\\", \\\"{x:1473,y:826,t:1526922806352};\\\", \\\"{x:1474,y:831,t:1526922806368};\\\", \\\"{x:1476,y:833,t:1526922806385};\\\", \\\"{x:1477,y:836,t:1526922806402};\\\", \\\"{x:1477,y:838,t:1526922806419};\\\", \\\"{x:1477,y:839,t:1526922806435};\\\", \\\"{x:1478,y:839,t:1526922806635};\\\", \\\"{x:1480,y:834,t:1526922806651};\\\", \\\"{x:1482,y:825,t:1526922806667};\\\", \\\"{x:1485,y:818,t:1526922806685};\\\", \\\"{x:1489,y:812,t:1526922806701};\\\", \\\"{x:1492,y:806,t:1526922806717};\\\", \\\"{x:1495,y:798,t:1526922806734};\\\", \\\"{x:1498,y:793,t:1526922806751};\\\", \\\"{x:1501,y:789,t:1526922806768};\\\", \\\"{x:1502,y:786,t:1526922806786};\\\", \\\"{x:1504,y:784,t:1526922806802};\\\", \\\"{x:1504,y:782,t:1526922806818};\\\", \\\"{x:1504,y:781,t:1526922806834};\\\", \\\"{x:1504,y:780,t:1526922806851};\\\", \\\"{x:1504,y:779,t:1526922806874};\\\", \\\"{x:1504,y:778,t:1526922806946};\\\", \\\"{x:1504,y:777,t:1526922806994};\\\", \\\"{x:1504,y:776,t:1526922807035};\\\", \\\"{x:1504,y:775,t:1526922807451};\\\", \\\"{x:1505,y:773,t:1526922807467};\\\", \\\"{x:1506,y:772,t:1526922807514};\\\", \\\"{x:1506,y:770,t:1526922807555};\\\", \\\"{x:1507,y:770,t:1526922807586};\\\", \\\"{x:1505,y:768,t:1526922809524};\\\", \\\"{x:1494,y:764,t:1526922809531};\\\", \\\"{x:1478,y:760,t:1526922809543};\\\", \\\"{x:1386,y:756,t:1526922809560};\\\", \\\"{x:1234,y:739,t:1526922809577};\\\", \\\"{x:1049,y:712,t:1526922809593};\\\", \\\"{x:842,y:687,t:1526922809610};\\\", \\\"{x:751,y:676,t:1526922809627};\\\", \\\"{x:744,y:680,t:1526922809644};\\\", \\\"{x:743,y:680,t:1526922810157};\\\", \\\"{x:742,y:680,t:1526922810164};\\\", \\\"{x:741,y:680,t:1526922810177};\\\", \\\"{x:739,y:680,t:1526922810193};\\\", \\\"{x:737,y:680,t:1526922810210};\\\", \\\"{x:736,y:681,t:1526922810227};\\\", \\\"{x:735,y:682,t:1526922810252};\\\", \\\"{x:734,y:676,t:1526922812589};\\\", \\\"{x:731,y:661,t:1526922812596};\\\", \\\"{x:721,y:637,t:1526922812609};\\\", \\\"{x:687,y:585,t:1526922812628};\\\", \\\"{x:627,y:499,t:1526922812642};\\\", \\\"{x:566,y:420,t:1526922812659};\\\", \\\"{x:512,y:344,t:1526922812678};\\\", \\\"{x:501,y:311,t:1526922812694};\\\", \\\"{x:499,y:297,t:1526922812712};\\\", \\\"{x:499,y:285,t:1526922812729};\\\", \\\"{x:504,y:277,t:1526922812745};\\\", \\\"{x:506,y:275,t:1526922812762};\\\", \\\"{x:508,y:274,t:1526922812778};\\\", \\\"{x:510,y:274,t:1526922812827};\\\", \\\"{x:513,y:279,t:1526922812835};\\\", \\\"{x:517,y:290,t:1526922812846};\\\", \\\"{x:528,y:317,t:1526922812862};\\\", \\\"{x:536,y:344,t:1526922812878};\\\", \\\"{x:544,y:379,t:1526922812896};\\\", \\\"{x:547,y:405,t:1526922812912};\\\", \\\"{x:547,y:429,t:1526922812929};\\\", \\\"{x:547,y:447,t:1526922812946};\\\", \\\"{x:547,y:461,t:1526922812963};\\\", \\\"{x:547,y:479,t:1526922812981};\\\", \\\"{x:547,y:484,t:1526922812996};\\\", \\\"{x:547,y:487,t:1526922813014};\\\", \\\"{x:547,y:489,t:1526922813030};\\\", \\\"{x:548,y:489,t:1526922813467};\\\", \\\"{x:549,y:489,t:1526922813483};\\\", \\\"{x:552,y:489,t:1526922813495};\\\", \\\"{x:554,y:489,t:1526922813513};\\\", \\\"{x:555,y:489,t:1526922813668};\\\", \\\"{x:556,y:489,t:1526922813679};\\\", \\\"{x:557,y:489,t:1526922813700};\\\", \\\"{x:558,y:489,t:1526922813713};\\\", \\\"{x:559,y:489,t:1526922813729};\\\", \\\"{x:561,y:489,t:1526922813746};\\\", \\\"{x:562,y:489,t:1526922813763};\\\", \\\"{x:563,y:489,t:1526922813779};\\\", \\\"{x:565,y:489,t:1526922813796};\\\", \\\"{x:568,y:489,t:1526922813813};\\\", \\\"{x:572,y:489,t:1526922813830};\\\", \\\"{x:575,y:489,t:1526922813846};\\\", \\\"{x:578,y:489,t:1526922813863};\\\", \\\"{x:579,y:489,t:1526922813880};\\\", \\\"{x:580,y:489,t:1526922813896};\\\", \\\"{x:581,y:489,t:1526922813913};\\\", \\\"{x:584,y:489,t:1526922813930};\\\", \\\"{x:585,y:489,t:1526922813972};\\\", \\\"{x:586,y:489,t:1526922813988};\\\", \\\"{x:587,y:489,t:1526922814044};\\\", \\\"{x:588,y:490,t:1526922814813};\\\", \\\"{x:583,y:493,t:1526922814820};\\\", \\\"{x:579,y:496,t:1526922814830};\\\", \\\"{x:562,y:505,t:1526922814847};\\\", \\\"{x:542,y:512,t:1526922814864};\\\", \\\"{x:530,y:515,t:1526922814880};\\\", \\\"{x:512,y:515,t:1526922814897};\\\", \\\"{x:495,y:515,t:1526922814916};\\\", \\\"{x:477,y:514,t:1526922814930};\\\", \\\"{x:458,y:509,t:1526922814947};\\\", \\\"{x:436,y:504,t:1526922814963};\\\", \\\"{x:428,y:503,t:1526922814979};\\\", \\\"{x:421,y:503,t:1526922814997};\\\", \\\"{x:418,y:503,t:1526922815013};\\\", \\\"{x:416,y:503,t:1526922815205};\\\", \\\"{x:416,y:504,t:1526922815220};\\\", \\\"{x:416,y:509,t:1526922815231};\\\", \\\"{x:416,y:515,t:1526922815247};\\\", \\\"{x:417,y:521,t:1526922815265};\\\", \\\"{x:418,y:532,t:1526922815280};\\\", \\\"{x:421,y:548,t:1526922815297};\\\", \\\"{x:421,y:559,t:1526922815314};\\\", \\\"{x:421,y:570,t:1526922815331};\\\", \\\"{x:420,y:576,t:1526922815347};\\\", \\\"{x:415,y:583,t:1526922815363};\\\", \\\"{x:412,y:586,t:1526922815380};\\\", \\\"{x:410,y:588,t:1526922815396};\\\", \\\"{x:409,y:588,t:1526922815413};\\\", \\\"{x:407,y:588,t:1526922815431};\\\", \\\"{x:406,y:588,t:1526922815451};\\\", \\\"{x:403,y:588,t:1526922815464};\\\", \\\"{x:393,y:582,t:1526922815480};\\\", \\\"{x:382,y:573,t:1526922815497};\\\", \\\"{x:372,y:564,t:1526922815515};\\\", \\\"{x:369,y:559,t:1526922815531};\\\", \\\"{x:368,y:558,t:1526922815548};\\\", \\\"{x:368,y:556,t:1526922815564};\\\", \\\"{x:368,y:555,t:1526922815588};\\\", \\\"{x:368,y:551,t:1526922815836};\\\", \\\"{x:368,y:549,t:1526922815847};\\\", \\\"{x:370,y:547,t:1526922815865};\\\", \\\"{x:370,y:545,t:1526922815881};\\\", \\\"{x:372,y:541,t:1526922815897};\\\", \\\"{x:373,y:539,t:1526922815915};\\\", \\\"{x:375,y:535,t:1526922815930};\\\", \\\"{x:376,y:534,t:1526922815948};\\\", \\\"{x:376,y:533,t:1526922815965};\\\", \\\"{x:376,y:535,t:1526922816115};\\\", \\\"{x:376,y:538,t:1526922816132};\\\", \\\"{x:377,y:542,t:1526922816147};\\\", \\\"{x:377,y:543,t:1526922816165};\\\", \\\"{x:378,y:543,t:1526922816371};\\\", \\\"{x:380,y:543,t:1526922816380};\\\", \\\"{x:383,y:540,t:1526922816398};\\\", \\\"{x:383,y:538,t:1526922816415};\\\", \\\"{x:385,y:534,t:1526922816431};\\\", \\\"{x:387,y:529,t:1526922816448};\\\", \\\"{x:388,y:528,t:1526922816465};\\\", \\\"{x:388,y:526,t:1526922816482};\\\", \\\"{x:388,y:524,t:1526922816499};\\\", \\\"{x:388,y:523,t:1526922816515};\\\", \\\"{x:388,y:520,t:1526922816531};\\\", \\\"{x:388,y:519,t:1526922816547};\\\", \\\"{x:388,y:517,t:1526922816565};\\\", \\\"{x:388,y:515,t:1526922816582};\\\", \\\"{x:388,y:514,t:1526922816612};\\\", \\\"{x:388,y:512,t:1526922816620};\\\", \\\"{x:388,y:511,t:1526922816632};\\\", \\\"{x:391,y:510,t:1526922816851};\\\", \\\"{x:398,y:510,t:1526922816864};\\\", \\\"{x:411,y:512,t:1526922816882};\\\", \\\"{x:421,y:513,t:1526922816898};\\\", \\\"{x:433,y:513,t:1526922816914};\\\", \\\"{x:458,y:513,t:1526922816931};\\\", \\\"{x:475,y:513,t:1526922816949};\\\", \\\"{x:494,y:513,t:1526922816965};\\\", \\\"{x:514,y:513,t:1526922816983};\\\", \\\"{x:539,y:513,t:1526922816998};\\\", \\\"{x:558,y:512,t:1526922817015};\\\", \\\"{x:572,y:511,t:1526922817032};\\\", \\\"{x:576,y:511,t:1526922817049};\\\", \\\"{x:577,y:511,t:1526922817065};\\\", \\\"{x:578,y:509,t:1526922817228};\\\", \\\"{x:580,y:507,t:1526922817236};\\\", \\\"{x:583,y:505,t:1526922817249};\\\", \\\"{x:589,y:500,t:1526922817265};\\\", \\\"{x:593,y:497,t:1526922817282};\\\", \\\"{x:597,y:494,t:1526922817299};\\\", \\\"{x:599,y:492,t:1526922817315};\\\", \\\"{x:600,y:492,t:1526922817332};\\\", \\\"{x:600,y:495,t:1526922817485};\\\", \\\"{x:601,y:497,t:1526922817499};\\\", \\\"{x:602,y:504,t:1526922817516};\\\", \\\"{x:603,y:505,t:1526922817533};\\\", \\\"{x:605,y:504,t:1526922817621};\\\", \\\"{x:605,y:503,t:1526922817634};\\\", \\\"{x:607,y:500,t:1526922817650};\\\", \\\"{x:608,y:498,t:1526922817667};\\\", \\\"{x:609,y:498,t:1526922817683};\\\", \\\"{x:610,y:498,t:1526922817900};\\\", \\\"{x:628,y:504,t:1526922817915};\\\", \\\"{x:660,y:514,t:1526922817933};\\\", \\\"{x:702,y:520,t:1526922817950};\\\", \\\"{x:756,y:527,t:1526922817966};\\\", \\\"{x:809,y:527,t:1526922817983};\\\", \\\"{x:842,y:527,t:1526922818000};\\\", \\\"{x:862,y:527,t:1526922818016};\\\", \\\"{x:868,y:527,t:1526922818033};\\\", \\\"{x:869,y:527,t:1526922818050};\\\", \\\"{x:870,y:527,t:1526922818066};\\\", \\\"{x:872,y:524,t:1526922818083};\\\", \\\"{x:875,y:522,t:1526922818099};\\\", \\\"{x:876,y:521,t:1526922818116};\\\", \\\"{x:875,y:521,t:1526922818219};\\\", \\\"{x:874,y:521,t:1526922818232};\\\", \\\"{x:872,y:521,t:1526922818250};\\\", \\\"{x:871,y:521,t:1526922818266};\\\", \\\"{x:870,y:521,t:1526922818283};\\\", \\\"{x:866,y:519,t:1526922818300};\\\", \\\"{x:863,y:518,t:1526922818316};\\\", \\\"{x:858,y:515,t:1526922818334};\\\", \\\"{x:854,y:512,t:1526922818350};\\\", \\\"{x:841,y:498,t:1526922818366};\\\", \\\"{x:831,y:483,t:1526922818383};\\\", \\\"{x:828,y:480,t:1526922818399};\\\", \\\"{x:826,y:478,t:1526922818416};\\\", \\\"{x:827,y:479,t:1526922818581};\\\", \\\"{x:828,y:484,t:1526922818588};\\\", \\\"{x:831,y:489,t:1526922818600};\\\", \\\"{x:836,y:498,t:1526922818617};\\\", \\\"{x:840,y:505,t:1526922818633};\\\", \\\"{x:841,y:508,t:1526922818650};\\\", \\\"{x:840,y:511,t:1526922818883};\\\", \\\"{x:829,y:526,t:1526922818900};\\\", \\\"{x:808,y:554,t:1526922818917};\\\", \\\"{x:752,y:625,t:1526922818933};\\\", \\\"{x:681,y:713,t:1526922818950};\\\", \\\"{x:599,y:801,t:1526922818967};\\\", \\\"{x:519,y:874,t:1526922818984};\\\", \\\"{x:465,y:912,t:1526922819000};\\\", \\\"{x:455,y:917,t:1526922819017};\\\", \\\"{x:454,y:917,t:1526922819052};\\\", \\\"{x:454,y:912,t:1526922819067};\\\", \\\"{x:459,y:874,t:1526922819083};\\\", \\\"{x:464,y:842,t:1526922819099};\\\", \\\"{x:471,y:796,t:1526922819117};\\\", \\\"{x:481,y:765,t:1526922819134};\\\", \\\"{x:488,y:745,t:1526922819151};\\\", \\\"{x:491,y:732,t:1526922819167};\\\", \\\"{x:494,y:723,t:1526922819183};\\\", \\\"{x:495,y:716,t:1526922819200};\\\", \\\"{x:497,y:711,t:1526922819216};\\\", \\\"{x:498,y:705,t:1526922819234};\\\", \\\"{x:499,y:701,t:1526922819250};\\\", \\\"{x:502,y:696,t:1526922819267};\\\", \\\"{x:502,y:690,t:1526922819284};\\\", \\\"{x:502,y:689,t:1526922819300};\\\", \\\"{x:503,y:688,t:1526922819323};\\\", \\\"{x:504,y:688,t:1526922819340};\\\", \\\"{x:505,y:691,t:1526922819350};\\\", \\\"{x:507,y:706,t:1526922819367};\\\", \\\"{x:509,y:727,t:1526922819385};\\\", \\\"{x:509,y:742,t:1526922819400};\\\", \\\"{x:509,y:749,t:1526922819417};\\\", \\\"{x:509,y:751,t:1526922819434};\\\", \\\"{x:509,y:752,t:1526922819584};\\\", \\\"{x:509,y:752,t:1526922819658};\\\" ] }, { \\\"rt\\\": 44877, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 477627, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"P\\\", \\\"L\\\", \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-M -01 PM-01 PM-D -P -P -H -H \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:753,t:1526922823964};\\\", \\\"{x:505,y:754,t:1526922823972};\\\", \\\"{x:493,y:754,t:1526922823987};\\\", \\\"{x:452,y:764,t:1526922824005};\\\", \\\"{x:427,y:771,t:1526922824021};\\\", \\\"{x:408,y:776,t:1526922824037};\\\", \\\"{x:396,y:779,t:1526922824054};\\\", \\\"{x:395,y:779,t:1526922824071};\\\", \\\"{x:394,y:779,t:1526922824087};\\\", \\\"{x:392,y:779,t:1526922824203};\\\", \\\"{x:395,y:755,t:1526922824221};\\\", \\\"{x:377,y:670,t:1526922824238};\\\", \\\"{x:315,y:574,t:1526922824255};\\\", \\\"{x:257,y:470,t:1526922824271};\\\", \\\"{x:215,y:373,t:1526922824288};\\\", \\\"{x:179,y:283,t:1526922824304};\\\", \\\"{x:159,y:201,t:1526922824321};\\\", \\\"{x:141,y:132,t:1526922824338};\\\", \\\"{x:127,y:69,t:1526922824354};\\\", \\\"{x:114,y:4,t:1526922824371};\\\", \\\"{x:108,y:0,t:1526922824387};\\\", \\\"{x:102,y:0,t:1526922824404};\\\", \\\"{x:97,y:0,t:1526922824421};\\\", \\\"{x:88,y:0,t:1526922824438};\\\", \\\"{x:80,y:0,t:1526922824454};\\\", \\\"{x:72,y:0,t:1526922824471};\\\", \\\"{x:64,y:0,t:1526922824488};\\\", \\\"{x:55,y:0,t:1526922824504};\\\", \\\"{x:46,y:0,t:1526922824522};\\\", \\\"{x:36,y:0,t:1526922824538};\\\", \\\"{x:25,y:0,t:1526922824554};\\\", \\\"{x:17,y:0,t:1526922824571};\\\", \\\"{x:8,y:0,t:1526922824588};\\\", \\\"{x:8,y:2,t:1526922824781};\\\", \\\"{x:8,y:3,t:1526922824796};\\\", \\\"{x:8,y:4,t:1526922824806};\\\", \\\"{x:8,y:6,t:1526922824821};\\\", \\\"{x:8,y:8,t:1526922824839};\\\", \\\"{x:8,y:12,t:1526922824856};\\\", \\\"{x:8,y:18,t:1526922824872};\\\", \\\"{x:8,y:25,t:1526922824888};\\\", \\\"{x:8,y:27,t:1526922824905};\\\", \\\"{x:8,y:29,t:1526922824922};\\\", \\\"{x:8,y:31,t:1526922825180};\\\", \\\"{x:8,y:34,t:1526922825188};\\\", \\\"{x:8,y:43,t:1526922825205};\\\", \\\"{x:8,y:48,t:1526922825222};\\\", \\\"{x:8,y:50,t:1526922825238};\\\", \\\"{x:8,y:52,t:1526922825255};\\\", \\\"{x:8,y:53,t:1526922825316};\\\", \\\"{x:8,y:55,t:1526922828972};\\\", \\\"{x:11,y:65,t:1526922828980};\\\", \\\"{x:15,y:75,t:1526922828992};\\\", \\\"{x:52,y:94,t:1526922829009};\\\", \\\"{x:146,y:104,t:1526922829026};\\\", \\\"{x:366,y:131,t:1526922829042};\\\", \\\"{x:610,y:136,t:1526922829059};\\\", \\\"{x:997,y:146,t:1526922829076};\\\", \\\"{x:1243,y:150,t:1526922829092};\\\", \\\"{x:1437,y:159,t:1526922829108};\\\", \\\"{x:1578,y:178,t:1526922829126};\\\", \\\"{x:1643,y:188,t:1526922829142};\\\", \\\"{x:1654,y:192,t:1526922829159};\\\", \\\"{x:1652,y:195,t:1526922829187};\\\", \\\"{x:1646,y:198,t:1526922829195};\\\", \\\"{x:1637,y:203,t:1526922829209};\\\", \\\"{x:1614,y:215,t:1526922829225};\\\", \\\"{x:1587,y:230,t:1526922829241};\\\", \\\"{x:1565,y:240,t:1526922829259};\\\", \\\"{x:1545,y:253,t:1526922829275};\\\", \\\"{x:1539,y:258,t:1526922829291};\\\", \\\"{x:1535,y:267,t:1526922829308};\\\", \\\"{x:1534,y:275,t:1526922829325};\\\", \\\"{x:1535,y:285,t:1526922829341};\\\", \\\"{x:1548,y:301,t:1526922829359};\\\", \\\"{x:1570,y:326,t:1526922829375};\\\", \\\"{x:1603,y:360,t:1526922829392};\\\", \\\"{x:1623,y:373,t:1526922829408};\\\", \\\"{x:1652,y:391,t:1526922829425};\\\", \\\"{x:1669,y:405,t:1526922829442};\\\", \\\"{x:1673,y:412,t:1526922829458};\\\", \\\"{x:1678,y:418,t:1526922829475};\\\", \\\"{x:1680,y:424,t:1526922829491};\\\", \\\"{x:1681,y:442,t:1526922829509};\\\", \\\"{x:1681,y:481,t:1526922829526};\\\", \\\"{x:1671,y:565,t:1526922829543};\\\", \\\"{x:1656,y:649,t:1526922829558};\\\", \\\"{x:1638,y:723,t:1526922829576};\\\", \\\"{x:1623,y:804,t:1526922829593};\\\", \\\"{x:1612,y:867,t:1526922829609};\\\", \\\"{x:1595,y:923,t:1526922829625};\\\", \\\"{x:1582,y:965,t:1526922829643};\\\", \\\"{x:1570,y:991,t:1526922829659};\\\", \\\"{x:1563,y:1005,t:1526922829676};\\\", \\\"{x:1562,y:1006,t:1526922829692};\\\", \\\"{x:1558,y:1005,t:1526922829748};\\\", \\\"{x:1555,y:1002,t:1526922829759};\\\", \\\"{x:1544,y:990,t:1526922829776};\\\", \\\"{x:1534,y:977,t:1526922829793};\\\", \\\"{x:1525,y:962,t:1526922829810};\\\", \\\"{x:1519,y:947,t:1526922829825};\\\", \\\"{x:1514,y:940,t:1526922829843};\\\", \\\"{x:1509,y:930,t:1526922829860};\\\", \\\"{x:1505,y:925,t:1526922829876};\\\", \\\"{x:1500,y:920,t:1526922829893};\\\", \\\"{x:1491,y:916,t:1526922829910};\\\", \\\"{x:1465,y:916,t:1526922829926};\\\", \\\"{x:1442,y:916,t:1526922829943};\\\", \\\"{x:1427,y:916,t:1526922829960};\\\", \\\"{x:1418,y:916,t:1526922829976};\\\", \\\"{x:1411,y:916,t:1526922829993};\\\", \\\"{x:1408,y:916,t:1526922830010};\\\", \\\"{x:1407,y:916,t:1526922830026};\\\", \\\"{x:1406,y:917,t:1526922830044};\\\", \\\"{x:1406,y:920,t:1526922830060};\\\", \\\"{x:1406,y:923,t:1526922830076};\\\", \\\"{x:1406,y:925,t:1526922830093};\\\", \\\"{x:1405,y:926,t:1526922830164};\\\", \\\"{x:1404,y:926,t:1526922830176};\\\", \\\"{x:1395,y:924,t:1526922830193};\\\", \\\"{x:1387,y:921,t:1526922830210};\\\", \\\"{x:1384,y:919,t:1526922830226};\\\", \\\"{x:1383,y:919,t:1526922830243};\\\", \\\"{x:1383,y:917,t:1526922830260};\\\", \\\"{x:1383,y:915,t:1526922830276};\\\", \\\"{x:1383,y:914,t:1526922830293};\\\", \\\"{x:1383,y:912,t:1526922830310};\\\", \\\"{x:1382,y:911,t:1526922830327};\\\", \\\"{x:1382,y:909,t:1526922830343};\\\", \\\"{x:1382,y:908,t:1526922830359};\\\", \\\"{x:1382,y:906,t:1526922830377};\\\", \\\"{x:1382,y:905,t:1526922830393};\\\", \\\"{x:1382,y:902,t:1526922830412};\\\", \\\"{x:1383,y:900,t:1526922830426};\\\", \\\"{x:1384,y:898,t:1526922830442};\\\", \\\"{x:1387,y:895,t:1526922830460};\\\", \\\"{x:1387,y:892,t:1526922830477};\\\", \\\"{x:1388,y:891,t:1526922830499};\\\", \\\"{x:1388,y:890,t:1526922830523};\\\", \\\"{x:1388,y:889,t:1526922830531};\\\", \\\"{x:1389,y:889,t:1526922830542};\\\", \\\"{x:1389,y:888,t:1526922830559};\\\", \\\"{x:1389,y:887,t:1526922830577};\\\", \\\"{x:1390,y:886,t:1526922830593};\\\", \\\"{x:1393,y:885,t:1526922830610};\\\", \\\"{x:1400,y:884,t:1526922830627};\\\", \\\"{x:1405,y:884,t:1526922830643};\\\", \\\"{x:1427,y:884,t:1526922830660};\\\", \\\"{x:1438,y:884,t:1526922830677};\\\", \\\"{x:1447,y:884,t:1526922830692};\\\", \\\"{x:1451,y:884,t:1526922830710};\\\", \\\"{x:1453,y:884,t:1526922830727};\\\", \\\"{x:1458,y:886,t:1526922830743};\\\", \\\"{x:1460,y:887,t:1526922830759};\\\", \\\"{x:1461,y:888,t:1526922830777};\\\", \\\"{x:1461,y:889,t:1526922830852};\\\", \\\"{x:1461,y:890,t:1526922830907};\\\", \\\"{x:1460,y:894,t:1526922830923};\\\", \\\"{x:1460,y:896,t:1526922830939};\\\", \\\"{x:1459,y:897,t:1526922830948};\\\", \\\"{x:1458,y:898,t:1526922830959};\\\", \\\"{x:1455,y:901,t:1526922830977};\\\", \\\"{x:1453,y:903,t:1526922830993};\\\", \\\"{x:1452,y:905,t:1526922831009};\\\", \\\"{x:1450,y:907,t:1526922831027};\\\", \\\"{x:1447,y:908,t:1526922831043};\\\", \\\"{x:1446,y:909,t:1526922831059};\\\", \\\"{x:1445,y:909,t:1526922831077};\\\", \\\"{x:1444,y:909,t:1526922831196};\\\", \\\"{x:1444,y:907,t:1526922831212};\\\", \\\"{x:1444,y:906,t:1526922831227};\\\", \\\"{x:1444,y:903,t:1526922831244};\\\", \\\"{x:1444,y:902,t:1526922831324};\\\", \\\"{x:1444,y:901,t:1526922831348};\\\", \\\"{x:1445,y:901,t:1526922831364};\\\", \\\"{x:1447,y:900,t:1526922831377};\\\", \\\"{x:1450,y:900,t:1526922831394};\\\", \\\"{x:1454,y:899,t:1526922831412};\\\", \\\"{x:1459,y:897,t:1526922831427};\\\", \\\"{x:1466,y:896,t:1526922831445};\\\", \\\"{x:1476,y:895,t:1526922831461};\\\", \\\"{x:1485,y:893,t:1526922831477};\\\", \\\"{x:1491,y:892,t:1526922831493};\\\", \\\"{x:1492,y:892,t:1526922831511};\\\", \\\"{x:1494,y:892,t:1526922831707};\\\", \\\"{x:1495,y:892,t:1526922831723};\\\", \\\"{x:1496,y:892,t:1526922831730};\\\", \\\"{x:1497,y:892,t:1526922831743};\\\", \\\"{x:1500,y:893,t:1526922831760};\\\", \\\"{x:1502,y:893,t:1526922831777};\\\", \\\"{x:1504,y:893,t:1526922831793};\\\", \\\"{x:1504,y:894,t:1526922831868};\\\", \\\"{x:1504,y:895,t:1526922831907};\\\", \\\"{x:1504,y:896,t:1526922831932};\\\", \\\"{x:1505,y:895,t:1526922832237};\\\", \\\"{x:1507,y:895,t:1526922832261};\\\", \\\"{x:1508,y:895,t:1526922832278};\\\", \\\"{x:1509,y:894,t:1526922832300};\\\", \\\"{x:1510,y:894,t:1526922832311};\\\", \\\"{x:1507,y:894,t:1526922832924};\\\", \\\"{x:1504,y:894,t:1526922832931};\\\", \\\"{x:1503,y:894,t:1526922832948};\\\", \\\"{x:1502,y:895,t:1526922832962};\\\", \\\"{x:1501,y:895,t:1526922832979};\\\", \\\"{x:1500,y:896,t:1526922832997};\\\", \\\"{x:1499,y:896,t:1526922833020};\\\", \\\"{x:1498,y:896,t:1526922833028};\\\", \\\"{x:1494,y:897,t:1526922833045};\\\", \\\"{x:1491,y:899,t:1526922833062};\\\", \\\"{x:1488,y:900,t:1526922833079};\\\", \\\"{x:1487,y:901,t:1526922833095};\\\", \\\"{x:1483,y:902,t:1526922833112};\\\", \\\"{x:1481,y:904,t:1526922833128};\\\", \\\"{x:1475,y:908,t:1526922833145};\\\", \\\"{x:1466,y:915,t:1526922833162};\\\", \\\"{x:1457,y:920,t:1526922833179};\\\", \\\"{x:1448,y:925,t:1526922833194};\\\", \\\"{x:1438,y:935,t:1526922833212};\\\", \\\"{x:1432,y:948,t:1526922833228};\\\", \\\"{x:1428,y:960,t:1526922833245};\\\", \\\"{x:1419,y:976,t:1526922833262};\\\", \\\"{x:1412,y:991,t:1526922833279};\\\", \\\"{x:1403,y:1005,t:1526922833295};\\\", \\\"{x:1401,y:1011,t:1526922833312};\\\", \\\"{x:1399,y:1017,t:1526922833329};\\\", \\\"{x:1399,y:1019,t:1526922833345};\\\", \\\"{x:1399,y:1020,t:1526922833362};\\\", \\\"{x:1400,y:1020,t:1526922833458};\\\", \\\"{x:1403,y:1016,t:1526922833467};\\\", \\\"{x:1405,y:1010,t:1526922833478};\\\", \\\"{x:1409,y:997,t:1526922833495};\\\", \\\"{x:1413,y:984,t:1526922833511};\\\", \\\"{x:1415,y:973,t:1526922833528};\\\", \\\"{x:1417,y:968,t:1526922833546};\\\", \\\"{x:1418,y:961,t:1526922833561};\\\", \\\"{x:1418,y:956,t:1526922833579};\\\", \\\"{x:1419,y:949,t:1526922833595};\\\", \\\"{x:1419,y:947,t:1526922833611};\\\", \\\"{x:1419,y:946,t:1526922833628};\\\", \\\"{x:1419,y:944,t:1526922833646};\\\", \\\"{x:1419,y:943,t:1526922833667};\\\", \\\"{x:1419,y:941,t:1526922833684};\\\", \\\"{x:1419,y:939,t:1526922833696};\\\", \\\"{x:1420,y:937,t:1526922833711};\\\", \\\"{x:1421,y:932,t:1526922833729};\\\", \\\"{x:1422,y:929,t:1526922833746};\\\", \\\"{x:1424,y:922,t:1526922833762};\\\", \\\"{x:1427,y:916,t:1526922833779};\\\", \\\"{x:1431,y:906,t:1526922833795};\\\", \\\"{x:1434,y:902,t:1526922833813};\\\", \\\"{x:1435,y:898,t:1526922833828};\\\", \\\"{x:1436,y:897,t:1526922833852};\\\", \\\"{x:1436,y:896,t:1526922833884};\\\", \\\"{x:1436,y:895,t:1526922833908};\\\", \\\"{x:1436,y:894,t:1526922833916};\\\", \\\"{x:1434,y:893,t:1526922833929};\\\", \\\"{x:1430,y:893,t:1526922833946};\\\", \\\"{x:1427,y:893,t:1526922833963};\\\", \\\"{x:1424,y:893,t:1526922833979};\\\", \\\"{x:1415,y:896,t:1526922833996};\\\", \\\"{x:1412,y:897,t:1526922834014};\\\", \\\"{x:1408,y:900,t:1526922834029};\\\", \\\"{x:1402,y:904,t:1526922834046};\\\", \\\"{x:1398,y:908,t:1526922834063};\\\", \\\"{x:1392,y:912,t:1526922834079};\\\", \\\"{x:1388,y:916,t:1526922834096};\\\", \\\"{x:1385,y:919,t:1526922834113};\\\", \\\"{x:1381,y:924,t:1526922834129};\\\", \\\"{x:1378,y:930,t:1526922834146};\\\", \\\"{x:1376,y:934,t:1526922834163};\\\", \\\"{x:1375,y:938,t:1526922834179};\\\", \\\"{x:1372,y:945,t:1526922834196};\\\", \\\"{x:1371,y:949,t:1526922834212};\\\", \\\"{x:1371,y:951,t:1526922834229};\\\", \\\"{x:1370,y:953,t:1526922834246};\\\", \\\"{x:1370,y:955,t:1526922834263};\\\", \\\"{x:1370,y:956,t:1526922834308};\\\", \\\"{x:1370,y:958,t:1526922834332};\\\", \\\"{x:1371,y:958,t:1526922834468};\\\", \\\"{x:1373,y:957,t:1526922834480};\\\", \\\"{x:1381,y:949,t:1526922834496};\\\", \\\"{x:1388,y:943,t:1526922834513};\\\", \\\"{x:1395,y:937,t:1526922834530};\\\", \\\"{x:1405,y:930,t:1526922834546};\\\", \\\"{x:1413,y:924,t:1526922834562};\\\", \\\"{x:1424,y:919,t:1526922834580};\\\", \\\"{x:1429,y:916,t:1526922834597};\\\", \\\"{x:1434,y:914,t:1526922834613};\\\", \\\"{x:1437,y:912,t:1526922834630};\\\", \\\"{x:1441,y:911,t:1526922834646};\\\", \\\"{x:1446,y:909,t:1526922834663};\\\", \\\"{x:1450,y:909,t:1526922834680};\\\", \\\"{x:1454,y:906,t:1526922834697};\\\", \\\"{x:1458,y:906,t:1526922834712};\\\", \\\"{x:1463,y:905,t:1526922834730};\\\", \\\"{x:1466,y:903,t:1526922834747};\\\", \\\"{x:1470,y:902,t:1526922834762};\\\", \\\"{x:1475,y:901,t:1526922834779};\\\", \\\"{x:1478,y:899,t:1526922834796};\\\", \\\"{x:1481,y:898,t:1526922834820};\\\", \\\"{x:1483,y:898,t:1526922834835};\\\", \\\"{x:1485,y:896,t:1526922834851};\\\", \\\"{x:1486,y:896,t:1526922834868};\\\", \\\"{x:1487,y:895,t:1526922834880};\\\", \\\"{x:1488,y:894,t:1526922834897};\\\", \\\"{x:1489,y:893,t:1526922834913};\\\", \\\"{x:1489,y:892,t:1526922834930};\\\", \\\"{x:1490,y:892,t:1526922834947};\\\", \\\"{x:1492,y:890,t:1526922835004};\\\", \\\"{x:1493,y:890,t:1526922835020};\\\", \\\"{x:1494,y:890,t:1526922835030};\\\", \\\"{x:1497,y:888,t:1526922835047};\\\", \\\"{x:1502,y:886,t:1526922835064};\\\", \\\"{x:1503,y:886,t:1526922835080};\\\", \\\"{x:1505,y:886,t:1526922835097};\\\", \\\"{x:1507,y:886,t:1526922835114};\\\", \\\"{x:1509,y:886,t:1526922835131};\\\", \\\"{x:1510,y:886,t:1526922835148};\\\", \\\"{x:1510,y:887,t:1526922835220};\\\", \\\"{x:1510,y:889,t:1526922835230};\\\", \\\"{x:1507,y:891,t:1526922835247};\\\", \\\"{x:1498,y:896,t:1526922835265};\\\", \\\"{x:1487,y:901,t:1526922835280};\\\", \\\"{x:1473,y:905,t:1526922835297};\\\", \\\"{x:1449,y:908,t:1526922835314};\\\", \\\"{x:1426,y:908,t:1526922835330};\\\", \\\"{x:1406,y:909,t:1526922835347};\\\", \\\"{x:1387,y:911,t:1526922835364};\\\", \\\"{x:1383,y:913,t:1526922835380};\\\", \\\"{x:1380,y:913,t:1526922835397};\\\", \\\"{x:1379,y:913,t:1526922835453};\\\", \\\"{x:1379,y:912,t:1526922835492};\\\", \\\"{x:1381,y:909,t:1526922835500};\\\", \\\"{x:1385,y:908,t:1526922835514};\\\", \\\"{x:1390,y:905,t:1526922835530};\\\", \\\"{x:1395,y:904,t:1526922835548};\\\", \\\"{x:1402,y:900,t:1526922835563};\\\", \\\"{x:1405,y:898,t:1526922835581};\\\", \\\"{x:1408,y:897,t:1526922835597};\\\", \\\"{x:1414,y:895,t:1526922835615};\\\", \\\"{x:1418,y:893,t:1526922835631};\\\", \\\"{x:1427,y:889,t:1526922835647};\\\", \\\"{x:1434,y:885,t:1526922835664};\\\", \\\"{x:1438,y:882,t:1526922835681};\\\", \\\"{x:1440,y:880,t:1526922835697};\\\", \\\"{x:1444,y:877,t:1526922835714};\\\", \\\"{x:1447,y:875,t:1526922835731};\\\", \\\"{x:1447,y:874,t:1526922835747};\\\", \\\"{x:1448,y:874,t:1526922835764};\\\", \\\"{x:1448,y:875,t:1526922835893};\\\", \\\"{x:1448,y:878,t:1526922835900};\\\", \\\"{x:1448,y:879,t:1526922835913};\\\", \\\"{x:1446,y:884,t:1526922835930};\\\", \\\"{x:1446,y:889,t:1526922835948};\\\", \\\"{x:1447,y:891,t:1526922835963};\\\", \\\"{x:1447,y:892,t:1526922836011};\\\", \\\"{x:1449,y:893,t:1526922836020};\\\", \\\"{x:1452,y:893,t:1526922836030};\\\", \\\"{x:1462,y:893,t:1526922836047};\\\", \\\"{x:1476,y:893,t:1526922836064};\\\", \\\"{x:1498,y:890,t:1526922836081};\\\", \\\"{x:1512,y:886,t:1526922836098};\\\", \\\"{x:1524,y:882,t:1526922836114};\\\", \\\"{x:1528,y:881,t:1526922836131};\\\", \\\"{x:1527,y:881,t:1526922836228};\\\", \\\"{x:1525,y:881,t:1526922836243};\\\", \\\"{x:1524,y:881,t:1526922836252};\\\", \\\"{x:1522,y:881,t:1526922836265};\\\", \\\"{x:1518,y:883,t:1526922836281};\\\", \\\"{x:1514,y:885,t:1526922836299};\\\", \\\"{x:1511,y:886,t:1526922836314};\\\", \\\"{x:1510,y:887,t:1526922836331};\\\", \\\"{x:1509,y:888,t:1526922836661};\\\", \\\"{x:1509,y:891,t:1526922836676};\\\", \\\"{x:1510,y:892,t:1526922836684};\\\", \\\"{x:1513,y:894,t:1526922836698};\\\", \\\"{x:1518,y:897,t:1526922836716};\\\", \\\"{x:1521,y:898,t:1526922836731};\\\", \\\"{x:1526,y:900,t:1526922836747};\\\", \\\"{x:1530,y:900,t:1526922836765};\\\", \\\"{x:1533,y:900,t:1526922836781};\\\", \\\"{x:1535,y:900,t:1526922836798};\\\", \\\"{x:1536,y:900,t:1526922836815};\\\", \\\"{x:1538,y:900,t:1526922836832};\\\", \\\"{x:1539,y:900,t:1526922836852};\\\", \\\"{x:1541,y:899,t:1526922836865};\\\", \\\"{x:1544,y:898,t:1526922836883};\\\", \\\"{x:1546,y:896,t:1526922836898};\\\", \\\"{x:1549,y:896,t:1526922836915};\\\", \\\"{x:1553,y:894,t:1526922836932};\\\", \\\"{x:1556,y:893,t:1526922836948};\\\", \\\"{x:1559,y:892,t:1526922836965};\\\", \\\"{x:1563,y:891,t:1526922836982};\\\", \\\"{x:1566,y:890,t:1526922836998};\\\", \\\"{x:1570,y:888,t:1526922837015};\\\", \\\"{x:1572,y:888,t:1526922837032};\\\", \\\"{x:1574,y:888,t:1526922837048};\\\", \\\"{x:1576,y:887,t:1526922837065};\\\", \\\"{x:1577,y:887,t:1526922837082};\\\", \\\"{x:1580,y:888,t:1526922837389};\\\", \\\"{x:1581,y:889,t:1526922837399};\\\", \\\"{x:1585,y:890,t:1526922837415};\\\", \\\"{x:1590,y:893,t:1526922837432};\\\", \\\"{x:1592,y:893,t:1526922837448};\\\", \\\"{x:1595,y:894,t:1526922837465};\\\", \\\"{x:1596,y:894,t:1526922837482};\\\", \\\"{x:1597,y:894,t:1526922837499};\\\", \\\"{x:1598,y:894,t:1526922837515};\\\", \\\"{x:1601,y:894,t:1526922837532};\\\", \\\"{x:1609,y:894,t:1526922837549};\\\", \\\"{x:1618,y:895,t:1526922837565};\\\", \\\"{x:1624,y:895,t:1526922837582};\\\", \\\"{x:1629,y:895,t:1526922837599};\\\", \\\"{x:1632,y:895,t:1526922837615};\\\", \\\"{x:1636,y:895,t:1526922837632};\\\", \\\"{x:1638,y:895,t:1526922837649};\\\", \\\"{x:1643,y:895,t:1526922837665};\\\", \\\"{x:1648,y:895,t:1526922837682};\\\", \\\"{x:1653,y:895,t:1526922837700};\\\", \\\"{x:1652,y:895,t:1526922838148};\\\", \\\"{x:1655,y:895,t:1526922838332};\\\", \\\"{x:1668,y:893,t:1526922838349};\\\", \\\"{x:1680,y:893,t:1526922838366};\\\", \\\"{x:1691,y:892,t:1526922838383};\\\", \\\"{x:1698,y:891,t:1526922838399};\\\", \\\"{x:1701,y:891,t:1526922838416};\\\", \\\"{x:1706,y:891,t:1526922838433};\\\", \\\"{x:1709,y:889,t:1526922838449};\\\", \\\"{x:1713,y:888,t:1526922838466};\\\", \\\"{x:1719,y:888,t:1526922838483};\\\", \\\"{x:1724,y:888,t:1526922838498};\\\", \\\"{x:1726,y:888,t:1526922838515};\\\", \\\"{x:1727,y:888,t:1526922838603};\\\", \\\"{x:1729,y:887,t:1526922838644};\\\", \\\"{x:1729,y:888,t:1526922838732};\\\", \\\"{x:1729,y:891,t:1526922838750};\\\", \\\"{x:1729,y:895,t:1526922838767};\\\", \\\"{x:1730,y:898,t:1526922838783};\\\", \\\"{x:1730,y:902,t:1526922838800};\\\", \\\"{x:1730,y:905,t:1526922838816};\\\", \\\"{x:1730,y:907,t:1526922838833};\\\", \\\"{x:1730,y:908,t:1526922838850};\\\", \\\"{x:1730,y:909,t:1526922838876};\\\", \\\"{x:1729,y:909,t:1526922838892};\\\", \\\"{x:1728,y:909,t:1526922838900};\\\", \\\"{x:1723,y:909,t:1526922838916};\\\", \\\"{x:1718,y:909,t:1526922838932};\\\", \\\"{x:1713,y:907,t:1526922838950};\\\", \\\"{x:1709,y:905,t:1526922838966};\\\", \\\"{x:1707,y:904,t:1526922838983};\\\", \\\"{x:1706,y:903,t:1526922839052};\\\", \\\"{x:1707,y:901,t:1526922839076};\\\", \\\"{x:1711,y:900,t:1526922839083};\\\", \\\"{x:1722,y:895,t:1526922839100};\\\", \\\"{x:1734,y:890,t:1526922839117};\\\", \\\"{x:1741,y:887,t:1526922839133};\\\", \\\"{x:1746,y:884,t:1526922839150};\\\", \\\"{x:1750,y:883,t:1526922839167};\\\", \\\"{x:1752,y:882,t:1526922839183};\\\", \\\"{x:1755,y:881,t:1526922839200};\\\", \\\"{x:1759,y:881,t:1526922839217};\\\", \\\"{x:1762,y:881,t:1526922839232};\\\", \\\"{x:1765,y:881,t:1526922839250};\\\", \\\"{x:1770,y:881,t:1526922839267};\\\", \\\"{x:1771,y:881,t:1526922839283};\\\", \\\"{x:1773,y:881,t:1526922839300};\\\", \\\"{x:1774,y:881,t:1526922839323};\\\", \\\"{x:1775,y:881,t:1526922839333};\\\", \\\"{x:1777,y:881,t:1526922839350};\\\", \\\"{x:1778,y:881,t:1526922839366};\\\", \\\"{x:1780,y:882,t:1526922839382};\\\", \\\"{x:1782,y:884,t:1526922839400};\\\", \\\"{x:1783,y:885,t:1526922839417};\\\", \\\"{x:1784,y:886,t:1526922839433};\\\", \\\"{x:1784,y:887,t:1526922839450};\\\", \\\"{x:1785,y:889,t:1526922839467};\\\", \\\"{x:1785,y:890,t:1526922839484};\\\", \\\"{x:1785,y:892,t:1526922839508};\\\", \\\"{x:1785,y:893,t:1526922839531};\\\", \\\"{x:1784,y:894,t:1526922839548};\\\", \\\"{x:1783,y:895,t:1526922839572};\\\", \\\"{x:1782,y:895,t:1526922839584};\\\", \\\"{x:1780,y:897,t:1526922839600};\\\", \\\"{x:1777,y:897,t:1526922839617};\\\", \\\"{x:1776,y:897,t:1526922839635};\\\", \\\"{x:1776,y:898,t:1526922839649};\\\", \\\"{x:1775,y:899,t:1526922839666};\\\", \\\"{x:1774,y:899,t:1526922839684};\\\", \\\"{x:1775,y:899,t:1526922840084};\\\", \\\"{x:1786,y:898,t:1526922840101};\\\", \\\"{x:1804,y:895,t:1526922840117};\\\", \\\"{x:1827,y:895,t:1526922840134};\\\", \\\"{x:1849,y:892,t:1526922840151};\\\", \\\"{x:1864,y:891,t:1526922840167};\\\", \\\"{x:1873,y:891,t:1526922840184};\\\", \\\"{x:1879,y:891,t:1526922840202};\\\", \\\"{x:1882,y:891,t:1526922840217};\\\", \\\"{x:1883,y:891,t:1526922840277};\\\", \\\"{x:1879,y:891,t:1526922840372};\\\", \\\"{x:1875,y:889,t:1526922840385};\\\", \\\"{x:1865,y:886,t:1526922840401};\\\", \\\"{x:1849,y:878,t:1526922840418};\\\", \\\"{x:1830,y:872,t:1526922840434};\\\", \\\"{x:1813,y:865,t:1526922840451};\\\", \\\"{x:1797,y:858,t:1526922840468};\\\", \\\"{x:1795,y:856,t:1526922840484};\\\", \\\"{x:1793,y:856,t:1526922840508};\\\", \\\"{x:1793,y:855,t:1526922840517};\\\", \\\"{x:1793,y:852,t:1526922840533};\\\", \\\"{x:1793,y:850,t:1526922840551};\\\", \\\"{x:1795,y:848,t:1526922840568};\\\", \\\"{x:1797,y:846,t:1526922840584};\\\", \\\"{x:1800,y:844,t:1526922840600};\\\", \\\"{x:1801,y:843,t:1526922840618};\\\", \\\"{x:1802,y:843,t:1526922840634};\\\", \\\"{x:1804,y:843,t:1526922840651};\\\", \\\"{x:1808,y:841,t:1526922840667};\\\", \\\"{x:1811,y:840,t:1526922840684};\\\", \\\"{x:1814,y:838,t:1526922840700};\\\", \\\"{x:1815,y:838,t:1526922840723};\\\", \\\"{x:1815,y:837,t:1526922840755};\\\", \\\"{x:1814,y:835,t:1526922840771};\\\", \\\"{x:1813,y:834,t:1526922840785};\\\", \\\"{x:1812,y:834,t:1526922840828};\\\", \\\"{x:1810,y:833,t:1526922840843};\\\", \\\"{x:1808,y:833,t:1526922840866};\\\", \\\"{x:1807,y:832,t:1526922840874};\\\", \\\"{x:1805,y:831,t:1526922840899};\\\", \\\"{x:1802,y:830,t:1526922840907};\\\", \\\"{x:1800,y:830,t:1526922840923};\\\", \\\"{x:1797,y:829,t:1526922840935};\\\", \\\"{x:1791,y:829,t:1526922840951};\\\", \\\"{x:1785,y:829,t:1526922840968};\\\", \\\"{x:1781,y:829,t:1526922840985};\\\", \\\"{x:1775,y:829,t:1526922841001};\\\", \\\"{x:1769,y:832,t:1526922841018};\\\", \\\"{x:1761,y:835,t:1526922841035};\\\", \\\"{x:1759,y:836,t:1526922841051};\\\", \\\"{x:1756,y:837,t:1526922841068};\\\", \\\"{x:1755,y:837,t:1526922841085};\\\", \\\"{x:1754,y:837,t:1526922841388};\\\", \\\"{x:1754,y:836,t:1526922841420};\\\", \\\"{x:1754,y:835,t:1526922841436};\\\", \\\"{x:1756,y:834,t:1526922841452};\\\", \\\"{x:1760,y:832,t:1526922841468};\\\", \\\"{x:1768,y:828,t:1526922841485};\\\", \\\"{x:1774,y:826,t:1526922841504};\\\", \\\"{x:1781,y:823,t:1526922841518};\\\", \\\"{x:1788,y:823,t:1526922841535};\\\", \\\"{x:1795,y:822,t:1526922841552};\\\", \\\"{x:1806,y:820,t:1526922841568};\\\", \\\"{x:1815,y:820,t:1526922841585};\\\", \\\"{x:1821,y:820,t:1526922841601};\\\", \\\"{x:1824,y:820,t:1526922841618};\\\", \\\"{x:1823,y:820,t:1526922841699};\\\", \\\"{x:1821,y:821,t:1526922841715};\\\", \\\"{x:1820,y:821,t:1526922841723};\\\", \\\"{x:1819,y:822,t:1526922841734};\\\", \\\"{x:1818,y:823,t:1526922841752};\\\", \\\"{x:1816,y:823,t:1526922841769};\\\", \\\"{x:1815,y:824,t:1526922841785};\\\", \\\"{x:1814,y:824,t:1526922841802};\\\", \\\"{x:1810,y:826,t:1526922841819};\\\", \\\"{x:1807,y:827,t:1526922841835};\\\", \\\"{x:1797,y:828,t:1526922841852};\\\", \\\"{x:1792,y:829,t:1526922841869};\\\", \\\"{x:1789,y:829,t:1526922841884};\\\", \\\"{x:1787,y:830,t:1526922841903};\\\", \\\"{x:1786,y:830,t:1526922841956};\\\", \\\"{x:1785,y:831,t:1526922841996};\\\", \\\"{x:1784,y:831,t:1526922842284};\\\", \\\"{x:1783,y:831,t:1526922842316};\\\", \\\"{x:1782,y:831,t:1526922842323};\\\", \\\"{x:1781,y:831,t:1526922842364};\\\", \\\"{x:1780,y:831,t:1526922842388};\\\", \\\"{x:1779,y:831,t:1526922842403};\\\", \\\"{x:1778,y:831,t:1526922842419};\\\", \\\"{x:1777,y:831,t:1526922842484};\\\", \\\"{x:1776,y:831,t:1526922842604};\\\", \\\"{x:1775,y:831,t:1526922842643};\\\", \\\"{x:1774,y:831,t:1526922842700};\\\", \\\"{x:1773,y:831,t:1526922842724};\\\", \\\"{x:1772,y:831,t:1526922842736};\\\", \\\"{x:1770,y:831,t:1526922843132};\\\", \\\"{x:1768,y:831,t:1526922843140};\\\", \\\"{x:1765,y:831,t:1526922843153};\\\", \\\"{x:1756,y:831,t:1526922843171};\\\", \\\"{x:1750,y:831,t:1526922843187};\\\", \\\"{x:1748,y:831,t:1526922843203};\\\", \\\"{x:1746,y:831,t:1526922843220};\\\", \\\"{x:1744,y:830,t:1526922843237};\\\", \\\"{x:1739,y:830,t:1526922844549};\\\", \\\"{x:1720,y:830,t:1526922844556};\\\", \\\"{x:1670,y:830,t:1526922844571};\\\", \\\"{x:1586,y:827,t:1526922844588};\\\", \\\"{x:1497,y:827,t:1526922844605};\\\", \\\"{x:1447,y:827,t:1526922844621};\\\", \\\"{x:1422,y:826,t:1526922844638};\\\", \\\"{x:1408,y:823,t:1526922844654};\\\", \\\"{x:1392,y:816,t:1526922844672};\\\", \\\"{x:1381,y:811,t:1526922844688};\\\", \\\"{x:1379,y:798,t:1526922844705};\\\", \\\"{x:1379,y:783,t:1526922844722};\\\", \\\"{x:1380,y:754,t:1526922844738};\\\", \\\"{x:1368,y:601,t:1526922844754};\\\", \\\"{x:1316,y:473,t:1526922844771};\\\", \\\"{x:1296,y:413,t:1526922844788};\\\", \\\"{x:1273,y:353,t:1526922844804};\\\", \\\"{x:1251,y:296,t:1526922844821};\\\", \\\"{x:1244,y:264,t:1526922844838};\\\", \\\"{x:1242,y:249,t:1526922844855};\\\", \\\"{x:1242,y:238,t:1526922844872};\\\", \\\"{x:1242,y:226,t:1526922844888};\\\", \\\"{x:1246,y:217,t:1526922844905};\\\", \\\"{x:1249,y:210,t:1526922844921};\\\", \\\"{x:1253,y:205,t:1526922844938};\\\", \\\"{x:1259,y:198,t:1526922844955};\\\", \\\"{x:1270,y:185,t:1526922844972};\\\", \\\"{x:1277,y:179,t:1526922844987};\\\", \\\"{x:1284,y:176,t:1526922845005};\\\", \\\"{x:1292,y:171,t:1526922845022};\\\", \\\"{x:1298,y:169,t:1526922845038};\\\", \\\"{x:1306,y:167,t:1526922845054};\\\", \\\"{x:1313,y:167,t:1526922845072};\\\", \\\"{x:1328,y:167,t:1526922845088};\\\", \\\"{x:1350,y:178,t:1526922845105};\\\", \\\"{x:1375,y:194,t:1526922845121};\\\", \\\"{x:1405,y:218,t:1526922845139};\\\", \\\"{x:1438,y:249,t:1526922845155};\\\", \\\"{x:1489,y:312,t:1526922845177};\\\", \\\"{x:1529,y:359,t:1526922845189};\\\", \\\"{x:1560,y:393,t:1526922845205};\\\", \\\"{x:1583,y:415,t:1526922845220};\\\", \\\"{x:1604,y:426,t:1526922845237};\\\", \\\"{x:1616,y:432,t:1526922845255};\\\", \\\"{x:1624,y:436,t:1526922845270};\\\", \\\"{x:1625,y:436,t:1526922845288};\\\", \\\"{x:1627,y:435,t:1526922845355};\\\", \\\"{x:1627,y:429,t:1526922845371};\\\", \\\"{x:1627,y:426,t:1526922845388};\\\", \\\"{x:1628,y:421,t:1526922845405};\\\", \\\"{x:1628,y:417,t:1526922845420};\\\", \\\"{x:1627,y:413,t:1526922845438};\\\", \\\"{x:1622,y:408,t:1526922845455};\\\", \\\"{x:1616,y:404,t:1526922845471};\\\", \\\"{x:1608,y:398,t:1526922845488};\\\", \\\"{x:1600,y:393,t:1526922845505};\\\", \\\"{x:1591,y:384,t:1526922845521};\\\", \\\"{x:1585,y:379,t:1526922845539};\\\", \\\"{x:1582,y:373,t:1526922845555};\\\", \\\"{x:1579,y:366,t:1526922845572};\\\", \\\"{x:1576,y:356,t:1526922845588};\\\", \\\"{x:1574,y:349,t:1526922845605};\\\", \\\"{x:1574,y:347,t:1526922845622};\\\", \\\"{x:1574,y:344,t:1526922845638};\\\", \\\"{x:1574,y:343,t:1526922845656};\\\", \\\"{x:1574,y:341,t:1526922845672};\\\", \\\"{x:1574,y:340,t:1526922845689};\\\", \\\"{x:1574,y:339,t:1526922845820};\\\", \\\"{x:1573,y:339,t:1526922845827};\\\", \\\"{x:1572,y:339,t:1526922845844};\\\", \\\"{x:1571,y:340,t:1526922845855};\\\", \\\"{x:1571,y:349,t:1526922845872};\\\", \\\"{x:1577,y:368,t:1526922845889};\\\", \\\"{x:1591,y:391,t:1526922845905};\\\", \\\"{x:1603,y:416,t:1526922845922};\\\", \\\"{x:1614,y:440,t:1526922845939};\\\", \\\"{x:1625,y:460,t:1526922845956};\\\", \\\"{x:1631,y:471,t:1526922845972};\\\", \\\"{x:1636,y:484,t:1526922845989};\\\", \\\"{x:1637,y:492,t:1526922846006};\\\", \\\"{x:1637,y:498,t:1526922846022};\\\", \\\"{x:1637,y:505,t:1526922846039};\\\", \\\"{x:1634,y:514,t:1526922846055};\\\", \\\"{x:1630,y:524,t:1526922846072};\\\", \\\"{x:1624,y:533,t:1526922846089};\\\", \\\"{x:1620,y:540,t:1526922846106};\\\", \\\"{x:1616,y:545,t:1526922846122};\\\", \\\"{x:1611,y:549,t:1526922846139};\\\", \\\"{x:1610,y:551,t:1526922846156};\\\", \\\"{x:1609,y:553,t:1526922846172};\\\", \\\"{x:1608,y:553,t:1526922846189};\\\", \\\"{x:1607,y:553,t:1526922846284};\\\", \\\"{x:1606,y:553,t:1526922846292};\\\", \\\"{x:1605,y:553,t:1526922846305};\\\", \\\"{x:1602,y:553,t:1526922846323};\\\", \\\"{x:1597,y:553,t:1526922846339};\\\", \\\"{x:1592,y:553,t:1526922846355};\\\", \\\"{x:1588,y:553,t:1526922846372};\\\", \\\"{x:1586,y:553,t:1526922846389};\\\", \\\"{x:1586,y:554,t:1526922846580};\\\", \\\"{x:1586,y:555,t:1526922846589};\\\", \\\"{x:1586,y:556,t:1526922846607};\\\", \\\"{x:1585,y:556,t:1526922846676};\\\", \\\"{x:1582,y:550,t:1526922846690};\\\", \\\"{x:1579,y:541,t:1526922846706};\\\", \\\"{x:1573,y:523,t:1526922846722};\\\", \\\"{x:1567,y:501,t:1526922846739};\\\", \\\"{x:1561,y:490,t:1526922846756};\\\", \\\"{x:1560,y:486,t:1526922846773};\\\", \\\"{x:1559,y:484,t:1526922846789};\\\", \\\"{x:1559,y:483,t:1526922846807};\\\", \\\"{x:1559,y:482,t:1526922846972};\\\", \\\"{x:1560,y:482,t:1526922846989};\\\", \\\"{x:1560,y:483,t:1526922847006};\\\", \\\"{x:1561,y:483,t:1526922847044};\\\", \\\"{x:1564,y:484,t:1526922847220};\\\", \\\"{x:1566,y:488,t:1526922847228};\\\", \\\"{x:1570,y:492,t:1526922847240};\\\", \\\"{x:1574,y:499,t:1526922847256};\\\", \\\"{x:1577,y:506,t:1526922847274};\\\", \\\"{x:1581,y:515,t:1526922847290};\\\", \\\"{x:1583,y:523,t:1526922847307};\\\", \\\"{x:1588,y:532,t:1526922847324};\\\", \\\"{x:1589,y:537,t:1526922847339};\\\", \\\"{x:1590,y:539,t:1526922847357};\\\", \\\"{x:1590,y:542,t:1526922847373};\\\", \\\"{x:1591,y:545,t:1526922847390};\\\", \\\"{x:1591,y:546,t:1526922847407};\\\", \\\"{x:1591,y:548,t:1526922847423};\\\", \\\"{x:1591,y:549,t:1526922847452};\\\", \\\"{x:1591,y:550,t:1526922847460};\\\", \\\"{x:1591,y:551,t:1526922847474};\\\", \\\"{x:1592,y:555,t:1526922847491};\\\", \\\"{x:1594,y:559,t:1526922847507};\\\", \\\"{x:1597,y:568,t:1526922847523};\\\", \\\"{x:1598,y:575,t:1526922847540};\\\", \\\"{x:1598,y:582,t:1526922847557};\\\", \\\"{x:1600,y:591,t:1526922847574};\\\", \\\"{x:1602,y:600,t:1526922847590};\\\", \\\"{x:1602,y:609,t:1526922847606};\\\", \\\"{x:1603,y:616,t:1526922847624};\\\", \\\"{x:1605,y:622,t:1526922847641};\\\", \\\"{x:1605,y:626,t:1526922847656};\\\", \\\"{x:1606,y:632,t:1526922847674};\\\", \\\"{x:1606,y:635,t:1526922847691};\\\", \\\"{x:1606,y:639,t:1526922847707};\\\", \\\"{x:1607,y:643,t:1526922847724};\\\", \\\"{x:1607,y:646,t:1526922847740};\\\", \\\"{x:1607,y:648,t:1526922847757};\\\", \\\"{x:1607,y:650,t:1526922847773};\\\", \\\"{x:1607,y:652,t:1526922847791};\\\", \\\"{x:1606,y:653,t:1526922847908};\\\", \\\"{x:1604,y:653,t:1526922847923};\\\", \\\"{x:1601,y:650,t:1526922847940};\\\", \\\"{x:1597,y:647,t:1526922847958};\\\", \\\"{x:1590,y:642,t:1526922847973};\\\", \\\"{x:1586,y:638,t:1526922847990};\\\", \\\"{x:1582,y:636,t:1526922848008};\\\", \\\"{x:1580,y:635,t:1526922848024};\\\", \\\"{x:1579,y:635,t:1526922848058};\\\", \\\"{x:1579,y:633,t:1526922851084};\\\", \\\"{x:1579,y:628,t:1526922851092};\\\", \\\"{x:1579,y:612,t:1526922851111};\\\", \\\"{x:1579,y:595,t:1526922851126};\\\", \\\"{x:1579,y:576,t:1526922851143};\\\", \\\"{x:1575,y:554,t:1526922851159};\\\", \\\"{x:1573,y:533,t:1526922851176};\\\", \\\"{x:1570,y:512,t:1526922851192};\\\", \\\"{x:1566,y:490,t:1526922851209};\\\", \\\"{x:1566,y:474,t:1526922851226};\\\", \\\"{x:1562,y:454,t:1526922851242};\\\", \\\"{x:1562,y:446,t:1526922851259};\\\", \\\"{x:1560,y:438,t:1526922851276};\\\", \\\"{x:1560,y:434,t:1526922851294};\\\", \\\"{x:1559,y:433,t:1526922851309};\\\", \\\"{x:1559,y:431,t:1526922851326};\\\", \\\"{x:1559,y:430,t:1526922851344};\\\", \\\"{x:1559,y:428,t:1526922851388};\\\", \\\"{x:1559,y:427,t:1526922851404};\\\", \\\"{x:1559,y:425,t:1526922851419};\\\", \\\"{x:1559,y:424,t:1526922851427};\\\", \\\"{x:1559,y:418,t:1526922851443};\\\", \\\"{x:1560,y:411,t:1526922851459};\\\", \\\"{x:1561,y:401,t:1526922851477};\\\", \\\"{x:1561,y:387,t:1526922851494};\\\", \\\"{x:1561,y:367,t:1526922851510};\\\", \\\"{x:1557,y:338,t:1526922851526};\\\", \\\"{x:1544,y:296,t:1526922851544};\\\", \\\"{x:1530,y:236,t:1526922851559};\\\", \\\"{x:1502,y:151,t:1526922851576};\\\", \\\"{x:1462,y:58,t:1526922851593};\\\", \\\"{x:1426,y:0,t:1526922851609};\\\", \\\"{x:1383,y:0,t:1526922851626};\\\", \\\"{x:1315,y:0,t:1526922851643};\\\", \\\"{x:1280,y:0,t:1526922851660};\\\", \\\"{x:1237,y:0,t:1526922851676};\\\", \\\"{x:1201,y:0,t:1526922851694};\\\", \\\"{x:1179,y:0,t:1526922851710};\\\", \\\"{x:1165,y:0,t:1526922851727};\\\", \\\"{x:1154,y:0,t:1526922851743};\\\", \\\"{x:1149,y:0,t:1526922851760};\\\", \\\"{x:1142,y:2,t:1526922851776};\\\", \\\"{x:1124,y:9,t:1526922851793};\\\", \\\"{x:1084,y:35,t:1526922851810};\\\", \\\"{x:1018,y:63,t:1526922851827};\\\", \\\"{x:889,y:110,t:1526922851843};\\\", \\\"{x:786,y:140,t:1526922851861};\\\", \\\"{x:666,y:161,t:1526922851876};\\\", \\\"{x:538,y:165,t:1526922851893};\\\", \\\"{x:392,y:165,t:1526922851911};\\\", \\\"{x:212,y:161,t:1526922851926};\\\", \\\"{x:32,y:134,t:1526922851943};\\\", \\\"{x:8,y:109,t:1526922851960};\\\", \\\"{x:8,y:80,t:1526922851977};\\\", \\\"{x:8,y:54,t:1526922851994};\\\", \\\"{x:8,y:39,t:1526922852011};\\\", \\\"{x:8,y:37,t:1526922852027};\\\", \\\"{x:8,y:38,t:1526922852076};\\\", \\\"{x:12,y:44,t:1526922852083};\\\", \\\"{x:19,y:49,t:1526922852094};\\\", \\\"{x:37,y:64,t:1526922852111};\\\", \\\"{x:58,y:77,t:1526922852127};\\\", \\\"{x:94,y:98,t:1526922852143};\\\", \\\"{x:139,y:118,t:1526922852160};\\\", \\\"{x:183,y:136,t:1526922852177};\\\", \\\"{x:233,y:159,t:1526922852194};\\\", \\\"{x:306,y:183,t:1526922852210};\\\", \\\"{x:393,y:202,t:1526922852227};\\\", \\\"{x:438,y:210,t:1526922852244};\\\", \\\"{x:469,y:215,t:1526922852260};\\\", \\\"{x:493,y:217,t:1526922852278};\\\", \\\"{x:513,y:220,t:1526922852293};\\\", \\\"{x:534,y:220,t:1526922852310};\\\", \\\"{x:560,y:220,t:1526922852328};\\\", \\\"{x:596,y:220,t:1526922852343};\\\", \\\"{x:638,y:220,t:1526922852361};\\\", \\\"{x:685,y:220,t:1526922852377};\\\", \\\"{x:730,y:220,t:1526922852394};\\\", \\\"{x:774,y:222,t:1526922852411};\\\", \\\"{x:812,y:229,t:1526922852427};\\\", \\\"{x:832,y:238,t:1526922852443};\\\", \\\"{x:842,y:249,t:1526922852460};\\\", \\\"{x:849,y:271,t:1526922852478};\\\", \\\"{x:854,y:302,t:1526922852494};\\\", \\\"{x:857,y:351,t:1526922852511};\\\", \\\"{x:857,y:423,t:1526922852527};\\\", \\\"{x:857,y:484,t:1526922852545};\\\", \\\"{x:857,y:538,t:1526922852562};\\\", \\\"{x:857,y:566,t:1526922852578};\\\", \\\"{x:857,y:582,t:1526922852594};\\\", \\\"{x:857,y:590,t:1526922852607};\\\", \\\"{x:856,y:592,t:1526922852623};\\\", \\\"{x:856,y:593,t:1526922852640};\\\", \\\"{x:854,y:589,t:1526922852723};\\\", \\\"{x:841,y:572,t:1526922852740};\\\", \\\"{x:823,y:553,t:1526922852758};\\\", \\\"{x:800,y:533,t:1526922852777};\\\", \\\"{x:779,y:511,t:1526922852795};\\\", \\\"{x:761,y:492,t:1526922852810};\\\", \\\"{x:757,y:489,t:1526922852827};\\\", \\\"{x:756,y:487,t:1526922852844};\\\", \\\"{x:756,y:486,t:1526922852876};\\\", \\\"{x:762,y:481,t:1526922852894};\\\", \\\"{x:781,y:475,t:1526922852911};\\\", \\\"{x:804,y:474,t:1526922852927};\\\", \\\"{x:834,y:474,t:1526922852944};\\\", \\\"{x:857,y:477,t:1526922852960};\\\", \\\"{x:874,y:481,t:1526922852977};\\\", \\\"{x:884,y:485,t:1526922852994};\\\", \\\"{x:887,y:488,t:1526922853010};\\\", \\\"{x:888,y:503,t:1526922853027};\\\", \\\"{x:884,y:523,t:1526922853044};\\\", \\\"{x:877,y:541,t:1526922853061};\\\", \\\"{x:869,y:560,t:1526922853078};\\\", \\\"{x:862,y:576,t:1526922853094};\\\", \\\"{x:860,y:587,t:1526922853111};\\\", \\\"{x:859,y:594,t:1526922853128};\\\", \\\"{x:858,y:595,t:1526922853144};\\\", \\\"{x:857,y:595,t:1526922853243};\\\", \\\"{x:841,y:583,t:1526922853262};\\\", \\\"{x:805,y:567,t:1526922853278};\\\", \\\"{x:754,y:551,t:1526922853294};\\\", \\\"{x:697,y:538,t:1526922853311};\\\", \\\"{x:669,y:534,t:1526922853328};\\\", \\\"{x:643,y:532,t:1526922853343};\\\", \\\"{x:619,y:530,t:1526922853361};\\\", \\\"{x:601,y:525,t:1526922853378};\\\", \\\"{x:593,y:524,t:1526922853394};\\\", \\\"{x:592,y:522,t:1526922853411};\\\", \\\"{x:593,y:522,t:1526922853434};\\\", \\\"{x:597,y:521,t:1526922853443};\\\", \\\"{x:612,y:521,t:1526922853461};\\\", \\\"{x:629,y:522,t:1526922853478};\\\", \\\"{x:644,y:523,t:1526922853494};\\\", \\\"{x:658,y:524,t:1526922853511};\\\", \\\"{x:670,y:529,t:1526922853528};\\\", \\\"{x:676,y:532,t:1526922853544};\\\", \\\"{x:682,y:540,t:1526922853560};\\\", \\\"{x:684,y:545,t:1526922853578};\\\", \\\"{x:683,y:558,t:1526922853595};\\\", \\\"{x:673,y:569,t:1526922853613};\\\", \\\"{x:655,y:578,t:1526922853628};\\\", \\\"{x:634,y:585,t:1526922853646};\\\", \\\"{x:610,y:595,t:1526922853662};\\\", \\\"{x:576,y:608,t:1526922853679};\\\", \\\"{x:541,y:615,t:1526922853694};\\\", \\\"{x:494,y:621,t:1526922853712};\\\", \\\"{x:456,y:622,t:1526922853728};\\\", \\\"{x:431,y:622,t:1526922853745};\\\", \\\"{x:410,y:622,t:1526922853762};\\\", \\\"{x:397,y:622,t:1526922853778};\\\", \\\"{x:393,y:622,t:1526922853795};\\\", \\\"{x:392,y:621,t:1526922853827};\\\", \\\"{x:392,y:620,t:1526922853843};\\\", \\\"{x:392,y:619,t:1526922853851};\\\", \\\"{x:392,y:616,t:1526922853861};\\\", \\\"{x:392,y:608,t:1526922853878};\\\", \\\"{x:390,y:598,t:1526922853895};\\\", \\\"{x:389,y:585,t:1526922853911};\\\", \\\"{x:389,y:578,t:1526922853928};\\\", \\\"{x:389,y:575,t:1526922853945};\\\", \\\"{x:389,y:572,t:1526922853961};\\\", \\\"{x:389,y:571,t:1526922853978};\\\", \\\"{x:389,y:570,t:1526922853995};\\\", \\\"{x:389,y:573,t:1526922854156};\\\", \\\"{x:389,y:575,t:1526922854163};\\\", \\\"{x:389,y:577,t:1526922854179};\\\", \\\"{x:389,y:585,t:1526922854195};\\\", \\\"{x:389,y:588,t:1526922854211};\\\", \\\"{x:390,y:590,t:1526922854229};\\\", \\\"{x:394,y:590,t:1526922854306};\\\", \\\"{x:396,y:589,t:1526922854314};\\\", \\\"{x:398,y:587,t:1526922854328};\\\", \\\"{x:399,y:584,t:1526922854345};\\\", \\\"{x:400,y:584,t:1526922854362};\\\", \\\"{x:399,y:584,t:1526922854443};\\\", \\\"{x:398,y:586,t:1526922854451};\\\", \\\"{x:395,y:590,t:1526922854463};\\\", \\\"{x:393,y:594,t:1526922854478};\\\", \\\"{x:391,y:599,t:1526922854495};\\\", \\\"{x:389,y:602,t:1526922854512};\\\", \\\"{x:389,y:605,t:1526922854529};\\\", \\\"{x:387,y:606,t:1526922854545};\\\", \\\"{x:387,y:608,t:1526922854595};\\\", \\\"{x:387,y:610,t:1526922854612};\\\", \\\"{x:387,y:615,t:1526922854629};\\\", \\\"{x:387,y:618,t:1526922854645};\\\", \\\"{x:387,y:620,t:1526922854662};\\\", \\\"{x:387,y:621,t:1526922854679};\\\", \\\"{x:388,y:622,t:1526922854946};\\\", \\\"{x:390,y:622,t:1526922854971};\\\", \\\"{x:391,y:622,t:1526922854978};\\\", \\\"{x:393,y:622,t:1526922854996};\\\", \\\"{x:394,y:621,t:1526922855012};\\\", \\\"{x:401,y:618,t:1526922855029};\\\", \\\"{x:407,y:615,t:1526922855046};\\\", \\\"{x:420,y:609,t:1526922855062};\\\", \\\"{x:436,y:606,t:1526922855079};\\\", \\\"{x:460,y:598,t:1526922855096};\\\", \\\"{x:487,y:596,t:1526922855112};\\\", \\\"{x:517,y:590,t:1526922855130};\\\", \\\"{x:545,y:585,t:1526922855146};\\\", \\\"{x:570,y:580,t:1526922855163};\\\", \\\"{x:600,y:574,t:1526922855179};\\\", \\\"{x:617,y:570,t:1526922855197};\\\", \\\"{x:630,y:566,t:1526922855213};\\\", \\\"{x:640,y:561,t:1526922855230};\\\", \\\"{x:644,y:560,t:1526922855247};\\\", \\\"{x:649,y:557,t:1526922855262};\\\", \\\"{x:650,y:557,t:1526922855283};\\\", \\\"{x:651,y:557,t:1526922855299};\\\", \\\"{x:652,y:555,t:1526922855314};\\\", \\\"{x:655,y:554,t:1526922855330};\\\", \\\"{x:657,y:553,t:1526922855347};\\\", \\\"{x:660,y:550,t:1526922855363};\\\", \\\"{x:661,y:550,t:1526922855403};\\\", \\\"{x:661,y:549,t:1526922855413};\\\", \\\"{x:647,y:541,t:1526922855429};\\\", \\\"{x:608,y:532,t:1526922855447};\\\", \\\"{x:549,y:530,t:1526922855464};\\\", \\\"{x:487,y:527,t:1526922855480};\\\", \\\"{x:430,y:536,t:1526922855496};\\\", \\\"{x:375,y:551,t:1526922855514};\\\", \\\"{x:324,y:558,t:1526922855530};\\\", \\\"{x:269,y:566,t:1526922855547};\\\", \\\"{x:128,y:585,t:1526922855563};\\\", \\\"{x:32,y:597,t:1526922855579};\\\", \\\"{x:8,y:603,t:1526922855596};\\\", \\\"{x:8,y:607,t:1526922855613};\\\", \\\"{x:8,y:608,t:1526922855630};\\\", \\\"{x:9,y:608,t:1526922855723};\\\", \\\"{x:11,y:608,t:1526922855730};\\\", \\\"{x:13,y:607,t:1526922855747};\\\", \\\"{x:35,y:599,t:1526922855763};\\\", \\\"{x:52,y:593,t:1526922855781};\\\", \\\"{x:72,y:587,t:1526922855798};\\\", \\\"{x:95,y:580,t:1526922855813};\\\", \\\"{x:116,y:575,t:1526922855830};\\\", \\\"{x:133,y:569,t:1526922855846};\\\", \\\"{x:153,y:563,t:1526922855863};\\\", \\\"{x:170,y:556,t:1526922855881};\\\", \\\"{x:186,y:551,t:1526922855898};\\\", \\\"{x:198,y:545,t:1526922855913};\\\", \\\"{x:205,y:541,t:1526922855930};\\\", \\\"{x:209,y:538,t:1526922855946};\\\", \\\"{x:210,y:536,t:1526922855964};\\\", \\\"{x:210,y:535,t:1526922855981};\\\", \\\"{x:211,y:533,t:1526922856003};\\\", \\\"{x:212,y:533,t:1526922856019};\\\", \\\"{x:212,y:532,t:1526922856059};\\\", \\\"{x:212,y:531,t:1526922856091};\\\", \\\"{x:213,y:530,t:1526922856099};\\\", \\\"{x:216,y:527,t:1526922856123};\\\", \\\"{x:217,y:525,t:1526922856131};\\\", \\\"{x:231,y:517,t:1526922856149};\\\", \\\"{x:254,y:511,t:1526922856163};\\\", \\\"{x:282,y:505,t:1526922856180};\\\", \\\"{x:311,y:502,t:1526922856196};\\\", \\\"{x:349,y:497,t:1526922856213};\\\", \\\"{x:382,y:494,t:1526922856230};\\\", \\\"{x:408,y:494,t:1526922856248};\\\", \\\"{x:431,y:494,t:1526922856264};\\\", \\\"{x:447,y:494,t:1526922856280};\\\", \\\"{x:460,y:494,t:1526922856297};\\\", \\\"{x:469,y:494,t:1526922856313};\\\", \\\"{x:472,y:494,t:1526922856330};\\\", \\\"{x:473,y:494,t:1526922856347};\\\", \\\"{x:475,y:494,t:1526922856435};\\\", \\\"{x:477,y:494,t:1526922856468};\\\", \\\"{x:478,y:494,t:1526922856483};\\\", \\\"{x:479,y:494,t:1526922856498};\\\", \\\"{x:481,y:494,t:1526922856514};\\\", \\\"{x:482,y:493,t:1526922856530};\\\", \\\"{x:487,y:493,t:1526922856772};\\\", \\\"{x:494,y:493,t:1526922856781};\\\", \\\"{x:513,y:493,t:1526922856800};\\\", \\\"{x:545,y:493,t:1526922856814};\\\", \\\"{x:584,y:493,t:1526922856830};\\\", \\\"{x:629,y:493,t:1526922856847};\\\", \\\"{x:660,y:493,t:1526922856864};\\\", \\\"{x:705,y:493,t:1526922856880};\\\", \\\"{x:747,y:493,t:1526922856897};\\\", \\\"{x:777,y:493,t:1526922856914};\\\", \\\"{x:800,y:493,t:1526922856930};\\\", \\\"{x:818,y:493,t:1526922856947};\\\", \\\"{x:822,y:493,t:1526922856964};\\\", \\\"{x:825,y:494,t:1526922856980};\\\", \\\"{x:828,y:495,t:1526922856998};\\\", \\\"{x:834,y:500,t:1526922857015};\\\", \\\"{x:846,y:513,t:1526922857030};\\\", \\\"{x:858,y:531,t:1526922857048};\\\", \\\"{x:877,y:554,t:1526922857065};\\\", \\\"{x:884,y:579,t:1526922857082};\\\", \\\"{x:897,y:609,t:1526922857098};\\\", \\\"{x:902,y:633,t:1526922857114};\\\", \\\"{x:903,y:666,t:1526922857130};\\\", \\\"{x:903,y:681,t:1526922857148};\\\", \\\"{x:899,y:691,t:1526922857164};\\\", \\\"{x:891,y:699,t:1526922857182};\\\", \\\"{x:885,y:702,t:1526922857197};\\\", \\\"{x:875,y:703,t:1526922857214};\\\", \\\"{x:860,y:703,t:1526922857232};\\\", \\\"{x:837,y:703,t:1526922857247};\\\", \\\"{x:815,y:703,t:1526922857264};\\\", \\\"{x:797,y:700,t:1526922857281};\\\", \\\"{x:781,y:696,t:1526922857297};\\\", \\\"{x:770,y:694,t:1526922857315};\\\", \\\"{x:764,y:691,t:1526922857331};\\\", \\\"{x:763,y:690,t:1526922857347};\\\", \\\"{x:761,y:688,t:1526922857365};\\\", \\\"{x:761,y:687,t:1526922857382};\\\", \\\"{x:761,y:685,t:1526922857397};\\\", \\\"{x:761,y:682,t:1526922857414};\\\", \\\"{x:761,y:679,t:1526922857432};\\\", \\\"{x:761,y:676,t:1526922857448};\\\", \\\"{x:761,y:672,t:1526922857465};\\\", \\\"{x:761,y:670,t:1526922857481};\\\", \\\"{x:761,y:667,t:1526922857497};\\\", \\\"{x:762,y:664,t:1526922857515};\\\", \\\"{x:762,y:661,t:1526922857531};\\\", \\\"{x:762,y:660,t:1526922857548};\\\", \\\"{x:762,y:658,t:1526922857565};\\\", \\\"{x:762,y:655,t:1526922857587};\\\", \\\"{x:761,y:654,t:1526922857603};\\\", \\\"{x:759,y:653,t:1526922857614};\\\", \\\"{x:756,y:651,t:1526922857631};\\\", \\\"{x:747,y:645,t:1526922857648};\\\", \\\"{x:729,y:631,t:1526922857665};\\\", \\\"{x:701,y:612,t:1526922857682};\\\", \\\"{x:667,y:588,t:1526922857698};\\\", \\\"{x:629,y:562,t:1526922857715};\\\", \\\"{x:618,y:548,t:1526922857731};\\\", \\\"{x:614,y:540,t:1526922857748};\\\", \\\"{x:613,y:532,t:1526922857764};\\\", \\\"{x:613,y:523,t:1526922857782};\\\", \\\"{x:613,y:512,t:1526922857799};\\\", \\\"{x:614,y:503,t:1526922857814};\\\", \\\"{x:618,y:495,t:1526922857831};\\\", \\\"{x:623,y:488,t:1526922857848};\\\", \\\"{x:630,y:480,t:1526922857866};\\\", \\\"{x:636,y:473,t:1526922857881};\\\", \\\"{x:648,y:468,t:1526922857899};\\\", \\\"{x:666,y:461,t:1526922857914};\\\", \\\"{x:682,y:455,t:1526922857932};\\\", \\\"{x:700,y:451,t:1526922857949};\\\", \\\"{x:726,y:449,t:1526922857965};\\\", \\\"{x:756,y:449,t:1526922857981};\\\", \\\"{x:786,y:449,t:1526922857998};\\\", \\\"{x:813,y:449,t:1526922858015};\\\", \\\"{x:835,y:449,t:1526922858031};\\\", \\\"{x:847,y:449,t:1526922858048};\\\", \\\"{x:851,y:450,t:1526922858065};\\\", \\\"{x:852,y:451,t:1526922858081};\\\", \\\"{x:851,y:452,t:1526922858115};\\\", \\\"{x:849,y:452,t:1526922858131};\\\", \\\"{x:846,y:456,t:1526922858148};\\\", \\\"{x:845,y:459,t:1526922858166};\\\", \\\"{x:843,y:465,t:1526922858182};\\\", \\\"{x:841,y:470,t:1526922858199};\\\", \\\"{x:836,y:479,t:1526922858216};\\\", \\\"{x:832,y:488,t:1526922858233};\\\", \\\"{x:828,y:499,t:1526922858248};\\\", \\\"{x:823,y:510,t:1526922858265};\\\", \\\"{x:817,y:524,t:1526922858282};\\\", \\\"{x:811,y:534,t:1526922858299};\\\", \\\"{x:803,y:543,t:1526922858315};\\\", \\\"{x:794,y:548,t:1526922858331};\\\", \\\"{x:779,y:552,t:1526922858348};\\\", \\\"{x:757,y:553,t:1526922858365};\\\", \\\"{x:727,y:553,t:1526922858381};\\\", \\\"{x:700,y:553,t:1526922858398};\\\", \\\"{x:677,y:553,t:1526922858415};\\\", \\\"{x:651,y:553,t:1526922858432};\\\", \\\"{x:632,y:553,t:1526922858448};\\\", \\\"{x:618,y:553,t:1526922858465};\\\", \\\"{x:610,y:553,t:1526922858482};\\\", \\\"{x:604,y:553,t:1526922858499};\\\", \\\"{x:603,y:553,t:1526922858515};\\\", \\\"{x:602,y:554,t:1526922858563};\\\", \\\"{x:600,y:556,t:1526922858572};\\\", \\\"{x:595,y:558,t:1526922858583};\\\", \\\"{x:580,y:569,t:1526922858599};\\\", \\\"{x:551,y:586,t:1526922858615};\\\", \\\"{x:524,y:601,t:1526922858633};\\\", \\\"{x:508,y:609,t:1526922858648};\\\", \\\"{x:492,y:617,t:1526922858665};\\\", \\\"{x:466,y:625,t:1526922858683};\\\", \\\"{x:456,y:627,t:1526922858698};\\\", \\\"{x:431,y:634,t:1526922858715};\\\", \\\"{x:421,y:635,t:1526922858732};\\\", \\\"{x:409,y:635,t:1526922858748};\\\", \\\"{x:404,y:635,t:1526922858766};\\\", \\\"{x:402,y:635,t:1526922858782};\\\", \\\"{x:401,y:633,t:1526922858868};\\\", \\\"{x:401,y:631,t:1526922858884};\\\", \\\"{x:400,y:618,t:1526922858898};\\\", \\\"{x:400,y:601,t:1526922858915};\\\", \\\"{x:400,y:587,t:1526922858932};\\\", \\\"{x:400,y:576,t:1526922858948};\\\", \\\"{x:400,y:569,t:1526922858965};\\\", \\\"{x:400,y:562,t:1526922858983};\\\", \\\"{x:400,y:558,t:1526922858999};\\\", \\\"{x:400,y:555,t:1526922859016};\\\", \\\"{x:400,y:552,t:1526922859032};\\\", \\\"{x:400,y:551,t:1526922859049};\\\", \\\"{x:400,y:547,t:1526922859066};\\\", \\\"{x:400,y:546,t:1526922859115};\\\", \\\"{x:397,y:546,t:1526922859372};\\\", \\\"{x:395,y:548,t:1526922859383};\\\", \\\"{x:385,y:554,t:1526922859400};\\\", \\\"{x:373,y:559,t:1526922859417};\\\", \\\"{x:363,y:562,t:1526922859432};\\\", \\\"{x:349,y:566,t:1526922859450};\\\", \\\"{x:327,y:569,t:1526922859466};\\\", \\\"{x:306,y:569,t:1526922859483};\\\", \\\"{x:280,y:569,t:1526922859500};\\\", \\\"{x:254,y:568,t:1526922859518};\\\", \\\"{x:228,y:565,t:1526922859533};\\\", \\\"{x:210,y:562,t:1526922859549};\\\", \\\"{x:199,y:562,t:1526922859566};\\\", \\\"{x:195,y:561,t:1526922859582};\\\", \\\"{x:194,y:561,t:1526922859643};\\\", \\\"{x:193,y:561,t:1526922859651};\\\", \\\"{x:191,y:561,t:1526922859667};\\\", \\\"{x:187,y:563,t:1526922859683};\\\", \\\"{x:181,y:570,t:1526922859700};\\\", \\\"{x:177,y:581,t:1526922859716};\\\", \\\"{x:173,y:591,t:1526922859734};\\\", \\\"{x:171,y:604,t:1526922859750};\\\", \\\"{x:167,y:615,t:1526922859766};\\\", \\\"{x:165,y:620,t:1526922859783};\\\", \\\"{x:164,y:623,t:1526922859799};\\\", \\\"{x:163,y:626,t:1526922859817};\\\", \\\"{x:163,y:627,t:1526922859832};\\\", \\\"{x:163,y:629,t:1526922859851};\\\", \\\"{x:163,y:631,t:1526922859866};\\\", \\\"{x:162,y:632,t:1526922860000};\\\", \\\"{x:162,y:632,t:1526922860075};\\\", \\\"{x:161,y:632,t:1526922860091};\\\", \\\"{x:161,y:631,t:1526922860100};\\\", \\\"{x:161,y:628,t:1526922860116};\\\", \\\"{x:162,y:626,t:1526922860133};\\\", \\\"{x:164,y:623,t:1526922860150};\\\", \\\"{x:165,y:621,t:1526922860166};\\\", \\\"{x:166,y:620,t:1526922860602};\\\", \\\"{x:167,y:619,t:1526922860617};\\\", \\\"{x:168,y:619,t:1526922860633};\\\", \\\"{x:168,y:618,t:1526922860651};\\\", \\\"{x:170,y:618,t:1526922860667};\\\", \\\"{x:174,y:617,t:1526922860684};\\\", \\\"{x:178,y:615,t:1526922860701};\\\", \\\"{x:186,y:614,t:1526922860717};\\\", \\\"{x:193,y:613,t:1526922860734};\\\", \\\"{x:205,y:613,t:1526922860750};\\\", \\\"{x:224,y:613,t:1526922860766};\\\", \\\"{x:249,y:613,t:1526922860783};\\\", \\\"{x:284,y:622,t:1526922860800};\\\", \\\"{x:342,y:628,t:1526922860816};\\\", \\\"{x:409,y:638,t:1526922860834};\\\", \\\"{x:516,y:652,t:1526922860850};\\\", \\\"{x:580,y:661,t:1526922860867};\\\", \\\"{x:642,y:664,t:1526922860883};\\\", \\\"{x:693,y:666,t:1526922860900};\\\", \\\"{x:726,y:666,t:1526922860918};\\\", \\\"{x:751,y:666,t:1526922860933};\\\", \\\"{x:766,y:666,t:1526922860951};\\\", \\\"{x:773,y:666,t:1526922860966};\\\", \\\"{x:778,y:665,t:1526922860983};\\\", \\\"{x:779,y:665,t:1526922861000};\\\", \\\"{x:779,y:663,t:1526922861017};\\\", \\\"{x:779,y:659,t:1526922861034};\\\", \\\"{x:779,y:651,t:1526922861050};\\\", \\\"{x:778,y:624,t:1526922861068};\\\", \\\"{x:771,y:600,t:1526922861084};\\\", \\\"{x:766,y:582,t:1526922861100};\\\", \\\"{x:761,y:564,t:1526922861117};\\\", \\\"{x:756,y:553,t:1526922861135};\\\", \\\"{x:755,y:548,t:1526922861150};\\\", \\\"{x:753,y:544,t:1526922861167};\\\", \\\"{x:753,y:541,t:1526922861184};\\\", \\\"{x:753,y:537,t:1526922861200};\\\", \\\"{x:753,y:536,t:1526922861217};\\\", \\\"{x:753,y:535,t:1526922861331};\\\", \\\"{x:753,y:532,t:1526922861339};\\\", \\\"{x:755,y:532,t:1526922861355};\\\", \\\"{x:756,y:531,t:1526922861367};\\\", \\\"{x:761,y:530,t:1526922861384};\\\", \\\"{x:766,y:529,t:1526922861401};\\\", \\\"{x:772,y:528,t:1526922861418};\\\", \\\"{x:780,y:527,t:1526922861434};\\\", \\\"{x:797,y:527,t:1526922861451};\\\", \\\"{x:809,y:527,t:1526922861467};\\\", \\\"{x:824,y:527,t:1526922861484};\\\", \\\"{x:844,y:527,t:1526922861501};\\\", \\\"{x:866,y:527,t:1526922861517};\\\", \\\"{x:883,y:526,t:1526922861534};\\\", \\\"{x:902,y:526,t:1526922861550};\\\", \\\"{x:920,y:526,t:1526922861568};\\\", \\\"{x:933,y:526,t:1526922861583};\\\", \\\"{x:940,y:526,t:1526922861601};\\\", \\\"{x:939,y:526,t:1526922861667};\\\", \\\"{x:932,y:527,t:1526922861683};\\\", \\\"{x:920,y:527,t:1526922861701};\\\", \\\"{x:899,y:527,t:1526922861717};\\\", \\\"{x:879,y:527,t:1526922861734};\\\", \\\"{x:858,y:530,t:1526922861752};\\\", \\\"{x:833,y:534,t:1526922861769};\\\", \\\"{x:806,y:538,t:1526922861785};\\\", \\\"{x:780,y:541,t:1526922861802};\\\", \\\"{x:751,y:547,t:1526922861818};\\\", \\\"{x:704,y:554,t:1526922861837};\\\", \\\"{x:681,y:557,t:1526922861853};\\\", \\\"{x:660,y:559,t:1526922861868};\\\", \\\"{x:630,y:569,t:1526922861884};\\\", \\\"{x:599,y:578,t:1526922861902};\\\", \\\"{x:578,y:583,t:1526922861918};\\\", \\\"{x:572,y:585,t:1526922861934};\\\", \\\"{x:567,y:586,t:1526922861951};\\\", \\\"{x:563,y:586,t:1526922861968};\\\", \\\"{x:558,y:586,t:1526922861986};\\\", \\\"{x:553,y:586,t:1526922862001};\\\", \\\"{x:538,y:584,t:1526922862019};\\\", \\\"{x:524,y:580,t:1526922862034};\\\", \\\"{x:508,y:575,t:1526922862052};\\\", \\\"{x:495,y:572,t:1526922862069};\\\", \\\"{x:485,y:569,t:1526922862085};\\\", \\\"{x:476,y:564,t:1526922862103};\\\", \\\"{x:465,y:560,t:1526922862119};\\\", \\\"{x:451,y:554,t:1526922862136};\\\", \\\"{x:436,y:547,t:1526922862151};\\\", \\\"{x:432,y:545,t:1526922862168};\\\", \\\"{x:431,y:545,t:1526922862195};\\\", \\\"{x:430,y:543,t:1526922862220};\\\", \\\"{x:429,y:539,t:1526922862235};\\\", \\\"{x:428,y:536,t:1526922862252};\\\", \\\"{x:427,y:533,t:1526922862268};\\\", \\\"{x:424,y:527,t:1526922862284};\\\", \\\"{x:424,y:523,t:1526922862304};\\\", \\\"{x:423,y:520,t:1526922862319};\\\", \\\"{x:423,y:518,t:1526922862335};\\\", \\\"{x:423,y:513,t:1526922862352};\\\", \\\"{x:421,y:508,t:1526922862369};\\\", \\\"{x:421,y:503,t:1526922862385};\\\", \\\"{x:420,y:499,t:1526922862401};\\\", \\\"{x:420,y:496,t:1526922862418};\\\", \\\"{x:419,y:492,t:1526922862434};\\\", \\\"{x:417,y:490,t:1526922862451};\\\", \\\"{x:416,y:488,t:1526922862469};\\\", \\\"{x:415,y:488,t:1526922862588};\\\", \\\"{x:414,y:488,t:1526922862602};\\\", \\\"{x:409,y:490,t:1526922862621};\\\", \\\"{x:406,y:493,t:1526922862635};\\\", \\\"{x:403,y:496,t:1526922862651};\\\", \\\"{x:402,y:499,t:1526922862668};\\\", \\\"{x:401,y:501,t:1526922862686};\\\", \\\"{x:401,y:502,t:1526922862701};\\\", \\\"{x:400,y:506,t:1526922862718};\\\", \\\"{x:400,y:507,t:1526922862736};\\\", \\\"{x:400,y:510,t:1526922862751};\\\", \\\"{x:400,y:513,t:1526922862769};\\\", \\\"{x:400,y:517,t:1526922862785};\\\", \\\"{x:402,y:520,t:1526922862802};\\\", \\\"{x:405,y:525,t:1526922862819};\\\", \\\"{x:408,y:529,t:1526922862836};\\\", \\\"{x:409,y:533,t:1526922862853};\\\", \\\"{x:411,y:536,t:1526922862868};\\\", \\\"{x:413,y:538,t:1526922862886};\\\", \\\"{x:414,y:540,t:1526922862902};\\\", \\\"{x:415,y:542,t:1526922862918};\\\", \\\"{x:415,y:543,t:1526922862935};\\\", \\\"{x:415,y:545,t:1526922862952};\\\", \\\"{x:415,y:548,t:1526922862969};\\\", \\\"{x:415,y:549,t:1526922862987};\\\", \\\"{x:411,y:552,t:1526922863003};\\\", \\\"{x:394,y:552,t:1526922863020};\\\", \\\"{x:365,y:552,t:1526922863035};\\\", \\\"{x:323,y:552,t:1526922863052};\\\", \\\"{x:279,y:549,t:1526922863070};\\\", \\\"{x:232,y:543,t:1526922863086};\\\", \\\"{x:197,y:540,t:1526922863102};\\\", \\\"{x:172,y:536,t:1526922863119};\\\", \\\"{x:151,y:531,t:1526922863135};\\\", \\\"{x:139,y:527,t:1526922863153};\\\", \\\"{x:138,y:527,t:1526922863170};\\\", \\\"{x:137,y:527,t:1526922863185};\\\", \\\"{x:137,y:528,t:1526922863267};\\\", \\\"{x:140,y:531,t:1526922863275};\\\", \\\"{x:146,y:532,t:1526922863286};\\\", \\\"{x:163,y:537,t:1526922863304};\\\", \\\"{x:193,y:544,t:1526922863319};\\\", \\\"{x:251,y:561,t:1526922863336};\\\", \\\"{x:309,y:574,t:1526922863353};\\\", \\\"{x:373,y:582,t:1526922863370};\\\", \\\"{x:442,y:593,t:1526922863385};\\\", \\\"{x:536,y:606,t:1526922863403};\\\", \\\"{x:584,y:614,t:1526922863419};\\\", \\\"{x:620,y:618,t:1526922863435};\\\", \\\"{x:644,y:618,t:1526922863452};\\\", \\\"{x:661,y:618,t:1526922863470};\\\", \\\"{x:667,y:618,t:1526922863486};\\\", \\\"{x:670,y:616,t:1526922863502};\\\", \\\"{x:670,y:615,t:1526922863519};\\\", \\\"{x:671,y:613,t:1526922863535};\\\", \\\"{x:671,y:611,t:1526922863552};\\\", \\\"{x:671,y:609,t:1526922863570};\\\", \\\"{x:671,y:603,t:1526922863586};\\\", \\\"{x:671,y:601,t:1526922863602};\\\", \\\"{x:671,y:597,t:1526922863620};\\\", \\\"{x:671,y:595,t:1526922863636};\\\", \\\"{x:670,y:591,t:1526922863653};\\\", \\\"{x:669,y:587,t:1526922863670};\\\", \\\"{x:668,y:580,t:1526922863687};\\\", \\\"{x:664,y:576,t:1526922863703};\\\", \\\"{x:664,y:573,t:1526922863719};\\\", \\\"{x:664,y:570,t:1526922863737};\\\", \\\"{x:664,y:568,t:1526922863752};\\\", \\\"{x:664,y:565,t:1526922863769};\\\", \\\"{x:664,y:563,t:1526922863787};\\\", \\\"{x:664,y:561,t:1526922863804};\\\", \\\"{x:664,y:560,t:1526922863819};\\\", \\\"{x:662,y:558,t:1526922863836};\\\", \\\"{x:662,y:557,t:1526922863858};\\\", \\\"{x:662,y:556,t:1526922863870};\\\", \\\"{x:662,y:555,t:1526922863887};\\\", \\\"{x:662,y:554,t:1526922863904};\\\", \\\"{x:662,y:553,t:1526922863919};\\\", \\\"{x:662,y:552,t:1526922863937};\\\", \\\"{x:662,y:551,t:1526922863952};\\\", \\\"{x:658,y:551,t:1526922864347};\\\", \\\"{x:653,y:556,t:1526922864356};\\\", \\\"{x:649,y:569,t:1526922864371};\\\", \\\"{x:643,y:589,t:1526922864386};\\\", \\\"{x:643,y:611,t:1526922864404};\\\", \\\"{x:643,y:628,t:1526922864420};\\\", \\\"{x:643,y:635,t:1526922864437};\\\", \\\"{x:643,y:636,t:1526922864522};\\\", \\\"{x:643,y:635,t:1526922864554};\\\", \\\"{x:644,y:629,t:1526922864571};\\\", \\\"{x:649,y:618,t:1526922864586};\\\", \\\"{x:651,y:611,t:1526922864604};\\\", \\\"{x:652,y:608,t:1526922864620};\\\", \\\"{x:652,y:607,t:1526922864637};\\\", \\\"{x:650,y:614,t:1526922864875};\\\", \\\"{x:644,y:627,t:1526922864887};\\\", \\\"{x:628,y:648,t:1526922864904};\\\", \\\"{x:609,y:671,t:1526922864921};\\\", \\\"{x:594,y:688,t:1526922864937};\\\", \\\"{x:577,y:705,t:1526922864954};\\\", \\\"{x:559,y:729,t:1526922864970};\\\", \\\"{x:554,y:731,t:1526922864987};\\\", \\\"{x:550,y:733,t:1526922865003};\\\", \\\"{x:549,y:733,t:1526922865027};\\\", \\\"{x:549,y:731,t:1526922865067};\\\", \\\"{x:549,y:729,t:1526922865074};\\\", \\\"{x:551,y:723,t:1526922865087};\\\", \\\"{x:558,y:709,t:1526922865104};\\\", \\\"{x:571,y:692,t:1526922865121};\\\", \\\"{x:583,y:676,t:1526922865138};\\\", \\\"{x:597,y:654,t:1526922865153};\\\", \\\"{x:616,y:628,t:1526922865171};\\\", \\\"{x:626,y:617,t:1526922865188};\\\", \\\"{x:630,y:611,t:1526922865203};\\\", \\\"{x:631,y:606,t:1526922865220};\\\", \\\"{x:632,y:605,t:1526922865237};\\\", \\\"{x:632,y:603,t:1526922865254};\\\", \\\"{x:632,y:602,t:1526922865270};\\\", \\\"{x:631,y:602,t:1526922865347};\\\", \\\"{x:630,y:602,t:1526922865355};\\\", \\\"{x:625,y:602,t:1526922865371};\\\", \\\"{x:616,y:607,t:1526922865388};\\\", \\\"{x:610,y:610,t:1526922865405};\\\", \\\"{x:607,y:613,t:1526922865421};\\\", \\\"{x:605,y:615,t:1526922865437};\\\", \\\"{x:604,y:615,t:1526922865454};\\\", \\\"{x:603,y:615,t:1526922865471};\\\", \\\"{x:603,y:616,t:1526922865649};\\\", \\\"{x:604,y:616,t:1526922865654};\\\", \\\"{x:604,y:617,t:1526922865714};\\\", \\\"{x:600,y:623,t:1526922865723};\\\", \\\"{x:593,y:633,t:1526922865738};\\\", \\\"{x:565,y:666,t:1526922865754};\\\", \\\"{x:545,y:687,t:1526922865772};\\\", \\\"{x:526,y:703,t:1526922865787};\\\", \\\"{x:515,y:713,t:1526922865805};\\\", \\\"{x:506,y:727,t:1526922865822};\\\", \\\"{x:502,y:731,t:1526922865837};\\\", \\\"{x:501,y:733,t:1526922865854};\\\", \\\"{x:501,y:732,t:1526922865916};\\\", \\\"{x:501,y:730,t:1526922865923};\\\", \\\"{x:502,y:728,t:1526922865938};\\\", \\\"{x:505,y:725,t:1526922865955};\\\", \\\"{x:506,y:724,t:1526922865971};\\\", \\\"{x:506,y:723,t:1526922866026};\\\", \\\"{x:507,y:723,t:1526922866037};\\\", \\\"{x:507,y:723,t:1526922866104};\\\", \\\"{x:507,y:720,t:1526922866611};\\\", \\\"{x:505,y:716,t:1526922866622};\\\", \\\"{x:505,y:706,t:1526922866639};\\\", \\\"{x:504,y:697,t:1526922866654};\\\", \\\"{x:503,y:690,t:1526922866671};\\\", \\\"{x:501,y:683,t:1526922866689};\\\", \\\"{x:499,y:676,t:1526922866704};\\\", \\\"{x:497,y:672,t:1526922866721};\\\", \\\"{x:496,y:670,t:1526922866738};\\\", \\\"{x:495,y:669,t:1526922866755};\\\", \\\"{x:494,y:669,t:1526922866794};\\\", \\\"{x:493,y:670,t:1526922866819};\\\", \\\"{x:491,y:670,t:1526922866851};\\\", \\\"{x:489,y:672,t:1526922866963};\\\", \\\"{x:488,y:672,t:1526922866972};\\\", \\\"{x:485,y:674,t:1526922866989};\\\", \\\"{x:483,y:674,t:1526922867006};\\\", \\\"{x:481,y:676,t:1526922867021};\\\", \\\"{x:480,y:676,t:1526922867039};\\\", \\\"{x:478,y:677,t:1526922867059};\\\", \\\"{x:477,y:678,t:1526922867072};\\\", \\\"{x:476,y:678,t:1526922867112};\\\", \\\"{x:475,y:679,t:1526922867139};\\\", \\\"{x:474,y:679,t:1526922867162};\\\", \\\"{x:473,y:679,t:1526922867178};\\\" ] }, { \\\"rt\\\": 35195, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 514036, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 4.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"O\\\", \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -I -J -J -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:444,y:665,t:1526922867299};\\\", \\\"{x:439,y:661,t:1526922867310};\\\", \\\"{x:435,y:655,t:1526922867327};\\\", \\\"{x:431,y:648,t:1526922867339};\\\", \\\"{x:427,y:643,t:1526922867356};\\\", \\\"{x:423,y:636,t:1526922867373};\\\", \\\"{x:421,y:631,t:1526922867391};\\\", \\\"{x:417,y:624,t:1526922867405};\\\", \\\"{x:414,y:619,t:1526922867423};\\\", \\\"{x:411,y:614,t:1526922867438};\\\", \\\"{x:409,y:611,t:1526922867455};\\\", \\\"{x:408,y:609,t:1526922867473};\\\", \\\"{x:405,y:606,t:1526922867490};\\\", \\\"{x:404,y:605,t:1526922867506};\\\", \\\"{x:403,y:602,t:1526922868374};\\\", \\\"{x:400,y:596,t:1526922868384};\\\", \\\"{x:395,y:580,t:1526922868400};\\\", \\\"{x:385,y:559,t:1526922868417};\\\", \\\"{x:377,y:536,t:1526922868433};\\\", \\\"{x:365,y:509,t:1526922868450};\\\", \\\"{x:347,y:477,t:1526922868467};\\\", \\\"{x:329,y:445,t:1526922868483};\\\", \\\"{x:317,y:420,t:1526922868499};\\\", \\\"{x:298,y:386,t:1526922868515};\\\", \\\"{x:285,y:368,t:1526922868533};\\\", \\\"{x:275,y:353,t:1526922868549};\\\", \\\"{x:264,y:338,t:1526922868566};\\\", \\\"{x:255,y:326,t:1526922868583};\\\", \\\"{x:247,y:312,t:1526922868599};\\\", \\\"{x:239,y:302,t:1526922868616};\\\", \\\"{x:233,y:292,t:1526922868633};\\\", \\\"{x:228,y:282,t:1526922868649};\\\", \\\"{x:225,y:274,t:1526922868666};\\\", \\\"{x:221,y:265,t:1526922868683};\\\", \\\"{x:217,y:255,t:1526922868699};\\\", \\\"{x:214,y:246,t:1526922868716};\\\", \\\"{x:212,y:242,t:1526922868733};\\\", \\\"{x:208,y:235,t:1526922868749};\\\", \\\"{x:205,y:231,t:1526922868766};\\\", \\\"{x:203,y:227,t:1526922868784};\\\", \\\"{x:200,y:222,t:1526922868801};\\\", \\\"{x:196,y:216,t:1526922868816};\\\", \\\"{x:193,y:210,t:1526922868833};\\\", \\\"{x:191,y:206,t:1526922868850};\\\", \\\"{x:188,y:200,t:1526922868867};\\\", \\\"{x:187,y:196,t:1526922868883};\\\", \\\"{x:183,y:187,t:1526922868900};\\\", \\\"{x:178,y:178,t:1526922868916};\\\", \\\"{x:176,y:171,t:1526922868933};\\\", \\\"{x:175,y:165,t:1526922868950};\\\", \\\"{x:173,y:158,t:1526922868966};\\\", \\\"{x:173,y:153,t:1526922868983};\\\", \\\"{x:172,y:150,t:1526922869001};\\\", \\\"{x:171,y:147,t:1526922869016};\\\", \\\"{x:171,y:144,t:1526922869033};\\\", \\\"{x:170,y:143,t:1526922869050};\\\", \\\"{x:168,y:141,t:1526922869067};\\\", \\\"{x:166,y:138,t:1526922869084};\\\", \\\"{x:162,y:133,t:1526922869101};\\\", \\\"{x:157,y:130,t:1526922869117};\\\", \\\"{x:155,y:128,t:1526922869134};\\\", \\\"{x:154,y:128,t:1526922869151};\\\", \\\"{x:153,y:126,t:1526922869166};\\\", \\\"{x:151,y:126,t:1526922869405};\\\", \\\"{x:150,y:126,t:1526922869429};\\\", \\\"{x:149,y:126,t:1526922869452};\\\", \\\"{x:148,y:127,t:1526922869468};\\\", \\\"{x:146,y:129,t:1526922869565};\\\", \\\"{x:145,y:130,t:1526922869653};\\\", \\\"{x:146,y:132,t:1526922878661};\\\", \\\"{x:160,y:138,t:1526922878674};\\\", \\\"{x:239,y:166,t:1526922878691};\\\", \\\"{x:348,y:206,t:1526922878707};\\\", \\\"{x:570,y:274,t:1526922878724};\\\", \\\"{x:740,y:317,t:1526922878740};\\\", \\\"{x:895,y:356,t:1526922878758};\\\", \\\"{x:1034,y:382,t:1526922878774};\\\", \\\"{x:1159,y:403,t:1526922878791};\\\", \\\"{x:1247,y:424,t:1526922878809};\\\", \\\"{x:1286,y:433,t:1526922878825};\\\", \\\"{x:1297,y:438,t:1526922878841};\\\", \\\"{x:1300,y:441,t:1526922878858};\\\", \\\"{x:1300,y:445,t:1526922878874};\\\", \\\"{x:1296,y:452,t:1526922878892};\\\", \\\"{x:1294,y:461,t:1526922878908};\\\", \\\"{x:1294,y:485,t:1526922878924};\\\", \\\"{x:1299,y:509,t:1526922878940};\\\", \\\"{x:1319,y:539,t:1526922878958};\\\", \\\"{x:1349,y:581,t:1526922878974};\\\", \\\"{x:1376,y:623,t:1526922878990};\\\", \\\"{x:1412,y:662,t:1526922879007};\\\", \\\"{x:1431,y:675,t:1526922879024};\\\", \\\"{x:1474,y:712,t:1526922879041};\\\", \\\"{x:1505,y:742,t:1526922879058};\\\", \\\"{x:1551,y:786,t:1526922879073};\\\", \\\"{x:1600,y:824,t:1526922879091};\\\", \\\"{x:1676,y:871,t:1526922879108};\\\", \\\"{x:1728,y:899,t:1526922879124};\\\", \\\"{x:1764,y:916,t:1526922879140};\\\", \\\"{x:1786,y:924,t:1526922879158};\\\", \\\"{x:1799,y:926,t:1526922879174};\\\", \\\"{x:1802,y:926,t:1526922879191};\\\", \\\"{x:1802,y:927,t:1526922879208};\\\", \\\"{x:1802,y:922,t:1526922879252};\\\", \\\"{x:1802,y:915,t:1526922879261};\\\", \\\"{x:1802,y:908,t:1526922879275};\\\", \\\"{x:1795,y:889,t:1526922879291};\\\", \\\"{x:1762,y:866,t:1526922879309};\\\", \\\"{x:1742,y:854,t:1526922879324};\\\", \\\"{x:1724,y:843,t:1526922879341};\\\", \\\"{x:1714,y:837,t:1526922879358};\\\", \\\"{x:1707,y:833,t:1526922879375};\\\", \\\"{x:1704,y:832,t:1526922879391};\\\", \\\"{x:1703,y:831,t:1526922879409};\\\", \\\"{x:1702,y:831,t:1526922879821};\\\", \\\"{x:1700,y:831,t:1526922879829};\\\", \\\"{x:1697,y:832,t:1526922879842};\\\", \\\"{x:1687,y:836,t:1526922879858};\\\", \\\"{x:1674,y:840,t:1526922879876};\\\", \\\"{x:1647,y:848,t:1526922879893};\\\", \\\"{x:1628,y:853,t:1526922879908};\\\", \\\"{x:1605,y:861,t:1526922879925};\\\", \\\"{x:1581,y:870,t:1526922879942};\\\", \\\"{x:1559,y:881,t:1526922879958};\\\", \\\"{x:1535,y:891,t:1526922879975};\\\", \\\"{x:1511,y:901,t:1526922879993};\\\", \\\"{x:1490,y:908,t:1526922880008};\\\", \\\"{x:1473,y:912,t:1526922880026};\\\", \\\"{x:1454,y:919,t:1526922880043};\\\", \\\"{x:1439,y:921,t:1526922880059};\\\", \\\"{x:1426,y:923,t:1526922880076};\\\", \\\"{x:1410,y:925,t:1526922880093};\\\", \\\"{x:1402,y:925,t:1526922880109};\\\", \\\"{x:1397,y:925,t:1526922880126};\\\", \\\"{x:1390,y:919,t:1526922880142};\\\", \\\"{x:1387,y:912,t:1526922880158};\\\", \\\"{x:1380,y:896,t:1526922880178};\\\", \\\"{x:1375,y:879,t:1526922880194};\\\", \\\"{x:1366,y:860,t:1526922880210};\\\", \\\"{x:1358,y:837,t:1526922880225};\\\", \\\"{x:1339,y:802,t:1526922880243};\\\", \\\"{x:1325,y:775,t:1526922880259};\\\", \\\"{x:1316,y:760,t:1526922880275};\\\", \\\"{x:1315,y:750,t:1526922880292};\\\", \\\"{x:1315,y:747,t:1526922880309};\\\", \\\"{x:1315,y:746,t:1526922880325};\\\", \\\"{x:1315,y:744,t:1526922880342};\\\", \\\"{x:1315,y:743,t:1526922880380};\\\", \\\"{x:1315,y:744,t:1526922880477};\\\", \\\"{x:1315,y:751,t:1526922880493};\\\", \\\"{x:1315,y:758,t:1526922880509};\\\", \\\"{x:1315,y:768,t:1526922880525};\\\", \\\"{x:1315,y:778,t:1526922880542};\\\", \\\"{x:1315,y:786,t:1526922880560};\\\", \\\"{x:1311,y:793,t:1526922880575};\\\", \\\"{x:1310,y:795,t:1526922880592};\\\", \\\"{x:1309,y:795,t:1526922880610};\\\", \\\"{x:1308,y:795,t:1526922880644};\\\", \\\"{x:1307,y:795,t:1526922880659};\\\", \\\"{x:1305,y:795,t:1526922880677};\\\", \\\"{x:1303,y:794,t:1526922880692};\\\", \\\"{x:1301,y:790,t:1526922880709};\\\", \\\"{x:1300,y:786,t:1526922880727};\\\", \\\"{x:1299,y:782,t:1526922880742};\\\", \\\"{x:1299,y:777,t:1526922880760};\\\", \\\"{x:1299,y:775,t:1526922880776};\\\", \\\"{x:1302,y:772,t:1526922880792};\\\", \\\"{x:1304,y:770,t:1526922880810};\\\", \\\"{x:1307,y:767,t:1526922880827};\\\", \\\"{x:1310,y:765,t:1526922880842};\\\", \\\"{x:1310,y:763,t:1526922880860};\\\", \\\"{x:1312,y:762,t:1526922880876};\\\", \\\"{x:1309,y:762,t:1526922881109};\\\", \\\"{x:1297,y:762,t:1526922881127};\\\", \\\"{x:1288,y:762,t:1526922881143};\\\", \\\"{x:1284,y:762,t:1526922881159};\\\", \\\"{x:1279,y:763,t:1526922881177};\\\", \\\"{x:1274,y:765,t:1526922881194};\\\", \\\"{x:1272,y:767,t:1526922881209};\\\", \\\"{x:1269,y:767,t:1526922881227};\\\", \\\"{x:1266,y:769,t:1526922881243};\\\", \\\"{x:1265,y:770,t:1526922881259};\\\", \\\"{x:1260,y:771,t:1526922881277};\\\", \\\"{x:1255,y:773,t:1526922881292};\\\", \\\"{x:1250,y:773,t:1526922881309};\\\", \\\"{x:1238,y:773,t:1526922881325};\\\", \\\"{x:1223,y:773,t:1526922881343};\\\", \\\"{x:1218,y:773,t:1526922881358};\\\", \\\"{x:1211,y:773,t:1526922881375};\\\", \\\"{x:1206,y:773,t:1526922881392};\\\", \\\"{x:1195,y:773,t:1526922881409};\\\", \\\"{x:1181,y:771,t:1526922881425};\\\", \\\"{x:1176,y:769,t:1526922881443};\\\", \\\"{x:1175,y:769,t:1526922881458};\\\", \\\"{x:1174,y:768,t:1526922881508};\\\", \\\"{x:1174,y:767,t:1526922881516};\\\", \\\"{x:1174,y:766,t:1526922881526};\\\", \\\"{x:1174,y:764,t:1526922881542};\\\", \\\"{x:1174,y:763,t:1526922881559};\\\", \\\"{x:1174,y:762,t:1526922881576};\\\", \\\"{x:1174,y:761,t:1526922881593};\\\", \\\"{x:1174,y:760,t:1526922881610};\\\", \\\"{x:1174,y:758,t:1526922881626};\\\", \\\"{x:1174,y:757,t:1526922881653};\\\", \\\"{x:1175,y:756,t:1526922881701};\\\", \\\"{x:1176,y:756,t:1526922882286};\\\", \\\"{x:1177,y:756,t:1526922882294};\\\", \\\"{x:1183,y:756,t:1526922882311};\\\", \\\"{x:1188,y:755,t:1526922882326};\\\", \\\"{x:1196,y:753,t:1526922882343};\\\", \\\"{x:1200,y:753,t:1526922882360};\\\", \\\"{x:1204,y:753,t:1526922882377};\\\", \\\"{x:1212,y:753,t:1526922882393};\\\", \\\"{x:1216,y:751,t:1526922882410};\\\", \\\"{x:1222,y:751,t:1526922882427};\\\", \\\"{x:1229,y:751,t:1526922882443};\\\", \\\"{x:1239,y:751,t:1526922882459};\\\", \\\"{x:1245,y:751,t:1526922882477};\\\", \\\"{x:1250,y:751,t:1526922882492};\\\", \\\"{x:1258,y:751,t:1526922882510};\\\", \\\"{x:1269,y:754,t:1526922882527};\\\", \\\"{x:1283,y:758,t:1526922882544};\\\", \\\"{x:1300,y:762,t:1526922882560};\\\", \\\"{x:1315,y:766,t:1526922882577};\\\", \\\"{x:1329,y:770,t:1526922882594};\\\", \\\"{x:1345,y:775,t:1526922882610};\\\", \\\"{x:1356,y:779,t:1526922882628};\\\", \\\"{x:1372,y:782,t:1526922882644};\\\", \\\"{x:1373,y:783,t:1526922882660};\\\", \\\"{x:1374,y:784,t:1526922882700};\\\", \\\"{x:1370,y:784,t:1526922882725};\\\", \\\"{x:1364,y:784,t:1526922882731};\\\", \\\"{x:1355,y:784,t:1526922882743};\\\", \\\"{x:1330,y:783,t:1526922882759};\\\", \\\"{x:1304,y:777,t:1526922882777};\\\", \\\"{x:1285,y:772,t:1526922882794};\\\", \\\"{x:1277,y:771,t:1526922882810};\\\", \\\"{x:1271,y:771,t:1526922882827};\\\", \\\"{x:1270,y:771,t:1526922882843};\\\", \\\"{x:1268,y:771,t:1526922883045};\\\", \\\"{x:1261,y:769,t:1526922883060};\\\", \\\"{x:1250,y:766,t:1526922883078};\\\", \\\"{x:1244,y:765,t:1526922883094};\\\", \\\"{x:1243,y:765,t:1526922883165};\\\", \\\"{x:1243,y:767,t:1526922883405};\\\", \\\"{x:1241,y:771,t:1526922883412};\\\", \\\"{x:1240,y:774,t:1526922883428};\\\", \\\"{x:1236,y:787,t:1526922883444};\\\", \\\"{x:1232,y:795,t:1526922883461};\\\", \\\"{x:1229,y:801,t:1526922883477};\\\", \\\"{x:1226,y:804,t:1526922883494};\\\", \\\"{x:1223,y:808,t:1526922883511};\\\", \\\"{x:1221,y:810,t:1526922883528};\\\", \\\"{x:1220,y:814,t:1526922883544};\\\", \\\"{x:1216,y:817,t:1526922883560};\\\", \\\"{x:1215,y:818,t:1526922883578};\\\", \\\"{x:1213,y:821,t:1526922883594};\\\", \\\"{x:1211,y:824,t:1526922883611};\\\", \\\"{x:1210,y:827,t:1526922883628};\\\", \\\"{x:1209,y:828,t:1526922883644};\\\", \\\"{x:1209,y:830,t:1526922883661};\\\", \\\"{x:1209,y:831,t:1526922883678};\\\", \\\"{x:1208,y:831,t:1526922883798};\\\", \\\"{x:1207,y:831,t:1526922883820};\\\", \\\"{x:1206,y:831,t:1526922883845};\\\", \\\"{x:1205,y:831,t:1526922883861};\\\", \\\"{x:1203,y:830,t:1526922883879};\\\", \\\"{x:1203,y:829,t:1526922883895};\\\", \\\"{x:1203,y:827,t:1526922883911};\\\", \\\"{x:1203,y:825,t:1526922883929};\\\", \\\"{x:1203,y:823,t:1526922883945};\\\", \\\"{x:1203,y:822,t:1526922883962};\\\", \\\"{x:1203,y:821,t:1526922883978};\\\", \\\"{x:1203,y:820,t:1526922883995};\\\", \\\"{x:1203,y:819,t:1526922884013};\\\", \\\"{x:1203,y:818,t:1526922884757};\\\", \\\"{x:1203,y:817,t:1526922884764};\\\", \\\"{x:1203,y:816,t:1526922884778};\\\", \\\"{x:1203,y:814,t:1526922884795};\\\", \\\"{x:1204,y:813,t:1526922884812};\\\", \\\"{x:1204,y:812,t:1526922884828};\\\", \\\"{x:1205,y:810,t:1526922884846};\\\", \\\"{x:1212,y:808,t:1526922884863};\\\", \\\"{x:1220,y:804,t:1526922884878};\\\", \\\"{x:1236,y:801,t:1526922884895};\\\", \\\"{x:1257,y:801,t:1526922884912};\\\", \\\"{x:1281,y:807,t:1526922884930};\\\", \\\"{x:1307,y:809,t:1526922884945};\\\", \\\"{x:1329,y:814,t:1526922884962};\\\", \\\"{x:1351,y:818,t:1526922884979};\\\", \\\"{x:1376,y:820,t:1526922884996};\\\", \\\"{x:1409,y:825,t:1526922885012};\\\", \\\"{x:1430,y:829,t:1526922885029};\\\", \\\"{x:1443,y:830,t:1526922885046};\\\", \\\"{x:1451,y:831,t:1526922885063};\\\", \\\"{x:1454,y:831,t:1526922885080};\\\", \\\"{x:1455,y:831,t:1526922885096};\\\", \\\"{x:1454,y:831,t:1526922885309};\\\", \\\"{x:1453,y:831,t:1526922885355};\\\", \\\"{x:1452,y:831,t:1526922885396};\\\", \\\"{x:1450,y:831,t:1526922885412};\\\", \\\"{x:1446,y:830,t:1526922885429};\\\", \\\"{x:1443,y:828,t:1526922885446};\\\", \\\"{x:1438,y:827,t:1526922885462};\\\", \\\"{x:1433,y:824,t:1526922885479};\\\", \\\"{x:1427,y:820,t:1526922885496};\\\", \\\"{x:1417,y:817,t:1526922885512};\\\", \\\"{x:1407,y:813,t:1526922885529};\\\", \\\"{x:1397,y:810,t:1526922885546};\\\", \\\"{x:1380,y:806,t:1526922885562};\\\", \\\"{x:1367,y:805,t:1526922885580};\\\", \\\"{x:1351,y:803,t:1526922885596};\\\", \\\"{x:1333,y:803,t:1526922885612};\\\", \\\"{x:1314,y:807,t:1526922885629};\\\", \\\"{x:1297,y:810,t:1526922885647};\\\", \\\"{x:1284,y:816,t:1526922885662};\\\", \\\"{x:1277,y:819,t:1526922885680};\\\", \\\"{x:1272,y:822,t:1526922885696};\\\", \\\"{x:1270,y:823,t:1526922885712};\\\", \\\"{x:1268,y:825,t:1526922885729};\\\", \\\"{x:1267,y:825,t:1526922885746};\\\", \\\"{x:1266,y:825,t:1526922885762};\\\", \\\"{x:1268,y:825,t:1526922885845};\\\", \\\"{x:1270,y:824,t:1526922885852};\\\", \\\"{x:1273,y:823,t:1526922885863};\\\", \\\"{x:1277,y:821,t:1526922885880};\\\", \\\"{x:1279,y:820,t:1526922885896};\\\", \\\"{x:1281,y:820,t:1526922885912};\\\", \\\"{x:1282,y:820,t:1526922886013};\\\", \\\"{x:1284,y:820,t:1526922886333};\\\", \\\"{x:1287,y:820,t:1526922886346};\\\", \\\"{x:1293,y:820,t:1526922886363};\\\", \\\"{x:1309,y:818,t:1526922886381};\\\", \\\"{x:1319,y:818,t:1526922886397};\\\", \\\"{x:1326,y:818,t:1526922886414};\\\", \\\"{x:1334,y:818,t:1526922886430};\\\", \\\"{x:1340,y:817,t:1526922886447};\\\", \\\"{x:1343,y:817,t:1526922886464};\\\", \\\"{x:1346,y:816,t:1526922886481};\\\", \\\"{x:1350,y:814,t:1526922886496};\\\", \\\"{x:1350,y:813,t:1526922886514};\\\", \\\"{x:1351,y:813,t:1526922886595};\\\", \\\"{x:1352,y:813,t:1526922886612};\\\", \\\"{x:1353,y:812,t:1526922886635};\\\", \\\"{x:1354,y:811,t:1526922886660};\\\", \\\"{x:1356,y:809,t:1526922886668};\\\", \\\"{x:1357,y:807,t:1526922886680};\\\", \\\"{x:1358,y:804,t:1526922886696};\\\", \\\"{x:1360,y:800,t:1526922886713};\\\", \\\"{x:1361,y:795,t:1526922886730};\\\", \\\"{x:1362,y:793,t:1526922886746};\\\", \\\"{x:1364,y:792,t:1526922886763};\\\", \\\"{x:1365,y:790,t:1526922886780};\\\", \\\"{x:1366,y:789,t:1526922886797};\\\", \\\"{x:1366,y:788,t:1526922886814};\\\", \\\"{x:1367,y:785,t:1526922886830};\\\", \\\"{x:1368,y:784,t:1526922886847};\\\", \\\"{x:1370,y:782,t:1526922886863};\\\", \\\"{x:1371,y:782,t:1526922886973};\\\", \\\"{x:1373,y:789,t:1526922886981};\\\", \\\"{x:1384,y:841,t:1526922886998};\\\", \\\"{x:1404,y:916,t:1526922887014};\\\", \\\"{x:1426,y:985,t:1526922887030};\\\", \\\"{x:1443,y:1054,t:1526922887047};\\\", \\\"{x:1454,y:1101,t:1526922887064};\\\", \\\"{x:1458,y:1130,t:1526922887080};\\\", \\\"{x:1461,y:1160,t:1526922887097};\\\", \\\"{x:1464,y:1189,t:1526922887114};\\\", \\\"{x:1465,y:1199,t:1526922887130};\\\", \\\"{x:1468,y:1199,t:1526922887143};\\\", \\\"{x:1469,y:1199,t:1526922887159};\\\", \\\"{x:1470,y:1199,t:1526922887176};\\\", \\\"{x:1471,y:1199,t:1526922887428};\\\", \\\"{x:1473,y:1199,t:1526922887468};\\\", \\\"{x:1476,y:1199,t:1526922887478};\\\", \\\"{x:1478,y:1199,t:1526922887494};\\\", \\\"{x:1480,y:1199,t:1526922887510};\\\", \\\"{x:1481,y:1199,t:1526922887527};\\\", \\\"{x:1481,y:1198,t:1526922892045};\\\", \\\"{x:1481,y:1197,t:1526922892054};\\\", \\\"{x:1481,y:1196,t:1526922892100};\\\", \\\"{x:1479,y:1196,t:1526922892117};\\\", \\\"{x:1475,y:1196,t:1526922892124};\\\", \\\"{x:1470,y:1199,t:1526922892139};\\\", \\\"{x:1458,y:1199,t:1526922892155};\\\", \\\"{x:1448,y:1199,t:1526922892172};\\\", \\\"{x:1441,y:1199,t:1526922892188};\\\", \\\"{x:1437,y:1199,t:1526922892204};\\\", \\\"{x:1434,y:1199,t:1526922892221};\\\", \\\"{x:1432,y:1199,t:1526922892239};\\\", \\\"{x:1431,y:1199,t:1526922892460};\\\", \\\"{x:1429,y:1199,t:1526922892484};\\\", \\\"{x:1425,y:1199,t:1526922892492};\\\", \\\"{x:1414,y:1199,t:1526922892506};\\\", \\\"{x:1354,y:1199,t:1526922892522};\\\", \\\"{x:1244,y:1199,t:1526922892539};\\\", \\\"{x:1139,y:1199,t:1526922892556};\\\", \\\"{x:1003,y:1199,t:1526922892573};\\\", \\\"{x:948,y:1199,t:1526922892590};\\\", \\\"{x:915,y:1199,t:1526922892605};\\\", \\\"{x:899,y:1199,t:1526922892622};\\\", \\\"{x:892,y:1199,t:1526922892640};\\\", \\\"{x:885,y:1192,t:1526922892656};\\\", \\\"{x:882,y:1188,t:1526922892673};\\\", \\\"{x:882,y:1185,t:1526922892690};\\\", \\\"{x:882,y:1170,t:1526922892706};\\\", \\\"{x:882,y:1154,t:1526922892723};\\\", \\\"{x:886,y:1138,t:1526922892735};\\\", \\\"{x:894,y:1124,t:1526922892753};\\\", \\\"{x:901,y:1116,t:1526922892770};\\\", \\\"{x:906,y:1114,t:1526922892786};\\\", \\\"{x:916,y:1118,t:1526922892802};\\\", \\\"{x:937,y:1153,t:1526922892819};\\\", \\\"{x:965,y:1199,t:1526922892836};\\\", \\\"{x:1004,y:1199,t:1526922892853};\\\", \\\"{x:1021,y:1199,t:1526922892870};\\\", \\\"{x:1032,y:1199,t:1526922892886};\\\", \\\"{x:1038,y:1199,t:1526922892902};\\\", \\\"{x:1040,y:1199,t:1526922892919};\\\", \\\"{x:1043,y:1197,t:1526922892956};\\\", \\\"{x:1050,y:1185,t:1526922892969};\\\", \\\"{x:1081,y:1133,t:1526922892987};\\\", \\\"{x:1137,y:1024,t:1526922893003};\\\", \\\"{x:1246,y:803,t:1526922893020};\\\", \\\"{x:1311,y:655,t:1526922893037};\\\", \\\"{x:1365,y:525,t:1526922893053};\\\", \\\"{x:1408,y:436,t:1526922893070};\\\", \\\"{x:1439,y:386,t:1526922893087};\\\", \\\"{x:1452,y:374,t:1526922893104};\\\", \\\"{x:1454,y:372,t:1526922893119};\\\", \\\"{x:1454,y:375,t:1526922893157};\\\", \\\"{x:1454,y:382,t:1526922893170};\\\", \\\"{x:1454,y:413,t:1526922893186};\\\", \\\"{x:1454,y:461,t:1526922893204};\\\", \\\"{x:1454,y:522,t:1526922893219};\\\", \\\"{x:1454,y:614,t:1526922893237};\\\", \\\"{x:1439,y:667,t:1526922893253};\\\", \\\"{x:1419,y:709,t:1526922893270};\\\", \\\"{x:1405,y:743,t:1526922893287};\\\", \\\"{x:1393,y:767,t:1526922893304};\\\", \\\"{x:1380,y:783,t:1526922893320};\\\", \\\"{x:1369,y:790,t:1526922893336};\\\", \\\"{x:1362,y:793,t:1526922893354};\\\", \\\"{x:1360,y:793,t:1526922893370};\\\", \\\"{x:1359,y:793,t:1526922893397};\\\", \\\"{x:1359,y:792,t:1526922893404};\\\", \\\"{x:1359,y:791,t:1526922893421};\\\", \\\"{x:1359,y:790,t:1526922893437};\\\", \\\"{x:1358,y:789,t:1526922893477};\\\", \\\"{x:1356,y:789,t:1526922893487};\\\", \\\"{x:1342,y:792,t:1526922893503};\\\", \\\"{x:1325,y:801,t:1526922893521};\\\", \\\"{x:1306,y:812,t:1526922893536};\\\", \\\"{x:1280,y:831,t:1526922893553};\\\", \\\"{x:1262,y:844,t:1526922893570};\\\", \\\"{x:1249,y:852,t:1526922893586};\\\", \\\"{x:1245,y:853,t:1526922893603};\\\", \\\"{x:1247,y:850,t:1526922893667};\\\", \\\"{x:1249,y:848,t:1526922893675};\\\", \\\"{x:1250,y:844,t:1526922893687};\\\", \\\"{x:1254,y:839,t:1526922893703};\\\", \\\"{x:1256,y:837,t:1526922893720};\\\", \\\"{x:1257,y:836,t:1526922893737};\\\", \\\"{x:1258,y:836,t:1526922893753};\\\", \\\"{x:1259,y:835,t:1526922893770};\\\", \\\"{x:1261,y:835,t:1526922893973};\\\", \\\"{x:1262,y:835,t:1526922893987};\\\", \\\"{x:1264,y:835,t:1526922894013};\\\", \\\"{x:1266,y:835,t:1526922894028};\\\", \\\"{x:1267,y:835,t:1526922894038};\\\", \\\"{x:1271,y:833,t:1526922894054};\\\", \\\"{x:1275,y:831,t:1526922894070};\\\", \\\"{x:1279,y:829,t:1526922894088};\\\", \\\"{x:1284,y:828,t:1526922894105};\\\", \\\"{x:1288,y:825,t:1526922894121};\\\", \\\"{x:1291,y:825,t:1526922894138};\\\", \\\"{x:1294,y:825,t:1526922894155};\\\", \\\"{x:1296,y:825,t:1526922894171};\\\", \\\"{x:1301,y:825,t:1526922894187};\\\", \\\"{x:1311,y:825,t:1526922894204};\\\", \\\"{x:1342,y:833,t:1526922894220};\\\", \\\"{x:1360,y:838,t:1526922894238};\\\", \\\"{x:1381,y:842,t:1526922894255};\\\", \\\"{x:1396,y:843,t:1526922894271};\\\", \\\"{x:1409,y:845,t:1526922894288};\\\", \\\"{x:1415,y:845,t:1526922894305};\\\", \\\"{x:1418,y:845,t:1526922894321};\\\", \\\"{x:1416,y:845,t:1526922894405};\\\", \\\"{x:1399,y:845,t:1526922894421};\\\", \\\"{x:1384,y:845,t:1526922894438};\\\", \\\"{x:1376,y:848,t:1526922894455};\\\", \\\"{x:1373,y:849,t:1526922894472};\\\", \\\"{x:1371,y:851,t:1526922894488};\\\", \\\"{x:1370,y:851,t:1526922894505};\\\", \\\"{x:1369,y:851,t:1526922894677};\\\", \\\"{x:1367,y:850,t:1526922894688};\\\", \\\"{x:1361,y:845,t:1526922894705};\\\", \\\"{x:1350,y:839,t:1526922894723};\\\", \\\"{x:1335,y:833,t:1526922894738};\\\", \\\"{x:1318,y:827,t:1526922894754};\\\", \\\"{x:1314,y:827,t:1526922894772};\\\", \\\"{x:1314,y:826,t:1526922894812};\\\", \\\"{x:1314,y:825,t:1526922894836};\\\", \\\"{x:1314,y:823,t:1526922894844};\\\", \\\"{x:1316,y:823,t:1526922894855};\\\", \\\"{x:1321,y:820,t:1526922894871};\\\", \\\"{x:1327,y:818,t:1526922894888};\\\", \\\"{x:1331,y:816,t:1526922894905};\\\", \\\"{x:1335,y:815,t:1526922894923};\\\", \\\"{x:1340,y:813,t:1526922894939};\\\", \\\"{x:1345,y:812,t:1526922894955};\\\", \\\"{x:1349,y:811,t:1526922894972};\\\", \\\"{x:1352,y:811,t:1526922894989};\\\", \\\"{x:1356,y:813,t:1526922895125};\\\", \\\"{x:1363,y:820,t:1526922895139};\\\", \\\"{x:1380,y:834,t:1526922895154};\\\", \\\"{x:1397,y:846,t:1526922895172};\\\", \\\"{x:1405,y:850,t:1526922895189};\\\", \\\"{x:1407,y:850,t:1526922895285};\\\", \\\"{x:1407,y:847,t:1526922895308};\\\", \\\"{x:1406,y:846,t:1526922895323};\\\", \\\"{x:1405,y:844,t:1526922895339};\\\", \\\"{x:1403,y:841,t:1526922895356};\\\", \\\"{x:1402,y:840,t:1526922895372};\\\", \\\"{x:1400,y:839,t:1526922895389};\\\", \\\"{x:1399,y:838,t:1526922895413};\\\", \\\"{x:1399,y:837,t:1526922895421};\\\", \\\"{x:1399,y:834,t:1526922895452};\\\", \\\"{x:1399,y:833,t:1526922895460};\\\", \\\"{x:1399,y:830,t:1526922895472};\\\", \\\"{x:1399,y:818,t:1526922895489};\\\", \\\"{x:1399,y:807,t:1526922895506};\\\", \\\"{x:1399,y:805,t:1526922895523};\\\", \\\"{x:1399,y:804,t:1526922895580};\\\", \\\"{x:1401,y:804,t:1526922895589};\\\", \\\"{x:1404,y:804,t:1526922895606};\\\", \\\"{x:1413,y:807,t:1526922895623};\\\", \\\"{x:1423,y:814,t:1526922895638};\\\", \\\"{x:1435,y:822,t:1526922895656};\\\", \\\"{x:1447,y:831,t:1526922895673};\\\", \\\"{x:1459,y:839,t:1526922895689};\\\", \\\"{x:1464,y:843,t:1526922895706};\\\", \\\"{x:1468,y:847,t:1526922895723};\\\", \\\"{x:1469,y:848,t:1526922895739};\\\", \\\"{x:1470,y:849,t:1526922895797};\\\", \\\"{x:1470,y:850,t:1526922895812};\\\", \\\"{x:1468,y:850,t:1526922895823};\\\", \\\"{x:1461,y:850,t:1526922895839};\\\", \\\"{x:1454,y:850,t:1526922895856};\\\", \\\"{x:1453,y:850,t:1526922895873};\\\", \\\"{x:1452,y:850,t:1526922895889};\\\", \\\"{x:1451,y:849,t:1526922895909};\\\", \\\"{x:1451,y:847,t:1526922895924};\\\", \\\"{x:1454,y:843,t:1526922895939};\\\", \\\"{x:1462,y:839,t:1526922895956};\\\", \\\"{x:1466,y:835,t:1526922895973};\\\", \\\"{x:1468,y:834,t:1526922895990};\\\", \\\"{x:1472,y:831,t:1526922896006};\\\", \\\"{x:1473,y:831,t:1526922896252};\\\", \\\"{x:1479,y:831,t:1526922896261};\\\", \\\"{x:1488,y:831,t:1526922896274};\\\", \\\"{x:1501,y:834,t:1526922896289};\\\", \\\"{x:1510,y:837,t:1526922896306};\\\", \\\"{x:1516,y:840,t:1526922896323};\\\", \\\"{x:1521,y:843,t:1526922896340};\\\", \\\"{x:1527,y:845,t:1526922896356};\\\", \\\"{x:1528,y:845,t:1526922896437};\\\", \\\"{x:1529,y:845,t:1526922896460};\\\", \\\"{x:1531,y:845,t:1526922896531};\\\", \\\"{x:1535,y:843,t:1526922896547};\\\", \\\"{x:1536,y:841,t:1526922896555};\\\", \\\"{x:1542,y:840,t:1526922896572};\\\", \\\"{x:1549,y:836,t:1526922896589};\\\", \\\"{x:1553,y:833,t:1526922896606};\\\", \\\"{x:1554,y:833,t:1526922896622};\\\", \\\"{x:1555,y:833,t:1526922896716};\\\", \\\"{x:1555,y:831,t:1526922896732};\\\", \\\"{x:1554,y:830,t:1526922896740};\\\", \\\"{x:1549,y:829,t:1526922896756};\\\", \\\"{x:1543,y:826,t:1526922896774};\\\", \\\"{x:1541,y:825,t:1526922896790};\\\", \\\"{x:1539,y:824,t:1526922896807};\\\", \\\"{x:1538,y:824,t:1526922896823};\\\", \\\"{x:1538,y:823,t:1526922896908};\\\", \\\"{x:1538,y:822,t:1526922896925};\\\", \\\"{x:1545,y:822,t:1526922896940};\\\", \\\"{x:1554,y:822,t:1526922896957};\\\", \\\"{x:1562,y:823,t:1526922896974};\\\", \\\"{x:1571,y:826,t:1526922896990};\\\", \\\"{x:1575,y:827,t:1526922897006};\\\", \\\"{x:1579,y:827,t:1526922897024};\\\", \\\"{x:1581,y:827,t:1526922897040};\\\", \\\"{x:1582,y:827,t:1526922897057};\\\", \\\"{x:1584,y:827,t:1526922897076};\\\", \\\"{x:1585,y:827,t:1526922897090};\\\", \\\"{x:1587,y:827,t:1526922897107};\\\", \\\"{x:1594,y:826,t:1526922897124};\\\", \\\"{x:1598,y:824,t:1526922897140};\\\", \\\"{x:1600,y:823,t:1526922897156};\\\", \\\"{x:1602,y:822,t:1526922897173};\\\", \\\"{x:1605,y:821,t:1526922897191};\\\", \\\"{x:1610,y:819,t:1526922897206};\\\", \\\"{x:1618,y:816,t:1526922897223};\\\", \\\"{x:1627,y:814,t:1526922897241};\\\", \\\"{x:1630,y:813,t:1526922897257};\\\", \\\"{x:1635,y:813,t:1526922897273};\\\", \\\"{x:1637,y:813,t:1526922897291};\\\", \\\"{x:1638,y:813,t:1526922897315};\\\", \\\"{x:1639,y:813,t:1526922897324};\\\", \\\"{x:1639,y:815,t:1526922897348};\\\", \\\"{x:1639,y:816,t:1526922897357};\\\", \\\"{x:1639,y:820,t:1526922897374};\\\", \\\"{x:1639,y:824,t:1526922897391};\\\", \\\"{x:1639,y:826,t:1526922897407};\\\", \\\"{x:1639,y:828,t:1526922897424};\\\", \\\"{x:1638,y:830,t:1526922897441};\\\", \\\"{x:1636,y:832,t:1526922897457};\\\", \\\"{x:1635,y:832,t:1526922897484};\\\", \\\"{x:1634,y:833,t:1526922897492};\\\", \\\"{x:1633,y:834,t:1526922897508};\\\", \\\"{x:1631,y:835,t:1526922897524};\\\", \\\"{x:1631,y:836,t:1526922897548};\\\", \\\"{x:1629,y:836,t:1526922897588};\\\", \\\"{x:1628,y:836,t:1526922897604};\\\", \\\"{x:1627,y:836,t:1526922897628};\\\", \\\"{x:1626,y:836,t:1526922897641};\\\", \\\"{x:1625,y:836,t:1526922897658};\\\", \\\"{x:1622,y:837,t:1526922897674};\\\", \\\"{x:1617,y:837,t:1526922897691};\\\", \\\"{x:1612,y:837,t:1526922897708};\\\", \\\"{x:1612,y:835,t:1526922897797};\\\", \\\"{x:1617,y:833,t:1526922897808};\\\", \\\"{x:1630,y:828,t:1526922897823};\\\", \\\"{x:1648,y:823,t:1526922897841};\\\", \\\"{x:1670,y:818,t:1526922897858};\\\", \\\"{x:1690,y:815,t:1526922897875};\\\", \\\"{x:1701,y:812,t:1526922897891};\\\", \\\"{x:1707,y:811,t:1526922897908};\\\", \\\"{x:1706,y:811,t:1526922898037};\\\", \\\"{x:1704,y:811,t:1526922898044};\\\", \\\"{x:1703,y:811,t:1526922898058};\\\", \\\"{x:1702,y:812,t:1526922898075};\\\", \\\"{x:1700,y:813,t:1526922898091};\\\", \\\"{x:1699,y:813,t:1526922898108};\\\", \\\"{x:1697,y:814,t:1526922898124};\\\", \\\"{x:1696,y:814,t:1526922898141};\\\", \\\"{x:1695,y:815,t:1526922898180};\\\", \\\"{x:1694,y:815,t:1526922898191};\\\", \\\"{x:1693,y:816,t:1526922898208};\\\", \\\"{x:1689,y:817,t:1526922898225};\\\", \\\"{x:1685,y:818,t:1526922898242};\\\", \\\"{x:1674,y:822,t:1526922898258};\\\", \\\"{x:1659,y:822,t:1526922898275};\\\", \\\"{x:1630,y:823,t:1526922898293};\\\", \\\"{x:1603,y:823,t:1526922898308};\\\", \\\"{x:1574,y:823,t:1526922898325};\\\", \\\"{x:1539,y:823,t:1526922898342};\\\", \\\"{x:1500,y:823,t:1526922898357};\\\", \\\"{x:1455,y:823,t:1526922898375};\\\", \\\"{x:1399,y:823,t:1526922898392};\\\", \\\"{x:1335,y:823,t:1526922898408};\\\", \\\"{x:1263,y:823,t:1526922898425};\\\", \\\"{x:1188,y:823,t:1526922898441};\\\", \\\"{x:1101,y:823,t:1526922898458};\\\", \\\"{x:1002,y:823,t:1526922898475};\\\", \\\"{x:857,y:823,t:1526922898492};\\\", \\\"{x:760,y:823,t:1526922898508};\\\", \\\"{x:666,y:823,t:1526922898525};\\\", \\\"{x:558,y:823,t:1526922898541};\\\", \\\"{x:458,y:812,t:1526922898558};\\\", \\\"{x:340,y:802,t:1526922898574};\\\", \\\"{x:229,y:786,t:1526922898591};\\\", \\\"{x:126,y:768,t:1526922898607};\\\", \\\"{x:32,y:756,t:1526922898624};\\\", \\\"{x:8,y:735,t:1526922898641};\\\", \\\"{x:8,y:711,t:1526922898659};\\\", \\\"{x:8,y:694,t:1526922898674};\\\", \\\"{x:8,y:685,t:1526922898691};\\\", \\\"{x:18,y:675,t:1526922898707};\\\", \\\"{x:41,y:660,t:1526922898724};\\\", \\\"{x:81,y:620,t:1526922898742};\\\", \\\"{x:129,y:585,t:1526922898759};\\\", \\\"{x:182,y:562,t:1526922898775};\\\", \\\"{x:241,y:542,t:1526922898791};\\\", \\\"{x:314,y:531,t:1526922898808};\\\", \\\"{x:388,y:524,t:1526922898824};\\\", \\\"{x:463,y:524,t:1526922898841};\\\", \\\"{x:541,y:524,t:1526922898857};\\\", \\\"{x:619,y:524,t:1526922898874};\\\", \\\"{x:677,y:524,t:1526922898890};\\\", \\\"{x:740,y:524,t:1526922898907};\\\", \\\"{x:759,y:524,t:1526922898924};\\\", \\\"{x:768,y:527,t:1526922898941};\\\", \\\"{x:769,y:527,t:1526922898964};\\\", \\\"{x:769,y:529,t:1526922898980};\\\", \\\"{x:767,y:529,t:1526922898991};\\\", \\\"{x:762,y:531,t:1526922899007};\\\", \\\"{x:758,y:533,t:1526922899024};\\\", \\\"{x:755,y:534,t:1526922899041};\\\", \\\"{x:749,y:534,t:1526922899057};\\\", \\\"{x:737,y:532,t:1526922899075};\\\", \\\"{x:711,y:521,t:1526922899093};\\\", \\\"{x:689,y:512,t:1526922899109};\\\", \\\"{x:670,y:504,t:1526922899124};\\\", \\\"{x:657,y:499,t:1526922899142};\\\", \\\"{x:649,y:497,t:1526922899157};\\\", \\\"{x:644,y:495,t:1526922899174};\\\", \\\"{x:640,y:494,t:1526922899192};\\\", \\\"{x:637,y:494,t:1526922899207};\\\", \\\"{x:631,y:494,t:1526922899224};\\\", \\\"{x:628,y:494,t:1526922899242};\\\", \\\"{x:622,y:494,t:1526922899257};\\\", \\\"{x:621,y:495,t:1526922899274};\\\", \\\"{x:620,y:495,t:1526922899291};\\\", \\\"{x:624,y:499,t:1526922899457};\\\", \\\"{x:638,y:499,t:1526922899474};\\\", \\\"{x:653,y:498,t:1526922899491};\\\", \\\"{x:681,y:495,t:1526922899508};\\\", \\\"{x:720,y:495,t:1526922899524};\\\", \\\"{x:762,y:495,t:1526922899542};\\\", \\\"{x:791,y:495,t:1526922899558};\\\", \\\"{x:813,y:495,t:1526922899574};\\\", \\\"{x:824,y:493,t:1526922899591};\\\", \\\"{x:825,y:493,t:1526922899609};\\\", \\\"{x:825,y:494,t:1526922899708};\\\", \\\"{x:825,y:496,t:1526922899988};\\\", \\\"{x:827,y:503,t:1526922899996};\\\", \\\"{x:830,y:511,t:1526922900008};\\\", \\\"{x:836,y:528,t:1526922900026};\\\", \\\"{x:839,y:545,t:1526922900042};\\\", \\\"{x:843,y:559,t:1526922900059};\\\", \\\"{x:846,y:569,t:1526922900076};\\\", \\\"{x:846,y:570,t:1526922900091};\\\", \\\"{x:847,y:570,t:1526922900109};\\\", \\\"{x:847,y:568,t:1526922900589};\\\", \\\"{x:847,y:566,t:1526922900596};\\\", \\\"{x:847,y:562,t:1526922900611};\\\", \\\"{x:847,y:559,t:1526922900626};\\\", \\\"{x:847,y:557,t:1526922900642};\\\", \\\"{x:847,y:556,t:1526922900658};\\\", \\\"{x:847,y:554,t:1526922900676};\\\", \\\"{x:847,y:555,t:1526922900940};\\\", \\\"{x:847,y:562,t:1526922900949};\\\", \\\"{x:847,y:573,t:1526922900960};\\\", \\\"{x:847,y:594,t:1526922900977};\\\", \\\"{x:848,y:615,t:1526922900993};\\\", \\\"{x:851,y:633,t:1526922901010};\\\", \\\"{x:852,y:643,t:1526922901025};\\\", \\\"{x:853,y:649,t:1526922901042};\\\", \\\"{x:854,y:652,t:1526922901059};\\\", \\\"{x:854,y:651,t:1526922901163};\\\", \\\"{x:852,y:645,t:1526922901176};\\\", \\\"{x:850,y:639,t:1526922901192};\\\", \\\"{x:850,y:633,t:1526922901209};\\\", \\\"{x:849,y:630,t:1526922901227};\\\", \\\"{x:848,y:628,t:1526922901242};\\\", \\\"{x:847,y:627,t:1526922901516};\\\", \\\"{x:846,y:626,t:1526922901527};\\\", \\\"{x:845,y:626,t:1526922901542};\\\", \\\"{x:844,y:626,t:1526922901563};\\\", \\\"{x:844,y:625,t:1526922901629};\\\", \\\"{x:844,y:624,t:1526922901643};\\\", \\\"{x:844,y:621,t:1526922901659};\\\", \\\"{x:844,y:620,t:1526922901677};\\\", \\\"{x:844,y:619,t:1526922901867};\\\", \\\"{x:837,y:619,t:1526922901876};\\\", \\\"{x:810,y:628,t:1526922901893};\\\", \\\"{x:765,y:641,t:1526922901910};\\\", \\\"{x:698,y:650,t:1526922901926};\\\", \\\"{x:628,y:660,t:1526922901943};\\\", \\\"{x:558,y:671,t:1526922901960};\\\", \\\"{x:502,y:679,t:1526922901976};\\\", \\\"{x:466,y:683,t:1526922901993};\\\", \\\"{x:442,y:686,t:1526922902009};\\\", \\\"{x:425,y:690,t:1526922902026};\\\", \\\"{x:417,y:693,t:1526922902043};\\\", \\\"{x:415,y:695,t:1526922902067};\\\", \\\"{x:415,y:696,t:1526922902076};\\\", \\\"{x:415,y:703,t:1526922902093};\\\", \\\"{x:415,y:713,t:1526922902110};\\\", \\\"{x:420,y:736,t:1526922902126};\\\", \\\"{x:424,y:746,t:1526922902144};\\\", \\\"{x:427,y:750,t:1526922902160};\\\", \\\"{x:431,y:753,t:1526922902177};\\\", \\\"{x:435,y:753,t:1526922902194};\\\", \\\"{x:438,y:753,t:1526922902210};\\\", \\\"{x:442,y:753,t:1526922902226};\\\", \\\"{x:449,y:753,t:1526922902244};\\\", \\\"{x:454,y:752,t:1526922902261};\\\", \\\"{x:462,y:749,t:1526922902276};\\\", \\\"{x:470,y:747,t:1526922902293};\\\", \\\"{x:473,y:745,t:1526922902311};\\\", \\\"{x:474,y:745,t:1526922902326};\\\", \\\"{x:475,y:744,t:1526922902344};\\\", \\\"{x:477,y:742,t:1526922902361};\\\", \\\"{x:477,y:741,t:1526922902378};\\\", \\\"{x:478,y:741,t:1526922902419};\\\", \\\"{x:477,y:741,t:1526922902595};\\\", \\\"{x:476,y:741,t:1526922902610};\\\", \\\"{x:474,y:741,t:1526922902627};\\\", \\\"{x:473,y:741,t:1526922902651};\\\", \\\"{x:472,y:741,t:1526922902660};\\\", \\\"{x:471,y:741,t:1526922902683};\\\", \\\"{x:469,y:740,t:1526922902693};\\\", \\\"{x:468,y:740,t:1526922902732};\\\" ] }, { \\\"rt\\\": 11386, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 526675, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"A\\\", \\\"X\\\", \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:468,y:735,t:1526922904548};\\\", \\\"{x:468,y:728,t:1526922904563};\\\", \\\"{x:470,y:710,t:1526922904580};\\\", \\\"{x:471,y:701,t:1526922904596};\\\", \\\"{x:471,y:691,t:1526922904611};\\\", \\\"{x:471,y:684,t:1526922904629};\\\", \\\"{x:471,y:676,t:1526922904645};\\\", \\\"{x:471,y:672,t:1526922904662};\\\", \\\"{x:470,y:670,t:1526922904691};\\\", \\\"{x:469,y:669,t:1526922904701};\\\", \\\"{x:469,y:667,t:1526922904711};\\\", \\\"{x:466,y:663,t:1526922904729};\\\", \\\"{x:466,y:662,t:1526922904747};\\\", \\\"{x:467,y:654,t:1526922910740};\\\", \\\"{x:470,y:643,t:1526922910750};\\\", \\\"{x:482,y:629,t:1526922910769};\\\", \\\"{x:500,y:613,t:1526922910783};\\\", \\\"{x:523,y:598,t:1526922910800};\\\", \\\"{x:545,y:574,t:1526922910834};\\\", \\\"{x:546,y:571,t:1526922910851};\\\", \\\"{x:547,y:570,t:1526922910867};\\\", \\\"{x:548,y:568,t:1526922910931};\\\", \\\"{x:553,y:567,t:1526922910939};\\\", \\\"{x:555,y:567,t:1526922910951};\\\", \\\"{x:566,y:562,t:1526922910967};\\\", \\\"{x:587,y:554,t:1526922910985};\\\", \\\"{x:611,y:546,t:1526922911001};\\\", \\\"{x:632,y:541,t:1526922911017};\\\", \\\"{x:644,y:537,t:1526922911034};\\\", \\\"{x:648,y:536,t:1526922911051};\\\", \\\"{x:650,y:536,t:1526922911067};\\\", \\\"{x:649,y:536,t:1526922911131};\\\", \\\"{x:648,y:536,t:1526922911139};\\\", \\\"{x:647,y:537,t:1526922911148};\\\", \\\"{x:646,y:538,t:1526922911167};\\\", \\\"{x:643,y:540,t:1526922911184};\\\", \\\"{x:642,y:541,t:1526922911268};\\\", \\\"{x:642,y:541,t:1526922911270};\\\", \\\"{x:641,y:543,t:1526922911283};\\\", \\\"{x:640,y:544,t:1526922911315};\\\", \\\"{x:638,y:547,t:1526922911323};\\\", \\\"{x:636,y:551,t:1526922911333};\\\", \\\"{x:633,y:561,t:1526922911351};\\\", \\\"{x:632,y:571,t:1526922911368};\\\", \\\"{x:631,y:581,t:1526922911384};\\\", \\\"{x:630,y:587,t:1526922911401};\\\", \\\"{x:629,y:589,t:1526922911417};\\\", \\\"{x:628,y:591,t:1526922911434};\\\", \\\"{x:627,y:591,t:1526922911451};\\\", \\\"{x:627,y:593,t:1526922911740};\\\", \\\"{x:626,y:597,t:1526922911752};\\\", \\\"{x:623,y:602,t:1526922911768};\\\", \\\"{x:622,y:607,t:1526922911785};\\\", \\\"{x:619,y:613,t:1526922911801};\\\", \\\"{x:618,y:617,t:1526922911818};\\\", \\\"{x:618,y:618,t:1526922911834};\\\", \\\"{x:617,y:619,t:1526922911964};\\\", \\\"{x:617,y:617,t:1526922912267};\\\", \\\"{x:615,y:613,t:1526922912284};\\\", \\\"{x:615,y:611,t:1526922912302};\\\", \\\"{x:613,y:609,t:1526922912317};\\\", \\\"{x:613,y:608,t:1526922912335};\\\", \\\"{x:612,y:604,t:1526922912351};\\\", \\\"{x:612,y:597,t:1526922912369};\\\", \\\"{x:610,y:593,t:1526922912385};\\\", \\\"{x:610,y:585,t:1526922912401};\\\", \\\"{x:609,y:578,t:1526922912418};\\\", \\\"{x:608,y:571,t:1526922912435};\\\", \\\"{x:608,y:570,t:1526922912452};\\\", \\\"{x:608,y:569,t:1526922912468};\\\", \\\"{x:608,y:567,t:1526922912691};\\\", \\\"{x:608,y:566,t:1526922912702};\\\", \\\"{x:609,y:561,t:1526922912719};\\\", \\\"{x:611,y:553,t:1526922912735};\\\", \\\"{x:614,y:546,t:1526922912752};\\\", \\\"{x:615,y:538,t:1526922912769};\\\", \\\"{x:617,y:534,t:1526922912785};\\\", \\\"{x:617,y:533,t:1526922912811};\\\", \\\"{x:617,y:529,t:1526922913140};\\\", \\\"{x:616,y:526,t:1526922913152};\\\", \\\"{x:613,y:521,t:1526922913170};\\\", \\\"{x:613,y:518,t:1526922913186};\\\", \\\"{x:612,y:517,t:1526922913203};\\\", \\\"{x:610,y:522,t:1526922913524};\\\", \\\"{x:608,y:528,t:1526922913537};\\\", \\\"{x:602,y:550,t:1526922913552};\\\", \\\"{x:594,y:579,t:1526922913569};\\\", \\\"{x:586,y:609,t:1526922913586};\\\", \\\"{x:576,y:649,t:1526922913603};\\\", \\\"{x:571,y:666,t:1526922913619};\\\", \\\"{x:569,y:675,t:1526922913636};\\\", \\\"{x:569,y:676,t:1526922913652};\\\", \\\"{x:569,y:673,t:1526922913716};\\\", \\\"{x:569,y:667,t:1526922913724};\\\", \\\"{x:569,y:660,t:1526922913738};\\\", \\\"{x:573,y:637,t:1526922913754};\\\", \\\"{x:585,y:602,t:1526922913772};\\\", \\\"{x:603,y:558,t:1526922913788};\\\", \\\"{x:610,y:538,t:1526922913805};\\\", \\\"{x:618,y:521,t:1526922913820};\\\", \\\"{x:619,y:505,t:1526922913836};\\\", \\\"{x:620,y:502,t:1526922913853};\\\", \\\"{x:620,y:500,t:1526922913869};\\\", \\\"{x:620,y:498,t:1526922913940};\\\", \\\"{x:622,y:497,t:1526922913953};\\\", \\\"{x:621,y:497,t:1526922914292};\\\", \\\"{x:620,y:497,t:1526922914316};\\\", \\\"{x:619,y:498,t:1526922914347};\\\", \\\"{x:618,y:498,t:1526922914372};\\\", \\\"{x:615,y:500,t:1526922914388};\\\", \\\"{x:612,y:501,t:1526922914403};\\\", \\\"{x:599,y:512,t:1526922914421};\\\", \\\"{x:586,y:528,t:1526922914437};\\\", \\\"{x:573,y:551,t:1526922914453};\\\", \\\"{x:562,y:574,t:1526922914470};\\\", \\\"{x:552,y:595,t:1526922914487};\\\", \\\"{x:545,y:613,t:1526922914503};\\\", \\\"{x:541,y:627,t:1526922914520};\\\", \\\"{x:535,y:647,t:1526922914537};\\\", \\\"{x:534,y:663,t:1526922914554};\\\", \\\"{x:528,y:695,t:1526922914570};\\\", \\\"{x:524,y:728,t:1526922914587};\\\", \\\"{x:524,y:747,t:1526922914603};\\\", \\\"{x:524,y:764,t:1526922914620};\\\", \\\"{x:524,y:773,t:1526922914637};\\\", \\\"{x:524,y:782,t:1526922914653};\\\", \\\"{x:524,y:785,t:1526922914670};\\\", \\\"{x:524,y:786,t:1526922914687};\\\", \\\"{x:524,y:787,t:1526922914704};\\\", \\\"{x:524,y:788,t:1526922914720};\\\", \\\"{x:524,y:790,t:1526922914737};\\\", \\\"{x:524,y:791,t:1526922914812};\\\", \\\"{x:525,y:790,t:1526922914820};\\\", \\\"{x:527,y:784,t:1526922914837};\\\", \\\"{x:528,y:771,t:1526922914854};\\\", \\\"{x:530,y:754,t:1526922914871};\\\", \\\"{x:532,y:746,t:1526922914887};\\\", \\\"{x:533,y:740,t:1526922914904};\\\", \\\"{x:533,y:737,t:1526922914920};\\\", \\\"{x:533,y:736,t:1526922914937};\\\" ] }, { \\\"rt\\\": 5652, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 533550, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"G\\\", \\\"O\\\", \\\"H\\\", \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:735,t:1526922916971};\\\", \\\"{x:553,y:726,t:1526922916979};\\\", \\\"{x:595,y:709,t:1526922916990};\\\", \\\"{x:713,y:665,t:1526922917006};\\\", \\\"{x:859,y:600,t:1526922917022};\\\", \\\"{x:1037,y:503,t:1526922917039};\\\", \\\"{x:1205,y:433,t:1526922917055};\\\", \\\"{x:1351,y:373,t:1526922917072};\\\", \\\"{x:1461,y:341,t:1526922917089};\\\", \\\"{x:1540,y:327,t:1526922917105};\\\", \\\"{x:1553,y:327,t:1526922917122};\\\", \\\"{x:1544,y:334,t:1526922917140};\\\", \\\"{x:1510,y:356,t:1526922917156};\\\", \\\"{x:1451,y:385,t:1526922917172};\\\", \\\"{x:1381,y:418,t:1526922917190};\\\", \\\"{x:1288,y:456,t:1526922917205};\\\", \\\"{x:1209,y:484,t:1526922917222};\\\", \\\"{x:1148,y:503,t:1526922917239};\\\", \\\"{x:1099,y:518,t:1526922917257};\\\", \\\"{x:1059,y:527,t:1526922917273};\\\", \\\"{x:1034,y:532,t:1526922917290};\\\", \\\"{x:1012,y:538,t:1526922917307};\\\", \\\"{x:991,y:545,t:1526922917322};\\\", \\\"{x:949,y:554,t:1526922917340};\\\", \\\"{x:917,y:557,t:1526922917356};\\\", \\\"{x:878,y:559,t:1526922917372};\\\", \\\"{x:867,y:559,t:1526922917389};\\\", \\\"{x:856,y:559,t:1526922917406};\\\", \\\"{x:855,y:557,t:1526922917422};\\\", \\\"{x:853,y:557,t:1526922917439};\\\", \\\"{x:850,y:556,t:1526922917455};\\\", \\\"{x:847,y:552,t:1526922917472};\\\", \\\"{x:846,y:549,t:1526922917489};\\\", \\\"{x:846,y:547,t:1526922917506};\\\", \\\"{x:849,y:544,t:1526922917522};\\\", \\\"{x:858,y:540,t:1526922917539};\\\", \\\"{x:862,y:538,t:1526922917556};\\\", \\\"{x:863,y:538,t:1526922917572};\\\", \\\"{x:867,y:536,t:1526922917589};\\\", \\\"{x:870,y:535,t:1526922917606};\\\", \\\"{x:870,y:534,t:1526922917622};\\\", \\\"{x:871,y:533,t:1526922917659};\\\", \\\"{x:871,y:531,t:1526922917675};\\\", \\\"{x:873,y:529,t:1526922917689};\\\", \\\"{x:873,y:523,t:1526922917706};\\\", \\\"{x:873,y:514,t:1526922917723};\\\", \\\"{x:870,y:506,t:1526922917739};\\\", \\\"{x:869,y:504,t:1526922917756};\\\", \\\"{x:867,y:501,t:1526922917774};\\\", \\\"{x:866,y:500,t:1526922917789};\\\", \\\"{x:865,y:500,t:1526922917806};\\\", \\\"{x:863,y:500,t:1526922917932};\\\", \\\"{x:862,y:500,t:1526922917939};\\\", \\\"{x:860,y:500,t:1526922917957};\\\", \\\"{x:856,y:501,t:1526922917974};\\\", \\\"{x:853,y:501,t:1526922917990};\\\", \\\"{x:850,y:501,t:1526922918007};\\\", \\\"{x:849,y:501,t:1526922918024};\\\", \\\"{x:848,y:502,t:1526922918275};\\\", \\\"{x:848,y:505,t:1526922918290};\\\", \\\"{x:845,y:516,t:1526922918306};\\\", \\\"{x:841,y:527,t:1526922918324};\\\", \\\"{x:840,y:534,t:1526922918340};\\\", \\\"{x:839,y:535,t:1526922918356};\\\", \\\"{x:839,y:536,t:1526922918373};\\\", \\\"{x:839,y:537,t:1526922918395};\\\", \\\"{x:839,y:538,t:1526922918492};\\\", \\\"{x:838,y:541,t:1526922918506};\\\", \\\"{x:837,y:547,t:1526922918523};\\\", \\\"{x:837,y:548,t:1526922918540};\\\", \\\"{x:836,y:552,t:1526922918787};\\\", \\\"{x:836,y:556,t:1526922918808};\\\", \\\"{x:835,y:560,t:1526922918823};\\\", \\\"{x:835,y:564,t:1526922918841};\\\", \\\"{x:834,y:566,t:1526922918857};\\\", \\\"{x:833,y:568,t:1526922918872};\\\", \\\"{x:833,y:569,t:1526922918890};\\\", \\\"{x:832,y:571,t:1526922918907};\\\", \\\"{x:832,y:572,t:1526922918924};\\\", \\\"{x:831,y:576,t:1526922918940};\\\", \\\"{x:830,y:577,t:1526922918957};\\\", \\\"{x:830,y:579,t:1526922918974};\\\", \\\"{x:830,y:581,t:1526922918996};\\\", \\\"{x:830,y:582,t:1526922919007};\\\", \\\"{x:830,y:585,t:1526922919023};\\\", \\\"{x:829,y:588,t:1526922919040};\\\", \\\"{x:829,y:591,t:1526922919058};\\\", \\\"{x:829,y:592,t:1526922919061};\\\", \\\"{x:829,y:593,t:1526922919089};\\\", \\\"{x:829,y:594,t:1526922919107};\\\", \\\"{x:829,y:595,t:1526922919124};\\\", \\\"{x:829,y:595,t:1526922919139};\\\", \\\"{x:829,y:597,t:1526922919211};\\\", \\\"{x:829,y:598,t:1526922919224};\\\", \\\"{x:829,y:600,t:1526922919240};\\\", \\\"{x:829,y:604,t:1526922919258};\\\", \\\"{x:828,y:606,t:1526922919274};\\\", \\\"{x:828,y:607,t:1526922919300};\\\", \\\"{x:828,y:608,t:1526922919315};\\\", \\\"{x:827,y:609,t:1526922919323};\\\", \\\"{x:827,y:610,t:1526922919355};\\\", \\\"{x:827,y:611,t:1526922919372};\\\", \\\"{x:827,y:606,t:1526922919500};\\\", \\\"{x:827,y:603,t:1526922919508};\\\", \\\"{x:827,y:599,t:1526922919524};\\\", \\\"{x:827,y:595,t:1526922919541};\\\", \\\"{x:827,y:594,t:1526922919578};\\\", \\\"{x:827,y:593,t:1526922919901};\\\", \\\"{x:828,y:592,t:1526922919908};\\\", \\\"{x:831,y:590,t:1526922919924};\\\", \\\"{x:833,y:587,t:1526922919941};\\\", \\\"{x:838,y:582,t:1526922919958};\\\", \\\"{x:838,y:581,t:1526922919974};\\\", \\\"{x:837,y:581,t:1526922920219};\\\", \\\"{x:836,y:582,t:1526922920227};\\\", \\\"{x:835,y:583,t:1526922920241};\\\", \\\"{x:835,y:589,t:1526922920258};\\\", \\\"{x:834,y:599,t:1526922920276};\\\", \\\"{x:833,y:611,t:1526922920292};\\\", \\\"{x:831,y:615,t:1526922920308};\\\", \\\"{x:830,y:620,t:1526922920325};\\\", \\\"{x:830,y:623,t:1526922920341};\\\", \\\"{x:825,y:624,t:1526922920603};\\\", \\\"{x:817,y:624,t:1526922920611};\\\", \\\"{x:805,y:624,t:1526922920625};\\\", \\\"{x:772,y:621,t:1526922920640};\\\", \\\"{x:742,y:618,t:1526922920658};\\\", \\\"{x:699,y:613,t:1526922920676};\\\", \\\"{x:674,y:610,t:1526922920691};\\\", \\\"{x:659,y:609,t:1526922920708};\\\", \\\"{x:654,y:608,t:1526922920725};\\\", \\\"{x:651,y:608,t:1526922920883};\\\", \\\"{x:648,y:608,t:1526922920892};\\\", \\\"{x:644,y:608,t:1526922920909};\\\", \\\"{x:639,y:608,t:1526922920926};\\\", \\\"{x:637,y:608,t:1526922920942};\\\", \\\"{x:635,y:608,t:1526922920958};\\\", \\\"{x:633,y:608,t:1526922920975};\\\", \\\"{x:630,y:608,t:1526922920993};\\\", \\\"{x:628,y:608,t:1526922921008};\\\", \\\"{x:627,y:608,t:1526922921025};\\\", \\\"{x:626,y:608,t:1526922921068};\\\", \\\"{x:626,y:609,t:1526922921083};\\\", \\\"{x:625,y:609,t:1526922921092};\\\", \\\"{x:623,y:611,t:1526922921109};\\\", \\\"{x:620,y:615,t:1526922921126};\\\", \\\"{x:616,y:620,t:1526922921142};\\\", \\\"{x:611,y:622,t:1526922921158};\\\", \\\"{x:609,y:624,t:1526922921176};\\\", \\\"{x:608,y:624,t:1526922921195};\\\", \\\"{x:606,y:627,t:1526922921523};\\\", \\\"{x:605,y:633,t:1526922921532};\\\", \\\"{x:603,y:637,t:1526922921542};\\\", \\\"{x:599,y:654,t:1526922921559};\\\", \\\"{x:594,y:676,t:1526922921576};\\\", \\\"{x:588,y:712,t:1526922921592};\\\", \\\"{x:578,y:731,t:1526922921609};\\\", \\\"{x:570,y:740,t:1526922921626};\\\", \\\"{x:567,y:744,t:1526922921643};\\\", \\\"{x:563,y:748,t:1526922921660};\\\", \\\"{x:559,y:756,t:1526922921676};\\\", \\\"{x:555,y:761,t:1526922921692};\\\", \\\"{x:551,y:767,t:1526922921709};\\\", \\\"{x:549,y:769,t:1526922921726};\\\", \\\"{x:547,y:769,t:1526922921795};\\\", \\\"{x:547,y:767,t:1526922921809};\\\", \\\"{x:540,y:757,t:1526922921827};\\\", \\\"{x:532,y:746,t:1526922921843};\\\", \\\"{x:521,y:733,t:1526922921859};\\\", \\\"{x:519,y:730,t:1526922921876};\\\", \\\"{x:519,y:729,t:1526922921892};\\\", \\\"{x:519,y:728,t:1526922922003};\\\", \\\"{x:519,y:727,t:1526922922025};\\\", \\\"{x:521,y:726,t:1526922922043};\\\", \\\"{x:522,y:725,t:1526922922059};\\\", \\\"{x:523,y:725,t:1526922922076};\\\", \\\"{x:524,y:724,t:1526922922092};\\\" ] }, { \\\"rt\\\": 5337, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 540106, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 4, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\", \\\"M\\\", \\\"K\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:722,t:1526922924507};\\\", \\\"{x:447,y:685,t:1526922924533};\\\", \\\"{x:410,y:667,t:1526922924543};\\\", \\\"{x:334,y:627,t:1526922924562};\\\", \\\"{x:278,y:600,t:1526922924579};\\\", \\\"{x:247,y:580,t:1526922924595};\\\", \\\"{x:245,y:577,t:1526922924611};\\\", \\\"{x:246,y:573,t:1526922924628};\\\", \\\"{x:246,y:566,t:1526922924644};\\\", \\\"{x:250,y:554,t:1526922924662};\\\", \\\"{x:256,y:539,t:1526922924678};\\\", \\\"{x:267,y:520,t:1526922924696};\\\", \\\"{x:273,y:501,t:1526922924711};\\\", \\\"{x:279,y:478,t:1526922924728};\\\", \\\"{x:288,y:457,t:1526922924745};\\\", \\\"{x:295,y:440,t:1526922924761};\\\", \\\"{x:306,y:432,t:1526922924778};\\\", \\\"{x:315,y:427,t:1526922924794};\\\", \\\"{x:317,y:425,t:1526922924812};\\\", \\\"{x:318,y:425,t:1526922924828};\\\", \\\"{x:322,y:425,t:1526922924859};\\\", \\\"{x:330,y:434,t:1526922924867};\\\", \\\"{x:341,y:446,t:1526922924879};\\\", \\\"{x:371,y:472,t:1526922924896};\\\", \\\"{x:392,y:490,t:1526922924912};\\\", \\\"{x:406,y:502,t:1526922924929};\\\", \\\"{x:412,y:507,t:1526922924945};\\\", \\\"{x:413,y:509,t:1526922924963};\\\", \\\"{x:411,y:510,t:1526922925236};\\\", \\\"{x:407,y:510,t:1526922925246};\\\", \\\"{x:398,y:507,t:1526922925262};\\\", \\\"{x:391,y:507,t:1526922925280};\\\", \\\"{x:389,y:507,t:1526922925297};\\\", \\\"{x:387,y:508,t:1526922925659};\\\", \\\"{x:383,y:512,t:1526922925666};\\\", \\\"{x:381,y:515,t:1526922925680};\\\", \\\"{x:379,y:523,t:1526922925695};\\\", \\\"{x:377,y:530,t:1526922925712};\\\", \\\"{x:375,y:536,t:1526922925730};\\\", \\\"{x:375,y:541,t:1526922925745};\\\", \\\"{x:374,y:544,t:1526922925762};\\\", \\\"{x:373,y:547,t:1526922925779};\\\", \\\"{x:373,y:550,t:1526922926195};\\\", \\\"{x:373,y:552,t:1526922926203};\\\", \\\"{x:373,y:555,t:1526922926212};\\\", \\\"{x:373,y:558,t:1526922926230};\\\", \\\"{x:373,y:563,t:1526922926247};\\\", \\\"{x:373,y:564,t:1526922926263};\\\", \\\"{x:373,y:565,t:1526922926283};\\\", \\\"{x:373,y:566,t:1526922926307};\\\", \\\"{x:373,y:567,t:1526922926323};\\\", \\\"{x:374,y:569,t:1526922926331};\\\", \\\"{x:375,y:572,t:1526922926579};\\\", \\\"{x:377,y:581,t:1526922926597};\\\", \\\"{x:378,y:588,t:1526922926613};\\\", \\\"{x:380,y:596,t:1526922926630};\\\", \\\"{x:382,y:603,t:1526922926647};\\\", \\\"{x:383,y:605,t:1526922926663};\\\", \\\"{x:383,y:606,t:1526922926679};\\\", \\\"{x:383,y:608,t:1526922927435};\\\", \\\"{x:387,y:613,t:1526922927447};\\\", \\\"{x:390,y:619,t:1526922927463};\\\", \\\"{x:393,y:625,t:1526922927481};\\\", \\\"{x:395,y:627,t:1526922927498};\\\", \\\"{x:395,y:631,t:1526922927514};\\\", \\\"{x:395,y:632,t:1526922927532};\\\", \\\"{x:396,y:633,t:1526922927546};\\\", \\\"{x:396,y:635,t:1526922927563};\\\", \\\"{x:396,y:637,t:1526922927580};\\\", \\\"{x:395,y:641,t:1526922927597};\\\", \\\"{x:395,y:651,t:1526922927614};\\\", \\\"{x:394,y:654,t:1526922927630};\\\", \\\"{x:393,y:658,t:1526922927647};\\\", \\\"{x:393,y:659,t:1526922927663};\\\", \\\"{x:392,y:662,t:1526922927680};\\\", \\\"{x:391,y:663,t:1526922927739};\\\", \\\"{x:397,y:664,t:1526922928044};\\\", \\\"{x:418,y:673,t:1526922928065};\\\", \\\"{x:441,y:683,t:1526922928081};\\\", \\\"{x:458,y:694,t:1526922928097};\\\", \\\"{x:475,y:705,t:1526922928114};\\\", \\\"{x:490,y:714,t:1526922928131};\\\", \\\"{x:490,y:715,t:1526922928268};\\\", \\\"{x:491,y:716,t:1526922928282};\\\", \\\"{x:492,y:718,t:1526922928298};\\\", \\\"{x:493,y:722,t:1526922928316};\\\", \\\"{x:495,y:728,t:1526922928339};\\\", \\\"{x:496,y:733,t:1526922928355};\\\", \\\"{x:498,y:740,t:1526922928372};\\\", \\\"{x:498,y:741,t:1526922928389};\\\", \\\"{x:499,y:742,t:1526922928405};\\\", \\\"{x:500,y:739,t:1526922928666};\\\", \\\"{x:500,y:737,t:1526922928674};\\\", \\\"{x:500,y:734,t:1526922928688};\\\", \\\"{x:500,y:730,t:1526922928705};\\\", \\\"{x:501,y:727,t:1526922928722};\\\", \\\"{x:501,y:726,t:1526922928739};\\\" ] }, { \\\"rt\\\": 9344, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 550734, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:725,t:1526922931435};\\\", \\\"{x:513,y:721,t:1526922931442};\\\", \\\"{x:524,y:717,t:1526922931456};\\\", \\\"{x:547,y:708,t:1526922931471};\\\", \\\"{x:569,y:697,t:1526922931491};\\\", \\\"{x:593,y:689,t:1526922931508};\\\", \\\"{x:619,y:682,t:1526922931525};\\\", \\\"{x:646,y:675,t:1526922931541};\\\", \\\"{x:671,y:668,t:1526922931558};\\\", \\\"{x:688,y:663,t:1526922931575};\\\", \\\"{x:708,y:656,t:1526922931591};\\\", \\\"{x:729,y:652,t:1526922931608};\\\", \\\"{x:755,y:646,t:1526922931625};\\\", \\\"{x:794,y:637,t:1526922931641};\\\", \\\"{x:872,y:616,t:1526922931658};\\\", \\\"{x:945,y:600,t:1526922931675};\\\", \\\"{x:1036,y:578,t:1526922931691};\\\", \\\"{x:1126,y:559,t:1526922931708};\\\", \\\"{x:1214,y:540,t:1526922931726};\\\", \\\"{x:1282,y:524,t:1526922931742};\\\", \\\"{x:1320,y:512,t:1526922931758};\\\", \\\"{x:1336,y:504,t:1526922931775};\\\", \\\"{x:1342,y:501,t:1526922931791};\\\", \\\"{x:1343,y:500,t:1526922931808};\\\", \\\"{x:1342,y:497,t:1526922931826};\\\", \\\"{x:1340,y:495,t:1526922931841};\\\", \\\"{x:1339,y:495,t:1526922931859};\\\", \\\"{x:1338,y:495,t:1526922931939};\\\", \\\"{x:1337,y:495,t:1526922931947};\\\", \\\"{x:1336,y:490,t:1526922932099};\\\", \\\"{x:1336,y:480,t:1526922932108};\\\", \\\"{x:1343,y:454,t:1526922932125};\\\", \\\"{x:1356,y:409,t:1526922932142};\\\", \\\"{x:1367,y:363,t:1526922932158};\\\", \\\"{x:1375,y:307,t:1526922932174};\\\", \\\"{x:1383,y:248,t:1526922932192};\\\", \\\"{x:1391,y:184,t:1526922932207};\\\", \\\"{x:1406,y:111,t:1526922932224};\\\", \\\"{x:1429,y:2,t:1526922932242};\\\", \\\"{x:1448,y:0,t:1526922932258};\\\", \\\"{x:1465,y:0,t:1526922932275};\\\", \\\"{x:1479,y:0,t:1526922932292};\\\", \\\"{x:1491,y:0,t:1526922932308};\\\", \\\"{x:1505,y:0,t:1526922932325};\\\", \\\"{x:1512,y:0,t:1526922932341};\\\", \\\"{x:1518,y:0,t:1526922932358};\\\", \\\"{x:1519,y:0,t:1526922932374};\\\", \\\"{x:1520,y:0,t:1526922932392};\\\", \\\"{x:1526,y:13,t:1526922932408};\\\", \\\"{x:1549,y:107,t:1526922932425};\\\", \\\"{x:1606,y:317,t:1526922932443};\\\", \\\"{x:1625,y:463,t:1526922932459};\\\", \\\"{x:1629,y:550,t:1526922932475};\\\", \\\"{x:1629,y:587,t:1526922932492};\\\", \\\"{x:1627,y:605,t:1526922932508};\\\", \\\"{x:1626,y:610,t:1526922932525};\\\", \\\"{x:1625,y:612,t:1526922932542};\\\", \\\"{x:1623,y:612,t:1526922932559};\\\", \\\"{x:1615,y:610,t:1526922932575};\\\", \\\"{x:1605,y:608,t:1526922932592};\\\", \\\"{x:1598,y:605,t:1526922932608};\\\", \\\"{x:1591,y:603,t:1526922932625};\\\", \\\"{x:1575,y:596,t:1526922932642};\\\", \\\"{x:1563,y:593,t:1526922932658};\\\", \\\"{x:1555,y:591,t:1526922932675};\\\", \\\"{x:1550,y:591,t:1526922932692};\\\", \\\"{x:1537,y:592,t:1526922932709};\\\", \\\"{x:1528,y:593,t:1526922932725};\\\", \\\"{x:1517,y:597,t:1526922932742};\\\", \\\"{x:1509,y:602,t:1526922932759};\\\", \\\"{x:1495,y:611,t:1526922932775};\\\", \\\"{x:1481,y:618,t:1526922932793};\\\", \\\"{x:1466,y:626,t:1526922932809};\\\", \\\"{x:1458,y:632,t:1526922932825};\\\", \\\"{x:1443,y:642,t:1526922932843};\\\", \\\"{x:1439,y:649,t:1526922932858};\\\", \\\"{x:1429,y:660,t:1526922932875};\\\", \\\"{x:1424,y:664,t:1526922932892};\\\", \\\"{x:1424,y:665,t:1526922932909};\\\", \\\"{x:1424,y:666,t:1526922932947};\\\", \\\"{x:1425,y:666,t:1526922933076};\\\", \\\"{x:1426,y:667,t:1526922933115};\\\", \\\"{x:1426,y:668,t:1526922933126};\\\", \\\"{x:1424,y:674,t:1526922933142};\\\", \\\"{x:1412,y:684,t:1526922933159};\\\", \\\"{x:1389,y:699,t:1526922933175};\\\", \\\"{x:1363,y:706,t:1526922933191};\\\", \\\"{x:1343,y:710,t:1526922933209};\\\", \\\"{x:1334,y:710,t:1526922933226};\\\", \\\"{x:1323,y:709,t:1526922933491};\\\", \\\"{x:1280,y:697,t:1526922933499};\\\", \\\"{x:1238,y:682,t:1526922933509};\\\", \\\"{x:1165,y:657,t:1526922933526};\\\", \\\"{x:1098,y:639,t:1526922933544};\\\", \\\"{x:1014,y:624,t:1526922933560};\\\", \\\"{x:933,y:611,t:1526922933576};\\\", \\\"{x:836,y:597,t:1526922933594};\\\", \\\"{x:625,y:589,t:1526922933610};\\\", \\\"{x:433,y:573,t:1526922933626};\\\", \\\"{x:201,y:543,t:1526922933643};\\\", \\\"{x:8,y:521,t:1526922933659};\\\", \\\"{x:8,y:492,t:1526922933675};\\\", \\\"{x:8,y:469,t:1526922933693};\\\", \\\"{x:8,y:457,t:1526922933710};\\\", \\\"{x:8,y:459,t:1526922933726};\\\", \\\"{x:9,y:459,t:1526922934123};\\\", \\\"{x:15,y:460,t:1526922934131};\\\", \\\"{x:23,y:462,t:1526922934144};\\\", \\\"{x:36,y:466,t:1526922934162};\\\", \\\"{x:65,y:475,t:1526922934179};\\\", \\\"{x:82,y:480,t:1526922934195};\\\", \\\"{x:92,y:482,t:1526922934212};\\\", \\\"{x:96,y:484,t:1526922934228};\\\", \\\"{x:97,y:487,t:1526922934247};\\\", \\\"{x:97,y:495,t:1526922934260};\\\", \\\"{x:96,y:508,t:1526922934276};\\\", \\\"{x:90,y:521,t:1526922934293};\\\", \\\"{x:80,y:537,t:1526922934310};\\\", \\\"{x:69,y:548,t:1526922934327};\\\", \\\"{x:58,y:560,t:1526922934343};\\\", \\\"{x:45,y:574,t:1526922934360};\\\", \\\"{x:32,y:586,t:1526922934377};\\\", \\\"{x:30,y:589,t:1526922934393};\\\", \\\"{x:35,y:589,t:1526922934425};\\\", \\\"{x:40,y:587,t:1526922934434};\\\", \\\"{x:53,y:584,t:1526922934445};\\\", \\\"{x:82,y:581,t:1526922934460};\\\", \\\"{x:122,y:576,t:1526922934477};\\\", \\\"{x:163,y:571,t:1526922934493};\\\", \\\"{x:201,y:567,t:1526922934510};\\\", \\\"{x:225,y:565,t:1526922934527};\\\", \\\"{x:239,y:565,t:1526922934543};\\\", \\\"{x:242,y:565,t:1526922934559};\\\", \\\"{x:243,y:565,t:1526922934585};\\\", \\\"{x:242,y:567,t:1526922934609};\\\", \\\"{x:236,y:576,t:1526922934627};\\\", \\\"{x:228,y:586,t:1526922934644};\\\", \\\"{x:224,y:593,t:1526922934660};\\\", \\\"{x:216,y:607,t:1526922934677};\\\", \\\"{x:212,y:618,t:1526922934694};\\\", \\\"{x:207,y:625,t:1526922934710};\\\", \\\"{x:203,y:634,t:1526922934727};\\\", \\\"{x:199,y:641,t:1526922934744};\\\", \\\"{x:196,y:647,t:1526922934760};\\\", \\\"{x:193,y:652,t:1526922934777};\\\", \\\"{x:188,y:660,t:1526922934794};\\\", \\\"{x:187,y:661,t:1526922934810};\\\", \\\"{x:185,y:661,t:1526922934827};\\\", \\\"{x:184,y:662,t:1526922934844};\\\", \\\"{x:183,y:663,t:1526922934860};\\\", \\\"{x:182,y:663,t:1526922934877};\\\", \\\"{x:181,y:663,t:1526922934907};\\\", \\\"{x:180,y:662,t:1526922934923};\\\", \\\"{x:179,y:662,t:1526922934930};\\\", \\\"{x:179,y:658,t:1526922934944};\\\", \\\"{x:177,y:646,t:1526922934961};\\\", \\\"{x:176,y:632,t:1526922934979};\\\", \\\"{x:172,y:608,t:1526922934996};\\\", \\\"{x:169,y:588,t:1526922935011};\\\", \\\"{x:165,y:571,t:1526922935027};\\\", \\\"{x:163,y:562,t:1526922935044};\\\", \\\"{x:163,y:559,t:1526922935061};\\\", \\\"{x:163,y:555,t:1526922935077};\\\", \\\"{x:163,y:552,t:1526922935094};\\\", \\\"{x:163,y:549,t:1526922935111};\\\", \\\"{x:163,y:546,t:1526922935126};\\\", \\\"{x:164,y:544,t:1526922935144};\\\", \\\"{x:165,y:542,t:1526922935161};\\\", \\\"{x:170,y:541,t:1526922935177};\\\", \\\"{x:175,y:537,t:1526922935193};\\\", \\\"{x:178,y:535,t:1526922935211};\\\", \\\"{x:181,y:533,t:1526922935227};\\\", \\\"{x:182,y:533,t:1526922937091};\\\", \\\"{x:182,y:535,t:1526922937748};\\\", \\\"{x:182,y:565,t:1526922937764};\\\", \\\"{x:178,y:606,t:1526922937779};\\\", \\\"{x:178,y:684,t:1526922937796};\\\", \\\"{x:178,y:734,t:1526922937813};\\\", \\\"{x:172,y:769,t:1526922937829};\\\", \\\"{x:164,y:792,t:1526922937846};\\\", \\\"{x:159,y:802,t:1526922937863};\\\", \\\"{x:158,y:806,t:1526922937879};\\\", \\\"{x:157,y:808,t:1526922937896};\\\", \\\"{x:156,y:808,t:1526922937930};\\\", \\\"{x:156,y:809,t:1526922938011};\\\", \\\"{x:158,y:809,t:1526922938019};\\\", \\\"{x:162,y:809,t:1526922938030};\\\", \\\"{x:170,y:806,t:1526922938046};\\\", \\\"{x:179,y:802,t:1526922938064};\\\", \\\"{x:191,y:796,t:1526922938080};\\\", \\\"{x:209,y:788,t:1526922938096};\\\", \\\"{x:229,y:773,t:1526922938114};\\\", \\\"{x:263,y:751,t:1526922938130};\\\", \\\"{x:284,y:737,t:1526922938147};\\\", \\\"{x:298,y:727,t:1526922938164};\\\", \\\"{x:310,y:720,t:1526922938180};\\\", \\\"{x:314,y:718,t:1526922938196};\\\", \\\"{x:317,y:714,t:1526922938214};\\\", \\\"{x:319,y:714,t:1526922938230};\\\", \\\"{x:322,y:710,t:1526922938246};\\\", \\\"{x:328,y:706,t:1526922938263};\\\", \\\"{x:340,y:705,t:1526922938281};\\\", \\\"{x:353,y:706,t:1526922938297};\\\", \\\"{x:355,y:706,t:1526922938314};\\\", \\\"{x:368,y:710,t:1526922938331};\\\", \\\"{x:390,y:716,t:1526922938346};\\\", \\\"{x:419,y:725,t:1526922938363};\\\", \\\"{x:446,y:735,t:1526922938381};\\\", \\\"{x:466,y:742,t:1526922938398};\\\", \\\"{x:479,y:750,t:1526922938413};\\\", \\\"{x:494,y:759,t:1526922938432};\\\", \\\"{x:501,y:770,t:1526922938447};\\\", \\\"{x:510,y:784,t:1526922938463};\\\", \\\"{x:516,y:798,t:1526922938480};\\\", \\\"{x:520,y:814,t:1526922938497};\\\", \\\"{x:521,y:825,t:1526922938513};\\\", \\\"{x:521,y:834,t:1526922938530};\\\", \\\"{x:522,y:838,t:1526922938547};\\\", \\\"{x:523,y:838,t:1526922938563};\\\", \\\"{x:523,y:834,t:1526922938651};\\\", \\\"{x:523,y:830,t:1526922938663};\\\", \\\"{x:523,y:821,t:1526922938680};\\\", \\\"{x:523,y:813,t:1526922938697};\\\", \\\"{x:523,y:805,t:1526922938713};\\\", \\\"{x:520,y:791,t:1526922938730};\\\", \\\"{x:516,y:786,t:1526922938747};\\\", \\\"{x:514,y:782,t:1526922938764};\\\", \\\"{x:513,y:779,t:1526922938780};\\\", \\\"{x:513,y:778,t:1526922938802};\\\", \\\"{x:513,y:776,t:1526922938814};\\\", \\\"{x:510,y:772,t:1526922938830};\\\", \\\"{x:507,y:768,t:1526922938848};\\\", \\\"{x:505,y:765,t:1526922938864};\\\", \\\"{x:505,y:764,t:1526922938882};\\\", \\\"{x:505,y:761,t:1526922938963};\\\", \\\"{x:505,y:759,t:1526922938971};\\\", \\\"{x:505,y:756,t:1526922938981};\\\", \\\"{x:505,y:754,t:1526922938999};\\\", \\\"{x:506,y:749,t:1526922939014};\\\", \\\"{x:507,y:743,t:1526922939030};\\\", \\\"{x:507,y:741,t:1526922939047};\\\", \\\"{x:507,y:739,t:1526922939063};\\\", \\\"{x:506,y:738,t:1526922939081};\\\", \\\"{x:503,y:736,t:1526922939298};\\\", \\\"{x:495,y:728,t:1526922939313};\\\", \\\"{x:486,y:722,t:1526922939330};\\\", \\\"{x:477,y:716,t:1526922939347};\\\", \\\"{x:472,y:712,t:1526922939365};\\\", \\\"{x:469,y:710,t:1526922939380};\\\", \\\"{x:466,y:709,t:1526922939397};\\\", \\\"{x:461,y:707,t:1526922939414};\\\", \\\"{x:458,y:706,t:1526922939430};\\\", \\\"{x:454,y:704,t:1526922939447};\\\", \\\"{x:450,y:702,t:1526922939464};\\\", \\\"{x:445,y:700,t:1526922939481};\\\", \\\"{x:442,y:700,t:1526922939497};\\\", \\\"{x:436,y:698,t:1526922939514};\\\", \\\"{x:434,y:698,t:1526922939531};\\\", \\\"{x:429,y:696,t:1526922939547};\\\", \\\"{x:424,y:696,t:1526922939565};\\\", \\\"{x:417,y:696,t:1526922939580};\\\", \\\"{x:412,y:696,t:1526922939597};\\\", \\\"{x:410,y:696,t:1526922939614};\\\", \\\"{x:408,y:696,t:1526922939631};\\\", \\\"{x:407,y:696,t:1526922939899};\\\", \\\"{x:405,y:696,t:1526922939914};\\\", \\\"{x:400,y:696,t:1526922939931};\\\", \\\"{x:398,y:696,t:1526922939947};\\\", \\\"{x:395,y:695,t:1526922939964};\\\", \\\"{x:393,y:695,t:1526922939981};\\\", \\\"{x:392,y:694,t:1526922939997};\\\", \\\"{x:389,y:692,t:1526922940014};\\\", \\\"{x:388,y:691,t:1526922940034};\\\", \\\"{x:387,y:691,t:1526922940047};\\\", \\\"{x:385,y:691,t:1526922940065};\\\", \\\"{x:382,y:689,t:1526922940082};\\\", \\\"{x:381,y:689,t:1526922940098};\\\", \\\"{x:378,y:687,t:1526922940115};\\\", \\\"{x:375,y:686,t:1526922940131};\\\", \\\"{x:374,y:685,t:1526922940148};\\\", \\\"{x:373,y:685,t:1526922940164};\\\", \\\"{x:372,y:685,t:1526922940186};\\\", \\\"{x:372,y:684,t:1526922940233};\\\" ] }, { \\\"rt\\\": 43898, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 595847, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -Z -Z -B -07 PM-05 PM-F -Z -Z -Z -Z -Z -Z -Z -L -L \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:371,y:684,t:1526922940883};\\\", \\\"{x:370,y:684,t:1526922940898};\\\", \\\"{x:369,y:684,t:1526922940985};\\\", \\\"{x:375,y:683,t:1526922948011};\\\", \\\"{x:386,y:679,t:1526922948022};\\\", \\\"{x:417,y:663,t:1526922948040};\\\", \\\"{x:458,y:637,t:1526922948054};\\\", \\\"{x:526,y:602,t:1526922948071};\\\", \\\"{x:597,y:571,t:1526922948088};\\\", \\\"{x:675,y:535,t:1526922948105};\\\", \\\"{x:788,y:480,t:1526922948122};\\\", \\\"{x:855,y:461,t:1526922948138};\\\", \\\"{x:899,y:449,t:1526922948154};\\\", \\\"{x:927,y:440,t:1526922948171};\\\", \\\"{x:950,y:431,t:1526922948187};\\\", \\\"{x:967,y:426,t:1526922948204};\\\", \\\"{x:986,y:425,t:1526922948221};\\\", \\\"{x:1003,y:424,t:1526922948238};\\\", \\\"{x:1023,y:420,t:1526922948254};\\\", \\\"{x:1046,y:420,t:1526922948271};\\\", \\\"{x:1085,y:420,t:1526922948288};\\\", \\\"{x:1128,y:420,t:1526922948304};\\\", \\\"{x:1214,y:420,t:1526922948321};\\\", \\\"{x:1245,y:420,t:1526922948337};\\\", \\\"{x:1350,y:420,t:1526922948354};\\\", \\\"{x:1414,y:420,t:1526922948372};\\\", \\\"{x:1478,y:420,t:1526922948388};\\\", \\\"{x:1535,y:421,t:1526922948405};\\\", \\\"{x:1566,y:425,t:1526922948422};\\\", \\\"{x:1585,y:430,t:1526922948438};\\\", \\\"{x:1591,y:432,t:1526922948455};\\\", \\\"{x:1592,y:433,t:1526922948472};\\\", \\\"{x:1593,y:436,t:1526922948488};\\\", \\\"{x:1594,y:444,t:1526922948505};\\\", \\\"{x:1594,y:456,t:1526922948522};\\\", \\\"{x:1593,y:466,t:1526922948538};\\\", \\\"{x:1589,y:476,t:1526922948555};\\\", \\\"{x:1586,y:492,t:1526922948572};\\\", \\\"{x:1582,y:513,t:1526922948587};\\\", \\\"{x:1578,y:542,t:1526922948604};\\\", \\\"{x:1570,y:598,t:1526922948621};\\\", \\\"{x:1557,y:660,t:1526922948639};\\\", \\\"{x:1533,y:718,t:1526922948654};\\\", \\\"{x:1505,y:779,t:1526922948672};\\\", \\\"{x:1476,y:836,t:1526922948688};\\\", \\\"{x:1446,y:887,t:1526922948704};\\\", \\\"{x:1415,y:939,t:1526922948722};\\\", \\\"{x:1401,y:960,t:1526922948737};\\\", \\\"{x:1391,y:973,t:1526922948755};\\\", \\\"{x:1386,y:981,t:1526922948772};\\\", \\\"{x:1383,y:985,t:1526922948789};\\\", \\\"{x:1382,y:987,t:1526922948805};\\\", \\\"{x:1382,y:984,t:1526922948931};\\\", \\\"{x:1382,y:981,t:1526922948938};\\\", \\\"{x:1384,y:975,t:1526922948955};\\\", \\\"{x:1385,y:968,t:1526922948972};\\\", \\\"{x:1388,y:963,t:1526922948989};\\\", \\\"{x:1389,y:961,t:1526922949005};\\\", \\\"{x:1389,y:960,t:1526922949022};\\\", \\\"{x:1390,y:960,t:1526922949039};\\\", \\\"{x:1391,y:960,t:1526922949091};\\\", \\\"{x:1392,y:960,t:1526922949111};\\\", \\\"{x:1393,y:960,t:1526922949161};\\\", \\\"{x:1393,y:959,t:1526922949266};\\\", \\\"{x:1393,y:958,t:1526922949274};\\\", \\\"{x:1393,y:957,t:1526922949288};\\\", \\\"{x:1393,y:954,t:1526922949306};\\\", \\\"{x:1393,y:946,t:1526922949322};\\\", \\\"{x:1393,y:925,t:1526922949339};\\\", \\\"{x:1397,y:909,t:1526922949356};\\\", \\\"{x:1406,y:900,t:1526922949372};\\\", \\\"{x:1419,y:894,t:1526922949389};\\\", \\\"{x:1444,y:890,t:1526922949406};\\\", \\\"{x:1473,y:887,t:1526922949422};\\\", \\\"{x:1517,y:887,t:1526922949439};\\\", \\\"{x:1562,y:887,t:1526922949456};\\\", \\\"{x:1596,y:887,t:1526922949473};\\\", \\\"{x:1624,y:887,t:1526922949489};\\\", \\\"{x:1662,y:887,t:1526922949507};\\\", \\\"{x:1675,y:884,t:1526922949523};\\\", \\\"{x:1684,y:882,t:1526922949538};\\\", \\\"{x:1686,y:882,t:1526922949556};\\\", \\\"{x:1687,y:882,t:1526922949573};\\\", \\\"{x:1687,y:880,t:1526922949675};\\\", \\\"{x:1684,y:875,t:1526922949689};\\\", \\\"{x:1651,y:858,t:1526922949707};\\\", \\\"{x:1623,y:851,t:1526922949723};\\\", \\\"{x:1595,y:850,t:1526922949739};\\\", \\\"{x:1559,y:850,t:1526922949758};\\\", \\\"{x:1387,y:847,t:1526922949811};\\\", \\\"{x:1368,y:847,t:1526922949821};\\\", \\\"{x:1328,y:847,t:1526922949838};\\\", \\\"{x:1292,y:847,t:1526922949856};\\\", \\\"{x:1263,y:847,t:1526922949873};\\\", \\\"{x:1243,y:846,t:1526922949888};\\\", \\\"{x:1229,y:845,t:1526922949905};\\\", \\\"{x:1229,y:844,t:1526922949922};\\\", \\\"{x:1228,y:842,t:1526922949978};\\\", \\\"{x:1228,y:840,t:1526922949988};\\\", \\\"{x:1228,y:833,t:1526922950006};\\\", \\\"{x:1227,y:824,t:1526922950022};\\\", \\\"{x:1227,y:820,t:1526922950039};\\\", \\\"{x:1226,y:812,t:1526922950056};\\\", \\\"{x:1226,y:794,t:1526922950072};\\\", \\\"{x:1226,y:766,t:1526922950089};\\\", \\\"{x:1232,y:730,t:1526922950106};\\\", \\\"{x:1242,y:703,t:1526922950122};\\\", \\\"{x:1245,y:686,t:1526922950139};\\\", \\\"{x:1250,y:668,t:1526922950156};\\\", \\\"{x:1254,y:658,t:1526922950173};\\\", \\\"{x:1257,y:651,t:1526922950189};\\\", \\\"{x:1258,y:646,t:1526922950206};\\\", \\\"{x:1258,y:642,t:1526922950222};\\\", \\\"{x:1261,y:638,t:1526922950239};\\\", \\\"{x:1261,y:636,t:1526922950256};\\\", \\\"{x:1261,y:635,t:1526922950272};\\\", \\\"{x:1262,y:631,t:1526922950289};\\\", \\\"{x:1263,y:629,t:1526922950306};\\\", \\\"{x:1268,y:627,t:1526922950322};\\\", \\\"{x:1276,y:624,t:1526922950339};\\\", \\\"{x:1293,y:624,t:1526922950356};\\\", \\\"{x:1328,y:644,t:1526922950373};\\\", \\\"{x:1364,y:668,t:1526922950389};\\\", \\\"{x:1398,y:694,t:1526922950406};\\\", \\\"{x:1427,y:715,t:1526922950423};\\\", \\\"{x:1459,y:738,t:1526922950439};\\\", \\\"{x:1482,y:754,t:1526922950456};\\\", \\\"{x:1502,y:769,t:1526922950473};\\\", \\\"{x:1515,y:778,t:1526922950489};\\\", \\\"{x:1522,y:784,t:1526922950506};\\\", \\\"{x:1523,y:785,t:1526922950523};\\\", \\\"{x:1524,y:785,t:1526922950587};\\\", \\\"{x:1526,y:785,t:1526922950594};\\\", \\\"{x:1529,y:785,t:1526922950605};\\\", \\\"{x:1535,y:785,t:1526922950623};\\\", \\\"{x:1546,y:783,t:1526922950639};\\\", \\\"{x:1559,y:778,t:1526922950656};\\\", \\\"{x:1573,y:771,t:1526922950673};\\\", \\\"{x:1587,y:754,t:1526922950690};\\\", \\\"{x:1595,y:743,t:1526922950706};\\\", \\\"{x:1600,y:729,t:1526922950723};\\\", \\\"{x:1604,y:717,t:1526922950739};\\\", \\\"{x:1607,y:707,t:1526922950756};\\\", \\\"{x:1612,y:697,t:1526922950775};\\\", \\\"{x:1615,y:688,t:1526922950790};\\\", \\\"{x:1619,y:679,t:1526922950806};\\\", \\\"{x:1625,y:667,t:1526922950823};\\\", \\\"{x:1629,y:657,t:1526922950840};\\\", \\\"{x:1633,y:647,t:1526922950856};\\\", \\\"{x:1634,y:636,t:1526922950873};\\\", \\\"{x:1626,y:597,t:1526922950891};\\\", \\\"{x:1590,y:535,t:1526922950906};\\\", \\\"{x:1530,y:463,t:1526922950923};\\\", \\\"{x:1464,y:391,t:1526922950940};\\\", \\\"{x:1408,y:339,t:1526922950956};\\\", \\\"{x:1382,y:316,t:1526922950974};\\\", \\\"{x:1372,y:303,t:1526922950990};\\\", \\\"{x:1368,y:296,t:1526922951007};\\\", \\\"{x:1367,y:290,t:1526922951023};\\\", \\\"{x:1365,y:285,t:1526922951040};\\\", \\\"{x:1364,y:280,t:1526922951056};\\\", \\\"{x:1364,y:277,t:1526922951074};\\\", \\\"{x:1365,y:272,t:1526922951091};\\\", \\\"{x:1367,y:270,t:1526922951107};\\\", \\\"{x:1372,y:267,t:1526922951123};\\\", \\\"{x:1375,y:266,t:1526922951140};\\\", \\\"{x:1378,y:265,t:1526922951156};\\\", \\\"{x:1380,y:264,t:1526922951173};\\\", \\\"{x:1383,y:262,t:1526922951190};\\\", \\\"{x:1387,y:262,t:1526922951207};\\\", \\\"{x:1394,y:260,t:1526922951223};\\\", \\\"{x:1410,y:260,t:1526922951239};\\\", \\\"{x:1430,y:261,t:1526922951256};\\\", \\\"{x:1454,y:268,t:1526922951272};\\\", \\\"{x:1507,y:287,t:1526922951289};\\\", \\\"{x:1528,y:292,t:1526922951306};\\\", \\\"{x:1542,y:299,t:1526922951323};\\\", \\\"{x:1545,y:302,t:1526922951340};\\\", \\\"{x:1547,y:302,t:1526922951356};\\\", \\\"{x:1547,y:303,t:1526922951373};\\\", \\\"{x:1547,y:305,t:1526922951389};\\\", \\\"{x:1546,y:307,t:1526922951407};\\\", \\\"{x:1537,y:311,t:1526922951423};\\\", \\\"{x:1528,y:314,t:1526922951440};\\\", \\\"{x:1519,y:317,t:1526922951457};\\\", \\\"{x:1512,y:320,t:1526922951473};\\\", \\\"{x:1499,y:326,t:1526922951490};\\\", \\\"{x:1492,y:334,t:1526922951506};\\\", \\\"{x:1483,y:340,t:1526922951523};\\\", \\\"{x:1479,y:345,t:1526922951540};\\\", \\\"{x:1470,y:352,t:1526922951557};\\\", \\\"{x:1464,y:362,t:1526922951573};\\\", \\\"{x:1458,y:373,t:1526922951590};\\\", \\\"{x:1451,y:385,t:1526922951607};\\\", \\\"{x:1444,y:395,t:1526922951622};\\\", \\\"{x:1436,y:405,t:1526922951640};\\\", \\\"{x:1426,y:418,t:1526922951657};\\\", \\\"{x:1420,y:426,t:1526922951673};\\\", \\\"{x:1412,y:440,t:1526922951690};\\\", \\\"{x:1410,y:451,t:1526922951707};\\\", \\\"{x:1407,y:464,t:1526922951723};\\\", \\\"{x:1407,y:476,t:1526922951740};\\\", \\\"{x:1408,y:491,t:1526922951757};\\\", \\\"{x:1418,y:510,t:1526922951773};\\\", \\\"{x:1430,y:532,t:1526922951791};\\\", \\\"{x:1443,y:548,t:1526922951807};\\\", \\\"{x:1460,y:561,t:1526922951824};\\\", \\\"{x:1472,y:573,t:1526922951840};\\\", \\\"{x:1479,y:578,t:1526922951858};\\\", \\\"{x:1481,y:581,t:1526922951874};\\\", \\\"{x:1481,y:584,t:1526922951890};\\\", \\\"{x:1478,y:588,t:1526922951907};\\\", \\\"{x:1465,y:595,t:1526922951924};\\\", \\\"{x:1447,y:600,t:1526922951940};\\\", \\\"{x:1428,y:606,t:1526922951957};\\\", \\\"{x:1400,y:615,t:1526922951975};\\\", \\\"{x:1359,y:622,t:1526922951990};\\\", \\\"{x:1324,y:630,t:1526922952007};\\\", \\\"{x:1300,y:640,t:1526922952024};\\\", \\\"{x:1267,y:665,t:1526922952040};\\\", \\\"{x:1237,y:688,t:1526922952057};\\\", \\\"{x:1219,y:716,t:1526922952075};\\\", \\\"{x:1216,y:725,t:1526922952091};\\\", \\\"{x:1216,y:728,t:1526922952107};\\\", \\\"{x:1216,y:731,t:1526922952124};\\\", \\\"{x:1216,y:733,t:1526922952146};\\\", \\\"{x:1217,y:733,t:1526922952163};\\\", \\\"{x:1218,y:733,t:1526922952178};\\\", \\\"{x:1220,y:733,t:1526922952190};\\\", \\\"{x:1221,y:733,t:1526922952207};\\\", \\\"{x:1224,y:731,t:1526922952225};\\\", \\\"{x:1227,y:720,t:1526922952240};\\\", \\\"{x:1228,y:701,t:1526922952257};\\\", \\\"{x:1228,y:663,t:1526922952274};\\\", \\\"{x:1228,y:640,t:1526922952291};\\\", \\\"{x:1228,y:615,t:1526922952308};\\\", \\\"{x:1228,y:593,t:1526922952324};\\\", \\\"{x:1228,y:573,t:1526922952340};\\\", \\\"{x:1226,y:551,t:1526922952357};\\\", \\\"{x:1226,y:537,t:1526922952374};\\\", \\\"{x:1227,y:527,t:1526922952390};\\\", \\\"{x:1232,y:516,t:1526922952408};\\\", \\\"{x:1239,y:509,t:1526922952424};\\\", \\\"{x:1246,y:503,t:1526922952441};\\\", \\\"{x:1257,y:499,t:1526922952457};\\\", \\\"{x:1275,y:492,t:1526922952475};\\\", \\\"{x:1282,y:489,t:1526922952490};\\\", \\\"{x:1285,y:488,t:1526922952507};\\\", \\\"{x:1283,y:488,t:1526922952619};\\\", \\\"{x:1279,y:491,t:1526922952626};\\\", \\\"{x:1274,y:495,t:1526922952642};\\\", \\\"{x:1263,y:503,t:1526922952657};\\\", \\\"{x:1240,y:516,t:1526922952674};\\\", \\\"{x:1228,y:524,t:1526922952691};\\\", \\\"{x:1217,y:529,t:1526922952708};\\\", \\\"{x:1210,y:536,t:1526922952724};\\\", \\\"{x:1205,y:541,t:1526922952741};\\\", \\\"{x:1200,y:546,t:1526922952757};\\\", \\\"{x:1197,y:551,t:1526922952774};\\\", \\\"{x:1195,y:556,t:1526922952792};\\\", \\\"{x:1194,y:557,t:1526922952807};\\\", \\\"{x:1193,y:559,t:1526922952826};\\\", \\\"{x:1193,y:558,t:1526922953643};\\\", \\\"{x:1194,y:556,t:1526922953659};\\\", \\\"{x:1194,y:555,t:1526922953675};\\\", \\\"{x:1195,y:554,t:1526922953690};\\\", \\\"{x:1197,y:554,t:1526922953826};\\\", \\\"{x:1200,y:561,t:1526922953840};\\\", \\\"{x:1217,y:582,t:1526922953857};\\\", \\\"{x:1230,y:599,t:1526922953874};\\\", \\\"{x:1244,y:621,t:1526922953890};\\\", \\\"{x:1265,y:649,t:1526922953908};\\\", \\\"{x:1303,y:693,t:1526922953925};\\\", \\\"{x:1348,y:752,t:1526922953941};\\\", \\\"{x:1405,y:833,t:1526922953958};\\\", \\\"{x:1463,y:922,t:1526922953974};\\\", \\\"{x:1513,y:1012,t:1526922953991};\\\", \\\"{x:1555,y:1103,t:1526922954008};\\\", \\\"{x:1593,y:1199,t:1526922954025};\\\", \\\"{x:1630,y:1199,t:1526922954041};\\\", \\\"{x:1659,y:1199,t:1526922954058};\\\", \\\"{x:1688,y:1199,t:1526922954076};\\\", \\\"{x:1706,y:1199,t:1526922954092};\\\", \\\"{x:1726,y:1199,t:1526922954109};\\\", \\\"{x:1734,y:1199,t:1526922954126};\\\", \\\"{x:1740,y:1199,t:1526922954143};\\\", \\\"{x:1743,y:1199,t:1526922954159};\\\", \\\"{x:1742,y:1199,t:1526922954290};\\\", \\\"{x:1741,y:1199,t:1526922954298};\\\", \\\"{x:1739,y:1199,t:1526922954309};\\\", \\\"{x:1733,y:1199,t:1526922954326};\\\", \\\"{x:1730,y:1199,t:1526922954342};\\\", \\\"{x:1729,y:1199,t:1526922954359};\\\", \\\"{x:1731,y:1199,t:1526922954402};\\\", \\\"{x:1733,y:1199,t:1526922954411};\\\", \\\"{x:1740,y:1199,t:1526922954427};\\\", \\\"{x:1739,y:1199,t:1526922954882};\\\", \\\"{x:1737,y:1199,t:1526922954922};\\\", \\\"{x:1736,y:1199,t:1526922955335};\\\", \\\"{x:1735,y:1199,t:1526922955347};\\\", \\\"{x:1734,y:1199,t:1526922955361};\\\", \\\"{x:1732,y:1199,t:1526922955377};\\\", \\\"{x:1731,y:1199,t:1526922955394};\\\", \\\"{x:1732,y:1199,t:1526922955563};\\\", \\\"{x:1734,y:1198,t:1526922955578};\\\", \\\"{x:1735,y:1195,t:1526922955593};\\\", \\\"{x:1737,y:1192,t:1526922955610};\\\", \\\"{x:1740,y:1184,t:1526922955627};\\\", \\\"{x:1746,y:1173,t:1526922955644};\\\", \\\"{x:1753,y:1160,t:1526922955661};\\\", \\\"{x:1764,y:1141,t:1526922955677};\\\", \\\"{x:1776,y:1123,t:1526922955694};\\\", \\\"{x:1795,y:1097,t:1526922955711};\\\", \\\"{x:1818,y:1072,t:1526922955727};\\\", \\\"{x:1859,y:1038,t:1526922955744};\\\", \\\"{x:1920,y:1000,t:1526922955762};\\\", \\\"{x:1927,y:948,t:1526922955777};\\\", \\\"{x:1927,y:878,t:1526922955794};\\\", \\\"{x:1927,y:826,t:1526922955811};\\\", \\\"{x:1927,y:777,t:1526922955828};\\\", \\\"{x:1927,y:733,t:1526922955844};\\\", \\\"{x:1927,y:683,t:1526922955860};\\\", \\\"{x:1927,y:636,t:1526922955877};\\\", \\\"{x:1927,y:592,t:1526922955893};\\\", \\\"{x:1927,y:558,t:1526922955911};\\\", \\\"{x:1927,y:523,t:1526922955928};\\\", \\\"{x:1927,y:499,t:1526922955944};\\\", \\\"{x:1927,y:472,t:1526922955961};\\\", \\\"{x:1927,y:438,t:1526922955978};\\\", \\\"{x:1927,y:419,t:1526922955994};\\\", \\\"{x:1927,y:400,t:1526922956011};\\\", \\\"{x:1927,y:373,t:1526922956028};\\\", \\\"{x:1927,y:333,t:1526922956044};\\\", \\\"{x:1927,y:277,t:1526922956061};\\\", \\\"{x:1927,y:191,t:1526922956078};\\\", \\\"{x:1927,y:79,t:1526922956094};\\\", \\\"{x:1927,y:0,t:1526922956111};\\\", \\\"{x:1926,y:0,t:1526922956499};\\\", \\\"{x:1925,y:0,t:1526922956511};\\\", \\\"{x:1924,y:0,t:1526922956538};\\\", \\\"{x:1923,y:1,t:1526922956898};\\\", \\\"{x:1922,y:1,t:1526922956913};\\\", \\\"{x:1922,y:2,t:1526922956928};\\\", \\\"{x:1921,y:3,t:1526922956945};\\\", \\\"{x:1920,y:3,t:1526922956962};\\\", \\\"{x:1917,y:7,t:1526922956978};\\\", \\\"{x:1900,y:69,t:1526922957012};\\\", \\\"{x:1871,y:161,t:1526922957028};\\\", \\\"{x:1845,y:322,t:1526922957045};\\\", \\\"{x:1838,y:517,t:1526922957062};\\\", \\\"{x:1834,y:738,t:1526922957079};\\\", \\\"{x:1834,y:970,t:1526922957096};\\\", \\\"{x:1831,y:1183,t:1526922957113};\\\", \\\"{x:1816,y:1199,t:1526922957129};\\\", \\\"{x:1797,y:1199,t:1526922957145};\\\", \\\"{x:1771,y:1199,t:1526922957162};\\\", \\\"{x:1764,y:1199,t:1526922957179};\\\", \\\"{x:1758,y:1199,t:1526922957194};\\\", \\\"{x:1756,y:1199,t:1526922957233};\\\", \\\"{x:1753,y:1188,t:1526922957245};\\\", \\\"{x:1743,y:1161,t:1526922957262};\\\", \\\"{x:1726,y:1123,t:1526922957279};\\\", \\\"{x:1709,y:1094,t:1526922957295};\\\", \\\"{x:1693,y:1062,t:1526922957312};\\\", \\\"{x:1678,y:1029,t:1526922957329};\\\", \\\"{x:1672,y:1008,t:1526922957345};\\\", \\\"{x:1662,y:983,t:1526922957362};\\\", \\\"{x:1660,y:968,t:1526922957380};\\\", \\\"{x:1660,y:954,t:1526922957395};\\\", \\\"{x:1660,y:938,t:1526922957412};\\\", \\\"{x:1655,y:921,t:1526922957429};\\\", \\\"{x:1651,y:911,t:1526922957445};\\\", \\\"{x:1643,y:897,t:1526922957462};\\\", \\\"{x:1641,y:895,t:1526922957479};\\\", \\\"{x:1641,y:894,t:1526922957495};\\\", \\\"{x:1639,y:893,t:1526922957512};\\\", \\\"{x:1638,y:893,t:1526922957554};\\\", \\\"{x:1635,y:894,t:1526922957562};\\\", \\\"{x:1631,y:896,t:1526922957580};\\\", \\\"{x:1628,y:897,t:1526922957597};\\\", \\\"{x:1620,y:900,t:1526922957612};\\\", \\\"{x:1609,y:904,t:1526922957630};\\\", \\\"{x:1595,y:908,t:1526922957645};\\\", \\\"{x:1581,y:911,t:1526922957662};\\\", \\\"{x:1563,y:911,t:1526922957680};\\\", \\\"{x:1548,y:911,t:1526922957696};\\\", \\\"{x:1534,y:911,t:1526922957712};\\\", \\\"{x:1524,y:909,t:1526922957729};\\\", \\\"{x:1503,y:896,t:1526922957747};\\\", \\\"{x:1492,y:888,t:1526922957762};\\\", \\\"{x:1486,y:876,t:1526922957779};\\\", \\\"{x:1480,y:862,t:1526922957796};\\\", \\\"{x:1473,y:841,t:1526922957812};\\\", \\\"{x:1467,y:821,t:1526922957829};\\\", \\\"{x:1463,y:797,t:1526922957846};\\\", \\\"{x:1460,y:770,t:1526922957863};\\\", \\\"{x:1459,y:743,t:1526922957879};\\\", \\\"{x:1461,y:716,t:1526922957896};\\\", \\\"{x:1470,y:691,t:1526922957914};\\\", \\\"{x:1480,y:668,t:1526922957929};\\\", \\\"{x:1494,y:644,t:1526922957946};\\\", \\\"{x:1504,y:634,t:1526922957963};\\\", \\\"{x:1514,y:626,t:1526922957979};\\\", \\\"{x:1521,y:623,t:1526922957996};\\\", \\\"{x:1523,y:622,t:1526922958013};\\\", \\\"{x:1525,y:622,t:1526922958030};\\\", \\\"{x:1525,y:623,t:1526922958154};\\\", \\\"{x:1525,y:625,t:1526922958163};\\\", \\\"{x:1525,y:628,t:1526922958180};\\\", \\\"{x:1525,y:630,t:1526922958197};\\\", \\\"{x:1525,y:631,t:1526922958214};\\\", \\\"{x:1525,y:632,t:1526922958230};\\\", \\\"{x:1526,y:633,t:1526922958459};\\\", \\\"{x:1526,y:636,t:1526922958515};\\\", \\\"{x:1526,y:640,t:1526922958530};\\\", \\\"{x:1530,y:650,t:1526922958546};\\\", \\\"{x:1532,y:652,t:1526922958564};\\\", \\\"{x:1532,y:654,t:1526922958580};\\\", \\\"{x:1533,y:655,t:1526922958595};\\\", \\\"{x:1533,y:656,t:1526922958612};\\\", \\\"{x:1534,y:656,t:1526922958634};\\\", \\\"{x:1534,y:657,t:1526922958665};\\\", \\\"{x:1535,y:657,t:1526922958681};\\\", \\\"{x:1535,y:658,t:1526922958697};\\\", \\\"{x:1536,y:659,t:1526922958713};\\\", \\\"{x:1537,y:659,t:1526922958786};\\\", \\\"{x:1539,y:661,t:1526922959395};\\\", \\\"{x:1539,y:662,t:1526922959403};\\\", \\\"{x:1540,y:665,t:1526922959414};\\\", \\\"{x:1540,y:668,t:1526922959431};\\\", \\\"{x:1541,y:669,t:1526922959448};\\\", \\\"{x:1541,y:671,t:1526922959465};\\\", \\\"{x:1542,y:674,t:1526922959480};\\\", \\\"{x:1543,y:675,t:1526922959498};\\\", \\\"{x:1547,y:683,t:1526922959514};\\\", \\\"{x:1551,y:691,t:1526922959530};\\\", \\\"{x:1556,y:700,t:1526922959548};\\\", \\\"{x:1561,y:707,t:1526922959564};\\\", \\\"{x:1566,y:713,t:1526922959580};\\\", \\\"{x:1570,y:716,t:1526922959598};\\\", \\\"{x:1577,y:718,t:1526922959615};\\\", \\\"{x:1582,y:720,t:1526922959630};\\\", \\\"{x:1588,y:720,t:1526922959647};\\\", \\\"{x:1590,y:720,t:1526922959664};\\\", \\\"{x:1592,y:720,t:1526922959680};\\\", \\\"{x:1594,y:720,t:1526922959698};\\\", \\\"{x:1595,y:717,t:1526922959714};\\\", \\\"{x:1595,y:713,t:1526922959730};\\\", \\\"{x:1598,y:708,t:1526922959747};\\\", \\\"{x:1599,y:704,t:1526922959765};\\\", \\\"{x:1599,y:701,t:1526922959781};\\\", \\\"{x:1599,y:697,t:1526922959797};\\\", \\\"{x:1600,y:695,t:1526922959815};\\\", \\\"{x:1600,y:693,t:1526922959831};\\\", \\\"{x:1601,y:691,t:1526922959847};\\\", \\\"{x:1601,y:690,t:1526922959865};\\\", \\\"{x:1602,y:690,t:1526922960027};\\\", \\\"{x:1604,y:690,t:1526922960075};\\\", \\\"{x:1604,y:691,t:1526922960123};\\\", \\\"{x:1604,y:692,t:1526922960163};\\\", \\\"{x:1603,y:692,t:1526922960178};\\\", \\\"{x:1603,y:693,t:1526922960194};\\\", \\\"{x:1603,y:694,t:1526922960210};\\\", \\\"{x:1603,y:695,t:1526922960218};\\\", \\\"{x:1603,y:696,t:1526922960250};\\\", \\\"{x:1600,y:699,t:1526922960939};\\\", \\\"{x:1594,y:699,t:1526922960949};\\\", \\\"{x:1571,y:702,t:1526922960966};\\\", \\\"{x:1527,y:707,t:1526922960982};\\\", \\\"{x:1448,y:714,t:1526922960998};\\\", \\\"{x:1361,y:716,t:1526922961016};\\\", \\\"{x:1264,y:716,t:1526922961032};\\\", \\\"{x:1184,y:716,t:1526922961048};\\\", \\\"{x:1128,y:716,t:1526922961065};\\\", \\\"{x:1091,y:721,t:1526922961082};\\\", \\\"{x:1088,y:722,t:1526922961097};\\\", \\\"{x:1091,y:722,t:1526922961201};\\\", \\\"{x:1094,y:722,t:1526922961216};\\\", \\\"{x:1098,y:720,t:1526922961232};\\\", \\\"{x:1103,y:719,t:1526922961248};\\\", \\\"{x:1106,y:718,t:1526922961265};\\\", \\\"{x:1109,y:717,t:1526922961282};\\\", \\\"{x:1110,y:716,t:1526922961467};\\\", \\\"{x:1114,y:713,t:1526922961482};\\\", \\\"{x:1123,y:709,t:1526922961498};\\\", \\\"{x:1136,y:706,t:1526922961516};\\\", \\\"{x:1151,y:703,t:1526922961533};\\\", \\\"{x:1163,y:701,t:1526922961550};\\\", \\\"{x:1180,y:698,t:1526922961566};\\\", \\\"{x:1198,y:696,t:1526922961582};\\\", \\\"{x:1213,y:696,t:1526922961599};\\\", \\\"{x:1224,y:696,t:1526922961615};\\\", \\\"{x:1237,y:696,t:1526922961632};\\\", \\\"{x:1245,y:696,t:1526922961649};\\\", \\\"{x:1250,y:696,t:1526922961665};\\\", \\\"{x:1256,y:696,t:1526922961682};\\\", \\\"{x:1260,y:696,t:1526922961700};\\\", \\\"{x:1263,y:696,t:1526922961716};\\\", \\\"{x:1269,y:696,t:1526922961732};\\\", \\\"{x:1272,y:696,t:1526922961750};\\\", \\\"{x:1276,y:696,t:1526922961765};\\\", \\\"{x:1278,y:696,t:1526922961782};\\\", \\\"{x:1281,y:696,t:1526922961800};\\\", \\\"{x:1284,y:696,t:1526922961817};\\\", \\\"{x:1287,y:696,t:1526922961832};\\\", \\\"{x:1289,y:696,t:1526922961849};\\\", \\\"{x:1294,y:696,t:1526922961866};\\\", \\\"{x:1299,y:696,t:1526922961883};\\\", \\\"{x:1302,y:696,t:1526922961900};\\\", \\\"{x:1305,y:696,t:1526922961916};\\\", \\\"{x:1306,y:696,t:1526922961932};\\\", \\\"{x:1309,y:696,t:1526922961949};\\\", \\\"{x:1311,y:696,t:1526922961965};\\\", \\\"{x:1315,y:696,t:1526922961982};\\\", \\\"{x:1319,y:696,t:1526922961999};\\\", \\\"{x:1323,y:696,t:1526922962016};\\\", \\\"{x:1327,y:696,t:1526922962032};\\\", \\\"{x:1330,y:696,t:1526922962049};\\\", \\\"{x:1335,y:696,t:1526922962065};\\\", \\\"{x:1337,y:696,t:1526922962082};\\\", \\\"{x:1342,y:696,t:1526922962100};\\\", \\\"{x:1344,y:696,t:1526922962116};\\\", \\\"{x:1346,y:696,t:1526922962132};\\\", \\\"{x:1348,y:696,t:1526922962149};\\\", \\\"{x:1350,y:696,t:1526922962166};\\\", \\\"{x:1353,y:696,t:1526922962182};\\\", \\\"{x:1356,y:696,t:1526922962200};\\\", \\\"{x:1360,y:696,t:1526922962216};\\\", \\\"{x:1367,y:696,t:1526922962233};\\\", \\\"{x:1371,y:696,t:1526922962249};\\\", \\\"{x:1374,y:696,t:1526922962266};\\\", \\\"{x:1376,y:696,t:1526922962282};\\\", \\\"{x:1377,y:696,t:1526922962299};\\\", \\\"{x:1378,y:696,t:1526922962321};\\\", \\\"{x:1379,y:696,t:1526922962338};\\\", \\\"{x:1380,y:696,t:1526922962349};\\\", \\\"{x:1383,y:696,t:1526922962366};\\\", \\\"{x:1386,y:696,t:1526922962383};\\\", \\\"{x:1395,y:696,t:1526922962399};\\\", \\\"{x:1406,y:696,t:1526922962416};\\\", \\\"{x:1424,y:696,t:1526922962433};\\\", \\\"{x:1440,y:696,t:1526922962449};\\\", \\\"{x:1474,y:696,t:1526922962466};\\\", \\\"{x:1502,y:696,t:1526922962483};\\\", \\\"{x:1534,y:696,t:1526922962499};\\\", \\\"{x:1564,y:696,t:1526922962517};\\\", \\\"{x:1593,y:696,t:1526922962533};\\\", \\\"{x:1616,y:696,t:1526922962550};\\\", \\\"{x:1633,y:696,t:1526922962567};\\\", \\\"{x:1644,y:696,t:1526922962583};\\\", \\\"{x:1645,y:696,t:1526922962599};\\\", \\\"{x:1643,y:696,t:1526922962811};\\\", \\\"{x:1642,y:696,t:1526922962818};\\\", \\\"{x:1641,y:696,t:1526922962833};\\\", \\\"{x:1639,y:696,t:1526922962851};\\\", \\\"{x:1638,y:697,t:1526922962867};\\\", \\\"{x:1637,y:697,t:1526922962884};\\\", \\\"{x:1635,y:697,t:1526922963019};\\\", \\\"{x:1633,y:697,t:1526922963033};\\\", \\\"{x:1630,y:698,t:1526922963051};\\\", \\\"{x:1629,y:698,t:1526922963066};\\\", \\\"{x:1627,y:698,t:1526922963083};\\\", \\\"{x:1626,y:698,t:1526922963101};\\\", \\\"{x:1624,y:698,t:1526922963116};\\\", \\\"{x:1623,y:698,t:1526922963134};\\\", \\\"{x:1621,y:698,t:1526922963151};\\\", \\\"{x:1620,y:699,t:1526922963166};\\\", \\\"{x:1618,y:699,t:1526922963184};\\\", \\\"{x:1616,y:700,t:1526922963217};\\\", \\\"{x:1615,y:701,t:1526922963233};\\\", \\\"{x:1614,y:701,t:1526922963250};\\\", \\\"{x:1612,y:701,t:1526922963290};\\\", \\\"{x:1611,y:695,t:1526922964219};\\\", \\\"{x:1609,y:685,t:1526922964234};\\\", \\\"{x:1608,y:673,t:1526922964251};\\\", \\\"{x:1607,y:664,t:1526922964267};\\\", \\\"{x:1607,y:657,t:1526922964284};\\\", \\\"{x:1607,y:651,t:1526922964301};\\\", \\\"{x:1607,y:647,t:1526922964318};\\\", \\\"{x:1607,y:644,t:1526922964334};\\\", \\\"{x:1607,y:642,t:1526922964351};\\\", \\\"{x:1606,y:640,t:1526922964369};\\\", \\\"{x:1606,y:639,t:1526922964401};\\\", \\\"{x:1606,y:638,t:1526922964418};\\\", \\\"{x:1605,y:637,t:1526922964434};\\\", \\\"{x:1605,y:635,t:1526922964451};\\\", \\\"{x:1603,y:631,t:1526922964467};\\\", \\\"{x:1602,y:623,t:1526922964485};\\\", \\\"{x:1599,y:611,t:1526922964501};\\\", \\\"{x:1593,y:593,t:1526922964518};\\\", \\\"{x:1586,y:569,t:1526922964534};\\\", \\\"{x:1578,y:543,t:1526922964552};\\\", \\\"{x:1572,y:526,t:1526922964568};\\\", \\\"{x:1567,y:509,t:1526922964584};\\\", \\\"{x:1564,y:492,t:1526922964601};\\\", \\\"{x:1559,y:467,t:1526922964617};\\\", \\\"{x:1556,y:450,t:1526922964634};\\\", \\\"{x:1555,y:436,t:1526922964651};\\\", \\\"{x:1554,y:426,t:1526922964669};\\\", \\\"{x:1553,y:412,t:1526922964684};\\\", \\\"{x:1553,y:404,t:1526922964702};\\\", \\\"{x:1551,y:395,t:1526922964719};\\\", \\\"{x:1551,y:389,t:1526922964734};\\\", \\\"{x:1551,y:383,t:1526922964752};\\\", \\\"{x:1551,y:376,t:1526922964769};\\\", \\\"{x:1551,y:371,t:1526922964785};\\\", \\\"{x:1551,y:365,t:1526922964802};\\\", \\\"{x:1551,y:355,t:1526922964818};\\\", \\\"{x:1551,y:349,t:1526922964835};\\\", \\\"{x:1551,y:343,t:1526922964851};\\\", \\\"{x:1551,y:336,t:1526922964869};\\\", \\\"{x:1551,y:332,t:1526922964884};\\\", \\\"{x:1551,y:326,t:1526922964902};\\\", \\\"{x:1551,y:319,t:1526922964918};\\\", \\\"{x:1550,y:312,t:1526922964934};\\\", \\\"{x:1550,y:306,t:1526922964951};\\\", \\\"{x:1550,y:301,t:1526922964969};\\\", \\\"{x:1550,y:294,t:1526922964985};\\\", \\\"{x:1550,y:287,t:1526922965001};\\\", \\\"{x:1550,y:273,t:1526922965019};\\\", \\\"{x:1550,y:263,t:1526922965035};\\\", \\\"{x:1550,y:255,t:1526922965051};\\\", \\\"{x:1550,y:246,t:1526922965068};\\\", \\\"{x:1550,y:239,t:1526922965085};\\\", \\\"{x:1550,y:233,t:1526922965102};\\\", \\\"{x:1550,y:228,t:1526922965119};\\\", \\\"{x:1550,y:224,t:1526922965136};\\\", \\\"{x:1550,y:222,t:1526922965151};\\\", \\\"{x:1549,y:221,t:1526922965289};\\\", \\\"{x:1548,y:221,t:1526922965321};\\\", \\\"{x:1547,y:221,t:1526922965345};\\\", \\\"{x:1551,y:223,t:1526922965571};\\\", \\\"{x:1558,y:227,t:1526922965586};\\\", \\\"{x:1565,y:230,t:1526922965602};\\\", \\\"{x:1569,y:233,t:1526922965619};\\\", \\\"{x:1573,y:235,t:1526922965636};\\\", \\\"{x:1576,y:237,t:1526922965652};\\\", \\\"{x:1580,y:240,t:1526922965669};\\\", \\\"{x:1583,y:243,t:1526922965685};\\\", \\\"{x:1587,y:248,t:1526922965702};\\\", \\\"{x:1591,y:259,t:1526922965720};\\\", \\\"{x:1598,y:280,t:1526922965735};\\\", \\\"{x:1605,y:307,t:1526922965753};\\\", \\\"{x:1615,y:351,t:1526922965770};\\\", \\\"{x:1620,y:395,t:1526922965785};\\\", \\\"{x:1632,y:496,t:1526922965802};\\\", \\\"{x:1632,y:557,t:1526922965820};\\\", \\\"{x:1632,y:608,t:1526922965836};\\\", \\\"{x:1632,y:644,t:1526922965853};\\\", \\\"{x:1632,y:671,t:1526922965869};\\\", \\\"{x:1633,y:692,t:1526922965885};\\\", \\\"{x:1637,y:711,t:1526922965902};\\\", \\\"{x:1639,y:722,t:1526922965920};\\\", \\\"{x:1640,y:725,t:1526922965936};\\\", \\\"{x:1641,y:729,t:1526922965953};\\\", \\\"{x:1637,y:726,t:1526922966066};\\\", \\\"{x:1632,y:718,t:1526922966074};\\\", \\\"{x:1626,y:712,t:1526922966086};\\\", \\\"{x:1617,y:705,t:1526922966102};\\\", \\\"{x:1614,y:702,t:1526922966120};\\\", \\\"{x:1612,y:701,t:1526922966135};\\\", \\\"{x:1611,y:699,t:1526922966152};\\\", \\\"{x:1610,y:697,t:1526922966169};\\\", \\\"{x:1609,y:697,t:1526922966185};\\\", \\\"{x:1609,y:696,t:1526922966202};\\\", \\\"{x:1608,y:694,t:1526922966219};\\\", \\\"{x:1608,y:693,t:1526922966249};\\\", \\\"{x:1608,y:692,t:1526922966257};\\\", \\\"{x:1608,y:691,t:1526922966269};\\\", \\\"{x:1607,y:691,t:1526922966285};\\\", \\\"{x:1607,y:689,t:1526922966303};\\\", \\\"{x:1606,y:688,t:1526922966319};\\\", \\\"{x:1606,y:687,t:1526922966337};\\\", \\\"{x:1606,y:686,t:1526922966354};\\\", \\\"{x:1606,y:685,t:1526922966378};\\\", \\\"{x:1606,y:684,t:1526922966434};\\\", \\\"{x:1606,y:683,t:1526922966450};\\\", \\\"{x:1606,y:682,t:1526922966466};\\\", \\\"{x:1606,y:681,t:1526922966498};\\\", \\\"{x:1606,y:680,t:1526922966507};\\\", \\\"{x:1606,y:679,t:1526922966519};\\\", \\\"{x:1606,y:678,t:1526922966537};\\\", \\\"{x:1607,y:675,t:1526922966553};\\\", \\\"{x:1607,y:672,t:1526922966570};\\\", \\\"{x:1607,y:669,t:1526922966586};\\\", \\\"{x:1607,y:666,t:1526922966604};\\\", \\\"{x:1607,y:663,t:1526922966620};\\\", \\\"{x:1607,y:658,t:1526922966636};\\\", \\\"{x:1607,y:652,t:1526922966653};\\\", \\\"{x:1607,y:644,t:1526922966669};\\\", \\\"{x:1606,y:634,t:1526922966686};\\\", \\\"{x:1603,y:620,t:1526922966703};\\\", \\\"{x:1602,y:611,t:1526922966719};\\\", \\\"{x:1602,y:605,t:1526922966736};\\\", \\\"{x:1599,y:597,t:1526922966754};\\\", \\\"{x:1598,y:591,t:1526922966769};\\\", \\\"{x:1598,y:587,t:1526922966786};\\\", \\\"{x:1597,y:582,t:1526922966803};\\\", \\\"{x:1597,y:578,t:1526922966819};\\\", \\\"{x:1597,y:575,t:1526922966836};\\\", \\\"{x:1597,y:574,t:1526922966854};\\\", \\\"{x:1597,y:572,t:1526922966869};\\\", \\\"{x:1597,y:570,t:1526922966886};\\\", \\\"{x:1597,y:569,t:1526922966914};\\\", \\\"{x:1597,y:567,t:1526922966970};\\\", \\\"{x:1597,y:569,t:1526922967082};\\\", \\\"{x:1597,y:578,t:1526922967090};\\\", \\\"{x:1597,y:589,t:1526922967104};\\\", \\\"{x:1597,y:611,t:1526922967120};\\\", \\\"{x:1597,y:629,t:1526922967137};\\\", \\\"{x:1597,y:653,t:1526922967154};\\\", \\\"{x:1601,y:668,t:1526922967170};\\\", \\\"{x:1605,y:682,t:1526922967187};\\\", \\\"{x:1606,y:690,t:1526922967203};\\\", \\\"{x:1608,y:693,t:1526922967221};\\\", \\\"{x:1608,y:697,t:1526922967237};\\\", \\\"{x:1609,y:699,t:1526922967254};\\\", \\\"{x:1609,y:698,t:1526922967379};\\\", \\\"{x:1609,y:697,t:1526922967387};\\\", \\\"{x:1609,y:695,t:1526922967404};\\\", \\\"{x:1609,y:692,t:1526922967423};\\\", \\\"{x:1609,y:688,t:1526922967437};\\\", \\\"{x:1610,y:685,t:1526922967454};\\\", \\\"{x:1611,y:681,t:1526922967470};\\\", \\\"{x:1611,y:679,t:1526922967487};\\\", \\\"{x:1612,y:677,t:1526922967504};\\\", \\\"{x:1613,y:675,t:1526922967521};\\\", \\\"{x:1613,y:673,t:1526922967538};\\\", \\\"{x:1613,y:677,t:1526922967651};\\\", \\\"{x:1613,y:680,t:1526922967658};\\\", \\\"{x:1613,y:684,t:1526922967670};\\\", \\\"{x:1613,y:698,t:1526922967689};\\\", \\\"{x:1616,y:715,t:1526922967705};\\\", \\\"{x:1620,y:732,t:1526922967720};\\\", \\\"{x:1626,y:749,t:1526922967738};\\\", \\\"{x:1628,y:765,t:1526922967754};\\\", \\\"{x:1632,y:788,t:1526922967771};\\\", \\\"{x:1632,y:815,t:1526922967787};\\\", \\\"{x:1631,y:837,t:1526922967804};\\\", \\\"{x:1629,y:857,t:1526922967822};\\\", \\\"{x:1626,y:875,t:1526922967837};\\\", \\\"{x:1621,y:890,t:1526922967853};\\\", \\\"{x:1618,y:905,t:1526922967871};\\\", \\\"{x:1614,y:916,t:1526922967888};\\\", \\\"{x:1611,y:929,t:1526922967904};\\\", \\\"{x:1610,y:939,t:1526922967921};\\\", \\\"{x:1610,y:947,t:1526922967938};\\\", \\\"{x:1609,y:950,t:1526922967954};\\\", \\\"{x:1609,y:954,t:1526922967971};\\\", \\\"{x:1609,y:955,t:1526922967987};\\\", \\\"{x:1609,y:957,t:1526922968003};\\\", \\\"{x:1608,y:957,t:1526922968130};\\\", \\\"{x:1607,y:952,t:1526922968138};\\\", \\\"{x:1603,y:938,t:1526922968154};\\\", \\\"{x:1603,y:924,t:1526922968171};\\\", \\\"{x:1601,y:909,t:1526922968187};\\\", \\\"{x:1600,y:891,t:1526922968205};\\\", \\\"{x:1597,y:870,t:1526922968221};\\\", \\\"{x:1595,y:860,t:1526922968237};\\\", \\\"{x:1592,y:848,t:1526922968254};\\\", \\\"{x:1590,y:839,t:1526922968270};\\\", \\\"{x:1588,y:830,t:1526922968288};\\\", \\\"{x:1587,y:818,t:1526922968304};\\\", \\\"{x:1586,y:786,t:1526922968321};\\\", \\\"{x:1586,y:773,t:1526922968337};\\\", \\\"{x:1586,y:756,t:1526922968354};\\\", \\\"{x:1586,y:740,t:1526922968372};\\\", \\\"{x:1587,y:722,t:1526922968387};\\\", \\\"{x:1590,y:706,t:1526922968404};\\\", \\\"{x:1595,y:692,t:1526922968422};\\\", \\\"{x:1598,y:679,t:1526922968437};\\\", \\\"{x:1598,y:670,t:1526922968454};\\\", \\\"{x:1600,y:661,t:1526922968471};\\\", \\\"{x:1603,y:654,t:1526922968487};\\\", \\\"{x:1606,y:648,t:1526922968504};\\\", \\\"{x:1616,y:630,t:1526922968522};\\\", \\\"{x:1621,y:617,t:1526922968538};\\\", \\\"{x:1623,y:605,t:1526922968555};\\\", \\\"{x:1624,y:598,t:1526922968572};\\\", \\\"{x:1625,y:593,t:1526922968587};\\\", \\\"{x:1626,y:588,t:1526922968604};\\\", \\\"{x:1627,y:574,t:1526922968621};\\\", \\\"{x:1627,y:554,t:1526922968637};\\\", \\\"{x:1627,y:538,t:1526922968654};\\\", \\\"{x:1624,y:524,t:1526922968672};\\\", \\\"{x:1621,y:514,t:1526922968687};\\\", \\\"{x:1619,y:505,t:1526922968704};\\\", \\\"{x:1616,y:494,t:1526922968721};\\\", \\\"{x:1615,y:489,t:1526922968737};\\\", \\\"{x:1613,y:484,t:1526922968754};\\\", \\\"{x:1612,y:480,t:1526922968771};\\\", \\\"{x:1611,y:477,t:1526922968787};\\\", \\\"{x:1611,y:476,t:1526922968804};\\\", \\\"{x:1610,y:474,t:1526922968821};\\\", \\\"{x:1609,y:473,t:1526922968837};\\\", \\\"{x:1608,y:471,t:1526922968857};\\\", \\\"{x:1607,y:471,t:1526922969115};\\\", \\\"{x:1604,y:471,t:1526922969122};\\\", \\\"{x:1589,y:491,t:1526922969138};\\\", \\\"{x:1575,y:524,t:1526922969155};\\\", \\\"{x:1569,y:550,t:1526922969172};\\\", \\\"{x:1566,y:568,t:1526922969189};\\\", \\\"{x:1566,y:575,t:1526922969205};\\\", \\\"{x:1566,y:576,t:1526922969222};\\\", \\\"{x:1567,y:573,t:1526922969299};\\\", \\\"{x:1567,y:569,t:1526922969306};\\\", \\\"{x:1570,y:561,t:1526922969322};\\\", \\\"{x:1570,y:553,t:1526922969338};\\\", \\\"{x:1571,y:543,t:1526922969356};\\\", \\\"{x:1571,y:535,t:1526922969372};\\\", \\\"{x:1571,y:526,t:1526922969388};\\\", \\\"{x:1571,y:520,t:1526922969406};\\\", \\\"{x:1571,y:515,t:1526922969423};\\\", \\\"{x:1571,y:511,t:1526922969439};\\\", \\\"{x:1573,y:506,t:1526922969456};\\\", \\\"{x:1574,y:504,t:1526922969471};\\\", \\\"{x:1574,y:501,t:1526922969489};\\\", \\\"{x:1574,y:498,t:1526922969506};\\\", \\\"{x:1574,y:497,t:1526922969530};\\\", \\\"{x:1575,y:497,t:1526922969539};\\\", \\\"{x:1576,y:495,t:1526922969557};\\\", \\\"{x:1576,y:494,t:1526922969571};\\\", \\\"{x:1576,y:492,t:1526922969595};\\\", \\\"{x:1576,y:491,t:1526922969618};\\\", \\\"{x:1577,y:490,t:1526922969626};\\\", \\\"{x:1578,y:488,t:1526922969642};\\\", \\\"{x:1578,y:487,t:1526922969690};\\\", \\\"{x:1578,y:486,t:1526922969706};\\\", \\\"{x:1578,y:482,t:1526922970218};\\\", \\\"{x:1578,y:480,t:1526922970225};\\\", \\\"{x:1578,y:476,t:1526922970240};\\\", \\\"{x:1578,y:461,t:1526922970256};\\\", \\\"{x:1578,y:440,t:1526922970272};\\\", \\\"{x:1570,y:408,t:1526922970289};\\\", \\\"{x:1565,y:388,t:1526922970305};\\\", \\\"{x:1558,y:365,t:1526922970322};\\\", \\\"{x:1552,y:342,t:1526922970339};\\\", \\\"{x:1546,y:324,t:1526922970355};\\\", \\\"{x:1540,y:308,t:1526922970372};\\\", \\\"{x:1537,y:300,t:1526922970389};\\\", \\\"{x:1535,y:294,t:1526922970405};\\\", \\\"{x:1535,y:293,t:1526922970422};\\\", \\\"{x:1535,y:292,t:1526922973618};\\\", \\\"{x:1536,y:292,t:1526922973625};\\\", \\\"{x:1541,y:291,t:1526922973641};\\\", \\\"{x:1545,y:289,t:1526922973659};\\\", \\\"{x:1548,y:288,t:1526922973676};\\\", \\\"{x:1541,y:289,t:1526922974419};\\\", \\\"{x:1524,y:296,t:1526922974426};\\\", \\\"{x:1461,y:321,t:1526922974442};\\\", \\\"{x:1375,y:350,t:1526922974459};\\\", \\\"{x:1280,y:377,t:1526922974475};\\\", \\\"{x:1181,y:401,t:1526922974492};\\\", \\\"{x:1099,y:410,t:1526922974509};\\\", \\\"{x:1040,y:427,t:1526922974526};\\\", \\\"{x:1008,y:446,t:1526922974542};\\\", \\\"{x:994,y:455,t:1526922974559};\\\", \\\"{x:989,y:460,t:1526922974575};\\\", \\\"{x:988,y:462,t:1526922974592};\\\", \\\"{x:988,y:464,t:1526922974610};\\\", \\\"{x:988,y:465,t:1526922974633};\\\", \\\"{x:988,y:466,t:1526922974649};\\\", \\\"{x:988,y:467,t:1526922974666};\\\", \\\"{x:986,y:468,t:1526922974682};\\\", \\\"{x:985,y:470,t:1526922974692};\\\", \\\"{x:978,y:471,t:1526922974710};\\\", \\\"{x:965,y:477,t:1526922974726};\\\", \\\"{x:940,y:480,t:1526922974743};\\\", \\\"{x:902,y:485,t:1526922974759};\\\", \\\"{x:849,y:493,t:1526922974777};\\\", \\\"{x:793,y:501,t:1526922974793};\\\", \\\"{x:752,y:504,t:1526922974809};\\\", \\\"{x:738,y:507,t:1526922974825};\\\", \\\"{x:737,y:507,t:1526922974842};\\\", \\\"{x:734,y:507,t:1526922975058};\\\", \\\"{x:728,y:507,t:1526922975065};\\\", \\\"{x:719,y:507,t:1526922975079};\\\", \\\"{x:698,y:507,t:1526922975092};\\\", \\\"{x:670,y:507,t:1526922975109};\\\", \\\"{x:641,y:507,t:1526922975126};\\\", \\\"{x:612,y:507,t:1526922975142};\\\", \\\"{x:580,y:507,t:1526922975160};\\\", \\\"{x:540,y:507,t:1526922975176};\\\", \\\"{x:509,y:507,t:1526922975193};\\\", \\\"{x:474,y:508,t:1526922975210};\\\", \\\"{x:449,y:510,t:1526922975227};\\\", \\\"{x:432,y:516,t:1526922975242};\\\", \\\"{x:415,y:524,t:1526922975259};\\\", \\\"{x:397,y:532,t:1526922975277};\\\", \\\"{x:375,y:546,t:1526922975293};\\\", \\\"{x:360,y:557,t:1526922975310};\\\", \\\"{x:348,y:569,t:1526922975327};\\\", \\\"{x:334,y:580,t:1526922975344};\\\", \\\"{x:327,y:585,t:1526922975359};\\\", \\\"{x:324,y:587,t:1526922975376};\\\", \\\"{x:327,y:587,t:1526922975537};\\\", \\\"{x:331,y:586,t:1526922975545};\\\", \\\"{x:339,y:582,t:1526922975560};\\\", \\\"{x:355,y:575,t:1526922975576};\\\", \\\"{x:380,y:564,t:1526922975593};\\\", \\\"{x:391,y:560,t:1526922975611};\\\", \\\"{x:392,y:559,t:1526922975627};\\\", \\\"{x:394,y:558,t:1526922975644};\\\", \\\"{x:395,y:558,t:1526922975778};\\\", \\\"{x:400,y:562,t:1526922975794};\\\", \\\"{x:404,y:570,t:1526922975811};\\\", \\\"{x:409,y:581,t:1526922975826};\\\", \\\"{x:413,y:593,t:1526922975843};\\\", \\\"{x:414,y:601,t:1526922975860};\\\", \\\"{x:415,y:610,t:1526922975877};\\\", \\\"{x:415,y:616,t:1526922975893};\\\", \\\"{x:415,y:623,t:1526922975910};\\\", \\\"{x:415,y:628,t:1526922975926};\\\", \\\"{x:415,y:632,t:1526922975944};\\\", \\\"{x:414,y:632,t:1526922976066};\\\", \\\"{x:413,y:631,t:1526922976078};\\\", \\\"{x:413,y:627,t:1526922976093};\\\", \\\"{x:413,y:620,t:1526922976111};\\\", \\\"{x:413,y:612,t:1526922976127};\\\", \\\"{x:413,y:604,t:1526922976144};\\\", \\\"{x:413,y:598,t:1526922976161};\\\", \\\"{x:413,y:587,t:1526922976178};\\\", \\\"{x:413,y:582,t:1526922976193};\\\", \\\"{x:413,y:579,t:1526922976210};\\\", \\\"{x:413,y:577,t:1526922976226};\\\", \\\"{x:413,y:576,t:1526922976244};\\\", \\\"{x:415,y:568,t:1526922981314};\\\", \\\"{x:426,y:556,t:1526922981332};\\\", \\\"{x:448,y:541,t:1526922981348};\\\", \\\"{x:479,y:522,t:1526922981364};\\\", \\\"{x:561,y:482,t:1526922981398};\\\", \\\"{x:600,y:477,t:1526922981415};\\\", \\\"{x:626,y:474,t:1526922981431};\\\", \\\"{x:645,y:474,t:1526922981448};\\\", \\\"{x:655,y:474,t:1526922981464};\\\", \\\"{x:662,y:478,t:1526922981481};\\\", \\\"{x:664,y:485,t:1526922981497};\\\", \\\"{x:667,y:499,t:1526922981515};\\\", \\\"{x:667,y:513,t:1526922981531};\\\", \\\"{x:667,y:526,t:1526922981549};\\\", \\\"{x:662,y:538,t:1526922981564};\\\", \\\"{x:655,y:549,t:1526922981582};\\\", \\\"{x:645,y:560,t:1526922981598};\\\", \\\"{x:637,y:567,t:1526922981615};\\\", \\\"{x:631,y:574,t:1526922981632};\\\", \\\"{x:627,y:576,t:1526922981647};\\\", \\\"{x:624,y:577,t:1526922981665};\\\", \\\"{x:622,y:577,t:1526922981722};\\\", \\\"{x:621,y:576,t:1526922981732};\\\", \\\"{x:620,y:563,t:1526922981749};\\\", \\\"{x:620,y:553,t:1526922981765};\\\", \\\"{x:620,y:542,t:1526922981781};\\\", \\\"{x:621,y:537,t:1526922981799};\\\", \\\"{x:621,y:534,t:1526922981814};\\\", \\\"{x:622,y:532,t:1526922981831};\\\", \\\"{x:624,y:532,t:1526922982009};\\\", \\\"{x:630,y:532,t:1526922982017};\\\", \\\"{x:644,y:529,t:1526922982032};\\\", \\\"{x:703,y:520,t:1526922982049};\\\", \\\"{x:826,y:501,t:1526922982065};\\\", \\\"{x:1087,y:463,t:1526922982083};\\\", \\\"{x:1265,y:430,t:1526922982099};\\\", \\\"{x:1422,y:385,t:1526922982115};\\\", \\\"{x:1538,y:332,t:1526922982131};\\\", \\\"{x:1631,y:258,t:1526922982149};\\\", \\\"{x:1680,y:208,t:1526922982165};\\\", \\\"{x:1705,y:171,t:1526922982181};\\\", \\\"{x:1721,y:142,t:1526922982199};\\\", \\\"{x:1731,y:120,t:1526922982215};\\\", \\\"{x:1740,y:101,t:1526922982232};\\\", \\\"{x:1747,y:85,t:1526922982249};\\\", \\\"{x:1768,y:64,t:1526922982265};\\\", \\\"{x:1774,y:58,t:1526922982281};\\\", \\\"{x:1918,y:0,t:1526922982385};\\\", \\\"{x:1921,y:0,t:1526922982416};\\\", \\\"{x:1922,y:2,t:1526922982538};\\\", \\\"{x:1922,y:3,t:1526922982549};\\\", \\\"{x:1922,y:5,t:1526922982566};\\\", \\\"{x:1922,y:8,t:1526922982583};\\\", \\\"{x:1922,y:12,t:1526922982599};\\\", \\\"{x:1922,y:15,t:1526922982615};\\\", \\\"{x:1922,y:17,t:1526922982632};\\\", \\\"{x:1921,y:19,t:1526922982648};\\\", \\\"{x:1919,y:21,t:1526922982665};\\\", \\\"{x:1892,y:24,t:1526922983219};\\\", \\\"{x:1891,y:24,t:1526922983233};\\\", \\\"{x:1891,y:23,t:1526922983257};\\\", \\\"{x:1891,y:22,t:1526922983281};\\\", \\\"{x:1890,y:22,t:1526922983379};\\\", \\\"{x:1886,y:22,t:1526922983385};\\\", \\\"{x:1871,y:30,t:1526922983401};\\\", \\\"{x:1803,y:69,t:1526922983416};\\\", \\\"{x:1646,y:169,t:1526922983434};\\\", \\\"{x:1321,y:382,t:1526922983450};\\\", \\\"{x:1098,y:516,t:1526922983467};\\\", \\\"{x:879,y:632,t:1526922983484};\\\", \\\"{x:687,y:704,t:1526922983500};\\\", \\\"{x:546,y:743,t:1526922983519};\\\", \\\"{x:463,y:755,t:1526922983534};\\\", \\\"{x:435,y:756,t:1526922983550};\\\", \\\"{x:433,y:756,t:1526922983566};\\\", \\\"{x:435,y:756,t:1526922983584};\\\", \\\"{x:443,y:753,t:1526922983600};\\\", \\\"{x:465,y:742,t:1526922983617};\\\", \\\"{x:474,y:738,t:1526922983633};\\\", \\\"{x:482,y:733,t:1526922983650};\\\", \\\"{x:491,y:728,t:1526922983666};\\\", \\\"{x:502,y:720,t:1526922983683};\\\", \\\"{x:508,y:713,t:1526922983700};\\\", \\\"{x:515,y:708,t:1526922983715};\\\", \\\"{x:518,y:705,t:1526922983733};\\\", \\\"{x:520,y:703,t:1526922983750};\\\", \\\"{x:521,y:703,t:1526922983767};\\\", \\\"{x:522,y:701,t:1526922984009};\\\", \\\"{x:523,y:701,t:1526922984017};\\\", \\\"{x:523,y:702,t:1526922984049};\\\", \\\"{x:527,y:714,t:1526922984067};\\\", \\\"{x:529,y:723,t:1526922984084};\\\", \\\"{x:531,y:730,t:1526922984101};\\\", \\\"{x:531,y:731,t:1526922984117};\\\", \\\"{x:532,y:732,t:1526922984194};\\\", \\\"{x:533,y:732,t:1526922984265};\\\", \\\"{x:533,y:732,t:1526922984331};\\\", \\\"{x:534,y:732,t:1526922984577};\\\", \\\"{x:534,y:731,t:1526922984601};\\\", \\\"{x:535,y:730,t:1526922984641};\\\" ] }, { \\\"rt\\\": 7638, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 604804, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:729,t:1526922986466};\\\", \\\"{x:582,y:721,t:1526922986483};\\\", \\\"{x:663,y:710,t:1526922986500};\\\", \\\"{x:751,y:698,t:1526922986518};\\\", \\\"{x:843,y:683,t:1526922986535};\\\", \\\"{x:913,y:674,t:1526922986552};\\\", \\\"{x:952,y:667,t:1526922986568};\\\", \\\"{x:957,y:666,t:1526922986585};\\\", \\\"{x:959,y:666,t:1526922986601};\\\", \\\"{x:963,y:661,t:1526922986619};\\\", \\\"{x:964,y:659,t:1526922986636};\\\", \\\"{x:966,y:655,t:1526922986651};\\\", \\\"{x:966,y:654,t:1526922986669};\\\", \\\"{x:967,y:652,t:1526922986686};\\\", \\\"{x:969,y:647,t:1526922986702};\\\", \\\"{x:970,y:642,t:1526922986719};\\\", \\\"{x:971,y:638,t:1526922986737};\\\", \\\"{x:972,y:635,t:1526922986752};\\\", \\\"{x:973,y:632,t:1526922986769};\\\", \\\"{x:970,y:631,t:1526922990477};\\\", \\\"{x:959,y:631,t:1526922990492};\\\", \\\"{x:917,y:631,t:1526922990509};\\\", \\\"{x:885,y:631,t:1526922990526};\\\", \\\"{x:858,y:629,t:1526922990543};\\\", \\\"{x:844,y:626,t:1526922990558};\\\", \\\"{x:840,y:625,t:1526922990575};\\\", \\\"{x:839,y:624,t:1526922990592};\\\", \\\"{x:837,y:622,t:1526922990609};\\\", \\\"{x:836,y:621,t:1526922990625};\\\", \\\"{x:835,y:619,t:1526922990643};\\\", \\\"{x:833,y:617,t:1526922990659};\\\", \\\"{x:833,y:616,t:1526922990675};\\\", \\\"{x:833,y:615,t:1526922990868};\\\", \\\"{x:833,y:612,t:1526922990876};\\\", \\\"{x:840,y:602,t:1526922990892};\\\", \\\"{x:844,y:596,t:1526922990910};\\\", \\\"{x:845,y:592,t:1526922990926};\\\", \\\"{x:845,y:588,t:1526922990942};\\\", \\\"{x:843,y:591,t:1526922991269};\\\", \\\"{x:837,y:600,t:1526922991278};\\\", \\\"{x:819,y:614,t:1526922991293};\\\", \\\"{x:810,y:619,t:1526922991309};\\\", \\\"{x:808,y:619,t:1526922991326};\\\", \\\"{x:807,y:619,t:1526922991343};\\\", \\\"{x:807,y:612,t:1526922991360};\\\", \\\"{x:807,y:593,t:1526922991377};\\\", \\\"{x:811,y:568,t:1526922991392};\\\", \\\"{x:822,y:541,t:1526922991411};\\\", \\\"{x:837,y:495,t:1526922991427};\\\", \\\"{x:843,y:480,t:1526922991443};\\\", \\\"{x:845,y:478,t:1526922991460};\\\", \\\"{x:847,y:480,t:1526922991532};\\\", \\\"{x:851,y:489,t:1526922991543};\\\", \\\"{x:857,y:504,t:1526922991560};\\\", \\\"{x:862,y:516,t:1526922991577};\\\", \\\"{x:866,y:529,t:1526922991593};\\\", \\\"{x:867,y:542,t:1526922991610};\\\", \\\"{x:867,y:546,t:1526922991627};\\\", \\\"{x:867,y:547,t:1526922991644};\\\", \\\"{x:867,y:545,t:1526922991725};\\\", \\\"{x:867,y:540,t:1526922991733};\\\", \\\"{x:867,y:534,t:1526922991744};\\\", \\\"{x:867,y:526,t:1526922991762};\\\", \\\"{x:868,y:518,t:1526922991777};\\\", \\\"{x:869,y:512,t:1526922991794};\\\", \\\"{x:869,y:506,t:1526922991810};\\\", \\\"{x:869,y:503,t:1526922991826};\\\", \\\"{x:869,y:502,t:1526922991844};\\\", \\\"{x:869,y:501,t:1526922991859};\\\", \\\"{x:869,y:499,t:1526922991877};\\\", \\\"{x:869,y:498,t:1526922991925};\\\", \\\"{x:868,y:498,t:1526922991957};\\\", \\\"{x:867,y:498,t:1526922991973};\\\", \\\"{x:866,y:496,t:1526922991994};\\\", \\\"{x:863,y:496,t:1526922992492};\\\", \\\"{x:857,y:498,t:1526922992500};\\\", \\\"{x:847,y:509,t:1526922992510};\\\", \\\"{x:808,y:549,t:1526922992527};\\\", \\\"{x:744,y:616,t:1526922992544};\\\", \\\"{x:659,y:687,t:1526922992561};\\\", \\\"{x:581,y:765,t:1526922992577};\\\", \\\"{x:540,y:796,t:1526922992593};\\\", \\\"{x:524,y:808,t:1526922992610};\\\", \\\"{x:515,y:813,t:1526922992628};\\\", \\\"{x:509,y:815,t:1526922992644};\\\", \\\"{x:508,y:816,t:1526922992661};\\\", \\\"{x:507,y:816,t:1526922992701};\\\", \\\"{x:507,y:815,t:1526922992711};\\\", \\\"{x:507,y:808,t:1526922992728};\\\", \\\"{x:507,y:797,t:1526922992744};\\\", \\\"{x:508,y:779,t:1526922992761};\\\", \\\"{x:515,y:762,t:1526922992777};\\\", \\\"{x:522,y:746,t:1526922992795};\\\", \\\"{x:532,y:729,t:1526922992810};\\\", \\\"{x:538,y:712,t:1526922992828};\\\", \\\"{x:542,y:698,t:1526922992843};\\\", \\\"{x:542,y:691,t:1526922992860};\\\", \\\"{x:543,y:691,t:1526922992877};\\\", \\\"{x:543,y:690,t:1526922992900};\\\", \\\"{x:543,y:695,t:1526922993013};\\\", \\\"{x:543,y:703,t:1526922993028};\\\", \\\"{x:543,y:714,t:1526922993044};\\\", \\\"{x:543,y:721,t:1526922993062};\\\", \\\"{x:543,y:724,t:1526922993078};\\\", \\\"{x:545,y:723,t:1526922993340};\\\", \\\"{x:546,y:722,t:1526922993348};\\\", \\\"{x:547,y:721,t:1526922993360};\\\", \\\"{x:548,y:721,t:1526922993380};\\\", \\\"{x:549,y:720,t:1526922993404};\\\", \\\"{x:551,y:725,t:1526922993604};\\\", \\\"{x:554,y:736,t:1526922993613};\\\", \\\"{x:557,y:750,t:1526922993628};\\\", \\\"{x:563,y:803,t:1526922993645};\\\", \\\"{x:563,y:848,t:1526922993661};\\\", \\\"{x:563,y:921,t:1526922993677};\\\", \\\"{x:563,y:1012,t:1526922993695};\\\", \\\"{x:563,y:1123,t:1526922993712};\\\", \\\"{x:562,y:1199,t:1526922993728};\\\", \\\"{x:552,y:1199,t:1526922993744};\\\", \\\"{x:540,y:1199,t:1526922993762};\\\", \\\"{x:518,y:1199,t:1526922993778};\\\", \\\"{x:509,y:1199,t:1526922993795};\\\", \\\"{x:504,y:1199,t:1526922993812};\\\", \\\"{x:502,y:1199,t:1526922993828};\\\", \\\"{x:497,y:1199,t:1526922993845};\\\", \\\"{x:495,y:1199,t:1526922993862};\\\", \\\"{x:493,y:1199,t:1526922993878};\\\", \\\"{x:499,y:1199,t:1526922993901};\\\", \\\"{x:503,y:1199,t:1526922993912};\\\", \\\"{x:525,y:1199,t:1526922993928};\\\", \\\"{x:551,y:1199,t:1526922993945};\\\", \\\"{x:582,y:1199,t:1526922993962};\\\", \\\"{x:615,y:1199,t:1526922993979};\\\", \\\"{x:646,y:1199,t:1526922993995};\\\", \\\"{x:681,y:1199,t:1526922994012};\\\", \\\"{x:721,y:1199,t:1526922994028};\\\", \\\"{x:779,y:1199,t:1526922994044};\\\", \\\"{x:810,y:1199,t:1526922994061};\\\", \\\"{x:845,y:1199,t:1526922994079};\\\", \\\"{x:872,y:1199,t:1526922994095};\\\", \\\"{x:907,y:1199,t:1526922994112};\\\", \\\"{x:934,y:1199,t:1526922994129};\\\", \\\"{x:959,y:1199,t:1526922994144};\\\", \\\"{x:989,y:1199,t:1526922994162};\\\", \\\"{x:1011,y:1199,t:1526922994179};\\\", \\\"{x:1039,y:1199,t:1526922994195};\\\", \\\"{x:1072,y:1199,t:1526922994212};\\\", \\\"{x:1104,y:1199,t:1526922994229};\\\", \\\"{x:1137,y:1199,t:1526922994245};\\\", \\\"{x:1156,y:1199,t:1526922994262};\\\", \\\"{x:1179,y:1199,t:1526922994296};\\\", \\\"{x:1184,y:1199,t:1526922994311};\\\", \\\"{x:1186,y:1199,t:1526922994328};\\\", \\\"{x:1189,y:1199,t:1526922994345};\\\", \\\"{x:1185,y:1199,t:1526922994372};\\\" ] }, { \\\"rt\\\": 18143, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 624185, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 5.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"G\\\", \\\"O\\\", \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:676,y:1199,t:1526922994495};\\\", \\\"{x:514,y:1199,t:1526922994512};\\\", \\\"{x:347,y:1199,t:1526922994528};\\\", \\\"{x:164,y:1199,t:1526922994546};\\\", \\\"{x:8,y:1199,t:1526922994562};\\\", \\\"{x:8,y:1188,t:1526922994741};\\\", \\\"{x:8,y:1165,t:1526922994748};\\\", \\\"{x:8,y:1135,t:1526922994762};\\\", \\\"{x:13,y:1042,t:1526922994779};\\\", \\\"{x:45,y:846,t:1526922994796};\\\", \\\"{x:60,y:761,t:1526922994811};\\\", \\\"{x:106,y:453,t:1526922994829};\\\", \\\"{x:153,y:234,t:1526922994846};\\\", \\\"{x:217,y:0,t:1526922994862};\\\", \\\"{x:532,y:0,t:1526922994929};\\\", \\\"{x:613,y:0,t:1526922994948};\\\", \\\"{x:634,y:0,t:1526922994963};\\\", \\\"{x:672,y:0,t:1526922994978};\\\", \\\"{x:696,y:0,t:1526922994995};\\\", \\\"{x:731,y:0,t:1526922995012};\\\", \\\"{x:739,y:0,t:1526922995029};\\\", \\\"{x:740,y:0,t:1526922995046};\\\", \\\"{x:743,y:6,t:1526922995117};\\\", \\\"{x:747,y:20,t:1526922995129};\\\", \\\"{x:757,y:70,t:1526922995146};\\\", \\\"{x:767,y:121,t:1526922995162};\\\", \\\"{x:776,y:155,t:1526922995179};\\\", \\\"{x:781,y:178,t:1526922995195};\\\", \\\"{x:783,y:198,t:1526922995212};\\\", \\\"{x:784,y:202,t:1526922995229};\\\", \\\"{x:784,y:206,t:1526922995245};\\\", \\\"{x:782,y:207,t:1526922995263};\\\", \\\"{x:781,y:209,t:1526922995279};\\\", \\\"{x:780,y:208,t:1526922995412};\\\", \\\"{x:774,y:194,t:1526922995428};\\\", \\\"{x:766,y:175,t:1526922995445};\\\", \\\"{x:758,y:157,t:1526922995462};\\\", \\\"{x:750,y:143,t:1526922995478};\\\", \\\"{x:745,y:135,t:1526922995495};\\\", \\\"{x:744,y:133,t:1526922995513};\\\", \\\"{x:742,y:131,t:1526922995529};\\\", \\\"{x:742,y:130,t:1526922995546};\\\", \\\"{x:742,y:129,t:1526922995563};\\\", \\\"{x:741,y:128,t:1526922995580};\\\", \\\"{x:741,y:127,t:1526922995621};\\\", \\\"{x:741,y:126,t:1526922995629};\\\", \\\"{x:741,y:123,t:1526922995646};\\\", \\\"{x:741,y:120,t:1526922995663};\\\", \\\"{x:742,y:116,t:1526922995680};\\\", \\\"{x:743,y:112,t:1526922995696};\\\", \\\"{x:743,y:111,t:1526922995716};\\\", \\\"{x:742,y:112,t:1526922995869};\\\", \\\"{x:741,y:113,t:1526922995880};\\\", \\\"{x:739,y:114,t:1526922995896};\\\", \\\"{x:739,y:113,t:1526922996164};\\\", \\\"{x:739,y:111,t:1526922996180};\\\", \\\"{x:740,y:103,t:1526922996195};\\\", \\\"{x:743,y:96,t:1526922996213};\\\", \\\"{x:744,y:92,t:1526922996230};\\\", \\\"{x:745,y:89,t:1526922996246};\\\", \\\"{x:745,y:88,t:1526922996263};\\\", \\\"{x:746,y:87,t:1526922996280};\\\", \\\"{x:746,y:80,t:1526923007621};\\\", \\\"{x:747,y:71,t:1526923007636};\\\", \\\"{x:752,y:17,t:1526923007652};\\\", \\\"{x:755,y:0,t:1526923007669};\\\", \\\"{x:768,y:0,t:1526923007685};\\\", \\\"{x:779,y:0,t:1526923007703};\\\", \\\"{x:791,y:0,t:1526923007719};\\\", \\\"{x:802,y:0,t:1526923007735};\\\", \\\"{x:818,y:0,t:1526923007752};\\\", \\\"{x:828,y:0,t:1526923007769};\\\", \\\"{x:842,y:0,t:1526923007786};\\\", \\\"{x:860,y:0,t:1526923007802};\\\", \\\"{x:878,y:0,t:1526923007819};\\\", \\\"{x:901,y:0,t:1526923007836};\\\", \\\"{x:938,y:0,t:1526923007853};\\\", \\\"{x:962,y:0,t:1526923007869};\\\", \\\"{x:986,y:0,t:1526923007886};\\\", \\\"{x:1010,y:0,t:1526923007903};\\\", \\\"{x:1035,y:0,t:1526923007920};\\\", \\\"{x:1060,y:0,t:1526923007935};\\\", \\\"{x:1076,y:0,t:1526923007952};\\\", \\\"{x:1093,y:0,t:1526923007970};\\\", \\\"{x:1107,y:0,t:1526923007986};\\\", \\\"{x:1116,y:0,t:1526923008003};\\\", \\\"{x:1124,y:0,t:1526923008019};\\\", \\\"{x:1129,y:0,t:1526923008036};\\\", \\\"{x:1140,y:0,t:1526923008052};\\\", \\\"{x:1148,y:0,t:1526923008069};\\\", \\\"{x:1159,y:0,t:1526923008086};\\\", \\\"{x:1172,y:0,t:1526923008102};\\\", \\\"{x:1191,y:0,t:1526923008120};\\\", \\\"{x:1212,y:0,t:1526923008136};\\\", \\\"{x:1238,y:0,t:1526923008152};\\\", \\\"{x:1269,y:0,t:1526923008169};\\\", \\\"{x:1306,y:0,t:1526923008185};\\\", \\\"{x:1343,y:0,t:1526923008203};\\\", \\\"{x:1379,y:0,t:1526923008219};\\\", \\\"{x:1411,y:0,t:1526923008235};\\\", \\\"{x:1453,y:0,t:1526923008253};\\\", \\\"{x:1476,y:0,t:1526923008269};\\\", \\\"{x:1488,y:0,t:1526923008286};\\\", \\\"{x:1494,y:0,t:1526923008302};\\\", \\\"{x:1496,y:0,t:1526923008319};\\\", \\\"{x:1497,y:9,t:1526923008381};\\\", \\\"{x:1497,y:25,t:1526923008389};\\\", \\\"{x:1497,y:48,t:1526923008403};\\\", \\\"{x:1489,y:96,t:1526923008420};\\\", \\\"{x:1473,y:144,t:1526923008436};\\\", \\\"{x:1445,y:197,t:1526923008452};\\\", \\\"{x:1426,y:219,t:1526923008470};\\\", \\\"{x:1404,y:238,t:1526923008486};\\\", \\\"{x:1387,y:247,t:1526923008503};\\\", \\\"{x:1365,y:260,t:1526923008520};\\\", \\\"{x:1336,y:277,t:1526923008536};\\\", \\\"{x:1299,y:297,t:1526923008552};\\\", \\\"{x:1250,y:324,t:1526923008570};\\\", \\\"{x:1214,y:346,t:1526923008586};\\\", \\\"{x:1191,y:365,t:1526923008603};\\\", \\\"{x:1147,y:390,t:1526923008620};\\\", \\\"{x:1075,y:437,t:1526923008636};\\\", \\\"{x:1023,y:469,t:1526923008652};\\\", \\\"{x:983,y:488,t:1526923008669};\\\", \\\"{x:960,y:502,t:1526923008686};\\\", \\\"{x:933,y:520,t:1526923008703};\\\", \\\"{x:909,y:530,t:1526923008719};\\\", \\\"{x:889,y:539,t:1526923008737};\\\", \\\"{x:876,y:546,t:1526923008757};\\\", \\\"{x:877,y:546,t:1526923008868};\\\", \\\"{x:877,y:547,t:1526923009157};\\\", \\\"{x:869,y:558,t:1526923009176};\\\", \\\"{x:861,y:566,t:1526923009191};\\\", \\\"{x:856,y:569,t:1526923009207};\\\", \\\"{x:854,y:571,t:1526923009224};\\\", \\\"{x:853,y:571,t:1526923009241};\\\", \\\"{x:853,y:573,t:1526923009332};\\\", \\\"{x:852,y:576,t:1526923009340};\\\", \\\"{x:851,y:578,t:1526923009358};\\\", \\\"{x:850,y:581,t:1526923009374};\\\", \\\"{x:850,y:582,t:1526923009391};\\\", \\\"{x:850,y:583,t:1526923009407};\\\", \\\"{x:848,y:586,t:1526923009424};\\\", \\\"{x:848,y:588,t:1526923009441};\\\", \\\"{x:848,y:589,t:1526923009457};\\\", \\\"{x:848,y:590,t:1526923009474};\\\", \\\"{x:847,y:590,t:1526923009596};\\\", \\\"{x:847,y:590,t:1526923009608};\\\", \\\"{x:846,y:591,t:1526923009624};\\\", \\\"{x:845,y:591,t:1526923009641};\\\", \\\"{x:841,y:591,t:1526923009668};\\\", \\\"{x:836,y:591,t:1526923009676};\\\", \\\"{x:830,y:591,t:1526923009691};\\\", \\\"{x:816,y:582,t:1526923009707};\\\", \\\"{x:801,y:567,t:1526923009724};\\\", \\\"{x:799,y:556,t:1526923009741};\\\", \\\"{x:799,y:547,t:1526923009757};\\\", \\\"{x:803,y:538,t:1526923009775};\\\", \\\"{x:809,y:533,t:1526923009791};\\\", \\\"{x:811,y:531,t:1526923009808};\\\", \\\"{x:812,y:531,t:1526923009824};\\\", \\\"{x:812,y:534,t:1526923010094};\\\", \\\"{x:814,y:540,t:1526923010108};\\\", \\\"{x:817,y:548,t:1526923010124};\\\", \\\"{x:818,y:554,t:1526923010141};\\\", \\\"{x:821,y:558,t:1526923010158};\\\", \\\"{x:821,y:560,t:1526923010174};\\\", \\\"{x:822,y:561,t:1526923010389};\\\", \\\"{x:824,y:561,t:1526923010398};\\\", \\\"{x:828,y:560,t:1526923010408};\\\", \\\"{x:835,y:556,t:1526923010426};\\\", \\\"{x:838,y:552,t:1526923010442};\\\", \\\"{x:838,y:550,t:1526923010460};\\\", \\\"{x:838,y:549,t:1526923010476};\\\", \\\"{x:838,y:547,t:1526923010507};\\\", \\\"{x:838,y:546,t:1526923010548};\\\", \\\"{x:838,y:544,t:1526923010589};\\\", \\\"{x:838,y:543,t:1526923010596};\\\", \\\"{x:837,y:540,t:1526923010613};\\\", \\\"{x:836,y:538,t:1526923010629};\\\", \\\"{x:836,y:536,t:1526923010641};\\\", \\\"{x:835,y:534,t:1526923010658};\\\", \\\"{x:835,y:532,t:1526923010675};\\\", \\\"{x:833,y:527,t:1526923010692};\\\", \\\"{x:833,y:524,t:1526923010708};\\\", \\\"{x:833,y:523,t:1526923010725};\\\", \\\"{x:833,y:525,t:1526923010923};\\\", \\\"{x:833,y:528,t:1526923010932};\\\", \\\"{x:833,y:532,t:1526923010943};\\\", \\\"{x:833,y:537,t:1526923010958};\\\", \\\"{x:833,y:541,t:1526923010976};\\\", \\\"{x:833,y:544,t:1526923010992};\\\", \\\"{x:833,y:548,t:1526923011009};\\\", \\\"{x:833,y:549,t:1526923011025};\\\", \\\"{x:833,y:550,t:1526923011043};\\\", \\\"{x:833,y:551,t:1526923011058};\\\", \\\"{x:833,y:552,t:1526923011075};\\\", \\\"{x:833,y:554,t:1526923011276};\\\", \\\"{x:836,y:561,t:1526923011291};\\\", \\\"{x:837,y:567,t:1526923011309};\\\", \\\"{x:838,y:574,t:1526923011325};\\\", \\\"{x:838,y:581,t:1526923011342};\\\", \\\"{x:838,y:588,t:1526923011360};\\\", \\\"{x:839,y:596,t:1526923011375};\\\", \\\"{x:840,y:606,t:1526923011393};\\\", \\\"{x:843,y:615,t:1526923011411};\\\", \\\"{x:846,y:625,t:1526923011425};\\\", \\\"{x:850,y:633,t:1526923011442};\\\", \\\"{x:852,y:636,t:1526923011459};\\\", \\\"{x:853,y:637,t:1526923011475};\\\", \\\"{x:854,y:637,t:1526923011564};\\\", \\\"{x:854,y:639,t:1526923011941};\\\", \\\"{x:853,y:641,t:1526923011949};\\\", \\\"{x:850,y:644,t:1526923011959};\\\", \\\"{x:842,y:652,t:1526923011977};\\\", \\\"{x:827,y:664,t:1526923011992};\\\", \\\"{x:807,y:677,t:1526923012009};\\\", \\\"{x:772,y:696,t:1526923012026};\\\", \\\"{x:711,y:726,t:1526923012042};\\\", \\\"{x:641,y:761,t:1526923012059};\\\", \\\"{x:521,y:813,t:1526923012076};\\\", \\\"{x:460,y:841,t:1526923012092};\\\", \\\"{x:419,y:865,t:1526923012109};\\\", \\\"{x:400,y:877,t:1526923012127};\\\", \\\"{x:390,y:885,t:1526923012142};\\\", \\\"{x:393,y:885,t:1526923012221};\\\", \\\"{x:394,y:883,t:1526923012229};\\\", \\\"{x:395,y:883,t:1526923012243};\\\", \\\"{x:401,y:879,t:1526923012260};\\\", \\\"{x:411,y:871,t:1526923012277};\\\", \\\"{x:423,y:862,t:1526923012293};\\\", \\\"{x:434,y:854,t:1526923012310};\\\", \\\"{x:447,y:842,t:1526923012327};\\\", \\\"{x:461,y:829,t:1526923012343};\\\", \\\"{x:474,y:814,t:1526923012359};\\\", \\\"{x:484,y:800,t:1526923012377};\\\", \\\"{x:495,y:789,t:1526923012393};\\\", \\\"{x:503,y:780,t:1526923012409};\\\", \\\"{x:508,y:773,t:1526923012427};\\\", \\\"{x:511,y:768,t:1526923012445};\\\", \\\"{x:512,y:766,t:1526923012459};\\\", \\\"{x:513,y:766,t:1526923012524};\\\" ] }, { \\\"rt\\\": 56495, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 681951, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Events that start at 12pm are plotted and labeled at the 12 pm\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 10141, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"24\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Philippines\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 693098, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 12764, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 706883, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 9637, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 717849, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"9BCHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"9BCHA\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 271, dom: 1370, initialDom: 1505",
  "javascriptErrors": []
}