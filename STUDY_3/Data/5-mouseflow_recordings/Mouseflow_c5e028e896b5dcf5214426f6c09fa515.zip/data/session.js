var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c5e028e896b5dcf5214426f6c09fa515",
  "created": "2018-05-21T12:12:58.1831344-07:00",
  "lastActivity": "2018-05-21T12:14:12.4591344-07:00",
  "pageViews": [
    {
      "id": "052158664717abfd948a696f0ac9ec30379a99cc",
      "startTime": "2018-05-21T12:12:58.1831344-07:00",
      "endTime": "2018-05-21T12:14:12.4591344-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 74276,
      "engagementTime": 47462,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 74276,
  "engagementTime": 47462,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CC7G0",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b90267177fbf7cdb622307cfb99824fa",
  "gdpr": false
}