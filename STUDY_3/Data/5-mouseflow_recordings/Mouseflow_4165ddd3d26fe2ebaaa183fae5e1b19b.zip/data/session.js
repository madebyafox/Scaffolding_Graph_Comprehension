var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4165ddd3d26fe2ebaaa183fae5e1b19b",
  "created": "2018-06-01T11:17:05.3930433-07:00",
  "lastActivity": "2018-06-01T11:18:24.3110433-07:00",
  "pageViews": [
    {
      "id": "0601057476ce5ac0a7824dcb014207567b531f8f",
      "startTime": "2018-06-01T11:17:05.3930433-07:00",
      "endTime": "2018-06-01T11:18:24.3110433-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 78918,
      "engagementTime": 66164,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 78918,
  "engagementTime": 66164,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=5KWEX",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "952a577eaa60126be8b8aa84da41c649",
  "gdpr": false
}