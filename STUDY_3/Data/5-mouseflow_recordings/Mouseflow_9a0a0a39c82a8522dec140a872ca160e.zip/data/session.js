var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "9a0a0a39c82a8522dec140a872ca160e",
  "created": "2018-06-01T11:15:16.511243-07:00",
  "lastActivity": "2018-06-01T11:15:33.965243-07:00",
  "pageViews": [
    {
      "id": "06011675f031955c2755443a79e27f316dc8d2da",
      "startTime": "2018-06-01T11:15:16.511243-07:00",
      "endTime": "2018-06-01T11:15:33.965243-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 17454,
      "engagementTime": 17448,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 17454,
  "engagementTime": 17448,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=2ZXKM",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d1885752472c659b1cb294c07a60f464",
  "gdpr": false
}