var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0522447123b774b407dcc35f8a40ba3ea95b1fa2"] = {
  "startTime": "2018-05-22T21:01:45.0648251Z",
  "websitePageUrl": "/",
  "visitTime": 341231,
  "engagementTime": 55044,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 929,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "f27927d67c97d056e8906e7173bdde54",
    "created": "2018-05-22T21:01:44.9120376+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "43c866454cb6e31daa7292cfcf8589d2",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/f27927d67c97d056e8906e7173bdde54/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 929,
      "y": 1047
    },
    {
      "t": 358,
      "e": 358,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 780,
      "y": 563
    },
    {
      "t": 2503,
      "e": 2503,
      "ty": 41,
      "x": 50025,
      "y": 36044,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 648,
      "y": 644
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 586,
      "y": 645
    },
    {
      "t": 2752,
      "e": 2752,
      "ty": 41,
      "x": 40413,
      "y": 40713,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 651,
      "y": 587
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 741,
      "y": 550
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 2,
      "x": 754,
      "y": 544
    },
    {
      "t": 3002,
      "e": 3002,
      "ty": 41,
      "x": 48605,
      "y": 34487,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3075,
      "e": 3075,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 3101,
      "e": 3101,
      "ty": 2,
      "x": 901,
      "y": 312
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 56633,
      "y": 15482,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3482,
      "e": 3482,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 876,
      "y": 29
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 41,
      "x": 62373,
      "y": 1336,
      "ta": "html > body"
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 5252,
      "e": 5252,
      "ty": 41,
      "x": 31303,
      "y": 1034,
      "ta": "html > body"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 1032,
      "y": 224
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 1116,
      "y": 422
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 1115,
      "y": 426
    },
    {
      "t": 5502,
      "e": 5502,
      "ty": 41,
      "x": 41259,
      "y": 22896,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 11200,
      "e": 10502,
      "ty": 2,
      "x": 1051,
      "y": 513
    },
    {
      "t": 11251,
      "e": 10553,
      "ty": 41,
      "x": 35907,
      "y": 35511,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11301,
      "e": 10603,
      "ty": 2,
      "x": 950,
      "y": 671
    },
    {
      "t": 11400,
      "e": 10702,
      "ty": 2,
      "x": 883,
      "y": 705
    },
    {
      "t": 11500,
      "e": 10802,
      "ty": 2,
      "x": 805,
      "y": 496
    },
    {
      "t": 11500,
      "e": 10802,
      "ty": 41,
      "x": 24329,
      "y": 28630,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11600,
      "e": 10902,
      "ty": 2,
      "x": 848,
      "y": 479
    },
    {
      "t": 11700,
      "e": 11002,
      "ty": 2,
      "x": 849,
      "y": 479
    },
    {
      "t": 11751,
      "e": 11053,
      "ty": 41,
      "x": 26732,
      "y": 27237,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12100,
      "e": 11402,
      "ty": 2,
      "x": 850,
      "y": 478
    },
    {
      "t": 12251,
      "e": 11553,
      "ty": 41,
      "x": 26787,
      "y": 27156,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12771,
      "e": 12073,
      "ty": 3,
      "x": 850,
      "y": 478,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12939,
      "e": 12241,
      "ty": 4,
      "x": 26787,
      "y": 27156,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12940,
      "e": 12242,
      "ty": 5,
      "x": 850,
      "y": 478,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 16401,
      "e": 15703,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 16401,
      "e": 15703,
      "ty": 2,
      "x": 850,
      "y": 544
    },
    {
      "t": 16500,
      "e": 15802,
      "ty": 41,
      "x": 26787,
      "y": 28221,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 17601,
      "e": 16903,
      "ty": 2,
      "x": 1121,
      "y": 731
    },
    {
      "t": 17701,
      "e": 17003,
      "ty": 2,
      "x": 1702,
      "y": 1199
    },
    {
      "t": 17801,
      "e": 17103,
      "ty": 2,
      "x": 1694,
      "y": 1185
    },
    {
      "t": 17901,
      "e": 17203,
      "ty": 2,
      "x": 1018,
      "y": 750
    },
    {
      "t": 18001,
      "e": 17303,
      "ty": 2,
      "x": 899,
      "y": 652
    },
    {
      "t": 18001,
      "e": 17303,
      "ty": 41,
      "x": 29463,
      "y": 37068,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 18101,
      "e": 17403,
      "ty": 2,
      "x": 898,
      "y": 651
    },
    {
      "t": 18251,
      "e": 17553,
      "ty": 41,
      "x": 29408,
      "y": 36986,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 20001,
      "e": 19303,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 34001,
      "e": 22553,
      "ty": 2,
      "x": 907,
      "y": 642
    },
    {
      "t": 34001,
      "e": 22553,
      "ty": 41,
      "x": 29900,
      "y": 36249,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 40001,
      "e": 27553,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 292515,
      "e": 27553,
      "ty": 2,
      "x": 901,
      "y": 879
    },
    {
      "t": 292516,
      "e": 27554,
      "ty": 41,
      "x": 29889,
      "y": 56191,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 292614,
      "e": 27652,
      "ty": 2,
      "x": 824,
      "y": 1049
    },
    {
      "t": 292714,
      "e": 27752,
      "ty": 2,
      "x": 763,
      "y": 1109
    },
    {
      "t": 292764,
      "e": 27802,
      "ty": 41,
      "x": 24920,
      "y": 64171,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 292814,
      "e": 27852,
      "ty": 2,
      "x": 818,
      "y": 1014
    },
    {
      "t": 292914,
      "e": 27952,
      "ty": 2,
      "x": 823,
      "y": 1004
    },
    {
      "t": 293014,
      "e": 28052,
      "ty": 2,
      "x": 821,
      "y": 969
    },
    {
      "t": 293015,
      "e": 28053,
      "ty": 41,
      "x": 25953,
      "y": 58354,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 293114,
      "e": 28152,
      "ty": 2,
      "x": 813,
      "y": 939
    },
    {
      "t": 293215,
      "e": 28253,
      "ty": 2,
      "x": 813,
      "y": 935
    },
    {
      "t": 293264,
      "e": 28302,
      "ty": 41,
      "x": 31333,
      "y": 59032,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 293314,
      "e": 28352,
      "ty": 2,
      "x": 813,
      "y": 927
    },
    {
      "t": 293414,
      "e": 28452,
      "ty": 2,
      "x": 813,
      "y": 926
    },
    {
      "t": 293453,
      "e": 28491,
      "ty": 3,
      "x": 813,
      "y": 926,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 293514,
      "e": 28552,
      "ty": 41,
      "x": 31333,
      "y": 49202,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 293588,
      "e": 28626,
      "ty": 4,
      "x": 31333,
      "y": 49202,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 293588,
      "e": 28626,
      "ty": 5,
      "x": 813,
      "y": 926,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 293590,
      "e": 28628,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 293594,
      "e": 28632,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 293915,
      "e": 28953,
      "ty": 2,
      "x": 889,
      "y": 1053
    },
    {
      "t": 294014,
      "e": 29052,
      "ty": 2,
      "x": 927,
      "y": 1089
    },
    {
      "t": 294014,
      "e": 29052,
      "ty": 41,
      "x": 9557,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 294114,
      "e": 29152,
      "ty": 2,
      "x": 933,
      "y": 1094
    },
    {
      "t": 294215,
      "e": 29253,
      "ty": 2,
      "x": 936,
      "y": 1094
    },
    {
      "t": 294265,
      "e": 29303,
      "ty": 41,
      "x": 14472,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 294277,
      "e": 29315,
      "ty": 3,
      "x": 936,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 294279,
      "e": 29317,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 294279,
      "e": 29317,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 294388,
      "e": 29426,
      "ty": 4,
      "x": 14472,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 294389,
      "e": 29427,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 294391,
      "e": 29429,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 294391,
      "e": 29429,
      "ty": 5,
      "x": 936,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 295397,
      "e": 30435,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 296014,
      "e": 31052,
      "ty": 2,
      "x": 807,
      "y": 808
    },
    {
      "t": 296015,
      "e": 31053,
      "ty": 41,
      "x": 27515,
      "y": 44317,
      "ta": "html > body"
    },
    {
      "t": 296115,
      "e": 31153,
      "ty": 2,
      "x": 771,
      "y": 351
    },
    {
      "t": 296214,
      "e": 31252,
      "ty": 2,
      "x": 775,
      "y": 342
    },
    {
      "t": 296265,
      "e": 31303,
      "ty": 41,
      "x": 27446,
      "y": 22934,
      "ta": "html > body"
    },
    {
      "t": 296314,
      "e": 31352,
      "ty": 2,
      "x": 899,
      "y": 562
    },
    {
      "t": 296330,
      "e": 31368,
      "ty": 6,
      "x": 926,
      "y": 599,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 296345,
      "e": 31383,
      "ty": 7,
      "x": 939,
      "y": 618,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 296414,
      "e": 31452,
      "ty": 2,
      "x": 946,
      "y": 622
    },
    {
      "t": 296514,
      "e": 31552,
      "ty": 2,
      "x": 948,
      "y": 621
    },
    {
      "t": 296514,
      "e": 31552,
      "ty": 41,
      "x": 30280,
      "y": 4228,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 296563,
      "e": 31601,
      "ty": 6,
      "x": 953,
      "y": 601,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 296614,
      "e": 31652,
      "ty": 2,
      "x": 955,
      "y": 588
    },
    {
      "t": 296725,
      "e": 31763,
      "ty": 3,
      "x": 955,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 296726,
      "e": 31764,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 296764,
      "e": 31802,
      "ty": 41,
      "x": 31794,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 296828,
      "e": 31866,
      "ty": 4,
      "x": 31794,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 296828,
      "e": 31866,
      "ty": 5,
      "x": 955,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 297825,
      "e": 32863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "72"
    },
    {
      "t": 297826,
      "e": 32864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 297920,
      "e": 32958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 297922,
      "e": 32960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 297944,
      "e": 32982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ho"
    },
    {
      "t": 298031,
      "e": 33069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "84"
    },
    {
      "t": 298032,
      "e": 33070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 298055,
      "e": 33093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "hot"
    },
    {
      "t": 298112,
      "e": 33150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 298112,
      "e": 33150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 298136,
      "e": 33174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "hote"
    },
    {
      "t": 298208,
      "e": 33246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 298209,
      "e": 33247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 298215,
      "e": 33253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||l"
    },
    {
      "t": 298303,
      "e": 33341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 298997,
      "e": 34035,
      "ty": 7,
      "x": 961,
      "y": 639,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 299014,
      "e": 34052,
      "ty": 6,
      "x": 966,
      "y": 679,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 299017,
      "e": 34055,
      "ty": 2,
      "x": 966,
      "y": 679
    },
    {
      "t": 299017,
      "e": 34055,
      "ty": 41,
      "x": 34173,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 299046,
      "e": 34084,
      "ty": 7,
      "x": 968,
      "y": 701,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 299064,
      "e": 34102,
      "ty": 6,
      "x": 971,
      "y": 710,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 299114,
      "e": 34152,
      "ty": 2,
      "x": 972,
      "y": 716
    },
    {
      "t": 299215,
      "e": 34253,
      "ty": 2,
      "x": 972,
      "y": 733
    },
    {
      "t": 299265,
      "e": 34303,
      "ty": 41,
      "x": 39209,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 299314,
      "e": 34352,
      "ty": 2,
      "x": 982,
      "y": 717
    },
    {
      "t": 299414,
      "e": 34452,
      "ty": 2,
      "x": 983,
      "y": 712
    },
    {
      "t": 299452,
      "e": 34490,
      "ty": 7,
      "x": 988,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 299517,
      "e": 34555,
      "ty": 2,
      "x": 992,
      "y": 701
    },
    {
      "t": 299518,
      "e": 34556,
      "ty": 41,
      "x": 39796,
      "y": 60602,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 299552,
      "e": 34590,
      "ty": 6,
      "x": 996,
      "y": 696,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 299617,
      "e": 34655,
      "ty": 2,
      "x": 996,
      "y": 696
    },
    {
      "t": 299718,
      "e": 34756,
      "ty": 2,
      "x": 996,
      "y": 694
    },
    {
      "t": 299768,
      "e": 34806,
      "ty": 41,
      "x": 40878,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 299817,
      "e": 34855,
      "ty": 2,
      "x": 997,
      "y": 693
    },
    {
      "t": 299918,
      "e": 34956,
      "ty": 2,
      "x": 997,
      "y": 691
    },
    {
      "t": 300018,
      "e": 35056,
      "ty": 2,
      "x": 997,
      "y": 690
    },
    {
      "t": 300018,
      "e": 35056,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 300023,
      "e": 35061,
      "ty": 41,
      "x": 40878,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 300064,
      "e": 35102,
      "ty": 3,
      "x": 997,
      "y": 690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 300065,
      "e": 35103,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "hotel"
    },
    {
      "t": 300067,
      "e": 35105,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 300067,
      "e": 35105,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 300166,
      "e": 35204,
      "ty": 4,
      "x": 40878,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 300166,
      "e": 35204,
      "ty": 5,
      "x": 997,
      "y": 690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 300684,
      "e": 35722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 300685,
      "e": 35723,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 300770,
      "e": 35808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "50"
    },
    {
      "t": 300771,
      "e": 35809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 300794,
      "e": 35832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12"
    },
    {
      "t": 300908,
      "e": 35946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 300909,
      "e": 35947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 300922,
      "e": 35960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 300995,
      "e": 36033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 302187,
      "e": 37225,
      "ty": 7,
      "x": 995,
      "y": 706,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 302203,
      "e": 37241,
      "ty": 6,
      "x": 993,
      "y": 718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 302218,
      "e": 37256,
      "ty": 2,
      "x": 993,
      "y": 718
    },
    {
      "t": 302268,
      "e": 37306,
      "ty": 41,
      "x": 49517,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 302318,
      "e": 37356,
      "ty": 2,
      "x": 991,
      "y": 729
    },
    {
      "t": 302418,
      "e": 37456,
      "ty": 2,
      "x": 991,
      "y": 733
    },
    {
      "t": 302518,
      "e": 37556,
      "ty": 41,
      "x": 49002,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 302536,
      "e": 37574,
      "ty": 3,
      "x": 991,
      "y": 733,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 302537,
      "e": 37575,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 302538,
      "e": 37576,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 302538,
      "e": 37576,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 302655,
      "e": 37693,
      "ty": 4,
      "x": 49002,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 302659,
      "e": 37697,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 302660,
      "e": 37698,
      "ty": 5,
      "x": 991,
      "y": 733,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 302660,
      "e": 37698,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 302768,
      "e": 37806,
      "ty": 41,
      "x": 33783,
      "y": 40218,
      "ta": "html > body"
    },
    {
      "t": 302818,
      "e": 37856,
      "ty": 2,
      "x": 989,
      "y": 734
    },
    {
      "t": 303750,
      "e": 38788,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 303780,
      "e": 38818,
      "ty": 6,
      "x": 989,
      "y": 734,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 310017,
      "e": 43818,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 320518,
      "e": 43818,
      "ty": 2,
      "x": 1002,
      "y": 742
    },
    {
      "t": 320519,
      "e": 43819,
      "ty": 41,
      "x": 33943,
      "y": 35144,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 320603,
      "e": 43903,
      "ty": 7,
      "x": 1024,
      "y": 756,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 320605,
      "e": 43905,
      "ty": 6,
      "x": 1024,
      "y": 756,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 320617,
      "e": 43917,
      "ty": 2,
      "x": 1024,
      "y": 756
    },
    {
      "t": 320768,
      "e": 44068,
      "ty": 41,
      "x": 35058,
      "y": 2377,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 321318,
      "e": 44618,
      "ty": 2,
      "x": 1024,
      "y": 758
    },
    {
      "t": 321418,
      "e": 44718,
      "ty": 2,
      "x": 1020,
      "y": 768
    },
    {
      "t": 321488,
      "e": 44788,
      "ty": 7,
      "x": 1013,
      "y": 789,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 321517,
      "e": 44817,
      "ty": 2,
      "x": 1009,
      "y": 807
    },
    {
      "t": 321518,
      "e": 44818,
      "ty": 41,
      "x": 35202,
      "y": 14079,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 321618,
      "e": 44918,
      "ty": 2,
      "x": 997,
      "y": 860
    },
    {
      "t": 321718,
      "e": 45018,
      "ty": 2,
      "x": 972,
      "y": 944
    },
    {
      "t": 321768,
      "e": 45068,
      "ty": 41,
      "x": 32939,
      "y": 60086,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 321818,
      "e": 45118,
      "ty": 2,
      "x": 959,
      "y": 1059
    },
    {
      "t": 321822,
      "e": 45122,
      "ty": 6,
      "x": 959,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 321917,
      "e": 45217,
      "ty": 2,
      "x": 960,
      "y": 1094
    },
    {
      "t": 322017,
      "e": 45317,
      "ty": 2,
      "x": 961,
      "y": 1096
    },
    {
      "t": 322018,
      "e": 45318,
      "ty": 41,
      "x": 28125,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 322153,
      "e": 45453,
      "ty": 3,
      "x": 961,
      "y": 1096,
      "ta": "#start"
    },
    {
      "t": 322154,
      "e": 45454,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 322218,
      "e": 45518,
      "ty": 2,
      "x": 962,
      "y": 1096
    },
    {
      "t": 322268,
      "e": 45568,
      "ty": 41,
      "x": 28671,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 322279,
      "e": 45579,
      "ty": 4,
      "x": 28671,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 322279,
      "e": 45579,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 322280,
      "e": 45580,
      "ty": 5,
      "x": 962,
      "y": 1096,
      "ta": "#start"
    },
    {
      "t": 322282,
      "e": 45582,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 323283,
      "e": 46583,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 330017,
      "e": 50580,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 336767,
      "e": 50580,
      "ty": 41,
      "x": 32888,
      "y": 59829,
      "ta": "html > body"
    },
    {
      "t": 336817,
      "e": 50630,
      "ty": 2,
      "x": 963,
      "y": 1082
    },
    {
      "t": 336917,
      "e": 50730,
      "ty": 2,
      "x": 963,
      "y": 1081
    },
    {
      "t": 337017,
      "e": 50830,
      "ty": 41,
      "x": 32888,
      "y": 59441,
      "ta": "html > body"
    },
    {
      "t": 340229,
      "e": 54042,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 341231,
      "e": 55044,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 273, dom: 740, initialDom: 747",
  "javascriptErrors": []
}