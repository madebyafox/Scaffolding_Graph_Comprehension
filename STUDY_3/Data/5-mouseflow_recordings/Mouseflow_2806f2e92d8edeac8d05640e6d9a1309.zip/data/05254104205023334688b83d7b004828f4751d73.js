var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05254104205023334688b83d7b004828f4751d73"] = {
  "startTime": "2018-05-25T18:17:41.192536Z",
  "websitePageUrl": "/16",
  "visitTime": 83004,
  "engagementTime": 78301,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "2806f2e92d8edeac8d05640e6d9a1309",
    "created": "2018-05-25T18:17:41.1125447+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=53R9B",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "bc1d33791189812874dd7b406ff48283",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/2806f2e92d8edeac8d05640e6d9a1309/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 188,
      "e": 188,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 2400,
      "e": 2400,
      "ty": 2,
      "x": 479,
      "y": 629
    },
    {
      "t": 2444,
      "e": 2444,
      "ty": 6,
      "x": 468,
      "y": 594,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 2,
      "x": 460,
      "y": 578
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 40794,
      "y": 44713,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2600,
      "e": 2600,
      "ty": 2,
      "x": 454,
      "y": 561
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 2,
      "x": 453,
      "y": 552
    },
    {
      "t": 2737,
      "e": 2737,
      "ty": 3,
      "x": 453,
      "y": 552,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2737,
      "e": 2737,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2750,
      "e": 2750,
      "ty": 41,
      "x": 40007,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2792,
      "e": 2792,
      "ty": 4,
      "x": 40007,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2792,
      "e": 2792,
      "ty": 5,
      "x": 453,
      "y": 552,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3100,
      "e": 3100,
      "ty": 2,
      "x": 453,
      "y": 551
    },
    {
      "t": 3250,
      "e": 3250,
      "ty": 41,
      "x": 40007,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 447,
      "y": 553
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 39332,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4100,
      "e": 4100,
      "ty": 2,
      "x": 447,
      "y": 554
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 39332,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4400,
      "e": 4400,
      "ty": 2,
      "x": 511,
      "y": 580
    },
    {
      "t": 4429,
      "e": 4429,
      "ty": 7,
      "x": 620,
      "y": 612,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 2,
      "x": 888,
      "y": 694
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 7188,
      "y": 39822,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 1172,
      "y": 822
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 1250,
      "y": 883
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 32980,
      "y": 54934,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 1256,
      "y": 919
    },
    {
      "t": 4900,
      "e": 4900,
      "ty": 2,
      "x": 1220,
      "y": 957
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 1191,
      "y": 968
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 28540,
      "y": 59447,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 1181,
      "y": 972
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 1172,
      "y": 975
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 61670,
      "y": 24831,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 1171,
      "y": 975
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 1158,
      "y": 975
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 41,
      "x": 40610,
      "y": 24831,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 5800,
      "e": 5800,
      "ty": 2,
      "x": 1163,
      "y": 956
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1128,
      "y": 867
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 2,
      "x": 1020,
      "y": 795
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 16490,
      "y": 47056,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 1005,
      "y": 786
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 15433,
      "y": 46411,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7710,
      "e": 7710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 7877,
      "e": 7877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 7878,
      "e": 7878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7956,
      "e": 7956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "U"
    },
    {
      "t": 7957,
      "e": 7957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "U"
    },
    {
      "t": 8925,
      "e": 8925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9020,
      "e": 9020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 9068,
      "e": 9068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9261,
      "e": 9261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 9262,
      "e": 9262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9284,
      "e": 9284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 9340,
      "e": 9340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 9453,
      "e": 9453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9453,
      "e": 9453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9533,
      "e": 9533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 9621,
      "e": 9621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9622,
      "e": 9622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9717,
      "e": 9717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Loo"
    },
    {
      "t": 9876,
      "e": 9876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 9877,
      "e": 9877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9964,
      "e": 9964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10028,
      "e": 10028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10028,
      "e": 10028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10140,
      "e": 10140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10148,
      "e": 10148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10148,
      "e": 10148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10244,
      "e": 10244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 10316,
      "e": 10316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10316,
      "e": 10316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10413,
      "e": 10413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10413,
      "e": 10413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10428,
      "e": 10428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 10500,
      "e": 10500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10524,
      "e": 10524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10525,
      "e": 10525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10612,
      "e": 10612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 10612,
      "e": 10612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10628,
      "e": 10628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 10685,
      "e": 10685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10717,
      "e": 10717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 10717,
      "e": 10717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10812,
      "e": 10812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 10837,
      "e": 10837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10837,
      "e": 10837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10957,
      "e": 10957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11405,
      "e": 11405,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 11405,
      "e": 11405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11525,
      "e": 11525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 11541,
      "e": 11541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11542,
      "e": 11542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11661,
      "e": 11661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11669,
      "e": 11669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11669,
      "e": 11669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11803,
      "e": 11803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x a"
    },
    {
      "t": 11804,
      "e": 11804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 11844,
      "e": 11844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 11844,
      "e": 11844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11957,
      "e": 11957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 12221,
      "e": 12221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12221,
      "e": 12221,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12284,
      "e": 12284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 12403,
      "e": 12403,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x asi"
    },
    {
      "t": 12685,
      "e": 12685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 12686,
      "e": 12686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12780,
      "e": 12780,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 12796,
      "e": 12796,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12797,
      "e": 12797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12900,
      "e": 12900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12916,
      "e": 12916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12916,
      "e": 12916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12989,
      "e": 12989,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 13060,
      "e": 13060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 13062,
      "e": 13062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13165,
      "e": 13165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 13189,
      "e": 13189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13189,
      "e": 13189,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13301,
      "e": 13301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13317,
      "e": 13317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 13318,
      "e": 13318,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13436,
      "e": 13436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 13821,
      "e": 13821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13822,
      "e": 13822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13932,
      "e": 13932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13972,
      "e": 13972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13972,
      "e": 13972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14165,
      "e": 14165,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 14285,
      "e": 14285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 14286,
      "e": 14286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14397,
      "e": 14397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 14493,
      "e": 14493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14494,
      "e": 14494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14596,
      "e": 14596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14597,
      "e": 14597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14599,
      "e": 14599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14708,
      "e": 14708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14716,
      "e": 14716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14716,
      "e": 14716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14829,
      "e": 14829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 14829,
      "e": 14829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14844,
      "e": 14844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 14908,
      "e": 14908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14972,
      "e": 14972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 14973,
      "e": 14973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15068,
      "e": 15068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 15100,
      "e": 15100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15102,
      "e": 15102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15212,
      "e": 15212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15477,
      "e": 15477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15478,
      "e": 15478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15602,
      "e": 15602,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x asix of start and e"
    },
    {
      "t": 15604,
      "e": 15604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 15685,
      "e": 15685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 15686,
      "e": 15686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15764,
      "e": 15764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 15869,
      "e": 15869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 15869,
      "e": 15869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15988,
      "e": 15988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 16752,
      "e": 16752,
      "ty": 41,
      "x": 15081,
      "y": 47700,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 16801,
      "e": 16801,
      "ty": 2,
      "x": 996,
      "y": 807
    },
    {
      "t": 16901,
      "e": 16901,
      "ty": 2,
      "x": 885,
      "y": 870
    },
    {
      "t": 17001,
      "e": 17001,
      "ty": 2,
      "x": 736,
      "y": 868
    },
    {
      "t": 17002,
      "e": 17002,
      "ty": 41,
      "x": 3208,
      "y": 51831,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 17101,
      "e": 17101,
      "ty": 2,
      "x": 334,
      "y": 642
    },
    {
      "t": 17108,
      "e": 17108,
      "ty": 6,
      "x": 257,
      "y": 593,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17190,
      "e": 17190,
      "ty": 7,
      "x": 139,
      "y": 520,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17200,
      "e": 17200,
      "ty": 2,
      "x": 139,
      "y": 520
    },
    {
      "t": 17251,
      "e": 17251,
      "ty": 41,
      "x": 7071,
      "y": 24027,
      "ta": "#.strategy > p"
    },
    {
      "t": 17301,
      "e": 17301,
      "ty": 2,
      "x": 170,
      "y": 499
    },
    {
      "t": 17400,
      "e": 17400,
      "ty": 2,
      "x": 185,
      "y": 496
    },
    {
      "t": 17490,
      "e": 17490,
      "ty": 6,
      "x": 221,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17501,
      "e": 17501,
      "ty": 2,
      "x": 221,
      "y": 522
    },
    {
      "t": 17501,
      "e": 17501,
      "ty": 41,
      "x": 13928,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17601,
      "e": 17601,
      "ty": 2,
      "x": 231,
      "y": 527
    },
    {
      "t": 17751,
      "e": 17751,
      "ty": 41,
      "x": 15052,
      "y": 3451,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17818,
      "e": 17818,
      "ty": 3,
      "x": 231,
      "y": 527,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17912,
      "e": 17912,
      "ty": 4,
      "x": 15052,
      "y": 3451,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17912,
      "e": 17912,
      "ty": 5,
      "x": 231,
      "y": 527,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18001,
      "e": 18001,
      "ty": 2,
      "x": 240,
      "y": 530
    },
    {
      "t": 18001,
      "e": 18001,
      "ty": 41,
      "x": 16064,
      "y": 5878,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18101,
      "e": 18101,
      "ty": 2,
      "x": 274,
      "y": 529
    },
    {
      "t": 18123,
      "e": 18123,
      "ty": 7,
      "x": 300,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18158,
      "e": 18158,
      "ty": 6,
      "x": 443,
      "y": 531,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18200,
      "e": 18200,
      "ty": 2,
      "x": 470,
      "y": 544
    },
    {
      "t": 18253,
      "e": 18202,
      "ty": 41,
      "x": 41918,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18613,
      "e": 18562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18676,
      "e": 18625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x asi of start and end"
    },
    {
      "t": 18772,
      "e": 18721,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18844,
      "e": 18793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x as of start and end"
    },
    {
      "t": 19301,
      "e": 19250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19364,
      "e": 19313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x a of start and end"
    },
    {
      "t": 20052,
      "e": 20001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 20053,
      "e": 20002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20163,
      "e": 20112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x ax of start and end"
    },
    {
      "t": 20236,
      "e": 20185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20237,
      "e": 20186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20308,
      "e": 20257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axi of start and end"
    },
    {
      "t": 20356,
      "e": 20305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20357,
      "e": 20306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20461,
      "e": 20410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis of start and end"
    },
    {
      "t": 21409,
      "e": 21358,
      "ty": 3,
      "x": 470,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21536,
      "e": 21485,
      "ty": 4,
      "x": 41918,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21538,
      "e": 21487,
      "ty": 5,
      "x": 470,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22500,
      "e": 22449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22501,
      "e": 22450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22604,
      "e": 22553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22964,
      "e": 22913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22964,
      "e": 22913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23060,
      "e": 23009,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 23325,
      "e": 23274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23420,
      "e": 23369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis of start and end "
    },
    {
      "t": 23460,
      "e": 23409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23461,
      "e": 23410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23556,
      "e": 23505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23604,
      "e": 23553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23606,
      "e": 23555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23724,
      "e": 23673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 23725,
      "e": 23674,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23756,
      "e": 23705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||im"
    },
    {
      "t": 23845,
      "e": 23794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24469,
      "e": 24418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24469,
      "e": 24418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24564,
      "e": 24513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 24724,
      "e": 24673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 24725,
      "e": 24674,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24796,
      "e": 24745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 25460,
      "e": 25409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 25461,
      "e": 25410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25540,
      "e": 25489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 25621,
      "e": 25570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25621,
      "e": 25570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25732,
      "e": 25681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 25740,
      "e": 25689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25925,
      "e": 25874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 25926,
      "e": 25875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25972,
      "e": 25921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||G"
    },
    {
      "t": 26053,
      "e": 26002,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26093,
      "e": 26042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26094,
      "e": 26043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26156,
      "e": 26105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 26204,
      "e": 26153,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26204,
      "e": 26153,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26316,
      "e": 26265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26333,
      "e": 26282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26335,
      "e": 26284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26428,
      "e": 26377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26452,
      "e": 26401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26452,
      "e": 26401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26540,
      "e": 26489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26540,
      "e": 26489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26547,
      "e": 26496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o "
    },
    {
      "t": 26659,
      "e": 26608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27325,
      "e": 27274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 27325,
      "e": 27274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27420,
      "e": 27369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 27564,
      "e": 27513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 27566,
      "e": 27515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27659,
      "e": 27608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 30001,
      "e": 29950,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30804,
      "e": 30753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 30948,
      "e": 30897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 30948,
      "e": 30897,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31037,
      "e": 30986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 31148,
      "e": 31097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31236,
      "e": 31185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 31238,
      "e": 31187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31340,
      "e": 31289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 31949,
      "e": 31898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32028,
      "e": 31977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis of start and end times. Go to 12P"
    },
    {
      "t": 32148,
      "e": 32097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 32300,
      "e": 32249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 32302,
      "e": 32251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32365,
      "e": 32314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 32429,
      "e": 32378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32484,
      "e": 32433,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32485,
      "e": 32434,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32588,
      "e": 32537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32668,
      "e": 32617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32669,
      "e": 32618,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32796,
      "e": 32745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 33253,
      "e": 33202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33254,
      "e": 33203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33316,
      "e": 33265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 33412,
      "e": 33361,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 33412,
      "e": 33361,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33516,
      "e": 33465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 33556,
      "e": 33505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33556,
      "e": 33505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33668,
      "e": 33617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33780,
      "e": 33729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 33781,
      "e": 33730,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33852,
      "e": 33801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 33973,
      "e": 33922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 33973,
      "e": 33922,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34035,
      "e": 33984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 34116,
      "e": 34065,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 34116,
      "e": 34065,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34188,
      "e": 34137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 34277,
      "e": 34226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 34277,
      "e": 34226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34292,
      "e": 34241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "74"
    },
    {
      "t": 34292,
      "e": 34241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34332,
      "e": 34281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||kj"
    },
    {
      "t": 34356,
      "e": 34305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34380,
      "e": 34329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34380,
      "e": 34329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34444,
      "e": 34393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35300,
      "e": 35249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35324,
      "e": 35273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis of start and end times. Go to 12PM and lookj"
    },
    {
      "t": 35447,
      "e": 35396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35564,
      "e": 35513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis of start and end times. Go to 12PM and look"
    },
    {
      "t": 35757,
      "e": 35706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35757,
      "e": 35706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35876,
      "e": 35825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35899,
      "e": 35848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 35900,
      "e": 35849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36004,
      "e": 35953,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis of start and end times. Go to 12PM and look s"
    },
    {
      "t": 36036,
      "e": 35985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 36222,
      "e": 36171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36223,
      "e": 36172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36316,
      "e": 36265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 36452,
      "e": 36401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 36453,
      "e": 36402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36556,
      "e": 36505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36557,
      "e": 36506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36572,
      "e": 36521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ra"
    },
    {
      "t": 36685,
      "e": 36634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36693,
      "e": 36642,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36693,
      "e": 36642,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36771,
      "e": 36720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 36828,
      "e": 36777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 36828,
      "e": 36777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36948,
      "e": 36897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 36956,
      "e": 36905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36957,
      "e": 36906,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37060,
      "e": 37009,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 38029,
      "e": 37978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38029,
      "e": 37978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38124,
      "e": 38073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38629,
      "e": 38578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38629,
      "e": 38578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38731,
      "e": 38680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38853,
      "e": 38802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 38854,
      "e": 38803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38915,
      "e": 38864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 39204,
      "e": 39153,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 39205,
      "e": 39154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39299,
      "e": 39248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 39356,
      "e": 39305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39356,
      "e": 39305,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39492,
      "e": 39441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40001,
      "e": 39950,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40140,
      "e": 40089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40140,
      "e": 40089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40236,
      "e": 40185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 40236,
      "e": 40185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40252,
      "e": 40201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 40307,
      "e": 40256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40315,
      "e": 40264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40316,
      "e": 40265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40412,
      "e": 40361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 40420,
      "e": 40369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40421,
      "e": 40370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40516,
      "e": 40465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40516,
      "e": 40465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40524,
      "e": 40473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 40628,
      "e": 40577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40668,
      "e": 40617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 40669,
      "e": 40618,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40772,
      "e": 40721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 40876,
      "e": 40825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40878,
      "e": 40827,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40979,
      "e": 40928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40979,
      "e": 40928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41019,
      "e": 40968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 41100,
      "e": 41049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41132,
      "e": 41081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41133,
      "e": 41082,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41187,
      "e": 41136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41187,
      "e": 41136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41227,
      "e": 41176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 41308,
      "e": 41257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41324,
      "e": 41273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 41324,
      "e": 41273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41412,
      "e": 41361,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 41412,
      "e": 41361,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41467,
      "e": 41416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fo"
    },
    {
      "t": 41500,
      "e": 41449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41596,
      "e": 41545,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 41597,
      "e": 41546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41717,
      "e": 41666,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 41718,
      "e": 41667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41719,
      "e": 41668,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41811,
      "e": 41760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41844,
      "e": 41793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41844,
      "e": 41793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41924,
      "e": 41873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 41924,
      "e": 41873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41956,
      "e": 41905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 41996,
      "e": 41945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42052,
      "e": 42001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 42053,
      "e": 42002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42116,
      "e": 42065,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42116,
      "e": 42065,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42147,
      "e": 42096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 42243,
      "e": 42192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42332,
      "e": 42281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 42333,
      "e": 42282,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42419,
      "e": 42368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 42420,
      "e": 42369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42427,
      "e": 42376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||le"
    },
    {
      "t": 42516,
      "e": 42465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42588,
      "e": 42537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42589,
      "e": 42538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42659,
      "e": 42608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 42708,
      "e": 42657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42708,
      "e": 42657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42812,
      "e": 42761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 43221,
      "e": 43170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43221,
      "e": 43170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43332,
      "e": 43281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 43355,
      "e": 43304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 43355,
      "e": 43304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43404,
      "e": 43353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43404,
      "e": 43353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43427,
      "e": 43376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r "
    },
    {
      "t": 43500,
      "e": 43449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43516,
      "e": 43465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 43516,
      "e": 43465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43603,
      "e": 43552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 43628,
      "e": 43577,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 43629,
      "e": 43578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43691,
      "e": 43640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43692,
      "e": 43641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43715,
      "e": 43664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f "
    },
    {
      "t": 43788,
      "e": 43737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43852,
      "e": 43801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43852,
      "e": 43801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43893,
      "e": 43842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 43893,
      "e": 43842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43964,
      "e": 43913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 43972,
      "e": 43921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44003,
      "e": 43952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44003,
      "e": 43952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44075,
      "e": 44024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44076,
      "e": 44025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44108,
      "e": 44057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 44180,
      "e": 44129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44236,
      "e": 44185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 44236,
      "e": 44185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44300,
      "e": 44249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44300,
      "e": 44249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44356,
      "e": 44305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sh"
    },
    {
      "t": 44381,
      "e": 44330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44468,
      "e": 44417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44469,
      "e": 44418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44556,
      "e": 44505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 44587,
      "e": 44536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 44588,
      "e": 44537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44684,
      "e": 44633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 44829,
      "e": 44778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44829,
      "e": 44778,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44924,
      "e": 44873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45501,
      "e": 45450,
      "ty": 2,
      "x": 426,
      "y": 580
    },
    {
      "t": 45501,
      "e": 45450,
      "ty": 41,
      "x": 36972,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45530,
      "e": 45479,
      "ty": 7,
      "x": 418,
      "y": 610,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45598,
      "e": 45547,
      "ty": 6,
      "x": 421,
      "y": 672,
      "ta": "#strategyButton"
    },
    {
      "t": 45601,
      "e": 45550,
      "ty": 2,
      "x": 421,
      "y": 672
    },
    {
      "t": 45701,
      "e": 45650,
      "ty": 2,
      "x": 421,
      "y": 676
    },
    {
      "t": 45751,
      "e": 45700,
      "ty": 41,
      "x": 45004,
      "y": 40989,
      "ta": "#strategyButton"
    },
    {
      "t": 45881,
      "e": 45830,
      "ty": 3,
      "x": 421,
      "y": 676,
      "ta": "#strategyButton"
    },
    {
      "t": 45883,
      "e": 45831,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis of start and end times. Go to 12PM and look straight up that line for the letter of the shift"
    },
    {
      "t": 45885,
      "e": 45833,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45886,
      "e": 45834,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 45944,
      "e": 45892,
      "ty": 4,
      "x": 45004,
      "y": 40989,
      "ta": "#strategyButton"
    },
    {
      "t": 45953,
      "e": 45901,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 45954,
      "e": 45902,
      "ty": 5,
      "x": 421,
      "y": 676,
      "ta": "#strategyButton"
    },
    {
      "t": 45958,
      "e": 45906,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 46959,
      "e": 46907,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 47751,
      "e": 47699,
      "ty": 41,
      "x": 15738,
      "y": 36285,
      "ta": "html > body"
    },
    {
      "t": 47801,
      "e": 47749,
      "ty": 2,
      "x": 594,
      "y": 619
    },
    {
      "t": 47901,
      "e": 47849,
      "ty": 2,
      "x": 671,
      "y": 593
    },
    {
      "t": 48001,
      "e": 47949,
      "ty": 2,
      "x": 719,
      "y": 590
    },
    {
      "t": 48001,
      "e": 47949,
      "ty": 41,
      "x": 24485,
      "y": 32241,
      "ta": "html > body"
    },
    {
      "t": 48101,
      "e": 48049,
      "ty": 2,
      "x": 800,
      "y": 587
    },
    {
      "t": 48200,
      "e": 48148,
      "ty": 2,
      "x": 834,
      "y": 576
    },
    {
      "t": 48232,
      "e": 48180,
      "ty": 6,
      "x": 843,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48252,
      "e": 48200,
      "ty": 41,
      "x": 10381,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48301,
      "e": 48249,
      "ty": 2,
      "x": 860,
      "y": 568
    },
    {
      "t": 48401,
      "e": 48349,
      "ty": 2,
      "x": 871,
      "y": 564
    },
    {
      "t": 48472,
      "e": 48420,
      "ty": 3,
      "x": 871,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48472,
      "e": 48420,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48502,
      "e": 48450,
      "ty": 41,
      "x": 13626,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48576,
      "e": 48524,
      "ty": 4,
      "x": 13626,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48577,
      "e": 48525,
      "ty": 5,
      "x": 871,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49324,
      "e": 49272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 49325,
      "e": 49273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49396,
      "e": 49344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 49396,
      "e": 49344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49404,
      "e": 49352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 49451,
      "e": 49399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 50050,
      "e": 49998,
      "ty": 7,
      "x": 871,
      "y": 580,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50101,
      "e": 50049,
      "ty": 2,
      "x": 874,
      "y": 583
    },
    {
      "t": 50201,
      "e": 50149,
      "ty": 2,
      "x": 874,
      "y": 623
    },
    {
      "t": 50252,
      "e": 50200,
      "ty": 41,
      "x": 14491,
      "y": 58513,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 50301,
      "e": 50249,
      "ty": 2,
      "x": 882,
      "y": 642
    },
    {
      "t": 50385,
      "e": 50333,
      "ty": 6,
      "x": 882,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50401,
      "e": 50349,
      "ty": 2,
      "x": 882,
      "y": 654
    },
    {
      "t": 50501,
      "e": 50449,
      "ty": 2,
      "x": 882,
      "y": 657
    },
    {
      "t": 50501,
      "e": 50449,
      "ty": 41,
      "x": 16005,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50600,
      "e": 50548,
      "ty": 3,
      "x": 881,
      "y": 658,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50602,
      "e": 50550,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 50603,
      "e": 50551,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50603,
      "e": 50551,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50605,
      "e": 50553,
      "ty": 2,
      "x": 881,
      "y": 658
    },
    {
      "t": 50655,
      "e": 50603,
      "ty": 4,
      "x": 15788,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50655,
      "e": 50603,
      "ty": 5,
      "x": 881,
      "y": 658,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50751,
      "e": 50699,
      "ty": 41,
      "x": 15788,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51285,
      "e": 51233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 51733,
      "e": 51681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 51733,
      "e": 51681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51795,
      "e": 51743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 51868,
      "e": 51816,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 51916,
      "e": 51864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 51916,
      "e": 51864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52036,
      "e": 51984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ca"
    },
    {
      "t": 52812,
      "e": 52760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 52813,
      "e": 52761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52883,
      "e": 52831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Can"
    },
    {
      "t": 52980,
      "e": 52928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 52980,
      "e": 52928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53100,
      "e": 53048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Cana"
    },
    {
      "t": 53372,
      "e": 53320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 53372,
      "e": 53320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53508,
      "e": 53456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 53588,
      "e": 53536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 53589,
      "e": 53537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53700,
      "e": 53648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 54339,
      "e": 54287,
      "ty": 7,
      "x": 893,
      "y": 673,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54357,
      "e": 54305,
      "ty": 6,
      "x": 899,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54404,
      "e": 54352,
      "ty": 2,
      "x": 911,
      "y": 690
    },
    {
      "t": 54503,
      "e": 54451,
      "ty": 2,
      "x": 916,
      "y": 697
    },
    {
      "t": 54504,
      "e": 54452,
      "ty": 41,
      "x": 10348,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54604,
      "e": 54552,
      "ty": 2,
      "x": 924,
      "y": 700
    },
    {
      "t": 54644,
      "e": 54592,
      "ty": 3,
      "x": 924,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54645,
      "e": 54593,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Canada"
    },
    {
      "t": 54646,
      "e": 54594,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54646,
      "e": 54594,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54715,
      "e": 54663,
      "ty": 4,
      "x": 14471,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54715,
      "e": 54663,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54716,
      "e": 54664,
      "ty": 5,
      "x": 924,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54716,
      "e": 54664,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 54754,
      "e": 54702,
      "ty": 41,
      "x": 31544,
      "y": 38334,
      "ta": "html > body"
    },
    {
      "t": 55004,
      "e": 54952,
      "ty": 2,
      "x": 925,
      "y": 702
    },
    {
      "t": 55004,
      "e": 54952,
      "ty": 41,
      "x": 31579,
      "y": 38445,
      "ta": "html > body"
    },
    {
      "t": 55740,
      "e": 55688,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 56254,
      "e": 56202,
      "ty": 41,
      "x": 25847,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 56304,
      "e": 56252,
      "ty": 2,
      "x": 923,
      "y": 703
    },
    {
      "t": 56504,
      "e": 56452,
      "ty": 41,
      "x": 25595,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 56754,
      "e": 56702,
      "ty": 41,
      "x": 16749,
      "y": 32730,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 56804,
      "e": 56752,
      "ty": 2,
      "x": 850,
      "y": 482
    },
    {
      "t": 56843,
      "e": 56752,
      "ty": 6,
      "x": 835,
      "y": 444,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 56876,
      "e": 56785,
      "ty": 7,
      "x": 830,
      "y": 428,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 56904,
      "e": 56813,
      "ty": 2,
      "x": 829,
      "y": 424
    },
    {
      "t": 56908,
      "e": 56817,
      "ty": 6,
      "x": 827,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 56926,
      "e": 56835,
      "ty": 7,
      "x": 825,
      "y": 394,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 57004,
      "e": 56913,
      "ty": 2,
      "x": 820,
      "y": 362
    },
    {
      "t": 57004,
      "e": 56913,
      "ty": 41,
      "x": 27963,
      "y": 19610,
      "ta": "html > body"
    },
    {
      "t": 57104,
      "e": 57013,
      "ty": 2,
      "x": 823,
      "y": 345
    },
    {
      "t": 57204,
      "e": 57113,
      "ty": 2,
      "x": 826,
      "y": 337
    },
    {
      "t": 57254,
      "e": 57163,
      "ty": 41,
      "x": 1086,
      "y": 13151,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 57304,
      "e": 57213,
      "ty": 2,
      "x": 826,
      "y": 334
    },
    {
      "t": 57310,
      "e": 57219,
      "ty": 6,
      "x": 829,
      "y": 323,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 57404,
      "e": 57313,
      "ty": 2,
      "x": 830,
      "y": 317
    },
    {
      "t": 57504,
      "e": 57413,
      "ty": 41,
      "x": 18037,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 57692,
      "e": 57601,
      "ty": 3,
      "x": 830,
      "y": 317,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 57693,
      "e": 57602,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 57755,
      "e": 57664,
      "ty": 4,
      "x": 18037,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 57755,
      "e": 57664,
      "ty": 5,
      "x": 830,
      "y": 317,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 57755,
      "e": 57664,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 58194,
      "e": 58103,
      "ty": 7,
      "x": 831,
      "y": 334,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 58204,
      "e": 58113,
      "ty": 2,
      "x": 831,
      "y": 334
    },
    {
      "t": 58254,
      "e": 58163,
      "ty": 41,
      "x": 6070,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 58304,
      "e": 58213,
      "ty": 2,
      "x": 848,
      "y": 369
    },
    {
      "t": 58404,
      "e": 58313,
      "ty": 2,
      "x": 859,
      "y": 389
    },
    {
      "t": 58504,
      "e": 58413,
      "ty": 41,
      "x": 8918,
      "y": 9207,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 58754,
      "e": 58663,
      "ty": 41,
      "x": 8918,
      "y": 9478,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 58804,
      "e": 58713,
      "ty": 2,
      "x": 860,
      "y": 392
    },
    {
      "t": 58904,
      "e": 58813,
      "ty": 2,
      "x": 861,
      "y": 399
    },
    {
      "t": 59004,
      "e": 58913,
      "ty": 2,
      "x": 861,
      "y": 402
    },
    {
      "t": 59004,
      "e": 58913,
      "ty": 41,
      "x": 9392,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 59104,
      "e": 59013,
      "ty": 2,
      "x": 859,
      "y": 406
    },
    {
      "t": 59204,
      "e": 59113,
      "ty": 2,
      "x": 859,
      "y": 412
    },
    {
      "t": 59254,
      "e": 59163,
      "ty": 41,
      "x": 8918,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 59304,
      "e": 59213,
      "ty": 2,
      "x": 859,
      "y": 430
    },
    {
      "t": 59404,
      "e": 59313,
      "ty": 2,
      "x": 855,
      "y": 448
    },
    {
      "t": 59504,
      "e": 59413,
      "ty": 2,
      "x": 850,
      "y": 457
    },
    {
      "t": 59504,
      "e": 59413,
      "ty": 41,
      "x": 6782,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 59604,
      "e": 59513,
      "ty": 2,
      "x": 844,
      "y": 465
    },
    {
      "t": 59704,
      "e": 59613,
      "ty": 2,
      "x": 843,
      "y": 465
    },
    {
      "t": 59754,
      "e": 59663,
      "ty": 41,
      "x": 22808,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 59904,
      "e": 59813,
      "ty": 2,
      "x": 842,
      "y": 466
    },
    {
      "t": 60004,
      "e": 59913,
      "ty": 2,
      "x": 840,
      "y": 468
    },
    {
      "t": 60004,
      "e": 59913,
      "ty": 41,
      "x": 19637,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 60341,
      "e": 60250,
      "ty": 6,
      "x": 839,
      "y": 468,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 60404,
      "e": 60313,
      "ty": 2,
      "x": 836,
      "y": 469
    },
    {
      "t": 60504,
      "e": 60413,
      "ty": 41,
      "x": 48284,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 60572,
      "e": 60481,
      "ty": 3,
      "x": 836,
      "y": 469,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 60573,
      "e": 60482,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 60573,
      "e": 60482,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 60618,
      "e": 60527,
      "ty": 4,
      "x": 48284,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 60619,
      "e": 60528,
      "ty": 5,
      "x": 836,
      "y": 469,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 60620,
      "e": 60529,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 61079,
      "e": 60988,
      "ty": 7,
      "x": 835,
      "y": 481,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 61104,
      "e": 61013,
      "ty": 2,
      "x": 835,
      "y": 487
    },
    {
      "t": 61204,
      "e": 61113,
      "ty": 2,
      "x": 838,
      "y": 478
    },
    {
      "t": 61254,
      "e": 61163,
      "ty": 41,
      "x": 17523,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 61604,
      "e": 61513,
      "ty": 2,
      "x": 834,
      "y": 486
    },
    {
      "t": 61615,
      "e": 61514,
      "ty": 6,
      "x": 830,
      "y": 498,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 61630,
      "e": 61529,
      "ty": 7,
      "x": 829,
      "y": 510,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 61646,
      "e": 61545,
      "ty": 6,
      "x": 828,
      "y": 524,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 61662,
      "e": 61561,
      "ty": 7,
      "x": 825,
      "y": 537,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 61704,
      "e": 61603,
      "ty": 2,
      "x": 820,
      "y": 552
    },
    {
      "t": 61755,
      "e": 61654,
      "ty": 41,
      "x": 27825,
      "y": 32019,
      "ta": "html > body"
    },
    {
      "t": 61804,
      "e": 61703,
      "ty": 2,
      "x": 816,
      "y": 587
    },
    {
      "t": 61904,
      "e": 61803,
      "ty": 2,
      "x": 815,
      "y": 588
    },
    {
      "t": 62004,
      "e": 61903,
      "ty": 2,
      "x": 813,
      "y": 601
    },
    {
      "t": 62005,
      "e": 61904,
      "ty": 41,
      "x": 27722,
      "y": 32850,
      "ta": "html > body"
    },
    {
      "t": 62104,
      "e": 62003,
      "ty": 2,
      "x": 862,
      "y": 639
    },
    {
      "t": 62254,
      "e": 62153,
      "ty": 41,
      "x": 9630,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 62404,
      "e": 62303,
      "ty": 2,
      "x": 850,
      "y": 659
    },
    {
      "t": 62504,
      "e": 62403,
      "ty": 2,
      "x": 847,
      "y": 661
    },
    {
      "t": 62504,
      "e": 62403,
      "ty": 41,
      "x": 6070,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 62604,
      "e": 62503,
      "ty": 2,
      "x": 845,
      "y": 663
    },
    {
      "t": 62704,
      "e": 62603,
      "ty": 2,
      "x": 844,
      "y": 681
    },
    {
      "t": 62755,
      "e": 62654,
      "ty": 41,
      "x": 5358,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 62804,
      "e": 62703,
      "ty": 2,
      "x": 844,
      "y": 689
    },
    {
      "t": 62904,
      "e": 62803,
      "ty": 2,
      "x": 844,
      "y": 691
    },
    {
      "t": 63004,
      "e": 62903,
      "ty": 41,
      "x": 5358,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 63204,
      "e": 63103,
      "ty": 2,
      "x": 850,
      "y": 692
    },
    {
      "t": 63254,
      "e": 63153,
      "ty": 41,
      "x": 7019,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 63304,
      "e": 63203,
      "ty": 2,
      "x": 851,
      "y": 686
    },
    {
      "t": 63705,
      "e": 63604,
      "ty": 2,
      "x": 844,
      "y": 693
    },
    {
      "t": 63754,
      "e": 63653,
      "ty": 41,
      "x": 5689,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 63804,
      "e": 63703,
      "ty": 2,
      "x": 842,
      "y": 696
    },
    {
      "t": 63876,
      "e": 63775,
      "ty": 6,
      "x": 839,
      "y": 699,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 63904,
      "e": 63803,
      "ty": 2,
      "x": 839,
      "y": 699
    },
    {
      "t": 64005,
      "e": 63904,
      "ty": 41,
      "x": 63408,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64104,
      "e": 64003,
      "ty": 2,
      "x": 835,
      "y": 701
    },
    {
      "t": 64204,
      "e": 64103,
      "ty": 2,
      "x": 835,
      "y": 702
    },
    {
      "t": 64255,
      "e": 64154,
      "ty": 41,
      "x": 43243,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64277,
      "e": 64176,
      "ty": 3,
      "x": 835,
      "y": 702,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64278,
      "e": 64177,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 64278,
      "e": 64177,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64306,
      "e": 64205,
      "ty": 4,
      "x": 43243,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64306,
      "e": 64205,
      "ty": 5,
      "x": 835,
      "y": 702,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64307,
      "e": 64206,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 64782,
      "e": 64681,
      "ty": 7,
      "x": 835,
      "y": 709,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 64804,
      "e": 64703,
      "ty": 2,
      "x": 836,
      "y": 714
    },
    {
      "t": 64848,
      "e": 64747,
      "ty": 6,
      "x": 839,
      "y": 729,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 64865,
      "e": 64764,
      "ty": 7,
      "x": 840,
      "y": 738,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 64904,
      "e": 64803,
      "ty": 2,
      "x": 842,
      "y": 752
    },
    {
      "t": 64931,
      "e": 64830,
      "ty": 6,
      "x": 838,
      "y": 760,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 65004,
      "e": 64903,
      "ty": 2,
      "x": 838,
      "y": 760
    },
    {
      "t": 65004,
      "e": 64903,
      "ty": 41,
      "x": 58367,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 65305,
      "e": 65204,
      "ty": 2,
      "x": 838,
      "y": 761
    },
    {
      "t": 65317,
      "e": 65216,
      "ty": 7,
      "x": 838,
      "y": 767,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 65405,
      "e": 65304,
      "ty": 2,
      "x": 846,
      "y": 793
    },
    {
      "t": 65505,
      "e": 65404,
      "ty": 2,
      "x": 858,
      "y": 842
    },
    {
      "t": 65505,
      "e": 65404,
      "ty": 41,
      "x": 25771,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 65604,
      "e": 65503,
      "ty": 2,
      "x": 866,
      "y": 924
    },
    {
      "t": 65705,
      "e": 65604,
      "ty": 2,
      "x": 847,
      "y": 952
    },
    {
      "t": 65756,
      "e": 65605,
      "ty": 41,
      "x": 6070,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 66105,
      "e": 65954,
      "ty": 2,
      "x": 842,
      "y": 945
    },
    {
      "t": 66205,
      "e": 66054,
      "ty": 2,
      "x": 839,
      "y": 941
    },
    {
      "t": 66254,
      "e": 66103,
      "ty": 41,
      "x": 18107,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 66276,
      "e": 66125,
      "ty": 6,
      "x": 834,
      "y": 938,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66304,
      "e": 66153,
      "ty": 2,
      "x": 830,
      "y": 935
    },
    {
      "t": 66404,
      "e": 66253,
      "ty": 2,
      "x": 830,
      "y": 934
    },
    {
      "t": 66435,
      "e": 66284,
      "ty": 3,
      "x": 830,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66436,
      "e": 66285,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 66436,
      "e": 66285,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66491,
      "e": 66340,
      "ty": 4,
      "x": 18037,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66492,
      "e": 66341,
      "ty": 5,
      "x": 830,
      "y": 934,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66492,
      "e": 66341,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 66504,
      "e": 66353,
      "ty": 41,
      "x": 18037,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66650,
      "e": 66499,
      "ty": 7,
      "x": 842,
      "y": 940,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 66704,
      "e": 66553,
      "ty": 2,
      "x": 863,
      "y": 979
    },
    {
      "t": 66754,
      "e": 66603,
      "ty": 41,
      "x": 13190,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 66766,
      "e": 66615,
      "ty": 6,
      "x": 881,
      "y": 1011,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66804,
      "e": 66653,
      "ty": 2,
      "x": 884,
      "y": 1016
    },
    {
      "t": 66905,
      "e": 66754,
      "ty": 2,
      "x": 887,
      "y": 1021
    },
    {
      "t": 67004,
      "e": 66853,
      "ty": 3,
      "x": 887,
      "y": 1021,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67005,
      "e": 66854,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 67006,
      "e": 66855,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67008,
      "e": 66857,
      "ty": 41,
      "x": 29675,
      "y": 31774,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67051,
      "e": 66900,
      "ty": 4,
      "x": 29675,
      "y": 31774,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67051,
      "e": 66900,
      "ty": 5,
      "x": 887,
      "y": 1021,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67053,
      "e": 66902,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 67053,
      "e": 66902,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 67054,
      "e": 66903,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 68380,
      "e": 68229,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 76605,
      "e": 71902,
      "ty": 2,
      "x": 916,
      "y": 1022
    },
    {
      "t": 76705,
      "e": 72002,
      "ty": 2,
      "x": 961,
      "y": 1059
    },
    {
      "t": 76755,
      "e": 72052,
      "ty": 41,
      "x": 32988,
      "y": 64725,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76804,
      "e": 72101,
      "ty": 2,
      "x": 964,
      "y": 1063
    },
    {
      "t": 76905,
      "e": 72202,
      "ty": 2,
      "x": 964,
      "y": 1065
    },
    {
      "t": 77005,
      "e": 72302,
      "ty": 2,
      "x": 960,
      "y": 1065
    },
    {
      "t": 77005,
      "e": 72302,
      "ty": 41,
      "x": 32792,
      "y": 65002,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 77904,
      "e": 73201,
      "ty": 2,
      "x": 959,
      "y": 1066
    },
    {
      "t": 78005,
      "e": 73302,
      "ty": 41,
      "x": 32742,
      "y": 65071,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 78105,
      "e": 73402,
      "ty": 2,
      "x": 958,
      "y": 1067
    },
    {
      "t": 78204,
      "e": 73501,
      "ty": 2,
      "x": 956,
      "y": 1067
    },
    {
      "t": 78254,
      "e": 73551,
      "ty": 41,
      "x": 32595,
      "y": 65141,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 78404,
      "e": 73701,
      "ty": 2,
      "x": 956,
      "y": 1069
    },
    {
      "t": 78451,
      "e": 73748,
      "ty": 6,
      "x": 956,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 78504,
      "e": 73801,
      "ty": 2,
      "x": 956,
      "y": 1077
    },
    {
      "t": 78504,
      "e": 73801,
      "ty": 41,
      "x": 25394,
      "y": 8312,
      "ta": "#start"
    },
    {
      "t": 78604,
      "e": 73901,
      "ty": 2,
      "x": 978,
      "y": 1102
    },
    {
      "t": 78703,
      "e": 74000,
      "ty": 2,
      "x": 984,
      "y": 1106
    },
    {
      "t": 78709,
      "e": 74006,
      "ty": 7,
      "x": 985,
      "y": 1107,
      "ta": "#start"
    },
    {
      "t": 78754,
      "e": 74051,
      "ty": 41,
      "x": 47044,
      "y": 20116,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 78804,
      "e": 74101,
      "ty": 2,
      "x": 993,
      "y": 1112
    },
    {
      "t": 78903,
      "e": 74200,
      "ty": 2,
      "x": 999,
      "y": 1115
    },
    {
      "t": 79004,
      "e": 74301,
      "ty": 2,
      "x": 999,
      "y": 1114
    },
    {
      "t": 79004,
      "e": 74301,
      "ty": 41,
      "x": 51257,
      "y": 22886,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 79104,
      "e": 74401,
      "ty": 2,
      "x": 997,
      "y": 1108
    },
    {
      "t": 79111,
      "e": 74408,
      "ty": 6,
      "x": 996,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 79204,
      "e": 74501,
      "ty": 2,
      "x": 994,
      "y": 1095
    },
    {
      "t": 79254,
      "e": 74551,
      "ty": 41,
      "x": 46147,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 79304,
      "e": 74601,
      "ty": 2,
      "x": 994,
      "y": 1090
    },
    {
      "t": 79504,
      "e": 74801,
      "ty": 2,
      "x": 994,
      "y": 1087
    },
    {
      "t": 79504,
      "e": 74801,
      "ty": 41,
      "x": 46147,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 79604,
      "e": 74901,
      "ty": 2,
      "x": 993,
      "y": 1084
    },
    {
      "t": 79678,
      "e": 74975,
      "ty": 7,
      "x": 993,
      "y": 1070,
      "ta": "#start"
    },
    {
      "t": 79704,
      "e": 75001,
      "ty": 2,
      "x": 993,
      "y": 1066
    },
    {
      "t": 79755,
      "e": 75052,
      "ty": 41,
      "x": 34415,
      "y": 64171,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 79803,
      "e": 75100,
      "ty": 2,
      "x": 993,
      "y": 1048
    },
    {
      "t": 79904,
      "e": 75201,
      "ty": 2,
      "x": 993,
      "y": 1046
    },
    {
      "t": 80004,
      "e": 75301,
      "ty": 41,
      "x": 34415,
      "y": 63686,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 80004,
      "e": 75301,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80104,
      "e": 75401,
      "ty": 2,
      "x": 989,
      "y": 1067
    },
    {
      "t": 80144,
      "e": 75441,
      "ty": 6,
      "x": 989,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 80204,
      "e": 75501,
      "ty": 2,
      "x": 989,
      "y": 1081
    },
    {
      "t": 80254,
      "e": 75551,
      "ty": 41,
      "x": 42870,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 80304,
      "e": 75601,
      "ty": 2,
      "x": 987,
      "y": 1086
    },
    {
      "t": 80404,
      "e": 75701,
      "ty": 2,
      "x": 985,
      "y": 1090
    },
    {
      "t": 80427,
      "e": 75724,
      "ty": 3,
      "x": 985,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 80427,
      "e": 75724,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 80499,
      "e": 75796,
      "ty": 4,
      "x": 41232,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 80499,
      "e": 75796,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 80499,
      "e": 75796,
      "ty": 5,
      "x": 985,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 80500,
      "e": 75797,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 80504,
      "e": 75801,
      "ty": 41,
      "x": 33645,
      "y": 59939,
      "ta": "html > body"
    },
    {
      "t": 81528,
      "e": 76825,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 83004,
      "e": 78301,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 648754, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 648761, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 21855, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 671961, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 11930, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"NOVEMBER\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 684900, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 16614, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 702611, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 17239, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 720852, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 23322, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 745554, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-A -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1179,y:590,t:1527271777925};\\\", \\\"{x:1177,y:590,t:1527271777942};\\\", \\\"{x:1176,y:591,t:1527271777959};\\\", \\\"{x:1176,y:593,t:1527271785886};\\\", \\\"{x:1177,y:595,t:1527271785897};\\\", \\\"{x:1177,y:596,t:1527271785914};\\\", \\\"{x:1179,y:599,t:1527271785932};\\\", \\\"{x:1181,y:602,t:1527271785948};\\\", \\\"{x:1184,y:606,t:1527271785964};\\\", \\\"{x:1188,y:611,t:1527271785981};\\\", \\\"{x:1192,y:614,t:1527271785998};\\\", \\\"{x:1193,y:617,t:1527271786014};\\\", \\\"{x:1195,y:621,t:1527271786032};\\\", \\\"{x:1197,y:624,t:1527271786048};\\\", \\\"{x:1197,y:625,t:1527271786064};\\\", \\\"{x:1199,y:628,t:1527271786082};\\\", \\\"{x:1201,y:630,t:1527271786098};\\\", \\\"{x:1201,y:631,t:1527271786114};\\\", \\\"{x:1204,y:636,t:1527271786134};\\\", \\\"{x:1205,y:637,t:1527271786149};\\\", \\\"{x:1206,y:640,t:1527271786163};\\\", \\\"{x:1211,y:647,t:1527271786181};\\\", \\\"{x:1213,y:651,t:1527271786197};\\\", \\\"{x:1216,y:655,t:1527271786214};\\\", \\\"{x:1218,y:658,t:1527271786230};\\\", \\\"{x:1220,y:662,t:1527271786247};\\\", \\\"{x:1222,y:664,t:1527271786264};\\\", \\\"{x:1225,y:668,t:1527271786281};\\\", \\\"{x:1227,y:670,t:1527271786298};\\\", \\\"{x:1227,y:671,t:1527271786313};\\\", \\\"{x:1228,y:673,t:1527271786331};\\\", \\\"{x:1230,y:676,t:1527271786348};\\\", \\\"{x:1232,y:680,t:1527271786365};\\\", \\\"{x:1233,y:682,t:1527271786380};\\\", \\\"{x:1235,y:685,t:1527271786397};\\\", \\\"{x:1238,y:691,t:1527271786415};\\\", \\\"{x:1241,y:694,t:1527271786430};\\\", \\\"{x:1244,y:699,t:1527271786448};\\\", \\\"{x:1245,y:703,t:1527271786465};\\\", \\\"{x:1248,y:706,t:1527271786481};\\\", \\\"{x:1250,y:708,t:1527271786498};\\\", \\\"{x:1252,y:711,t:1527271786515};\\\", \\\"{x:1253,y:715,t:1527271786531};\\\", \\\"{x:1254,y:717,t:1527271786549};\\\", \\\"{x:1256,y:725,t:1527271786565};\\\", \\\"{x:1258,y:728,t:1527271786581};\\\", \\\"{x:1259,y:732,t:1527271786598};\\\", \\\"{x:1261,y:734,t:1527271786616};\\\", \\\"{x:1262,y:737,t:1527271786632};\\\", \\\"{x:1263,y:740,t:1527271786649};\\\", \\\"{x:1264,y:743,t:1527271786665};\\\", \\\"{x:1266,y:747,t:1527271786681};\\\", \\\"{x:1268,y:751,t:1527271786699};\\\", \\\"{x:1270,y:755,t:1527271786716};\\\", \\\"{x:1273,y:760,t:1527271786731};\\\", \\\"{x:1276,y:764,t:1527271786749};\\\", \\\"{x:1279,y:772,t:1527271786765};\\\", \\\"{x:1281,y:777,t:1527271786781};\\\", \\\"{x:1282,y:779,t:1527271786799};\\\", \\\"{x:1282,y:781,t:1527271786815};\\\", \\\"{x:1283,y:783,t:1527271786831};\\\", \\\"{x:1283,y:784,t:1527271786848};\\\", \\\"{x:1283,y:786,t:1527271786865};\\\", \\\"{x:1283,y:787,t:1527271786885};\\\", \\\"{x:1283,y:788,t:1527271786900};\\\", \\\"{x:1283,y:789,t:1527271786915};\\\", \\\"{x:1283,y:793,t:1527271786932};\\\", \\\"{x:1284,y:796,t:1527271786947};\\\", \\\"{x:1284,y:799,t:1527271786965};\\\", \\\"{x:1285,y:803,t:1527271786982};\\\", \\\"{x:1285,y:805,t:1527271786997};\\\", \\\"{x:1285,y:808,t:1527271787015};\\\", \\\"{x:1285,y:811,t:1527271787032};\\\", \\\"{x:1286,y:813,t:1527271787048};\\\", \\\"{x:1287,y:815,t:1527271787065};\\\", \\\"{x:1287,y:816,t:1527271787126};\\\", \\\"{x:1287,y:817,t:1527271787141};\\\", \\\"{x:1287,y:818,t:1527271787157};\\\", \\\"{x:1287,y:819,t:1527271787174};\\\", \\\"{x:1287,y:820,t:1527271787182};\\\", \\\"{x:1287,y:819,t:1527271787389};\\\", \\\"{x:1287,y:816,t:1527271787400};\\\", \\\"{x:1287,y:809,t:1527271787415};\\\", \\\"{x:1287,y:803,t:1527271787431};\\\", \\\"{x:1287,y:796,t:1527271787449};\\\", \\\"{x:1287,y:788,t:1527271787464};\\\", \\\"{x:1287,y:778,t:1527271787482};\\\", \\\"{x:1286,y:771,t:1527271787499};\\\", \\\"{x:1284,y:769,t:1527271787515};\\\", \\\"{x:1283,y:764,t:1527271787532};\\\", \\\"{x:1282,y:762,t:1527271787548};\\\", \\\"{x:1282,y:760,t:1527271787565};\\\", \\\"{x:1282,y:759,t:1527271787582};\\\", \\\"{x:1282,y:758,t:1527271787599};\\\", \\\"{x:1281,y:757,t:1527271787616};\\\", \\\"{x:1281,y:755,t:1527271787633};\\\", \\\"{x:1280,y:754,t:1527271787650};\\\", \\\"{x:1280,y:752,t:1527271787665};\\\", \\\"{x:1280,y:751,t:1527271787682};\\\", \\\"{x:1279,y:748,t:1527271787699};\\\", \\\"{x:1279,y:744,t:1527271787715};\\\", \\\"{x:1277,y:740,t:1527271787733};\\\", \\\"{x:1276,y:733,t:1527271787749};\\\", \\\"{x:1276,y:730,t:1527271787765};\\\", \\\"{x:1275,y:729,t:1527271787782};\\\", \\\"{x:1275,y:727,t:1527271787800};\\\", \\\"{x:1275,y:723,t:1527271787817};\\\", \\\"{x:1275,y:721,t:1527271787833};\\\", \\\"{x:1275,y:720,t:1527271787849};\\\", \\\"{x:1275,y:718,t:1527271787866};\\\", \\\"{x:1275,y:714,t:1527271787882};\\\", \\\"{x:1275,y:710,t:1527271787899};\\\", \\\"{x:1275,y:704,t:1527271787917};\\\", \\\"{x:1273,y:694,t:1527271787933};\\\", \\\"{x:1269,y:679,t:1527271787949};\\\", \\\"{x:1268,y:669,t:1527271787966};\\\", \\\"{x:1268,y:661,t:1527271787982};\\\", \\\"{x:1268,y:656,t:1527271788000};\\\", \\\"{x:1268,y:651,t:1527271788017};\\\", \\\"{x:1268,y:648,t:1527271788032};\\\", \\\"{x:1268,y:644,t:1527271788050};\\\", \\\"{x:1268,y:643,t:1527271788067};\\\", \\\"{x:1268,y:641,t:1527271788083};\\\", \\\"{x:1268,y:639,t:1527271788102};\\\", \\\"{x:1269,y:638,t:1527271788117};\\\", \\\"{x:1269,y:636,t:1527271788132};\\\", \\\"{x:1270,y:635,t:1527271788165};\\\", \\\"{x:1270,y:634,t:1527271788182};\\\", \\\"{x:1270,y:632,t:1527271788199};\\\", \\\"{x:1270,y:631,t:1527271788216};\\\", \\\"{x:1270,y:628,t:1527271788233};\\\", \\\"{x:1266,y:623,t:1527271788249};\\\", \\\"{x:1258,y:613,t:1527271788266};\\\", \\\"{x:1251,y:604,t:1527271788284};\\\", \\\"{x:1268,y:594,t:1527271788301};\\\", \\\"{x:1299,y:585,t:1527271788317};\\\", \\\"{x:1299,y:593,t:1527271789134};\\\", \\\"{x:1297,y:619,t:1527271789151};\\\", \\\"{x:1295,y:637,t:1527271789167};\\\", \\\"{x:1291,y:649,t:1527271789183};\\\", \\\"{x:1282,y:665,t:1527271789201};\\\", \\\"{x:1265,y:683,t:1527271789217};\\\", \\\"{x:1225,y:706,t:1527271789233};\\\", \\\"{x:1127,y:738,t:1527271789251};\\\", \\\"{x:1006,y:771,t:1527271789268};\\\", \\\"{x:884,y:807,t:1527271789283};\\\", \\\"{x:784,y:837,t:1527271789301};\\\", \\\"{x:658,y:841,t:1527271789317};\\\", \\\"{x:575,y:833,t:1527271789333};\\\", \\\"{x:478,y:819,t:1527271789351};\\\", \\\"{x:436,y:816,t:1527271789367};\\\", \\\"{x:424,y:815,t:1527271789383};\\\", \\\"{x:422,y:815,t:1527271789401};\\\", \\\"{x:416,y:811,t:1527271789417};\\\", \\\"{x:397,y:800,t:1527271789433};\\\", \\\"{x:381,y:789,t:1527271789451};\\\", \\\"{x:375,y:783,t:1527271789467};\\\", \\\"{x:375,y:778,t:1527271789485};\\\", \\\"{x:375,y:773,t:1527271789501};\\\", \\\"{x:375,y:749,t:1527271789518};\\\", \\\"{x:373,y:735,t:1527271789533};\\\", \\\"{x:373,y:716,t:1527271789550};\\\", \\\"{x:375,y:703,t:1527271789568};\\\", \\\"{x:377,y:687,t:1527271789583};\\\", \\\"{x:377,y:671,t:1527271789600};\\\", \\\"{x:378,y:660,t:1527271789618};\\\", \\\"{x:384,y:646,t:1527271789635};\\\", \\\"{x:390,y:635,t:1527271789649};\\\", \\\"{x:395,y:624,t:1527271789667};\\\", \\\"{x:397,y:613,t:1527271789684};\\\", \\\"{x:398,y:598,t:1527271789701};\\\", \\\"{x:398,y:591,t:1527271789717};\\\", \\\"{x:398,y:577,t:1527271789734};\\\", \\\"{x:402,y:563,t:1527271789752};\\\", \\\"{x:403,y:554,t:1527271789767};\\\", \\\"{x:402,y:545,t:1527271789784};\\\", \\\"{x:400,y:538,t:1527271789801};\\\", \\\"{x:399,y:536,t:1527271789818};\\\", \\\"{x:399,y:535,t:1527271789834};\\\", \\\"{x:399,y:533,t:1527271789851};\\\", \\\"{x:398,y:532,t:1527271789868};\\\", \\\"{x:398,y:531,t:1527271789884};\\\", \\\"{x:396,y:530,t:1527271789926};\\\", \\\"{x:393,y:529,t:1527271789941};\\\", \\\"{x:392,y:529,t:1527271789957};\\\", \\\"{x:391,y:528,t:1527271789973};\\\", \\\"{x:390,y:528,t:1527271790045};\\\", \\\"{x:389,y:528,t:1527271790102};\\\", \\\"{x:388,y:527,t:1527271790120};\\\", \\\"{x:388,y:526,t:1527271790141};\\\", \\\"{x:388,y:524,t:1527271790152};\\\", \\\"{x:386,y:522,t:1527271790169};\\\", \\\"{x:388,y:522,t:1527271790710};\\\", \\\"{x:396,y:524,t:1527271790720};\\\", \\\"{x:402,y:526,t:1527271790736};\\\", \\\"{x:404,y:527,t:1527271790752};\\\", \\\"{x:404,y:528,t:1527271790789};\\\", \\\"{x:406,y:528,t:1527271790812};\\\", \\\"{x:410,y:530,t:1527271790820};\\\", \\\"{x:414,y:532,t:1527271790835};\\\", \\\"{x:425,y:536,t:1527271790851};\\\", \\\"{x:434,y:541,t:1527271790868};\\\", \\\"{x:437,y:541,t:1527271790886};\\\", \\\"{x:437,y:542,t:1527271790901};\\\", \\\"{x:438,y:543,t:1527271790933};\\\", \\\"{x:439,y:544,t:1527271791062};\\\", \\\"{x:443,y:549,t:1527271791068};\\\", \\\"{x:451,y:553,t:1527271791085};\\\", \\\"{x:458,y:554,t:1527271791102};\\\", \\\"{x:463,y:555,t:1527271791119};\\\", \\\"{x:466,y:557,t:1527271791136};\\\", \\\"{x:471,y:558,t:1527271791152};\\\", \\\"{x:480,y:561,t:1527271791169};\\\", \\\"{x:489,y:562,t:1527271791186};\\\", \\\"{x:496,y:562,t:1527271791202};\\\", \\\"{x:502,y:563,t:1527271791220};\\\", \\\"{x:503,y:563,t:1527271791235};\\\", \\\"{x:504,y:563,t:1527271791252};\\\", \\\"{x:508,y:563,t:1527271791269};\\\", \\\"{x:514,y:563,t:1527271791286};\\\", \\\"{x:519,y:565,t:1527271791302};\\\", \\\"{x:522,y:565,t:1527271791319};\\\", \\\"{x:522,y:566,t:1527271791336};\\\", \\\"{x:526,y:566,t:1527271793550};\\\", \\\"{x:541,y:567,t:1527271793557};\\\", \\\"{x:560,y:571,t:1527271793572};\\\", \\\"{x:619,y:579,t:1527271793588};\\\", \\\"{x:674,y:586,t:1527271793605};\\\", \\\"{x:753,y:586,t:1527271793621};\\\", \\\"{x:841,y:586,t:1527271793638};\\\", \\\"{x:936,y:586,t:1527271793654};\\\", \\\"{x:1025,y:589,t:1527271793671};\\\", \\\"{x:1103,y:598,t:1527271793688};\\\", \\\"{x:1164,y:607,t:1527271793703};\\\", \\\"{x:1206,y:618,t:1527271793721};\\\", \\\"{x:1223,y:626,t:1527271793738};\\\", \\\"{x:1237,y:637,t:1527271793754};\\\", \\\"{x:1241,y:645,t:1527271793771};\\\", \\\"{x:1243,y:659,t:1527271793788};\\\", \\\"{x:1245,y:677,t:1527271793804};\\\", \\\"{x:1251,y:714,t:1527271793821};\\\", \\\"{x:1255,y:754,t:1527271793838};\\\", \\\"{x:1258,y:787,t:1527271793854};\\\", \\\"{x:1258,y:802,t:1527271793871};\\\", \\\"{x:1258,y:811,t:1527271793888};\\\", \\\"{x:1258,y:818,t:1527271793904};\\\", \\\"{x:1260,y:825,t:1527271793921};\\\", \\\"{x:1263,y:835,t:1527271793938};\\\", \\\"{x:1266,y:847,t:1527271793954};\\\", \\\"{x:1266,y:860,t:1527271793971};\\\", \\\"{x:1266,y:874,t:1527271793989};\\\", \\\"{x:1267,y:887,t:1527271794005};\\\", \\\"{x:1270,y:892,t:1527271794021};\\\", \\\"{x:1272,y:895,t:1527271794038};\\\", \\\"{x:1272,y:896,t:1527271794165};\\\", \\\"{x:1273,y:897,t:1527271794182};\\\", \\\"{x:1277,y:904,t:1527271794189};\\\", \\\"{x:1277,y:909,t:1527271794205};\\\", \\\"{x:1276,y:913,t:1527271794222};\\\", \\\"{x:1276,y:914,t:1527271794238};\\\", \\\"{x:1276,y:915,t:1527271794310};\\\", \\\"{x:1276,y:918,t:1527271794321};\\\", \\\"{x:1276,y:927,t:1527271794338};\\\", \\\"{x:1276,y:931,t:1527271794356};\\\", \\\"{x:1276,y:934,t:1527271794371};\\\", \\\"{x:1276,y:936,t:1527271794389};\\\", \\\"{x:1276,y:938,t:1527271794406};\\\", \\\"{x:1276,y:941,t:1527271794422};\\\", \\\"{x:1277,y:945,t:1527271794438};\\\", \\\"{x:1279,y:952,t:1527271794456};\\\", \\\"{x:1281,y:959,t:1527271794472};\\\", \\\"{x:1282,y:963,t:1527271794488};\\\", \\\"{x:1282,y:967,t:1527271794506};\\\", \\\"{x:1282,y:969,t:1527271794522};\\\", \\\"{x:1282,y:971,t:1527271794538};\\\", \\\"{x:1282,y:972,t:1527271794555};\\\", \\\"{x:1282,y:971,t:1527271794629};\\\", \\\"{x:1282,y:967,t:1527271794640};\\\", \\\"{x:1282,y:958,t:1527271794656};\\\", \\\"{x:1282,y:950,t:1527271794673};\\\", \\\"{x:1282,y:939,t:1527271794689};\\\", \\\"{x:1284,y:926,t:1527271794706};\\\", \\\"{x:1285,y:916,t:1527271794723};\\\", \\\"{x:1287,y:908,t:1527271794739};\\\", \\\"{x:1287,y:902,t:1527271794756};\\\", \\\"{x:1287,y:897,t:1527271794773};\\\", \\\"{x:1287,y:893,t:1527271794789};\\\", \\\"{x:1288,y:887,t:1527271794805};\\\", \\\"{x:1289,y:883,t:1527271794822};\\\", \\\"{x:1290,y:877,t:1527271794838};\\\", \\\"{x:1290,y:875,t:1527271794856};\\\", \\\"{x:1290,y:872,t:1527271794873};\\\", \\\"{x:1290,y:869,t:1527271794889};\\\", \\\"{x:1290,y:868,t:1527271794905};\\\", \\\"{x:1290,y:866,t:1527271794925};\\\", \\\"{x:1290,y:865,t:1527271794949};\\\", \\\"{x:1290,y:863,t:1527271794957};\\\", \\\"{x:1290,y:862,t:1527271794973};\\\", \\\"{x:1290,y:860,t:1527271794989};\\\", \\\"{x:1290,y:858,t:1527271795006};\\\", \\\"{x:1290,y:855,t:1527271795023};\\\", \\\"{x:1290,y:849,t:1527271795039};\\\", \\\"{x:1290,y:844,t:1527271795055};\\\", \\\"{x:1288,y:840,t:1527271795073};\\\", \\\"{x:1288,y:837,t:1527271795089};\\\", \\\"{x:1288,y:834,t:1527271795105};\\\", \\\"{x:1288,y:833,t:1527271795123};\\\", \\\"{x:1288,y:832,t:1527271795139};\\\", \\\"{x:1288,y:833,t:1527271795365};\\\", \\\"{x:1288,y:834,t:1527271795373};\\\", \\\"{x:1288,y:837,t:1527271795389};\\\", \\\"{x:1288,y:838,t:1527271795421};\\\", \\\"{x:1286,y:838,t:1527271795574};\\\", \\\"{x:1284,y:838,t:1527271795590};\\\", \\\"{x:1284,y:837,t:1527271795607};\\\", \\\"{x:1283,y:836,t:1527271795622};\\\", \\\"{x:1282,y:836,t:1527271795717};\\\", \\\"{x:1282,y:835,t:1527271795742};\\\", \\\"{x:1281,y:833,t:1527271795837};\\\", \\\"{x:1283,y:836,t:1527271795991};\\\", \\\"{x:1286,y:842,t:1527271796007};\\\", \\\"{x:1287,y:847,t:1527271796023};\\\", \\\"{x:1288,y:850,t:1527271796040};\\\", \\\"{x:1290,y:854,t:1527271796057};\\\", \\\"{x:1293,y:863,t:1527271796074};\\\", \\\"{x:1300,y:875,t:1527271796090};\\\", \\\"{x:1301,y:882,t:1527271796106};\\\", \\\"{x:1304,y:886,t:1527271796124};\\\", \\\"{x:1305,y:893,t:1527271796140};\\\", \\\"{x:1307,y:899,t:1527271796157};\\\", \\\"{x:1309,y:908,t:1527271796173};\\\", \\\"{x:1311,y:913,t:1527271796190};\\\", \\\"{x:1311,y:917,t:1527271796207};\\\", \\\"{x:1312,y:920,t:1527271796224};\\\", \\\"{x:1312,y:925,t:1527271796240};\\\", \\\"{x:1312,y:929,t:1527271796257};\\\", \\\"{x:1310,y:934,t:1527271796274};\\\", \\\"{x:1310,y:936,t:1527271796290};\\\", \\\"{x:1309,y:939,t:1527271796306};\\\", \\\"{x:1307,y:942,t:1527271796323};\\\", \\\"{x:1304,y:948,t:1527271796340};\\\", \\\"{x:1302,y:951,t:1527271796357};\\\", \\\"{x:1297,y:956,t:1527271796374};\\\", \\\"{x:1295,y:959,t:1527271796390};\\\", \\\"{x:1293,y:961,t:1527271796662};\\\", \\\"{x:1292,y:961,t:1527271796701};\\\", \\\"{x:1292,y:962,t:1527271796709};\\\", \\\"{x:1291,y:963,t:1527271796726};\\\", \\\"{x:1289,y:963,t:1527271796741};\\\", \\\"{x:1289,y:964,t:1527271796757};\\\", \\\"{x:1285,y:964,t:1527271796774};\\\", \\\"{x:1283,y:965,t:1527271796791};\\\", \\\"{x:1281,y:965,t:1527271796807};\\\", \\\"{x:1280,y:966,t:1527271796823};\\\", \\\"{x:1279,y:966,t:1527271796900};\\\", \\\"{x:1277,y:964,t:1527271796908};\\\", \\\"{x:1277,y:963,t:1527271796923};\\\", \\\"{x:1275,y:958,t:1527271796941};\\\", \\\"{x:1274,y:954,t:1527271796957};\\\", \\\"{x:1274,y:950,t:1527271796974};\\\", \\\"{x:1274,y:945,t:1527271796991};\\\", \\\"{x:1274,y:942,t:1527271797008};\\\", \\\"{x:1274,y:936,t:1527271797023};\\\", \\\"{x:1274,y:931,t:1527271797040};\\\", \\\"{x:1274,y:925,t:1527271797057};\\\", \\\"{x:1274,y:920,t:1527271797073};\\\", \\\"{x:1274,y:915,t:1527271797090};\\\", \\\"{x:1274,y:910,t:1527271797108};\\\", \\\"{x:1275,y:905,t:1527271797124};\\\", \\\"{x:1277,y:898,t:1527271797140};\\\", \\\"{x:1279,y:890,t:1527271797157};\\\", \\\"{x:1282,y:883,t:1527271797174};\\\", \\\"{x:1282,y:879,t:1527271797191};\\\", \\\"{x:1282,y:874,t:1527271797207};\\\", \\\"{x:1282,y:871,t:1527271797224};\\\", \\\"{x:1282,y:867,t:1527271797240};\\\", \\\"{x:1282,y:860,t:1527271797257};\\\", \\\"{x:1283,y:854,t:1527271797273};\\\", \\\"{x:1283,y:850,t:1527271797290};\\\", \\\"{x:1283,y:845,t:1527271797308};\\\", \\\"{x:1283,y:842,t:1527271797324};\\\", \\\"{x:1283,y:838,t:1527271797340};\\\", \\\"{x:1283,y:834,t:1527271797357};\\\", \\\"{x:1283,y:831,t:1527271797373};\\\", \\\"{x:1283,y:828,t:1527271797390};\\\", \\\"{x:1282,y:827,t:1527271797407};\\\", \\\"{x:1281,y:823,t:1527271797425};\\\", \\\"{x:1281,y:822,t:1527271797441};\\\", \\\"{x:1280,y:822,t:1527271797458};\\\", \\\"{x:1280,y:820,t:1527271797474};\\\", \\\"{x:1280,y:818,t:1527271797490};\\\", \\\"{x:1278,y:814,t:1527271797507};\\\", \\\"{x:1277,y:810,t:1527271797525};\\\", \\\"{x:1276,y:805,t:1527271797541};\\\", \\\"{x:1274,y:799,t:1527271797557};\\\", \\\"{x:1273,y:793,t:1527271797575};\\\", \\\"{x:1273,y:786,t:1527271797591};\\\", \\\"{x:1271,y:781,t:1527271797607};\\\", \\\"{x:1271,y:777,t:1527271797625};\\\", \\\"{x:1270,y:775,t:1527271797641};\\\", \\\"{x:1270,y:771,t:1527271797658};\\\", \\\"{x:1270,y:768,t:1527271797675};\\\", \\\"{x:1270,y:765,t:1527271797692};\\\", \\\"{x:1270,y:762,t:1527271797708};\\\", \\\"{x:1272,y:758,t:1527271797725};\\\", \\\"{x:1273,y:752,t:1527271797741};\\\", \\\"{x:1274,y:748,t:1527271797758};\\\", \\\"{x:1275,y:745,t:1527271797775};\\\", \\\"{x:1275,y:743,t:1527271797791};\\\", \\\"{x:1276,y:740,t:1527271797808};\\\", \\\"{x:1277,y:739,t:1527271797825};\\\", \\\"{x:1277,y:737,t:1527271797841};\\\", \\\"{x:1278,y:734,t:1527271797858};\\\", \\\"{x:1278,y:731,t:1527271797875};\\\", \\\"{x:1280,y:729,t:1527271797891};\\\", \\\"{x:1282,y:725,t:1527271797908};\\\", \\\"{x:1285,y:720,t:1527271797925};\\\", \\\"{x:1285,y:711,t:1527271797942};\\\", \\\"{x:1285,y:705,t:1527271797959};\\\", \\\"{x:1285,y:702,t:1527271797975};\\\", \\\"{x:1285,y:699,t:1527271797992};\\\", \\\"{x:1285,y:696,t:1527271798008};\\\", \\\"{x:1285,y:691,t:1527271798025};\\\", \\\"{x:1285,y:686,t:1527271798042};\\\", \\\"{x:1285,y:682,t:1527271798058};\\\", \\\"{x:1286,y:673,t:1527271798075};\\\", \\\"{x:1288,y:665,t:1527271798091};\\\", \\\"{x:1288,y:659,t:1527271798108};\\\", \\\"{x:1288,y:651,t:1527271798125};\\\", \\\"{x:1288,y:643,t:1527271798141};\\\", \\\"{x:1290,y:637,t:1527271798158};\\\", \\\"{x:1293,y:633,t:1527271798175};\\\", \\\"{x:1293,y:627,t:1527271798192};\\\", \\\"{x:1293,y:624,t:1527271798208};\\\", \\\"{x:1293,y:620,t:1527271798225};\\\", \\\"{x:1293,y:618,t:1527271798242};\\\", \\\"{x:1295,y:614,t:1527271798258};\\\", \\\"{x:1298,y:609,t:1527271798275};\\\", \\\"{x:1302,y:602,t:1527271798292};\\\", \\\"{x:1304,y:595,t:1527271798308};\\\", \\\"{x:1304,y:589,t:1527271798325};\\\", \\\"{x:1304,y:587,t:1527271798342};\\\", \\\"{x:1304,y:585,t:1527271798358};\\\", \\\"{x:1304,y:583,t:1527271798382};\\\", \\\"{x:1304,y:582,t:1527271798392};\\\", \\\"{x:1304,y:580,t:1527271798413};\\\", \\\"{x:1303,y:580,t:1527271798486};\\\", \\\"{x:1302,y:579,t:1527271798494};\\\", \\\"{x:1299,y:577,t:1527271798509};\\\", \\\"{x:1298,y:576,t:1527271798525};\\\", \\\"{x:1297,y:575,t:1527271798542};\\\", \\\"{x:1295,y:573,t:1527271798565};\\\", \\\"{x:1293,y:573,t:1527271798677};\\\", \\\"{x:1292,y:572,t:1527271798702};\\\", \\\"{x:1291,y:572,t:1527271798709};\\\", \\\"{x:1287,y:570,t:1527271798726};\\\", \\\"{x:1285,y:570,t:1527271798789};\\\", \\\"{x:1284,y:570,t:1527271798813};\\\", \\\"{x:1277,y:569,t:1527271799526};\\\", \\\"{x:1249,y:567,t:1527271799543};\\\", \\\"{x:1225,y:567,t:1527271799559};\\\", \\\"{x:1212,y:567,t:1527271799576};\\\", \\\"{x:1191,y:575,t:1527271799593};\\\", \\\"{x:1149,y:586,t:1527271799610};\\\", \\\"{x:1088,y:603,t:1527271799626};\\\", \\\"{x:1045,y:622,t:1527271799643};\\\", \\\"{x:1015,y:635,t:1527271799659};\\\", \\\"{x:995,y:652,t:1527271799676};\\\", \\\"{x:982,y:664,t:1527271799693};\\\", \\\"{x:961,y:678,t:1527271799709};\\\", \\\"{x:941,y:688,t:1527271799726};\\\", \\\"{x:916,y:694,t:1527271799743};\\\", \\\"{x:886,y:700,t:1527271799759};\\\", \\\"{x:852,y:701,t:1527271799776};\\\", \\\"{x:790,y:703,t:1527271799792};\\\", \\\"{x:713,y:712,t:1527271799810};\\\", \\\"{x:640,y:713,t:1527271799825};\\\", \\\"{x:571,y:713,t:1527271799842};\\\", \\\"{x:525,y:708,t:1527271799859};\\\", \\\"{x:477,y:692,t:1527271799876};\\\", \\\"{x:427,y:675,t:1527271799893};\\\", \\\"{x:424,y:674,t:1527271799909};\\\", \\\"{x:423,y:673,t:1527271799932};\\\", \\\"{x:423,y:672,t:1527271799949};\\\", \\\"{x:423,y:671,t:1527271799959};\\\", \\\"{x:423,y:670,t:1527271799976};\\\", \\\"{x:424,y:670,t:1527271800004};\\\", \\\"{x:427,y:670,t:1527271800013};\\\", \\\"{x:431,y:670,t:1527271800026};\\\", \\\"{x:446,y:676,t:1527271800042};\\\", \\\"{x:454,y:683,t:1527271800059};\\\", \\\"{x:462,y:689,t:1527271800076};\\\", \\\"{x:475,y:696,t:1527271800092};\\\", \\\"{x:493,y:702,t:1527271800110};\\\", \\\"{x:503,y:704,t:1527271800127};\\\", \\\"{x:506,y:704,t:1527271800144};\\\", \\\"{x:506,y:705,t:1527271800205};\\\", \\\"{x:506,y:707,t:1527271800213};\\\", \\\"{x:507,y:709,t:1527271800226};\\\", \\\"{x:508,y:710,t:1527271800244};\\\" ] }, { \\\"rt\\\": 13512, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 760384, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -K -G \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:710,t:1527271804493};\\\", \\\"{x:517,y:709,t:1527271804508};\\\", \\\"{x:520,y:708,t:1527271804522};\\\", \\\"{x:521,y:708,t:1527271804540};\\\", \\\"{x:523,y:705,t:1527271806101};\\\", \\\"{x:529,y:703,t:1527271806113};\\\", \\\"{x:551,y:692,t:1527271806131};\\\", \\\"{x:583,y:675,t:1527271806147};\\\", \\\"{x:644,y:657,t:1527271806163};\\\", \\\"{x:765,y:599,t:1527271806182};\\\", \\\"{x:847,y:568,t:1527271806198};\\\", \\\"{x:898,y:551,t:1527271806214};\\\", \\\"{x:953,y:538,t:1527271806232};\\\", \\\"{x:993,y:531,t:1527271806248};\\\", \\\"{x:1032,y:526,t:1527271806264};\\\", \\\"{x:1062,y:523,t:1527271806282};\\\", \\\"{x:1087,y:519,t:1527271806297};\\\", \\\"{x:1115,y:514,t:1527271806314};\\\", \\\"{x:1138,y:511,t:1527271806330};\\\", \\\"{x:1153,y:508,t:1527271806347};\\\", \\\"{x:1178,y:505,t:1527271806364};\\\", \\\"{x:1194,y:505,t:1527271806382};\\\", \\\"{x:1217,y:505,t:1527271806398};\\\", \\\"{x:1245,y:505,t:1527271806415};\\\", \\\"{x:1273,y:505,t:1527271806431};\\\", \\\"{x:1309,y:506,t:1527271806447};\\\", \\\"{x:1350,y:508,t:1527271806464};\\\", \\\"{x:1389,y:512,t:1527271806480};\\\", \\\"{x:1430,y:515,t:1527271806497};\\\", \\\"{x:1463,y:516,t:1527271806515};\\\", \\\"{x:1487,y:516,t:1527271806530};\\\", \\\"{x:1506,y:516,t:1527271806548};\\\", \\\"{x:1531,y:514,t:1527271806565};\\\", \\\"{x:1544,y:511,t:1527271806581};\\\", \\\"{x:1553,y:510,t:1527271806598};\\\", \\\"{x:1557,y:509,t:1527271806615};\\\", \\\"{x:1559,y:509,t:1527271806677};\\\", \\\"{x:1561,y:508,t:1527271806685};\\\", \\\"{x:1564,y:507,t:1527271806698};\\\", \\\"{x:1568,y:506,t:1527271806715};\\\", \\\"{x:1569,y:505,t:1527271806731};\\\", \\\"{x:1570,y:505,t:1527271806748};\\\", \\\"{x:1571,y:503,t:1527271806765};\\\", \\\"{x:1573,y:500,t:1527271806781};\\\", \\\"{x:1573,y:499,t:1527271806798};\\\", \\\"{x:1574,y:497,t:1527271806814};\\\", \\\"{x:1576,y:495,t:1527271806830};\\\", \\\"{x:1577,y:493,t:1527271806848};\\\", \\\"{x:1579,y:493,t:1527271806865};\\\", \\\"{x:1581,y:492,t:1527271806881};\\\", \\\"{x:1583,y:489,t:1527271806898};\\\", \\\"{x:1583,y:485,t:1527271806915};\\\", \\\"{x:1586,y:478,t:1527271806931};\\\", \\\"{x:1588,y:475,t:1527271806949};\\\", \\\"{x:1592,y:471,t:1527271806965};\\\", \\\"{x:1594,y:468,t:1527271806981};\\\", \\\"{x:1594,y:467,t:1527271806998};\\\", \\\"{x:1594,y:465,t:1527271807014};\\\", \\\"{x:1595,y:463,t:1527271807031};\\\", \\\"{x:1597,y:462,t:1527271807048};\\\", \\\"{x:1598,y:458,t:1527271807064};\\\", \\\"{x:1598,y:456,t:1527271807081};\\\", \\\"{x:1600,y:453,t:1527271807098};\\\", \\\"{x:1602,y:451,t:1527271807114};\\\", \\\"{x:1605,y:446,t:1527271807131};\\\", \\\"{x:1606,y:444,t:1527271807149};\\\", \\\"{x:1606,y:442,t:1527271807164};\\\", \\\"{x:1608,y:438,t:1527271807180};\\\", \\\"{x:1608,y:435,t:1527271807198};\\\", \\\"{x:1609,y:434,t:1527271807214};\\\", \\\"{x:1610,y:432,t:1527271807233};\\\", \\\"{x:1611,y:431,t:1527271807247};\\\", \\\"{x:1612,y:430,t:1527271807263};\\\", \\\"{x:1613,y:431,t:1527271807549};\\\", \\\"{x:1615,y:438,t:1527271807565};\\\", \\\"{x:1620,y:448,t:1527271807581};\\\", \\\"{x:1620,y:452,t:1527271807598};\\\", \\\"{x:1620,y:455,t:1527271807614};\\\", \\\"{x:1620,y:459,t:1527271807631};\\\", \\\"{x:1620,y:464,t:1527271807647};\\\", \\\"{x:1622,y:470,t:1527271807664};\\\", \\\"{x:1623,y:476,t:1527271807681};\\\", \\\"{x:1623,y:481,t:1527271807697};\\\", \\\"{x:1623,y:486,t:1527271807714};\\\", \\\"{x:1623,y:491,t:1527271807731};\\\", \\\"{x:1623,y:497,t:1527271807747};\\\", \\\"{x:1622,y:502,t:1527271807764};\\\", \\\"{x:1622,y:506,t:1527271807780};\\\", \\\"{x:1622,y:507,t:1527271807797};\\\", \\\"{x:1622,y:508,t:1527271807814};\\\", \\\"{x:1622,y:510,t:1527271807831};\\\", \\\"{x:1622,y:512,t:1527271807847};\\\", \\\"{x:1622,y:515,t:1527271807864};\\\", \\\"{x:1622,y:519,t:1527271807881};\\\", \\\"{x:1622,y:525,t:1527271807897};\\\", \\\"{x:1622,y:531,t:1527271807914};\\\", \\\"{x:1622,y:537,t:1527271807931};\\\", \\\"{x:1622,y:544,t:1527271807947};\\\", \\\"{x:1622,y:549,t:1527271807964};\\\", \\\"{x:1622,y:557,t:1527271807981};\\\", \\\"{x:1622,y:563,t:1527271807997};\\\", \\\"{x:1622,y:567,t:1527271808014};\\\", \\\"{x:1622,y:569,t:1527271808030};\\\", \\\"{x:1622,y:573,t:1527271808047};\\\", \\\"{x:1622,y:577,t:1527271808064};\\\", \\\"{x:1622,y:581,t:1527271808081};\\\", \\\"{x:1622,y:589,t:1527271808097};\\\", \\\"{x:1622,y:596,t:1527271808114};\\\", \\\"{x:1622,y:599,t:1527271808131};\\\", \\\"{x:1622,y:603,t:1527271808148};\\\", \\\"{x:1622,y:605,t:1527271808164};\\\", \\\"{x:1621,y:607,t:1527271808181};\\\", \\\"{x:1618,y:611,t:1527271808197};\\\", \\\"{x:1613,y:615,t:1527271808214};\\\", \\\"{x:1596,y:622,t:1527271808230};\\\", \\\"{x:1564,y:625,t:1527271808247};\\\", \\\"{x:1520,y:630,t:1527271808264};\\\", \\\"{x:1496,y:639,t:1527271808281};\\\", \\\"{x:1454,y:646,t:1527271808297};\\\", \\\"{x:1360,y:646,t:1527271808314};\\\", \\\"{x:1215,y:638,t:1527271808330};\\\", \\\"{x:1103,y:632,t:1527271808348};\\\", \\\"{x:1072,y:633,t:1527271808364};\\\", \\\"{x:1052,y:639,t:1527271808380};\\\", \\\"{x:1014,y:639,t:1527271808397};\\\", \\\"{x:962,y:635,t:1527271808414};\\\", \\\"{x:890,y:626,t:1527271808430};\\\", \\\"{x:841,y:618,t:1527271808447};\\\", \\\"{x:808,y:613,t:1527271808464};\\\", \\\"{x:779,y:613,t:1527271808480};\\\", \\\"{x:751,y:613,t:1527271808497};\\\", \\\"{x:705,y:606,t:1527271808515};\\\", \\\"{x:647,y:600,t:1527271808530};\\\", \\\"{x:620,y:597,t:1527271808547};\\\", \\\"{x:598,y:597,t:1527271808566};\\\", \\\"{x:576,y:593,t:1527271808583};\\\", \\\"{x:554,y:590,t:1527271808599};\\\", \\\"{x:541,y:587,t:1527271808616};\\\", \\\"{x:533,y:586,t:1527271808632};\\\", \\\"{x:519,y:581,t:1527271808649};\\\", \\\"{x:503,y:580,t:1527271808666};\\\", \\\"{x:482,y:578,t:1527271808682};\\\", \\\"{x:472,y:577,t:1527271808700};\\\", \\\"{x:460,y:576,t:1527271808716};\\\", \\\"{x:457,y:575,t:1527271808733};\\\", \\\"{x:455,y:575,t:1527271808749};\\\", \\\"{x:454,y:575,t:1527271808767};\\\", \\\"{x:450,y:575,t:1527271808813};\\\", \\\"{x:449,y:574,t:1527271808822};\\\", \\\"{x:447,y:574,t:1527271808832};\\\", \\\"{x:446,y:574,t:1527271808849};\\\", \\\"{x:444,y:574,t:1527271808908};\\\", \\\"{x:443,y:574,t:1527271808932};\\\", \\\"{x:441,y:574,t:1527271808948};\\\", \\\"{x:440,y:574,t:1527271808972};\\\", \\\"{x:439,y:575,t:1527271808997};\\\", \\\"{x:438,y:576,t:1527271809020};\\\", \\\"{x:437,y:576,t:1527271809037};\\\", \\\"{x:436,y:577,t:1527271809052};\\\", \\\"{x:435,y:577,t:1527271809067};\\\", \\\"{x:434,y:577,t:1527271809084};\\\", \\\"{x:438,y:580,t:1527271809099};\\\", \\\"{x:456,y:581,t:1527271809116};\\\", \\\"{x:457,y:581,t:1527271809461};\\\", \\\"{x:458,y:581,t:1527271809468};\\\", \\\"{x:460,y:581,t:1527271809517};\\\", \\\"{x:464,y:580,t:1527271809534};\\\", \\\"{x:471,y:580,t:1527271809551};\\\", \\\"{x:482,y:580,t:1527271809567};\\\", \\\"{x:499,y:580,t:1527271809584};\\\", \\\"{x:519,y:580,t:1527271809601};\\\", \\\"{x:542,y:580,t:1527271809618};\\\", \\\"{x:569,y:580,t:1527271809634};\\\", \\\"{x:592,y:580,t:1527271809651};\\\", \\\"{x:613,y:580,t:1527271809668};\\\", \\\"{x:632,y:581,t:1527271809684};\\\", \\\"{x:655,y:585,t:1527271809701};\\\", \\\"{x:663,y:586,t:1527271809717};\\\", \\\"{x:666,y:587,t:1527271809733};\\\", \\\"{x:667,y:587,t:1527271809750};\\\", \\\"{x:662,y:587,t:1527271809820};\\\", \\\"{x:653,y:587,t:1527271809834};\\\", \\\"{x:635,y:585,t:1527271809850};\\\", \\\"{x:603,y:584,t:1527271809868};\\\", \\\"{x:568,y:584,t:1527271809883};\\\", \\\"{x:523,y:584,t:1527271809900};\\\", \\\"{x:494,y:584,t:1527271809919};\\\", \\\"{x:466,y:584,t:1527271809934};\\\", \\\"{x:438,y:584,t:1527271809951};\\\", \\\"{x:415,y:584,t:1527271809967};\\\", \\\"{x:393,y:584,t:1527271809984};\\\", \\\"{x:369,y:584,t:1527271810001};\\\", \\\"{x:350,y:584,t:1527271810017};\\\", \\\"{x:337,y:584,t:1527271810034};\\\", \\\"{x:329,y:584,t:1527271810051};\\\", \\\"{x:320,y:585,t:1527271810066};\\\", \\\"{x:315,y:585,t:1527271810083};\\\", \\\"{x:309,y:587,t:1527271810100};\\\", \\\"{x:303,y:591,t:1527271810117};\\\", \\\"{x:296,y:594,t:1527271810134};\\\", \\\"{x:285,y:599,t:1527271810150};\\\", \\\"{x:268,y:605,t:1527271810170};\\\", \\\"{x:251,y:609,t:1527271810183};\\\", \\\"{x:243,y:613,t:1527271810201};\\\", \\\"{x:239,y:614,t:1527271810218};\\\", \\\"{x:233,y:615,t:1527271810234};\\\", \\\"{x:222,y:615,t:1527271810251};\\\", \\\"{x:209,y:618,t:1527271810267};\\\", \\\"{x:196,y:619,t:1527271810284};\\\", \\\"{x:190,y:619,t:1527271810301};\\\", \\\"{x:183,y:619,t:1527271810317};\\\", \\\"{x:175,y:619,t:1527271810334};\\\", \\\"{x:172,y:619,t:1527271810350};\\\", \\\"{x:171,y:619,t:1527271810372};\\\", \\\"{x:171,y:620,t:1527271810386};\\\", \\\"{x:170,y:621,t:1527271810404};\\\", \\\"{x:169,y:621,t:1527271810417};\\\", \\\"{x:168,y:622,t:1527271810435};\\\", \\\"{x:165,y:624,t:1527271810451};\\\", \\\"{x:164,y:625,t:1527271810467};\\\", \\\"{x:162,y:627,t:1527271810485};\\\", \\\"{x:161,y:628,t:1527271810508};\\\", \\\"{x:160,y:628,t:1527271810565};\\\", \\\"{x:162,y:628,t:1527271810917};\\\", \\\"{x:167,y:628,t:1527271810924};\\\", \\\"{x:176,y:629,t:1527271810935};\\\", \\\"{x:203,y:635,t:1527271810953};\\\", \\\"{x:299,y:656,t:1527271810969};\\\", \\\"{x:434,y:675,t:1527271810985};\\\", \\\"{x:604,y:684,t:1527271811001};\\\", \\\"{x:809,y:686,t:1527271811018};\\\", \\\"{x:1016,y:689,t:1527271811035};\\\", \\\"{x:1216,y:698,t:1527271811051};\\\", \\\"{x:1487,y:698,t:1527271811068};\\\", \\\"{x:1618,y:695,t:1527271811085};\\\", \\\"{x:1724,y:689,t:1527271811102};\\\", \\\"{x:1793,y:680,t:1527271811119};\\\", \\\"{x:1824,y:675,t:1527271811135};\\\", \\\"{x:1828,y:674,t:1527271811153};\\\", \\\"{x:1829,y:674,t:1527271811173};\\\", \\\"{x:1829,y:673,t:1527271811185};\\\", \\\"{x:1828,y:673,t:1527271811202};\\\", \\\"{x:1828,y:672,t:1527271811229};\\\", \\\"{x:1828,y:669,t:1527271811236};\\\", \\\"{x:1827,y:664,t:1527271811252};\\\", \\\"{x:1809,y:647,t:1527271811269};\\\", \\\"{x:1780,y:630,t:1527271811285};\\\", \\\"{x:1738,y:609,t:1527271811301};\\\", \\\"{x:1715,y:598,t:1527271811319};\\\", \\\"{x:1696,y:593,t:1527271811336};\\\", \\\"{x:1686,y:591,t:1527271811353};\\\", \\\"{x:1682,y:590,t:1527271811369};\\\", \\\"{x:1681,y:590,t:1527271811386};\\\", \\\"{x:1681,y:589,t:1527271811518};\\\", \\\"{x:1678,y:586,t:1527271811524};\\\", \\\"{x:1675,y:585,t:1527271811536};\\\", \\\"{x:1667,y:583,t:1527271811553};\\\", \\\"{x:1655,y:579,t:1527271811569};\\\", \\\"{x:1641,y:575,t:1527271811586};\\\", \\\"{x:1631,y:573,t:1527271811602};\\\", \\\"{x:1630,y:573,t:1527271811620};\\\", \\\"{x:1629,y:573,t:1527271811686};\\\", \\\"{x:1629,y:574,t:1527271811741};\\\", \\\"{x:1629,y:575,t:1527271811754};\\\", \\\"{x:1629,y:579,t:1527271811769};\\\", \\\"{x:1629,y:584,t:1527271811786};\\\", \\\"{x:1628,y:589,t:1527271811803};\\\", \\\"{x:1628,y:597,t:1527271811819};\\\", \\\"{x:1628,y:617,t:1527271811836};\\\", \\\"{x:1628,y:635,t:1527271811852};\\\", \\\"{x:1630,y:654,t:1527271811869};\\\", \\\"{x:1634,y:669,t:1527271811886};\\\", \\\"{x:1639,y:686,t:1527271811903};\\\", \\\"{x:1646,y:708,t:1527271811919};\\\", \\\"{x:1656,y:732,t:1527271811936};\\\", \\\"{x:1663,y:754,t:1527271811954};\\\", \\\"{x:1665,y:763,t:1527271811969};\\\", \\\"{x:1666,y:774,t:1527271811987};\\\", \\\"{x:1666,y:775,t:1527271812029};\\\", \\\"{x:1665,y:772,t:1527271812628};\\\", \\\"{x:1661,y:765,t:1527271812636};\\\", \\\"{x:1651,y:757,t:1527271812653};\\\", \\\"{x:1648,y:755,t:1527271812669};\\\", \\\"{x:1645,y:751,t:1527271812685};\\\", \\\"{x:1642,y:745,t:1527271812703};\\\", \\\"{x:1639,y:739,t:1527271812720};\\\", \\\"{x:1633,y:730,t:1527271812736};\\\", \\\"{x:1629,y:725,t:1527271812752};\\\", \\\"{x:1627,y:722,t:1527271812770};\\\", \\\"{x:1627,y:720,t:1527271812786};\\\", \\\"{x:1627,y:719,t:1527271812812};\\\", \\\"{x:1627,y:717,t:1527271812836};\\\", \\\"{x:1628,y:716,t:1527271812884};\\\", \\\"{x:1630,y:715,t:1527271812892};\\\", \\\"{x:1631,y:714,t:1527271812903};\\\", \\\"{x:1632,y:713,t:1527271812920};\\\", \\\"{x:1632,y:709,t:1527271812936};\\\", \\\"{x:1629,y:703,t:1527271812952};\\\", \\\"{x:1628,y:700,t:1527271812970};\\\", \\\"{x:1628,y:698,t:1527271812987};\\\", \\\"{x:1628,y:695,t:1527271813003};\\\", \\\"{x:1624,y:691,t:1527271813020};\\\", \\\"{x:1618,y:687,t:1527271813036};\\\", \\\"{x:1607,y:680,t:1527271813053};\\\", \\\"{x:1593,y:674,t:1527271813070};\\\", \\\"{x:1588,y:674,t:1527271813087};\\\", \\\"{x:1586,y:674,t:1527271813103};\\\", \\\"{x:1583,y:674,t:1527271813120};\\\", \\\"{x:1576,y:677,t:1527271813137};\\\", \\\"{x:1574,y:678,t:1527271813153};\\\", \\\"{x:1566,y:679,t:1527271813170};\\\", \\\"{x:1552,y:684,t:1527271813187};\\\", \\\"{x:1534,y:687,t:1527271813203};\\\", \\\"{x:1521,y:690,t:1527271813220};\\\", \\\"{x:1518,y:692,t:1527271813237};\\\", \\\"{x:1520,y:692,t:1527271813293};\\\", \\\"{x:1525,y:689,t:1527271813303};\\\", \\\"{x:1532,y:680,t:1527271813320};\\\", \\\"{x:1535,y:671,t:1527271813338};\\\", \\\"{x:1540,y:664,t:1527271813354};\\\", \\\"{x:1544,y:660,t:1527271813371};\\\", \\\"{x:1550,y:656,t:1527271813387};\\\", \\\"{x:1551,y:654,t:1527271813404};\\\", \\\"{x:1554,y:652,t:1527271813421};\\\", \\\"{x:1555,y:647,t:1527271813437};\\\", \\\"{x:1557,y:642,t:1527271813454};\\\", \\\"{x:1560,y:637,t:1527271813470};\\\", \\\"{x:1563,y:632,t:1527271813487};\\\", \\\"{x:1564,y:623,t:1527271813505};\\\", \\\"{x:1564,y:615,t:1527271813521};\\\", \\\"{x:1564,y:613,t:1527271813538};\\\", \\\"{x:1564,y:609,t:1527271813554};\\\", \\\"{x:1567,y:606,t:1527271813570};\\\", \\\"{x:1569,y:604,t:1527271813587};\\\", \\\"{x:1569,y:603,t:1527271813645};\\\", \\\"{x:1568,y:603,t:1527271813655};\\\", \\\"{x:1565,y:608,t:1527271813671};\\\", \\\"{x:1567,y:619,t:1527271813687};\\\", \\\"{x:1567,y:627,t:1527271813704};\\\", \\\"{x:1570,y:636,t:1527271813721};\\\", \\\"{x:1576,y:647,t:1527271813737};\\\", \\\"{x:1581,y:660,t:1527271813753};\\\", \\\"{x:1586,y:671,t:1527271813771};\\\", \\\"{x:1587,y:677,t:1527271813787};\\\", \\\"{x:1587,y:680,t:1527271813805};\\\", \\\"{x:1587,y:683,t:1527271813820};\\\", \\\"{x:1591,y:695,t:1527271813837};\\\", \\\"{x:1596,y:704,t:1527271813854};\\\", \\\"{x:1596,y:713,t:1527271813871};\\\", \\\"{x:1597,y:721,t:1527271813887};\\\", \\\"{x:1597,y:727,t:1527271813904};\\\", \\\"{x:1597,y:732,t:1527271813921};\\\", \\\"{x:1597,y:742,t:1527271813938};\\\", \\\"{x:1597,y:754,t:1527271813955};\\\", \\\"{x:1600,y:766,t:1527271813971};\\\", \\\"{x:1601,y:781,t:1527271813988};\\\", \\\"{x:1601,y:796,t:1527271814005};\\\", \\\"{x:1601,y:825,t:1527271814021};\\\", \\\"{x:1601,y:844,t:1527271814037};\\\", \\\"{x:1601,y:859,t:1527271814054};\\\", \\\"{x:1598,y:872,t:1527271814072};\\\", \\\"{x:1594,y:882,t:1527271814087};\\\", \\\"{x:1589,y:893,t:1527271814104};\\\", \\\"{x:1582,y:903,t:1527271814122};\\\", \\\"{x:1565,y:914,t:1527271814137};\\\", \\\"{x:1513,y:922,t:1527271814154};\\\", \\\"{x:1392,y:922,t:1527271814171};\\\", \\\"{x:1251,y:910,t:1527271814188};\\\", \\\"{x:1117,y:906,t:1527271814205};\\\", \\\"{x:1075,y:906,t:1527271814221};\\\", \\\"{x:1011,y:906,t:1527271814237};\\\", \\\"{x:908,y:890,t:1527271814255};\\\", \\\"{x:784,y:858,t:1527271814271};\\\", \\\"{x:687,y:828,t:1527271814287};\\\", \\\"{x:623,y:811,t:1527271814304};\\\", \\\"{x:600,y:803,t:1527271814321};\\\", \\\"{x:592,y:799,t:1527271814337};\\\", \\\"{x:588,y:795,t:1527271814354};\\\", \\\"{x:580,y:783,t:1527271814372};\\\", \\\"{x:566,y:768,t:1527271814387};\\\", \\\"{x:550,y:760,t:1527271814405};\\\", \\\"{x:537,y:751,t:1527271814421};\\\", \\\"{x:536,y:749,t:1527271814452};\\\", \\\"{x:535,y:746,t:1527271814461};\\\", \\\"{x:531,y:740,t:1527271814471};\\\", \\\"{x:518,y:727,t:1527271814489};\\\", \\\"{x:513,y:724,t:1527271814504};\\\", \\\"{x:513,y:722,t:1527271814540};\\\", \\\"{x:513,y:720,t:1527271814553};\\\", \\\"{x:513,y:717,t:1527271814570};\\\", \\\"{x:513,y:715,t:1527271814588};\\\", \\\"{x:513,y:714,t:1527271814603};\\\", \\\"{x:513,y:716,t:1527271814821};\\\", \\\"{x:515,y:721,t:1527271814838};\\\", \\\"{x:516,y:724,t:1527271814856};\\\", \\\"{x:516,y:725,t:1527271816061};\\\" ] }, { \\\"rt\\\": 29743, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 791456, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-C -C -12 PM-11 AM-10 AM-10 AM-C -10 AM-12 PM-Z -Z -Z -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:725,t:1527271817461};\\\", \\\"{x:504,y:728,t:1527271817477};\\\", \\\"{x:501,y:729,t:1527271817492};\\\", \\\"{x:500,y:730,t:1527271817509};\\\", \\\"{x:503,y:730,t:1527271817701};\\\", \\\"{x:510,y:727,t:1527271817710};\\\", \\\"{x:527,y:726,t:1527271817726};\\\", \\\"{x:545,y:726,t:1527271817743};\\\", \\\"{x:560,y:723,t:1527271817760};\\\", \\\"{x:576,y:720,t:1527271817779};\\\", \\\"{x:593,y:716,t:1527271817792};\\\", \\\"{x:612,y:716,t:1527271817807};\\\", \\\"{x:638,y:715,t:1527271817823};\\\", \\\"{x:668,y:714,t:1527271817841};\\\", \\\"{x:693,y:714,t:1527271817858};\\\", \\\"{x:716,y:714,t:1527271817873};\\\", \\\"{x:743,y:714,t:1527271817890};\\\", \\\"{x:784,y:714,t:1527271817907};\\\", \\\"{x:794,y:714,t:1527271817923};\\\", \\\"{x:795,y:714,t:1527271817948};\\\", \\\"{x:796,y:714,t:1527271818356};\\\", \\\"{x:799,y:714,t:1527271818373};\\\", \\\"{x:801,y:714,t:1527271818382};\\\", \\\"{x:806,y:714,t:1527271818391};\\\", \\\"{x:815,y:714,t:1527271818409};\\\", \\\"{x:824,y:717,t:1527271818425};\\\", \\\"{x:835,y:718,t:1527271818441};\\\", \\\"{x:851,y:722,t:1527271818458};\\\", \\\"{x:871,y:727,t:1527271818476};\\\", \\\"{x:893,y:732,t:1527271818492};\\\", \\\"{x:930,y:737,t:1527271818509};\\\", \\\"{x:959,y:743,t:1527271818525};\\\", \\\"{x:1003,y:752,t:1527271818542};\\\", \\\"{x:1061,y:760,t:1527271818559};\\\", \\\"{x:1114,y:766,t:1527271818577};\\\", \\\"{x:1148,y:768,t:1527271818592};\\\", \\\"{x:1175,y:768,t:1527271818608};\\\", \\\"{x:1196,y:770,t:1527271818624};\\\", \\\"{x:1222,y:772,t:1527271818642};\\\", \\\"{x:1253,y:777,t:1527271818658};\\\", \\\"{x:1277,y:780,t:1527271818675};\\\", \\\"{x:1291,y:782,t:1527271818692};\\\", \\\"{x:1291,y:783,t:1527271818812};\\\", \\\"{x:1289,y:783,t:1527271818825};\\\", \\\"{x:1285,y:784,t:1527271818843};\\\", \\\"{x:1282,y:785,t:1527271818858};\\\", \\\"{x:1278,y:788,t:1527271818875};\\\", \\\"{x:1274,y:790,t:1527271818892};\\\", \\\"{x:1273,y:791,t:1527271818908};\\\", \\\"{x:1269,y:794,t:1527271818925};\\\", \\\"{x:1266,y:795,t:1527271818942};\\\", \\\"{x:1263,y:796,t:1527271818960};\\\", \\\"{x:1261,y:798,t:1527271818975};\\\", \\\"{x:1257,y:801,t:1527271818993};\\\", \\\"{x:1256,y:802,t:1527271819010};\\\", \\\"{x:1254,y:803,t:1527271819026};\\\", \\\"{x:1249,y:805,t:1527271819042};\\\", \\\"{x:1244,y:808,t:1527271819059};\\\", \\\"{x:1239,y:811,t:1527271819076};\\\", \\\"{x:1230,y:816,t:1527271819093};\\\", \\\"{x:1227,y:818,t:1527271819109};\\\", \\\"{x:1225,y:819,t:1527271819125};\\\", \\\"{x:1222,y:820,t:1527271819142};\\\", \\\"{x:1221,y:821,t:1527271819165};\\\", \\\"{x:1220,y:821,t:1527271819188};\\\", \\\"{x:1219,y:822,t:1527271819196};\\\", \\\"{x:1217,y:823,t:1527271819229};\\\", \\\"{x:1215,y:823,t:1527271819244};\\\", \\\"{x:1213,y:825,t:1527271819263};\\\", \\\"{x:1212,y:826,t:1527271819292};\\\", \\\"{x:1211,y:827,t:1527271819324};\\\", \\\"{x:1210,y:829,t:1527271819356};\\\", \\\"{x:1211,y:831,t:1527271820101};\\\", \\\"{x:1214,y:833,t:1527271820110};\\\", \\\"{x:1218,y:836,t:1527271820127};\\\", \\\"{x:1229,y:843,t:1527271820144};\\\", \\\"{x:1247,y:855,t:1527271820161};\\\", \\\"{x:1264,y:870,t:1527271820176};\\\", \\\"{x:1277,y:885,t:1527271820194};\\\", \\\"{x:1289,y:898,t:1527271820211};\\\", \\\"{x:1302,y:908,t:1527271820226};\\\", \\\"{x:1314,y:917,t:1527271820243};\\\", \\\"{x:1328,y:926,t:1527271820260};\\\", \\\"{x:1334,y:931,t:1527271820277};\\\", \\\"{x:1344,y:941,t:1527271820294};\\\", \\\"{x:1354,y:951,t:1527271820311};\\\", \\\"{x:1359,y:958,t:1527271820326};\\\", \\\"{x:1359,y:959,t:1527271820344};\\\", \\\"{x:1359,y:960,t:1527271820477};\\\", \\\"{x:1360,y:960,t:1527271821085};\\\", \\\"{x:1360,y:962,t:1527271821182};\\\", \\\"{x:1360,y:963,t:1527271821195};\\\", \\\"{x:1360,y:964,t:1527271821211};\\\", \\\"{x:1361,y:967,t:1527271821228};\\\", \\\"{x:1362,y:967,t:1527271821269};\\\", \\\"{x:1364,y:969,t:1527271821278};\\\", \\\"{x:1365,y:971,t:1527271821294};\\\", \\\"{x:1367,y:972,t:1527271821311};\\\", \\\"{x:1368,y:973,t:1527271821328};\\\", \\\"{x:1370,y:976,t:1527271821345};\\\", \\\"{x:1373,y:979,t:1527271821362};\\\", \\\"{x:1378,y:984,t:1527271821377};\\\", \\\"{x:1387,y:990,t:1527271821394};\\\", \\\"{x:1395,y:994,t:1527271821412};\\\", \\\"{x:1397,y:996,t:1527271821429};\\\", \\\"{x:1398,y:996,t:1527271821460};\\\", \\\"{x:1402,y:999,t:1527271821479};\\\", \\\"{x:1409,y:1002,t:1527271821495};\\\", \\\"{x:1411,y:1003,t:1527271821511};\\\", \\\"{x:1412,y:1003,t:1527271821528};\\\", \\\"{x:1413,y:1004,t:1527271821582};\\\", \\\"{x:1413,y:1005,t:1527271821595};\\\", \\\"{x:1414,y:1006,t:1527271821611};\\\", \\\"{x:1416,y:1007,t:1527271821725};\\\", \\\"{x:1416,y:1008,t:1527271821732};\\\", \\\"{x:1417,y:1009,t:1527271821744};\\\", \\\"{x:1417,y:1010,t:1527271821761};\\\", \\\"{x:1417,y:1012,t:1527271821779};\\\", \\\"{x:1417,y:1013,t:1527271821795};\\\", \\\"{x:1418,y:1015,t:1527271821812};\\\", \\\"{x:1418,y:1016,t:1527271821828};\\\", \\\"{x:1419,y:1018,t:1527271821846};\\\", \\\"{x:1420,y:1019,t:1527271821862};\\\", \\\"{x:1419,y:1020,t:1527271822021};\\\", \\\"{x:1417,y:1018,t:1527271822549};\\\", \\\"{x:1415,y:1015,t:1527271822562};\\\", \\\"{x:1406,y:1009,t:1527271822579};\\\", \\\"{x:1398,y:1004,t:1527271822596};\\\", \\\"{x:1393,y:1001,t:1527271822612};\\\", \\\"{x:1392,y:1001,t:1527271822629};\\\", \\\"{x:1392,y:1000,t:1527271822645};\\\", \\\"{x:1390,y:998,t:1527271822662};\\\", \\\"{x:1389,y:996,t:1527271822679};\\\", \\\"{x:1386,y:992,t:1527271822696};\\\", \\\"{x:1384,y:990,t:1527271822713};\\\", \\\"{x:1384,y:989,t:1527271822730};\\\", \\\"{x:1383,y:987,t:1527271822745};\\\", \\\"{x:1383,y:986,t:1527271822763};\\\", \\\"{x:1382,y:985,t:1527271822782};\\\", \\\"{x:1382,y:984,t:1527271822812};\\\", \\\"{x:1381,y:983,t:1527271822830};\\\", \\\"{x:1381,y:981,t:1527271822869};\\\", \\\"{x:1380,y:979,t:1527271822881};\\\", \\\"{x:1378,y:977,t:1527271822896};\\\", \\\"{x:1376,y:974,t:1527271822912};\\\", \\\"{x:1375,y:969,t:1527271822930};\\\", \\\"{x:1372,y:966,t:1527271822947};\\\", \\\"{x:1370,y:964,t:1527271822963};\\\", \\\"{x:1369,y:963,t:1527271822980};\\\", \\\"{x:1368,y:961,t:1527271822997};\\\", \\\"{x:1367,y:961,t:1527271823061};\\\", \\\"{x:1365,y:961,t:1527271823125};\\\", \\\"{x:1363,y:961,t:1527271823133};\\\", \\\"{x:1360,y:961,t:1527271823146};\\\", \\\"{x:1353,y:961,t:1527271823162};\\\", \\\"{x:1348,y:961,t:1527271823180};\\\", \\\"{x:1344,y:961,t:1527271823196};\\\", \\\"{x:1342,y:962,t:1527271823213};\\\", \\\"{x:1339,y:962,t:1527271823230};\\\", \\\"{x:1335,y:964,t:1527271823247};\\\", \\\"{x:1333,y:964,t:1527271823263};\\\", \\\"{x:1331,y:965,t:1527271823279};\\\", \\\"{x:1329,y:965,t:1527271823397};\\\", \\\"{x:1327,y:966,t:1527271823414};\\\", \\\"{x:1326,y:968,t:1527271823429};\\\", \\\"{x:1321,y:969,t:1527271823447};\\\", \\\"{x:1319,y:970,t:1527271823464};\\\", \\\"{x:1314,y:972,t:1527271823480};\\\", \\\"{x:1310,y:972,t:1527271823497};\\\", \\\"{x:1305,y:973,t:1527271823513};\\\", \\\"{x:1299,y:973,t:1527271823530};\\\", \\\"{x:1296,y:973,t:1527271823546};\\\", \\\"{x:1293,y:973,t:1527271823564};\\\", \\\"{x:1290,y:973,t:1527271823582};\\\", \\\"{x:1286,y:973,t:1527271823597};\\\", \\\"{x:1279,y:973,t:1527271823614};\\\", \\\"{x:1274,y:974,t:1527271823631};\\\", \\\"{x:1269,y:975,t:1527271823646};\\\", \\\"{x:1267,y:975,t:1527271823663};\\\", \\\"{x:1266,y:976,t:1527271823683};\\\", \\\"{x:1265,y:976,t:1527271823700};\\\", \\\"{x:1263,y:976,t:1527271823713};\\\", \\\"{x:1261,y:976,t:1527271823730};\\\", \\\"{x:1257,y:976,t:1527271823746};\\\", \\\"{x:1256,y:976,t:1527271823763};\\\", \\\"{x:1254,y:976,t:1527271823780};\\\", \\\"{x:1250,y:976,t:1527271823796};\\\", \\\"{x:1246,y:976,t:1527271823813};\\\", \\\"{x:1240,y:976,t:1527271823830};\\\", \\\"{x:1236,y:976,t:1527271823846};\\\", \\\"{x:1234,y:976,t:1527271823864};\\\", \\\"{x:1232,y:976,t:1527271823881};\\\", \\\"{x:1231,y:976,t:1527271823897};\\\", \\\"{x:1227,y:976,t:1527271823913};\\\", \\\"{x:1226,y:976,t:1527271823930};\\\", \\\"{x:1223,y:976,t:1527271824109};\\\", \\\"{x:1222,y:975,t:1527271824117};\\\", \\\"{x:1221,y:974,t:1527271824131};\\\", \\\"{x:1221,y:972,t:1527271824148};\\\", \\\"{x:1221,y:971,t:1527271824172};\\\", \\\"{x:1220,y:970,t:1527271829701};\\\", \\\"{x:1218,y:968,t:1527271829870};\\\", \\\"{x:1218,y:967,t:1527271829886};\\\", \\\"{x:1217,y:967,t:1527271829903};\\\", \\\"{x:1216,y:967,t:1527271830277};\\\", \\\"{x:1214,y:967,t:1527271830301};\\\", \\\"{x:1213,y:967,t:1527271830317};\\\", \\\"{x:1212,y:967,t:1527271830325};\\\", \\\"{x:1212,y:966,t:1527271830337};\\\", \\\"{x:1210,y:965,t:1527271830354};\\\", \\\"{x:1207,y:964,t:1527271830370};\\\", \\\"{x:1206,y:964,t:1527271830388};\\\", \\\"{x:1204,y:962,t:1527271830405};\\\", \\\"{x:1203,y:961,t:1527271830420};\\\", \\\"{x:1200,y:958,t:1527271830437};\\\", \\\"{x:1199,y:955,t:1527271830454};\\\", \\\"{x:1199,y:953,t:1527271830469};\\\", \\\"{x:1199,y:949,t:1527271830487};\\\", \\\"{x:1199,y:946,t:1527271830503};\\\", \\\"{x:1199,y:940,t:1527271830520};\\\", \\\"{x:1201,y:933,t:1527271830537};\\\", \\\"{x:1202,y:928,t:1527271830554};\\\", \\\"{x:1202,y:923,t:1527271830569};\\\", \\\"{x:1202,y:919,t:1527271830587};\\\", \\\"{x:1202,y:915,t:1527271830604};\\\", \\\"{x:1202,y:912,t:1527271830620};\\\", \\\"{x:1200,y:906,t:1527271830637};\\\", \\\"{x:1199,y:903,t:1527271830653};\\\", \\\"{x:1198,y:900,t:1527271830671};\\\", \\\"{x:1198,y:898,t:1527271830687};\\\", \\\"{x:1198,y:897,t:1527271830704};\\\", \\\"{x:1198,y:896,t:1527271830748};\\\", \\\"{x:1198,y:895,t:1527271830757};\\\", \\\"{x:1200,y:894,t:1527271830771};\\\", \\\"{x:1202,y:892,t:1527271830787};\\\", \\\"{x:1204,y:890,t:1527271830804};\\\", \\\"{x:1204,y:884,t:1527271830820};\\\", \\\"{x:1204,y:881,t:1527271830837};\\\", \\\"{x:1205,y:878,t:1527271830854};\\\", \\\"{x:1206,y:873,t:1527271830871};\\\", \\\"{x:1207,y:870,t:1527271830887};\\\", \\\"{x:1208,y:868,t:1527271830904};\\\", \\\"{x:1208,y:866,t:1527271830921};\\\", \\\"{x:1208,y:864,t:1527271830937};\\\", \\\"{x:1208,y:863,t:1527271830954};\\\", \\\"{x:1208,y:861,t:1527271830971};\\\", \\\"{x:1208,y:860,t:1527271830988};\\\", \\\"{x:1210,y:858,t:1527271831004};\\\", \\\"{x:1210,y:856,t:1527271831021};\\\", \\\"{x:1210,y:855,t:1527271831045};\\\", \\\"{x:1210,y:854,t:1527271831054};\\\", \\\"{x:1210,y:853,t:1527271831071};\\\", \\\"{x:1210,y:852,t:1527271831092};\\\", \\\"{x:1210,y:851,t:1527271831108};\\\", \\\"{x:1210,y:850,t:1527271831132};\\\", \\\"{x:1210,y:848,t:1527271831156};\\\", \\\"{x:1209,y:847,t:1527271831172};\\\", \\\"{x:1208,y:845,t:1527271831189};\\\", \\\"{x:1207,y:844,t:1527271831205};\\\", \\\"{x:1206,y:843,t:1527271831221};\\\", \\\"{x:1205,y:843,t:1527271831612};\\\", \\\"{x:1203,y:843,t:1527271831621};\\\", \\\"{x:1201,y:843,t:1527271831638};\\\", \\\"{x:1199,y:844,t:1527271831655};\\\", \\\"{x:1198,y:846,t:1527271831877};\\\", \\\"{x:1198,y:853,t:1527271831888};\\\", \\\"{x:1203,y:870,t:1527271831905};\\\", \\\"{x:1206,y:884,t:1527271831922};\\\", \\\"{x:1209,y:897,t:1527271831938};\\\", \\\"{x:1210,y:907,t:1527271831955};\\\", \\\"{x:1210,y:915,t:1527271831972};\\\", \\\"{x:1210,y:920,t:1527271831987};\\\", \\\"{x:1211,y:926,t:1527271832005};\\\", \\\"{x:1212,y:929,t:1527271832022};\\\", \\\"{x:1214,y:934,t:1527271832038};\\\", \\\"{x:1215,y:943,t:1527271832055};\\\", \\\"{x:1216,y:947,t:1527271832072};\\\", \\\"{x:1216,y:951,t:1527271832089};\\\", \\\"{x:1216,y:953,t:1527271832105};\\\", \\\"{x:1215,y:956,t:1527271832122};\\\", \\\"{x:1215,y:957,t:1527271832139};\\\", \\\"{x:1215,y:959,t:1527271832155};\\\", \\\"{x:1213,y:962,t:1527271832172};\\\", \\\"{x:1213,y:965,t:1527271832188};\\\", \\\"{x:1213,y:966,t:1527271832205};\\\", \\\"{x:1213,y:969,t:1527271832222};\\\", \\\"{x:1214,y:970,t:1527271832239};\\\", \\\"{x:1214,y:971,t:1527271832260};\\\", \\\"{x:1214,y:970,t:1527271832717};\\\", \\\"{x:1214,y:969,t:1527271832724};\\\", \\\"{x:1214,y:967,t:1527271832741};\\\", \\\"{x:1216,y:964,t:1527271832756};\\\", \\\"{x:1216,y:962,t:1527271832774};\\\", \\\"{x:1216,y:961,t:1527271832797};\\\", \\\"{x:1216,y:960,t:1527271835080};\\\", \\\"{x:1216,y:956,t:1527271835094};\\\", \\\"{x:1218,y:937,t:1527271835112};\\\", \\\"{x:1221,y:930,t:1527271835128};\\\", \\\"{x:1221,y:925,t:1527271835144};\\\", \\\"{x:1221,y:921,t:1527271835161};\\\", \\\"{x:1221,y:918,t:1527271835178};\\\", \\\"{x:1221,y:917,t:1527271835194};\\\", \\\"{x:1221,y:914,t:1527271835211};\\\", \\\"{x:1221,y:911,t:1527271835228};\\\", \\\"{x:1221,y:908,t:1527271835244};\\\", \\\"{x:1221,y:905,t:1527271835261};\\\", \\\"{x:1221,y:902,t:1527271835278};\\\", \\\"{x:1222,y:897,t:1527271835295};\\\", \\\"{x:1223,y:894,t:1527271835311};\\\", \\\"{x:1223,y:891,t:1527271835328};\\\", \\\"{x:1224,y:890,t:1527271835345};\\\", \\\"{x:1224,y:888,t:1527271835361};\\\", \\\"{x:1224,y:887,t:1527271835378};\\\", \\\"{x:1224,y:884,t:1527271835395};\\\", \\\"{x:1224,y:879,t:1527271835411};\\\", \\\"{x:1224,y:876,t:1527271835428};\\\", \\\"{x:1225,y:871,t:1527271835445};\\\", \\\"{x:1225,y:867,t:1527271835461};\\\", \\\"{x:1225,y:866,t:1527271835478};\\\", \\\"{x:1225,y:864,t:1527271835496};\\\", \\\"{x:1225,y:862,t:1527271835511};\\\", \\\"{x:1225,y:861,t:1527271835583};\\\", \\\"{x:1225,y:860,t:1527271835594};\\\", \\\"{x:1225,y:858,t:1527271835612};\\\", \\\"{x:1225,y:857,t:1527271835628};\\\", \\\"{x:1225,y:856,t:1527271835645};\\\", \\\"{x:1225,y:854,t:1527271835662};\\\", \\\"{x:1225,y:851,t:1527271835678};\\\", \\\"{x:1224,y:848,t:1527271835695};\\\", \\\"{x:1223,y:845,t:1527271835712};\\\", \\\"{x:1223,y:844,t:1527271835728};\\\", \\\"{x:1221,y:842,t:1527271835745};\\\", \\\"{x:1221,y:840,t:1527271835808};\\\", \\\"{x:1221,y:838,t:1527271835823};\\\", \\\"{x:1221,y:837,t:1527271835832};\\\", \\\"{x:1221,y:835,t:1527271835846};\\\", \\\"{x:1222,y:832,t:1527271835862};\\\", \\\"{x:1222,y:830,t:1527271835878};\\\", \\\"{x:1222,y:826,t:1527271835895};\\\", \\\"{x:1222,y:825,t:1527271835913};\\\", \\\"{x:1222,y:824,t:1527271835929};\\\", \\\"{x:1222,y:823,t:1527271836080};\\\", \\\"{x:1221,y:823,t:1527271836104};\\\", \\\"{x:1220,y:823,t:1527271836112};\\\", \\\"{x:1217,y:827,t:1527271836130};\\\", \\\"{x:1216,y:836,t:1527271836146};\\\", \\\"{x:1214,y:842,t:1527271836162};\\\", \\\"{x:1213,y:851,t:1527271836179};\\\", \\\"{x:1212,y:857,t:1527271836195};\\\", \\\"{x:1211,y:862,t:1527271836213};\\\", \\\"{x:1211,y:866,t:1527271836229};\\\", \\\"{x:1211,y:871,t:1527271836245};\\\", \\\"{x:1211,y:873,t:1527271836262};\\\", \\\"{x:1211,y:880,t:1527271836280};\\\", \\\"{x:1211,y:888,t:1527271836295};\\\", \\\"{x:1211,y:895,t:1527271836312};\\\", \\\"{x:1213,y:902,t:1527271836329};\\\", \\\"{x:1213,y:904,t:1527271836346};\\\", \\\"{x:1213,y:908,t:1527271836363};\\\", \\\"{x:1214,y:913,t:1527271836379};\\\", \\\"{x:1215,y:918,t:1527271836396};\\\", \\\"{x:1219,y:926,t:1527271836412};\\\", \\\"{x:1223,y:933,t:1527271836429};\\\", \\\"{x:1225,y:937,t:1527271836445};\\\", \\\"{x:1226,y:939,t:1527271836461};\\\", \\\"{x:1226,y:941,t:1527271836478};\\\", \\\"{x:1227,y:942,t:1527271836495};\\\", \\\"{x:1227,y:945,t:1527271836512};\\\", \\\"{x:1229,y:950,t:1527271836529};\\\", \\\"{x:1230,y:954,t:1527271836545};\\\", \\\"{x:1230,y:956,t:1527271836562};\\\", \\\"{x:1230,y:959,t:1527271836578};\\\", \\\"{x:1230,y:960,t:1527271836596};\\\", \\\"{x:1230,y:962,t:1527271836615};\\\", \\\"{x:1231,y:963,t:1527271836631};\\\", \\\"{x:1231,y:964,t:1527271836785};\\\", \\\"{x:1231,y:966,t:1527271836797};\\\", \\\"{x:1231,y:970,t:1527271836813};\\\", \\\"{x:1230,y:970,t:1527271836830};\\\", \\\"{x:1229,y:972,t:1527271836846};\\\", \\\"{x:1228,y:976,t:1527271836864};\\\", \\\"{x:1227,y:977,t:1527271836887};\\\", \\\"{x:1227,y:978,t:1527271836919};\\\", \\\"{x:1227,y:976,t:1527271837063};\\\", \\\"{x:1237,y:971,t:1527271837080};\\\", \\\"{x:1244,y:967,t:1527271837096};\\\", \\\"{x:1250,y:961,t:1527271837113};\\\", \\\"{x:1255,y:955,t:1527271837130};\\\", \\\"{x:1259,y:952,t:1527271837146};\\\", \\\"{x:1263,y:950,t:1527271837163};\\\", \\\"{x:1266,y:949,t:1527271837180};\\\", \\\"{x:1269,y:947,t:1527271837196};\\\", \\\"{x:1271,y:946,t:1527271837214};\\\", \\\"{x:1272,y:945,t:1527271837240};\\\", \\\"{x:1274,y:945,t:1527271837248};\\\", \\\"{x:1280,y:943,t:1527271837263};\\\", \\\"{x:1287,y:942,t:1527271837280};\\\", \\\"{x:1291,y:941,t:1527271837296};\\\", \\\"{x:1294,y:940,t:1527271837352};\\\", \\\"{x:1295,y:939,t:1527271837364};\\\", \\\"{x:1299,y:938,t:1527271837380};\\\", \\\"{x:1302,y:938,t:1527271837397};\\\", \\\"{x:1303,y:938,t:1527271837413};\\\", \\\"{x:1305,y:938,t:1527271837472};\\\", \\\"{x:1308,y:938,t:1527271837480};\\\", \\\"{x:1314,y:938,t:1527271837497};\\\", \\\"{x:1317,y:939,t:1527271837513};\\\", \\\"{x:1318,y:939,t:1527271837530};\\\", \\\"{x:1319,y:940,t:1527271837568};\\\", \\\"{x:1320,y:940,t:1527271837580};\\\", \\\"{x:1323,y:943,t:1527271837597};\\\", \\\"{x:1330,y:947,t:1527271837613};\\\", \\\"{x:1335,y:950,t:1527271837630};\\\", \\\"{x:1336,y:951,t:1527271837679};\\\", \\\"{x:1338,y:953,t:1527271837697};\\\", \\\"{x:1339,y:954,t:1527271837713};\\\", \\\"{x:1340,y:955,t:1527271837800};\\\", \\\"{x:1341,y:957,t:1527271837815};\\\", \\\"{x:1342,y:959,t:1527271837830};\\\", \\\"{x:1344,y:964,t:1527271837847};\\\", \\\"{x:1345,y:966,t:1527271837864};\\\", \\\"{x:1345,y:967,t:1527271837895};\\\", \\\"{x:1346,y:967,t:1527271837920};\\\", \\\"{x:1347,y:969,t:1527271837952};\\\", \\\"{x:1348,y:970,t:1527271837975};\\\", \\\"{x:1348,y:972,t:1527271838023};\\\", \\\"{x:1348,y:970,t:1527271840055};\\\", \\\"{x:1348,y:969,t:1527271840066};\\\", \\\"{x:1348,y:962,t:1527271840082};\\\", \\\"{x:1349,y:954,t:1527271840100};\\\", \\\"{x:1352,y:945,t:1527271840116};\\\", \\\"{x:1353,y:937,t:1527271840133};\\\", \\\"{x:1353,y:931,t:1527271840150};\\\", \\\"{x:1355,y:925,t:1527271840166};\\\", \\\"{x:1356,y:915,t:1527271840185};\\\", \\\"{x:1356,y:909,t:1527271840200};\\\", \\\"{x:1356,y:905,t:1527271840216};\\\", \\\"{x:1356,y:901,t:1527271840233};\\\", \\\"{x:1356,y:898,t:1527271840249};\\\", \\\"{x:1356,y:897,t:1527271840267};\\\", \\\"{x:1355,y:895,t:1527271840560};\\\", \\\"{x:1355,y:894,t:1527271840567};\\\", \\\"{x:1354,y:894,t:1527271840664};\\\", \\\"{x:1353,y:894,t:1527271840672};\\\", \\\"{x:1352,y:894,t:1527271840683};\\\", \\\"{x:1351,y:891,t:1527271840839};\\\", \\\"{x:1350,y:889,t:1527271840850};\\\", \\\"{x:1350,y:888,t:1527271840866};\\\", \\\"{x:1349,y:887,t:1527271840882};\\\", \\\"{x:1349,y:886,t:1527271840900};\\\", \\\"{x:1349,y:885,t:1527271840915};\\\", \\\"{x:1349,y:884,t:1527271840933};\\\", \\\"{x:1349,y:883,t:1527271840949};\\\", \\\"{x:1349,y:881,t:1527271840966};\\\", \\\"{x:1349,y:880,t:1527271840984};\\\", \\\"{x:1349,y:879,t:1527271841064};\\\", \\\"{x:1349,y:878,t:1527271841071};\\\", \\\"{x:1348,y:876,t:1527271841176};\\\", \\\"{x:1348,y:875,t:1527271841198};\\\", \\\"{x:1348,y:873,t:1527271841239};\\\", \\\"{x:1347,y:873,t:1527271841304};\\\", \\\"{x:1347,y:874,t:1527271841487};\\\", \\\"{x:1347,y:876,t:1527271841501};\\\", \\\"{x:1347,y:879,t:1527271841518};\\\", \\\"{x:1347,y:882,t:1527271841535};\\\", \\\"{x:1347,y:885,t:1527271841550};\\\", \\\"{x:1347,y:888,t:1527271841568};\\\", \\\"{x:1347,y:889,t:1527271841751};\\\", \\\"{x:1347,y:890,t:1527271841767};\\\", \\\"{x:1347,y:891,t:1527271841792};\\\", \\\"{x:1347,y:892,t:1527271842432};\\\", \\\"{x:1347,y:893,t:1527271842463};\\\", \\\"{x:1346,y:895,t:1527271842487};\\\", \\\"{x:1346,y:896,t:1527271842544};\\\", \\\"{x:1345,y:897,t:1527271842623};\\\", \\\"{x:1345,y:896,t:1527271843063};\\\", \\\"{x:1345,y:892,t:1527271843071};\\\", \\\"{x:1345,y:890,t:1527271843088};\\\", \\\"{x:1345,y:888,t:1527271843102};\\\", \\\"{x:1345,y:883,t:1527271843119};\\\", \\\"{x:1345,y:881,t:1527271843135};\\\", \\\"{x:1345,y:879,t:1527271843152};\\\", \\\"{x:1345,y:877,t:1527271843170};\\\", \\\"{x:1345,y:876,t:1527271843186};\\\", \\\"{x:1345,y:874,t:1527271843203};\\\", \\\"{x:1345,y:871,t:1527271843219};\\\", \\\"{x:1345,y:868,t:1527271843236};\\\", \\\"{x:1344,y:865,t:1527271843253};\\\", \\\"{x:1343,y:862,t:1527271843269};\\\", \\\"{x:1343,y:858,t:1527271843285};\\\", \\\"{x:1342,y:853,t:1527271843302};\\\", \\\"{x:1341,y:846,t:1527271843319};\\\", \\\"{x:1341,y:843,t:1527271843335};\\\", \\\"{x:1341,y:842,t:1527271843352};\\\", \\\"{x:1341,y:841,t:1527271843370};\\\", \\\"{x:1341,y:840,t:1527271843391};\\\", \\\"{x:1341,y:839,t:1527271843402};\\\", \\\"{x:1341,y:838,t:1527271843419};\\\", \\\"{x:1341,y:835,t:1527271843436};\\\", \\\"{x:1342,y:833,t:1527271843453};\\\", \\\"{x:1343,y:829,t:1527271843469};\\\", \\\"{x:1344,y:826,t:1527271843487};\\\", \\\"{x:1345,y:821,t:1527271843503};\\\", \\\"{x:1345,y:819,t:1527271843519};\\\", \\\"{x:1345,y:817,t:1527271843537};\\\", \\\"{x:1343,y:812,t:1527271843553};\\\", \\\"{x:1343,y:810,t:1527271843575};\\\", \\\"{x:1343,y:809,t:1527271843586};\\\", \\\"{x:1343,y:806,t:1527271843602};\\\", \\\"{x:1343,y:804,t:1527271843620};\\\", \\\"{x:1342,y:799,t:1527271843637};\\\", \\\"{x:1340,y:796,t:1527271843652};\\\", \\\"{x:1339,y:794,t:1527271843670};\\\", \\\"{x:1339,y:791,t:1527271843687};\\\", \\\"{x:1339,y:789,t:1527271843703};\\\", \\\"{x:1339,y:785,t:1527271843720};\\\", \\\"{x:1338,y:782,t:1527271843737};\\\", \\\"{x:1336,y:781,t:1527271843753};\\\", \\\"{x:1335,y:780,t:1527271843769};\\\", \\\"{x:1332,y:777,t:1527271843787};\\\", \\\"{x:1332,y:776,t:1527271843803};\\\", \\\"{x:1332,y:772,t:1527271843820};\\\", \\\"{x:1332,y:771,t:1527271843837};\\\", \\\"{x:1332,y:768,t:1527271843854};\\\", \\\"{x:1331,y:766,t:1527271843869};\\\", \\\"{x:1331,y:763,t:1527271843887};\\\", \\\"{x:1329,y:752,t:1527271843903};\\\", \\\"{x:1329,y:748,t:1527271843920};\\\", \\\"{x:1329,y:746,t:1527271843936};\\\", \\\"{x:1329,y:743,t:1527271843953};\\\", \\\"{x:1330,y:742,t:1527271843970};\\\", \\\"{x:1331,y:741,t:1527271843987};\\\", \\\"{x:1330,y:741,t:1527271844031};\\\", \\\"{x:1323,y:741,t:1527271844040};\\\", \\\"{x:1309,y:739,t:1527271844053};\\\", \\\"{x:1272,y:734,t:1527271844069};\\\", \\\"{x:1220,y:728,t:1527271844087};\\\", \\\"{x:1081,y:716,t:1527271844103};\\\", \\\"{x:971,y:726,t:1527271844121};\\\", \\\"{x:839,y:737,t:1527271844136};\\\", \\\"{x:718,y:749,t:1527271844153};\\\", \\\"{x:622,y:755,t:1527271844170};\\\", \\\"{x:543,y:758,t:1527271844187};\\\", \\\"{x:472,y:763,t:1527271844203};\\\", \\\"{x:440,y:766,t:1527271844220};\\\", \\\"{x:429,y:766,t:1527271844236};\\\", \\\"{x:428,y:766,t:1527271844253};\\\", \\\"{x:427,y:767,t:1527271844270};\\\", \\\"{x:426,y:767,t:1527271844335};\\\", \\\"{x:426,y:764,t:1527271844353};\\\", \\\"{x:427,y:761,t:1527271844371};\\\", \\\"{x:430,y:757,t:1527271844387};\\\", \\\"{x:430,y:753,t:1527271844403};\\\", \\\"{x:430,y:746,t:1527271844420};\\\", \\\"{x:430,y:741,t:1527271844436};\\\", \\\"{x:429,y:737,t:1527271844453};\\\", \\\"{x:427,y:733,t:1527271844470};\\\", \\\"{x:426,y:729,t:1527271844486};\\\", \\\"{x:426,y:726,t:1527271844502};\\\", \\\"{x:426,y:724,t:1527271844519};\\\", \\\"{x:426,y:718,t:1527271844536};\\\", \\\"{x:425,y:715,t:1527271844552};\\\", \\\"{x:421,y:712,t:1527271844570};\\\", \\\"{x:417,y:709,t:1527271844587};\\\", \\\"{x:414,y:708,t:1527271844602};\\\", \\\"{x:411,y:707,t:1527271844619};\\\", \\\"{x:406,y:705,t:1527271844637};\\\", \\\"{x:397,y:701,t:1527271844653};\\\", \\\"{x:383,y:697,t:1527271844670};\\\", \\\"{x:343,y:688,t:1527271844687};\\\", \\\"{x:301,y:682,t:1527271844703};\\\", \\\"{x:270,y:677,t:1527271844720};\\\", \\\"{x:257,y:676,t:1527271844737};\\\", \\\"{x:255,y:675,t:1527271844753};\\\", \\\"{x:253,y:673,t:1527271844920};\\\", \\\"{x:247,y:669,t:1527271844938};\\\", \\\"{x:239,y:665,t:1527271844955};\\\", \\\"{x:229,y:659,t:1527271844970};\\\", \\\"{x:222,y:652,t:1527271844987};\\\", \\\"{x:212,y:644,t:1527271845006};\\\", \\\"{x:200,y:636,t:1527271845020};\\\", \\\"{x:185,y:625,t:1527271845037};\\\", \\\"{x:171,y:615,t:1527271845048};\\\", \\\"{x:158,y:608,t:1527271845066};\\\", \\\"{x:152,y:604,t:1527271845082};\\\", \\\"{x:152,y:601,t:1527271845099};\\\", \\\"{x:152,y:595,t:1527271845116};\\\", \\\"{x:151,y:590,t:1527271845133};\\\", \\\"{x:149,y:585,t:1527271845149};\\\", \\\"{x:149,y:582,t:1527271845166};\\\", \\\"{x:149,y:580,t:1527271845182};\\\", \\\"{x:149,y:579,t:1527271845199};\\\", \\\"{x:149,y:577,t:1527271845216};\\\", \\\"{x:150,y:574,t:1527271845233};\\\", \\\"{x:150,y:571,t:1527271845249};\\\", \\\"{x:147,y:568,t:1527271845266};\\\", \\\"{x:147,y:567,t:1527271845283};\\\", \\\"{x:147,y:566,t:1527271845343};\\\", \\\"{x:147,y:565,t:1527271845359};\\\", \\\"{x:147,y:564,t:1527271845375};\\\", \\\"{x:148,y:563,t:1527271845399};\\\", \\\"{x:149,y:563,t:1527271845417};\\\", \\\"{x:150,y:563,t:1527271845432};\\\", \\\"{x:152,y:563,t:1527271845607};\\\", \\\"{x:154,y:562,t:1527271845616};\\\", \\\"{x:162,y:560,t:1527271845633};\\\", \\\"{x:184,y:559,t:1527271845649};\\\", \\\"{x:236,y:573,t:1527271845667};\\\", \\\"{x:300,y:583,t:1527271845684};\\\", \\\"{x:356,y:592,t:1527271845700};\\\", \\\"{x:396,y:605,t:1527271845716};\\\", \\\"{x:415,y:612,t:1527271845733};\\\", \\\"{x:418,y:614,t:1527271845750};\\\", \\\"{x:422,y:616,t:1527271845766};\\\", \\\"{x:439,y:625,t:1527271845784};\\\", \\\"{x:455,y:631,t:1527271845800};\\\", \\\"{x:459,y:633,t:1527271845816};\\\", \\\"{x:459,y:634,t:1527271845833};\\\", \\\"{x:459,y:637,t:1527271845855};\\\", \\\"{x:455,y:638,t:1527271845866};\\\", \\\"{x:446,y:643,t:1527271845883};\\\", \\\"{x:440,y:647,t:1527271845899};\\\", \\\"{x:440,y:650,t:1527271845916};\\\", \\\"{x:440,y:652,t:1527271845933};\\\", \\\"{x:440,y:655,t:1527271845950};\\\", \\\"{x:439,y:666,t:1527271845966};\\\", \\\"{x:439,y:673,t:1527271845984};\\\", \\\"{x:439,y:678,t:1527271846000};\\\", \\\"{x:439,y:680,t:1527271846017};\\\", \\\"{x:439,y:681,t:1527271846033};\\\", \\\"{x:439,y:686,t:1527271846051};\\\", \\\"{x:443,y:693,t:1527271846068};\\\", \\\"{x:462,y:705,t:1527271846084};\\\", \\\"{x:477,y:711,t:1527271846099};\\\", \\\"{x:481,y:713,t:1527271846117};\\\", \\\"{x:482,y:713,t:1527271846133};\\\", \\\"{x:484,y:713,t:1527271846191};\\\", \\\"{x:488,y:713,t:1527271846200};\\\", \\\"{x:492,y:713,t:1527271846216};\\\", \\\"{x:493,y:712,t:1527271846233};\\\", \\\"{x:495,y:712,t:1527271846326};\\\", \\\"{x:495,y:712,t:1527271846399};\\\", \\\"{x:498,y:712,t:1527271846623};\\\", \\\"{x:499,y:711,t:1527271846634};\\\", \\\"{x:503,y:710,t:1527271846650};\\\", \\\"{x:505,y:710,t:1527271846671};\\\", \\\"{x:506,y:710,t:1527271846684};\\\", \\\"{x:510,y:711,t:1527271846700};\\\", \\\"{x:514,y:719,t:1527271846717};\\\", \\\"{x:516,y:721,t:1527271846735};\\\", \\\"{x:517,y:721,t:1527271846750};\\\", \\\"{x:516,y:723,t:1527271847248};\\\", \\\"{x:516,y:725,t:1527271847255};\\\", \\\"{x:514,y:725,t:1527271847267};\\\", \\\"{x:513,y:727,t:1527271847303};\\\", \\\"{x:512,y:727,t:1527271847318};\\\" ] }, { \\\"rt\\\": 28845, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 821539, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-04 PM-Z -12 PM-12 PM-12 PM-U -02 PM-03 PM-02 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:731,t:1527271848687};\\\", \\\"{x:516,y:735,t:1527271848703};\\\", \\\"{x:541,y:743,t:1527271848721};\\\", \\\"{x:556,y:748,t:1527271848735};\\\", \\\"{x:572,y:752,t:1527271848752};\\\", \\\"{x:591,y:758,t:1527271848769};\\\", \\\"{x:606,y:761,t:1527271848785};\\\", \\\"{x:628,y:766,t:1527271848802};\\\", \\\"{x:653,y:770,t:1527271848819};\\\", \\\"{x:680,y:773,t:1527271848835};\\\", \\\"{x:705,y:778,t:1527271848852};\\\", \\\"{x:722,y:782,t:1527271848869};\\\", \\\"{x:745,y:788,t:1527271848885};\\\", \\\"{x:765,y:791,t:1527271848902};\\\", \\\"{x:799,y:797,t:1527271848919};\\\", \\\"{x:821,y:799,t:1527271848935};\\\", \\\"{x:845,y:803,t:1527271848953};\\\", \\\"{x:881,y:806,t:1527271848969};\\\", \\\"{x:916,y:813,t:1527271848986};\\\", \\\"{x:947,y:817,t:1527271849002};\\\", \\\"{x:972,y:822,t:1527271849019};\\\", \\\"{x:997,y:829,t:1527271849035};\\\", \\\"{x:1031,y:838,t:1527271849052};\\\", \\\"{x:1059,y:846,t:1527271849069};\\\", \\\"{x:1088,y:857,t:1527271849086};\\\", \\\"{x:1105,y:869,t:1527271849103};\\\", \\\"{x:1110,y:873,t:1527271849119};\\\", \\\"{x:1110,y:875,t:1527271849720};\\\", \\\"{x:1110,y:876,t:1527271849737};\\\", \\\"{x:1110,y:877,t:1527271849753};\\\", \\\"{x:1110,y:878,t:1527271849770};\\\", \\\"{x:1111,y:879,t:1527271849791};\\\", \\\"{x:1113,y:881,t:1527271849804};\\\", \\\"{x:1114,y:885,t:1527271849819};\\\", \\\"{x:1118,y:887,t:1527271849837};\\\", \\\"{x:1122,y:889,t:1527271849853};\\\", \\\"{x:1128,y:891,t:1527271849870};\\\", \\\"{x:1138,y:898,t:1527271849887};\\\", \\\"{x:1145,y:902,t:1527271849903};\\\", \\\"{x:1148,y:904,t:1527271849920};\\\", \\\"{x:1150,y:905,t:1527271849937};\\\", \\\"{x:1157,y:910,t:1527271849954};\\\", \\\"{x:1164,y:916,t:1527271849970};\\\", \\\"{x:1165,y:918,t:1527271849987};\\\", \\\"{x:1167,y:920,t:1527271850004};\\\", \\\"{x:1168,y:921,t:1527271851408};\\\", \\\"{x:1170,y:922,t:1527271851421};\\\", \\\"{x:1176,y:922,t:1527271851438};\\\", \\\"{x:1182,y:922,t:1527271851455};\\\", \\\"{x:1183,y:922,t:1527271851471};\\\", \\\"{x:1184,y:922,t:1527271851511};\\\", \\\"{x:1185,y:922,t:1527271851521};\\\", \\\"{x:1187,y:922,t:1527271851538};\\\", \\\"{x:1193,y:922,t:1527271851555};\\\", \\\"{x:1198,y:923,t:1527271851572};\\\", \\\"{x:1204,y:923,t:1527271851588};\\\", \\\"{x:1205,y:923,t:1527271851605};\\\", \\\"{x:1209,y:923,t:1527271851622};\\\", \\\"{x:1214,y:925,t:1527271851638};\\\", \\\"{x:1224,y:925,t:1527271851656};\\\", \\\"{x:1231,y:925,t:1527271851672};\\\", \\\"{x:1237,y:925,t:1527271851688};\\\", \\\"{x:1244,y:925,t:1527271851704};\\\", \\\"{x:1252,y:925,t:1527271851722};\\\", \\\"{x:1266,y:926,t:1527271851737};\\\", \\\"{x:1282,y:928,t:1527271851755};\\\", \\\"{x:1299,y:930,t:1527271851772};\\\", \\\"{x:1316,y:932,t:1527271851788};\\\", \\\"{x:1327,y:932,t:1527271851805};\\\", \\\"{x:1337,y:932,t:1527271851821};\\\", \\\"{x:1348,y:932,t:1527271851838};\\\", \\\"{x:1372,y:932,t:1527271851855};\\\", \\\"{x:1413,y:932,t:1527271851871};\\\", \\\"{x:1433,y:932,t:1527271851888};\\\", \\\"{x:1451,y:932,t:1527271851905};\\\", \\\"{x:1477,y:932,t:1527271851922};\\\", \\\"{x:1504,y:932,t:1527271851938};\\\", \\\"{x:1529,y:932,t:1527271851955};\\\", \\\"{x:1550,y:935,t:1527271851972};\\\", \\\"{x:1572,y:938,t:1527271851988};\\\", \\\"{x:1598,y:941,t:1527271852005};\\\", \\\"{x:1623,y:941,t:1527271852022};\\\", \\\"{x:1642,y:941,t:1527271852038};\\\", \\\"{x:1660,y:941,t:1527271852055};\\\", \\\"{x:1674,y:943,t:1527271852071};\\\", \\\"{x:1689,y:944,t:1527271852089};\\\", \\\"{x:1702,y:947,t:1527271852105};\\\", \\\"{x:1716,y:948,t:1527271852121};\\\", \\\"{x:1726,y:949,t:1527271852139};\\\", \\\"{x:1727,y:950,t:1527271852154};\\\", \\\"{x:1729,y:951,t:1527271852172};\\\", \\\"{x:1731,y:953,t:1527271852189};\\\", \\\"{x:1731,y:954,t:1527271852205};\\\", \\\"{x:1731,y:957,t:1527271852222};\\\", \\\"{x:1733,y:961,t:1527271852239};\\\", \\\"{x:1728,y:964,t:1527271852255};\\\", \\\"{x:1719,y:964,t:1527271852272};\\\", \\\"{x:1708,y:964,t:1527271852289};\\\", \\\"{x:1697,y:964,t:1527271852305};\\\", \\\"{x:1680,y:966,t:1527271852322};\\\", \\\"{x:1666,y:969,t:1527271852340};\\\", \\\"{x:1657,y:970,t:1527271852356};\\\", \\\"{x:1647,y:973,t:1527271852371};\\\", \\\"{x:1640,y:974,t:1527271852389};\\\", \\\"{x:1632,y:974,t:1527271852405};\\\", \\\"{x:1622,y:974,t:1527271852421};\\\", \\\"{x:1619,y:975,t:1527271852438};\\\", \\\"{x:1618,y:976,t:1527271852470};\\\", \\\"{x:1617,y:976,t:1527271852502};\\\", \\\"{x:1614,y:976,t:1527271852510};\\\", \\\"{x:1613,y:976,t:1527271852522};\\\", \\\"{x:1611,y:976,t:1527271852538};\\\", \\\"{x:1611,y:974,t:1527271852655};\\\", \\\"{x:1611,y:972,t:1527271852672};\\\", \\\"{x:1611,y:971,t:1527271852688};\\\", \\\"{x:1609,y:969,t:1527271852706};\\\", \\\"{x:1609,y:968,t:1527271852722};\\\", \\\"{x:1609,y:967,t:1527271852743};\\\", \\\"{x:1609,y:966,t:1527271852759};\\\", \\\"{x:1609,y:965,t:1527271852808};\\\", \\\"{x:1610,y:963,t:1527271853064};\\\", \\\"{x:1611,y:963,t:1527271853143};\\\", \\\"{x:1612,y:962,t:1527271853176};\\\", \\\"{x:1613,y:961,t:1527271853263};\\\", \\\"{x:1614,y:961,t:1527271853279};\\\", \\\"{x:1615,y:960,t:1527271853327};\\\", \\\"{x:1615,y:959,t:1527271853759};\\\", \\\"{x:1614,y:959,t:1527271853773};\\\", \\\"{x:1611,y:959,t:1527271853790};\\\", \\\"{x:1607,y:959,t:1527271853806};\\\", \\\"{x:1600,y:959,t:1527271853823};\\\", \\\"{x:1593,y:961,t:1527271853840};\\\", \\\"{x:1586,y:961,t:1527271853856};\\\", \\\"{x:1580,y:961,t:1527271853873};\\\", \\\"{x:1572,y:961,t:1527271853890};\\\", \\\"{x:1560,y:961,t:1527271853906};\\\", \\\"{x:1543,y:961,t:1527271853923};\\\", \\\"{x:1522,y:961,t:1527271853939};\\\", \\\"{x:1490,y:961,t:1527271853957};\\\", \\\"{x:1475,y:961,t:1527271853973};\\\", \\\"{x:1453,y:961,t:1527271853990};\\\", \\\"{x:1422,y:961,t:1527271854007};\\\", \\\"{x:1400,y:957,t:1527271854023};\\\", \\\"{x:1376,y:955,t:1527271854040};\\\", \\\"{x:1352,y:952,t:1527271854057};\\\", \\\"{x:1343,y:951,t:1527271854073};\\\", \\\"{x:1341,y:951,t:1527271854090};\\\", \\\"{x:1340,y:951,t:1527271854107};\\\", \\\"{x:1339,y:951,t:1527271854123};\\\", \\\"{x:1338,y:950,t:1527271854140};\\\", \\\"{x:1337,y:950,t:1527271854157};\\\", \\\"{x:1336,y:950,t:1527271854199};\\\", \\\"{x:1335,y:950,t:1527271854207};\\\", \\\"{x:1328,y:950,t:1527271854223};\\\", \\\"{x:1319,y:950,t:1527271854240};\\\", \\\"{x:1309,y:950,t:1527271854257};\\\", \\\"{x:1302,y:952,t:1527271854273};\\\", \\\"{x:1300,y:952,t:1527271854290};\\\", \\\"{x:1298,y:952,t:1527271854307};\\\", \\\"{x:1295,y:952,t:1527271854323};\\\", \\\"{x:1291,y:953,t:1527271854340};\\\", \\\"{x:1289,y:953,t:1527271854357};\\\", \\\"{x:1286,y:953,t:1527271854373};\\\", \\\"{x:1284,y:953,t:1527271854390};\\\", \\\"{x:1278,y:955,t:1527271854407};\\\", \\\"{x:1275,y:957,t:1527271854423};\\\", \\\"{x:1271,y:958,t:1527271854440};\\\", \\\"{x:1270,y:959,t:1527271854457};\\\", \\\"{x:1269,y:959,t:1527271854474};\\\", \\\"{x:1267,y:959,t:1527271854490};\\\", \\\"{x:1262,y:959,t:1527271854506};\\\", \\\"{x:1252,y:959,t:1527271854524};\\\", \\\"{x:1243,y:959,t:1527271854541};\\\", \\\"{x:1239,y:960,t:1527271854557};\\\", \\\"{x:1237,y:960,t:1527271854574};\\\", \\\"{x:1235,y:960,t:1527271854590};\\\", \\\"{x:1231,y:960,t:1527271854607};\\\", \\\"{x:1229,y:960,t:1527271854624};\\\", \\\"{x:1224,y:962,t:1527271854640};\\\", \\\"{x:1226,y:962,t:1527271854759};\\\", \\\"{x:1228,y:962,t:1527271854775};\\\", \\\"{x:1229,y:961,t:1527271854816};\\\", \\\"{x:1231,y:960,t:1527271854831};\\\", \\\"{x:1233,y:959,t:1527271854840};\\\", \\\"{x:1239,y:959,t:1527271854857};\\\", \\\"{x:1247,y:959,t:1527271854874};\\\", \\\"{x:1253,y:958,t:1527271854890};\\\", \\\"{x:1255,y:958,t:1527271854907};\\\", \\\"{x:1257,y:957,t:1527271854935};\\\", \\\"{x:1259,y:956,t:1527271854943};\\\", \\\"{x:1262,y:955,t:1527271854957};\\\", \\\"{x:1270,y:953,t:1527271854974};\\\", \\\"{x:1276,y:952,t:1527271854991};\\\", \\\"{x:1278,y:951,t:1527271855048};\\\", \\\"{x:1279,y:950,t:1527271855057};\\\", \\\"{x:1285,y:950,t:1527271855074};\\\", \\\"{x:1289,y:949,t:1527271855091};\\\", \\\"{x:1290,y:948,t:1527271855107};\\\", \\\"{x:1291,y:948,t:1527271855124};\\\", \\\"{x:1291,y:946,t:1527271855141};\\\", \\\"{x:1291,y:944,t:1527271855223};\\\", \\\"{x:1289,y:942,t:1527271855242};\\\", \\\"{x:1290,y:942,t:1527271855295};\\\", \\\"{x:1292,y:942,t:1527271855307};\\\", \\\"{x:1293,y:942,t:1527271855324};\\\", \\\"{x:1296,y:941,t:1527271855341};\\\", \\\"{x:1299,y:941,t:1527271855357};\\\", \\\"{x:1307,y:941,t:1527271855374};\\\", \\\"{x:1326,y:941,t:1527271855391};\\\", \\\"{x:1339,y:941,t:1527271855407};\\\", \\\"{x:1345,y:941,t:1527271855424};\\\", \\\"{x:1347,y:941,t:1527271855441};\\\", \\\"{x:1348,y:941,t:1527271855458};\\\", \\\"{x:1350,y:942,t:1527271855474};\\\", \\\"{x:1351,y:943,t:1527271855491};\\\", \\\"{x:1354,y:946,t:1527271855508};\\\", \\\"{x:1354,y:948,t:1527271855527};\\\", \\\"{x:1354,y:949,t:1527271855541};\\\", \\\"{x:1354,y:951,t:1527271855559};\\\", \\\"{x:1353,y:953,t:1527271855583};\\\", \\\"{x:1351,y:955,t:1527271855617};\\\", \\\"{x:1351,y:956,t:1527271855625};\\\", \\\"{x:1351,y:958,t:1527271855642};\\\", \\\"{x:1351,y:961,t:1527271855658};\\\", \\\"{x:1351,y:963,t:1527271855675};\\\", \\\"{x:1351,y:964,t:1527271855768};\\\", \\\"{x:1351,y:963,t:1527271855934};\\\", \\\"{x:1352,y:963,t:1527271855943};\\\", \\\"{x:1352,y:961,t:1527271855957};\\\", \\\"{x:1352,y:959,t:1527271855974};\\\", \\\"{x:1352,y:958,t:1527271855991};\\\", \\\"{x:1352,y:955,t:1527271856008};\\\", \\\"{x:1352,y:954,t:1527271856030};\\\", \\\"{x:1352,y:951,t:1527271856111};\\\", \\\"{x:1352,y:950,t:1527271856125};\\\", \\\"{x:1352,y:947,t:1527271856141};\\\", \\\"{x:1352,y:943,t:1527271856158};\\\", \\\"{x:1352,y:937,t:1527271856175};\\\", \\\"{x:1352,y:931,t:1527271856191};\\\", \\\"{x:1352,y:928,t:1527271856209};\\\", \\\"{x:1351,y:920,t:1527271856225};\\\", \\\"{x:1349,y:914,t:1527271856241};\\\", \\\"{x:1348,y:906,t:1527271856258};\\\", \\\"{x:1348,y:897,t:1527271856276};\\\", \\\"{x:1351,y:890,t:1527271856291};\\\", \\\"{x:1352,y:889,t:1527271856307};\\\", \\\"{x:1352,y:887,t:1527271856324};\\\", \\\"{x:1353,y:887,t:1527271856342};\\\", \\\"{x:1354,y:887,t:1527271856366};\\\", \\\"{x:1355,y:887,t:1527271856374};\\\", \\\"{x:1361,y:891,t:1527271856391};\\\", \\\"{x:1363,y:898,t:1527271856407};\\\", \\\"{x:1365,y:900,t:1527271856425};\\\", \\\"{x:1366,y:905,t:1527271856442};\\\", \\\"{x:1369,y:909,t:1527271856458};\\\", \\\"{x:1369,y:914,t:1527271856474};\\\", \\\"{x:1373,y:918,t:1527271856491};\\\", \\\"{x:1382,y:929,t:1527271856507};\\\", \\\"{x:1393,y:937,t:1527271856525};\\\", \\\"{x:1405,y:943,t:1527271856542};\\\", \\\"{x:1411,y:946,t:1527271856558};\\\", \\\"{x:1412,y:946,t:1527271856575};\\\", \\\"{x:1412,y:947,t:1527271856592};\\\", \\\"{x:1412,y:949,t:1527271856631};\\\", \\\"{x:1412,y:950,t:1527271856642};\\\", \\\"{x:1412,y:951,t:1527271856671};\\\", \\\"{x:1413,y:952,t:1527271856687};\\\", \\\"{x:1413,y:953,t:1527271856703};\\\", \\\"{x:1414,y:954,t:1527271856720};\\\", \\\"{x:1414,y:955,t:1527271856735};\\\", \\\"{x:1414,y:956,t:1527271856767};\\\", \\\"{x:1412,y:956,t:1527271856824};\\\", \\\"{x:1411,y:956,t:1527271856832};\\\", \\\"{x:1410,y:956,t:1527271856842};\\\", \\\"{x:1409,y:956,t:1527271856859};\\\", \\\"{x:1407,y:956,t:1527271856875};\\\", \\\"{x:1401,y:956,t:1527271856892};\\\", \\\"{x:1393,y:955,t:1527271856909};\\\", \\\"{x:1377,y:952,t:1527271856925};\\\", \\\"{x:1370,y:950,t:1527271856942};\\\", \\\"{x:1367,y:949,t:1527271856959};\\\", \\\"{x:1364,y:947,t:1527271856975};\\\", \\\"{x:1356,y:942,t:1527271856992};\\\", \\\"{x:1345,y:936,t:1527271857009};\\\", \\\"{x:1334,y:929,t:1527271857025};\\\", \\\"{x:1327,y:924,t:1527271857042};\\\", \\\"{x:1323,y:921,t:1527271857059};\\\", \\\"{x:1319,y:919,t:1527271857075};\\\", \\\"{x:1316,y:917,t:1527271857093};\\\", \\\"{x:1314,y:915,t:1527271857109};\\\", \\\"{x:1310,y:912,t:1527271857125};\\\", \\\"{x:1305,y:908,t:1527271857142};\\\", \\\"{x:1302,y:905,t:1527271857159};\\\", \\\"{x:1302,y:903,t:1527271857199};\\\", \\\"{x:1301,y:902,t:1527271857209};\\\", \\\"{x:1299,y:899,t:1527271857225};\\\", \\\"{x:1299,y:898,t:1527271857279};\\\", \\\"{x:1299,y:896,t:1527271857311};\\\", \\\"{x:1298,y:895,t:1527271857326};\\\", \\\"{x:1298,y:893,t:1527271857342};\\\", \\\"{x:1298,y:890,t:1527271857359};\\\", \\\"{x:1298,y:889,t:1527271857376};\\\", \\\"{x:1298,y:887,t:1527271857392};\\\", \\\"{x:1298,y:886,t:1527271857409};\\\", \\\"{x:1298,y:884,t:1527271857426};\\\", \\\"{x:1298,y:883,t:1527271857442};\\\", \\\"{x:1299,y:883,t:1527271857458};\\\", \\\"{x:1302,y:881,t:1527271857476};\\\", \\\"{x:1304,y:880,t:1527271857492};\\\", \\\"{x:1306,y:879,t:1527271857509};\\\", \\\"{x:1309,y:877,t:1527271857525};\\\", \\\"{x:1311,y:877,t:1527271857583};\\\", \\\"{x:1312,y:877,t:1527271857592};\\\", \\\"{x:1314,y:877,t:1527271857609};\\\", \\\"{x:1316,y:877,t:1527271857625};\\\", \\\"{x:1317,y:877,t:1527271857642};\\\", \\\"{x:1318,y:876,t:1527271857670};\\\", \\\"{x:1318,y:872,t:1527271857679};\\\", \\\"{x:1318,y:873,t:1527271858056};\\\", \\\"{x:1318,y:875,t:1527271858071};\\\", \\\"{x:1318,y:877,t:1527271858079};\\\", \\\"{x:1318,y:880,t:1527271858093};\\\", \\\"{x:1317,y:883,t:1527271858109};\\\", \\\"{x:1317,y:887,t:1527271858126};\\\", \\\"{x:1314,y:894,t:1527271858143};\\\", \\\"{x:1313,y:899,t:1527271858159};\\\", \\\"{x:1310,y:903,t:1527271858176};\\\", \\\"{x:1308,y:906,t:1527271858193};\\\", \\\"{x:1307,y:909,t:1527271858210};\\\", \\\"{x:1307,y:913,t:1527271858226};\\\", \\\"{x:1306,y:917,t:1527271858243};\\\", \\\"{x:1306,y:921,t:1527271858260};\\\", \\\"{x:1305,y:924,t:1527271858276};\\\", \\\"{x:1303,y:928,t:1527271858293};\\\", \\\"{x:1302,y:932,t:1527271858310};\\\", \\\"{x:1302,y:935,t:1527271858326};\\\", \\\"{x:1302,y:940,t:1527271858343};\\\", \\\"{x:1302,y:941,t:1527271858359};\\\", \\\"{x:1302,y:944,t:1527271858376};\\\", \\\"{x:1302,y:945,t:1527271858399};\\\", \\\"{x:1302,y:947,t:1527271858416};\\\", \\\"{x:1302,y:948,t:1527271858425};\\\", \\\"{x:1302,y:950,t:1527271858442};\\\", \\\"{x:1302,y:951,t:1527271858462};\\\", \\\"{x:1302,y:953,t:1527271858519};\\\", \\\"{x:1302,y:954,t:1527271858534};\\\", \\\"{x:1300,y:955,t:1527271858542};\\\", \\\"{x:1300,y:956,t:1527271858559};\\\", \\\"{x:1299,y:957,t:1527271858607};\\\", \\\"{x:1299,y:958,t:1527271858616};\\\", \\\"{x:1298,y:958,t:1527271858639};\\\", \\\"{x:1297,y:958,t:1527271858694};\\\", \\\"{x:1296,y:960,t:1527271858709};\\\", \\\"{x:1295,y:960,t:1527271858727};\\\", \\\"{x:1295,y:961,t:1527271858750};\\\", \\\"{x:1294,y:962,t:1527271858815};\\\", \\\"{x:1294,y:963,t:1527271858872};\\\", \\\"{x:1294,y:964,t:1527271858887};\\\", \\\"{x:1293,y:964,t:1527271858894};\\\", \\\"{x:1292,y:965,t:1527271858911};\\\", \\\"{x:1291,y:965,t:1527271858927};\\\", \\\"{x:1291,y:967,t:1527271858943};\\\", \\\"{x:1291,y:968,t:1527271858960};\\\", \\\"{x:1290,y:967,t:1527271859591};\\\", \\\"{x:1289,y:958,t:1527271859599};\\\", \\\"{x:1287,y:948,t:1527271859610};\\\", \\\"{x:1285,y:926,t:1527271859627};\\\", \\\"{x:1284,y:912,t:1527271859644};\\\", \\\"{x:1284,y:905,t:1527271859661};\\\", \\\"{x:1282,y:901,t:1527271859677};\\\", \\\"{x:1281,y:899,t:1527271859694};\\\", \\\"{x:1281,y:897,t:1527271859816};\\\", \\\"{x:1281,y:895,t:1527271859831};\\\", \\\"{x:1281,y:894,t:1527271859844};\\\", \\\"{x:1281,y:891,t:1527271859862};\\\", \\\"{x:1280,y:888,t:1527271859877};\\\", \\\"{x:1280,y:886,t:1527271859975};\\\", \\\"{x:1280,y:884,t:1527271859983};\\\", \\\"{x:1280,y:882,t:1527271860007};\\\", \\\"{x:1280,y:880,t:1527271860016};\\\", \\\"{x:1281,y:877,t:1527271860027};\\\", \\\"{x:1281,y:875,t:1527271860044};\\\", \\\"{x:1282,y:872,t:1527271860061};\\\", \\\"{x:1282,y:870,t:1527271860078};\\\", \\\"{x:1282,y:867,t:1527271860094};\\\", \\\"{x:1282,y:864,t:1527271860111};\\\", \\\"{x:1282,y:860,t:1527271860127};\\\", \\\"{x:1282,y:856,t:1527271860144};\\\", \\\"{x:1283,y:853,t:1527271860161};\\\", \\\"{x:1283,y:850,t:1527271860178};\\\", \\\"{x:1284,y:848,t:1527271860194};\\\", \\\"{x:1286,y:846,t:1527271860211};\\\", \\\"{x:1288,y:845,t:1527271860228};\\\", \\\"{x:1289,y:843,t:1527271860243};\\\", \\\"{x:1289,y:841,t:1527271860261};\\\", \\\"{x:1289,y:838,t:1527271860277};\\\", \\\"{x:1289,y:837,t:1527271860735};\\\", \\\"{x:1291,y:842,t:1527271862111};\\\", \\\"{x:1296,y:850,t:1527271862129};\\\", \\\"{x:1304,y:863,t:1527271862146};\\\", \\\"{x:1319,y:883,t:1527271862163};\\\", \\\"{x:1333,y:906,t:1527271862179};\\\", \\\"{x:1342,y:919,t:1527271862197};\\\", \\\"{x:1346,y:927,t:1527271862212};\\\", \\\"{x:1349,y:932,t:1527271862230};\\\", \\\"{x:1354,y:941,t:1527271862246};\\\", \\\"{x:1357,y:947,t:1527271862262};\\\", \\\"{x:1359,y:951,t:1527271862279};\\\", \\\"{x:1360,y:951,t:1527271862296};\\\", \\\"{x:1361,y:952,t:1527271862312};\\\", \\\"{x:1362,y:953,t:1527271862335};\\\", \\\"{x:1363,y:954,t:1527271862346};\\\", \\\"{x:1363,y:955,t:1527271862362};\\\", \\\"{x:1365,y:958,t:1527271862447};\\\", \\\"{x:1365,y:959,t:1527271862463};\\\", \\\"{x:1366,y:959,t:1527271863135};\\\", \\\"{x:1366,y:960,t:1527271863146};\\\", \\\"{x:1368,y:962,t:1527271863167};\\\", \\\"{x:1368,y:963,t:1527271863183};\\\", \\\"{x:1368,y:964,t:1527271863199};\\\", \\\"{x:1368,y:967,t:1527271863213};\\\", \\\"{x:1368,y:971,t:1527271863230};\\\", \\\"{x:1368,y:972,t:1527271863246};\\\", \\\"{x:1368,y:979,t:1527271863263};\\\", \\\"{x:1368,y:983,t:1527271863280};\\\", \\\"{x:1369,y:985,t:1527271863296};\\\", \\\"{x:1369,y:986,t:1527271863550};\\\", \\\"{x:1368,y:986,t:1527271863562};\\\", \\\"{x:1368,y:985,t:1527271863580};\\\", \\\"{x:1367,y:985,t:1527271863596};\\\", \\\"{x:1365,y:983,t:1527271863613};\\\", \\\"{x:1364,y:981,t:1527271863630};\\\", \\\"{x:1363,y:980,t:1527271863646};\\\", \\\"{x:1362,y:979,t:1527271863927};\\\", \\\"{x:1361,y:980,t:1527271864735};\\\", \\\"{x:1361,y:981,t:1527271864747};\\\", \\\"{x:1361,y:983,t:1527271864765};\\\", \\\"{x:1360,y:986,t:1527271864782};\\\", \\\"{x:1359,y:986,t:1527271864807};\\\", \\\"{x:1358,y:983,t:1527271864920};\\\", \\\"{x:1358,y:982,t:1527271864932};\\\", \\\"{x:1357,y:979,t:1527271864949};\\\", \\\"{x:1355,y:973,t:1527271864964};\\\", \\\"{x:1352,y:968,t:1527271864981};\\\", \\\"{x:1350,y:964,t:1527271864999};\\\", \\\"{x:1348,y:963,t:1527271865014};\\\", \\\"{x:1347,y:960,t:1527271865031};\\\", \\\"{x:1347,y:957,t:1527271865048};\\\", \\\"{x:1345,y:955,t:1527271865065};\\\", \\\"{x:1344,y:953,t:1527271865081};\\\", \\\"{x:1343,y:951,t:1527271865098};\\\", \\\"{x:1343,y:947,t:1527271865114};\\\", \\\"{x:1342,y:943,t:1527271865131};\\\", \\\"{x:1341,y:939,t:1527271865149};\\\", \\\"{x:1340,y:933,t:1527271865165};\\\", \\\"{x:1337,y:925,t:1527271865181};\\\", \\\"{x:1335,y:919,t:1527271865199};\\\", \\\"{x:1333,y:912,t:1527271865214};\\\", \\\"{x:1333,y:905,t:1527271865231};\\\", \\\"{x:1332,y:899,t:1527271865248};\\\", \\\"{x:1332,y:893,t:1527271865264};\\\", \\\"{x:1332,y:883,t:1527271865281};\\\", \\\"{x:1331,y:878,t:1527271865298};\\\", \\\"{x:1331,y:872,t:1527271865315};\\\", \\\"{x:1331,y:861,t:1527271865331};\\\", \\\"{x:1333,y:852,t:1527271865349};\\\", \\\"{x:1333,y:844,t:1527271865366};\\\", \\\"{x:1333,y:840,t:1527271865381};\\\", \\\"{x:1333,y:835,t:1527271865398};\\\", \\\"{x:1333,y:825,t:1527271865415};\\\", \\\"{x:1331,y:818,t:1527271865431};\\\", \\\"{x:1330,y:812,t:1527271865449};\\\", \\\"{x:1329,y:810,t:1527271865465};\\\", \\\"{x:1329,y:809,t:1527271865481};\\\", \\\"{x:1330,y:805,t:1527271865499};\\\", \\\"{x:1332,y:803,t:1527271865516};\\\", \\\"{x:1333,y:799,t:1527271865531};\\\", \\\"{x:1334,y:794,t:1527271865548};\\\", \\\"{x:1334,y:789,t:1527271865566};\\\", \\\"{x:1336,y:783,t:1527271865582};\\\", \\\"{x:1337,y:781,t:1527271865598};\\\", \\\"{x:1338,y:774,t:1527271865615};\\\", \\\"{x:1338,y:770,t:1527271865632};\\\", \\\"{x:1338,y:765,t:1527271865648};\\\", \\\"{x:1338,y:764,t:1527271865665};\\\", \\\"{x:1338,y:762,t:1527271865682};\\\", \\\"{x:1338,y:761,t:1527271865699};\\\", \\\"{x:1339,y:759,t:1527271865715};\\\", \\\"{x:1341,y:757,t:1527271865732};\\\", \\\"{x:1343,y:754,t:1527271865749};\\\", \\\"{x:1343,y:750,t:1527271865766};\\\", \\\"{x:1343,y:748,t:1527271865782};\\\", \\\"{x:1344,y:746,t:1527271865798};\\\", \\\"{x:1348,y:741,t:1527271865816};\\\", \\\"{x:1351,y:739,t:1527271865833};\\\", \\\"{x:1351,y:736,t:1527271865849};\\\", \\\"{x:1352,y:733,t:1527271865865};\\\", \\\"{x:1352,y:732,t:1527271865882};\\\", \\\"{x:1355,y:729,t:1527271865898};\\\", \\\"{x:1357,y:729,t:1527271865916};\\\", \\\"{x:1360,y:726,t:1527271865933};\\\", \\\"{x:1360,y:723,t:1527271865948};\\\", \\\"{x:1360,y:716,t:1527271865966};\\\", \\\"{x:1360,y:715,t:1527271865983};\\\", \\\"{x:1360,y:713,t:1527271865999};\\\", \\\"{x:1361,y:713,t:1527271866017};\\\", \\\"{x:1362,y:712,t:1527271866063};\\\", \\\"{x:1362,y:710,t:1527271866087};\\\", \\\"{x:1362,y:709,t:1527271866103};\\\", \\\"{x:1363,y:709,t:1527271866115};\\\", \\\"{x:1363,y:708,t:1527271866134};\\\", \\\"{x:1363,y:707,t:1527271866149};\\\", \\\"{x:1364,y:706,t:1527271866190};\\\", \\\"{x:1364,y:703,t:1527271866199};\\\", \\\"{x:1364,y:700,t:1527271866217};\\\", \\\"{x:1364,y:696,t:1527271866232};\\\", \\\"{x:1363,y:695,t:1527271866249};\\\", \\\"{x:1361,y:694,t:1527271866265};\\\", \\\"{x:1360,y:694,t:1527271866283};\\\", \\\"{x:1359,y:693,t:1527271866311};\\\", \\\"{x:1358,y:693,t:1527271866335};\\\", \\\"{x:1357,y:693,t:1527271866348};\\\", \\\"{x:1355,y:693,t:1527271866407};\\\", \\\"{x:1354,y:692,t:1527271866447};\\\", \\\"{x:1353,y:692,t:1527271866455};\\\", \\\"{x:1352,y:692,t:1527271866465};\\\", \\\"{x:1350,y:692,t:1527271866567};\\\", \\\"{x:1349,y:692,t:1527271866583};\\\", \\\"{x:1348,y:692,t:1527271866607};\\\", \\\"{x:1346,y:692,t:1527271866680};\\\", \\\"{x:1345,y:692,t:1527271866759};\\\", \\\"{x:1344,y:692,t:1527271866768};\\\", \\\"{x:1343,y:692,t:1527271866791};\\\", \\\"{x:1341,y:693,t:1527271866799};\\\", \\\"{x:1339,y:693,t:1527271866823};\\\", \\\"{x:1337,y:694,t:1527271866887};\\\", \\\"{x:1335,y:694,t:1527271866900};\\\", \\\"{x:1331,y:696,t:1527271866917};\\\", \\\"{x:1332,y:696,t:1527271867847};\\\", \\\"{x:1333,y:696,t:1527271867855};\\\", \\\"{x:1334,y:696,t:1527271867866};\\\", \\\"{x:1336,y:696,t:1527271867895};\\\", \\\"{x:1338,y:695,t:1527271867904};\\\", \\\"{x:1340,y:695,t:1527271867919};\\\", \\\"{x:1341,y:695,t:1527271867967};\\\", \\\"{x:1343,y:695,t:1527271868016};\\\", \\\"{x:1345,y:693,t:1527271868033};\\\", \\\"{x:1347,y:693,t:1527271868071};\\\", \\\"{x:1348,y:693,t:1527271868111};\\\", \\\"{x:1349,y:693,t:1527271868143};\\\", \\\"{x:1353,y:693,t:1527271868151};\\\", \\\"{x:1359,y:693,t:1527271868166};\\\", \\\"{x:1362,y:694,t:1527271868183};\\\", \\\"{x:1365,y:694,t:1527271868201};\\\", \\\"{x:1374,y:697,t:1527271868217};\\\", \\\"{x:1381,y:698,t:1527271868233};\\\", \\\"{x:1387,y:698,t:1527271868251};\\\", \\\"{x:1390,y:698,t:1527271868267};\\\", \\\"{x:1392,y:698,t:1527271868283};\\\", \\\"{x:1393,y:698,t:1527271868300};\\\", \\\"{x:1396,y:701,t:1527271868367};\\\", \\\"{x:1402,y:705,t:1527271868384};\\\", \\\"{x:1409,y:710,t:1527271868400};\\\", \\\"{x:1419,y:715,t:1527271868418};\\\", \\\"{x:1425,y:719,t:1527271868433};\\\", \\\"{x:1431,y:724,t:1527271868450};\\\", \\\"{x:1435,y:731,t:1527271868468};\\\", \\\"{x:1436,y:733,t:1527271868483};\\\", \\\"{x:1438,y:737,t:1527271868500};\\\", \\\"{x:1439,y:739,t:1527271868518};\\\", \\\"{x:1440,y:741,t:1527271868533};\\\", \\\"{x:1440,y:744,t:1527271868550};\\\", \\\"{x:1440,y:748,t:1527271868567};\\\", \\\"{x:1440,y:752,t:1527271868583};\\\", \\\"{x:1443,y:760,t:1527271868600};\\\", \\\"{x:1444,y:766,t:1527271868617};\\\", \\\"{x:1444,y:770,t:1527271868634};\\\", \\\"{x:1446,y:772,t:1527271868651};\\\", \\\"{x:1446,y:773,t:1527271868668};\\\", \\\"{x:1448,y:776,t:1527271868683};\\\", \\\"{x:1450,y:781,t:1527271868700};\\\", \\\"{x:1452,y:786,t:1527271868717};\\\", \\\"{x:1462,y:800,t:1527271868734};\\\", \\\"{x:1466,y:807,t:1527271868750};\\\", \\\"{x:1467,y:809,t:1527271868766};\\\", \\\"{x:1469,y:811,t:1527271868784};\\\", \\\"{x:1473,y:815,t:1527271868800};\\\", \\\"{x:1483,y:824,t:1527271868817};\\\", \\\"{x:1492,y:835,t:1527271868834};\\\", \\\"{x:1506,y:845,t:1527271868850};\\\", \\\"{x:1507,y:845,t:1527271868867};\\\", \\\"{x:1507,y:846,t:1527271868884};\\\", \\\"{x:1509,y:846,t:1527271868911};\\\", \\\"{x:1512,y:849,t:1527271868926};\\\", \\\"{x:1513,y:850,t:1527271869103};\\\", \\\"{x:1513,y:851,t:1527271869117};\\\", \\\"{x:1513,y:856,t:1527271869134};\\\", \\\"{x:1513,y:859,t:1527271869151};\\\", \\\"{x:1513,y:865,t:1527271869168};\\\", \\\"{x:1513,y:869,t:1527271869184};\\\", \\\"{x:1513,y:874,t:1527271869202};\\\", \\\"{x:1512,y:880,t:1527271869217};\\\", \\\"{x:1512,y:881,t:1527271869235};\\\", \\\"{x:1512,y:884,t:1527271869251};\\\", \\\"{x:1512,y:885,t:1527271869267};\\\", \\\"{x:1512,y:888,t:1527271869285};\\\", \\\"{x:1512,y:895,t:1527271869301};\\\", \\\"{x:1509,y:904,t:1527271869318};\\\", \\\"{x:1504,y:914,t:1527271869335};\\\", \\\"{x:1503,y:919,t:1527271869351};\\\", \\\"{x:1502,y:924,t:1527271869368};\\\", \\\"{x:1502,y:929,t:1527271869385};\\\", \\\"{x:1502,y:934,t:1527271869401};\\\", \\\"{x:1502,y:936,t:1527271869417};\\\", \\\"{x:1502,y:939,t:1527271869435};\\\", \\\"{x:1502,y:942,t:1527271869451};\\\", \\\"{x:1502,y:946,t:1527271869468};\\\", \\\"{x:1501,y:951,t:1527271869484};\\\", \\\"{x:1501,y:953,t:1527271869501};\\\", \\\"{x:1499,y:956,t:1527271869518};\\\", \\\"{x:1497,y:959,t:1527271869534};\\\", \\\"{x:1495,y:963,t:1527271869551};\\\", \\\"{x:1493,y:965,t:1527271869567};\\\", \\\"{x:1491,y:967,t:1527271869585};\\\", \\\"{x:1490,y:969,t:1527271869607};\\\", \\\"{x:1488,y:970,t:1527271869623};\\\", \\\"{x:1488,y:971,t:1527271869638};\\\", \\\"{x:1486,y:971,t:1527271869767};\\\", \\\"{x:1485,y:971,t:1527271869784};\\\", \\\"{x:1484,y:971,t:1527271869801};\\\", \\\"{x:1481,y:968,t:1527271869863};\\\", \\\"{x:1481,y:965,t:1527271869871};\\\", \\\"{x:1481,y:960,t:1527271869885};\\\", \\\"{x:1480,y:954,t:1527271869901};\\\", \\\"{x:1479,y:940,t:1527271869919};\\\", \\\"{x:1476,y:928,t:1527271869934};\\\", \\\"{x:1474,y:920,t:1527271869951};\\\", \\\"{x:1472,y:916,t:1527271869968};\\\", \\\"{x:1472,y:912,t:1527271869985};\\\", \\\"{x:1472,y:910,t:1527271870002};\\\", \\\"{x:1471,y:902,t:1527271870019};\\\", \\\"{x:1470,y:896,t:1527271870035};\\\", \\\"{x:1469,y:893,t:1527271870052};\\\", \\\"{x:1468,y:891,t:1527271870068};\\\", \\\"{x:1468,y:888,t:1527271870085};\\\", \\\"{x:1468,y:884,t:1527271870101};\\\", \\\"{x:1465,y:878,t:1527271870119};\\\", \\\"{x:1464,y:874,t:1527271870135};\\\", \\\"{x:1464,y:870,t:1527271870152};\\\", \\\"{x:1464,y:867,t:1527271870168};\\\", \\\"{x:1464,y:865,t:1527271870185};\\\", \\\"{x:1464,y:863,t:1527271870201};\\\", \\\"{x:1464,y:861,t:1527271870218};\\\", \\\"{x:1464,y:859,t:1527271870236};\\\", \\\"{x:1464,y:855,t:1527271870252};\\\", \\\"{x:1465,y:850,t:1527271870269};\\\", \\\"{x:1465,y:847,t:1527271870286};\\\", \\\"{x:1465,y:845,t:1527271870302};\\\", \\\"{x:1465,y:843,t:1527271870319};\\\", \\\"{x:1465,y:842,t:1527271870335};\\\", \\\"{x:1465,y:839,t:1527271870351};\\\", \\\"{x:1465,y:835,t:1527271870369};\\\", \\\"{x:1465,y:834,t:1527271870386};\\\", \\\"{x:1465,y:833,t:1527271870402};\\\", \\\"{x:1465,y:832,t:1527271870419};\\\", \\\"{x:1464,y:831,t:1527271870463};\\\", \\\"{x:1460,y:831,t:1527271870471};\\\", \\\"{x:1452,y:831,t:1527271870485};\\\", \\\"{x:1418,y:831,t:1527271870502};\\\", \\\"{x:1264,y:836,t:1527271870519};\\\", \\\"{x:1088,y:836,t:1527271870535};\\\", \\\"{x:874,y:833,t:1527271870551};\\\", \\\"{x:684,y:830,t:1527271870569};\\\", \\\"{x:531,y:809,t:1527271870585};\\\", \\\"{x:426,y:793,t:1527271870602};\\\", \\\"{x:382,y:783,t:1527271870618};\\\", \\\"{x:361,y:773,t:1527271870636};\\\", \\\"{x:349,y:765,t:1527271870652};\\\", \\\"{x:345,y:762,t:1527271870669};\\\", \\\"{x:345,y:761,t:1527271870685};\\\", \\\"{x:353,y:756,t:1527271870703};\\\", \\\"{x:371,y:750,t:1527271870719};\\\", \\\"{x:390,y:742,t:1527271870735};\\\", \\\"{x:406,y:736,t:1527271870753};\\\", \\\"{x:421,y:733,t:1527271870769};\\\", \\\"{x:446,y:729,t:1527271870786};\\\", \\\"{x:478,y:724,t:1527271870802};\\\", \\\"{x:522,y:724,t:1527271870818};\\\", \\\"{x:577,y:734,t:1527271870836};\\\", \\\"{x:646,y:741,t:1527271870853};\\\", \\\"{x:783,y:760,t:1527271870869};\\\", \\\"{x:900,y:783,t:1527271870887};\\\", \\\"{x:1027,y:812,t:1527271870903};\\\", \\\"{x:1148,y:844,t:1527271870920};\\\", \\\"{x:1267,y:877,t:1527271870937};\\\", \\\"{x:1359,y:906,t:1527271870953};\\\", \\\"{x:1425,y:924,t:1527271870970};\\\", \\\"{x:1495,y:943,t:1527271870987};\\\", \\\"{x:1550,y:958,t:1527271871003};\\\", \\\"{x:1571,y:963,t:1527271871020};\\\", \\\"{x:1575,y:964,t:1527271871037};\\\", \\\"{x:1575,y:965,t:1527271871071};\\\", \\\"{x:1579,y:968,t:1527271871086};\\\", \\\"{x:1587,y:968,t:1527271871103};\\\", \\\"{x:1589,y:968,t:1527271871120};\\\", \\\"{x:1590,y:969,t:1527271871199};\\\", \\\"{x:1589,y:971,t:1527271871206};\\\", \\\"{x:1585,y:974,t:1527271871221};\\\", \\\"{x:1571,y:977,t:1527271871237};\\\", \\\"{x:1559,y:980,t:1527271871255};\\\", \\\"{x:1553,y:982,t:1527271871271};\\\", \\\"{x:1550,y:983,t:1527271871287};\\\", \\\"{x:1548,y:983,t:1527271871304};\\\", \\\"{x:1544,y:983,t:1527271871320};\\\", \\\"{x:1536,y:983,t:1527271871338};\\\", \\\"{x:1527,y:982,t:1527271871355};\\\", \\\"{x:1514,y:978,t:1527271871371};\\\", \\\"{x:1501,y:976,t:1527271871388};\\\", \\\"{x:1497,y:974,t:1527271871404};\\\", \\\"{x:1497,y:973,t:1527271871420};\\\", \\\"{x:1493,y:970,t:1527271871438};\\\", \\\"{x:1479,y:962,t:1527271871454};\\\", \\\"{x:1477,y:960,t:1527271871470};\\\", \\\"{x:1475,y:955,t:1527271871487};\\\", \\\"{x:1471,y:943,t:1527271871504};\\\", \\\"{x:1469,y:927,t:1527271871520};\\\", \\\"{x:1461,y:905,t:1527271871537};\\\", \\\"{x:1454,y:890,t:1527271871554};\\\", \\\"{x:1454,y:884,t:1527271871571};\\\", \\\"{x:1454,y:874,t:1527271871587};\\\", \\\"{x:1455,y:865,t:1527271871604};\\\", \\\"{x:1455,y:858,t:1527271871620};\\\", \\\"{x:1455,y:850,t:1527271871637};\\\", \\\"{x:1456,y:843,t:1527271871654};\\\", \\\"{x:1457,y:841,t:1527271871670};\\\", \\\"{x:1458,y:840,t:1527271871687};\\\", \\\"{x:1454,y:837,t:1527271871735};\\\", \\\"{x:1441,y:835,t:1527271871743};\\\", \\\"{x:1427,y:832,t:1527271871755};\\\", \\\"{x:1394,y:824,t:1527271871771};\\\", \\\"{x:1317,y:804,t:1527271871788};\\\", \\\"{x:1200,y:783,t:1527271871805};\\\", \\\"{x:1070,y:767,t:1527271871822};\\\", \\\"{x:935,y:754,t:1527271871837};\\\", \\\"{x:733,y:754,t:1527271871854};\\\", \\\"{x:600,y:752,t:1527271871870};\\\", \\\"{x:454,y:737,t:1527271871887};\\\", \\\"{x:335,y:723,t:1527271871904};\\\", \\\"{x:242,y:715,t:1527271871921};\\\", \\\"{x:188,y:705,t:1527271871937};\\\", \\\"{x:171,y:702,t:1527271871954};\\\", \\\"{x:169,y:702,t:1527271871970};\\\", \\\"{x:170,y:700,t:1527271872071};\\\", \\\"{x:178,y:696,t:1527271872088};\\\", \\\"{x:195,y:687,t:1527271872104};\\\", \\\"{x:211,y:681,t:1527271872122};\\\", \\\"{x:224,y:675,t:1527271872138};\\\", \\\"{x:231,y:670,t:1527271872154};\\\", \\\"{x:235,y:666,t:1527271872171};\\\", \\\"{x:235,y:664,t:1527271872188};\\\", \\\"{x:240,y:661,t:1527271872205};\\\", \\\"{x:245,y:659,t:1527271872221};\\\", \\\"{x:264,y:650,t:1527271872238};\\\", \\\"{x:276,y:647,t:1527271872254};\\\", \\\"{x:279,y:646,t:1527271872271};\\\", \\\"{x:280,y:646,t:1527271872294};\\\", \\\"{x:276,y:646,t:1527271872326};\\\", \\\"{x:267,y:645,t:1527271872338};\\\", \\\"{x:247,y:640,t:1527271872355};\\\", \\\"{x:241,y:640,t:1527271872371};\\\", \\\"{x:238,y:637,t:1527271872454};\\\", \\\"{x:227,y:628,t:1527271872471};\\\", \\\"{x:219,y:623,t:1527271872488};\\\", \\\"{x:219,y:621,t:1527271872567};\\\", \\\"{x:219,y:620,t:1527271872574};\\\", \\\"{x:219,y:619,t:1527271872590};\\\", \\\"{x:228,y:613,t:1527271872605};\\\", \\\"{x:241,y:606,t:1527271872621};\\\", \\\"{x:256,y:601,t:1527271872637};\\\", \\\"{x:267,y:596,t:1527271872655};\\\", \\\"{x:286,y:588,t:1527271872672};\\\", \\\"{x:318,y:578,t:1527271872689};\\\", \\\"{x:385,y:570,t:1527271872705};\\\", \\\"{x:471,y:570,t:1527271872721};\\\", \\\"{x:546,y:570,t:1527271872739};\\\", \\\"{x:588,y:570,t:1527271872755};\\\", \\\"{x:613,y:570,t:1527271872772};\\\", \\\"{x:634,y:570,t:1527271872788};\\\", \\\"{x:654,y:570,t:1527271872805};\\\", \\\"{x:662,y:570,t:1527271872821};\\\", \\\"{x:668,y:571,t:1527271872838};\\\", \\\"{x:672,y:573,t:1527271872855};\\\", \\\"{x:688,y:575,t:1527271872873};\\\", \\\"{x:704,y:578,t:1527271872888};\\\", \\\"{x:709,y:579,t:1527271872905};\\\", \\\"{x:709,y:580,t:1527271872921};\\\", \\\"{x:706,y:582,t:1527271873082};\\\", \\\"{x:699,y:584,t:1527271873088};\\\", \\\"{x:683,y:591,t:1527271873105};\\\", \\\"{x:669,y:597,t:1527271873121};\\\", \\\"{x:661,y:600,t:1527271873139};\\\", \\\"{x:659,y:600,t:1527271873238};\\\", \\\"{x:656,y:602,t:1527271873255};\\\", \\\"{x:655,y:602,t:1527271873303};\\\", \\\"{x:654,y:603,t:1527271873311};\\\", \\\"{x:651,y:603,t:1527271873322};\\\", \\\"{x:646,y:605,t:1527271873339};\\\", \\\"{x:642,y:605,t:1527271873357};\\\", \\\"{x:641,y:605,t:1527271873372};\\\", \\\"{x:640,y:605,t:1527271873388};\\\", \\\"{x:636,y:604,t:1527271873405};\\\", \\\"{x:630,y:600,t:1527271873422};\\\", \\\"{x:626,y:599,t:1527271873439};\\\", \\\"{x:624,y:599,t:1527271873470};\\\", \\\"{x:624,y:598,t:1527271873478};\\\", \\\"{x:623,y:598,t:1527271873489};\\\", \\\"{x:621,y:598,t:1527271873510};\\\", \\\"{x:620,y:598,t:1527271873749};\\\", \\\"{x:617,y:598,t:1527271873758};\\\", \\\"{x:613,y:598,t:1527271873772};\\\", \\\"{x:604,y:601,t:1527271873789};\\\", \\\"{x:596,y:604,t:1527271873806};\\\", \\\"{x:590,y:605,t:1527271873822};\\\", \\\"{x:584,y:609,t:1527271873839};\\\", \\\"{x:575,y:614,t:1527271873856};\\\", \\\"{x:568,y:620,t:1527271873873};\\\", \\\"{x:564,y:623,t:1527271873889};\\\", \\\"{x:561,y:627,t:1527271873906};\\\", \\\"{x:557,y:632,t:1527271873921};\\\", \\\"{x:557,y:637,t:1527271873939};\\\", \\\"{x:553,y:642,t:1527271873956};\\\", \\\"{x:553,y:644,t:1527271873972};\\\", \\\"{x:553,y:647,t:1527271873989};\\\", \\\"{x:552,y:648,t:1527271874006};\\\", \\\"{x:551,y:650,t:1527271874079};\\\", \\\"{x:550,y:651,t:1527271874090};\\\", \\\"{x:550,y:654,t:1527271874106};\\\", \\\"{x:549,y:655,t:1527271875343};\\\", \\\"{x:547,y:658,t:1527271875358};\\\", \\\"{x:546,y:671,t:1527271875374};\\\", \\\"{x:546,y:679,t:1527271875390};\\\", \\\"{x:545,y:687,t:1527271875407};\\\", \\\"{x:545,y:689,t:1527271875424};\\\", \\\"{x:545,y:691,t:1527271875440};\\\", \\\"{x:545,y:692,t:1527271875457};\\\", \\\"{x:545,y:693,t:1527271875474};\\\", \\\"{x:544,y:695,t:1527271875494};\\\", \\\"{x:544,y:696,t:1527271875517};\\\", \\\"{x:544,y:697,t:1527271875534};\\\", \\\"{x:544,y:698,t:1527271875550};\\\", \\\"{x:544,y:699,t:1527271875558};\\\", \\\"{x:543,y:700,t:1527271875575};\\\", \\\"{x:543,y:702,t:1527271875599};\\\", \\\"{x:542,y:703,t:1527271875622};\\\", \\\"{x:542,y:704,t:1527271875630};\\\", \\\"{x:542,y:705,t:1527271875640};\\\", \\\"{x:542,y:708,t:1527271875657};\\\", \\\"{x:540,y:710,t:1527271875673};\\\", \\\"{x:540,y:712,t:1527271875694};\\\", \\\"{x:539,y:713,t:1527271875775};\\\", \\\"{x:539,y:715,t:1527271875791};\\\" ] }, { \\\"rt\\\": 57557, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 880301, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -I -Z -Z -Z -Z -Z -Z -11 AM-I -O -O -O -02 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:542,y:718,t:1527271881095};\\\", \\\"{x:565,y:737,t:1527271881114};\\\", \\\"{x:586,y:743,t:1527271881129};\\\", \\\"{x:601,y:750,t:1527271881145};\\\", \\\"{x:621,y:757,t:1527271881162};\\\", \\\"{x:659,y:767,t:1527271881178};\\\", \\\"{x:710,y:785,t:1527271881196};\\\", \\\"{x:782,y:804,t:1527271881212};\\\", \\\"{x:878,y:824,t:1527271881229};\\\", \\\"{x:970,y:837,t:1527271881245};\\\", \\\"{x:1067,y:849,t:1527271881262};\\\", \\\"{x:1204,y:870,t:1527271881278};\\\", \\\"{x:1285,y:881,t:1527271881296};\\\", \\\"{x:1361,y:893,t:1527271881312};\\\", \\\"{x:1410,y:898,t:1527271881328};\\\", \\\"{x:1438,y:904,t:1527271881346};\\\", \\\"{x:1461,y:907,t:1527271881362};\\\", \\\"{x:1478,y:909,t:1527271881378};\\\", \\\"{x:1496,y:914,t:1527271881396};\\\", \\\"{x:1523,y:918,t:1527271881411};\\\", \\\"{x:1563,y:920,t:1527271881428};\\\", \\\"{x:1611,y:921,t:1527271881446};\\\", \\\"{x:1656,y:921,t:1527271881462};\\\", \\\"{x:1703,y:921,t:1527271881478};\\\", \\\"{x:1747,y:925,t:1527271881496};\\\", \\\"{x:1777,y:930,t:1527271881512};\\\", \\\"{x:1796,y:931,t:1527271881529};\\\", \\\"{x:1808,y:931,t:1527271881546};\\\", \\\"{x:1814,y:931,t:1527271881563};\\\", \\\"{x:1816,y:931,t:1527271881591};\\\", \\\"{x:1816,y:929,t:1527271881775};\\\", \\\"{x:1815,y:928,t:1527271881798};\\\", \\\"{x:1813,y:926,t:1527271881815};\\\", \\\"{x:1809,y:921,t:1527271881829};\\\", \\\"{x:1791,y:907,t:1527271881846};\\\", \\\"{x:1762,y:888,t:1527271881863};\\\", \\\"{x:1757,y:884,t:1527271881879};\\\", \\\"{x:1755,y:882,t:1527271881896};\\\", \\\"{x:1749,y:874,t:1527271881913};\\\", \\\"{x:1736,y:855,t:1527271881929};\\\", \\\"{x:1717,y:834,t:1527271881946};\\\", \\\"{x:1700,y:812,t:1527271881963};\\\", \\\"{x:1696,y:808,t:1527271881979};\\\", \\\"{x:1696,y:806,t:1527271881996};\\\", \\\"{x:1696,y:801,t:1527271882013};\\\", \\\"{x:1696,y:793,t:1527271882030};\\\", \\\"{x:1696,y:779,t:1527271882046};\\\", \\\"{x:1696,y:757,t:1527271882062};\\\", \\\"{x:1696,y:752,t:1527271882080};\\\", \\\"{x:1696,y:750,t:1527271882096};\\\", \\\"{x:1695,y:749,t:1527271882113};\\\", \\\"{x:1694,y:748,t:1527271882149};\\\", \\\"{x:1694,y:747,t:1527271882182};\\\", \\\"{x:1694,y:745,t:1527271882195};\\\", \\\"{x:1694,y:738,t:1527271882213};\\\", \\\"{x:1694,y:734,t:1527271882229};\\\", \\\"{x:1692,y:726,t:1527271882245};\\\", \\\"{x:1682,y:704,t:1527271882262};\\\", \\\"{x:1680,y:697,t:1527271882280};\\\", \\\"{x:1680,y:696,t:1527271882296};\\\", \\\"{x:1680,y:697,t:1527271882559};\\\", \\\"{x:1681,y:699,t:1527271882567};\\\", \\\"{x:1682,y:700,t:1527271882580};\\\", \\\"{x:1682,y:701,t:1527271882735};\\\", \\\"{x:1682,y:700,t:1527271882747};\\\", \\\"{x:1671,y:694,t:1527271882763};\\\", \\\"{x:1643,y:680,t:1527271882780};\\\", \\\"{x:1598,y:666,t:1527271882797};\\\", \\\"{x:1561,y:654,t:1527271882813};\\\", \\\"{x:1521,y:645,t:1527271882830};\\\", \\\"{x:1464,y:633,t:1527271882847};\\\", \\\"{x:1416,y:619,t:1527271882864};\\\", \\\"{x:1369,y:607,t:1527271882880};\\\", \\\"{x:1339,y:597,t:1527271882897};\\\", \\\"{x:1322,y:590,t:1527271882914};\\\", \\\"{x:1305,y:580,t:1527271882930};\\\", \\\"{x:1288,y:569,t:1527271882947};\\\", \\\"{x:1284,y:567,t:1527271882964};\\\", \\\"{x:1284,y:565,t:1527271882983};\\\", \\\"{x:1284,y:563,t:1527271882997};\\\", \\\"{x:1281,y:558,t:1527271883014};\\\", \\\"{x:1277,y:551,t:1527271883030};\\\", \\\"{x:1275,y:546,t:1527271883047};\\\", \\\"{x:1275,y:543,t:1527271883064};\\\", \\\"{x:1282,y:539,t:1527271883080};\\\", \\\"{x:1287,y:535,t:1527271883097};\\\", \\\"{x:1288,y:531,t:1527271883114};\\\", \\\"{x:1288,y:527,t:1527271883130};\\\", \\\"{x:1288,y:523,t:1527271883147};\\\", \\\"{x:1288,y:520,t:1527271883164};\\\", \\\"{x:1289,y:519,t:1527271883180};\\\", \\\"{x:1293,y:517,t:1527271883197};\\\", \\\"{x:1297,y:515,t:1527271883214};\\\", \\\"{x:1300,y:514,t:1527271883231};\\\", \\\"{x:1301,y:513,t:1527271883279};\\\", \\\"{x:1302,y:513,t:1527271883327};\\\", \\\"{x:1303,y:511,t:1527271883350};\\\", \\\"{x:1303,y:510,t:1527271883364};\\\", \\\"{x:1303,y:509,t:1527271883381};\\\", \\\"{x:1303,y:508,t:1527271883397};\\\", \\\"{x:1303,y:507,t:1527271883414};\\\", \\\"{x:1306,y:505,t:1527271883431};\\\", \\\"{x:1306,y:504,t:1527271883447};\\\", \\\"{x:1306,y:503,t:1527271883464};\\\", \\\"{x:1306,y:501,t:1527271883511};\\\", \\\"{x:1307,y:501,t:1527271883526};\\\", \\\"{x:1308,y:500,t:1527271883543};\\\", \\\"{x:1309,y:499,t:1527271883552};\\\", \\\"{x:1309,y:498,t:1527271883581};\\\", \\\"{x:1310,y:496,t:1527271887959};\\\", \\\"{x:1316,y:491,t:1527271887966};\\\", \\\"{x:1330,y:480,t:1527271887986};\\\", \\\"{x:1330,y:479,t:1527271888000};\\\", \\\"{x:1329,y:479,t:1527271888799};\\\", \\\"{x:1327,y:479,t:1527271888807};\\\", \\\"{x:1325,y:480,t:1527271888818};\\\", \\\"{x:1317,y:482,t:1527271888834};\\\", \\\"{x:1300,y:488,t:1527271888852};\\\", \\\"{x:1274,y:496,t:1527271888868};\\\", \\\"{x:1249,y:505,t:1527271888884};\\\", \\\"{x:1233,y:511,t:1527271888901};\\\", \\\"{x:1226,y:512,t:1527271888918};\\\", \\\"{x:1225,y:513,t:1527271888934};\\\", \\\"{x:1224,y:513,t:1527271888951};\\\", \\\"{x:1222,y:513,t:1527271888969};\\\", \\\"{x:1224,y:513,t:1527271889022};\\\", \\\"{x:1226,y:513,t:1527271889035};\\\", \\\"{x:1228,y:512,t:1527271889052};\\\", \\\"{x:1230,y:511,t:1527271889068};\\\", \\\"{x:1231,y:511,t:1527271889085};\\\", \\\"{x:1232,y:510,t:1527271889647};\\\", \\\"{x:1233,y:510,t:1527271889759};\\\", \\\"{x:1234,y:510,t:1527271889768};\\\", \\\"{x:1238,y:509,t:1527271889785};\\\", \\\"{x:1241,y:508,t:1527271889802};\\\", \\\"{x:1248,y:506,t:1527271889818};\\\", \\\"{x:1261,y:502,t:1527271889835};\\\", \\\"{x:1269,y:499,t:1527271889853};\\\", \\\"{x:1274,y:498,t:1527271889868};\\\", \\\"{x:1279,y:496,t:1527271889885};\\\", \\\"{x:1286,y:494,t:1527271889903};\\\", \\\"{x:1291,y:492,t:1527271889918};\\\", \\\"{x:1295,y:489,t:1527271889935};\\\", \\\"{x:1302,y:485,t:1527271889952};\\\", \\\"{x:1306,y:485,t:1527271889969};\\\", \\\"{x:1307,y:484,t:1527271889985};\\\", \\\"{x:1309,y:483,t:1527271890287};\\\", \\\"{x:1310,y:483,t:1527271890503};\\\", \\\"{x:1311,y:484,t:1527271890575};\\\", \\\"{x:1311,y:485,t:1527271890587};\\\", \\\"{x:1311,y:486,t:1527271890602};\\\", \\\"{x:1313,y:489,t:1527271890620};\\\", \\\"{x:1314,y:490,t:1527271890637};\\\", \\\"{x:1315,y:491,t:1527271890653};\\\", \\\"{x:1315,y:492,t:1527271890670};\\\", \\\"{x:1316,y:493,t:1527271890686};\\\", \\\"{x:1316,y:494,t:1527271895866};\\\", \\\"{x:1316,y:495,t:1527271895877};\\\", \\\"{x:1317,y:496,t:1527271895930};\\\", \\\"{x:1317,y:497,t:1527271900434};\\\", \\\"{x:1317,y:499,t:1527271900446};\\\", \\\"{x:1317,y:517,t:1527271900464};\\\", \\\"{x:1317,y:524,t:1527271900480};\\\", \\\"{x:1317,y:532,t:1527271900497};\\\", \\\"{x:1319,y:545,t:1527271900513};\\\", \\\"{x:1327,y:576,t:1527271900530};\\\", \\\"{x:1336,y:601,t:1527271900547};\\\", \\\"{x:1341,y:622,t:1527271900563};\\\", \\\"{x:1344,y:639,t:1527271900580};\\\", \\\"{x:1346,y:640,t:1527271900597};\\\", \\\"{x:1346,y:641,t:1527271901043};\\\", \\\"{x:1345,y:642,t:1527271901082};\\\", \\\"{x:1345,y:644,t:1527271901098};\\\", \\\"{x:1345,y:659,t:1527271901114};\\\", \\\"{x:1345,y:674,t:1527271901131};\\\", \\\"{x:1348,y:693,t:1527271901148};\\\", \\\"{x:1351,y:711,t:1527271901165};\\\", \\\"{x:1351,y:732,t:1527271901181};\\\", \\\"{x:1351,y:748,t:1527271901198};\\\", \\\"{x:1347,y:765,t:1527271901215};\\\", \\\"{x:1346,y:776,t:1527271901230};\\\", \\\"{x:1346,y:783,t:1527271901247};\\\", \\\"{x:1346,y:785,t:1527271901265};\\\", \\\"{x:1346,y:788,t:1527271901298};\\\", \\\"{x:1346,y:789,t:1527271901314};\\\", \\\"{x:1344,y:793,t:1527271901331};\\\", \\\"{x:1344,y:794,t:1527271902138};\\\", \\\"{x:1343,y:795,t:1527271902154};\\\", \\\"{x:1342,y:800,t:1527271902164};\\\", \\\"{x:1339,y:806,t:1527271902181};\\\", \\\"{x:1339,y:808,t:1527271902198};\\\", \\\"{x:1339,y:811,t:1527271902214};\\\", \\\"{x:1338,y:813,t:1527271902230};\\\", \\\"{x:1338,y:816,t:1527271902248};\\\", \\\"{x:1338,y:820,t:1527271902264};\\\", \\\"{x:1336,y:831,t:1527271902281};\\\", \\\"{x:1336,y:837,t:1527271902297};\\\", \\\"{x:1336,y:841,t:1527271902314};\\\", \\\"{x:1336,y:845,t:1527271902331};\\\", \\\"{x:1336,y:848,t:1527271902348};\\\", \\\"{x:1338,y:852,t:1527271902364};\\\", \\\"{x:1339,y:858,t:1527271902381};\\\", \\\"{x:1340,y:863,t:1527271902398};\\\", \\\"{x:1340,y:868,t:1527271902414};\\\", \\\"{x:1341,y:873,t:1527271902431};\\\", \\\"{x:1342,y:879,t:1527271902449};\\\", \\\"{x:1346,y:888,t:1527271902466};\\\", \\\"{x:1349,y:897,t:1527271902482};\\\", \\\"{x:1352,y:902,t:1527271902499};\\\", \\\"{x:1353,y:907,t:1527271902515};\\\", \\\"{x:1354,y:910,t:1527271902532};\\\", \\\"{x:1355,y:913,t:1527271902548};\\\", \\\"{x:1356,y:915,t:1527271902566};\\\", \\\"{x:1357,y:921,t:1527271902581};\\\", \\\"{x:1361,y:926,t:1527271902599};\\\", \\\"{x:1363,y:935,t:1527271902615};\\\", \\\"{x:1365,y:941,t:1527271902632};\\\", \\\"{x:1365,y:945,t:1527271902649};\\\", \\\"{x:1365,y:949,t:1527271902666};\\\", \\\"{x:1365,y:950,t:1527271902682};\\\", \\\"{x:1365,y:952,t:1527271902698};\\\", \\\"{x:1365,y:953,t:1527271902716};\\\", \\\"{x:1365,y:955,t:1527271902731};\\\", \\\"{x:1365,y:957,t:1527271902749};\\\", \\\"{x:1365,y:958,t:1527271902766};\\\", \\\"{x:1365,y:960,t:1527271902818};\\\", \\\"{x:1365,y:961,t:1527271902858};\\\", \\\"{x:1364,y:961,t:1527271902866};\\\", \\\"{x:1363,y:962,t:1527271902890};\\\", \\\"{x:1363,y:963,t:1527271902947};\\\", \\\"{x:1362,y:963,t:1527271902962};\\\", \\\"{x:1361,y:964,t:1527271902986};\\\", \\\"{x:1360,y:964,t:1527271902999};\\\", \\\"{x:1360,y:965,t:1527271903018};\\\", \\\"{x:1359,y:965,t:1527271903033};\\\", \\\"{x:1358,y:965,t:1527271903315};\\\", \\\"{x:1355,y:964,t:1527271903332};\\\", \\\"{x:1353,y:956,t:1527271903349};\\\", \\\"{x:1350,y:949,t:1527271903366};\\\", \\\"{x:1350,y:944,t:1527271903383};\\\", \\\"{x:1349,y:943,t:1527271903398};\\\", \\\"{x:1348,y:940,t:1527271903415};\\\", \\\"{x:1347,y:938,t:1527271903434};\\\", \\\"{x:1347,y:937,t:1527271903450};\\\", \\\"{x:1347,y:935,t:1527271903474};\\\", \\\"{x:1347,y:934,t:1527271903482};\\\", \\\"{x:1347,y:933,t:1527271903499};\\\", \\\"{x:1347,y:932,t:1527271903516};\\\", \\\"{x:1347,y:931,t:1527271903533};\\\", \\\"{x:1346,y:930,t:1527271904442};\\\", \\\"{x:1346,y:931,t:1527271904690};\\\", \\\"{x:1346,y:933,t:1527271904699};\\\", \\\"{x:1346,y:937,t:1527271904716};\\\", \\\"{x:1346,y:940,t:1527271904733};\\\", \\\"{x:1346,y:941,t:1527271904749};\\\", \\\"{x:1346,y:943,t:1527271904785};\\\", \\\"{x:1346,y:944,t:1527271904801};\\\", \\\"{x:1346,y:946,t:1527271904826};\\\", \\\"{x:1346,y:947,t:1527271904866};\\\", \\\"{x:1346,y:943,t:1527271905066};\\\", \\\"{x:1346,y:941,t:1527271905084};\\\", \\\"{x:1346,y:937,t:1527271905101};\\\", \\\"{x:1346,y:933,t:1527271905116};\\\", \\\"{x:1348,y:928,t:1527271905134};\\\", \\\"{x:1348,y:925,t:1527271905151};\\\", \\\"{x:1348,y:920,t:1527271905167};\\\", \\\"{x:1348,y:917,t:1527271905183};\\\", \\\"{x:1348,y:915,t:1527271905201};\\\", \\\"{x:1348,y:912,t:1527271905217};\\\", \\\"{x:1349,y:908,t:1527271905234};\\\", \\\"{x:1349,y:906,t:1527271905251};\\\", \\\"{x:1350,y:904,t:1527271905267};\\\", \\\"{x:1350,y:903,t:1527271905284};\\\", \\\"{x:1350,y:902,t:1527271905301};\\\", \\\"{x:1350,y:901,t:1527271905317};\\\", \\\"{x:1350,y:898,t:1527271905333};\\\", \\\"{x:1350,y:896,t:1527271905350};\\\", \\\"{x:1350,y:895,t:1527271905367};\\\", \\\"{x:1350,y:893,t:1527271905394};\\\", \\\"{x:1351,y:893,t:1527271905419};\\\", \\\"{x:1351,y:892,t:1527271905434};\\\", \\\"{x:1351,y:890,t:1527271905459};\\\", \\\"{x:1351,y:889,t:1527271905481};\\\", \\\"{x:1351,y:887,t:1527271905497};\\\", \\\"{x:1352,y:887,t:1527271905505};\\\", \\\"{x:1352,y:886,t:1527271905517};\\\", \\\"{x:1354,y:882,t:1527271905533};\\\", \\\"{x:1357,y:878,t:1527271905550};\\\", \\\"{x:1359,y:875,t:1527271905567};\\\", \\\"{x:1360,y:872,t:1527271905583};\\\", \\\"{x:1361,y:869,t:1527271905600};\\\", \\\"{x:1361,y:866,t:1527271905617};\\\", \\\"{x:1361,y:863,t:1527271905633};\\\", \\\"{x:1361,y:861,t:1527271905651};\\\", \\\"{x:1361,y:860,t:1527271905673};\\\", \\\"{x:1361,y:859,t:1527271905730};\\\", \\\"{x:1361,y:857,t:1527271905738};\\\", \\\"{x:1361,y:856,t:1527271905750};\\\", \\\"{x:1361,y:853,t:1527271905768};\\\", \\\"{x:1360,y:848,t:1527271905785};\\\", \\\"{x:1360,y:844,t:1527271905800};\\\", \\\"{x:1357,y:833,t:1527271905818};\\\", \\\"{x:1351,y:817,t:1527271905834};\\\", \\\"{x:1335,y:798,t:1527271905851};\\\", \\\"{x:1322,y:783,t:1527271905868};\\\", \\\"{x:1302,y:763,t:1527271905885};\\\", \\\"{x:1289,y:748,t:1527271905901};\\\", \\\"{x:1278,y:734,t:1527271905918};\\\", \\\"{x:1272,y:723,t:1527271905935};\\\", \\\"{x:1267,y:712,t:1527271905951};\\\", \\\"{x:1262,y:700,t:1527271905968};\\\", \\\"{x:1259,y:691,t:1527271905984};\\\", \\\"{x:1259,y:685,t:1527271906000};\\\", \\\"{x:1259,y:672,t:1527271906018};\\\", \\\"{x:1259,y:659,t:1527271906034};\\\", \\\"{x:1259,y:648,t:1527271906051};\\\", \\\"{x:1259,y:638,t:1527271906067};\\\", \\\"{x:1261,y:627,t:1527271906085};\\\", \\\"{x:1261,y:617,t:1527271906101};\\\", \\\"{x:1262,y:608,t:1527271906117};\\\", \\\"{x:1262,y:601,t:1527271906135};\\\", \\\"{x:1262,y:592,t:1527271906152};\\\", \\\"{x:1264,y:578,t:1527271906167};\\\", \\\"{x:1264,y:566,t:1527271906184};\\\", \\\"{x:1264,y:552,t:1527271906200};\\\", \\\"{x:1263,y:532,t:1527271906217};\\\", \\\"{x:1263,y:523,t:1527271906234};\\\", \\\"{x:1263,y:514,t:1527271906251};\\\", \\\"{x:1263,y:509,t:1527271906268};\\\", \\\"{x:1263,y:507,t:1527271906284};\\\", \\\"{x:1263,y:505,t:1527271906302};\\\", \\\"{x:1263,y:504,t:1527271906317};\\\", \\\"{x:1264,y:504,t:1527271906442};\\\", \\\"{x:1265,y:504,t:1527271906466};\\\", \\\"{x:1268,y:508,t:1527271906482};\\\", \\\"{x:1274,y:526,t:1527271906490};\\\", \\\"{x:1275,y:538,t:1527271906501};\\\", \\\"{x:1282,y:556,t:1527271906517};\\\", \\\"{x:1286,y:569,t:1527271906534};\\\", \\\"{x:1291,y:579,t:1527271906551};\\\", \\\"{x:1295,y:596,t:1527271906567};\\\", \\\"{x:1296,y:616,t:1527271906584};\\\", \\\"{x:1297,y:643,t:1527271906601};\\\", \\\"{x:1297,y:662,t:1527271906617};\\\", \\\"{x:1297,y:683,t:1527271906634};\\\", \\\"{x:1297,y:704,t:1527271906651};\\\", \\\"{x:1297,y:719,t:1527271906667};\\\", \\\"{x:1297,y:741,t:1527271906685};\\\", \\\"{x:1302,y:763,t:1527271906701};\\\", \\\"{x:1308,y:783,t:1527271906718};\\\", \\\"{x:1310,y:793,t:1527271906734};\\\", \\\"{x:1310,y:806,t:1527271906751};\\\", \\\"{x:1311,y:817,t:1527271906767};\\\", \\\"{x:1315,y:835,t:1527271906784};\\\", \\\"{x:1324,y:860,t:1527271906802};\\\", \\\"{x:1331,y:876,t:1527271906818};\\\", \\\"{x:1336,y:889,t:1527271906835};\\\", \\\"{x:1339,y:896,t:1527271906851};\\\", \\\"{x:1341,y:902,t:1527271906869};\\\", \\\"{x:1348,y:914,t:1527271906884};\\\", \\\"{x:1352,y:922,t:1527271906902};\\\", \\\"{x:1356,y:932,t:1527271906918};\\\", \\\"{x:1362,y:944,t:1527271906934};\\\", \\\"{x:1366,y:951,t:1527271906951};\\\", \\\"{x:1367,y:954,t:1527271906968};\\\", \\\"{x:1368,y:956,t:1527271906984};\\\", \\\"{x:1369,y:958,t:1527271907002};\\\", \\\"{x:1369,y:959,t:1527271907019};\\\", \\\"{x:1370,y:960,t:1527271907035};\\\", \\\"{x:1370,y:961,t:1527271907058};\\\", \\\"{x:1370,y:962,t:1527271907082};\\\", \\\"{x:1369,y:963,t:1527271907106};\\\", \\\"{x:1365,y:963,t:1527271907119};\\\", \\\"{x:1354,y:958,t:1527271907135};\\\", \\\"{x:1351,y:958,t:1527271907152};\\\", \\\"{x:1350,y:957,t:1527271907169};\\\", \\\"{x:1349,y:957,t:1527271907226};\\\", \\\"{x:1349,y:956,t:1527271907242};\\\", \\\"{x:1349,y:952,t:1527271907418};\\\", \\\"{x:1345,y:937,t:1527271907436};\\\", \\\"{x:1344,y:922,t:1527271907452};\\\", \\\"{x:1344,y:907,t:1527271907469};\\\", \\\"{x:1343,y:900,t:1527271907486};\\\", \\\"{x:1343,y:894,t:1527271907501};\\\", \\\"{x:1343,y:893,t:1527271907518};\\\", \\\"{x:1343,y:892,t:1527271907535};\\\", \\\"{x:1344,y:891,t:1527271907601};\\\", \\\"{x:1344,y:894,t:1527271907658};\\\", \\\"{x:1343,y:900,t:1527271907669};\\\", \\\"{x:1340,y:909,t:1527271907686};\\\", \\\"{x:1339,y:917,t:1527271907702};\\\", \\\"{x:1338,y:926,t:1527271907719};\\\", \\\"{x:1337,y:932,t:1527271907736};\\\", \\\"{x:1337,y:936,t:1527271907752};\\\", \\\"{x:1336,y:941,t:1527271907768};\\\", \\\"{x:1335,y:946,t:1527271907785};\\\", \\\"{x:1335,y:948,t:1527271907803};\\\", \\\"{x:1335,y:950,t:1527271907819};\\\", \\\"{x:1333,y:952,t:1527271907836};\\\", \\\"{x:1329,y:954,t:1527271907853};\\\", \\\"{x:1325,y:956,t:1527271907869};\\\", \\\"{x:1319,y:958,t:1527271907886};\\\", \\\"{x:1313,y:962,t:1527271907903};\\\", \\\"{x:1310,y:963,t:1527271907919};\\\", \\\"{x:1305,y:964,t:1527271907936};\\\", \\\"{x:1301,y:967,t:1527271907953};\\\", \\\"{x:1297,y:968,t:1527271907969};\\\", \\\"{x:1290,y:972,t:1527271907986};\\\", \\\"{x:1288,y:974,t:1527271908002};\\\", \\\"{x:1287,y:975,t:1527271908019};\\\", \\\"{x:1284,y:975,t:1527271908035};\\\", \\\"{x:1282,y:975,t:1527271908053};\\\", \\\"{x:1284,y:975,t:1527271908138};\\\", \\\"{x:1288,y:973,t:1527271908153};\\\", \\\"{x:1298,y:971,t:1527271908170};\\\", \\\"{x:1303,y:969,t:1527271908187};\\\", \\\"{x:1304,y:969,t:1527271908202};\\\", \\\"{x:1304,y:968,t:1527271908266};\\\", \\\"{x:1304,y:967,t:1527271908443};\\\", \\\"{x:1304,y:965,t:1527271908453};\\\", \\\"{x:1304,y:959,t:1527271908469};\\\", \\\"{x:1305,y:954,t:1527271908486};\\\", \\\"{x:1305,y:950,t:1527271908503};\\\", \\\"{x:1307,y:945,t:1527271908520};\\\", \\\"{x:1307,y:940,t:1527271908536};\\\", \\\"{x:1307,y:935,t:1527271908553};\\\", \\\"{x:1307,y:929,t:1527271908570};\\\", \\\"{x:1307,y:925,t:1527271908586};\\\", \\\"{x:1307,y:922,t:1527271908603};\\\", \\\"{x:1307,y:918,t:1527271908620};\\\", \\\"{x:1307,y:913,t:1527271908637};\\\", \\\"{x:1307,y:910,t:1527271908653};\\\", \\\"{x:1306,y:904,t:1527271908670};\\\", \\\"{x:1306,y:901,t:1527271908686};\\\", \\\"{x:1306,y:897,t:1527271908703};\\\", \\\"{x:1306,y:896,t:1527271908720};\\\", \\\"{x:1306,y:893,t:1527271908736};\\\", \\\"{x:1305,y:891,t:1527271908752};\\\", \\\"{x:1305,y:889,t:1527271908769};\\\", \\\"{x:1305,y:887,t:1527271908786};\\\", \\\"{x:1305,y:884,t:1527271908803};\\\", \\\"{x:1305,y:880,t:1527271908820};\\\", \\\"{x:1305,y:876,t:1527271908836};\\\", \\\"{x:1305,y:871,t:1527271908852};\\\", \\\"{x:1305,y:865,t:1527271908869};\\\", \\\"{x:1305,y:859,t:1527271908886};\\\", \\\"{x:1305,y:852,t:1527271908902};\\\", \\\"{x:1305,y:845,t:1527271908919};\\\", \\\"{x:1304,y:837,t:1527271908936};\\\", \\\"{x:1303,y:829,t:1527271908953};\\\", \\\"{x:1303,y:822,t:1527271908969};\\\", \\\"{x:1303,y:818,t:1527271908986};\\\", \\\"{x:1304,y:809,t:1527271909003};\\\", \\\"{x:1305,y:805,t:1527271909019};\\\", \\\"{x:1305,y:797,t:1527271909037};\\\", \\\"{x:1306,y:793,t:1527271909053};\\\", \\\"{x:1306,y:789,t:1527271909070};\\\", \\\"{x:1306,y:787,t:1527271909087};\\\", \\\"{x:1306,y:784,t:1527271909104};\\\", \\\"{x:1306,y:783,t:1527271909119};\\\", \\\"{x:1306,y:780,t:1527271909137};\\\", \\\"{x:1306,y:778,t:1527271909154};\\\", \\\"{x:1306,y:777,t:1527271909170};\\\", \\\"{x:1306,y:775,t:1527271909187};\\\", \\\"{x:1307,y:773,t:1527271909203};\\\", \\\"{x:1307,y:771,t:1527271909220};\\\", \\\"{x:1308,y:765,t:1527271909237};\\\", \\\"{x:1308,y:761,t:1527271909253};\\\", \\\"{x:1308,y:756,t:1527271909270};\\\", \\\"{x:1308,y:747,t:1527271909287};\\\", \\\"{x:1308,y:739,t:1527271909303};\\\", \\\"{x:1308,y:732,t:1527271909320};\\\", \\\"{x:1308,y:724,t:1527271909336};\\\", \\\"{x:1311,y:715,t:1527271909354};\\\", \\\"{x:1312,y:712,t:1527271909369};\\\", \\\"{x:1312,y:711,t:1527271909387};\\\", \\\"{x:1313,y:709,t:1527271909403};\\\", \\\"{x:1313,y:708,t:1527271909419};\\\", \\\"{x:1314,y:705,t:1527271909437};\\\", \\\"{x:1315,y:704,t:1527271909454};\\\", \\\"{x:1315,y:703,t:1527271909474};\\\", \\\"{x:1316,y:702,t:1527271909530};\\\", \\\"{x:1316,y:701,t:1527271909538};\\\", \\\"{x:1317,y:693,t:1527271909554};\\\", \\\"{x:1318,y:692,t:1527271909570};\\\", \\\"{x:1318,y:691,t:1527271909587};\\\", \\\"{x:1318,y:690,t:1527271909682};\\\", \\\"{x:1319,y:684,t:1527271909946};\\\", \\\"{x:1319,y:677,t:1527271909954};\\\", \\\"{x:1319,y:669,t:1527271909971};\\\", \\\"{x:1318,y:664,t:1527271909987};\\\", \\\"{x:1315,y:657,t:1527271910004};\\\", \\\"{x:1310,y:646,t:1527271910021};\\\", \\\"{x:1306,y:639,t:1527271910037};\\\", \\\"{x:1304,y:635,t:1527271910054};\\\", \\\"{x:1304,y:628,t:1527271910071};\\\", \\\"{x:1304,y:625,t:1527271910088};\\\", \\\"{x:1303,y:621,t:1527271910104};\\\", \\\"{x:1300,y:617,t:1527271910121};\\\", \\\"{x:1298,y:610,t:1527271910138};\\\", \\\"{x:1296,y:605,t:1527271910154};\\\", \\\"{x:1296,y:602,t:1527271910170};\\\", \\\"{x:1296,y:598,t:1527271910188};\\\", \\\"{x:1293,y:594,t:1527271910204};\\\", \\\"{x:1291,y:588,t:1527271910221};\\\", \\\"{x:1290,y:583,t:1527271910238};\\\", \\\"{x:1290,y:578,t:1527271910254};\\\", \\\"{x:1289,y:572,t:1527271910271};\\\", \\\"{x:1289,y:567,t:1527271910287};\\\", \\\"{x:1289,y:561,t:1527271910304};\\\", \\\"{x:1289,y:558,t:1527271910320};\\\", \\\"{x:1295,y:551,t:1527271910338};\\\", \\\"{x:1296,y:548,t:1527271910354};\\\", \\\"{x:1298,y:543,t:1527271910371};\\\", \\\"{x:1299,y:541,t:1527271910388};\\\", \\\"{x:1299,y:537,t:1527271910404};\\\", \\\"{x:1300,y:535,t:1527271910421};\\\", \\\"{x:1302,y:533,t:1527271910438};\\\", \\\"{x:1303,y:531,t:1527271910454};\\\", \\\"{x:1305,y:525,t:1527271910471};\\\", \\\"{x:1306,y:520,t:1527271910488};\\\", \\\"{x:1307,y:515,t:1527271910504};\\\", \\\"{x:1309,y:512,t:1527271910520};\\\", \\\"{x:1309,y:509,t:1527271910537};\\\", \\\"{x:1309,y:508,t:1527271910555};\\\", \\\"{x:1309,y:507,t:1527271910570};\\\", \\\"{x:1309,y:506,t:1527271910609};\\\", \\\"{x:1310,y:506,t:1527271910626};\\\", \\\"{x:1310,y:504,t:1527271910658};\\\", \\\"{x:1310,y:503,t:1527271910673};\\\", \\\"{x:1310,y:501,t:1527271910697};\\\", \\\"{x:1310,y:500,t:1527271910721};\\\", \\\"{x:1310,y:498,t:1527271910754};\\\", \\\"{x:1310,y:497,t:1527271912282};\\\", \\\"{x:1309,y:497,t:1527271924914};\\\", \\\"{x:1308,y:507,t:1527271924947};\\\", \\\"{x:1307,y:515,t:1527271924954};\\\", \\\"{x:1305,y:521,t:1527271924965};\\\", \\\"{x:1304,y:527,t:1527271924982};\\\", \\\"{x:1304,y:532,t:1527271924998};\\\", \\\"{x:1303,y:534,t:1527271925015};\\\", \\\"{x:1303,y:536,t:1527271925031};\\\", \\\"{x:1303,y:539,t:1527271925049};\\\", \\\"{x:1303,y:544,t:1527271925066};\\\", \\\"{x:1303,y:548,t:1527271925081};\\\", \\\"{x:1303,y:551,t:1527271925098};\\\", \\\"{x:1303,y:556,t:1527271925115};\\\", \\\"{x:1303,y:561,t:1527271925131};\\\", \\\"{x:1303,y:567,t:1527271925148};\\\", \\\"{x:1303,y:572,t:1527271925165};\\\", \\\"{x:1304,y:578,t:1527271925181};\\\", \\\"{x:1304,y:582,t:1527271925198};\\\", \\\"{x:1305,y:587,t:1527271925215};\\\", \\\"{x:1305,y:592,t:1527271925232};\\\", \\\"{x:1305,y:596,t:1527271925249};\\\", \\\"{x:1308,y:602,t:1527271925266};\\\", \\\"{x:1308,y:606,t:1527271925281};\\\", \\\"{x:1309,y:611,t:1527271925298};\\\", \\\"{x:1312,y:618,t:1527271925316};\\\", \\\"{x:1316,y:626,t:1527271925333};\\\", \\\"{x:1318,y:630,t:1527271925349};\\\", \\\"{x:1321,y:635,t:1527271925367};\\\", \\\"{x:1322,y:638,t:1527271925382};\\\", \\\"{x:1324,y:641,t:1527271925398};\\\", \\\"{x:1325,y:641,t:1527271925415};\\\", \\\"{x:1325,y:642,t:1527271925433};\\\", \\\"{x:1325,y:641,t:1527271925738};\\\", \\\"{x:1325,y:640,t:1527271925750};\\\", \\\"{x:1324,y:639,t:1527271925786};\\\", \\\"{x:1323,y:639,t:1527271925802};\\\", \\\"{x:1323,y:638,t:1527271925815};\\\", \\\"{x:1320,y:636,t:1527271925833};\\\", \\\"{x:1319,y:635,t:1527271925866};\\\", \\\"{x:1318,y:635,t:1527271927226};\\\", \\\"{x:1316,y:635,t:1527271927234};\\\", \\\"{x:1309,y:642,t:1527271927250};\\\", \\\"{x:1305,y:650,t:1527271927267};\\\", \\\"{x:1302,y:656,t:1527271927283};\\\", \\\"{x:1299,y:663,t:1527271927301};\\\", \\\"{x:1297,y:668,t:1527271927316};\\\", \\\"{x:1296,y:676,t:1527271927334};\\\", \\\"{x:1295,y:687,t:1527271927351};\\\", \\\"{x:1292,y:702,t:1527271927366};\\\", \\\"{x:1292,y:720,t:1527271927384};\\\", \\\"{x:1292,y:735,t:1527271927400};\\\", \\\"{x:1294,y:762,t:1527271927417};\\\", \\\"{x:1299,y:811,t:1527271927433};\\\", \\\"{x:1300,y:829,t:1527271927450};\\\", \\\"{x:1301,y:839,t:1527271927466};\\\", \\\"{x:1301,y:841,t:1527271927483};\\\", \\\"{x:1303,y:836,t:1527271928706};\\\", \\\"{x:1304,y:832,t:1527271928722};\\\", \\\"{x:1304,y:830,t:1527271928735};\\\", \\\"{x:1305,y:823,t:1527271928751};\\\", \\\"{x:1309,y:808,t:1527271928767};\\\", \\\"{x:1319,y:785,t:1527271928783};\\\", \\\"{x:1339,y:757,t:1527271928800};\\\", \\\"{x:1354,y:740,t:1527271928817};\\\", \\\"{x:1365,y:719,t:1527271928834};\\\", \\\"{x:1369,y:709,t:1527271928851};\\\", \\\"{x:1371,y:697,t:1527271928867};\\\", \\\"{x:1374,y:688,t:1527271928884};\\\", \\\"{x:1376,y:680,t:1527271928901};\\\", \\\"{x:1378,y:673,t:1527271928917};\\\", \\\"{x:1379,y:666,t:1527271928934};\\\", \\\"{x:1379,y:656,t:1527271928952};\\\", \\\"{x:1371,y:641,t:1527271928967};\\\", \\\"{x:1366,y:629,t:1527271928984};\\\", \\\"{x:1360,y:616,t:1527271929001};\\\", \\\"{x:1356,y:609,t:1527271929018};\\\", \\\"{x:1356,y:604,t:1527271929034};\\\", \\\"{x:1356,y:600,t:1527271929051};\\\", \\\"{x:1353,y:594,t:1527271929068};\\\", \\\"{x:1353,y:592,t:1527271929084};\\\", \\\"{x:1352,y:591,t:1527271929137};\\\", \\\"{x:1352,y:596,t:1527271929242};\\\", \\\"{x:1352,y:599,t:1527271929251};\\\", \\\"{x:1352,y:606,t:1527271929268};\\\", \\\"{x:1352,y:610,t:1527271929285};\\\", \\\"{x:1354,y:616,t:1527271929302};\\\", \\\"{x:1356,y:627,t:1527271929318};\\\", \\\"{x:1358,y:632,t:1527271929335};\\\", \\\"{x:1361,y:638,t:1527271929351};\\\", \\\"{x:1364,y:645,t:1527271929369};\\\", \\\"{x:1367,y:652,t:1527271929385};\\\", \\\"{x:1368,y:658,t:1527271929402};\\\", \\\"{x:1369,y:660,t:1527271929419};\\\", \\\"{x:1371,y:666,t:1527271929435};\\\", \\\"{x:1373,y:670,t:1527271929452};\\\", \\\"{x:1374,y:672,t:1527271929469};\\\", \\\"{x:1374,y:674,t:1527271929484};\\\", \\\"{x:1374,y:675,t:1527271929546};\\\", \\\"{x:1375,y:677,t:1527271929553};\\\", \\\"{x:1377,y:680,t:1527271929569};\\\", \\\"{x:1379,y:685,t:1527271929585};\\\", \\\"{x:1380,y:687,t:1527271929602};\\\", \\\"{x:1381,y:690,t:1527271929619};\\\", \\\"{x:1382,y:693,t:1527271929635};\\\", \\\"{x:1385,y:696,t:1527271929652};\\\", \\\"{x:1389,y:701,t:1527271929669};\\\", \\\"{x:1393,y:708,t:1527271929685};\\\", \\\"{x:1397,y:711,t:1527271929702};\\\", \\\"{x:1401,y:716,t:1527271929718};\\\", \\\"{x:1402,y:719,t:1527271929736};\\\", \\\"{x:1403,y:720,t:1527271929752};\\\", \\\"{x:1403,y:721,t:1527271929778};\\\", \\\"{x:1404,y:722,t:1527271929793};\\\", \\\"{x:1404,y:723,t:1527271929801};\\\", \\\"{x:1408,y:729,t:1527271929819};\\\", \\\"{x:1409,y:733,t:1527271929835};\\\", \\\"{x:1412,y:737,t:1527271929851};\\\", \\\"{x:1413,y:740,t:1527271929869};\\\", \\\"{x:1416,y:743,t:1527271929885};\\\", \\\"{x:1420,y:751,t:1527271929902};\\\", \\\"{x:1425,y:760,t:1527271929918};\\\", \\\"{x:1429,y:766,t:1527271929935};\\\", \\\"{x:1433,y:775,t:1527271929951};\\\", \\\"{x:1435,y:779,t:1527271929969};\\\", \\\"{x:1437,y:789,t:1527271929986};\\\", \\\"{x:1440,y:796,t:1527271930002};\\\", \\\"{x:1442,y:800,t:1527271930019};\\\", \\\"{x:1443,y:803,t:1527271930036};\\\", \\\"{x:1444,y:805,t:1527271930053};\\\", \\\"{x:1445,y:806,t:1527271930069};\\\", \\\"{x:1447,y:808,t:1527271930086};\\\", \\\"{x:1449,y:809,t:1527271930103};\\\", \\\"{x:1451,y:810,t:1527271930119};\\\", \\\"{x:1452,y:811,t:1527271930135};\\\", \\\"{x:1453,y:812,t:1527271930152};\\\", \\\"{x:1454,y:813,t:1527271930186};\\\", \\\"{x:1458,y:815,t:1527271930203};\\\", \\\"{x:1459,y:816,t:1527271930218};\\\", \\\"{x:1461,y:817,t:1527271930235};\\\", \\\"{x:1462,y:817,t:1527271930386};\\\", \\\"{x:1463,y:823,t:1527271930403};\\\", \\\"{x:1464,y:829,t:1527271930419};\\\", \\\"{x:1464,y:835,t:1527271930436};\\\", \\\"{x:1465,y:842,t:1527271930453};\\\", \\\"{x:1467,y:849,t:1527271930468};\\\", \\\"{x:1470,y:856,t:1527271930486};\\\", \\\"{x:1472,y:863,t:1527271930503};\\\", \\\"{x:1474,y:867,t:1527271930520};\\\", \\\"{x:1476,y:872,t:1527271930536};\\\", \\\"{x:1476,y:873,t:1527271930552};\\\", \\\"{x:1477,y:875,t:1527271930570};\\\", \\\"{x:1478,y:878,t:1527271930586};\\\", \\\"{x:1480,y:882,t:1527271930603};\\\", \\\"{x:1480,y:886,t:1527271930619};\\\", \\\"{x:1481,y:889,t:1527271930636};\\\", \\\"{x:1481,y:892,t:1527271930653};\\\", \\\"{x:1482,y:895,t:1527271930670};\\\", \\\"{x:1484,y:896,t:1527271930686};\\\", \\\"{x:1484,y:897,t:1527271930703};\\\", \\\"{x:1484,y:898,t:1527271930720};\\\", \\\"{x:1485,y:899,t:1527271930735};\\\", \\\"{x:1486,y:900,t:1527271930753};\\\", \\\"{x:1486,y:902,t:1527271930770};\\\", \\\"{x:1487,y:904,t:1527271930786};\\\", \\\"{x:1488,y:908,t:1527271930803};\\\", \\\"{x:1490,y:912,t:1527271930819};\\\", \\\"{x:1490,y:915,t:1527271930835};\\\", \\\"{x:1491,y:918,t:1527271930853};\\\", \\\"{x:1491,y:920,t:1527271930870};\\\", \\\"{x:1491,y:922,t:1527271930885};\\\", \\\"{x:1492,y:924,t:1527271930903};\\\", \\\"{x:1493,y:927,t:1527271930919};\\\", \\\"{x:1493,y:928,t:1527271930936};\\\", \\\"{x:1494,y:930,t:1527271930953};\\\", \\\"{x:1494,y:931,t:1527271930970};\\\", \\\"{x:1494,y:934,t:1527271930986};\\\", \\\"{x:1496,y:938,t:1527271931002};\\\", \\\"{x:1497,y:943,t:1527271931020};\\\", \\\"{x:1497,y:945,t:1527271931037};\\\", \\\"{x:1497,y:946,t:1527271931053};\\\", \\\"{x:1497,y:948,t:1527271931070};\\\", \\\"{x:1497,y:950,t:1527271931086};\\\", \\\"{x:1497,y:955,t:1527271931103};\\\", \\\"{x:1498,y:959,t:1527271931120};\\\", \\\"{x:1497,y:963,t:1527271931137};\\\", \\\"{x:1495,y:965,t:1527271931153};\\\", \\\"{x:1491,y:966,t:1527271931170};\\\", \\\"{x:1490,y:966,t:1527271931202};\\\", \\\"{x:1490,y:967,t:1527271931250};\\\", \\\"{x:1490,y:969,t:1527271931258};\\\", \\\"{x:1491,y:969,t:1527271931270};\\\", \\\"{x:1494,y:970,t:1527271931286};\\\", \\\"{x:1497,y:971,t:1527271931302};\\\", \\\"{x:1498,y:972,t:1527271931320};\\\", \\\"{x:1498,y:970,t:1527271932146};\\\", \\\"{x:1498,y:960,t:1527271932154};\\\", \\\"{x:1498,y:949,t:1527271932171};\\\", \\\"{x:1498,y:937,t:1527271932186};\\\", \\\"{x:1499,y:924,t:1527271932203};\\\", \\\"{x:1500,y:914,t:1527271932220};\\\", \\\"{x:1500,y:904,t:1527271932237};\\\", \\\"{x:1500,y:893,t:1527271932253};\\\", \\\"{x:1500,y:884,t:1527271932271};\\\", \\\"{x:1501,y:876,t:1527271932287};\\\", \\\"{x:1501,y:867,t:1527271932303};\\\", \\\"{x:1502,y:855,t:1527271932321};\\\", \\\"{x:1504,y:849,t:1527271932337};\\\", \\\"{x:1504,y:846,t:1527271932354};\\\", \\\"{x:1504,y:843,t:1527271932371};\\\", \\\"{x:1504,y:842,t:1527271932388};\\\", \\\"{x:1504,y:838,t:1527271932404};\\\", \\\"{x:1504,y:835,t:1527271932420};\\\", \\\"{x:1504,y:833,t:1527271932437};\\\", \\\"{x:1503,y:833,t:1527271932474};\\\", \\\"{x:1501,y:833,t:1527271932497};\\\", \\\"{x:1495,y:832,t:1527271932506};\\\", \\\"{x:1488,y:831,t:1527271932520};\\\", \\\"{x:1437,y:821,t:1527271932537};\\\", \\\"{x:1387,y:813,t:1527271932553};\\\", \\\"{x:1294,y:791,t:1527271932570};\\\", \\\"{x:1188,y:776,t:1527271932587};\\\", \\\"{x:1073,y:753,t:1527271932603};\\\", \\\"{x:958,y:728,t:1527271932620};\\\", \\\"{x:831,y:692,t:1527271932637};\\\", \\\"{x:707,y:656,t:1527271932654};\\\", \\\"{x:593,y:625,t:1527271932671};\\\", \\\"{x:506,y:590,t:1527271932688};\\\", \\\"{x:468,y:570,t:1527271932708};\\\", \\\"{x:465,y:569,t:1527271932723};\\\", \\\"{x:464,y:568,t:1527271932740};\\\", \\\"{x:464,y:567,t:1527271932757};\\\", \\\"{x:466,y:566,t:1527271932774};\\\", \\\"{x:468,y:565,t:1527271932791};\\\", \\\"{x:466,y:565,t:1527271932929};\\\", \\\"{x:461,y:565,t:1527271932941};\\\", \\\"{x:447,y:572,t:1527271932957};\\\", \\\"{x:434,y:578,t:1527271932974};\\\", \\\"{x:421,y:579,t:1527271932991};\\\", \\\"{x:411,y:583,t:1527271933008};\\\", \\\"{x:401,y:584,t:1527271933025};\\\", \\\"{x:389,y:587,t:1527271933041};\\\", \\\"{x:378,y:589,t:1527271933058};\\\", \\\"{x:363,y:590,t:1527271933075};\\\", \\\"{x:347,y:594,t:1527271933091};\\\", \\\"{x:331,y:596,t:1527271933108};\\\", \\\"{x:322,y:597,t:1527271933124};\\\", \\\"{x:307,y:599,t:1527271933141};\\\", \\\"{x:294,y:600,t:1527271933158};\\\", \\\"{x:291,y:600,t:1527271933174};\\\", \\\"{x:289,y:601,t:1527271933191};\\\", \\\"{x:287,y:601,t:1527271933208};\\\", \\\"{x:286,y:601,t:1527271933224};\\\", \\\"{x:285,y:601,t:1527271933241};\\\", \\\"{x:284,y:602,t:1527271933258};\\\", \\\"{x:285,y:602,t:1527271933369};\\\", \\\"{x:287,y:602,t:1527271933377};\\\", \\\"{x:290,y:602,t:1527271933391};\\\", \\\"{x:299,y:602,t:1527271933409};\\\", \\\"{x:333,y:602,t:1527271933425};\\\", \\\"{x:362,y:602,t:1527271933441};\\\", \\\"{x:396,y:602,t:1527271933460};\\\", \\\"{x:427,y:602,t:1527271933475};\\\", \\\"{x:464,y:602,t:1527271933491};\\\", \\\"{x:495,y:598,t:1527271933508};\\\", \\\"{x:529,y:598,t:1527271933525};\\\", \\\"{x:563,y:598,t:1527271933540};\\\", \\\"{x:590,y:594,t:1527271933559};\\\", \\\"{x:610,y:590,t:1527271933575};\\\", \\\"{x:636,y:589,t:1527271933591};\\\", \\\"{x:680,y:589,t:1527271933608};\\\", \\\"{x:745,y:589,t:1527271933625};\\\", \\\"{x:768,y:589,t:1527271933641};\\\", \\\"{x:782,y:585,t:1527271933659};\\\", \\\"{x:783,y:585,t:1527271933696};\\\", \\\"{x:785,y:584,t:1527271933708};\\\", \\\"{x:789,y:583,t:1527271933725};\\\", \\\"{x:792,y:583,t:1527271933742};\\\", \\\"{x:792,y:582,t:1527271933758};\\\", \\\"{x:791,y:581,t:1527271933785};\\\", \\\"{x:784,y:581,t:1527271933792};\\\", \\\"{x:773,y:580,t:1527271933809};\\\", \\\"{x:747,y:578,t:1527271933825};\\\", \\\"{x:736,y:578,t:1527271933842};\\\", \\\"{x:718,y:578,t:1527271933860};\\\", \\\"{x:709,y:578,t:1527271933875};\\\", \\\"{x:707,y:578,t:1527271933891};\\\", \\\"{x:705,y:578,t:1527271933908};\\\", \\\"{x:704,y:578,t:1527271933944};\\\", \\\"{x:703,y:578,t:1527271933958};\\\", \\\"{x:701,y:579,t:1527271933975};\\\", \\\"{x:695,y:579,t:1527271933991};\\\", \\\"{x:691,y:581,t:1527271934008};\\\", \\\"{x:687,y:582,t:1527271934024};\\\", \\\"{x:682,y:584,t:1527271934042};\\\", \\\"{x:674,y:585,t:1527271934058};\\\", \\\"{x:665,y:588,t:1527271934076};\\\", \\\"{x:660,y:590,t:1527271934093};\\\", \\\"{x:656,y:591,t:1527271934108};\\\", \\\"{x:652,y:593,t:1527271934125};\\\", \\\"{x:651,y:593,t:1527271934143};\\\", \\\"{x:650,y:593,t:1527271934169};\\\", \\\"{x:647,y:595,t:1527271934177};\\\", \\\"{x:645,y:595,t:1527271934192};\\\", \\\"{x:635,y:599,t:1527271934210};\\\", \\\"{x:628,y:601,t:1527271934225};\\\", \\\"{x:627,y:602,t:1527271934243};\\\", \\\"{x:627,y:603,t:1527271934281};\\\", \\\"{x:625,y:603,t:1527271934297};\\\", \\\"{x:623,y:604,t:1527271934309};\\\", \\\"{x:618,y:606,t:1527271934326};\\\", \\\"{x:614,y:608,t:1527271934342};\\\", \\\"{x:611,y:609,t:1527271934359};\\\", \\\"{x:611,y:610,t:1527271934375};\\\", \\\"{x:610,y:610,t:1527271934577};\\\", \\\"{x:609,y:610,t:1527271934592};\\\", \\\"{x:601,y:625,t:1527271934609};\\\", \\\"{x:598,y:632,t:1527271934626};\\\", \\\"{x:592,y:639,t:1527271934643};\\\", \\\"{x:581,y:649,t:1527271934659};\\\", \\\"{x:566,y:657,t:1527271934675};\\\", \\\"{x:554,y:665,t:1527271934693};\\\", \\\"{x:547,y:673,t:1527271934709};\\\", \\\"{x:545,y:675,t:1527271934725};\\\", \\\"{x:540,y:679,t:1527271934743};\\\", \\\"{x:533,y:685,t:1527271934759};\\\", \\\"{x:526,y:691,t:1527271934776};\\\", \\\"{x:520,y:697,t:1527271934792};\\\", \\\"{x:515,y:707,t:1527271934809};\\\", \\\"{x:512,y:712,t:1527271934826};\\\", \\\"{x:511,y:715,t:1527271934844};\\\", \\\"{x:509,y:719,t:1527271934859};\\\", \\\"{x:509,y:720,t:1527271934876};\\\", \\\"{x:508,y:722,t:1527271934892};\\\", \\\"{x:507,y:724,t:1527271934909};\\\", \\\"{x:507,y:727,t:1527271934927};\\\", \\\"{x:505,y:730,t:1527271934942};\\\", \\\"{x:505,y:733,t:1527271934960};\\\", \\\"{x:505,y:734,t:1527271934976};\\\", \\\"{x:505,y:735,t:1527271934993};\\\", \\\"{x:505,y:736,t:1527271935441};\\\", \\\"{x:505,y:737,t:1527271935465};\\\", \\\"{x:506,y:737,t:1527271935477};\\\", \\\"{x:514,y:736,t:1527271935494};\\\", \\\"{x:518,y:735,t:1527271935510};\\\", \\\"{x:520,y:734,t:1527271935527};\\\", \\\"{x:525,y:733,t:1527271935543};\\\", \\\"{x:536,y:729,t:1527271935559};\\\", \\\"{x:558,y:722,t:1527271935576};\\\", \\\"{x:602,y:709,t:1527271935593};\\\", \\\"{x:630,y:701,t:1527271935610};\\\", \\\"{x:657,y:693,t:1527271935626};\\\", \\\"{x:681,y:685,t:1527271935644};\\\", \\\"{x:705,y:675,t:1527271935660};\\\", \\\"{x:753,y:653,t:1527271935676};\\\", \\\"{x:806,y:628,t:1527271935693};\\\", \\\"{x:864,y:603,t:1527271935710};\\\", \\\"{x:882,y:585,t:1527271935727};\\\", \\\"{x:883,y:584,t:1527271935744};\\\" ] }, { \\\"rt\\\": 8714, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 890293, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:883,y:585,t:1527271939017};\\\", \\\"{x:882,y:590,t:1527271939033};\\\", \\\"{x:879,y:597,t:1527271939051};\\\", \\\"{x:877,y:604,t:1527271939066};\\\", \\\"{x:874,y:608,t:1527271939082};\\\", \\\"{x:874,y:609,t:1527271939095};\\\", \\\"{x:871,y:612,t:1527271939112};\\\", \\\"{x:871,y:614,t:1527271939136};\\\", \\\"{x:871,y:615,t:1527271939249};\\\", \\\"{x:874,y:615,t:1527271939262};\\\", \\\"{x:882,y:616,t:1527271939279};\\\", \\\"{x:892,y:616,t:1527271939297};\\\", \\\"{x:896,y:616,t:1527271939312};\\\", \\\"{x:916,y:616,t:1527271939329};\\\", \\\"{x:934,y:616,t:1527271939346};\\\", \\\"{x:960,y:613,t:1527271939363};\\\", \\\"{x:980,y:608,t:1527271939380};\\\", \\\"{x:998,y:606,t:1527271939397};\\\", \\\"{x:1021,y:602,t:1527271939413};\\\", \\\"{x:1045,y:602,t:1527271939430};\\\", \\\"{x:1070,y:602,t:1527271939447};\\\", \\\"{x:1089,y:601,t:1527271939462};\\\", \\\"{x:1102,y:598,t:1527271939480};\\\", \\\"{x:1114,y:596,t:1527271939497};\\\", \\\"{x:1121,y:593,t:1527271939513};\\\", \\\"{x:1133,y:591,t:1527271939530};\\\", \\\"{x:1145,y:590,t:1527271939547};\\\", \\\"{x:1157,y:588,t:1527271939563};\\\", \\\"{x:1165,y:586,t:1527271939579};\\\", \\\"{x:1167,y:585,t:1527271939597};\\\", \\\"{x:1173,y:584,t:1527271939614};\\\", \\\"{x:1188,y:584,t:1527271939629};\\\", \\\"{x:1213,y:584,t:1527271939647};\\\", \\\"{x:1236,y:584,t:1527271939663};\\\", \\\"{x:1257,y:583,t:1527271939680};\\\", \\\"{x:1277,y:583,t:1527271939697};\\\", \\\"{x:1287,y:583,t:1527271939713};\\\", \\\"{x:1294,y:583,t:1527271939730};\\\", \\\"{x:1304,y:583,t:1527271939747};\\\", \\\"{x:1316,y:583,t:1527271939764};\\\", \\\"{x:1324,y:583,t:1527271939779};\\\", \\\"{x:1329,y:583,t:1527271939798};\\\", \\\"{x:1330,y:583,t:1527271939814};\\\", \\\"{x:1329,y:583,t:1527271939865};\\\", \\\"{x:1327,y:583,t:1527271939880};\\\", \\\"{x:1321,y:583,t:1527271939896};\\\", \\\"{x:1303,y:583,t:1527271939913};\\\", \\\"{x:1266,y:584,t:1527271939930};\\\", \\\"{x:1197,y:584,t:1527271939947};\\\", \\\"{x:1130,y:584,t:1527271939964};\\\", \\\"{x:1063,y:584,t:1527271939980};\\\", \\\"{x:972,y:584,t:1527271939997};\\\", \\\"{x:883,y:584,t:1527271940015};\\\", \\\"{x:783,y:584,t:1527271940030};\\\", \\\"{x:680,y:584,t:1527271940047};\\\", \\\"{x:586,y:584,t:1527271940064};\\\", \\\"{x:485,y:586,t:1527271940081};\\\", \\\"{x:438,y:586,t:1527271940096};\\\", \\\"{x:403,y:586,t:1527271940113};\\\", \\\"{x:377,y:588,t:1527271940130};\\\", \\\"{x:365,y:589,t:1527271940147};\\\", \\\"{x:360,y:589,t:1527271940163};\\\", \\\"{x:358,y:589,t:1527271940180};\\\", \\\"{x:359,y:589,t:1527271940273};\\\", \\\"{x:366,y:589,t:1527271940281};\\\", \\\"{x:379,y:586,t:1527271940297};\\\", \\\"{x:388,y:584,t:1527271940314};\\\", \\\"{x:390,y:581,t:1527271940330};\\\", \\\"{x:391,y:579,t:1527271940386};\\\", \\\"{x:396,y:577,t:1527271940397};\\\", \\\"{x:407,y:574,t:1527271940414};\\\", \\\"{x:415,y:571,t:1527271940430};\\\", \\\"{x:418,y:570,t:1527271940448};\\\", \\\"{x:420,y:569,t:1527271940497};\\\", \\\"{x:426,y:568,t:1527271940514};\\\", \\\"{x:434,y:567,t:1527271940530};\\\", \\\"{x:435,y:565,t:1527271940547};\\\", \\\"{x:438,y:564,t:1527271940563};\\\", \\\"{x:439,y:564,t:1527271940581};\\\", \\\"{x:445,y:561,t:1527271940598};\\\", \\\"{x:464,y:556,t:1527271940614};\\\", \\\"{x:484,y:550,t:1527271940631};\\\", \\\"{x:501,y:544,t:1527271940648};\\\", \\\"{x:510,y:540,t:1527271940663};\\\", \\\"{x:522,y:538,t:1527271940680};\\\", \\\"{x:526,y:536,t:1527271940697};\\\", \\\"{x:528,y:535,t:1527271940713};\\\", \\\"{x:529,y:535,t:1527271940760};\\\", \\\"{x:531,y:535,t:1527271940769};\\\", \\\"{x:533,y:535,t:1527271940780};\\\", \\\"{x:535,y:533,t:1527271940798};\\\", \\\"{x:538,y:531,t:1527271940841};\\\", \\\"{x:540,y:531,t:1527271940849};\\\", \\\"{x:543,y:529,t:1527271940864};\\\", \\\"{x:548,y:527,t:1527271940880};\\\", \\\"{x:552,y:525,t:1527271940898};\\\", \\\"{x:553,y:524,t:1527271940922};\\\", \\\"{x:553,y:523,t:1527271940952};\\\", \\\"{x:553,y:521,t:1527271940963};\\\", \\\"{x:558,y:515,t:1527271940981};\\\", \\\"{x:568,y:508,t:1527271940998};\\\", \\\"{x:572,y:505,t:1527271941014};\\\", \\\"{x:572,y:503,t:1527271941031};\\\", \\\"{x:572,y:501,t:1527271941047};\\\", \\\"{x:572,y:500,t:1527271941073};\\\", \\\"{x:574,y:499,t:1527271941081};\\\", \\\"{x:576,y:498,t:1527271941097};\\\", \\\"{x:577,y:497,t:1527271941193};\\\", \\\"{x:578,y:497,t:1527271941201};\\\", \\\"{x:579,y:496,t:1527271941214};\\\", \\\"{x:583,y:495,t:1527271941231};\\\", \\\"{x:585,y:494,t:1527271941247};\\\", \\\"{x:586,y:494,t:1527271941314};\\\", \\\"{x:587,y:494,t:1527271941330};\\\", \\\"{x:588,y:493,t:1527271941553};\\\", \\\"{x:589,y:490,t:1527271941565};\\\", \\\"{x:609,y:490,t:1527271941583};\\\", \\\"{x:630,y:490,t:1527271941597};\\\", \\\"{x:655,y:490,t:1527271941614};\\\", \\\"{x:665,y:490,t:1527271941631};\\\", \\\"{x:667,y:490,t:1527271941648};\\\", \\\"{x:670,y:490,t:1527271941664};\\\", \\\"{x:683,y:490,t:1527271941682};\\\", \\\"{x:703,y:492,t:1527271941698};\\\", \\\"{x:718,y:495,t:1527271941714};\\\", \\\"{x:726,y:497,t:1527271941732};\\\", \\\"{x:728,y:497,t:1527271941776};\\\", \\\"{x:735,y:499,t:1527271941784};\\\", \\\"{x:742,y:502,t:1527271941798};\\\", \\\"{x:760,y:506,t:1527271941814};\\\", \\\"{x:772,y:508,t:1527271941831};\\\", \\\"{x:775,y:509,t:1527271941849};\\\", \\\"{x:777,y:511,t:1527271941889};\\\", \\\"{x:781,y:515,t:1527271941898};\\\", \\\"{x:792,y:520,t:1527271941916};\\\", \\\"{x:801,y:524,t:1527271941931};\\\", \\\"{x:803,y:525,t:1527271941949};\\\", \\\"{x:804,y:526,t:1527271942001};\\\", \\\"{x:806,y:527,t:1527271942015};\\\", \\\"{x:809,y:529,t:1527271942032};\\\", \\\"{x:809,y:530,t:1527271942185};\\\", \\\"{x:809,y:531,t:1527271942233};\\\", \\\"{x:810,y:531,t:1527271942273};\\\", \\\"{x:810,y:532,t:1527271942282};\\\", \\\"{x:812,y:532,t:1527271942298};\\\", \\\"{x:812,y:533,t:1527271942337};\\\", \\\"{x:812,y:534,t:1527271942353};\\\", \\\"{x:812,y:535,t:1527271942377};\\\", \\\"{x:813,y:535,t:1527271942393};\\\", \\\"{x:814,y:535,t:1527271942401};\\\", \\\"{x:815,y:535,t:1527271942416};\\\", \\\"{x:815,y:536,t:1527271942569};\\\", \\\"{x:815,y:537,t:1527271942584};\\\", \\\"{x:813,y:538,t:1527271942601};\\\", \\\"{x:812,y:538,t:1527271942615};\\\", \\\"{x:800,y:541,t:1527271942633};\\\", \\\"{x:783,y:542,t:1527271942649};\\\", \\\"{x:767,y:542,t:1527271942665};\\\", \\\"{x:758,y:542,t:1527271942683};\\\", \\\"{x:756,y:542,t:1527271942698};\\\", \\\"{x:752,y:543,t:1527271942716};\\\", \\\"{x:745,y:544,t:1527271942732};\\\", \\\"{x:729,y:544,t:1527271942748};\\\", \\\"{x:717,y:541,t:1527271942768};\\\", \\\"{x:715,y:540,t:1527271942782};\\\", \\\"{x:714,y:540,t:1527271942832};\\\", \\\"{x:711,y:538,t:1527271942849};\\\", \\\"{x:705,y:535,t:1527271942865};\\\", \\\"{x:696,y:531,t:1527271942882};\\\", \\\"{x:694,y:531,t:1527271942900};\\\", \\\"{x:693,y:531,t:1527271942937};\\\", \\\"{x:689,y:528,t:1527271942953};\\\", \\\"{x:686,y:528,t:1527271942965};\\\", \\\"{x:678,y:524,t:1527271942983};\\\", \\\"{x:677,y:523,t:1527271943000};\\\", \\\"{x:676,y:523,t:1527271943015};\\\", \\\"{x:673,y:522,t:1527271943033};\\\", \\\"{x:667,y:521,t:1527271943049};\\\", \\\"{x:655,y:518,t:1527271943066};\\\", \\\"{x:641,y:513,t:1527271943084};\\\", \\\"{x:637,y:513,t:1527271943099};\\\", \\\"{x:635,y:513,t:1527271943115};\\\", \\\"{x:633,y:513,t:1527271943144};\\\", \\\"{x:631,y:511,t:1527271943153};\\\", \\\"{x:629,y:511,t:1527271943165};\\\", \\\"{x:618,y:509,t:1527271943183};\\\", \\\"{x:616,y:509,t:1527271943199};\\\", \\\"{x:614,y:509,t:1527271943216};\\\", \\\"{x:613,y:509,t:1527271943240};\\\", \\\"{x:612,y:509,t:1527271943249};\\\", \\\"{x:607,y:509,t:1527271943266};\\\", \\\"{x:605,y:507,t:1527271943283};\\\", \\\"{x:603,y:507,t:1527271943337};\\\", \\\"{x:607,y:507,t:1527271943536};\\\", \\\"{x:615,y:508,t:1527271943549};\\\", \\\"{x:630,y:510,t:1527271943566};\\\", \\\"{x:641,y:512,t:1527271943582};\\\", \\\"{x:653,y:513,t:1527271943600};\\\", \\\"{x:682,y:517,t:1527271943617};\\\", \\\"{x:704,y:517,t:1527271943633};\\\", \\\"{x:714,y:517,t:1527271943650};\\\", \\\"{x:718,y:517,t:1527271943666};\\\", \\\"{x:721,y:517,t:1527271943682};\\\", \\\"{x:725,y:517,t:1527271943700};\\\", \\\"{x:727,y:517,t:1527271943716};\\\", \\\"{x:728,y:517,t:1527271943732};\\\", \\\"{x:731,y:517,t:1527271943749};\\\", \\\"{x:741,y:519,t:1527271943767};\\\", \\\"{x:746,y:521,t:1527271943782};\\\", \\\"{x:747,y:521,t:1527271943800};\\\", \\\"{x:753,y:523,t:1527271943816};\\\", \\\"{x:761,y:526,t:1527271943834};\\\", \\\"{x:768,y:528,t:1527271943849};\\\", \\\"{x:769,y:528,t:1527271943872};\\\", \\\"{x:770,y:529,t:1527271943888};\\\", \\\"{x:771,y:529,t:1527271943900};\\\", \\\"{x:772,y:530,t:1527271943920};\\\", \\\"{x:774,y:530,t:1527271943937};\\\", \\\"{x:778,y:531,t:1527271943949};\\\", \\\"{x:783,y:534,t:1527271943967};\\\", \\\"{x:787,y:534,t:1527271943984};\\\", \\\"{x:789,y:534,t:1527271943999};\\\", \\\"{x:791,y:535,t:1527271944016};\\\", \\\"{x:800,y:535,t:1527271944033};\\\", \\\"{x:814,y:535,t:1527271944049};\\\", \\\"{x:821,y:535,t:1527271944067};\\\", \\\"{x:823,y:535,t:1527271944097};\\\", \\\"{x:824,y:535,t:1527271944113};\\\", \\\"{x:825,y:535,t:1527271944161};\\\", \\\"{x:826,y:535,t:1527271944169};\\\", \\\"{x:828,y:535,t:1527271944184};\\\", \\\"{x:830,y:535,t:1527271944199};\\\", \\\"{x:831,y:535,t:1527271944217};\\\", \\\"{x:831,y:536,t:1527271944448};\\\", \\\"{x:825,y:537,t:1527271944456};\\\", \\\"{x:820,y:539,t:1527271944466};\\\", \\\"{x:810,y:544,t:1527271944483};\\\", \\\"{x:795,y:548,t:1527271944500};\\\", \\\"{x:769,y:559,t:1527271944518};\\\", \\\"{x:731,y:573,t:1527271944534};\\\", \\\"{x:711,y:584,t:1527271944552};\\\", \\\"{x:700,y:600,t:1527271944568};\\\", \\\"{x:691,y:616,t:1527271944584};\\\", \\\"{x:663,y:639,t:1527271944601};\\\", \\\"{x:638,y:651,t:1527271944617};\\\", \\\"{x:626,y:658,t:1527271944633};\\\", \\\"{x:619,y:662,t:1527271944650};\\\", \\\"{x:613,y:665,t:1527271944667};\\\", \\\"{x:607,y:669,t:1527271944683};\\\", \\\"{x:595,y:673,t:1527271944700};\\\", \\\"{x:588,y:678,t:1527271944717};\\\", \\\"{x:585,y:680,t:1527271944734};\\\", \\\"{x:580,y:684,t:1527271944750};\\\", \\\"{x:566,y:688,t:1527271944768};\\\", \\\"{x:552,y:693,t:1527271944784};\\\", \\\"{x:541,y:700,t:1527271944800};\\\", \\\"{x:538,y:705,t:1527271944817};\\\", \\\"{x:534,y:709,t:1527271944834};\\\", \\\"{x:529,y:712,t:1527271944851};\\\", \\\"{x:523,y:716,t:1527271944868};\\\", \\\"{x:521,y:718,t:1527271944883};\\\", \\\"{x:519,y:720,t:1527271944902};\\\", \\\"{x:519,y:722,t:1527271944918};\\\", \\\"{x:518,y:723,t:1527271944934};\\\", \\\"{x:514,y:727,t:1527271944950};\\\", \\\"{x:512,y:732,t:1527271944967};\\\", \\\"{x:510,y:738,t:1527271944983};\\\", \\\"{x:510,y:742,t:1527271945000};\\\", \\\"{x:508,y:744,t:1527271945018};\\\", \\\"{x:508,y:745,t:1527271945056};\\\", \\\"{x:508,y:747,t:1527271945081};\\\", \\\"{x:507,y:747,t:1527271945151};\\\", \\\"{x:505,y:748,t:1527271945167};\\\", \\\"{x:503,y:751,t:1527271945184};\\\", \\\"{x:503,y:751,t:1527271945235};\\\", \\\"{x:503,y:749,t:1527271945674};\\\" ] }, { \\\"rt\\\": 24609, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 916224, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -H -H \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:748,t:1527271949546};\\\", \\\"{x:510,y:748,t:1527271950081};\\\", \\\"{x:519,y:748,t:1527271950095};\\\", \\\"{x:544,y:748,t:1527271950111};\\\", \\\"{x:580,y:748,t:1527271950130};\\\", \\\"{x:616,y:748,t:1527271950144};\\\", \\\"{x:692,y:748,t:1527271950161};\\\", \\\"{x:754,y:747,t:1527271950178};\\\", \\\"{x:782,y:745,t:1527271950188};\\\", \\\"{x:845,y:740,t:1527271950204};\\\", \\\"{x:896,y:739,t:1527271950222};\\\", \\\"{x:974,y:739,t:1527271950238};\\\", \\\"{x:1055,y:739,t:1527271950255};\\\", \\\"{x:1136,y:735,t:1527271950272};\\\", \\\"{x:1206,y:723,t:1527271950288};\\\", \\\"{x:1246,y:715,t:1527271950305};\\\", \\\"{x:1272,y:709,t:1527271950322};\\\", \\\"{x:1303,y:704,t:1527271950339};\\\", \\\"{x:1330,y:697,t:1527271950354};\\\", \\\"{x:1352,y:692,t:1527271950372};\\\", \\\"{x:1372,y:686,t:1527271950389};\\\", \\\"{x:1380,y:682,t:1527271950405};\\\", \\\"{x:1382,y:682,t:1527271950422};\\\", \\\"{x:1383,y:681,t:1527271950439};\\\", \\\"{x:1385,y:681,t:1527271950455};\\\", \\\"{x:1387,y:680,t:1527271950472};\\\", \\\"{x:1392,y:677,t:1527271950488};\\\", \\\"{x:1394,y:671,t:1527271950505};\\\", \\\"{x:1395,y:667,t:1527271950522};\\\", \\\"{x:1397,y:665,t:1527271950539};\\\", \\\"{x:1399,y:663,t:1527271950555};\\\", \\\"{x:1401,y:661,t:1527271950572};\\\", \\\"{x:1403,y:660,t:1527271950590};\\\", \\\"{x:1403,y:658,t:1527271950605};\\\", \\\"{x:1404,y:651,t:1527271950622};\\\", \\\"{x:1404,y:648,t:1527271950639};\\\", \\\"{x:1406,y:646,t:1527271950655};\\\", \\\"{x:1408,y:644,t:1527271950672};\\\", \\\"{x:1408,y:643,t:1527271950690};\\\", \\\"{x:1410,y:642,t:1527271950705};\\\", \\\"{x:1418,y:639,t:1527271950722};\\\", \\\"{x:1431,y:636,t:1527271950739};\\\", \\\"{x:1442,y:632,t:1527271950756};\\\", \\\"{x:1444,y:631,t:1527271950774};\\\", \\\"{x:1448,y:629,t:1527271950789};\\\", \\\"{x:1450,y:628,t:1527271950806};\\\", \\\"{x:1452,y:627,t:1527271950832};\\\", \\\"{x:1453,y:627,t:1527271950865};\\\", \\\"{x:1454,y:626,t:1527271950945};\\\", \\\"{x:1455,y:626,t:1527271950956};\\\", \\\"{x:1456,y:626,t:1527271950985};\\\", \\\"{x:1458,y:626,t:1527271950993};\\\", \\\"{x:1459,y:626,t:1527271951006};\\\", \\\"{x:1468,y:624,t:1527271951022};\\\", \\\"{x:1483,y:623,t:1527271951039};\\\", \\\"{x:1498,y:623,t:1527271951056};\\\", \\\"{x:1514,y:620,t:1527271951072};\\\", \\\"{x:1526,y:618,t:1527271951089};\\\", \\\"{x:1528,y:618,t:1527271951106};\\\", \\\"{x:1530,y:618,t:1527271951123};\\\", \\\"{x:1532,y:618,t:1527271951139};\\\", \\\"{x:1533,y:618,t:1527271951156};\\\", \\\"{x:1535,y:618,t:1527271951173};\\\", \\\"{x:1536,y:617,t:1527271951193};\\\", \\\"{x:1538,y:617,t:1527271951206};\\\", \\\"{x:1543,y:616,t:1527271951223};\\\", \\\"{x:1551,y:616,t:1527271951239};\\\", \\\"{x:1558,y:614,t:1527271951256};\\\", \\\"{x:1562,y:614,t:1527271951273};\\\", \\\"{x:1564,y:614,t:1527271951337};\\\", \\\"{x:1567,y:614,t:1527271951345};\\\", \\\"{x:1572,y:614,t:1527271951356};\\\", \\\"{x:1581,y:616,t:1527271951373};\\\", \\\"{x:1583,y:616,t:1527271951389};\\\", \\\"{x:1584,y:616,t:1527271951457};\\\", \\\"{x:1588,y:618,t:1527271951472};\\\", \\\"{x:1589,y:618,t:1527271951489};\\\", \\\"{x:1589,y:619,t:1527271951506};\\\", \\\"{x:1589,y:620,t:1527271951523};\\\", \\\"{x:1589,y:621,t:1527271951539};\\\", \\\"{x:1589,y:622,t:1527271951555};\\\", \\\"{x:1589,y:623,t:1527271951573};\\\", \\\"{x:1590,y:624,t:1527271951617};\\\", \\\"{x:1591,y:625,t:1527271965445};\\\", \\\"{x:1591,y:626,t:1527271965454};\\\", \\\"{x:1587,y:627,t:1527271965471};\\\", \\\"{x:1584,y:628,t:1527271965488};\\\", \\\"{x:1579,y:629,t:1527271965504};\\\", \\\"{x:1571,y:631,t:1527271965523};\\\", \\\"{x:1556,y:631,t:1527271965538};\\\", \\\"{x:1535,y:631,t:1527271965554};\\\", \\\"{x:1512,y:632,t:1527271965572};\\\", \\\"{x:1454,y:632,t:1527271965588};\\\", \\\"{x:1404,y:632,t:1527271965605};\\\", \\\"{x:1337,y:632,t:1527271965622};\\\", \\\"{x:1265,y:632,t:1527271965638};\\\", \\\"{x:1187,y:632,t:1527271965655};\\\", \\\"{x:1106,y:632,t:1527271965672};\\\", \\\"{x:1009,y:632,t:1527271965689};\\\", \\\"{x:896,y:632,t:1527271965705};\\\", \\\"{x:785,y:632,t:1527271965722};\\\", \\\"{x:674,y:632,t:1527271965738};\\\", \\\"{x:552,y:632,t:1527271965754};\\\", \\\"{x:461,y:632,t:1527271965772};\\\", \\\"{x:360,y:632,t:1527271965788};\\\", \\\"{x:318,y:632,t:1527271965804};\\\", \\\"{x:299,y:632,t:1527271965821};\\\", \\\"{x:296,y:632,t:1527271965839};\\\", \\\"{x:295,y:632,t:1527271965854};\\\", \\\"{x:303,y:632,t:1527271965909};\\\", \\\"{x:311,y:631,t:1527271965923};\\\", \\\"{x:334,y:625,t:1527271965938};\\\", \\\"{x:352,y:620,t:1527271965954};\\\", \\\"{x:370,y:614,t:1527271965971};\\\", \\\"{x:422,y:606,t:1527271965988};\\\", \\\"{x:455,y:599,t:1527271966005};\\\", \\\"{x:478,y:594,t:1527271966021};\\\", \\\"{x:490,y:589,t:1527271966038};\\\", \\\"{x:492,y:589,t:1527271966055};\\\", \\\"{x:493,y:588,t:1527271966071};\\\", \\\"{x:494,y:588,t:1527271966091};\\\", \\\"{x:495,y:587,t:1527271966105};\\\", \\\"{x:496,y:587,t:1527271966122};\\\", \\\"{x:499,y:586,t:1527271966139};\\\", \\\"{x:503,y:584,t:1527271966155};\\\", \\\"{x:505,y:583,t:1527271966171};\\\", \\\"{x:509,y:581,t:1527271966188};\\\", \\\"{x:515,y:578,t:1527271966205};\\\", \\\"{x:531,y:571,t:1527271966222};\\\", \\\"{x:545,y:564,t:1527271966239};\\\", \\\"{x:557,y:556,t:1527271966256};\\\", \\\"{x:567,y:547,t:1527271966273};\\\", \\\"{x:580,y:539,t:1527271966288};\\\", \\\"{x:596,y:532,t:1527271966305};\\\", \\\"{x:612,y:522,t:1527271966323};\\\", \\\"{x:620,y:518,t:1527271966338};\\\", \\\"{x:622,y:517,t:1527271966356};\\\", \\\"{x:626,y:517,t:1527271966468};\\\", \\\"{x:633,y:514,t:1527271966476};\\\", \\\"{x:644,y:514,t:1527271966488};\\\", \\\"{x:669,y:514,t:1527271966505};\\\", \\\"{x:685,y:514,t:1527271966522};\\\", \\\"{x:698,y:514,t:1527271966538};\\\", \\\"{x:707,y:514,t:1527271966555};\\\", \\\"{x:711,y:514,t:1527271966572};\\\", \\\"{x:712,y:515,t:1527271966589};\\\", \\\"{x:716,y:515,t:1527271966606};\\\", \\\"{x:727,y:518,t:1527271966624};\\\", \\\"{x:743,y:519,t:1527271966640};\\\", \\\"{x:754,y:519,t:1527271966655};\\\", \\\"{x:755,y:519,t:1527271966672};\\\", \\\"{x:757,y:519,t:1527271966688};\\\", \\\"{x:766,y:518,t:1527271966705};\\\", \\\"{x:780,y:515,t:1527271966722};\\\", \\\"{x:788,y:514,t:1527271966738};\\\", \\\"{x:791,y:513,t:1527271966755};\\\", \\\"{x:792,y:513,t:1527271966796};\\\", \\\"{x:795,y:513,t:1527271966805};\\\", \\\"{x:804,y:512,t:1527271966822};\\\", \\\"{x:808,y:510,t:1527271966840};\\\", \\\"{x:810,y:509,t:1527271966855};\\\", \\\"{x:811,y:509,t:1527271966925};\\\", \\\"{x:812,y:509,t:1527271966940};\\\", \\\"{x:819,y:507,t:1527271966955};\\\", \\\"{x:822,y:506,t:1527271966973};\\\", \\\"{x:823,y:505,t:1527271967116};\\\", \\\"{x:822,y:505,t:1527271967405};\\\", \\\"{x:820,y:505,t:1527271967420};\\\", \\\"{x:819,y:506,t:1527271967429};\\\", \\\"{x:820,y:506,t:1527271967541};\\\", \\\"{x:826,y:505,t:1527271967558};\\\", \\\"{x:823,y:506,t:1527271967932};\\\", \\\"{x:822,y:506,t:1527271967939};\\\", \\\"{x:820,y:506,t:1527271967956};\\\", \\\"{x:818,y:507,t:1527271967973};\\\", \\\"{x:811,y:508,t:1527271967990};\\\", \\\"{x:805,y:510,t:1527271968006};\\\", \\\"{x:802,y:511,t:1527271968023};\\\", \\\"{x:798,y:512,t:1527271968040};\\\", \\\"{x:789,y:514,t:1527271968056};\\\", \\\"{x:772,y:520,t:1527271968074};\\\", \\\"{x:750,y:525,t:1527271968091};\\\", \\\"{x:703,y:533,t:1527271968107};\\\", \\\"{x:644,y:542,t:1527271968123};\\\", \\\"{x:573,y:552,t:1527271968140};\\\", \\\"{x:531,y:559,t:1527271968157};\\\", \\\"{x:508,y:566,t:1527271968174};\\\", \\\"{x:496,y:570,t:1527271968191};\\\", \\\"{x:486,y:572,t:1527271968206};\\\", \\\"{x:470,y:574,t:1527271968223};\\\", \\\"{x:448,y:578,t:1527271968240};\\\", \\\"{x:430,y:579,t:1527271968256};\\\", \\\"{x:411,y:584,t:1527271968274};\\\", \\\"{x:396,y:585,t:1527271968290};\\\", \\\"{x:385,y:586,t:1527271968306};\\\", \\\"{x:383,y:587,t:1527271968323};\\\", \\\"{x:381,y:589,t:1527271968349};\\\", \\\"{x:378,y:589,t:1527271968357};\\\", \\\"{x:367,y:589,t:1527271968375};\\\", \\\"{x:343,y:589,t:1527271968390};\\\", \\\"{x:325,y:589,t:1527271968408};\\\", \\\"{x:313,y:589,t:1527271968424};\\\", \\\"{x:311,y:589,t:1527271968441};\\\", \\\"{x:310,y:589,t:1527271968458};\\\", \\\"{x:308,y:589,t:1527271968474};\\\", \\\"{x:300,y:581,t:1527271968491};\\\", \\\"{x:278,y:570,t:1527271968508};\\\", \\\"{x:260,y:559,t:1527271968525};\\\", \\\"{x:251,y:553,t:1527271968541};\\\", \\\"{x:247,y:547,t:1527271968557};\\\", \\\"{x:241,y:539,t:1527271968573};\\\", \\\"{x:230,y:532,t:1527271968590};\\\", \\\"{x:215,y:526,t:1527271968607};\\\", \\\"{x:196,y:520,t:1527271968624};\\\", \\\"{x:188,y:516,t:1527271968642};\\\", \\\"{x:186,y:515,t:1527271968657};\\\", \\\"{x:185,y:515,t:1527271968708};\\\", \\\"{x:184,y:515,t:1527271968724};\\\", \\\"{x:178,y:516,t:1527271968740};\\\", \\\"{x:176,y:517,t:1527271968757};\\\", \\\"{x:175,y:518,t:1527271968774};\\\", \\\"{x:174,y:519,t:1527271968791};\\\", \\\"{x:173,y:519,t:1527271968828};\\\", \\\"{x:171,y:521,t:1527271968840};\\\", \\\"{x:164,y:525,t:1527271968859};\\\", \\\"{x:157,y:529,t:1527271968875};\\\", \\\"{x:154,y:533,t:1527271968890};\\\", \\\"{x:153,y:537,t:1527271968907};\\\", \\\"{x:153,y:538,t:1527271968924};\\\", \\\"{x:152,y:538,t:1527271969003};\\\", \\\"{x:150,y:540,t:1527271969012};\\\", \\\"{x:149,y:541,t:1527271969025};\\\", \\\"{x:147,y:543,t:1527271969040};\\\", \\\"{x:151,y:543,t:1527271969244};\\\", \\\"{x:160,y:544,t:1527271969258};\\\", \\\"{x:185,y:547,t:1527271969275};\\\", \\\"{x:210,y:547,t:1527271969291};\\\", \\\"{x:233,y:550,t:1527271969307};\\\", \\\"{x:261,y:560,t:1527271969324};\\\", \\\"{x:272,y:563,t:1527271969342};\\\", \\\"{x:281,y:567,t:1527271969358};\\\", \\\"{x:296,y:570,t:1527271969374};\\\", \\\"{x:319,y:576,t:1527271969391};\\\", \\\"{x:339,y:583,t:1527271969408};\\\", \\\"{x:352,y:589,t:1527271969425};\\\", \\\"{x:357,y:594,t:1527271969442};\\\", \\\"{x:360,y:601,t:1527271969459};\\\", \\\"{x:366,y:609,t:1527271969474};\\\", \\\"{x:369,y:614,t:1527271969491};\\\", \\\"{x:370,y:620,t:1527271969508};\\\", \\\"{x:372,y:621,t:1527271969525};\\\", \\\"{x:372,y:622,t:1527271969541};\\\", \\\"{x:372,y:623,t:1527271969580};\\\", \\\"{x:369,y:624,t:1527271969591};\\\", \\\"{x:354,y:624,t:1527271969609};\\\", \\\"{x:320,y:621,t:1527271969624};\\\", \\\"{x:251,y:611,t:1527271969643};\\\", \\\"{x:178,y:600,t:1527271969659};\\\", \\\"{x:150,y:596,t:1527271969674};\\\", \\\"{x:146,y:595,t:1527271969691};\\\", \\\"{x:143,y:589,t:1527271969757};\\\", \\\"{x:142,y:586,t:1527271969774};\\\", \\\"{x:142,y:582,t:1527271969791};\\\", \\\"{x:141,y:575,t:1527271969809};\\\", \\\"{x:141,y:570,t:1527271969824};\\\", \\\"{x:141,y:566,t:1527271969841};\\\", \\\"{x:144,y:562,t:1527271969859};\\\", \\\"{x:151,y:558,t:1527271969874};\\\", \\\"{x:156,y:555,t:1527271969892};\\\", \\\"{x:158,y:553,t:1527271969909};\\\", \\\"{x:159,y:552,t:1527271969924};\\\", \\\"{x:159,y:551,t:1527271969957};\\\", \\\"{x:159,y:549,t:1527271970004};\\\", \\\"{x:159,y:548,t:1527271970012};\\\", \\\"{x:159,y:547,t:1527271970108};\\\", \\\"{x:159,y:546,t:1527271970125};\\\", \\\"{x:160,y:545,t:1527271970236};\\\", \\\"{x:161,y:545,t:1527271970259};\\\", \\\"{x:162,y:545,t:1527271970291};\\\", \\\"{x:164,y:544,t:1527271970309};\\\", \\\"{x:174,y:544,t:1527271970325};\\\", \\\"{x:188,y:550,t:1527271970342};\\\", \\\"{x:200,y:555,t:1527271970359};\\\", \\\"{x:213,y:560,t:1527271970376};\\\", \\\"{x:227,y:563,t:1527271970392};\\\", \\\"{x:244,y:569,t:1527271970408};\\\", \\\"{x:263,y:581,t:1527271970425};\\\", \\\"{x:280,y:590,t:1527271970442};\\\", \\\"{x:300,y:599,t:1527271970459};\\\", \\\"{x:329,y:607,t:1527271970476};\\\", \\\"{x:389,y:627,t:1527271970492};\\\", \\\"{x:432,y:642,t:1527271970510};\\\", \\\"{x:456,y:652,t:1527271970525};\\\", \\\"{x:478,y:665,t:1527271970542};\\\", \\\"{x:496,y:678,t:1527271970559};\\\", \\\"{x:512,y:689,t:1527271970576};\\\", \\\"{x:523,y:696,t:1527271970592};\\\", \\\"{x:531,y:700,t:1527271970609};\\\", \\\"{x:535,y:703,t:1527271970626};\\\", \\\"{x:536,y:704,t:1527271970652};\\\", \\\"{x:536,y:705,t:1527271970661};\\\", \\\"{x:539,y:707,t:1527271970676};\\\", \\\"{x:544,y:717,t:1527271970692};\\\", \\\"{x:546,y:721,t:1527271970710};\\\", \\\"{x:547,y:721,t:1527271970725};\\\", \\\"{x:548,y:723,t:1527271970765};\\\", \\\"{x:548,y:724,t:1527271970776};\\\", \\\"{x:551,y:728,t:1527271970793};\\\", \\\"{x:551,y:729,t:1527271970810};\\\", \\\"{x:552,y:731,t:1527271970825};\\\", \\\"{x:552,y:735,t:1527271970843};\\\", \\\"{x:550,y:738,t:1527271970860};\\\", \\\"{x:549,y:741,t:1527271970876};\\\", \\\"{x:549,y:742,t:1527271970892};\\\", \\\"{x:551,y:742,t:1527271971869};\\\", \\\"{x:553,y:741,t:1527271971916};\\\", \\\"{x:554,y:741,t:1527271971926};\\\", \\\"{x:562,y:738,t:1527271971944};\\\", \\\"{x:567,y:736,t:1527271971959};\\\", \\\"{x:570,y:736,t:1527271971976};\\\", \\\"{x:571,y:735,t:1527271972005};\\\", \\\"{x:572,y:734,t:1527271972012};\\\", \\\"{x:574,y:734,t:1527271972027};\\\", \\\"{x:579,y:732,t:1527271972044};\\\", \\\"{x:585,y:730,t:1527271972060};\\\", \\\"{x:589,y:728,t:1527271972076};\\\", \\\"{x:590,y:728,t:1527271972100};\\\", \\\"{x:591,y:728,t:1527271972110};\\\", \\\"{x:593,y:727,t:1527271972126};\\\", \\\"{x:600,y:723,t:1527271972143};\\\", \\\"{x:607,y:721,t:1527271972159};\\\", \\\"{x:612,y:716,t:1527271972210};\\\", \\\"{x:613,y:715,t:1527271972226};\\\", \\\"{x:615,y:714,t:1527271972244};\\\", \\\"{x:618,y:713,t:1527271972260};\\\", \\\"{x:618,y:712,t:1527271972276};\\\" ] }, { \\\"rt\\\": 24427, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 941911, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:632,y:706,t:1527271972410};\\\", \\\"{x:633,y:705,t:1527271972452};\\\", \\\"{x:635,y:704,t:1527271972460};\\\", \\\"{x:637,y:704,t:1527271972476};\\\", \\\"{x:642,y:702,t:1527271974660};\\\", \\\"{x:694,y:684,t:1527271974679};\\\", \\\"{x:744,y:669,t:1527271974696};\\\", \\\"{x:776,y:658,t:1527271974712};\\\", \\\"{x:805,y:651,t:1527271974729};\\\", \\\"{x:835,y:643,t:1527271974746};\\\", \\\"{x:885,y:637,t:1527271974762};\\\", \\\"{x:933,y:630,t:1527271974780};\\\", \\\"{x:1011,y:614,t:1527271974796};\\\", \\\"{x:1075,y:597,t:1527271974812};\\\", \\\"{x:1142,y:579,t:1527271974827};\\\", \\\"{x:1197,y:564,t:1527271974844};\\\", \\\"{x:1253,y:556,t:1527271974862};\\\", \\\"{x:1290,y:552,t:1527271974878};\\\", \\\"{x:1315,y:548,t:1527271974895};\\\", \\\"{x:1332,y:545,t:1527271974911};\\\", \\\"{x:1343,y:542,t:1527271974928};\\\", \\\"{x:1348,y:540,t:1527271974945};\\\", \\\"{x:1349,y:540,t:1527271974972};\\\", \\\"{x:1352,y:539,t:1527271974980};\\\", \\\"{x:1355,y:536,t:1527271974995};\\\", \\\"{x:1361,y:535,t:1527271975012};\\\", \\\"{x:1363,y:534,t:1527271975029};\\\", \\\"{x:1364,y:533,t:1527271975045};\\\", \\\"{x:1364,y:529,t:1527271975062};\\\", \\\"{x:1354,y:524,t:1527271975079};\\\", \\\"{x:1341,y:522,t:1527271975095};\\\", \\\"{x:1332,y:523,t:1527271975112};\\\", \\\"{x:1322,y:526,t:1527271975129};\\\", \\\"{x:1306,y:529,t:1527271975145};\\\", \\\"{x:1295,y:529,t:1527271975162};\\\", \\\"{x:1289,y:530,t:1527271975179};\\\", \\\"{x:1288,y:531,t:1527271975196};\\\", \\\"{x:1288,y:530,t:1527271975252};\\\", \\\"{x:1286,y:528,t:1527271975263};\\\", \\\"{x:1284,y:522,t:1527271975280};\\\", \\\"{x:1283,y:514,t:1527271975296};\\\", \\\"{x:1283,y:508,t:1527271975312};\\\", \\\"{x:1283,y:504,t:1527271975329};\\\", \\\"{x:1283,y:502,t:1527271975345};\\\", \\\"{x:1284,y:499,t:1527271975362};\\\", \\\"{x:1285,y:497,t:1527271975380};\\\", \\\"{x:1285,y:496,t:1527271975395};\\\", \\\"{x:1287,y:494,t:1527271975413};\\\", \\\"{x:1289,y:493,t:1527271975429};\\\", \\\"{x:1290,y:492,t:1527271975446};\\\", \\\"{x:1292,y:491,t:1527271975468};\\\", \\\"{x:1293,y:491,t:1527271975479};\\\", \\\"{x:1296,y:491,t:1527271975496};\\\", \\\"{x:1298,y:491,t:1527271975512};\\\", \\\"{x:1301,y:490,t:1527271975530};\\\", \\\"{x:1304,y:490,t:1527271975546};\\\", \\\"{x:1305,y:489,t:1527271975562};\\\", \\\"{x:1306,y:489,t:1527271975805};\\\", \\\"{x:1306,y:490,t:1527271975861};\\\", \\\"{x:1306,y:491,t:1527271975885};\\\", \\\"{x:1306,y:492,t:1527271975908};\\\", \\\"{x:1306,y:493,t:1527271975956};\\\", \\\"{x:1306,y:494,t:1527271975981};\\\", \\\"{x:1306,y:496,t:1527271975997};\\\", \\\"{x:1307,y:496,t:1527271976012};\\\", \\\"{x:1307,y:497,t:1527271976373};\\\", \\\"{x:1308,y:497,t:1527271976380};\\\", \\\"{x:1309,y:497,t:1527271985556};\\\", \\\"{x:1309,y:500,t:1527271985567};\\\", \\\"{x:1306,y:508,t:1527271985583};\\\", \\\"{x:1306,y:509,t:1527271985601};\\\", \\\"{x:1306,y:511,t:1527271985618};\\\", \\\"{x:1306,y:512,t:1527271985635};\\\", \\\"{x:1306,y:514,t:1527271985676};\\\", \\\"{x:1306,y:515,t:1527271985684};\\\", \\\"{x:1306,y:517,t:1527271985701};\\\", \\\"{x:1306,y:519,t:1527271985718};\\\", \\\"{x:1305,y:521,t:1527271985735};\\\", \\\"{x:1305,y:522,t:1527271985751};\\\", \\\"{x:1305,y:524,t:1527271985767};\\\", \\\"{x:1305,y:525,t:1527271985785};\\\", \\\"{x:1305,y:526,t:1527271985804};\\\", \\\"{x:1306,y:525,t:1527271985964};\\\", \\\"{x:1308,y:522,t:1527271985972};\\\", \\\"{x:1310,y:518,t:1527271985984};\\\", \\\"{x:1313,y:514,t:1527271986001};\\\", \\\"{x:1317,y:508,t:1527271986017};\\\", \\\"{x:1320,y:504,t:1527271986035};\\\", \\\"{x:1324,y:500,t:1527271986051};\\\", \\\"{x:1325,y:499,t:1527271986148};\\\", \\\"{x:1324,y:499,t:1527271986189};\\\", \\\"{x:1323,y:499,t:1527271986200};\\\", \\\"{x:1320,y:501,t:1527271986218};\\\", \\\"{x:1320,y:502,t:1527271986234};\\\", \\\"{x:1320,y:504,t:1527271986251};\\\", \\\"{x:1320,y:505,t:1527271986268};\\\", \\\"{x:1322,y:505,t:1527271986605};\\\", \\\"{x:1323,y:505,t:1527271986617};\\\", \\\"{x:1325,y:504,t:1527271986634};\\\", \\\"{x:1327,y:503,t:1527271986652};\\\", \\\"{x:1329,y:501,t:1527271986667};\\\", \\\"{x:1329,y:505,t:1527271986756};\\\", \\\"{x:1332,y:518,t:1527271986768};\\\", \\\"{x:1340,y:539,t:1527271986785};\\\", \\\"{x:1345,y:554,t:1527271986801};\\\", \\\"{x:1351,y:567,t:1527271986817};\\\", \\\"{x:1353,y:576,t:1527271986834};\\\", \\\"{x:1356,y:582,t:1527271986851};\\\", \\\"{x:1359,y:590,t:1527271986867};\\\", \\\"{x:1361,y:599,t:1527271986884};\\\", \\\"{x:1363,y:607,t:1527271986901};\\\", \\\"{x:1364,y:619,t:1527271986917};\\\", \\\"{x:1364,y:622,t:1527271986934};\\\", \\\"{x:1364,y:628,t:1527271986951};\\\", \\\"{x:1364,y:631,t:1527271986967};\\\", \\\"{x:1364,y:634,t:1527271986984};\\\", \\\"{x:1364,y:639,t:1527271987001};\\\", \\\"{x:1364,y:641,t:1527271987017};\\\", \\\"{x:1364,y:642,t:1527271987052};\\\", \\\"{x:1364,y:643,t:1527271987100};\\\", \\\"{x:1364,y:645,t:1527271987118};\\\", \\\"{x:1362,y:648,t:1527271987148};\\\", \\\"{x:1362,y:649,t:1527271987157};\\\", \\\"{x:1361,y:652,t:1527271987172};\\\", \\\"{x:1361,y:653,t:1527271987196};\\\", \\\"{x:1361,y:654,t:1527271987229};\\\", \\\"{x:1360,y:655,t:1527271987236};\\\", \\\"{x:1360,y:656,t:1527271987251};\\\", \\\"{x:1360,y:665,t:1527271987268};\\\", \\\"{x:1360,y:677,t:1527271987284};\\\", \\\"{x:1360,y:703,t:1527271987301};\\\", \\\"{x:1360,y:737,t:1527271987319};\\\", \\\"{x:1353,y:757,t:1527271987334};\\\", \\\"{x:1352,y:758,t:1527271988189};\\\", \\\"{x:1350,y:759,t:1527271988215};\\\", \\\"{x:1349,y:760,t:1527271988308};\\\", \\\"{x:1348,y:761,t:1527271988356};\\\", \\\"{x:1346,y:761,t:1527271988379};\\\", \\\"{x:1345,y:762,t:1527271988388};\\\", \\\"{x:1343,y:763,t:1527271988404};\\\", \\\"{x:1343,y:764,t:1527271988418};\\\", \\\"{x:1342,y:765,t:1527271988518};\\\", \\\"{x:1339,y:762,t:1527271988795};\\\", \\\"{x:1332,y:757,t:1527271988804};\\\", \\\"{x:1322,y:752,t:1527271988818};\\\", \\\"{x:1308,y:746,t:1527271988835};\\\", \\\"{x:1283,y:730,t:1527271988852};\\\", \\\"{x:1273,y:723,t:1527271988869};\\\", \\\"{x:1273,y:721,t:1527271988885};\\\", \\\"{x:1273,y:713,t:1527271988902};\\\", \\\"{x:1278,y:702,t:1527271988918};\\\", \\\"{x:1283,y:691,t:1527271988936};\\\", \\\"{x:1285,y:682,t:1527271988952};\\\", \\\"{x:1285,y:675,t:1527271988969};\\\", \\\"{x:1286,y:669,t:1527271988985};\\\", \\\"{x:1290,y:662,t:1527271989002};\\\", \\\"{x:1298,y:656,t:1527271989018};\\\", \\\"{x:1303,y:651,t:1527271989035};\\\", \\\"{x:1308,y:641,t:1527271989051};\\\", \\\"{x:1308,y:635,t:1527271989069};\\\", \\\"{x:1308,y:628,t:1527271989085};\\\", \\\"{x:1308,y:620,t:1527271989102};\\\", \\\"{x:1307,y:611,t:1527271989119};\\\", \\\"{x:1303,y:600,t:1527271989135};\\\", \\\"{x:1302,y:593,t:1527271989152};\\\", \\\"{x:1301,y:586,t:1527271989168};\\\", \\\"{x:1301,y:577,t:1527271989186};\\\", \\\"{x:1301,y:569,t:1527271989202};\\\", \\\"{x:1299,y:559,t:1527271989219};\\\", \\\"{x:1298,y:551,t:1527271989235};\\\", \\\"{x:1297,y:541,t:1527271989252};\\\", \\\"{x:1297,y:538,t:1527271989270};\\\", \\\"{x:1297,y:532,t:1527271989286};\\\", \\\"{x:1297,y:528,t:1527271989303};\\\", \\\"{x:1297,y:527,t:1527271989320};\\\", \\\"{x:1297,y:526,t:1527271989335};\\\", \\\"{x:1297,y:525,t:1527271989353};\\\", \\\"{x:1296,y:525,t:1527271989604};\\\", \\\"{x:1295,y:525,t:1527271989629};\\\", \\\"{x:1293,y:525,t:1527271989645};\\\", \\\"{x:1292,y:528,t:1527271989652};\\\", \\\"{x:1292,y:534,t:1527271989669};\\\", \\\"{x:1292,y:535,t:1527271989686};\\\", \\\"{x:1292,y:537,t:1527271989703};\\\", \\\"{x:1292,y:538,t:1527271989719};\\\", \\\"{x:1292,y:539,t:1527271989797};\\\", \\\"{x:1292,y:540,t:1527271989804};\\\", \\\"{x:1292,y:541,t:1527271989844};\\\", \\\"{x:1292,y:542,t:1527271989852};\\\", \\\"{x:1292,y:543,t:1527271989870};\\\", \\\"{x:1291,y:545,t:1527271989886};\\\", \\\"{x:1291,y:546,t:1527271994821};\\\", \\\"{x:1279,y:550,t:1527271994839};\\\", \\\"{x:1263,y:556,t:1527271994855};\\\", \\\"{x:1252,y:561,t:1527271994872};\\\", \\\"{x:1237,y:578,t:1527271994889};\\\", \\\"{x:1221,y:588,t:1527271994905};\\\", \\\"{x:1199,y:597,t:1527271994922};\\\", \\\"{x:1171,y:603,t:1527271994939};\\\", \\\"{x:1123,y:610,t:1527271994955};\\\", \\\"{x:1028,y:620,t:1527271994972};\\\", \\\"{x:993,y:626,t:1527271994989};\\\", \\\"{x:974,y:627,t:1527271995006};\\\", \\\"{x:953,y:628,t:1527271995022};\\\", \\\"{x:932,y:628,t:1527271995040};\\\", \\\"{x:911,y:628,t:1527271995055};\\\", \\\"{x:882,y:628,t:1527271995071};\\\", \\\"{x:838,y:624,t:1527271995095};\\\", \\\"{x:782,y:616,t:1527271995113};\\\", \\\"{x:713,y:610,t:1527271995128};\\\", \\\"{x:647,y:605,t:1527271995145};\\\", \\\"{x:598,y:600,t:1527271995162};\\\", \\\"{x:567,y:599,t:1527271995178};\\\", \\\"{x:540,y:595,t:1527271995195};\\\", \\\"{x:530,y:593,t:1527271995213};\\\", \\\"{x:526,y:591,t:1527271995228};\\\", \\\"{x:523,y:590,t:1527271995245};\\\", \\\"{x:525,y:588,t:1527271995283};\\\", \\\"{x:528,y:585,t:1527271995296};\\\", \\\"{x:540,y:579,t:1527271995312};\\\", \\\"{x:551,y:572,t:1527271995330};\\\", \\\"{x:561,y:567,t:1527271995345};\\\", \\\"{x:573,y:561,t:1527271995363};\\\", \\\"{x:590,y:553,t:1527271995380};\\\", \\\"{x:596,y:550,t:1527271995395};\\\", \\\"{x:601,y:548,t:1527271995412};\\\", \\\"{x:601,y:546,t:1527271995443};\\\", \\\"{x:605,y:542,t:1527271995452};\\\", \\\"{x:610,y:540,t:1527271995463};\\\", \\\"{x:619,y:534,t:1527271995478};\\\", \\\"{x:623,y:532,t:1527271995495};\\\", \\\"{x:623,y:530,t:1527271995512};\\\", \\\"{x:623,y:528,t:1527271995529};\\\", \\\"{x:621,y:525,t:1527271995546};\\\", \\\"{x:621,y:524,t:1527271995563};\\\", \\\"{x:621,y:520,t:1527271995580};\\\", \\\"{x:619,y:518,t:1527271995595};\\\", \\\"{x:617,y:516,t:1527271995613};\\\", \\\"{x:614,y:512,t:1527271995629};\\\", \\\"{x:613,y:508,t:1527271995646};\\\", \\\"{x:613,y:504,t:1527271995662};\\\", \\\"{x:612,y:502,t:1527271995680};\\\", \\\"{x:611,y:500,t:1527271995696};\\\", \\\"{x:611,y:496,t:1527271995712};\\\", \\\"{x:611,y:494,t:1527271995730};\\\", \\\"{x:611,y:492,t:1527271995746};\\\", \\\"{x:611,y:491,t:1527271995763};\\\", \\\"{x:611,y:492,t:1527271996059};\\\", \\\"{x:610,y:496,t:1527271996068};\\\", \\\"{x:610,y:498,t:1527271996080};\\\", \\\"{x:608,y:502,t:1527271996096};\\\", \\\"{x:607,y:506,t:1527271996113};\\\", \\\"{x:607,y:507,t:1527271996129};\\\", \\\"{x:607,y:508,t:1527271996163};\\\", \\\"{x:604,y:516,t:1527271996181};\\\", \\\"{x:602,y:530,t:1527271996198};\\\", \\\"{x:598,y:543,t:1527271996213};\\\", \\\"{x:596,y:561,t:1527271996230};\\\", \\\"{x:590,y:583,t:1527271996247};\\\", \\\"{x:580,y:606,t:1527271996263};\\\", \\\"{x:569,y:626,t:1527271996279};\\\", \\\"{x:558,y:644,t:1527271996296};\\\", \\\"{x:551,y:661,t:1527271996313};\\\", \\\"{x:546,y:675,t:1527271996329};\\\", \\\"{x:541,y:686,t:1527271996346};\\\", \\\"{x:528,y:703,t:1527271996363};\\\", \\\"{x:523,y:709,t:1527271996379};\\\", \\\"{x:516,y:714,t:1527271996397};\\\", \\\"{x:511,y:717,t:1527271996413};\\\", \\\"{x:506,y:721,t:1527271996431};\\\", \\\"{x:503,y:722,t:1527271996446};\\\", \\\"{x:502,y:723,t:1527271996463};\\\", \\\"{x:501,y:724,t:1527271996479};\\\", \\\"{x:499,y:725,t:1527271996496};\\\", \\\"{x:498,y:726,t:1527271996515};\\\", \\\"{x:497,y:727,t:1527271996540};\\\", \\\"{x:497,y:728,t:1527271996563};\\\", \\\"{x:494,y:731,t:1527271996579};\\\", \\\"{x:492,y:735,t:1527271996596};\\\", \\\"{x:490,y:738,t:1527271996614};\\\", \\\"{x:490,y:739,t:1527271996629};\\\", \\\"{x:490,y:741,t:1527271996646};\\\" ] }, { \\\"rt\\\": 35734, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 978963, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -N -Z -Z -J -J -J -B -B -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:489,y:741,t:1527272005284};\\\", \\\"{x:492,y:739,t:1527272005515};\\\", \\\"{x:494,y:737,t:1527272005531};\\\", \\\"{x:498,y:734,t:1527272005547};\\\", \\\"{x:498,y:730,t:1527272005564};\\\", \\\"{x:498,y:726,t:1527272005581};\\\", \\\"{x:498,y:720,t:1527272005597};\\\", \\\"{x:496,y:715,t:1527272005616};\\\", \\\"{x:492,y:708,t:1527272005630};\\\", \\\"{x:486,y:701,t:1527272005648};\\\", \\\"{x:481,y:695,t:1527272005670};\\\", \\\"{x:479,y:690,t:1527272005686};\\\", \\\"{x:477,y:688,t:1527272005704};\\\", \\\"{x:474,y:680,t:1527272005721};\\\", \\\"{x:472,y:674,t:1527272005736};\\\", \\\"{x:469,y:666,t:1527272005754};\\\", \\\"{x:462,y:652,t:1527272005770};\\\", \\\"{x:444,y:636,t:1527272005788};\\\", \\\"{x:437,y:624,t:1527272005804};\\\", \\\"{x:432,y:613,t:1527272005820};\\\", \\\"{x:431,y:605,t:1527272005837};\\\", \\\"{x:429,y:601,t:1527272005854};\\\", \\\"{x:429,y:596,t:1527272005871};\\\", \\\"{x:428,y:592,t:1527272005888};\\\", \\\"{x:426,y:588,t:1527272005903};\\\", \\\"{x:426,y:586,t:1527272005921};\\\", \\\"{x:427,y:583,t:1527272005937};\\\", \\\"{x:433,y:580,t:1527272005954};\\\", \\\"{x:438,y:578,t:1527272005970};\\\", \\\"{x:446,y:575,t:1527272005987};\\\", \\\"{x:450,y:573,t:1527272006004};\\\", \\\"{x:458,y:568,t:1527272006020};\\\", \\\"{x:466,y:564,t:1527272006038};\\\", \\\"{x:481,y:560,t:1527272006055};\\\", \\\"{x:489,y:558,t:1527272006071};\\\", \\\"{x:495,y:556,t:1527272006087};\\\", \\\"{x:498,y:555,t:1527272006104};\\\", \\\"{x:505,y:554,t:1527272006122};\\\", \\\"{x:518,y:550,t:1527272006137};\\\", \\\"{x:544,y:551,t:1527272006153};\\\", \\\"{x:590,y:560,t:1527272006171};\\\", \\\"{x:681,y:573,t:1527272006189};\\\", \\\"{x:764,y:584,t:1527272006205};\\\", \\\"{x:867,y:600,t:1527272006221};\\\", \\\"{x:997,y:619,t:1527272006237};\\\", \\\"{x:1138,y:638,t:1527272006254};\\\", \\\"{x:1280,y:660,t:1527272006270};\\\", \\\"{x:1415,y:674,t:1527272006288};\\\", \\\"{x:1537,y:691,t:1527272006305};\\\", \\\"{x:1628,y:702,t:1527272006322};\\\", \\\"{x:1709,y:717,t:1527272006338};\\\", \\\"{x:1756,y:722,t:1527272006355};\\\", \\\"{x:1795,y:730,t:1527272006372};\\\", \\\"{x:1813,y:730,t:1527272006388};\\\", \\\"{x:1824,y:730,t:1527272006405};\\\", \\\"{x:1831,y:730,t:1527272006422};\\\", \\\"{x:1834,y:730,t:1527272006439};\\\", \\\"{x:1835,y:730,t:1527272006455};\\\", \\\"{x:1839,y:732,t:1527272006472};\\\", \\\"{x:1846,y:735,t:1527272006489};\\\", \\\"{x:1855,y:741,t:1527272006505};\\\", \\\"{x:1859,y:744,t:1527272006522};\\\", \\\"{x:1860,y:745,t:1527272006539};\\\", \\\"{x:1861,y:746,t:1527272006556};\\\", \\\"{x:1861,y:747,t:1527272006573};\\\", \\\"{x:1862,y:750,t:1527272006589};\\\", \\\"{x:1862,y:754,t:1527272006606};\\\", \\\"{x:1858,y:757,t:1527272006623};\\\", \\\"{x:1845,y:759,t:1527272006639};\\\", \\\"{x:1818,y:759,t:1527272006657};\\\", \\\"{x:1776,y:759,t:1527272006672};\\\", \\\"{x:1720,y:759,t:1527272006689};\\\", \\\"{x:1697,y:759,t:1527272006706};\\\", \\\"{x:1685,y:762,t:1527272006723};\\\", \\\"{x:1676,y:763,t:1527272006740};\\\", \\\"{x:1660,y:763,t:1527272006755};\\\", \\\"{x:1642,y:761,t:1527272006774};\\\", \\\"{x:1614,y:754,t:1527272006789};\\\", \\\"{x:1582,y:749,t:1527272006806};\\\", \\\"{x:1555,y:745,t:1527272006823};\\\", \\\"{x:1534,y:743,t:1527272006839};\\\", \\\"{x:1519,y:740,t:1527272006856};\\\", \\\"{x:1509,y:739,t:1527272006873};\\\", \\\"{x:1493,y:736,t:1527272006890};\\\", \\\"{x:1478,y:732,t:1527272006906};\\\", \\\"{x:1460,y:731,t:1527272006924};\\\", \\\"{x:1435,y:731,t:1527272006940};\\\", \\\"{x:1423,y:729,t:1527272006957};\\\", \\\"{x:1416,y:728,t:1527272006973};\\\", \\\"{x:1411,y:728,t:1527272006991};\\\", \\\"{x:1407,y:727,t:1527272007007};\\\", \\\"{x:1404,y:727,t:1527272007023};\\\", \\\"{x:1401,y:726,t:1527272007041};\\\", \\\"{x:1396,y:726,t:1527272007057};\\\", \\\"{x:1393,y:725,t:1527272007073};\\\", \\\"{x:1390,y:725,t:1527272007090};\\\", \\\"{x:1387,y:724,t:1527272007107};\\\", \\\"{x:1383,y:724,t:1527272007124};\\\", \\\"{x:1377,y:724,t:1527272007141};\\\", \\\"{x:1376,y:724,t:1527272007157};\\\", \\\"{x:1374,y:724,t:1527272007174};\\\", \\\"{x:1386,y:727,t:1527272007284};\\\", \\\"{x:1401,y:734,t:1527272007292};\\\", \\\"{x:1421,y:739,t:1527272007307};\\\", \\\"{x:1452,y:747,t:1527272007325};\\\", \\\"{x:1463,y:747,t:1527272007341};\\\", \\\"{x:1479,y:751,t:1527272007358};\\\", \\\"{x:1511,y:756,t:1527272007375};\\\", \\\"{x:1564,y:764,t:1527272007392};\\\", \\\"{x:1628,y:774,t:1527272007408};\\\", \\\"{x:1679,y:782,t:1527272007424};\\\", \\\"{x:1721,y:789,t:1527272007441};\\\", \\\"{x:1756,y:801,t:1527272007458};\\\", \\\"{x:1789,y:810,t:1527272007474};\\\", \\\"{x:1831,y:822,t:1527272007491};\\\", \\\"{x:1850,y:824,t:1527272007509};\\\", \\\"{x:1850,y:825,t:1527272007884};\\\", \\\"{x:1850,y:827,t:1527272007892};\\\", \\\"{x:1849,y:829,t:1527272007939};\\\", \\\"{x:1848,y:829,t:1527272007947};\\\", \\\"{x:1847,y:829,t:1527272007959};\\\", \\\"{x:1844,y:829,t:1527272007976};\\\", \\\"{x:1841,y:830,t:1527272007992};\\\", \\\"{x:1840,y:830,t:1527272008009};\\\", \\\"{x:1837,y:831,t:1527272008026};\\\", \\\"{x:1831,y:831,t:1527272008043};\\\", \\\"{x:1821,y:831,t:1527272008059};\\\", \\\"{x:1781,y:826,t:1527272008076};\\\", \\\"{x:1738,y:819,t:1527272008093};\\\", \\\"{x:1712,y:818,t:1527272008109};\\\", \\\"{x:1696,y:818,t:1527272008126};\\\", \\\"{x:1678,y:818,t:1527272008144};\\\", \\\"{x:1659,y:818,t:1527272008160};\\\", \\\"{x:1639,y:818,t:1527272008176};\\\", \\\"{x:1613,y:818,t:1527272008193};\\\", \\\"{x:1595,y:818,t:1527272008210};\\\", \\\"{x:1587,y:818,t:1527272008226};\\\", \\\"{x:1584,y:818,t:1527272008243};\\\", \\\"{x:1583,y:818,t:1527272008261};\\\", \\\"{x:1581,y:818,t:1527272008277};\\\", \\\"{x:1579,y:818,t:1527272008294};\\\", \\\"{x:1577,y:818,t:1527272008310};\\\", \\\"{x:1576,y:818,t:1527272008328};\\\", \\\"{x:1574,y:818,t:1527272008437};\\\", \\\"{x:1573,y:818,t:1527272009228};\\\", \\\"{x:1573,y:817,t:1527272009246};\\\", \\\"{x:1573,y:801,t:1527272009263};\\\", \\\"{x:1573,y:777,t:1527272009280};\\\", \\\"{x:1580,y:746,t:1527272009297};\\\", \\\"{x:1592,y:722,t:1527272009314};\\\", \\\"{x:1602,y:709,t:1527272009330};\\\", \\\"{x:1610,y:702,t:1527272009346};\\\", \\\"{x:1620,y:695,t:1527272009366};\\\", \\\"{x:1627,y:691,t:1527272009380};\\\", \\\"{x:1628,y:691,t:1527272009396};\\\", \\\"{x:1627,y:691,t:1527272010244};\\\", \\\"{x:1626,y:691,t:1527272010251};\\\", \\\"{x:1625,y:691,t:1527272010268};\\\", \\\"{x:1623,y:692,t:1527272010283};\\\", \\\"{x:1615,y:702,t:1527272010300};\\\", \\\"{x:1605,y:714,t:1527272010317};\\\", \\\"{x:1591,y:728,t:1527272010332};\\\", \\\"{x:1567,y:749,t:1527272010350};\\\", \\\"{x:1554,y:761,t:1527272010365};\\\", \\\"{x:1547,y:767,t:1527272010382};\\\", \\\"{x:1546,y:769,t:1527272010399};\\\", \\\"{x:1546,y:772,t:1527272010416};\\\", \\\"{x:1544,y:773,t:1527272010432};\\\", \\\"{x:1544,y:774,t:1527272010450};\\\", \\\"{x:1543,y:776,t:1527272010466};\\\", \\\"{x:1543,y:778,t:1527272010482};\\\", \\\"{x:1542,y:778,t:1527272010500};\\\", \\\"{x:1540,y:779,t:1527272010564};\\\", \\\"{x:1538,y:780,t:1527272010580};\\\", \\\"{x:1537,y:781,t:1527272010588};\\\", \\\"{x:1535,y:782,t:1527272010600};\\\", \\\"{x:1534,y:782,t:1527272010616};\\\", \\\"{x:1531,y:782,t:1527272010940};\\\", \\\"{x:1521,y:782,t:1527272010951};\\\", \\\"{x:1509,y:787,t:1527272010968};\\\", \\\"{x:1506,y:789,t:1527272010984};\\\", \\\"{x:1503,y:790,t:1527272011000};\\\", \\\"{x:1497,y:792,t:1527272011017};\\\", \\\"{x:1490,y:793,t:1527272011035};\\\", \\\"{x:1481,y:796,t:1527272011051};\\\", \\\"{x:1464,y:801,t:1527272011068};\\\", \\\"{x:1459,y:803,t:1527272011084};\\\", \\\"{x:1457,y:804,t:1527272011102};\\\", \\\"{x:1455,y:805,t:1527272011118};\\\", \\\"{x:1451,y:806,t:1527272011134};\\\", \\\"{x:1444,y:807,t:1527272011151};\\\", \\\"{x:1433,y:809,t:1527272011167};\\\", \\\"{x:1423,y:814,t:1527272011184};\\\", \\\"{x:1416,y:816,t:1527272011202};\\\", \\\"{x:1414,y:817,t:1527272011220};\\\", \\\"{x:1412,y:818,t:1527272011236};\\\", \\\"{x:1406,y:820,t:1527272011252};\\\", \\\"{x:1400,y:822,t:1527272011268};\\\", \\\"{x:1390,y:824,t:1527272011285};\\\", \\\"{x:1381,y:828,t:1527272011301};\\\", \\\"{x:1374,y:829,t:1527272011318};\\\", \\\"{x:1370,y:830,t:1527272011336};\\\", \\\"{x:1364,y:830,t:1527272011351};\\\", \\\"{x:1346,y:830,t:1527272011368};\\\", \\\"{x:1315,y:830,t:1527272011386};\\\", \\\"{x:1268,y:830,t:1527272011401};\\\", \\\"{x:1220,y:837,t:1527272011419};\\\", \\\"{x:1182,y:843,t:1527272011435};\\\", \\\"{x:1173,y:843,t:1527272011452};\\\", \\\"{x:1164,y:843,t:1527272011470};\\\", \\\"{x:1162,y:843,t:1527272011486};\\\", \\\"{x:1160,y:843,t:1527272011503};\\\", \\\"{x:1158,y:843,t:1527272011518};\\\", \\\"{x:1158,y:842,t:1527272011644};\\\", \\\"{x:1159,y:841,t:1527272011652};\\\", \\\"{x:1161,y:841,t:1527272011670};\\\", \\\"{x:1165,y:838,t:1527272011686};\\\", \\\"{x:1171,y:837,t:1527272011702};\\\", \\\"{x:1176,y:834,t:1527272011720};\\\", \\\"{x:1177,y:834,t:1527272011737};\\\", \\\"{x:1179,y:833,t:1527272011772};\\\", \\\"{x:1183,y:833,t:1527272011788};\\\", \\\"{x:1187,y:833,t:1527272011803};\\\", \\\"{x:1195,y:833,t:1527272011820};\\\", \\\"{x:1197,y:833,t:1527272011860};\\\", \\\"{x:1197,y:834,t:1527272012148};\\\", \\\"{x:1198,y:835,t:1527272012164};\\\", \\\"{x:1199,y:837,t:1527272012189};\\\", \\\"{x:1200,y:837,t:1527272016520};\\\", \\\"{x:1206,y:837,t:1527272016535};\\\", \\\"{x:1213,y:835,t:1527272016553};\\\", \\\"{x:1217,y:833,t:1527272016570};\\\", \\\"{x:1219,y:832,t:1527272016587};\\\", \\\"{x:1220,y:832,t:1527272016889};\\\", \\\"{x:1224,y:829,t:1527272016903};\\\", \\\"{x:1229,y:826,t:1527272016920};\\\", \\\"{x:1228,y:826,t:1527272017136};\\\", \\\"{x:1227,y:826,t:1527272017151};\\\", \\\"{x:1226,y:826,t:1527272017168};\\\", \\\"{x:1226,y:827,t:1527272017256};\\\", \\\"{x:1225,y:827,t:1527272017384};\\\", \\\"{x:1223,y:827,t:1527272017552};\\\", \\\"{x:1222,y:827,t:1527272017592};\\\", \\\"{x:1220,y:827,t:1527272017607};\\\", \\\"{x:1219,y:827,t:1527272017631};\\\", \\\"{x:1217,y:826,t:1527272017656};\\\", \\\"{x:1216,y:825,t:1527272017673};\\\", \\\"{x:1215,y:825,t:1527272017689};\\\", \\\"{x:1214,y:825,t:1527272017706};\\\", \\\"{x:1213,y:825,t:1527272017735};\\\", \\\"{x:1213,y:824,t:1527272017761};\\\", \\\"{x:1212,y:824,t:1527272017772};\\\", \\\"{x:1212,y:823,t:1527272017789};\\\", \\\"{x:1211,y:822,t:1527272017806};\\\", \\\"{x:1209,y:822,t:1527272017895};\\\", \\\"{x:1209,y:821,t:1527272017906};\\\", \\\"{x:1207,y:821,t:1527272017922};\\\", \\\"{x:1206,y:821,t:1527272017991};\\\", \\\"{x:1205,y:821,t:1527272018006};\\\", \\\"{x:1202,y:820,t:1527272018023};\\\", \\\"{x:1201,y:820,t:1527272018038};\\\", \\\"{x:1199,y:820,t:1527272018056};\\\", \\\"{x:1197,y:819,t:1527272018086};\\\", \\\"{x:1197,y:817,t:1527272019648};\\\", \\\"{x:1197,y:813,t:1527272019660};\\\", \\\"{x:1197,y:808,t:1527272019677};\\\", \\\"{x:1197,y:803,t:1527272019694};\\\", \\\"{x:1198,y:801,t:1527272019710};\\\", \\\"{x:1199,y:799,t:1527272019728};\\\", \\\"{x:1199,y:797,t:1527272019745};\\\", \\\"{x:1199,y:795,t:1527272019762};\\\", \\\"{x:1199,y:794,t:1527272019778};\\\", \\\"{x:1199,y:793,t:1527272019794};\\\", \\\"{x:1199,y:791,t:1527272019811};\\\", \\\"{x:1199,y:789,t:1527272019827};\\\", \\\"{x:1199,y:788,t:1527272019845};\\\", \\\"{x:1199,y:787,t:1527272019863};\\\", \\\"{x:1199,y:786,t:1527272019879};\\\", \\\"{x:1199,y:785,t:1527272019903};\\\", \\\"{x:1199,y:784,t:1527272019912};\\\", \\\"{x:1199,y:783,t:1527272019928};\\\", \\\"{x:1199,y:782,t:1527272019944};\\\", \\\"{x:1199,y:781,t:1527272019962};\\\", \\\"{x:1199,y:780,t:1527272019979};\\\", \\\"{x:1198,y:779,t:1527272019995};\\\", \\\"{x:1198,y:776,t:1527272020012};\\\", \\\"{x:1197,y:774,t:1527272020028};\\\", \\\"{x:1196,y:772,t:1527272020046};\\\", \\\"{x:1196,y:770,t:1527272020062};\\\", \\\"{x:1194,y:770,t:1527272020078};\\\", \\\"{x:1194,y:769,t:1527272020127};\\\", \\\"{x:1193,y:769,t:1527272020151};\\\", \\\"{x:1192,y:768,t:1527272020167};\\\", \\\"{x:1190,y:767,t:1527272020207};\\\", \\\"{x:1189,y:767,t:1527272020264};\\\", \\\"{x:1188,y:767,t:1527272020304};\\\", \\\"{x:1187,y:767,t:1527272021048};\\\", \\\"{x:1190,y:764,t:1527272021064};\\\", \\\"{x:1196,y:764,t:1527272021081};\\\", \\\"{x:1202,y:762,t:1527272021098};\\\", \\\"{x:1210,y:759,t:1527272021114};\\\", \\\"{x:1220,y:759,t:1527272021132};\\\", \\\"{x:1229,y:758,t:1527272021148};\\\", \\\"{x:1236,y:756,t:1527272021165};\\\", \\\"{x:1243,y:754,t:1527272021182};\\\", \\\"{x:1245,y:754,t:1527272021199};\\\", \\\"{x:1250,y:753,t:1527272021215};\\\", \\\"{x:1254,y:753,t:1527272021231};\\\", \\\"{x:1257,y:753,t:1527272021249};\\\", \\\"{x:1258,y:753,t:1527272021272};\\\", \\\"{x:1260,y:753,t:1527272021281};\\\", \\\"{x:1265,y:753,t:1527272021298};\\\", \\\"{x:1274,y:753,t:1527272021316};\\\", \\\"{x:1280,y:753,t:1527272021331};\\\", \\\"{x:1282,y:753,t:1527272021348};\\\", \\\"{x:1284,y:753,t:1527272021365};\\\", \\\"{x:1286,y:753,t:1527272021381};\\\", \\\"{x:1287,y:753,t:1527272021398};\\\", \\\"{x:1289,y:753,t:1527272021416};\\\", \\\"{x:1294,y:753,t:1527272021433};\\\", \\\"{x:1300,y:753,t:1527272021448};\\\", \\\"{x:1305,y:753,t:1527272021465};\\\", \\\"{x:1308,y:753,t:1527272021482};\\\", \\\"{x:1309,y:753,t:1527272021503};\\\", \\\"{x:1310,y:753,t:1527272021519};\\\", \\\"{x:1312,y:753,t:1527272021532};\\\", \\\"{x:1317,y:754,t:1527272021549};\\\", \\\"{x:1320,y:754,t:1527272021564};\\\", \\\"{x:1322,y:754,t:1527272021582};\\\", \\\"{x:1323,y:754,t:1527272021598};\\\", \\\"{x:1325,y:754,t:1527272021631};\\\", \\\"{x:1328,y:754,t:1527272021639};\\\", \\\"{x:1330,y:754,t:1527272021650};\\\", \\\"{x:1332,y:754,t:1527272021666};\\\", \\\"{x:1333,y:754,t:1527272021682};\\\", \\\"{x:1336,y:754,t:1527272021751};\\\", \\\"{x:1339,y:754,t:1527272021767};\\\", \\\"{x:1353,y:754,t:1527272021782};\\\", \\\"{x:1355,y:754,t:1527272021824};\\\", \\\"{x:1355,y:755,t:1527272021959};\\\", \\\"{x:1354,y:756,t:1527272021982};\\\", \\\"{x:1353,y:756,t:1527272022006};\\\", \\\"{x:1352,y:756,t:1527272022030};\\\", \\\"{x:1351,y:756,t:1527272022038};\\\", \\\"{x:1350,y:757,t:1527272022054};\\\", \\\"{x:1349,y:758,t:1527272022087};\\\", \\\"{x:1347,y:759,t:1527272022117};\\\", \\\"{x:1346,y:759,t:1527272022142};\\\", \\\"{x:1345,y:760,t:1527272022150};\\\", \\\"{x:1344,y:760,t:1527272022246};\\\", \\\"{x:1343,y:761,t:1527272022270};\\\", \\\"{x:1342,y:761,t:1527272022343};\\\", \\\"{x:1341,y:761,t:1527272030584};\\\", \\\"{x:1337,y:763,t:1527272030591};\\\", \\\"{x:1327,y:770,t:1527272030608};\\\", \\\"{x:1319,y:774,t:1527272030623};\\\", \\\"{x:1316,y:776,t:1527272030639};\\\", \\\"{x:1312,y:779,t:1527272030657};\\\", \\\"{x:1309,y:781,t:1527272030674};\\\", \\\"{x:1305,y:784,t:1527272030690};\\\", \\\"{x:1300,y:787,t:1527272030707};\\\", \\\"{x:1295,y:791,t:1527272030724};\\\", \\\"{x:1290,y:796,t:1527272030740};\\\", \\\"{x:1286,y:798,t:1527272030757};\\\", \\\"{x:1283,y:801,t:1527272030774};\\\", \\\"{x:1280,y:802,t:1527272030790};\\\", \\\"{x:1272,y:805,t:1527272030807};\\\", \\\"{x:1266,y:808,t:1527272030824};\\\", \\\"{x:1264,y:809,t:1527272030840};\\\", \\\"{x:1262,y:810,t:1527272030856};\\\", \\\"{x:1261,y:811,t:1527272030874};\\\", \\\"{x:1259,y:812,t:1527272030890};\\\", \\\"{x:1256,y:814,t:1527272030907};\\\", \\\"{x:1253,y:816,t:1527272030924};\\\", \\\"{x:1252,y:816,t:1527272030941};\\\", \\\"{x:1251,y:816,t:1527272030992};\\\", \\\"{x:1248,y:817,t:1527272031007};\\\", \\\"{x:1247,y:818,t:1527272031023};\\\", \\\"{x:1245,y:819,t:1527272031063};\\\", \\\"{x:1243,y:820,t:1527272031279};\\\", \\\"{x:1242,y:820,t:1527272031319};\\\", \\\"{x:1241,y:821,t:1527272031327};\\\", \\\"{x:1240,y:821,t:1527272031344};\\\", \\\"{x:1236,y:822,t:1527272031359};\\\", \\\"{x:1233,y:823,t:1527272031375};\\\", \\\"{x:1229,y:825,t:1527272031392};\\\", \\\"{x:1228,y:825,t:1527272031409};\\\", \\\"{x:1226,y:825,t:1527272031425};\\\", \\\"{x:1225,y:826,t:1527272031442};\\\", \\\"{x:1222,y:827,t:1527272031458};\\\", \\\"{x:1218,y:827,t:1527272031476};\\\", \\\"{x:1210,y:828,t:1527272031492};\\\", \\\"{x:1203,y:828,t:1527272031510};\\\", \\\"{x:1198,y:828,t:1527272031526};\\\", \\\"{x:1194,y:828,t:1527272031542};\\\", \\\"{x:1187,y:828,t:1527272031559};\\\", \\\"{x:1172,y:828,t:1527272031575};\\\", \\\"{x:1147,y:828,t:1527272031593};\\\", \\\"{x:1100,y:828,t:1527272031609};\\\", \\\"{x:1024,y:826,t:1527272031626};\\\", \\\"{x:937,y:811,t:1527272031643};\\\", \\\"{x:840,y:797,t:1527272031659};\\\", \\\"{x:738,y:785,t:1527272031676};\\\", \\\"{x:640,y:770,t:1527272031693};\\\", \\\"{x:557,y:761,t:1527272031709};\\\", \\\"{x:517,y:752,t:1527272031726};\\\", \\\"{x:492,y:741,t:1527272031742};\\\", \\\"{x:491,y:740,t:1527272031759};\\\", \\\"{x:490,y:738,t:1527272031778};\\\", \\\"{x:490,y:727,t:1527272031795};\\\", \\\"{x:490,y:716,t:1527272031812};\\\", \\\"{x:492,y:711,t:1527272031828};\\\", \\\"{x:494,y:707,t:1527272031845};\\\", \\\"{x:498,y:702,t:1527272031861};\\\", \\\"{x:505,y:693,t:1527272031879};\\\", \\\"{x:508,y:688,t:1527272031895};\\\", \\\"{x:509,y:683,t:1527272031912};\\\", \\\"{x:510,y:678,t:1527272031929};\\\", \\\"{x:510,y:674,t:1527272031945};\\\", \\\"{x:510,y:668,t:1527272031962};\\\", \\\"{x:506,y:659,t:1527272031978};\\\", \\\"{x:493,y:653,t:1527272031995};\\\", \\\"{x:475,y:645,t:1527272032011};\\\", \\\"{x:456,y:640,t:1527272032028};\\\", \\\"{x:441,y:637,t:1527272032046};\\\", \\\"{x:421,y:631,t:1527272032063};\\\", \\\"{x:411,y:629,t:1527272032079};\\\", \\\"{x:401,y:629,t:1527272032095};\\\", \\\"{x:387,y:627,t:1527272032113};\\\", \\\"{x:373,y:625,t:1527272032130};\\\", \\\"{x:360,y:625,t:1527272032147};\\\", \\\"{x:345,y:625,t:1527272032163};\\\", \\\"{x:323,y:625,t:1527272032179};\\\", \\\"{x:302,y:625,t:1527272032196};\\\", \\\"{x:281,y:625,t:1527272032213};\\\", \\\"{x:262,y:625,t:1527272032231};\\\", \\\"{x:237,y:625,t:1527272032246};\\\", \\\"{x:218,y:625,t:1527272032263};\\\", \\\"{x:198,y:625,t:1527272032280};\\\", \\\"{x:184,y:625,t:1527272032296};\\\", \\\"{x:178,y:625,t:1527272032312};\\\", \\\"{x:177,y:624,t:1527272032383};\\\", \\\"{x:175,y:623,t:1527272032396};\\\", \\\"{x:174,y:621,t:1527272032413};\\\", \\\"{x:173,y:618,t:1527272032430};\\\", \\\"{x:173,y:611,t:1527272032446};\\\", \\\"{x:185,y:589,t:1527272032465};\\\", \\\"{x:187,y:587,t:1527272032479};\\\", \\\"{x:187,y:586,t:1527272032534};\\\", \\\"{x:187,y:584,t:1527272032647};\\\", \\\"{x:187,y:581,t:1527272032662};\\\", \\\"{x:187,y:575,t:1527272032680};\\\", \\\"{x:185,y:565,t:1527272032697};\\\", \\\"{x:181,y:552,t:1527272032714};\\\", \\\"{x:176,y:540,t:1527272032730};\\\", \\\"{x:175,y:530,t:1527272032747};\\\", \\\"{x:170,y:520,t:1527272032763};\\\", \\\"{x:168,y:517,t:1527272032780};\\\", \\\"{x:168,y:516,t:1527272032796};\\\", \\\"{x:168,y:514,t:1527272032813};\\\", \\\"{x:168,y:512,t:1527272032830};\\\", \\\"{x:168,y:511,t:1527272032910};\\\", \\\"{x:169,y:511,t:1527272033302};\\\", \\\"{x:179,y:516,t:1527272033314};\\\", \\\"{x:195,y:526,t:1527272033332};\\\", \\\"{x:202,y:530,t:1527272033347};\\\", \\\"{x:207,y:536,t:1527272033363};\\\", \\\"{x:216,y:545,t:1527272033381};\\\", \\\"{x:241,y:564,t:1527272033398};\\\", \\\"{x:291,y:598,t:1527272033415};\\\", \\\"{x:380,y:645,t:1527272033430};\\\", \\\"{x:410,y:662,t:1527272033447};\\\", \\\"{x:428,y:673,t:1527272033463};\\\", \\\"{x:438,y:681,t:1527272033481};\\\", \\\"{x:441,y:684,t:1527272033496};\\\", \\\"{x:444,y:688,t:1527272033514};\\\", \\\"{x:446,y:691,t:1527272033531};\\\", \\\"{x:453,y:700,t:1527272033547};\\\", \\\"{x:462,y:712,t:1527272033564};\\\", \\\"{x:470,y:722,t:1527272033581};\\\", \\\"{x:479,y:733,t:1527272033598};\\\", \\\"{x:484,y:738,t:1527272033613};\\\", \\\"{x:485,y:739,t:1527272033647};\\\", \\\"{x:487,y:742,t:1527272033663};\\\", \\\"{x:491,y:745,t:1527272033681};\\\", \\\"{x:492,y:746,t:1527272033702};\\\" ] }, { \\\"rt\\\": 45020, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 1025254, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -F -06 PM-05 PM-04 PM-M -J -B -G -M -04 PM-O -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:746,t:1527272037351};\\\", \\\"{x:524,y:742,t:1527272037372};\\\", \\\"{x:562,y:742,t:1527272037378};\\\", \\\"{x:709,y:720,t:1527272037390};\\\", \\\"{x:942,y:704,t:1527272037407};\\\", \\\"{x:1170,y:715,t:1527272037424};\\\", \\\"{x:1261,y:742,t:1527272037434};\\\", \\\"{x:1395,y:792,t:1527272037450};\\\", \\\"{x:1451,y:819,t:1527272037467};\\\", \\\"{x:1467,y:826,t:1527272037483};\\\", \\\"{x:1471,y:827,t:1527272037499};\\\", \\\"{x:1488,y:832,t:1527272037517};\\\", \\\"{x:1514,y:832,t:1527272037534};\\\", \\\"{x:1540,y:827,t:1527272037550};\\\", \\\"{x:1572,y:821,t:1527272037567};\\\", \\\"{x:1575,y:820,t:1527272037584};\\\", \\\"{x:1579,y:817,t:1527272037599};\\\", \\\"{x:1591,y:813,t:1527272037617};\\\", \\\"{x:1609,y:805,t:1527272037634};\\\", \\\"{x:1622,y:803,t:1527272037650};\\\", \\\"{x:1627,y:802,t:1527272037667};\\\", \\\"{x:1628,y:802,t:1527272038079};\\\", \\\"{x:1632,y:804,t:1527272038086};\\\", \\\"{x:1640,y:809,t:1527272038100};\\\", \\\"{x:1656,y:820,t:1527272038116};\\\", \\\"{x:1675,y:829,t:1527272038134};\\\", \\\"{x:1698,y:840,t:1527272038150};\\\", \\\"{x:1705,y:844,t:1527272038168};\\\", \\\"{x:1707,y:845,t:1527272038183};\\\", \\\"{x:1704,y:845,t:1527272038288};\\\", \\\"{x:1695,y:843,t:1527272038301};\\\", \\\"{x:1672,y:833,t:1527272038319};\\\", \\\"{x:1657,y:828,t:1527272038334};\\\", \\\"{x:1645,y:823,t:1527272038351};\\\", \\\"{x:1638,y:817,t:1527272038368};\\\", \\\"{x:1627,y:809,t:1527272038384};\\\", \\\"{x:1620,y:802,t:1527272038401};\\\", \\\"{x:1616,y:799,t:1527272038418};\\\", \\\"{x:1615,y:796,t:1527272038434};\\\", \\\"{x:1615,y:793,t:1527272038451};\\\", \\\"{x:1613,y:789,t:1527272038469};\\\", \\\"{x:1613,y:786,t:1527272038485};\\\", \\\"{x:1612,y:783,t:1527272038502};\\\", \\\"{x:1612,y:781,t:1527272038518};\\\", \\\"{x:1612,y:780,t:1527272038534};\\\", \\\"{x:1612,y:779,t:1527272038647};\\\", \\\"{x:1611,y:777,t:1527272038655};\\\", \\\"{x:1610,y:777,t:1527272038668};\\\", \\\"{x:1609,y:776,t:1527272038685};\\\", \\\"{x:1606,y:775,t:1527272038701};\\\", \\\"{x:1603,y:773,t:1527272038718};\\\", \\\"{x:1596,y:770,t:1527272038735};\\\", \\\"{x:1588,y:770,t:1527272038751};\\\", \\\"{x:1582,y:769,t:1527272038768};\\\", \\\"{x:1579,y:769,t:1527272038785};\\\", \\\"{x:1577,y:769,t:1527272038801};\\\", \\\"{x:1576,y:769,t:1527272038855};\\\", \\\"{x:1574,y:769,t:1527272038871};\\\", \\\"{x:1573,y:769,t:1527272038887};\\\", \\\"{x:1572,y:769,t:1527272038901};\\\", \\\"{x:1571,y:768,t:1527272038919};\\\", \\\"{x:1564,y:766,t:1527272038935};\\\", \\\"{x:1556,y:764,t:1527272038951};\\\", \\\"{x:1549,y:762,t:1527272038969};\\\", \\\"{x:1532,y:761,t:1527272038985};\\\", \\\"{x:1503,y:761,t:1527272039001};\\\", \\\"{x:1473,y:764,t:1527272039018};\\\", \\\"{x:1448,y:768,t:1527272039035};\\\", \\\"{x:1419,y:774,t:1527272039051};\\\", \\\"{x:1395,y:777,t:1527272039068};\\\", \\\"{x:1374,y:779,t:1527272039085};\\\", \\\"{x:1370,y:779,t:1527272039102};\\\", \\\"{x:1368,y:777,t:1527272039135};\\\", \\\"{x:1366,y:766,t:1527272039152};\\\", \\\"{x:1356,y:755,t:1527272039168};\\\", \\\"{x:1354,y:751,t:1527272039185};\\\", \\\"{x:1354,y:746,t:1527272039202};\\\", \\\"{x:1353,y:738,t:1527272039218};\\\", \\\"{x:1351,y:733,t:1527272039235};\\\", \\\"{x:1349,y:730,t:1527272039252};\\\", \\\"{x:1349,y:729,t:1527272039271};\\\", \\\"{x:1349,y:728,t:1527272039285};\\\", \\\"{x:1359,y:723,t:1527272039302};\\\", \\\"{x:1367,y:719,t:1527272039319};\\\", \\\"{x:1368,y:718,t:1527272039335};\\\", \\\"{x:1368,y:716,t:1527272039352};\\\", \\\"{x:1368,y:711,t:1527272039368};\\\", \\\"{x:1367,y:709,t:1527272039386};\\\", \\\"{x:1366,y:706,t:1527272039402};\\\", \\\"{x:1364,y:704,t:1527272039418};\\\", \\\"{x:1363,y:702,t:1527272039435};\\\", \\\"{x:1361,y:701,t:1527272039452};\\\", \\\"{x:1359,y:699,t:1527272039623};\\\", \\\"{x:1358,y:698,t:1527272039635};\\\", \\\"{x:1357,y:697,t:1527272039651};\\\", \\\"{x:1356,y:697,t:1527272039669};\\\", \\\"{x:1356,y:696,t:1527272039719};\\\", \\\"{x:1358,y:701,t:1527272040311};\\\", \\\"{x:1367,y:716,t:1527272040319};\\\", \\\"{x:1383,y:736,t:1527272040336};\\\", \\\"{x:1389,y:746,t:1527272040353};\\\", \\\"{x:1394,y:758,t:1527272040370};\\\", \\\"{x:1397,y:767,t:1527272040386};\\\", \\\"{x:1398,y:772,t:1527272040403};\\\", \\\"{x:1398,y:782,t:1527272040419};\\\", \\\"{x:1397,y:797,t:1527272040436};\\\", \\\"{x:1397,y:818,t:1527272040452};\\\", \\\"{x:1404,y:845,t:1527272040469};\\\", \\\"{x:1407,y:863,t:1527272040486};\\\", \\\"{x:1407,y:871,t:1527272040502};\\\", \\\"{x:1407,y:874,t:1527272040519};\\\", \\\"{x:1407,y:875,t:1527272040542};\\\", \\\"{x:1407,y:877,t:1527272040554};\\\", \\\"{x:1407,y:886,t:1527272040569};\\\", \\\"{x:1407,y:903,t:1527272040586};\\\", \\\"{x:1407,y:922,t:1527272040603};\\\", \\\"{x:1403,y:928,t:1527272040619};\\\", \\\"{x:1402,y:941,t:1527272040637};\\\", \\\"{x:1396,y:951,t:1527272040653};\\\", \\\"{x:1392,y:956,t:1527272040670};\\\", \\\"{x:1388,y:965,t:1527272040686};\\\", \\\"{x:1382,y:976,t:1527272040703};\\\", \\\"{x:1380,y:979,t:1527272040719};\\\", \\\"{x:1380,y:976,t:1527272040847};\\\", \\\"{x:1379,y:973,t:1527272040854};\\\", \\\"{x:1379,y:969,t:1527272040869};\\\", \\\"{x:1378,y:965,t:1527272040886};\\\", \\\"{x:1377,y:962,t:1527272040903};\\\", \\\"{x:1377,y:961,t:1527272040927};\\\", \\\"{x:1377,y:960,t:1527272040951};\\\", \\\"{x:1377,y:959,t:1527272040959};\\\", \\\"{x:1377,y:958,t:1527272040970};\\\", \\\"{x:1377,y:953,t:1527272040986};\\\", \\\"{x:1377,y:951,t:1527272041003};\\\", \\\"{x:1379,y:946,t:1527272041020};\\\", \\\"{x:1381,y:937,t:1527272041037};\\\", \\\"{x:1382,y:914,t:1527272041053};\\\", \\\"{x:1382,y:884,t:1527272041071};\\\", \\\"{x:1376,y:861,t:1527272041087};\\\", \\\"{x:1373,y:840,t:1527272041103};\\\", \\\"{x:1375,y:826,t:1527272041120};\\\", \\\"{x:1379,y:814,t:1527272041136};\\\", \\\"{x:1379,y:808,t:1527272041153};\\\", \\\"{x:1379,y:803,t:1527272041171};\\\", \\\"{x:1379,y:801,t:1527272041187};\\\", \\\"{x:1379,y:798,t:1527272041203};\\\", \\\"{x:1379,y:795,t:1527272041220};\\\", \\\"{x:1379,y:788,t:1527272041237};\\\", \\\"{x:1378,y:776,t:1527272041253};\\\", \\\"{x:1375,y:764,t:1527272041270};\\\", \\\"{x:1374,y:760,t:1527272041287};\\\", \\\"{x:1375,y:757,t:1527272041303};\\\", \\\"{x:1376,y:755,t:1527272041320};\\\", \\\"{x:1375,y:755,t:1527272041399};\\\", \\\"{x:1373,y:760,t:1527272041407};\\\", \\\"{x:1369,y:772,t:1527272041421};\\\", \\\"{x:1363,y:794,t:1527272041436};\\\", \\\"{x:1358,y:813,t:1527272041454};\\\", \\\"{x:1352,y:829,t:1527272041470};\\\", \\\"{x:1349,y:838,t:1527272041487};\\\", \\\"{x:1348,y:841,t:1527272041504};\\\", \\\"{x:1348,y:850,t:1527272041520};\\\", \\\"{x:1348,y:861,t:1527272041537};\\\", \\\"{x:1350,y:869,t:1527272041553};\\\", \\\"{x:1353,y:876,t:1527272041570};\\\", \\\"{x:1354,y:879,t:1527272041588};\\\", \\\"{x:1354,y:880,t:1527272041607};\\\", \\\"{x:1354,y:883,t:1527272041620};\\\", \\\"{x:1358,y:895,t:1527272041637};\\\", \\\"{x:1365,y:919,t:1527272041654};\\\", \\\"{x:1380,y:977,t:1527272041671};\\\", \\\"{x:1383,y:992,t:1527272041687};\\\", \\\"{x:1383,y:999,t:1527272041704};\\\", \\\"{x:1383,y:1000,t:1527272041720};\\\", \\\"{x:1382,y:992,t:1527272041792};\\\", \\\"{x:1378,y:982,t:1527272041803};\\\", \\\"{x:1376,y:961,t:1527272041821};\\\", \\\"{x:1373,y:940,t:1527272041837};\\\", \\\"{x:1371,y:925,t:1527272041853};\\\", \\\"{x:1371,y:914,t:1527272041870};\\\", \\\"{x:1371,y:885,t:1527272041887};\\\", \\\"{x:1366,y:863,t:1527272041904};\\\", \\\"{x:1364,y:841,t:1527272041921};\\\", \\\"{x:1361,y:819,t:1527272041938};\\\", \\\"{x:1361,y:801,t:1527272041955};\\\", \\\"{x:1362,y:786,t:1527272041971};\\\", \\\"{x:1364,y:777,t:1527272041988};\\\", \\\"{x:1365,y:769,t:1527272042004};\\\", \\\"{x:1365,y:762,t:1527272042021};\\\", \\\"{x:1363,y:752,t:1527272042037};\\\", \\\"{x:1361,y:745,t:1527272042055};\\\", \\\"{x:1360,y:743,t:1527272042071};\\\", \\\"{x:1360,y:741,t:1527272042088};\\\", \\\"{x:1360,y:740,t:1527272042127};\\\", \\\"{x:1360,y:738,t:1527272042137};\\\", \\\"{x:1359,y:734,t:1527272042155};\\\", \\\"{x:1359,y:727,t:1527272042171};\\\", \\\"{x:1358,y:723,t:1527272042187};\\\", \\\"{x:1357,y:718,t:1527272042204};\\\", \\\"{x:1356,y:714,t:1527272042221};\\\", \\\"{x:1356,y:711,t:1527272042237};\\\", \\\"{x:1356,y:709,t:1527272042255};\\\", \\\"{x:1356,y:707,t:1527272042271};\\\", \\\"{x:1356,y:706,t:1527272042287};\\\", \\\"{x:1356,y:704,t:1527272042319};\\\", \\\"{x:1356,y:702,t:1527272042337};\\\", \\\"{x:1356,y:700,t:1527272042399};\\\", \\\"{x:1355,y:698,t:1527272042407};\\\", \\\"{x:1354,y:697,t:1527272042421};\\\", \\\"{x:1352,y:697,t:1527272042440};\\\", \\\"{x:1351,y:697,t:1527272042470};\\\", \\\"{x:1350,y:697,t:1527272042487};\\\", \\\"{x:1348,y:697,t:1527272042504};\\\", \\\"{x:1345,y:696,t:1527272042522};\\\", \\\"{x:1344,y:695,t:1527272042537};\\\", \\\"{x:1344,y:697,t:1527272046071};\\\", \\\"{x:1348,y:707,t:1527272046080};\\\", \\\"{x:1355,y:715,t:1527272046091};\\\", \\\"{x:1380,y:733,t:1527272046106};\\\", \\\"{x:1400,y:745,t:1527272046123};\\\", \\\"{x:1418,y:755,t:1527272046140};\\\", \\\"{x:1432,y:763,t:1527272046156};\\\", \\\"{x:1449,y:772,t:1527272046173};\\\", \\\"{x:1484,y:791,t:1527272046189};\\\", \\\"{x:1519,y:805,t:1527272046206};\\\", \\\"{x:1569,y:826,t:1527272046223};\\\", \\\"{x:1618,y:847,t:1527272046240};\\\", \\\"{x:1659,y:861,t:1527272046257};\\\", \\\"{x:1702,y:873,t:1527272046273};\\\", \\\"{x:1743,y:884,t:1527272046290};\\\", \\\"{x:1777,y:899,t:1527272046307};\\\", \\\"{x:1793,y:906,t:1527272046323};\\\", \\\"{x:1795,y:908,t:1527272046340};\\\", \\\"{x:1795,y:910,t:1527272046358};\\\", \\\"{x:1795,y:916,t:1527272046373};\\\", \\\"{x:1798,y:926,t:1527272046391};\\\", \\\"{x:1798,y:930,t:1527272046407};\\\", \\\"{x:1798,y:934,t:1527272046424};\\\", \\\"{x:1796,y:938,t:1527272046440};\\\", \\\"{x:1790,y:941,t:1527272046458};\\\", \\\"{x:1786,y:946,t:1527272046473};\\\", \\\"{x:1785,y:951,t:1527272046490};\\\", \\\"{x:1784,y:957,t:1527272046507};\\\", \\\"{x:1782,y:962,t:1527272046523};\\\", \\\"{x:1776,y:967,t:1527272046540};\\\", \\\"{x:1768,y:971,t:1527272046557};\\\", \\\"{x:1751,y:976,t:1527272046573};\\\", \\\"{x:1726,y:980,t:1527272046592};\\\", \\\"{x:1714,y:982,t:1527272046607};\\\", \\\"{x:1702,y:982,t:1527272046624};\\\", \\\"{x:1689,y:982,t:1527272046641};\\\", \\\"{x:1671,y:982,t:1527272046657};\\\", \\\"{x:1648,y:976,t:1527272046674};\\\", \\\"{x:1630,y:972,t:1527272046691};\\\", \\\"{x:1622,y:968,t:1527272046708};\\\", \\\"{x:1620,y:968,t:1527272046725};\\\", \\\"{x:1619,y:967,t:1527272046741};\\\", \\\"{x:1619,y:966,t:1527272046757};\\\", \\\"{x:1619,y:963,t:1527272046775};\\\", \\\"{x:1616,y:960,t:1527272046791};\\\", \\\"{x:1616,y:959,t:1527272046807};\\\", \\\"{x:1616,y:958,t:1527272047872};\\\", \\\"{x:1616,y:957,t:1527272047895};\\\", \\\"{x:1616,y:956,t:1527272048119};\\\", \\\"{x:1616,y:955,t:1527272048206};\\\", \\\"{x:1612,y:952,t:1527272048214};\\\", \\\"{x:1605,y:949,t:1527272048225};\\\", \\\"{x:1595,y:945,t:1527272048241};\\\", \\\"{x:1585,y:942,t:1527272048258};\\\", \\\"{x:1575,y:940,t:1527272048275};\\\", \\\"{x:1569,y:937,t:1527272048291};\\\", \\\"{x:1562,y:936,t:1527272048308};\\\", \\\"{x:1558,y:934,t:1527272048325};\\\", \\\"{x:1549,y:932,t:1527272048341};\\\", \\\"{x:1530,y:927,t:1527272048358};\\\", \\\"{x:1515,y:924,t:1527272048375};\\\", \\\"{x:1497,y:922,t:1527272048391};\\\", \\\"{x:1490,y:921,t:1527272048409};\\\", \\\"{x:1489,y:921,t:1527272048426};\\\", \\\"{x:1488,y:921,t:1527272048441};\\\", \\\"{x:1486,y:921,t:1527272048463};\\\", \\\"{x:1484,y:920,t:1527272048475};\\\", \\\"{x:1478,y:919,t:1527272048492};\\\", \\\"{x:1463,y:918,t:1527272048509};\\\", \\\"{x:1450,y:915,t:1527272048525};\\\", \\\"{x:1440,y:914,t:1527272048541};\\\", \\\"{x:1425,y:910,t:1527272048559};\\\", \\\"{x:1411,y:908,t:1527272048575};\\\", \\\"{x:1399,y:904,t:1527272048592};\\\", \\\"{x:1396,y:903,t:1527272048609};\\\", \\\"{x:1395,y:903,t:1527272048626};\\\", \\\"{x:1394,y:903,t:1527272048642};\\\", \\\"{x:1392,y:903,t:1527272048886};\\\", \\\"{x:1391,y:903,t:1527272048894};\\\", \\\"{x:1390,y:903,t:1527272048908};\\\", \\\"{x:1388,y:901,t:1527272048925};\\\", \\\"{x:1384,y:900,t:1527272048942};\\\", \\\"{x:1383,y:900,t:1527272048958};\\\", \\\"{x:1382,y:899,t:1527272049167};\\\", \\\"{x:1381,y:899,t:1527272049327};\\\", \\\"{x:1379,y:895,t:1527272049343};\\\", \\\"{x:1376,y:892,t:1527272049360};\\\", \\\"{x:1374,y:891,t:1527272049376};\\\", \\\"{x:1373,y:890,t:1527272049393};\\\", \\\"{x:1372,y:890,t:1527272049791};\\\", \\\"{x:1367,y:889,t:1527272049810};\\\", \\\"{x:1362,y:887,t:1527272049826};\\\", \\\"{x:1351,y:885,t:1527272049843};\\\", \\\"{x:1340,y:883,t:1527272049859};\\\", \\\"{x:1335,y:881,t:1527272049876};\\\", \\\"{x:1329,y:879,t:1527272049893};\\\", \\\"{x:1326,y:878,t:1527272049910};\\\", \\\"{x:1321,y:875,t:1527272049927};\\\", \\\"{x:1314,y:873,t:1527272049942};\\\", \\\"{x:1311,y:873,t:1527272049959};\\\", \\\"{x:1309,y:873,t:1527272049977};\\\", \\\"{x:1307,y:873,t:1527272050039};\\\", \\\"{x:1306,y:873,t:1527272050047};\\\", \\\"{x:1303,y:873,t:1527272050060};\\\", \\\"{x:1299,y:871,t:1527272050078};\\\", \\\"{x:1294,y:871,t:1527272050093};\\\", \\\"{x:1287,y:869,t:1527272050109};\\\", \\\"{x:1279,y:867,t:1527272050127};\\\", \\\"{x:1275,y:866,t:1527272050143};\\\", \\\"{x:1272,y:865,t:1527272050160};\\\", \\\"{x:1269,y:865,t:1527272050176};\\\", \\\"{x:1267,y:864,t:1527272050194};\\\", \\\"{x:1266,y:863,t:1527272050210};\\\", \\\"{x:1265,y:863,t:1527272050231};\\\", \\\"{x:1264,y:863,t:1527272050255};\\\", \\\"{x:1262,y:862,t:1527272050263};\\\", \\\"{x:1259,y:861,t:1527272050279};\\\", \\\"{x:1255,y:860,t:1527272050294};\\\", \\\"{x:1251,y:859,t:1527272050309};\\\", \\\"{x:1247,y:858,t:1527272050326};\\\", \\\"{x:1243,y:856,t:1527272050343};\\\", \\\"{x:1242,y:856,t:1527272050359};\\\", \\\"{x:1240,y:854,t:1527272050376};\\\", \\\"{x:1237,y:852,t:1527272050394};\\\", \\\"{x:1230,y:851,t:1527272050410};\\\", \\\"{x:1229,y:849,t:1527272050431};\\\", \\\"{x:1228,y:849,t:1527272050479};\\\", \\\"{x:1227,y:849,t:1527272050494};\\\", \\\"{x:1227,y:848,t:1527272050575};\\\", \\\"{x:1226,y:848,t:1527272050591};\\\", \\\"{x:1226,y:847,t:1527272050606};\\\", \\\"{x:1225,y:846,t:1527272050639};\\\", \\\"{x:1224,y:846,t:1527272050647};\\\", \\\"{x:1224,y:845,t:1527272050727};\\\", \\\"{x:1224,y:844,t:1527272050744};\\\", \\\"{x:1224,y:843,t:1527272050760};\\\", \\\"{x:1224,y:842,t:1527272050777};\\\", \\\"{x:1223,y:842,t:1527272050831};\\\", \\\"{x:1223,y:841,t:1527272050895};\\\", \\\"{x:1223,y:840,t:1527272050911};\\\", \\\"{x:1223,y:839,t:1527272050959};\\\", \\\"{x:1223,y:837,t:1527272050983};\\\", \\\"{x:1221,y:836,t:1527272051007};\\\", \\\"{x:1221,y:835,t:1527272051079};\\\", \\\"{x:1220,y:834,t:1527272051111};\\\", \\\"{x:1219,y:833,t:1527272051129};\\\", \\\"{x:1218,y:832,t:1527272051143};\\\", \\\"{x:1217,y:831,t:1527272051167};\\\", \\\"{x:1218,y:830,t:1527272052175};\\\", \\\"{x:1219,y:830,t:1527272052182};\\\", \\\"{x:1221,y:830,t:1527272052196};\\\", \\\"{x:1224,y:829,t:1527272052212};\\\", \\\"{x:1225,y:828,t:1527272052227};\\\", \\\"{x:1227,y:828,t:1527272052245};\\\", \\\"{x:1228,y:827,t:1527272052263};\\\", \\\"{x:1230,y:827,t:1527272052278};\\\", \\\"{x:1234,y:826,t:1527272052295};\\\", \\\"{x:1236,y:826,t:1527272052312};\\\", \\\"{x:1238,y:824,t:1527272052328};\\\", \\\"{x:1241,y:823,t:1527272052345};\\\", \\\"{x:1243,y:823,t:1527272052367};\\\", \\\"{x:1244,y:823,t:1527272052378};\\\", \\\"{x:1249,y:821,t:1527272052395};\\\", \\\"{x:1256,y:819,t:1527272052412};\\\", \\\"{x:1261,y:817,t:1527272052429};\\\", \\\"{x:1263,y:816,t:1527272052445};\\\", \\\"{x:1264,y:816,t:1527272052462};\\\", \\\"{x:1266,y:815,t:1527272052478};\\\", \\\"{x:1268,y:815,t:1527272052495};\\\", \\\"{x:1271,y:815,t:1527272052511};\\\", \\\"{x:1275,y:812,t:1527272052529};\\\", \\\"{x:1278,y:812,t:1527272052545};\\\", \\\"{x:1281,y:811,t:1527272052562};\\\", \\\"{x:1285,y:809,t:1527272052579};\\\", \\\"{x:1287,y:808,t:1527272052594};\\\", \\\"{x:1292,y:807,t:1527272052612};\\\", \\\"{x:1293,y:805,t:1527272052629};\\\", \\\"{x:1295,y:805,t:1527272052645};\\\", \\\"{x:1297,y:804,t:1527272052671};\\\", \\\"{x:1297,y:803,t:1527272052678};\\\", \\\"{x:1301,y:802,t:1527272052695};\\\", \\\"{x:1302,y:801,t:1527272052712};\\\", \\\"{x:1307,y:798,t:1527272052729};\\\", \\\"{x:1309,y:798,t:1527272052745};\\\", \\\"{x:1310,y:797,t:1527272052767};\\\", \\\"{x:1312,y:796,t:1527272052783};\\\", \\\"{x:1313,y:795,t:1527272052795};\\\", \\\"{x:1316,y:794,t:1527272052812};\\\", \\\"{x:1320,y:792,t:1527272052829};\\\", \\\"{x:1322,y:791,t:1527272052845};\\\", \\\"{x:1323,y:791,t:1527272052862};\\\", \\\"{x:1325,y:789,t:1527272052879};\\\", \\\"{x:1327,y:788,t:1527272052895};\\\", \\\"{x:1330,y:787,t:1527272052912};\\\", \\\"{x:1332,y:785,t:1527272052929};\\\", \\\"{x:1334,y:784,t:1527272052946};\\\", \\\"{x:1337,y:782,t:1527272052962};\\\", \\\"{x:1338,y:782,t:1527272052991};\\\", \\\"{x:1338,y:781,t:1527272053039};\\\", \\\"{x:1338,y:779,t:1527272053055};\\\", \\\"{x:1339,y:779,t:1527272053063};\\\", \\\"{x:1340,y:779,t:1527272053167};\\\", \\\"{x:1340,y:778,t:1527272053223};\\\", \\\"{x:1340,y:777,t:1527272053231};\\\", \\\"{x:1340,y:776,t:1527272053246};\\\", \\\"{x:1341,y:776,t:1527272053262};\\\", \\\"{x:1343,y:774,t:1527272053279};\\\", \\\"{x:1344,y:774,t:1527272053296};\\\", \\\"{x:1345,y:773,t:1527272053312};\\\", \\\"{x:1345,y:772,t:1527272053367};\\\", \\\"{x:1346,y:772,t:1527272053378};\\\", \\\"{x:1347,y:770,t:1527272053396};\\\", \\\"{x:1347,y:769,t:1527272053415};\\\", \\\"{x:1348,y:767,t:1527272053439};\\\", \\\"{x:1348,y:766,t:1527272053519};\\\", \\\"{x:1349,y:765,t:1527272053623};\\\", \\\"{x:1349,y:764,t:1527272053638};\\\", \\\"{x:1349,y:763,t:1527272053663};\\\", \\\"{x:1350,y:762,t:1527272053679};\\\", \\\"{x:1350,y:761,t:1527272053696};\\\", \\\"{x:1349,y:761,t:1527272055150};\\\", \\\"{x:1347,y:761,t:1527272055163};\\\", \\\"{x:1344,y:761,t:1527272055179};\\\", \\\"{x:1342,y:762,t:1527272055196};\\\", \\\"{x:1340,y:762,t:1527272055214};\\\", \\\"{x:1339,y:763,t:1527272055287};\\\", \\\"{x:1339,y:762,t:1527272056016};\\\", \\\"{x:1339,y:758,t:1527272056031};\\\", \\\"{x:1339,y:755,t:1527272056048};\\\", \\\"{x:1339,y:751,t:1527272056064};\\\", \\\"{x:1335,y:745,t:1527272056081};\\\", \\\"{x:1334,y:743,t:1527272056098};\\\", \\\"{x:1331,y:739,t:1527272056113};\\\", \\\"{x:1329,y:735,t:1527272056131};\\\", \\\"{x:1323,y:727,t:1527272056148};\\\", \\\"{x:1320,y:723,t:1527272056163};\\\", \\\"{x:1317,y:718,t:1527272056181};\\\", \\\"{x:1312,y:713,t:1527272056198};\\\", \\\"{x:1311,y:710,t:1527272056214};\\\", \\\"{x:1310,y:706,t:1527272056231};\\\", \\\"{x:1309,y:704,t:1527272056248};\\\", \\\"{x:1309,y:703,t:1527272056265};\\\", \\\"{x:1309,y:702,t:1527272056281};\\\", \\\"{x:1309,y:701,t:1527272056303};\\\", \\\"{x:1309,y:700,t:1527272056415};\\\", \\\"{x:1309,y:697,t:1527272056431};\\\", \\\"{x:1309,y:691,t:1527272056448};\\\", \\\"{x:1309,y:688,t:1527272056465};\\\", \\\"{x:1306,y:677,t:1527272056481};\\\", \\\"{x:1295,y:660,t:1527272056498};\\\", \\\"{x:1288,y:651,t:1527272056515};\\\", \\\"{x:1287,y:646,t:1527272056531};\\\", \\\"{x:1286,y:640,t:1527272056548};\\\", \\\"{x:1284,y:634,t:1527272056565};\\\", \\\"{x:1284,y:629,t:1527272056581};\\\", \\\"{x:1284,y:626,t:1527272056598};\\\", \\\"{x:1283,y:621,t:1527272056615};\\\", \\\"{x:1283,y:618,t:1527272056631};\\\", \\\"{x:1283,y:615,t:1527272056648};\\\", \\\"{x:1283,y:611,t:1527272056665};\\\", \\\"{x:1283,y:609,t:1527272056682};\\\", \\\"{x:1283,y:607,t:1527272056697};\\\", \\\"{x:1283,y:605,t:1527272056718};\\\", \\\"{x:1283,y:604,t:1527272056749};\\\", \\\"{x:1283,y:602,t:1527272056766};\\\", \\\"{x:1283,y:601,t:1527272056790};\\\", \\\"{x:1283,y:600,t:1527272056797};\\\", \\\"{x:1283,y:598,t:1527272056813};\\\", \\\"{x:1284,y:594,t:1527272056832};\\\", \\\"{x:1284,y:588,t:1527272056847};\\\", \\\"{x:1284,y:585,t:1527272056864};\\\", \\\"{x:1284,y:583,t:1527272056882};\\\", \\\"{x:1285,y:580,t:1527272056898};\\\", \\\"{x:1285,y:577,t:1527272056914};\\\", \\\"{x:1285,y:575,t:1527272056931};\\\", \\\"{x:1285,y:574,t:1527272056950};\\\", \\\"{x:1285,y:573,t:1527272061879};\\\", \\\"{x:1287,y:571,t:1527272061886};\\\", \\\"{x:1293,y:571,t:1527272061902};\\\", \\\"{x:1312,y:573,t:1527272061919};\\\", \\\"{x:1322,y:577,t:1527272061935};\\\", \\\"{x:1329,y:577,t:1527272061952};\\\", \\\"{x:1335,y:577,t:1527272061969};\\\", \\\"{x:1336,y:577,t:1527272061985};\\\", \\\"{x:1337,y:577,t:1527272062002};\\\", \\\"{x:1338,y:577,t:1527272062019};\\\", \\\"{x:1340,y:577,t:1527272062035};\\\", \\\"{x:1343,y:576,t:1527272062052};\\\", \\\"{x:1350,y:576,t:1527272062069};\\\", \\\"{x:1354,y:576,t:1527272062085};\\\", \\\"{x:1357,y:575,t:1527272062102};\\\", \\\"{x:1358,y:575,t:1527272062127};\\\", \\\"{x:1360,y:575,t:1527272062143};\\\", \\\"{x:1361,y:574,t:1527272062153};\\\", \\\"{x:1363,y:573,t:1527272062169};\\\", \\\"{x:1366,y:573,t:1527272062185};\\\", \\\"{x:1368,y:571,t:1527272062202};\\\", \\\"{x:1371,y:570,t:1527272062219};\\\", \\\"{x:1372,y:570,t:1527272062254};\\\", \\\"{x:1373,y:570,t:1527272062269};\\\", \\\"{x:1375,y:569,t:1527272062285};\\\", \\\"{x:1380,y:569,t:1527272062302};\\\", \\\"{x:1389,y:565,t:1527272062318};\\\", \\\"{x:1399,y:562,t:1527272062336};\\\", \\\"{x:1403,y:561,t:1527272062352};\\\", \\\"{x:1406,y:560,t:1527272062369};\\\", \\\"{x:1409,y:560,t:1527272063071};\\\", \\\"{x:1410,y:560,t:1527272063087};\\\", \\\"{x:1412,y:560,t:1527272063119};\\\", \\\"{x:1410,y:566,t:1527272066727};\\\", \\\"{x:1408,y:583,t:1527272066740};\\\", \\\"{x:1404,y:612,t:1527272066755};\\\", \\\"{x:1394,y:646,t:1527272066773};\\\", \\\"{x:1388,y:692,t:1527272066789};\\\", \\\"{x:1385,y:736,t:1527272066806};\\\", \\\"{x:1381,y:778,t:1527272066823};\\\", \\\"{x:1381,y:791,t:1527272066838};\\\", \\\"{x:1381,y:801,t:1527272066856};\\\", \\\"{x:1382,y:806,t:1527272066872};\\\", \\\"{x:1382,y:809,t:1527272066890};\\\", \\\"{x:1382,y:813,t:1527272066905};\\\", \\\"{x:1383,y:816,t:1527272066923};\\\", \\\"{x:1383,y:820,t:1527272066940};\\\", \\\"{x:1383,y:821,t:1527272066955};\\\", \\\"{x:1383,y:822,t:1527272066972};\\\", \\\"{x:1383,y:823,t:1527272066990};\\\", \\\"{x:1385,y:825,t:1527272067006};\\\", \\\"{x:1386,y:829,t:1527272067022};\\\", \\\"{x:1387,y:831,t:1527272067039};\\\", \\\"{x:1387,y:834,t:1527272067055};\\\", \\\"{x:1387,y:840,t:1527272067073};\\\", \\\"{x:1388,y:845,t:1527272067089};\\\", \\\"{x:1389,y:852,t:1527272067105};\\\", \\\"{x:1389,y:855,t:1527272067123};\\\", \\\"{x:1390,y:858,t:1527272067139};\\\", \\\"{x:1390,y:860,t:1527272067159};\\\", \\\"{x:1389,y:861,t:1527272067175};\\\", \\\"{x:1387,y:864,t:1527272067190};\\\", \\\"{x:1385,y:867,t:1527272067206};\\\", \\\"{x:1385,y:870,t:1527272067222};\\\", \\\"{x:1384,y:871,t:1527272067239};\\\", \\\"{x:1384,y:873,t:1527272067256};\\\", \\\"{x:1383,y:875,t:1527272067286};\\\", \\\"{x:1382,y:876,t:1527272067311};\\\", \\\"{x:1382,y:877,t:1527272067327};\\\", \\\"{x:1381,y:878,t:1527272067339};\\\", \\\"{x:1380,y:880,t:1527272067356};\\\", \\\"{x:1379,y:881,t:1527272067423};\\\", \\\"{x:1378,y:882,t:1527272067439};\\\", \\\"{x:1377,y:883,t:1527272067478};\\\", \\\"{x:1377,y:884,t:1527272067759};\\\", \\\"{x:1377,y:885,t:1527272067814};\\\", \\\"{x:1378,y:886,t:1527272067926};\\\", \\\"{x:1379,y:886,t:1527272067940};\\\", \\\"{x:1384,y:887,t:1527272068431};\\\", \\\"{x:1389,y:886,t:1527272068441};\\\", \\\"{x:1403,y:886,t:1527272068457};\\\", \\\"{x:1416,y:886,t:1527272068473};\\\", \\\"{x:1424,y:886,t:1527272068490};\\\", \\\"{x:1430,y:886,t:1527272068506};\\\", \\\"{x:1438,y:886,t:1527272068523};\\\", \\\"{x:1448,y:887,t:1527272068540};\\\", \\\"{x:1461,y:890,t:1527272068556};\\\", \\\"{x:1477,y:893,t:1527272068573};\\\", \\\"{x:1498,y:897,t:1527272068590};\\\", \\\"{x:1508,y:898,t:1527272068607};\\\", \\\"{x:1513,y:899,t:1527272068623};\\\", \\\"{x:1518,y:899,t:1527272068641};\\\", \\\"{x:1522,y:900,t:1527272068657};\\\", \\\"{x:1524,y:901,t:1527272068673};\\\", \\\"{x:1525,y:901,t:1527272068691};\\\", \\\"{x:1527,y:901,t:1527272068707};\\\", \\\"{x:1533,y:901,t:1527272068723};\\\", \\\"{x:1539,y:901,t:1527272068741};\\\", \\\"{x:1549,y:903,t:1527272068758};\\\", \\\"{x:1553,y:903,t:1527272068774};\\\", \\\"{x:1559,y:904,t:1527272068790};\\\", \\\"{x:1564,y:906,t:1527272068807};\\\", \\\"{x:1571,y:907,t:1527272068823};\\\", \\\"{x:1576,y:909,t:1527272068841};\\\", \\\"{x:1579,y:909,t:1527272068858};\\\", \\\"{x:1580,y:910,t:1527272068873};\\\", \\\"{x:1581,y:910,t:1527272068890};\\\", \\\"{x:1583,y:910,t:1527272068907};\\\", \\\"{x:1585,y:911,t:1527272068922};\\\", \\\"{x:1586,y:911,t:1527272068939};\\\", \\\"{x:1588,y:911,t:1527272068957};\\\", \\\"{x:1591,y:912,t:1527272068973};\\\", \\\"{x:1595,y:914,t:1527272068990};\\\", \\\"{x:1601,y:916,t:1527272069007};\\\", \\\"{x:1603,y:917,t:1527272069023};\\\", \\\"{x:1604,y:917,t:1527272069046};\\\", \\\"{x:1606,y:917,t:1527272069078};\\\", \\\"{x:1608,y:917,t:1527272069094};\\\", \\\"{x:1609,y:917,t:1527272069191};\\\", \\\"{x:1610,y:917,t:1527272069303};\\\", \\\"{x:1611,y:919,t:1527272069311};\\\", \\\"{x:1612,y:920,t:1527272069324};\\\", \\\"{x:1613,y:921,t:1527272069340};\\\", \\\"{x:1614,y:923,t:1527272069357};\\\", \\\"{x:1616,y:927,t:1527272069375};\\\", \\\"{x:1618,y:930,t:1527272069390};\\\", \\\"{x:1619,y:932,t:1527272069407};\\\", \\\"{x:1620,y:932,t:1527272069425};\\\", \\\"{x:1620,y:934,t:1527272069440};\\\", \\\"{x:1620,y:935,t:1527272069503};\\\", \\\"{x:1620,y:936,t:1527272069566};\\\", \\\"{x:1620,y:937,t:1527272069574};\\\", \\\"{x:1621,y:938,t:1527272069591};\\\", \\\"{x:1621,y:939,t:1527272069639};\\\", \\\"{x:1622,y:940,t:1527272069672};\\\", \\\"{x:1622,y:941,t:1527272069695};\\\", \\\"{x:1622,y:942,t:1527272069727};\\\", \\\"{x:1622,y:943,t:1527272069758};\\\", \\\"{x:1623,y:944,t:1527272069775};\\\", \\\"{x:1624,y:946,t:1527272069798};\\\", \\\"{x:1624,y:947,t:1527272069822};\\\", \\\"{x:1624,y:948,t:1527272069887};\\\", \\\"{x:1624,y:949,t:1527272069927};\\\", \\\"{x:1624,y:951,t:1527272069941};\\\", \\\"{x:1624,y:952,t:1527272069991};\\\", \\\"{x:1624,y:954,t:1527272070008};\\\", \\\"{x:1625,y:954,t:1527272070024};\\\", \\\"{x:1625,y:955,t:1527272070135};\\\", \\\"{x:1625,y:956,t:1527272070142};\\\", \\\"{x:1625,y:957,t:1527272070198};\\\", \\\"{x:1625,y:958,t:1527272070327};\\\", \\\"{x:1625,y:959,t:1527272070342};\\\", \\\"{x:1625,y:960,t:1527272070359};\\\", \\\"{x:1624,y:961,t:1527272070383};\\\", \\\"{x:1624,y:962,t:1527272070567};\\\", \\\"{x:1624,y:963,t:1527272070575};\\\", \\\"{x:1624,y:964,t:1527272070598};\\\", \\\"{x:1623,y:965,t:1527272070615};\\\", \\\"{x:1622,y:966,t:1527272070625};\\\", \\\"{x:1622,y:967,t:1527272070663};\\\", \\\"{x:1621,y:969,t:1527272070719};\\\", \\\"{x:1620,y:969,t:1527272070734};\\\", \\\"{x:1620,y:970,t:1527272070775};\\\", \\\"{x:1619,y:971,t:1527272070791};\\\", \\\"{x:1617,y:971,t:1527272070831};\\\", \\\"{x:1616,y:970,t:1527272071039};\\\", \\\"{x:1616,y:969,t:1527272071254};\\\", \\\"{x:1615,y:968,t:1527272071270};\\\", \\\"{x:1615,y:967,t:1527272071278};\\\", \\\"{x:1614,y:965,t:1527272071294};\\\", \\\"{x:1612,y:962,t:1527272071308};\\\", \\\"{x:1608,y:957,t:1527272071325};\\\", \\\"{x:1603,y:950,t:1527272071341};\\\", \\\"{x:1602,y:950,t:1527272071358};\\\", \\\"{x:1601,y:949,t:1527272071375};\\\", \\\"{x:1600,y:948,t:1527272071392};\\\", \\\"{x:1599,y:947,t:1527272071409};\\\", \\\"{x:1598,y:946,t:1527272071425};\\\", \\\"{x:1598,y:945,t:1527272071462};\\\", \\\"{x:1598,y:944,t:1527272071475};\\\", \\\"{x:1597,y:939,t:1527272071493};\\\", \\\"{x:1597,y:935,t:1527272071509};\\\", \\\"{x:1596,y:931,t:1527272071525};\\\", \\\"{x:1595,y:924,t:1527272071543};\\\", \\\"{x:1595,y:919,t:1527272071559};\\\", \\\"{x:1596,y:914,t:1527272071575};\\\", \\\"{x:1596,y:908,t:1527272071592};\\\", \\\"{x:1598,y:903,t:1527272071610};\\\", \\\"{x:1599,y:896,t:1527272071625};\\\", \\\"{x:1600,y:888,t:1527272071642};\\\", \\\"{x:1603,y:879,t:1527272071659};\\\", \\\"{x:1605,y:873,t:1527272071675};\\\", \\\"{x:1607,y:865,t:1527272071692};\\\", \\\"{x:1608,y:857,t:1527272071709};\\\", \\\"{x:1608,y:839,t:1527272071725};\\\", \\\"{x:1608,y:824,t:1527272071742};\\\", \\\"{x:1609,y:814,t:1527272071759};\\\", \\\"{x:1611,y:805,t:1527272071776};\\\", \\\"{x:1612,y:794,t:1527272071793};\\\", \\\"{x:1612,y:782,t:1527272071809};\\\", \\\"{x:1609,y:771,t:1527272071825};\\\", \\\"{x:1606,y:763,t:1527272071843};\\\", \\\"{x:1606,y:756,t:1527272071859};\\\", \\\"{x:1606,y:755,t:1527272071876};\\\", \\\"{x:1606,y:752,t:1527272071893};\\\", \\\"{x:1607,y:749,t:1527272071910};\\\", \\\"{x:1607,y:748,t:1527272071926};\\\", \\\"{x:1607,y:747,t:1527272072006};\\\", \\\"{x:1606,y:747,t:1527272072014};\\\", \\\"{x:1602,y:747,t:1527272072026};\\\", \\\"{x:1593,y:747,t:1527272072043};\\\", \\\"{x:1584,y:749,t:1527272072059};\\\", \\\"{x:1573,y:750,t:1527272072076};\\\", \\\"{x:1563,y:750,t:1527272072093};\\\", \\\"{x:1555,y:750,t:1527272072110};\\\", \\\"{x:1548,y:751,t:1527272072127};\\\", \\\"{x:1547,y:751,t:1527272072143};\\\", \\\"{x:1545,y:751,t:1527272072159};\\\", \\\"{x:1542,y:751,t:1527272072177};\\\", \\\"{x:1541,y:751,t:1527272072193};\\\", \\\"{x:1540,y:751,t:1527272072210};\\\", \\\"{x:1538,y:753,t:1527272072226};\\\", \\\"{x:1537,y:753,t:1527272072242};\\\", \\\"{x:1534,y:755,t:1527272072260};\\\", \\\"{x:1532,y:756,t:1527272072276};\\\", \\\"{x:1531,y:757,t:1527272072292};\\\", \\\"{x:1530,y:758,t:1527272072309};\\\", \\\"{x:1528,y:760,t:1527272072326};\\\", \\\"{x:1527,y:762,t:1527272072342};\\\", \\\"{x:1525,y:763,t:1527272072366};\\\", \\\"{x:1524,y:763,t:1527272072376};\\\", \\\"{x:1522,y:763,t:1527272072393};\\\", \\\"{x:1522,y:764,t:1527272072410};\\\", \\\"{x:1521,y:765,t:1527272072430};\\\", \\\"{x:1520,y:765,t:1527272072443};\\\", \\\"{x:1518,y:766,t:1527272072460};\\\", \\\"{x:1515,y:767,t:1527272072476};\\\", \\\"{x:1510,y:770,t:1527272076811};\\\", \\\"{x:1506,y:779,t:1527272076819};\\\", \\\"{x:1501,y:785,t:1527272076834};\\\", \\\"{x:1491,y:796,t:1527272076850};\\\", \\\"{x:1487,y:801,t:1527272076867};\\\", \\\"{x:1484,y:804,t:1527272076884};\\\", \\\"{x:1483,y:805,t:1527272076901};\\\", \\\"{x:1483,y:807,t:1527272076917};\\\", \\\"{x:1482,y:809,t:1527272076933};\\\", \\\"{x:1481,y:809,t:1527272076951};\\\", \\\"{x:1480,y:810,t:1527272076967};\\\", \\\"{x:1479,y:812,t:1527272076984};\\\", \\\"{x:1478,y:814,t:1527272077000};\\\", \\\"{x:1477,y:815,t:1527272077017};\\\", \\\"{x:1477,y:816,t:1527272077075};\\\", \\\"{x:1477,y:817,t:1527272077090};\\\", \\\"{x:1477,y:818,t:1527272077171};\\\", \\\"{x:1477,y:819,t:1527272077184};\\\", \\\"{x:1476,y:822,t:1527272077201};\\\", \\\"{x:1476,y:824,t:1527272077218};\\\", \\\"{x:1476,y:825,t:1527272077259};\\\", \\\"{x:1476,y:827,t:1527272077387};\\\", \\\"{x:1476,y:828,t:1527272077483};\\\", \\\"{x:1475,y:832,t:1527272077892};\\\", \\\"{x:1463,y:837,t:1527272077901};\\\", \\\"{x:1390,y:840,t:1527272077918};\\\", \\\"{x:1271,y:840,t:1527272077935};\\\", \\\"{x:1097,y:821,t:1527272077951};\\\", \\\"{x:912,y:794,t:1527272077968};\\\", \\\"{x:736,y:756,t:1527272077985};\\\", \\\"{x:593,y:716,t:1527272078001};\\\", \\\"{x:476,y:679,t:1527272078018};\\\", \\\"{x:404,y:636,t:1527272078034};\\\", \\\"{x:397,y:618,t:1527272078052};\\\", \\\"{x:397,y:600,t:1527272078067};\\\", \\\"{x:397,y:580,t:1527272078084};\\\", \\\"{x:397,y:563,t:1527272078104};\\\", \\\"{x:397,y:548,t:1527272078121};\\\", \\\"{x:397,y:541,t:1527272078137};\\\", \\\"{x:404,y:531,t:1527272078153};\\\", \\\"{x:418,y:525,t:1527272078170};\\\", \\\"{x:438,y:517,t:1527272078188};\\\", \\\"{x:457,y:508,t:1527272078204};\\\", \\\"{x:473,y:501,t:1527272078221};\\\", \\\"{x:482,y:498,t:1527272078237};\\\", \\\"{x:493,y:493,t:1527272078254};\\\", \\\"{x:502,y:491,t:1527272078272};\\\", \\\"{x:511,y:489,t:1527272078287};\\\", \\\"{x:526,y:487,t:1527272078304};\\\", \\\"{x:567,y:508,t:1527272078320};\\\", \\\"{x:604,y:525,t:1527272078338};\\\", \\\"{x:630,y:539,t:1527272078354};\\\", \\\"{x:641,y:546,t:1527272078370};\\\", \\\"{x:647,y:553,t:1527272078387};\\\", \\\"{x:650,y:558,t:1527272078404};\\\", \\\"{x:650,y:560,t:1527272078420};\\\", \\\"{x:650,y:561,t:1527272078437};\\\", \\\"{x:650,y:563,t:1527272078455};\\\", \\\"{x:650,y:566,t:1527272078471};\\\", \\\"{x:650,y:568,t:1527272078487};\\\", \\\"{x:650,y:573,t:1527272078504};\\\", \\\"{x:650,y:575,t:1527272078521};\\\", \\\"{x:650,y:576,t:1527272078538};\\\", \\\"{x:649,y:577,t:1527272078554};\\\", \\\"{x:649,y:578,t:1527272078572};\\\", \\\"{x:647,y:579,t:1527272078587};\\\", \\\"{x:644,y:581,t:1527272078605};\\\", \\\"{x:641,y:582,t:1527272078622};\\\", \\\"{x:637,y:584,t:1527272078637};\\\", \\\"{x:635,y:585,t:1527272078654};\\\", \\\"{x:633,y:585,t:1527272078671};\\\", \\\"{x:632,y:586,t:1527272078687};\\\", \\\"{x:630,y:586,t:1527272078704};\\\", \\\"{x:629,y:586,t:1527272078722};\\\", \\\"{x:629,y:587,t:1527272078738};\\\", \\\"{x:627,y:587,t:1527272078786};\\\", \\\"{x:626,y:587,t:1527272078801};\\\", \\\"{x:624,y:587,t:1527272078834};\\\", \\\"{x:623,y:587,t:1527272078850};\\\", \\\"{x:622,y:587,t:1527272078866};\\\", \\\"{x:621,y:587,t:1527272078874};\\\", \\\"{x:620,y:587,t:1527272078953};\\\", \\\"{x:619,y:586,t:1527272078971};\\\", \\\"{x:618,y:585,t:1527272079378};\\\", \\\"{x:617,y:585,t:1527272079389};\\\", \\\"{x:616,y:585,t:1527272079404};\\\", \\\"{x:614,y:585,t:1527272079451};\\\", \\\"{x:612,y:586,t:1527272079458};\\\", \\\"{x:607,y:588,t:1527272079472};\\\", \\\"{x:601,y:593,t:1527272079489};\\\", \\\"{x:589,y:602,t:1527272079506};\\\", \\\"{x:581,y:611,t:1527272079521};\\\", \\\"{x:572,y:620,t:1527272079539};\\\", \\\"{x:562,y:633,t:1527272079555};\\\", \\\"{x:553,y:645,t:1527272079571};\\\", \\\"{x:548,y:655,t:1527272079588};\\\", \\\"{x:543,y:662,t:1527272079605};\\\", \\\"{x:539,y:667,t:1527272079621};\\\", \\\"{x:535,y:671,t:1527272079639};\\\", \\\"{x:531,y:676,t:1527272079655};\\\", \\\"{x:530,y:678,t:1527272079671};\\\", \\\"{x:530,y:681,t:1527272079689};\\\", \\\"{x:527,y:687,t:1527272079706};\\\", \\\"{x:525,y:689,t:1527272079721};\\\", \\\"{x:524,y:691,t:1527272079738};\\\", \\\"{x:524,y:693,t:1527272079762};\\\", \\\"{x:523,y:694,t:1527272079772};\\\", \\\"{x:522,y:697,t:1527272079788};\\\", \\\"{x:521,y:701,t:1527272079805};\\\", \\\"{x:520,y:705,t:1527272079822};\\\", \\\"{x:517,y:713,t:1527272079839};\\\", \\\"{x:511,y:722,t:1527272079857};\\\", \\\"{x:504,y:731,t:1527272079873};\\\", \\\"{x:501,y:736,t:1527272079889};\\\", \\\"{x:499,y:742,t:1527272079906};\\\", \\\"{x:498,y:746,t:1527272079922};\\\", \\\"{x:497,y:747,t:1527272080218};\\\" ] }, { \\\"rt\\\": 9366, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 1035989, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:747,t:1527272082379};\\\", \\\"{x:503,y:744,t:1527272082391};\\\", \\\"{x:515,y:737,t:1527272082407};\\\", \\\"{x:548,y:725,t:1527272082433};\\\", \\\"{x:564,y:724,t:1527272082441};\\\", \\\"{x:624,y:737,t:1527272082457};\\\", \\\"{x:748,y:774,t:1527272082475};\\\", \\\"{x:748,y:775,t:1527272083522};\\\", \\\"{x:745,y:775,t:1527272083722};\\\", \\\"{x:744,y:775,t:1527272083730};\\\", \\\"{x:743,y:775,t:1527272083742};\\\", \\\"{x:741,y:775,t:1527272083921};\\\", \\\"{x:741,y:774,t:1527272083929};\\\", \\\"{x:739,y:774,t:1527272084171};\\\", \\\"{x:738,y:774,t:1527272084179};\\\", \\\"{x:737,y:774,t:1527272084202};\\\", \\\"{x:736,y:774,t:1527272084571};\\\", \\\"{x:735,y:780,t:1527272084578};\\\", \\\"{x:742,y:793,t:1527272084593};\\\", \\\"{x:771,y:828,t:1527272084610};\\\", \\\"{x:806,y:856,t:1527272084627};\\\", \\\"{x:849,y:887,t:1527272084643};\\\", \\\"{x:898,y:913,t:1527272084660};\\\", \\\"{x:956,y:930,t:1527272084677};\\\", \\\"{x:1014,y:947,t:1527272084693};\\\", \\\"{x:1070,y:961,t:1527272084710};\\\", \\\"{x:1121,y:979,t:1527272084727};\\\", \\\"{x:1166,y:992,t:1527272084744};\\\", \\\"{x:1192,y:998,t:1527272084760};\\\", \\\"{x:1206,y:1000,t:1527272084778};\\\", \\\"{x:1212,y:1001,t:1527272084793};\\\", \\\"{x:1222,y:1001,t:1527272084810};\\\", \\\"{x:1239,y:1001,t:1527272084827};\\\", \\\"{x:1257,y:1001,t:1527272084843};\\\", \\\"{x:1270,y:1001,t:1527272084860};\\\", \\\"{x:1283,y:1001,t:1527272084877};\\\", \\\"{x:1289,y:1001,t:1527272084893};\\\", \\\"{x:1295,y:998,t:1527272084910};\\\", \\\"{x:1298,y:995,t:1527272084927};\\\", \\\"{x:1301,y:992,t:1527272084943};\\\", \\\"{x:1303,y:991,t:1527272084960};\\\", \\\"{x:1308,y:988,t:1527272084977};\\\", \\\"{x:1312,y:988,t:1527272084995};\\\", \\\"{x:1316,y:988,t:1527272085011};\\\", \\\"{x:1319,y:988,t:1527272085027};\\\", \\\"{x:1320,y:987,t:1527272085044};\\\", \\\"{x:1322,y:986,t:1527272085082};\\\", \\\"{x:1323,y:984,t:1527272085094};\\\", \\\"{x:1330,y:984,t:1527272085110};\\\", \\\"{x:1339,y:983,t:1527272085127};\\\", \\\"{x:1341,y:983,t:1527272085143};\\\", \\\"{x:1342,y:982,t:1527272085170};\\\", \\\"{x:1342,y:981,t:1527272085194};\\\", \\\"{x:1342,y:980,t:1527272085266};\\\", \\\"{x:1342,y:979,t:1527272085278};\\\", \\\"{x:1342,y:978,t:1527272085294};\\\", \\\"{x:1342,y:977,t:1527272085310};\\\", \\\"{x:1342,y:976,t:1527272085371};\\\", \\\"{x:1343,y:975,t:1527272085395};\\\", \\\"{x:1344,y:975,t:1527272085418};\\\", \\\"{x:1345,y:974,t:1527272085427};\\\", \\\"{x:1346,y:973,t:1527272085444};\\\", \\\"{x:1348,y:972,t:1527272085475};\\\", \\\"{x:1348,y:971,t:1527272085499};\\\", \\\"{x:1350,y:970,t:1527272085522};\\\", \\\"{x:1351,y:968,t:1527272085540};\\\", \\\"{x:1351,y:967,t:1527272085570};\\\", \\\"{x:1351,y:966,t:1527272085602};\\\", \\\"{x:1352,y:965,t:1527272085634};\\\", \\\"{x:1352,y:964,t:1527272085683};\\\", \\\"{x:1352,y:963,t:1527272085778};\\\", \\\"{x:1352,y:962,t:1527272085810};\\\", \\\"{x:1352,y:961,t:1527272085834};\\\", \\\"{x:1352,y:960,t:1527272085844};\\\", \\\"{x:1352,y:958,t:1527272085861};\\\", \\\"{x:1349,y:955,t:1527272085878};\\\", \\\"{x:1349,y:952,t:1527272085914};\\\", \\\"{x:1349,y:950,t:1527272085928};\\\", \\\"{x:1347,y:948,t:1527272085944};\\\", \\\"{x:1345,y:944,t:1527272085961};\\\", \\\"{x:1341,y:938,t:1527272085978};\\\", \\\"{x:1340,y:937,t:1527272085995};\\\", \\\"{x:1340,y:934,t:1527272086011};\\\", \\\"{x:1340,y:932,t:1527272086029};\\\", \\\"{x:1339,y:927,t:1527272086045};\\\", \\\"{x:1338,y:919,t:1527272086061};\\\", \\\"{x:1334,y:911,t:1527272086078};\\\", \\\"{x:1334,y:907,t:1527272086094};\\\", \\\"{x:1334,y:903,t:1527272086111};\\\", \\\"{x:1335,y:901,t:1527272086128};\\\", \\\"{x:1335,y:897,t:1527272086146};\\\", \\\"{x:1335,y:892,t:1527272086161};\\\", \\\"{x:1335,y:884,t:1527272086178};\\\", \\\"{x:1335,y:883,t:1527272086202};\\\", \\\"{x:1335,y:880,t:1527272086218};\\\", \\\"{x:1336,y:880,t:1527272086228};\\\", \\\"{x:1338,y:874,t:1527272086245};\\\", \\\"{x:1338,y:869,t:1527272086261};\\\", \\\"{x:1338,y:866,t:1527272086278};\\\", \\\"{x:1340,y:858,t:1527272086295};\\\", \\\"{x:1340,y:847,t:1527272086311};\\\", \\\"{x:1343,y:836,t:1527272086328};\\\", \\\"{x:1344,y:819,t:1527272086345};\\\", \\\"{x:1343,y:801,t:1527272086361};\\\", \\\"{x:1290,y:761,t:1527272086378};\\\", \\\"{x:1221,y:735,t:1527272086395};\\\", \\\"{x:1110,y:700,t:1527272086411};\\\", \\\"{x:1023,y:688,t:1527272086429};\\\", \\\"{x:899,y:671,t:1527272086445};\\\", \\\"{x:861,y:669,t:1527272086461};\\\", \\\"{x:823,y:662,t:1527272086478};\\\", \\\"{x:744,y:650,t:1527272086495};\\\", \\\"{x:676,y:636,t:1527272086512};\\\", \\\"{x:610,y:621,t:1527272086530};\\\", \\\"{x:560,y:613,t:1527272086544};\\\", \\\"{x:531,y:608,t:1527272086561};\\\", \\\"{x:519,y:608,t:1527272086577};\\\", \\\"{x:518,y:608,t:1527272086690};\\\", \\\"{x:517,y:608,t:1527272086705};\\\", \\\"{x:515,y:608,t:1527272086714};\\\", \\\"{x:511,y:608,t:1527272086728};\\\", \\\"{x:499,y:608,t:1527272086744};\\\", \\\"{x:488,y:608,t:1527272086762};\\\", \\\"{x:484,y:609,t:1527272086778};\\\", \\\"{x:481,y:609,t:1527272086794};\\\", \\\"{x:476,y:609,t:1527272086810};\\\", \\\"{x:464,y:609,t:1527272086827};\\\", \\\"{x:447,y:609,t:1527272086845};\\\", \\\"{x:431,y:609,t:1527272086860};\\\", \\\"{x:424,y:609,t:1527272086877};\\\", \\\"{x:423,y:609,t:1527272086914};\\\", \\\"{x:423,y:610,t:1527272086978};\\\", \\\"{x:430,y:612,t:1527272086995};\\\", \\\"{x:437,y:613,t:1527272087012};\\\", \\\"{x:440,y:613,t:1527272087028};\\\", \\\"{x:441,y:613,t:1527272087045};\\\", \\\"{x:442,y:613,t:1527272087378};\\\", \\\"{x:443,y:613,t:1527272087418};\\\", \\\"{x:444,y:613,t:1527272087429};\\\", \\\"{x:448,y:613,t:1527272087445};\\\", \\\"{x:451,y:612,t:1527272087461};\\\", \\\"{x:459,y:611,t:1527272087479};\\\", \\\"{x:469,y:609,t:1527272087495};\\\", \\\"{x:477,y:606,t:1527272087511};\\\", \\\"{x:481,y:605,t:1527272087528};\\\", \\\"{x:488,y:604,t:1527272087545};\\\", \\\"{x:499,y:604,t:1527272087563};\\\", \\\"{x:508,y:604,t:1527272087579};\\\", \\\"{x:513,y:604,t:1527272087594};\\\", \\\"{x:521,y:604,t:1527272087612};\\\", \\\"{x:535,y:604,t:1527272087627};\\\", \\\"{x:551,y:604,t:1527272087644};\\\", \\\"{x:568,y:604,t:1527272087661};\\\", \\\"{x:583,y:603,t:1527272087677};\\\", \\\"{x:595,y:599,t:1527272087695};\\\", \\\"{x:612,y:591,t:1527272087713};\\\", \\\"{x:633,y:582,t:1527272087729};\\\", \\\"{x:656,y:577,t:1527272087744};\\\", \\\"{x:680,y:567,t:1527272087762};\\\", \\\"{x:692,y:565,t:1527272087779};\\\", \\\"{x:696,y:564,t:1527272087795};\\\", \\\"{x:697,y:563,t:1527272087812};\\\", \\\"{x:700,y:561,t:1527272087834};\\\", \\\"{x:709,y:558,t:1527272087845};\\\", \\\"{x:727,y:557,t:1527272087861};\\\", \\\"{x:745,y:554,t:1527272087879};\\\", \\\"{x:753,y:551,t:1527272087895};\\\", \\\"{x:746,y:553,t:1527272088009};\\\", \\\"{x:736,y:554,t:1527272088017};\\\", \\\"{x:731,y:554,t:1527272088029};\\\", \\\"{x:724,y:555,t:1527272088045};\\\", \\\"{x:723,y:555,t:1527272088083};\\\", \\\"{x:720,y:557,t:1527272088097};\\\", \\\"{x:716,y:558,t:1527272088112};\\\", \\\"{x:700,y:562,t:1527272088129};\\\", \\\"{x:684,y:562,t:1527272088146};\\\", \\\"{x:682,y:563,t:1527272088163};\\\", \\\"{x:681,y:563,t:1527272088194};\\\", \\\"{x:680,y:563,t:1527272088202};\\\", \\\"{x:672,y:562,t:1527272088213};\\\", \\\"{x:646,y:560,t:1527272088229};\\\", \\\"{x:619,y:560,t:1527272088246};\\\", \\\"{x:603,y:560,t:1527272088262};\\\", \\\"{x:590,y:560,t:1527272088279};\\\", \\\"{x:579,y:558,t:1527272088295};\\\", \\\"{x:558,y:554,t:1527272088312};\\\", \\\"{x:526,y:547,t:1527272088329};\\\", \\\"{x:499,y:542,t:1527272088345};\\\", \\\"{x:494,y:542,t:1527272088364};\\\", \\\"{x:493,y:541,t:1527272088378};\\\", \\\"{x:493,y:540,t:1527272088409};\\\", \\\"{x:493,y:539,t:1527272088418};\\\", \\\"{x:490,y:536,t:1527272088428};\\\", \\\"{x:475,y:532,t:1527272088445};\\\", \\\"{x:465,y:531,t:1527272088463};\\\", \\\"{x:459,y:531,t:1527272088478};\\\", \\\"{x:453,y:531,t:1527272088496};\\\", \\\"{x:436,y:532,t:1527272088512};\\\", \\\"{x:413,y:535,t:1527272088529};\\\", \\\"{x:367,y:543,t:1527272088546};\\\", \\\"{x:340,y:549,t:1527272088562};\\\", \\\"{x:316,y:551,t:1527272088579};\\\", \\\"{x:288,y:555,t:1527272088596};\\\", \\\"{x:255,y:556,t:1527272088613};\\\", \\\"{x:223,y:556,t:1527272088628};\\\", \\\"{x:200,y:557,t:1527272088645};\\\", \\\"{x:187,y:560,t:1527272088663};\\\", \\\"{x:178,y:561,t:1527272088680};\\\", \\\"{x:168,y:562,t:1527272088695};\\\", \\\"{x:159,y:562,t:1527272088713};\\\", \\\"{x:155,y:562,t:1527272088730};\\\", \\\"{x:153,y:560,t:1527272088787};\\\", \\\"{x:152,y:556,t:1527272088797};\\\", \\\"{x:151,y:554,t:1527272088814};\\\", \\\"{x:151,y:552,t:1527272088830};\\\", \\\"{x:151,y:550,t:1527272088846};\\\", \\\"{x:151,y:548,t:1527272088863};\\\", \\\"{x:151,y:547,t:1527272088880};\\\", \\\"{x:151,y:546,t:1527272088895};\\\", \\\"{x:151,y:545,t:1527272088929};\\\", \\\"{x:151,y:543,t:1527272088953};\\\", \\\"{x:151,y:541,t:1527272088963};\\\", \\\"{x:151,y:540,t:1527272088986};\\\", \\\"{x:151,y:539,t:1527272089002};\\\", \\\"{x:151,y:538,t:1527272089257};\\\", \\\"{x:155,y:536,t:1527272089265};\\\", \\\"{x:159,y:535,t:1527272089280};\\\", \\\"{x:169,y:535,t:1527272089296};\\\", \\\"{x:184,y:535,t:1527272089313};\\\", \\\"{x:201,y:535,t:1527272089330};\\\", \\\"{x:212,y:535,t:1527272089347};\\\", \\\"{x:222,y:535,t:1527272089363};\\\", \\\"{x:227,y:535,t:1527272089380};\\\", \\\"{x:239,y:535,t:1527272089397};\\\", \\\"{x:261,y:531,t:1527272089412};\\\", \\\"{x:281,y:529,t:1527272089430};\\\", \\\"{x:300,y:529,t:1527272089447};\\\", \\\"{x:326,y:529,t:1527272089463};\\\", \\\"{x:352,y:529,t:1527272089479};\\\", \\\"{x:376,y:529,t:1527272089497};\\\", \\\"{x:398,y:529,t:1527272089513};\\\", \\\"{x:429,y:529,t:1527272089530};\\\", \\\"{x:455,y:529,t:1527272089547};\\\", \\\"{x:499,y:529,t:1527272089564};\\\", \\\"{x:541,y:529,t:1527272089580};\\\", \\\"{x:583,y:529,t:1527272089597};\\\", \\\"{x:614,y:529,t:1527272089613};\\\", \\\"{x:642,y:529,t:1527272089629};\\\", \\\"{x:667,y:529,t:1527272089647};\\\", \\\"{x:684,y:529,t:1527272089663};\\\", \\\"{x:693,y:529,t:1527272089680};\\\", \\\"{x:704,y:529,t:1527272089697};\\\", \\\"{x:721,y:529,t:1527272089713};\\\", \\\"{x:746,y:532,t:1527272089730};\\\", \\\"{x:763,y:532,t:1527272089747};\\\", \\\"{x:778,y:532,t:1527272089764};\\\", \\\"{x:785,y:532,t:1527272089780};\\\", \\\"{x:786,y:532,t:1527272089818};\\\", \\\"{x:789,y:532,t:1527272089830};\\\", \\\"{x:805,y:527,t:1527272089847};\\\", \\\"{x:818,y:523,t:1527272089864};\\\", \\\"{x:824,y:521,t:1527272089880};\\\", \\\"{x:825,y:520,t:1527272089930};\\\", \\\"{x:830,y:517,t:1527272089948};\\\", \\\"{x:835,y:514,t:1527272089964};\\\", \\\"{x:836,y:513,t:1527272089981};\\\", \\\"{x:836,y:512,t:1527272089997};\\\", \\\"{x:836,y:511,t:1527272090014};\\\", \\\"{x:835,y:508,t:1527272090030};\\\", \\\"{x:833,y:508,t:1527272090091};\\\", \\\"{x:832,y:508,t:1527272090106};\\\", \\\"{x:832,y:507,t:1527272090114};\\\", \\\"{x:830,y:507,t:1527272090178};\\\", \\\"{x:828,y:507,t:1527272090362};\\\", \\\"{x:823,y:507,t:1527272090369};\\\", \\\"{x:817,y:509,t:1527272090381};\\\", \\\"{x:805,y:516,t:1527272090396};\\\", \\\"{x:787,y:527,t:1527272090414};\\\", \\\"{x:765,y:542,t:1527272090430};\\\", \\\"{x:739,y:559,t:1527272090447};\\\", \\\"{x:705,y:583,t:1527272090464};\\\", \\\"{x:672,y:602,t:1527272090481};\\\", \\\"{x:634,y:634,t:1527272090497};\\\", \\\"{x:557,y:690,t:1527272090514};\\\", \\\"{x:528,y:711,t:1527272090531};\\\", \\\"{x:515,y:720,t:1527272090547};\\\", \\\"{x:511,y:722,t:1527272090564};\\\", \\\"{x:509,y:722,t:1527272090580};\\\", \\\"{x:507,y:724,t:1527272090610};\\\", \\\"{x:503,y:724,t:1527272090617};\\\", \\\"{x:500,y:726,t:1527272090631};\\\", \\\"{x:496,y:729,t:1527272090648};\\\", \\\"{x:495,y:732,t:1527272090665};\\\" ] }, { \\\"rt\\\": 10628, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 1047819, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -B -F -F -F -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:501,y:737,t:1527272096018};\\\", \\\"{x:524,y:744,t:1527272096032};\\\", \\\"{x:565,y:755,t:1527272096049};\\\", \\\"{x:582,y:757,t:1527272096065};\\\", \\\"{x:621,y:769,t:1527272096081};\\\", \\\"{x:666,y:783,t:1527272096100};\\\", \\\"{x:715,y:793,t:1527272096116};\\\", \\\"{x:775,y:800,t:1527272096134};\\\", \\\"{x:834,y:808,t:1527272096150};\\\", \\\"{x:895,y:816,t:1527272096167};\\\", \\\"{x:946,y:824,t:1527272096184};\\\", \\\"{x:1002,y:832,t:1527272096200};\\\", \\\"{x:1042,y:839,t:1527272096217};\\\", \\\"{x:1082,y:844,t:1527272096234};\\\", \\\"{x:1099,y:844,t:1527272096250};\\\", \\\"{x:1107,y:845,t:1527272096267};\\\", \\\"{x:1117,y:845,t:1527272096284};\\\", \\\"{x:1128,y:845,t:1527272096300};\\\", \\\"{x:1132,y:845,t:1527272096317};\\\", \\\"{x:1137,y:845,t:1527272096334};\\\", \\\"{x:1151,y:844,t:1527272096350};\\\", \\\"{x:1162,y:844,t:1527272096367};\\\", \\\"{x:1171,y:843,t:1527272096384};\\\", \\\"{x:1176,y:842,t:1527272096400};\\\", \\\"{x:1177,y:842,t:1527272096418};\\\", \\\"{x:1178,y:842,t:1527272096434};\\\", \\\"{x:1187,y:842,t:1527272096450};\\\", \\\"{x:1202,y:842,t:1527272096467};\\\", \\\"{x:1217,y:842,t:1527272096484};\\\", \\\"{x:1229,y:842,t:1527272096500};\\\", \\\"{x:1240,y:842,t:1527272096518};\\\", \\\"{x:1253,y:844,t:1527272096534};\\\", \\\"{x:1265,y:846,t:1527272096550};\\\", \\\"{x:1276,y:849,t:1527272096567};\\\", \\\"{x:1289,y:852,t:1527272096584};\\\", \\\"{x:1304,y:858,t:1527272096601};\\\", \\\"{x:1321,y:865,t:1527272096617};\\\", \\\"{x:1354,y:877,t:1527272096634};\\\", \\\"{x:1369,y:883,t:1527272096651};\\\", \\\"{x:1374,y:883,t:1527272096667};\\\", \\\"{x:1379,y:887,t:1527272096684};\\\", \\\"{x:1385,y:890,t:1527272096700};\\\", \\\"{x:1391,y:893,t:1527272096718};\\\", \\\"{x:1393,y:894,t:1527272096735};\\\", \\\"{x:1396,y:894,t:1527272096752};\\\", \\\"{x:1398,y:894,t:1527272096817};\\\", \\\"{x:1400,y:894,t:1527272096834};\\\", \\\"{x:1401,y:894,t:1527272096851};\\\", \\\"{x:1403,y:893,t:1527272096867};\\\", \\\"{x:1406,y:893,t:1527272096884};\\\", \\\"{x:1410,y:891,t:1527272096901};\\\", \\\"{x:1412,y:889,t:1527272096917};\\\", \\\"{x:1414,y:885,t:1527272096934};\\\", \\\"{x:1414,y:880,t:1527272096951};\\\", \\\"{x:1414,y:869,t:1527272096967};\\\", \\\"{x:1414,y:861,t:1527272096984};\\\", \\\"{x:1410,y:853,t:1527272097002};\\\", \\\"{x:1407,y:847,t:1527272097017};\\\", \\\"{x:1404,y:839,t:1527272097034};\\\", \\\"{x:1399,y:831,t:1527272097051};\\\", \\\"{x:1389,y:818,t:1527272097067};\\\", \\\"{x:1385,y:812,t:1527272097084};\\\", \\\"{x:1383,y:810,t:1527272097101};\\\", \\\"{x:1382,y:808,t:1527272097117};\\\", \\\"{x:1381,y:806,t:1527272097134};\\\", \\\"{x:1378,y:801,t:1527272097151};\\\", \\\"{x:1373,y:793,t:1527272097168};\\\", \\\"{x:1369,y:789,t:1527272097184};\\\", \\\"{x:1368,y:787,t:1527272097202};\\\", \\\"{x:1366,y:784,t:1527272097217};\\\", \\\"{x:1366,y:779,t:1527272097234};\\\", \\\"{x:1361,y:772,t:1527272097252};\\\", \\\"{x:1357,y:764,t:1527272097267};\\\", \\\"{x:1354,y:758,t:1527272097285};\\\", \\\"{x:1351,y:750,t:1527272097302};\\\", \\\"{x:1348,y:746,t:1527272097317};\\\", \\\"{x:1345,y:738,t:1527272097335};\\\", \\\"{x:1342,y:729,t:1527272097351};\\\", \\\"{x:1340,y:722,t:1527272097367};\\\", \\\"{x:1340,y:716,t:1527272097385};\\\", \\\"{x:1340,y:713,t:1527272097402};\\\", \\\"{x:1340,y:711,t:1527272097418};\\\", \\\"{x:1338,y:708,t:1527272097435};\\\", \\\"{x:1338,y:707,t:1527272097451};\\\", \\\"{x:1338,y:706,t:1527272097467};\\\", \\\"{x:1338,y:702,t:1527272097485};\\\", \\\"{x:1341,y:700,t:1527272097501};\\\", \\\"{x:1342,y:698,t:1527272097519};\\\", \\\"{x:1342,y:696,t:1527272097534};\\\", \\\"{x:1342,y:695,t:1527272097550};\\\", \\\"{x:1343,y:694,t:1527272097577};\\\", \\\"{x:1343,y:693,t:1527272097585};\\\", \\\"{x:1344,y:693,t:1527272097609};\\\", \\\"{x:1345,y:692,t:1527272097625};\\\", \\\"{x:1346,y:691,t:1527272097650};\\\", \\\"{x:1347,y:691,t:1527272097665};\\\", \\\"{x:1348,y:690,t:1527272097673};\\\", \\\"{x:1349,y:689,t:1527272097697};\\\", \\\"{x:1349,y:690,t:1527272098067};\\\", \\\"{x:1349,y:694,t:1527272098074};\\\", \\\"{x:1349,y:698,t:1527272098085};\\\", \\\"{x:1349,y:702,t:1527272098101};\\\", \\\"{x:1350,y:709,t:1527272098119};\\\", \\\"{x:1350,y:714,t:1527272098135};\\\", \\\"{x:1350,y:720,t:1527272098151};\\\", \\\"{x:1351,y:722,t:1527272098168};\\\", \\\"{x:1351,y:727,t:1527272098184};\\\", \\\"{x:1353,y:732,t:1527272098202};\\\", \\\"{x:1354,y:740,t:1527272098218};\\\", \\\"{x:1354,y:743,t:1527272098235};\\\", \\\"{x:1354,y:745,t:1527272098252};\\\", \\\"{x:1354,y:746,t:1527272098269};\\\", \\\"{x:1354,y:748,t:1527272098306};\\\", \\\"{x:1353,y:748,t:1527272098318};\\\", \\\"{x:1353,y:749,t:1527272098335};\\\", \\\"{x:1353,y:751,t:1527272098352};\\\", \\\"{x:1352,y:751,t:1527272098369};\\\", \\\"{x:1352,y:752,t:1527272098387};\\\", \\\"{x:1351,y:753,t:1527272098402};\\\", \\\"{x:1350,y:753,t:1527272098426};\\\", \\\"{x:1349,y:753,t:1527272098442};\\\", \\\"{x:1347,y:755,t:1527272098452};\\\", \\\"{x:1347,y:756,t:1527272098498};\\\", \\\"{x:1345,y:756,t:1527272098626};\\\", \\\"{x:1345,y:757,t:1527272099418};\\\", \\\"{x:1344,y:759,t:1527272099437};\\\", \\\"{x:1344,y:761,t:1527272099452};\\\", \\\"{x:1344,y:762,t:1527272099469};\\\", \\\"{x:1344,y:764,t:1527272099486};\\\", \\\"{x:1344,y:766,t:1527272099501};\\\", \\\"{x:1344,y:767,t:1527272099519};\\\", \\\"{x:1344,y:769,t:1527272099537};\\\", \\\"{x:1344,y:770,t:1527272099552};\\\", \\\"{x:1344,y:768,t:1527272100010};\\\", \\\"{x:1344,y:767,t:1527272100067};\\\", \\\"{x:1344,y:766,t:1527272100394};\\\", \\\"{x:1341,y:766,t:1527272100403};\\\", \\\"{x:1330,y:768,t:1527272100419};\\\", \\\"{x:1303,y:771,t:1527272100436};\\\", \\\"{x:1221,y:768,t:1527272100453};\\\", \\\"{x:1085,y:744,t:1527272100469};\\\", \\\"{x:919,y:722,t:1527272100486};\\\", \\\"{x:772,y:698,t:1527272100503};\\\", \\\"{x:617,y:681,t:1527272100519};\\\", \\\"{x:489,y:660,t:1527272100537};\\\", \\\"{x:411,y:649,t:1527272100552};\\\", \\\"{x:384,y:647,t:1527272100568};\\\", \\\"{x:360,y:640,t:1527272100590};\\\", \\\"{x:353,y:637,t:1527272100605};\\\", \\\"{x:349,y:634,t:1527272100622};\\\", \\\"{x:348,y:633,t:1527272100639};\\\", \\\"{x:348,y:629,t:1527272100656};\\\", \\\"{x:348,y:628,t:1527272100681};\\\", \\\"{x:349,y:627,t:1527272100745};\\\", \\\"{x:350,y:625,t:1527272100755};\\\", \\\"{x:354,y:623,t:1527272100772};\\\", \\\"{x:359,y:620,t:1527272100789};\\\", \\\"{x:364,y:617,t:1527272100805};\\\", \\\"{x:366,y:617,t:1527272100822};\\\", \\\"{x:367,y:615,t:1527272100839};\\\", \\\"{x:368,y:614,t:1527272100855};\\\", \\\"{x:369,y:613,t:1527272100873};\\\", \\\"{x:370,y:612,t:1527272100889};\\\", \\\"{x:372,y:610,t:1527272100905};\\\", \\\"{x:372,y:607,t:1527272100923};\\\", \\\"{x:368,y:601,t:1527272100940};\\\", \\\"{x:356,y:594,t:1527272100958};\\\", \\\"{x:348,y:589,t:1527272100972};\\\", \\\"{x:342,y:587,t:1527272100989};\\\", \\\"{x:338,y:584,t:1527272101006};\\\", \\\"{x:331,y:581,t:1527272101022};\\\", \\\"{x:319,y:576,t:1527272101039};\\\", \\\"{x:294,y:569,t:1527272101056};\\\", \\\"{x:275,y:565,t:1527272101072};\\\", \\\"{x:267,y:564,t:1527272101090};\\\", \\\"{x:266,y:563,t:1527272101169};\\\", \\\"{x:264,y:563,t:1527272101177};\\\", \\\"{x:261,y:562,t:1527272101190};\\\", \\\"{x:249,y:559,t:1527272101206};\\\", \\\"{x:235,y:555,t:1527272101223};\\\", \\\"{x:211,y:548,t:1527272101239};\\\", \\\"{x:195,y:544,t:1527272101256};\\\", \\\"{x:187,y:541,t:1527272101273};\\\", \\\"{x:186,y:540,t:1527272101289};\\\", \\\"{x:184,y:540,t:1527272101306};\\\", \\\"{x:182,y:540,t:1527272101322};\\\", \\\"{x:180,y:539,t:1527272101339};\\\", \\\"{x:174,y:537,t:1527272101356};\\\", \\\"{x:173,y:537,t:1527272101373};\\\", \\\"{x:171,y:537,t:1527272101513};\\\", \\\"{x:170,y:537,t:1527272101523};\\\", \\\"{x:169,y:537,t:1527272101539};\\\", \\\"{x:168,y:537,t:1527272101561};\\\", \\\"{x:166,y:537,t:1527272101793};\\\", \\\"{x:163,y:537,t:1527272101930};\\\", \\\"{x:162,y:538,t:1527272101940};\\\", \\\"{x:160,y:538,t:1527272101956};\\\", \\\"{x:156,y:538,t:1527272101973};\\\", \\\"{x:153,y:541,t:1527272101990};\\\", \\\"{x:150,y:541,t:1527272102006};\\\", \\\"{x:149,y:541,t:1527272102024};\\\", \\\"{x:150,y:543,t:1527272102042};\\\", \\\"{x:150,y:545,t:1527272102057};\\\", \\\"{x:167,y:570,t:1527272102075};\\\", \\\"{x:187,y:590,t:1527272102091};\\\", \\\"{x:203,y:606,t:1527272102106};\\\", \\\"{x:222,y:622,t:1527272102123};\\\", \\\"{x:238,y:631,t:1527272102140};\\\", \\\"{x:251,y:636,t:1527272102156};\\\", \\\"{x:281,y:650,t:1527272102174};\\\", \\\"{x:322,y:666,t:1527272102190};\\\", \\\"{x:362,y:678,t:1527272102207};\\\", \\\"{x:408,y:689,t:1527272102223};\\\", \\\"{x:442,y:699,t:1527272102240};\\\", \\\"{x:462,y:701,t:1527272102257};\\\", \\\"{x:463,y:701,t:1527272102273};\\\", \\\"{x:464,y:704,t:1527272102338};\\\", \\\"{x:464,y:705,t:1527272102353};\\\", \\\"{x:464,y:706,t:1527272102402};\\\", \\\"{x:464,y:709,t:1527272102410};\\\", \\\"{x:465,y:711,t:1527272102424};\\\", \\\"{x:467,y:714,t:1527272102439};\\\", \\\"{x:469,y:717,t:1527272102457};\\\", \\\"{x:469,y:719,t:1527272102474};\\\", \\\"{x:469,y:721,t:1527272102491};\\\", \\\"{x:469,y:724,t:1527272102507};\\\", \\\"{x:469,y:726,t:1527272102524};\\\", \\\"{x:470,y:727,t:1527272102540};\\\", \\\"{x:470,y:729,t:1527272102586};\\\" ] }, { \\\"rt\\\": 64464, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 1113567, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -Z -H -O -X -X -M -M -12 PM-10 AM-10 AM-10 AM-10 AM-J -J -F -B -B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:467,y:729,t:1527272104265};\\\", \\\"{x:458,y:723,t:1527272104275};\\\", \\\"{x:436,y:714,t:1527272104293};\\\", \\\"{x:413,y:705,t:1527272104310};\\\", \\\"{x:392,y:696,t:1527272104325};\\\", \\\"{x:381,y:690,t:1527272104341};\\\", \\\"{x:376,y:686,t:1527272104359};\\\", \\\"{x:374,y:683,t:1527272104376};\\\", \\\"{x:372,y:679,t:1527272104392};\\\", \\\"{x:370,y:677,t:1527272104408};\\\", \\\"{x:368,y:672,t:1527272104426};\\\", \\\"{x:368,y:670,t:1527272104442};\\\", \\\"{x:368,y:669,t:1527272104459};\\\", \\\"{x:368,y:666,t:1527272104475};\\\", \\\"{x:367,y:661,t:1527272104492};\\\", \\\"{x:366,y:657,t:1527272104508};\\\", \\\"{x:362,y:651,t:1527272104525};\\\", \\\"{x:342,y:636,t:1527272104610};\\\", \\\"{x:334,y:631,t:1527272104626};\\\", \\\"{x:332,y:630,t:1527272104641};\\\", \\\"{x:330,y:629,t:1527272104658};\\\", \\\"{x:328,y:628,t:1527272104675};\\\", \\\"{x:327,y:628,t:1527272104692};\\\", \\\"{x:329,y:631,t:1527272109154};\\\", \\\"{x:329,y:632,t:1527272109163};\\\", \\\"{x:332,y:637,t:1527272109179};\\\", \\\"{x:334,y:637,t:1527272109195};\\\", \\\"{x:335,y:637,t:1527272109212};\\\", \\\"{x:336,y:638,t:1527272109690};\\\", \\\"{x:336,y:639,t:1527272109707};\\\", \\\"{x:346,y:645,t:1527272109728};\\\", \\\"{x:353,y:647,t:1527272109745};\\\", \\\"{x:356,y:648,t:1527272109762};\\\", \\\"{x:364,y:650,t:1527272109779};\\\", \\\"{x:378,y:654,t:1527272109796};\\\", \\\"{x:402,y:657,t:1527272109813};\\\", \\\"{x:431,y:662,t:1527272109830};\\\", \\\"{x:471,y:666,t:1527272109846};\\\", \\\"{x:501,y:668,t:1527272109863};\\\", \\\"{x:537,y:672,t:1527272109879};\\\", \\\"{x:584,y:678,t:1527272109896};\\\", \\\"{x:697,y:694,t:1527272109913};\\\", \\\"{x:762,y:704,t:1527272109929};\\\", \\\"{x:807,y:706,t:1527272109947};\\\", \\\"{x:844,y:712,t:1527272109964};\\\", \\\"{x:889,y:718,t:1527272109980};\\\", \\\"{x:928,y:727,t:1527272109997};\\\", \\\"{x:964,y:730,t:1527272110013};\\\", \\\"{x:985,y:733,t:1527272110030};\\\", \\\"{x:1000,y:736,t:1527272110046};\\\", \\\"{x:1015,y:740,t:1527272110063};\\\", \\\"{x:1036,y:747,t:1527272110080};\\\", \\\"{x:1067,y:759,t:1527272110096};\\\", \\\"{x:1127,y:779,t:1527272110113};\\\", \\\"{x:1168,y:790,t:1527272110129};\\\", \\\"{x:1221,y:796,t:1527272110147};\\\", \\\"{x:1222,y:797,t:1527272110803};\\\", \\\"{x:1223,y:797,t:1527272110825};\\\", \\\"{x:1225,y:797,t:1527272110834};\\\", \\\"{x:1226,y:797,t:1527272110849};\\\", \\\"{x:1228,y:796,t:1527272110864};\\\", \\\"{x:1230,y:796,t:1527272110881};\\\", \\\"{x:1242,y:794,t:1527272110898};\\\", \\\"{x:1258,y:792,t:1527272110915};\\\", \\\"{x:1278,y:792,t:1527272110931};\\\", \\\"{x:1301,y:792,t:1527272110948};\\\", \\\"{x:1316,y:791,t:1527272110965};\\\", \\\"{x:1329,y:790,t:1527272110981};\\\", \\\"{x:1339,y:790,t:1527272110998};\\\", \\\"{x:1350,y:790,t:1527272111015};\\\", \\\"{x:1365,y:790,t:1527272111031};\\\", \\\"{x:1377,y:790,t:1527272111048};\\\", \\\"{x:1383,y:791,t:1527272111065};\\\", \\\"{x:1385,y:791,t:1527272111081};\\\", \\\"{x:1387,y:795,t:1527272112234};\\\", \\\"{x:1385,y:825,t:1527272112249};\\\", \\\"{x:1373,y:871,t:1527272112266};\\\", \\\"{x:1364,y:893,t:1527272112282};\\\", \\\"{x:1353,y:918,t:1527272112299};\\\", \\\"{x:1329,y:964,t:1527272112317};\\\", \\\"{x:1305,y:1014,t:1527272112332};\\\", \\\"{x:1289,y:1055,t:1527272112349};\\\", \\\"{x:1275,y:1087,t:1527272112367};\\\", \\\"{x:1267,y:1110,t:1527272112383};\\\", \\\"{x:1264,y:1114,t:1527272112399};\\\", \\\"{x:1263,y:1115,t:1527272112416};\\\", \\\"{x:1262,y:1115,t:1527272112433};\\\", \\\"{x:1261,y:1115,t:1527272112449};\\\", \\\"{x:1259,y:1115,t:1527272112530};\\\", \\\"{x:1258,y:1115,t:1527272112538};\\\", \\\"{x:1252,y:1107,t:1527272112549};\\\", \\\"{x:1244,y:1093,t:1527272112566};\\\", \\\"{x:1240,y:1087,t:1527272112583};\\\", \\\"{x:1236,y:1081,t:1527272112599};\\\", \\\"{x:1233,y:1077,t:1527272112616};\\\", \\\"{x:1228,y:1072,t:1527272112633};\\\", \\\"{x:1221,y:1066,t:1527272112649};\\\", \\\"{x:1216,y:1062,t:1527272112666};\\\", \\\"{x:1215,y:1061,t:1527272112690};\\\", \\\"{x:1211,y:1065,t:1527272114162};\\\", \\\"{x:1200,y:1083,t:1527272114170};\\\", \\\"{x:1193,y:1096,t:1527272114184};\\\", \\\"{x:1172,y:1123,t:1527272114201};\\\", \\\"{x:1123,y:1180,t:1527272114218};\\\", \\\"{x:1078,y:1199,t:1527272114234};\\\", \\\"{x:1040,y:1199,t:1527272114250};\\\", \\\"{x:1008,y:1199,t:1527272114265};\\\", \\\"{x:991,y:1199,t:1527272114282};\\\", \\\"{x:978,y:1199,t:1527272114299};\\\", \\\"{x:972,y:1199,t:1527272114315};\\\", \\\"{x:969,y:1199,t:1527272114333};\\\", \\\"{x:968,y:1199,t:1527272114349};\\\", \\\"{x:967,y:1199,t:1527272114369};\\\", \\\"{x:966,y:1199,t:1527272114442};\\\", \\\"{x:964,y:1199,t:1527272114449};\\\", \\\"{x:957,y:1199,t:1527272114466};\\\", \\\"{x:947,y:1199,t:1527272114483};\\\", \\\"{x:929,y:1199,t:1527272114500};\\\", \\\"{x:903,y:1199,t:1527272114517};\\\", \\\"{x:878,y:1199,t:1527272114533};\\\", \\\"{x:864,y:1199,t:1527272114550};\\\", \\\"{x:860,y:1199,t:1527272114567};\\\", \\\"{x:859,y:1199,t:1527272114650};\\\", \\\"{x:857,y:1199,t:1527272114690};\\\", \\\"{x:855,y:1199,t:1527272114700};\\\", \\\"{x:856,y:1191,t:1527272115922};\\\", \\\"{x:856,y:1178,t:1527272115935};\\\", \\\"{x:853,y:1132,t:1527272115951};\\\", \\\"{x:846,y:1118,t:1527272115967};\\\", \\\"{x:846,y:1098,t:1527272115985};\\\", \\\"{x:847,y:1089,t:1527272116002};\\\", \\\"{x:858,y:1078,t:1527272116018};\\\", \\\"{x:858,y:1075,t:1527272116042};\\\", \\\"{x:858,y:1074,t:1527272116098};\\\", \\\"{x:858,y:1072,t:1527272116113};\\\", \\\"{x:861,y:1072,t:1527272116170};\\\", \\\"{x:865,y:1067,t:1527272116185};\\\", \\\"{x:861,y:1059,t:1527272116202};\\\", \\\"{x:860,y:1047,t:1527272116218};\\\", \\\"{x:857,y:998,t:1527272116235};\\\", \\\"{x:845,y:938,t:1527272116252};\\\", \\\"{x:840,y:870,t:1527272116268};\\\", \\\"{x:835,y:804,t:1527272116285};\\\", \\\"{x:833,y:734,t:1527272116302};\\\", \\\"{x:826,y:657,t:1527272116319};\\\", \\\"{x:826,y:585,t:1527272116336};\\\", \\\"{x:826,y:512,t:1527272116352};\\\", \\\"{x:826,y:411,t:1527272116369};\\\", \\\"{x:827,y:363,t:1527272116385};\\\", \\\"{x:827,y:324,t:1527272116402};\\\", \\\"{x:827,y:298,t:1527272116418};\\\", \\\"{x:826,y:277,t:1527272116435};\\\", \\\"{x:825,y:268,t:1527272116452};\\\", \\\"{x:825,y:264,t:1527272116468};\\\", \\\"{x:822,y:260,t:1527272116485};\\\", \\\"{x:823,y:259,t:1527272117010};\\\", \\\"{x:834,y:254,t:1527272117020};\\\", \\\"{x:846,y:244,t:1527272117036};\\\", \\\"{x:860,y:226,t:1527272117053};\\\", \\\"{x:872,y:208,t:1527272117069};\\\", \\\"{x:883,y:197,t:1527272117086};\\\", \\\"{x:887,y:193,t:1527272117102};\\\", \\\"{x:889,y:185,t:1527272117119};\\\", \\\"{x:889,y:170,t:1527272117136};\\\", \\\"{x:886,y:151,t:1527272117152};\\\", \\\"{x:883,y:140,t:1527272117169};\\\", \\\"{x:883,y:131,t:1527272117186};\\\", \\\"{x:884,y:127,t:1527272117203};\\\", \\\"{x:884,y:123,t:1527272117219};\\\", \\\"{x:884,y:110,t:1527272117236};\\\", \\\"{x:883,y:95,t:1527272117253};\\\", \\\"{x:878,y:80,t:1527272117269};\\\", \\\"{x:871,y:71,t:1527272117286};\\\", \\\"{x:864,y:64,t:1527272117303};\\\", \\\"{x:862,y:63,t:1527272117319};\\\", \\\"{x:861,y:63,t:1527272117336};\\\", \\\"{x:860,y:63,t:1527272117377};\\\", \\\"{x:859,y:63,t:1527272117442};\\\", \\\"{x:857,y:67,t:1527272117453};\\\", \\\"{x:857,y:69,t:1527272117469};\\\", \\\"{x:856,y:72,t:1527272117487};\\\", \\\"{x:856,y:74,t:1527272117503};\\\", \\\"{x:855,y:75,t:1527272117520};\\\", \\\"{x:855,y:76,t:1527272117536};\\\", \\\"{x:856,y:76,t:1527272117690};\\\", \\\"{x:859,y:76,t:1527272117703};\\\", \\\"{x:861,y:77,t:1527272117719};\\\", \\\"{x:864,y:77,t:1527272117737};\\\", \\\"{x:878,y:81,t:1527272117753};\\\", \\\"{x:907,y:88,t:1527272117769};\\\", \\\"{x:954,y:107,t:1527272117786};\\\", \\\"{x:1001,y:127,t:1527272117802};\\\", \\\"{x:1045,y:147,t:1527272117820};\\\", \\\"{x:1131,y:170,t:1527272117836};\\\", \\\"{x:1264,y:210,t:1527272117853};\\\", \\\"{x:1443,y:258,t:1527272117870};\\\", \\\"{x:1626,y:320,t:1527272117886};\\\", \\\"{x:1815,y:382,t:1527272117903};\\\", \\\"{x:1919,y:442,t:1527272117920};\\\", \\\"{x:1919,y:475,t:1527272117936};\\\", \\\"{x:1919,y:480,t:1527272117953};\\\", \\\"{x:1919,y:478,t:1527272117970};\\\", \\\"{x:1919,y:475,t:1527272117987};\\\", \\\"{x:1910,y:475,t:1527272118033};\\\", \\\"{x:1901,y:475,t:1527272118041};\\\", \\\"{x:1891,y:475,t:1527272118053};\\\", \\\"{x:1873,y:482,t:1527272118070};\\\", \\\"{x:1855,y:495,t:1527272118086};\\\", \\\"{x:1838,y:503,t:1527272118103};\\\", \\\"{x:1820,y:503,t:1527272118120};\\\", \\\"{x:1817,y:503,t:1527272118136};\\\", \\\"{x:1816,y:503,t:1527272118153};\\\", \\\"{x:1814,y:503,t:1527272118218};\\\", \\\"{x:1813,y:503,t:1527272118226};\\\", \\\"{x:1812,y:503,t:1527272118330};\\\", \\\"{x:1812,y:500,t:1527272118370};\\\", \\\"{x:1810,y:498,t:1527272118388};\\\", \\\"{x:1808,y:497,t:1527272118404};\\\", \\\"{x:1804,y:497,t:1527272118466};\\\", \\\"{x:1802,y:497,t:1527272118482};\\\", \\\"{x:1800,y:497,t:1527272118490};\\\", \\\"{x:1799,y:497,t:1527272118503};\\\", \\\"{x:1796,y:497,t:1527272118520};\\\", \\\"{x:1793,y:498,t:1527272118618};\\\", \\\"{x:1789,y:500,t:1527272118625};\\\", \\\"{x:1783,y:502,t:1527272118637};\\\", \\\"{x:1776,y:505,t:1527272118654};\\\", \\\"{x:1771,y:509,t:1527272118671};\\\", \\\"{x:1761,y:515,t:1527272118687};\\\", \\\"{x:1749,y:522,t:1527272118705};\\\", \\\"{x:1734,y:530,t:1527272118720};\\\", \\\"{x:1716,y:540,t:1527272118737};\\\", \\\"{x:1711,y:543,t:1527272118753};\\\", \\\"{x:1707,y:545,t:1527272118770};\\\", \\\"{x:1704,y:547,t:1527272118786};\\\", \\\"{x:1700,y:548,t:1527272118803};\\\", \\\"{x:1697,y:549,t:1527272118820};\\\", \\\"{x:1696,y:549,t:1527272118837};\\\", \\\"{x:1696,y:550,t:1527272118905};\\\", \\\"{x:1694,y:550,t:1527272118921};\\\", \\\"{x:1691,y:550,t:1527272118937};\\\", \\\"{x:1687,y:550,t:1527272118954};\\\", \\\"{x:1682,y:552,t:1527272118970};\\\", \\\"{x:1673,y:555,t:1527272118987};\\\", \\\"{x:1667,y:555,t:1527272119004};\\\", \\\"{x:1663,y:555,t:1527272119021};\\\", \\\"{x:1659,y:555,t:1527272119037};\\\", \\\"{x:1657,y:555,t:1527272119054};\\\", \\\"{x:1654,y:555,t:1527272119071};\\\", \\\"{x:1653,y:555,t:1527272119087};\\\", \\\"{x:1652,y:555,t:1527272119162};\\\", \\\"{x:1649,y:555,t:1527272119171};\\\", \\\"{x:1645,y:555,t:1527272119188};\\\", \\\"{x:1642,y:555,t:1527272119204};\\\", \\\"{x:1639,y:555,t:1527272119221};\\\", \\\"{x:1631,y:555,t:1527272119238};\\\", \\\"{x:1623,y:555,t:1527272119255};\\\", \\\"{x:1617,y:555,t:1527272119272};\\\", \\\"{x:1611,y:555,t:1527272119288};\\\", \\\"{x:1604,y:555,t:1527272119304};\\\", \\\"{x:1596,y:555,t:1527272119322};\\\", \\\"{x:1588,y:555,t:1527272119338};\\\", \\\"{x:1572,y:560,t:1527272119355};\\\", \\\"{x:1548,y:575,t:1527272119371};\\\", \\\"{x:1521,y:597,t:1527272119387};\\\", \\\"{x:1509,y:607,t:1527272119405};\\\", \\\"{x:1496,y:616,t:1527272119422};\\\", \\\"{x:1485,y:621,t:1527272119438};\\\", \\\"{x:1471,y:629,t:1527272119455};\\\", \\\"{x:1459,y:637,t:1527272119471};\\\", \\\"{x:1446,y:645,t:1527272119489};\\\", \\\"{x:1436,y:650,t:1527272119504};\\\", \\\"{x:1426,y:655,t:1527272119522};\\\", \\\"{x:1421,y:659,t:1527272119538};\\\", \\\"{x:1415,y:663,t:1527272119554};\\\", \\\"{x:1411,y:665,t:1527272119572};\\\", \\\"{x:1404,y:667,t:1527272119589};\\\", \\\"{x:1399,y:669,t:1527272119605};\\\", \\\"{x:1396,y:670,t:1527272119621};\\\", \\\"{x:1395,y:670,t:1527272119638};\\\", \\\"{x:1394,y:670,t:1527272119730};\\\", \\\"{x:1393,y:670,t:1527272119745};\\\", \\\"{x:1392,y:670,t:1527272120066};\\\", \\\"{x:1392,y:671,t:1527272120402};\\\", \\\"{x:1392,y:672,t:1527272120409};\\\", \\\"{x:1393,y:675,t:1527272120422};\\\", \\\"{x:1393,y:678,t:1527272120439};\\\", \\\"{x:1395,y:683,t:1527272120456};\\\", \\\"{x:1396,y:683,t:1527272120473};\\\", \\\"{x:1398,y:684,t:1527272120488};\\\", \\\"{x:1406,y:688,t:1527272120506};\\\", \\\"{x:1418,y:693,t:1527272120522};\\\", \\\"{x:1431,y:699,t:1527272120539};\\\", \\\"{x:1445,y:708,t:1527272120556};\\\", \\\"{x:1470,y:729,t:1527272120572};\\\", \\\"{x:1506,y:761,t:1527272120589};\\\", \\\"{x:1521,y:779,t:1527272120606};\\\", \\\"{x:1519,y:779,t:1527272121186};\\\", \\\"{x:1515,y:780,t:1527272121194};\\\", \\\"{x:1512,y:781,t:1527272121207};\\\", \\\"{x:1509,y:782,t:1527272121222};\\\", \\\"{x:1507,y:782,t:1527272121239};\\\", \\\"{x:1505,y:782,t:1527272121257};\\\", \\\"{x:1505,y:783,t:1527272121273};\\\", \\\"{x:1501,y:783,t:1527272121290};\\\", \\\"{x:1489,y:783,t:1527272121307};\\\", \\\"{x:1446,y:772,t:1527272121322};\\\", \\\"{x:1385,y:759,t:1527272121340};\\\", \\\"{x:1327,y:744,t:1527272121356};\\\", \\\"{x:1300,y:737,t:1527272121372};\\\", \\\"{x:1297,y:736,t:1527272121389};\\\", \\\"{x:1297,y:735,t:1527272121410};\\\", \\\"{x:1297,y:733,t:1527272121422};\\\", \\\"{x:1295,y:732,t:1527272121440};\\\", \\\"{x:1295,y:731,t:1527272121456};\\\", \\\"{x:1295,y:730,t:1527272121490};\\\", \\\"{x:1295,y:729,t:1527272121506};\\\", \\\"{x:1295,y:724,t:1527272121522};\\\", \\\"{x:1299,y:713,t:1527272121540};\\\", \\\"{x:1310,y:696,t:1527272121557};\\\", \\\"{x:1323,y:679,t:1527272121572};\\\", \\\"{x:1333,y:657,t:1527272121589};\\\", \\\"{x:1338,y:644,t:1527272121606};\\\", \\\"{x:1339,y:639,t:1527272121623};\\\", \\\"{x:1342,y:634,t:1527272121639};\\\", \\\"{x:1343,y:632,t:1527272121656};\\\", \\\"{x:1346,y:625,t:1527272121673};\\\", \\\"{x:1350,y:617,t:1527272121689};\\\", \\\"{x:1355,y:610,t:1527272121706};\\\", \\\"{x:1360,y:606,t:1527272121723};\\\", \\\"{x:1367,y:599,t:1527272121739};\\\", \\\"{x:1371,y:587,t:1527272121756};\\\", \\\"{x:1373,y:582,t:1527272121773};\\\", \\\"{x:1375,y:580,t:1527272121789};\\\", \\\"{x:1376,y:575,t:1527272121806};\\\", \\\"{x:1382,y:571,t:1527272121823};\\\", \\\"{x:1390,y:566,t:1527272121839};\\\", \\\"{x:1395,y:563,t:1527272121857};\\\", \\\"{x:1397,y:561,t:1527272121873};\\\", \\\"{x:1399,y:558,t:1527272121889};\\\", \\\"{x:1404,y:552,t:1527272121906};\\\", \\\"{x:1420,y:546,t:1527272121923};\\\", \\\"{x:1433,y:541,t:1527272121940};\\\", \\\"{x:1440,y:536,t:1527272121956};\\\", \\\"{x:1444,y:534,t:1527272121973};\\\", \\\"{x:1446,y:534,t:1527272121994};\\\", \\\"{x:1447,y:533,t:1527272122007};\\\", \\\"{x:1456,y:529,t:1527272122025};\\\", \\\"{x:1466,y:526,t:1527272122040};\\\", \\\"{x:1470,y:525,t:1527272122057};\\\", \\\"{x:1472,y:525,t:1527272122226};\\\", \\\"{x:1474,y:526,t:1527272122241};\\\", \\\"{x:1476,y:526,t:1527272122257};\\\", \\\"{x:1477,y:527,t:1527272122274};\\\", \\\"{x:1477,y:528,t:1527272122314};\\\", \\\"{x:1477,y:530,t:1527272122324};\\\", \\\"{x:1477,y:536,t:1527272122340};\\\", \\\"{x:1478,y:538,t:1527272122357};\\\", \\\"{x:1478,y:540,t:1527272122375};\\\", \\\"{x:1478,y:541,t:1527272122394};\\\", \\\"{x:1478,y:543,t:1527272122407};\\\", \\\"{x:1479,y:545,t:1527272122424};\\\", \\\"{x:1480,y:547,t:1527272122441};\\\", \\\"{x:1481,y:550,t:1527272122457};\\\", \\\"{x:1483,y:554,t:1527272122473};\\\", \\\"{x:1484,y:555,t:1527272122490};\\\", \\\"{x:1485,y:556,t:1527272122507};\\\", \\\"{x:1485,y:558,t:1527272122524};\\\", \\\"{x:1485,y:560,t:1527272122541};\\\", \\\"{x:1487,y:565,t:1527272122557};\\\", \\\"{x:1488,y:570,t:1527272122574};\\\", \\\"{x:1490,y:574,t:1527272122591};\\\", \\\"{x:1490,y:575,t:1527272122607};\\\", \\\"{x:1486,y:580,t:1527272122624};\\\", \\\"{x:1476,y:585,t:1527272122641};\\\", \\\"{x:1450,y:597,t:1527272122657};\\\", \\\"{x:1444,y:604,t:1527272122673};\\\", \\\"{x:1441,y:611,t:1527272122691};\\\", \\\"{x:1439,y:616,t:1527272122708};\\\", \\\"{x:1436,y:620,t:1527272122723};\\\", \\\"{x:1432,y:624,t:1527272122741};\\\", \\\"{x:1430,y:625,t:1527272122757};\\\", \\\"{x:1429,y:626,t:1527272122775};\\\", \\\"{x:1428,y:628,t:1527272122791};\\\", \\\"{x:1422,y:636,t:1527272122808};\\\", \\\"{x:1415,y:643,t:1527272122824};\\\", \\\"{x:1401,y:657,t:1527272122840};\\\", \\\"{x:1392,y:672,t:1527272122858};\\\", \\\"{x:1388,y:676,t:1527272122874};\\\", \\\"{x:1386,y:677,t:1527272122890};\\\", \\\"{x:1385,y:678,t:1527272123634};\\\", \\\"{x:1384,y:679,t:1527272123641};\\\", \\\"{x:1383,y:681,t:1527272123658};\\\", \\\"{x:1380,y:683,t:1527272123674};\\\", \\\"{x:1380,y:684,t:1527272123692};\\\", \\\"{x:1380,y:686,t:1527272123708};\\\", \\\"{x:1379,y:688,t:1527272123729};\\\", \\\"{x:1378,y:688,t:1527272123741};\\\", \\\"{x:1377,y:690,t:1527272123759};\\\", \\\"{x:1376,y:695,t:1527272123778};\\\", \\\"{x:1376,y:697,t:1527272123791};\\\", \\\"{x:1376,y:699,t:1527272123808};\\\", \\\"{x:1376,y:701,t:1527272123824};\\\", \\\"{x:1381,y:701,t:1527272124714};\\\", \\\"{x:1391,y:699,t:1527272124726};\\\", \\\"{x:1404,y:695,t:1527272124742};\\\", \\\"{x:1417,y:693,t:1527272124759};\\\", \\\"{x:1433,y:689,t:1527272124777};\\\", \\\"{x:1437,y:689,t:1527272124793};\\\", \\\"{x:1455,y:689,t:1527272124809};\\\", \\\"{x:1480,y:690,t:1527272124826};\\\", \\\"{x:1497,y:693,t:1527272124842};\\\", \\\"{x:1510,y:696,t:1527272124859};\\\", \\\"{x:1517,y:696,t:1527272124876};\\\", \\\"{x:1519,y:696,t:1527272124892};\\\", \\\"{x:1521,y:696,t:1527272124970};\\\", \\\"{x:1523,y:696,t:1527272124977};\\\", \\\"{x:1524,y:696,t:1527272124993};\\\", \\\"{x:1528,y:696,t:1527272125009};\\\", \\\"{x:1544,y:697,t:1527272125026};\\\", \\\"{x:1560,y:701,t:1527272125043};\\\", \\\"{x:1578,y:703,t:1527272125060};\\\", \\\"{x:1587,y:706,t:1527272125076};\\\", \\\"{x:1593,y:706,t:1527272125093};\\\", \\\"{x:1594,y:706,t:1527272125194};\\\", \\\"{x:1596,y:706,t:1527272125506};\\\", \\\"{x:1597,y:706,t:1527272126402};\\\", \\\"{x:1598,y:706,t:1527272126425};\\\", \\\"{x:1599,y:707,t:1527272126444};\\\", \\\"{x:1600,y:707,t:1527272126466};\\\", \\\"{x:1602,y:708,t:1527272126481};\\\", \\\"{x:1603,y:708,t:1527272126498};\\\", \\\"{x:1605,y:708,t:1527272126521};\\\", \\\"{x:1606,y:708,t:1527272126530};\\\", \\\"{x:1607,y:708,t:1527272126543};\\\", \\\"{x:1609,y:708,t:1527272126561};\\\", \\\"{x:1611,y:708,t:1527272126577};\\\", \\\"{x:1613,y:707,t:1527272126642};\\\", \\\"{x:1614,y:707,t:1527272127106};\\\", \\\"{x:1614,y:710,t:1527272127114};\\\", \\\"{x:1614,y:712,t:1527272127128};\\\", \\\"{x:1615,y:718,t:1527272127144};\\\", \\\"{x:1617,y:721,t:1527272127161};\\\", \\\"{x:1617,y:725,t:1527272127177};\\\", \\\"{x:1617,y:727,t:1527272127202};\\\", \\\"{x:1617,y:730,t:1527272127218};\\\", \\\"{x:1618,y:731,t:1527272127228};\\\", \\\"{x:1620,y:738,t:1527272127244};\\\", \\\"{x:1621,y:744,t:1527272127261};\\\", \\\"{x:1622,y:751,t:1527272127278};\\\", \\\"{x:1624,y:762,t:1527272127295};\\\", \\\"{x:1625,y:773,t:1527272127311};\\\", \\\"{x:1625,y:779,t:1527272127328};\\\", \\\"{x:1626,y:785,t:1527272127344};\\\", \\\"{x:1626,y:788,t:1527272127361};\\\", \\\"{x:1626,y:789,t:1527272127377};\\\", \\\"{x:1626,y:791,t:1527272127395};\\\", \\\"{x:1626,y:793,t:1527272127411};\\\", \\\"{x:1626,y:795,t:1527272127428};\\\", \\\"{x:1626,y:796,t:1527272127444};\\\", \\\"{x:1626,y:797,t:1527272127461};\\\", \\\"{x:1625,y:797,t:1527272127554};\\\", \\\"{x:1624,y:793,t:1527272127561};\\\", \\\"{x:1623,y:781,t:1527272127578};\\\", \\\"{x:1622,y:767,t:1527272127594};\\\", \\\"{x:1620,y:759,t:1527272127611};\\\", \\\"{x:1618,y:752,t:1527272127628};\\\", \\\"{x:1616,y:748,t:1527272127644};\\\", \\\"{x:1616,y:744,t:1527272127661};\\\", \\\"{x:1616,y:737,t:1527272127678};\\\", \\\"{x:1618,y:730,t:1527272127695};\\\", \\\"{x:1618,y:725,t:1527272127712};\\\", \\\"{x:1619,y:719,t:1527272127728};\\\", \\\"{x:1619,y:715,t:1527272127745};\\\", \\\"{x:1621,y:700,t:1527272127761};\\\", \\\"{x:1623,y:685,t:1527272127778};\\\", \\\"{x:1624,y:675,t:1527272127794};\\\", \\\"{x:1624,y:669,t:1527272127812};\\\", \\\"{x:1625,y:667,t:1527272127828};\\\", \\\"{x:1625,y:666,t:1527272127845};\\\", \\\"{x:1625,y:665,t:1527272128042};\\\", \\\"{x:1625,y:667,t:1527272128066};\\\", \\\"{x:1623,y:669,t:1527272128078};\\\", \\\"{x:1621,y:675,t:1527272128095};\\\", \\\"{x:1619,y:683,t:1527272128112};\\\", \\\"{x:1616,y:696,t:1527272128131};\\\", \\\"{x:1615,y:711,t:1527272128145};\\\", \\\"{x:1615,y:740,t:1527272128161};\\\", \\\"{x:1615,y:759,t:1527272128178};\\\", \\\"{x:1615,y:772,t:1527272128195};\\\", \\\"{x:1616,y:778,t:1527272128212};\\\", \\\"{x:1618,y:782,t:1527272128228};\\\", \\\"{x:1619,y:794,t:1527272128244};\\\", \\\"{x:1625,y:811,t:1527272128261};\\\", \\\"{x:1626,y:825,t:1527272128278};\\\", \\\"{x:1631,y:840,t:1527272128295};\\\", \\\"{x:1633,y:851,t:1527272128311};\\\", \\\"{x:1636,y:861,t:1527272128329};\\\", \\\"{x:1642,y:877,t:1527272128345};\\\", \\\"{x:1642,y:890,t:1527272128361};\\\", \\\"{x:1642,y:897,t:1527272128379};\\\", \\\"{x:1642,y:902,t:1527272128395};\\\", \\\"{x:1639,y:909,t:1527272128412};\\\", \\\"{x:1639,y:912,t:1527272128429};\\\", \\\"{x:1639,y:913,t:1527272128445};\\\", \\\"{x:1637,y:914,t:1527272128462};\\\", \\\"{x:1634,y:916,t:1527272128478};\\\", \\\"{x:1631,y:918,t:1527272128495};\\\", \\\"{x:1630,y:920,t:1527272128512};\\\", \\\"{x:1630,y:923,t:1527272128529};\\\", \\\"{x:1626,y:928,t:1527272128545};\\\", \\\"{x:1622,y:931,t:1527272128562};\\\", \\\"{x:1620,y:932,t:1527272128579};\\\", \\\"{x:1618,y:933,t:1527272128596};\\\", \\\"{x:1618,y:934,t:1527272128612};\\\", \\\"{x:1618,y:935,t:1527272128629};\\\", \\\"{x:1617,y:937,t:1527272128646};\\\", \\\"{x:1616,y:939,t:1527272128662};\\\", \\\"{x:1616,y:940,t:1527272128679};\\\", \\\"{x:1615,y:943,t:1527272128696};\\\", \\\"{x:1613,y:946,t:1527272128712};\\\", \\\"{x:1613,y:949,t:1527272128729};\\\", \\\"{x:1613,y:951,t:1527272128745};\\\", \\\"{x:1613,y:950,t:1527272129666};\\\", \\\"{x:1613,y:939,t:1527272129680};\\\", \\\"{x:1614,y:930,t:1527272129696};\\\", \\\"{x:1615,y:922,t:1527272129712};\\\", \\\"{x:1617,y:902,t:1527272129730};\\\", \\\"{x:1616,y:893,t:1527272129746};\\\", \\\"{x:1607,y:872,t:1527272129763};\\\", \\\"{x:1605,y:865,t:1527272129780};\\\", \\\"{x:1603,y:860,t:1527272129796};\\\", \\\"{x:1601,y:850,t:1527272129813};\\\", \\\"{x:1597,y:838,t:1527272129830};\\\", \\\"{x:1590,y:824,t:1527272129846};\\\", \\\"{x:1586,y:810,t:1527272129863};\\\", \\\"{x:1585,y:803,t:1527272129880};\\\", \\\"{x:1585,y:798,t:1527272129897};\\\", \\\"{x:1589,y:786,t:1527272129912};\\\", \\\"{x:1592,y:770,t:1527272129929};\\\", \\\"{x:1592,y:757,t:1527272129947};\\\", \\\"{x:1594,y:743,t:1527272129963};\\\", \\\"{x:1601,y:734,t:1527272129980};\\\", \\\"{x:1606,y:728,t:1527272129997};\\\", \\\"{x:1608,y:721,t:1527272130013};\\\", \\\"{x:1609,y:715,t:1527272130030};\\\", \\\"{x:1610,y:702,t:1527272130047};\\\", \\\"{x:1610,y:697,t:1527272130063};\\\", \\\"{x:1611,y:694,t:1527272130079};\\\", \\\"{x:1612,y:693,t:1527272130097};\\\", \\\"{x:1613,y:691,t:1527272130113};\\\", \\\"{x:1613,y:690,t:1527272130129};\\\", \\\"{x:1613,y:688,t:1527272130146};\\\", \\\"{x:1613,y:687,t:1527272130163};\\\", \\\"{x:1613,y:685,t:1527272130180};\\\", \\\"{x:1613,y:684,t:1527272130197};\\\", \\\"{x:1613,y:682,t:1527272130212};\\\", \\\"{x:1613,y:680,t:1527272130230};\\\", \\\"{x:1613,y:678,t:1527272130246};\\\", \\\"{x:1613,y:677,t:1527272130263};\\\", \\\"{x:1613,y:676,t:1527272130290};\\\", \\\"{x:1613,y:675,t:1527272130298};\\\", \\\"{x:1613,y:674,t:1527272130314};\\\", \\\"{x:1613,y:672,t:1527272130330};\\\", \\\"{x:1613,y:671,t:1527272130346};\\\", \\\"{x:1613,y:670,t:1527272130364};\\\", \\\"{x:1613,y:668,t:1527272130380};\\\", \\\"{x:1613,y:667,t:1527272130397};\\\", \\\"{x:1613,y:665,t:1527272130414};\\\", \\\"{x:1612,y:660,t:1527272130430};\\\", \\\"{x:1609,y:653,t:1527272130447};\\\", \\\"{x:1608,y:649,t:1527272130464};\\\", \\\"{x:1606,y:646,t:1527272130480};\\\", \\\"{x:1606,y:645,t:1527272130497};\\\", \\\"{x:1606,y:643,t:1527272130514};\\\", \\\"{x:1606,y:641,t:1527272130529};\\\", \\\"{x:1605,y:638,t:1527272130547};\\\", \\\"{x:1604,y:636,t:1527272130564};\\\", \\\"{x:1603,y:634,t:1527272130580};\\\", \\\"{x:1602,y:633,t:1527272130597};\\\", \\\"{x:1602,y:632,t:1527272130614};\\\", \\\"{x:1602,y:630,t:1527272130630};\\\", \\\"{x:1601,y:627,t:1527272130648};\\\", \\\"{x:1601,y:626,t:1527272130664};\\\", \\\"{x:1601,y:625,t:1527272130680};\\\", \\\"{x:1601,y:624,t:1527272130706};\\\", \\\"{x:1601,y:623,t:1527272130810};\\\", \\\"{x:1599,y:621,t:1527272130817};\\\", \\\"{x:1598,y:620,t:1527272130831};\\\", \\\"{x:1594,y:618,t:1527272130847};\\\", \\\"{x:1592,y:618,t:1527272130898};\\\", \\\"{x:1587,y:618,t:1527272130914};\\\", \\\"{x:1582,y:618,t:1527272130931};\\\", \\\"{x:1579,y:619,t:1527272130946};\\\", \\\"{x:1578,y:619,t:1527272130964};\\\", \\\"{x:1577,y:620,t:1527272131034};\\\", \\\"{x:1576,y:621,t:1527272131047};\\\", \\\"{x:1574,y:622,t:1527272131064};\\\", \\\"{x:1573,y:623,t:1527272132962};\\\", \\\"{x:1573,y:624,t:1527272133026};\\\", \\\"{x:1574,y:624,t:1527272133074};\\\", \\\"{x:1574,y:625,t:1527272133090};\\\", \\\"{x:1574,y:626,t:1527272133378};\\\", \\\"{x:1574,y:627,t:1527272133386};\\\", \\\"{x:1574,y:629,t:1527272133399};\\\", \\\"{x:1572,y:633,t:1527272133416};\\\", \\\"{x:1571,y:635,t:1527272133433};\\\", \\\"{x:1571,y:636,t:1527272133449};\\\", \\\"{x:1570,y:640,t:1527272133466};\\\", \\\"{x:1570,y:643,t:1527272133497};\\\", \\\"{x:1570,y:644,t:1527272133506};\\\", \\\"{x:1570,y:646,t:1527272133516};\\\", \\\"{x:1570,y:654,t:1527272133533};\\\", \\\"{x:1570,y:658,t:1527272133549};\\\", \\\"{x:1569,y:663,t:1527272133566};\\\", \\\"{x:1567,y:669,t:1527272133583};\\\", \\\"{x:1567,y:677,t:1527272133599};\\\", \\\"{x:1567,y:683,t:1527272133616};\\\", \\\"{x:1567,y:689,t:1527272133633};\\\", \\\"{x:1566,y:695,t:1527272133650};\\\", \\\"{x:1565,y:699,t:1527272133666};\\\", \\\"{x:1565,y:702,t:1527272133683};\\\", \\\"{x:1562,y:707,t:1527272133700};\\\", \\\"{x:1562,y:711,t:1527272133716};\\\", \\\"{x:1562,y:716,t:1527272133733};\\\", \\\"{x:1559,y:722,t:1527272133749};\\\", \\\"{x:1559,y:725,t:1527272133766};\\\", \\\"{x:1557,y:727,t:1527272133783};\\\", \\\"{x:1555,y:731,t:1527272133799};\\\", \\\"{x:1553,y:734,t:1527272133816};\\\", \\\"{x:1553,y:737,t:1527272133832};\\\", \\\"{x:1552,y:737,t:1527272133849};\\\", \\\"{x:1551,y:739,t:1527272133866};\\\", \\\"{x:1550,y:740,t:1527272133882};\\\", \\\"{x:1548,y:741,t:1527272133899};\\\", \\\"{x:1547,y:741,t:1527272133921};\\\", \\\"{x:1546,y:742,t:1527272133933};\\\", \\\"{x:1546,y:743,t:1527272133949};\\\", \\\"{x:1543,y:746,t:1527272133966};\\\", \\\"{x:1539,y:750,t:1527272133983};\\\", \\\"{x:1537,y:751,t:1527272133999};\\\", \\\"{x:1535,y:752,t:1527272134016};\\\", \\\"{x:1533,y:753,t:1527272134033};\\\", \\\"{x:1532,y:754,t:1527272134050};\\\", \\\"{x:1531,y:755,t:1527272134074};\\\", \\\"{x:1531,y:756,t:1527272134298};\\\", \\\"{x:1530,y:756,t:1527272134305};\\\", \\\"{x:1529,y:757,t:1527272134317};\\\", \\\"{x:1529,y:758,t:1527272134345};\\\", \\\"{x:1529,y:759,t:1527272134530};\\\", \\\"{x:1528,y:760,t:1527272135054};\\\", \\\"{x:1528,y:761,t:1527272135070};\\\", \\\"{x:1527,y:761,t:1527272135087};\\\", \\\"{x:1526,y:761,t:1527272135103};\\\", \\\"{x:1525,y:762,t:1527272135121};\\\", \\\"{x:1523,y:762,t:1527272135268};\\\", \\\"{x:1523,y:763,t:1527272135287};\\\", \\\"{x:1522,y:763,t:1527272135304};\\\", \\\"{x:1522,y:764,t:1527272135321};\\\", \\\"{x:1521,y:764,t:1527272135413};\\\", \\\"{x:1521,y:765,t:1527272135605};\\\", \\\"{x:1520,y:766,t:1527272135621};\\\", \\\"{x:1519,y:766,t:1527272135637};\\\", \\\"{x:1517,y:766,t:1527272136637};\\\", \\\"{x:1515,y:764,t:1527272136655};\\\", \\\"{x:1513,y:761,t:1527272136671};\\\", \\\"{x:1513,y:760,t:1527272136688};\\\", \\\"{x:1512,y:760,t:1527272136885};\\\", \\\"{x:1507,y:765,t:1527272136893};\\\", \\\"{x:1502,y:772,t:1527272136906};\\\", \\\"{x:1487,y:792,t:1527272136922};\\\", \\\"{x:1475,y:813,t:1527272136938};\\\", \\\"{x:1463,y:828,t:1527272136955};\\\", \\\"{x:1459,y:833,t:1527272136972};\\\", \\\"{x:1459,y:834,t:1527272137085};\\\", \\\"{x:1460,y:834,t:1527272137117};\\\", \\\"{x:1462,y:834,t:1527272137133};\\\", \\\"{x:1464,y:834,t:1527272137141};\\\", \\\"{x:1465,y:833,t:1527272137156};\\\", \\\"{x:1469,y:831,t:1527272137173};\\\", \\\"{x:1473,y:829,t:1527272137189};\\\", \\\"{x:1477,y:827,t:1527272137206};\\\", \\\"{x:1478,y:827,t:1527272137222};\\\", \\\"{x:1479,y:826,t:1527272137238};\\\", \\\"{x:1481,y:825,t:1527272137255};\\\", \\\"{x:1483,y:825,t:1527272137272};\\\", \\\"{x:1486,y:825,t:1527272137289};\\\", \\\"{x:1487,y:825,t:1527272137365};\\\", \\\"{x:1486,y:825,t:1527272137637};\\\", \\\"{x:1486,y:826,t:1527272137653};\\\", \\\"{x:1485,y:826,t:1527272137661};\\\", \\\"{x:1484,y:827,t:1527272137836};\\\", \\\"{x:1482,y:829,t:1527272138029};\\\", \\\"{x:1481,y:829,t:1527272138101};\\\", \\\"{x:1480,y:829,t:1527272138116};\\\", \\\"{x:1478,y:829,t:1527272138621};\\\", \\\"{x:1469,y:829,t:1527272138630};\\\", \\\"{x:1455,y:825,t:1527272138640};\\\", \\\"{x:1361,y:802,t:1527272138656};\\\", \\\"{x:1242,y:767,t:1527272138674};\\\", \\\"{x:1066,y:721,t:1527272138689};\\\", \\\"{x:898,y:679,t:1527272138706};\\\", \\\"{x:744,y:648,t:1527272138723};\\\", \\\"{x:598,y:622,t:1527272138741};\\\", \\\"{x:567,y:612,t:1527272138756};\\\", \\\"{x:554,y:606,t:1527272138772};\\\", \\\"{x:554,y:605,t:1527272138789};\\\", \\\"{x:553,y:603,t:1527272138812};\\\", \\\"{x:555,y:601,t:1527272138828};\\\", \\\"{x:556,y:599,t:1527272138840};\\\", \\\"{x:562,y:595,t:1527272138856};\\\", \\\"{x:563,y:594,t:1527272138873};\\\", \\\"{x:567,y:593,t:1527272138900};\\\", \\\"{x:568,y:591,t:1527272138908};\\\", \\\"{x:573,y:589,t:1527272138922};\\\", \\\"{x:592,y:581,t:1527272138939};\\\", \\\"{x:605,y:576,t:1527272138957};\\\", \\\"{x:610,y:572,t:1527272138972};\\\", \\\"{x:608,y:572,t:1527272139157};\\\", \\\"{x:607,y:572,t:1527272139173};\\\", \\\"{x:606,y:573,t:1527272139197};\\\", \\\"{x:605,y:573,t:1527272139212};\\\", \\\"{x:605,y:574,t:1527272139223};\\\", \\\"{x:603,y:575,t:1527272139240};\\\", \\\"{x:602,y:575,t:1527272139257};\\\", \\\"{x:605,y:575,t:1527272140037};\\\", \\\"{x:620,y:577,t:1527272140045};\\\", \\\"{x:646,y:585,t:1527272140058};\\\", \\\"{x:758,y:623,t:1527272140075};\\\", \\\"{x:871,y:653,t:1527272140091};\\\", \\\"{x:1013,y:695,t:1527272140108};\\\", \\\"{x:1107,y:722,t:1527272140124};\\\", \\\"{x:1199,y:751,t:1527272140141};\\\", \\\"{x:1282,y:774,t:1527272140159};\\\", \\\"{x:1349,y:795,t:1527272140175};\\\", \\\"{x:1381,y:808,t:1527272140191};\\\", \\\"{x:1399,y:814,t:1527272140208};\\\", \\\"{x:1413,y:821,t:1527272140224};\\\", \\\"{x:1420,y:825,t:1527272140241};\\\", \\\"{x:1422,y:827,t:1527272140258};\\\", \\\"{x:1423,y:828,t:1527272140341};\\\", \\\"{x:1424,y:828,t:1527272140359};\\\", \\\"{x:1426,y:829,t:1527272140380};\\\", \\\"{x:1428,y:829,t:1527272140391};\\\", \\\"{x:1433,y:831,t:1527272140408};\\\", \\\"{x:1441,y:833,t:1527272140424};\\\", \\\"{x:1447,y:836,t:1527272140441};\\\", \\\"{x:1458,y:836,t:1527272140458};\\\", \\\"{x:1468,y:836,t:1527272140475};\\\", \\\"{x:1477,y:836,t:1527272140492};\\\", \\\"{x:1484,y:836,t:1527272140509};\\\", \\\"{x:1485,y:836,t:1527272140549};\\\", \\\"{x:1486,y:836,t:1527272140559};\\\", \\\"{x:1487,y:836,t:1527272141469};\\\", \\\"{x:1483,y:836,t:1527272142949};\\\", \\\"{x:1479,y:837,t:1527272142960};\\\", \\\"{x:1468,y:842,t:1527272142977};\\\", \\\"{x:1455,y:847,t:1527272142994};\\\", \\\"{x:1450,y:848,t:1527272143011};\\\", \\\"{x:1447,y:850,t:1527272143027};\\\", \\\"{x:1443,y:851,t:1527272143044};\\\", \\\"{x:1437,y:851,t:1527272143060};\\\", \\\"{x:1432,y:852,t:1527272143077};\\\", \\\"{x:1429,y:854,t:1527272143094};\\\", \\\"{x:1429,y:855,t:1527272143111};\\\", \\\"{x:1428,y:855,t:1527272143128};\\\", \\\"{x:1428,y:856,t:1527272143143};\\\", \\\"{x:1428,y:857,t:1527272143164};\\\", \\\"{x:1427,y:858,t:1527272143181};\\\", \\\"{x:1427,y:859,t:1527272143194};\\\", \\\"{x:1425,y:860,t:1527272143210};\\\", \\\"{x:1424,y:861,t:1527272143227};\\\", \\\"{x:1422,y:862,t:1527272143244};\\\", \\\"{x:1418,y:867,t:1527272143261};\\\", \\\"{x:1417,y:869,t:1527272143277};\\\", \\\"{x:1417,y:871,t:1527272143293};\\\", \\\"{x:1416,y:872,t:1527272143311};\\\", \\\"{x:1415,y:873,t:1527272143328};\\\", \\\"{x:1415,y:874,t:1527272143348};\\\", \\\"{x:1414,y:874,t:1527272143701};\\\", \\\"{x:1413,y:874,t:1527272143710};\\\", \\\"{x:1410,y:874,t:1527272143727};\\\", \\\"{x:1409,y:874,t:1527272143744};\\\", \\\"{x:1407,y:874,t:1527272143761};\\\", \\\"{x:1404,y:874,t:1527272143781};\\\", \\\"{x:1403,y:875,t:1527272143794};\\\", \\\"{x:1402,y:875,t:1527272143810};\\\", \\\"{x:1401,y:875,t:1527272143826};\\\", \\\"{x:1400,y:875,t:1527272143844};\\\", \\\"{x:1400,y:872,t:1527272143884};\\\", \\\"{x:1400,y:869,t:1527272143894};\\\", \\\"{x:1400,y:868,t:1527272144412};\\\", \\\"{x:1400,y:867,t:1527272144428};\\\", \\\"{x:1400,y:864,t:1527272144445};\\\", \\\"{x:1400,y:862,t:1527272144462};\\\", \\\"{x:1399,y:859,t:1527272144479};\\\", \\\"{x:1397,y:854,t:1527272144495};\\\", \\\"{x:1397,y:853,t:1527272144511};\\\", \\\"{x:1396,y:852,t:1527272144529};\\\", \\\"{x:1396,y:851,t:1527272144549};\\\", \\\"{x:1394,y:851,t:1527272144709};\\\", \\\"{x:1392,y:852,t:1527272144716};\\\", \\\"{x:1391,y:853,t:1527272144728};\\\", \\\"{x:1389,y:857,t:1527272144745};\\\", \\\"{x:1389,y:871,t:1527272144762};\\\", \\\"{x:1388,y:880,t:1527272144778};\\\", \\\"{x:1385,y:885,t:1527272144794};\\\", \\\"{x:1382,y:889,t:1527272144811};\\\", \\\"{x:1382,y:894,t:1527272144828};\\\", \\\"{x:1382,y:897,t:1527272144845};\\\", \\\"{x:1381,y:897,t:1527272144861};\\\", \\\"{x:1380,y:899,t:1527272144878};\\\", \\\"{x:1379,y:901,t:1527272144894};\\\", \\\"{x:1378,y:904,t:1527272144911};\\\", \\\"{x:1378,y:907,t:1527272144928};\\\", \\\"{x:1378,y:912,t:1527272144945};\\\", \\\"{x:1377,y:915,t:1527272144961};\\\", \\\"{x:1377,y:918,t:1527272144978};\\\", \\\"{x:1376,y:921,t:1527272144995};\\\", \\\"{x:1375,y:922,t:1527272145012};\\\", \\\"{x:1375,y:924,t:1527272145029};\\\", \\\"{x:1375,y:925,t:1527272145045};\\\", \\\"{x:1374,y:927,t:1527272145061};\\\", \\\"{x:1373,y:929,t:1527272145078};\\\", \\\"{x:1373,y:932,t:1527272145095};\\\", \\\"{x:1371,y:935,t:1527272145111};\\\", \\\"{x:1371,y:937,t:1527272145128};\\\", \\\"{x:1369,y:939,t:1527272145145};\\\", \\\"{x:1368,y:941,t:1527272145161};\\\", \\\"{x:1368,y:942,t:1527272145178};\\\", \\\"{x:1368,y:943,t:1527272145195};\\\", \\\"{x:1367,y:944,t:1527272145212};\\\", \\\"{x:1364,y:948,t:1527272145228};\\\", \\\"{x:1361,y:950,t:1527272145245};\\\", \\\"{x:1358,y:953,t:1527272145262};\\\", \\\"{x:1354,y:959,t:1527272145278};\\\", \\\"{x:1352,y:964,t:1527272145296};\\\", \\\"{x:1351,y:966,t:1527272145313};\\\", \\\"{x:1351,y:967,t:1527272145329};\\\", \\\"{x:1350,y:969,t:1527272145345};\\\", \\\"{x:1348,y:970,t:1527272145380};\\\", \\\"{x:1347,y:970,t:1527272146125};\\\", \\\"{x:1347,y:969,t:1527272146132};\\\", \\\"{x:1347,y:968,t:1527272146147};\\\", \\\"{x:1347,y:964,t:1527272146163};\\\", \\\"{x:1346,y:962,t:1527272146180};\\\", \\\"{x:1346,y:960,t:1527272146196};\\\", \\\"{x:1346,y:959,t:1527272146308};\\\", \\\"{x:1346,y:958,t:1527272146317};\\\", \\\"{x:1344,y:957,t:1527272146330};\\\", \\\"{x:1344,y:953,t:1527272146347};\\\", \\\"{x:1344,y:950,t:1527272146362};\\\", \\\"{x:1344,y:947,t:1527272146380};\\\", \\\"{x:1344,y:946,t:1527272146397};\\\", \\\"{x:1344,y:944,t:1527272146413};\\\", \\\"{x:1344,y:943,t:1527272146436};\\\", \\\"{x:1344,y:942,t:1527272146446};\\\", \\\"{x:1344,y:941,t:1527272146463};\\\", \\\"{x:1345,y:938,t:1527272146480};\\\", \\\"{x:1346,y:937,t:1527272146496};\\\", \\\"{x:1348,y:933,t:1527272146512};\\\", \\\"{x:1348,y:931,t:1527272146529};\\\", \\\"{x:1348,y:930,t:1527272146546};\\\", \\\"{x:1348,y:928,t:1527272146562};\\\", \\\"{x:1349,y:927,t:1527272146580};\\\", \\\"{x:1350,y:925,t:1527272146621};\\\", \\\"{x:1350,y:924,t:1527272146637};\\\", \\\"{x:1351,y:923,t:1527272146646};\\\", \\\"{x:1351,y:922,t:1527272146664};\\\", \\\"{x:1354,y:920,t:1527272146680};\\\", \\\"{x:1354,y:919,t:1527272146757};\\\", \\\"{x:1354,y:918,t:1527272146764};\\\", \\\"{x:1355,y:917,t:1527272146780};\\\", \\\"{x:1356,y:917,t:1527272146853};\\\", \\\"{x:1357,y:917,t:1527272146864};\\\", \\\"{x:1358,y:919,t:1527272146973};\\\", \\\"{x:1359,y:921,t:1527272146980};\\\", \\\"{x:1360,y:925,t:1527272146996};\\\", \\\"{x:1363,y:929,t:1527272147014};\\\", \\\"{x:1366,y:932,t:1527272147030};\\\", \\\"{x:1367,y:934,t:1527272147047};\\\", \\\"{x:1368,y:934,t:1527272147063};\\\", \\\"{x:1368,y:935,t:1527272147117};\\\", \\\"{x:1368,y:936,t:1527272147131};\\\", \\\"{x:1369,y:939,t:1527272147147};\\\", \\\"{x:1372,y:942,t:1527272147164};\\\", \\\"{x:1376,y:945,t:1527272147181};\\\", \\\"{x:1377,y:945,t:1527272147196};\\\", \\\"{x:1378,y:946,t:1527272147214};\\\", \\\"{x:1379,y:947,t:1527272147341};\\\", \\\"{x:1380,y:947,t:1527272147957};\\\", \\\"{x:1377,y:947,t:1527272147972};\\\", \\\"{x:1375,y:947,t:1527272147981};\\\", \\\"{x:1374,y:947,t:1527272147998};\\\", \\\"{x:1372,y:947,t:1527272148092};\\\", \\\"{x:1370,y:947,t:1527272148100};\\\", \\\"{x:1368,y:947,t:1527272148115};\\\", \\\"{x:1366,y:947,t:1527272148131};\\\", \\\"{x:1365,y:947,t:1527272148148};\\\", \\\"{x:1364,y:947,t:1527272148165};\\\", \\\"{x:1363,y:947,t:1527272148229};\\\", \\\"{x:1362,y:947,t:1527272148244};\\\", \\\"{x:1361,y:947,t:1527272148253};\\\", \\\"{x:1360,y:948,t:1527272148501};\\\", \\\"{x:1358,y:949,t:1527272149011};\\\", \\\"{x:1355,y:947,t:1527272149020};\\\", \\\"{x:1352,y:940,t:1527272149032};\\\", \\\"{x:1348,y:919,t:1527272149049};\\\", \\\"{x:1348,y:906,t:1527272149065};\\\", \\\"{x:1348,y:905,t:1527272149081};\\\", \\\"{x:1348,y:902,t:1527272149149};\\\", \\\"{x:1354,y:900,t:1527272149165};\\\", \\\"{x:1352,y:889,t:1527272151333};\\\", \\\"{x:1326,y:865,t:1527272151350};\\\", \\\"{x:1288,y:839,t:1527272151367};\\\", \\\"{x:1256,y:823,t:1527272151384};\\\", \\\"{x:1239,y:820,t:1527272151401};\\\", \\\"{x:1230,y:818,t:1527272151416};\\\", \\\"{x:1221,y:813,t:1527272151433};\\\", \\\"{x:1204,y:799,t:1527272151450};\\\", \\\"{x:1183,y:785,t:1527272151467};\\\", \\\"{x:1150,y:769,t:1527272151485};\\\", \\\"{x:1135,y:766,t:1527272151501};\\\", \\\"{x:1133,y:764,t:1527272151517};\\\", \\\"{x:1134,y:763,t:1527272151677};\\\", \\\"{x:1137,y:763,t:1527272151684};\\\", \\\"{x:1141,y:760,t:1527272151700};\\\", \\\"{x:1146,y:758,t:1527272151717};\\\", \\\"{x:1147,y:758,t:1527272151757};\\\", \\\"{x:1149,y:758,t:1527272151767};\\\", \\\"{x:1152,y:755,t:1527272151784};\\\", \\\"{x:1155,y:755,t:1527272151801};\\\", \\\"{x:1159,y:753,t:1527272151817};\\\", \\\"{x:1160,y:753,t:1527272151834};\\\", \\\"{x:1161,y:752,t:1527272151851};\\\", \\\"{x:1162,y:752,t:1527272151867};\\\", \\\"{x:1163,y:752,t:1527272151949};\\\", \\\"{x:1165,y:753,t:1527272151980};\\\", \\\"{x:1166,y:757,t:1527272151988};\\\", \\\"{x:1168,y:763,t:1527272152001};\\\", \\\"{x:1171,y:771,t:1527272152018};\\\", \\\"{x:1172,y:775,t:1527272152034};\\\", \\\"{x:1172,y:778,t:1527272152051};\\\", \\\"{x:1172,y:779,t:1527272152141};\\\", \\\"{x:1172,y:781,t:1527272152372};\\\", \\\"{x:1172,y:789,t:1527272152385};\\\", \\\"{x:1175,y:799,t:1527272152401};\\\", \\\"{x:1181,y:815,t:1527272152417};\\\", \\\"{x:1183,y:830,t:1527272152435};\\\", \\\"{x:1188,y:848,t:1527272152450};\\\", \\\"{x:1192,y:862,t:1527272152467};\\\", \\\"{x:1193,y:870,t:1527272152484};\\\", \\\"{x:1195,y:879,t:1527272152500};\\\", \\\"{x:1195,y:892,t:1527272152517};\\\", \\\"{x:1195,y:903,t:1527272152535};\\\", \\\"{x:1195,y:916,t:1527272152550};\\\", \\\"{x:1198,y:931,t:1527272152568};\\\", \\\"{x:1203,y:949,t:1527272152584};\\\", \\\"{x:1206,y:959,t:1527272152601};\\\", \\\"{x:1207,y:963,t:1527272152618};\\\", \\\"{x:1207,y:965,t:1527272152635};\\\", \\\"{x:1207,y:966,t:1527272152651};\\\", \\\"{x:1206,y:969,t:1527272152668};\\\", \\\"{x:1206,y:972,t:1527272152684};\\\", \\\"{x:1206,y:974,t:1527272152732};\\\", \\\"{x:1205,y:975,t:1527272152805};\\\", \\\"{x:1204,y:975,t:1527272152828};\\\", \\\"{x:1203,y:975,t:1527272152836};\\\", \\\"{x:1202,y:976,t:1527272152852};\\\", \\\"{x:1200,y:977,t:1527272152868};\\\", \\\"{x:1199,y:977,t:1527272152885};\\\", \\\"{x:1198,y:978,t:1527272152908};\\\", \\\"{x:1196,y:978,t:1527272153085};\\\", \\\"{x:1195,y:976,t:1527272153101};\\\", \\\"{x:1194,y:976,t:1527272153309};\\\", \\\"{x:1194,y:974,t:1527272153319};\\\", \\\"{x:1195,y:973,t:1527272153336};\\\", \\\"{x:1197,y:971,t:1527272153352};\\\", \\\"{x:1200,y:970,t:1527272153369};\\\", \\\"{x:1203,y:969,t:1527272153385};\\\", \\\"{x:1206,y:968,t:1527272153402};\\\", \\\"{x:1208,y:967,t:1527272153419};\\\", \\\"{x:1210,y:966,t:1527272153435};\\\", \\\"{x:1213,y:965,t:1527272153452};\\\", \\\"{x:1214,y:965,t:1527272153469};\\\", \\\"{x:1215,y:965,t:1527272153525};\\\", \\\"{x:1216,y:965,t:1527272153536};\\\", \\\"{x:1220,y:965,t:1527272153552};\\\", \\\"{x:1222,y:965,t:1527272153569};\\\", \\\"{x:1220,y:965,t:1527272153891};\\\", \\\"{x:1219,y:965,t:1527272153963};\\\", \\\"{x:1218,y:963,t:1527272153971};\\\", \\\"{x:1215,y:958,t:1527272153986};\\\", \\\"{x:1210,y:945,t:1527272154002};\\\", \\\"{x:1206,y:932,t:1527272154018};\\\", \\\"{x:1206,y:915,t:1527272154035};\\\", \\\"{x:1206,y:909,t:1527272154052};\\\", \\\"{x:1205,y:905,t:1527272154068};\\\", \\\"{x:1203,y:902,t:1527272154085};\\\", \\\"{x:1203,y:901,t:1527272154108};\\\", \\\"{x:1203,y:897,t:1527272154119};\\\", \\\"{x:1203,y:893,t:1527272154136};\\\", \\\"{x:1203,y:887,t:1527272154152};\\\", \\\"{x:1203,y:879,t:1527272154168};\\\", \\\"{x:1204,y:877,t:1527272154185};\\\", \\\"{x:1205,y:877,t:1527272154203};\\\", \\\"{x:1206,y:876,t:1527272154219};\\\", \\\"{x:1212,y:873,t:1527272154236};\\\", \\\"{x:1215,y:871,t:1527272154252};\\\", \\\"{x:1217,y:870,t:1527272154269};\\\", \\\"{x:1215,y:876,t:1527272154421};\\\", \\\"{x:1212,y:891,t:1527272154436};\\\", \\\"{x:1211,y:907,t:1527272154453};\\\", \\\"{x:1210,y:921,t:1527272154470};\\\", \\\"{x:1206,y:935,t:1527272154486};\\\", \\\"{x:1204,y:946,t:1527272154503};\\\", \\\"{x:1204,y:955,t:1527272154520};\\\", \\\"{x:1204,y:959,t:1527272154536};\\\", \\\"{x:1204,y:963,t:1527272154553};\\\", \\\"{x:1204,y:966,t:1527272154571};\\\", \\\"{x:1204,y:969,t:1527272154586};\\\", \\\"{x:1204,y:972,t:1527272154603};\\\", \\\"{x:1204,y:976,t:1527272154620};\\\", \\\"{x:1204,y:980,t:1527272154636};\\\", \\\"{x:1204,y:982,t:1527272154653};\\\", \\\"{x:1204,y:986,t:1527272154670};\\\", \\\"{x:1204,y:987,t:1527272154686};\\\", \\\"{x:1204,y:988,t:1527272154702};\\\", \\\"{x:1206,y:989,t:1527272154764};\\\", \\\"{x:1208,y:989,t:1527272154772};\\\", \\\"{x:1211,y:989,t:1527272154786};\\\", \\\"{x:1214,y:982,t:1527272154804};\\\", \\\"{x:1219,y:963,t:1527272154821};\\\", \\\"{x:1221,y:953,t:1527272154837};\\\", \\\"{x:1224,y:942,t:1527272154853};\\\", \\\"{x:1224,y:934,t:1527272154870};\\\", \\\"{x:1224,y:924,t:1527272154887};\\\", \\\"{x:1224,y:914,t:1527272154903};\\\", \\\"{x:1223,y:907,t:1527272154920};\\\", \\\"{x:1223,y:904,t:1527272154937};\\\", \\\"{x:1223,y:901,t:1527272154953};\\\", \\\"{x:1223,y:897,t:1527272154970};\\\", \\\"{x:1222,y:892,t:1527272154987};\\\", \\\"{x:1218,y:883,t:1527272155003};\\\", \\\"{x:1218,y:878,t:1527272155021};\\\", \\\"{x:1218,y:876,t:1527272155037};\\\", \\\"{x:1218,y:873,t:1527272155053};\\\", \\\"{x:1217,y:869,t:1527272155070};\\\", \\\"{x:1214,y:862,t:1527272155087};\\\", \\\"{x:1210,y:854,t:1527272155103};\\\", \\\"{x:1210,y:850,t:1527272155120};\\\", \\\"{x:1210,y:849,t:1527272155137};\\\", \\\"{x:1210,y:846,t:1527272155153};\\\", \\\"{x:1211,y:845,t:1527272155181};\\\", \\\"{x:1211,y:844,t:1527272155188};\\\", \\\"{x:1212,y:844,t:1527272155204};\\\", \\\"{x:1213,y:843,t:1527272155220};\\\", \\\"{x:1215,y:842,t:1527272155236};\\\", \\\"{x:1216,y:841,t:1527272155253};\\\", \\\"{x:1217,y:840,t:1527272155333};\\\", \\\"{x:1216,y:839,t:1527272155477};\\\", \\\"{x:1213,y:839,t:1527272155487};\\\", \\\"{x:1212,y:838,t:1527272155589};\\\", \\\"{x:1212,y:835,t:1527272155653};\\\", \\\"{x:1212,y:832,t:1527272155670};\\\", \\\"{x:1212,y:830,t:1527272155687};\\\", \\\"{x:1212,y:826,t:1527272155704};\\\", \\\"{x:1215,y:822,t:1527272155721};\\\", \\\"{x:1217,y:820,t:1527272155738};\\\", \\\"{x:1218,y:820,t:1527272155754};\\\", \\\"{x:1218,y:819,t:1527272155771};\\\", \\\"{x:1218,y:817,t:1527272155787};\\\", \\\"{x:1209,y:803,t:1527272155804};\\\", \\\"{x:1199,y:792,t:1527272155821};\\\", \\\"{x:1189,y:781,t:1527272155836};\\\", \\\"{x:1186,y:775,t:1527272155853};\\\", \\\"{x:1185,y:773,t:1527272155871};\\\", \\\"{x:1185,y:771,t:1527272155886};\\\", \\\"{x:1187,y:766,t:1527272155903};\\\", \\\"{x:1191,y:761,t:1527272155921};\\\", \\\"{x:1194,y:759,t:1527272155936};\\\", \\\"{x:1197,y:756,t:1527272155954};\\\", \\\"{x:1198,y:752,t:1527272155971};\\\", \\\"{x:1200,y:748,t:1527272155987};\\\", \\\"{x:1202,y:745,t:1527272156004};\\\", \\\"{x:1206,y:741,t:1527272156020};\\\", \\\"{x:1210,y:737,t:1527272156036};\\\", \\\"{x:1213,y:732,t:1527272156053};\\\", \\\"{x:1218,y:719,t:1527272156071};\\\", \\\"{x:1222,y:708,t:1527272156087};\\\", \\\"{x:1229,y:696,t:1527272156104};\\\", \\\"{x:1239,y:682,t:1527272156122};\\\", \\\"{x:1248,y:665,t:1527272156137};\\\", \\\"{x:1254,y:650,t:1527272156154};\\\", \\\"{x:1254,y:642,t:1527272156171};\\\", \\\"{x:1253,y:632,t:1527272156187};\\\", \\\"{x:1252,y:627,t:1527272156205};\\\", \\\"{x:1252,y:625,t:1527272156221};\\\", \\\"{x:1252,y:623,t:1527272156237};\\\", \\\"{x:1252,y:620,t:1527272156253};\\\", \\\"{x:1252,y:617,t:1527272156270};\\\", \\\"{x:1253,y:615,t:1527272156287};\\\", \\\"{x:1254,y:614,t:1527272156303};\\\", \\\"{x:1257,y:612,t:1527272156320};\\\", \\\"{x:1258,y:610,t:1527272156337};\\\", \\\"{x:1258,y:607,t:1527272156354};\\\", \\\"{x:1259,y:604,t:1527272156371};\\\", \\\"{x:1259,y:603,t:1527272156387};\\\", \\\"{x:1259,y:602,t:1527272156404};\\\", \\\"{x:1260,y:601,t:1527272156420};\\\", \\\"{x:1260,y:599,t:1527272156444};\\\", \\\"{x:1260,y:598,t:1527272156454};\\\", \\\"{x:1260,y:594,t:1527272156470};\\\", \\\"{x:1260,y:589,t:1527272156488};\\\", \\\"{x:1261,y:585,t:1527272156503};\\\", \\\"{x:1263,y:583,t:1527272156520};\\\", \\\"{x:1263,y:581,t:1527272156538};\\\", \\\"{x:1263,y:579,t:1527272156554};\\\", \\\"{x:1265,y:578,t:1527272156580};\\\", \\\"{x:1266,y:577,t:1527272156589};\\\", \\\"{x:1270,y:575,t:1527272156604};\\\", \\\"{x:1271,y:574,t:1527272156621};\\\", \\\"{x:1273,y:573,t:1527272156638};\\\", \\\"{x:1274,y:571,t:1527272156933};\\\", \\\"{x:1272,y:572,t:1527272157229};\\\", \\\"{x:1271,y:572,t:1527272157238};\\\", \\\"{x:1269,y:574,t:1527272157255};\\\", \\\"{x:1269,y:588,t:1527272157273};\\\", \\\"{x:1269,y:595,t:1527272157288};\\\", \\\"{x:1271,y:602,t:1527272157305};\\\", \\\"{x:1272,y:610,t:1527272157322};\\\", \\\"{x:1275,y:620,t:1527272157339};\\\", \\\"{x:1276,y:625,t:1527272157355};\\\", \\\"{x:1276,y:631,t:1527272157372};\\\", \\\"{x:1277,y:639,t:1527272157389};\\\", \\\"{x:1280,y:648,t:1527272157405};\\\", \\\"{x:1285,y:664,t:1527272157422};\\\", \\\"{x:1289,y:677,t:1527272157439};\\\", \\\"{x:1292,y:691,t:1527272157455};\\\", \\\"{x:1293,y:700,t:1527272157472};\\\", \\\"{x:1294,y:702,t:1527272157488};\\\", \\\"{x:1295,y:707,t:1527272157505};\\\", \\\"{x:1295,y:712,t:1527272157522};\\\", \\\"{x:1296,y:716,t:1527272157539};\\\", \\\"{x:1298,y:719,t:1527272157555};\\\", \\\"{x:1298,y:727,t:1527272157572};\\\", \\\"{x:1298,y:731,t:1527272157588};\\\", \\\"{x:1298,y:734,t:1527272157605};\\\", \\\"{x:1298,y:735,t:1527272157622};\\\", \\\"{x:1298,y:738,t:1527272157640};\\\", \\\"{x:1298,y:741,t:1527272157655};\\\", \\\"{x:1298,y:743,t:1527272157672};\\\", \\\"{x:1300,y:745,t:1527272157701};\\\", \\\"{x:1300,y:748,t:1527272157716};\\\", \\\"{x:1300,y:749,t:1527272157725};\\\", \\\"{x:1300,y:752,t:1527272157739};\\\", \\\"{x:1300,y:757,t:1527272157755};\\\", \\\"{x:1300,y:764,t:1527272157773};\\\", \\\"{x:1300,y:770,t:1527272157789};\\\", \\\"{x:1301,y:775,t:1527272157805};\\\", \\\"{x:1301,y:779,t:1527272157822};\\\", \\\"{x:1301,y:784,t:1527272157839};\\\", \\\"{x:1301,y:788,t:1527272157855};\\\", \\\"{x:1300,y:795,t:1527272157872};\\\", \\\"{x:1300,y:800,t:1527272157889};\\\", \\\"{x:1300,y:804,t:1527272157906};\\\", \\\"{x:1297,y:812,t:1527272157922};\\\", \\\"{x:1297,y:817,t:1527272157939};\\\", \\\"{x:1293,y:826,t:1527272157956};\\\", \\\"{x:1291,y:836,t:1527272157972};\\\", \\\"{x:1289,y:845,t:1527272157989};\\\", \\\"{x:1289,y:855,t:1527272158005};\\\", \\\"{x:1288,y:862,t:1527272158021};\\\", \\\"{x:1286,y:869,t:1527272158038};\\\", \\\"{x:1284,y:877,t:1527272158055};\\\", \\\"{x:1283,y:887,t:1527272158071};\\\", \\\"{x:1283,y:897,t:1527272158089};\\\", \\\"{x:1283,y:902,t:1527272158105};\\\", \\\"{x:1283,y:906,t:1527272158122};\\\", \\\"{x:1283,y:910,t:1527272158138};\\\", \\\"{x:1284,y:921,t:1527272158156};\\\", \\\"{x:1287,y:932,t:1527272158172};\\\", \\\"{x:1290,y:942,t:1527272158189};\\\", \\\"{x:1293,y:949,t:1527272158206};\\\", \\\"{x:1293,y:950,t:1527272158222};\\\", \\\"{x:1293,y:951,t:1527272158251};\\\", \\\"{x:1293,y:939,t:1527272160533};\\\", \\\"{x:1291,y:905,t:1527272160542};\\\", \\\"{x:1277,y:860,t:1527272160557};\\\", \\\"{x:1268,y:803,t:1527272160574};\\\", \\\"{x:1268,y:775,t:1527272160591};\\\", \\\"{x:1271,y:738,t:1527272160607};\\\", \\\"{x:1281,y:704,t:1527272160624};\\\", \\\"{x:1285,y:677,t:1527272160642};\\\", \\\"{x:1289,y:657,t:1527272160658};\\\", \\\"{x:1289,y:637,t:1527272160675};\\\", \\\"{x:1289,y:627,t:1527272160691};\\\", \\\"{x:1292,y:615,t:1527272160708};\\\", \\\"{x:1292,y:613,t:1527272160749};\\\", \\\"{x:1292,y:612,t:1527272160772};\\\", \\\"{x:1293,y:611,t:1527272160804};\\\", \\\"{x:1295,y:610,t:1527272160812};\\\", \\\"{x:1297,y:615,t:1527272160852};\\\", \\\"{x:1303,y:629,t:1527272160860};\\\", \\\"{x:1307,y:641,t:1527272160874};\\\", \\\"{x:1315,y:660,t:1527272160891};\\\", \\\"{x:1320,y:677,t:1527272160908};\\\", \\\"{x:1320,y:678,t:1527272160925};\\\", \\\"{x:1320,y:679,t:1527272160941};\\\", \\\"{x:1323,y:681,t:1527272160958};\\\", \\\"{x:1325,y:682,t:1527272160975};\\\", \\\"{x:1327,y:685,t:1527272161037};\\\", \\\"{x:1329,y:689,t:1527272161044};\\\", \\\"{x:1331,y:691,t:1527272161058};\\\", \\\"{x:1337,y:697,t:1527272161075};\\\", \\\"{x:1338,y:698,t:1527272161091};\\\", \\\"{x:1339,y:698,t:1527272161317};\\\", \\\"{x:1341,y:698,t:1527272161332};\\\", \\\"{x:1342,y:698,t:1527272161348};\\\", \\\"{x:1343,y:698,t:1527272161375};\\\", \\\"{x:1344,y:697,t:1527272161396};\\\", \\\"{x:1346,y:697,t:1527272161477};\\\", \\\"{x:1347,y:697,t:1527272161516};\\\", \\\"{x:1348,y:697,t:1527272161540};\\\", \\\"{x:1348,y:699,t:1527272162836};\\\", \\\"{x:1348,y:705,t:1527272162845};\\\", \\\"{x:1347,y:713,t:1527272162860};\\\", \\\"{x:1344,y:728,t:1527272162876};\\\", \\\"{x:1344,y:738,t:1527272162893};\\\", \\\"{x:1341,y:752,t:1527272162909};\\\", \\\"{x:1341,y:761,t:1527272162927};\\\", \\\"{x:1341,y:772,t:1527272162943};\\\", \\\"{x:1341,y:785,t:1527272162960};\\\", \\\"{x:1341,y:799,t:1527272162977};\\\", \\\"{x:1341,y:822,t:1527272162993};\\\", \\\"{x:1348,y:860,t:1527272163010};\\\", \\\"{x:1353,y:884,t:1527272163027};\\\", \\\"{x:1355,y:894,t:1527272163043};\\\", \\\"{x:1356,y:899,t:1527272163060};\\\", \\\"{x:1358,y:909,t:1527272163076};\\\", \\\"{x:1359,y:924,t:1527272163094};\\\", \\\"{x:1359,y:937,t:1527272163109};\\\", \\\"{x:1360,y:942,t:1527272163126};\\\", \\\"{x:1362,y:949,t:1527272163143};\\\", \\\"{x:1363,y:951,t:1527272163159};\\\", \\\"{x:1366,y:955,t:1527272163176};\\\", \\\"{x:1367,y:956,t:1527272163194};\\\", \\\"{x:1370,y:957,t:1527272163210};\\\", \\\"{x:1371,y:956,t:1527272163324};\\\", \\\"{x:1371,y:950,t:1527272163332};\\\", \\\"{x:1369,y:942,t:1527272163344};\\\", \\\"{x:1366,y:923,t:1527272163361};\\\", \\\"{x:1364,y:906,t:1527272163377};\\\", \\\"{x:1359,y:890,t:1527272163394};\\\", \\\"{x:1357,y:875,t:1527272163410};\\\", \\\"{x:1353,y:859,t:1527272163427};\\\", \\\"{x:1353,y:850,t:1527272163443};\\\", \\\"{x:1352,y:831,t:1527272163460};\\\", \\\"{x:1351,y:821,t:1527272163477};\\\", \\\"{x:1349,y:813,t:1527272163493};\\\", \\\"{x:1348,y:804,t:1527272163510};\\\", \\\"{x:1348,y:797,t:1527272163526};\\\", \\\"{x:1348,y:792,t:1527272163543};\\\", \\\"{x:1348,y:786,t:1527272163560};\\\", \\\"{x:1348,y:782,t:1527272163575};\\\", \\\"{x:1348,y:777,t:1527272163593};\\\", \\\"{x:1348,y:774,t:1527272163610};\\\", \\\"{x:1348,y:770,t:1527272163626};\\\", \\\"{x:1348,y:767,t:1527272163643};\\\", \\\"{x:1348,y:765,t:1527272163660};\\\", \\\"{x:1348,y:764,t:1527272163677};\\\", \\\"{x:1348,y:761,t:1527272164732};\\\", \\\"{x:1348,y:753,t:1527272164745};\\\", \\\"{x:1348,y:748,t:1527272164761};\\\", \\\"{x:1348,y:739,t:1527272164776};\\\", \\\"{x:1348,y:731,t:1527272164794};\\\", \\\"{x:1349,y:726,t:1527272164810};\\\", \\\"{x:1349,y:725,t:1527272164827};\\\", \\\"{x:1349,y:720,t:1527272164844};\\\", \\\"{x:1350,y:718,t:1527272164860};\\\", \\\"{x:1350,y:716,t:1527272164877};\\\", \\\"{x:1350,y:713,t:1527272164893};\\\", \\\"{x:1350,y:711,t:1527272164911};\\\", \\\"{x:1350,y:710,t:1527272164927};\\\", \\\"{x:1350,y:708,t:1527272164944};\\\", \\\"{x:1351,y:707,t:1527272164963};\\\", \\\"{x:1351,y:705,t:1527272164987};\\\", \\\"{x:1351,y:704,t:1527272165019};\\\", \\\"{x:1351,y:701,t:1527272165589};\\\", \\\"{x:1349,y:699,t:1527272165611};\\\", \\\"{x:1347,y:697,t:1527272165628};\\\", \\\"{x:1346,y:694,t:1527272165700};\\\", \\\"{x:1345,y:694,t:1527272165712};\\\", \\\"{x:1343,y:693,t:1527272165728};\\\", \\\"{x:1342,y:692,t:1527272165789};\\\", \\\"{x:1336,y:690,t:1527272165804};\\\", \\\"{x:1332,y:689,t:1527272165812};\\\", \\\"{x:1310,y:685,t:1527272165829};\\\", \\\"{x:1272,y:682,t:1527272165845};\\\", \\\"{x:1211,y:682,t:1527272165862};\\\", \\\"{x:1104,y:672,t:1527272165878};\\\", \\\"{x:1000,y:668,t:1527272165896};\\\", \\\"{x:897,y:669,t:1527272165913};\\\", \\\"{x:742,y:671,t:1527272165928};\\\", \\\"{x:586,y:680,t:1527272165945};\\\", \\\"{x:441,y:690,t:1527272165963};\\\", \\\"{x:322,y:705,t:1527272165979};\\\", \\\"{x:254,y:717,t:1527272165995};\\\", \\\"{x:228,y:719,t:1527272166012};\\\", \\\"{x:221,y:719,t:1527272166028};\\\", \\\"{x:216,y:719,t:1527272166045};\\\", \\\"{x:205,y:718,t:1527272166062};\\\", \\\"{x:192,y:717,t:1527272166078};\\\", \\\"{x:179,y:715,t:1527272166095};\\\", \\\"{x:174,y:714,t:1527272166112};\\\", \\\"{x:166,y:707,t:1527272166128};\\\", \\\"{x:149,y:690,t:1527272166145};\\\", \\\"{x:123,y:669,t:1527272166164};\\\", \\\"{x:118,y:661,t:1527272166177};\\\", \\\"{x:130,y:644,t:1527272166195};\\\", \\\"{x:142,y:633,t:1527272166212};\\\", \\\"{x:157,y:623,t:1527272166230};\\\", \\\"{x:161,y:620,t:1527272166245};\\\", \\\"{x:161,y:615,t:1527272166261};\\\", \\\"{x:162,y:613,t:1527272166279};\\\", \\\"{x:167,y:609,t:1527272166295};\\\", \\\"{x:172,y:604,t:1527272166312};\\\", \\\"{x:174,y:600,t:1527272166329};\\\", \\\"{x:176,y:594,t:1527272166346};\\\", \\\"{x:177,y:590,t:1527272166363};\\\", \\\"{x:179,y:586,t:1527272166379};\\\", \\\"{x:184,y:580,t:1527272166395};\\\", \\\"{x:185,y:577,t:1527272166412};\\\", \\\"{x:185,y:574,t:1527272166429};\\\", \\\"{x:185,y:572,t:1527272166446};\\\", \\\"{x:185,y:570,t:1527272166462};\\\", \\\"{x:185,y:568,t:1527272166479};\\\", \\\"{x:185,y:566,t:1527272166496};\\\", \\\"{x:185,y:561,t:1527272166513};\\\", \\\"{x:185,y:557,t:1527272166529};\\\", \\\"{x:185,y:554,t:1527272166547};\\\", \\\"{x:191,y:550,t:1527272166564};\\\", \\\"{x:204,y:545,t:1527272166579};\\\", \\\"{x:225,y:534,t:1527272166595};\\\", \\\"{x:240,y:531,t:1527272166612};\\\", \\\"{x:252,y:528,t:1527272166629};\\\", \\\"{x:269,y:528,t:1527272166646};\\\", \\\"{x:289,y:528,t:1527272166665};\\\", \\\"{x:316,y:532,t:1527272166678};\\\", \\\"{x:379,y:541,t:1527272166696};\\\", \\\"{x:463,y:554,t:1527272166713};\\\", \\\"{x:536,y:558,t:1527272166729};\\\", \\\"{x:584,y:558,t:1527272166745};\\\", \\\"{x:629,y:558,t:1527272166762};\\\", \\\"{x:685,y:558,t:1527272166779};\\\", \\\"{x:796,y:558,t:1527272166795};\\\", \\\"{x:829,y:558,t:1527272166813};\\\", \\\"{x:840,y:558,t:1527272166829};\\\", \\\"{x:843,y:558,t:1527272166846};\\\", \\\"{x:844,y:558,t:1527272166883};\\\", \\\"{x:846,y:558,t:1527272166899};\\\", \\\"{x:849,y:557,t:1527272166913};\\\", \\\"{x:861,y:554,t:1527272166933};\\\", \\\"{x:867,y:552,t:1527272166946};\\\", \\\"{x:868,y:551,t:1527272166962};\\\", \\\"{x:871,y:551,t:1527272166979};\\\", \\\"{x:875,y:550,t:1527272166994};\\\", \\\"{x:881,y:549,t:1527272167011};\\\", \\\"{x:881,y:548,t:1527272167043};\\\", \\\"{x:881,y:545,t:1527272167051};\\\", \\\"{x:874,y:537,t:1527272167062};\\\", \\\"{x:861,y:528,t:1527272167078};\\\", \\\"{x:860,y:526,t:1527272167095};\\\", \\\"{x:860,y:525,t:1527272167123};\\\", \\\"{x:860,y:523,t:1527272167148};\\\", \\\"{x:859,y:523,t:1527272167163};\\\", \\\"{x:859,y:522,t:1527272167179};\\\", \\\"{x:858,y:521,t:1527272167196};\\\", \\\"{x:857,y:519,t:1527272167236};\\\", \\\"{x:855,y:519,t:1527272167247};\\\", \\\"{x:849,y:515,t:1527272167264};\\\", \\\"{x:846,y:514,t:1527272167280};\\\", \\\"{x:844,y:514,t:1527272167388};\\\", \\\"{x:843,y:513,t:1527272167397};\\\", \\\"{x:841,y:512,t:1527272167419};\\\", \\\"{x:840,y:511,t:1527272167430};\\\", \\\"{x:839,y:511,t:1527272167507};\\\", \\\"{x:837,y:510,t:1527272167699};\\\", \\\"{x:835,y:510,t:1527272167712};\\\", \\\"{x:828,y:510,t:1527272167730};\\\", \\\"{x:825,y:510,t:1527272167747};\\\", \\\"{x:822,y:512,t:1527272167763};\\\", \\\"{x:815,y:516,t:1527272167780};\\\", \\\"{x:799,y:521,t:1527272167797};\\\", \\\"{x:780,y:533,t:1527272167813};\\\", \\\"{x:762,y:548,t:1527272167830};\\\", \\\"{x:751,y:562,t:1527272167847};\\\", \\\"{x:736,y:581,t:1527272167863};\\\", \\\"{x:711,y:602,t:1527272167881};\\\", \\\"{x:679,y:625,t:1527272167897};\\\", \\\"{x:649,y:650,t:1527272167914};\\\", \\\"{x:632,y:664,t:1527272167930};\\\", \\\"{x:617,y:675,t:1527272167947};\\\", \\\"{x:608,y:680,t:1527272167963};\\\", \\\"{x:603,y:681,t:1527272167980};\\\", \\\"{x:601,y:683,t:1527272167997};\\\", \\\"{x:596,y:685,t:1527272168014};\\\", \\\"{x:590,y:688,t:1527272168030};\\\", \\\"{x:578,y:693,t:1527272168047};\\\", \\\"{x:566,y:698,t:1527272168064};\\\", \\\"{x:562,y:701,t:1527272168080};\\\", \\\"{x:561,y:701,t:1527272168097};\\\", \\\"{x:560,y:701,t:1527272168124};\\\", \\\"{x:557,y:702,t:1527272168132};\\\", \\\"{x:551,y:705,t:1527272168148};\\\", \\\"{x:540,y:710,t:1527272168164};\\\", \\\"{x:533,y:714,t:1527272168180};\\\", \\\"{x:527,y:720,t:1527272168198};\\\", \\\"{x:519,y:724,t:1527272168214};\\\", \\\"{x:517,y:727,t:1527272168230};\\\", \\\"{x:515,y:728,t:1527272168247};\\\", \\\"{x:514,y:730,t:1527272168264};\\\", \\\"{x:513,y:730,t:1527272168284};\\\", \\\"{x:512,y:731,t:1527272168297};\\\", \\\"{x:511,y:732,t:1527272168315};\\\", \\\"{x:509,y:733,t:1527272168330};\\\" ] }, { \\\"rt\\\": 34020, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 1149123, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-03 PM-O -X -X -X -X -C -M -12 PM-B -B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:508,y:734,t:1527272174099};\\\", \\\"{x:521,y:745,t:1527272174107};\\\", \\\"{x:549,y:762,t:1527272174119};\\\", \\\"{x:601,y:796,t:1527272174135};\\\", \\\"{x:651,y:829,t:1527272174152};\\\", \\\"{x:724,y:864,t:1527272174168};\\\", \\\"{x:846,y:902,t:1527272174184};\\\", \\\"{x:1004,y:946,t:1527272174202};\\\", \\\"{x:1140,y:987,t:1527272174218};\\\", \\\"{x:1234,y:1016,t:1527272174235};\\\", \\\"{x:1290,y:1025,t:1527272174251};\\\", \\\"{x:1290,y:1024,t:1527272174267};\\\", \\\"{x:1291,y:1027,t:1527272174653};\\\", \\\"{x:1292,y:1030,t:1527272174668};\\\", \\\"{x:1293,y:1030,t:1527272174732};\\\", \\\"{x:1294,y:1030,t:1527272174740};\\\", \\\"{x:1297,y:1030,t:1527272174752};\\\", \\\"{x:1311,y:1032,t:1527272174768};\\\", \\\"{x:1325,y:1034,t:1527272174786};\\\", \\\"{x:1338,y:1035,t:1527272174802};\\\", \\\"{x:1353,y:1036,t:1527272174818};\\\", \\\"{x:1377,y:1039,t:1527272174836};\\\", \\\"{x:1394,y:1039,t:1527272174852};\\\", \\\"{x:1412,y:1039,t:1527272174869};\\\", \\\"{x:1421,y:1038,t:1527272174886};\\\", \\\"{x:1427,y:1036,t:1527272174902};\\\", \\\"{x:1428,y:1035,t:1527272174919};\\\", \\\"{x:1429,y:1035,t:1527272174936};\\\", \\\"{x:1430,y:1034,t:1527272174951};\\\", \\\"{x:1435,y:1032,t:1527272174969};\\\", \\\"{x:1440,y:1031,t:1527272174986};\\\", \\\"{x:1445,y:1030,t:1527272175001};\\\", \\\"{x:1449,y:1028,t:1527272175018};\\\", \\\"{x:1452,y:1026,t:1527272175036};\\\", \\\"{x:1458,y:1024,t:1527272175052};\\\", \\\"{x:1461,y:1023,t:1527272175068};\\\", \\\"{x:1462,y:1023,t:1527272175085};\\\", \\\"{x:1463,y:1021,t:1527272175140};\\\", \\\"{x:1465,y:1020,t:1527272175152};\\\", \\\"{x:1466,y:1020,t:1527272175168};\\\", \\\"{x:1469,y:1019,t:1527272175186};\\\", \\\"{x:1470,y:1018,t:1527272175201};\\\", \\\"{x:1472,y:1017,t:1527272175244};\\\", \\\"{x:1472,y:1016,t:1527272175252};\\\", \\\"{x:1475,y:1016,t:1527272175268};\\\", \\\"{x:1476,y:1014,t:1527272175286};\\\", \\\"{x:1477,y:1013,t:1527272175302};\\\", \\\"{x:1478,y:1011,t:1527272175318};\\\", \\\"{x:1479,y:1009,t:1527272175336};\\\", \\\"{x:1481,y:1007,t:1527272175353};\\\", \\\"{x:1484,y:1005,t:1527272175369};\\\", \\\"{x:1486,y:1004,t:1527272175386};\\\", \\\"{x:1487,y:1004,t:1527272175403};\\\", \\\"{x:1488,y:1004,t:1527272175419};\\\", \\\"{x:1488,y:1003,t:1527272175444};\\\", \\\"{x:1489,y:1002,t:1527272175452};\\\", \\\"{x:1491,y:1001,t:1527272175469};\\\", \\\"{x:1492,y:999,t:1527272175500};\\\", \\\"{x:1493,y:999,t:1527272175507};\\\", \\\"{x:1493,y:996,t:1527272175519};\\\", \\\"{x:1495,y:995,t:1527272175536};\\\", \\\"{x:1498,y:993,t:1527272175553};\\\", \\\"{x:1500,y:993,t:1527272175569};\\\", \\\"{x:1501,y:992,t:1527272175586};\\\", \\\"{x:1502,y:991,t:1527272175603};\\\", \\\"{x:1502,y:990,t:1527272175619};\\\", \\\"{x:1508,y:986,t:1527272175636};\\\", \\\"{x:1511,y:986,t:1527272175652};\\\", \\\"{x:1514,y:984,t:1527272175669};\\\", \\\"{x:1515,y:984,t:1527272175692};\\\", \\\"{x:1515,y:983,t:1527272175707};\\\", \\\"{x:1516,y:983,t:1527272175719};\\\", \\\"{x:1519,y:982,t:1527272175736};\\\", \\\"{x:1524,y:981,t:1527272175753};\\\", \\\"{x:1528,y:980,t:1527272175769};\\\", \\\"{x:1531,y:980,t:1527272175786};\\\", \\\"{x:1532,y:979,t:1527272175802};\\\", \\\"{x:1533,y:978,t:1527272175819};\\\", \\\"{x:1534,y:977,t:1527272175835};\\\", \\\"{x:1535,y:976,t:1527272175853};\\\", \\\"{x:1536,y:975,t:1527272175870};\\\", \\\"{x:1537,y:975,t:1527272175885};\\\", \\\"{x:1537,y:973,t:1527272175903};\\\", \\\"{x:1538,y:973,t:1527272175920};\\\", \\\"{x:1539,y:972,t:1527272175940};\\\", \\\"{x:1541,y:972,t:1527272175964};\\\", \\\"{x:1542,y:970,t:1527272175988};\\\", \\\"{x:1543,y:970,t:1527272176012};\\\", \\\"{x:1543,y:969,t:1527272176300};\\\", \\\"{x:1543,y:968,t:1527272176309};\\\", \\\"{x:1544,y:967,t:1527272176319};\\\", \\\"{x:1545,y:967,t:1527272176335};\\\", \\\"{x:1546,y:967,t:1527272176475};\\\", \\\"{x:1547,y:967,t:1527272178917};\\\", \\\"{x:1550,y:968,t:1527272178923};\\\", \\\"{x:1550,y:971,t:1527272178938};\\\", \\\"{x:1552,y:974,t:1527272178955};\\\", \\\"{x:1552,y:975,t:1527272178971};\\\", \\\"{x:1553,y:979,t:1527272178987};\\\", \\\"{x:1554,y:981,t:1527272179004};\\\", \\\"{x:1555,y:982,t:1527272179020};\\\", \\\"{x:1555,y:981,t:1527272179188};\\\", \\\"{x:1554,y:977,t:1527272179205};\\\", \\\"{x:1554,y:975,t:1527272179276};\\\", \\\"{x:1553,y:974,t:1527272179288};\\\", \\\"{x:1552,y:972,t:1527272179691};\\\", \\\"{x:1552,y:971,t:1527272179704};\\\", \\\"{x:1552,y:966,t:1527272179757};\\\", \\\"{x:1552,y:958,t:1527272179771};\\\", \\\"{x:1552,y:955,t:1527272179788};\\\", \\\"{x:1552,y:951,t:1527272179805};\\\", \\\"{x:1552,y:949,t:1527272179836};\\\", \\\"{x:1552,y:948,t:1527272179844};\\\", \\\"{x:1552,y:946,t:1527272179860};\\\", \\\"{x:1552,y:945,t:1527272179884};\\\", \\\"{x:1552,y:944,t:1527272179900};\\\", \\\"{x:1552,y:943,t:1527272179908};\\\", \\\"{x:1552,y:942,t:1527272179931};\\\", \\\"{x:1552,y:941,t:1527272179947};\\\", \\\"{x:1552,y:940,t:1527272179956};\\\", \\\"{x:1552,y:938,t:1527272179972};\\\", \\\"{x:1552,y:936,t:1527272179989};\\\", \\\"{x:1550,y:934,t:1527272180005};\\\", \\\"{x:1550,y:930,t:1527272180022};\\\", \\\"{x:1550,y:927,t:1527272180039};\\\", \\\"{x:1550,y:923,t:1527272180055};\\\", \\\"{x:1548,y:919,t:1527272180072};\\\", \\\"{x:1547,y:916,t:1527272180089};\\\", \\\"{x:1547,y:914,t:1527272180105};\\\", \\\"{x:1547,y:911,t:1527272180123};\\\", \\\"{x:1547,y:908,t:1527272180139};\\\", \\\"{x:1547,y:906,t:1527272180155};\\\", \\\"{x:1547,y:905,t:1527272180172};\\\", \\\"{x:1547,y:906,t:1527272180275};\\\", \\\"{x:1547,y:910,t:1527272180289};\\\", \\\"{x:1547,y:918,t:1527272180305};\\\", \\\"{x:1546,y:928,t:1527272180324};\\\", \\\"{x:1545,y:935,t:1527272180340};\\\", \\\"{x:1545,y:940,t:1527272180355};\\\", \\\"{x:1545,y:946,t:1527272180372};\\\", \\\"{x:1545,y:947,t:1527272180389};\\\", \\\"{x:1545,y:948,t:1527272180428};\\\", \\\"{x:1545,y:949,t:1527272180439};\\\", \\\"{x:1545,y:952,t:1527272180468};\\\", \\\"{x:1545,y:953,t:1527272180476};\\\", \\\"{x:1545,y:954,t:1527272180489};\\\", \\\"{x:1545,y:956,t:1527272180506};\\\", \\\"{x:1545,y:957,t:1527272180532};\\\", \\\"{x:1545,y:958,t:1527272180540};\\\", \\\"{x:1545,y:959,t:1527272180556};\\\", \\\"{x:1547,y:960,t:1527272180844};\\\", \\\"{x:1550,y:957,t:1527272180856};\\\", \\\"{x:1552,y:949,t:1527272180872};\\\", \\\"{x:1552,y:941,t:1527272180889};\\\", \\\"{x:1552,y:939,t:1527272180906};\\\", \\\"{x:1551,y:934,t:1527272180923};\\\", \\\"{x:1551,y:933,t:1527272180939};\\\", \\\"{x:1551,y:930,t:1527272180956};\\\", \\\"{x:1549,y:927,t:1527272180973};\\\", \\\"{x:1548,y:924,t:1527272180989};\\\", \\\"{x:1548,y:921,t:1527272181006};\\\", \\\"{x:1548,y:920,t:1527272181023};\\\", \\\"{x:1548,y:917,t:1527272181039};\\\", \\\"{x:1546,y:914,t:1527272181056};\\\", \\\"{x:1546,y:912,t:1527272181073};\\\", \\\"{x:1544,y:907,t:1527272181089};\\\", \\\"{x:1543,y:903,t:1527272181106};\\\", \\\"{x:1542,y:900,t:1527272181124};\\\", \\\"{x:1542,y:899,t:1527272181140};\\\", \\\"{x:1542,y:892,t:1527272181155};\\\", \\\"{x:1541,y:888,t:1527272181173};\\\", \\\"{x:1538,y:879,t:1527272181189};\\\", \\\"{x:1531,y:868,t:1527272181206};\\\", \\\"{x:1526,y:855,t:1527272181223};\\\", \\\"{x:1527,y:847,t:1527272181239};\\\", \\\"{x:1531,y:842,t:1527272181256};\\\", \\\"{x:1531,y:837,t:1527272181273};\\\", \\\"{x:1532,y:835,t:1527272181289};\\\", \\\"{x:1532,y:832,t:1527272181306};\\\", \\\"{x:1534,y:829,t:1527272181323};\\\", \\\"{x:1535,y:828,t:1527272181340};\\\", \\\"{x:1536,y:827,t:1527272181355};\\\", \\\"{x:1537,y:826,t:1527272181373};\\\", \\\"{x:1539,y:824,t:1527272181389};\\\", \\\"{x:1539,y:821,t:1527272181406};\\\", \\\"{x:1539,y:817,t:1527272181423};\\\", \\\"{x:1539,y:816,t:1527272181439};\\\", \\\"{x:1542,y:813,t:1527272181456};\\\", \\\"{x:1542,y:811,t:1527272181474};\\\", \\\"{x:1542,y:808,t:1527272181489};\\\", \\\"{x:1542,y:806,t:1527272181507};\\\", \\\"{x:1542,y:804,t:1527272181524};\\\", \\\"{x:1542,y:801,t:1527272181538};\\\", \\\"{x:1541,y:797,t:1527272181555};\\\", \\\"{x:1539,y:792,t:1527272181572};\\\", \\\"{x:1538,y:786,t:1527272181588};\\\", \\\"{x:1537,y:784,t:1527272181605};\\\", \\\"{x:1535,y:782,t:1527272181622};\\\", \\\"{x:1533,y:780,t:1527272181640};\\\", \\\"{x:1532,y:778,t:1527272181656};\\\", \\\"{x:1531,y:777,t:1527272181672};\\\", \\\"{x:1531,y:776,t:1527272181724};\\\", \\\"{x:1531,y:773,t:1527272181740};\\\", \\\"{x:1530,y:772,t:1527272181756};\\\", \\\"{x:1529,y:770,t:1527272181804};\\\", \\\"{x:1528,y:770,t:1527272181820};\\\", \\\"{x:1527,y:770,t:1527272181844};\\\", \\\"{x:1527,y:769,t:1527272181856};\\\", \\\"{x:1525,y:769,t:1527272181874};\\\", \\\"{x:1525,y:768,t:1527272181891};\\\", \\\"{x:1524,y:768,t:1527272181906};\\\", \\\"{x:1523,y:767,t:1527272181989};\\\", \\\"{x:1522,y:767,t:1527272181996};\\\", \\\"{x:1521,y:767,t:1527272182028};\\\", \\\"{x:1519,y:766,t:1527272182046};\\\", \\\"{x:1519,y:765,t:1527272182055};\\\", \\\"{x:1518,y:764,t:1527272182072};\\\", \\\"{x:1514,y:763,t:1527272183484};\\\", \\\"{x:1512,y:763,t:1527272183491};\\\", \\\"{x:1510,y:765,t:1527272183507};\\\", \\\"{x:1503,y:772,t:1527272183525};\\\", \\\"{x:1501,y:776,t:1527272183541};\\\", \\\"{x:1499,y:778,t:1527272183556};\\\", \\\"{x:1498,y:779,t:1527272183574};\\\", \\\"{x:1497,y:780,t:1527272183591};\\\", \\\"{x:1496,y:781,t:1527272183607};\\\", \\\"{x:1495,y:783,t:1527272183623};\\\", \\\"{x:1493,y:786,t:1527272183640};\\\", \\\"{x:1493,y:788,t:1527272183656};\\\", \\\"{x:1492,y:790,t:1527272183674};\\\", \\\"{x:1492,y:791,t:1527272183692};\\\", \\\"{x:1492,y:792,t:1527272183715};\\\", \\\"{x:1492,y:793,t:1527272183723};\\\", \\\"{x:1490,y:795,t:1527272183741};\\\", \\\"{x:1490,y:798,t:1527272183757};\\\", \\\"{x:1488,y:800,t:1527272183774};\\\", \\\"{x:1488,y:803,t:1527272183791};\\\", \\\"{x:1486,y:806,t:1527272183806};\\\", \\\"{x:1486,y:809,t:1527272183824};\\\", \\\"{x:1486,y:811,t:1527272183841};\\\", \\\"{x:1486,y:814,t:1527272183857};\\\", \\\"{x:1484,y:815,t:1527272183875};\\\", \\\"{x:1483,y:816,t:1527272183891};\\\", \\\"{x:1482,y:817,t:1527272183908};\\\", \\\"{x:1482,y:818,t:1527272183923};\\\", \\\"{x:1482,y:819,t:1527272184020};\\\", \\\"{x:1482,y:821,t:1527272184043};\\\", \\\"{x:1482,y:824,t:1527272184058};\\\", \\\"{x:1484,y:831,t:1527272184075};\\\", \\\"{x:1484,y:833,t:1527272184090};\\\", \\\"{x:1484,y:836,t:1527272184109};\\\", \\\"{x:1483,y:831,t:1527272185389};\\\", \\\"{x:1483,y:822,t:1527272185409};\\\", \\\"{x:1483,y:815,t:1527272185425};\\\", \\\"{x:1480,y:808,t:1527272185442};\\\", \\\"{x:1480,y:804,t:1527272185459};\\\", \\\"{x:1478,y:797,t:1527272185475};\\\", \\\"{x:1473,y:786,t:1527272185492};\\\", \\\"{x:1473,y:785,t:1527272185508};\\\", \\\"{x:1473,y:782,t:1527272185526};\\\", \\\"{x:1473,y:780,t:1527272185543};\\\", \\\"{x:1473,y:775,t:1527272185558};\\\", \\\"{x:1473,y:769,t:1527272185576};\\\", \\\"{x:1473,y:763,t:1527272185593};\\\", \\\"{x:1473,y:755,t:1527272185609};\\\", \\\"{x:1477,y:734,t:1527272185625};\\\", \\\"{x:1482,y:720,t:1527272185642};\\\", \\\"{x:1488,y:704,t:1527272185660};\\\", \\\"{x:1488,y:700,t:1527272185675};\\\", \\\"{x:1490,y:692,t:1527272185692};\\\", \\\"{x:1490,y:689,t:1527272185709};\\\", \\\"{x:1490,y:684,t:1527272185725};\\\", \\\"{x:1490,y:679,t:1527272185742};\\\", \\\"{x:1490,y:677,t:1527272185759};\\\", \\\"{x:1490,y:673,t:1527272185775};\\\", \\\"{x:1490,y:669,t:1527272185792};\\\", \\\"{x:1490,y:662,t:1527272185809};\\\", \\\"{x:1488,y:656,t:1527272185825};\\\", \\\"{x:1482,y:648,t:1527272185842};\\\", \\\"{x:1477,y:641,t:1527272185859};\\\", \\\"{x:1475,y:636,t:1527272185875};\\\", \\\"{x:1469,y:628,t:1527272185892};\\\", \\\"{x:1465,y:623,t:1527272185909};\\\", \\\"{x:1463,y:618,t:1527272185925};\\\", \\\"{x:1460,y:615,t:1527272185942};\\\", \\\"{x:1458,y:613,t:1527272185960};\\\", \\\"{x:1457,y:612,t:1527272185975};\\\", \\\"{x:1455,y:612,t:1527272186077};\\\", \\\"{x:1454,y:612,t:1527272186092};\\\", \\\"{x:1453,y:612,t:1527272186181};\\\", \\\"{x:1453,y:613,t:1527272186196};\\\", \\\"{x:1453,y:614,t:1527272186212};\\\", \\\"{x:1453,y:615,t:1527272186228};\\\", \\\"{x:1453,y:616,t:1527272186252};\\\", \\\"{x:1453,y:617,t:1527272186276};\\\", \\\"{x:1453,y:620,t:1527272186292};\\\", \\\"{x:1452,y:624,t:1527272186309};\\\", \\\"{x:1452,y:627,t:1527272186327};\\\", \\\"{x:1451,y:629,t:1527272186342};\\\", \\\"{x:1450,y:630,t:1527272186387};\\\", \\\"{x:1449,y:630,t:1527272186436};\\\", \\\"{x:1449,y:633,t:1527272187412};\\\", \\\"{x:1448,y:636,t:1527272187427};\\\", \\\"{x:1445,y:645,t:1527272187444};\\\", \\\"{x:1443,y:649,t:1527272187460};\\\", \\\"{x:1443,y:655,t:1527272187477};\\\", \\\"{x:1442,y:665,t:1527272187493};\\\", \\\"{x:1442,y:676,t:1527272187510};\\\", \\\"{x:1442,y:689,t:1527272187526};\\\", \\\"{x:1440,y:705,t:1527272187543};\\\", \\\"{x:1440,y:721,t:1527272187560};\\\", \\\"{x:1440,y:734,t:1527272187575};\\\", \\\"{x:1440,y:744,t:1527272187592};\\\", \\\"{x:1440,y:761,t:1527272187610};\\\", \\\"{x:1440,y:780,t:1527272187626};\\\", \\\"{x:1437,y:805,t:1527272187643};\\\", \\\"{x:1437,y:819,t:1527272187659};\\\", \\\"{x:1435,y:831,t:1527272187676};\\\", \\\"{x:1434,y:836,t:1527272187693};\\\", \\\"{x:1433,y:846,t:1527272187710};\\\", \\\"{x:1428,y:861,t:1527272187726};\\\", \\\"{x:1427,y:869,t:1527272187743};\\\", \\\"{x:1426,y:875,t:1527272187760};\\\", \\\"{x:1426,y:880,t:1527272187776};\\\", \\\"{x:1425,y:884,t:1527272187793};\\\", \\\"{x:1425,y:887,t:1527272187810};\\\", \\\"{x:1425,y:889,t:1527272187826};\\\", \\\"{x:1425,y:893,t:1527272187844};\\\", \\\"{x:1425,y:897,t:1527272187860};\\\", \\\"{x:1423,y:902,t:1527272187876};\\\", \\\"{x:1420,y:906,t:1527272187893};\\\", \\\"{x:1420,y:908,t:1527272187910};\\\", \\\"{x:1418,y:911,t:1527272187927};\\\", \\\"{x:1417,y:912,t:1527272187943};\\\", \\\"{x:1417,y:913,t:1527272187963};\\\", \\\"{x:1415,y:914,t:1527272187978};\\\", \\\"{x:1413,y:916,t:1527272187993};\\\", \\\"{x:1409,y:918,t:1527272188010};\\\", \\\"{x:1408,y:918,t:1527272188027};\\\", \\\"{x:1407,y:919,t:1527272188044};\\\", \\\"{x:1406,y:919,t:1527272188076};\\\", \\\"{x:1403,y:918,t:1527272188204};\\\", \\\"{x:1400,y:914,t:1527272188212};\\\", \\\"{x:1389,y:906,t:1527272188228};\\\", \\\"{x:1384,y:903,t:1527272188244};\\\", \\\"{x:1380,y:901,t:1527272188260};\\\", \\\"{x:1378,y:899,t:1527272188278};\\\", \\\"{x:1378,y:898,t:1527272189027};\\\", \\\"{x:1379,y:897,t:1527272189044};\\\", \\\"{x:1378,y:901,t:1527272190020};\\\", \\\"{x:1377,y:904,t:1527272190029};\\\", \\\"{x:1375,y:909,t:1527272190045};\\\", \\\"{x:1374,y:915,t:1527272190062};\\\", \\\"{x:1373,y:917,t:1527272190079};\\\", \\\"{x:1372,y:922,t:1527272190094};\\\", \\\"{x:1371,y:924,t:1527272190112};\\\", \\\"{x:1370,y:927,t:1527272190128};\\\", \\\"{x:1370,y:931,t:1527272190144};\\\", \\\"{x:1370,y:933,t:1527272190162};\\\", \\\"{x:1370,y:935,t:1527272190178};\\\", \\\"{x:1370,y:938,t:1527272190195};\\\", \\\"{x:1370,y:942,t:1527272190212};\\\", \\\"{x:1368,y:946,t:1527272190228};\\\", \\\"{x:1366,y:951,t:1527272190245};\\\", \\\"{x:1363,y:954,t:1527272190261};\\\", \\\"{x:1360,y:959,t:1527272190278};\\\", \\\"{x:1358,y:961,t:1527272190295};\\\", \\\"{x:1355,y:966,t:1527272190311};\\\", \\\"{x:1353,y:968,t:1527272190329};\\\", \\\"{x:1351,y:968,t:1527272190348};\\\", \\\"{x:1349,y:969,t:1527272190362};\\\", \\\"{x:1347,y:969,t:1527272190378};\\\", \\\"{x:1344,y:971,t:1527272190395};\\\", \\\"{x:1342,y:971,t:1527272190411};\\\", \\\"{x:1341,y:971,t:1527272190443};\\\", \\\"{x:1340,y:970,t:1527272190468};\\\", \\\"{x:1339,y:969,t:1527272191092};\\\", \\\"{x:1339,y:968,t:1527272191101};\\\", \\\"{x:1339,y:966,t:1527272191112};\\\", \\\"{x:1339,y:964,t:1527272191128};\\\", \\\"{x:1339,y:961,t:1527272191146};\\\", \\\"{x:1339,y:957,t:1527272191162};\\\", \\\"{x:1339,y:954,t:1527272191179};\\\", \\\"{x:1339,y:942,t:1527272191195};\\\", \\\"{x:1339,y:932,t:1527272191212};\\\", \\\"{x:1339,y:921,t:1527272191229};\\\", \\\"{x:1342,y:909,t:1527272191245};\\\", \\\"{x:1346,y:896,t:1527272191263};\\\", \\\"{x:1351,y:881,t:1527272191278};\\\", \\\"{x:1351,y:868,t:1527272191296};\\\", \\\"{x:1351,y:856,t:1527272191312};\\\", \\\"{x:1350,y:847,t:1527272191328};\\\", \\\"{x:1350,y:837,t:1527272191345};\\\", \\\"{x:1350,y:829,t:1527272191362};\\\", \\\"{x:1348,y:820,t:1527272191379};\\\", \\\"{x:1348,y:817,t:1527272191395};\\\", \\\"{x:1346,y:811,t:1527272191411};\\\", \\\"{x:1345,y:809,t:1527272191429};\\\", \\\"{x:1343,y:806,t:1527272191445};\\\", \\\"{x:1342,y:803,t:1527272191462};\\\", \\\"{x:1342,y:801,t:1527272191479};\\\", \\\"{x:1342,y:800,t:1527272191499};\\\", \\\"{x:1342,y:799,t:1527272191512};\\\", \\\"{x:1342,y:798,t:1527272191529};\\\", \\\"{x:1342,y:796,t:1527272191547};\\\", \\\"{x:1342,y:794,t:1527272191562};\\\", \\\"{x:1343,y:790,t:1527272191580};\\\", \\\"{x:1344,y:788,t:1527272191596};\\\", \\\"{x:1344,y:787,t:1527272191612};\\\", \\\"{x:1345,y:785,t:1527272191630};\\\", \\\"{x:1345,y:784,t:1527272191645};\\\", \\\"{x:1345,y:782,t:1527272191662};\\\", \\\"{x:1347,y:780,t:1527272191679};\\\", \\\"{x:1347,y:778,t:1527272191695};\\\", \\\"{x:1347,y:775,t:1527272191713};\\\", \\\"{x:1347,y:774,t:1527272191729};\\\", \\\"{x:1347,y:772,t:1527272191780};\\\", \\\"{x:1347,y:771,t:1527272191820};\\\", \\\"{x:1348,y:771,t:1527272191836};\\\", \\\"{x:1348,y:770,t:1527272192420};\\\", \\\"{x:1348,y:769,t:1527272192468};\\\", \\\"{x:1348,y:768,t:1527272192588};\\\", \\\"{x:1348,y:767,t:1527272193004};\\\", \\\"{x:1337,y:767,t:1527272193014};\\\", \\\"{x:1287,y:768,t:1527272193029};\\\", \\\"{x:1168,y:768,t:1527272193046};\\\", \\\"{x:1072,y:773,t:1527272193063};\\\", \\\"{x:1049,y:769,t:1527272193079};\\\", \\\"{x:1048,y:769,t:1527272193460};\\\", \\\"{x:1047,y:769,t:1527272193467};\\\", \\\"{x:1045,y:768,t:1527272193480};\\\", \\\"{x:1039,y:766,t:1527272193497};\\\", \\\"{x:1026,y:763,t:1527272193514};\\\", \\\"{x:1009,y:760,t:1527272193531};\\\", \\\"{x:978,y:750,t:1527272193546};\\\", \\\"{x:942,y:739,t:1527272193563};\\\", \\\"{x:927,y:737,t:1527272193581};\\\", \\\"{x:917,y:736,t:1527272193596};\\\", \\\"{x:893,y:732,t:1527272193613};\\\", \\\"{x:856,y:730,t:1527272193630};\\\", \\\"{x:805,y:723,t:1527272193646};\\\", \\\"{x:746,y:711,t:1527272193663};\\\", \\\"{x:684,y:703,t:1527272193680};\\\", \\\"{x:651,y:699,t:1527272193697};\\\", \\\"{x:610,y:691,t:1527272193714};\\\", \\\"{x:569,y:681,t:1527272193731};\\\", \\\"{x:501,y:660,t:1527272193748};\\\", \\\"{x:470,y:650,t:1527272193764};\\\", \\\"{x:450,y:642,t:1527272193779};\\\", \\\"{x:437,y:639,t:1527272193797};\\\", \\\"{x:426,y:635,t:1527272193818};\\\", \\\"{x:416,y:627,t:1527272193835};\\\", \\\"{x:414,y:625,t:1527272193851};\\\", \\\"{x:412,y:623,t:1527272193868};\\\", \\\"{x:412,y:622,t:1527272193915};\\\", \\\"{x:412,y:619,t:1527272193930};\\\", \\\"{x:412,y:618,t:1527272193938};\\\", \\\"{x:412,y:615,t:1527272193950};\\\", \\\"{x:412,y:614,t:1527272193968};\\\", \\\"{x:412,y:612,t:1527272193984};\\\", \\\"{x:412,y:610,t:1527272194001};\\\", \\\"{x:414,y:609,t:1527272194018};\\\", \\\"{x:415,y:608,t:1527272194034};\\\", \\\"{x:418,y:607,t:1527272194059};\\\", \\\"{x:418,y:606,t:1527272194075};\\\", \\\"{x:418,y:604,t:1527272194084};\\\", \\\"{x:418,y:602,t:1527272194101};\\\", \\\"{x:417,y:602,t:1527272194156};\\\", \\\"{x:416,y:602,t:1527272194168};\\\", \\\"{x:410,y:602,t:1527272194185};\\\", \\\"{x:402,y:602,t:1527272194201};\\\", \\\"{x:393,y:602,t:1527272194219};\\\", \\\"{x:375,y:601,t:1527272194236};\\\", \\\"{x:357,y:601,t:1527272194251};\\\", \\\"{x:334,y:600,t:1527272194270};\\\", \\\"{x:311,y:600,t:1527272194285};\\\", \\\"{x:288,y:599,t:1527272194301};\\\", \\\"{x:271,y:599,t:1527272194318};\\\", \\\"{x:264,y:597,t:1527272194335};\\\", \\\"{x:261,y:596,t:1527272194352};\\\", \\\"{x:258,y:596,t:1527272194367};\\\", \\\"{x:256,y:595,t:1527272194385};\\\", \\\"{x:252,y:594,t:1527272194402};\\\", \\\"{x:249,y:593,t:1527272194419};\\\", \\\"{x:246,y:592,t:1527272194435};\\\", \\\"{x:240,y:589,t:1527272194452};\\\", \\\"{x:232,y:584,t:1527272194467};\\\", \\\"{x:227,y:580,t:1527272194485};\\\", \\\"{x:219,y:576,t:1527272194502};\\\", \\\"{x:209,y:572,t:1527272194518};\\\", \\\"{x:201,y:569,t:1527272194535};\\\", \\\"{x:197,y:566,t:1527272194552};\\\", \\\"{x:191,y:564,t:1527272194568};\\\", \\\"{x:187,y:562,t:1527272194586};\\\", \\\"{x:182,y:559,t:1527272194601};\\\", \\\"{x:181,y:559,t:1527272194682};\\\", \\\"{x:179,y:557,t:1527272194714};\\\", \\\"{x:176,y:557,t:1527272194723};\\\", \\\"{x:175,y:556,t:1527272194735};\\\", \\\"{x:172,y:555,t:1527272194753};\\\", \\\"{x:168,y:553,t:1527272194769};\\\", \\\"{x:164,y:550,t:1527272194785};\\\", \\\"{x:163,y:549,t:1527272194802};\\\", \\\"{x:164,y:550,t:1527272195528};\\\", \\\"{x:168,y:550,t:1527272195540};\\\", \\\"{x:185,y:557,t:1527272195558};\\\", \\\"{x:214,y:566,t:1527272195574};\\\", \\\"{x:258,y:577,t:1527272195589};\\\", \\\"{x:363,y:607,t:1527272195608};\\\", \\\"{x:440,y:628,t:1527272195623};\\\", \\\"{x:513,y:649,t:1527272195641};\\\", \\\"{x:579,y:667,t:1527272195657};\\\", \\\"{x:663,y:691,t:1527272195673};\\\", \\\"{x:737,y:707,t:1527272195690};\\\", \\\"{x:790,y:717,t:1527272195707};\\\", \\\"{x:822,y:722,t:1527272195723};\\\", \\\"{x:841,y:725,t:1527272195740};\\\", \\\"{x:853,y:728,t:1527272195757};\\\", \\\"{x:863,y:728,t:1527272195773};\\\", \\\"{x:878,y:732,t:1527272195790};\\\", \\\"{x:921,y:742,t:1527272195807};\\\", \\\"{x:968,y:756,t:1527272195824};\\\", \\\"{x:1017,y:765,t:1527272195841};\\\", \\\"{x:1069,y:776,t:1527272195858};\\\", \\\"{x:1135,y:784,t:1527272195874};\\\", \\\"{x:1196,y:793,t:1527272195890};\\\", \\\"{x:1230,y:799,t:1527272195908};\\\", \\\"{x:1252,y:801,t:1527272195924};\\\", \\\"{x:1265,y:804,t:1527272195941};\\\", \\\"{x:1269,y:805,t:1527272195958};\\\", \\\"{x:1270,y:805,t:1527272195975};\\\", \\\"{x:1271,y:805,t:1527272195991};\\\", \\\"{x:1276,y:805,t:1527272196008};\\\", \\\"{x:1281,y:808,t:1527272196024};\\\", \\\"{x:1284,y:817,t:1527272196041};\\\", \\\"{x:1284,y:823,t:1527272196057};\\\", \\\"{x:1283,y:823,t:1527272196512};\\\", \\\"{x:1283,y:821,t:1527272196524};\\\", \\\"{x:1286,y:816,t:1527272196541};\\\", \\\"{x:1290,y:811,t:1527272196559};\\\", \\\"{x:1294,y:807,t:1527272196575};\\\", \\\"{x:1301,y:800,t:1527272196592};\\\", \\\"{x:1306,y:797,t:1527272196608};\\\", \\\"{x:1308,y:796,t:1527272196625};\\\", \\\"{x:1309,y:793,t:1527272196642};\\\", \\\"{x:1309,y:792,t:1527272196658};\\\", \\\"{x:1312,y:788,t:1527272196675};\\\", \\\"{x:1317,y:784,t:1527272196692};\\\", \\\"{x:1322,y:780,t:1527272196708};\\\", \\\"{x:1327,y:777,t:1527272196724};\\\", \\\"{x:1330,y:774,t:1527272196742};\\\", \\\"{x:1331,y:773,t:1527272196759};\\\", \\\"{x:1336,y:768,t:1527272196776};\\\", \\\"{x:1339,y:766,t:1527272196792};\\\", \\\"{x:1344,y:764,t:1527272196809};\\\", \\\"{x:1346,y:763,t:1527272196828};\\\", \\\"{x:1348,y:762,t:1527272196841};\\\", \\\"{x:1349,y:762,t:1527272198920};\\\", \\\"{x:1348,y:763,t:1527272198968};\\\", \\\"{x:1348,y:764,t:1527272198999};\\\", \\\"{x:1347,y:765,t:1527272199015};\\\", \\\"{x:1346,y:766,t:1527272199048};\\\", \\\"{x:1345,y:767,t:1527272199061};\\\", \\\"{x:1342,y:769,t:1527272199078};\\\", \\\"{x:1338,y:772,t:1527272199095};\\\", \\\"{x:1330,y:776,t:1527272199111};\\\", \\\"{x:1314,y:779,t:1527272199127};\\\", \\\"{x:1302,y:782,t:1527272199145};\\\", \\\"{x:1284,y:782,t:1527272199162};\\\", \\\"{x:1267,y:782,t:1527272199178};\\\", \\\"{x:1249,y:782,t:1527272199195};\\\", \\\"{x:1224,y:782,t:1527272199211};\\\", \\\"{x:1199,y:782,t:1527272199227};\\\", \\\"{x:1177,y:782,t:1527272199244};\\\", \\\"{x:1160,y:782,t:1527272199262};\\\", \\\"{x:1147,y:782,t:1527272199278};\\\", \\\"{x:1143,y:782,t:1527272199295};\\\", \\\"{x:1142,y:782,t:1527272199312};\\\", \\\"{x:1142,y:781,t:1527272199376};\\\", \\\"{x:1142,y:779,t:1527272199424};\\\", \\\"{x:1142,y:778,t:1527272199432};\\\", \\\"{x:1142,y:777,t:1527272199703};\\\", \\\"{x:1143,y:781,t:1527272199712};\\\", \\\"{x:1149,y:793,t:1527272199729};\\\", \\\"{x:1152,y:800,t:1527272199746};\\\", \\\"{x:1155,y:807,t:1527272199762};\\\", \\\"{x:1158,y:815,t:1527272199779};\\\", \\\"{x:1162,y:821,t:1527272199795};\\\", \\\"{x:1166,y:827,t:1527272199811};\\\", \\\"{x:1170,y:833,t:1527272199829};\\\", \\\"{x:1174,y:841,t:1527272199846};\\\", \\\"{x:1178,y:848,t:1527272199861};\\\", \\\"{x:1180,y:853,t:1527272199878};\\\", \\\"{x:1181,y:854,t:1527272199896};\\\", \\\"{x:1182,y:854,t:1527272200008};\\\", \\\"{x:1182,y:853,t:1527272200016};\\\", \\\"{x:1182,y:849,t:1527272200029};\\\", \\\"{x:1182,y:841,t:1527272200046};\\\", \\\"{x:1182,y:834,t:1527272200063};\\\", \\\"{x:1184,y:829,t:1527272200078};\\\", \\\"{x:1186,y:817,t:1527272200095};\\\", \\\"{x:1186,y:811,t:1527272200113};\\\", \\\"{x:1186,y:806,t:1527272200129};\\\", \\\"{x:1187,y:802,t:1527272200145};\\\", \\\"{x:1188,y:797,t:1527272200163};\\\", \\\"{x:1190,y:790,t:1527272200178};\\\", \\\"{x:1191,y:785,t:1527272200195};\\\", \\\"{x:1192,y:777,t:1527272200212};\\\", \\\"{x:1192,y:770,t:1527272200229};\\\", \\\"{x:1192,y:766,t:1527272200246};\\\", \\\"{x:1193,y:760,t:1527272200262};\\\", \\\"{x:1194,y:754,t:1527272200279};\\\", \\\"{x:1196,y:748,t:1527272200296};\\\", \\\"{x:1198,y:744,t:1527272200313};\\\", \\\"{x:1203,y:739,t:1527272200330};\\\", \\\"{x:1205,y:736,t:1527272200346};\\\", \\\"{x:1208,y:733,t:1527272200363};\\\", \\\"{x:1212,y:727,t:1527272200379};\\\", \\\"{x:1216,y:721,t:1527272200396};\\\", \\\"{x:1221,y:715,t:1527272200413};\\\", \\\"{x:1228,y:705,t:1527272200430};\\\", \\\"{x:1235,y:691,t:1527272200446};\\\", \\\"{x:1243,y:672,t:1527272200463};\\\", \\\"{x:1248,y:652,t:1527272200479};\\\", \\\"{x:1251,y:638,t:1527272200495};\\\", \\\"{x:1251,y:628,t:1527272200513};\\\", \\\"{x:1252,y:618,t:1527272200530};\\\", \\\"{x:1253,y:613,t:1527272200546};\\\", \\\"{x:1256,y:607,t:1527272200563};\\\", \\\"{x:1257,y:601,t:1527272200580};\\\", \\\"{x:1257,y:594,t:1527272200596};\\\", \\\"{x:1257,y:588,t:1527272200612};\\\", \\\"{x:1257,y:587,t:1527272200629};\\\", \\\"{x:1257,y:584,t:1527272200647};\\\", \\\"{x:1258,y:581,t:1527272200663};\\\", \\\"{x:1260,y:577,t:1527272200680};\\\", \\\"{x:1260,y:575,t:1527272200697};\\\", \\\"{x:1260,y:574,t:1527272200713};\\\", \\\"{x:1260,y:573,t:1527272200730};\\\", \\\"{x:1260,y:572,t:1527272200747};\\\", \\\"{x:1260,y:571,t:1527272200763};\\\", \\\"{x:1260,y:569,t:1527272200779};\\\", \\\"{x:1260,y:567,t:1527272200797};\\\", \\\"{x:1260,y:566,t:1527272200812};\\\", \\\"{x:1260,y:565,t:1527272200830};\\\", \\\"{x:1261,y:563,t:1527272200864};\\\", \\\"{x:1262,y:563,t:1527272200880};\\\", \\\"{x:1263,y:562,t:1527272200897};\\\", \\\"{x:1265,y:561,t:1527272200919};\\\", \\\"{x:1266,y:561,t:1527272200930};\\\", \\\"{x:1266,y:560,t:1527272200947};\\\", \\\"{x:1268,y:560,t:1527272200992};\\\", \\\"{x:1270,y:559,t:1527272201016};\\\", \\\"{x:1270,y:561,t:1527272201176};\\\", \\\"{x:1270,y:563,t:1527272201183};\\\", \\\"{x:1273,y:566,t:1527272201198};\\\", \\\"{x:1276,y:576,t:1527272201213};\\\", \\\"{x:1279,y:586,t:1527272201230};\\\", \\\"{x:1284,y:595,t:1527272201247};\\\", \\\"{x:1291,y:610,t:1527272201263};\\\", \\\"{x:1294,y:623,t:1527272201281};\\\", \\\"{x:1298,y:635,t:1527272201297};\\\", \\\"{x:1302,y:648,t:1527272201314};\\\", \\\"{x:1304,y:658,t:1527272201331};\\\", \\\"{x:1304,y:667,t:1527272201347};\\\", \\\"{x:1305,y:674,t:1527272201363};\\\", \\\"{x:1308,y:683,t:1527272201381};\\\", \\\"{x:1310,y:688,t:1527272201397};\\\", \\\"{x:1310,y:690,t:1527272201414};\\\", \\\"{x:1310,y:693,t:1527272201431};\\\", \\\"{x:1310,y:695,t:1527272201447};\\\", \\\"{x:1310,y:698,t:1527272201463};\\\", \\\"{x:1312,y:698,t:1527272202463};\\\", \\\"{x:1322,y:693,t:1527272202481};\\\", \\\"{x:1333,y:687,t:1527272202498};\\\", \\\"{x:1345,y:681,t:1527272202515};\\\", \\\"{x:1351,y:677,t:1527272202532};\\\", \\\"{x:1357,y:672,t:1527272202549};\\\", \\\"{x:1362,y:666,t:1527272202564};\\\", \\\"{x:1371,y:658,t:1527272202581};\\\", \\\"{x:1379,y:650,t:1527272202598};\\\", \\\"{x:1389,y:644,t:1527272202614};\\\", \\\"{x:1403,y:632,t:1527272202631};\\\", \\\"{x:1412,y:625,t:1527272202648};\\\", \\\"{x:1416,y:620,t:1527272202664};\\\", \\\"{x:1422,y:611,t:1527272202682};\\\", \\\"{x:1425,y:601,t:1527272202699};\\\", \\\"{x:1429,y:586,t:1527272202715};\\\", \\\"{x:1435,y:578,t:1527272202731};\\\", \\\"{x:1443,y:572,t:1527272202749};\\\", \\\"{x:1446,y:566,t:1527272202766};\\\", \\\"{x:1447,y:559,t:1527272202782};\\\", \\\"{x:1450,y:553,t:1527272202798};\\\", \\\"{x:1449,y:542,t:1527272202815};\\\", \\\"{x:1445,y:536,t:1527272202831};\\\", \\\"{x:1443,y:534,t:1527272203296};\\\", \\\"{x:1441,y:532,t:1527272203304};\\\", \\\"{x:1438,y:528,t:1527272203316};\\\", \\\"{x:1425,y:522,t:1527272203333};\\\", \\\"{x:1406,y:519,t:1527272203350};\\\", \\\"{x:1380,y:519,t:1527272203365};\\\", \\\"{x:1346,y:519,t:1527272203383};\\\", \\\"{x:1232,y:519,t:1527272203399};\\\", \\\"{x:1121,y:530,t:1527272203416};\\\", \\\"{x:989,y:543,t:1527272203433};\\\", \\\"{x:853,y:545,t:1527272203451};\\\", \\\"{x:762,y:556,t:1527272203466};\\\", \\\"{x:725,y:563,t:1527272203482};\\\", \\\"{x:675,y:564,t:1527272203514};\\\", \\\"{x:656,y:560,t:1527272203531};\\\", \\\"{x:653,y:560,t:1527272203546};\\\", \\\"{x:653,y:559,t:1527272203574};\\\", \\\"{x:647,y:558,t:1527272203615};\\\", \\\"{x:633,y:570,t:1527272203630};\\\", \\\"{x:575,y:647,t:1527272203647};\\\", \\\"{x:557,y:679,t:1527272203663};\\\", \\\"{x:543,y:697,t:1527272203679};\\\", \\\"{x:530,y:710,t:1527272203696};\\\", \\\"{x:519,y:716,t:1527272203714};\\\", \\\"{x:510,y:720,t:1527272203730};\\\", \\\"{x:508,y:722,t:1527272203746};\\\", \\\"{x:507,y:726,t:1527272203763};\\\", \\\"{x:507,y:728,t:1527272203781};\\\", \\\"{x:507,y:731,t:1527272203797};\\\", \\\"{x:508,y:731,t:1527272203936};\\\", \\\"{x:509,y:731,t:1527272203982};\\\", \\\"{x:509,y:731,t:1527272204067};\\\" ] }, { \\\"rt\\\": 54777, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 1205116, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-01 PM-03 PM-I -J -J -J -J -J -B -F -B -F -F -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:732,t:1527272210936};\\\", \\\"{x:509,y:735,t:1527272210952};\\\", \\\"{x:511,y:738,t:1527272210969};\\\", \\\"{x:511,y:741,t:1527272210985};\\\", \\\"{x:519,y:755,t:1527272211003};\\\", \\\"{x:543,y:770,t:1527272211019};\\\", \\\"{x:580,y:791,t:1527272211036};\\\", \\\"{x:633,y:814,t:1527272211052};\\\", \\\"{x:682,y:833,t:1527272211069};\\\", \\\"{x:731,y:854,t:1527272211085};\\\", \\\"{x:771,y:874,t:1527272211102};\\\", \\\"{x:775,y:880,t:1527272211119};\\\", \\\"{x:775,y:881,t:1527272211607};\\\", \\\"{x:776,y:881,t:1527272211647};\\\", \\\"{x:778,y:881,t:1527272211663};\\\", \\\"{x:779,y:881,t:1527272211679};\\\", \\\"{x:781,y:881,t:1527272211695};\\\", \\\"{x:782,y:881,t:1527272211703};\\\", \\\"{x:786,y:880,t:1527272211720};\\\", \\\"{x:798,y:880,t:1527272211737};\\\", \\\"{x:819,y:882,t:1527272211753};\\\", \\\"{x:852,y:886,t:1527272211770};\\\", \\\"{x:885,y:890,t:1527272211787};\\\", \\\"{x:931,y:897,t:1527272211803};\\\", \\\"{x:996,y:909,t:1527272211820};\\\", \\\"{x:1053,y:919,t:1527272211837};\\\", \\\"{x:1122,y:928,t:1527272211853};\\\", \\\"{x:1175,y:935,t:1527272211870};\\\", \\\"{x:1244,y:945,t:1527272211887};\\\", \\\"{x:1276,y:952,t:1527272211903};\\\", \\\"{x:1300,y:957,t:1527272211921};\\\", \\\"{x:1312,y:964,t:1527272211937};\\\", \\\"{x:1329,y:972,t:1527272211954};\\\", \\\"{x:1335,y:979,t:1527272211970};\\\", \\\"{x:1338,y:979,t:1527272212984};\\\", \\\"{x:1342,y:979,t:1527272212992};\\\", \\\"{x:1348,y:980,t:1527272213004};\\\", \\\"{x:1363,y:983,t:1527272213021};\\\", \\\"{x:1378,y:983,t:1527272213039};\\\", \\\"{x:1387,y:983,t:1527272213054};\\\", \\\"{x:1391,y:983,t:1527272213071};\\\", \\\"{x:1393,y:983,t:1527272213136};\\\", \\\"{x:1396,y:983,t:1527272213143};\\\", \\\"{x:1405,y:983,t:1527272213154};\\\", \\\"{x:1431,y:985,t:1527272213171};\\\", \\\"{x:1471,y:989,t:1527272213188};\\\", \\\"{x:1499,y:997,t:1527272213204};\\\", \\\"{x:1528,y:1001,t:1527272213221};\\\", \\\"{x:1554,y:1003,t:1527272213239};\\\", \\\"{x:1571,y:1003,t:1527272213254};\\\", \\\"{x:1576,y:1003,t:1527272213272};\\\", \\\"{x:1577,y:1003,t:1527272213608};\\\", \\\"{x:1577,y:1001,t:1527272214975};\\\", \\\"{x:1577,y:1000,t:1527272214989};\\\", \\\"{x:1575,y:996,t:1527272215006};\\\", \\\"{x:1570,y:993,t:1527272215022};\\\", \\\"{x:1565,y:989,t:1527272215039};\\\", \\\"{x:1561,y:987,t:1527272215055};\\\", \\\"{x:1558,y:984,t:1527272215073};\\\", \\\"{x:1554,y:982,t:1527272215089};\\\", \\\"{x:1548,y:980,t:1527272215106};\\\", \\\"{x:1544,y:977,t:1527272215121};\\\", \\\"{x:1541,y:975,t:1527272215463};\\\", \\\"{x:1538,y:974,t:1527272215474};\\\", \\\"{x:1537,y:974,t:1527272215489};\\\", \\\"{x:1535,y:974,t:1527272215576};\\\", \\\"{x:1534,y:974,t:1527272215591};\\\", \\\"{x:1533,y:974,t:1527272215607};\\\", \\\"{x:1530,y:974,t:1527272215623};\\\", \\\"{x:1528,y:974,t:1527272215639};\\\", \\\"{x:1526,y:974,t:1527272215657};\\\", \\\"{x:1525,y:974,t:1527272215712};\\\", \\\"{x:1523,y:974,t:1527272215735};\\\", \\\"{x:1522,y:974,t:1527272215744};\\\", \\\"{x:1521,y:974,t:1527272215759};\\\", \\\"{x:1519,y:973,t:1527272215815};\\\", \\\"{x:1518,y:973,t:1527272215831};\\\", \\\"{x:1516,y:973,t:1527272215847};\\\", \\\"{x:1514,y:973,t:1527272215856};\\\", \\\"{x:1508,y:970,t:1527272215873};\\\", \\\"{x:1506,y:969,t:1527272215890};\\\", \\\"{x:1505,y:969,t:1527272215907};\\\", \\\"{x:1504,y:969,t:1527272215927};\\\", \\\"{x:1502,y:969,t:1527272215983};\\\", \\\"{x:1501,y:968,t:1527272216103};\\\", \\\"{x:1499,y:967,t:1527272216439};\\\", \\\"{x:1499,y:966,t:1527272216457};\\\", \\\"{x:1498,y:966,t:1527272216473};\\\", \\\"{x:1496,y:965,t:1527272216490};\\\", \\\"{x:1496,y:963,t:1527272225648};\\\", \\\"{x:1487,y:951,t:1527272225664};\\\", \\\"{x:1481,y:945,t:1527272225681};\\\", \\\"{x:1466,y:939,t:1527272225697};\\\", \\\"{x:1442,y:928,t:1527272225714};\\\", \\\"{x:1417,y:918,t:1527272225731};\\\", \\\"{x:1398,y:912,t:1527272225747};\\\", \\\"{x:1380,y:907,t:1527272225764};\\\", \\\"{x:1361,y:903,t:1527272225781};\\\", \\\"{x:1351,y:899,t:1527272225796};\\\", \\\"{x:1346,y:897,t:1527272225814};\\\", \\\"{x:1334,y:891,t:1527272225831};\\\", \\\"{x:1322,y:886,t:1527272225847};\\\", \\\"{x:1310,y:879,t:1527272225863};\\\", \\\"{x:1302,y:874,t:1527272225880};\\\", \\\"{x:1293,y:867,t:1527272225898};\\\", \\\"{x:1286,y:862,t:1527272225914};\\\", \\\"{x:1280,y:857,t:1527272225931};\\\", \\\"{x:1274,y:846,t:1527272225948};\\\", \\\"{x:1264,y:834,t:1527272225964};\\\", \\\"{x:1250,y:820,t:1527272225981};\\\", \\\"{x:1240,y:812,t:1527272225998};\\\", \\\"{x:1237,y:809,t:1527272226014};\\\", \\\"{x:1235,y:808,t:1527272226031};\\\", \\\"{x:1234,y:806,t:1527272226047};\\\", \\\"{x:1233,y:806,t:1527272226064};\\\", \\\"{x:1232,y:804,t:1527272226081};\\\", \\\"{x:1230,y:803,t:1527272226097};\\\", \\\"{x:1230,y:802,t:1527272226113};\\\", \\\"{x:1228,y:800,t:1527272226130};\\\", \\\"{x:1227,y:798,t:1527272226147};\\\", \\\"{x:1224,y:796,t:1527272226163};\\\", \\\"{x:1223,y:794,t:1527272226180};\\\", \\\"{x:1222,y:793,t:1527272226197};\\\", \\\"{x:1221,y:791,t:1527272226213};\\\", \\\"{x:1219,y:790,t:1527272226231};\\\", \\\"{x:1218,y:788,t:1527272226247};\\\", \\\"{x:1217,y:785,t:1527272226264};\\\", \\\"{x:1216,y:783,t:1527272226280};\\\", \\\"{x:1214,y:781,t:1527272226297};\\\", \\\"{x:1211,y:778,t:1527272226314};\\\", \\\"{x:1210,y:776,t:1527272226330};\\\", \\\"{x:1208,y:775,t:1527272226347};\\\", \\\"{x:1207,y:774,t:1527272226364};\\\", \\\"{x:1206,y:774,t:1527272226380};\\\", \\\"{x:1204,y:772,t:1527272226397};\\\", \\\"{x:1202,y:770,t:1527272226414};\\\", \\\"{x:1201,y:769,t:1527272226430};\\\", \\\"{x:1200,y:767,t:1527272226448};\\\", \\\"{x:1198,y:767,t:1527272226465};\\\", \\\"{x:1195,y:767,t:1527272226480};\\\", \\\"{x:1193,y:765,t:1527272226497};\\\", \\\"{x:1192,y:765,t:1527272226514};\\\", \\\"{x:1191,y:764,t:1527272226531};\\\", \\\"{x:1190,y:764,t:1527272226576};\\\", \\\"{x:1189,y:764,t:1527272226583};\\\", \\\"{x:1188,y:764,t:1527272226679};\\\", \\\"{x:1187,y:764,t:1527272226698};\\\", \\\"{x:1185,y:762,t:1527272226717};\\\", \\\"{x:1183,y:762,t:1527272226747};\\\", \\\"{x:1182,y:762,t:1527272226766};\\\", \\\"{x:1181,y:762,t:1527272227623};\\\", \\\"{x:1181,y:764,t:1527272227631};\\\", \\\"{x:1184,y:772,t:1527272227650};\\\", \\\"{x:1185,y:776,t:1527272227665};\\\", \\\"{x:1187,y:780,t:1527272227682};\\\", \\\"{x:1187,y:781,t:1527272227699};\\\", \\\"{x:1187,y:782,t:1527272227716};\\\", \\\"{x:1187,y:783,t:1527272227732};\\\", \\\"{x:1187,y:784,t:1527272227749};\\\", \\\"{x:1188,y:786,t:1527272227766};\\\", \\\"{x:1188,y:789,t:1527272227782};\\\", \\\"{x:1190,y:794,t:1527272227798};\\\", \\\"{x:1191,y:797,t:1527272227814};\\\", \\\"{x:1192,y:799,t:1527272227832};\\\", \\\"{x:1195,y:802,t:1527272227849};\\\", \\\"{x:1195,y:805,t:1527272227866};\\\", \\\"{x:1197,y:809,t:1527272227881};\\\", \\\"{x:1198,y:811,t:1527272227898};\\\", \\\"{x:1199,y:812,t:1527272227916};\\\", \\\"{x:1199,y:815,t:1527272227932};\\\", \\\"{x:1201,y:818,t:1527272227948};\\\", \\\"{x:1202,y:819,t:1527272227967};\\\", \\\"{x:1202,y:820,t:1527272227982};\\\", \\\"{x:1202,y:821,t:1527272227998};\\\", \\\"{x:1203,y:822,t:1527272228022};\\\", \\\"{x:1204,y:825,t:1527272228039};\\\", \\\"{x:1205,y:826,t:1527272228049};\\\", \\\"{x:1206,y:828,t:1527272228066};\\\", \\\"{x:1207,y:830,t:1527272228086};\\\", \\\"{x:1208,y:830,t:1527272228102};\\\", \\\"{x:1209,y:832,t:1527272228134};\\\", \\\"{x:1210,y:833,t:1527272228174};\\\", \\\"{x:1211,y:833,t:1527272228207};\\\", \\\"{x:1212,y:834,t:1527272228319};\\\", \\\"{x:1214,y:834,t:1527272228333};\\\", \\\"{x:1215,y:834,t:1527272228415};\\\", \\\"{x:1216,y:835,t:1527272228728};\\\", \\\"{x:1216,y:842,t:1527272228736};\\\", \\\"{x:1216,y:844,t:1527272228750};\\\", \\\"{x:1216,y:850,t:1527272228766};\\\", \\\"{x:1214,y:854,t:1527272228783};\\\", \\\"{x:1214,y:858,t:1527272228799};\\\", \\\"{x:1214,y:861,t:1527272228816};\\\", \\\"{x:1213,y:865,t:1527272228833};\\\", \\\"{x:1212,y:873,t:1527272228850};\\\", \\\"{x:1212,y:881,t:1527272228866};\\\", \\\"{x:1212,y:887,t:1527272228883};\\\", \\\"{x:1212,y:893,t:1527272228899};\\\", \\\"{x:1212,y:900,t:1527272228916};\\\", \\\"{x:1212,y:907,t:1527272228932};\\\", \\\"{x:1212,y:915,t:1527272228950};\\\", \\\"{x:1215,y:923,t:1527272228966};\\\", \\\"{x:1215,y:931,t:1527272228983};\\\", \\\"{x:1216,y:937,t:1527272228999};\\\", \\\"{x:1218,y:942,t:1527272229015};\\\", \\\"{x:1218,y:944,t:1527272229032};\\\", \\\"{x:1218,y:946,t:1527272229050};\\\", \\\"{x:1218,y:947,t:1527272229066};\\\", \\\"{x:1218,y:945,t:1527272229647};\\\", \\\"{x:1218,y:941,t:1527272229655};\\\", \\\"{x:1218,y:936,t:1527272229667};\\\", \\\"{x:1218,y:929,t:1527272229684};\\\", \\\"{x:1217,y:919,t:1527272229699};\\\", \\\"{x:1214,y:909,t:1527272229716};\\\", \\\"{x:1213,y:896,t:1527272229734};\\\", \\\"{x:1211,y:883,t:1527272229750};\\\", \\\"{x:1211,y:861,t:1527272229767};\\\", \\\"{x:1211,y:850,t:1527272229783};\\\", \\\"{x:1211,y:843,t:1527272229800};\\\", \\\"{x:1211,y:837,t:1527272229816};\\\", \\\"{x:1211,y:832,t:1527272229834};\\\", \\\"{x:1211,y:828,t:1527272229849};\\\", \\\"{x:1211,y:827,t:1527272229866};\\\", \\\"{x:1213,y:823,t:1527272229885};\\\", \\\"{x:1214,y:821,t:1527272229899};\\\", \\\"{x:1216,y:819,t:1527272229917};\\\", \\\"{x:1217,y:819,t:1527272229934};\\\", \\\"{x:1217,y:818,t:1527272229949};\\\", \\\"{x:1216,y:818,t:1527272230167};\\\", \\\"{x:1212,y:818,t:1527272230184};\\\", \\\"{x:1209,y:820,t:1527272230202};\\\", \\\"{x:1207,y:821,t:1527272230218};\\\", \\\"{x:1205,y:822,t:1527272230234};\\\", \\\"{x:1204,y:823,t:1527272230251};\\\", \\\"{x:1203,y:824,t:1527272230343};\\\", \\\"{x:1203,y:825,t:1527272230359};\\\", \\\"{x:1202,y:825,t:1527272230375};\\\", \\\"{x:1206,y:825,t:1527272230792};\\\", \\\"{x:1213,y:825,t:1527272230801};\\\", \\\"{x:1220,y:826,t:1527272230819};\\\", \\\"{x:1224,y:827,t:1527272230834};\\\", \\\"{x:1224,y:828,t:1527272230851};\\\", \\\"{x:1225,y:828,t:1527272230868};\\\", \\\"{x:1227,y:829,t:1527272230884};\\\", \\\"{x:1231,y:834,t:1527272230901};\\\", \\\"{x:1241,y:844,t:1527272230918};\\\", \\\"{x:1256,y:855,t:1527272230934};\\\", \\\"{x:1272,y:867,t:1527272230950};\\\", \\\"{x:1289,y:877,t:1527272230968};\\\", \\\"{x:1306,y:886,t:1527272230984};\\\", \\\"{x:1316,y:895,t:1527272231001};\\\", \\\"{x:1324,y:903,t:1527272231018};\\\", \\\"{x:1336,y:910,t:1527272231035};\\\", \\\"{x:1342,y:917,t:1527272231051};\\\", \\\"{x:1354,y:925,t:1527272231068};\\\", \\\"{x:1363,y:933,t:1527272231085};\\\", \\\"{x:1370,y:941,t:1527272231101};\\\", \\\"{x:1374,y:946,t:1527272231118};\\\", \\\"{x:1380,y:950,t:1527272231135};\\\", \\\"{x:1383,y:953,t:1527272231151};\\\", \\\"{x:1386,y:954,t:1527272231168};\\\", \\\"{x:1387,y:956,t:1527272231255};\\\", \\\"{x:1388,y:957,t:1527272231267};\\\", \\\"{x:1388,y:958,t:1527272231391};\\\", \\\"{x:1388,y:959,t:1527272231415};\\\", \\\"{x:1388,y:960,t:1527272231423};\\\", \\\"{x:1388,y:961,t:1527272231455};\\\", \\\"{x:1388,y:962,t:1527272231470};\\\", \\\"{x:1388,y:963,t:1527272231495};\\\", \\\"{x:1387,y:964,t:1527272231502};\\\", \\\"{x:1386,y:965,t:1527272231527};\\\", \\\"{x:1386,y:966,t:1527272231632};\\\", \\\"{x:1386,y:965,t:1527272233136};\\\", \\\"{x:1386,y:962,t:1527272233153};\\\", \\\"{x:1386,y:960,t:1527272233169};\\\", \\\"{x:1386,y:959,t:1527272233190};\\\", \\\"{x:1388,y:958,t:1527272233223};\\\", \\\"{x:1389,y:957,t:1527272233239};\\\", \\\"{x:1390,y:957,t:1527272233255};\\\", \\\"{x:1390,y:956,t:1527272233269};\\\", \\\"{x:1391,y:954,t:1527272233286};\\\", \\\"{x:1391,y:953,t:1527272233303};\\\", \\\"{x:1392,y:953,t:1527272233319};\\\", \\\"{x:1393,y:951,t:1527272233336};\\\", \\\"{x:1393,y:949,t:1527272233353};\\\", \\\"{x:1393,y:947,t:1527272233369};\\\", \\\"{x:1393,y:946,t:1527272233386};\\\", \\\"{x:1394,y:945,t:1527272233403};\\\", \\\"{x:1394,y:944,t:1527272233420};\\\", \\\"{x:1394,y:943,t:1527272233436};\\\", \\\"{x:1394,y:939,t:1527272233453};\\\", \\\"{x:1394,y:936,t:1527272233470};\\\", \\\"{x:1394,y:930,t:1527272233486};\\\", \\\"{x:1394,y:925,t:1527272233502};\\\", \\\"{x:1394,y:921,t:1527272233520};\\\", \\\"{x:1394,y:916,t:1527272233536};\\\", \\\"{x:1395,y:911,t:1527272233553};\\\", \\\"{x:1395,y:905,t:1527272233570};\\\", \\\"{x:1395,y:900,t:1527272233586};\\\", \\\"{x:1395,y:896,t:1527272233603};\\\", \\\"{x:1395,y:891,t:1527272233621};\\\", \\\"{x:1395,y:889,t:1527272233636};\\\", \\\"{x:1395,y:887,t:1527272233653};\\\", \\\"{x:1395,y:885,t:1527272233670};\\\", \\\"{x:1395,y:883,t:1527272233686};\\\", \\\"{x:1395,y:882,t:1527272233703};\\\", \\\"{x:1395,y:881,t:1527272233720};\\\", \\\"{x:1395,y:880,t:1527272233736};\\\", \\\"{x:1395,y:879,t:1527272233759};\\\", \\\"{x:1395,y:877,t:1527272233770};\\\", \\\"{x:1395,y:875,t:1527272233786};\\\", \\\"{x:1395,y:870,t:1527272233804};\\\", \\\"{x:1395,y:868,t:1527272233821};\\\", \\\"{x:1395,y:863,t:1527272233836};\\\", \\\"{x:1394,y:860,t:1527272233853};\\\", \\\"{x:1392,y:855,t:1527272233871};\\\", \\\"{x:1389,y:847,t:1527272233887};\\\", \\\"{x:1387,y:841,t:1527272233903};\\\", \\\"{x:1386,y:836,t:1527272233920};\\\", \\\"{x:1385,y:831,t:1527272233937};\\\", \\\"{x:1382,y:821,t:1527272233953};\\\", \\\"{x:1379,y:812,t:1527272233970};\\\", \\\"{x:1375,y:804,t:1527272233987};\\\", \\\"{x:1373,y:798,t:1527272234003};\\\", \\\"{x:1373,y:796,t:1527272234020};\\\", \\\"{x:1373,y:795,t:1527272234037};\\\", \\\"{x:1373,y:793,t:1527272234052};\\\", \\\"{x:1374,y:791,t:1527272234069};\\\", \\\"{x:1375,y:790,t:1527272234087};\\\", \\\"{x:1375,y:787,t:1527272234102};\\\", \\\"{x:1376,y:784,t:1527272234119};\\\", \\\"{x:1376,y:781,t:1527272234137};\\\", \\\"{x:1376,y:777,t:1527272234152};\\\", \\\"{x:1376,y:774,t:1527272234170};\\\", \\\"{x:1376,y:770,t:1527272234186};\\\", \\\"{x:1376,y:768,t:1527272234203};\\\", \\\"{x:1376,y:767,t:1527272234220};\\\", \\\"{x:1376,y:766,t:1527272234255};\\\", \\\"{x:1376,y:765,t:1527272234270};\\\", \\\"{x:1376,y:763,t:1527272234286};\\\", \\\"{x:1375,y:762,t:1527272234303};\\\", \\\"{x:1374,y:762,t:1527272234343};\\\", \\\"{x:1373,y:762,t:1527272234353};\\\", \\\"{x:1371,y:762,t:1527272234370};\\\", \\\"{x:1367,y:762,t:1527272234387};\\\", \\\"{x:1362,y:764,t:1527272234404};\\\", \\\"{x:1358,y:766,t:1527272234420};\\\", \\\"{x:1357,y:767,t:1527272234437};\\\", \\\"{x:1355,y:776,t:1527272234455};\\\", \\\"{x:1355,y:787,t:1527272234470};\\\", \\\"{x:1355,y:805,t:1527272234487};\\\", \\\"{x:1355,y:812,t:1527272234504};\\\", \\\"{x:1356,y:823,t:1527272234520};\\\", \\\"{x:1360,y:840,t:1527272234537};\\\", \\\"{x:1364,y:855,t:1527272234554};\\\", \\\"{x:1365,y:865,t:1527272234570};\\\", \\\"{x:1366,y:867,t:1527272234587};\\\", \\\"{x:1366,y:870,t:1527272234605};\\\", \\\"{x:1366,y:877,t:1527272234620};\\\", \\\"{x:1365,y:883,t:1527272234637};\\\", \\\"{x:1363,y:891,t:1527272234654};\\\", \\\"{x:1362,y:898,t:1527272234670};\\\", \\\"{x:1362,y:908,t:1527272234686};\\\", \\\"{x:1361,y:912,t:1527272234704};\\\", \\\"{x:1360,y:917,t:1527272234720};\\\", \\\"{x:1359,y:921,t:1527272234737};\\\", \\\"{x:1359,y:925,t:1527272234754};\\\", \\\"{x:1359,y:928,t:1527272234770};\\\", \\\"{x:1356,y:933,t:1527272234787};\\\", \\\"{x:1355,y:934,t:1527272234823};\\\", \\\"{x:1355,y:937,t:1527272235047};\\\", \\\"{x:1355,y:940,t:1527272235055};\\\", \\\"{x:1357,y:943,t:1527272235071};\\\", \\\"{x:1357,y:944,t:1527272235102};\\\", \\\"{x:1357,y:946,t:1527272235118};\\\", \\\"{x:1357,y:949,t:1527272235126};\\\", \\\"{x:1357,y:950,t:1527272235136};\\\", \\\"{x:1356,y:940,t:1527272235230};\\\", \\\"{x:1354,y:928,t:1527272235237};\\\", \\\"{x:1352,y:918,t:1527272235253};\\\", \\\"{x:1350,y:891,t:1527272235270};\\\", \\\"{x:1346,y:870,t:1527272235286};\\\", \\\"{x:1344,y:856,t:1527272235303};\\\", \\\"{x:1340,y:844,t:1527272235321};\\\", \\\"{x:1339,y:837,t:1527272235337};\\\", \\\"{x:1339,y:829,t:1527272235353};\\\", \\\"{x:1338,y:828,t:1527272235374};\\\", \\\"{x:1337,y:828,t:1527272235388};\\\", \\\"{x:1337,y:825,t:1527272235404};\\\", \\\"{x:1337,y:820,t:1527272235421};\\\", \\\"{x:1337,y:815,t:1527272235438};\\\", \\\"{x:1337,y:812,t:1527272235454};\\\", \\\"{x:1337,y:809,t:1527272235470};\\\", \\\"{x:1337,y:808,t:1527272235488};\\\", \\\"{x:1337,y:805,t:1527272235504};\\\", \\\"{x:1337,y:802,t:1527272235521};\\\", \\\"{x:1337,y:800,t:1527272235538};\\\", \\\"{x:1337,y:799,t:1527272235554};\\\", \\\"{x:1336,y:798,t:1527272235571};\\\", \\\"{x:1336,y:797,t:1527272235587};\\\", \\\"{x:1336,y:795,t:1527272235604};\\\", \\\"{x:1336,y:791,t:1527272235620};\\\", \\\"{x:1336,y:788,t:1527272235638};\\\", \\\"{x:1336,y:786,t:1527272235654};\\\", \\\"{x:1336,y:783,t:1527272235671};\\\", \\\"{x:1336,y:782,t:1527272235688};\\\", \\\"{x:1336,y:780,t:1527272235704};\\\", \\\"{x:1336,y:779,t:1527272235721};\\\", \\\"{x:1336,y:777,t:1527272235738};\\\", \\\"{x:1336,y:776,t:1527272235754};\\\", \\\"{x:1334,y:775,t:1527272235771};\\\", \\\"{x:1334,y:773,t:1527272235807};\\\", \\\"{x:1335,y:771,t:1527272235823};\\\", \\\"{x:1335,y:770,t:1527272235838};\\\", \\\"{x:1335,y:766,t:1527272235855};\\\", \\\"{x:1335,y:764,t:1527272235872};\\\", \\\"{x:1335,y:763,t:1527272235927};\\\", \\\"{x:1336,y:763,t:1527272235938};\\\", \\\"{x:1337,y:762,t:1527272235955};\\\", \\\"{x:1339,y:761,t:1527272235971};\\\", \\\"{x:1340,y:761,t:1527272236031};\\\", \\\"{x:1341,y:760,t:1527272236055};\\\", \\\"{x:1342,y:760,t:1527272236158};\\\", \\\"{x:1343,y:760,t:1527272236519};\\\", \\\"{x:1343,y:765,t:1527272236538};\\\", \\\"{x:1344,y:769,t:1527272236556};\\\", \\\"{x:1345,y:776,t:1527272236572};\\\", \\\"{x:1347,y:784,t:1527272236588};\\\", \\\"{x:1349,y:798,t:1527272236605};\\\", \\\"{x:1350,y:813,t:1527272236622};\\\", \\\"{x:1353,y:825,t:1527272236638};\\\", \\\"{x:1358,y:845,t:1527272236655};\\\", \\\"{x:1365,y:864,t:1527272236672};\\\", \\\"{x:1369,y:880,t:1527272236688};\\\", \\\"{x:1374,y:897,t:1527272236705};\\\", \\\"{x:1376,y:911,t:1527272236721};\\\", \\\"{x:1378,y:923,t:1527272236738};\\\", \\\"{x:1379,y:937,t:1527272236755};\\\", \\\"{x:1380,y:952,t:1527272236772};\\\", \\\"{x:1381,y:966,t:1527272236789};\\\", \\\"{x:1383,y:977,t:1527272236805};\\\", \\\"{x:1384,y:986,t:1527272236822};\\\", \\\"{x:1385,y:996,t:1527272236837};\\\", \\\"{x:1386,y:999,t:1527272236854};\\\", \\\"{x:1386,y:1000,t:1527272236871};\\\", \\\"{x:1385,y:985,t:1527272236935};\\\", \\\"{x:1381,y:961,t:1527272236942};\\\", \\\"{x:1376,y:942,t:1527272236954};\\\", \\\"{x:1372,y:915,t:1527272236971};\\\", \\\"{x:1372,y:896,t:1527272236989};\\\", \\\"{x:1372,y:879,t:1527272237005};\\\", \\\"{x:1372,y:859,t:1527272237022};\\\", \\\"{x:1372,y:840,t:1527272237038};\\\", \\\"{x:1372,y:828,t:1527272237054};\\\", \\\"{x:1372,y:815,t:1527272237072};\\\", \\\"{x:1372,y:804,t:1527272237089};\\\", \\\"{x:1372,y:799,t:1527272237105};\\\", \\\"{x:1372,y:792,t:1527272237122};\\\", \\\"{x:1372,y:790,t:1527272237139};\\\", \\\"{x:1372,y:788,t:1527272237155};\\\", \\\"{x:1372,y:783,t:1527272237173};\\\", \\\"{x:1370,y:776,t:1527272237189};\\\", \\\"{x:1368,y:769,t:1527272237205};\\\", \\\"{x:1366,y:762,t:1527272237222};\\\", \\\"{x:1365,y:755,t:1527272237239};\\\", \\\"{x:1365,y:749,t:1527272237256};\\\", \\\"{x:1360,y:741,t:1527272237272};\\\", \\\"{x:1355,y:733,t:1527272237289};\\\", \\\"{x:1346,y:723,t:1527272237306};\\\", \\\"{x:1338,y:715,t:1527272237323};\\\", \\\"{x:1330,y:710,t:1527272237340};\\\", \\\"{x:1325,y:707,t:1527272237357};\\\", \\\"{x:1319,y:703,t:1527272237372};\\\", \\\"{x:1306,y:702,t:1527272237389};\\\", \\\"{x:1282,y:699,t:1527272237407};\\\", \\\"{x:1231,y:699,t:1527272237422};\\\", \\\"{x:1112,y:688,t:1527272237439};\\\", \\\"{x:1017,y:686,t:1527272237456};\\\", \\\"{x:956,y:686,t:1527272237472};\\\", \\\"{x:934,y:686,t:1527272237489};\\\", \\\"{x:928,y:687,t:1527272237506};\\\", \\\"{x:919,y:688,t:1527272237727};\\\", \\\"{x:914,y:688,t:1527272237739};\\\", \\\"{x:911,y:689,t:1527272237756};\\\", \\\"{x:910,y:691,t:1527272237773};\\\", \\\"{x:902,y:691,t:1527272237789};\\\", \\\"{x:846,y:685,t:1527272237806};\\\", \\\"{x:813,y:676,t:1527272237822};\\\", \\\"{x:800,y:668,t:1527272237839};\\\", \\\"{x:788,y:663,t:1527272237856};\\\", \\\"{x:782,y:659,t:1527272237873};\\\", \\\"{x:775,y:657,t:1527272237889};\\\", \\\"{x:765,y:653,t:1527272237906};\\\", \\\"{x:750,y:648,t:1527272237923};\\\", \\\"{x:735,y:643,t:1527272237941};\\\", \\\"{x:731,y:642,t:1527272237955};\\\", \\\"{x:729,y:640,t:1527272237972};\\\", \\\"{x:724,y:639,t:1527272237988};\\\", \\\"{x:719,y:638,t:1527272238006};\\\", \\\"{x:711,y:634,t:1527272238021};\\\", \\\"{x:683,y:623,t:1527272238041};\\\", \\\"{x:657,y:615,t:1527272238057};\\\", \\\"{x:633,y:608,t:1527272238075};\\\", \\\"{x:612,y:603,t:1527272238091};\\\", \\\"{x:596,y:596,t:1527272238108};\\\", \\\"{x:585,y:594,t:1527272238124};\\\", \\\"{x:568,y:588,t:1527272238141};\\\", \\\"{x:525,y:577,t:1527272238157};\\\", \\\"{x:492,y:572,t:1527272238175};\\\", \\\"{x:466,y:569,t:1527272238192};\\\", \\\"{x:438,y:567,t:1527272238208};\\\", \\\"{x:417,y:567,t:1527272238224};\\\", \\\"{x:398,y:567,t:1527272238240};\\\", \\\"{x:380,y:567,t:1527272238257};\\\", \\\"{x:364,y:567,t:1527272238275};\\\", \\\"{x:355,y:567,t:1527272238292};\\\", \\\"{x:354,y:567,t:1527272238307};\\\", \\\"{x:352,y:567,t:1527272238334};\\\", \\\"{x:350,y:567,t:1527272238350};\\\", \\\"{x:348,y:567,t:1527272238358};\\\", \\\"{x:343,y:567,t:1527272238374};\\\", \\\"{x:342,y:567,t:1527272238391};\\\", \\\"{x:340,y:567,t:1527272238408};\\\", \\\"{x:336,y:567,t:1527272238425};\\\", \\\"{x:333,y:567,t:1527272238442};\\\", \\\"{x:326,y:564,t:1527272238458};\\\", \\\"{x:314,y:562,t:1527272238475};\\\", \\\"{x:308,y:562,t:1527272238492};\\\", \\\"{x:301,y:562,t:1527272238508};\\\", \\\"{x:295,y:560,t:1527272238524};\\\", \\\"{x:291,y:560,t:1527272238542};\\\", \\\"{x:288,y:560,t:1527272238558};\\\", \\\"{x:279,y:560,t:1527272238574};\\\", \\\"{x:278,y:560,t:1527272238592};\\\", \\\"{x:279,y:561,t:1527272238686};\\\", \\\"{x:281,y:564,t:1527272238694};\\\", \\\"{x:283,y:567,t:1527272238708};\\\", \\\"{x:290,y:576,t:1527272238726};\\\", \\\"{x:298,y:586,t:1527272238744};\\\", \\\"{x:303,y:592,t:1527272238758};\\\", \\\"{x:308,y:598,t:1527272238776};\\\", \\\"{x:312,y:602,t:1527272238791};\\\", \\\"{x:324,y:610,t:1527272238809};\\\", \\\"{x:346,y:619,t:1527272238826};\\\", \\\"{x:373,y:626,t:1527272238842};\\\", \\\"{x:386,y:629,t:1527272238859};\\\", \\\"{x:389,y:629,t:1527272238876};\\\", \\\"{x:390,y:629,t:1527272238892};\\\", \\\"{x:393,y:629,t:1527272238909};\\\", \\\"{x:401,y:628,t:1527272238925};\\\", \\\"{x:419,y:624,t:1527272238942};\\\", \\\"{x:435,y:622,t:1527272238958};\\\", \\\"{x:459,y:622,t:1527272238975};\\\", \\\"{x:485,y:622,t:1527272238991};\\\", \\\"{x:507,y:619,t:1527272239009};\\\", \\\"{x:525,y:613,t:1527272239027};\\\", \\\"{x:549,y:608,t:1527272239041};\\\", \\\"{x:593,y:607,t:1527272239059};\\\", \\\"{x:649,y:607,t:1527272239076};\\\", \\\"{x:673,y:607,t:1527272239092};\\\", \\\"{x:692,y:606,t:1527272239109};\\\", \\\"{x:711,y:605,t:1527272239125};\\\", \\\"{x:715,y:605,t:1527272239141};\\\", \\\"{x:734,y:605,t:1527272239159};\\\", \\\"{x:749,y:605,t:1527272239176};\\\", \\\"{x:772,y:605,t:1527272239192};\\\", \\\"{x:801,y:605,t:1527272239208};\\\", \\\"{x:831,y:605,t:1527272239226};\\\", \\\"{x:845,y:603,t:1527272239241};\\\", \\\"{x:859,y:602,t:1527272239259};\\\", \\\"{x:877,y:602,t:1527272239277};\\\", \\\"{x:897,y:602,t:1527272239292};\\\", \\\"{x:911,y:602,t:1527272239308};\\\", \\\"{x:915,y:602,t:1527272239326};\\\", \\\"{x:915,y:600,t:1527272239358};\\\", \\\"{x:914,y:594,t:1527272239376};\\\", \\\"{x:914,y:592,t:1527272239392};\\\", \\\"{x:914,y:589,t:1527272239409};\\\", \\\"{x:913,y:587,t:1527272239425};\\\", \\\"{x:909,y:579,t:1527272239441};\\\", \\\"{x:899,y:570,t:1527272239459};\\\", \\\"{x:888,y:561,t:1527272239477};\\\", \\\"{x:886,y:559,t:1527272239492};\\\", \\\"{x:884,y:558,t:1527272239526};\\\", \\\"{x:880,y:552,t:1527272239542};\\\", \\\"{x:870,y:546,t:1527272239558};\\\", \\\"{x:866,y:542,t:1527272239576};\\\", \\\"{x:865,y:542,t:1527272239592};\\\", \\\"{x:864,y:540,t:1527272239623};\\\", \\\"{x:863,y:540,t:1527272239630};\\\", \\\"{x:862,y:539,t:1527272239643};\\\", \\\"{x:858,y:537,t:1527272239659};\\\", \\\"{x:855,y:535,t:1527272239676};\\\", \\\"{x:853,y:535,t:1527272239783};\\\", \\\"{x:851,y:533,t:1527272239793};\\\", \\\"{x:848,y:531,t:1527272239809};\\\", \\\"{x:847,y:530,t:1527272239826};\\\", \\\"{x:846,y:529,t:1527272239842};\\\", \\\"{x:842,y:528,t:1527272239859};\\\", \\\"{x:842,y:527,t:1527272239878};\\\", \\\"{x:840,y:526,t:1527272239934};\\\", \\\"{x:839,y:524,t:1527272239943};\\\", \\\"{x:837,y:522,t:1527272239959};\\\", \\\"{x:837,y:521,t:1527272239976};\\\", \\\"{x:837,y:520,t:1527272239993};\\\", \\\"{x:837,y:519,t:1527272240176};\\\", \\\"{x:840,y:520,t:1527272240254};\\\", \\\"{x:848,y:526,t:1527272240263};\\\", \\\"{x:856,y:532,t:1527272240276};\\\", \\\"{x:877,y:549,t:1527272240293};\\\", \\\"{x:913,y:572,t:1527272240310};\\\", \\\"{x:938,y:580,t:1527272240326};\\\", \\\"{x:965,y:591,t:1527272240343};\\\", \\\"{x:996,y:600,t:1527272240360};\\\", \\\"{x:1039,y:609,t:1527272240377};\\\", \\\"{x:1074,y:621,t:1527272240392};\\\", \\\"{x:1102,y:629,t:1527272240410};\\\", \\\"{x:1126,y:636,t:1527272240427};\\\", \\\"{x:1148,y:642,t:1527272240444};\\\", \\\"{x:1172,y:649,t:1527272240459};\\\", \\\"{x:1190,y:655,t:1527272240477};\\\", \\\"{x:1215,y:659,t:1527272240494};\\\", \\\"{x:1232,y:663,t:1527272240510};\\\", \\\"{x:1252,y:669,t:1527272240527};\\\", \\\"{x:1268,y:673,t:1527272240544};\\\", \\\"{x:1277,y:677,t:1527272240561};\\\", \\\"{x:1283,y:678,t:1527272240578};\\\", \\\"{x:1293,y:682,t:1527272240594};\\\", \\\"{x:1301,y:683,t:1527272240611};\\\", \\\"{x:1309,y:686,t:1527272240628};\\\", \\\"{x:1315,y:687,t:1527272240644};\\\", \\\"{x:1316,y:687,t:1527272240799};\\\", \\\"{x:1318,y:689,t:1527272240812};\\\", \\\"{x:1319,y:689,t:1527272240828};\\\", \\\"{x:1320,y:689,t:1527272240845};\\\", \\\"{x:1323,y:689,t:1527272240863};\\\", \\\"{x:1326,y:689,t:1527272240879};\\\", \\\"{x:1327,y:689,t:1527272240896};\\\", \\\"{x:1330,y:689,t:1527272240912};\\\", \\\"{x:1335,y:686,t:1527272240929};\\\", \\\"{x:1338,y:685,t:1527272240945};\\\", \\\"{x:1341,y:685,t:1527272240962};\\\", \\\"{x:1346,y:685,t:1527272240979};\\\", \\\"{x:1347,y:685,t:1527272240996};\\\", \\\"{x:1349,y:685,t:1527272241012};\\\", \\\"{x:1350,y:685,t:1527272241031};\\\", \\\"{x:1356,y:685,t:1527272241047};\\\", \\\"{x:1362,y:685,t:1527272241063};\\\", \\\"{x:1369,y:685,t:1527272241080};\\\", \\\"{x:1373,y:685,t:1527272241096};\\\", \\\"{x:1374,y:685,t:1527272241113};\\\", \\\"{x:1374,y:686,t:1527272241319};\\\", \\\"{x:1372,y:687,t:1527272241331};\\\", \\\"{x:1371,y:690,t:1527272241347};\\\", \\\"{x:1369,y:694,t:1527272241365};\\\", \\\"{x:1367,y:697,t:1527272241380};\\\", \\\"{x:1365,y:697,t:1527272241397};\\\", \\\"{x:1365,y:698,t:1527272241423};\\\", \\\"{x:1364,y:699,t:1527272241493};\\\", \\\"{x:1364,y:700,t:1527272241517};\\\", \\\"{x:1362,y:701,t:1527272241530};\\\", \\\"{x:1361,y:702,t:1527272241547};\\\", \\\"{x:1360,y:706,t:1527272241564};\\\", \\\"{x:1358,y:712,t:1527272241581};\\\", \\\"{x:1357,y:721,t:1527272241598};\\\", \\\"{x:1356,y:730,t:1527272241614};\\\", \\\"{x:1353,y:743,t:1527272241631};\\\", \\\"{x:1351,y:767,t:1527272241648};\\\", \\\"{x:1351,y:808,t:1527272241666};\\\", \\\"{x:1351,y:848,t:1527272241681};\\\", \\\"{x:1351,y:859,t:1527272241698};\\\", \\\"{x:1349,y:866,t:1527272241715};\\\", \\\"{x:1347,y:869,t:1527272241732};\\\", \\\"{x:1347,y:870,t:1527272241747};\\\", \\\"{x:1347,y:873,t:1527272241765};\\\", \\\"{x:1347,y:875,t:1527272241782};\\\", \\\"{x:1347,y:876,t:1527272241927};\\\", \\\"{x:1347,y:877,t:1527272241951};\\\", \\\"{x:1347,y:888,t:1527272241966};\\\", \\\"{x:1347,y:891,t:1527272241983};\\\", \\\"{x:1345,y:897,t:1527272241999};\\\", \\\"{x:1344,y:900,t:1527272242016};\\\", \\\"{x:1343,y:902,t:1527272242033};\\\", \\\"{x:1343,y:904,t:1527272242051};\\\", \\\"{x:1343,y:905,t:1527272242066};\\\", \\\"{x:1343,y:906,t:1527272242083};\\\", \\\"{x:1345,y:910,t:1527272242100};\\\", \\\"{x:1345,y:913,t:1527272242118};\\\", \\\"{x:1346,y:914,t:1527272242133};\\\", \\\"{x:1347,y:916,t:1527272242150};\\\", \\\"{x:1347,y:917,t:1527272242167};\\\", \\\"{x:1348,y:921,t:1527272242183};\\\", \\\"{x:1350,y:928,t:1527272242200};\\\", \\\"{x:1356,y:938,t:1527272242218};\\\", \\\"{x:1364,y:948,t:1527272242234};\\\", \\\"{x:1369,y:953,t:1527272242250};\\\", \\\"{x:1371,y:955,t:1527272242267};\\\", \\\"{x:1373,y:956,t:1527272242284};\\\", \\\"{x:1374,y:956,t:1527272242391};\\\", \\\"{x:1374,y:955,t:1527272242401};\\\", \\\"{x:1374,y:948,t:1527272242418};\\\", \\\"{x:1374,y:934,t:1527272242435};\\\", \\\"{x:1374,y:908,t:1527272242451};\\\", \\\"{x:1374,y:888,t:1527272242469};\\\", \\\"{x:1374,y:866,t:1527272242485};\\\", \\\"{x:1374,y:847,t:1527272242501};\\\", \\\"{x:1374,y:821,t:1527272242519};\\\", \\\"{x:1374,y:804,t:1527272242535};\\\", \\\"{x:1372,y:790,t:1527272242551};\\\", \\\"{x:1371,y:780,t:1527272242568};\\\", \\\"{x:1371,y:775,t:1527272242585};\\\", \\\"{x:1371,y:769,t:1527272242602};\\\", \\\"{x:1371,y:761,t:1527272242618};\\\", \\\"{x:1371,y:752,t:1527272242635};\\\", \\\"{x:1371,y:743,t:1527272242653};\\\", \\\"{x:1371,y:739,t:1527272242668};\\\", \\\"{x:1371,y:737,t:1527272242685};\\\", \\\"{x:1371,y:734,t:1527272242703};\\\", \\\"{x:1370,y:729,t:1527272242719};\\\", \\\"{x:1368,y:723,t:1527272242735};\\\", \\\"{x:1368,y:717,t:1527272242753};\\\", \\\"{x:1367,y:714,t:1527272242769};\\\", \\\"{x:1366,y:711,t:1527272242787};\\\", \\\"{x:1365,y:709,t:1527272242802};\\\", \\\"{x:1365,y:706,t:1527272242820};\\\", \\\"{x:1365,y:705,t:1527272242838};\\\", \\\"{x:1364,y:703,t:1527272242855};\\\", \\\"{x:1363,y:702,t:1527272242903};\\\", \\\"{x:1362,y:700,t:1527272242919};\\\", \\\"{x:1359,y:697,t:1527272242936};\\\", \\\"{x:1357,y:696,t:1527272242953};\\\", \\\"{x:1356,y:695,t:1527272243272};\\\", \\\"{x:1355,y:695,t:1527272243359};\\\", \\\"{x:1353,y:695,t:1527272244759};\\\", \\\"{x:1352,y:695,t:1527272244776};\\\", \\\"{x:1351,y:695,t:1527272244798};\\\", \\\"{x:1349,y:694,t:1527272244810};\\\", \\\"{x:1349,y:693,t:1527272244826};\\\", \\\"{x:1347,y:692,t:1527272244843};\\\", \\\"{x:1342,y:690,t:1527272244861};\\\", \\\"{x:1343,y:690,t:1527272246863};\\\", \\\"{x:1346,y:689,t:1527272246870};\\\", \\\"{x:1350,y:689,t:1527272246885};\\\", \\\"{x:1352,y:688,t:1527272246902};\\\", \\\"{x:1355,y:687,t:1527272246918};\\\", \\\"{x:1359,y:686,t:1527272246935};\\\", \\\"{x:1361,y:685,t:1527272246951};\\\", \\\"{x:1367,y:682,t:1527272246969};\\\", \\\"{x:1373,y:680,t:1527272246985};\\\", \\\"{x:1379,y:677,t:1527272247001};\\\", \\\"{x:1383,y:675,t:1527272247019};\\\", \\\"{x:1388,y:673,t:1527272247035};\\\", \\\"{x:1393,y:668,t:1527272247052};\\\", \\\"{x:1395,y:661,t:1527272247069};\\\", \\\"{x:1395,y:655,t:1527272247085};\\\", \\\"{x:1396,y:651,t:1527272247102};\\\", \\\"{x:1397,y:647,t:1527272247118};\\\", \\\"{x:1398,y:644,t:1527272247136};\\\", \\\"{x:1399,y:641,t:1527272247153};\\\", \\\"{x:1400,y:638,t:1527272247169};\\\", \\\"{x:1401,y:632,t:1527272247186};\\\", \\\"{x:1403,y:629,t:1527272247202};\\\", \\\"{x:1403,y:626,t:1527272247220};\\\", \\\"{x:1405,y:623,t:1527272247236};\\\", \\\"{x:1405,y:626,t:1527272247327};\\\", \\\"{x:1403,y:637,t:1527272247337};\\\", \\\"{x:1401,y:655,t:1527272247352};\\\", \\\"{x:1400,y:670,t:1527272247369};\\\", \\\"{x:1400,y:681,t:1527272247387};\\\", \\\"{x:1399,y:687,t:1527272247403};\\\", \\\"{x:1399,y:693,t:1527272247420};\\\", \\\"{x:1398,y:698,t:1527272247437};\\\", \\\"{x:1397,y:704,t:1527272247454};\\\", \\\"{x:1396,y:721,t:1527272247470};\\\", \\\"{x:1396,y:740,t:1527272247486};\\\", \\\"{x:1396,y:763,t:1527272247504};\\\", \\\"{x:1396,y:783,t:1527272247521};\\\", \\\"{x:1398,y:801,t:1527272247537};\\\", \\\"{x:1405,y:821,t:1527272247553};\\\", \\\"{x:1413,y:847,t:1527272247570};\\\", \\\"{x:1422,y:885,t:1527272247587};\\\", \\\"{x:1434,y:917,t:1527272247604};\\\", \\\"{x:1441,y:942,t:1527272247621};\\\", \\\"{x:1445,y:955,t:1527272247637};\\\", \\\"{x:1446,y:959,t:1527272247654};\\\", \\\"{x:1446,y:961,t:1527272247670};\\\", \\\"{x:1449,y:964,t:1527272247687};\\\", \\\"{x:1449,y:966,t:1527272247704};\\\", \\\"{x:1449,y:967,t:1527272247721};\\\", \\\"{x:1449,y:957,t:1527272247815};\\\", \\\"{x:1449,y:944,t:1527272247822};\\\", \\\"{x:1449,y:921,t:1527272247839};\\\", \\\"{x:1449,y:885,t:1527272247855};\\\", \\\"{x:1445,y:843,t:1527272247872};\\\", \\\"{x:1439,y:814,t:1527272247888};\\\", \\\"{x:1438,y:798,t:1527272247904};\\\", \\\"{x:1438,y:777,t:1527272247921};\\\", \\\"{x:1438,y:753,t:1527272247939};\\\", \\\"{x:1438,y:727,t:1527272247956};\\\", \\\"{x:1429,y:699,t:1527272247971};\\\", \\\"{x:1427,y:686,t:1527272247988};\\\", \\\"{x:1427,y:678,t:1527272248005};\\\", \\\"{x:1424,y:665,t:1527272248023};\\\", \\\"{x:1422,y:657,t:1527272248038};\\\", \\\"{x:1419,y:648,t:1527272248055};\\\", \\\"{x:1419,y:642,t:1527272248073};\\\", \\\"{x:1419,y:636,t:1527272248089};\\\", \\\"{x:1420,y:631,t:1527272248105};\\\", \\\"{x:1420,y:627,t:1527272248122};\\\", \\\"{x:1420,y:619,t:1527272248140};\\\", \\\"{x:1420,y:615,t:1527272248156};\\\", \\\"{x:1420,y:611,t:1527272248173};\\\", \\\"{x:1420,y:606,t:1527272248190};\\\", \\\"{x:1419,y:599,t:1527272248206};\\\", \\\"{x:1418,y:595,t:1527272248223};\\\", \\\"{x:1415,y:591,t:1527272248240};\\\", \\\"{x:1415,y:590,t:1527272248257};\\\", \\\"{x:1415,y:589,t:1527272248302};\\\", \\\"{x:1415,y:587,t:1527272248311};\\\", \\\"{x:1415,y:586,t:1527272248323};\\\", \\\"{x:1414,y:585,t:1527272248340};\\\", \\\"{x:1414,y:584,t:1527272248356};\\\", \\\"{x:1412,y:582,t:1527272248373};\\\", \\\"{x:1411,y:581,t:1527272248406};\\\", \\\"{x:1411,y:580,t:1527272248511};\\\", \\\"{x:1410,y:580,t:1527272248615};\\\", \\\"{x:1409,y:579,t:1527272248687};\\\", \\\"{x:1409,y:577,t:1527272248703};\\\", \\\"{x:1407,y:574,t:1527272248710};\\\", \\\"{x:1406,y:573,t:1527272248724};\\\", \\\"{x:1405,y:571,t:1527272248741};\\\", \\\"{x:1405,y:570,t:1527272248799};\\\", \\\"{x:1405,y:569,t:1527272249015};\\\", \\\"{x:1405,y:568,t:1527272249031};\\\", \\\"{x:1405,y:571,t:1527272253311};\\\", \\\"{x:1410,y:582,t:1527272253324};\\\", \\\"{x:1422,y:601,t:1527272253341};\\\", \\\"{x:1430,y:616,t:1527272253358};\\\", \\\"{x:1432,y:619,t:1527272253376};\\\", \\\"{x:1434,y:621,t:1527272253391};\\\", \\\"{x:1435,y:623,t:1527272253409};\\\", \\\"{x:1435,y:626,t:1527272253662};\\\", \\\"{x:1435,y:633,t:1527272253677};\\\", \\\"{x:1435,y:648,t:1527272253693};\\\", \\\"{x:1440,y:665,t:1527272253710};\\\", \\\"{x:1446,y:693,t:1527272253727};\\\", \\\"{x:1450,y:706,t:1527272253744};\\\", \\\"{x:1453,y:722,t:1527272253759};\\\", \\\"{x:1457,y:733,t:1527272253777};\\\", \\\"{x:1461,y:744,t:1527272253793};\\\", \\\"{x:1463,y:755,t:1527272253811};\\\", \\\"{x:1465,y:761,t:1527272253827};\\\", \\\"{x:1466,y:764,t:1527272253844};\\\", \\\"{x:1466,y:768,t:1527272253860};\\\", \\\"{x:1466,y:775,t:1527272253878};\\\", \\\"{x:1465,y:789,t:1527272253894};\\\", \\\"{x:1451,y:814,t:1527272253910};\\\", \\\"{x:1436,y:819,t:1527272253928};\\\", \\\"{x:1436,y:827,t:1527272254198};\\\", \\\"{x:1436,y:830,t:1527272254211};\\\", \\\"{x:1437,y:838,t:1527272254229};\\\", \\\"{x:1442,y:857,t:1527272254244};\\\", \\\"{x:1449,y:873,t:1527272254262};\\\", \\\"{x:1460,y:892,t:1527272254278};\\\", \\\"{x:1462,y:897,t:1527272254296};\\\", \\\"{x:1466,y:903,t:1527272254312};\\\", \\\"{x:1474,y:910,t:1527272254328};\\\", \\\"{x:1481,y:916,t:1527272254346};\\\", \\\"{x:1483,y:917,t:1527272254362};\\\", \\\"{x:1483,y:918,t:1527272254379};\\\", \\\"{x:1484,y:919,t:1527272254415};\\\", \\\"{x:1484,y:920,t:1527272254429};\\\", \\\"{x:1487,y:924,t:1527272254446};\\\", \\\"{x:1490,y:930,t:1527272254463};\\\", \\\"{x:1490,y:933,t:1527272254480};\\\", \\\"{x:1492,y:936,t:1527272254496};\\\", \\\"{x:1492,y:938,t:1527272254513};\\\", \\\"{x:1493,y:940,t:1527272254531};\\\", \\\"{x:1494,y:942,t:1527272254547};\\\", \\\"{x:1494,y:944,t:1527272254563};\\\", \\\"{x:1494,y:948,t:1527272254579};\\\", \\\"{x:1494,y:949,t:1527272254597};\\\", \\\"{x:1494,y:951,t:1527272254614};\\\", \\\"{x:1494,y:952,t:1527272254662};\\\", \\\"{x:1494,y:951,t:1527272254814};\\\", \\\"{x:1494,y:947,t:1527272254831};\\\", \\\"{x:1494,y:940,t:1527272254847};\\\", \\\"{x:1494,y:936,t:1527272254864};\\\", \\\"{x:1494,y:933,t:1527272254882};\\\", \\\"{x:1494,y:927,t:1527272254898};\\\", \\\"{x:1494,y:922,t:1527272254915};\\\", \\\"{x:1493,y:914,t:1527272254931};\\\", \\\"{x:1490,y:904,t:1527272254947};\\\", \\\"{x:1489,y:900,t:1527272254965};\\\", \\\"{x:1488,y:896,t:1527272254982};\\\", \\\"{x:1488,y:894,t:1527272254999};\\\", \\\"{x:1486,y:890,t:1527272255014};\\\", \\\"{x:1486,y:887,t:1527272255036};\\\", \\\"{x:1486,y:886,t:1527272255051};\\\", \\\"{x:1486,y:880,t:1527272255069};\\\", \\\"{x:1486,y:877,t:1527272255086};\\\", \\\"{x:1486,y:871,t:1527272255102};\\\", \\\"{x:1486,y:866,t:1527272255118};\\\", \\\"{x:1486,y:863,t:1527272255136};\\\", \\\"{x:1486,y:859,t:1527272255152};\\\", \\\"{x:1486,y:857,t:1527272255169};\\\", \\\"{x:1486,y:855,t:1527272255186};\\\", \\\"{x:1486,y:852,t:1527272255203};\\\", \\\"{x:1486,y:849,t:1527272255220};\\\", \\\"{x:1486,y:845,t:1527272255236};\\\", \\\"{x:1486,y:844,t:1527272255266};\\\", \\\"{x:1486,y:843,t:1527272255274};\\\", \\\"{x:1486,y:842,t:1527272255290};\\\", \\\"{x:1486,y:841,t:1527272255305};\\\", \\\"{x:1486,y:840,t:1527272255319};\\\", \\\"{x:1486,y:839,t:1527272255337};\\\", \\\"{x:1486,y:838,t:1527272255419};\\\", \\\"{x:1486,y:837,t:1527272255437};\\\", \\\"{x:1486,y:836,t:1527272255454};\\\", \\\"{x:1487,y:836,t:1527272255471};\\\", \\\"{x:1487,y:835,t:1527272255491};\\\", \\\"{x:1487,y:834,t:1527272255504};\\\", \\\"{x:1487,y:833,t:1527272255521};\\\", \\\"{x:1487,y:831,t:1527272255538};\\\", \\\"{x:1487,y:830,t:1527272255571};\\\", \\\"{x:1487,y:829,t:1527272255595};\\\", \\\"{x:1486,y:829,t:1527272255827};\\\", \\\"{x:1485,y:829,t:1527272255839};\\\", \\\"{x:1484,y:829,t:1527272255859};\\\", \\\"{x:1483,y:829,t:1527272255891};\\\", \\\"{x:1482,y:829,t:1527272255914};\\\", \\\"{x:1481,y:829,t:1527272255923};\\\", \\\"{x:1480,y:829,t:1527272255939};\\\", \\\"{x:1478,y:829,t:1527272256523};\\\", \\\"{x:1474,y:830,t:1527272256531};\\\", \\\"{x:1467,y:830,t:1527272256541};\\\", \\\"{x:1417,y:819,t:1527272256559};\\\", \\\"{x:1303,y:800,t:1527272256575};\\\", \\\"{x:1159,y:779,t:1527272256591};\\\", \\\"{x:981,y:750,t:1527272256608};\\\", \\\"{x:799,y:723,t:1527272256625};\\\", \\\"{x:595,y:698,t:1527272256642};\\\", \\\"{x:425,y:669,t:1527272256659};\\\", \\\"{x:263,y:646,t:1527272256674};\\\", \\\"{x:225,y:636,t:1527272256707};\\\", \\\"{x:225,y:632,t:1527272256723};\\\", \\\"{x:234,y:626,t:1527272256739};\\\", \\\"{x:246,y:620,t:1527272256757};\\\", \\\"{x:253,y:617,t:1527272256773};\\\", \\\"{x:257,y:614,t:1527272256790};\\\", \\\"{x:262,y:612,t:1527272256806};\\\", \\\"{x:283,y:605,t:1527272256828};\\\", \\\"{x:302,y:600,t:1527272256843};\\\", \\\"{x:313,y:598,t:1527272256860};\\\", \\\"{x:321,y:595,t:1527272256878};\\\", \\\"{x:322,y:595,t:1527272256893};\\\", \\\"{x:324,y:595,t:1527272256954};\\\", \\\"{x:326,y:595,t:1527272256978};\\\", \\\"{x:329,y:596,t:1527272256994};\\\", \\\"{x:360,y:607,t:1527272257011};\\\", \\\"{x:384,y:617,t:1527272257029};\\\", \\\"{x:404,y:626,t:1527272257044};\\\", \\\"{x:428,y:634,t:1527272257061};\\\", \\\"{x:460,y:644,t:1527272257078};\\\", \\\"{x:492,y:654,t:1527272257094};\\\", \\\"{x:523,y:659,t:1527272257111};\\\", \\\"{x:538,y:664,t:1527272257127};\\\", \\\"{x:539,y:664,t:1527272257153};\\\", \\\"{x:538,y:665,t:1527272257307};\\\", \\\"{x:532,y:665,t:1527272257314};\\\", \\\"{x:528,y:665,t:1527272257328};\\\", \\\"{x:524,y:665,t:1527272257343};\\\", \\\"{x:524,y:664,t:1527272257370};\\\", \\\"{x:524,y:662,t:1527272257387};\\\", \\\"{x:526,y:661,t:1527272257394};\\\", \\\"{x:531,y:658,t:1527272257410};\\\", \\\"{x:538,y:651,t:1527272257426};\\\", \\\"{x:545,y:646,t:1527272257444};\\\", \\\"{x:549,y:644,t:1527272257461};\\\", \\\"{x:550,y:643,t:1527272257477};\\\", \\\"{x:551,y:640,t:1527272257493};\\\", \\\"{x:556,y:638,t:1527272257509};\\\", \\\"{x:562,y:634,t:1527272257526};\\\", \\\"{x:567,y:632,t:1527272257544};\\\", \\\"{x:569,y:631,t:1527272257560};\\\", \\\"{x:569,y:629,t:1527272257577};\\\", \\\"{x:569,y:622,t:1527272257593};\\\", \\\"{x:570,y:619,t:1527272257610};\\\", \\\"{x:575,y:615,t:1527272257626};\\\", \\\"{x:578,y:613,t:1527272257644};\\\", \\\"{x:580,y:610,t:1527272257660};\\\", \\\"{x:581,y:607,t:1527272257678};\\\", \\\"{x:581,y:605,t:1527272257694};\\\", \\\"{x:584,y:604,t:1527272257711};\\\", \\\"{x:586,y:602,t:1527272257727};\\\", \\\"{x:587,y:601,t:1527272257744};\\\", \\\"{x:592,y:599,t:1527272257762};\\\", \\\"{x:593,y:598,t:1527272257801};\\\", \\\"{x:595,y:597,t:1527272257859};\\\", \\\"{x:596,y:596,t:1527272257866};\\\", \\\"{x:598,y:595,t:1527272257878};\\\", \\\"{x:599,y:595,t:1527272257895};\\\", \\\"{x:596,y:595,t:1527272258114};\\\", \\\"{x:592,y:595,t:1527272258128};\\\", \\\"{x:570,y:606,t:1527272258146};\\\", \\\"{x:554,y:621,t:1527272258162};\\\", \\\"{x:534,y:642,t:1527272258179};\\\", \\\"{x:515,y:660,t:1527272258194};\\\", \\\"{x:506,y:669,t:1527272258211};\\\", \\\"{x:504,y:673,t:1527272258228};\\\", \\\"{x:502,y:679,t:1527272258245};\\\", \\\"{x:495,y:689,t:1527272258262};\\\", \\\"{x:493,y:695,t:1527272258279};\\\", \\\"{x:490,y:703,t:1527272258295};\\\", \\\"{x:490,y:704,t:1527272258312};\\\", \\\"{x:490,y:706,t:1527272258328};\\\", \\\"{x:489,y:707,t:1527272258346};\\\", \\\"{x:486,y:710,t:1527272258361};\\\", \\\"{x:486,y:711,t:1527272258378};\\\", \\\"{x:486,y:712,t:1527272258395};\\\", \\\"{x:486,y:714,t:1527272258412};\\\", \\\"{x:486,y:717,t:1527272258428};\\\", \\\"{x:486,y:720,t:1527272258446};\\\", \\\"{x:486,y:722,t:1527272258461};\\\", \\\"{x:487,y:726,t:1527272258479};\\\", \\\"{x:488,y:729,t:1527272258496};\\\", \\\"{x:488,y:734,t:1527272258513};\\\", \\\"{x:491,y:738,t:1527272258528};\\\", \\\"{x:493,y:739,t:1527272258545};\\\", \\\"{x:497,y:739,t:1527272258561};\\\", \\\"{x:508,y:738,t:1527272258579};\\\", \\\"{x:528,y:729,t:1527272258595};\\\", \\\"{x:554,y:713,t:1527272258611};\\\", \\\"{x:582,y:689,t:1527272258628};\\\", \\\"{x:601,y:661,t:1527272258645};\\\", \\\"{x:609,y:640,t:1527272258662};\\\", \\\"{x:611,y:633,t:1527272258678};\\\", \\\"{x:611,y:632,t:1527272258696};\\\", \\\"{x:611,y:629,t:1527272258714};\\\", \\\"{x:611,y:628,t:1527272258728};\\\", \\\"{x:609,y:624,t:1527272258745};\\\", \\\"{x:608,y:622,t:1527272258762};\\\", \\\"{x:608,y:621,t:1527272258779};\\\", \\\"{x:605,y:618,t:1527272258796};\\\", \\\"{x:601,y:613,t:1527272258812};\\\", \\\"{x:599,y:610,t:1527272258828};\\\", \\\"{x:599,y:607,t:1527272258922};\\\", \\\"{x:599,y:605,t:1527272258930};\\\", \\\"{x:603,y:602,t:1527272258945};\\\", \\\"{x:604,y:599,t:1527272258962};\\\", \\\"{x:604,y:596,t:1527272258979};\\\", \\\"{x:604,y:593,t:1527272258995};\\\", \\\"{x:604,y:592,t:1527272259345};\\\", \\\"{x:601,y:593,t:1527272259363};\\\", \\\"{x:591,y:599,t:1527272259380};\\\", \\\"{x:578,y:620,t:1527272259396};\\\", \\\"{x:562,y:648,t:1527272259412};\\\", \\\"{x:546,y:666,t:1527272259429};\\\", \\\"{x:535,y:678,t:1527272259445};\\\", \\\"{x:527,y:687,t:1527272259463};\\\", \\\"{x:521,y:693,t:1527272259480};\\\", \\\"{x:517,y:697,t:1527272259496};\\\", \\\"{x:511,y:707,t:1527272259513};\\\", \\\"{x:504,y:717,t:1527272259530};\\\", \\\"{x:503,y:719,t:1527272259545};\\\", \\\"{x:502,y:720,t:1527272259563};\\\", \\\"{x:501,y:720,t:1527272259603};\\\", \\\"{x:499,y:721,t:1527272259613};\\\", \\\"{x:494,y:724,t:1527272259630};\\\", \\\"{x:489,y:727,t:1527272259646};\\\", \\\"{x:487,y:729,t:1527272259662};\\\", \\\"{x:486,y:729,t:1527272259681};\\\", \\\"{x:485,y:730,t:1527272259697};\\\", \\\"{x:484,y:730,t:1527272259722};\\\", \\\"{x:484,y:732,t:1527272259738};\\\", \\\"{x:484,y:736,t:1527272259747};\\\", \\\"{x:484,y:739,t:1527272259762};\\\", \\\"{x:484,y:742,t:1527272259779};\\\", \\\"{x:484,y:743,t:1527272259826};\\\", \\\"{x:484,y:745,t:1527272259842};\\\", \\\"{x:484,y:746,t:1527272259858};\\\", \\\"{x:484,y:747,t:1527272259890};\\\" ] }, { \\\"rt\\\": 45760, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 1252124, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Look at the x axis of start and end times. Go to 12PM and look straight up that line for the letter of the shift\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7757, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Canada\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 1260886, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 11314, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1273223, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 12124, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1286669, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"53R9B\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"53R9B\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 226, dom: 720, initialDom: 818",
  "javascriptErrors": []
}