var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e712844b443770739c33231cd791f57e",
  "created": "2018-05-24T12:01:14.2676078-07:00",
  "lastActivity": "2018-05-24T12:05:25.3896428-07:00",
  "pageViews": [
    {
      "id": "05241441616d4cea4ac8dd476d05cdfc4a827ddb",
      "startTime": "2018-05-24T12:01:14.4103136-07:00",
      "endTime": "2018-05-24T12:05:25.3896428-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 251536,
      "engagementTime": 60906,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 251536,
  "engagementTime": 60906,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a18ee947f9d4e4ae8423600a7940d8cb",
  "gdpr": false
}