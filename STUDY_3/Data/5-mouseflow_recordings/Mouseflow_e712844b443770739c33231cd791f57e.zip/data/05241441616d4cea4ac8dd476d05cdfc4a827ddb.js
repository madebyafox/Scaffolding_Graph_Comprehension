var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05241441616d4cea4ac8dd476d05cdfc4a827ddb"] = {
  "startTime": "2018-05-24T19:01:14.4103136Z",
  "websitePageUrl": "/",
  "visitTime": 251536,
  "engagementTime": 60906,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "e712844b443770739c33231cd791f57e",
    "created": "2018-05-24T19:01:14.2676078+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "a18ee947f9d4e4ae8423600a7940d8cb",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/e712844b443770739c33231cd791f57e/play"
  },
  "events": [
    {
      "t": 6,
      "e": 6,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 10000,
      "e": 5100,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 48700,
      "e": 5100,
      "ty": 2,
      "x": 0,
      "y": 476
    },
    {
      "t": 48750,
      "e": 5150,
      "ty": 41,
      "x": 0,
      "y": 41316,
      "ta": "html"
    },
    {
      "t": 48800,
      "e": 5200,
      "ty": 2,
      "x": 0,
      "y": 708
    },
    {
      "t": 48900,
      "e": 5300,
      "ty": 2,
      "x": 0,
      "y": 684
    },
    {
      "t": 49000,
      "e": 5400,
      "ty": 2,
      "x": 12,
      "y": 750
    },
    {
      "t": 49001,
      "e": 5401,
      "ty": 41,
      "x": 137,
      "y": 45150,
      "ta": "html > body"
    },
    {
      "t": 49100,
      "e": 5500,
      "ty": 2,
      "x": 66,
      "y": 992
    },
    {
      "t": 49163,
      "e": 5563,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 49200,
      "e": 5600,
      "ty": 2,
      "x": 99,
      "y": 1092
    },
    {
      "t": 60008,
      "e": 10600,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 64708,
      "e": 10600,
      "ty": 2,
      "x": 515,
      "y": 922
    },
    {
      "t": 64758,
      "e": 10650,
      "ty": 41,
      "x": 9256,
      "y": 64511,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 64786,
      "e": 10678,
      "ty": 3,
      "x": 529,
      "y": 934,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 64809,
      "e": 10701,
      "ty": 2,
      "x": 529,
      "y": 934
    },
    {
      "t": 64850,
      "e": 10742,
      "ty": 4,
      "x": 9256,
      "y": 64511,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 64850,
      "e": 10742,
      "ty": 5,
      "x": 529,
      "y": 934,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 64908,
      "e": 10800,
      "ty": 2,
      "x": 569,
      "y": 920
    },
    {
      "t": 65008,
      "e": 10900,
      "ty": 2,
      "x": 1442,
      "y": 923
    },
    {
      "t": 65008,
      "e": 10900,
      "ty": 41,
      "x": 59118,
      "y": 63609,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 65109,
      "e": 11001,
      "ty": 2,
      "x": 1913,
      "y": 1015
    },
    {
      "t": 65209,
      "e": 11101,
      "ty": 2,
      "x": 1919,
      "y": 1069
    },
    {
      "t": 65235,
      "e": 11127,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 65308,
      "e": 11200,
      "ty": 2,
      "x": 1919,
      "y": 1091
    },
    {
      "t": 70798,
      "e": 16200,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 78009,
      "e": 16200,
      "ty": 2,
      "x": 1503,
      "y": 978
    },
    {
      "t": 78009,
      "e": 16200,
      "ty": 41,
      "x": 51484,
      "y": 59024,
      "ta": "html > body"
    },
    {
      "t": 78109,
      "e": 16300,
      "ty": 2,
      "x": 1043,
      "y": 768
    },
    {
      "t": 78208,
      "e": 16399,
      "ty": 2,
      "x": 1043,
      "y": 767
    },
    {
      "t": 78258,
      "e": 16449,
      "ty": 41,
      "x": 37163,
      "y": 50093,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 78308,
      "e": 16499,
      "ty": 2,
      "x": 978,
      "y": 710
    },
    {
      "t": 78408,
      "e": 16599,
      "ty": 2,
      "x": 651,
      "y": 687
    },
    {
      "t": 78508,
      "e": 16699,
      "ty": 2,
      "x": 415,
      "y": 703
    },
    {
      "t": 78508,
      "e": 16699,
      "ty": 41,
      "x": 3030,
      "y": 45587,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 78609,
      "e": 16800,
      "ty": 2,
      "x": 383,
      "y": 719
    },
    {
      "t": 78758,
      "e": 16949,
      "ty": 41,
      "x": 1283,
      "y": 46898,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 80808,
      "e": 18999,
      "ty": 2,
      "x": 460,
      "y": 694
    },
    {
      "t": 80908,
      "e": 19099,
      "ty": 2,
      "x": 649,
      "y": 636
    },
    {
      "t": 81008,
      "e": 19199,
      "ty": 2,
      "x": 689,
      "y": 615
    },
    {
      "t": 81008,
      "e": 19199,
      "ty": 41,
      "x": 17994,
      "y": 38378,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 81109,
      "e": 19300,
      "ty": 2,
      "x": 769,
      "y": 589
    },
    {
      "t": 81208,
      "e": 19399,
      "ty": 2,
      "x": 794,
      "y": 578
    },
    {
      "t": 81258,
      "e": 19449,
      "ty": 41,
      "x": 24712,
      "y": 34610,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 81308,
      "e": 19499,
      "ty": 2,
      "x": 812,
      "y": 569
    },
    {
      "t": 81508,
      "e": 19699,
      "ty": 2,
      "x": 810,
      "y": 569
    },
    {
      "t": 81509,
      "e": 19700,
      "ty": 41,
      "x": 24602,
      "y": 34610,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 81608,
      "e": 19799,
      "ty": 2,
      "x": 665,
      "y": 580
    },
    {
      "t": 81708,
      "e": 19899,
      "ty": 2,
      "x": 593,
      "y": 581
    },
    {
      "t": 81759,
      "e": 19950,
      "ty": 41,
      "x": 12369,
      "y": 35511,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 81808,
      "e": 19999,
      "ty": 2,
      "x": 585,
      "y": 581
    },
    {
      "t": 81908,
      "e": 20099,
      "ty": 2,
      "x": 585,
      "y": 582
    },
    {
      "t": 82008,
      "e": 20199,
      "ty": 2,
      "x": 585,
      "y": 583
    },
    {
      "t": 82008,
      "e": 20199,
      "ty": 41,
      "x": 12315,
      "y": 35757,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 82052,
      "e": 20243,
      "ty": 3,
      "x": 585,
      "y": 583,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 82162,
      "e": 20353,
      "ty": 4,
      "x": 12315,
      "y": 35757,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 82163,
      "e": 20354,
      "ty": 5,
      "x": 585,
      "y": 583,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 82408,
      "e": 20599,
      "ty": 2,
      "x": 641,
      "y": 694
    },
    {
      "t": 82508,
      "e": 20699,
      "ty": 2,
      "x": 709,
      "y": 791
    },
    {
      "t": 82509,
      "e": 20700,
      "ty": 41,
      "x": 19087,
      "y": 52796,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 82608,
      "e": 20799,
      "ty": 2,
      "x": 752,
      "y": 843
    },
    {
      "t": 82708,
      "e": 20899,
      "ty": 2,
      "x": 762,
      "y": 834
    },
    {
      "t": 82758,
      "e": 20949,
      "ty": 41,
      "x": 22909,
      "y": 55172,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 82809,
      "e": 21000,
      "ty": 2,
      "x": 779,
      "y": 820
    },
    {
      "t": 83084,
      "e": 21275,
      "ty": 3,
      "x": 779,
      "y": 820,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 83195,
      "e": 21386,
      "ty": 4,
      "x": 22909,
      "y": 55172,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 83195,
      "e": 21386,
      "ty": 5,
      "x": 779,
      "y": 820,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 83608,
      "e": 21799,
      "ty": 1,
      "x": 0,
      "y": 9
    },
    {
      "t": 83708,
      "e": 21899,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 84308,
      "e": 22499,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 84408,
      "e": 22599,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 85009,
      "e": 23200,
      "ty": 2,
      "x": 624,
      "y": 784
    },
    {
      "t": 85009,
      "e": 23200,
      "ty": 41,
      "x": 14445,
      "y": 52223,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 85108,
      "e": 23299,
      "ty": 2,
      "x": 4,
      "y": 655
    },
    {
      "t": 85208,
      "e": 23399,
      "ty": 2,
      "x": 5,
      "y": 641
    },
    {
      "t": 85258,
      "e": 23449,
      "ty": 41,
      "x": 137,
      "y": 37726,
      "ta": "html > body"
    },
    {
      "t": 85309,
      "e": 23500,
      "ty": 2,
      "x": 34,
      "y": 608
    },
    {
      "t": 85409,
      "e": 23600,
      "ty": 2,
      "x": 77,
      "y": 574
    },
    {
      "t": 85509,
      "e": 23700,
      "ty": 2,
      "x": 99,
      "y": 558
    },
    {
      "t": 85509,
      "e": 23700,
      "ty": 41,
      "x": 3133,
      "y": 33467,
      "ta": "html > body"
    },
    {
      "t": 85609,
      "e": 23800,
      "ty": 2,
      "x": 118,
      "y": 528
    },
    {
      "t": 85759,
      "e": 23950,
      "ty": 41,
      "x": 3788,
      "y": 31641,
      "ta": "html > body"
    },
    {
      "t": 90008,
      "e": 28199,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 128117,
      "e": 28950,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 128218,
      "e": 29051,
      "ty": 2,
      "x": 118,
      "y": 594
    },
    {
      "t": 128267,
      "e": 29100,
      "ty": 41,
      "x": 3788,
      "y": 32462,
      "ta": "html > body"
    },
    {
      "t": 140018,
      "e": 34100,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 210778,
      "e": 34100,
      "ty": 41,
      "x": 4132,
      "y": 32296,
      "ta": "> div.masterdiv"
    },
    {
      "t": 210827,
      "e": 34149,
      "ty": 2,
      "x": 344,
      "y": 548
    },
    {
      "t": 210927,
      "e": 34249,
      "ty": 2,
      "x": 426,
      "y": 626
    },
    {
      "t": 211027,
      "e": 34349,
      "ty": 2,
      "x": 547,
      "y": 696
    },
    {
      "t": 211027,
      "e": 34349,
      "ty": 41,
      "x": 12473,
      "y": 10773,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 211126,
      "e": 34448,
      "ty": 2,
      "x": 636,
      "y": 771
    },
    {
      "t": 211226,
      "e": 34548,
      "ty": 2,
      "x": 742,
      "y": 888
    },
    {
      "t": 211278,
      "e": 34600,
      "ty": 41,
      "x": 22657,
      "y": 61705,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 211327,
      "e": 34649,
      "ty": 2,
      "x": 761,
      "y": 900
    },
    {
      "t": 211427,
      "e": 34749,
      "ty": 2,
      "x": 763,
      "y": 900
    },
    {
      "t": 211527,
      "e": 34849,
      "ty": 2,
      "x": 797,
      "y": 932
    },
    {
      "t": 211527,
      "e": 34849,
      "ty": 41,
      "x": 24772,
      "y": 61050,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 211626,
      "e": 34948,
      "ty": 2,
      "x": 804,
      "y": 933
    },
    {
      "t": 211727,
      "e": 35049,
      "ty": 2,
      "x": 818,
      "y": 933
    },
    {
      "t": 211777,
      "e": 35099,
      "ty": 41,
      "x": 21503,
      "y": 42648,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 211827,
      "e": 35149,
      "ty": 2,
      "x": 810,
      "y": 924
    },
    {
      "t": 211835,
      "e": 35157,
      "ty": 3,
      "x": 810,
      "y": 924,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 211883,
      "e": 35205,
      "ty": 4,
      "x": 21503,
      "y": 42648,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 211883,
      "e": 35205,
      "ty": 5,
      "x": 810,
      "y": 924,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 211885,
      "e": 35207,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 211888,
      "e": 35210,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 212027,
      "e": 35349,
      "ty": 2,
      "x": 817,
      "y": 950
    },
    {
      "t": 212027,
      "e": 35349,
      "ty": 41,
      "x": 25756,
      "y": 57039,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 212127,
      "e": 35449,
      "ty": 2,
      "x": 897,
      "y": 1078
    },
    {
      "t": 212227,
      "e": 35549,
      "ty": 2,
      "x": 911,
      "y": 1093
    },
    {
      "t": 212276,
      "e": 35598,
      "ty": 41,
      "x": 3549,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 212327,
      "e": 35649,
      "ty": 2,
      "x": 925,
      "y": 1094
    },
    {
      "t": 212396,
      "e": 35718,
      "ty": 3,
      "x": 925,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 212397,
      "e": 35719,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 212398,
      "e": 35720,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 212475,
      "e": 35797,
      "ty": 4,
      "x": 9557,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 212476,
      "e": 35798,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 212478,
      "e": 35800,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 212478,
      "e": 35800,
      "ty": 5,
      "x": 927,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 212527,
      "e": 35849,
      "ty": 2,
      "x": 927,
      "y": 1094
    },
    {
      "t": 212527,
      "e": 35849,
      "ty": 41,
      "x": 31648,
      "y": 60161,
      "ta": "html > body"
    },
    {
      "t": 213481,
      "e": 36803,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 214026,
      "e": 37348,
      "ty": 2,
      "x": 936,
      "y": 953
    },
    {
      "t": 214026,
      "e": 37348,
      "ty": 41,
      "x": 31958,
      "y": 52350,
      "ta": "html > body"
    },
    {
      "t": 214126,
      "e": 37448,
      "ty": 2,
      "x": 958,
      "y": 841
    },
    {
      "t": 214227,
      "e": 37549,
      "ty": 2,
      "x": 946,
      "y": 782
    },
    {
      "t": 214264,
      "e": 37586,
      "ty": 6,
      "x": 932,
      "y": 721,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 214277,
      "e": 37599,
      "ty": 41,
      "x": 18594,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 214280,
      "e": 37602,
      "ty": 7,
      "x": 930,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 214296,
      "e": 37618,
      "ty": 6,
      "x": 927,
      "y": 695,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 214327,
      "e": 37649,
      "ty": 2,
      "x": 925,
      "y": 682
    },
    {
      "t": 214330,
      "e": 37652,
      "ty": 7,
      "x": 922,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 214427,
      "e": 37749,
      "ty": 2,
      "x": 920,
      "y": 655
    },
    {
      "t": 214527,
      "e": 37849,
      "ty": 2,
      "x": 920,
      "y": 647
    },
    {
      "t": 214527,
      "e": 37849,
      "ty": 41,
      "x": 24224,
      "y": 32767,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 214627,
      "e": 37949,
      "ty": 2,
      "x": 927,
      "y": 614
    },
    {
      "t": 214727,
      "e": 38049,
      "ty": 2,
      "x": 931,
      "y": 607
    },
    {
      "t": 214777,
      "e": 38099,
      "ty": 41,
      "x": 26603,
      "y": 59897,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 214788,
      "e": 38110,
      "ty": 6,
      "x": 932,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 214826,
      "e": 38148,
      "ty": 2,
      "x": 933,
      "y": 597
    },
    {
      "t": 214907,
      "e": 38229,
      "ty": 3,
      "x": 936,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 214908,
      "e": 38230,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 214927,
      "e": 38249,
      "ty": 2,
      "x": 936,
      "y": 588
    },
    {
      "t": 214963,
      "e": 38285,
      "ty": 4,
      "x": 27684,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 214964,
      "e": 38286,
      "ty": 5,
      "x": 936,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 215027,
      "e": 38349,
      "ty": 41,
      "x": 27684,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 215752,
      "e": 39074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "75"
    },
    {
      "t": 215753,
      "e": 39075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 215839,
      "e": 39161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "k"
    },
    {
      "t": 215919,
      "e": 39241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 215920,
      "e": 39242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 215967,
      "e": 39289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ki"
    },
    {
      "t": 216031,
      "e": 39353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 216031,
      "e": 39353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 216119,
      "e": 39441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "kil"
    },
    {
      "t": 216191,
      "e": 39513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 216192,
      "e": 39514,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 216262,
      "e": 39584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "kilo"
    },
    {
      "t": 216999,
      "e": 40321,
      "ty": 7,
      "x": 936,
      "y": 607,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 217027,
      "e": 40349,
      "ty": 2,
      "x": 938,
      "y": 627
    },
    {
      "t": 217028,
      "e": 40350,
      "ty": 41,
      "x": 28117,
      "y": 8456,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 217127,
      "e": 40449,
      "ty": 2,
      "x": 941,
      "y": 658
    },
    {
      "t": 217227,
      "e": 40549,
      "ty": 2,
      "x": 940,
      "y": 667
    },
    {
      "t": 217277,
      "e": 40599,
      "ty": 41,
      "x": 28549,
      "y": 36643,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 217301,
      "e": 40623,
      "ty": 6,
      "x": 939,
      "y": 686,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 217327,
      "e": 40649,
      "ty": 2,
      "x": 939,
      "y": 688
    },
    {
      "t": 217427,
      "e": 40749,
      "ty": 2,
      "x": 939,
      "y": 684
    },
    {
      "t": 217527,
      "e": 40849,
      "ty": 2,
      "x": 938,
      "y": 683
    },
    {
      "t": 217528,
      "e": 40850,
      "ty": 41,
      "x": 28117,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 217531,
      "e": 40853,
      "ty": 3,
      "x": 938,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 217532,
      "e": 40854,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "kilo"
    },
    {
      "t": 217532,
      "e": 40854,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 217533,
      "e": 40855,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 217604,
      "e": 40926,
      "ty": 4,
      "x": 28117,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 217604,
      "e": 40926,
      "ty": 5,
      "x": 938,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 218064,
      "e": 41386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 218066,
      "e": 41388,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 218111,
      "e": 41388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 218223,
      "e": 41500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 218224,
      "e": 41501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 218295,
      "e": 41572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 218438,
      "e": 41715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "51"
    },
    {
      "t": 218439,
      "e": 41716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 218528,
      "e": 41805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 218632,
      "e": 41909,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 218727,
      "e": 42004,
      "ty": 2,
      "x": 936,
      "y": 697
    },
    {
      "t": 218734,
      "e": 42011,
      "ty": 7,
      "x": 935,
      "y": 700,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 218778,
      "e": 42055,
      "ty": 41,
      "x": 27468,
      "y": 62011,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 218818,
      "e": 42095,
      "ty": 6,
      "x": 935,
      "y": 709,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 218827,
      "e": 42104,
      "ty": 2,
      "x": 935,
      "y": 709
    },
    {
      "t": 218927,
      "e": 42204,
      "ty": 2,
      "x": 936,
      "y": 712
    },
    {
      "t": 219027,
      "e": 42304,
      "ty": 2,
      "x": 940,
      "y": 721
    },
    {
      "t": 219027,
      "e": 42304,
      "ty": 41,
      "x": 22717,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 220628,
      "e": 43905,
      "ty": 3,
      "x": 940,
      "y": 721,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 220629,
      "e": 43906,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 220630,
      "e": 43907,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 220630,
      "e": 43907,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 220731,
      "e": 44008,
      "ty": 4,
      "x": 22717,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 220732,
      "e": 44009,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 220733,
      "e": 44010,
      "ty": 5,
      "x": 940,
      "y": 721,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 220733,
      "e": 44010,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 221827,
      "e": 45104,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 221856,
      "e": 45133,
      "ty": 6,
      "x": 940,
      "y": 721,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 228164,
      "e": 50133,
      "ty": 7,
      "x": 943,
      "y": 768,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 228165,
      "e": 50134,
      "ty": 6,
      "x": 943,
      "y": 768,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 228176,
      "e": 50145,
      "ty": 7,
      "x": 951,
      "y": 817,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 228227,
      "e": 50196,
      "ty": 2,
      "x": 979,
      "y": 979
    },
    {
      "t": 228277,
      "e": 50246,
      "ty": 41,
      "x": 34218,
      "y": 62925,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 228326,
      "e": 50295,
      "ty": 2,
      "x": 991,
      "y": 1067
    },
    {
      "t": 228342,
      "e": 50311,
      "ty": 6,
      "x": 994,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 228427,
      "e": 50396,
      "ty": 2,
      "x": 994,
      "y": 1098
    },
    {
      "t": 228527,
      "e": 50496,
      "ty": 41,
      "x": 46147,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 228627,
      "e": 50596,
      "ty": 2,
      "x": 994,
      "y": 1095
    },
    {
      "t": 228777,
      "e": 50746,
      "ty": 41,
      "x": 46147,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 230026,
      "e": 51995,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 236437,
      "e": 55746,
      "ty": 3,
      "x": 994,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 236437,
      "e": 55746,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 236595,
      "e": 55904,
      "ty": 4,
      "x": 46147,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 236595,
      "e": 55904,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 236597,
      "e": 55906,
      "ty": 5,
      "x": 994,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 236599,
      "e": 55908,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 237600,
      "e": 56909,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 250036,
      "e": 60906,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 250530,
      "e": 60906,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 251536,
      "e": 60906,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 218, dom: 626, initialDom: 628",
  "javascriptErrors": []
}