var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052230918ddc6142d37663569cdaf65660754428"] = {
  "startTime": "2018-05-22T23:13:30.4066052Z",
  "websitePageUrl": "/16",
  "visitTime": 131175,
  "engagementTime": 117406,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "2015f99b53ec60bf8db79b69ab73b17e",
    "created": "2018-05-22T23:13:30.4066052+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=ZY4DY",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "4dbc2d22ced2ed999c4f304fba28a698",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/2015f99b53ec60bf8db79b69ab73b17e/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 228,
      "e": 228,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 228,
      "e": 228,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 488,
      "y": 699
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 440,
      "y": 622
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 56831,
      "y": 174,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 1048,
      "e": 1048,
      "ty": 6,
      "x": 431,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 424,
      "y": 592
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 418,
      "y": 585
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 36073,
      "y": 50377,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1314,
      "e": 1314,
      "ty": 3,
      "x": 418,
      "y": 585,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1314,
      "e": 1314,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1410,
      "e": 1410,
      "ty": 4,
      "x": 36073,
      "y": 50377,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1410,
      "e": 1410,
      "ty": 5,
      "x": 418,
      "y": 585,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10000,
      "e": 6410,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 19975,
      "e": 6410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 19976,
      "e": 6411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20134,
      "e": 6569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "f"
    },
    {
      "t": 20182,
      "e": 6617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20183,
      "e": 6618,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20262,
      "e": 6697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "fi"
    },
    {
      "t": 20414,
      "e": 6849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20414,
      "e": 6849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20477,
      "e": 6912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "fin"
    },
    {
      "t": 20602,
      "e": 7037,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "fin"
    },
    {
      "t": 20614,
      "e": 7049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20614,
      "e": 7049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20750,
      "e": 7185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find"
    },
    {
      "t": 20758,
      "e": 7193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20759,
      "e": 7194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20853,
      "e": 7288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20990,
      "e": 7425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20991,
      "e": 7426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21157,
      "e": 7592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 21158,
      "e": 7593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21181,
      "e": 7616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21181,
      "e": 7616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21237,
      "e": 7672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||the"
    },
    {
      "t": 21326,
      "e": 7761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21359,
      "e": 7794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21390,
      "e": 7825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 21391,
      "e": 7826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21398,
      "e": 7833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21399,
      "e": 7834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21534,
      "e": 7969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b "
    },
    {
      "t": 21573,
      "e": 8008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22030,
      "e": 8465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22158,
      "e": 8593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find theb"
    },
    {
      "t": 22262,
      "e": 8697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22374,
      "e": 8809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the"
    },
    {
      "t": 22854,
      "e": 9289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22858,
      "e": 9293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22982,
      "e": 9417,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23366,
      "e": 9801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 23367,
      "e": 9802,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23453,
      "e": 9888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 23598,
      "e": 10033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23599,
      "e": 10034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23661,
      "e": 10096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 23814,
      "e": 10249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23814,
      "e": 10249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23885,
      "e": 10320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 23982,
      "e": 10417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23983,
      "e": 10418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24125,
      "e": 10560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 24149,
      "e": 10584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24150,
      "e": 10585,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24222,
      "e": 10657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25886,
      "e": 12321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 25886,
      "e": 12321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25981,
      "e": 12416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 26190,
      "e": 12625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26191,
      "e": 12626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26261,
      "e": 12696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 26398,
      "e": 12833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26399,
      "e": 12834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26461,
      "e": 12896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 26614,
      "e": 13049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 26614,
      "e": 13049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26678,
      "e": 13113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 26803,
      "e": 13238,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line goin"
    },
    {
      "t": 26806,
      "e": 13241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 26807,
      "e": 13242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26918,
      "e": 13353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 26973,
      "e": 13408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26974,
      "e": 13409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27046,
      "e": 13481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27478,
      "e": 13913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27479,
      "e": 13914,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27549,
      "e": 13984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 27629,
      "e": 14064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 27630,
      "e": 14065,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27750,
      "e": 14185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 28166,
      "e": 14601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28167,
      "e": 14602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28277,
      "e": 14712,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28447,
      "e": 14882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28447,
      "e": 14882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28574,
      "e": 15009,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29214,
      "e": 15649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 29215,
      "e": 15650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29309,
      "e": 15744,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 29446,
      "e": 15881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 29446,
      "e": 15881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29573,
      "e": 16008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 29629,
      "e": 16064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29630,
      "e": 16065,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29702,
      "e": 16137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 29803,
      "e": 16238,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out fro"
    },
    {
      "t": 29870,
      "e": 16305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 29871,
      "e": 16306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29941,
      "e": 16376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 29998,
      "e": 16433,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30100,
      "e": 16535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30101,
      "e": 16536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30157,
      "e": 16592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30877,
      "e": 17312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 30877,
      "e": 17312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30964,
      "e": 17399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 31060,
      "e": 17495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31061,
      "e": 17496,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31139,
      "e": 17574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31325,
      "e": 17760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31325,
      "e": 17760,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31388,
      "e": 17823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 31588,
      "e": 18023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 31589,
      "e": 18024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31660,
      "e": 18095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 31764,
      "e": 18199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31764,
      "e": 18199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31860,
      "e": 18295,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32021,
      "e": 18456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32021,
      "e": 18456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32148,
      "e": 18583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33565,
      "e": 20000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 33565,
      "e": 20000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33660,
      "e": 20095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 33660,
      "e": 20095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33699,
      "e": 20134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 33788,
      "e": 20223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34613,
      "e": 21048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 34653,
      "e": 21088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 34653,
      "e": 21088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34772,
      "e": 21207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 34941,
      "e": 21376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 34941,
      "e": 21376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35004,
      "e": 21439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 35020,
      "e": 21455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35180,
      "e": 21615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35180,
      "e": 21615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35244,
      "e": 21679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36220,
      "e": 22655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 36222,
      "e": 22657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36284,
      "e": 22719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 36401,
      "e": 22836,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM o"
    },
    {
      "t": 36444,
      "e": 22879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36445,
      "e": 22880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36508,
      "e": 22943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 36660,
      "e": 23095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36662,
      "e": 23097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36748,
      "e": 23183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36852,
      "e": 23287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36853,
      "e": 23288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36924,
      "e": 23359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36924,
      "e": 23359,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37068,
      "e": 23503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 37084,
      "e": 23519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37085,
      "e": 23520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37116,
      "e": 23551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37132,
      "e": 23567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37133,
      "e": 23568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37259,
      "e": 23694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37332,
      "e": 23767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38269,
      "e": 24704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 38269,
      "e": 24704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38372,
      "e": 24807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 38500,
      "e": 24935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38501,
      "e": 24936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38571,
      "e": 25006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38668,
      "e": 25103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 38668,
      "e": 25103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38795,
      "e": 25230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 39268,
      "e": 25703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 39269,
      "e": 25704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39372,
      "e": 25807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 39748,
      "e": 26183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 39749,
      "e": 26184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39820,
      "e": 26255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 39932,
      "e": 26367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39932,
      "e": 26367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39999,
      "e": 26434,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40060,
      "e": 26495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 40708,
      "e": 27143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40709,
      "e": 27144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40820,
      "e": 27255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40916,
      "e": 27351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40917,
      "e": 27352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41028,
      "e": 27463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 41028,
      "e": 27463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41108,
      "e": 27543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ad"
    },
    {
      "t": 41124,
      "e": 27559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41125,
      "e": 27560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41219,
      "e": 27654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41267,
      "e": 27702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41580,
      "e": 28015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41700,
      "e": 28135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis ad"
    },
    {
      "t": 41933,
      "e": 28368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42036,
      "e": 28471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis a"
    },
    {
      "t": 42589,
      "e": 29024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 42589,
      "e": 29024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42676,
      "e": 29111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 42747,
      "e": 29182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 42747,
      "e": 29182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42891,
      "e": 29326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42892,
      "e": 29327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42923,
      "e": 29358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 42980,
      "e": 29415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43820,
      "e": 30255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 43821,
      "e": 30256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43933,
      "e": 30368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 44021,
      "e": 30456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44021,
      "e": 30456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44091,
      "e": 30526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 44201,
      "e": 30636,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis and fi"
    },
    {
      "t": 44236,
      "e": 30671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 44237,
      "e": 30672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44300,
      "e": 30735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 44589,
      "e": 31024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 44589,
      "e": 31024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44683,
      "e": 31118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44684,
      "e": 31119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44747,
      "e": 31182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 44755,
      "e": 31190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46236,
      "e": 32671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 46237,
      "e": 32672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46324,
      "e": 32759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 46477,
      "e": 32912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 46477,
      "e": 32912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46540,
      "e": 32975,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 46691,
      "e": 33126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 46692,
      "e": 33127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46763,
      "e": 33198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 46892,
      "e": 33327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 46892,
      "e": 33327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46980,
      "e": 33415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 47773,
      "e": 34208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47773,
      "e": 34208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47836,
      "e": 34271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 48045,
      "e": 34480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 48045,
      "e": 34480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48200,
      "e": 34635,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis and find ponits"
    },
    {
      "t": 48204,
      "e": 34639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 48268,
      "e": 34703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48269,
      "e": 34704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48332,
      "e": 34767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49428,
      "e": 35863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 49429,
      "e": 35864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49484,
      "e": 35919,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 49600,
      "e": 36035,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis and find ponits o"
    },
    {
      "t": 49636,
      "e": 36071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 49637,
      "e": 36072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49723,
      "e": 36158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 49948,
      "e": 36383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49949,
      "e": 36384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49998,
      "e": 36433,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50019,
      "e": 36454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50781,
      "e": 37216,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "187"
    },
    {
      "t": 50781,
      "e": 37216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50851,
      "e": 37286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||="
    },
    {
      "t": 50971,
      "e": 37406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "187"
    },
    {
      "t": 50972,
      "e": 37407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51035,
      "e": 37470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||="
    },
    {
      "t": 51644,
      "e": 38079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 51799,
      "e": 38234,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis and find ponits on ="
    },
    {
      "t": 52142,
      "e": 38577,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52176,
      "e": 38611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52209,
      "e": 38644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52242,
      "e": 38677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52275,
      "e": 38710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52308,
      "e": 38743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52341,
      "e": 38776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52363,
      "e": 38798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis and find poni"
    },
    {
      "t": 52932,
      "e": 39367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 53003,
      "e": 39438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis and find pon"
    },
    {
      "t": 53252,
      "e": 39687,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 53315,
      "e": 39750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis and find po"
    },
    {
      "t": 54004,
      "e": 40439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 54005,
      "e": 40440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54084,
      "e": 40519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 54201,
      "e": 40636,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis and find poi"
    },
    {
      "t": 54212,
      "e": 40647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 54213,
      "e": 40648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54283,
      "e": 40718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 54363,
      "e": 40798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 54363,
      "e": 40798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54491,
      "e": 40926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 54676,
      "e": 41111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 54676,
      "e": 41111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54763,
      "e": 41198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 55019,
      "e": 41454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55019,
      "e": 41454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55083,
      "e": 41518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55201,
      "e": 41636,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis and find points "
    },
    {
      "t": 55531,
      "e": 41966,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 55533,
      "e": 41968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55579,
      "e": 42014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 55835,
      "e": 42270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 55837,
      "e": 42272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55939,
      "e": 42374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 56115,
      "e": 42550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56115,
      "e": 42550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56195,
      "e": 42630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56708,
      "e": 43143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 56709,
      "e": 43144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56851,
      "e": 43286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 56883,
      "e": 43318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 56885,
      "e": 43320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56972,
      "e": 43407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 57020,
      "e": 43455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 57020,
      "e": 43455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57156,
      "e": 43591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 58004,
      "e": 44439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "187"
    },
    {
      "t": 58005,
      "e": 44440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58155,
      "e": 44590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||="
    },
    {
      "t": 59011,
      "e": 45446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 59099,
      "e": 45534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis and find points on the"
    },
    {
      "t": 59201,
      "e": 45535,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis and find points on the"
    },
    {
      "t": 59219,
      "e": 45553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 59308,
      "e": 45642,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis and find points on th"
    },
    {
      "t": 59627,
      "e": 45961,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 59628,
      "e": 45962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59763,
      "e": 46097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 59899,
      "e": 46233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59900,
      "e": 46234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59987,
      "e": 46321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 60204,
      "e": 46538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60204,
      "e": 46538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60259,
      "e": 46593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 60401,
      "e": 46735,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis and find points on that "
    },
    {
      "t": 60620,
      "e": 46954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 60620,
      "e": 46954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60707,
      "e": 47041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 60797,
      "e": 47131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 60798,
      "e": 47132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60939,
      "e": 47273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 61076,
      "e": 47410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 61077,
      "e": 47411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61139,
      "e": 47473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 61316,
      "e": 47650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 61316,
      "e": 47650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61387,
      "e": 47721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 63019,
      "e": 49353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 63019,
      "e": 49353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63084,
      "e": 49418,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 63202,
      "e": 49536,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis and find points on that path."
    },
    {
      "t": 64115,
      "e": 50449,
      "ty": 7,
      "x": 424,
      "y": 614,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64198,
      "e": 50532,
      "ty": 2,
      "x": 443,
      "y": 653
    },
    {
      "t": 64216,
      "e": 50550,
      "ty": 6,
      "x": 443,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 64249,
      "e": 50583,
      "ty": 41,
      "x": 57564,
      "y": 8221,
      "ta": "#strategyButton"
    },
    {
      "t": 64299,
      "e": 50633,
      "ty": 2,
      "x": 447,
      "y": 668
    },
    {
      "t": 64364,
      "e": 50698,
      "ty": 7,
      "x": 460,
      "y": 685,
      "ta": "#strategyButton"
    },
    {
      "t": 64399,
      "e": 50733,
      "ty": 2,
      "x": 472,
      "y": 695
    },
    {
      "t": 64499,
      "e": 50833,
      "ty": 2,
      "x": 474,
      "y": 705
    },
    {
      "t": 64499,
      "e": 50833,
      "ty": 41,
      "x": 42368,
      "y": 38611,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 64599,
      "e": 50933,
      "ty": 2,
      "x": 475,
      "y": 711
    },
    {
      "t": 64749,
      "e": 51083,
      "ty": 41,
      "x": 42480,
      "y": 38944,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 65299,
      "e": 51633,
      "ty": 2,
      "x": 475,
      "y": 716
    },
    {
      "t": 65399,
      "e": 51733,
      "ty": 2,
      "x": 499,
      "y": 992
    },
    {
      "t": 65499,
      "e": 51833,
      "ty": 2,
      "x": 619,
      "y": 1102
    },
    {
      "t": 65499,
      "e": 51833,
      "ty": 41,
      "x": 58667,
      "y": 60604,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 65599,
      "e": 51933,
      "ty": 2,
      "x": 682,
      "y": 1110
    },
    {
      "t": 65699,
      "e": 52033,
      "ty": 2,
      "x": 865,
      "y": 1100
    },
    {
      "t": 65750,
      "e": 52084,
      "ty": 41,
      "x": 33507,
      "y": 58610,
      "ta": "> div.stimulus"
    },
    {
      "t": 65799,
      "e": 52133,
      "ty": 2,
      "x": 1044,
      "y": 1041
    },
    {
      "t": 65899,
      "e": 52233,
      "ty": 2,
      "x": 1048,
      "y": 1039
    },
    {
      "t": 66000,
      "e": 52334,
      "ty": 41,
      "x": 18463,
      "y": 64532,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 66198,
      "e": 52532,
      "ty": 2,
      "x": 1063,
      "y": 1024
    },
    {
      "t": 66249,
      "e": 52583,
      "ty": 41,
      "x": 23889,
      "y": 60163,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 66299,
      "e": 52633,
      "ty": 2,
      "x": 1168,
      "y": 947
    },
    {
      "t": 66399,
      "e": 52733,
      "ty": 2,
      "x": 1202,
      "y": 931
    },
    {
      "t": 66500,
      "e": 52834,
      "ty": 41,
      "x": 29527,
      "y": 56940,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 66500,
      "e": 52834,
      "ty": 2,
      "x": 1205,
      "y": 933
    },
    {
      "t": 66599,
      "e": 52933,
      "ty": 2,
      "x": 1197,
      "y": 950
    },
    {
      "t": 66699,
      "e": 53033,
      "ty": 2,
      "x": 1196,
      "y": 953
    },
    {
      "t": 66749,
      "e": 53083,
      "ty": 41,
      "x": 28892,
      "y": 58372,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 66799,
      "e": 53133,
      "ty": 2,
      "x": 1192,
      "y": 957
    },
    {
      "t": 66899,
      "e": 53233,
      "ty": 2,
      "x": 1157,
      "y": 966
    },
    {
      "t": 66999,
      "e": 53333,
      "ty": 2,
      "x": 1151,
      "y": 966
    },
    {
      "t": 66999,
      "e": 53333,
      "ty": 41,
      "x": 25721,
      "y": 59303,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 67099,
      "e": 53433,
      "ty": 2,
      "x": 1152,
      "y": 964
    },
    {
      "t": 67199,
      "e": 53533,
      "ty": 2,
      "x": 1200,
      "y": 894
    },
    {
      "t": 67249,
      "e": 53583,
      "ty": 41,
      "x": 31077,
      "y": 49276,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 67299,
      "e": 53633,
      "ty": 2,
      "x": 1258,
      "y": 756
    },
    {
      "t": 67399,
      "e": 53733,
      "ty": 2,
      "x": 1333,
      "y": 600
    },
    {
      "t": 67498,
      "e": 53832,
      "ty": 2,
      "x": 1393,
      "y": 494
    },
    {
      "t": 67499,
      "e": 53833,
      "ty": 41,
      "x": 42775,
      "y": 25497,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 67599,
      "e": 53933,
      "ty": 2,
      "x": 1396,
      "y": 482
    },
    {
      "t": 67749,
      "e": 54083,
      "ty": 41,
      "x": 42986,
      "y": 24638,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 67999,
      "e": 54333,
      "ty": 2,
      "x": 1395,
      "y": 482
    },
    {
      "t": 67999,
      "e": 54333,
      "ty": 41,
      "x": 42915,
      "y": 24638,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 68399,
      "e": 54733,
      "ty": 2,
      "x": 1391,
      "y": 486
    },
    {
      "t": 68499,
      "e": 54833,
      "ty": 2,
      "x": 1382,
      "y": 493
    },
    {
      "t": 68499,
      "e": 54833,
      "ty": 41,
      "x": 11007,
      "y": 14563,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[12] > circle"
    },
    {
      "t": 68599,
      "e": 54933,
      "ty": 2,
      "x": 1367,
      "y": 505
    },
    {
      "t": 68699,
      "e": 55033,
      "ty": 2,
      "x": 1365,
      "y": 505
    },
    {
      "t": 68749,
      "e": 55083,
      "ty": 41,
      "x": 40801,
      "y": 26285,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 69999,
      "e": 56333,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70249,
      "e": 56583,
      "ty": 41,
      "x": 40379,
      "y": 26715,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 70299,
      "e": 56633,
      "ty": 2,
      "x": 1358,
      "y": 513
    },
    {
      "t": 70499,
      "e": 56833,
      "ty": 41,
      "x": 40308,
      "y": 26858,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 70699,
      "e": 57033,
      "ty": 2,
      "x": 1358,
      "y": 514
    },
    {
      "t": 70749,
      "e": 57083,
      "ty": 41,
      "x": 40097,
      "y": 27073,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 70799,
      "e": 57133,
      "ty": 2,
      "x": 1353,
      "y": 518
    },
    {
      "t": 70899,
      "e": 57233,
      "ty": 2,
      "x": 1352,
      "y": 518
    },
    {
      "t": 70999,
      "e": 57333,
      "ty": 41,
      "x": 39885,
      "y": 27216,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 71699,
      "e": 58033,
      "ty": 2,
      "x": 1190,
      "y": 647
    },
    {
      "t": 71749,
      "e": 58083,
      "ty": 41,
      "x": 10853,
      "y": 44692,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 71799,
      "e": 58133,
      "ty": 2,
      "x": 582,
      "y": 886
    },
    {
      "t": 71899,
      "e": 58233,
      "ty": 2,
      "x": 303,
      "y": 925
    },
    {
      "t": 71999,
      "e": 58333,
      "ty": 2,
      "x": 260,
      "y": 892
    },
    {
      "t": 72000,
      "e": 58334,
      "ty": 41,
      "x": 18312,
      "y": 48971,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 72099,
      "e": 58433,
      "ty": 2,
      "x": 280,
      "y": 798
    },
    {
      "t": 72139,
      "e": 58473,
      "ty": 6,
      "x": 393,
      "y": 686,
      "ta": "#strategyButton"
    },
    {
      "t": 72155,
      "e": 58489,
      "ty": 7,
      "x": 451,
      "y": 653,
      "ta": "#strategyButton"
    },
    {
      "t": 72199,
      "e": 58533,
      "ty": 2,
      "x": 528,
      "y": 612
    },
    {
      "t": 72205,
      "e": 58539,
      "ty": 6,
      "x": 548,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72249,
      "e": 58583,
      "ty": 41,
      "x": 51585,
      "y": 64131,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72299,
      "e": 58633,
      "ty": 2,
      "x": 559,
      "y": 602
    },
    {
      "t": 72321,
      "e": 58655,
      "ty": 7,
      "x": 569,
      "y": 611,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72399,
      "e": 58733,
      "ty": 2,
      "x": 572,
      "y": 684
    },
    {
      "t": 72499,
      "e": 58833,
      "ty": 2,
      "x": 537,
      "y": 717
    },
    {
      "t": 72499,
      "e": 58833,
      "ty": 41,
      "x": 49449,
      "y": 39276,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 72599,
      "e": 58933,
      "ty": 2,
      "x": 436,
      "y": 689
    },
    {
      "t": 72605,
      "e": 58939,
      "ty": 6,
      "x": 422,
      "y": 685,
      "ta": "#strategyButton"
    },
    {
      "t": 72699,
      "e": 59033,
      "ty": 2,
      "x": 407,
      "y": 678
    },
    {
      "t": 72749,
      "e": 59083,
      "ty": 41,
      "x": 37358,
      "y": 44844,
      "ta": "#strategyButton"
    },
    {
      "t": 72800,
      "e": 59134,
      "ty": 2,
      "x": 408,
      "y": 678
    },
    {
      "t": 72899,
      "e": 59233,
      "ty": 2,
      "x": 425,
      "y": 684
    },
    {
      "t": 72999,
      "e": 59333,
      "ty": 2,
      "x": 426,
      "y": 684
    },
    {
      "t": 73000,
      "e": 59334,
      "ty": 41,
      "x": 47734,
      "y": 56409,
      "ta": "#strategyButton"
    },
    {
      "t": 73099,
      "e": 59433,
      "ty": 2,
      "x": 424,
      "y": 684
    },
    {
      "t": 73199,
      "e": 59533,
      "ty": 2,
      "x": 422,
      "y": 683
    },
    {
      "t": 73249,
      "e": 59583,
      "ty": 41,
      "x": 45550,
      "y": 54481,
      "ta": "#strategyButton"
    },
    {
      "t": 73499,
      "e": 59833,
      "ty": 2,
      "x": 421,
      "y": 683
    },
    {
      "t": 73499,
      "e": 59833,
      "ty": 41,
      "x": 45004,
      "y": 54481,
      "ta": "#strategyButton"
    },
    {
      "t": 73598,
      "e": 59932,
      "ty": 2,
      "x": 419,
      "y": 682
    },
    {
      "t": 73699,
      "e": 60033,
      "ty": 2,
      "x": 416,
      "y": 674
    },
    {
      "t": 73748,
      "e": 60082,
      "ty": 41,
      "x": 41727,
      "y": 27496,
      "ta": "#strategyButton"
    },
    {
      "t": 73798,
      "e": 60132,
      "ty": 2,
      "x": 415,
      "y": 669
    },
    {
      "t": 73998,
      "e": 60332,
      "ty": 2,
      "x": 414,
      "y": 668
    },
    {
      "t": 73998,
      "e": 60332,
      "ty": 41,
      "x": 41181,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 74360,
      "e": 60694,
      "ty": 3,
      "x": 414,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 74362,
      "e": 60696,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "find the line going out from point 12PM on the x axis and find points on that path."
    },
    {
      "t": 74362,
      "e": 60696,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74364,
      "e": 60698,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 74568,
      "e": 60902,
      "ty": 4,
      "x": 41181,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 74586,
      "e": 60920,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 74588,
      "e": 60922,
      "ty": 5,
      "x": 414,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 74596,
      "e": 60930,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 75591,
      "e": 61925,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 76699,
      "e": 63033,
      "ty": 2,
      "x": 464,
      "y": 665
    },
    {
      "t": 76748,
      "e": 63082,
      "ty": 41,
      "x": 17769,
      "y": 36008,
      "ta": "html > body"
    },
    {
      "t": 76798,
      "e": 63132,
      "ty": 2,
      "x": 790,
      "y": 620
    },
    {
      "t": 76898,
      "e": 63232,
      "ty": 2,
      "x": 861,
      "y": 604
    },
    {
      "t": 76999,
      "e": 63333,
      "ty": 2,
      "x": 862,
      "y": 604
    },
    {
      "t": 76999,
      "e": 63333,
      "ty": 41,
      "x": 11679,
      "y": 7021,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 77098,
      "e": 63432,
      "ty": 2,
      "x": 898,
      "y": 576
    },
    {
      "t": 77108,
      "e": 63442,
      "ty": 6,
      "x": 903,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77198,
      "e": 63532,
      "ty": 2,
      "x": 905,
      "y": 570
    },
    {
      "t": 77248,
      "e": 63582,
      "ty": 41,
      "x": 20979,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77336,
      "e": 63670,
      "ty": 3,
      "x": 905,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77337,
      "e": 63671,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77462,
      "e": 63796,
      "ty": 4,
      "x": 20979,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77463,
      "e": 63797,
      "ty": 5,
      "x": 905,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 78444,
      "e": 64778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 78444,
      "e": 64778,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 78599,
      "e": 64933,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 78603,
      "e": 64937,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 78715,
      "e": 65049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 78716,
      "e": 65050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 78859,
      "e": 65193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 79360,
      "e": 65694,
      "ty": 7,
      "x": 850,
      "y": 481,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 79398,
      "e": 65732,
      "ty": 2,
      "x": 782,
      "y": 434
    },
    {
      "t": 79499,
      "e": 65833,
      "ty": 2,
      "x": 776,
      "y": 433
    },
    {
      "t": 79499,
      "e": 65833,
      "ty": 41,
      "x": 26448,
      "y": 23543,
      "ta": "html > body"
    },
    {
      "t": 79599,
      "e": 65933,
      "ty": 2,
      "x": 830,
      "y": 457
    },
    {
      "t": 79698,
      "e": 66032,
      "ty": 2,
      "x": 941,
      "y": 548
    },
    {
      "t": 79728,
      "e": 66062,
      "ty": 6,
      "x": 941,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 79749,
      "e": 66083,
      "ty": 41,
      "x": 29415,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 79760,
      "e": 66094,
      "ty": 7,
      "x": 944,
      "y": 577,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 79798,
      "e": 66132,
      "ty": 2,
      "x": 945,
      "y": 591
    },
    {
      "t": 79898,
      "e": 66232,
      "ty": 2,
      "x": 936,
      "y": 625
    },
    {
      "t": 79927,
      "e": 66261,
      "ty": 6,
      "x": 923,
      "y": 652,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79999,
      "e": 66333,
      "ty": 2,
      "x": 915,
      "y": 664
    },
    {
      "t": 79999,
      "e": 66333,
      "ty": 41,
      "x": 23142,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79999,
      "e": 66333,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80098,
      "e": 66432,
      "ty": 2,
      "x": 909,
      "y": 664
    },
    {
      "t": 80198,
      "e": 66532,
      "ty": 2,
      "x": 906,
      "y": 664
    },
    {
      "t": 80249,
      "e": 66583,
      "ty": 41,
      "x": 21196,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80398,
      "e": 66732,
      "ty": 2,
      "x": 905,
      "y": 664
    },
    {
      "t": 80480,
      "e": 66814,
      "ty": 3,
      "x": 905,
      "y": 664,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80481,
      "e": 66815,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 80481,
      "e": 66815,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 80482,
      "e": 66816,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80499,
      "e": 66833,
      "ty": 41,
      "x": 20979,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80663,
      "e": 66997,
      "ty": 4,
      "x": 20979,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80664,
      "e": 66998,
      "ty": 5,
      "x": 905,
      "y": 664,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81198,
      "e": 67532,
      "ty": 2,
      "x": 903,
      "y": 662
    },
    {
      "t": 81249,
      "e": 67583,
      "ty": 41,
      "x": 20547,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81599,
      "e": 67933,
      "ty": 2,
      "x": 915,
      "y": 662
    },
    {
      "t": 81698,
      "e": 68032,
      "ty": 2,
      "x": 917,
      "y": 663
    },
    {
      "t": 81749,
      "e": 68083,
      "ty": 41,
      "x": 23575,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83411,
      "e": 69745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 83794,
      "e": 70128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 83794,
      "e": 70128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83930,
      "e": 70264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 83986,
      "e": 70320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 84148,
      "e": 70482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 84148,
      "e": 70482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84259,
      "e": 70593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ch"
    },
    {
      "t": 84291,
      "e": 70625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 84291,
      "e": 70625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84363,
      "e": 70697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chi"
    },
    {
      "t": 84508,
      "e": 70842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 84508,
      "e": 70842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84635,
      "e": 70969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chin"
    },
    {
      "t": 84772,
      "e": 71106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 84772,
      "e": 71106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84914,
      "e": 71248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 85352,
      "e": 71686,
      "ty": 7,
      "x": 899,
      "y": 646,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 85398,
      "e": 71732,
      "ty": 2,
      "x": 716,
      "y": 457
    },
    {
      "t": 85498,
      "e": 71832,
      "ty": 2,
      "x": 697,
      "y": 446
    },
    {
      "t": 85499,
      "e": 71833,
      "ty": 41,
      "x": 23727,
      "y": 24264,
      "ta": "html > body"
    },
    {
      "t": 85599,
      "e": 71933,
      "ty": 2,
      "x": 696,
      "y": 446
    },
    {
      "t": 85698,
      "e": 72032,
      "ty": 2,
      "x": 698,
      "y": 448
    },
    {
      "t": 85749,
      "e": 72083,
      "ty": 41,
      "x": 24175,
      "y": 25039,
      "ta": "html > body"
    },
    {
      "t": 85799,
      "e": 72133,
      "ty": 2,
      "x": 719,
      "y": 486
    },
    {
      "t": 85899,
      "e": 72233,
      "ty": 2,
      "x": 969,
      "y": 733
    },
    {
      "t": 85999,
      "e": 72333,
      "ty": 2,
      "x": 993,
      "y": 733
    },
    {
      "t": 85999,
      "e": 72333,
      "ty": 41,
      "x": 33921,
      "y": 40163,
      "ta": "html > body"
    },
    {
      "t": 86099,
      "e": 72433,
      "ty": 2,
      "x": 987,
      "y": 713
    },
    {
      "t": 86131,
      "e": 72465,
      "ty": 6,
      "x": 977,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 86198,
      "e": 72532,
      "ty": 2,
      "x": 974,
      "y": 704
    },
    {
      "t": 86249,
      "e": 72583,
      "ty": 41,
      "x": 40240,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 86312,
      "e": 72646,
      "ty": 3,
      "x": 974,
      "y": 704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 86312,
      "e": 72646,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "China"
    },
    {
      "t": 86313,
      "e": 72647,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86313,
      "e": 72647,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 86439,
      "e": 72773,
      "ty": 4,
      "x": 40240,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 86441,
      "e": 72775,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 86442,
      "e": 72776,
      "ty": 5,
      "x": 974,
      "y": 704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 86443,
      "e": 72777,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 87462,
      "e": 73796,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 88799,
      "e": 75133,
      "ty": 2,
      "x": 973,
      "y": 701
    },
    {
      "t": 88898,
      "e": 75232,
      "ty": 2,
      "x": 982,
      "y": 452
    },
    {
      "t": 88998,
      "e": 75332,
      "ty": 2,
      "x": 1104,
      "y": 93
    },
    {
      "t": 88998,
      "e": 75332,
      "ty": 41,
      "x": 37743,
      "y": 4708,
      "ta": "html > body"
    },
    {
      "t": 89099,
      "e": 75433,
      "ty": 2,
      "x": 1075,
      "y": 45
    },
    {
      "t": 89249,
      "e": 75583,
      "ty": 41,
      "x": 36435,
      "y": 2049,
      "ta": "html > body"
    },
    {
      "t": 89299,
      "e": 75633,
      "ty": 2,
      "x": 1049,
      "y": 51
    },
    {
      "t": 89399,
      "e": 75733,
      "ty": 2,
      "x": 902,
      "y": 203
    },
    {
      "t": 89499,
      "e": 75833,
      "ty": 2,
      "x": 881,
      "y": 221
    },
    {
      "t": 89499,
      "e": 75833,
      "ty": 41,
      "x": 14139,
      "y": 17420,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 89899,
      "e": 76233,
      "ty": 2,
      "x": 895,
      "y": 216
    },
    {
      "t": 89996,
      "e": 76330,
      "ty": 2,
      "x": 897,
      "y": 215
    },
    {
      "t": 89997,
      "e": 76331,
      "ty": 41,
      "x": 17936,
      "y": 14932,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 89997,
      "e": 76331,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90196,
      "e": 76530,
      "ty": 2,
      "x": 898,
      "y": 215
    },
    {
      "t": 90247,
      "e": 76581,
      "ty": 41,
      "x": 19360,
      "y": 17005,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 90297,
      "e": 76631,
      "ty": 2,
      "x": 908,
      "y": 226
    },
    {
      "t": 90397,
      "e": 76731,
      "ty": 2,
      "x": 922,
      "y": 235
    },
    {
      "t": 90497,
      "e": 76831,
      "ty": 2,
      "x": 931,
      "y": 266
    },
    {
      "t": 90497,
      "e": 76831,
      "ty": 41,
      "x": 26005,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 90596,
      "e": 76930,
      "ty": 2,
      "x": 909,
      "y": 300
    },
    {
      "t": 90697,
      "e": 77031,
      "ty": 2,
      "x": 907,
      "y": 301
    },
    {
      "t": 90747,
      "e": 77081,
      "ty": 41,
      "x": 25253,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 90797,
      "e": 77131,
      "ty": 2,
      "x": 898,
      "y": 301
    },
    {
      "t": 90897,
      "e": 77231,
      "ty": 2,
      "x": 896,
      "y": 301
    },
    {
      "t": 90996,
      "e": 77330,
      "ty": 2,
      "x": 876,
      "y": 297
    },
    {
      "t": 90997,
      "e": 77331,
      "ty": 41,
      "x": 17104,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 91097,
      "e": 77431,
      "ty": 2,
      "x": 859,
      "y": 294
    },
    {
      "t": 91247,
      "e": 77581,
      "ty": 41,
      "x": 11777,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 91297,
      "e": 77631,
      "ty": 2,
      "x": 856,
      "y": 294
    },
    {
      "t": 91385,
      "e": 77719,
      "ty": 6,
      "x": 839,
      "y": 293,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 91396,
      "e": 77730,
      "ty": 2,
      "x": 839,
      "y": 293
    },
    {
      "t": 91497,
      "e": 77831,
      "ty": 2,
      "x": 838,
      "y": 293
    },
    {
      "t": 91497,
      "e": 77831,
      "ty": 41,
      "x": 58367,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 91796,
      "e": 78130,
      "ty": 2,
      "x": 837,
      "y": 293
    },
    {
      "t": 91897,
      "e": 78231,
      "ty": 2,
      "x": 828,
      "y": 294
    },
    {
      "t": 91997,
      "e": 78331,
      "ty": 41,
      "x": 7955,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 92397,
      "e": 78731,
      "ty": 2,
      "x": 828,
      "y": 293
    },
    {
      "t": 92497,
      "e": 78831,
      "ty": 2,
      "x": 828,
      "y": 292
    },
    {
      "t": 92497,
      "e": 78831,
      "ty": 41,
      "x": 7955,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 93097,
      "e": 79431,
      "ty": 2,
      "x": 829,
      "y": 292
    },
    {
      "t": 93196,
      "e": 79530,
      "ty": 2,
      "x": 832,
      "y": 292
    },
    {
      "t": 93246,
      "e": 79580,
      "ty": 41,
      "x": 33161,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 93297,
      "e": 79631,
      "ty": 2,
      "x": 834,
      "y": 292
    },
    {
      "t": 93397,
      "e": 79731,
      "ty": 2,
      "x": 835,
      "y": 293
    },
    {
      "t": 93497,
      "e": 79831,
      "ty": 41,
      "x": 43243,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 94270,
      "e": 80604,
      "ty": 3,
      "x": 835,
      "y": 293,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 94271,
      "e": 80605,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 94404,
      "e": 80738,
      "ty": 4,
      "x": 43243,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 94405,
      "e": 80739,
      "ty": 5,
      "x": 835,
      "y": 293,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 94405,
      "e": 80739,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 94921,
      "e": 81255,
      "ty": 7,
      "x": 848,
      "y": 290,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 94997,
      "e": 81331,
      "ty": 2,
      "x": 991,
      "y": 286
    },
    {
      "t": 94997,
      "e": 81331,
      "ty": 41,
      "x": 53145,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 95097,
      "e": 81431,
      "ty": 2,
      "x": 1101,
      "y": 288
    },
    {
      "t": 95247,
      "e": 81581,
      "ty": 41,
      "x": 37640,
      "y": 15511,
      "ta": "html > body"
    },
    {
      "t": 95397,
      "e": 81731,
      "ty": 2,
      "x": 1099,
      "y": 288
    },
    {
      "t": 95497,
      "e": 81831,
      "ty": 2,
      "x": 1005,
      "y": 356
    },
    {
      "t": 95497,
      "e": 81831,
      "ty": 41,
      "x": 43567,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 95597,
      "e": 81931,
      "ty": 2,
      "x": 927,
      "y": 399
    },
    {
      "t": 95697,
      "e": 82031,
      "ty": 2,
      "x": 917,
      "y": 406
    },
    {
      "t": 95747,
      "e": 82081,
      "ty": 41,
      "x": 22683,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 95797,
      "e": 82131,
      "ty": 2,
      "x": 925,
      "y": 411
    },
    {
      "t": 95896,
      "e": 82230,
      "ty": 2,
      "x": 946,
      "y": 423
    },
    {
      "t": 95997,
      "e": 82331,
      "ty": 2,
      "x": 949,
      "y": 425
    },
    {
      "t": 95997,
      "e": 82331,
      "ty": 41,
      "x": 30277,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 96296,
      "e": 82630,
      "ty": 2,
      "x": 946,
      "y": 425
    },
    {
      "t": 96397,
      "e": 82731,
      "ty": 2,
      "x": 939,
      "y": 426
    },
    {
      "t": 96497,
      "e": 82831,
      "ty": 2,
      "x": 937,
      "y": 426
    },
    {
      "t": 96497,
      "e": 82831,
      "ty": 41,
      "x": 27429,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 96997,
      "e": 83331,
      "ty": 2,
      "x": 936,
      "y": 428
    },
    {
      "t": 96997,
      "e": 83331,
      "ty": 41,
      "x": 27192,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 97097,
      "e": 83431,
      "ty": 2,
      "x": 890,
      "y": 447
    },
    {
      "t": 97197,
      "e": 83531,
      "ty": 2,
      "x": 863,
      "y": 458
    },
    {
      "t": 97247,
      "e": 83581,
      "ty": 41,
      "x": 8206,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 97297,
      "e": 83631,
      "ty": 2,
      "x": 842,
      "y": 446
    },
    {
      "t": 97391,
      "e": 83725,
      "ty": 6,
      "x": 839,
      "y": 444,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 97397,
      "e": 83731,
      "ty": 2,
      "x": 839,
      "y": 444
    },
    {
      "t": 97497,
      "e": 83831,
      "ty": 2,
      "x": 834,
      "y": 442
    },
    {
      "t": 97497,
      "e": 83831,
      "ty": 41,
      "x": 38202,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 97597,
      "e": 83931,
      "ty": 2,
      "x": 831,
      "y": 440
    },
    {
      "t": 97622,
      "e": 83956,
      "ty": 3,
      "x": 831,
      "y": 440,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 97623,
      "e": 83957,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 97624,
      "e": 83958,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 97732,
      "e": 84066,
      "ty": 4,
      "x": 23079,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 97732,
      "e": 84066,
      "ty": 5,
      "x": 831,
      "y": 440,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 97732,
      "e": 84066,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 97747,
      "e": 84081,
      "ty": 41,
      "x": 23079,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 97891,
      "e": 84225,
      "ty": 7,
      "x": 851,
      "y": 444,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 97896,
      "e": 84230,
      "ty": 2,
      "x": 851,
      "y": 444
    },
    {
      "t": 97996,
      "e": 84330,
      "ty": 2,
      "x": 1574,
      "y": 583
    },
    {
      "t": 97996,
      "e": 84330,
      "ty": 41,
      "x": 53929,
      "y": 31853,
      "ta": "html > body"
    },
    {
      "t": 98097,
      "e": 84431,
      "ty": 2,
      "x": 1580,
      "y": 585
    },
    {
      "t": 98247,
      "e": 84581,
      "ty": 41,
      "x": 54032,
      "y": 32075,
      "ta": "html > body"
    },
    {
      "t": 98296,
      "e": 84630,
      "ty": 2,
      "x": 1568,
      "y": 591
    },
    {
      "t": 98497,
      "e": 84831,
      "ty": 2,
      "x": 1499,
      "y": 601
    },
    {
      "t": 98497,
      "e": 84831,
      "ty": 41,
      "x": 51346,
      "y": 32850,
      "ta": "html > body"
    },
    {
      "t": 98596,
      "e": 84930,
      "ty": 2,
      "x": 1412,
      "y": 602
    },
    {
      "t": 98697,
      "e": 85031,
      "ty": 2,
      "x": 1319,
      "y": 626
    },
    {
      "t": 98747,
      "e": 85081,
      "ty": 41,
      "x": 44872,
      "y": 34457,
      "ta": "html > body"
    },
    {
      "t": 98796,
      "e": 85130,
      "ty": 2,
      "x": 1281,
      "y": 647
    },
    {
      "t": 98897,
      "e": 85231,
      "ty": 2,
      "x": 1257,
      "y": 677
    },
    {
      "t": 98996,
      "e": 85330,
      "ty": 2,
      "x": 1266,
      "y": 685
    },
    {
      "t": 98996,
      "e": 85330,
      "ty": 41,
      "x": 43322,
      "y": 37503,
      "ta": "html > body"
    },
    {
      "t": 99097,
      "e": 85431,
      "ty": 2,
      "x": 1268,
      "y": 687
    },
    {
      "t": 99247,
      "e": 85581,
      "ty": 41,
      "x": 43391,
      "y": 37614,
      "ta": "html > body"
    },
    {
      "t": 99397,
      "e": 85731,
      "ty": 2,
      "x": 1269,
      "y": 687
    },
    {
      "t": 99498,
      "e": 85832,
      "ty": 41,
      "x": 43425,
      "y": 37614,
      "ta": "html > body"
    },
    {
      "t": 99697,
      "e": 86031,
      "ty": 2,
      "x": 1254,
      "y": 689
    },
    {
      "t": 99748,
      "e": 86032,
      "ty": 41,
      "x": 40533,
      "y": 38002,
      "ta": "html > body"
    },
    {
      "t": 99796,
      "e": 86080,
      "ty": 2,
      "x": 1121,
      "y": 694
    },
    {
      "t": 99897,
      "e": 86181,
      "ty": 2,
      "x": 969,
      "y": 694
    },
    {
      "t": 99996,
      "e": 86280,
      "ty": 2,
      "x": 907,
      "y": 687
    },
    {
      "t": 99997,
      "e": 86281,
      "ty": 41,
      "x": 20309,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 100097,
      "e": 86381,
      "ty": 2,
      "x": 874,
      "y": 685
    },
    {
      "t": 100197,
      "e": 86481,
      "ty": 2,
      "x": 870,
      "y": 685
    },
    {
      "t": 100247,
      "e": 86531,
      "ty": 41,
      "x": 11528,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 100497,
      "e": 86781,
      "ty": 2,
      "x": 843,
      "y": 678
    },
    {
      "t": 100497,
      "e": 86781,
      "ty": 41,
      "x": 5793,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 100597,
      "e": 86881,
      "ty": 2,
      "x": 842,
      "y": 677
    },
    {
      "t": 100697,
      "e": 86981,
      "ty": 2,
      "x": 843,
      "y": 674
    },
    {
      "t": 100747,
      "e": 87031,
      "ty": 41,
      "x": 7136,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 100796,
      "e": 87080,
      "ty": 2,
      "x": 857,
      "y": 666
    },
    {
      "t": 100897,
      "e": 87181,
      "ty": 2,
      "x": 926,
      "y": 654
    },
    {
      "t": 100997,
      "e": 87281,
      "ty": 2,
      "x": 936,
      "y": 652
    },
    {
      "t": 100997,
      "e": 87281,
      "ty": 41,
      "x": 27192,
      "y": 10019,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 101097,
      "e": 87381,
      "ty": 2,
      "x": 980,
      "y": 648
    },
    {
      "t": 101196,
      "e": 87480,
      "ty": 2,
      "x": 998,
      "y": 647
    },
    {
      "t": 101247,
      "e": 87531,
      "ty": 41,
      "x": 45466,
      "y": 8665,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 101296,
      "e": 87580,
      "ty": 2,
      "x": 1030,
      "y": 647
    },
    {
      "t": 101396,
      "e": 87680,
      "ty": 2,
      "x": 1034,
      "y": 647
    },
    {
      "t": 101497,
      "e": 87781,
      "ty": 2,
      "x": 1044,
      "y": 649
    },
    {
      "t": 101497,
      "e": 87781,
      "ty": 41,
      "x": 52823,
      "y": 9207,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 101596,
      "e": 87880,
      "ty": 2,
      "x": 1055,
      "y": 655
    },
    {
      "t": 101696,
      "e": 87980,
      "ty": 2,
      "x": 1064,
      "y": 662
    },
    {
      "t": 101746,
      "e": 88030,
      "ty": 41,
      "x": 65400,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 101797,
      "e": 88081,
      "ty": 2,
      "x": 1065,
      "y": 676
    },
    {
      "t": 101896,
      "e": 88180,
      "ty": 2,
      "x": 1052,
      "y": 707
    },
    {
      "t": 101996,
      "e": 88280,
      "ty": 2,
      "x": 1043,
      "y": 723
    },
    {
      "t": 101997,
      "e": 88281,
      "ty": 41,
      "x": 55613,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 102096,
      "e": 88380,
      "ty": 2,
      "x": 1037,
      "y": 731
    },
    {
      "t": 102197,
      "e": 88481,
      "ty": 2,
      "x": 1013,
      "y": 742
    },
    {
      "t": 102246,
      "e": 88530,
      "ty": 41,
      "x": 40245,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 102297,
      "e": 88581,
      "ty": 2,
      "x": 976,
      "y": 754
    },
    {
      "t": 102396,
      "e": 88680,
      "ty": 2,
      "x": 960,
      "y": 756
    },
    {
      "t": 102496,
      "e": 88780,
      "ty": 2,
      "x": 908,
      "y": 762
    },
    {
      "t": 102496,
      "e": 88780,
      "ty": 41,
      "x": 36125,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 102596,
      "e": 88880,
      "ty": 2,
      "x": 866,
      "y": 768
    },
    {
      "t": 102696,
      "e": 88980,
      "ty": 2,
      "x": 858,
      "y": 771
    },
    {
      "t": 102747,
      "e": 89031,
      "ty": 41,
      "x": 7256,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 102796,
      "e": 89080,
      "ty": 2,
      "x": 848,
      "y": 777
    },
    {
      "t": 102877,
      "e": 89161,
      "ty": 6,
      "x": 837,
      "y": 782,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 102896,
      "e": 89180,
      "ty": 2,
      "x": 836,
      "y": 783
    },
    {
      "t": 102996,
      "e": 89280,
      "ty": 2,
      "x": 835,
      "y": 783
    },
    {
      "t": 102996,
      "e": 89280,
      "ty": 41,
      "x": 43243,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 103093,
      "e": 89377,
      "ty": 3,
      "x": 835,
      "y": 783,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 103094,
      "e": 89378,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 103094,
      "e": 89378,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 103212,
      "e": 89496,
      "ty": 4,
      "x": 43243,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 103212,
      "e": 89496,
      "ty": 5,
      "x": 835,
      "y": 783,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 103212,
      "e": 89496,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf",
      "v": "Engineering"
    },
    {
      "t": 103461,
      "e": 89745,
      "ty": 7,
      "x": 842,
      "y": 783,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 103496,
      "e": 89780,
      "ty": 2,
      "x": 941,
      "y": 759
    },
    {
      "t": 103496,
      "e": 89780,
      "ty": 41,
      "x": 49894,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 103596,
      "e": 89880,
      "ty": 2,
      "x": 1353,
      "y": 693
    },
    {
      "t": 103696,
      "e": 89980,
      "ty": 2,
      "x": 1357,
      "y": 692
    },
    {
      "t": 103747,
      "e": 90031,
      "ty": 41,
      "x": 46456,
      "y": 37891,
      "ta": "html > body"
    },
    {
      "t": 105096,
      "e": 91380,
      "ty": 2,
      "x": 1299,
      "y": 700
    },
    {
      "t": 105196,
      "e": 91480,
      "ty": 2,
      "x": 1202,
      "y": 703
    },
    {
      "t": 105246,
      "e": 91530,
      "ty": 41,
      "x": 40188,
      "y": 38501,
      "ta": "html > body"
    },
    {
      "t": 105296,
      "e": 91580,
      "ty": 2,
      "x": 1162,
      "y": 703
    },
    {
      "t": 105396,
      "e": 91680,
      "ty": 2,
      "x": 1089,
      "y": 704
    },
    {
      "t": 105496,
      "e": 91780,
      "ty": 2,
      "x": 900,
      "y": 704
    },
    {
      "t": 105497,
      "e": 91781,
      "ty": 41,
      "x": 19800,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 105596,
      "e": 91880,
      "ty": 2,
      "x": 884,
      "y": 704
    },
    {
      "t": 105696,
      "e": 91980,
      "ty": 2,
      "x": 875,
      "y": 697
    },
    {
      "t": 105747,
      "e": 91981,
      "ty": 41,
      "x": 11054,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 105796,
      "e": 92030,
      "ty": 2,
      "x": 863,
      "y": 690
    },
    {
      "t": 105896,
      "e": 92130,
      "ty": 2,
      "x": 842,
      "y": 682
    },
    {
      "t": 105930,
      "e": 92164,
      "ty": 6,
      "x": 838,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 105997,
      "e": 92231,
      "ty": 2,
      "x": 835,
      "y": 679
    },
    {
      "t": 105997,
      "e": 92231,
      "ty": 41,
      "x": 43243,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 106102,
      "e": 92336,
      "ty": 3,
      "x": 835,
      "y": 679,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 106102,
      "e": 92336,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 106103,
      "e": 92337,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 106252,
      "e": 92486,
      "ty": 4,
      "x": 43243,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 106252,
      "e": 92486,
      "ty": 5,
      "x": 835,
      "y": 679,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 106253,
      "e": 92487,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 106565,
      "e": 92799,
      "ty": 7,
      "x": 836,
      "y": 683,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 106596,
      "e": 92830,
      "ty": 2,
      "x": 837,
      "y": 690
    },
    {
      "t": 106629,
      "e": 92863,
      "ty": 6,
      "x": 839,
      "y": 699,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 106646,
      "e": 92880,
      "ty": 7,
      "x": 841,
      "y": 702,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 106696,
      "e": 92930,
      "ty": 2,
      "x": 844,
      "y": 712
    },
    {
      "t": 106746,
      "e": 92980,
      "ty": 41,
      "x": 5666,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 106797,
      "e": 93031,
      "ty": 2,
      "x": 843,
      "y": 742
    },
    {
      "t": 106897,
      "e": 93131,
      "ty": 2,
      "x": 843,
      "y": 752
    },
    {
      "t": 106996,
      "e": 93230,
      "ty": 2,
      "x": 843,
      "y": 764
    },
    {
      "t": 106996,
      "e": 93230,
      "ty": 41,
      "x": 9003,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 107096,
      "e": 93330,
      "ty": 2,
      "x": 844,
      "y": 778
    },
    {
      "t": 107196,
      "e": 93430,
      "ty": 2,
      "x": 846,
      "y": 781
    },
    {
      "t": 107247,
      "e": 93481,
      "ty": 41,
      "x": 14319,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 107296,
      "e": 93530,
      "ty": 2,
      "x": 847,
      "y": 789
    },
    {
      "t": 107396,
      "e": 93630,
      "ty": 2,
      "x": 843,
      "y": 789
    },
    {
      "t": 107448,
      "e": 93682,
      "ty": 6,
      "x": 839,
      "y": 788,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 107497,
      "e": 93731,
      "ty": 2,
      "x": 838,
      "y": 787
    },
    {
      "t": 107497,
      "e": 93731,
      "ty": 41,
      "x": 58367,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 107709,
      "e": 93943,
      "ty": 7,
      "x": 842,
      "y": 789,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 107746,
      "e": 93980,
      "ty": 41,
      "x": 12639,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 107796,
      "e": 94030,
      "ty": 2,
      "x": 848,
      "y": 791
    },
    {
      "t": 107996,
      "e": 94230,
      "ty": 41,
      "x": 14879,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 108296,
      "e": 94530,
      "ty": 2,
      "x": 850,
      "y": 791
    },
    {
      "t": 108396,
      "e": 94630,
      "ty": 2,
      "x": 866,
      "y": 842
    },
    {
      "t": 108496,
      "e": 94730,
      "ty": 2,
      "x": 879,
      "y": 871
    },
    {
      "t": 108496,
      "e": 94730,
      "ty": 41,
      "x": 13664,
      "y": 53055,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 108596,
      "e": 94830,
      "ty": 2,
      "x": 879,
      "y": 901
    },
    {
      "t": 108696,
      "e": 94930,
      "ty": 2,
      "x": 877,
      "y": 928
    },
    {
      "t": 108746,
      "e": 94980,
      "ty": 41,
      "x": 61797,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 108796,
      "e": 95030,
      "ty": 2,
      "x": 878,
      "y": 934
    },
    {
      "t": 108896,
      "e": 95130,
      "ty": 2,
      "x": 867,
      "y": 933
    },
    {
      "t": 108997,
      "e": 95231,
      "ty": 2,
      "x": 865,
      "y": 933
    },
    {
      "t": 108997,
      "e": 95231,
      "ty": 41,
      "x": 47598,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 109030,
      "e": 95264,
      "ty": 3,
      "x": 865,
      "y": 933,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 109031,
      "e": 95265,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 109100,
      "e": 95334,
      "ty": 4,
      "x": 47598,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 109100,
      "e": 95334,
      "ty": 5,
      "x": 865,
      "y": 933,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 109101,
      "e": 95335,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 109101,
      "e": 95335,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 109196,
      "e": 95430,
      "ty": 2,
      "x": 861,
      "y": 954
    },
    {
      "t": 109246,
      "e": 95480,
      "ty": 41,
      "x": 53188,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 109250,
      "e": 95481,
      "ty": 6,
      "x": 882,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 109296,
      "e": 95527,
      "ty": 2,
      "x": 904,
      "y": 1032
    },
    {
      "t": 109299,
      "e": 95530,
      "ty": 7,
      "x": 912,
      "y": 1039,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 109396,
      "e": 95627,
      "ty": 2,
      "x": 929,
      "y": 1052
    },
    {
      "t": 109496,
      "e": 95727,
      "ty": 2,
      "x": 909,
      "y": 1045
    },
    {
      "t": 109496,
      "e": 95727,
      "ty": 41,
      "x": 31028,
      "y": 57446,
      "ta": "html > body"
    },
    {
      "t": 109549,
      "e": 95780,
      "ty": 6,
      "x": 903,
      "y": 1037,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 109597,
      "e": 95828,
      "ty": 2,
      "x": 902,
      "y": 1035
    },
    {
      "t": 109697,
      "e": 95928,
      "ty": 2,
      "x": 900,
      "y": 1029
    },
    {
      "t": 109747,
      "e": 95978,
      "ty": 41,
      "x": 35859,
      "y": 41704,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 109796,
      "e": 96027,
      "ty": 2,
      "x": 897,
      "y": 1024
    },
    {
      "t": 109896,
      "e": 96127,
      "ty": 2,
      "x": 891,
      "y": 1020
    },
    {
      "t": 109997,
      "e": 96228,
      "ty": 41,
      "x": 31736,
      "y": 29788,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 110784,
      "e": 97015,
      "ty": 7,
      "x": 933,
      "y": 992,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 110796,
      "e": 97027,
      "ty": 2,
      "x": 933,
      "y": 992
    },
    {
      "t": 110897,
      "e": 97128,
      "ty": 2,
      "x": 1025,
      "y": 713
    },
    {
      "t": 110996,
      "e": 97227,
      "ty": 2,
      "x": 967,
      "y": 653
    },
    {
      "t": 110997,
      "e": 97228,
      "ty": 41,
      "x": 34549,
      "y": 10290,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 111096,
      "e": 97327,
      "ty": 2,
      "x": 945,
      "y": 663
    },
    {
      "t": 111197,
      "e": 97428,
      "ty": 2,
      "x": 868,
      "y": 733
    },
    {
      "t": 111246,
      "e": 97477,
      "ty": 41,
      "x": 8586,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 111296,
      "e": 97527,
      "ty": 2,
      "x": 813,
      "y": 790
    },
    {
      "t": 111396,
      "e": 97627,
      "ty": 2,
      "x": 813,
      "y": 796
    },
    {
      "t": 111496,
      "e": 97727,
      "ty": 2,
      "x": 819,
      "y": 796
    },
    {
      "t": 111496,
      "e": 97727,
      "ty": 41,
      "x": 27928,
      "y": 43653,
      "ta": "html > body"
    },
    {
      "t": 111556,
      "e": 97787,
      "ty": 6,
      "x": 826,
      "y": 791,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 111596,
      "e": 97827,
      "ty": 2,
      "x": 826,
      "y": 791
    },
    {
      "t": 111746,
      "e": 97977,
      "ty": 41,
      "x": 0,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 111764,
      "e": 97995,
      "ty": 3,
      "x": 826,
      "y": 791,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 111764,
      "e": 97995,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 111764,
      "e": 97995,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 111868,
      "e": 98099,
      "ty": 4,
      "x": 0,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 111868,
      "e": 98099,
      "ty": 5,
      "x": 826,
      "y": 791,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 111868,
      "e": 98099,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf",
      "v": "Engineering"
    },
    {
      "t": 111996,
      "e": 98227,
      "ty": 2,
      "x": 834,
      "y": 789
    },
    {
      "t": 111996,
      "e": 98227,
      "ty": 41,
      "x": 38202,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 112017,
      "e": 98248,
      "ty": 7,
      "x": 840,
      "y": 789,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 112096,
      "e": 98327,
      "ty": 2,
      "x": 846,
      "y": 789
    },
    {
      "t": 112196,
      "e": 98427,
      "ty": 2,
      "x": 847,
      "y": 789
    },
    {
      "t": 112247,
      "e": 98478,
      "ty": 41,
      "x": 14319,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 112396,
      "e": 98627,
      "ty": 2,
      "x": 860,
      "y": 784
    },
    {
      "t": 112496,
      "e": 98727,
      "ty": 2,
      "x": 864,
      "y": 773
    },
    {
      "t": 112497,
      "e": 98728,
      "ty": 41,
      "x": 10104,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 112597,
      "e": 98828,
      "ty": 2,
      "x": 869,
      "y": 762
    },
    {
      "t": 112697,
      "e": 98928,
      "ty": 2,
      "x": 885,
      "y": 748
    },
    {
      "t": 112747,
      "e": 98978,
      "ty": 41,
      "x": 15088,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 112796,
      "e": 99027,
      "ty": 2,
      "x": 887,
      "y": 748
    },
    {
      "t": 112997,
      "e": 99228,
      "ty": 41,
      "x": 15563,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 113097,
      "e": 99328,
      "ty": 2,
      "x": 900,
      "y": 741
    },
    {
      "t": 113196,
      "e": 99427,
      "ty": 2,
      "x": 904,
      "y": 735
    },
    {
      "t": 113246,
      "e": 99477,
      "ty": 41,
      "x": 21227,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 113296,
      "e": 99527,
      "ty": 2,
      "x": 906,
      "y": 711
    },
    {
      "t": 113397,
      "e": 99628,
      "ty": 2,
      "x": 903,
      "y": 691
    },
    {
      "t": 113496,
      "e": 99727,
      "ty": 2,
      "x": 899,
      "y": 680
    },
    {
      "t": 113497,
      "e": 99728,
      "ty": 41,
      "x": 20829,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 113596,
      "e": 99827,
      "ty": 2,
      "x": 865,
      "y": 731
    },
    {
      "t": 113696,
      "e": 99927,
      "ty": 2,
      "x": 837,
      "y": 879
    },
    {
      "t": 113746,
      "e": 99977,
      "ty": 41,
      "x": 3934,
      "y": 22181,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 113797,
      "e": 100028,
      "ty": 2,
      "x": 842,
      "y": 930
    },
    {
      "t": 113896,
      "e": 100127,
      "ty": 2,
      "x": 892,
      "y": 984
    },
    {
      "t": 113936,
      "e": 100167,
      "ty": 6,
      "x": 906,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 113997,
      "e": 100228,
      "ty": 2,
      "x": 912,
      "y": 1016
    },
    {
      "t": 113997,
      "e": 100228,
      "ty": 41,
      "x": 42559,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 114096,
      "e": 100327,
      "ty": 2,
      "x": 913,
      "y": 1023
    },
    {
      "t": 114247,
      "e": 100478,
      "ty": 41,
      "x": 43075,
      "y": 35746,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 114333,
      "e": 100564,
      "ty": 3,
      "x": 913,
      "y": 1023,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 114336,
      "e": 100567,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 114336,
      "e": 100567,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 114436,
      "e": 100667,
      "ty": 4,
      "x": 43075,
      "y": 35746,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 114436,
      "e": 100667,
      "ty": 5,
      "x": 913,
      "y": 1023,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 114438,
      "e": 100669,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 114439,
      "e": 100670,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 114440,
      "e": 100671,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 115773,
      "e": 102004,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 115896,
      "e": 102127,
      "ty": 2,
      "x": 913,
      "y": 1022
    },
    {
      "t": 115997,
      "e": 102228,
      "ty": 41,
      "x": 30479,
      "y": 62025,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 116197,
      "e": 102428,
      "ty": 2,
      "x": 913,
      "y": 1019
    },
    {
      "t": 116246,
      "e": 102477,
      "ty": 41,
      "x": 30430,
      "y": 61609,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 116297,
      "e": 102528,
      "ty": 2,
      "x": 912,
      "y": 1014
    },
    {
      "t": 116496,
      "e": 102727,
      "ty": 2,
      "x": 908,
      "y": 1007
    },
    {
      "t": 116497,
      "e": 102728,
      "ty": 41,
      "x": 30233,
      "y": 60986,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 116596,
      "e": 102827,
      "ty": 2,
      "x": 839,
      "y": 943
    },
    {
      "t": 116697,
      "e": 102928,
      "ty": 2,
      "x": 601,
      "y": 808
    },
    {
      "t": 116747,
      "e": 102978,
      "ty": 41,
      "x": 13064,
      "y": 53437,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 116796,
      "e": 103027,
      "ty": 2,
      "x": 541,
      "y": 796
    },
    {
      "t": 116897,
      "e": 103128,
      "ty": 2,
      "x": 525,
      "y": 781
    },
    {
      "t": 116996,
      "e": 103227,
      "ty": 2,
      "x": 712,
      "y": 611
    },
    {
      "t": 116996,
      "e": 103227,
      "ty": 41,
      "x": 20591,
      "y": 50132,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 117096,
      "e": 103327,
      "ty": 2,
      "x": 833,
      "y": 521
    },
    {
      "t": 117197,
      "e": 103428,
      "ty": 2,
      "x": 833,
      "y": 520
    },
    {
      "t": 117247,
      "e": 103478,
      "ty": 41,
      "x": 27380,
      "y": 11123,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 117297,
      "e": 103528,
      "ty": 2,
      "x": 882,
      "y": 491
    },
    {
      "t": 117396,
      "e": 103627,
      "ty": 2,
      "x": 898,
      "y": 483
    },
    {
      "t": 117497,
      "e": 103728,
      "ty": 2,
      "x": 899,
      "y": 482
    },
    {
      "t": 117497,
      "e": 103728,
      "ty": 41,
      "x": 29791,
      "y": 17080,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 117747,
      "e": 103978,
      "ty": 41,
      "x": 29889,
      "y": 17080,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 117796,
      "e": 104027,
      "ty": 2,
      "x": 905,
      "y": 483
    },
    {
      "t": 117896,
      "e": 104127,
      "ty": 2,
      "x": 913,
      "y": 489
    },
    {
      "t": 117996,
      "e": 104227,
      "ty": 2,
      "x": 914,
      "y": 490
    },
    {
      "t": 117996,
      "e": 104227,
      "ty": 41,
      "x": 30529,
      "y": 2931,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 118097,
      "e": 104328,
      "ty": 2,
      "x": 915,
      "y": 492
    },
    {
      "t": 118247,
      "e": 104478,
      "ty": 41,
      "x": 30578,
      "y": 3711,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 118497,
      "e": 104728,
      "ty": 2,
      "x": 915,
      "y": 495
    },
    {
      "t": 118497,
      "e": 104728,
      "ty": 41,
      "x": 30578,
      "y": 4882,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 118697,
      "e": 104928,
      "ty": 2,
      "x": 916,
      "y": 496
    },
    {
      "t": 118747,
      "e": 104978,
      "ty": 41,
      "x": 30627,
      "y": 5272,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 119697,
      "e": 105928,
      "ty": 2,
      "x": 924,
      "y": 543
    },
    {
      "t": 119747,
      "e": 105978,
      "ty": 41,
      "x": 32890,
      "y": 53643,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 119796,
      "e": 106027,
      "ty": 2,
      "x": 1024,
      "y": 700
    },
    {
      "t": 119897,
      "e": 106128,
      "ty": 2,
      "x": 1083,
      "y": 783
    },
    {
      "t": 119996,
      "e": 106227,
      "ty": 2,
      "x": 1088,
      "y": 793
    },
    {
      "t": 119996,
      "e": 106227,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 119999,
      "e": 106230,
      "ty": 41,
      "x": 39089,
      "y": 53089,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 120097,
      "e": 106328,
      "ty": 2,
      "x": 1099,
      "y": 799
    },
    {
      "t": 120247,
      "e": 106478,
      "ty": 41,
      "x": 39630,
      "y": 603,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 120697,
      "e": 106928,
      "ty": 2,
      "x": 1092,
      "y": 894
    },
    {
      "t": 120747,
      "e": 106978,
      "ty": 41,
      "x": 39236,
      "y": 56969,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 120796,
      "e": 107027,
      "ty": 2,
      "x": 1087,
      "y": 962
    },
    {
      "t": 120896,
      "e": 107127,
      "ty": 2,
      "x": 1076,
      "y": 994
    },
    {
      "t": 120997,
      "e": 107228,
      "ty": 2,
      "x": 1063,
      "y": 1009
    },
    {
      "t": 120997,
      "e": 107228,
      "ty": 41,
      "x": 37859,
      "y": 61124,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 121097,
      "e": 107328,
      "ty": 2,
      "x": 1054,
      "y": 1038
    },
    {
      "t": 121197,
      "e": 107428,
      "ty": 2,
      "x": 1046,
      "y": 1054
    },
    {
      "t": 121246,
      "e": 107477,
      "ty": 41,
      "x": 36777,
      "y": 64725,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 121297,
      "e": 107528,
      "ty": 2,
      "x": 1035,
      "y": 1068
    },
    {
      "t": 121497,
      "e": 107728,
      "ty": 41,
      "x": 36481,
      "y": 65210,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 121596,
      "e": 107827,
      "ty": 2,
      "x": 1030,
      "y": 1065
    },
    {
      "t": 121696,
      "e": 107927,
      "ty": 2,
      "x": 401,
      "y": 838
    },
    {
      "t": 121747,
      "e": 107978,
      "ty": 41,
      "x": 1010,
      "y": 16987,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 121796,
      "e": 108027,
      "ty": 2,
      "x": 311,
      "y": 811
    },
    {
      "t": 121897,
      "e": 108128,
      "ty": 2,
      "x": 365,
      "y": 698
    },
    {
      "t": 121997,
      "e": 108228,
      "ty": 2,
      "x": 384,
      "y": 533
    },
    {
      "t": 121997,
      "e": 108228,
      "ty": 41,
      "x": 4454,
      "y": 19705,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 122097,
      "e": 108328,
      "ty": 2,
      "x": 392,
      "y": 438
    },
    {
      "t": 122197,
      "e": 108428,
      "ty": 2,
      "x": 436,
      "y": 398
    },
    {
      "t": 122247,
      "e": 108478,
      "ty": 41,
      "x": 10309,
      "y": 3649,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 122297,
      "e": 108528,
      "ty": 2,
      "x": 523,
      "y": 370
    },
    {
      "t": 122397,
      "e": 108628,
      "ty": 2,
      "x": 536,
      "y": 377
    },
    {
      "t": 122469,
      "e": 108700,
      "ty": 3,
      "x": 536,
      "y": 377,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 122497,
      "e": 108728,
      "ty": 41,
      "x": 11932,
      "y": 4922,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 122597,
      "e": 108828,
      "ty": 2,
      "x": 542,
      "y": 384
    },
    {
      "t": 122696,
      "e": 108927,
      "ty": 2,
      "x": 977,
      "y": 520
    },
    {
      "t": 122747,
      "e": 108978,
      "ty": 41,
      "x": 48485,
      "y": 19315,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 122797,
      "e": 109028,
      "ty": 2,
      "x": 1354,
      "y": 531
    },
    {
      "t": 122897,
      "e": 109128,
      "ty": 2,
      "x": 1364,
      "y": 531
    },
    {
      "t": 122997,
      "e": 109228,
      "ty": 2,
      "x": 1457,
      "y": 626
    },
    {
      "t": 122997,
      "e": 109228,
      "ty": 41,
      "x": 57243,
      "y": 55983,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 123097,
      "e": 109328,
      "ty": 2,
      "x": 1561,
      "y": 741
    },
    {
      "t": 123197,
      "e": 109428,
      "ty": 2,
      "x": 1575,
      "y": 756
    },
    {
      "t": 123246,
      "e": 109477,
      "ty": 41,
      "x": 63294,
      "y": 53548,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 123297,
      "e": 109528,
      "ty": 2,
      "x": 1584,
      "y": 765
    },
    {
      "t": 123397,
      "e": 109628,
      "ty": 2,
      "x": 1610,
      "y": 848
    },
    {
      "t": 123496,
      "e": 109727,
      "ty": 2,
      "x": 1618,
      "y": 879
    },
    {
      "t": 123497,
      "e": 109728,
      "ty": 41,
      "x": 65163,
      "y": 15250,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 123828,
      "e": 110059,
      "ty": 4,
      "x": 65163,
      "y": 15250,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 123830,
      "e": 110061,
      "ty": 5,
      "x": 1618,
      "y": 879,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 123897,
      "e": 110128,
      "ty": 2,
      "x": 1617,
      "y": 879
    },
    {
      "t": 123997,
      "e": 110228,
      "ty": 2,
      "x": 1453,
      "y": 870
    },
    {
      "t": 123997,
      "e": 110228,
      "ty": 41,
      "x": 57046,
      "y": 62005,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 124096,
      "e": 110327,
      "ty": 2,
      "x": 1370,
      "y": 855
    },
    {
      "t": 124197,
      "e": 110428,
      "ty": 2,
      "x": 1361,
      "y": 851
    },
    {
      "t": 124247,
      "e": 110478,
      "ty": 41,
      "x": 52372,
      "y": 57946,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 124297,
      "e": 110528,
      "ty": 2,
      "x": 1351,
      "y": 843
    },
    {
      "t": 124397,
      "e": 110628,
      "ty": 2,
      "x": 1345,
      "y": 838
    },
    {
      "t": 124498,
      "e": 110729,
      "ty": 41,
      "x": 51732,
      "y": 46243,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 124604,
      "e": 110835,
      "ty": 3,
      "x": 1345,
      "y": 838,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 124780,
      "e": 111011,
      "ty": 4,
      "x": 51732,
      "y": 46243,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 124781,
      "e": 111012,
      "ty": 5,
      "x": 1345,
      "y": 838,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 124997,
      "e": 111228,
      "ty": 2,
      "x": 1318,
      "y": 838
    },
    {
      "t": 124998,
      "e": 111229,
      "ty": 41,
      "x": 50404,
      "y": 46243,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 125097,
      "e": 111328,
      "ty": 2,
      "x": 1125,
      "y": 867
    },
    {
      "t": 125197,
      "e": 111428,
      "ty": 2,
      "x": 1109,
      "y": 876
    },
    {
      "t": 125247,
      "e": 111478,
      "ty": 41,
      "x": 40122,
      "y": 8228,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 125796,
      "e": 112027,
      "ty": 2,
      "x": 1107,
      "y": 895
    },
    {
      "t": 125897,
      "e": 112128,
      "ty": 2,
      "x": 1099,
      "y": 951
    },
    {
      "t": 125996,
      "e": 112227,
      "ty": 2,
      "x": 1074,
      "y": 995
    },
    {
      "t": 125997,
      "e": 112228,
      "ty": 41,
      "x": 38400,
      "y": 60155,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 126097,
      "e": 112328,
      "ty": 2,
      "x": 1047,
      "y": 1033
    },
    {
      "t": 126197,
      "e": 112428,
      "ty": 2,
      "x": 1031,
      "y": 1046
    },
    {
      "t": 126247,
      "e": 112478,
      "ty": 41,
      "x": 36285,
      "y": 63686,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 126296,
      "e": 112527,
      "ty": 2,
      "x": 1025,
      "y": 1049
    },
    {
      "t": 126397,
      "e": 112628,
      "ty": 2,
      "x": 1014,
      "y": 1054
    },
    {
      "t": 126497,
      "e": 112728,
      "ty": 2,
      "x": 1001,
      "y": 1057
    },
    {
      "t": 126497,
      "e": 112728,
      "ty": 41,
      "x": 34809,
      "y": 64448,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 126597,
      "e": 112828,
      "ty": 2,
      "x": 988,
      "y": 1061
    },
    {
      "t": 126697,
      "e": 112928,
      "ty": 2,
      "x": 984,
      "y": 1063
    },
    {
      "t": 126747,
      "e": 112978,
      "ty": 41,
      "x": 33874,
      "y": 64933,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 126797,
      "e": 113028,
      "ty": 2,
      "x": 977,
      "y": 1069
    },
    {
      "t": 126831,
      "e": 113062,
      "ty": 6,
      "x": 976,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 126896,
      "e": 113127,
      "ty": 2,
      "x": 976,
      "y": 1078
    },
    {
      "t": 126997,
      "e": 113228,
      "ty": 2,
      "x": 977,
      "y": 1083
    },
    {
      "t": 126997,
      "e": 113228,
      "ty": 41,
      "x": 36863,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 127097,
      "e": 113328,
      "ty": 2,
      "x": 977,
      "y": 1084
    },
    {
      "t": 127247,
      "e": 113478,
      "ty": 41,
      "x": 36863,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 128221,
      "e": 114452,
      "ty": 3,
      "x": 977,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 128221,
      "e": 114452,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 128844,
      "e": 115075,
      "ty": 4,
      "x": 36863,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 128845,
      "e": 115076,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 128847,
      "e": 115078,
      "ty": 5,
      "x": 977,
      "y": 1084,
      "ta": "#start"
    },
    {
      "t": 128850,
      "e": 115081,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 129881,
      "e": 116112,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 130594,
      "e": 116825,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 131175,
      "e": 117406,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 152202, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 152208, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 11853, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 165400, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 11530, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"juliet\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 177938, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 30330, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 209354, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 10455, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 220812, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 80319, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 302490, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -01 PM-Z -F -Z -Z -F -F -Z -Z -F -A -A -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:998,y:1080,t:1527030350596};\\\", \\\"{x:1018,y:1071,t:1527030350608};\\\", \\\"{x:1160,y:998,t:1527030350625};\\\", \\\"{x:1387,y:866,t:1527030350642};\\\", \\\"{x:1659,y:706,t:1527030350658};\\\", \\\"{x:1898,y:610,t:1527030350675};\\\", \\\"{x:1919,y:582,t:1527030350692};\\\", \\\"{x:1919,y:579,t:1527030350708};\\\", \\\"{x:1918,y:579,t:1527030350812};\\\", \\\"{x:1915,y:580,t:1527030350827};\\\", \\\"{x:1914,y:585,t:1527030350844};\\\", \\\"{x:1914,y:586,t:1527030350859};\\\", \\\"{x:1912,y:587,t:1527030350933};\\\", \\\"{x:1906,y:587,t:1527030350944};\\\", \\\"{x:1892,y:587,t:1527030350960};\\\", \\\"{x:1884,y:587,t:1527030350976};\\\", \\\"{x:1867,y:590,t:1527030350992};\\\", \\\"{x:1830,y:590,t:1527030351010};\\\", \\\"{x:1758,y:590,t:1527030351026};\\\", \\\"{x:1677,y:601,t:1527030351043};\\\", \\\"{x:1600,y:611,t:1527030351059};\\\", \\\"{x:1526,y:612,t:1527030351075};\\\", \\\"{x:1496,y:613,t:1527030351093};\\\", \\\"{x:1469,y:617,t:1527030351109};\\\", \\\"{x:1445,y:621,t:1527030351126};\\\", \\\"{x:1433,y:621,t:1527030351143};\\\", \\\"{x:1432,y:621,t:1527030351159};\\\", \\\"{x:1431,y:617,t:1527030351212};\\\", \\\"{x:1431,y:606,t:1527030351226};\\\", \\\"{x:1435,y:580,t:1527030351243};\\\", \\\"{x:1443,y:554,t:1527030351259};\\\", \\\"{x:1452,y:520,t:1527030351276};\\\", \\\"{x:1452,y:509,t:1527030351294};\\\", \\\"{x:1454,y:498,t:1527030351310};\\\", \\\"{x:1455,y:483,t:1527030351327};\\\", \\\"{x:1455,y:469,t:1527030351343};\\\", \\\"{x:1455,y:458,t:1527030351360};\\\", \\\"{x:1452,y:446,t:1527030351376};\\\", \\\"{x:1443,y:439,t:1527030351393};\\\", \\\"{x:1433,y:434,t:1527030351409};\\\", \\\"{x:1421,y:430,t:1527030351426};\\\", \\\"{x:1404,y:429,t:1527030351444};\\\", \\\"{x:1388,y:429,t:1527030351459};\\\", \\\"{x:1374,y:429,t:1527030351476};\\\", \\\"{x:1369,y:431,t:1527030351493};\\\", \\\"{x:1365,y:433,t:1527030351510};\\\", \\\"{x:1358,y:436,t:1527030351527};\\\", \\\"{x:1350,y:440,t:1527030351543};\\\", \\\"{x:1346,y:442,t:1527030351560};\\\", \\\"{x:1340,y:444,t:1527030351576};\\\", \\\"{x:1336,y:447,t:1527030351594};\\\", \\\"{x:1329,y:451,t:1527030351611};\\\", \\\"{x:1316,y:458,t:1527030351627};\\\", \\\"{x:1303,y:467,t:1527030351647};\\\", \\\"{x:1298,y:470,t:1527030351660};\\\", \\\"{x:1293,y:474,t:1527030351676};\\\", \\\"{x:1291,y:475,t:1527030351693};\\\", \\\"{x:1287,y:478,t:1527030351710};\\\", \\\"{x:1284,y:481,t:1527030351726};\\\", \\\"{x:1278,y:483,t:1527030351743};\\\", \\\"{x:1274,y:485,t:1527030351760};\\\", \\\"{x:1267,y:491,t:1527030351776};\\\", \\\"{x:1261,y:495,t:1527030351794};\\\", \\\"{x:1256,y:499,t:1527030351810};\\\", \\\"{x:1254,y:500,t:1527030351826};\\\", \\\"{x:1253,y:501,t:1527030351843};\\\", \\\"{x:1246,y:506,t:1527030351860};\\\", \\\"{x:1238,y:511,t:1527030351876};\\\", \\\"{x:1234,y:514,t:1527030351894};\\\", \\\"{x:1229,y:517,t:1527030351910};\\\", \\\"{x:1227,y:518,t:1527030351927};\\\", \\\"{x:1223,y:520,t:1527030351943};\\\", \\\"{x:1215,y:525,t:1527030351961};\\\", \\\"{x:1204,y:528,t:1527030351977};\\\", \\\"{x:1195,y:531,t:1527030351993};\\\", \\\"{x:1192,y:533,t:1527030352011};\\\", \\\"{x:1189,y:534,t:1527030352028};\\\", \\\"{x:1186,y:535,t:1527030352043};\\\", \\\"{x:1178,y:539,t:1527030352060};\\\", \\\"{x:1175,y:541,t:1527030352078};\\\", \\\"{x:1173,y:542,t:1527030352093};\\\", \\\"{x:1169,y:545,t:1527030352110};\\\", \\\"{x:1164,y:549,t:1527030352128};\\\", \\\"{x:1159,y:552,t:1527030352143};\\\", \\\"{x:1156,y:556,t:1527030352161};\\\", \\\"{x:1150,y:561,t:1527030352178};\\\", \\\"{x:1146,y:565,t:1527030352193};\\\", \\\"{x:1142,y:572,t:1527030352210};\\\", \\\"{x:1142,y:579,t:1527030352227};\\\", \\\"{x:1142,y:584,t:1527030352243};\\\", \\\"{x:1142,y:592,t:1527030352260};\\\", \\\"{x:1142,y:600,t:1527030352278};\\\", \\\"{x:1142,y:613,t:1527030352294};\\\", \\\"{x:1142,y:627,t:1527030352311};\\\", \\\"{x:1144,y:646,t:1527030352328};\\\", \\\"{x:1149,y:672,t:1527030352344};\\\", \\\"{x:1157,y:695,t:1527030352361};\\\", \\\"{x:1167,y:712,t:1527030352378};\\\", \\\"{x:1176,y:724,t:1527030352393};\\\", \\\"{x:1181,y:729,t:1527030352410};\\\", \\\"{x:1184,y:732,t:1527030352428};\\\", \\\"{x:1186,y:734,t:1527030352444};\\\", \\\"{x:1197,y:741,t:1527030352461};\\\", \\\"{x:1204,y:748,t:1527030352478};\\\", \\\"{x:1211,y:754,t:1527030352495};\\\", \\\"{x:1216,y:759,t:1527030352510};\\\", \\\"{x:1220,y:764,t:1527030352528};\\\", \\\"{x:1225,y:768,t:1527030352545};\\\", \\\"{x:1229,y:769,t:1527030352560};\\\", \\\"{x:1230,y:770,t:1527030352578};\\\", \\\"{x:1231,y:770,t:1527030352595};\\\", \\\"{x:1231,y:771,t:1527030352611};\\\", \\\"{x:1232,y:771,t:1527030352629};\\\", \\\"{x:1236,y:769,t:1527030352644};\\\", \\\"{x:1241,y:763,t:1527030352661};\\\", \\\"{x:1252,y:747,t:1527030352678};\\\", \\\"{x:1264,y:719,t:1527030352694};\\\", \\\"{x:1289,y:666,t:1527030352711};\\\", \\\"{x:1322,y:579,t:1527030352728};\\\", \\\"{x:1349,y:520,t:1527030352745};\\\", \\\"{x:1362,y:478,t:1527030352761};\\\", \\\"{x:1382,y:436,t:1527030352778};\\\", \\\"{x:1398,y:395,t:1527030352795};\\\", \\\"{x:1405,y:362,t:1527030352811};\\\", \\\"{x:1408,y:334,t:1527030352827};\\\", \\\"{x:1410,y:307,t:1527030352844};\\\", \\\"{x:1411,y:297,t:1527030352862};\\\", \\\"{x:1411,y:290,t:1527030352878};\\\", \\\"{x:1411,y:285,t:1527030352895};\\\", \\\"{x:1408,y:276,t:1527030352912};\\\", \\\"{x:1405,y:267,t:1527030352928};\\\", \\\"{x:1404,y:255,t:1527030352945};\\\", \\\"{x:1403,y:246,t:1527030352961};\\\", \\\"{x:1402,y:241,t:1527030352977};\\\", \\\"{x:1401,y:240,t:1527030352995};\\\", \\\"{x:1400,y:240,t:1527030353077};\\\", \\\"{x:1396,y:248,t:1527030353095};\\\", \\\"{x:1395,y:253,t:1527030353112};\\\", \\\"{x:1393,y:256,t:1527030353128};\\\", \\\"{x:1393,y:257,t:1527030353144};\\\", \\\"{x:1394,y:258,t:1527030353293};\\\", \\\"{x:1398,y:256,t:1527030353300};\\\", \\\"{x:1402,y:252,t:1527030353312};\\\", \\\"{x:1413,y:242,t:1527030353328};\\\", \\\"{x:1421,y:235,t:1527030353344};\\\", \\\"{x:1427,y:229,t:1527030353361};\\\", \\\"{x:1432,y:225,t:1527030353378};\\\", \\\"{x:1438,y:219,t:1527030353394};\\\", \\\"{x:1455,y:215,t:1527030353411};\\\", \\\"{x:1486,y:207,t:1527030353428};\\\", \\\"{x:1510,y:204,t:1527030353444};\\\", \\\"{x:1530,y:204,t:1527030353461};\\\", \\\"{x:1541,y:204,t:1527030353478};\\\", \\\"{x:1544,y:204,t:1527030353494};\\\", \\\"{x:1545,y:204,t:1527030353604};\\\", \\\"{x:1545,y:206,t:1527030353612};\\\", \\\"{x:1544,y:209,t:1527030353627};\\\", \\\"{x:1543,y:210,t:1527030353644};\\\", \\\"{x:1543,y:212,t:1527030353661};\\\", \\\"{x:1541,y:214,t:1527030353678};\\\", \\\"{x:1540,y:215,t:1527030353695};\\\", \\\"{x:1539,y:215,t:1527030353829};\\\", \\\"{x:1532,y:216,t:1527030353845};\\\", \\\"{x:1525,y:217,t:1527030353862};\\\", \\\"{x:1523,y:217,t:1527030353879};\\\", \\\"{x:1519,y:217,t:1527030353896};\\\", \\\"{x:1513,y:217,t:1527030353912};\\\", \\\"{x:1506,y:217,t:1527030353929};\\\", \\\"{x:1503,y:217,t:1527030353946};\\\", \\\"{x:1500,y:217,t:1527030353962};\\\", \\\"{x:1497,y:216,t:1527030353979};\\\", \\\"{x:1494,y:213,t:1527030353995};\\\", \\\"{x:1492,y:210,t:1527030354012};\\\", \\\"{x:1488,y:205,t:1527030354029};\\\", \\\"{x:1487,y:203,t:1527030354046};\\\", \\\"{x:1485,y:201,t:1527030354062};\\\", \\\"{x:1483,y:199,t:1527030354079};\\\", \\\"{x:1482,y:195,t:1527030354096};\\\", \\\"{x:1482,y:190,t:1527030354112};\\\", \\\"{x:1482,y:185,t:1527030354129};\\\", \\\"{x:1482,y:178,t:1527030354145};\\\", \\\"{x:1482,y:174,t:1527030354163};\\\", \\\"{x:1482,y:170,t:1527030354178};\\\", \\\"{x:1482,y:169,t:1527030354195};\\\", \\\"{x:1482,y:168,t:1527030354220};\\\", \\\"{x:1482,y:170,t:1527030354518};\\\", \\\"{x:1482,y:173,t:1527030354528};\\\", \\\"{x:1482,y:179,t:1527030354545};\\\", \\\"{x:1482,y:186,t:1527030354562};\\\", \\\"{x:1482,y:192,t:1527030354579};\\\", \\\"{x:1482,y:197,t:1527030354595};\\\", \\\"{x:1482,y:201,t:1527030354612};\\\", \\\"{x:1482,y:204,t:1527030354628};\\\", \\\"{x:1482,y:208,t:1527030354646};\\\", \\\"{x:1482,y:211,t:1527030354662};\\\", \\\"{x:1481,y:214,t:1527030354679};\\\", \\\"{x:1480,y:216,t:1527030354695};\\\", \\\"{x:1479,y:221,t:1527030354712};\\\", \\\"{x:1478,y:222,t:1527030354729};\\\", \\\"{x:1477,y:225,t:1527030354745};\\\", \\\"{x:1476,y:227,t:1527030354765};\\\", \\\"{x:1475,y:228,t:1527030354796};\\\", \\\"{x:1471,y:231,t:1527030355741};\\\", \\\"{x:1461,y:238,t:1527030355748};\\\", \\\"{x:1452,y:245,t:1527030355764};\\\", \\\"{x:1431,y:258,t:1527030355780};\\\", \\\"{x:1382,y:288,t:1527030355797};\\\", \\\"{x:1307,y:325,t:1527030355814};\\\", \\\"{x:1191,y:378,t:1527030355830};\\\", \\\"{x:1072,y:431,t:1527030355847};\\\", \\\"{x:946,y:476,t:1527030355864};\\\", \\\"{x:844,y:523,t:1527030355881};\\\", \\\"{x:761,y:561,t:1527030355898};\\\", \\\"{x:692,y:592,t:1527030355914};\\\", \\\"{x:634,y:625,t:1527030355931};\\\", \\\"{x:608,y:646,t:1527030355946};\\\", \\\"{x:596,y:661,t:1527030355963};\\\", \\\"{x:593,y:675,t:1527030355980};\\\", \\\"{x:593,y:678,t:1527030355996};\\\", \\\"{x:593,y:679,t:1527030356013};\\\", \\\"{x:593,y:678,t:1527030357157};\\\", \\\"{x:593,y:676,t:1527030357173};\\\", \\\"{x:593,y:675,t:1527030357189};\\\", \\\"{x:593,y:673,t:1527030357199};\\\", \\\"{x:594,y:671,t:1527030357215};\\\", \\\"{x:594,y:668,t:1527030357232};\\\", \\\"{x:594,y:666,t:1527030357248};\\\", \\\"{x:596,y:663,t:1527030357265};\\\", \\\"{x:596,y:661,t:1527030357282};\\\", \\\"{x:597,y:659,t:1527030357299};\\\", \\\"{x:597,y:658,t:1527030357315};\\\", \\\"{x:598,y:656,t:1527030357332};\\\", \\\"{x:599,y:653,t:1527030357348};\\\", \\\"{x:599,y:651,t:1527030357372};\\\", \\\"{x:601,y:648,t:1527030357383};\\\", \\\"{x:608,y:640,t:1527030357399};\\\", \\\"{x:614,y:632,t:1527030357416};\\\", \\\"{x:623,y:623,t:1527030357431};\\\", \\\"{x:630,y:615,t:1527030357448};\\\", \\\"{x:633,y:613,t:1527030357466};\\\", \\\"{x:634,y:611,t:1527030357482};\\\", \\\"{x:635,y:610,t:1527030357498};\\\", \\\"{x:636,y:609,t:1527030357514};\\\", \\\"{x:635,y:605,t:1527030357765};\\\", \\\"{x:631,y:601,t:1527030357781};\\\", \\\"{x:622,y:595,t:1527030357799};\\\", \\\"{x:612,y:586,t:1527030357815};\\\", \\\"{x:600,y:577,t:1527030357832};\\\", \\\"{x:590,y:568,t:1527030357849};\\\", \\\"{x:581,y:560,t:1527030357866};\\\", \\\"{x:570,y:551,t:1527030357881};\\\", \\\"{x:556,y:539,t:1527030357899};\\\", \\\"{x:545,y:527,t:1527030357916};\\\", \\\"{x:539,y:521,t:1527030357931};\\\", \\\"{x:533,y:515,t:1527030357948};\\\", \\\"{x:528,y:511,t:1527030357965};\\\", \\\"{x:524,y:506,t:1527030357982};\\\", \\\"{x:521,y:502,t:1527030357999};\\\", \\\"{x:520,y:498,t:1527030358016};\\\", \\\"{x:519,y:497,t:1527030358031};\\\", \\\"{x:518,y:495,t:1527030358049};\\\", \\\"{x:518,y:492,t:1527030358064};\\\", \\\"{x:518,y:489,t:1527030358081};\\\", \\\"{x:518,y:484,t:1527030358099};\\\", \\\"{x:520,y:482,t:1527030358114};\\\", \\\"{x:521,y:481,t:1527030358132};\\\", \\\"{x:523,y:480,t:1527030358573};\\\", \\\"{x:525,y:478,t:1527030358581};\\\", \\\"{x:533,y:472,t:1527030358598};\\\", \\\"{x:541,y:468,t:1527030358615};\\\", \\\"{x:547,y:465,t:1527030358631};\\\", \\\"{x:552,y:463,t:1527030358648};\\\", \\\"{x:557,y:460,t:1527030358665};\\\", \\\"{x:564,y:455,t:1527030358682};\\\", \\\"{x:576,y:450,t:1527030358698};\\\", \\\"{x:585,y:446,t:1527030358715};\\\", \\\"{x:599,y:442,t:1527030358732};\\\", \\\"{x:602,y:440,t:1527030358748};\\\", \\\"{x:605,y:440,t:1527030358765};\\\", \\\"{x:607,y:439,t:1527030358781};\\\", \\\"{x:608,y:439,t:1527030358797};\\\", \\\"{x:613,y:438,t:1527030358815};\\\", \\\"{x:621,y:435,t:1527030358832};\\\", \\\"{x:651,y:431,t:1527030358848};\\\", \\\"{x:691,y:426,t:1527030358865};\\\", \\\"{x:725,y:421,t:1527030358882};\\\", \\\"{x:757,y:416,t:1527030358898};\\\", \\\"{x:781,y:415,t:1527030358915};\\\", \\\"{x:809,y:415,t:1527030358932};\\\", \\\"{x:816,y:415,t:1527030358948};\\\", \\\"{x:817,y:415,t:1527030358965};\\\", \\\"{x:819,y:416,t:1527030359044};\\\", \\\"{x:822,y:416,t:1527030359052};\\\", \\\"{x:826,y:419,t:1527030359065};\\\", \\\"{x:835,y:423,t:1527030359081};\\\", \\\"{x:849,y:429,t:1527030359098};\\\", \\\"{x:864,y:434,t:1527030359115};\\\", \\\"{x:883,y:441,t:1527030359131};\\\", \\\"{x:911,y:446,t:1527030359148};\\\", \\\"{x:925,y:447,t:1527030359164};\\\", \\\"{x:940,y:449,t:1527030359181};\\\", \\\"{x:957,y:449,t:1527030359198};\\\", \\\"{x:981,y:449,t:1527030359215};\\\", \\\"{x:1004,y:449,t:1527030359231};\\\", \\\"{x:1040,y:449,t:1527030359248};\\\", \\\"{x:1067,y:445,t:1527030359265};\\\", \\\"{x:1107,y:435,t:1527030359281};\\\", \\\"{x:1162,y:420,t:1527030359298};\\\", \\\"{x:1249,y:389,t:1527030359316};\\\", \\\"{x:1315,y:360,t:1527030359331};\\\", \\\"{x:1415,y:309,t:1527030359349};\\\", \\\"{x:1485,y:272,t:1527030359364};\\\", \\\"{x:1548,y:237,t:1527030359381};\\\", \\\"{x:1597,y:209,t:1527030359398};\\\", \\\"{x:1638,y:185,t:1527030359414};\\\", \\\"{x:1657,y:174,t:1527030359431};\\\", \\\"{x:1662,y:170,t:1527030359448};\\\", \\\"{x:1659,y:172,t:1527030359573};\\\", \\\"{x:1651,y:176,t:1527030359581};\\\", \\\"{x:1637,y:182,t:1527030359598};\\\", \\\"{x:1617,y:188,t:1527030359614};\\\", \\\"{x:1600,y:193,t:1527030359632};\\\", \\\"{x:1585,y:198,t:1527030359648};\\\", \\\"{x:1578,y:198,t:1527030359664};\\\", \\\"{x:1577,y:198,t:1527030359681};\\\", \\\"{x:1576,y:198,t:1527030359765};\\\", \\\"{x:1573,y:199,t:1527030359781};\\\", \\\"{x:1566,y:202,t:1527030359798};\\\", \\\"{x:1556,y:203,t:1527030359814};\\\", \\\"{x:1546,y:206,t:1527030359831};\\\", \\\"{x:1537,y:208,t:1527030359848};\\\", \\\"{x:1528,y:212,t:1527030359864};\\\", \\\"{x:1521,y:214,t:1527030359881};\\\", \\\"{x:1516,y:216,t:1527030359898};\\\", \\\"{x:1513,y:217,t:1527030359914};\\\", \\\"{x:1512,y:217,t:1527030359931};\\\", \\\"{x:1510,y:219,t:1527030360124};\\\", \\\"{x:1509,y:219,t:1527030360140};\\\", \\\"{x:1509,y:220,t:1527030360148};\\\", \\\"{x:1508,y:220,t:1527030360172};\\\", \\\"{x:1507,y:220,t:1527030360189};\\\", \\\"{x:1506,y:220,t:1527030360213};\\\", \\\"{x:1506,y:221,t:1527030360231};\\\", \\\"{x:1505,y:222,t:1527030360247};\\\", \\\"{x:1504,y:223,t:1527030360353};\\\", \\\"{x:1503,y:223,t:1527030360367};\\\", \\\"{x:1499,y:223,t:1527030360383};\\\", \\\"{x:1492,y:223,t:1527030360400};\\\", \\\"{x:1484,y:223,t:1527030360417};\\\", \\\"{x:1475,y:225,t:1527030360434};\\\", \\\"{x:1468,y:226,t:1527030360450};\\\", \\\"{x:1461,y:227,t:1527030360467};\\\", \\\"{x:1458,y:228,t:1527030360483};\\\", \\\"{x:1457,y:228,t:1527030360501};\\\", \\\"{x:1456,y:228,t:1527030360616};\\\", \\\"{x:1455,y:228,t:1527030360647};\\\", \\\"{x:1453,y:228,t:1527030360655};\\\", \\\"{x:1451,y:228,t:1527030360667};\\\", \\\"{x:1449,y:228,t:1527030360683};\\\", \\\"{x:1447,y:229,t:1527030360882};\\\", \\\"{x:1445,y:230,t:1527030360887};\\\", \\\"{x:1444,y:231,t:1527030360901};\\\", \\\"{x:1442,y:231,t:1527030360916};\\\", \\\"{x:1441,y:231,t:1527030360933};\\\", \\\"{x:1440,y:233,t:1527030360950};\\\", \\\"{x:1438,y:233,t:1527030360966};\\\", \\\"{x:1437,y:235,t:1527030360983};\\\", \\\"{x:1435,y:237,t:1527030361000};\\\", \\\"{x:1435,y:238,t:1527030361152};\\\", \\\"{x:1437,y:238,t:1527030361167};\\\", \\\"{x:1441,y:238,t:1527030361184};\\\", \\\"{x:1442,y:238,t:1527030361200};\\\", \\\"{x:1444,y:238,t:1527030361217};\\\", \\\"{x:1446,y:238,t:1527030361240};\\\", \\\"{x:1447,y:237,t:1527030361417};\\\", \\\"{x:1447,y:236,t:1527030361434};\\\", \\\"{x:1447,y:234,t:1527030361450};\\\", \\\"{x:1447,y:231,t:1527030361467};\\\", \\\"{x:1447,y:230,t:1527030361484};\\\", \\\"{x:1447,y:229,t:1527030361501};\\\", \\\"{x:1447,y:228,t:1527030361516};\\\", \\\"{x:1447,y:227,t:1527030361639};\\\", \\\"{x:1448,y:227,t:1527030361663};\\\", \\\"{x:1449,y:227,t:1527030361671};\\\", \\\"{x:1450,y:227,t:1527030361687};\\\", \\\"{x:1451,y:226,t:1527030362144};\\\", \\\"{x:1453,y:223,t:1527030362153};\\\", \\\"{x:1455,y:222,t:1527030362165};\\\", \\\"{x:1457,y:218,t:1527030362182};\\\", \\\"{x:1458,y:216,t:1527030362199};\\\", \\\"{x:1459,y:213,t:1527030362215};\\\", \\\"{x:1460,y:213,t:1527030362417};\\\", \\\"{x:1460,y:218,t:1527030362456};\\\", \\\"{x:1457,y:224,t:1527030362465};\\\", \\\"{x:1455,y:233,t:1527030362483};\\\", \\\"{x:1452,y:240,t:1527030362499};\\\", \\\"{x:1452,y:242,t:1527030362516};\\\", \\\"{x:1452,y:243,t:1527030362552};\\\", \\\"{x:1451,y:243,t:1527030362640};\\\", \\\"{x:1447,y:242,t:1527030362648};\\\", \\\"{x:1440,y:238,t:1527030362665};\\\", \\\"{x:1440,y:236,t:1527030362683};\\\", \\\"{x:1440,y:235,t:1527030362698};\\\", \\\"{x:1440,y:233,t:1527030362716};\\\", \\\"{x:1440,y:229,t:1527030362733};\\\", \\\"{x:1440,y:228,t:1527030362749};\\\", \\\"{x:1440,y:225,t:1527030362766};\\\", \\\"{x:1441,y:223,t:1527030362783};\\\", \\\"{x:1442,y:223,t:1527030362799};\\\", \\\"{x:1442,y:222,t:1527030362816};\\\", \\\"{x:1444,y:222,t:1527030362921};\\\", \\\"{x:1447,y:223,t:1527030362933};\\\", \\\"{x:1450,y:224,t:1527030362949};\\\", \\\"{x:1453,y:226,t:1527030362966};\\\", \\\"{x:1455,y:227,t:1527030362983};\\\", \\\"{x:1457,y:229,t:1527030362999};\\\", \\\"{x:1458,y:229,t:1527030363016};\\\", \\\"{x:1457,y:230,t:1527030363337};\\\", \\\"{x:1454,y:230,t:1527030364448};\\\", \\\"{x:1434,y:245,t:1527030364465};\\\", \\\"{x:1408,y:263,t:1527030364481};\\\", \\\"{x:1367,y:289,t:1527030364498};\\\", \\\"{x:1315,y:321,t:1527030364516};\\\", \\\"{x:1245,y:356,t:1527030364532};\\\", \\\"{x:1197,y:379,t:1527030364548};\\\", \\\"{x:1174,y:403,t:1527030364565};\\\", \\\"{x:1161,y:419,t:1527030364581};\\\", \\\"{x:1156,y:426,t:1527030364598};\\\", \\\"{x:1155,y:428,t:1527030364615};\\\", \\\"{x:1154,y:428,t:1527030364712};\\\", \\\"{x:1153,y:429,t:1527030364720};\\\", \\\"{x:1152,y:431,t:1527030364731};\\\", \\\"{x:1152,y:434,t:1527030364748};\\\", \\\"{x:1152,y:438,t:1527030364765};\\\", \\\"{x:1152,y:439,t:1527030364781};\\\", \\\"{x:1152,y:442,t:1527030364799};\\\", \\\"{x:1152,y:444,t:1527030364815};\\\", \\\"{x:1152,y:447,t:1527030364831};\\\", \\\"{x:1152,y:455,t:1527030364848};\\\", \\\"{x:1152,y:469,t:1527030364864};\\\", \\\"{x:1151,y:492,t:1527030364881};\\\", \\\"{x:1151,y:507,t:1527030364898};\\\", \\\"{x:1151,y:516,t:1527030364914};\\\", \\\"{x:1151,y:523,t:1527030364932};\\\", \\\"{x:1151,y:529,t:1527030364948};\\\", \\\"{x:1151,y:542,t:1527030364964};\\\", \\\"{x:1151,y:552,t:1527030364981};\\\", \\\"{x:1149,y:560,t:1527030364998};\\\", \\\"{x:1148,y:564,t:1527030365014};\\\", \\\"{x:1148,y:567,t:1527030365031};\\\", \\\"{x:1152,y:567,t:1527030366265};\\\", \\\"{x:1153,y:568,t:1527030366280};\\\", \\\"{x:1153,y:571,t:1527030366296};\\\", \\\"{x:1148,y:574,t:1527030366313};\\\", \\\"{x:1147,y:575,t:1527030366330};\\\", \\\"{x:1150,y:575,t:1527030366347};\\\", \\\"{x:1151,y:575,t:1527030366363};\\\", \\\"{x:1153,y:575,t:1527030366465};\\\", \\\"{x:1156,y:584,t:1527030366480};\\\", \\\"{x:1156,y:594,t:1527030366496};\\\", \\\"{x:1155,y:599,t:1527030366513};\\\", \\\"{x:1154,y:602,t:1527030366530};\\\", \\\"{x:1154,y:603,t:1527030366548};\\\", \\\"{x:1154,y:606,t:1527030366564};\\\", \\\"{x:1154,y:615,t:1527030366580};\\\", \\\"{x:1155,y:633,t:1527030366597};\\\", \\\"{x:1166,y:647,t:1527030366613};\\\", \\\"{x:1177,y:656,t:1527030366630};\\\", \\\"{x:1191,y:660,t:1527030366648};\\\", \\\"{x:1199,y:665,t:1527030366663};\\\", \\\"{x:1204,y:665,t:1527030366681};\\\", \\\"{x:1208,y:669,t:1527030366696};\\\", \\\"{x:1212,y:675,t:1527030366713};\\\", \\\"{x:1217,y:682,t:1527030366730};\\\", \\\"{x:1227,y:695,t:1527030366747};\\\", \\\"{x:1236,y:706,t:1527030366763};\\\", \\\"{x:1245,y:718,t:1527030366780};\\\", \\\"{x:1254,y:731,t:1527030366796};\\\", \\\"{x:1258,y:735,t:1527030366813};\\\", \\\"{x:1262,y:738,t:1527030366830};\\\", \\\"{x:1265,y:738,t:1527030366846};\\\", \\\"{x:1268,y:740,t:1527030366863};\\\", \\\"{x:1269,y:741,t:1527030366904};\\\", \\\"{x:1268,y:745,t:1527030366915};\\\", \\\"{x:1250,y:766,t:1527030366930};\\\", \\\"{x:1235,y:793,t:1527030366946};\\\", \\\"{x:1230,y:819,t:1527030366962};\\\", \\\"{x:1227,y:846,t:1527030366979};\\\", \\\"{x:1225,y:876,t:1527030366996};\\\", \\\"{x:1224,y:894,t:1527030367012};\\\", \\\"{x:1224,y:902,t:1527030367029};\\\", \\\"{x:1224,y:903,t:1527030367045};\\\", \\\"{x:1225,y:905,t:1527030367062};\\\", \\\"{x:1235,y:908,t:1527030367079};\\\", \\\"{x:1242,y:909,t:1527030367096};\\\", \\\"{x:1252,y:913,t:1527030367113};\\\", \\\"{x:1261,y:917,t:1527030367129};\\\", \\\"{x:1269,y:920,t:1527030367146};\\\", \\\"{x:1277,y:922,t:1527030367163};\\\", \\\"{x:1284,y:922,t:1527030367179};\\\", \\\"{x:1287,y:923,t:1527030367196};\\\", \\\"{x:1289,y:923,t:1527030367213};\\\", \\\"{x:1290,y:923,t:1527030367229};\\\", \\\"{x:1291,y:924,t:1527030367304};\\\", \\\"{x:1294,y:925,t:1527030367312};\\\", \\\"{x:1298,y:927,t:1527030367329};\\\", \\\"{x:1302,y:930,t:1527030367346};\\\", \\\"{x:1306,y:933,t:1527030367363};\\\", \\\"{x:1309,y:936,t:1527030367380};\\\", \\\"{x:1311,y:938,t:1527030367396};\\\", \\\"{x:1313,y:941,t:1527030367414};\\\", \\\"{x:1314,y:944,t:1527030367429};\\\", \\\"{x:1317,y:948,t:1527030367446};\\\", \\\"{x:1317,y:950,t:1527030367462};\\\", \\\"{x:1317,y:951,t:1527030367479};\\\", \\\"{x:1318,y:954,t:1527030367496};\\\", \\\"{x:1318,y:955,t:1527030367617};\\\", \\\"{x:1317,y:955,t:1527030367632};\\\", \\\"{x:1316,y:955,t:1527030367656};\\\", \\\"{x:1315,y:955,t:1527030367664};\\\", \\\"{x:1314,y:955,t:1527030367680};\\\", \\\"{x:1312,y:955,t:1527030367696};\\\", \\\"{x:1311,y:955,t:1527030367712};\\\", \\\"{x:1309,y:955,t:1527030367729};\\\", \\\"{x:1306,y:955,t:1527030367746};\\\", \\\"{x:1305,y:955,t:1527030367763};\\\", \\\"{x:1303,y:955,t:1527030367792};\\\", \\\"{x:1302,y:955,t:1527030367808};\\\", \\\"{x:1300,y:956,t:1527030367816};\\\", \\\"{x:1299,y:956,t:1527030367832};\\\", \\\"{x:1298,y:956,t:1527030367846};\\\", \\\"{x:1296,y:956,t:1527030367862};\\\", \\\"{x:1296,y:957,t:1527030367879};\\\", \\\"{x:1293,y:957,t:1527030367896};\\\", \\\"{x:1292,y:957,t:1527030367912};\\\", \\\"{x:1289,y:958,t:1527030367930};\\\", \\\"{x:1288,y:958,t:1527030367946};\\\", \\\"{x:1286,y:958,t:1527030367962};\\\", \\\"{x:1284,y:958,t:1527030367979};\\\", \\\"{x:1283,y:958,t:1527030367999};\\\", \\\"{x:1281,y:958,t:1527030368011};\\\", \\\"{x:1280,y:958,t:1527030368029};\\\", \\\"{x:1277,y:958,t:1527030368044};\\\", \\\"{x:1276,y:958,t:1527030368061};\\\", \\\"{x:1274,y:958,t:1527030368079};\\\", \\\"{x:1273,y:958,t:1527030368095};\\\", \\\"{x:1271,y:958,t:1527030368111};\\\", \\\"{x:1270,y:958,t:1527030368128};\\\", \\\"{x:1269,y:958,t:1527030368145};\\\", \\\"{x:1270,y:958,t:1527030368432};\\\", \\\"{x:1271,y:958,t:1527030368445};\\\", \\\"{x:1274,y:959,t:1527030368463};\\\", \\\"{x:1275,y:960,t:1527030368478};\\\", \\\"{x:1277,y:961,t:1527030368495};\\\", \\\"{x:1278,y:961,t:1527030368512};\\\", \\\"{x:1278,y:960,t:1527030368720};\\\", \\\"{x:1279,y:959,t:1527030368728};\\\", \\\"{x:1279,y:957,t:1527030368747};\\\", \\\"{x:1280,y:954,t:1527030368762};\\\", \\\"{x:1281,y:951,t:1527030368778};\\\", \\\"{x:1284,y:946,t:1527030368795};\\\", \\\"{x:1287,y:941,t:1527030368812};\\\", \\\"{x:1289,y:939,t:1527030368828};\\\", \\\"{x:1290,y:937,t:1527030368845};\\\", \\\"{x:1292,y:936,t:1527030368897};\\\", \\\"{x:1293,y:936,t:1527030368911};\\\", \\\"{x:1297,y:936,t:1527030368928};\\\", \\\"{x:1301,y:937,t:1527030368946};\\\", \\\"{x:1304,y:939,t:1527030368961};\\\", \\\"{x:1307,y:942,t:1527030368979};\\\", \\\"{x:1308,y:945,t:1527030368996};\\\", \\\"{x:1308,y:947,t:1527030369012};\\\", \\\"{x:1309,y:951,t:1527030369029};\\\", \\\"{x:1309,y:954,t:1527030369045};\\\", \\\"{x:1309,y:956,t:1527030369061};\\\", \\\"{x:1309,y:957,t:1527030369160};\\\", \\\"{x:1307,y:957,t:1527030369178};\\\", \\\"{x:1306,y:957,t:1527030369196};\\\", \\\"{x:1304,y:957,t:1527030369211};\\\", \\\"{x:1301,y:957,t:1527030369228};\\\", \\\"{x:1300,y:957,t:1527030369245};\\\", \\\"{x:1298,y:957,t:1527030369261};\\\", \\\"{x:1295,y:957,t:1527030369278};\\\", \\\"{x:1293,y:956,t:1527030369295};\\\", \\\"{x:1292,y:955,t:1527030369312};\\\", \\\"{x:1291,y:955,t:1527030369328};\\\", \\\"{x:1289,y:955,t:1527030369433};\\\", \\\"{x:1288,y:954,t:1527030369444};\\\", \\\"{x:1286,y:954,t:1527030369960};\\\", \\\"{x:1285,y:956,t:1527030369977};\\\", \\\"{x:1285,y:958,t:1527030369994};\\\", \\\"{x:1284,y:959,t:1527030370011};\\\", \\\"{x:1284,y:960,t:1527030370688};\\\", \\\"{x:1282,y:960,t:1527030370720};\\\", \\\"{x:1281,y:960,t:1527030370784};\\\", \\\"{x:1280,y:960,t:1527030370800};\\\", \\\"{x:1279,y:960,t:1527030370848};\\\", \\\"{x:1279,y:959,t:1527030371352};\\\", \\\"{x:1278,y:959,t:1527030371497};\\\", \\\"{x:1275,y:956,t:1527030373528};\\\", \\\"{x:1274,y:956,t:1527030373542};\\\", \\\"{x:1267,y:952,t:1527030373558};\\\", \\\"{x:1252,y:943,t:1527030373576};\\\", \\\"{x:1231,y:930,t:1527030373592};\\\", \\\"{x:1130,y:902,t:1527030373608};\\\", \\\"{x:1020,y:887,t:1527030373625};\\\", \\\"{x:953,y:877,t:1527030373641};\\\", \\\"{x:920,y:875,t:1527030373658};\\\", \\\"{x:895,y:867,t:1527030373675};\\\", \\\"{x:883,y:862,t:1527030373691};\\\", \\\"{x:871,y:857,t:1527030373708};\\\", \\\"{x:859,y:852,t:1527030373726};\\\", \\\"{x:849,y:843,t:1527030373741};\\\", \\\"{x:837,y:828,t:1527030373758};\\\", \\\"{x:824,y:804,t:1527030373775};\\\", \\\"{x:795,y:762,t:1527030373791};\\\", \\\"{x:744,y:698,t:1527030373808};\\\", \\\"{x:717,y:668,t:1527030373825};\\\", \\\"{x:698,y:628,t:1527030373842};\\\", \\\"{x:684,y:588,t:1527030373858};\\\", \\\"{x:673,y:554,t:1527030373875};\\\", \\\"{x:649,y:504,t:1527030373899};\\\", \\\"{x:627,y:471,t:1527030373915};\\\", \\\"{x:614,y:452,t:1527030373933};\\\", \\\"{x:602,y:440,t:1527030373948};\\\", \\\"{x:590,y:430,t:1527030373965};\\\", \\\"{x:578,y:423,t:1527030373982};\\\", \\\"{x:571,y:418,t:1527030373998};\\\", \\\"{x:570,y:417,t:1527030374015};\\\", \\\"{x:569,y:416,t:1527030374079};\\\", \\\"{x:567,y:418,t:1527030374095};\\\", \\\"{x:566,y:426,t:1527030374103};\\\", \\\"{x:566,y:433,t:1527030374115};\\\", \\\"{x:563,y:449,t:1527030374132};\\\", \\\"{x:563,y:464,t:1527030374148};\\\", \\\"{x:563,y:478,t:1527030374165};\\\", \\\"{x:564,y:486,t:1527030374182};\\\", \\\"{x:565,y:493,t:1527030374199};\\\", \\\"{x:568,y:499,t:1527030374214};\\\", \\\"{x:571,y:503,t:1527030374232};\\\", \\\"{x:571,y:504,t:1527030374249};\\\", \\\"{x:572,y:504,t:1527030374266};\\\", \\\"{x:572,y:505,t:1527030374360};\\\", \\\"{x:573,y:506,t:1527030374369};\\\", \\\"{x:580,y:508,t:1527030374382};\\\", \\\"{x:594,y:512,t:1527030374398};\\\", \\\"{x:617,y:514,t:1527030374416};\\\", \\\"{x:625,y:515,t:1527030374431};\\\", \\\"{x:656,y:515,t:1527030374449};\\\", \\\"{x:674,y:515,t:1527030374465};\\\", \\\"{x:688,y:516,t:1527030374482};\\\", \\\"{x:695,y:516,t:1527030374498};\\\", \\\"{x:701,y:518,t:1527030374515};\\\", \\\"{x:708,y:520,t:1527030374533};\\\", \\\"{x:714,y:521,t:1527030374549};\\\", \\\"{x:721,y:524,t:1527030374566};\\\", \\\"{x:728,y:527,t:1527030374583};\\\", \\\"{x:747,y:534,t:1527030374599};\\\", \\\"{x:765,y:543,t:1527030374616};\\\", \\\"{x:782,y:551,t:1527030374633};\\\", \\\"{x:798,y:560,t:1527030374648};\\\", \\\"{x:814,y:565,t:1527030374666};\\\", \\\"{x:834,y:571,t:1527030374683};\\\", \\\"{x:854,y:580,t:1527030374699};\\\", \\\"{x:880,y:594,t:1527030374716};\\\", \\\"{x:908,y:606,t:1527030374733};\\\", \\\"{x:931,y:619,t:1527030374749};\\\", \\\"{x:960,y:638,t:1527030374765};\\\", \\\"{x:981,y:652,t:1527030374783};\\\", \\\"{x:1000,y:666,t:1527030374799};\\\", \\\"{x:1019,y:679,t:1527030374816};\\\", \\\"{x:1021,y:681,t:1527030374833};\\\", \\\"{x:1022,y:682,t:1527030374904};\\\", \\\"{x:1025,y:686,t:1527030374917};\\\", \\\"{x:1041,y:696,t:1527030374933};\\\", \\\"{x:1061,y:711,t:1527030374950};\\\", \\\"{x:1078,y:721,t:1527030374966};\\\", \\\"{x:1089,y:728,t:1527030374983};\\\", \\\"{x:1110,y:739,t:1527030375000};\\\", \\\"{x:1126,y:749,t:1527030375016};\\\", \\\"{x:1145,y:760,t:1527030375034};\\\", \\\"{x:1166,y:771,t:1527030375050};\\\", \\\"{x:1178,y:779,t:1527030375067};\\\", \\\"{x:1186,y:782,t:1527030375083};\\\", \\\"{x:1195,y:786,t:1527030375101};\\\", \\\"{x:1204,y:790,t:1527030375116};\\\", \\\"{x:1212,y:793,t:1527030375134};\\\", \\\"{x:1217,y:796,t:1527030375150};\\\", \\\"{x:1223,y:798,t:1527030375167};\\\", \\\"{x:1229,y:803,t:1527030375183};\\\", \\\"{x:1232,y:806,t:1527030375200};\\\", \\\"{x:1235,y:810,t:1527030375216};\\\", \\\"{x:1237,y:812,t:1527030375232};\\\", \\\"{x:1238,y:814,t:1527030375250};\\\", \\\"{x:1239,y:815,t:1527030375267};\\\", \\\"{x:1240,y:816,t:1527030375295};\\\", \\\"{x:1240,y:817,t:1527030375319};\\\", \\\"{x:1240,y:818,t:1527030375333};\\\", \\\"{x:1240,y:819,t:1527030375350};\\\", \\\"{x:1240,y:821,t:1527030375368};\\\", \\\"{x:1240,y:823,t:1527030375384};\\\", \\\"{x:1240,y:825,t:1527030375400};\\\", \\\"{x:1240,y:828,t:1527030375418};\\\", \\\"{x:1240,y:831,t:1527030375434};\\\", \\\"{x:1240,y:835,t:1527030375451};\\\", \\\"{x:1240,y:840,t:1527030375468};\\\", \\\"{x:1240,y:842,t:1527030375485};\\\", \\\"{x:1240,y:843,t:1527030375500};\\\", \\\"{x:1240,y:845,t:1527030375518};\\\", \\\"{x:1241,y:847,t:1527030375535};\\\", \\\"{x:1242,y:848,t:1527030375550};\\\", \\\"{x:1243,y:849,t:1527030375568};\\\", \\\"{x:1248,y:853,t:1527030375584};\\\", \\\"{x:1254,y:857,t:1527030375600};\\\", \\\"{x:1263,y:862,t:1527030375617};\\\", \\\"{x:1272,y:866,t:1527030375634};\\\", \\\"{x:1282,y:870,t:1527030375652};\\\", \\\"{x:1286,y:872,t:1527030375668};\\\", \\\"{x:1290,y:873,t:1527030375685};\\\", \\\"{x:1293,y:875,t:1527030375701};\\\", \\\"{x:1295,y:876,t:1527030375717};\\\", \\\"{x:1297,y:878,t:1527030375734};\\\", \\\"{x:1299,y:880,t:1527030375751};\\\", \\\"{x:1301,y:882,t:1527030375768};\\\", \\\"{x:1304,y:887,t:1527030375784};\\\", \\\"{x:1307,y:891,t:1527030375802};\\\", \\\"{x:1308,y:892,t:1527030375817};\\\", \\\"{x:1308,y:895,t:1527030375834};\\\", \\\"{x:1309,y:900,t:1527030375852};\\\", \\\"{x:1309,y:903,t:1527030375868};\\\", \\\"{x:1310,y:906,t:1527030375884};\\\", \\\"{x:1310,y:909,t:1527030375901};\\\", \\\"{x:1310,y:912,t:1527030375919};\\\", \\\"{x:1310,y:916,t:1527030375935};\\\", \\\"{x:1310,y:918,t:1527030375952};\\\", \\\"{x:1310,y:921,t:1527030375967};\\\", \\\"{x:1310,y:922,t:1527030375992};\\\", \\\"{x:1310,y:923,t:1527030376001};\\\", \\\"{x:1309,y:924,t:1527030376018};\\\", \\\"{x:1308,y:927,t:1527030376035};\\\", \\\"{x:1307,y:929,t:1527030376051};\\\", \\\"{x:1307,y:930,t:1527030376136};\\\", \\\"{x:1306,y:931,t:1527030376152};\\\", \\\"{x:1306,y:932,t:1527030376168};\\\", \\\"{x:1306,y:933,t:1527030376192};\\\", \\\"{x:1306,y:934,t:1527030376201};\\\", \\\"{x:1305,y:936,t:1527030376219};\\\", \\\"{x:1305,y:937,t:1527030376236};\\\", \\\"{x:1305,y:938,t:1527030376251};\\\", \\\"{x:1305,y:939,t:1527030376296};\\\", \\\"{x:1305,y:940,t:1527030376337};\\\", \\\"{x:1305,y:941,t:1527030376352};\\\", \\\"{x:1307,y:942,t:1527030376384};\\\", \\\"{x:1308,y:942,t:1527030376400};\\\", \\\"{x:1309,y:944,t:1527030376408};\\\", \\\"{x:1310,y:944,t:1527030376419};\\\", \\\"{x:1314,y:945,t:1527030376436};\\\", \\\"{x:1318,y:947,t:1527030376452};\\\", \\\"{x:1321,y:947,t:1527030376468};\\\", \\\"{x:1327,y:948,t:1527030376485};\\\", \\\"{x:1335,y:948,t:1527030376502};\\\", \\\"{x:1341,y:949,t:1527030376518};\\\", \\\"{x:1347,y:949,t:1527030376535};\\\", \\\"{x:1348,y:949,t:1527030376551};\\\", \\\"{x:1350,y:949,t:1527030376568};\\\", \\\"{x:1351,y:949,t:1527030376585};\\\", \\\"{x:1352,y:949,t:1527030376602};\\\", \\\"{x:1353,y:949,t:1527030376619};\\\", \\\"{x:1354,y:949,t:1527030376635};\\\", \\\"{x:1355,y:949,t:1527030376664};\\\", \\\"{x:1357,y:949,t:1527030376673};\\\", \\\"{x:1359,y:949,t:1527030376688};\\\", \\\"{x:1362,y:950,t:1527030376702};\\\", \\\"{x:1363,y:951,t:1527030376720};\\\", \\\"{x:1365,y:952,t:1527030376744};\\\", \\\"{x:1366,y:952,t:1527030376752};\\\", \\\"{x:1368,y:956,t:1527030376769};\\\", \\\"{x:1370,y:960,t:1527030376785};\\\", \\\"{x:1375,y:968,t:1527030376802};\\\", \\\"{x:1385,y:975,t:1527030376819};\\\", \\\"{x:1400,y:983,t:1527030376835};\\\", \\\"{x:1423,y:993,t:1527030376853};\\\", \\\"{x:1456,y:999,t:1527030376869};\\\", \\\"{x:1507,y:1007,t:1527030376885};\\\", \\\"{x:1543,y:1007,t:1527030376902};\\\", \\\"{x:1574,y:1006,t:1527030376920};\\\", \\\"{x:1579,y:1004,t:1527030376935};\\\", \\\"{x:1581,y:1003,t:1527030376952};\\\", \\\"{x:1581,y:1002,t:1527030377040};\\\", \\\"{x:1580,y:1002,t:1527030377063};\\\", \\\"{x:1579,y:1002,t:1527030377072};\\\", \\\"{x:1577,y:1002,t:1527030377088};\\\", \\\"{x:1574,y:1002,t:1527030377102};\\\", \\\"{x:1572,y:1003,t:1527030377120};\\\", \\\"{x:1570,y:1003,t:1527030377136};\\\", \\\"{x:1568,y:1004,t:1527030377153};\\\", \\\"{x:1565,y:1005,t:1527030377170};\\\", \\\"{x:1562,y:1006,t:1527030377186};\\\", \\\"{x:1558,y:1007,t:1527030377203};\\\", \\\"{x:1555,y:1010,t:1527030377220};\\\", \\\"{x:1552,y:1011,t:1527030377236};\\\", \\\"{x:1548,y:1012,t:1527030377253};\\\", \\\"{x:1546,y:1013,t:1527030377269};\\\", \\\"{x:1543,y:1014,t:1527030377286};\\\", \\\"{x:1537,y:1017,t:1527030377304};\\\", \\\"{x:1535,y:1017,t:1527030377320};\\\", \\\"{x:1531,y:1018,t:1527030377337};\\\", \\\"{x:1526,y:1021,t:1527030377353};\\\", \\\"{x:1523,y:1022,t:1527030377371};\\\", \\\"{x:1521,y:1023,t:1527030377386};\\\", \\\"{x:1517,y:1025,t:1527030377403};\\\", \\\"{x:1511,y:1028,t:1527030377421};\\\", \\\"{x:1508,y:1029,t:1527030377436};\\\", \\\"{x:1506,y:1031,t:1527030377454};\\\", \\\"{x:1504,y:1032,t:1527030377472};\\\", \\\"{x:1503,y:1032,t:1527030377496};\\\", \\\"{x:1502,y:1032,t:1527030377512};\\\", \\\"{x:1502,y:1033,t:1527030377520};\\\", \\\"{x:1500,y:1034,t:1527030377537};\\\", \\\"{x:1499,y:1035,t:1527030377584};\\\", \\\"{x:1499,y:1036,t:1527030377848};\\\", \\\"{x:1502,y:1038,t:1527030377856};\\\", \\\"{x:1506,y:1039,t:1527030377870};\\\", \\\"{x:1518,y:1043,t:1527030377888};\\\", \\\"{x:1525,y:1043,t:1527030377904};\\\", \\\"{x:1532,y:1043,t:1527030377920};\\\", \\\"{x:1537,y:1043,t:1527030377938};\\\", \\\"{x:1540,y:1043,t:1527030377955};\\\", \\\"{x:1544,y:1043,t:1527030377970};\\\", \\\"{x:1547,y:1043,t:1527030377988};\\\", \\\"{x:1550,y:1043,t:1527030378004};\\\", \\\"{x:1554,y:1043,t:1527030378020};\\\", \\\"{x:1555,y:1043,t:1527030378037};\\\", \\\"{x:1558,y:1044,t:1527030378054};\\\", \\\"{x:1561,y:1044,t:1527030378071};\\\", \\\"{x:1564,y:1044,t:1527030378088};\\\", \\\"{x:1565,y:1044,t:1527030378119};\\\", \\\"{x:1566,y:1043,t:1527030378144};\\\", \\\"{x:1567,y:1043,t:1527030378160};\\\", \\\"{x:1568,y:1042,t:1527030378176};\\\", \\\"{x:1569,y:1042,t:1527030378199};\\\", \\\"{x:1570,y:1042,t:1527030378207};\\\", \\\"{x:1570,y:1041,t:1527030378296};\\\", \\\"{x:1570,y:1040,t:1527030378304};\\\", \\\"{x:1572,y:1040,t:1527030378335};\\\", \\\"{x:1573,y:1039,t:1527030378360};\\\", \\\"{x:1574,y:1038,t:1527030378384};\\\", \\\"{x:1575,y:1038,t:1527030378408};\\\", \\\"{x:1575,y:1037,t:1527030378424};\\\", \\\"{x:1576,y:1037,t:1527030378438};\\\", \\\"{x:1576,y:1036,t:1527030378456};\\\", \\\"{x:1577,y:1036,t:1527030378471};\\\", \\\"{x:1577,y:1035,t:1527030378489};\\\", \\\"{x:1577,y:1034,t:1527030378504};\\\", \\\"{x:1578,y:1034,t:1527030378522};\\\", \\\"{x:1578,y:1033,t:1527030378712};\\\", \\\"{x:1578,y:1032,t:1527030378721};\\\", \\\"{x:1579,y:1031,t:1527030378744};\\\", \\\"{x:1580,y:1030,t:1527030378755};\\\", \\\"{x:1583,y:1029,t:1527030378772};\\\", \\\"{x:1586,y:1027,t:1527030378788};\\\", \\\"{x:1588,y:1026,t:1527030378806};\\\", \\\"{x:1591,y:1024,t:1527030378821};\\\", \\\"{x:1592,y:1022,t:1527030378839};\\\", \\\"{x:1594,y:1021,t:1527030378855};\\\", \\\"{x:1595,y:1021,t:1527030378872};\\\", \\\"{x:1595,y:1020,t:1527030378895};\\\", \\\"{x:1596,y:1019,t:1527030378968};\\\", \\\"{x:1596,y:1018,t:1527030379152};\\\", \\\"{x:1596,y:1017,t:1527030379176};\\\", \\\"{x:1596,y:1016,t:1527030379208};\\\", \\\"{x:1596,y:1015,t:1527030379222};\\\", \\\"{x:1596,y:1014,t:1527030379264};\\\", \\\"{x:1596,y:1012,t:1527030379273};\\\", \\\"{x:1595,y:1012,t:1527030379296};\\\", \\\"{x:1595,y:1010,t:1527030379312};\\\", \\\"{x:1594,y:1009,t:1527030379322};\\\", \\\"{x:1593,y:1008,t:1527030379339};\\\", \\\"{x:1592,y:1007,t:1527030379357};\\\", \\\"{x:1592,y:1006,t:1527030379373};\\\", \\\"{x:1590,y:1005,t:1527030379390};\\\", \\\"{x:1589,y:1004,t:1527030379406};\\\", \\\"{x:1589,y:1003,t:1527030379423};\\\", \\\"{x:1587,y:1000,t:1527030379439};\\\", \\\"{x:1585,y:997,t:1527030379456};\\\", \\\"{x:1582,y:994,t:1527030379472};\\\", \\\"{x:1579,y:990,t:1527030379489};\\\", \\\"{x:1578,y:987,t:1527030379507};\\\", \\\"{x:1576,y:983,t:1527030379523};\\\", \\\"{x:1575,y:978,t:1527030379540};\\\", \\\"{x:1572,y:974,t:1527030379556};\\\", \\\"{x:1570,y:970,t:1527030379573};\\\", \\\"{x:1568,y:966,t:1527030379589};\\\", \\\"{x:1567,y:963,t:1527030379606};\\\", \\\"{x:1565,y:956,t:1527030379624};\\\", \\\"{x:1564,y:952,t:1527030379640};\\\", \\\"{x:1563,y:947,t:1527030379657};\\\", \\\"{x:1559,y:940,t:1527030379673};\\\", \\\"{x:1557,y:937,t:1527030379690};\\\", \\\"{x:1556,y:932,t:1527030379707};\\\", \\\"{x:1556,y:929,t:1527030379723};\\\", \\\"{x:1553,y:924,t:1527030379740};\\\", \\\"{x:1544,y:913,t:1527030379757};\\\", \\\"{x:1542,y:911,t:1527030379774};\\\", \\\"{x:1543,y:911,t:1527030379872};\\\", \\\"{x:1542,y:911,t:1527030380999};\\\", \\\"{x:1534,y:910,t:1527030381008};\\\", \\\"{x:1524,y:910,t:1527030381025};\\\", \\\"{x:1515,y:910,t:1527030381041};\\\", \\\"{x:1498,y:910,t:1527030381059};\\\", \\\"{x:1476,y:910,t:1527030381076};\\\", \\\"{x:1452,y:909,t:1527030381092};\\\", \\\"{x:1432,y:909,t:1527030381109};\\\", \\\"{x:1415,y:909,t:1527030381126};\\\", \\\"{x:1406,y:909,t:1527030381142};\\\", \\\"{x:1399,y:909,t:1527030381159};\\\", \\\"{x:1388,y:906,t:1527030381176};\\\", \\\"{x:1380,y:905,t:1527030381192};\\\", \\\"{x:1371,y:904,t:1527030381209};\\\", \\\"{x:1365,y:904,t:1527030381226};\\\", \\\"{x:1361,y:904,t:1527030381241};\\\", \\\"{x:1357,y:904,t:1527030381259};\\\", \\\"{x:1360,y:904,t:1527030381392};\\\", \\\"{x:1377,y:898,t:1527030381409};\\\", \\\"{x:1398,y:893,t:1527030381426};\\\", \\\"{x:1425,y:885,t:1527030381442};\\\", \\\"{x:1453,y:878,t:1527030381458};\\\", \\\"{x:1494,y:869,t:1527030381475};\\\", \\\"{x:1544,y:863,t:1527030381492};\\\", \\\"{x:1592,y:856,t:1527030381508};\\\", \\\"{x:1639,y:848,t:1527030381525};\\\", \\\"{x:1677,y:841,t:1527030381542};\\\", \\\"{x:1729,y:828,t:1527030381558};\\\", \\\"{x:1754,y:826,t:1527030381575};\\\", \\\"{x:1771,y:823,t:1527030381592};\\\", \\\"{x:1775,y:822,t:1527030381610};\\\", \\\"{x:1779,y:821,t:1527030381625};\\\", \\\"{x:1775,y:823,t:1527030381808};\\\", \\\"{x:1767,y:826,t:1527030381816};\\\", \\\"{x:1758,y:829,t:1527030381827};\\\", \\\"{x:1737,y:836,t:1527030381842};\\\", \\\"{x:1711,y:847,t:1527030381860};\\\", \\\"{x:1685,y:854,t:1527030381877};\\\", \\\"{x:1664,y:860,t:1527030381893};\\\", \\\"{x:1647,y:865,t:1527030381910};\\\", \\\"{x:1630,y:869,t:1527030381927};\\\", \\\"{x:1622,y:870,t:1527030381942};\\\", \\\"{x:1617,y:870,t:1527030381960};\\\", \\\"{x:1615,y:870,t:1527030381977};\\\", \\\"{x:1614,y:870,t:1527030381993};\\\", \\\"{x:1610,y:870,t:1527030382010};\\\", \\\"{x:1604,y:870,t:1527030382026};\\\", \\\"{x:1590,y:870,t:1527030382043};\\\", \\\"{x:1569,y:870,t:1527030382060};\\\", \\\"{x:1547,y:870,t:1527030382076};\\\", \\\"{x:1521,y:870,t:1527030382094};\\\", \\\"{x:1493,y:870,t:1527030382110};\\\", \\\"{x:1467,y:870,t:1527030382126};\\\", \\\"{x:1434,y:870,t:1527030382143};\\\", \\\"{x:1423,y:870,t:1527030382160};\\\", \\\"{x:1420,y:870,t:1527030382176};\\\", \\\"{x:1419,y:870,t:1527030382194};\\\", \\\"{x:1418,y:870,t:1527030382232};\\\", \\\"{x:1415,y:870,t:1527030382248};\\\", \\\"{x:1414,y:870,t:1527030382261};\\\", \\\"{x:1408,y:874,t:1527030382277};\\\", \\\"{x:1400,y:878,t:1527030382294};\\\", \\\"{x:1394,y:883,t:1527030382311};\\\", \\\"{x:1387,y:889,t:1527030382327};\\\", \\\"{x:1381,y:894,t:1527030382347};\\\", \\\"{x:1379,y:897,t:1527030382359};\\\", \\\"{x:1378,y:899,t:1527030382377};\\\", \\\"{x:1377,y:900,t:1527030382393};\\\", \\\"{x:1375,y:902,t:1527030382411};\\\", \\\"{x:1372,y:905,t:1527030382426};\\\", \\\"{x:1369,y:907,t:1527030382443};\\\", \\\"{x:1367,y:909,t:1527030382460};\\\", \\\"{x:1364,y:912,t:1527030382476};\\\", \\\"{x:1360,y:914,t:1527030382494};\\\", \\\"{x:1358,y:915,t:1527030382511};\\\", \\\"{x:1354,y:919,t:1527030382527};\\\", \\\"{x:1345,y:924,t:1527030382543};\\\", \\\"{x:1339,y:927,t:1527030382560};\\\", \\\"{x:1332,y:929,t:1527030382577};\\\", \\\"{x:1321,y:931,t:1527030382593};\\\", \\\"{x:1316,y:934,t:1527030382610};\\\", \\\"{x:1313,y:934,t:1527030382627};\\\", \\\"{x:1310,y:935,t:1527030382643};\\\", \\\"{x:1309,y:935,t:1527030382660};\\\", \\\"{x:1307,y:935,t:1527030382677};\\\", \\\"{x:1306,y:935,t:1527030382728};\\\", \\\"{x:1304,y:935,t:1527030382744};\\\", \\\"{x:1302,y:936,t:1527030382760};\\\", \\\"{x:1301,y:937,t:1527030382777};\\\", \\\"{x:1300,y:937,t:1527030382794};\\\", \\\"{x:1299,y:937,t:1527030382832};\\\", \\\"{x:1297,y:937,t:1527030382936};\\\", \\\"{x:1296,y:937,t:1527030382944};\\\", \\\"{x:1293,y:938,t:1527030382961};\\\", \\\"{x:1292,y:938,t:1527030382978};\\\", \\\"{x:1290,y:938,t:1527030382995};\\\", \\\"{x:1288,y:938,t:1527030383012};\\\", \\\"{x:1287,y:938,t:1527030383028};\\\", \\\"{x:1286,y:938,t:1527030383044};\\\", \\\"{x:1285,y:939,t:1527030383061};\\\", \\\"{x:1284,y:938,t:1527030383185};\\\", \\\"{x:1280,y:935,t:1527030383195};\\\", \\\"{x:1274,y:924,t:1527030383212};\\\", \\\"{x:1260,y:909,t:1527030383228};\\\", \\\"{x:1242,y:893,t:1527030383244};\\\", \\\"{x:1223,y:877,t:1527030383262};\\\", \\\"{x:1196,y:857,t:1527030383279};\\\", \\\"{x:1176,y:841,t:1527030383294};\\\", \\\"{x:1153,y:825,t:1527030383312};\\\", \\\"{x:1141,y:815,t:1527030383328};\\\", \\\"{x:1130,y:809,t:1527030383346};\\\", \\\"{x:1125,y:803,t:1527030383362};\\\", \\\"{x:1121,y:799,t:1527030383379};\\\", \\\"{x:1118,y:796,t:1527030383395};\\\", \\\"{x:1116,y:793,t:1527030383412};\\\", \\\"{x:1113,y:789,t:1527030383428};\\\", \\\"{x:1112,y:788,t:1527030383445};\\\", \\\"{x:1110,y:785,t:1527030383462};\\\", \\\"{x:1108,y:783,t:1527030383479};\\\", \\\"{x:1102,y:777,t:1527030383496};\\\", \\\"{x:1097,y:770,t:1527030383512};\\\", \\\"{x:1089,y:761,t:1527030383529};\\\", \\\"{x:1081,y:748,t:1527030383547};\\\", \\\"{x:1070,y:732,t:1527030383562};\\\", \\\"{x:1057,y:713,t:1527030383579};\\\", \\\"{x:1038,y:685,t:1527030383596};\\\", \\\"{x:1024,y:664,t:1527030383612};\\\", \\\"{x:1014,y:647,t:1527030383629};\\\", \\\"{x:1005,y:631,t:1527030383645};\\\", \\\"{x:999,y:616,t:1527030383661};\\\", \\\"{x:989,y:600,t:1527030383679};\\\", \\\"{x:982,y:578,t:1527030383695};\\\", \\\"{x:979,y:568,t:1527030383711};\\\", \\\"{x:977,y:559,t:1527030383729};\\\", \\\"{x:976,y:550,t:1527030383747};\\\", \\\"{x:976,y:545,t:1527030383763};\\\", \\\"{x:975,y:541,t:1527030383779};\\\", \\\"{x:975,y:532,t:1527030383796};\\\", \\\"{x:975,y:523,t:1527030383813};\\\", \\\"{x:976,y:514,t:1527030383828};\\\", \\\"{x:981,y:504,t:1527030383846};\\\", \\\"{x:988,y:493,t:1527030383862};\\\", \\\"{x:993,y:486,t:1527030383879};\\\", \\\"{x:1000,y:477,t:1527030383896};\\\", \\\"{x:1003,y:474,t:1527030383913};\\\", \\\"{x:1007,y:470,t:1527030383929};\\\", \\\"{x:1012,y:467,t:1527030383947};\\\", \\\"{x:1014,y:466,t:1527030383963};\\\", \\\"{x:1014,y:465,t:1527030383980};\\\", \\\"{x:1015,y:465,t:1527030383995};\\\", \\\"{x:1018,y:465,t:1527030384160};\\\", \\\"{x:1024,y:469,t:1527030384167};\\\", \\\"{x:1031,y:474,t:1527030384179};\\\", \\\"{x:1048,y:486,t:1527030384196};\\\", \\\"{x:1069,y:500,t:1527030384213};\\\", \\\"{x:1084,y:511,t:1527030384230};\\\", \\\"{x:1097,y:521,t:1527030384246};\\\", \\\"{x:1110,y:532,t:1527030384263};\\\", \\\"{x:1124,y:543,t:1527030384280};\\\", \\\"{x:1132,y:550,t:1527030384296};\\\", \\\"{x:1141,y:558,t:1527030384313};\\\", \\\"{x:1152,y:567,t:1527030384330};\\\", \\\"{x:1160,y:574,t:1527030384347};\\\", \\\"{x:1166,y:580,t:1527030384363};\\\", \\\"{x:1170,y:584,t:1527030384380};\\\", \\\"{x:1174,y:590,t:1527030384397};\\\", \\\"{x:1177,y:593,t:1527030384413};\\\", \\\"{x:1178,y:596,t:1527030384430};\\\", \\\"{x:1180,y:599,t:1527030384447};\\\", \\\"{x:1184,y:607,t:1527030384464};\\\", \\\"{x:1187,y:612,t:1527030384479};\\\", \\\"{x:1191,y:617,t:1527030384496};\\\", \\\"{x:1193,y:623,t:1527030384513};\\\", \\\"{x:1196,y:630,t:1527030384529};\\\", \\\"{x:1198,y:632,t:1527030384546};\\\", \\\"{x:1201,y:637,t:1527030384563};\\\", \\\"{x:1203,y:642,t:1527030384579};\\\", \\\"{x:1205,y:644,t:1527030384596};\\\", \\\"{x:1207,y:646,t:1527030384613};\\\", \\\"{x:1208,y:647,t:1527030384629};\\\", \\\"{x:1209,y:648,t:1527030384647};\\\", \\\"{x:1211,y:650,t:1527030384663};\\\", \\\"{x:1214,y:653,t:1527030384680};\\\", \\\"{x:1218,y:656,t:1527030384697};\\\", \\\"{x:1223,y:661,t:1527030384713};\\\", \\\"{x:1227,y:665,t:1527030384730};\\\", \\\"{x:1235,y:670,t:1527030384747};\\\", \\\"{x:1244,y:677,t:1527030384764};\\\", \\\"{x:1253,y:683,t:1527030384780};\\\", \\\"{x:1260,y:687,t:1527030384796};\\\", \\\"{x:1267,y:691,t:1527030384814};\\\", \\\"{x:1273,y:695,t:1527030384830};\\\", \\\"{x:1275,y:697,t:1527030384847};\\\", \\\"{x:1278,y:701,t:1527030384863};\\\", \\\"{x:1281,y:704,t:1527030384880};\\\", \\\"{x:1287,y:712,t:1527030384897};\\\", \\\"{x:1293,y:716,t:1527030384914};\\\", \\\"{x:1296,y:718,t:1527030384931};\\\", \\\"{x:1297,y:719,t:1527030384948};\\\", \\\"{x:1298,y:719,t:1527030384975};\\\", \\\"{x:1300,y:719,t:1527030385096};\\\", \\\"{x:1302,y:721,t:1527030385104};\\\", \\\"{x:1303,y:721,t:1527030385113};\\\", \\\"{x:1305,y:722,t:1527030385130};\\\", \\\"{x:1307,y:722,t:1527030385147};\\\", \\\"{x:1307,y:723,t:1527030385163};\\\", \\\"{x:1308,y:723,t:1527030385182};\\\", \\\"{x:1309,y:724,t:1527030385199};\\\", \\\"{x:1308,y:727,t:1527030385239};\\\", \\\"{x:1305,y:728,t:1527030385246};\\\", \\\"{x:1300,y:730,t:1527030385264};\\\", \\\"{x:1299,y:731,t:1527030385281};\\\", \\\"{x:1298,y:732,t:1527030385456};\\\", \\\"{x:1296,y:732,t:1527030385464};\\\", \\\"{x:1292,y:734,t:1527030385482};\\\", \\\"{x:1290,y:736,t:1527030385497};\\\", \\\"{x:1289,y:736,t:1527030385520};\\\", \\\"{x:1288,y:736,t:1527030386624};\\\", \\\"{x:1287,y:738,t:1527030386633};\\\", \\\"{x:1284,y:739,t:1527030386650};\\\", \\\"{x:1279,y:742,t:1527030386667};\\\", \\\"{x:1274,y:753,t:1527030386683};\\\", \\\"{x:1269,y:762,t:1527030386700};\\\", \\\"{x:1259,y:774,t:1527030386717};\\\", \\\"{x:1252,y:787,t:1527030386733};\\\", \\\"{x:1243,y:802,t:1527030386750};\\\", \\\"{x:1231,y:819,t:1527030386767};\\\", \\\"{x:1220,y:835,t:1527030386783};\\\", \\\"{x:1204,y:854,t:1527030386799};\\\", \\\"{x:1199,y:860,t:1527030386817};\\\", \\\"{x:1193,y:867,t:1527030386833};\\\", \\\"{x:1190,y:872,t:1527030386850};\\\", \\\"{x:1188,y:874,t:1527030386867};\\\", \\\"{x:1185,y:878,t:1527030386883};\\\", \\\"{x:1184,y:881,t:1527030386900};\\\", \\\"{x:1181,y:885,t:1527030386917};\\\", \\\"{x:1180,y:887,t:1527030386934};\\\", \\\"{x:1178,y:891,t:1527030386950};\\\", \\\"{x:1177,y:894,t:1527030386967};\\\", \\\"{x:1175,y:901,t:1527030386984};\\\", \\\"{x:1172,y:907,t:1527030386999};\\\", \\\"{x:1171,y:912,t:1527030387017};\\\", \\\"{x:1170,y:918,t:1527030387034};\\\", \\\"{x:1168,y:924,t:1527030387050};\\\", \\\"{x:1166,y:931,t:1527030387067};\\\", \\\"{x:1162,y:937,t:1527030387084};\\\", \\\"{x:1161,y:942,t:1527030387100};\\\", \\\"{x:1159,y:950,t:1527030387116};\\\", \\\"{x:1156,y:955,t:1527030387133};\\\", \\\"{x:1153,y:960,t:1527030387151};\\\", \\\"{x:1151,y:964,t:1527030387167};\\\", \\\"{x:1149,y:966,t:1527030387184};\\\", \\\"{x:1147,y:966,t:1527030387265};\\\", \\\"{x:1146,y:966,t:1527030387287};\\\", \\\"{x:1145,y:966,t:1527030387301};\\\", \\\"{x:1144,y:966,t:1527030387317};\\\", \\\"{x:1143,y:966,t:1527030387333};\\\", \\\"{x:1143,y:962,t:1527030387351};\\\", \\\"{x:1147,y:953,t:1527030387367};\\\", \\\"{x:1163,y:928,t:1527030387384};\\\", \\\"{x:1180,y:902,t:1527030387401};\\\", \\\"{x:1198,y:879,t:1527030387418};\\\", \\\"{x:1210,y:864,t:1527030387433};\\\", \\\"{x:1216,y:854,t:1527030387451};\\\", \\\"{x:1219,y:849,t:1527030387468};\\\", \\\"{x:1221,y:845,t:1527030387484};\\\", \\\"{x:1222,y:841,t:1527030387501};\\\", \\\"{x:1222,y:837,t:1527030387518};\\\", \\\"{x:1222,y:832,t:1527030387533};\\\", \\\"{x:1222,y:828,t:1527030387551};\\\", \\\"{x:1222,y:825,t:1527030387568};\\\", \\\"{x:1222,y:824,t:1527030387615};\\\", \\\"{x:1227,y:829,t:1527030388576};\\\", \\\"{x:1228,y:832,t:1527030388586};\\\", \\\"{x:1230,y:835,t:1527030388602};\\\", \\\"{x:1230,y:838,t:1527030388619};\\\", \\\"{x:1230,y:842,t:1527030388636};\\\", \\\"{x:1232,y:845,t:1527030388653};\\\", \\\"{x:1238,y:851,t:1527030388669};\\\", \\\"{x:1246,y:857,t:1527030388686};\\\", \\\"{x:1262,y:863,t:1527030388703};\\\", \\\"{x:1281,y:872,t:1527030388719};\\\", \\\"{x:1316,y:883,t:1527030388735};\\\", \\\"{x:1338,y:890,t:1527030388753};\\\", \\\"{x:1351,y:895,t:1527030388769};\\\", \\\"{x:1356,y:897,t:1527030388787};\\\", \\\"{x:1357,y:897,t:1527030388803};\\\", \\\"{x:1357,y:898,t:1527030388936};\\\", \\\"{x:1354,y:898,t:1527030388953};\\\", \\\"{x:1341,y:903,t:1527030388970};\\\", \\\"{x:1329,y:907,t:1527030388986};\\\", \\\"{x:1315,y:910,t:1527030389003};\\\", \\\"{x:1304,y:913,t:1527030389020};\\\", \\\"{x:1296,y:918,t:1527030389036};\\\", \\\"{x:1293,y:920,t:1527030389053};\\\", \\\"{x:1291,y:921,t:1527030389070};\\\", \\\"{x:1290,y:923,t:1527030389086};\\\", \\\"{x:1288,y:926,t:1527030389103};\\\", \\\"{x:1285,y:930,t:1527030389119};\\\", \\\"{x:1285,y:931,t:1527030389136};\\\", \\\"{x:1285,y:933,t:1527030389152};\\\", \\\"{x:1284,y:934,t:1527030389174};\\\", \\\"{x:1284,y:936,t:1527030389186};\\\", \\\"{x:1284,y:937,t:1527030389202};\\\", \\\"{x:1284,y:939,t:1527030389219};\\\", \\\"{x:1284,y:941,t:1527030389271};\\\", \\\"{x:1284,y:943,t:1527030389286};\\\", \\\"{x:1284,y:944,t:1527030389303};\\\", \\\"{x:1284,y:946,t:1527030389319};\\\", \\\"{x:1284,y:947,t:1527030389488};\\\", \\\"{x:1284,y:949,t:1527030389503};\\\", \\\"{x:1284,y:950,t:1527030389520};\\\", \\\"{x:1284,y:953,t:1527030389537};\\\", \\\"{x:1284,y:954,t:1527030389554};\\\", \\\"{x:1284,y:956,t:1527030389570};\\\", \\\"{x:1283,y:957,t:1527030389588};\\\", \\\"{x:1283,y:958,t:1527030389640};\\\", \\\"{x:1282,y:959,t:1527030389656};\\\", \\\"{x:1283,y:957,t:1527030389872};\\\", \\\"{x:1289,y:951,t:1527030389887};\\\", \\\"{x:1294,y:945,t:1527030389904};\\\", \\\"{x:1296,y:943,t:1527030389921};\\\", \\\"{x:1298,y:941,t:1527030389938};\\\", \\\"{x:1304,y:935,t:1527030389954};\\\", \\\"{x:1308,y:930,t:1527030389971};\\\", \\\"{x:1311,y:926,t:1527030389988};\\\", \\\"{x:1314,y:920,t:1527030390004};\\\", \\\"{x:1315,y:916,t:1527030390021};\\\", \\\"{x:1317,y:911,t:1527030390038};\\\", \\\"{x:1319,y:908,t:1527030390054};\\\", \\\"{x:1321,y:904,t:1527030390071};\\\", \\\"{x:1323,y:900,t:1527030390087};\\\", \\\"{x:1326,y:894,t:1527030390105};\\\", \\\"{x:1327,y:889,t:1527030390121};\\\", \\\"{x:1330,y:882,t:1527030390138};\\\", \\\"{x:1330,y:878,t:1527030390155};\\\", \\\"{x:1331,y:877,t:1527030390171};\\\", \\\"{x:1333,y:873,t:1527030390188};\\\", \\\"{x:1334,y:867,t:1527030390205};\\\", \\\"{x:1337,y:861,t:1527030390221};\\\", \\\"{x:1339,y:856,t:1527030390238};\\\", \\\"{x:1340,y:851,t:1527030390255};\\\", \\\"{x:1342,y:848,t:1527030390271};\\\", \\\"{x:1346,y:842,t:1527030390288};\\\", \\\"{x:1346,y:840,t:1527030390305};\\\", \\\"{x:1348,y:836,t:1527030390321};\\\", \\\"{x:1349,y:836,t:1527030390338};\\\", \\\"{x:1350,y:834,t:1527030390355};\\\", \\\"{x:1350,y:833,t:1527030390373};\\\", \\\"{x:1352,y:830,t:1527030390388};\\\", \\\"{x:1352,y:828,t:1527030390408};\\\", \\\"{x:1352,y:827,t:1527030390422};\\\", \\\"{x:1352,y:826,t:1527030390438};\\\", \\\"{x:1353,y:824,t:1527030390455};\\\", \\\"{x:1354,y:821,t:1527030390471};\\\", \\\"{x:1355,y:818,t:1527030390488};\\\", \\\"{x:1356,y:814,t:1527030390505};\\\", \\\"{x:1358,y:809,t:1527030390522};\\\", \\\"{x:1359,y:806,t:1527030390537};\\\", \\\"{x:1360,y:803,t:1527030390555};\\\", \\\"{x:1361,y:800,t:1527030390572};\\\", \\\"{x:1361,y:798,t:1527030390589};\\\", \\\"{x:1361,y:797,t:1527030390605};\\\", \\\"{x:1362,y:795,t:1527030390622};\\\", \\\"{x:1363,y:793,t:1527030390639};\\\", \\\"{x:1364,y:791,t:1527030390655};\\\", \\\"{x:1365,y:787,t:1527030390672};\\\", \\\"{x:1365,y:785,t:1527030390689};\\\", \\\"{x:1366,y:784,t:1527030390705};\\\", \\\"{x:1367,y:782,t:1527030390722};\\\", \\\"{x:1369,y:779,t:1527030390740};\\\", \\\"{x:1369,y:778,t:1527030390755};\\\", \\\"{x:1370,y:777,t:1527030390772};\\\", \\\"{x:1371,y:775,t:1527030390792};\\\", \\\"{x:1372,y:774,t:1527030390831};\\\", \\\"{x:1373,y:772,t:1527030390904};\\\", \\\"{x:1374,y:772,t:1527030390912};\\\", \\\"{x:1374,y:771,t:1527030390944};\\\", \\\"{x:1375,y:770,t:1527030391008};\\\", \\\"{x:1375,y:769,t:1527030391031};\\\", \\\"{x:1376,y:769,t:1527030391120};\\\", \\\"{x:1376,y:768,t:1527030391176};\\\", \\\"{x:1374,y:768,t:1527030392639};\\\", \\\"{x:1369,y:768,t:1527030392647};\\\", \\\"{x:1366,y:768,t:1527030392658};\\\", \\\"{x:1362,y:768,t:1527030392674};\\\", \\\"{x:1359,y:768,t:1527030392690};\\\", \\\"{x:1353,y:768,t:1527030392708};\\\", \\\"{x:1348,y:768,t:1527030392725};\\\", \\\"{x:1340,y:771,t:1527030392741};\\\", \\\"{x:1330,y:773,t:1527030392758};\\\", \\\"{x:1316,y:776,t:1527030392775};\\\", \\\"{x:1284,y:781,t:1527030392792};\\\", \\\"{x:1254,y:785,t:1527030392808};\\\", \\\"{x:1221,y:787,t:1527030392825};\\\", \\\"{x:1170,y:776,t:1527030392842};\\\", \\\"{x:1086,y:752,t:1527030392858};\\\", \\\"{x:1004,y:731,t:1527030392875};\\\", \\\"{x:910,y:710,t:1527030392892};\\\", \\\"{x:846,y:689,t:1527030392908};\\\", \\\"{x:785,y:665,t:1527030392925};\\\", \\\"{x:685,y:631,t:1527030392943};\\\", \\\"{x:590,y:615,t:1527030392958};\\\", \\\"{x:496,y:602,t:1527030392975};\\\", \\\"{x:477,y:602,t:1527030392997};\\\", \\\"{x:472,y:602,t:1527030393013};\\\", \\\"{x:470,y:602,t:1527030393030};\\\", \\\"{x:469,y:602,t:1527030393055};\\\", \\\"{x:466,y:602,t:1527030393063};\\\", \\\"{x:461,y:601,t:1527030393080};\\\", \\\"{x:453,y:598,t:1527030393097};\\\", \\\"{x:443,y:594,t:1527030393114};\\\", \\\"{x:430,y:593,t:1527030393130};\\\", \\\"{x:413,y:593,t:1527030393148};\\\", \\\"{x:403,y:593,t:1527030393164};\\\", \\\"{x:389,y:593,t:1527030393181};\\\", \\\"{x:374,y:594,t:1527030393198};\\\", \\\"{x:345,y:594,t:1527030393215};\\\", \\\"{x:323,y:593,t:1527030393231};\\\", \\\"{x:298,y:589,t:1527030393247};\\\", \\\"{x:282,y:585,t:1527030393264};\\\", \\\"{x:276,y:582,t:1527030393281};\\\", \\\"{x:270,y:579,t:1527030393298};\\\", \\\"{x:269,y:578,t:1527030393314};\\\", \\\"{x:269,y:577,t:1527030393335};\\\", \\\"{x:269,y:576,t:1527030393351};\\\", \\\"{x:269,y:575,t:1527030393364};\\\", \\\"{x:282,y:566,t:1527030393380};\\\", \\\"{x:305,y:558,t:1527030393397};\\\", \\\"{x:342,y:541,t:1527030393415};\\\", \\\"{x:362,y:532,t:1527030393431};\\\", \\\"{x:365,y:531,t:1527030393447};\\\", \\\"{x:368,y:529,t:1527030393464};\\\", \\\"{x:370,y:529,t:1527030393487};\\\", \\\"{x:374,y:529,t:1527030393576};\\\", \\\"{x:380,y:530,t:1527030393583};\\\", \\\"{x:384,y:532,t:1527030393598};\\\", \\\"{x:391,y:540,t:1527030393616};\\\", \\\"{x:396,y:543,t:1527030393630};\\\", \\\"{x:398,y:548,t:1527030393649};\\\", \\\"{x:398,y:550,t:1527030393664};\\\", \\\"{x:398,y:553,t:1527030393681};\\\", \\\"{x:398,y:556,t:1527030393698};\\\", \\\"{x:402,y:556,t:1527030394336};\\\", \\\"{x:407,y:557,t:1527030394348};\\\", \\\"{x:424,y:557,t:1527030394366};\\\", \\\"{x:457,y:557,t:1527030394382};\\\", \\\"{x:552,y:557,t:1527030394399};\\\", \\\"{x:608,y:557,t:1527030394416};\\\", \\\"{x:668,y:562,t:1527030394432};\\\", \\\"{x:720,y:565,t:1527030394448};\\\", \\\"{x:756,y:565,t:1527030394465};\\\", \\\"{x:781,y:567,t:1527030394481};\\\", \\\"{x:801,y:571,t:1527030394498};\\\", \\\"{x:826,y:577,t:1527030394515};\\\", \\\"{x:856,y:594,t:1527030394532};\\\", \\\"{x:877,y:607,t:1527030394549};\\\", \\\"{x:902,y:622,t:1527030394566};\\\", \\\"{x:926,y:635,t:1527030394582};\\\", \\\"{x:966,y:651,t:1527030394599};\\\", \\\"{x:991,y:665,t:1527030394615};\\\", \\\"{x:1012,y:678,t:1527030394632};\\\", \\\"{x:1032,y:692,t:1527030394649};\\\", \\\"{x:1050,y:706,t:1527030394665};\\\", \\\"{x:1068,y:715,t:1527030394682};\\\", \\\"{x:1081,y:721,t:1527030394699};\\\", \\\"{x:1086,y:723,t:1527030394715};\\\", \\\"{x:1091,y:725,t:1527030394732};\\\", \\\"{x:1094,y:726,t:1527030394749};\\\", \\\"{x:1098,y:728,t:1527030394765};\\\", \\\"{x:1103,y:729,t:1527030394782};\\\", \\\"{x:1110,y:733,t:1527030394799};\\\", \\\"{x:1112,y:735,t:1527030394816};\\\", \\\"{x:1113,y:735,t:1527030394888};\\\", \\\"{x:1115,y:735,t:1527030394904};\\\", \\\"{x:1117,y:735,t:1527030394915};\\\", \\\"{x:1127,y:741,t:1527030394932};\\\", \\\"{x:1136,y:747,t:1527030394950};\\\", \\\"{x:1142,y:749,t:1527030394964};\\\", \\\"{x:1147,y:751,t:1527030394981};\\\", \\\"{x:1157,y:753,t:1527030394997};\\\", \\\"{x:1185,y:756,t:1527030395014};\\\", \\\"{x:1197,y:759,t:1527030395031};\\\", \\\"{x:1205,y:763,t:1527030395048};\\\", \\\"{x:1209,y:764,t:1527030395065};\\\", \\\"{x:1214,y:767,t:1527030395081};\\\", \\\"{x:1225,y:771,t:1527030395098};\\\", \\\"{x:1230,y:773,t:1527030395115};\\\", \\\"{x:1237,y:775,t:1527030395131};\\\", \\\"{x:1239,y:777,t:1527030395148};\\\", \\\"{x:1245,y:779,t:1527030395164};\\\", \\\"{x:1248,y:780,t:1527030395182};\\\", \\\"{x:1250,y:782,t:1527030395197};\\\", \\\"{x:1255,y:787,t:1527030395215};\\\", \\\"{x:1256,y:791,t:1527030395231};\\\", \\\"{x:1257,y:797,t:1527030395249};\\\", \\\"{x:1258,y:803,t:1527030395265};\\\", \\\"{x:1259,y:810,t:1527030395282};\\\", \\\"{x:1261,y:819,t:1527030395298};\\\", \\\"{x:1264,y:824,t:1527030395316};\\\", \\\"{x:1268,y:831,t:1527030395332};\\\", \\\"{x:1272,y:836,t:1527030395348};\\\", \\\"{x:1275,y:843,t:1527030395365};\\\", \\\"{x:1278,y:847,t:1527030395381};\\\", \\\"{x:1279,y:851,t:1527030395399};\\\", \\\"{x:1281,y:857,t:1527030395416};\\\", \\\"{x:1281,y:861,t:1527030395432};\\\", \\\"{x:1281,y:865,t:1527030395447};\\\", \\\"{x:1281,y:868,t:1527030395465};\\\", \\\"{x:1281,y:871,t:1527030395481};\\\", \\\"{x:1281,y:872,t:1527030395498};\\\", \\\"{x:1281,y:873,t:1527030395515};\\\", \\\"{x:1281,y:874,t:1527030395536};\\\", \\\"{x:1281,y:875,t:1527030395551};\\\", \\\"{x:1281,y:876,t:1527030395575};\\\", \\\"{x:1281,y:877,t:1527030395584};\\\", \\\"{x:1281,y:878,t:1527030395600};\\\", \\\"{x:1281,y:879,t:1527030395624};\\\", \\\"{x:1281,y:880,t:1527030395656};\\\", \\\"{x:1282,y:881,t:1527030395664};\\\", \\\"{x:1283,y:881,t:1527030395687};\\\", \\\"{x:1284,y:881,t:1527030395953};\\\", \\\"{x:1285,y:881,t:1527030396031};\\\", \\\"{x:1286,y:879,t:1527030396046};\\\", \\\"{x:1288,y:878,t:1527030396063};\\\", \\\"{x:1289,y:876,t:1527030396080};\\\", \\\"{x:1291,y:872,t:1527030396097};\\\", \\\"{x:1294,y:869,t:1527030396113};\\\", \\\"{x:1296,y:865,t:1527030396131};\\\", \\\"{x:1299,y:860,t:1527030396146};\\\", \\\"{x:1303,y:853,t:1527030396163};\\\", \\\"{x:1307,y:846,t:1527030396181};\\\", \\\"{x:1308,y:841,t:1527030396197};\\\", \\\"{x:1310,y:837,t:1527030396214};\\\", \\\"{x:1311,y:829,t:1527030396232};\\\", \\\"{x:1312,y:821,t:1527030396248};\\\", \\\"{x:1316,y:811,t:1527030396264};\\\", \\\"{x:1327,y:797,t:1527030396281};\\\", \\\"{x:1345,y:785,t:1527030396297};\\\", \\\"{x:1362,y:772,t:1527030396314};\\\", \\\"{x:1377,y:761,t:1527030396330};\\\", \\\"{x:1388,y:750,t:1527030396347};\\\", \\\"{x:1401,y:735,t:1527030396363};\\\", \\\"{x:1413,y:720,t:1527030396379};\\\", \\\"{x:1422,y:708,t:1527030396396};\\\", \\\"{x:1427,y:704,t:1527030396414};\\\", \\\"{x:1431,y:697,t:1527030396429};\\\", \\\"{x:1440,y:685,t:1527030396447};\\\", \\\"{x:1450,y:671,t:1527030396463};\\\", \\\"{x:1455,y:662,t:1527030396479};\\\", \\\"{x:1462,y:648,t:1527030396497};\\\", \\\"{x:1468,y:638,t:1527030396514};\\\", \\\"{x:1471,y:628,t:1527030396530};\\\", \\\"{x:1474,y:621,t:1527030396547};\\\", \\\"{x:1476,y:615,t:1527030396563};\\\", \\\"{x:1476,y:611,t:1527030396580};\\\", \\\"{x:1479,y:602,t:1527030396596};\\\", \\\"{x:1481,y:594,t:1527030396613};\\\", \\\"{x:1482,y:588,t:1527030396630};\\\", \\\"{x:1483,y:578,t:1527030396647};\\\", \\\"{x:1487,y:569,t:1527030396663};\\\", \\\"{x:1488,y:565,t:1527030396680};\\\", \\\"{x:1491,y:558,t:1527030396697};\\\", \\\"{x:1492,y:553,t:1527030396713};\\\", \\\"{x:1495,y:547,t:1527030396730};\\\", \\\"{x:1500,y:539,t:1527030396747};\\\", \\\"{x:1504,y:530,t:1527030396763};\\\", \\\"{x:1507,y:518,t:1527030396780};\\\", \\\"{x:1512,y:506,t:1527030396797};\\\", \\\"{x:1517,y:496,t:1527030396813};\\\", \\\"{x:1521,y:488,t:1527030396830};\\\", \\\"{x:1527,y:479,t:1527030396847};\\\", \\\"{x:1529,y:475,t:1527030396863};\\\", \\\"{x:1531,y:472,t:1527030396879};\\\", \\\"{x:1532,y:469,t:1527030396897};\\\", \\\"{x:1533,y:465,t:1527030396914};\\\", \\\"{x:1534,y:462,t:1527030396931};\\\", \\\"{x:1534,y:460,t:1527030396947};\\\", \\\"{x:1535,y:459,t:1527030396963};\\\", \\\"{x:1534,y:459,t:1527030397120};\\\", \\\"{x:1531,y:459,t:1527030397130};\\\", \\\"{x:1523,y:464,t:1527030397146};\\\", \\\"{x:1511,y:470,t:1527030397163};\\\", \\\"{x:1490,y:479,t:1527030397180};\\\", \\\"{x:1467,y:488,t:1527030397196};\\\", \\\"{x:1448,y:497,t:1527030397213};\\\", \\\"{x:1427,y:504,t:1527030397231};\\\", \\\"{x:1382,y:517,t:1527030397247};\\\", \\\"{x:1277,y:533,t:1527030397263};\\\", \\\"{x:1170,y:559,t:1527030397280};\\\", \\\"{x:1068,y:587,t:1527030397296};\\\", \\\"{x:949,y:616,t:1527030397313};\\\", \\\"{x:826,y:646,t:1527030397329};\\\", \\\"{x:701,y:679,t:1527030397346};\\\", \\\"{x:589,y:702,t:1527030397363};\\\", \\\"{x:478,y:722,t:1527030397381};\\\", \\\"{x:386,y:747,t:1527030397396};\\\", \\\"{x:337,y:760,t:1527030397412};\\\", \\\"{x:305,y:766,t:1527030397434};\\\", \\\"{x:302,y:767,t:1527030397450};\\\", \\\"{x:302,y:768,t:1527030397510};\\\", \\\"{x:300,y:768,t:1527030397518};\\\", \\\"{x:295,y:772,t:1527030397535};\\\", \\\"{x:288,y:780,t:1527030397550};\\\", \\\"{x:286,y:784,t:1527030397568};\\\", \\\"{x:286,y:785,t:1527030397656};\\\", \\\"{x:290,y:784,t:1527030397668};\\\", \\\"{x:313,y:773,t:1527030397685};\\\", \\\"{x:342,y:764,t:1527030397701};\\\", \\\"{x:366,y:759,t:1527030397718};\\\", \\\"{x:397,y:753,t:1527030397735};\\\", \\\"{x:405,y:751,t:1527030397751};\\\", \\\"{x:407,y:750,t:1527030397768};\\\", \\\"{x:408,y:750,t:1527030397807};\\\", \\\"{x:409,y:750,t:1527030397818};\\\", \\\"{x:412,y:747,t:1527030397835};\\\", \\\"{x:418,y:745,t:1527030397852};\\\", \\\"{x:424,y:742,t:1527030397868};\\\", \\\"{x:430,y:739,t:1527030397885};\\\", \\\"{x:438,y:737,t:1527030397902};\\\", \\\"{x:448,y:734,t:1527030397918};\\\", \\\"{x:462,y:729,t:1527030397936};\\\", \\\"{x:466,y:727,t:1527030397951};\\\", \\\"{x:469,y:726,t:1527030397968};\\\", \\\"{x:471,y:725,t:1527030397984};\\\", \\\"{x:473,y:723,t:1527030398002};\\\", \\\"{x:475,y:722,t:1527030398019};\\\", \\\"{x:479,y:720,t:1527030398035};\\\", \\\"{x:484,y:718,t:1527030398051};\\\", \\\"{x:487,y:715,t:1527030398069};\\\", \\\"{x:489,y:715,t:1527030398084};\\\", \\\"{x:491,y:714,t:1527030398102};\\\", \\\"{x:493,y:713,t:1527030398119};\\\", \\\"{x:495,y:712,t:1527030398135};\\\", \\\"{x:496,y:712,t:1527030398224};\\\", \\\"{x:495,y:712,t:1527030398767};\\\", \\\"{x:494,y:713,t:1527030398871};\\\", \\\"{x:493,y:713,t:1527030398928};\\\", \\\"{x:492,y:713,t:1527030399192};\\\", \\\"{x:493,y:713,t:1527030399728};\\\", \\\"{x:495,y:711,t:1527030399738};\\\", \\\"{x:500,y:708,t:1527030399755};\\\", \\\"{x:501,y:708,t:1527030399771};\\\", \\\"{x:503,y:707,t:1527030399788};\\\", \\\"{x:505,y:705,t:1527030399804};\\\", \\\"{x:512,y:701,t:1527030399822};\\\", \\\"{x:523,y:696,t:1527030399839};\\\", \\\"{x:553,y:689,t:1527030399854};\\\", \\\"{x:577,y:683,t:1527030399870};\\\", \\\"{x:594,y:678,t:1527030399885};\\\", \\\"{x:636,y:666,t:1527030399902};\\\", \\\"{x:676,y:660,t:1527030399919};\\\", \\\"{x:702,y:651,t:1527030399935};\\\", \\\"{x:729,y:646,t:1527030399952};\\\", \\\"{x:748,y:643,t:1527030399970};\\\", \\\"{x:765,y:641,t:1527030399986};\\\", \\\"{x:770,y:641,t:1527030400003};\\\", \\\"{x:771,y:641,t:1527030400020};\\\", \\\"{x:773,y:641,t:1527030400036};\\\", \\\"{x:774,y:640,t:1527030400052};\\\", \\\"{x:779,y:639,t:1527030400070};\\\", \\\"{x:792,y:639,t:1527030400087};\\\", \\\"{x:805,y:639,t:1527030400103};\\\", \\\"{x:827,y:639,t:1527030400120};\\\", \\\"{x:848,y:639,t:1527030400137};\\\", \\\"{x:870,y:639,t:1527030400153};\\\", \\\"{x:891,y:639,t:1527030400170};\\\", \\\"{x:918,y:639,t:1527030400188};\\\", \\\"{x:946,y:639,t:1527030400203};\\\", \\\"{x:967,y:643,t:1527030400220};\\\", \\\"{x:984,y:644,t:1527030400237};\\\", \\\"{x:995,y:648,t:1527030400253};\\\", \\\"{x:1011,y:651,t:1527030400270};\\\", \\\"{x:1050,y:667,t:1527030400286};\\\", \\\"{x:1086,y:676,t:1527030400302};\\\", \\\"{x:1128,y:687,t:1527030400320};\\\", \\\"{x:1161,y:702,t:1527030400337};\\\", \\\"{x:1181,y:713,t:1527030400353};\\\", \\\"{x:1205,y:726,t:1527030400370};\\\", \\\"{x:1233,y:741,t:1527030400386};\\\", \\\"{x:1253,y:752,t:1527030400402};\\\", \\\"{x:1267,y:763,t:1527030400419};\\\", \\\"{x:1274,y:769,t:1527030400437};\\\", \\\"{x:1281,y:778,t:1527030400453};\\\", \\\"{x:1287,y:784,t:1527030400470};\\\", \\\"{x:1300,y:798,t:1527030400487};\\\", \\\"{x:1307,y:803,t:1527030400503};\\\", \\\"{x:1317,y:810,t:1527030400520};\\\", \\\"{x:1325,y:817,t:1527030400536};\\\", \\\"{x:1335,y:826,t:1527030400553};\\\", \\\"{x:1340,y:833,t:1527030400570};\\\", \\\"{x:1340,y:834,t:1527030400587};\\\", \\\"{x:1340,y:835,t:1527030401248};\\\", \\\"{x:1340,y:836,t:1527030401255};\\\", \\\"{x:1341,y:839,t:1527030401271};\\\", \\\"{x:1342,y:846,t:1527030401287};\\\", \\\"{x:1344,y:853,t:1527030401304};\\\", \\\"{x:1344,y:861,t:1527030401322};\\\", \\\"{x:1344,y:870,t:1527030401338};\\\", \\\"{x:1344,y:878,t:1527030401355};\\\", \\\"{x:1344,y:885,t:1527030401371};\\\", \\\"{x:1344,y:891,t:1527030401387};\\\", \\\"{x:1345,y:896,t:1527030401405};\\\", \\\"{x:1345,y:897,t:1527030401422};\\\", \\\"{x:1346,y:900,t:1527030401437};\\\", \\\"{x:1347,y:901,t:1527030401454};\\\", \\\"{x:1349,y:902,t:1527030401471};\\\", \\\"{x:1350,y:902,t:1527030401489};\\\", \\\"{x:1351,y:902,t:1527030401536};\\\", \\\"{x:1354,y:895,t:1527030401543};\\\", \\\"{x:1360,y:884,t:1527030401555};\\\", \\\"{x:1367,y:863,t:1527030401571};\\\", \\\"{x:1377,y:837,t:1527030401589};\\\", \\\"{x:1384,y:809,t:1527030401604};\\\", \\\"{x:1389,y:783,t:1527030401621};\\\", \\\"{x:1389,y:758,t:1527030401638};\\\", \\\"{x:1389,y:735,t:1527030401654};\\\", \\\"{x:1389,y:724,t:1527030401672};\\\", \\\"{x:1392,y:725,t:1527030401792};\\\", \\\"{x:1394,y:727,t:1527030401804};\\\", \\\"{x:1400,y:739,t:1527030401821};\\\", \\\"{x:1405,y:750,t:1527030401838};\\\", \\\"{x:1409,y:761,t:1527030401855};\\\", \\\"{x:1410,y:769,t:1527030401871};\\\", \\\"{x:1411,y:771,t:1527030401889};\\\", \\\"{x:1411,y:772,t:1527030401992};\\\", \\\"{x:1409,y:772,t:1527030402007};\\\", \\\"{x:1408,y:772,t:1527030402022};\\\", \\\"{x:1406,y:771,t:1527030402038};\\\", \\\"{x:1402,y:770,t:1527030402056};\\\", \\\"{x:1401,y:769,t:1527030402071};\\\", \\\"{x:1400,y:769,t:1527030402088};\\\", \\\"{x:1399,y:768,t:1527030402119};\\\", \\\"{x:1398,y:768,t:1527030402151};\\\", \\\"{x:1397,y:768,t:1527030402160};\\\", \\\"{x:1396,y:767,t:1527030402171};\\\", \\\"{x:1395,y:767,t:1527030402207};\\\", \\\"{x:1394,y:767,t:1527030402272};\\\", \\\"{x:1397,y:773,t:1527030402398};\\\", \\\"{x:1401,y:779,t:1527030402407};\\\", \\\"{x:1402,y:781,t:1527030402422};\\\", \\\"{x:1407,y:788,t:1527030402438};\\\", \\\"{x:1413,y:796,t:1527030402454};\\\", \\\"{x:1417,y:802,t:1527030402472};\\\", \\\"{x:1419,y:807,t:1527030402488};\\\", \\\"{x:1421,y:811,t:1527030402505};\\\", \\\"{x:1422,y:815,t:1527030402521};\\\", \\\"{x:1425,y:819,t:1527030402538};\\\", \\\"{x:1425,y:824,t:1527030402555};\\\", \\\"{x:1427,y:830,t:1527030402572};\\\", \\\"{x:1429,y:838,t:1527030402588};\\\", \\\"{x:1434,y:848,t:1527030402605};\\\", \\\"{x:1438,y:858,t:1527030402622};\\\", \\\"{x:1440,y:862,t:1527030402638};\\\", \\\"{x:1443,y:868,t:1527030402655};\\\", \\\"{x:1443,y:871,t:1527030402672};\\\", \\\"{x:1445,y:874,t:1527030402688};\\\", \\\"{x:1446,y:876,t:1527030402706};\\\", \\\"{x:1447,y:877,t:1527030402722};\\\", \\\"{x:1447,y:879,t:1527030402738};\\\", \\\"{x:1447,y:881,t:1527030402756};\\\", \\\"{x:1449,y:883,t:1527030402772};\\\", \\\"{x:1449,y:884,t:1527030402788};\\\", \\\"{x:1449,y:888,t:1527030402805};\\\", \\\"{x:1449,y:890,t:1527030402823};\\\", \\\"{x:1449,y:894,t:1527030402838};\\\", \\\"{x:1450,y:896,t:1527030402856};\\\", \\\"{x:1450,y:898,t:1527030402873};\\\", \\\"{x:1450,y:899,t:1527030402889};\\\", \\\"{x:1450,y:900,t:1527030402906};\\\", \\\"{x:1450,y:901,t:1527030402927};\\\", \\\"{x:1450,y:902,t:1527030403120};\\\", \\\"{x:1450,y:903,t:1527030403320};\\\", \\\"{x:1450,y:904,t:1527030403376};\\\", \\\"{x:1450,y:905,t:1527030403391};\\\", \\\"{x:1450,y:906,t:1527030403407};\\\", \\\"{x:1450,y:907,t:1527030403431};\\\", \\\"{x:1450,y:908,t:1527030403439};\\\", \\\"{x:1449,y:909,t:1527030403455};\\\", \\\"{x:1449,y:910,t:1527030403488};\\\", \\\"{x:1449,y:911,t:1527030403503};\\\", \\\"{x:1449,y:912,t:1527030403527};\\\", \\\"{x:1448,y:913,t:1527030403560};\\\", \\\"{x:1448,y:914,t:1527030403583};\\\", \\\"{x:1448,y:916,t:1527030403608};\\\", \\\"{x:1447,y:916,t:1527030403623};\\\", \\\"{x:1447,y:917,t:1527030403639};\\\", \\\"{x:1446,y:917,t:1527030403679};\\\", \\\"{x:1445,y:918,t:1527030403720};\\\", \\\"{x:1444,y:919,t:1527030403792};\\\", \\\"{x:1444,y:920,t:1527030403806};\\\", \\\"{x:1443,y:920,t:1527030403839};\\\", \\\"{x:1443,y:921,t:1527030403912};\\\", \\\"{x:1441,y:921,t:1527030403992};\\\", \\\"{x:1440,y:921,t:1527030404006};\\\", \\\"{x:1436,y:921,t:1527030404023};\\\", \\\"{x:1429,y:922,t:1527030404040};\\\", \\\"{x:1424,y:924,t:1527030404056};\\\", \\\"{x:1421,y:924,t:1527030404074};\\\", \\\"{x:1413,y:926,t:1527030404090};\\\", \\\"{x:1404,y:926,t:1527030404110};\\\", \\\"{x:1388,y:928,t:1527030404123};\\\", \\\"{x:1381,y:930,t:1527030404138};\\\", \\\"{x:1376,y:931,t:1527030404156};\\\", \\\"{x:1375,y:932,t:1527030404173};\\\", \\\"{x:1372,y:932,t:1527030404188};\\\", \\\"{x:1367,y:933,t:1527030404206};\\\", \\\"{x:1360,y:935,t:1527030404222};\\\", \\\"{x:1356,y:935,t:1527030404239};\\\", \\\"{x:1356,y:936,t:1527030404256};\\\", \\\"{x:1354,y:936,t:1527030404319};\\\", \\\"{x:1351,y:938,t:1527030404327};\\\", \\\"{x:1350,y:939,t:1527030404344};\\\", \\\"{x:1349,y:939,t:1527030404357};\\\", \\\"{x:1346,y:939,t:1527030404373};\\\", \\\"{x:1342,y:941,t:1527030404391};\\\", \\\"{x:1340,y:941,t:1527030404407};\\\", \\\"{x:1335,y:943,t:1527030404423};\\\", \\\"{x:1329,y:945,t:1527030404440};\\\", \\\"{x:1326,y:947,t:1527030404457};\\\", \\\"{x:1323,y:949,t:1527030404473};\\\", \\\"{x:1319,y:952,t:1527030404490};\\\", \\\"{x:1316,y:954,t:1527030404506};\\\", \\\"{x:1312,y:957,t:1527030404523};\\\", \\\"{x:1310,y:958,t:1527030404540};\\\", \\\"{x:1309,y:959,t:1527030404680};\\\", \\\"{x:1307,y:961,t:1527030404696};\\\", \\\"{x:1307,y:962,t:1527030404707};\\\", \\\"{x:1305,y:965,t:1527030404724};\\\", \\\"{x:1305,y:967,t:1527030404740};\\\", \\\"{x:1305,y:968,t:1527030404757};\\\", \\\"{x:1305,y:966,t:1527030404904};\\\", \\\"{x:1307,y:960,t:1527030404912};\\\", \\\"{x:1312,y:951,t:1527030404924};\\\", \\\"{x:1315,y:941,t:1527030404941};\\\", \\\"{x:1319,y:930,t:1527030404958};\\\", \\\"{x:1325,y:917,t:1527030404975};\\\", \\\"{x:1332,y:902,t:1527030404990};\\\", \\\"{x:1346,y:873,t:1527030405007};\\\", \\\"{x:1361,y:846,t:1527030405024};\\\", \\\"{x:1377,y:805,t:1527030405040};\\\", \\\"{x:1388,y:777,t:1527030405057};\\\", \\\"{x:1394,y:749,t:1527030405074};\\\", \\\"{x:1397,y:728,t:1527030405090};\\\", \\\"{x:1400,y:714,t:1527030405108};\\\", \\\"{x:1400,y:708,t:1527030405124};\\\", \\\"{x:1400,y:707,t:1527030405140};\\\", \\\"{x:1400,y:710,t:1527030405416};\\\", \\\"{x:1401,y:720,t:1527030405424};\\\", \\\"{x:1401,y:733,t:1527030405441};\\\", \\\"{x:1401,y:751,t:1527030405458};\\\", \\\"{x:1402,y:768,t:1527030405474};\\\", \\\"{x:1402,y:782,t:1527030405491};\\\", \\\"{x:1405,y:796,t:1527030405508};\\\", \\\"{x:1407,y:806,t:1527030405524};\\\", \\\"{x:1407,y:812,t:1527030405541};\\\", \\\"{x:1407,y:814,t:1527030405557};\\\", \\\"{x:1407,y:815,t:1527030405575};\\\", \\\"{x:1407,y:816,t:1527030405591};\\\", \\\"{x:1404,y:814,t:1527030405720};\\\", \\\"{x:1402,y:812,t:1527030405728};\\\", \\\"{x:1400,y:811,t:1527030405742};\\\", \\\"{x:1392,y:806,t:1527030405757};\\\", \\\"{x:1389,y:801,t:1527030405775};\\\", \\\"{x:1383,y:791,t:1527030405792};\\\", \\\"{x:1378,y:780,t:1527030405807};\\\", \\\"{x:1373,y:768,t:1527030405825};\\\", \\\"{x:1369,y:760,t:1527030405842};\\\", \\\"{x:1367,y:755,t:1527030405858};\\\", \\\"{x:1364,y:746,t:1527030405874};\\\", \\\"{x:1361,y:739,t:1527030405891};\\\", \\\"{x:1360,y:736,t:1527030405908};\\\", \\\"{x:1360,y:735,t:1527030405924};\\\", \\\"{x:1360,y:734,t:1527030405959};\\\", \\\"{x:1361,y:734,t:1527030405975};\\\", \\\"{x:1373,y:740,t:1527030405991};\\\", \\\"{x:1377,y:744,t:1527030406008};\\\", \\\"{x:1377,y:745,t:1527030406118};\\\", \\\"{x:1377,y:747,t:1527030406126};\\\", \\\"{x:1377,y:752,t:1527030406140};\\\", \\\"{x:1377,y:758,t:1527030406157};\\\", \\\"{x:1377,y:764,t:1527030406174};\\\", \\\"{x:1374,y:774,t:1527030406191};\\\", \\\"{x:1371,y:778,t:1527030406208};\\\", \\\"{x:1371,y:779,t:1527030406224};\\\", \\\"{x:1369,y:780,t:1527030406241};\\\", \\\"{x:1367,y:783,t:1527030406258};\\\", \\\"{x:1366,y:784,t:1527030406279};\\\", \\\"{x:1366,y:785,t:1527030406319};\\\", \\\"{x:1365,y:786,t:1527030406327};\\\", \\\"{x:1364,y:787,t:1527030406351};\\\", \\\"{x:1363,y:788,t:1527030406358};\\\", \\\"{x:1362,y:788,t:1527030406383};\\\", \\\"{x:1361,y:789,t:1527030406704};\\\", \\\"{x:1357,y:790,t:1527030406711};\\\", \\\"{x:1356,y:791,t:1527030406726};\\\", \\\"{x:1355,y:792,t:1527030406742};\\\", \\\"{x:1352,y:795,t:1527030406758};\\\", \\\"{x:1350,y:797,t:1527030406776};\\\", \\\"{x:1350,y:798,t:1527030406792};\\\", \\\"{x:1349,y:798,t:1527030406808};\\\", \\\"{x:1349,y:799,t:1527030406832};\\\", \\\"{x:1349,y:800,t:1527030406999};\\\", \\\"{x:1349,y:801,t:1527030407023};\\\", \\\"{x:1349,y:802,t:1527030407031};\\\", \\\"{x:1349,y:804,t:1527030407041};\\\", \\\"{x:1349,y:807,t:1527030407058};\\\", \\\"{x:1348,y:808,t:1527030407076};\\\", \\\"{x:1348,y:810,t:1527030407091};\\\", \\\"{x:1348,y:811,t:1527030407108};\\\", \\\"{x:1348,y:812,t:1527030407127};\\\", \\\"{x:1348,y:813,t:1527030407143};\\\", \\\"{x:1348,y:814,t:1527030407159};\\\", \\\"{x:1347,y:815,t:1527030407175};\\\", \\\"{x:1347,y:817,t:1527030407193};\\\", \\\"{x:1347,y:819,t:1527030407209};\\\", \\\"{x:1347,y:820,t:1527030407226};\\\", \\\"{x:1347,y:823,t:1527030407243};\\\", \\\"{x:1347,y:824,t:1527030407259};\\\", \\\"{x:1347,y:826,t:1527030407276};\\\", \\\"{x:1347,y:827,t:1527030407292};\\\", \\\"{x:1347,y:829,t:1527030407307};\\\", \\\"{x:1347,y:830,t:1527030407325};\\\", \\\"{x:1347,y:831,t:1527030407341};\\\", \\\"{x:1347,y:832,t:1527030407358};\\\", \\\"{x:1347,y:834,t:1527030407375};\\\", \\\"{x:1346,y:836,t:1527030407392};\\\", \\\"{x:1346,y:837,t:1527030407415};\\\", \\\"{x:1346,y:838,t:1527030407425};\\\", \\\"{x:1346,y:839,t:1527030407442};\\\", \\\"{x:1345,y:839,t:1527030407458};\\\", \\\"{x:1345,y:840,t:1527030407703};\\\", \\\"{x:1345,y:841,t:1527030407824};\\\", \\\"{x:1345,y:842,t:1527030408055};\\\", \\\"{x:1344,y:845,t:1527030408440};\\\", \\\"{x:1343,y:846,t:1527030408455};\\\", \\\"{x:1343,y:847,t:1527030408463};\\\", \\\"{x:1343,y:848,t:1527030408477};\\\", \\\"{x:1343,y:851,t:1527030408493};\\\", \\\"{x:1343,y:854,t:1527030408509};\\\", \\\"{x:1343,y:860,t:1527030408527};\\\", \\\"{x:1343,y:867,t:1527030408543};\\\", \\\"{x:1343,y:877,t:1527030408560};\\\", \\\"{x:1343,y:882,t:1527030408576};\\\", \\\"{x:1343,y:886,t:1527030408594};\\\", \\\"{x:1343,y:890,t:1527030408610};\\\", \\\"{x:1342,y:893,t:1527030408627};\\\", \\\"{x:1342,y:896,t:1527030408644};\\\", \\\"{x:1342,y:899,t:1527030408661};\\\", \\\"{x:1342,y:902,t:1527030408677};\\\", \\\"{x:1341,y:904,t:1527030408694};\\\", \\\"{x:1341,y:906,t:1527030408710};\\\", \\\"{x:1340,y:909,t:1527030408727};\\\", \\\"{x:1340,y:913,t:1527030408743};\\\", \\\"{x:1340,y:915,t:1527030408759};\\\", \\\"{x:1340,y:918,t:1527030408777};\\\", \\\"{x:1340,y:920,t:1527030408794};\\\", \\\"{x:1340,y:922,t:1527030408810};\\\", \\\"{x:1340,y:923,t:1527030408827};\\\", \\\"{x:1340,y:924,t:1527030408844};\\\", \\\"{x:1340,y:925,t:1527030408859};\\\", \\\"{x:1341,y:926,t:1527030408888};\\\", \\\"{x:1341,y:927,t:1527030408911};\\\", \\\"{x:1341,y:928,t:1527030408928};\\\", \\\"{x:1342,y:928,t:1527030408944};\\\", \\\"{x:1342,y:929,t:1527030408960};\\\", \\\"{x:1343,y:931,t:1527030408983};\\\", \\\"{x:1344,y:931,t:1527030408999};\\\", \\\"{x:1344,y:932,t:1527030409040};\\\", \\\"{x:1344,y:933,t:1527030409047};\\\", \\\"{x:1344,y:934,t:1527030409119};\\\", \\\"{x:1344,y:935,t:1527030409151};\\\", \\\"{x:1344,y:936,t:1527030409167};\\\", \\\"{x:1344,y:937,t:1527030409176};\\\", \\\"{x:1344,y:938,t:1527030409194};\\\", \\\"{x:1343,y:940,t:1527030409211};\\\", \\\"{x:1343,y:941,t:1527030409226};\\\", \\\"{x:1342,y:942,t:1527030409244};\\\", \\\"{x:1341,y:944,t:1527030409261};\\\", \\\"{x:1340,y:945,t:1527030409276};\\\", \\\"{x:1339,y:946,t:1527030409295};\\\", \\\"{x:1338,y:947,t:1527030409335};\\\", \\\"{x:1337,y:947,t:1527030409351};\\\", \\\"{x:1336,y:947,t:1527030409367};\\\", \\\"{x:1334,y:947,t:1527030409376};\\\", \\\"{x:1332,y:947,t:1527030409393};\\\", \\\"{x:1328,y:947,t:1527030409411};\\\", \\\"{x:1327,y:947,t:1527030409427};\\\", \\\"{x:1325,y:947,t:1527030409444};\\\", \\\"{x:1322,y:947,t:1527030409461};\\\", \\\"{x:1321,y:947,t:1527030409476};\\\", \\\"{x:1319,y:947,t:1527030409494};\\\", \\\"{x:1318,y:947,t:1527030409511};\\\", \\\"{x:1314,y:947,t:1527030409528};\\\", \\\"{x:1311,y:947,t:1527030409544};\\\", \\\"{x:1309,y:947,t:1527030409560};\\\", \\\"{x:1307,y:947,t:1527030409577};\\\", \\\"{x:1305,y:946,t:1527030409640};\\\", \\\"{x:1305,y:944,t:1527030409727};\\\", \\\"{x:1305,y:938,t:1527030409744};\\\", \\\"{x:1305,y:931,t:1527030409761};\\\", \\\"{x:1306,y:922,t:1527030409778};\\\", \\\"{x:1315,y:902,t:1527030409794};\\\", \\\"{x:1329,y:878,t:1527030409811};\\\", \\\"{x:1341,y:864,t:1527030409827};\\\", \\\"{x:1349,y:855,t:1527030409844};\\\", \\\"{x:1358,y:845,t:1527030409860};\\\", \\\"{x:1365,y:836,t:1527030409878};\\\", \\\"{x:1375,y:826,t:1527030409894};\\\", \\\"{x:1384,y:815,t:1527030409911};\\\", \\\"{x:1398,y:792,t:1527030409927};\\\", \\\"{x:1406,y:779,t:1527030409943};\\\", \\\"{x:1410,y:770,t:1527030409961};\\\", \\\"{x:1415,y:762,t:1527030409978};\\\", \\\"{x:1418,y:754,t:1527030409994};\\\", \\\"{x:1418,y:748,t:1527030410011};\\\", \\\"{x:1419,y:739,t:1527030410028};\\\", \\\"{x:1420,y:735,t:1527030410044};\\\", \\\"{x:1420,y:727,t:1527030410060};\\\", \\\"{x:1420,y:720,t:1527030410078};\\\", \\\"{x:1421,y:716,t:1527030410094};\\\", \\\"{x:1422,y:713,t:1527030410111};\\\", \\\"{x:1424,y:698,t:1527030410127};\\\", \\\"{x:1428,y:681,t:1527030410145};\\\", \\\"{x:1432,y:660,t:1527030410161};\\\", \\\"{x:1437,y:647,t:1527030410178};\\\", \\\"{x:1439,y:638,t:1527030410195};\\\", \\\"{x:1443,y:631,t:1527030410211};\\\", \\\"{x:1449,y:620,t:1527030410228};\\\", \\\"{x:1457,y:608,t:1527030410245};\\\", \\\"{x:1463,y:589,t:1527030410261};\\\", \\\"{x:1470,y:575,t:1527030410277};\\\", \\\"{x:1474,y:566,t:1527030410294};\\\", \\\"{x:1479,y:554,t:1527030410311};\\\", \\\"{x:1479,y:549,t:1527030410327};\\\", \\\"{x:1480,y:546,t:1527030410346};\\\", \\\"{x:1480,y:543,t:1527030410361};\\\", \\\"{x:1480,y:540,t:1527030410378};\\\", \\\"{x:1481,y:537,t:1527030410394};\\\", \\\"{x:1482,y:535,t:1527030410411};\\\", \\\"{x:1484,y:531,t:1527030410428};\\\", \\\"{x:1487,y:527,t:1527030410447};\\\", \\\"{x:1487,y:526,t:1527030410461};\\\", \\\"{x:1488,y:523,t:1527030410477};\\\", \\\"{x:1491,y:519,t:1527030410494};\\\", \\\"{x:1492,y:518,t:1527030410511};\\\", \\\"{x:1492,y:517,t:1527030410527};\\\", \\\"{x:1491,y:517,t:1527030410639};\\\", \\\"{x:1489,y:520,t:1527030410647};\\\", \\\"{x:1487,y:531,t:1527030410661};\\\", \\\"{x:1485,y:545,t:1527030410677};\\\", \\\"{x:1481,y:560,t:1527030410696};\\\", \\\"{x:1476,y:576,t:1527030410711};\\\", \\\"{x:1471,y:593,t:1527030410728};\\\", \\\"{x:1465,y:606,t:1527030410744};\\\", \\\"{x:1462,y:614,t:1527030410761};\\\", \\\"{x:1458,y:622,t:1527030410778};\\\", \\\"{x:1452,y:637,t:1527030410794};\\\", \\\"{x:1445,y:658,t:1527030410812};\\\", \\\"{x:1439,y:674,t:1527030410828};\\\", \\\"{x:1435,y:688,t:1527030410845};\\\", \\\"{x:1434,y:698,t:1527030410862};\\\", \\\"{x:1431,y:705,t:1527030410878};\\\", \\\"{x:1431,y:709,t:1527030410894};\\\", \\\"{x:1430,y:719,t:1527030410911};\\\", \\\"{x:1430,y:729,t:1527030410928};\\\", \\\"{x:1430,y:740,t:1527030410944};\\\", \\\"{x:1429,y:750,t:1527030410962};\\\", \\\"{x:1426,y:760,t:1527030410979};\\\", \\\"{x:1425,y:765,t:1527030410995};\\\", \\\"{x:1421,y:772,t:1527030411012};\\\", \\\"{x:1418,y:779,t:1527030411029};\\\", \\\"{x:1412,y:788,t:1527030411044};\\\", \\\"{x:1407,y:797,t:1527030411062};\\\", \\\"{x:1401,y:805,t:1527030411078};\\\", \\\"{x:1393,y:818,t:1527030411095};\\\", \\\"{x:1386,y:827,t:1527030411111};\\\", \\\"{x:1379,y:836,t:1527030411128};\\\", \\\"{x:1374,y:843,t:1527030411144};\\\", \\\"{x:1367,y:851,t:1527030411162};\\\", \\\"{x:1358,y:860,t:1527030411179};\\\", \\\"{x:1348,y:869,t:1527030411195};\\\", \\\"{x:1341,y:876,t:1527030411212};\\\", \\\"{x:1337,y:884,t:1527030411229};\\\", \\\"{x:1331,y:892,t:1527030411245};\\\", \\\"{x:1328,y:899,t:1527030411262};\\\", \\\"{x:1326,y:903,t:1527030411279};\\\", \\\"{x:1324,y:906,t:1527030411295};\\\", \\\"{x:1323,y:908,t:1527030411312};\\\", \\\"{x:1322,y:911,t:1527030411329};\\\", \\\"{x:1321,y:913,t:1527030411344};\\\", \\\"{x:1321,y:914,t:1527030411366};\\\", \\\"{x:1321,y:915,t:1527030411378};\\\", \\\"{x:1321,y:911,t:1527030411495};\\\", \\\"{x:1324,y:903,t:1527030411511};\\\", \\\"{x:1331,y:892,t:1527030411528};\\\", \\\"{x:1338,y:881,t:1527030411547};\\\", \\\"{x:1345,y:872,t:1527030411562};\\\", \\\"{x:1349,y:865,t:1527030411578};\\\", \\\"{x:1353,y:858,t:1527030411596};\\\", \\\"{x:1355,y:850,t:1527030411612};\\\", \\\"{x:1359,y:843,t:1527030411628};\\\", \\\"{x:1360,y:839,t:1527030411646};\\\", \\\"{x:1360,y:836,t:1527030411662};\\\", \\\"{x:1360,y:835,t:1527030411679};\\\", \\\"{x:1361,y:833,t:1527030411695};\\\", \\\"{x:1361,y:832,t:1527030411712};\\\", \\\"{x:1361,y:831,t:1527030411729};\\\", \\\"{x:1361,y:826,t:1527030411747};\\\", \\\"{x:1361,y:820,t:1527030411762};\\\", \\\"{x:1361,y:812,t:1527030411779};\\\", \\\"{x:1364,y:806,t:1527030411796};\\\", \\\"{x:1365,y:800,t:1527030411812};\\\", \\\"{x:1370,y:792,t:1527030411829};\\\", \\\"{x:1372,y:788,t:1527030411846};\\\", \\\"{x:1375,y:780,t:1527030411862};\\\", \\\"{x:1378,y:774,t:1527030411879};\\\", \\\"{x:1379,y:770,t:1527030411895};\\\", \\\"{x:1380,y:768,t:1527030411913};\\\", \\\"{x:1381,y:766,t:1527030411928};\\\", \\\"{x:1381,y:762,t:1527030411948};\\\", \\\"{x:1383,y:760,t:1527030411962};\\\", \\\"{x:1383,y:759,t:1527030412008};\\\", \\\"{x:1384,y:759,t:1527030412288};\\\", \\\"{x:1385,y:760,t:1527030412295};\\\", \\\"{x:1387,y:762,t:1527030412314};\\\", \\\"{x:1388,y:765,t:1527030412328};\\\", \\\"{x:1389,y:768,t:1527030412346};\\\", \\\"{x:1390,y:771,t:1527030412362};\\\", \\\"{x:1391,y:773,t:1527030412379};\\\", \\\"{x:1391,y:777,t:1527030412396};\\\", \\\"{x:1393,y:780,t:1527030412412};\\\", \\\"{x:1394,y:782,t:1527030412430};\\\", \\\"{x:1395,y:783,t:1527030412446};\\\", \\\"{x:1396,y:784,t:1527030412463};\\\", \\\"{x:1398,y:785,t:1527030412480};\\\", \\\"{x:1401,y:788,t:1527030412496};\\\", \\\"{x:1405,y:792,t:1527030412513};\\\", \\\"{x:1410,y:798,t:1527030412530};\\\", \\\"{x:1415,y:803,t:1527030412547};\\\", \\\"{x:1417,y:808,t:1527030412563};\\\", \\\"{x:1420,y:813,t:1527030412580};\\\", \\\"{x:1422,y:817,t:1527030412596};\\\", \\\"{x:1424,y:823,t:1527030412613};\\\", \\\"{x:1428,y:831,t:1527030412630};\\\", \\\"{x:1430,y:837,t:1527030412646};\\\", \\\"{x:1433,y:845,t:1527030412664};\\\", \\\"{x:1434,y:854,t:1527030412679};\\\", \\\"{x:1438,y:863,t:1527030412696};\\\", \\\"{x:1443,y:873,t:1527030412713};\\\", \\\"{x:1451,y:887,t:1527030412730};\\\", \\\"{x:1456,y:895,t:1527030412746};\\\", \\\"{x:1460,y:903,t:1527030412763};\\\", \\\"{x:1464,y:908,t:1527030412780};\\\", \\\"{x:1466,y:910,t:1527030412796};\\\", \\\"{x:1466,y:911,t:1527030412813};\\\", \\\"{x:1467,y:912,t:1527030412830};\\\", \\\"{x:1468,y:912,t:1527030412880};\\\", \\\"{x:1469,y:914,t:1527030412897};\\\", \\\"{x:1470,y:915,t:1527030412913};\\\", \\\"{x:1472,y:917,t:1527030412930};\\\", \\\"{x:1475,y:922,t:1527030412946};\\\", \\\"{x:1477,y:926,t:1527030412963};\\\", \\\"{x:1479,y:929,t:1527030412980};\\\", \\\"{x:1481,y:934,t:1527030412997};\\\", \\\"{x:1482,y:936,t:1527030413013};\\\", \\\"{x:1483,y:938,t:1527030413030};\\\", \\\"{x:1484,y:940,t:1527030413047};\\\", \\\"{x:1485,y:941,t:1527030413063};\\\", \\\"{x:1485,y:942,t:1527030413095};\\\", \\\"{x:1485,y:943,t:1527030413111};\\\", \\\"{x:1485,y:944,t:1527030413119};\\\", \\\"{x:1485,y:945,t:1527030413167};\\\", \\\"{x:1486,y:946,t:1527030413180};\\\", \\\"{x:1486,y:947,t:1527030413196};\\\", \\\"{x:1487,y:947,t:1527030413213};\\\", \\\"{x:1488,y:949,t:1527030413230};\\\", \\\"{x:1489,y:951,t:1527030413263};\\\", \\\"{x:1488,y:951,t:1527030413519};\\\", \\\"{x:1485,y:951,t:1527030413530};\\\", \\\"{x:1481,y:951,t:1527030413547};\\\", \\\"{x:1477,y:950,t:1527030413563};\\\", \\\"{x:1474,y:950,t:1527030413579};\\\", \\\"{x:1470,y:950,t:1527030413596};\\\", \\\"{x:1467,y:951,t:1527030413613};\\\", \\\"{x:1464,y:951,t:1527030413629};\\\", \\\"{x:1459,y:953,t:1527030413645};\\\", \\\"{x:1453,y:955,t:1527030413663};\\\", \\\"{x:1448,y:955,t:1527030413680};\\\", \\\"{x:1443,y:957,t:1527030413696};\\\", \\\"{x:1441,y:957,t:1527030413714};\\\", \\\"{x:1437,y:957,t:1527030413729};\\\", \\\"{x:1434,y:957,t:1527030413746};\\\", \\\"{x:1431,y:957,t:1527030413763};\\\", \\\"{x:1427,y:957,t:1527030413779};\\\", \\\"{x:1421,y:957,t:1527030413797};\\\", \\\"{x:1416,y:957,t:1527030413814};\\\", \\\"{x:1406,y:955,t:1527030413830};\\\", \\\"{x:1401,y:954,t:1527030413846};\\\", \\\"{x:1396,y:953,t:1527030413864};\\\", \\\"{x:1394,y:952,t:1527030413881};\\\", \\\"{x:1390,y:950,t:1527030413896};\\\", \\\"{x:1385,y:949,t:1527030413913};\\\", \\\"{x:1384,y:948,t:1527030413931};\\\", \\\"{x:1382,y:948,t:1527030413946};\\\", \\\"{x:1378,y:947,t:1527030413963};\\\", \\\"{x:1375,y:945,t:1527030413981};\\\", \\\"{x:1372,y:944,t:1527030413996};\\\", \\\"{x:1368,y:942,t:1527030414014};\\\", \\\"{x:1360,y:938,t:1527030414031};\\\", \\\"{x:1351,y:935,t:1527030414047};\\\", \\\"{x:1340,y:931,t:1527030414064};\\\", \\\"{x:1331,y:929,t:1527030414081};\\\", \\\"{x:1322,y:927,t:1527030414097};\\\", \\\"{x:1310,y:925,t:1527030414113};\\\", \\\"{x:1297,y:923,t:1527030414131};\\\", \\\"{x:1283,y:921,t:1527030414146};\\\", \\\"{x:1271,y:919,t:1527030414164};\\\", \\\"{x:1264,y:917,t:1527030414180};\\\", \\\"{x:1262,y:917,t:1527030414196};\\\", \\\"{x:1260,y:917,t:1527030414214};\\\", \\\"{x:1259,y:916,t:1527030414231};\\\", \\\"{x:1259,y:915,t:1527030414255};\\\", \\\"{x:1259,y:914,t:1527030414271};\\\", \\\"{x:1259,y:912,t:1527030414281};\\\", \\\"{x:1257,y:909,t:1527030414298};\\\", \\\"{x:1257,y:903,t:1527030414313};\\\", \\\"{x:1256,y:899,t:1527030414331};\\\", \\\"{x:1256,y:892,t:1527030414348};\\\", \\\"{x:1256,y:883,t:1527030414364};\\\", \\\"{x:1259,y:874,t:1527030414381};\\\", \\\"{x:1263,y:864,t:1527030414398};\\\", \\\"{x:1268,y:852,t:1527030414414};\\\", \\\"{x:1276,y:840,t:1527030414431};\\\", \\\"{x:1281,y:833,t:1527030414447};\\\", \\\"{x:1285,y:829,t:1527030414463};\\\", \\\"{x:1288,y:825,t:1527030414481};\\\", \\\"{x:1289,y:825,t:1527030414498};\\\", \\\"{x:1289,y:824,t:1527030414513};\\\", \\\"{x:1291,y:823,t:1527030414531};\\\", \\\"{x:1291,y:822,t:1527030414548};\\\", \\\"{x:1290,y:823,t:1527030414944};\\\", \\\"{x:1289,y:823,t:1527030414951};\\\", \\\"{x:1287,y:825,t:1527030414964};\\\", \\\"{x:1282,y:829,t:1527030414980};\\\", \\\"{x:1275,y:836,t:1527030414998};\\\", \\\"{x:1264,y:848,t:1527030415014};\\\", \\\"{x:1261,y:855,t:1527030415030};\\\", \\\"{x:1257,y:863,t:1527030415047};\\\", \\\"{x:1253,y:870,t:1527030415064};\\\", \\\"{x:1252,y:876,t:1527030415080};\\\", \\\"{x:1252,y:881,t:1527030415098};\\\", \\\"{x:1252,y:887,t:1527030415114};\\\", \\\"{x:1252,y:891,t:1527030415131};\\\", \\\"{x:1254,y:894,t:1527030415148};\\\", \\\"{x:1256,y:896,t:1527030415164};\\\", \\\"{x:1257,y:896,t:1527030415255};\\\", \\\"{x:1258,y:897,t:1527030415266};\\\", \\\"{x:1260,y:898,t:1527030415282};\\\", \\\"{x:1261,y:900,t:1527030415298};\\\", \\\"{x:1262,y:900,t:1527030415315};\\\", \\\"{x:1264,y:901,t:1527030415332};\\\", \\\"{x:1265,y:903,t:1527030415347};\\\", \\\"{x:1267,y:905,t:1527030415365};\\\", \\\"{x:1269,y:907,t:1527030415382};\\\", \\\"{x:1271,y:911,t:1527030415402};\\\", \\\"{x:1277,y:919,t:1527030415414};\\\", \\\"{x:1279,y:925,t:1527030415431};\\\", \\\"{x:1284,y:930,t:1527030415447};\\\", \\\"{x:1287,y:934,t:1527030415464};\\\", \\\"{x:1288,y:935,t:1527030415481};\\\", \\\"{x:1289,y:935,t:1527030415497};\\\", \\\"{x:1290,y:936,t:1527030415514};\\\", \\\"{x:1290,y:937,t:1527030415531};\\\", \\\"{x:1291,y:937,t:1527030415547};\\\", \\\"{x:1291,y:939,t:1527030415672};\\\", \\\"{x:1291,y:942,t:1527030415682};\\\", \\\"{x:1288,y:951,t:1527030415698};\\\", \\\"{x:1282,y:958,t:1527030415715};\\\", \\\"{x:1277,y:964,t:1527030415732};\\\", \\\"{x:1277,y:965,t:1527030415749};\\\", \\\"{x:1276,y:965,t:1527030415765};\\\", \\\"{x:1276,y:966,t:1527030415782};\\\", \\\"{x:1275,y:966,t:1527030415798};\\\", \\\"{x:1273,y:966,t:1527030415831};\\\", \\\"{x:1272,y:966,t:1527030416135};\\\", \\\"{x:1270,y:964,t:1527030416447};\\\", \\\"{x:1269,y:963,t:1527030416711};\\\", \\\"{x:1268,y:962,t:1527030416728};\\\", \\\"{x:1267,y:961,t:1527030416759};\\\", \\\"{x:1266,y:961,t:1527030416767};\\\", \\\"{x:1266,y:960,t:1527030417135};\\\", \\\"{x:1269,y:959,t:1527030417184};\\\", \\\"{x:1269,y:958,t:1527030417199};\\\", \\\"{x:1270,y:958,t:1527030417311};\\\", \\\"{x:1272,y:957,t:1527030417391};\\\", \\\"{x:1274,y:953,t:1527030417991};\\\", \\\"{x:1281,y:948,t:1527030418000};\\\", \\\"{x:1298,y:937,t:1527030418017};\\\", \\\"{x:1313,y:923,t:1527030418033};\\\", \\\"{x:1328,y:910,t:1527030418050};\\\", \\\"{x:1341,y:895,t:1527030418067};\\\", \\\"{x:1350,y:884,t:1527030418084};\\\", \\\"{x:1353,y:876,t:1527030418100};\\\", \\\"{x:1354,y:872,t:1527030418117};\\\", \\\"{x:1354,y:870,t:1527030418134};\\\", \\\"{x:1354,y:869,t:1527030418151};\\\", \\\"{x:1354,y:868,t:1527030418167};\\\", \\\"{x:1354,y:867,t:1527030418184};\\\", \\\"{x:1354,y:866,t:1527030418200};\\\", \\\"{x:1354,y:863,t:1527030418217};\\\", \\\"{x:1354,y:859,t:1527030418234};\\\", \\\"{x:1353,y:846,t:1527030418250};\\\", \\\"{x:1353,y:834,t:1527030418267};\\\", \\\"{x:1353,y:816,t:1527030418285};\\\", \\\"{x:1353,y:800,t:1527030418300};\\\", \\\"{x:1354,y:784,t:1527030418317};\\\", \\\"{x:1358,y:772,t:1527030418334};\\\", \\\"{x:1359,y:763,t:1527030418350};\\\", \\\"{x:1362,y:756,t:1527030418367};\\\", \\\"{x:1362,y:753,t:1527030418384};\\\", \\\"{x:1363,y:752,t:1527030418400};\\\", \\\"{x:1364,y:750,t:1527030418431};\\\", \\\"{x:1365,y:749,t:1527030418463};\\\", \\\"{x:1366,y:749,t:1527030418471};\\\", \\\"{x:1366,y:748,t:1527030418495};\\\", \\\"{x:1366,y:747,t:1527030418511};\\\", \\\"{x:1368,y:746,t:1527030418520};\\\", \\\"{x:1368,y:750,t:1527030418680};\\\", \\\"{x:1368,y:759,t:1527030418687};\\\", \\\"{x:1365,y:767,t:1527030418701};\\\", \\\"{x:1361,y:784,t:1527030418717};\\\", \\\"{x:1358,y:809,t:1527030418734};\\\", \\\"{x:1350,y:837,t:1527030418752};\\\", \\\"{x:1344,y:849,t:1527030418767};\\\", \\\"{x:1341,y:857,t:1527030418784};\\\", \\\"{x:1336,y:865,t:1527030418801};\\\", \\\"{x:1333,y:870,t:1527030418817};\\\", \\\"{x:1332,y:872,t:1527030418834};\\\", \\\"{x:1332,y:873,t:1527030418851};\\\", \\\"{x:1331,y:875,t:1527030418867};\\\", \\\"{x:1329,y:876,t:1527030418884};\\\", \\\"{x:1328,y:877,t:1527030418901};\\\", \\\"{x:1325,y:879,t:1527030418918};\\\", \\\"{x:1323,y:881,t:1527030418935};\\\", \\\"{x:1322,y:883,t:1527030418951};\\\", \\\"{x:1319,y:887,t:1527030418967};\\\", \\\"{x:1318,y:893,t:1527030418985};\\\", \\\"{x:1316,y:904,t:1527030419001};\\\", \\\"{x:1316,y:915,t:1527030419018};\\\", \\\"{x:1318,y:927,t:1527030419034};\\\", \\\"{x:1321,y:936,t:1527030419051};\\\", \\\"{x:1322,y:945,t:1527030419068};\\\", \\\"{x:1322,y:950,t:1527030419084};\\\", \\\"{x:1322,y:953,t:1527030419101};\\\", \\\"{x:1322,y:958,t:1527030419118};\\\", \\\"{x:1321,y:961,t:1527030419134};\\\", \\\"{x:1319,y:964,t:1527030419151};\\\", \\\"{x:1318,y:965,t:1527030419168};\\\", \\\"{x:1316,y:967,t:1527030419184};\\\", \\\"{x:1313,y:968,t:1527030419201};\\\", \\\"{x:1311,y:968,t:1527030419218};\\\", \\\"{x:1310,y:968,t:1527030419234};\\\", \\\"{x:1309,y:968,t:1527030419251};\\\", \\\"{x:1307,y:968,t:1527030419269};\\\", \\\"{x:1305,y:968,t:1527030419284};\\\", \\\"{x:1304,y:968,t:1527030419301};\\\", \\\"{x:1301,y:968,t:1527030419318};\\\", \\\"{x:1299,y:968,t:1527030419334};\\\", \\\"{x:1298,y:968,t:1527030419351};\\\", \\\"{x:1297,y:968,t:1527030419368};\\\", \\\"{x:1296,y:968,t:1527030419384};\\\", \\\"{x:1295,y:968,t:1527030419472};\\\", \\\"{x:1294,y:968,t:1527030419485};\\\", \\\"{x:1293,y:968,t:1527030419501};\\\", \\\"{x:1292,y:968,t:1527030419527};\\\", \\\"{x:1291,y:968,t:1527030419535};\\\", \\\"{x:1290,y:967,t:1527030419551};\\\", \\\"{x:1289,y:966,t:1527030419568};\\\", \\\"{x:1288,y:966,t:1527030419591};\\\", \\\"{x:1287,y:966,t:1527030419672};\\\", \\\"{x:1286,y:966,t:1527030419685};\\\", \\\"{x:1286,y:965,t:1527030419701};\\\", \\\"{x:1286,y:964,t:1527030419718};\\\", \\\"{x:1285,y:964,t:1527030419735};\\\", \\\"{x:1285,y:963,t:1527030419751};\\\", \\\"{x:1285,y:962,t:1527030419769};\\\", \\\"{x:1285,y:961,t:1527030419786};\\\", \\\"{x:1285,y:960,t:1527030419801};\\\", \\\"{x:1285,y:959,t:1527030419818};\\\", \\\"{x:1285,y:958,t:1527030419835};\\\", \\\"{x:1285,y:956,t:1527030419851};\\\", \\\"{x:1285,y:955,t:1527030419868};\\\", \\\"{x:1285,y:954,t:1527030419887};\\\", \\\"{x:1285,y:953,t:1527030419912};\\\", \\\"{x:1285,y:952,t:1527030419992};\\\", \\\"{x:1286,y:952,t:1527030420003};\\\", \\\"{x:1287,y:950,t:1527030420018};\\\", \\\"{x:1288,y:948,t:1527030420035};\\\", \\\"{x:1290,y:946,t:1527030420052};\\\", \\\"{x:1293,y:943,t:1527030420068};\\\", \\\"{x:1295,y:940,t:1527030420086};\\\", \\\"{x:1297,y:938,t:1527030420102};\\\", \\\"{x:1298,y:938,t:1527030420119};\\\", \\\"{x:1301,y:935,t:1527030420135};\\\", \\\"{x:1306,y:930,t:1527030420152};\\\", \\\"{x:1313,y:921,t:1527030420168};\\\", \\\"{x:1320,y:917,t:1527030420185};\\\", \\\"{x:1324,y:913,t:1527030420203};\\\", \\\"{x:1327,y:910,t:1527030420218};\\\", \\\"{x:1332,y:907,t:1527030420235};\\\", \\\"{x:1335,y:902,t:1527030420253};\\\", \\\"{x:1337,y:900,t:1527030420269};\\\", \\\"{x:1343,y:892,t:1527030420285};\\\", \\\"{x:1348,y:883,t:1527030420302};\\\", \\\"{x:1350,y:879,t:1527030420319};\\\", \\\"{x:1355,y:872,t:1527030420335};\\\", \\\"{x:1358,y:867,t:1527030420356};\\\", \\\"{x:1360,y:863,t:1527030420371};\\\", \\\"{x:1363,y:857,t:1527030420388};\\\", \\\"{x:1372,y:839,t:1527030420405};\\\", \\\"{x:1383,y:822,t:1527030420421};\\\", \\\"{x:1399,y:801,t:1527030420438};\\\", \\\"{x:1409,y:786,t:1527030420455};\\\", \\\"{x:1414,y:776,t:1527030420472};\\\", \\\"{x:1417,y:770,t:1527030420489};\\\", \\\"{x:1419,y:764,t:1527030420505};\\\", \\\"{x:1422,y:758,t:1527030420522};\\\", \\\"{x:1426,y:752,t:1527030420538};\\\", \\\"{x:1431,y:744,t:1527030420555};\\\", \\\"{x:1431,y:742,t:1527030420573};\\\", \\\"{x:1434,y:739,t:1527030420589};\\\", \\\"{x:1435,y:737,t:1527030420606};\\\", \\\"{x:1436,y:735,t:1527030420622};\\\", \\\"{x:1438,y:734,t:1527030420639};\\\", \\\"{x:1439,y:732,t:1527030420656};\\\", \\\"{x:1440,y:732,t:1527030420672};\\\", \\\"{x:1441,y:730,t:1527030420688};\\\", \\\"{x:1444,y:727,t:1527030420706};\\\", \\\"{x:1445,y:725,t:1527030420723};\\\", \\\"{x:1445,y:723,t:1527030420739};\\\", \\\"{x:1446,y:721,t:1527030420755};\\\", \\\"{x:1447,y:718,t:1527030420773};\\\", \\\"{x:1448,y:713,t:1527030420789};\\\", \\\"{x:1451,y:704,t:1527030420805};\\\", \\\"{x:1452,y:697,t:1527030420823};\\\", \\\"{x:1457,y:688,t:1527030420839};\\\", \\\"{x:1460,y:683,t:1527030420856};\\\", \\\"{x:1461,y:679,t:1527030420873};\\\", \\\"{x:1464,y:672,t:1527030420889};\\\", \\\"{x:1468,y:663,t:1527030420906};\\\", \\\"{x:1475,y:645,t:1527030420923};\\\", \\\"{x:1480,y:635,t:1527030420939};\\\", \\\"{x:1484,y:625,t:1527030420956};\\\", \\\"{x:1486,y:620,t:1527030420973};\\\", \\\"{x:1488,y:616,t:1527030420990};\\\", \\\"{x:1491,y:611,t:1527030421006};\\\", \\\"{x:1492,y:605,t:1527030421023};\\\", \\\"{x:1496,y:597,t:1527030421039};\\\", \\\"{x:1497,y:592,t:1527030421056};\\\", \\\"{x:1498,y:587,t:1527030421073};\\\", \\\"{x:1499,y:581,t:1527030421090};\\\", \\\"{x:1499,y:578,t:1527030421106};\\\", \\\"{x:1500,y:575,t:1527030421123};\\\", \\\"{x:1496,y:577,t:1527030421236};\\\", \\\"{x:1490,y:583,t:1527030421243};\\\", \\\"{x:1481,y:594,t:1527030421256};\\\", \\\"{x:1455,y:619,t:1527030421273};\\\", \\\"{x:1401,y:659,t:1527030421290};\\\", \\\"{x:1298,y:708,t:1527030421306};\\\", \\\"{x:1153,y:773,t:1527030421323};\\\", \\\"{x:1086,y:794,t:1527030421340};\\\", \\\"{x:1051,y:804,t:1527030421355};\\\", \\\"{x:1034,y:808,t:1527030421373};\\\", \\\"{x:1022,y:812,t:1527030421390};\\\", \\\"{x:1014,y:814,t:1527030421406};\\\", \\\"{x:1011,y:815,t:1527030421423};\\\", \\\"{x:1010,y:815,t:1527030421440};\\\", \\\"{x:1009,y:815,t:1527030421459};\\\", \\\"{x:1008,y:815,t:1527030421490};\\\", \\\"{x:1006,y:815,t:1527030421506};\\\", \\\"{x:1005,y:815,t:1527030421522};\\\", \\\"{x:1004,y:815,t:1527030421561};\\\", \\\"{x:1003,y:815,t:1527030421779};\\\", \\\"{x:1002,y:815,t:1527030421790};\\\", \\\"{x:997,y:815,t:1527030421807};\\\", \\\"{x:989,y:816,t:1527030421823};\\\", \\\"{x:974,y:816,t:1527030421840};\\\", \\\"{x:958,y:816,t:1527030421857};\\\", \\\"{x:942,y:816,t:1527030421874};\\\", \\\"{x:926,y:813,t:1527030421890};\\\", \\\"{x:916,y:812,t:1527030421906};\\\", \\\"{x:911,y:810,t:1527030421924};\\\", \\\"{x:909,y:809,t:1527030421940};\\\", \\\"{x:908,y:809,t:1527030421956};\\\", \\\"{x:907,y:809,t:1527030421974};\\\", \\\"{x:906,y:808,t:1527030421994};\\\", \\\"{x:903,y:807,t:1527030422083};\\\", \\\"{x:898,y:805,t:1527030422091};\\\", \\\"{x:882,y:801,t:1527030422107};\\\", \\\"{x:875,y:798,t:1527030422123};\\\", \\\"{x:863,y:795,t:1527030422139};\\\", \\\"{x:850,y:794,t:1527030422156};\\\", \\\"{x:836,y:791,t:1527030422174};\\\", \\\"{x:825,y:790,t:1527030422190};\\\", \\\"{x:816,y:787,t:1527030422207};\\\", \\\"{x:808,y:786,t:1527030422224};\\\", \\\"{x:800,y:783,t:1527030422239};\\\", \\\"{x:796,y:782,t:1527030422257};\\\", \\\"{x:791,y:782,t:1527030422274};\\\", \\\"{x:788,y:782,t:1527030422290};\\\", \\\"{x:773,y:779,t:1527030422307};\\\", \\\"{x:755,y:778,t:1527030422324};\\\", \\\"{x:734,y:775,t:1527030422341};\\\", \\\"{x:711,y:772,t:1527030422356};\\\", \\\"{x:686,y:766,t:1527030422373};\\\", \\\"{x:652,y:758,t:1527030422390};\\\", \\\"{x:623,y:747,t:1527030422406};\\\", \\\"{x:600,y:741,t:1527030422423};\\\", \\\"{x:581,y:736,t:1527030422440};\\\", \\\"{x:562,y:732,t:1527030422457};\\\", \\\"{x:548,y:730,t:1527030422474};\\\", \\\"{x:535,y:728,t:1527030422490};\\\", \\\"{x:531,y:727,t:1527030422508};\\\", \\\"{x:530,y:727,t:1527030422546};\\\" ] }, { \\\"rt\\\": 13505, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 317564, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:727,t:1527030431811};\\\", \\\"{x:517,y:735,t:1527030431827};\\\", \\\"{x:507,y:742,t:1527030431844};\\\", \\\"{x:500,y:746,t:1527030431860};\\\", \\\"{x:495,y:748,t:1527030431882};\\\", \\\"{x:492,y:751,t:1527030431897};\\\", \\\"{x:491,y:751,t:1527030431953};\\\", \\\"{x:489,y:751,t:1527030431985};\\\", \\\"{x:485,y:747,t:1527030431997};\\\", \\\"{x:481,y:729,t:1527030432016};\\\", \\\"{x:478,y:715,t:1527030432032};\\\", \\\"{x:478,y:699,t:1527030432051};\\\", \\\"{x:482,y:686,t:1527030432065};\\\", \\\"{x:489,y:674,t:1527030432082};\\\", \\\"{x:494,y:665,t:1527030432100};\\\", \\\"{x:498,y:656,t:1527030432115};\\\", \\\"{x:502,y:648,t:1527030432134};\\\", \\\"{x:509,y:641,t:1527030432150};\\\", \\\"{x:516,y:634,t:1527030432166};\\\", \\\"{x:518,y:632,t:1527030432183};\\\", \\\"{x:520,y:630,t:1527030432200};\\\", \\\"{x:520,y:629,t:1527030432216};\\\", \\\"{x:521,y:629,t:1527030432250};\\\", \\\"{x:526,y:628,t:1527030432266};\\\", \\\"{x:532,y:625,t:1527030432282};\\\", \\\"{x:535,y:623,t:1527030432300};\\\", \\\"{x:545,y:617,t:1527030432318};\\\", \\\"{x:558,y:612,t:1527030432333};\\\", \\\"{x:572,y:608,t:1527030432350};\\\", \\\"{x:588,y:605,t:1527030432367};\\\", \\\"{x:607,y:600,t:1527030432383};\\\", \\\"{x:631,y:592,t:1527030432400};\\\", \\\"{x:652,y:586,t:1527030432417};\\\", \\\"{x:673,y:584,t:1527030432433};\\\", \\\"{x:702,y:579,t:1527030432451};\\\", \\\"{x:729,y:569,t:1527030432467};\\\", \\\"{x:746,y:564,t:1527030432482};\\\", \\\"{x:755,y:562,t:1527030432499};\\\", \\\"{x:763,y:560,t:1527030432516};\\\", \\\"{x:766,y:559,t:1527030432533};\\\", \\\"{x:767,y:559,t:1527030432549};\\\", \\\"{x:761,y:559,t:1527030432658};\\\", \\\"{x:744,y:560,t:1527030432666};\\\", \\\"{x:685,y:560,t:1527030432684};\\\", \\\"{x:607,y:562,t:1527030432700};\\\", \\\"{x:524,y:573,t:1527030432716};\\\", \\\"{x:465,y:583,t:1527030432734};\\\", \\\"{x:432,y:589,t:1527030432750};\\\", \\\"{x:423,y:591,t:1527030432767};\\\", \\\"{x:424,y:591,t:1527030432890};\\\", \\\"{x:425,y:591,t:1527030432900};\\\", \\\"{x:428,y:591,t:1527030432917};\\\", \\\"{x:431,y:593,t:1527030432933};\\\", \\\"{x:434,y:595,t:1527030432950};\\\", \\\"{x:435,y:595,t:1527030432986};\\\", \\\"{x:435,y:596,t:1527030433000};\\\", \\\"{x:433,y:597,t:1527030433017};\\\", \\\"{x:432,y:598,t:1527030433033};\\\", \\\"{x:425,y:597,t:1527030433050};\\\", \\\"{x:423,y:597,t:1527030433066};\\\", \\\"{x:422,y:597,t:1527030433083};\\\", \\\"{x:420,y:595,t:1527030433100};\\\", \\\"{x:417,y:595,t:1527030433117};\\\", \\\"{x:411,y:593,t:1527030433133};\\\", \\\"{x:406,y:591,t:1527030433150};\\\", \\\"{x:403,y:590,t:1527030433166};\\\", \\\"{x:400,y:589,t:1527030433183};\\\", \\\"{x:410,y:592,t:1527030433489};\\\", \\\"{x:418,y:597,t:1527030433501};\\\", \\\"{x:428,y:603,t:1527030433517};\\\", \\\"{x:444,y:609,t:1527030433533};\\\", \\\"{x:457,y:615,t:1527030433551};\\\", \\\"{x:464,y:618,t:1527030433566};\\\", \\\"{x:472,y:623,t:1527030433585};\\\", \\\"{x:477,y:627,t:1527030433601};\\\", \\\"{x:480,y:630,t:1527030433617};\\\", \\\"{x:480,y:632,t:1527030433634};\\\", \\\"{x:481,y:636,t:1527030433651};\\\", \\\"{x:483,y:641,t:1527030433668};\\\", \\\"{x:486,y:647,t:1527030433683};\\\", \\\"{x:487,y:651,t:1527030433701};\\\", \\\"{x:488,y:656,t:1527030433718};\\\", \\\"{x:489,y:662,t:1527030433734};\\\", \\\"{x:489,y:666,t:1527030433751};\\\", \\\"{x:489,y:668,t:1527030433767};\\\", \\\"{x:491,y:671,t:1527030433783};\\\", \\\"{x:492,y:671,t:1527030433882};\\\", \\\"{x:492,y:672,t:1527030433891};\\\", \\\"{x:492,y:673,t:1527030433962};\\\", \\\"{x:492,y:674,t:1527030433978};\\\", \\\"{x:491,y:674,t:1527030434002};\\\", \\\"{x:491,y:675,t:1527030434051};\\\", \\\"{x:491,y:676,t:1527030434426};\\\", \\\"{x:493,y:678,t:1527030434434};\\\", \\\"{x:504,y:684,t:1527030434451};\\\", \\\"{x:507,y:686,t:1527030434468};\\\", \\\"{x:510,y:691,t:1527030434484};\\\", \\\"{x:516,y:697,t:1527030434501};\\\", \\\"{x:521,y:702,t:1527030434519};\\\", \\\"{x:524,y:706,t:1527030434534};\\\", \\\"{x:525,y:708,t:1527030434551};\\\", \\\"{x:527,y:709,t:1527030434568};\\\", \\\"{x:529,y:711,t:1527030434611};\\\", \\\"{x:530,y:711,t:1527030434618};\\\", \\\"{x:531,y:711,t:1527030434635};\\\", \\\"{x:532,y:712,t:1527030434652};\\\", \\\"{x:533,y:712,t:1527030434682};\\\", \\\"{x:534,y:712,t:1527030434690};\\\", \\\"{x:534,y:713,t:1527030434702};\\\", \\\"{x:535,y:713,t:1527030434719};\\\", \\\"{x:535,y:714,t:1527030434735};\\\", \\\"{x:538,y:717,t:1527030434752};\\\", \\\"{x:538,y:720,t:1527030434769};\\\", \\\"{x:540,y:722,t:1527030434786};\\\", \\\"{x:541,y:724,t:1527030434802};\\\", \\\"{x:541,y:725,t:1527030434827};\\\", \\\"{x:541,y:726,t:1527030434835};\\\", \\\"{x:541,y:727,t:1527030434852};\\\", \\\"{x:541,y:728,t:1527030434882};\\\", \\\"{x:540,y:730,t:1527030434970};\\\", \\\"{x:538,y:730,t:1527030434986};\\\", \\\"{x:535,y:730,t:1527030435002};\\\", \\\"{x:533,y:731,t:1527030435019};\\\", \\\"{x:531,y:731,t:1527030435036};\\\", \\\"{x:529,y:731,t:1527030435052};\\\", \\\"{x:528,y:731,t:1527030435069};\\\", \\\"{x:527,y:731,t:1527030435090};\\\", \\\"{x:526,y:731,t:1527030435106};\\\", \\\"{x:525,y:731,t:1527030435119};\\\", \\\"{x:524,y:732,t:1527030435136};\\\", \\\"{x:522,y:732,t:1527030435153};\\\", \\\"{x:520,y:732,t:1527030435178};\\\", \\\"{x:518,y:733,t:1527030435186};\\\", \\\"{x:516,y:733,t:1527030435210};\\\", \\\"{x:515,y:733,t:1527030435746};\\\", \\\"{x:512,y:733,t:1527030436698};\\\", \\\"{x:511,y:733,t:1527030436707};\\\", \\\"{x:510,y:733,t:1527030436721};\\\", \\\"{x:506,y:737,t:1527030436739};\\\", \\\"{x:506,y:745,t:1527030436754};\\\", \\\"{x:506,y:749,t:1527030436770};\\\", \\\"{x:506,y:750,t:1527030436786};\\\", \\\"{x:506,y:752,t:1527030436803};\\\", \\\"{x:506,y:751,t:1527030437235};\\\", \\\"{x:506,y:748,t:1527030437242};\\\", \\\"{x:506,y:745,t:1527030437253};\\\", \\\"{x:507,y:738,t:1527030437270};\\\", \\\"{x:508,y:732,t:1527030437288};\\\", \\\"{x:509,y:729,t:1527030437304};\\\", \\\"{x:510,y:728,t:1527030437319};\\\" ] }, { \\\"rt\\\": 16600, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 335378, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-09 AM-C -C -11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:728,t:1527030439809};\\\", \\\"{x:509,y:729,t:1527030439874};\\\", \\\"{x:508,y:729,t:1527030439889};\\\", \\\"{x:506,y:733,t:1527030439906};\\\", \\\"{x:505,y:734,t:1527030439923};\\\", \\\"{x:503,y:737,t:1527030439939};\\\", \\\"{x:500,y:740,t:1527030439956};\\\", \\\"{x:498,y:742,t:1527030439972};\\\", \\\"{x:497,y:744,t:1527030439989};\\\", \\\"{x:496,y:745,t:1527030440006};\\\", \\\"{x:495,y:745,t:1527030440026};\\\", \\\"{x:495,y:741,t:1527030441675};\\\", \\\"{x:510,y:729,t:1527030441692};\\\", \\\"{x:522,y:722,t:1527030441707};\\\", \\\"{x:531,y:717,t:1527030441724};\\\", \\\"{x:537,y:715,t:1527030441740};\\\", \\\"{x:540,y:714,t:1527030441757};\\\", \\\"{x:541,y:713,t:1527030441774};\\\", \\\"{x:543,y:712,t:1527030441791};\\\", \\\"{x:546,y:711,t:1527030441807};\\\", \\\"{x:549,y:709,t:1527030441823};\\\", \\\"{x:551,y:709,t:1527030441841};\\\", \\\"{x:553,y:708,t:1527030441857};\\\", \\\"{x:557,y:706,t:1527030441874};\\\", \\\"{x:557,y:705,t:1527030441891};\\\", \\\"{x:559,y:705,t:1527030441907};\\\", \\\"{x:560,y:705,t:1527030441924};\\\", \\\"{x:562,y:704,t:1527030441946};\\\", \\\"{x:563,y:703,t:1527030441958};\\\", \\\"{x:564,y:703,t:1527030441973};\\\", \\\"{x:564,y:702,t:1527030441991};\\\", \\\"{x:564,y:700,t:1527030442007};\\\", \\\"{x:564,y:699,t:1527030442024};\\\", \\\"{x:564,y:696,t:1527030442040};\\\", \\\"{x:564,y:692,t:1527030442056};\\\", \\\"{x:554,y:689,t:1527030442074};\\\", \\\"{x:548,y:689,t:1527030442091};\\\", \\\"{x:553,y:687,t:1527030442443};\\\", \\\"{x:559,y:684,t:1527030442458};\\\", \\\"{x:561,y:683,t:1527030442474};\\\", \\\"{x:562,y:683,t:1527030442491};\\\", \\\"{x:565,y:681,t:1527030442509};\\\", \\\"{x:567,y:681,t:1527030442524};\\\", \\\"{x:568,y:680,t:1527030442541};\\\", \\\"{x:569,y:679,t:1527030442558};\\\", \\\"{x:570,y:678,t:1527030442574};\\\", \\\"{x:572,y:678,t:1527030442592};\\\", \\\"{x:577,y:678,t:1527030442608};\\\", \\\"{x:579,y:678,t:1527030442624};\\\", \\\"{x:580,y:679,t:1527030442666};\\\", \\\"{x:583,y:679,t:1527030442675};\\\", \\\"{x:591,y:683,t:1527030442691};\\\", \\\"{x:605,y:688,t:1527030442708};\\\", \\\"{x:619,y:692,t:1527030442725};\\\", \\\"{x:628,y:695,t:1527030442741};\\\", \\\"{x:635,y:697,t:1527030442758};\\\", \\\"{x:650,y:703,t:1527030442776};\\\", \\\"{x:667,y:704,t:1527030442791};\\\", \\\"{x:677,y:704,t:1527030442808};\\\", \\\"{x:680,y:704,t:1527030442825};\\\", \\\"{x:681,y:705,t:1527030442841};\\\", \\\"{x:697,y:718,t:1527030442858};\\\", \\\"{x:729,y:731,t:1527030442875};\\\", \\\"{x:768,y:742,t:1527030442891};\\\", \\\"{x:791,y:748,t:1527030442908};\\\", \\\"{x:806,y:752,t:1527030442925};\\\", \\\"{x:809,y:753,t:1527030442941};\\\", \\\"{x:811,y:753,t:1527030442959};\\\", \\\"{x:812,y:753,t:1527030442976};\\\", \\\"{x:813,y:754,t:1527030443090};\\\", \\\"{x:814,y:765,t:1527030443108};\\\", \\\"{x:816,y:781,t:1527030443126};\\\", \\\"{x:817,y:788,t:1527030443142};\\\", \\\"{x:819,y:794,t:1527030443158};\\\", \\\"{x:826,y:803,t:1527030443175};\\\", \\\"{x:838,y:819,t:1527030443192};\\\", \\\"{x:863,y:849,t:1527030443208};\\\", \\\"{x:886,y:876,t:1527030443226};\\\", \\\"{x:936,y:908,t:1527030443242};\\\", \\\"{x:976,y:929,t:1527030443258};\\\", \\\"{x:999,y:940,t:1527030443276};\\\", \\\"{x:1018,y:951,t:1527030443292};\\\", \\\"{x:1029,y:957,t:1527030443309};\\\", \\\"{x:1043,y:967,t:1527030443326};\\\", \\\"{x:1058,y:976,t:1527030443343};\\\", \\\"{x:1074,y:982,t:1527030443359};\\\", \\\"{x:1085,y:984,t:1527030443376};\\\", \\\"{x:1096,y:984,t:1527030443392};\\\", \\\"{x:1105,y:984,t:1527030443409};\\\", \\\"{x:1118,y:981,t:1527030443426};\\\", \\\"{x:1138,y:981,t:1527030443443};\\\", \\\"{x:1139,y:981,t:1527030443474};\\\", \\\"{x:1144,y:977,t:1527030444795};\\\", \\\"{x:1161,y:969,t:1527030444810};\\\", \\\"{x:1202,y:936,t:1527030444827};\\\", \\\"{x:1233,y:924,t:1527030444843};\\\", \\\"{x:1269,y:910,t:1527030444860};\\\", \\\"{x:1290,y:902,t:1527030444876};\\\", \\\"{x:1298,y:899,t:1527030444893};\\\", \\\"{x:1299,y:897,t:1527030444909};\\\", \\\"{x:1300,y:896,t:1527030444927};\\\", \\\"{x:1301,y:895,t:1527030444944};\\\", \\\"{x:1301,y:894,t:1527030444960};\\\", \\\"{x:1301,y:893,t:1527030444977};\\\", \\\"{x:1301,y:892,t:1527030444995};\\\", \\\"{x:1301,y:891,t:1527030445051};\\\", \\\"{x:1300,y:889,t:1527030445059};\\\", \\\"{x:1297,y:885,t:1527030445076};\\\", \\\"{x:1289,y:881,t:1527030445093};\\\", \\\"{x:1281,y:876,t:1527030445111};\\\", \\\"{x:1276,y:873,t:1527030445127};\\\", \\\"{x:1271,y:870,t:1527030445143};\\\", \\\"{x:1267,y:866,t:1527030445161};\\\", \\\"{x:1257,y:853,t:1527030445176};\\\", \\\"{x:1247,y:836,t:1527030445194};\\\", \\\"{x:1236,y:802,t:1527030445210};\\\", \\\"{x:1225,y:779,t:1527030445226};\\\", \\\"{x:1215,y:762,t:1527030445244};\\\", \\\"{x:1212,y:755,t:1527030445260};\\\", \\\"{x:1209,y:749,t:1527030445277};\\\", \\\"{x:1209,y:746,t:1527030445294};\\\", \\\"{x:1207,y:739,t:1527030445310};\\\", \\\"{x:1205,y:734,t:1527030445327};\\\", \\\"{x:1202,y:729,t:1527030445344};\\\", \\\"{x:1201,y:727,t:1527030445361};\\\", \\\"{x:1199,y:724,t:1527030445377};\\\", \\\"{x:1198,y:723,t:1527030445394};\\\", \\\"{x:1196,y:721,t:1527030445410};\\\", \\\"{x:1195,y:719,t:1527030445498};\\\", \\\"{x:1194,y:717,t:1527030445511};\\\", \\\"{x:1193,y:716,t:1527030445527};\\\", \\\"{x:1192,y:715,t:1527030445542};\\\", \\\"{x:1190,y:711,t:1527030445560};\\\", \\\"{x:1188,y:709,t:1527030445577};\\\", \\\"{x:1182,y:704,t:1527030445593};\\\", \\\"{x:1178,y:700,t:1527030445610};\\\", \\\"{x:1176,y:700,t:1527030445722};\\\", \\\"{x:1175,y:700,t:1527030445810};\\\", \\\"{x:1175,y:702,t:1527030445828};\\\", \\\"{x:1174,y:705,t:1527030445843};\\\", \\\"{x:1172,y:710,t:1527030445861};\\\", \\\"{x:1171,y:713,t:1527030445878};\\\", \\\"{x:1170,y:718,t:1527030445894};\\\", \\\"{x:1170,y:723,t:1527030445911};\\\", \\\"{x:1170,y:730,t:1527030445927};\\\", \\\"{x:1170,y:735,t:1527030445944};\\\", \\\"{x:1170,y:737,t:1527030445960};\\\", \\\"{x:1171,y:740,t:1527030445978};\\\", \\\"{x:1172,y:743,t:1527030445994};\\\", \\\"{x:1174,y:746,t:1527030446010};\\\", \\\"{x:1177,y:751,t:1527030446027};\\\", \\\"{x:1180,y:755,t:1527030446045};\\\", \\\"{x:1180,y:757,t:1527030446060};\\\", \\\"{x:1182,y:760,t:1527030446078};\\\", \\\"{x:1183,y:763,t:1527030446095};\\\", \\\"{x:1184,y:765,t:1527030446111};\\\", \\\"{x:1185,y:768,t:1527030446127};\\\", \\\"{x:1186,y:773,t:1527030446145};\\\", \\\"{x:1190,y:779,t:1527030446161};\\\", \\\"{x:1195,y:790,t:1527030446178};\\\", \\\"{x:1206,y:809,t:1527030446195};\\\", \\\"{x:1212,y:823,t:1527030446211};\\\", \\\"{x:1217,y:835,t:1527030446230};\\\", \\\"{x:1227,y:850,t:1527030446245};\\\", \\\"{x:1237,y:866,t:1527030446260};\\\", \\\"{x:1244,y:883,t:1527030446277};\\\", \\\"{x:1251,y:897,t:1527030446294};\\\", \\\"{x:1258,y:910,t:1527030446311};\\\", \\\"{x:1265,y:924,t:1527030446327};\\\", \\\"{x:1269,y:935,t:1527030446344};\\\", \\\"{x:1275,y:949,t:1527030446360};\\\", \\\"{x:1280,y:958,t:1527030446377};\\\", \\\"{x:1283,y:965,t:1527030446393};\\\", \\\"{x:1284,y:966,t:1527030446410};\\\", \\\"{x:1284,y:967,t:1527030446427};\\\", \\\"{x:1285,y:969,t:1527030446445};\\\", \\\"{x:1285,y:970,t:1527030446586};\\\", \\\"{x:1285,y:972,t:1527030446617};\\\", \\\"{x:1283,y:972,t:1527030446682};\\\", \\\"{x:1283,y:973,t:1527030446694};\\\", \\\"{x:1282,y:973,t:1527030446803};\\\", \\\"{x:1280,y:973,t:1527030446914};\\\", \\\"{x:1280,y:974,t:1527030446962};\\\", \\\"{x:1279,y:974,t:1527030447057};\\\", \\\"{x:1277,y:974,t:1527030447194};\\\", \\\"{x:1276,y:974,t:1527030447427};\\\", \\\"{x:1276,y:973,t:1527030447458};\\\", \\\"{x:1276,y:972,t:1527030447466};\\\", \\\"{x:1276,y:971,t:1527030447479};\\\", \\\"{x:1276,y:969,t:1527030447495};\\\", \\\"{x:1276,y:966,t:1527030447512};\\\", \\\"{x:1277,y:963,t:1527030447529};\\\", \\\"{x:1278,y:960,t:1527030447546};\\\", \\\"{x:1279,y:957,t:1527030447562};\\\", \\\"{x:1281,y:953,t:1527030447578};\\\", \\\"{x:1285,y:946,t:1527030447596};\\\", \\\"{x:1290,y:935,t:1527030447612};\\\", \\\"{x:1301,y:915,t:1527030447629};\\\", \\\"{x:1315,y:897,t:1527030447646};\\\", \\\"{x:1322,y:886,t:1527030447663};\\\", \\\"{x:1331,y:872,t:1527030447679};\\\", \\\"{x:1336,y:864,t:1527030447695};\\\", \\\"{x:1340,y:851,t:1527030447712};\\\", \\\"{x:1343,y:834,t:1527030447729};\\\", \\\"{x:1348,y:809,t:1527030447746};\\\", \\\"{x:1352,y:793,t:1527030447762};\\\", \\\"{x:1357,y:777,t:1527030447779};\\\", \\\"{x:1361,y:764,t:1527030447796};\\\", \\\"{x:1364,y:751,t:1527030447812};\\\", \\\"{x:1367,y:742,t:1527030447829};\\\", \\\"{x:1371,y:728,t:1527030447846};\\\", \\\"{x:1374,y:718,t:1527030447862};\\\", \\\"{x:1378,y:707,t:1527030447878};\\\", \\\"{x:1385,y:694,t:1527030447895};\\\", \\\"{x:1394,y:680,t:1527030447913};\\\", \\\"{x:1404,y:666,t:1527030447928};\\\", \\\"{x:1430,y:646,t:1527030447946};\\\", \\\"{x:1496,y:597,t:1527030447962};\\\", \\\"{x:1571,y:523,t:1527030447979};\\\", \\\"{x:1664,y:447,t:1527030447996};\\\", \\\"{x:1740,y:390,t:1527030448012};\\\", \\\"{x:1792,y:345,t:1527030448029};\\\", \\\"{x:1842,y:302,t:1527030448045};\\\", \\\"{x:1875,y:266,t:1527030448063};\\\", \\\"{x:1902,y:240,t:1527030448079};\\\", \\\"{x:1917,y:224,t:1527030448096};\\\", \\\"{x:1919,y:217,t:1527030448112};\\\", \\\"{x:1919,y:213,t:1527030448129};\\\", \\\"{x:1919,y:210,t:1527030448145};\\\", \\\"{x:1918,y:211,t:1527030448241};\\\", \\\"{x:1913,y:212,t:1527030448249};\\\", \\\"{x:1907,y:217,t:1527030448262};\\\", \\\"{x:1900,y:224,t:1527030448279};\\\", \\\"{x:1887,y:232,t:1527030448296};\\\", \\\"{x:1868,y:241,t:1527030448312};\\\", \\\"{x:1786,y:268,t:1527030448329};\\\", \\\"{x:1656,y:306,t:1527030448346};\\\", \\\"{x:1513,y:361,t:1527030448362};\\\", \\\"{x:1338,y:423,t:1527030448380};\\\", \\\"{x:1156,y:477,t:1527030448396};\\\", \\\"{x:978,y:534,t:1527030448412};\\\", \\\"{x:810,y:577,t:1527030448429};\\\", \\\"{x:664,y:616,t:1527030448446};\\\", \\\"{x:523,y:658,t:1527030448462};\\\", \\\"{x:406,y:676,t:1527030448480};\\\", \\\"{x:331,y:689,t:1527030448496};\\\", \\\"{x:295,y:693,t:1527030448512};\\\", \\\"{x:268,y:695,t:1527030448529};\\\", \\\"{x:264,y:695,t:1527030448546};\\\", \\\"{x:262,y:695,t:1527030448562};\\\", \\\"{x:261,y:693,t:1527030448579};\\\", \\\"{x:261,y:687,t:1527030448597};\\\", \\\"{x:260,y:681,t:1527030448613};\\\", \\\"{x:260,y:675,t:1527030448630};\\\", \\\"{x:260,y:667,t:1527030448646};\\\", \\\"{x:262,y:657,t:1527030448663};\\\", \\\"{x:270,y:644,t:1527030448682};\\\", \\\"{x:279,y:634,t:1527030448697};\\\", \\\"{x:292,y:617,t:1527030448713};\\\", \\\"{x:307,y:605,t:1527030448730};\\\", \\\"{x:319,y:597,t:1527030448746};\\\", \\\"{x:330,y:589,t:1527030448762};\\\", \\\"{x:336,y:585,t:1527030448779};\\\", \\\"{x:337,y:584,t:1527030448796};\\\", \\\"{x:338,y:583,t:1527030448812};\\\", \\\"{x:337,y:585,t:1527030448890};\\\", \\\"{x:336,y:586,t:1527030448898};\\\", \\\"{x:335,y:589,t:1527030448913};\\\", \\\"{x:333,y:591,t:1527030448929};\\\", \\\"{x:330,y:589,t:1527030449106};\\\", \\\"{x:330,y:588,t:1527030449113};\\\", \\\"{x:329,y:585,t:1527030449129};\\\", \\\"{x:329,y:583,t:1527030449146};\\\", \\\"{x:329,y:579,t:1527030449164};\\\", \\\"{x:329,y:577,t:1527030449180};\\\", \\\"{x:333,y:574,t:1527030449196};\\\", \\\"{x:340,y:570,t:1527030449213};\\\", \\\"{x:353,y:566,t:1527030449230};\\\", \\\"{x:365,y:565,t:1527030449246};\\\", \\\"{x:374,y:562,t:1527030449263};\\\", \\\"{x:388,y:558,t:1527030449281};\\\", \\\"{x:404,y:552,t:1527030449296};\\\", \\\"{x:414,y:550,t:1527030449313};\\\", \\\"{x:415,y:549,t:1527030449330};\\\", \\\"{x:415,y:548,t:1527030449442};\\\", \\\"{x:414,y:548,t:1527030449458};\\\", \\\"{x:411,y:549,t:1527030449466};\\\", \\\"{x:409,y:550,t:1527030449481};\\\", \\\"{x:403,y:553,t:1527030449497};\\\", \\\"{x:396,y:556,t:1527030449514};\\\", \\\"{x:393,y:557,t:1527030449531};\\\", \\\"{x:389,y:557,t:1527030449546};\\\", \\\"{x:388,y:557,t:1527030449563};\\\", \\\"{x:386,y:557,t:1527030449580};\\\", \\\"{x:385,y:559,t:1527030449597};\\\", \\\"{x:383,y:559,t:1527030449613};\\\", \\\"{x:382,y:559,t:1527030449630};\\\", \\\"{x:382,y:560,t:1527030449977};\\\", \\\"{x:381,y:561,t:1527030449985};\\\", \\\"{x:381,y:563,t:1527030449997};\\\", \\\"{x:381,y:565,t:1527030450013};\\\", \\\"{x:381,y:567,t:1527030450030};\\\", \\\"{x:381,y:569,t:1527030450047};\\\", \\\"{x:381,y:572,t:1527030450065};\\\", \\\"{x:381,y:575,t:1527030450081};\\\", \\\"{x:381,y:578,t:1527030450098};\\\", \\\"{x:382,y:581,t:1527030450114};\\\", \\\"{x:382,y:582,t:1527030450131};\\\", \\\"{x:383,y:586,t:1527030450148};\\\", \\\"{x:383,y:588,t:1527030450164};\\\", \\\"{x:383,y:591,t:1527030450180};\\\", \\\"{x:384,y:594,t:1527030450197};\\\", \\\"{x:386,y:597,t:1527030450214};\\\", \\\"{x:386,y:599,t:1527030450230};\\\", \\\"{x:387,y:600,t:1527030450247};\\\", \\\"{x:388,y:605,t:1527030450264};\\\", \\\"{x:390,y:607,t:1527030450281};\\\", \\\"{x:393,y:615,t:1527030450298};\\\", \\\"{x:395,y:620,t:1527030450315};\\\", \\\"{x:398,y:625,t:1527030450331};\\\", \\\"{x:404,y:632,t:1527030450347};\\\", \\\"{x:410,y:640,t:1527030450364};\\\", \\\"{x:423,y:651,t:1527030450381};\\\", \\\"{x:432,y:657,t:1527030450397};\\\", \\\"{x:441,y:661,t:1527030450414};\\\", \\\"{x:451,y:667,t:1527030450430};\\\", \\\"{x:455,y:669,t:1527030450447};\\\", \\\"{x:461,y:671,t:1527030450464};\\\", \\\"{x:463,y:672,t:1527030450482};\\\", \\\"{x:465,y:673,t:1527030450497};\\\", \\\"{x:466,y:674,t:1527030450514};\\\", \\\"{x:468,y:676,t:1527030450531};\\\", \\\"{x:474,y:680,t:1527030450547};\\\", \\\"{x:481,y:684,t:1527030450564};\\\", \\\"{x:484,y:687,t:1527030450582};\\\", \\\"{x:487,y:690,t:1527030450598};\\\", \\\"{x:491,y:692,t:1527030450614};\\\", \\\"{x:491,y:693,t:1527030450631};\\\", \\\"{x:493,y:694,t:1527030450648};\\\", \\\"{x:495,y:696,t:1527030450664};\\\", \\\"{x:496,y:698,t:1527030450681};\\\", \\\"{x:496,y:700,t:1527030450698};\\\", \\\"{x:497,y:701,t:1527030450716};\\\", \\\"{x:498,y:703,t:1527030450731};\\\", \\\"{x:498,y:704,t:1527030450769};\\\", \\\"{x:498,y:705,t:1527030451098};\\\", \\\"{x:503,y:715,t:1527030451115};\\\", \\\"{x:508,y:724,t:1527030451132};\\\", \\\"{x:512,y:727,t:1527030451149};\\\", \\\"{x:517,y:733,t:1527030451164};\\\", \\\"{x:525,y:744,t:1527030451182};\\\", \\\"{x:530,y:758,t:1527030451198};\\\", \\\"{x:535,y:773,t:1527030451216};\\\", \\\"{x:539,y:788,t:1527030451231};\\\", \\\"{x:542,y:801,t:1527030451249};\\\", \\\"{x:552,y:820,t:1527030451265};\\\", \\\"{x:561,y:830,t:1527030451282};\\\", \\\"{x:566,y:836,t:1527030451298};\\\", \\\"{x:574,y:844,t:1527030451316};\\\", \\\"{x:583,y:851,t:1527030451331};\\\", \\\"{x:600,y:861,t:1527030451349};\\\", \\\"{x:616,y:871,t:1527030451366};\\\", \\\"{x:634,y:877,t:1527030451382};\\\", \\\"{x:650,y:882,t:1527030451399};\\\", \\\"{x:661,y:883,t:1527030451415};\\\", \\\"{x:667,y:884,t:1527030451431};\\\", \\\"{x:670,y:884,t:1527030451449};\\\", \\\"{x:673,y:884,t:1527030451466};\\\", \\\"{x:675,y:884,t:1527030451482};\\\", \\\"{x:679,y:886,t:1527030451498};\\\", \\\"{x:684,y:889,t:1527030451515};\\\", \\\"{x:687,y:891,t:1527030451532};\\\", \\\"{x:695,y:895,t:1527030451549};\\\", \\\"{x:707,y:903,t:1527030451565};\\\", \\\"{x:723,y:912,t:1527030451583};\\\", \\\"{x:737,y:918,t:1527030451599};\\\", \\\"{x:745,y:920,t:1527030451615};\\\", \\\"{x:749,y:921,t:1527030451632};\\\", \\\"{x:749,y:922,t:1527030451648};\\\", \\\"{x:750,y:923,t:1527030451666};\\\", \\\"{x:751,y:924,t:1527030451681};\\\", \\\"{x:752,y:925,t:1527030451706};\\\", \\\"{x:753,y:926,t:1527030451721};\\\", \\\"{x:754,y:926,t:1527030454803};\\\", \\\"{x:754,y:927,t:1527030454825};\\\", \\\"{x:754,y:928,t:1527030454875};\\\", \\\"{x:753,y:928,t:1527030454884};\\\", \\\"{x:748,y:931,t:1527030454902};\\\", \\\"{x:735,y:931,t:1527030454918};\\\", \\\"{x:734,y:931,t:1527030454935};\\\", \\\"{x:732,y:931,t:1527030454954};\\\", \\\"{x:731,y:931,t:1527030454968};\\\", \\\"{x:728,y:931,t:1527030454984};\\\", \\\"{x:726,y:931,t:1527030455090};\\\", \\\"{x:725,y:931,t:1527030455122};\\\", \\\"{x:723,y:931,t:1527030455134};\\\", \\\"{x:722,y:931,t:1527030455162};\\\", \\\"{x:721,y:930,t:1527030455178};\\\", \\\"{x:721,y:929,t:1527030455185};\\\", \\\"{x:724,y:921,t:1527030455201};\\\", \\\"{x:733,y:901,t:1527030455218};\\\", \\\"{x:749,y:869,t:1527030455236};\\\", \\\"{x:767,y:846,t:1527030455252};\\\", \\\"{x:781,y:827,t:1527030455268};\\\", \\\"{x:788,y:816,t:1527030455286};\\\", \\\"{x:792,y:809,t:1527030455301};\\\", \\\"{x:792,y:803,t:1527030455318};\\\", \\\"{x:786,y:791,t:1527030455335};\\\", \\\"{x:770,y:776,t:1527030455351};\\\", \\\"{x:750,y:764,t:1527030455369};\\\", \\\"{x:698,y:753,t:1527030455385};\\\", \\\"{x:644,y:745,t:1527030455401};\\\", \\\"{x:592,y:740,t:1527030455418};\\\", \\\"{x:552,y:733,t:1527030455436};\\\", \\\"{x:523,y:731,t:1527030455451};\\\", \\\"{x:504,y:730,t:1527030455468};\\\", \\\"{x:494,y:729,t:1527030455485};\\\", \\\"{x:490,y:728,t:1527030455501};\\\", \\\"{x:489,y:727,t:1527030455825};\\\", \\\"{x:489,y:727,t:1527030455901};\\\", \\\"{x:489,y:728,t:1527030456626};\\\", \\\"{x:489,y:730,t:1527030456636};\\\", \\\"{x:489,y:732,t:1527030456652};\\\", \\\"{x:489,y:733,t:1527030456673};\\\", \\\"{x:489,y:734,t:1527030456686};\\\", \\\"{x:489,y:735,t:1527030456703};\\\", \\\"{x:489,y:736,t:1527030456721};\\\", \\\"{x:489,y:737,t:1527030456746};\\\", \\\"{x:489,y:738,t:1527030456929};\\\", \\\"{x:490,y:738,t:1527030456944};\\\", \\\"{x:490,y:739,t:1527030456985};\\\" ] }, { \\\"rt\\\": 13425, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 350030, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:490,y:740,t:1527030457131};\\\", \\\"{x:490,y:741,t:1527030457145};\\\", \\\"{x:490,y:742,t:1527030457161};\\\", \\\"{x:490,y:743,t:1527030457177};\\\", \\\"{x:490,y:744,t:1527030457201};\\\", \\\"{x:490,y:745,t:1527030457236};\\\", \\\"{x:490,y:746,t:1527030457252};\\\", \\\"{x:490,y:747,t:1527030457273};\\\", \\\"{x:490,y:748,t:1527030457577};\\\", \\\"{x:491,y:749,t:1527030457587};\\\", \\\"{x:491,y:750,t:1527030457721};\\\", \\\"{x:491,y:751,t:1527030457810};\\\", \\\"{x:491,y:753,t:1527030457914};\\\", \\\"{x:491,y:754,t:1527030458042};\\\", \\\"{x:491,y:756,t:1527030459746};\\\", \\\"{x:491,y:757,t:1527030459770};\\\", \\\"{x:491,y:758,t:1527030459786};\\\", \\\"{x:491,y:759,t:1527030459802};\\\", \\\"{x:491,y:760,t:1527030459898};\\\", \\\"{x:491,y:762,t:1527030460050};\\\", \\\"{x:490,y:763,t:1527030460210};\\\", \\\"{x:489,y:763,t:1527030460466};\\\", \\\"{x:489,y:765,t:1527030460481};\\\", \\\"{x:489,y:766,t:1527030460498};\\\", \\\"{x:489,y:767,t:1527030460513};\\\", \\\"{x:488,y:768,t:1527030460530};\\\", \\\"{x:488,y:769,t:1527030460602};\\\", \\\"{x:487,y:770,t:1527030460650};\\\", \\\"{x:487,y:771,t:1527030462762};\\\", \\\"{x:487,y:772,t:1527030463130};\\\", \\\"{x:485,y:775,t:1527030465218};\\\", \\\"{x:485,y:776,t:1527030465250};\\\", \\\"{x:485,y:777,t:1527030465314};\\\", \\\"{x:485,y:778,t:1527030465562};\\\", \\\"{x:486,y:779,t:1527030466266};\\\", \\\"{x:493,y:779,t:1527030466277};\\\", \\\"{x:526,y:779,t:1527030466293};\\\", \\\"{x:625,y:789,t:1527030466310};\\\", \\\"{x:814,y:798,t:1527030466327};\\\", \\\"{x:1073,y:798,t:1527030466344};\\\", \\\"{x:1344,y:800,t:1527030466360};\\\", \\\"{x:1606,y:794,t:1527030466377};\\\", \\\"{x:1897,y:792,t:1527030466394};\\\", \\\"{x:1919,y:792,t:1527030466410};\\\", \\\"{x:1919,y:794,t:1527030466506};\\\", \\\"{x:1919,y:797,t:1527030466514};\\\", \\\"{x:1919,y:803,t:1527030466528};\\\", \\\"{x:1919,y:811,t:1527030466544};\\\", \\\"{x:1919,y:823,t:1527030466561};\\\", \\\"{x:1919,y:826,t:1527030466577};\\\", \\\"{x:1914,y:834,t:1527030466594};\\\", \\\"{x:1904,y:840,t:1527030466611};\\\", \\\"{x:1900,y:843,t:1527030466628};\\\", \\\"{x:1899,y:848,t:1527030466644};\\\", \\\"{x:1899,y:850,t:1527030466661};\\\", \\\"{x:1896,y:855,t:1527030466678};\\\", \\\"{x:1891,y:861,t:1527030466694};\\\", \\\"{x:1884,y:870,t:1527030466711};\\\", \\\"{x:1882,y:875,t:1527030466728};\\\", \\\"{x:1880,y:881,t:1527030466744};\\\", \\\"{x:1875,y:889,t:1527030466762};\\\", \\\"{x:1867,y:895,t:1527030466778};\\\", \\\"{x:1856,y:900,t:1527030466794};\\\", \\\"{x:1839,y:907,t:1527030466811};\\\", \\\"{x:1826,y:910,t:1527030466828};\\\", \\\"{x:1805,y:915,t:1527030466844};\\\", \\\"{x:1780,y:921,t:1527030466862};\\\", \\\"{x:1753,y:930,t:1527030466879};\\\", \\\"{x:1730,y:938,t:1527030466894};\\\", \\\"{x:1709,y:948,t:1527030466912};\\\", \\\"{x:1696,y:953,t:1527030466928};\\\", \\\"{x:1685,y:959,t:1527030466943};\\\", \\\"{x:1675,y:963,t:1527030466961};\\\", \\\"{x:1670,y:966,t:1527030466978};\\\", \\\"{x:1669,y:967,t:1527030466994};\\\", \\\"{x:1667,y:968,t:1527030467016};\\\", \\\"{x:1666,y:969,t:1527030467041};\\\", \\\"{x:1664,y:969,t:1527030467049};\\\", \\\"{x:1662,y:970,t:1527030467061};\\\", \\\"{x:1661,y:971,t:1527030467089};\\\", \\\"{x:1660,y:971,t:1527030467105};\\\", \\\"{x:1659,y:971,t:1527030467113};\\\", \\\"{x:1658,y:971,t:1527030467128};\\\", \\\"{x:1657,y:971,t:1527030467144};\\\", \\\"{x:1652,y:971,t:1527030467162};\\\", \\\"{x:1647,y:968,t:1527030467178};\\\", \\\"{x:1643,y:964,t:1527030467194};\\\", \\\"{x:1637,y:962,t:1527030467211};\\\", \\\"{x:1635,y:961,t:1527030467228};\\\", \\\"{x:1634,y:961,t:1527030467244};\\\", \\\"{x:1634,y:960,t:1527030467261};\\\", \\\"{x:1632,y:959,t:1527030467278};\\\", \\\"{x:1631,y:958,t:1527030467295};\\\", \\\"{x:1629,y:957,t:1527030467311};\\\", \\\"{x:1628,y:957,t:1527030467328};\\\", \\\"{x:1627,y:955,t:1527030467354};\\\", \\\"{x:1626,y:955,t:1527030467402};\\\", \\\"{x:1625,y:954,t:1527030467411};\\\", \\\"{x:1624,y:952,t:1527030467429};\\\", \\\"{x:1624,y:951,t:1527030467445};\\\", \\\"{x:1622,y:949,t:1527030467461};\\\", \\\"{x:1621,y:948,t:1527030467479};\\\", \\\"{x:1618,y:945,t:1527030467496};\\\", \\\"{x:1614,y:940,t:1527030467511};\\\", \\\"{x:1606,y:930,t:1527030467528};\\\", \\\"{x:1599,y:919,t:1527030467545};\\\", \\\"{x:1594,y:910,t:1527030467562};\\\", \\\"{x:1586,y:900,t:1527030467578};\\\", \\\"{x:1579,y:892,t:1527030467596};\\\", \\\"{x:1568,y:880,t:1527030467611};\\\", \\\"{x:1557,y:872,t:1527030467628};\\\", \\\"{x:1546,y:863,t:1527030467645};\\\", \\\"{x:1537,y:854,t:1527030467661};\\\", \\\"{x:1531,y:848,t:1527030467678};\\\", \\\"{x:1526,y:843,t:1527030467695};\\\", \\\"{x:1521,y:837,t:1527030467711};\\\", \\\"{x:1517,y:831,t:1527030467728};\\\", \\\"{x:1508,y:815,t:1527030467746};\\\", \\\"{x:1502,y:805,t:1527030467762};\\\", \\\"{x:1497,y:794,t:1527030467779};\\\", \\\"{x:1493,y:782,t:1527030467795};\\\", \\\"{x:1487,y:771,t:1527030467812};\\\", \\\"{x:1484,y:760,t:1527030467829};\\\", \\\"{x:1480,y:751,t:1527030467845};\\\", \\\"{x:1476,y:738,t:1527030467863};\\\", \\\"{x:1471,y:725,t:1527030467879};\\\", \\\"{x:1468,y:714,t:1527030467895};\\\", \\\"{x:1463,y:703,t:1527030467913};\\\", \\\"{x:1459,y:694,t:1527030467928};\\\", \\\"{x:1451,y:676,t:1527030467946};\\\", \\\"{x:1446,y:665,t:1527030467961};\\\", \\\"{x:1441,y:655,t:1527030467979};\\\", \\\"{x:1435,y:644,t:1527030467995};\\\", \\\"{x:1430,y:633,t:1527030468012};\\\", \\\"{x:1425,y:622,t:1527030468028};\\\", \\\"{x:1421,y:609,t:1527030468046};\\\", \\\"{x:1418,y:599,t:1527030468063};\\\", \\\"{x:1415,y:586,t:1527030468079};\\\", \\\"{x:1411,y:574,t:1527030468095};\\\", \\\"{x:1407,y:561,t:1527030468112};\\\", \\\"{x:1405,y:552,t:1527030468128};\\\", \\\"{x:1397,y:528,t:1527030468145};\\\", \\\"{x:1395,y:515,t:1527030468163};\\\", \\\"{x:1388,y:497,t:1527030468180};\\\", \\\"{x:1372,y:469,t:1527030468195};\\\", \\\"{x:1357,y:446,t:1527030468212};\\\", \\\"{x:1338,y:427,t:1527030468229};\\\", \\\"{x:1315,y:410,t:1527030468245};\\\", \\\"{x:1292,y:399,t:1527030468262};\\\", \\\"{x:1270,y:393,t:1527030468279};\\\", \\\"{x:1240,y:388,t:1527030468295};\\\", \\\"{x:1201,y:388,t:1527030468312};\\\", \\\"{x:1102,y:405,t:1527030468329};\\\", \\\"{x:997,y:431,t:1527030468345};\\\", \\\"{x:883,y:466,t:1527030468363};\\\", \\\"{x:791,y:496,t:1527030468380};\\\", \\\"{x:703,y:519,t:1527030468396};\\\", \\\"{x:636,y:538,t:1527030468412};\\\", \\\"{x:558,y:562,t:1527030468429};\\\", \\\"{x:497,y:579,t:1527030468446};\\\", \\\"{x:460,y:589,t:1527030468463};\\\", \\\"{x:436,y:596,t:1527030468479};\\\", \\\"{x:420,y:599,t:1527030468495};\\\", \\\"{x:405,y:602,t:1527030468512};\\\", \\\"{x:378,y:607,t:1527030468529};\\\", \\\"{x:365,y:609,t:1527030468546};\\\", \\\"{x:357,y:610,t:1527030468562};\\\", \\\"{x:355,y:610,t:1527030468579};\\\", \\\"{x:360,y:610,t:1527030468649};\\\", \\\"{x:369,y:610,t:1527030468662};\\\", \\\"{x:379,y:610,t:1527030468679};\\\", \\\"{x:397,y:610,t:1527030468696};\\\", \\\"{x:421,y:610,t:1527030468711};\\\", \\\"{x:447,y:610,t:1527030468728};\\\", \\\"{x:461,y:610,t:1527030468745};\\\", \\\"{x:473,y:610,t:1527030468762};\\\", \\\"{x:477,y:610,t:1527030468779};\\\", \\\"{x:480,y:610,t:1527030468795};\\\", \\\"{x:483,y:610,t:1527030468812};\\\", \\\"{x:491,y:610,t:1527030468828};\\\", \\\"{x:501,y:610,t:1527030468847};\\\", \\\"{x:513,y:607,t:1527030468862};\\\", \\\"{x:523,y:604,t:1527030468879};\\\", \\\"{x:535,y:597,t:1527030468896};\\\", \\\"{x:547,y:596,t:1527030468913};\\\", \\\"{x:552,y:594,t:1527030468929};\\\", \\\"{x:556,y:592,t:1527030468946};\\\", \\\"{x:566,y:585,t:1527030468963};\\\", \\\"{x:579,y:580,t:1527030468981};\\\", \\\"{x:584,y:578,t:1527030468996};\\\", \\\"{x:587,y:576,t:1527030469013};\\\", \\\"{x:589,y:575,t:1527030469028};\\\", \\\"{x:590,y:575,t:1527030469049};\\\", \\\"{x:591,y:575,t:1527030469233};\\\", \\\"{x:593,y:572,t:1527030469247};\\\", \\\"{x:595,y:570,t:1527030469263};\\\", \\\"{x:596,y:570,t:1527030469279};\\\", \\\"{x:598,y:568,t:1527030469296};\\\", \\\"{x:599,y:568,t:1527030469321};\\\", \\\"{x:601,y:566,t:1527030469329};\\\", \\\"{x:603,y:565,t:1527030469353};\\\", \\\"{x:604,y:564,t:1527030469363};\\\", \\\"{x:607,y:562,t:1527030469379};\\\", \\\"{x:608,y:561,t:1527030469396};\\\", \\\"{x:611,y:560,t:1527030469413};\\\", \\\"{x:612,y:559,t:1527030469430};\\\", \\\"{x:613,y:559,t:1527030469681};\\\", \\\"{x:612,y:562,t:1527030469695};\\\", \\\"{x:608,y:569,t:1527030469712};\\\", \\\"{x:600,y:579,t:1527030469731};\\\", \\\"{x:590,y:590,t:1527030469746};\\\", \\\"{x:577,y:605,t:1527030469763};\\\", \\\"{x:563,y:623,t:1527030469781};\\\", \\\"{x:550,y:640,t:1527030469797};\\\", \\\"{x:540,y:653,t:1527030469813};\\\", \\\"{x:535,y:661,t:1527030469829};\\\", \\\"{x:530,y:669,t:1527030469847};\\\", \\\"{x:525,y:674,t:1527030469862};\\\", \\\"{x:521,y:676,t:1527030469880};\\\", \\\"{x:517,y:680,t:1527030469897};\\\", \\\"{x:516,y:681,t:1527030469912};\\\", \\\"{x:515,y:682,t:1527030469929};\\\", \\\"{x:514,y:684,t:1527030469961};\\\", \\\"{x:513,y:685,t:1527030469969};\\\", \\\"{x:513,y:687,t:1527030469985};\\\", \\\"{x:513,y:688,t:1527030470001};\\\", \\\"{x:513,y:689,t:1527030470013};\\\", \\\"{x:512,y:691,t:1527030470030};\\\", \\\"{x:511,y:694,t:1527030470047};\\\", \\\"{x:511,y:695,t:1527030470064};\\\", \\\"{x:511,y:697,t:1527030470080};\\\", \\\"{x:511,y:700,t:1527030470097};\\\", \\\"{x:511,y:701,t:1527030470115};\\\", \\\"{x:511,y:703,t:1527030470130};\\\", \\\"{x:511,y:704,t:1527030470153};\\\", \\\"{x:511,y:705,t:1527030470169};\\\", \\\"{x:511,y:706,t:1527030470180};\\\", \\\"{x:511,y:707,t:1527030470265};\\\", \\\"{x:512,y:708,t:1527030470280};\\\", \\\"{x:513,y:710,t:1527030470298};\\\", \\\"{x:513,y:712,t:1527030470762};\\\", \\\"{x:513,y:713,t:1527030471082};\\\", \\\"{x:513,y:715,t:1527030471113};\\\", \\\"{x:513,y:716,t:1527030471153};\\\", \\\"{x:512,y:717,t:1527030471330};\\\", \\\"{x:512,y:718,t:1527030471369};\\\", \\\"{x:511,y:719,t:1527030471381};\\\", \\\"{x:511,y:720,t:1527030471398};\\\", \\\"{x:510,y:721,t:1527030471414};\\\", \\\"{x:509,y:722,t:1527030471432};\\\", \\\"{x:508,y:724,t:1527030471449};\\\", \\\"{x:508,y:725,t:1527030471474};\\\", \\\"{x:508,y:726,t:1527030471481};\\\", \\\"{x:507,y:726,t:1527030471497};\\\", \\\"{x:507,y:727,t:1527030471515};\\\", \\\"{x:506,y:728,t:1527030471569};\\\", \\\"{x:505,y:729,t:1527030471624};\\\" ] }, { \\\"rt\\\": 67714, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 418950, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:730,t:1527030472026};\\\", \\\"{x:504,y:731,t:1527030472073};\\\", \\\"{x:504,y:733,t:1527030472130};\\\", \\\"{x:503,y:733,t:1527030472321};\\\", \\\"{x:503,y:734,t:1527030472345};\\\", \\\"{x:502,y:734,t:1527030472473};\\\", \\\"{x:501,y:735,t:1527030472633};\\\", \\\"{x:501,y:736,t:1527030472649};\\\", \\\"{x:501,y:737,t:1527030472674};\\\", \\\"{x:498,y:740,t:1527030510501};\\\", \\\"{x:486,y:746,t:1527030510516};\\\", \\\"{x:487,y:749,t:1527030510533};\\\", \\\"{x:496,y:760,t:1527030510551};\\\", \\\"{x:502,y:765,t:1527030510566};\\\", \\\"{x:503,y:766,t:1527030510765};\\\", \\\"{x:503,y:768,t:1527030510780};\\\", \\\"{x:500,y:770,t:1527030510793};\\\", \\\"{x:481,y:777,t:1527030510809};\\\", \\\"{x:465,y:778,t:1527030510826};\\\", \\\"{x:452,y:775,t:1527030510843};\\\", \\\"{x:434,y:756,t:1527030510859};\\\", \\\"{x:446,y:668,t:1527030510876};\\\", \\\"{x:524,y:567,t:1527030510894};\\\", \\\"{x:616,y:462,t:1527030510910};\\\", \\\"{x:727,y:327,t:1527030510933};\\\", \\\"{x:751,y:300,t:1527030510950};\\\", \\\"{x:761,y:290,t:1527030510967};\\\", \\\"{x:764,y:290,t:1527030510983};\\\", \\\"{x:761,y:290,t:1527030511068};\\\", \\\"{x:755,y:293,t:1527030511083};\\\", \\\"{x:744,y:298,t:1527030511100};\\\", \\\"{x:742,y:299,t:1527030511118};\\\", \\\"{x:741,y:300,t:1527030511135};\\\", \\\"{x:725,y:310,t:1527030511150};\\\", \\\"{x:676,y:337,t:1527030511168};\\\", \\\"{x:586,y:389,t:1527030511185};\\\", \\\"{x:538,y:422,t:1527030511201};\\\", \\\"{x:536,y:424,t:1527030511218};\\\", \\\"{x:536,y:425,t:1527030511252};\\\", \\\"{x:536,y:426,t:1527030511268};\\\", \\\"{x:541,y:432,t:1527030511284};\\\", \\\"{x:559,y:442,t:1527030511300};\\\", \\\"{x:599,y:461,t:1527030511317};\\\", \\\"{x:665,y:479,t:1527030511335};\\\", \\\"{x:748,y:501,t:1527030511351};\\\", \\\"{x:831,y:528,t:1527030511369};\\\", \\\"{x:896,y:551,t:1527030511385};\\\", \\\"{x:953,y:569,t:1527030511400};\\\", \\\"{x:989,y:580,t:1527030511417};\\\", \\\"{x:1013,y:583,t:1527030511434};\\\", \\\"{x:1016,y:583,t:1527030511450};\\\", \\\"{x:1014,y:583,t:1527030511556};\\\", \\\"{x:1006,y:581,t:1527030511567};\\\", \\\"{x:986,y:572,t:1527030511584};\\\", \\\"{x:963,y:567,t:1527030511602};\\\", \\\"{x:921,y:563,t:1527030511618};\\\", \\\"{x:879,y:556,t:1527030511634};\\\", \\\"{x:856,y:551,t:1527030511650};\\\", \\\"{x:850,y:549,t:1527030511667};\\\", \\\"{x:848,y:547,t:1527030511684};\\\", \\\"{x:847,y:546,t:1527030511796};\\\", \\\"{x:845,y:545,t:1527030511804};\\\", \\\"{x:843,y:543,t:1527030511819};\\\", \\\"{x:842,y:543,t:1527030511835};\\\", \\\"{x:842,y:542,t:1527030511851};\\\", \\\"{x:841,y:542,t:1527030511868};\\\", \\\"{x:840,y:541,t:1527030511964};\\\", \\\"{x:839,y:540,t:1527030512004};\\\", \\\"{x:837,y:539,t:1527030512028};\\\", \\\"{x:836,y:538,t:1527030512044};\\\", \\\"{x:835,y:538,t:1527030512069};\\\", \\\"{x:835,y:537,t:1527030512109};\\\", \\\"{x:834,y:535,t:1527030512132};\\\", \\\"{x:833,y:534,t:1527030512148};\\\", \\\"{x:833,y:533,t:1527030512165};\\\", \\\"{x:832,y:533,t:1527030512172};\\\", \\\"{x:832,y:532,t:1527030512220};\\\", \\\"{x:832,y:529,t:1527030512235};\\\", \\\"{x:831,y:529,t:1527030512268};\\\", \\\"{x:831,y:528,t:1527030512301};\\\", \\\"{x:830,y:528,t:1527030512413};\\\", \\\"{x:829,y:528,t:1527030512469};\\\", \\\"{x:828,y:527,t:1527030512484};\\\", \\\"{x:827,y:526,t:1527030512500};\\\", \\\"{x:825,y:526,t:1527030512756};\\\", \\\"{x:821,y:528,t:1527030512769};\\\", \\\"{x:810,y:532,t:1527030512785};\\\", \\\"{x:787,y:548,t:1527030512801};\\\", \\\"{x:767,y:562,t:1527030512818};\\\", \\\"{x:711,y:595,t:1527030512835};\\\", \\\"{x:644,y:630,t:1527030512851};\\\", \\\"{x:551,y:659,t:1527030512869};\\\", \\\"{x:501,y:673,t:1527030512886};\\\", \\\"{x:463,y:679,t:1527030512902};\\\", \\\"{x:444,y:680,t:1527030512918};\\\", \\\"{x:440,y:682,t:1527030512935};\\\", \\\"{x:440,y:681,t:1527030513036};\\\", \\\"{x:445,y:678,t:1527030513052};\\\", \\\"{x:456,y:673,t:1527030513069};\\\", \\\"{x:473,y:666,t:1527030513085};\\\", \\\"{x:492,y:656,t:1527030513103};\\\", \\\"{x:513,y:647,t:1527030513120};\\\", \\\"{x:530,y:644,t:1527030513134};\\\", \\\"{x:538,y:640,t:1527030513152};\\\", \\\"{x:540,y:640,t:1527030513169};\\\", \\\"{x:539,y:640,t:1527030513500};\\\", \\\"{x:537,y:641,t:1527030513508};\\\", \\\"{x:534,y:642,t:1527030513519};\\\", \\\"{x:525,y:656,t:1527030513537};\\\", \\\"{x:514,y:680,t:1527030513555};\\\", \\\"{x:501,y:704,t:1527030513570};\\\", \\\"{x:492,y:721,t:1527030513587};\\\", \\\"{x:487,y:729,t:1527030513602};\\\", \\\"{x:483,y:734,t:1527030513619};\\\", \\\"{x:481,y:737,t:1527030513637};\\\", \\\"{x:477,y:732,t:1527030522076};\\\", \\\"{x:475,y:718,t:1527030522092};\\\", \\\"{x:475,y:717,t:1527030522110};\\\", \\\"{x:471,y:716,t:1527030537868};\\\", \\\"{x:432,y:716,t:1527030537877};\\\", \\\"{x:374,y:716,t:1527030537888};\\\", \\\"{x:249,y:714,t:1527030537905};\\\", \\\"{x:154,y:714,t:1527030537922};\\\", \\\"{x:74,y:744,t:1527030537939};\\\", \\\"{x:46,y:761,t:1527030537955};\\\", \\\"{x:38,y:769,t:1527030537972};\\\", \\\"{x:39,y:769,t:1527030537995};\\\", \\\"{x:41,y:769,t:1527030538004};\\\", \\\"{x:47,y:768,t:1527030538022};\\\", \\\"{x:58,y:761,t:1527030538039};\\\", \\\"{x:68,y:748,t:1527030538056};\\\", \\\"{x:91,y:711,t:1527030538072};\\\", \\\"{x:115,y:684,t:1527030538089};\\\", \\\"{x:139,y:654,t:1527030538107};\\\", \\\"{x:169,y:623,t:1527030538123};\\\", \\\"{x:199,y:590,t:1527030538139};\\\", \\\"{x:200,y:588,t:1527030538156};\\\", \\\"{x:200,y:587,t:1527030538210};\\\", \\\"{x:199,y:587,t:1527030538221};\\\", \\\"{x:197,y:587,t:1527030538239};\\\", \\\"{x:196,y:588,t:1527030538275};\\\", \\\"{x:196,y:590,t:1527030538290};\\\", \\\"{x:227,y:603,t:1527030538305};\\\", \\\"{x:265,y:623,t:1527030538322};\\\", \\\"{x:342,y:660,t:1527030538340};\\\", \\\"{x:401,y:692,t:1527030538356};\\\", \\\"{x:432,y:713,t:1527030538372};\\\", \\\"{x:458,y:735,t:1527030538390};\\\", \\\"{x:471,y:750,t:1527030538407};\\\", \\\"{x:478,y:759,t:1527030538422};\\\", \\\"{x:480,y:761,t:1527030538439};\\\", \\\"{x:482,y:761,t:1527030538499};\\\", \\\"{x:485,y:761,t:1527030538506};\\\", \\\"{x:490,y:759,t:1527030538523};\\\", \\\"{x:496,y:756,t:1527030538539};\\\", \\\"{x:504,y:750,t:1527030538556};\\\", \\\"{x:511,y:745,t:1527030538574};\\\", \\\"{x:516,y:740,t:1527030538589};\\\", \\\"{x:518,y:737,t:1527030538605};\\\", \\\"{x:520,y:734,t:1527030538622};\\\", \\\"{x:521,y:734,t:1527030538796};\\\", \\\"{x:523,y:733,t:1527030538812};\\\", \\\"{x:523,y:732,t:1527030538823};\\\", \\\"{x:524,y:731,t:1527030538844};\\\", \\\"{x:525,y:731,t:1527030539299};\\\", \\\"{x:525,y:731,t:1527030539475};\\\" ] }, { \\\"rt\\\": 22650, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 443165, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -G -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:525,y:730,t:1527030544368};\\\", \\\"{x:525,y:729,t:1527030544528};\\\", \\\"{x:525,y:726,t:1527030544543};\\\", \\\"{x:529,y:715,t:1527030544560};\\\", \\\"{x:534,y:709,t:1527030544576};\\\", \\\"{x:537,y:705,t:1527030544593};\\\", \\\"{x:540,y:701,t:1527030544613};\\\", \\\"{x:548,y:696,t:1527030544629};\\\", \\\"{x:559,y:689,t:1527030544647};\\\", \\\"{x:660,y:649,t:1527030544663};\\\", \\\"{x:753,y:611,t:1527030544680};\\\", \\\"{x:841,y:574,t:1527030544697};\\\", \\\"{x:899,y:548,t:1527030544716};\\\", \\\"{x:928,y:535,t:1527030544732};\\\", \\\"{x:947,y:523,t:1527030544749};\\\", \\\"{x:956,y:518,t:1527030544765};\\\", \\\"{x:959,y:515,t:1527030544781};\\\", \\\"{x:962,y:514,t:1527030544798};\\\", \\\"{x:968,y:510,t:1527030544815};\\\", \\\"{x:984,y:502,t:1527030544831};\\\", \\\"{x:1012,y:495,t:1527030544848};\\\", \\\"{x:1041,y:486,t:1527030544865};\\\", \\\"{x:1076,y:476,t:1527030544882};\\\", \\\"{x:1116,y:464,t:1527030544899};\\\", \\\"{x:1144,y:455,t:1527030544916};\\\", \\\"{x:1168,y:447,t:1527030544932};\\\", \\\"{x:1182,y:444,t:1527030544949};\\\", \\\"{x:1187,y:442,t:1527030544964};\\\", \\\"{x:1188,y:442,t:1527030544981};\\\", \\\"{x:1188,y:441,t:1527030544999};\\\", \\\"{x:1189,y:441,t:1527030545048};\\\", \\\"{x:1191,y:441,t:1527030545280};\\\", \\\"{x:1199,y:442,t:1527030545288};\\\", \\\"{x:1211,y:444,t:1527030545299};\\\", \\\"{x:1250,y:452,t:1527030545315};\\\", \\\"{x:1300,y:465,t:1527030545332};\\\", \\\"{x:1344,y:475,t:1527030545350};\\\", \\\"{x:1366,y:478,t:1527030545365};\\\", \\\"{x:1379,y:481,t:1527030545382};\\\", \\\"{x:1383,y:483,t:1527030545399};\\\", \\\"{x:1384,y:484,t:1527030545416};\\\", \\\"{x:1385,y:484,t:1527030545440};\\\", \\\"{x:1387,y:485,t:1527030545449};\\\", \\\"{x:1388,y:487,t:1527030545466};\\\", \\\"{x:1391,y:494,t:1527030545483};\\\", \\\"{x:1394,y:501,t:1527030545499};\\\", \\\"{x:1395,y:507,t:1527030545515};\\\", \\\"{x:1395,y:514,t:1527030545532};\\\", \\\"{x:1395,y:519,t:1527030545549};\\\", \\\"{x:1395,y:526,t:1527030545565};\\\", \\\"{x:1390,y:534,t:1527030545582};\\\", \\\"{x:1385,y:540,t:1527030545599};\\\", \\\"{x:1378,y:549,t:1527030545615};\\\", \\\"{x:1369,y:558,t:1527030545632};\\\", \\\"{x:1363,y:562,t:1527030545648};\\\", \\\"{x:1358,y:565,t:1527030545665};\\\", \\\"{x:1354,y:567,t:1527030545682};\\\", \\\"{x:1347,y:569,t:1527030545699};\\\", \\\"{x:1338,y:574,t:1527030545715};\\\", \\\"{x:1330,y:576,t:1527030545733};\\\", \\\"{x:1324,y:578,t:1527030545748};\\\", \\\"{x:1320,y:579,t:1527030545765};\\\", \\\"{x:1319,y:579,t:1527030545782};\\\", \\\"{x:1318,y:579,t:1527030545798};\\\", \\\"{x:1317,y:579,t:1527030545839};\\\", \\\"{x:1316,y:579,t:1527030545855};\\\", \\\"{x:1315,y:579,t:1527030545864};\\\", \\\"{x:1313,y:579,t:1527030545882};\\\", \\\"{x:1312,y:579,t:1527030545897};\\\", \\\"{x:1311,y:579,t:1527030545999};\\\", \\\"{x:1309,y:577,t:1527030546015};\\\", \\\"{x:1305,y:574,t:1527030546031};\\\", \\\"{x:1304,y:573,t:1527030546048};\\\", \\\"{x:1302,y:572,t:1527030546064};\\\", \\\"{x:1301,y:571,t:1527030546082};\\\", \\\"{x:1299,y:570,t:1527030546097};\\\", \\\"{x:1298,y:568,t:1527030546115};\\\", \\\"{x:1297,y:568,t:1527030546135};\\\", \\\"{x:1297,y:567,t:1527030546176};\\\", \\\"{x:1296,y:566,t:1527030546265};\\\", \\\"{x:1295,y:565,t:1527030546760};\\\", \\\"{x:1293,y:564,t:1527030547184};\\\", \\\"{x:1292,y:564,t:1527030547288};\\\", \\\"{x:1290,y:564,t:1527030547904};\\\", \\\"{x:1289,y:564,t:1527030547968};\\\", \\\"{x:1288,y:564,t:1527030548193};\\\", \\\"{x:1287,y:564,t:1527030549473};\\\", \\\"{x:1290,y:564,t:1527030549912};\\\", \\\"{x:1299,y:564,t:1527030549931};\\\", \\\"{x:1319,y:563,t:1527030549947};\\\", \\\"{x:1348,y:557,t:1527030549964};\\\", \\\"{x:1370,y:552,t:1527030549980};\\\", \\\"{x:1385,y:548,t:1527030549997};\\\", \\\"{x:1393,y:546,t:1527030550014};\\\", \\\"{x:1394,y:545,t:1527030550031};\\\", \\\"{x:1395,y:545,t:1527030550047};\\\", \\\"{x:1397,y:545,t:1527030550096};\\\", \\\"{x:1398,y:545,t:1527030550113};\\\", \\\"{x:1400,y:545,t:1527030550130};\\\", \\\"{x:1401,y:545,t:1527030550147};\\\", \\\"{x:1404,y:545,t:1527030550163};\\\", \\\"{x:1406,y:546,t:1527030550180};\\\", \\\"{x:1409,y:548,t:1527030550197};\\\", \\\"{x:1411,y:548,t:1527030550213};\\\", \\\"{x:1412,y:549,t:1527030550230};\\\", \\\"{x:1415,y:550,t:1527030550247};\\\", \\\"{x:1417,y:550,t:1527030550263};\\\", \\\"{x:1418,y:550,t:1527030550280};\\\", \\\"{x:1419,y:551,t:1527030550299};\\\", \\\"{x:1420,y:552,t:1527030550369};\\\", \\\"{x:1420,y:553,t:1527030550576};\\\", \\\"{x:1418,y:553,t:1527030550607};\\\", \\\"{x:1417,y:553,t:1527030550639};\\\", \\\"{x:1416,y:554,t:1527030550647};\\\", \\\"{x:1415,y:554,t:1527030550662};\\\", \\\"{x:1414,y:554,t:1527030550728};\\\", \\\"{x:1413,y:554,t:1527030550743};\\\", \\\"{x:1412,y:554,t:1527030550760};\\\", \\\"{x:1411,y:554,t:1527030550784};\\\", \\\"{x:1410,y:554,t:1527030550799};\\\", \\\"{x:1409,y:554,t:1527030550816};\\\", \\\"{x:1408,y:554,t:1527030550864};\\\", \\\"{x:1407,y:555,t:1527030550896};\\\", \\\"{x:1406,y:555,t:1527030551168};\\\", \\\"{x:1405,y:555,t:1527030551179};\\\", \\\"{x:1403,y:555,t:1527030551207};\\\", \\\"{x:1401,y:555,t:1527030551296};\\\", \\\"{x:1400,y:555,t:1527030551360};\\\", \\\"{x:1400,y:556,t:1527030551392};\\\", \\\"{x:1399,y:556,t:1527030551488};\\\", \\\"{x:1398,y:557,t:1527030551496};\\\", \\\"{x:1397,y:557,t:1527030551513};\\\", \\\"{x:1395,y:558,t:1527030551529};\\\", \\\"{x:1394,y:559,t:1527030551551};\\\", \\\"{x:1393,y:560,t:1527030551563};\\\", \\\"{x:1392,y:561,t:1527030551599};\\\", \\\"{x:1391,y:564,t:1527030551615};\\\", \\\"{x:1391,y:565,t:1527030551647};\\\", \\\"{x:1393,y:567,t:1527030551752};\\\", \\\"{x:1396,y:567,t:1527030551762};\\\", \\\"{x:1404,y:567,t:1527030551779};\\\", \\\"{x:1413,y:567,t:1527030551799};\\\", \\\"{x:1422,y:567,t:1527030551813};\\\", \\\"{x:1428,y:567,t:1527030551828};\\\", \\\"{x:1430,y:567,t:1527030551846};\\\", \\\"{x:1431,y:567,t:1527030551863};\\\", \\\"{x:1432,y:567,t:1527030551895};\\\", \\\"{x:1430,y:567,t:1527030552080};\\\", \\\"{x:1429,y:567,t:1527030552096};\\\", \\\"{x:1426,y:567,t:1527030552113};\\\", \\\"{x:1425,y:567,t:1527030552130};\\\", \\\"{x:1423,y:567,t:1527030552146};\\\", \\\"{x:1422,y:567,t:1527030552162};\\\", \\\"{x:1420,y:567,t:1527030552179};\\\", \\\"{x:1419,y:567,t:1527030552197};\\\", \\\"{x:1418,y:567,t:1527030552213};\\\", \\\"{x:1417,y:567,t:1527030552229};\\\", \\\"{x:1416,y:567,t:1527030552248};\\\", \\\"{x:1415,y:567,t:1527030552288};\\\", \\\"{x:1414,y:567,t:1527030552296};\\\", \\\"{x:1413,y:566,t:1527030552312};\\\", \\\"{x:1412,y:566,t:1527030552344};\\\", \\\"{x:1411,y:566,t:1527030552352};\\\", \\\"{x:1410,y:566,t:1527030552362};\\\", \\\"{x:1409,y:565,t:1527030552383};\\\", \\\"{x:1408,y:565,t:1527030552417};\\\", \\\"{x:1407,y:565,t:1527030552432};\\\", \\\"{x:1407,y:564,t:1527030552446};\\\", \\\"{x:1406,y:564,t:1527030552464};\\\", \\\"{x:1405,y:564,t:1527030552480};\\\", \\\"{x:1404,y:564,t:1527030552497};\\\", \\\"{x:1403,y:563,t:1527030552553};\\\", \\\"{x:1402,y:563,t:1527030552568};\\\", \\\"{x:1401,y:562,t:1527030552592};\\\", \\\"{x:1402,y:563,t:1527030553040};\\\", \\\"{x:1402,y:564,t:1527030553192};\\\", \\\"{x:1402,y:565,t:1527030553280};\\\", \\\"{x:1403,y:565,t:1527030553312};\\\", \\\"{x:1405,y:567,t:1527030553336};\\\", \\\"{x:1406,y:568,t:1527030553368};\\\", \\\"{x:1407,y:568,t:1527030553380};\\\", \\\"{x:1408,y:569,t:1527030553396};\\\", \\\"{x:1410,y:569,t:1527030553412};\\\", \\\"{x:1410,y:570,t:1527030553896};\\\", \\\"{x:1409,y:570,t:1527030558424};\\\", \\\"{x:1407,y:570,t:1527030558432};\\\", \\\"{x:1404,y:570,t:1527030558443};\\\", \\\"{x:1400,y:570,t:1527030558461};\\\", \\\"{x:1397,y:570,t:1527030558476};\\\", \\\"{x:1394,y:570,t:1527030558494};\\\", \\\"{x:1393,y:570,t:1527030558510};\\\", \\\"{x:1390,y:571,t:1527030558527};\\\", \\\"{x:1387,y:573,t:1527030558544};\\\", \\\"{x:1382,y:576,t:1527030558560};\\\", \\\"{x:1375,y:580,t:1527030558577};\\\", \\\"{x:1369,y:585,t:1527030558593};\\\", \\\"{x:1365,y:588,t:1527030558610};\\\", \\\"{x:1363,y:590,t:1527030558627};\\\", \\\"{x:1361,y:591,t:1527030558644};\\\", \\\"{x:1359,y:593,t:1527030558661};\\\", \\\"{x:1357,y:594,t:1527030558677};\\\", \\\"{x:1356,y:594,t:1527030558693};\\\", \\\"{x:1353,y:594,t:1527030560256};\\\", \\\"{x:1352,y:592,t:1527030560263};\\\", \\\"{x:1351,y:591,t:1527030560276};\\\", \\\"{x:1349,y:588,t:1527030560293};\\\", \\\"{x:1348,y:586,t:1527030560310};\\\", \\\"{x:1344,y:583,t:1527030560325};\\\", \\\"{x:1336,y:577,t:1527030560343};\\\", \\\"{x:1297,y:571,t:1527030560359};\\\", \\\"{x:1262,y:564,t:1527030560375};\\\", \\\"{x:1216,y:556,t:1527030560393};\\\", \\\"{x:1168,y:549,t:1527030560409};\\\", \\\"{x:1110,y:541,t:1527030560426};\\\", \\\"{x:1055,y:528,t:1527030560443};\\\", \\\"{x:1023,y:520,t:1527030560460};\\\", \\\"{x:1013,y:517,t:1527030560476};\\\", \\\"{x:1005,y:515,t:1527030560492};\\\", \\\"{x:1001,y:515,t:1527030560510};\\\", \\\"{x:998,y:515,t:1527030560530};\\\", \\\"{x:994,y:515,t:1527030560550};\\\", \\\"{x:990,y:516,t:1527030560559};\\\", \\\"{x:968,y:525,t:1527030560575};\\\", \\\"{x:937,y:535,t:1527030560592};\\\", \\\"{x:891,y:545,t:1527030560608};\\\", \\\"{x:861,y:552,t:1527030560621};\\\", \\\"{x:806,y:565,t:1527030560638};\\\", \\\"{x:780,y:568,t:1527030560653};\\\", \\\"{x:765,y:571,t:1527030560670};\\\", \\\"{x:764,y:571,t:1527030560688};\\\", \\\"{x:762,y:571,t:1527030560719};\\\", \\\"{x:760,y:571,t:1527030560726};\\\", \\\"{x:756,y:569,t:1527030560738};\\\", \\\"{x:749,y:566,t:1527030560755};\\\", \\\"{x:740,y:564,t:1527030560771};\\\", \\\"{x:729,y:558,t:1527030560788};\\\", \\\"{x:712,y:551,t:1527030560805};\\\", \\\"{x:697,y:542,t:1527030560828};\\\", \\\"{x:691,y:538,t:1527030560845};\\\", \\\"{x:689,y:537,t:1527030560861};\\\", \\\"{x:688,y:537,t:1527030560877};\\\", \\\"{x:688,y:536,t:1527030560902};\\\", \\\"{x:688,y:535,t:1527030560927};\\\", \\\"{x:688,y:533,t:1527030560934};\\\", \\\"{x:687,y:531,t:1527030560945};\\\", \\\"{x:686,y:530,t:1527030560960};\\\", \\\"{x:685,y:529,t:1527030560978};\\\", \\\"{x:680,y:524,t:1527030560995};\\\", \\\"{x:673,y:520,t:1527030561011};\\\", \\\"{x:664,y:514,t:1527030561029};\\\", \\\"{x:653,y:506,t:1527030561045};\\\", \\\"{x:642,y:499,t:1527030561062};\\\", \\\"{x:639,y:497,t:1527030561078};\\\", \\\"{x:636,y:496,t:1527030561095};\\\", \\\"{x:635,y:496,t:1527030561112};\\\", \\\"{x:634,y:495,t:1527030561128};\\\", \\\"{x:633,y:495,t:1527030561167};\\\", \\\"{x:631,y:495,t:1527030561183};\\\", \\\"{x:630,y:495,t:1527030561195};\\\", \\\"{x:628,y:495,t:1527030561212};\\\", \\\"{x:627,y:495,t:1527030561228};\\\", \\\"{x:626,y:494,t:1527030561245};\\\", \\\"{x:632,y:494,t:1527030561663};\\\", \\\"{x:645,y:500,t:1527030561679};\\\", \\\"{x:652,y:504,t:1527030561695};\\\", \\\"{x:660,y:506,t:1527030561712};\\\", \\\"{x:668,y:510,t:1527030561728};\\\", \\\"{x:674,y:512,t:1527030561746};\\\", \\\"{x:677,y:512,t:1527030561762};\\\", \\\"{x:682,y:513,t:1527030561780};\\\", \\\"{x:688,y:514,t:1527030561795};\\\", \\\"{x:701,y:516,t:1527030561813};\\\", \\\"{x:713,y:518,t:1527030561831};\\\", \\\"{x:721,y:518,t:1527030561846};\\\", \\\"{x:725,y:520,t:1527030561862};\\\", \\\"{x:727,y:521,t:1527030561879};\\\", \\\"{x:728,y:521,t:1527030561895};\\\", \\\"{x:729,y:522,t:1527030561919};\\\", \\\"{x:730,y:522,t:1527030561929};\\\", \\\"{x:732,y:523,t:1527030561947};\\\", \\\"{x:734,y:524,t:1527030561962};\\\", \\\"{x:738,y:526,t:1527030561981};\\\", \\\"{x:743,y:527,t:1527030561996};\\\", \\\"{x:757,y:529,t:1527030562012};\\\", \\\"{x:786,y:529,t:1527030562029};\\\", \\\"{x:839,y:529,t:1527030562046};\\\", \\\"{x:883,y:526,t:1527030562062};\\\", \\\"{x:921,y:520,t:1527030562079};\\\", \\\"{x:923,y:519,t:1527030562096};\\\", \\\"{x:924,y:519,t:1527030562199};\\\", \\\"{x:923,y:521,t:1527030562212};\\\", \\\"{x:914,y:525,t:1527030562230};\\\", \\\"{x:903,y:528,t:1527030562246};\\\", \\\"{x:885,y:534,t:1527030562262};\\\", \\\"{x:862,y:540,t:1527030562279};\\\", \\\"{x:853,y:542,t:1527030562296};\\\", \\\"{x:848,y:544,t:1527030562313};\\\", \\\"{x:846,y:544,t:1527030562329};\\\", \\\"{x:845,y:545,t:1527030562346};\\\", \\\"{x:843,y:545,t:1527030562424};\\\", \\\"{x:842,y:545,t:1527030562608};\\\", \\\"{x:840,y:545,t:1527030562855};\\\", \\\"{x:833,y:550,t:1527030562862};\\\", \\\"{x:817,y:556,t:1527030562881};\\\", \\\"{x:805,y:569,t:1527030562896};\\\", \\\"{x:789,y:587,t:1527030562913};\\\", \\\"{x:770,y:609,t:1527030562931};\\\", \\\"{x:728,y:639,t:1527030562947};\\\", \\\"{x:706,y:659,t:1527030562963};\\\", \\\"{x:688,y:680,t:1527030562980};\\\", \\\"{x:676,y:689,t:1527030562997};\\\", \\\"{x:670,y:697,t:1527030563013};\\\", \\\"{x:663,y:704,t:1527030563030};\\\", \\\"{x:661,y:706,t:1527030563046};\\\", \\\"{x:659,y:708,t:1527030563063};\\\", \\\"{x:658,y:709,t:1527030563080};\\\", \\\"{x:657,y:709,t:1527030563098};\\\", \\\"{x:652,y:711,t:1527030563113};\\\", \\\"{x:645,y:712,t:1527030563130};\\\", \\\"{x:633,y:714,t:1527030563147};\\\", \\\"{x:621,y:715,t:1527030563163};\\\", \\\"{x:612,y:715,t:1527030563180};\\\", \\\"{x:598,y:718,t:1527030563198};\\\", \\\"{x:581,y:723,t:1527030563213};\\\", \\\"{x:560,y:728,t:1527030563231};\\\", \\\"{x:525,y:738,t:1527030563246};\\\", \\\"{x:508,y:742,t:1527030563263};\\\", \\\"{x:494,y:744,t:1527030563280};\\\", \\\"{x:488,y:745,t:1527030563297};\\\", \\\"{x:487,y:745,t:1527030563313};\\\" ] }, { \\\"rt\\\": 42980, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 487428, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -O -Z -12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:489,y:745,t:1527030585495};\\\", \\\"{x:512,y:766,t:1527030585511};\\\", \\\"{x:539,y:785,t:1527030585516};\\\", \\\"{x:593,y:812,t:1527030585533};\\\", \\\"{x:650,y:825,t:1527030585547};\\\", \\\"{x:719,y:832,t:1527030585564};\\\", \\\"{x:781,y:834,t:1527030585580};\\\", \\\"{x:841,y:830,t:1527030585597};\\\", \\\"{x:890,y:813,t:1527030585614};\\\", \\\"{x:1011,y:753,t:1527030585630};\\\", \\\"{x:1090,y:696,t:1527030585647};\\\", \\\"{x:1164,y:632,t:1527030585664};\\\", \\\"{x:1228,y:562,t:1527030585681};\\\", \\\"{x:1272,y:505,t:1527030585697};\\\", \\\"{x:1294,y:460,t:1527030585714};\\\", \\\"{x:1302,y:437,t:1527030585731};\\\", \\\"{x:1306,y:430,t:1527030585747};\\\", \\\"{x:1309,y:426,t:1527030585765};\\\", \\\"{x:1311,y:425,t:1527030585781};\\\", \\\"{x:1312,y:424,t:1527030585797};\\\", \\\"{x:1313,y:424,t:1527030586040};\\\", \\\"{x:1315,y:425,t:1527030586049};\\\", \\\"{x:1320,y:441,t:1527030586065};\\\", \\\"{x:1322,y:451,t:1527030586082};\\\", \\\"{x:1324,y:459,t:1527030586099};\\\", \\\"{x:1325,y:463,t:1527030586114};\\\", \\\"{x:1326,y:464,t:1527030586132};\\\", \\\"{x:1326,y:466,t:1527030586336};\\\", \\\"{x:1327,y:475,t:1527030586348};\\\", \\\"{x:1332,y:484,t:1527030586364};\\\", \\\"{x:1336,y:492,t:1527030586382};\\\", \\\"{x:1344,y:508,t:1527030586399};\\\", \\\"{x:1347,y:514,t:1527030586415};\\\", \\\"{x:1349,y:517,t:1527030586431};\\\", \\\"{x:1351,y:519,t:1527030586448};\\\", \\\"{x:1351,y:520,t:1527030586465};\\\", \\\"{x:1354,y:524,t:1527030586481};\\\", \\\"{x:1356,y:530,t:1527030586499};\\\", \\\"{x:1360,y:545,t:1527030586515};\\\", \\\"{x:1361,y:557,t:1527030586531};\\\", \\\"{x:1365,y:570,t:1527030586549};\\\", \\\"{x:1366,y:579,t:1527030586566};\\\", \\\"{x:1367,y:586,t:1527030586581};\\\", \\\"{x:1367,y:588,t:1527030586598};\\\", \\\"{x:1367,y:589,t:1527030586639};\\\", \\\"{x:1367,y:590,t:1527030586663};\\\", \\\"{x:1367,y:591,t:1527030586752};\\\", \\\"{x:1366,y:592,t:1527030586766};\\\", \\\"{x:1360,y:596,t:1527030586782};\\\", \\\"{x:1357,y:597,t:1527030586798};\\\", \\\"{x:1354,y:598,t:1527030586816};\\\", \\\"{x:1350,y:600,t:1527030586831};\\\", \\\"{x:1344,y:610,t:1527030586848};\\\", \\\"{x:1342,y:628,t:1527030586865};\\\", \\\"{x:1336,y:650,t:1527030586881};\\\", \\\"{x:1334,y:670,t:1527030586899};\\\", \\\"{x:1331,y:683,t:1527030586916};\\\", \\\"{x:1330,y:693,t:1527030586931};\\\", \\\"{x:1329,y:702,t:1527030586948};\\\", \\\"{x:1325,y:710,t:1527030586965};\\\", \\\"{x:1324,y:717,t:1527030586983};\\\", \\\"{x:1321,y:722,t:1527030586999};\\\", \\\"{x:1321,y:730,t:1527030587015};\\\", \\\"{x:1321,y:734,t:1527030587033};\\\", \\\"{x:1319,y:738,t:1527030587049};\\\", \\\"{x:1318,y:740,t:1527030587066};\\\", \\\"{x:1317,y:740,t:1527030587183};\\\", \\\"{x:1315,y:741,t:1527030587199};\\\", \\\"{x:1311,y:741,t:1527030587327};\\\", \\\"{x:1309,y:741,t:1527030587337};\\\", \\\"{x:1305,y:741,t:1527030587349};\\\", \\\"{x:1300,y:742,t:1527030587366};\\\", \\\"{x:1293,y:743,t:1527030587382};\\\", \\\"{x:1284,y:743,t:1527030587398};\\\", \\\"{x:1265,y:743,t:1527030587415};\\\", \\\"{x:1246,y:743,t:1527030587432};\\\", \\\"{x:1225,y:742,t:1527030587449};\\\", \\\"{x:1205,y:738,t:1527030587465};\\\", \\\"{x:1190,y:732,t:1527030587482};\\\", \\\"{x:1179,y:725,t:1527030587499};\\\", \\\"{x:1172,y:718,t:1527030587515};\\\", \\\"{x:1168,y:708,t:1527030587532};\\\", \\\"{x:1167,y:696,t:1527030587549};\\\", \\\"{x:1167,y:684,t:1527030587565};\\\", \\\"{x:1167,y:677,t:1527030587582};\\\", \\\"{x:1171,y:669,t:1527030587599};\\\", \\\"{x:1171,y:668,t:1527030587616};\\\", \\\"{x:1173,y:668,t:1527030587655};\\\", \\\"{x:1177,y:668,t:1527030587665};\\\", \\\"{x:1198,y:676,t:1527030587682};\\\", \\\"{x:1228,y:690,t:1527030587699};\\\", \\\"{x:1277,y:707,t:1527030587715};\\\", \\\"{x:1336,y:727,t:1527030587733};\\\", \\\"{x:1381,y:739,t:1527030587750};\\\", \\\"{x:1417,y:750,t:1527030587766};\\\", \\\"{x:1451,y:759,t:1527030587783};\\\", \\\"{x:1482,y:762,t:1527030587799};\\\", \\\"{x:1496,y:762,t:1527030587815};\\\", \\\"{x:1505,y:762,t:1527030587833};\\\", \\\"{x:1508,y:761,t:1527030587849};\\\", \\\"{x:1511,y:760,t:1527030587868};\\\", \\\"{x:1512,y:759,t:1527030587882};\\\", \\\"{x:1512,y:758,t:1527030587899};\\\", \\\"{x:1517,y:755,t:1527030587919};\\\", \\\"{x:1521,y:751,t:1527030587933};\\\", \\\"{x:1528,y:743,t:1527030587950};\\\", \\\"{x:1542,y:731,t:1527030587967};\\\", \\\"{x:1547,y:726,t:1527030587982};\\\", \\\"{x:1558,y:718,t:1527030588000};\\\", \\\"{x:1561,y:716,t:1527030588017};\\\", \\\"{x:1563,y:714,t:1527030588033};\\\", \\\"{x:1564,y:714,t:1527030588049};\\\", \\\"{x:1561,y:714,t:1527030588239};\\\", \\\"{x:1558,y:715,t:1527030588249};\\\", \\\"{x:1552,y:721,t:1527030588267};\\\", \\\"{x:1547,y:730,t:1527030588282};\\\", \\\"{x:1545,y:742,t:1527030588299};\\\", \\\"{x:1545,y:752,t:1527030588317};\\\", \\\"{x:1545,y:758,t:1527030588333};\\\", \\\"{x:1542,y:766,t:1527030588349};\\\", \\\"{x:1538,y:776,t:1527030588366};\\\", \\\"{x:1527,y:805,t:1527030588383};\\\", \\\"{x:1526,y:821,t:1527030588400};\\\", \\\"{x:1525,y:833,t:1527030588417};\\\", \\\"{x:1524,y:845,t:1527030588434};\\\", \\\"{x:1522,y:855,t:1527030588450};\\\", \\\"{x:1522,y:864,t:1527030588467};\\\", \\\"{x:1520,y:869,t:1527030588484};\\\", \\\"{x:1520,y:871,t:1527030588500};\\\", \\\"{x:1520,y:873,t:1527030588516};\\\", \\\"{x:1517,y:869,t:1527030588615};\\\", \\\"{x:1511,y:856,t:1527030588633};\\\", \\\"{x:1502,y:842,t:1527030588649};\\\", \\\"{x:1490,y:826,t:1527030588667};\\\", \\\"{x:1478,y:809,t:1527030588683};\\\", \\\"{x:1466,y:794,t:1527030588700};\\\", \\\"{x:1450,y:779,t:1527030588717};\\\", \\\"{x:1436,y:765,t:1527030588733};\\\", \\\"{x:1423,y:753,t:1527030588750};\\\", \\\"{x:1408,y:740,t:1527030588767};\\\", \\\"{x:1383,y:728,t:1527030588783};\\\", \\\"{x:1371,y:723,t:1527030588800};\\\", \\\"{x:1364,y:720,t:1527030588817};\\\", \\\"{x:1359,y:718,t:1527030588834};\\\", \\\"{x:1355,y:716,t:1527030588851};\\\", \\\"{x:1353,y:716,t:1527030588866};\\\", \\\"{x:1352,y:716,t:1527030588967};\\\", \\\"{x:1350,y:716,t:1527030588983};\\\", \\\"{x:1346,y:717,t:1527030589001};\\\", \\\"{x:1341,y:720,t:1527030589016};\\\", \\\"{x:1338,y:722,t:1527030589033};\\\", \\\"{x:1331,y:728,t:1527030589051};\\\", \\\"{x:1330,y:736,t:1527030589067};\\\", \\\"{x:1330,y:742,t:1527030589084};\\\", \\\"{x:1330,y:745,t:1527030589100};\\\", \\\"{x:1330,y:751,t:1527030589116};\\\", \\\"{x:1331,y:756,t:1527030589134};\\\", \\\"{x:1334,y:762,t:1527030589151};\\\", \\\"{x:1335,y:768,t:1527030589167};\\\", \\\"{x:1337,y:775,t:1527030589183};\\\", \\\"{x:1338,y:779,t:1527030589201};\\\", \\\"{x:1338,y:782,t:1527030589217};\\\", \\\"{x:1338,y:785,t:1527030589234};\\\", \\\"{x:1338,y:790,t:1527030589251};\\\", \\\"{x:1338,y:793,t:1527030589267};\\\", \\\"{x:1338,y:797,t:1527030589284};\\\", \\\"{x:1339,y:800,t:1527030589301};\\\", \\\"{x:1339,y:801,t:1527030589318};\\\", \\\"{x:1339,y:802,t:1527030589333};\\\", \\\"{x:1339,y:803,t:1527030589351};\\\", \\\"{x:1339,y:805,t:1527030589367};\\\", \\\"{x:1339,y:806,t:1527030589391};\\\", \\\"{x:1339,y:807,t:1527030589401};\\\", \\\"{x:1339,y:808,t:1527030589418};\\\", \\\"{x:1339,y:809,t:1527030589434};\\\", \\\"{x:1339,y:810,t:1527030589615};\\\", \\\"{x:1338,y:810,t:1527030589623};\\\", \\\"{x:1337,y:810,t:1527030589634};\\\", \\\"{x:1334,y:809,t:1527030589651};\\\", \\\"{x:1331,y:808,t:1527030589668};\\\", \\\"{x:1330,y:807,t:1527030589684};\\\", \\\"{x:1327,y:806,t:1527030589701};\\\", \\\"{x:1326,y:805,t:1527030589719};\\\", \\\"{x:1325,y:805,t:1527030589767};\\\", \\\"{x:1324,y:805,t:1527030589785};\\\", \\\"{x:1323,y:804,t:1527030589801};\\\", \\\"{x:1322,y:804,t:1527030589872};\\\", \\\"{x:1321,y:804,t:1527030589884};\\\", \\\"{x:1321,y:803,t:1527030589901};\\\", \\\"{x:1320,y:803,t:1527030589918};\\\", \\\"{x:1320,y:802,t:1527030590056};\\\", \\\"{x:1324,y:802,t:1527030590608};\\\", \\\"{x:1334,y:807,t:1527030590618};\\\", \\\"{x:1379,y:828,t:1527030590635};\\\", \\\"{x:1449,y:860,t:1527030590652};\\\", \\\"{x:1522,y:888,t:1527030590668};\\\", \\\"{x:1577,y:909,t:1527030590684};\\\", \\\"{x:1601,y:916,t:1527030590702};\\\", \\\"{x:1612,y:921,t:1527030590718};\\\", \\\"{x:1616,y:922,t:1527030590735};\\\", \\\"{x:1620,y:921,t:1527030590752};\\\", \\\"{x:1623,y:914,t:1527030590769};\\\", \\\"{x:1628,y:899,t:1527030590785};\\\", \\\"{x:1634,y:881,t:1527030590801};\\\", \\\"{x:1638,y:855,t:1527030590819};\\\", \\\"{x:1638,y:837,t:1527030590835};\\\", \\\"{x:1638,y:822,t:1527030590852};\\\", \\\"{x:1638,y:808,t:1527030590869};\\\", \\\"{x:1638,y:794,t:1527030590885};\\\", \\\"{x:1638,y:783,t:1527030590901};\\\", \\\"{x:1637,y:772,t:1527030590920};\\\", \\\"{x:1633,y:765,t:1527030590935};\\\", \\\"{x:1633,y:758,t:1527030590951};\\\", \\\"{x:1630,y:743,t:1527030590969};\\\", \\\"{x:1626,y:731,t:1527030590985};\\\", \\\"{x:1624,y:726,t:1527030591002};\\\", \\\"{x:1621,y:721,t:1527030591019};\\\", \\\"{x:1617,y:711,t:1527030591035};\\\", \\\"{x:1612,y:698,t:1527030591052};\\\", \\\"{x:1605,y:686,t:1527030591070};\\\", \\\"{x:1595,y:677,t:1527030591085};\\\", \\\"{x:1587,y:675,t:1527030591102};\\\", \\\"{x:1580,y:675,t:1527030591119};\\\", \\\"{x:1576,y:675,t:1527030591135};\\\", \\\"{x:1568,y:680,t:1527030591152};\\\", \\\"{x:1560,y:687,t:1527030591168};\\\", \\\"{x:1551,y:696,t:1527030591185};\\\", \\\"{x:1546,y:701,t:1527030591202};\\\", \\\"{x:1542,y:704,t:1527030591219};\\\", \\\"{x:1542,y:705,t:1527030591236};\\\", \\\"{x:1541,y:706,t:1527030591252};\\\", \\\"{x:1540,y:706,t:1527030591271};\\\", \\\"{x:1540,y:708,t:1527030591286};\\\", \\\"{x:1539,y:717,t:1527030591302};\\\", \\\"{x:1537,y:726,t:1527030591319};\\\", \\\"{x:1536,y:731,t:1527030591335};\\\", \\\"{x:1534,y:738,t:1527030591351};\\\", \\\"{x:1533,y:745,t:1527030591369};\\\", \\\"{x:1531,y:755,t:1527030591385};\\\", \\\"{x:1528,y:765,t:1527030591401};\\\", \\\"{x:1526,y:775,t:1527030591418};\\\", \\\"{x:1516,y:787,t:1527030591436};\\\", \\\"{x:1509,y:798,t:1527030591452};\\\", \\\"{x:1500,y:811,t:1527030591468};\\\", \\\"{x:1489,y:823,t:1527030591486};\\\", \\\"{x:1479,y:840,t:1527030591501};\\\", \\\"{x:1460,y:864,t:1527030591519};\\\", \\\"{x:1443,y:883,t:1527030591535};\\\", \\\"{x:1428,y:895,t:1527030591551};\\\", \\\"{x:1418,y:905,t:1527030591568};\\\", \\\"{x:1408,y:914,t:1527030591586};\\\", \\\"{x:1391,y:933,t:1527030591601};\\\", \\\"{x:1374,y:953,t:1527030591619};\\\", \\\"{x:1362,y:968,t:1527030591636};\\\", \\\"{x:1356,y:976,t:1527030591651};\\\", \\\"{x:1354,y:978,t:1527030591668};\\\", \\\"{x:1354,y:979,t:1527030591685};\\\", \\\"{x:1353,y:979,t:1527030591735};\\\", \\\"{x:1344,y:972,t:1527030591752};\\\", \\\"{x:1330,y:954,t:1527030591769};\\\", \\\"{x:1303,y:922,t:1527030591785};\\\", \\\"{x:1242,y:879,t:1527030591802};\\\", \\\"{x:1178,y:837,t:1527030591819};\\\", \\\"{x:1119,y:796,t:1527030591836};\\\", \\\"{x:1044,y:762,t:1527030591852};\\\", \\\"{x:964,y:726,t:1527030591868};\\\", \\\"{x:873,y:688,t:1527030591885};\\\", \\\"{x:756,y:649,t:1527030591903};\\\", \\\"{x:711,y:635,t:1527030591918};\\\", \\\"{x:685,y:628,t:1527030591939};\\\", \\\"{x:680,y:626,t:1527030591952};\\\", \\\"{x:679,y:625,t:1527030591968};\\\", \\\"{x:678,y:625,t:1527030592079};\\\", \\\"{x:678,y:623,t:1527030592336};\\\", \\\"{x:678,y:621,t:1527030592343};\\\", \\\"{x:680,y:618,t:1527030592353};\\\", \\\"{x:689,y:608,t:1527030592370};\\\", \\\"{x:693,y:603,t:1527030592388};\\\", \\\"{x:703,y:595,t:1527030592404};\\\", \\\"{x:730,y:582,t:1527030592421};\\\", \\\"{x:795,y:561,t:1527030592438};\\\", \\\"{x:918,y:533,t:1527030592454};\\\", \\\"{x:960,y:520,t:1527030592470};\\\", \\\"{x:964,y:517,t:1527030592487};\\\", \\\"{x:965,y:516,t:1527030592518};\\\", \\\"{x:965,y:514,t:1527030592526};\\\", \\\"{x:961,y:514,t:1527030592542};\\\", \\\"{x:957,y:514,t:1527030592555};\\\", \\\"{x:947,y:517,t:1527030592571};\\\", \\\"{x:936,y:521,t:1527030592588};\\\", \\\"{x:919,y:531,t:1527030592604};\\\", \\\"{x:879,y:547,t:1527030592620};\\\", \\\"{x:812,y:568,t:1527030592637};\\\", \\\"{x:711,y:598,t:1527030592655};\\\", \\\"{x:653,y:613,t:1527030592671};\\\", \\\"{x:601,y:627,t:1527030592687};\\\", \\\"{x:575,y:630,t:1527030592704};\\\", \\\"{x:569,y:632,t:1527030592722};\\\", \\\"{x:564,y:631,t:1527030592737};\\\", \\\"{x:561,y:629,t:1527030592754};\\\", \\\"{x:555,y:625,t:1527030592770};\\\", \\\"{x:550,y:623,t:1527030592787};\\\", \\\"{x:550,y:622,t:1527030592886};\\\", \\\"{x:550,y:620,t:1527030592904};\\\", \\\"{x:558,y:613,t:1527030592921};\\\", \\\"{x:568,y:607,t:1527030592937};\\\", \\\"{x:575,y:605,t:1527030592954};\\\", \\\"{x:584,y:603,t:1527030592971};\\\", \\\"{x:589,y:601,t:1527030592987};\\\", \\\"{x:593,y:599,t:1527030593005};\\\", \\\"{x:598,y:596,t:1527030593021};\\\", \\\"{x:603,y:594,t:1527030593037};\\\", \\\"{x:606,y:592,t:1527030593055};\\\", \\\"{x:607,y:591,t:1527030593071};\\\", \\\"{x:609,y:586,t:1527030593158};\\\", \\\"{x:611,y:583,t:1527030593171};\\\", \\\"{x:612,y:580,t:1527030593187};\\\", \\\"{x:613,y:580,t:1527030593204};\\\", \\\"{x:613,y:579,t:1527030593454};\\\", \\\"{x:616,y:577,t:1527030593471};\\\", \\\"{x:618,y:576,t:1527030593488};\\\", \\\"{x:626,y:575,t:1527030593504};\\\", \\\"{x:632,y:575,t:1527030593521};\\\", \\\"{x:638,y:575,t:1527030593538};\\\", \\\"{x:650,y:575,t:1527030593555};\\\", \\\"{x:669,y:575,t:1527030593571};\\\", \\\"{x:690,y:575,t:1527030593589};\\\", \\\"{x:713,y:575,t:1527030593604};\\\", \\\"{x:736,y:575,t:1527030593622};\\\", \\\"{x:759,y:575,t:1527030593638};\\\", \\\"{x:773,y:575,t:1527030593654};\\\", \\\"{x:779,y:575,t:1527030593671};\\\", \\\"{x:781,y:575,t:1527030593688};\\\", \\\"{x:784,y:575,t:1527030593705};\\\", \\\"{x:785,y:575,t:1527030593721};\\\", \\\"{x:787,y:575,t:1527030593738};\\\", \\\"{x:788,y:575,t:1527030593759};\\\", \\\"{x:790,y:575,t:1527030593771};\\\", \\\"{x:796,y:575,t:1527030593788};\\\", \\\"{x:804,y:575,t:1527030593806};\\\", \\\"{x:809,y:575,t:1527030593821};\\\", \\\"{x:815,y:575,t:1527030593839};\\\", \\\"{x:819,y:575,t:1527030593855};\\\", \\\"{x:824,y:575,t:1527030593872};\\\", \\\"{x:826,y:575,t:1527030593888};\\\", \\\"{x:827,y:575,t:1527030593904};\\\", \\\"{x:830,y:575,t:1527030594415};\\\", \\\"{x:832,y:575,t:1527030594422};\\\", \\\"{x:833,y:575,t:1527030594438};\\\", \\\"{x:834,y:575,t:1527030594456};\\\", \\\"{x:836,y:574,t:1527030594472};\\\", \\\"{x:837,y:574,t:1527030594503};\\\", \\\"{x:839,y:574,t:1527030594527};\\\", \\\"{x:841,y:574,t:1527030594542};\\\", \\\"{x:842,y:574,t:1527030594555};\\\", \\\"{x:843,y:575,t:1527030594572};\\\", \\\"{x:844,y:576,t:1527030594589};\\\", \\\"{x:844,y:577,t:1527030594607};\\\", \\\"{x:846,y:578,t:1527030594623};\\\", \\\"{x:846,y:579,t:1527030594638};\\\", \\\"{x:846,y:582,t:1527030594655};\\\", \\\"{x:845,y:585,t:1527030594673};\\\", \\\"{x:845,y:590,t:1527030594690};\\\", \\\"{x:845,y:597,t:1527030594707};\\\", \\\"{x:845,y:603,t:1527030594722};\\\", \\\"{x:846,y:612,t:1527030594739};\\\", \\\"{x:846,y:618,t:1527030594755};\\\", \\\"{x:846,y:620,t:1527030594772};\\\", \\\"{x:846,y:622,t:1527030594789};\\\", \\\"{x:846,y:623,t:1527030594822};\\\", \\\"{x:846,y:624,t:1527030594839};\\\", \\\"{x:846,y:625,t:1527030594855};\\\", \\\"{x:846,y:627,t:1527030594886};\\\", \\\"{x:846,y:628,t:1527030594903};\\\", \\\"{x:845,y:629,t:1527030594935};\\\", \\\"{x:844,y:629,t:1527030594942};\\\", \\\"{x:843,y:629,t:1527030594998};\\\", \\\"{x:843,y:630,t:1527030595006};\\\", \\\"{x:842,y:630,t:1527030595054};\\\", \\\"{x:841,y:631,t:1527030595071};\\\", \\\"{x:840,y:631,t:1527030595087};\\\", \\\"{x:839,y:632,t:1527030595096};\\\", \\\"{x:837,y:633,t:1527030595158};\\\", \\\"{x:835,y:634,t:1527030595172};\\\", \\\"{x:833,y:635,t:1527030595190};\\\", \\\"{x:830,y:636,t:1527030595206};\\\", \\\"{x:829,y:637,t:1527030595222};\\\", \\\"{x:826,y:638,t:1527030595240};\\\", \\\"{x:824,y:639,t:1527030595256};\\\", \\\"{x:822,y:640,t:1527030595272};\\\", \\\"{x:822,y:641,t:1527030595289};\\\", \\\"{x:821,y:641,t:1527030595319};\\\", \\\"{x:820,y:642,t:1527030595343};\\\", \\\"{x:818,y:643,t:1527030595407};\\\", \\\"{x:817,y:644,t:1527030595424};\\\", \\\"{x:817,y:647,t:1527030595440};\\\", \\\"{x:816,y:649,t:1527030595456};\\\", \\\"{x:814,y:652,t:1527030595474};\\\", \\\"{x:814,y:653,t:1527030595490};\\\", \\\"{x:814,y:655,t:1527030595506};\\\", \\\"{x:814,y:657,t:1527030595523};\\\", \\\"{x:814,y:658,t:1527030595540};\\\", \\\"{x:814,y:660,t:1527030595556};\\\", \\\"{x:813,y:661,t:1527030595575};\\\", \\\"{x:813,y:662,t:1527030595727};\\\", \\\"{x:812,y:663,t:1527030595740};\\\", \\\"{x:812,y:664,t:1527030595756};\\\", \\\"{x:811,y:665,t:1527030595775};\\\", \\\"{x:811,y:666,t:1527030595839};\\\", \\\"{x:810,y:666,t:1527030595854};\\\", \\\"{x:810,y:667,t:1527030595911};\\\", \\\"{x:809,y:668,t:1527030596047};\\\", \\\"{x:808,y:669,t:1527030596057};\\\", \\\"{x:808,y:670,t:1527030596074};\\\", \\\"{x:805,y:670,t:1527030596091};\\\", \\\"{x:801,y:672,t:1527030596108};\\\", \\\"{x:798,y:672,t:1527030596123};\\\", \\\"{x:795,y:673,t:1527030596140};\\\", \\\"{x:789,y:674,t:1527030596157};\\\", \\\"{x:787,y:674,t:1527030596173};\\\", \\\"{x:784,y:674,t:1527030596190};\\\", \\\"{x:782,y:674,t:1527030596207};\\\", \\\"{x:781,y:674,t:1527030596224};\\\", \\\"{x:780,y:674,t:1527030596241};\\\", \\\"{x:779,y:674,t:1527030596258};\\\", \\\"{x:778,y:674,t:1527030596274};\\\", \\\"{x:777,y:674,t:1527030596766};\\\", \\\"{x:776,y:674,t:1527030596774};\\\", \\\"{x:774,y:673,t:1527030596791};\\\", \\\"{x:773,y:673,t:1527030596807};\\\", \\\"{x:772,y:672,t:1527030596825};\\\", \\\"{x:771,y:671,t:1527030596841};\\\", \\\"{x:770,y:670,t:1527030596857};\\\", \\\"{x:768,y:669,t:1527030596875};\\\", \\\"{x:768,y:668,t:1527030596891};\\\", \\\"{x:767,y:667,t:1527030596907};\\\", \\\"{x:766,y:666,t:1527030596924};\\\", \\\"{x:765,y:665,t:1527030596942};\\\", \\\"{x:764,y:663,t:1527030596957};\\\", \\\"{x:762,y:660,t:1527030596974};\\\", \\\"{x:759,y:656,t:1527030596992};\\\", \\\"{x:758,y:653,t:1527030597008};\\\", \\\"{x:756,y:649,t:1527030597024};\\\", \\\"{x:753,y:643,t:1527030597042};\\\", \\\"{x:750,y:638,t:1527030597058};\\\", \\\"{x:749,y:634,t:1527030597075};\\\", \\\"{x:747,y:631,t:1527030597092};\\\", \\\"{x:746,y:629,t:1527030597107};\\\", \\\"{x:746,y:628,t:1527030597124};\\\", \\\"{x:744,y:629,t:1527030597639};\\\", \\\"{x:741,y:631,t:1527030597646};\\\", \\\"{x:740,y:632,t:1527030597659};\\\", \\\"{x:739,y:632,t:1527030597799};\\\", \\\"{x:737,y:633,t:1527030603970};\\\", \\\"{x:727,y:637,t:1527030603984};\\\", \\\"{x:675,y:649,t:1527030604000};\\\", \\\"{x:628,y:654,t:1527030604016};\\\", \\\"{x:592,y:659,t:1527030604033};\\\", \\\"{x:577,y:663,t:1527030604050};\\\", \\\"{x:576,y:663,t:1527030604067};\\\", \\\"{x:573,y:663,t:1527030604083};\\\", \\\"{x:570,y:663,t:1527030604100};\\\", \\\"{x:566,y:663,t:1527030604117};\\\", \\\"{x:564,y:663,t:1527030604133};\\\", \\\"{x:563,y:663,t:1527030604150};\\\", \\\"{x:562,y:663,t:1527030604168};\\\", \\\"{x:560,y:664,t:1527030604183};\\\", \\\"{x:558,y:666,t:1527030604201};\\\", \\\"{x:556,y:667,t:1527030604217};\\\", \\\"{x:555,y:668,t:1527030604233};\\\", \\\"{x:554,y:668,t:1527030604330};\\\", \\\"{x:553,y:669,t:1527030604394};\\\", \\\"{x:551,y:670,t:1527030604402};\\\", \\\"{x:550,y:670,t:1527030604417};\\\", \\\"{x:549,y:671,t:1527030604434};\\\", \\\"{x:548,y:672,t:1527030604450};\\\", \\\"{x:543,y:676,t:1527030604467};\\\", \\\"{x:538,y:694,t:1527030604485};\\\", \\\"{x:532,y:707,t:1527030604500};\\\", \\\"{x:526,y:718,t:1527030604517};\\\", \\\"{x:522,y:724,t:1527030604536};\\\", \\\"{x:518,y:728,t:1527030604549};\\\", \\\"{x:517,y:729,t:1527030604566};\\\", \\\"{x:515,y:730,t:1527030604697};\\\", \\\"{x:515,y:731,t:1527030604705};\\\", \\\"{x:514,y:731,t:1527030604716};\\\", \\\"{x:513,y:732,t:1527030604734};\\\", \\\"{x:512,y:732,t:1527030607682};\\\" ] }, { \\\"rt\\\": 64159, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 552788, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -E -I -J -J -F -G -F -B -B -B -F -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:730,t:1527030631554};\\\", \\\"{x:539,y:715,t:1527030631563};\\\", \\\"{x:617,y:688,t:1527030631573};\\\", \\\"{x:877,y:606,t:1527030631590};\\\", \\\"{x:1115,y:523,t:1527030631601};\\\", \\\"{x:1275,y:485,t:1527030631617};\\\", \\\"{x:1412,y:448,t:1527030631635};\\\", \\\"{x:1510,y:417,t:1527030631651};\\\", \\\"{x:1541,y:402,t:1527030631668};\\\", \\\"{x:1545,y:398,t:1527030631684};\\\", \\\"{x:1540,y:395,t:1527030631728};\\\", \\\"{x:1526,y:394,t:1527030631736};\\\", \\\"{x:1507,y:394,t:1527030631751};\\\", \\\"{x:1465,y:394,t:1527030631768};\\\", \\\"{x:1390,y:407,t:1527030631784};\\\", \\\"{x:1360,y:417,t:1527030631801};\\\", \\\"{x:1309,y:432,t:1527030631818};\\\", \\\"{x:1263,y:449,t:1527030631835};\\\", \\\"{x:1242,y:458,t:1527030631851};\\\", \\\"{x:1236,y:461,t:1527030631869};\\\", \\\"{x:1235,y:462,t:1527030631886};\\\", \\\"{x:1235,y:464,t:1527030631913};\\\", \\\"{x:1235,y:465,t:1527030631922};\\\", \\\"{x:1235,y:468,t:1527030631935};\\\", \\\"{x:1238,y:474,t:1527030631951};\\\", \\\"{x:1252,y:491,t:1527030631968};\\\", \\\"{x:1313,y:527,t:1527030631984};\\\", \\\"{x:1377,y:545,t:1527030632001};\\\", \\\"{x:1465,y:570,t:1527030632018};\\\", \\\"{x:1532,y:589,t:1527030632035};\\\", \\\"{x:1585,y:603,t:1527030632052};\\\", \\\"{x:1612,y:615,t:1527030632068};\\\", \\\"{x:1623,y:622,t:1527030632084};\\\", \\\"{x:1626,y:625,t:1527030632101};\\\", \\\"{x:1626,y:628,t:1527030632118};\\\", \\\"{x:1625,y:632,t:1527030632134};\\\", \\\"{x:1615,y:642,t:1527030632152};\\\", \\\"{x:1596,y:654,t:1527030632168};\\\", \\\"{x:1566,y:671,t:1527030632185};\\\", \\\"{x:1547,y:680,t:1527030632202};\\\", \\\"{x:1531,y:685,t:1527030632218};\\\", \\\"{x:1524,y:686,t:1527030632235};\\\", \\\"{x:1518,y:686,t:1527030632252};\\\", \\\"{x:1512,y:686,t:1527030632268};\\\", \\\"{x:1504,y:689,t:1527030632285};\\\", \\\"{x:1491,y:690,t:1527030632302};\\\", \\\"{x:1481,y:690,t:1527030632318};\\\", \\\"{x:1472,y:690,t:1527030632335};\\\", \\\"{x:1468,y:691,t:1527030632352};\\\", \\\"{x:1464,y:692,t:1527030632368};\\\", \\\"{x:1461,y:694,t:1527030632385};\\\", \\\"{x:1455,y:698,t:1527030632402};\\\", \\\"{x:1450,y:702,t:1527030632418};\\\", \\\"{x:1446,y:706,t:1527030632435};\\\", \\\"{x:1443,y:709,t:1527030632453};\\\", \\\"{x:1442,y:712,t:1527030632468};\\\", \\\"{x:1438,y:717,t:1527030632485};\\\", \\\"{x:1429,y:723,t:1527030632503};\\\", \\\"{x:1420,y:731,t:1527030632519};\\\", \\\"{x:1408,y:741,t:1527030632535};\\\", \\\"{x:1402,y:750,t:1527030632553};\\\", \\\"{x:1397,y:756,t:1527030632569};\\\", \\\"{x:1382,y:770,t:1527030632585};\\\", \\\"{x:1372,y:777,t:1527030632602};\\\", \\\"{x:1368,y:781,t:1527030632620};\\\", \\\"{x:1367,y:783,t:1527030632635};\\\", \\\"{x:1366,y:784,t:1527030632665};\\\", \\\"{x:1365,y:784,t:1527030632697};\\\", \\\"{x:1364,y:784,t:1527030632714};\\\", \\\"{x:1362,y:784,t:1527030632729};\\\", \\\"{x:1361,y:784,t:1527030632761};\\\", \\\"{x:1361,y:783,t:1527030632802};\\\", \\\"{x:1360,y:782,t:1527030632819};\\\", \\\"{x:1359,y:779,t:1527030632836};\\\", \\\"{x:1359,y:778,t:1527030632852};\\\", \\\"{x:1359,y:777,t:1527030632869};\\\", \\\"{x:1359,y:776,t:1527030632886};\\\", \\\"{x:1359,y:775,t:1527030632905};\\\", \\\"{x:1359,y:774,t:1527030632919};\\\", \\\"{x:1359,y:773,t:1527030632936};\\\", \\\"{x:1359,y:772,t:1527030632952};\\\", \\\"{x:1359,y:768,t:1527030632970};\\\", \\\"{x:1359,y:766,t:1527030632985};\\\", \\\"{x:1359,y:764,t:1527030633002};\\\", \\\"{x:1359,y:762,t:1527030633020};\\\", \\\"{x:1360,y:760,t:1527030633035};\\\", \\\"{x:1360,y:759,t:1527030633053};\\\", \\\"{x:1360,y:758,t:1527030633081};\\\", \\\"{x:1360,y:757,t:1527030633162};\\\", \\\"{x:1361,y:756,t:1527030633169};\\\", \\\"{x:1366,y:750,t:1527030633185};\\\", \\\"{x:1377,y:739,t:1527030633203};\\\", \\\"{x:1390,y:725,t:1527030633219};\\\", \\\"{x:1404,y:711,t:1527030633235};\\\", \\\"{x:1417,y:698,t:1527030633252};\\\", \\\"{x:1428,y:683,t:1527030633269};\\\", \\\"{x:1440,y:670,t:1527030633286};\\\", \\\"{x:1449,y:659,t:1527030633302};\\\", \\\"{x:1456,y:648,t:1527030633320};\\\", \\\"{x:1463,y:639,t:1527030633336};\\\", \\\"{x:1466,y:632,t:1527030633352};\\\", \\\"{x:1469,y:621,t:1527030633370};\\\", \\\"{x:1469,y:614,t:1527030633386};\\\", \\\"{x:1469,y:606,t:1527030633403};\\\", \\\"{x:1470,y:598,t:1527030633420};\\\", \\\"{x:1471,y:593,t:1527030633436};\\\", \\\"{x:1471,y:589,t:1527030633452};\\\", \\\"{x:1471,y:585,t:1527030633469};\\\", \\\"{x:1471,y:583,t:1527030633486};\\\", \\\"{x:1471,y:582,t:1527030633502};\\\", \\\"{x:1470,y:579,t:1527030633520};\\\", \\\"{x:1468,y:575,t:1527030633536};\\\", \\\"{x:1465,y:568,t:1527030633553};\\\", \\\"{x:1459,y:558,t:1527030633569};\\\", \\\"{x:1453,y:551,t:1527030633586};\\\", \\\"{x:1450,y:547,t:1527030633603};\\\", \\\"{x:1447,y:543,t:1527030633619};\\\", \\\"{x:1445,y:539,t:1527030633636};\\\", \\\"{x:1444,y:537,t:1527030633652};\\\", \\\"{x:1443,y:535,t:1527030633670};\\\", \\\"{x:1441,y:532,t:1527030633686};\\\", \\\"{x:1440,y:530,t:1527030633702};\\\", \\\"{x:1440,y:529,t:1527030633720};\\\", \\\"{x:1439,y:528,t:1527030633736};\\\", \\\"{x:1438,y:527,t:1527030633833};\\\", \\\"{x:1438,y:526,t:1527030633849};\\\", \\\"{x:1438,y:524,t:1527030633857};\\\", \\\"{x:1438,y:521,t:1527030633869};\\\", \\\"{x:1440,y:516,t:1527030633886};\\\", \\\"{x:1443,y:511,t:1527030633903};\\\", \\\"{x:1445,y:508,t:1527030633919};\\\", \\\"{x:1445,y:507,t:1527030633936};\\\", \\\"{x:1446,y:501,t:1527030633953};\\\", \\\"{x:1446,y:496,t:1527030633970};\\\", \\\"{x:1446,y:493,t:1527030633987};\\\", \\\"{x:1446,y:490,t:1527030634004};\\\", \\\"{x:1446,y:489,t:1527030634019};\\\", \\\"{x:1447,y:488,t:1527030634114};\\\", \\\"{x:1449,y:488,t:1527030634121};\\\", \\\"{x:1452,y:488,t:1527030634136};\\\", \\\"{x:1461,y:491,t:1527030634153};\\\", \\\"{x:1464,y:492,t:1527030634170};\\\", \\\"{x:1468,y:494,t:1527030634186};\\\", \\\"{x:1472,y:496,t:1527030634203};\\\", \\\"{x:1475,y:497,t:1527030634220};\\\", \\\"{x:1479,y:499,t:1527030634236};\\\", \\\"{x:1480,y:499,t:1527030634253};\\\", \\\"{x:1482,y:500,t:1527030634269};\\\", \\\"{x:1482,y:503,t:1527030634906};\\\", \\\"{x:1476,y:511,t:1527030634920};\\\", \\\"{x:1465,y:526,t:1527030634936};\\\", \\\"{x:1454,y:549,t:1527030634953};\\\", \\\"{x:1448,y:566,t:1527030634970};\\\", \\\"{x:1439,y:582,t:1527030634986};\\\", \\\"{x:1432,y:597,t:1527030635003};\\\", \\\"{x:1425,y:611,t:1527030635020};\\\", \\\"{x:1419,y:626,t:1527030635036};\\\", \\\"{x:1416,y:638,t:1527030635053};\\\", \\\"{x:1412,y:646,t:1527030635070};\\\", \\\"{x:1408,y:654,t:1527030635086};\\\", \\\"{x:1404,y:664,t:1527030635103};\\\", \\\"{x:1400,y:673,t:1527030635120};\\\", \\\"{x:1399,y:677,t:1527030635136};\\\", \\\"{x:1397,y:685,t:1527030635153};\\\", \\\"{x:1396,y:688,t:1527030635170};\\\", \\\"{x:1395,y:692,t:1527030635187};\\\", \\\"{x:1395,y:698,t:1527030635203};\\\", \\\"{x:1393,y:703,t:1527030635220};\\\", \\\"{x:1392,y:708,t:1527030635237};\\\", \\\"{x:1392,y:710,t:1527030635253};\\\", \\\"{x:1391,y:714,t:1527030635270};\\\", \\\"{x:1389,y:717,t:1527030635288};\\\", \\\"{x:1389,y:719,t:1527030635304};\\\", \\\"{x:1388,y:722,t:1527030635320};\\\", \\\"{x:1387,y:725,t:1527030635337};\\\", \\\"{x:1386,y:726,t:1527030635354};\\\", \\\"{x:1385,y:727,t:1527030635371};\\\", \\\"{x:1384,y:729,t:1527030635387};\\\", \\\"{x:1381,y:731,t:1527030635404};\\\", \\\"{x:1377,y:734,t:1527030635420};\\\", \\\"{x:1375,y:736,t:1527030635438};\\\", \\\"{x:1370,y:740,t:1527030635454};\\\", \\\"{x:1364,y:743,t:1527030635470};\\\", \\\"{x:1362,y:744,t:1527030635488};\\\", \\\"{x:1360,y:746,t:1527030635503};\\\", \\\"{x:1359,y:746,t:1527030635520};\\\", \\\"{x:1356,y:749,t:1527030635537};\\\", \\\"{x:1354,y:751,t:1527030635554};\\\", \\\"{x:1353,y:752,t:1527030635571};\\\", \\\"{x:1352,y:752,t:1527030635842};\\\", \\\"{x:1350,y:752,t:1527030635854};\\\", \\\"{x:1348,y:752,t:1527030635870};\\\", \\\"{x:1345,y:749,t:1527030635888};\\\", \\\"{x:1344,y:741,t:1527030635906};\\\", \\\"{x:1344,y:734,t:1527030635921};\\\", \\\"{x:1349,y:721,t:1527030635938};\\\", \\\"{x:1354,y:711,t:1527030635955};\\\", \\\"{x:1362,y:698,t:1527030635970};\\\", \\\"{x:1371,y:681,t:1527030635987};\\\", \\\"{x:1382,y:665,t:1527030636003};\\\", \\\"{x:1396,y:647,t:1527030636020};\\\", \\\"{x:1407,y:631,t:1527030636036};\\\", \\\"{x:1416,y:619,t:1527030636054};\\\", \\\"{x:1419,y:615,t:1527030636070};\\\", \\\"{x:1420,y:613,t:1527030636087};\\\", \\\"{x:1421,y:611,t:1527030636104};\\\", \\\"{x:1421,y:610,t:1527030636120};\\\", \\\"{x:1421,y:609,t:1527030636137};\\\", \\\"{x:1421,y:605,t:1527030636154};\\\", \\\"{x:1422,y:601,t:1527030636170};\\\", \\\"{x:1422,y:598,t:1527030636187};\\\", \\\"{x:1423,y:595,t:1527030636204};\\\", \\\"{x:1424,y:591,t:1527030636221};\\\", \\\"{x:1424,y:586,t:1527030636237};\\\", \\\"{x:1424,y:583,t:1527030636255};\\\", \\\"{x:1424,y:580,t:1527030636271};\\\", \\\"{x:1423,y:578,t:1527030636287};\\\", \\\"{x:1422,y:578,t:1527030636409};\\\", \\\"{x:1417,y:580,t:1527030636421};\\\", \\\"{x:1408,y:592,t:1527030636438};\\\", \\\"{x:1398,y:607,t:1527030636454};\\\", \\\"{x:1388,y:620,t:1527030636471};\\\", \\\"{x:1380,y:631,t:1527030636487};\\\", \\\"{x:1374,y:639,t:1527030636504};\\\", \\\"{x:1370,y:648,t:1527030636520};\\\", \\\"{x:1367,y:652,t:1527030636537};\\\", \\\"{x:1365,y:659,t:1527030636554};\\\", \\\"{x:1362,y:664,t:1527030636572};\\\", \\\"{x:1359,y:669,t:1527030636587};\\\", \\\"{x:1358,y:670,t:1527030636604};\\\", \\\"{x:1358,y:672,t:1527030636622};\\\", \\\"{x:1356,y:673,t:1527030636637};\\\", \\\"{x:1354,y:675,t:1527030636654};\\\", \\\"{x:1352,y:677,t:1527030636671};\\\", \\\"{x:1350,y:677,t:1527030636687};\\\", \\\"{x:1341,y:678,t:1527030636705};\\\", \\\"{x:1318,y:676,t:1527030636721};\\\", \\\"{x:1302,y:668,t:1527030636737};\\\", \\\"{x:1288,y:657,t:1527030636754};\\\", \\\"{x:1271,y:643,t:1527030636771};\\\", \\\"{x:1263,y:629,t:1527030636787};\\\", \\\"{x:1259,y:623,t:1527030636804};\\\", \\\"{x:1259,y:622,t:1527030636821};\\\", \\\"{x:1259,y:620,t:1527030636837};\\\", \\\"{x:1259,y:614,t:1527030636854};\\\", \\\"{x:1263,y:604,t:1527030636871};\\\", \\\"{x:1273,y:592,t:1527030636887};\\\", \\\"{x:1278,y:587,t:1527030636904};\\\", \\\"{x:1285,y:577,t:1527030636922};\\\", \\\"{x:1288,y:574,t:1527030636937};\\\", \\\"{x:1290,y:573,t:1527030636954};\\\", \\\"{x:1292,y:571,t:1527030636971};\\\", \\\"{x:1292,y:570,t:1527030636988};\\\", \\\"{x:1292,y:568,t:1527030637004};\\\", \\\"{x:1292,y:567,t:1527030637021};\\\", \\\"{x:1293,y:565,t:1527030637038};\\\", \\\"{x:1293,y:564,t:1527030637055};\\\", \\\"{x:1293,y:562,t:1527030637072};\\\", \\\"{x:1293,y:560,t:1527030637087};\\\", \\\"{x:1292,y:560,t:1527030637361};\\\", \\\"{x:1291,y:560,t:1527030637385};\\\", \\\"{x:1289,y:560,t:1527030637450};\\\", \\\"{x:1287,y:563,t:1527030637460};\\\", \\\"{x:1283,y:568,t:1527030637471};\\\", \\\"{x:1276,y:582,t:1527030637488};\\\", \\\"{x:1268,y:593,t:1527030637504};\\\", \\\"{x:1259,y:606,t:1527030637521};\\\", \\\"{x:1256,y:613,t:1527030637538};\\\", \\\"{x:1253,y:618,t:1527030637553};\\\", \\\"{x:1250,y:624,t:1527030637571};\\\", \\\"{x:1245,y:635,t:1527030637588};\\\", \\\"{x:1240,y:646,t:1527030637604};\\\", \\\"{x:1233,y:655,t:1527030637621};\\\", \\\"{x:1226,y:664,t:1527030637638};\\\", \\\"{x:1220,y:672,t:1527030637654};\\\", \\\"{x:1215,y:677,t:1527030637672};\\\", \\\"{x:1211,y:681,t:1527030637689};\\\", \\\"{x:1208,y:688,t:1527030637705};\\\", \\\"{x:1203,y:707,t:1527030637721};\\\", \\\"{x:1199,y:723,t:1527030637738};\\\", \\\"{x:1193,y:735,t:1527030637755};\\\", \\\"{x:1187,y:749,t:1527030637771};\\\", \\\"{x:1183,y:762,t:1527030637789};\\\", \\\"{x:1180,y:771,t:1527030637805};\\\", \\\"{x:1180,y:776,t:1527030637822};\\\", \\\"{x:1179,y:780,t:1527030637839};\\\", \\\"{x:1179,y:781,t:1527030637855};\\\", \\\"{x:1179,y:782,t:1527030637872};\\\", \\\"{x:1179,y:783,t:1527030637888};\\\", \\\"{x:1179,y:786,t:1527030637905};\\\", \\\"{x:1179,y:787,t:1527030637921};\\\", \\\"{x:1179,y:789,t:1527030637945};\\\", \\\"{x:1179,y:790,t:1527030637955};\\\", \\\"{x:1179,y:791,t:1527030637972};\\\", \\\"{x:1180,y:792,t:1527030637989};\\\", \\\"{x:1183,y:796,t:1527030638005};\\\", \\\"{x:1185,y:797,t:1527030638021};\\\", \\\"{x:1188,y:801,t:1527030638039};\\\", \\\"{x:1192,y:806,t:1527030638055};\\\", \\\"{x:1198,y:810,t:1527030638071};\\\", \\\"{x:1204,y:815,t:1527030638088};\\\", \\\"{x:1211,y:821,t:1527030638105};\\\", \\\"{x:1212,y:822,t:1527030638121};\\\", \\\"{x:1215,y:824,t:1527030638139};\\\", \\\"{x:1218,y:825,t:1527030638155};\\\", \\\"{x:1219,y:827,t:1527030638171};\\\", \\\"{x:1221,y:829,t:1527030638189};\\\", \\\"{x:1224,y:832,t:1527030638205};\\\", \\\"{x:1226,y:836,t:1527030638221};\\\", \\\"{x:1226,y:838,t:1527030638239};\\\", \\\"{x:1228,y:841,t:1527030638255};\\\", \\\"{x:1229,y:843,t:1527030638297};\\\", \\\"{x:1231,y:844,t:1527030638426};\\\", \\\"{x:1233,y:844,t:1527030638439};\\\", \\\"{x:1239,y:843,t:1527030638456};\\\", \\\"{x:1247,y:839,t:1527030638472};\\\", \\\"{x:1253,y:836,t:1527030638489};\\\", \\\"{x:1257,y:834,t:1527030638505};\\\", \\\"{x:1258,y:833,t:1527030638658};\\\", \\\"{x:1258,y:832,t:1527030638672};\\\", \\\"{x:1260,y:827,t:1527030638688};\\\", \\\"{x:1264,y:820,t:1527030638705};\\\", \\\"{x:1265,y:818,t:1527030638721};\\\", \\\"{x:1267,y:816,t:1527030638738};\\\", \\\"{x:1268,y:816,t:1527030638760};\\\", \\\"{x:1268,y:815,t:1527030638776};\\\", \\\"{x:1270,y:814,t:1527030638788};\\\", \\\"{x:1278,y:810,t:1527030638805};\\\", \\\"{x:1282,y:808,t:1527030638822};\\\", \\\"{x:1283,y:807,t:1527030638838};\\\", \\\"{x:1284,y:806,t:1527030638855};\\\", \\\"{x:1285,y:806,t:1527030638873};\\\", \\\"{x:1286,y:806,t:1527030638889};\\\", \\\"{x:1291,y:803,t:1527030638905};\\\", \\\"{x:1298,y:796,t:1527030638922};\\\", \\\"{x:1309,y:780,t:1527030638938};\\\", \\\"{x:1318,y:764,t:1527030638956};\\\", \\\"{x:1325,y:752,t:1527030638972};\\\", \\\"{x:1329,y:743,t:1527030638989};\\\", \\\"{x:1333,y:738,t:1527030639005};\\\", \\\"{x:1337,y:730,t:1527030639022};\\\", \\\"{x:1341,y:721,t:1527030639038};\\\", \\\"{x:1341,y:714,t:1527030639055};\\\", \\\"{x:1345,y:705,t:1527030639072};\\\", \\\"{x:1351,y:692,t:1527030639088};\\\", \\\"{x:1355,y:682,t:1527030639105};\\\", \\\"{x:1361,y:667,t:1527030639122};\\\", \\\"{x:1366,y:655,t:1527030639139};\\\", \\\"{x:1371,y:640,t:1527030639155};\\\", \\\"{x:1376,y:625,t:1527030639172};\\\", \\\"{x:1380,y:613,t:1527030639189};\\\", \\\"{x:1383,y:603,t:1527030639205};\\\", \\\"{x:1386,y:595,t:1527030639222};\\\", \\\"{x:1387,y:588,t:1527030639239};\\\", \\\"{x:1398,y:581,t:1527030639255};\\\", \\\"{x:1408,y:573,t:1527030639272};\\\", \\\"{x:1416,y:568,t:1527030639289};\\\", \\\"{x:1420,y:566,t:1527030639306};\\\", \\\"{x:1422,y:566,t:1527030639530};\\\", \\\"{x:1425,y:571,t:1527030639539};\\\", \\\"{x:1427,y:574,t:1527030639555};\\\", \\\"{x:1428,y:576,t:1527030639572};\\\", \\\"{x:1429,y:578,t:1527030639589};\\\", \\\"{x:1430,y:579,t:1527030639605};\\\", \\\"{x:1431,y:580,t:1527030639625};\\\", \\\"{x:1430,y:581,t:1527030639826};\\\", \\\"{x:1426,y:584,t:1527030639840};\\\", \\\"{x:1420,y:590,t:1527030639857};\\\", \\\"{x:1415,y:597,t:1527030639872};\\\", \\\"{x:1408,y:607,t:1527030639889};\\\", \\\"{x:1401,y:616,t:1527030639907};\\\", \\\"{x:1397,y:620,t:1527030639923};\\\", \\\"{x:1393,y:624,t:1527030639940};\\\", \\\"{x:1391,y:626,t:1527030639956};\\\", \\\"{x:1389,y:628,t:1527030639972};\\\", \\\"{x:1388,y:628,t:1527030639989};\\\", \\\"{x:1386,y:630,t:1527030640007};\\\", \\\"{x:1382,y:632,t:1527030640023};\\\", \\\"{x:1381,y:634,t:1527030640040};\\\", \\\"{x:1379,y:636,t:1527030640056};\\\", \\\"{x:1377,y:637,t:1527030640073};\\\", \\\"{x:1374,y:640,t:1527030640089};\\\", \\\"{x:1374,y:641,t:1527030640265};\\\", \\\"{x:1373,y:642,t:1527030640272};\\\", \\\"{x:1369,y:646,t:1527030640289};\\\", \\\"{x:1366,y:652,t:1527030640307};\\\", \\\"{x:1363,y:661,t:1527030640322};\\\", \\\"{x:1362,y:664,t:1527030640339};\\\", \\\"{x:1362,y:670,t:1527030640357};\\\", \\\"{x:1359,y:675,t:1527030640373};\\\", \\\"{x:1358,y:680,t:1527030640390};\\\", \\\"{x:1357,y:685,t:1527030640407};\\\", \\\"{x:1354,y:691,t:1527030640423};\\\", \\\"{x:1350,y:698,t:1527030640439};\\\", \\\"{x:1348,y:703,t:1527030640457};\\\", \\\"{x:1345,y:709,t:1527030640473};\\\", \\\"{x:1343,y:712,t:1527030640489};\\\", \\\"{x:1342,y:714,t:1527030640507};\\\", \\\"{x:1342,y:716,t:1527030640524};\\\", \\\"{x:1342,y:717,t:1527030640540};\\\", \\\"{x:1341,y:717,t:1527030640557};\\\", \\\"{x:1339,y:720,t:1527030640573};\\\", \\\"{x:1339,y:723,t:1527030640589};\\\", \\\"{x:1339,y:725,t:1527030640607};\\\", \\\"{x:1339,y:728,t:1527030640624};\\\", \\\"{x:1339,y:732,t:1527030640639};\\\", \\\"{x:1339,y:735,t:1527030640657};\\\", \\\"{x:1339,y:741,t:1527030640674};\\\", \\\"{x:1339,y:744,t:1527030640690};\\\", \\\"{x:1339,y:748,t:1527030640706};\\\", \\\"{x:1339,y:750,t:1527030640724};\\\", \\\"{x:1340,y:756,t:1527030640740};\\\", \\\"{x:1340,y:758,t:1527030640757};\\\", \\\"{x:1340,y:761,t:1527030640773};\\\", \\\"{x:1341,y:762,t:1527030640789};\\\", \\\"{x:1341,y:764,t:1527030640806};\\\", \\\"{x:1341,y:765,t:1527030640826};\\\", \\\"{x:1341,y:766,t:1527030641089};\\\", \\\"{x:1341,y:767,t:1527030641657};\\\", \\\"{x:1337,y:774,t:1527030642666};\\\", \\\"{x:1329,y:784,t:1527030642675};\\\", \\\"{x:1318,y:797,t:1527030642691};\\\", \\\"{x:1311,y:815,t:1527030642707};\\\", \\\"{x:1299,y:834,t:1527030642724};\\\", \\\"{x:1289,y:849,t:1527030642741};\\\", \\\"{x:1283,y:861,t:1527030642758};\\\", \\\"{x:1278,y:872,t:1527030642774};\\\", \\\"{x:1276,y:878,t:1527030642791};\\\", \\\"{x:1276,y:882,t:1527030642807};\\\", \\\"{x:1276,y:884,t:1527030642833};\\\", \\\"{x:1276,y:885,t:1527030642841};\\\", \\\"{x:1276,y:886,t:1527030642881};\\\", \\\"{x:1277,y:886,t:1527030642897};\\\", \\\"{x:1278,y:887,t:1527030642913};\\\", \\\"{x:1278,y:888,t:1527030642925};\\\", \\\"{x:1279,y:891,t:1527030642941};\\\", \\\"{x:1279,y:893,t:1527030642957};\\\", \\\"{x:1279,y:898,t:1527030642975};\\\", \\\"{x:1278,y:903,t:1527030642992};\\\", \\\"{x:1275,y:909,t:1527030643008};\\\", \\\"{x:1269,y:918,t:1527030643025};\\\", \\\"{x:1265,y:922,t:1527030643041};\\\", \\\"{x:1260,y:927,t:1527030643058};\\\", \\\"{x:1256,y:932,t:1527030643074};\\\", \\\"{x:1253,y:937,t:1527030643092};\\\", \\\"{x:1250,y:940,t:1527030643107};\\\", \\\"{x:1248,y:942,t:1527030643125};\\\", \\\"{x:1247,y:943,t:1527030643142};\\\", \\\"{x:1246,y:943,t:1527030643157};\\\", \\\"{x:1246,y:944,t:1527030643233};\\\", \\\"{x:1246,y:945,t:1527030643241};\\\", \\\"{x:1246,y:946,t:1527030643258};\\\", \\\"{x:1246,y:948,t:1527030643275};\\\", \\\"{x:1246,y:950,t:1527030643292};\\\", \\\"{x:1246,y:951,t:1527030643307};\\\", \\\"{x:1246,y:954,t:1527030643325};\\\", \\\"{x:1246,y:957,t:1527030643342};\\\", \\\"{x:1244,y:960,t:1527030643357};\\\", \\\"{x:1244,y:964,t:1527030643375};\\\", \\\"{x:1244,y:965,t:1527030643394};\\\", \\\"{x:1244,y:966,t:1527030643408};\\\", \\\"{x:1243,y:967,t:1527030643425};\\\", \\\"{x:1244,y:966,t:1527030643529};\\\", \\\"{x:1244,y:964,t:1527030643542};\\\", \\\"{x:1245,y:960,t:1527030643559};\\\", \\\"{x:1247,y:954,t:1527030643575};\\\", \\\"{x:1250,y:948,t:1527030643591};\\\", \\\"{x:1258,y:936,t:1527030643609};\\\", \\\"{x:1266,y:926,t:1527030643625};\\\", \\\"{x:1274,y:913,t:1527030643642};\\\", \\\"{x:1288,y:902,t:1527030643659};\\\", \\\"{x:1303,y:890,t:1527030643675};\\\", \\\"{x:1317,y:878,t:1527030643691};\\\", \\\"{x:1328,y:869,t:1527030643709};\\\", \\\"{x:1339,y:858,t:1527030643725};\\\", \\\"{x:1347,y:847,t:1527030643741};\\\", \\\"{x:1354,y:837,t:1527030643759};\\\", \\\"{x:1361,y:827,t:1527030643775};\\\", \\\"{x:1365,y:821,t:1527030643792};\\\", \\\"{x:1368,y:813,t:1527030643809};\\\", \\\"{x:1369,y:810,t:1527030643825};\\\", \\\"{x:1371,y:806,t:1527030643842};\\\", \\\"{x:1374,y:801,t:1527030643858};\\\", \\\"{x:1377,y:795,t:1527030643875};\\\", \\\"{x:1379,y:788,t:1527030643892};\\\", \\\"{x:1381,y:787,t:1527030643908};\\\", \\\"{x:1381,y:785,t:1527030643945};\\\", \\\"{x:1381,y:784,t:1527030644081};\\\", \\\"{x:1381,y:783,t:1527030644105};\\\", \\\"{x:1380,y:782,t:1527030644113};\\\", \\\"{x:1377,y:781,t:1527030644129};\\\", \\\"{x:1376,y:780,t:1527030644142};\\\", \\\"{x:1374,y:780,t:1527030644159};\\\", \\\"{x:1373,y:779,t:1527030644176};\\\", \\\"{x:1372,y:778,t:1527030644192};\\\", \\\"{x:1371,y:778,t:1527030644233};\\\", \\\"{x:1369,y:777,t:1527030644257};\\\", \\\"{x:1369,y:776,t:1527030644265};\\\", \\\"{x:1368,y:775,t:1527030644276};\\\", \\\"{x:1366,y:773,t:1527030644292};\\\", \\\"{x:1365,y:771,t:1527030644309};\\\", \\\"{x:1364,y:769,t:1527030644325};\\\", \\\"{x:1362,y:767,t:1527030644342};\\\", \\\"{x:1361,y:765,t:1527030644358};\\\", \\\"{x:1360,y:764,t:1527030644375};\\\", \\\"{x:1358,y:762,t:1527030644392};\\\", \\\"{x:1356,y:762,t:1527030644417};\\\", \\\"{x:1355,y:762,t:1527030646776};\\\", \\\"{x:1347,y:763,t:1527030646793};\\\", \\\"{x:1339,y:767,t:1527030646809};\\\", \\\"{x:1334,y:770,t:1527030646826};\\\", \\\"{x:1333,y:773,t:1527030646843};\\\", \\\"{x:1332,y:774,t:1527030646864};\\\", \\\"{x:1332,y:775,t:1527030647082};\\\", \\\"{x:1333,y:775,t:1527030647094};\\\", \\\"{x:1334,y:774,t:1527030647110};\\\", \\\"{x:1336,y:773,t:1527030647127};\\\", \\\"{x:1337,y:772,t:1527030647144};\\\", \\\"{x:1337,y:770,t:1527030647177};\\\", \\\"{x:1337,y:769,t:1527030647201};\\\", \\\"{x:1337,y:768,t:1527030647241};\\\", \\\"{x:1338,y:768,t:1527030647273};\\\", \\\"{x:1340,y:765,t:1527030650282};\\\", \\\"{x:1342,y:763,t:1527030650296};\\\", \\\"{x:1347,y:758,t:1527030650312};\\\", \\\"{x:1352,y:753,t:1527030650330};\\\", \\\"{x:1352,y:757,t:1527030652154};\\\", \\\"{x:1352,y:761,t:1527030652163};\\\", \\\"{x:1353,y:772,t:1527030652181};\\\", \\\"{x:1353,y:783,t:1527030652196};\\\", \\\"{x:1353,y:792,t:1527030652213};\\\", \\\"{x:1353,y:797,t:1527030652230};\\\", \\\"{x:1353,y:799,t:1527030652246};\\\", \\\"{x:1354,y:800,t:1527030652361};\\\", \\\"{x:1356,y:797,t:1527030652377};\\\", \\\"{x:1360,y:791,t:1527030652385};\\\", \\\"{x:1365,y:781,t:1527030652397};\\\", \\\"{x:1372,y:763,t:1527030652413};\\\", \\\"{x:1378,y:744,t:1527030652431};\\\", \\\"{x:1382,y:724,t:1527030652447};\\\", \\\"{x:1383,y:711,t:1527030652463};\\\", \\\"{x:1384,y:706,t:1527030652480};\\\", \\\"{x:1384,y:700,t:1527030652497};\\\", \\\"{x:1384,y:693,t:1527030652513};\\\", \\\"{x:1384,y:685,t:1527030652530};\\\", \\\"{x:1386,y:670,t:1527030652547};\\\", \\\"{x:1388,y:652,t:1527030652563};\\\", \\\"{x:1388,y:635,t:1527030652580};\\\", \\\"{x:1388,y:622,t:1527030652597};\\\", \\\"{x:1388,y:608,t:1527030652613};\\\", \\\"{x:1392,y:590,t:1527030652630};\\\", \\\"{x:1394,y:580,t:1527030652646};\\\", \\\"{x:1398,y:571,t:1527030652664};\\\", \\\"{x:1400,y:564,t:1527030652681};\\\", \\\"{x:1402,y:559,t:1527030652697};\\\", \\\"{x:1403,y:558,t:1527030652713};\\\", \\\"{x:1403,y:560,t:1527030652905};\\\", \\\"{x:1400,y:565,t:1527030652913};\\\", \\\"{x:1398,y:574,t:1527030652930};\\\", \\\"{x:1396,y:584,t:1527030652947};\\\", \\\"{x:1394,y:596,t:1527030652963};\\\", \\\"{x:1390,y:606,t:1527030652980};\\\", \\\"{x:1388,y:615,t:1527030652997};\\\", \\\"{x:1384,y:626,t:1527030653014};\\\", \\\"{x:1380,y:633,t:1527030653030};\\\", \\\"{x:1376,y:638,t:1527030653047};\\\", \\\"{x:1373,y:643,t:1527030653064};\\\", \\\"{x:1371,y:646,t:1527030653080};\\\", \\\"{x:1363,y:656,t:1527030653097};\\\", \\\"{x:1353,y:664,t:1527030653114};\\\", \\\"{x:1343,y:673,t:1527030653130};\\\", \\\"{x:1333,y:682,t:1527030653147};\\\", \\\"{x:1325,y:687,t:1527030653166};\\\", \\\"{x:1317,y:693,t:1527030653180};\\\", \\\"{x:1306,y:701,t:1527030653198};\\\", \\\"{x:1298,y:705,t:1527030653215};\\\", \\\"{x:1288,y:711,t:1527030653230};\\\", \\\"{x:1284,y:713,t:1527030653247};\\\", \\\"{x:1278,y:717,t:1527030653264};\\\", \\\"{x:1275,y:718,t:1527030653281};\\\", \\\"{x:1273,y:719,t:1527030653297};\\\", \\\"{x:1272,y:720,t:1527030653345};\\\", \\\"{x:1271,y:720,t:1527030653465};\\\", \\\"{x:1270,y:720,t:1527030653480};\\\", \\\"{x:1269,y:720,t:1527030653537};\\\", \\\"{x:1268,y:720,t:1527030654144};\\\", \\\"{x:1267,y:720,t:1527030654192};\\\", \\\"{x:1266,y:721,t:1527030654208};\\\", \\\"{x:1265,y:722,t:1527030654248};\\\", \\\"{x:1264,y:722,t:1527030654385};\\\", \\\"{x:1267,y:722,t:1527030654513};\\\", \\\"{x:1305,y:722,t:1527030654531};\\\", \\\"{x:1331,y:720,t:1527030654548};\\\", \\\"{x:1353,y:716,t:1527030654565};\\\", \\\"{x:1368,y:716,t:1527030654581};\\\", \\\"{x:1374,y:716,t:1527030654598};\\\", \\\"{x:1377,y:716,t:1527030654614};\\\", \\\"{x:1378,y:716,t:1527030655009};\\\", \\\"{x:1376,y:715,t:1527030655065};\\\", \\\"{x:1368,y:709,t:1527030655081};\\\", \\\"{x:1358,y:700,t:1527030655098};\\\", \\\"{x:1353,y:696,t:1527030655116};\\\", \\\"{x:1352,y:696,t:1527030655131};\\\", \\\"{x:1353,y:697,t:1527030655281};\\\", \\\"{x:1354,y:697,t:1527030656562};\\\", \\\"{x:1354,y:698,t:1527030656569};\\\", \\\"{x:1355,y:700,t:1527030656582};\\\", \\\"{x:1355,y:705,t:1527030656598};\\\", \\\"{x:1358,y:713,t:1527030656614};\\\", \\\"{x:1361,y:721,t:1527030656632};\\\", \\\"{x:1369,y:731,t:1527030656648};\\\", \\\"{x:1377,y:737,t:1527030656665};\\\", \\\"{x:1391,y:747,t:1527030656681};\\\", \\\"{x:1409,y:755,t:1527030656698};\\\", \\\"{x:1426,y:765,t:1527030656714};\\\", \\\"{x:1444,y:775,t:1527030656731};\\\", \\\"{x:1463,y:784,t:1527030656749};\\\", \\\"{x:1482,y:792,t:1527030656766};\\\", \\\"{x:1498,y:798,t:1527030656782};\\\", \\\"{x:1508,y:802,t:1527030656799};\\\", \\\"{x:1515,y:804,t:1527030656815};\\\", \\\"{x:1517,y:806,t:1527030656832};\\\", \\\"{x:1518,y:806,t:1527030656849};\\\", \\\"{x:1519,y:808,t:1527030656881};\\\", \\\"{x:1523,y:817,t:1527030656900};\\\", \\\"{x:1527,y:826,t:1527030656916};\\\", \\\"{x:1529,y:831,t:1527030656932};\\\", \\\"{x:1534,y:839,t:1527030656950};\\\", \\\"{x:1536,y:843,t:1527030656966};\\\", \\\"{x:1537,y:851,t:1527030656982};\\\", \\\"{x:1537,y:856,t:1527030656999};\\\", \\\"{x:1539,y:860,t:1527030657015};\\\", \\\"{x:1540,y:862,t:1527030657032};\\\", \\\"{x:1542,y:866,t:1527030657049};\\\", \\\"{x:1543,y:866,t:1527030657169};\\\", \\\"{x:1543,y:862,t:1527030657182};\\\", \\\"{x:1543,y:850,t:1527030657198};\\\", \\\"{x:1540,y:822,t:1527030657216};\\\", \\\"{x:1539,y:813,t:1527030657232};\\\", \\\"{x:1534,y:789,t:1527030657249};\\\", \\\"{x:1529,y:771,t:1527030657266};\\\", \\\"{x:1515,y:752,t:1527030657281};\\\", \\\"{x:1502,y:732,t:1527030657299};\\\", \\\"{x:1487,y:712,t:1527030657316};\\\", \\\"{x:1470,y:690,t:1527030657331};\\\", \\\"{x:1456,y:672,t:1527030657348};\\\", \\\"{x:1445,y:659,t:1527030657366};\\\", \\\"{x:1439,y:653,t:1527030657381};\\\", \\\"{x:1438,y:653,t:1527030657465};\\\", \\\"{x:1446,y:676,t:1527030657483};\\\", \\\"{x:1456,y:702,t:1527030657499};\\\", \\\"{x:1468,y:731,t:1527030657515};\\\", \\\"{x:1482,y:756,t:1527030657533};\\\", \\\"{x:1492,y:775,t:1527030657549};\\\", \\\"{x:1503,y:788,t:1527030657566};\\\", \\\"{x:1509,y:798,t:1527030657583};\\\", \\\"{x:1513,y:804,t:1527030657599};\\\", \\\"{x:1518,y:811,t:1527030657616};\\\", \\\"{x:1520,y:814,t:1527030657633};\\\", \\\"{x:1520,y:815,t:1527030658217};\\\", \\\"{x:1519,y:815,t:1527030660168};\\\", \\\"{x:1518,y:815,t:1527030666053};\\\", \\\"{x:1517,y:814,t:1527030666205};\\\", \\\"{x:1516,y:814,t:1527030666212};\\\", \\\"{x:1514,y:813,t:1527030666224};\\\", \\\"{x:1513,y:811,t:1527030666245};\\\", \\\"{x:1511,y:809,t:1527030666260};\\\", \\\"{x:1511,y:808,t:1527030666276};\\\", \\\"{x:1510,y:807,t:1527030666292};\\\", \\\"{x:1506,y:797,t:1527030666308};\\\", \\\"{x:1505,y:794,t:1527030666325};\\\", \\\"{x:1505,y:792,t:1527030666341};\\\", \\\"{x:1504,y:791,t:1527030666359};\\\", \\\"{x:1504,y:790,t:1527030666375};\\\", \\\"{x:1503,y:789,t:1527030666391};\\\", \\\"{x:1502,y:787,t:1527030666412};\\\", \\\"{x:1502,y:786,t:1527030666425};\\\", \\\"{x:1502,y:784,t:1527030666442};\\\", \\\"{x:1500,y:782,t:1527030666458};\\\", \\\"{x:1500,y:780,t:1527030666476};\\\", \\\"{x:1500,y:779,t:1527030666492};\\\", \\\"{x:1500,y:777,t:1527030666508};\\\", \\\"{x:1499,y:776,t:1527030667172};\\\", \\\"{x:1497,y:776,t:1527030667181};\\\", \\\"{x:1496,y:777,t:1527030667193};\\\", \\\"{x:1495,y:778,t:1527030667208};\\\", \\\"{x:1494,y:779,t:1527030667226};\\\", \\\"{x:1494,y:780,t:1527030667243};\\\", \\\"{x:1494,y:782,t:1527030667260};\\\", \\\"{x:1493,y:782,t:1527030667275};\\\", \\\"{x:1492,y:779,t:1527030667677};\\\", \\\"{x:1489,y:772,t:1527030667692};\\\", \\\"{x:1488,y:763,t:1527030667709};\\\", \\\"{x:1485,y:751,t:1527030667726};\\\", \\\"{x:1482,y:738,t:1527030667742};\\\", \\\"{x:1478,y:727,t:1527030667759};\\\", \\\"{x:1474,y:713,t:1527030667776};\\\", \\\"{x:1472,y:705,t:1527030667792};\\\", \\\"{x:1471,y:696,t:1527030667809};\\\", \\\"{x:1471,y:685,t:1527030667826};\\\", \\\"{x:1471,y:675,t:1527030667842};\\\", \\\"{x:1471,y:662,t:1527030667859};\\\", \\\"{x:1473,y:641,t:1527030667875};\\\", \\\"{x:1478,y:609,t:1527030667893};\\\", \\\"{x:1478,y:591,t:1527030667909};\\\", \\\"{x:1477,y:587,t:1527030667926};\\\", \\\"{x:1476,y:587,t:1527030669373};\\\", \\\"{x:1474,y:586,t:1527030669381};\\\", \\\"{x:1472,y:584,t:1527030669393};\\\", \\\"{x:1468,y:582,t:1527030669409};\\\", \\\"{x:1466,y:581,t:1527030669426};\\\", \\\"{x:1465,y:580,t:1527030669444};\\\", \\\"{x:1459,y:575,t:1527030669460};\\\", \\\"{x:1445,y:563,t:1527030669476};\\\", \\\"{x:1435,y:554,t:1527030669493};\\\", \\\"{x:1417,y:543,t:1527030669510};\\\", \\\"{x:1385,y:531,t:1527030669527};\\\", \\\"{x:1351,y:525,t:1527030669544};\\\", \\\"{x:1320,y:525,t:1527030669559};\\\", \\\"{x:1293,y:525,t:1527030669577};\\\", \\\"{x:1261,y:521,t:1527030669593};\\\", \\\"{x:1211,y:505,t:1527030669609};\\\", \\\"{x:1155,y:489,t:1527030669626};\\\", \\\"{x:1099,y:481,t:1527030669644};\\\", \\\"{x:1012,y:480,t:1527030669660};\\\", \\\"{x:931,y:480,t:1527030669676};\\\", \\\"{x:825,y:487,t:1527030669695};\\\", \\\"{x:722,y:501,t:1527030669710};\\\", \\\"{x:601,y:513,t:1527030669726};\\\", \\\"{x:491,y:523,t:1527030669741};\\\", \\\"{x:397,y:523,t:1527030669757};\\\", \\\"{x:305,y:523,t:1527030669773};\\\", \\\"{x:238,y:523,t:1527030669790};\\\", \\\"{x:199,y:523,t:1527030669806};\\\", \\\"{x:180,y:523,t:1527030669823};\\\", \\\"{x:173,y:521,t:1527030669839};\\\", \\\"{x:174,y:519,t:1527030669868};\\\", \\\"{x:181,y:518,t:1527030669876};\\\", \\\"{x:187,y:515,t:1527030669891};\\\", \\\"{x:199,y:512,t:1527030669907};\\\", \\\"{x:209,y:510,t:1527030669923};\\\", \\\"{x:231,y:509,t:1527030669939};\\\", \\\"{x:284,y:509,t:1527030669957};\\\", \\\"{x:368,y:507,t:1527030669974};\\\", \\\"{x:384,y:506,t:1527030669990};\\\", \\\"{x:391,y:504,t:1527030670007};\\\", \\\"{x:393,y:504,t:1527030670024};\\\", \\\"{x:400,y:504,t:1527030670040};\\\", \\\"{x:405,y:506,t:1527030670057};\\\", \\\"{x:405,y:507,t:1527030670074};\\\", \\\"{x:405,y:513,t:1527030670091};\\\", \\\"{x:399,y:522,t:1527030670109};\\\", \\\"{x:382,y:546,t:1527030670124};\\\", \\\"{x:371,y:558,t:1527030670141};\\\", \\\"{x:365,y:567,t:1527030670157};\\\", \\\"{x:354,y:578,t:1527030670174};\\\", \\\"{x:339,y:594,t:1527030670190};\\\", \\\"{x:324,y:605,t:1527030670207};\\\", \\\"{x:303,y:615,t:1527030670224};\\\", \\\"{x:289,y:620,t:1527030670240};\\\", \\\"{x:267,y:621,t:1527030670257};\\\", \\\"{x:244,y:621,t:1527030670274};\\\", \\\"{x:220,y:615,t:1527030670291};\\\", \\\"{x:199,y:609,t:1527030670307};\\\", \\\"{x:182,y:605,t:1527030670324};\\\", \\\"{x:179,y:604,t:1527030670340};\\\", \\\"{x:178,y:603,t:1527030670405};\\\", \\\"{x:175,y:600,t:1527030670424};\\\", \\\"{x:172,y:596,t:1527030670441};\\\", \\\"{x:168,y:588,t:1527030670458};\\\", \\\"{x:167,y:584,t:1527030670474};\\\", \\\"{x:167,y:581,t:1527030670491};\\\", \\\"{x:167,y:579,t:1527030670507};\\\", \\\"{x:167,y:578,t:1527030670524};\\\", \\\"{x:167,y:577,t:1527030670540};\\\", \\\"{x:167,y:576,t:1527030670571};\\\", \\\"{x:168,y:575,t:1527030670587};\\\", \\\"{x:171,y:573,t:1527030670596};\\\", \\\"{x:178,y:569,t:1527030670607};\\\", \\\"{x:221,y:559,t:1527030670625};\\\", \\\"{x:289,y:545,t:1527030670641};\\\", \\\"{x:372,y:536,t:1527030670658};\\\", \\\"{x:455,y:523,t:1527030670675};\\\", \\\"{x:557,y:513,t:1527030670692};\\\", \\\"{x:673,y:504,t:1527030670707};\\\", \\\"{x:726,y:504,t:1527030670725};\\\", \\\"{x:754,y:507,t:1527030670741};\\\", \\\"{x:762,y:507,t:1527030670758};\\\", \\\"{x:763,y:507,t:1527030670836};\\\", \\\"{x:763,y:509,t:1527030670843};\\\", \\\"{x:761,y:512,t:1527030670858};\\\", \\\"{x:759,y:518,t:1527030670875};\\\", \\\"{x:759,y:522,t:1527030670891};\\\", \\\"{x:759,y:525,t:1527030670908};\\\", \\\"{x:759,y:526,t:1527030670924};\\\", \\\"{x:760,y:527,t:1527030670941};\\\", \\\"{x:766,y:527,t:1527030670958};\\\", \\\"{x:770,y:527,t:1527030670974};\\\", \\\"{x:777,y:527,t:1527030670991};\\\", \\\"{x:791,y:527,t:1527030671008};\\\", \\\"{x:801,y:527,t:1527030671024};\\\", \\\"{x:805,y:527,t:1527030671041};\\\", \\\"{x:813,y:527,t:1527030671058};\\\", \\\"{x:825,y:525,t:1527030671074};\\\", \\\"{x:835,y:524,t:1527030671092};\\\", \\\"{x:840,y:524,t:1527030671107};\\\", \\\"{x:841,y:524,t:1527030671125};\\\", \\\"{x:842,y:524,t:1527030671141};\\\", \\\"{x:842,y:528,t:1527030671238};\\\", \\\"{x:841,y:536,t:1527030671258};\\\", \\\"{x:840,y:542,t:1527030671274};\\\", \\\"{x:840,y:546,t:1527030671290};\\\", \\\"{x:840,y:547,t:1527030671308};\\\", \\\"{x:839,y:548,t:1527030671420};\\\", \\\"{x:838,y:547,t:1527030671452};\\\", \\\"{x:838,y:546,t:1527030671508};\\\", \\\"{x:837,y:546,t:1527030671924};\\\", \\\"{x:835,y:546,t:1527030671931};\\\", \\\"{x:831,y:546,t:1527030671941};\\\", \\\"{x:821,y:549,t:1527030671959};\\\", \\\"{x:815,y:551,t:1527030671975};\\\", \\\"{x:805,y:554,t:1527030671992};\\\", \\\"{x:792,y:555,t:1527030672009};\\\", \\\"{x:775,y:561,t:1527030672026};\\\", \\\"{x:756,y:566,t:1527030672043};\\\", \\\"{x:738,y:572,t:1527030672059};\\\", \\\"{x:721,y:577,t:1527030672076};\\\", \\\"{x:699,y:583,t:1527030672092};\\\", \\\"{x:681,y:589,t:1527030672109};\\\", \\\"{x:659,y:596,t:1527030672126};\\\", \\\"{x:637,y:603,t:1527030672143};\\\", \\\"{x:609,y:617,t:1527030672160};\\\", \\\"{x:570,y:632,t:1527030672176};\\\", \\\"{x:534,y:651,t:1527030672192};\\\", \\\"{x:506,y:666,t:1527030672209};\\\", \\\"{x:474,y:687,t:1527030672225};\\\", \\\"{x:452,y:704,t:1527030672242};\\\", \\\"{x:441,y:713,t:1527030672259};\\\", \\\"{x:436,y:720,t:1527030672275};\\\", \\\"{x:434,y:724,t:1527030672292};\\\", \\\"{x:434,y:730,t:1527030672309};\\\", \\\"{x:437,y:734,t:1527030672326};\\\", \\\"{x:444,y:741,t:1527030672343};\\\", \\\"{x:448,y:746,t:1527030672359};\\\", \\\"{x:454,y:752,t:1527030672375};\\\", \\\"{x:460,y:756,t:1527030672392};\\\", \\\"{x:466,y:758,t:1527030672409};\\\", \\\"{x:470,y:760,t:1527030672425};\\\", \\\"{x:473,y:760,t:1527030672442};\\\", \\\"{x:478,y:760,t:1527030672459};\\\", \\\"{x:487,y:755,t:1527030672476};\\\", \\\"{x:491,y:753,t:1527030672492};\\\", \\\"{x:494,y:749,t:1527030672509};\\\", \\\"{x:495,y:748,t:1527030672525};\\\", \\\"{x:497,y:748,t:1527030672542};\\\", \\\"{x:497,y:747,t:1527030672580};\\\", \\\"{x:498,y:747,t:1527030672596};\\\", \\\"{x:499,y:747,t:1527030672610};\\\", \\\"{x:500,y:747,t:1527030672626};\\\", \\\"{x:501,y:746,t:1527030672709};\\\", \\\"{x:501,y:745,t:1527030672789};\\\", \\\"{x:501,y:742,t:1527030672796};\\\", \\\"{x:502,y:741,t:1527030672809};\\\", \\\"{x:502,y:738,t:1527030672826};\\\", \\\"{x:503,y:735,t:1527030672842};\\\", \\\"{x:503,y:734,t:1527030672859};\\\", \\\"{x:503,y:733,t:1527030672876};\\\", \\\"{x:505,y:732,t:1527030673828};\\\", \\\"{x:507,y:730,t:1527030673843};\\\", \\\"{x:515,y:722,t:1527030673859};\\\", \\\"{x:518,y:720,t:1527030673877};\\\", \\\"{x:523,y:714,t:1527030673893};\\\", \\\"{x:531,y:705,t:1527030673910};\\\", \\\"{x:559,y:693,t:1527030673927};\\\", \\\"{x:629,y:673,t:1527030673944};\\\", \\\"{x:729,y:643,t:1527030673960};\\\", \\\"{x:828,y:616,t:1527030673978};\\\", \\\"{x:928,y:588,t:1527030673993};\\\", \\\"{x:1023,y:570,t:1527030674010};\\\", \\\"{x:1120,y:556,t:1527030674028};\\\", \\\"{x:1231,y:540,t:1527030674044};\\\", \\\"{x:1426,y:513,t:1527030674060};\\\", \\\"{x:1549,y:494,t:1527030674077};\\\", \\\"{x:1646,y:479,t:1527030674094};\\\", \\\"{x:1695,y:470,t:1527030674110};\\\", \\\"{x:1707,y:469,t:1527030674128};\\\", \\\"{x:1710,y:469,t:1527030674143};\\\", \\\"{x:1708,y:470,t:1527030674260};\\\", \\\"{x:1703,y:471,t:1527030674277};\\\", \\\"{x:1702,y:472,t:1527030674295};\\\", \\\"{x:1699,y:474,t:1527030674322};\\\", \\\"{x:1697,y:474,t:1527030674327};\\\", \\\"{x:1691,y:477,t:1527030674347};\\\", \\\"{x:1688,y:478,t:1527030674360};\\\", \\\"{x:1686,y:479,t:1527030674376};\\\", \\\"{x:1683,y:481,t:1527030674394};\\\", \\\"{x:1680,y:482,t:1527030674410};\\\", \\\"{x:1677,y:484,t:1527030674426};\\\", \\\"{x:1670,y:489,t:1527030674443};\\\", \\\"{x:1666,y:491,t:1527030674460};\\\", \\\"{x:1665,y:492,t:1527030674477};\\\", \\\"{x:1664,y:492,t:1527030674494};\\\", \\\"{x:1661,y:494,t:1527030674510};\\\", \\\"{x:1650,y:497,t:1527030674527};\\\", \\\"{x:1647,y:497,t:1527030674544};\\\", \\\"{x:1645,y:499,t:1527030674560};\\\" ] }, { \\\"rt\\\": 26950, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 581258, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1643,y:499,t:1527030675179};\\\", \\\"{x:1642,y:499,t:1527030675196};\\\", \\\"{x:1641,y:500,t:1527030675211};\\\", \\\"{x:1640,y:500,t:1527030675228};\\\", \\\"{x:1639,y:500,t:1527030675251};\\\", \\\"{x:1638,y:500,t:1527030675261};\\\", \\\"{x:1637,y:501,t:1527030675278};\\\", \\\"{x:1636,y:501,t:1527030675295};\\\", \\\"{x:1636,y:502,t:1527030675311};\\\", \\\"{x:1635,y:502,t:1527030675328};\\\", \\\"{x:1634,y:502,t:1527030675344};\\\", \\\"{x:1632,y:503,t:1527030675361};\\\", \\\"{x:1631,y:504,t:1527030675378};\\\", \\\"{x:1627,y:505,t:1527030675396};\\\", \\\"{x:1627,y:506,t:1527030675412};\\\", \\\"{x:1623,y:507,t:1527030675428};\\\", \\\"{x:1620,y:509,t:1527030675444};\\\", \\\"{x:1616,y:510,t:1527030675462};\\\", \\\"{x:1613,y:511,t:1527030675479};\\\", \\\"{x:1610,y:512,t:1527030675495};\\\", \\\"{x:1609,y:513,t:1527030675511};\\\", \\\"{x:1608,y:513,t:1527030675529};\\\", \\\"{x:1607,y:514,t:1527030675621};\\\", \\\"{x:1606,y:516,t:1527030675668};\\\", \\\"{x:1605,y:516,t:1527030675684};\\\", \\\"{x:1604,y:516,t:1527030675696};\\\", \\\"{x:1603,y:517,t:1527030677253};\\\", \\\"{x:1600,y:519,t:1527030677263};\\\", \\\"{x:1596,y:520,t:1527030677280};\\\", \\\"{x:1588,y:524,t:1527030677297};\\\", \\\"{x:1585,y:525,t:1527030677313};\\\", \\\"{x:1580,y:528,t:1527030677330};\\\", \\\"{x:1578,y:528,t:1527030677347};\\\", \\\"{x:1576,y:529,t:1527030677363};\\\", \\\"{x:1575,y:530,t:1527030677380};\\\", \\\"{x:1574,y:530,t:1527030678716};\\\", \\\"{x:1572,y:531,t:1527030678731};\\\", \\\"{x:1565,y:534,t:1527030678748};\\\", \\\"{x:1563,y:535,t:1527030678763};\\\", \\\"{x:1561,y:535,t:1527030679029};\\\", \\\"{x:1560,y:536,t:1527030679036};\\\", \\\"{x:1559,y:536,t:1527030679053};\\\", \\\"{x:1557,y:538,t:1527030679064};\\\", \\\"{x:1556,y:538,t:1527030679081};\\\", \\\"{x:1553,y:539,t:1527030679098};\\\", \\\"{x:1552,y:540,t:1527030679114};\\\", \\\"{x:1549,y:540,t:1527030679131};\\\", \\\"{x:1546,y:540,t:1527030679147};\\\", \\\"{x:1544,y:540,t:1527030679165};\\\", \\\"{x:1543,y:540,t:1527030679180};\\\", \\\"{x:1543,y:541,t:1527030679197};\\\", \\\"{x:1540,y:541,t:1527030682308};\\\", \\\"{x:1537,y:542,t:1527030682317};\\\", \\\"{x:1535,y:543,t:1527030682334};\\\", \\\"{x:1532,y:544,t:1527030682350};\\\", \\\"{x:1526,y:544,t:1527030682367};\\\", \\\"{x:1519,y:545,t:1527030682383};\\\", \\\"{x:1515,y:546,t:1527030682400};\\\", \\\"{x:1511,y:547,t:1527030682417};\\\", \\\"{x:1510,y:547,t:1527030682433};\\\", \\\"{x:1508,y:547,t:1527030682450};\\\", \\\"{x:1506,y:547,t:1527030682467};\\\", \\\"{x:1501,y:548,t:1527030682484};\\\", \\\"{x:1498,y:549,t:1527030682501};\\\", \\\"{x:1497,y:549,t:1527030682517};\\\", \\\"{x:1495,y:550,t:1527030682534};\\\", \\\"{x:1494,y:550,t:1527030682564};\\\", \\\"{x:1493,y:551,t:1527030682581};\\\", \\\"{x:1492,y:551,t:1527030682588};\\\", \\\"{x:1491,y:552,t:1527030682629};\\\", \\\"{x:1490,y:552,t:1527030682652};\\\", \\\"{x:1489,y:552,t:1527030682677};\\\", \\\"{x:1488,y:553,t:1527030682700};\\\", \\\"{x:1487,y:553,t:1527030683268};\\\", \\\"{x:1485,y:553,t:1527030683284};\\\", \\\"{x:1484,y:553,t:1527030683325};\\\", \\\"{x:1482,y:554,t:1527030683661};\\\", \\\"{x:1481,y:555,t:1527030683676};\\\", \\\"{x:1477,y:557,t:1527030683684};\\\", \\\"{x:1474,y:558,t:1527030683701};\\\", \\\"{x:1472,y:558,t:1527030683718};\\\", \\\"{x:1471,y:559,t:1527030683736};\\\", \\\"{x:1468,y:559,t:1527030683771};\\\", \\\"{x:1466,y:559,t:1527030684061};\\\", \\\"{x:1465,y:559,t:1527030684077};\\\", \\\"{x:1464,y:560,t:1527030684091};\\\", \\\"{x:1462,y:560,t:1527030684101};\\\", \\\"{x:1460,y:560,t:1527030684117};\\\", \\\"{x:1460,y:561,t:1527030684134};\\\", \\\"{x:1459,y:561,t:1527030684152};\\\", \\\"{x:1457,y:561,t:1527030684564};\\\", \\\"{x:1452,y:561,t:1527030684573};\\\", \\\"{x:1450,y:561,t:1527030684585};\\\", \\\"{x:1447,y:561,t:1527030684602};\\\", \\\"{x:1437,y:561,t:1527030684619};\\\", \\\"{x:1425,y:561,t:1527030684635};\\\", \\\"{x:1416,y:561,t:1527030684654};\\\", \\\"{x:1412,y:561,t:1527030684668};\\\", \\\"{x:1409,y:561,t:1527030684685};\\\", \\\"{x:1407,y:561,t:1527030684704};\\\", \\\"{x:1402,y:563,t:1527030684719};\\\", \\\"{x:1393,y:567,t:1527030684735};\\\", \\\"{x:1377,y:573,t:1527030684752};\\\", \\\"{x:1360,y:578,t:1527030684770};\\\", \\\"{x:1345,y:583,t:1527030684785};\\\", \\\"{x:1332,y:588,t:1527030684802};\\\", \\\"{x:1323,y:591,t:1527030684819};\\\", \\\"{x:1318,y:593,t:1527030684835};\\\", \\\"{x:1311,y:596,t:1527030684852};\\\", \\\"{x:1307,y:597,t:1527030684869};\\\", \\\"{x:1303,y:599,t:1527030684885};\\\", \\\"{x:1299,y:602,t:1527030684903};\\\", \\\"{x:1295,y:604,t:1527030684919};\\\", \\\"{x:1292,y:604,t:1527030684936};\\\", \\\"{x:1288,y:607,t:1527030684953};\\\", \\\"{x:1279,y:613,t:1527030684969};\\\", \\\"{x:1265,y:624,t:1527030684987};\\\", \\\"{x:1256,y:632,t:1527030685002};\\\", \\\"{x:1247,y:642,t:1527030685019};\\\", \\\"{x:1235,y:656,t:1527030685036};\\\", \\\"{x:1226,y:665,t:1527030685052};\\\", \\\"{x:1218,y:673,t:1527030685069};\\\", \\\"{x:1213,y:679,t:1527030685086};\\\", \\\"{x:1211,y:684,t:1527030685102};\\\", \\\"{x:1209,y:690,t:1527030685120};\\\", \\\"{x:1205,y:699,t:1527030685136};\\\", \\\"{x:1201,y:712,t:1527030685152};\\\", \\\"{x:1199,y:731,t:1527030685169};\\\", \\\"{x:1195,y:746,t:1527030685186};\\\", \\\"{x:1195,y:747,t:1527030685660};\\\", \\\"{x:1194,y:748,t:1527030685669};\\\", \\\"{x:1192,y:749,t:1527030685687};\\\", \\\"{x:1191,y:750,t:1527030685703};\\\", \\\"{x:1190,y:752,t:1527030685719};\\\", \\\"{x:1188,y:756,t:1527030685737};\\\", \\\"{x:1185,y:760,t:1527030685754};\\\", \\\"{x:1179,y:770,t:1527030685771};\\\", \\\"{x:1171,y:782,t:1527030685786};\\\", \\\"{x:1163,y:792,t:1527030685803};\\\", \\\"{x:1155,y:802,t:1527030685820};\\\", \\\"{x:1149,y:812,t:1527030685836};\\\", \\\"{x:1143,y:823,t:1527030685854};\\\", \\\"{x:1137,y:835,t:1527030685869};\\\", \\\"{x:1132,y:850,t:1527030685886};\\\", \\\"{x:1131,y:864,t:1527030685903};\\\", \\\"{x:1131,y:870,t:1527030685920};\\\", \\\"{x:1135,y:874,t:1527030685936};\\\", \\\"{x:1139,y:874,t:1527030685953};\\\", \\\"{x:1143,y:876,t:1527030685970};\\\", \\\"{x:1145,y:876,t:1527030685986};\\\", \\\"{x:1147,y:876,t:1527030686003};\\\", \\\"{x:1160,y:866,t:1527030686020};\\\", \\\"{x:1178,y:850,t:1527030686035};\\\", \\\"{x:1198,y:838,t:1527030686053};\\\", \\\"{x:1220,y:820,t:1527030686070};\\\", \\\"{x:1244,y:802,t:1527030686086};\\\", \\\"{x:1271,y:781,t:1527030686104};\\\", \\\"{x:1299,y:754,t:1527030686120};\\\", \\\"{x:1317,y:735,t:1527030686137};\\\", \\\"{x:1343,y:701,t:1527030686153};\\\", \\\"{x:1375,y:669,t:1527030686170};\\\", \\\"{x:1412,y:632,t:1527030686186};\\\", \\\"{x:1435,y:613,t:1527030686204};\\\", \\\"{x:1461,y:591,t:1527030686220};\\\", \\\"{x:1467,y:587,t:1527030686236};\\\", \\\"{x:1468,y:586,t:1527030686253};\\\", \\\"{x:1469,y:586,t:1527030686270};\\\", \\\"{x:1466,y:586,t:1527030686541};\\\", \\\"{x:1463,y:586,t:1527030686553};\\\", \\\"{x:1460,y:588,t:1527030686571};\\\", \\\"{x:1458,y:589,t:1527030686587};\\\", \\\"{x:1454,y:590,t:1527030686604};\\\", \\\"{x:1452,y:591,t:1527030686620};\\\", \\\"{x:1451,y:591,t:1527030686638};\\\", \\\"{x:1450,y:592,t:1527030686653};\\\", \\\"{x:1448,y:593,t:1527030687404};\\\", \\\"{x:1434,y:598,t:1527030687421};\\\", \\\"{x:1418,y:602,t:1527030687437};\\\", \\\"{x:1400,y:606,t:1527030687454};\\\", \\\"{x:1385,y:607,t:1527030687471};\\\", \\\"{x:1372,y:609,t:1527030687487};\\\", \\\"{x:1365,y:609,t:1527030687503};\\\", \\\"{x:1363,y:609,t:1527030687521};\\\", \\\"{x:1361,y:610,t:1527030687948};\\\", \\\"{x:1359,y:610,t:1527030687965};\\\", \\\"{x:1358,y:610,t:1527030687972};\\\", \\\"{x:1355,y:610,t:1527030687988};\\\", \\\"{x:1354,y:610,t:1527030688005};\\\", \\\"{x:1353,y:610,t:1527030688021};\\\", \\\"{x:1352,y:610,t:1527030688044};\\\", \\\"{x:1351,y:611,t:1527030688054};\\\", \\\"{x:1350,y:611,t:1527030688071};\\\", \\\"{x:1348,y:612,t:1527030688089};\\\", \\\"{x:1345,y:614,t:1527030688104};\\\", \\\"{x:1344,y:614,t:1527030688121};\\\", \\\"{x:1342,y:614,t:1527030688139};\\\", \\\"{x:1341,y:615,t:1527030688154};\\\", \\\"{x:1339,y:616,t:1527030688171};\\\", \\\"{x:1337,y:617,t:1527030688188};\\\", \\\"{x:1333,y:617,t:1527030688204};\\\", \\\"{x:1331,y:619,t:1527030688221};\\\", \\\"{x:1329,y:620,t:1527030688239};\\\", \\\"{x:1327,y:621,t:1527030688254};\\\", \\\"{x:1325,y:622,t:1527030688271};\\\", \\\"{x:1324,y:623,t:1527030688288};\\\", \\\"{x:1323,y:623,t:1527030688308};\\\", \\\"{x:1322,y:623,t:1527030688348};\\\", \\\"{x:1320,y:623,t:1527030688356};\\\", \\\"{x:1319,y:623,t:1527030688372};\\\", \\\"{x:1315,y:622,t:1527030688388};\\\", \\\"{x:1312,y:622,t:1527030688406};\\\", \\\"{x:1310,y:621,t:1527030688422};\\\", \\\"{x:1307,y:619,t:1527030688439};\\\", \\\"{x:1306,y:618,t:1527030688455};\\\", \\\"{x:1304,y:618,t:1527030688471};\\\", \\\"{x:1301,y:613,t:1527030688489};\\\", \\\"{x:1297,y:607,t:1527030688505};\\\", \\\"{x:1293,y:603,t:1527030688521};\\\", \\\"{x:1288,y:596,t:1527030688539};\\\", \\\"{x:1286,y:594,t:1527030688556};\\\", \\\"{x:1284,y:592,t:1527030688571};\\\", \\\"{x:1283,y:591,t:1527030688588};\\\", \\\"{x:1283,y:589,t:1527030688606};\\\", \\\"{x:1282,y:585,t:1527030688621};\\\", \\\"{x:1282,y:583,t:1527030688638};\\\", \\\"{x:1282,y:582,t:1527030688655};\\\", \\\"{x:1282,y:580,t:1527030688676};\\\", \\\"{x:1282,y:579,t:1527030688700};\\\", \\\"{x:1282,y:577,t:1527030693164};\\\", \\\"{x:1282,y:575,t:1527030693175};\\\", \\\"{x:1282,y:574,t:1527030693191};\\\", \\\"{x:1283,y:572,t:1527030693208};\\\", \\\"{x:1284,y:570,t:1527030693225};\\\", \\\"{x:1284,y:569,t:1527030693241};\\\", \\\"{x:1284,y:570,t:1527030693644};\\\", \\\"{x:1284,y:573,t:1527030693658};\\\", \\\"{x:1284,y:578,t:1527030693675};\\\", \\\"{x:1284,y:581,t:1527030693692};\\\", \\\"{x:1284,y:582,t:1527030693708};\\\", \\\"{x:1285,y:583,t:1527030693726};\\\", \\\"{x:1285,y:584,t:1527030693743};\\\", \\\"{x:1285,y:586,t:1527030693759};\\\", \\\"{x:1285,y:587,t:1527030693780};\\\", \\\"{x:1285,y:588,t:1527030693796};\\\", \\\"{x:1286,y:589,t:1527030693836};\\\", \\\"{x:1286,y:590,t:1527030693885};\\\", \\\"{x:1286,y:591,t:1527030693893};\\\", \\\"{x:1288,y:593,t:1527030693908};\\\", \\\"{x:1292,y:600,t:1527030693925};\\\", \\\"{x:1299,y:607,t:1527030693942};\\\", \\\"{x:1301,y:610,t:1527030693960};\\\", \\\"{x:1305,y:616,t:1527030693976};\\\", \\\"{x:1309,y:620,t:1527030693993};\\\", \\\"{x:1313,y:625,t:1527030694010};\\\", \\\"{x:1317,y:632,t:1527030694026};\\\", \\\"{x:1321,y:636,t:1527030694042};\\\", \\\"{x:1324,y:640,t:1527030694059};\\\", \\\"{x:1327,y:644,t:1527030694075};\\\", \\\"{x:1328,y:647,t:1527030694093};\\\", \\\"{x:1330,y:650,t:1527030694110};\\\", \\\"{x:1332,y:653,t:1527030694125};\\\", \\\"{x:1336,y:660,t:1527030694143};\\\", \\\"{x:1345,y:672,t:1527030694159};\\\", \\\"{x:1352,y:683,t:1527030694175};\\\", \\\"{x:1356,y:691,t:1527030694193};\\\", \\\"{x:1360,y:700,t:1527030694209};\\\", \\\"{x:1365,y:707,t:1527030694226};\\\", \\\"{x:1370,y:716,t:1527030694242};\\\", \\\"{x:1374,y:722,t:1527030694259};\\\", \\\"{x:1377,y:728,t:1527030694276};\\\", \\\"{x:1383,y:740,t:1527030694292};\\\", \\\"{x:1386,y:744,t:1527030694310};\\\", \\\"{x:1389,y:748,t:1527030694327};\\\", \\\"{x:1390,y:749,t:1527030694342};\\\", \\\"{x:1390,y:750,t:1527030694359};\\\", \\\"{x:1392,y:751,t:1527030694411};\\\", \\\"{x:1393,y:752,t:1527030694427};\\\", \\\"{x:1393,y:754,t:1527030694442};\\\", \\\"{x:1395,y:756,t:1527030694458};\\\", \\\"{x:1396,y:757,t:1527030694476};\\\", \\\"{x:1396,y:759,t:1527030694492};\\\", \\\"{x:1399,y:762,t:1527030694509};\\\", \\\"{x:1400,y:763,t:1527030694526};\\\", \\\"{x:1402,y:766,t:1527030694542};\\\", \\\"{x:1404,y:769,t:1527030694559};\\\", \\\"{x:1406,y:772,t:1527030694576};\\\", \\\"{x:1407,y:773,t:1527030694592};\\\", \\\"{x:1408,y:774,t:1527030694609};\\\", \\\"{x:1409,y:776,t:1527030694626};\\\", \\\"{x:1412,y:780,t:1527030694642};\\\", \\\"{x:1415,y:785,t:1527030694659};\\\", \\\"{x:1420,y:792,t:1527030694675};\\\", \\\"{x:1421,y:796,t:1527030694692};\\\", \\\"{x:1424,y:801,t:1527030694709};\\\", \\\"{x:1428,y:806,t:1527030694726};\\\", \\\"{x:1432,y:813,t:1527030694742};\\\", \\\"{x:1436,y:821,t:1527030694759};\\\", \\\"{x:1441,y:830,t:1527030694776};\\\", \\\"{x:1445,y:839,t:1527030694792};\\\", \\\"{x:1446,y:844,t:1527030694809};\\\", \\\"{x:1450,y:851,t:1527030694826};\\\", \\\"{x:1451,y:854,t:1527030694843};\\\", \\\"{x:1454,y:860,t:1527030694860};\\\", \\\"{x:1456,y:868,t:1527030694876};\\\", \\\"{x:1459,y:874,t:1527030694894};\\\", \\\"{x:1461,y:880,t:1527030694910};\\\", \\\"{x:1462,y:887,t:1527030694927};\\\", \\\"{x:1465,y:892,t:1527030694944};\\\", \\\"{x:1466,y:897,t:1527030694959};\\\", \\\"{x:1467,y:900,t:1527030694977};\\\", \\\"{x:1469,y:905,t:1527030694994};\\\", \\\"{x:1470,y:907,t:1527030695010};\\\", \\\"{x:1470,y:908,t:1527030695036};\\\", \\\"{x:1470,y:909,t:1527030695052};\\\", \\\"{x:1470,y:910,t:1527030695084};\\\", \\\"{x:1470,y:911,t:1527030695117};\\\", \\\"{x:1472,y:912,t:1527030695164};\\\", \\\"{x:1472,y:913,t:1527030695196};\\\", \\\"{x:1472,y:914,t:1527030695212};\\\", \\\"{x:1472,y:915,t:1527030695228};\\\", \\\"{x:1472,y:916,t:1527030695244};\\\", \\\"{x:1472,y:917,t:1527030695268};\\\", \\\"{x:1472,y:918,t:1527030695276};\\\", \\\"{x:1472,y:919,t:1527030695294};\\\", \\\"{x:1472,y:920,t:1527030695316};\\\", \\\"{x:1472,y:921,t:1527030695327};\\\", \\\"{x:1472,y:922,t:1527030695343};\\\", \\\"{x:1473,y:924,t:1527030695360};\\\", \\\"{x:1474,y:925,t:1527030695377};\\\", \\\"{x:1475,y:927,t:1527030695394};\\\", \\\"{x:1476,y:928,t:1527030695411};\\\", \\\"{x:1473,y:925,t:1527030695557};\\\", \\\"{x:1471,y:922,t:1527030695563};\\\", \\\"{x:1467,y:918,t:1527030695576};\\\", \\\"{x:1460,y:912,t:1527030695594};\\\", \\\"{x:1451,y:905,t:1527030695610};\\\", \\\"{x:1436,y:894,t:1527030695627};\\\", \\\"{x:1421,y:882,t:1527030695644};\\\", \\\"{x:1416,y:878,t:1527030695660};\\\", \\\"{x:1412,y:876,t:1527030695676};\\\", \\\"{x:1411,y:875,t:1527030695694};\\\", \\\"{x:1410,y:874,t:1527030695711};\\\", \\\"{x:1410,y:873,t:1527030695732};\\\", \\\"{x:1410,y:872,t:1527030695744};\\\", \\\"{x:1409,y:871,t:1527030695760};\\\", \\\"{x:1408,y:870,t:1527030695777};\\\", \\\"{x:1407,y:869,t:1527030695795};\\\", \\\"{x:1407,y:868,t:1527030695828};\\\", \\\"{x:1406,y:866,t:1527030695892};\\\", \\\"{x:1405,y:865,t:1527030695910};\\\", \\\"{x:1403,y:863,t:1527030695926};\\\", \\\"{x:1402,y:860,t:1527030695943};\\\", \\\"{x:1399,y:855,t:1527030695961};\\\", \\\"{x:1395,y:851,t:1527030695978};\\\", \\\"{x:1387,y:838,t:1527030695993};\\\", \\\"{x:1379,y:828,t:1527030696010};\\\", \\\"{x:1367,y:811,t:1527030696028};\\\", \\\"{x:1359,y:801,t:1527030696043};\\\", \\\"{x:1353,y:792,t:1527030696060};\\\", \\\"{x:1341,y:775,t:1527030696077};\\\", \\\"{x:1321,y:757,t:1527030696093};\\\", \\\"{x:1295,y:737,t:1527030696111};\\\", \\\"{x:1247,y:713,t:1527030696127};\\\", \\\"{x:1192,y:690,t:1527030696143};\\\", \\\"{x:1139,y:676,t:1527030696160};\\\", \\\"{x:1075,y:657,t:1527030696177};\\\", \\\"{x:1011,y:637,t:1527030696193};\\\", \\\"{x:966,y:624,t:1527030696211};\\\", \\\"{x:896,y:604,t:1527030696229};\\\", \\\"{x:835,y:587,t:1527030696243};\\\", \\\"{x:774,y:570,t:1527030696260};\\\", \\\"{x:732,y:557,t:1527030696278};\\\", \\\"{x:711,y:552,t:1527030696296};\\\", \\\"{x:691,y:545,t:1527030696311};\\\", \\\"{x:687,y:544,t:1527030696328};\\\", \\\"{x:686,y:544,t:1527030696345};\\\", \\\"{x:685,y:543,t:1527030696362};\\\", \\\"{x:684,y:541,t:1527030696378};\\\", \\\"{x:679,y:538,t:1527030696395};\\\", \\\"{x:678,y:538,t:1527030696411};\\\", \\\"{x:676,y:538,t:1527030696428};\\\", \\\"{x:675,y:538,t:1527030696444};\\\", \\\"{x:675,y:537,t:1527030696483};\\\", \\\"{x:675,y:535,t:1527030696495};\\\", \\\"{x:677,y:525,t:1527030696512};\\\", \\\"{x:688,y:513,t:1527030696530};\\\", \\\"{x:707,y:498,t:1527030696545};\\\", \\\"{x:752,y:471,t:1527030696562};\\\", \\\"{x:799,y:454,t:1527030696579};\\\", \\\"{x:800,y:454,t:1527030696595};\\\", \\\"{x:802,y:455,t:1527030696619};\\\", \\\"{x:802,y:458,t:1527030696628};\\\", \\\"{x:800,y:462,t:1527030696645};\\\", \\\"{x:792,y:470,t:1527030696662};\\\", \\\"{x:779,y:478,t:1527030696679};\\\", \\\"{x:762,y:488,t:1527030696695};\\\", \\\"{x:746,y:497,t:1527030696712};\\\", \\\"{x:732,y:505,t:1527030696729};\\\", \\\"{x:720,y:511,t:1527030696748};\\\", \\\"{x:708,y:516,t:1527030696762};\\\", \\\"{x:696,y:517,t:1527030696779};\\\", \\\"{x:690,y:517,t:1527030696795};\\\", \\\"{x:676,y:517,t:1527030696811};\\\", \\\"{x:654,y:517,t:1527030696829};\\\", \\\"{x:632,y:514,t:1527030696845};\\\", \\\"{x:617,y:511,t:1527030696863};\\\", \\\"{x:611,y:508,t:1527030696878};\\\", \\\"{x:608,y:507,t:1527030696895};\\\", \\\"{x:607,y:506,t:1527030697283};\\\", \\\"{x:604,y:506,t:1527030697295};\\\", \\\"{x:598,y:525,t:1527030697313};\\\", \\\"{x:592,y:545,t:1527030697329};\\\", \\\"{x:583,y:559,t:1527030697346};\\\", \\\"{x:572,y:578,t:1527030697362};\\\", \\\"{x:554,y:609,t:1527030697380};\\\", \\\"{x:540,y:629,t:1527030697396};\\\", \\\"{x:524,y:644,t:1527030697414};\\\", \\\"{x:506,y:661,t:1527030697429};\\\", \\\"{x:489,y:679,t:1527030697446};\\\", \\\"{x:478,y:692,t:1527030697462};\\\", \\\"{x:466,y:705,t:1527030697479};\\\", \\\"{x:451,y:722,t:1527030697498};\\\", \\\"{x:439,y:732,t:1527030697513};\\\", \\\"{x:434,y:737,t:1527030697529};\\\", \\\"{x:434,y:736,t:1527030697627};\\\", \\\"{x:434,y:735,t:1527030697635};\\\", \\\"{x:434,y:733,t:1527030697646};\\\", \\\"{x:437,y:729,t:1527030697663};\\\", \\\"{x:442,y:724,t:1527030697680};\\\", \\\"{x:444,y:722,t:1527030697696};\\\", \\\"{x:445,y:722,t:1527030697713};\\\", \\\"{x:447,y:722,t:1527030697781};\\\", \\\"{x:451,y:722,t:1527030697797};\\\", \\\"{x:456,y:722,t:1527030697813};\\\", \\\"{x:461,y:723,t:1527030697830};\\\", \\\"{x:466,y:724,t:1527030697846};\\\", \\\"{x:474,y:725,t:1527030697864};\\\", \\\"{x:482,y:726,t:1527030697880};\\\", \\\"{x:490,y:726,t:1527030697896};\\\", \\\"{x:498,y:727,t:1527030697913};\\\", \\\"{x:501,y:728,t:1527030697930};\\\", \\\"{x:504,y:729,t:1527030697946};\\\", \\\"{x:505,y:729,t:1527030697971};\\\", \\\"{x:506,y:729,t:1527030697988};\\\", \\\"{x:507,y:729,t:1527030698012};\\\", \\\"{x:508,y:730,t:1527030698044};\\\", \\\"{x:507,y:730,t:1527030698644};\\\", \\\"{x:506,y:730,t:1527030698651};\\\", \\\"{x:505,y:730,t:1527030698665};\\\", \\\"{x:504,y:730,t:1527030698680};\\\", \\\"{x:503,y:730,t:1527030698697};\\\", \\\"{x:502,y:730,t:1527030698739};\\\", \\\"{x:501,y:730,t:1527030700220};\\\", \\\"{x:499,y:730,t:1527030702076};\\\", \\\"{x:498,y:730,t:1527030702115};\\\", \\\"{x:497,y:730,t:1527030702147};\\\", \\\"{x:496,y:729,t:1527030702155};\\\", \\\"{x:496,y:728,t:1527030702187};\\\" ] }, { \\\"rt\\\": 12000, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 594497, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:727,t:1527030703675};\\\", \\\"{x:494,y:727,t:1527030703715};\\\", \\\"{x:494,y:726,t:1527030703724};\\\", \\\"{x:493,y:726,t:1527030703735};\\\", \\\"{x:493,y:724,t:1527030703751};\\\", \\\"{x:493,y:721,t:1527030703768};\\\", \\\"{x:493,y:719,t:1527030703786};\\\", \\\"{x:495,y:714,t:1527030703801};\\\", \\\"{x:500,y:709,t:1527030703818};\\\", \\\"{x:502,y:705,t:1527030703834};\\\", \\\"{x:505,y:697,t:1527030703851};\\\", \\\"{x:510,y:687,t:1527030703868};\\\", \\\"{x:516,y:677,t:1527030703884};\\\", \\\"{x:524,y:664,t:1527030703901};\\\", \\\"{x:537,y:654,t:1527030703918};\\\", \\\"{x:558,y:641,t:1527030703935};\\\", \\\"{x:581,y:630,t:1527030703952};\\\", \\\"{x:611,y:618,t:1527030703968};\\\", \\\"{x:638,y:607,t:1527030703984};\\\", \\\"{x:676,y:593,t:1527030704002};\\\", \\\"{x:709,y:584,t:1527030704018};\\\", \\\"{x:729,y:575,t:1527030704035};\\\", \\\"{x:746,y:568,t:1527030704051};\\\", \\\"{x:749,y:566,t:1527030704068};\\\", \\\"{x:753,y:565,t:1527030704252};\\\", \\\"{x:765,y:561,t:1527030704269};\\\", \\\"{x:772,y:561,t:1527030704285};\\\", \\\"{x:778,y:564,t:1527030704302};\\\", \\\"{x:780,y:568,t:1527030704318};\\\", \\\"{x:782,y:579,t:1527030704335};\\\", \\\"{x:771,y:602,t:1527030704352};\\\", \\\"{x:767,y:615,t:1527030704368};\\\", \\\"{x:767,y:618,t:1527030704385};\\\", \\\"{x:767,y:622,t:1527030704401};\\\", \\\"{x:767,y:626,t:1527030704418};\\\", \\\"{x:767,y:634,t:1527030704436};\\\", \\\"{x:767,y:639,t:1527030704451};\\\", \\\"{x:767,y:642,t:1527030704468};\\\", \\\"{x:767,y:643,t:1527030704486};\\\", \\\"{x:767,y:646,t:1527030704501};\\\", \\\"{x:767,y:648,t:1527030704518};\\\", \\\"{x:767,y:650,t:1527030704536};\\\", \\\"{x:767,y:651,t:1527030704551};\\\", \\\"{x:767,y:654,t:1527030704568};\\\", \\\"{x:767,y:655,t:1527030704585};\\\", \\\"{x:767,y:656,t:1527030704601};\\\", \\\"{x:767,y:657,t:1527030704619};\\\", \\\"{x:767,y:658,t:1527030708292};\\\", \\\"{x:767,y:659,t:1527030708307};\\\", \\\"{x:766,y:659,t:1527030708339};\\\", \\\"{x:764,y:659,t:1527030708356};\\\", \\\"{x:763,y:659,t:1527030708468};\\\", \\\"{x:762,y:659,t:1527030708500};\\\", \\\"{x:761,y:659,t:1527030708627};\\\", \\\"{x:759,y:659,t:1527030708660};\\\", \\\"{x:757,y:659,t:1527030708669};\\\", \\\"{x:754,y:658,t:1527030708686};\\\", \\\"{x:753,y:658,t:1527030708702};\\\", \\\"{x:752,y:658,t:1527030708932};\\\", \\\"{x:751,y:658,t:1527030708955};\\\", \\\"{x:748,y:657,t:1527030708970};\\\", \\\"{x:746,y:657,t:1527030708985};\\\", \\\"{x:744,y:656,t:1527030709002};\\\", \\\"{x:742,y:656,t:1527030710396};\\\", \\\"{x:739,y:656,t:1527030710403};\\\", \\\"{x:737,y:656,t:1527030710420};\\\", \\\"{x:735,y:654,t:1527030710437};\\\", \\\"{x:733,y:654,t:1527030710540};\\\", \\\"{x:732,y:653,t:1527030710553};\\\", \\\"{x:728,y:652,t:1527030710570};\\\", \\\"{x:722,y:649,t:1527030710587};\\\", \\\"{x:713,y:647,t:1527030710603};\\\", \\\"{x:693,y:641,t:1527030710620};\\\", \\\"{x:679,y:639,t:1527030710637};\\\", \\\"{x:670,y:639,t:1527030710653};\\\", \\\"{x:662,y:637,t:1527030710670};\\\", \\\"{x:655,y:636,t:1527030710687};\\\", \\\"{x:648,y:635,t:1527030710703};\\\", \\\"{x:641,y:634,t:1527030710720};\\\", \\\"{x:637,y:632,t:1527030710736};\\\", \\\"{x:635,y:631,t:1527030710754};\\\", \\\"{x:632,y:628,t:1527030710769};\\\", \\\"{x:627,y:624,t:1527030710787};\\\", \\\"{x:623,y:620,t:1527030710807};\\\", \\\"{x:621,y:618,t:1527030710823};\\\", \\\"{x:619,y:616,t:1527030710840};\\\", \\\"{x:617,y:613,t:1527030710856};\\\", \\\"{x:613,y:608,t:1527030710874};\\\", \\\"{x:611,y:605,t:1527030710890};\\\", \\\"{x:608,y:602,t:1527030710906};\\\", \\\"{x:604,y:600,t:1527030710924};\\\", \\\"{x:597,y:595,t:1527030710940};\\\", \\\"{x:590,y:594,t:1527030710956};\\\", \\\"{x:579,y:590,t:1527030710974};\\\", \\\"{x:566,y:586,t:1527030710990};\\\", \\\"{x:554,y:582,t:1527030711007};\\\", \\\"{x:549,y:581,t:1527030711023};\\\", \\\"{x:541,y:578,t:1527030711040};\\\", \\\"{x:534,y:576,t:1527030711056};\\\", \\\"{x:529,y:574,t:1527030711073};\\\", \\\"{x:528,y:574,t:1527030711091};\\\", \\\"{x:527,y:573,t:1527030711123};\\\", \\\"{x:527,y:564,t:1527030711140};\\\", \\\"{x:530,y:551,t:1527030711158};\\\", \\\"{x:542,y:540,t:1527030711173};\\\", \\\"{x:551,y:533,t:1527030711191};\\\", \\\"{x:566,y:524,t:1527030711207};\\\", \\\"{x:576,y:519,t:1527030711224};\\\", \\\"{x:580,y:516,t:1527030711241};\\\", \\\"{x:585,y:514,t:1527030711257};\\\", \\\"{x:588,y:512,t:1527030711273};\\\", \\\"{x:590,y:512,t:1527030711290};\\\", \\\"{x:595,y:512,t:1527030711307};\\\", \\\"{x:601,y:512,t:1527030711324};\\\", \\\"{x:602,y:512,t:1527030711341};\\\", \\\"{x:603,y:512,t:1527030711771};\\\", \\\"{x:600,y:514,t:1527030711787};\\\", \\\"{x:596,y:520,t:1527030711795};\\\", \\\"{x:594,y:531,t:1527030711807};\\\", \\\"{x:586,y:548,t:1527030711824};\\\", \\\"{x:583,y:558,t:1527030711841};\\\", \\\"{x:581,y:568,t:1527030711858};\\\", \\\"{x:574,y:586,t:1527030711874};\\\", \\\"{x:570,y:597,t:1527030711891};\\\", \\\"{x:565,y:606,t:1527030711908};\\\", \\\"{x:558,y:617,t:1527030711925};\\\", \\\"{x:551,y:631,t:1527030711940};\\\", \\\"{x:547,y:641,t:1527030711958};\\\", \\\"{x:543,y:649,t:1527030711974};\\\", \\\"{x:538,y:656,t:1527030711991};\\\", \\\"{x:536,y:659,t:1527030712007};\\\", \\\"{x:533,y:663,t:1527030712025};\\\", \\\"{x:531,y:666,t:1527030712040};\\\", \\\"{x:529,y:669,t:1527030712057};\\\", \\\"{x:527,y:672,t:1527030712075};\\\", \\\"{x:526,y:673,t:1527030712092};\\\", \\\"{x:526,y:675,t:1527030712108};\\\", \\\"{x:524,y:678,t:1527030712125};\\\", \\\"{x:523,y:679,t:1527030712141};\\\", \\\"{x:522,y:682,t:1527030712158};\\\", \\\"{x:520,y:682,t:1527030712175};\\\", \\\"{x:520,y:683,t:1527030712195};\\\", \\\"{x:519,y:684,t:1527030712212};\\\", \\\"{x:518,y:684,t:1527030712225};\\\", \\\"{x:516,y:686,t:1527030712242};\\\", \\\"{x:515,y:686,t:1527030712259};\\\", \\\"{x:514,y:687,t:1527030712275};\\\", \\\"{x:513,y:688,t:1527030712356};\\\", \\\"{x:511,y:689,t:1527030712371};\\\", \\\"{x:510,y:690,t:1527030712387};\\\", \\\"{x:509,y:692,t:1527030712396};\\\", \\\"{x:508,y:692,t:1527030712419};\\\", \\\"{x:507,y:693,t:1527030712499};\\\", \\\"{x:506,y:693,t:1527030712516};\\\", \\\"{x:504,y:694,t:1527030712604};\\\", \\\"{x:504,y:695,t:1527030712628};\\\", \\\"{x:503,y:695,t:1527030712642};\\\", \\\"{x:502,y:696,t:1527030712676};\\\", \\\"{x:501,y:696,t:1527030712692};\\\", \\\"{x:499,y:700,t:1527030712709};\\\", \\\"{x:497,y:702,t:1527030712726};\\\", \\\"{x:495,y:706,t:1527030712742};\\\", \\\"{x:495,y:707,t:1527030712759};\\\", \\\"{x:495,y:709,t:1527030712776};\\\", \\\"{x:494,y:712,t:1527030712792};\\\", \\\"{x:494,y:713,t:1527030712835};\\\", \\\"{x:494,y:714,t:1527030712842};\\\", \\\"{x:494,y:717,t:1527030712858};\\\", \\\"{x:494,y:718,t:1527030712875};\\\", \\\"{x:494,y:720,t:1527030712893};\\\", \\\"{x:495,y:722,t:1527030712914};\\\", \\\"{x:495,y:723,t:1527030712938};\\\", \\\"{x:496,y:723,t:1527030712947};\\\", \\\"{x:497,y:725,t:1527030712962};\\\", \\\"{x:499,y:725,t:1527030712975};\\\", \\\"{x:501,y:727,t:1527030712991};\\\", \\\"{x:503,y:728,t:1527030713008};\\\", \\\"{x:504,y:729,t:1527030713025};\\\", \\\"{x:506,y:730,t:1527030713041};\\\", \\\"{x:506,y:731,t:1527030713058};\\\", \\\"{x:508,y:733,t:1527030713075};\\\" ] }, { \\\"rt\\\": 11287, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 607005, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:733,t:1527030719244};\\\", \\\"{x:507,y:731,t:1527030719386};\\\", \\\"{x:508,y:729,t:1527030719395};\\\", \\\"{x:528,y:720,t:1527030719411};\\\", \\\"{x:559,y:707,t:1527030719428};\\\", \\\"{x:628,y:692,t:1527030719444};\\\", \\\"{x:721,y:686,t:1527030719461};\\\", \\\"{x:829,y:682,t:1527030719479};\\\", \\\"{x:946,y:682,t:1527030719496};\\\", \\\"{x:1059,y:682,t:1527030719513};\\\", \\\"{x:1173,y:682,t:1527030719530};\\\", \\\"{x:1259,y:682,t:1527030719545};\\\", \\\"{x:1356,y:682,t:1527030719562};\\\", \\\"{x:1387,y:682,t:1527030719580};\\\", \\\"{x:1397,y:682,t:1527030719596};\\\", \\\"{x:1399,y:682,t:1527030719613};\\\", \\\"{x:1399,y:684,t:1527030719699};\\\", \\\"{x:1401,y:687,t:1527030719713};\\\", \\\"{x:1406,y:695,t:1527030719731};\\\", \\\"{x:1410,y:702,t:1527030719748};\\\", \\\"{x:1413,y:705,t:1527030719764};\\\", \\\"{x:1414,y:707,t:1527030719781};\\\", \\\"{x:1414,y:711,t:1527030719797};\\\", \\\"{x:1414,y:716,t:1527030719814};\\\", \\\"{x:1414,y:723,t:1527030719831};\\\", \\\"{x:1414,y:733,t:1527030719847};\\\", \\\"{x:1411,y:744,t:1527030719864};\\\", \\\"{x:1410,y:752,t:1527030719880};\\\", \\\"{x:1409,y:761,t:1527030719897};\\\", \\\"{x:1407,y:766,t:1527030719913};\\\", \\\"{x:1406,y:771,t:1527030719930};\\\", \\\"{x:1405,y:778,t:1527030719947};\\\", \\\"{x:1405,y:787,t:1527030719963};\\\", \\\"{x:1405,y:795,t:1527030719981};\\\", \\\"{x:1409,y:807,t:1527030719997};\\\", \\\"{x:1415,y:823,t:1527030720013};\\\", \\\"{x:1419,y:836,t:1527030720030};\\\", \\\"{x:1424,y:846,t:1527030720047};\\\", \\\"{x:1424,y:855,t:1527030720064};\\\", \\\"{x:1425,y:861,t:1527030720081};\\\", \\\"{x:1427,y:868,t:1527030720097};\\\", \\\"{x:1427,y:874,t:1527030720113};\\\", \\\"{x:1427,y:879,t:1527030720130};\\\", \\\"{x:1426,y:886,t:1527030720148};\\\", \\\"{x:1422,y:892,t:1527030720164};\\\", \\\"{x:1419,y:895,t:1527030720180};\\\", \\\"{x:1415,y:898,t:1527030720197};\\\", \\\"{x:1412,y:899,t:1527030720213};\\\", \\\"{x:1408,y:900,t:1527030720230};\\\", \\\"{x:1405,y:902,t:1527030720248};\\\", \\\"{x:1401,y:905,t:1527030720263};\\\", \\\"{x:1394,y:908,t:1527030720281};\\\", \\\"{x:1390,y:910,t:1527030720297};\\\", \\\"{x:1387,y:913,t:1527030720315};\\\", \\\"{x:1385,y:915,t:1527030720330};\\\", \\\"{x:1384,y:917,t:1527030720347};\\\", \\\"{x:1383,y:919,t:1527030720363};\\\", \\\"{x:1383,y:921,t:1527030720387};\\\", \\\"{x:1383,y:922,t:1527030720397};\\\", \\\"{x:1381,y:924,t:1527030720415};\\\", \\\"{x:1380,y:925,t:1527030720430};\\\", \\\"{x:1379,y:926,t:1527030720447};\\\", \\\"{x:1378,y:927,t:1527030720464};\\\", \\\"{x:1378,y:928,t:1527030720491};\\\", \\\"{x:1377,y:928,t:1527030720532};\\\", \\\"{x:1376,y:928,t:1527030720815};\\\", \\\"{x:1375,y:928,t:1527030720952};\\\", \\\"{x:1374,y:928,t:1527030721072};\\\", \\\"{x:1374,y:929,t:1527030721103};\\\", \\\"{x:1374,y:930,t:1527030721118};\\\", \\\"{x:1374,y:931,t:1527030721143};\\\", \\\"{x:1374,y:932,t:1527030721151};\\\", \\\"{x:1374,y:933,t:1527030721303};\\\", \\\"{x:1374,y:935,t:1527030721375};\\\", \\\"{x:1374,y:937,t:1527030721385};\\\", \\\"{x:1373,y:942,t:1527030721401};\\\", \\\"{x:1370,y:946,t:1527030721418};\\\", \\\"{x:1367,y:949,t:1527030721435};\\\", \\\"{x:1363,y:953,t:1527030721451};\\\", \\\"{x:1362,y:953,t:1527030721468};\\\", \\\"{x:1362,y:955,t:1527030721485};\\\", \\\"{x:1361,y:955,t:1527030721501};\\\", \\\"{x:1360,y:955,t:1527030721568};\\\", \\\"{x:1359,y:955,t:1527030721607};\\\", \\\"{x:1357,y:955,t:1527030721641};\\\", \\\"{x:1356,y:955,t:1527030721695};\\\", \\\"{x:1356,y:954,t:1527030722015};\\\", \\\"{x:1356,y:953,t:1527030722023};\\\", \\\"{x:1357,y:952,t:1527030722035};\\\", \\\"{x:1357,y:950,t:1527030722051};\\\", \\\"{x:1358,y:949,t:1527030722068};\\\", \\\"{x:1359,y:946,t:1527030722085};\\\", \\\"{x:1360,y:946,t:1527030722102};\\\", \\\"{x:1361,y:945,t:1527030722118};\\\", \\\"{x:1363,y:942,t:1527030722135};\\\", \\\"{x:1364,y:941,t:1527030722158};\\\", \\\"{x:1364,y:940,t:1527030722191};\\\", \\\"{x:1366,y:939,t:1527030722215};\\\", \\\"{x:1367,y:937,t:1527030722223};\\\", \\\"{x:1367,y:936,t:1527030722240};\\\", \\\"{x:1368,y:936,t:1527030722252};\\\", \\\"{x:1369,y:934,t:1527030722268};\\\", \\\"{x:1370,y:932,t:1527030722285};\\\", \\\"{x:1371,y:931,t:1527030722302};\\\", \\\"{x:1373,y:929,t:1527030722318};\\\", \\\"{x:1375,y:925,t:1527030722335};\\\", \\\"{x:1380,y:921,t:1527030722351};\\\", \\\"{x:1385,y:915,t:1527030722367};\\\", \\\"{x:1390,y:909,t:1527030722385};\\\", \\\"{x:1397,y:901,t:1527030722401};\\\", \\\"{x:1402,y:895,t:1527030722418};\\\", \\\"{x:1408,y:889,t:1527030722435};\\\", \\\"{x:1411,y:887,t:1527030722451};\\\", \\\"{x:1412,y:885,t:1527030722468};\\\", \\\"{x:1414,y:882,t:1527030722484};\\\", \\\"{x:1415,y:882,t:1527030722502};\\\", \\\"{x:1415,y:881,t:1527030722517};\\\", \\\"{x:1417,y:879,t:1527030722535};\\\", \\\"{x:1418,y:878,t:1527030722551};\\\", \\\"{x:1419,y:876,t:1527030722568};\\\", \\\"{x:1420,y:875,t:1527030722584};\\\", \\\"{x:1421,y:875,t:1527030722606};\\\", \\\"{x:1421,y:873,t:1527030722618};\\\", \\\"{x:1421,y:872,t:1527030722635};\\\", \\\"{x:1423,y:869,t:1527030722652};\\\", \\\"{x:1424,y:867,t:1527030722669};\\\", \\\"{x:1425,y:862,t:1527030722685};\\\", \\\"{x:1426,y:860,t:1527030722702};\\\", \\\"{x:1429,y:850,t:1527030722719};\\\", \\\"{x:1431,y:842,t:1527030722735};\\\", \\\"{x:1433,y:834,t:1527030722752};\\\", \\\"{x:1438,y:823,t:1527030722769};\\\", \\\"{x:1442,y:803,t:1527030722785};\\\", \\\"{x:1450,y:780,t:1527030722802};\\\", \\\"{x:1457,y:757,t:1527030722819};\\\", \\\"{x:1468,y:730,t:1527030722835};\\\", \\\"{x:1482,y:694,t:1527030722852};\\\", \\\"{x:1500,y:655,t:1527030722869};\\\", \\\"{x:1512,y:616,t:1527030722884};\\\", \\\"{x:1518,y:586,t:1527030722901};\\\", \\\"{x:1535,y:532,t:1527030722919};\\\", \\\"{x:1547,y:502,t:1527030722935};\\\", \\\"{x:1562,y:475,t:1527030722952};\\\", \\\"{x:1576,y:456,t:1527030722969};\\\", \\\"{x:1592,y:436,t:1527030722985};\\\", \\\"{x:1604,y:419,t:1527030723001};\\\", \\\"{x:1612,y:410,t:1527030723018};\\\", \\\"{x:1618,y:402,t:1527030723034};\\\", \\\"{x:1625,y:394,t:1527030723051};\\\", \\\"{x:1632,y:389,t:1527030723068};\\\", \\\"{x:1635,y:386,t:1527030723085};\\\", \\\"{x:1639,y:383,t:1527030723101};\\\", \\\"{x:1640,y:382,t:1527030723118};\\\", \\\"{x:1640,y:383,t:1527030723455};\\\", \\\"{x:1637,y:384,t:1527030723469};\\\", \\\"{x:1632,y:386,t:1527030723486};\\\", \\\"{x:1626,y:389,t:1527030723502};\\\", \\\"{x:1603,y:405,t:1527030723519};\\\", \\\"{x:1584,y:420,t:1527030723536};\\\", \\\"{x:1568,y:431,t:1527030723552};\\\", \\\"{x:1557,y:438,t:1527030723569};\\\", \\\"{x:1543,y:446,t:1527030723586};\\\", \\\"{x:1529,y:451,t:1527030723602};\\\", \\\"{x:1503,y:463,t:1527030723619};\\\", \\\"{x:1464,y:478,t:1527030723636};\\\", \\\"{x:1392,y:496,t:1527030723652};\\\", \\\"{x:1314,y:520,t:1527030723669};\\\", \\\"{x:1228,y:535,t:1527030723686};\\\", \\\"{x:1157,y:548,t:1527030723702};\\\", \\\"{x:1041,y:568,t:1527030723719};\\\", \\\"{x:969,y:576,t:1527030723736};\\\", \\\"{x:905,y:587,t:1527030723753};\\\", \\\"{x:851,y:596,t:1527030723769};\\\", \\\"{x:820,y:602,t:1527030723786};\\\", \\\"{x:797,y:607,t:1527030723804};\\\", \\\"{x:772,y:614,t:1527030723821};\\\", \\\"{x:753,y:619,t:1527030723837};\\\", \\\"{x:736,y:628,t:1527030723853};\\\", \\\"{x:728,y:633,t:1527030723870};\\\", \\\"{x:722,y:636,t:1527030723887};\\\", \\\"{x:720,y:637,t:1527030723904};\\\", \\\"{x:718,y:639,t:1527030723920};\\\", \\\"{x:716,y:639,t:1527030723937};\\\", \\\"{x:714,y:640,t:1527030723966};\\\", \\\"{x:713,y:640,t:1527030723982};\\\", \\\"{x:711,y:641,t:1527030723990};\\\", \\\"{x:710,y:641,t:1527030724006};\\\", \\\"{x:707,y:641,t:1527030724021};\\\", \\\"{x:701,y:641,t:1527030724039};\\\", \\\"{x:694,y:641,t:1527030724054};\\\", \\\"{x:685,y:636,t:1527030724071};\\\", \\\"{x:677,y:629,t:1527030724089};\\\", \\\"{x:669,y:622,t:1527030724104};\\\", \\\"{x:660,y:612,t:1527030724120};\\\", \\\"{x:655,y:600,t:1527030724138};\\\", \\\"{x:651,y:582,t:1527030724155};\\\", \\\"{x:651,y:561,t:1527030724171};\\\", \\\"{x:652,y:545,t:1527030724188};\\\", \\\"{x:651,y:538,t:1527030724204};\\\", \\\"{x:647,y:532,t:1527030724222};\\\", \\\"{x:645,y:530,t:1527030724237};\\\", \\\"{x:644,y:530,t:1527030724286};\\\", \\\"{x:641,y:530,t:1527030724294};\\\", \\\"{x:638,y:530,t:1527030724304};\\\", \\\"{x:618,y:530,t:1527030724321};\\\", \\\"{x:590,y:537,t:1527030724338};\\\", \\\"{x:549,y:553,t:1527030724354};\\\", \\\"{x:522,y:562,t:1527030724372};\\\", \\\"{x:502,y:568,t:1527030724388};\\\", \\\"{x:487,y:573,t:1527030724405};\\\", \\\"{x:472,y:576,t:1527030724422};\\\", \\\"{x:458,y:578,t:1527030724437};\\\", \\\"{x:454,y:579,t:1527030724455};\\\", \\\"{x:453,y:579,t:1527030724527};\\\", \\\"{x:451,y:577,t:1527030724538};\\\", \\\"{x:446,y:568,t:1527030724555};\\\", \\\"{x:439,y:560,t:1527030724573};\\\", \\\"{x:431,y:552,t:1527030724589};\\\", \\\"{x:424,y:547,t:1527030724604};\\\", \\\"{x:418,y:544,t:1527030724621};\\\", \\\"{x:409,y:540,t:1527030724638};\\\", \\\"{x:402,y:537,t:1527030724654};\\\", \\\"{x:397,y:536,t:1527030724671};\\\", \\\"{x:396,y:536,t:1527030724688};\\\", \\\"{x:395,y:535,t:1527030724704};\\\", \\\"{x:394,y:535,t:1527030724775};\\\", \\\"{x:399,y:536,t:1527030725062};\\\", \\\"{x:402,y:537,t:1527030725071};\\\", \\\"{x:404,y:539,t:1527030725088};\\\", \\\"{x:406,y:543,t:1527030725105};\\\", \\\"{x:407,y:547,t:1527030725121};\\\", \\\"{x:407,y:551,t:1527030725139};\\\", \\\"{x:401,y:556,t:1527030725156};\\\", \\\"{x:396,y:560,t:1527030725171};\\\", \\\"{x:390,y:566,t:1527030725190};\\\", \\\"{x:384,y:575,t:1527030725205};\\\", \\\"{x:379,y:584,t:1527030725222};\\\", \\\"{x:376,y:593,t:1527030725239};\\\", \\\"{x:376,y:596,t:1527030725255};\\\", \\\"{x:376,y:599,t:1527030725271};\\\", \\\"{x:376,y:600,t:1527030725294};\\\", \\\"{x:376,y:601,t:1527030725305};\\\", \\\"{x:376,y:602,t:1527030725322};\\\", \\\"{x:376,y:605,t:1527030725339};\\\", \\\"{x:377,y:609,t:1527030725356};\\\", \\\"{x:381,y:615,t:1527030725371};\\\", \\\"{x:382,y:621,t:1527030725388};\\\", \\\"{x:384,y:623,t:1527030725405};\\\", \\\"{x:385,y:623,t:1527030725423};\\\", \\\"{x:387,y:626,t:1527030725766};\\\", \\\"{x:392,y:627,t:1527030725774};\\\", \\\"{x:393,y:630,t:1527030725789};\\\", \\\"{x:401,y:635,t:1527030725806};\\\", \\\"{x:415,y:644,t:1527030725823};\\\", \\\"{x:424,y:648,t:1527030725840};\\\", \\\"{x:433,y:655,t:1527030725855};\\\", \\\"{x:440,y:661,t:1527030725872};\\\", \\\"{x:442,y:666,t:1527030725889};\\\", \\\"{x:444,y:668,t:1527030725905};\\\", \\\"{x:446,y:670,t:1527030725923};\\\", \\\"{x:447,y:673,t:1527030725939};\\\", \\\"{x:449,y:678,t:1527030725956};\\\", \\\"{x:451,y:685,t:1527030725973};\\\", \\\"{x:453,y:689,t:1527030725990};\\\", \\\"{x:455,y:695,t:1527030726005};\\\", \\\"{x:458,y:703,t:1527030726022};\\\", \\\"{x:458,y:706,t:1527030726040};\\\", \\\"{x:459,y:707,t:1527030726055};\\\", \\\"{x:460,y:708,t:1527030726078};\\\", \\\"{x:460,y:709,t:1527030726090};\\\", \\\"{x:461,y:709,t:1527030726119};\\\", \\\"{x:461,y:710,t:1527030726126};\\\", \\\"{x:462,y:710,t:1527030726140};\\\", \\\"{x:465,y:714,t:1527030726156};\\\", \\\"{x:468,y:717,t:1527030726173};\\\", \\\"{x:469,y:721,t:1527030726191};\\\", \\\"{x:472,y:728,t:1527030726206};\\\", \\\"{x:475,y:733,t:1527030726222};\\\", \\\"{x:476,y:735,t:1527030726240};\\\", \\\"{x:477,y:736,t:1527030726311};\\\", \\\"{x:476,y:736,t:1527030727823};\\\", \\\"{x:475,y:736,t:1527030728031};\\\", \\\"{x:474,y:736,t:1527030728046};\\\", \\\"{x:473,y:736,t:1527030728058};\\\", \\\"{x:472,y:736,t:1527030728119};\\\", \\\"{x:469,y:736,t:1527030728159};\\\", \\\"{x:468,y:735,t:1527030728182};\\\", \\\"{x:467,y:735,t:1527030728199};\\\", \\\"{x:466,y:735,t:1527030728238};\\\", \\\"{x:465,y:735,t:1527030728255};\\\", \\\"{x:465,y:734,t:1527030728263};\\\", \\\"{x:464,y:734,t:1527030728286};\\\", \\\"{x:463,y:734,t:1527030728541};\\\", \\\"{x:462,y:733,t:1527030728557};\\\" ] }, { \\\"rt\\\": 11953, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 620215, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:461,y:733,t:1527030728934};\\\", \\\"{x:460,y:732,t:1527030728974};\\\", \\\"{x:458,y:731,t:1527030729189};\\\", \\\"{x:456,y:730,t:1527030729301};\\\", \\\"{x:455,y:730,t:1527030729358};\\\", \\\"{x:454,y:729,t:1527030729376};\\\", \\\"{x:453,y:729,t:1527030730135};\\\", \\\"{x:452,y:729,t:1527030730158};\\\", \\\"{x:451,y:729,t:1527030730223};\\\", \\\"{x:451,y:728,t:1527030730230};\\\", \\\"{x:450,y:728,t:1527030730575};\\\", \\\"{x:449,y:727,t:1527030730647};\\\", \\\"{x:448,y:726,t:1527030730719};\\\", \\\"{x:447,y:726,t:1527030731415};\\\", \\\"{x:446,y:726,t:1527030731455};\\\", \\\"{x:445,y:726,t:1527030731535};\\\", \\\"{x:444,y:725,t:1527030731546};\\\", \\\"{x:444,y:724,t:1527030731561};\\\", \\\"{x:444,y:721,t:1527030731578};\\\", \\\"{x:447,y:716,t:1527030731594};\\\", \\\"{x:454,y:706,t:1527030731610};\\\", \\\"{x:461,y:698,t:1527030731627};\\\", \\\"{x:468,y:687,t:1527030731643};\\\", \\\"{x:476,y:677,t:1527030731661};\\\", \\\"{x:484,y:664,t:1527030731678};\\\", \\\"{x:490,y:657,t:1527030731693};\\\", \\\"{x:497,y:648,t:1527030731710};\\\", \\\"{x:501,y:644,t:1527030731727};\\\", \\\"{x:502,y:643,t:1527030731744};\\\", \\\"{x:503,y:643,t:1527030731761};\\\", \\\"{x:505,y:642,t:1527030731776};\\\", \\\"{x:508,y:641,t:1527030731794};\\\", \\\"{x:510,y:639,t:1527030731811};\\\", \\\"{x:514,y:638,t:1527030731827};\\\", \\\"{x:518,y:636,t:1527030731844};\\\", \\\"{x:519,y:635,t:1527030731861};\\\", \\\"{x:523,y:634,t:1527030731877};\\\", \\\"{x:533,y:629,t:1527030731895};\\\", \\\"{x:550,y:622,t:1527030731911};\\\", \\\"{x:566,y:619,t:1527030731927};\\\", \\\"{x:585,y:613,t:1527030731945};\\\", \\\"{x:606,y:606,t:1527030731961};\\\", \\\"{x:636,y:597,t:1527030731978};\\\", \\\"{x:674,y:585,t:1527030731994};\\\", \\\"{x:707,y:569,t:1527030732010};\\\", \\\"{x:738,y:556,t:1527030732028};\\\", \\\"{x:763,y:546,t:1527030732044};\\\", \\\"{x:778,y:540,t:1527030732060};\\\", \\\"{x:802,y:528,t:1527030732078};\\\", \\\"{x:808,y:525,t:1527030732093};\\\", \\\"{x:812,y:522,t:1527030732111};\\\", \\\"{x:814,y:521,t:1527030732128};\\\", \\\"{x:816,y:519,t:1527030732144};\\\", \\\"{x:817,y:519,t:1527030732160};\\\", \\\"{x:819,y:518,t:1527030732182};\\\", \\\"{x:820,y:517,t:1527030732198};\\\", \\\"{x:822,y:516,t:1527030732210};\\\", \\\"{x:823,y:516,t:1527030732228};\\\", \\\"{x:818,y:516,t:1527030736511};\\\", \\\"{x:813,y:517,t:1527030736518};\\\", \\\"{x:809,y:520,t:1527030736534};\\\", \\\"{x:802,y:522,t:1527030736548};\\\", \\\"{x:797,y:525,t:1527030736565};\\\", \\\"{x:793,y:526,t:1527030736581};\\\", \\\"{x:785,y:530,t:1527030736597};\\\", \\\"{x:779,y:533,t:1527030736615};\\\", \\\"{x:773,y:535,t:1527030736630};\\\", \\\"{x:756,y:538,t:1527030736648};\\\", \\\"{x:741,y:540,t:1527030736664};\\\", \\\"{x:729,y:543,t:1527030736681};\\\", \\\"{x:717,y:543,t:1527030736699};\\\", \\\"{x:708,y:543,t:1527030736715};\\\", \\\"{x:703,y:543,t:1527030736731};\\\", \\\"{x:696,y:543,t:1527030736747};\\\", \\\"{x:688,y:544,t:1527030736765};\\\", \\\"{x:679,y:546,t:1527030736781};\\\", \\\"{x:671,y:547,t:1527030736798};\\\", \\\"{x:663,y:547,t:1527030736815};\\\", \\\"{x:655,y:547,t:1527030736832};\\\", \\\"{x:649,y:547,t:1527030736848};\\\", \\\"{x:643,y:547,t:1527030736865};\\\", \\\"{x:638,y:546,t:1527030736883};\\\", \\\"{x:635,y:546,t:1527030736898};\\\", \\\"{x:630,y:547,t:1527030736915};\\\", \\\"{x:627,y:547,t:1527030736932};\\\", \\\"{x:620,y:550,t:1527030736948};\\\", \\\"{x:613,y:552,t:1527030736966};\\\", \\\"{x:597,y:560,t:1527030736983};\\\", \\\"{x:580,y:566,t:1527030736998};\\\", \\\"{x:558,y:571,t:1527030737015};\\\", \\\"{x:541,y:572,t:1527030737031};\\\", \\\"{x:523,y:575,t:1527030737048};\\\", \\\"{x:507,y:575,t:1527030737065};\\\", \\\"{x:489,y:575,t:1527030737083};\\\", \\\"{x:470,y:575,t:1527030737098};\\\", \\\"{x:456,y:575,t:1527030737114};\\\", \\\"{x:445,y:575,t:1527030737131};\\\", \\\"{x:436,y:575,t:1527030737147};\\\", \\\"{x:427,y:575,t:1527030737165};\\\", \\\"{x:415,y:575,t:1527030737181};\\\", \\\"{x:410,y:575,t:1527030737198};\\\", \\\"{x:407,y:576,t:1527030737215};\\\", \\\"{x:404,y:576,t:1527030737232};\\\", \\\"{x:402,y:577,t:1527030737302};\\\", \\\"{x:400,y:577,t:1527030737318};\\\", \\\"{x:397,y:577,t:1527030737332};\\\", \\\"{x:388,y:576,t:1527030737350};\\\", \\\"{x:372,y:574,t:1527030737366};\\\", \\\"{x:340,y:573,t:1527030737383};\\\", \\\"{x:319,y:573,t:1527030737399};\\\", \\\"{x:304,y:573,t:1527030737415};\\\", \\\"{x:290,y:573,t:1527030737432};\\\", \\\"{x:273,y:573,t:1527030737449};\\\", \\\"{x:250,y:573,t:1527030737467};\\\", \\\"{x:224,y:573,t:1527030737482};\\\", \\\"{x:208,y:571,t:1527030737499};\\\", \\\"{x:201,y:570,t:1527030737515};\\\", \\\"{x:200,y:569,t:1527030737532};\\\", \\\"{x:199,y:569,t:1527030737751};\\\", \\\"{x:201,y:571,t:1527030737783};\\\", \\\"{x:204,y:575,t:1527030737798};\\\", \\\"{x:205,y:579,t:1527030737815};\\\", \\\"{x:205,y:582,t:1527030737832};\\\", \\\"{x:205,y:586,t:1527030737849};\\\", \\\"{x:202,y:592,t:1527030737865};\\\", \\\"{x:198,y:596,t:1527030737883};\\\", \\\"{x:194,y:600,t:1527030737899};\\\", \\\"{x:191,y:602,t:1527030737915};\\\", \\\"{x:190,y:602,t:1527030737932};\\\", \\\"{x:188,y:603,t:1527030737948};\\\", \\\"{x:186,y:605,t:1527030737966};\\\", \\\"{x:183,y:607,t:1527030737982};\\\", \\\"{x:178,y:609,t:1527030737999};\\\", \\\"{x:176,y:611,t:1527030738015};\\\", \\\"{x:174,y:613,t:1527030738032};\\\", \\\"{x:172,y:615,t:1527030738118};\\\", \\\"{x:171,y:616,t:1527030738133};\\\", \\\"{x:171,y:619,t:1527030738149};\\\", \\\"{x:171,y:623,t:1527030738166};\\\", \\\"{x:172,y:626,t:1527030738183};\\\", \\\"{x:179,y:626,t:1527030738199};\\\", \\\"{x:194,y:626,t:1527030738216};\\\", \\\"{x:216,y:621,t:1527030738233};\\\", \\\"{x:249,y:611,t:1527030738249};\\\", \\\"{x:287,y:608,t:1527030738266};\\\", \\\"{x:323,y:604,t:1527030738282};\\\", \\\"{x:353,y:602,t:1527030738299};\\\", \\\"{x:376,y:602,t:1527030738316};\\\", \\\"{x:383,y:602,t:1527030738333};\\\", \\\"{x:386,y:602,t:1527030738349};\\\", \\\"{x:389,y:603,t:1527030738366};\\\", \\\"{x:390,y:603,t:1527030738383};\\\", \\\"{x:398,y:603,t:1527030738399};\\\", \\\"{x:410,y:603,t:1527030738416};\\\", \\\"{x:430,y:604,t:1527030738433};\\\", \\\"{x:446,y:605,t:1527030738449};\\\", \\\"{x:466,y:608,t:1527030738465};\\\", \\\"{x:485,y:610,t:1527030738483};\\\", \\\"{x:512,y:612,t:1527030738500};\\\", \\\"{x:555,y:612,t:1527030738516};\\\", \\\"{x:621,y:612,t:1527030738533};\\\", \\\"{x:663,y:612,t:1527030738549};\\\", \\\"{x:694,y:616,t:1527030738566};\\\", \\\"{x:701,y:616,t:1527030738583};\\\", \\\"{x:702,y:616,t:1527030738598};\\\", \\\"{x:704,y:616,t:1527030738616};\\\", \\\"{x:705,y:616,t:1527030738633};\\\", \\\"{x:707,y:616,t:1527030738718};\\\", \\\"{x:708,y:615,t:1527030738734};\\\", \\\"{x:709,y:614,t:1527030738749};\\\", \\\"{x:710,y:614,t:1527030738766};\\\", \\\"{x:709,y:614,t:1527030738878};\\\", \\\"{x:707,y:614,t:1527030738886};\\\", \\\"{x:706,y:608,t:1527030738943};\\\", \\\"{x:706,y:603,t:1527030738950};\\\", \\\"{x:715,y:586,t:1527030738968};\\\", \\\"{x:724,y:573,t:1527030738985};\\\", \\\"{x:732,y:562,t:1527030739001};\\\", \\\"{x:739,y:554,t:1527030739017};\\\", \\\"{x:747,y:550,t:1527030739033};\\\", \\\"{x:756,y:547,t:1527030739049};\\\", \\\"{x:765,y:545,t:1527030739066};\\\", \\\"{x:770,y:545,t:1527030739083};\\\", \\\"{x:774,y:543,t:1527030739100};\\\", \\\"{x:777,y:542,t:1527030739116};\\\", \\\"{x:779,y:542,t:1527030739133};\\\", \\\"{x:783,y:540,t:1527030739149};\\\", \\\"{x:789,y:540,t:1527030739166};\\\", \\\"{x:797,y:539,t:1527030739183};\\\", \\\"{x:805,y:536,t:1527030739200};\\\", \\\"{x:809,y:534,t:1527030739216};\\\", \\\"{x:812,y:534,t:1527030739233};\\\", \\\"{x:816,y:534,t:1527030739249};\\\", \\\"{x:820,y:534,t:1527030739266};\\\", \\\"{x:824,y:534,t:1527030739284};\\\", \\\"{x:826,y:534,t:1527030739299};\\\", \\\"{x:827,y:534,t:1527030739621};\\\", \\\"{x:827,y:536,t:1527030739634};\\\", \\\"{x:814,y:547,t:1527030739650};\\\", \\\"{x:797,y:565,t:1527030739667};\\\", \\\"{x:771,y:585,t:1527030739684};\\\", \\\"{x:749,y:601,t:1527030739700};\\\", \\\"{x:729,y:619,t:1527030739717};\\\", \\\"{x:704,y:633,t:1527030739734};\\\", \\\"{x:691,y:642,t:1527030739750};\\\", \\\"{x:677,y:649,t:1527030739766};\\\", \\\"{x:666,y:654,t:1527030739784};\\\", \\\"{x:655,y:661,t:1527030739800};\\\", \\\"{x:643,y:667,t:1527030739816};\\\", \\\"{x:629,y:672,t:1527030739834};\\\", \\\"{x:613,y:674,t:1527030739851};\\\", \\\"{x:599,y:679,t:1527030739867};\\\", \\\"{x:581,y:681,t:1527030739884};\\\", \\\"{x:569,y:683,t:1527030739901};\\\", \\\"{x:565,y:684,t:1527030739917};\\\", \\\"{x:563,y:685,t:1527030739934};\\\", \\\"{x:562,y:686,t:1527030739951};\\\", \\\"{x:560,y:686,t:1527030739968};\\\", \\\"{x:559,y:686,t:1527030739991};\\\", \\\"{x:558,y:687,t:1527030740002};\\\", \\\"{x:557,y:688,t:1527030740016};\\\", \\\"{x:555,y:690,t:1527030740033};\\\", \\\"{x:551,y:694,t:1527030740051};\\\", \\\"{x:548,y:700,t:1527030740067};\\\", \\\"{x:542,y:711,t:1527030740084};\\\", \\\"{x:532,y:727,t:1527030740102};\\\", \\\"{x:522,y:741,t:1527030740117};\\\", \\\"{x:511,y:757,t:1527030740134};\\\", \\\"{x:508,y:761,t:1527030740151};\\\", \\\"{x:506,y:763,t:1527030740167};\\\", \\\"{x:505,y:764,t:1527030740184};\\\", \\\"{x:504,y:764,t:1527030740230};\\\", \\\"{x:503,y:764,t:1527030740246};\\\", \\\"{x:502,y:764,t:1527030740278};\\\", \\\"{x:501,y:764,t:1527030740294};\\\", \\\"{x:499,y:763,t:1527030740310};\\\", \\\"{x:497,y:762,t:1527030740319};\\\", \\\"{x:495,y:756,t:1527030740335};\\\", \\\"{x:495,y:750,t:1527030740352};\\\", \\\"{x:495,y:748,t:1527030740367};\\\", \\\"{x:495,y:746,t:1527030740384};\\\", \\\"{x:495,y:742,t:1527030740401};\\\", \\\"{x:495,y:740,t:1527030740418};\\\", \\\"{x:495,y:737,t:1527030740434};\\\", \\\"{x:495,y:735,t:1527030741350};\\\", \\\"{x:495,y:734,t:1527030741374};\\\", \\\"{x:494,y:733,t:1527030741385};\\\", \\\"{x:494,y:732,t:1527030741503};\\\" ] }, { \\\"rt\\\": 24320, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 645785, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:731,t:1527030743718};\\\", \\\"{x:494,y:730,t:1527030743754};\\\", \\\"{x:494,y:729,t:1527030743789};\\\", \\\"{x:494,y:728,t:1527030743918};\\\", \\\"{x:494,y:727,t:1527030744014};\\\", \\\"{x:494,y:726,t:1527030745118};\\\", \\\"{x:494,y:725,t:1527030745134};\\\", \\\"{x:494,y:724,t:1527030745152};\\\", \\\"{x:494,y:723,t:1527030745168};\\\", \\\"{x:494,y:722,t:1527030745519};\\\", \\\"{x:495,y:720,t:1527030745694};\\\", \\\"{x:497,y:719,t:1527030745703};\\\", \\\"{x:498,y:719,t:1527030745717};\\\", \\\"{x:499,y:718,t:1527030745733};\\\", \\\"{x:501,y:716,t:1527030745755};\\\", \\\"{x:503,y:714,t:1527030745771};\\\", \\\"{x:505,y:713,t:1527030745788};\\\", \\\"{x:510,y:711,t:1527030745805};\\\", \\\"{x:524,y:705,t:1527030745821};\\\", \\\"{x:536,y:701,t:1527030745838};\\\", \\\"{x:569,y:694,t:1527030745855};\\\", \\\"{x:636,y:685,t:1527030745873};\\\", \\\"{x:737,y:677,t:1527030745888};\\\", \\\"{x:859,y:677,t:1527030745906};\\\", \\\"{x:992,y:675,t:1527030745922};\\\", \\\"{x:1130,y:675,t:1527030745939};\\\", \\\"{x:1260,y:675,t:1527030745955};\\\", \\\"{x:1355,y:675,t:1527030745972};\\\", \\\"{x:1396,y:675,t:1527030745988};\\\", \\\"{x:1413,y:675,t:1527030746006};\\\", \\\"{x:1414,y:675,t:1527030746022};\\\", \\\"{x:1415,y:675,t:1527030746039};\\\", \\\"{x:1416,y:677,t:1527030746056};\\\", \\\"{x:1418,y:681,t:1527030746073};\\\", \\\"{x:1422,y:686,t:1527030746089};\\\", \\\"{x:1430,y:690,t:1527030746105};\\\", \\\"{x:1442,y:693,t:1527030746122};\\\", \\\"{x:1461,y:697,t:1527030746138};\\\", \\\"{x:1486,y:700,t:1527030746155};\\\", \\\"{x:1521,y:704,t:1527030746172};\\\", \\\"{x:1546,y:710,t:1527030746189};\\\", \\\"{x:1565,y:715,t:1527030746205};\\\", \\\"{x:1586,y:723,t:1527030746222};\\\", \\\"{x:1597,y:725,t:1527030746239};\\\", \\\"{x:1605,y:728,t:1527030746255};\\\", \\\"{x:1606,y:729,t:1527030746272};\\\", \\\"{x:1612,y:729,t:1527030746289};\\\", \\\"{x:1622,y:731,t:1527030746306};\\\", \\\"{x:1628,y:731,t:1527030746323};\\\", \\\"{x:1635,y:731,t:1527030746339};\\\", \\\"{x:1639,y:730,t:1527030746355};\\\", \\\"{x:1641,y:730,t:1527030746373};\\\", \\\"{x:1642,y:730,t:1527030746406};\\\", \\\"{x:1643,y:729,t:1527030746527};\\\", \\\"{x:1642,y:728,t:1527030746540};\\\", \\\"{x:1637,y:719,t:1527030746556};\\\", \\\"{x:1632,y:713,t:1527030746572};\\\", \\\"{x:1626,y:707,t:1527030746590};\\\", \\\"{x:1614,y:698,t:1527030746609};\\\", \\\"{x:1609,y:694,t:1527030746622};\\\", \\\"{x:1605,y:692,t:1527030746640};\\\", \\\"{x:1602,y:690,t:1527030746655};\\\", \\\"{x:1602,y:689,t:1527030746672};\\\", \\\"{x:1601,y:689,t:1527030746910};\\\", \\\"{x:1600,y:689,t:1527030746923};\\\", \\\"{x:1600,y:690,t:1527030746939};\\\", \\\"{x:1600,y:691,t:1527030746957};\\\", \\\"{x:1600,y:692,t:1527030746973};\\\", \\\"{x:1600,y:695,t:1527030746990};\\\", \\\"{x:1600,y:697,t:1527030747007};\\\", \\\"{x:1600,y:698,t:1527030747023};\\\", \\\"{x:1599,y:703,t:1527030747040};\\\", \\\"{x:1598,y:705,t:1527030747057};\\\", \\\"{x:1596,y:708,t:1527030747073};\\\", \\\"{x:1595,y:710,t:1527030747089};\\\", \\\"{x:1593,y:712,t:1527030747107};\\\", \\\"{x:1588,y:719,t:1527030747122};\\\", \\\"{x:1584,y:727,t:1527030747140};\\\", \\\"{x:1580,y:734,t:1527030747157};\\\", \\\"{x:1574,y:745,t:1527030747173};\\\", \\\"{x:1570,y:752,t:1527030747190};\\\", \\\"{x:1564,y:766,t:1527030747207};\\\", \\\"{x:1560,y:776,t:1527030747223};\\\", \\\"{x:1554,y:791,t:1527030747240};\\\", \\\"{x:1546,y:807,t:1527030747257};\\\", \\\"{x:1539,y:824,t:1527030747273};\\\", \\\"{x:1531,y:844,t:1527030747290};\\\", \\\"{x:1522,y:861,t:1527030747307};\\\", \\\"{x:1517,y:875,t:1527030747323};\\\", \\\"{x:1510,y:888,t:1527030747340};\\\", \\\"{x:1501,y:901,t:1527030747358};\\\", \\\"{x:1497,y:910,t:1527030747374};\\\", \\\"{x:1494,y:917,t:1527030747391};\\\", \\\"{x:1494,y:920,t:1527030747406};\\\", \\\"{x:1494,y:923,t:1527030747424};\\\", \\\"{x:1494,y:925,t:1527030747440};\\\", \\\"{x:1494,y:926,t:1527030747457};\\\", \\\"{x:1494,y:927,t:1527030747473};\\\", \\\"{x:1494,y:928,t:1527030747489};\\\", \\\"{x:1494,y:929,t:1527030747506};\\\", \\\"{x:1494,y:930,t:1527030747523};\\\", \\\"{x:1494,y:932,t:1527030747539};\\\", \\\"{x:1494,y:933,t:1527030747556};\\\", \\\"{x:1494,y:936,t:1527030747573};\\\", \\\"{x:1494,y:938,t:1527030747589};\\\", \\\"{x:1493,y:942,t:1527030747606};\\\", \\\"{x:1491,y:945,t:1527030747624};\\\", \\\"{x:1490,y:948,t:1527030747640};\\\", \\\"{x:1490,y:949,t:1527030747657};\\\", \\\"{x:1489,y:952,t:1527030747673};\\\", \\\"{x:1487,y:955,t:1527030747690};\\\", \\\"{x:1485,y:959,t:1527030747706};\\\", \\\"{x:1482,y:963,t:1527030747724};\\\", \\\"{x:1481,y:964,t:1527030747741};\\\", \\\"{x:1480,y:966,t:1527030747757};\\\", \\\"{x:1478,y:967,t:1527030747774};\\\", \\\"{x:1477,y:967,t:1527030747790};\\\", \\\"{x:1476,y:968,t:1527030747807};\\\", \\\"{x:1474,y:968,t:1527030747823};\\\", \\\"{x:1473,y:968,t:1527030747841};\\\", \\\"{x:1471,y:968,t:1527030747862};\\\", \\\"{x:1470,y:968,t:1527030747878};\\\", \\\"{x:1469,y:968,t:1527030747895};\\\", \\\"{x:1468,y:967,t:1527030747906};\\\", \\\"{x:1468,y:962,t:1527030747924};\\\", \\\"{x:1468,y:958,t:1527030747941};\\\", \\\"{x:1468,y:951,t:1527030747956};\\\", \\\"{x:1472,y:939,t:1527030747973};\\\", \\\"{x:1483,y:921,t:1527030747991};\\\", \\\"{x:1489,y:910,t:1527030748007};\\\", \\\"{x:1498,y:899,t:1527030748024};\\\", \\\"{x:1502,y:892,t:1527030748041};\\\", \\\"{x:1507,y:883,t:1527030748057};\\\", \\\"{x:1511,y:878,t:1527030748074};\\\", \\\"{x:1512,y:875,t:1527030748091};\\\", \\\"{x:1515,y:871,t:1527030748107};\\\", \\\"{x:1516,y:868,t:1527030748124};\\\", \\\"{x:1518,y:865,t:1527030748141};\\\", \\\"{x:1520,y:861,t:1527030748157};\\\", \\\"{x:1522,y:859,t:1527030748174};\\\", \\\"{x:1525,y:852,t:1527030748191};\\\", \\\"{x:1526,y:847,t:1527030748207};\\\", \\\"{x:1530,y:839,t:1527030748223};\\\", \\\"{x:1537,y:825,t:1527030748240};\\\", \\\"{x:1544,y:813,t:1527030748257};\\\", \\\"{x:1548,y:806,t:1527030748273};\\\", \\\"{x:1553,y:800,t:1527030748290};\\\", \\\"{x:1556,y:796,t:1527030748308};\\\", \\\"{x:1559,y:792,t:1527030748324};\\\", \\\"{x:1562,y:788,t:1527030748340};\\\", \\\"{x:1566,y:781,t:1527030748357};\\\", \\\"{x:1572,y:775,t:1527030748374};\\\", \\\"{x:1575,y:772,t:1527030748390};\\\", \\\"{x:1580,y:766,t:1527030748408};\\\", \\\"{x:1586,y:759,t:1527030748424};\\\", \\\"{x:1590,y:753,t:1527030748440};\\\", \\\"{x:1593,y:744,t:1527030748458};\\\", \\\"{x:1599,y:736,t:1527030748473};\\\", \\\"{x:1603,y:730,t:1527030748491};\\\", \\\"{x:1607,y:725,t:1527030748508};\\\", \\\"{x:1612,y:717,t:1527030748524};\\\", \\\"{x:1615,y:712,t:1527030748541};\\\", \\\"{x:1627,y:693,t:1527030748558};\\\", \\\"{x:1634,y:680,t:1527030748574};\\\", \\\"{x:1645,y:665,t:1527030748591};\\\", \\\"{x:1653,y:651,t:1527030748608};\\\", \\\"{x:1661,y:639,t:1527030748624};\\\", \\\"{x:1666,y:631,t:1527030748641};\\\", \\\"{x:1668,y:620,t:1527030748658};\\\", \\\"{x:1673,y:611,t:1527030748673};\\\", \\\"{x:1679,y:601,t:1527030748690};\\\", \\\"{x:1681,y:596,t:1527030748707};\\\", \\\"{x:1685,y:590,t:1527030748724};\\\", \\\"{x:1686,y:585,t:1527030748741};\\\", \\\"{x:1688,y:581,t:1527030748757};\\\", \\\"{x:1692,y:574,t:1527030748773};\\\", \\\"{x:1692,y:571,t:1527030748790};\\\", \\\"{x:1693,y:570,t:1527030748807};\\\", \\\"{x:1693,y:569,t:1527030748825};\\\", \\\"{x:1693,y:568,t:1527030748841};\\\", \\\"{x:1693,y:567,t:1527030750671};\\\", \\\"{x:1692,y:567,t:1527030750678};\\\", \\\"{x:1691,y:567,t:1527030750693};\\\", \\\"{x:1689,y:568,t:1527030750709};\\\", \\\"{x:1688,y:568,t:1527030750726};\\\", \\\"{x:1687,y:568,t:1527030750743};\\\", \\\"{x:1686,y:568,t:1527030750759};\\\", \\\"{x:1685,y:569,t:1527030750776};\\\", \\\"{x:1684,y:570,t:1527030750806};\\\", \\\"{x:1682,y:571,t:1527030750823};\\\", \\\"{x:1682,y:572,t:1527030750830};\\\", \\\"{x:1680,y:572,t:1527030750842};\\\", \\\"{x:1677,y:574,t:1527030750859};\\\", \\\"{x:1676,y:575,t:1527030750876};\\\", \\\"{x:1674,y:575,t:1527030750893};\\\", \\\"{x:1673,y:576,t:1527030751014};\\\", \\\"{x:1672,y:578,t:1527030751026};\\\", \\\"{x:1671,y:591,t:1527030751043};\\\", \\\"{x:1671,y:609,t:1527030751059};\\\", \\\"{x:1675,y:622,t:1527030751076};\\\", \\\"{x:1685,y:640,t:1527030751093};\\\", \\\"{x:1700,y:658,t:1527030751113};\\\", \\\"{x:1706,y:664,t:1527030751126};\\\", \\\"{x:1708,y:665,t:1527030751142};\\\", \\\"{x:1709,y:668,t:1527030751159};\\\", \\\"{x:1710,y:670,t:1527030751175};\\\", \\\"{x:1711,y:674,t:1527030751193};\\\", \\\"{x:1711,y:677,t:1527030751210};\\\", \\\"{x:1711,y:681,t:1527030751226};\\\", \\\"{x:1711,y:683,t:1527030751242};\\\", \\\"{x:1711,y:686,t:1527030751259};\\\", \\\"{x:1710,y:689,t:1527030751276};\\\", \\\"{x:1704,y:694,t:1527030751293};\\\", \\\"{x:1695,y:705,t:1527030751310};\\\", \\\"{x:1689,y:712,t:1527030751326};\\\", \\\"{x:1684,y:718,t:1527030751343};\\\", \\\"{x:1677,y:726,t:1527030751360};\\\", \\\"{x:1667,y:734,t:1527030751376};\\\", \\\"{x:1653,y:747,t:1527030751393};\\\", \\\"{x:1640,y:758,t:1527030751410};\\\", \\\"{x:1630,y:771,t:1527030751426};\\\", \\\"{x:1619,y:788,t:1527030751444};\\\", \\\"{x:1608,y:802,t:1527030751460};\\\", \\\"{x:1597,y:822,t:1527030751476};\\\", \\\"{x:1589,y:842,t:1527030751493};\\\", \\\"{x:1576,y:870,t:1527030751510};\\\", \\\"{x:1568,y:887,t:1527030751526};\\\", \\\"{x:1556,y:906,t:1527030751542};\\\", \\\"{x:1544,y:923,t:1527030751560};\\\", \\\"{x:1535,y:935,t:1527030751576};\\\", \\\"{x:1527,y:944,t:1527030751592};\\\", \\\"{x:1521,y:949,t:1527030751610};\\\", \\\"{x:1516,y:951,t:1527030751626};\\\", \\\"{x:1514,y:952,t:1527030751642};\\\", \\\"{x:1512,y:953,t:1527030751660};\\\", \\\"{x:1511,y:955,t:1527030751677};\\\", \\\"{x:1509,y:955,t:1527030751693};\\\", \\\"{x:1509,y:956,t:1527030751710};\\\", \\\"{x:1508,y:956,t:1527030751742};\\\", \\\"{x:1506,y:956,t:1527030751760};\\\", \\\"{x:1505,y:956,t:1527030751797};\\\", \\\"{x:1504,y:955,t:1527030751809};\\\", \\\"{x:1502,y:954,t:1527030751826};\\\", \\\"{x:1499,y:952,t:1527030751842};\\\", \\\"{x:1496,y:949,t:1527030751860};\\\", \\\"{x:1494,y:944,t:1527030751876};\\\", \\\"{x:1491,y:939,t:1527030751892};\\\", \\\"{x:1489,y:933,t:1527030751909};\\\", \\\"{x:1488,y:928,t:1527030751927};\\\", \\\"{x:1487,y:926,t:1527030751943};\\\", \\\"{x:1487,y:924,t:1527030751959};\\\", \\\"{x:1486,y:922,t:1527030751977};\\\", \\\"{x:1486,y:919,t:1527030751993};\\\", \\\"{x:1486,y:918,t:1527030752010};\\\", \\\"{x:1485,y:916,t:1527030752027};\\\", \\\"{x:1485,y:915,t:1527030752044};\\\", \\\"{x:1485,y:914,t:1527030752060};\\\", \\\"{x:1485,y:913,t:1527030752077};\\\", \\\"{x:1484,y:911,t:1527030752103};\\\", \\\"{x:1484,y:910,t:1527030752110};\\\", \\\"{x:1484,y:909,t:1527030752134};\\\", \\\"{x:1484,y:907,t:1527030752149};\\\", \\\"{x:1484,y:906,t:1527030752166};\\\", \\\"{x:1484,y:904,t:1527030752182};\\\", \\\"{x:1484,y:903,t:1527030752198};\\\", \\\"{x:1484,y:901,t:1527030752209};\\\", \\\"{x:1484,y:900,t:1527030752227};\\\", \\\"{x:1484,y:898,t:1527030752244};\\\", \\\"{x:1484,y:895,t:1527030752260};\\\", \\\"{x:1484,y:893,t:1527030752276};\\\", \\\"{x:1485,y:887,t:1527030752293};\\\", \\\"{x:1486,y:884,t:1527030752310};\\\", \\\"{x:1486,y:881,t:1527030752327};\\\", \\\"{x:1486,y:879,t:1527030752344};\\\", \\\"{x:1489,y:876,t:1527030752360};\\\", \\\"{x:1489,y:874,t:1527030752376};\\\", \\\"{x:1489,y:873,t:1527030752394};\\\", \\\"{x:1490,y:870,t:1527030752410};\\\", \\\"{x:1491,y:867,t:1527030752426};\\\", \\\"{x:1492,y:864,t:1527030752444};\\\", \\\"{x:1493,y:862,t:1527030752460};\\\", \\\"{x:1493,y:861,t:1527030752477};\\\", \\\"{x:1495,y:857,t:1527030752494};\\\", \\\"{x:1496,y:856,t:1527030752526};\\\", \\\"{x:1497,y:855,t:1527030752551};\\\", \\\"{x:1497,y:854,t:1527030752560};\\\", \\\"{x:1498,y:853,t:1527030752577};\\\", \\\"{x:1498,y:852,t:1527030752623};\\\", \\\"{x:1499,y:851,t:1527030752646};\\\", \\\"{x:1499,y:850,t:1527030752687};\\\", \\\"{x:1500,y:848,t:1527030752783};\\\", \\\"{x:1501,y:847,t:1527030752798};\\\", \\\"{x:1502,y:846,t:1527030752854};\\\", \\\"{x:1504,y:844,t:1527030752887};\\\", \\\"{x:1504,y:843,t:1527030752926};\\\", \\\"{x:1505,y:842,t:1527030752958};\\\", \\\"{x:1505,y:841,t:1527030752982};\\\", \\\"{x:1506,y:841,t:1527030752999};\\\", \\\"{x:1507,y:840,t:1527030753014};\\\", \\\"{x:1508,y:840,t:1527030753028};\\\", \\\"{x:1509,y:839,t:1527030753044};\\\", \\\"{x:1510,y:838,t:1527030753061};\\\", \\\"{x:1514,y:835,t:1527030753078};\\\", \\\"{x:1518,y:832,t:1527030753094};\\\", \\\"{x:1520,y:831,t:1527030753112};\\\", \\\"{x:1521,y:831,t:1527030753128};\\\", \\\"{x:1523,y:829,t:1527030753145};\\\", \\\"{x:1523,y:828,t:1527030753161};\\\", \\\"{x:1525,y:828,t:1527030753178};\\\", \\\"{x:1528,y:825,t:1527030753194};\\\", \\\"{x:1535,y:819,t:1527030753211};\\\", \\\"{x:1546,y:812,t:1527030753229};\\\", \\\"{x:1559,y:801,t:1527030753244};\\\", \\\"{x:1575,y:790,t:1527030753261};\\\", \\\"{x:1597,y:778,t:1527030753278};\\\", \\\"{x:1612,y:770,t:1527030753294};\\\", \\\"{x:1620,y:764,t:1527030753311};\\\", \\\"{x:1624,y:761,t:1527030753328};\\\", \\\"{x:1628,y:757,t:1527030753344};\\\", \\\"{x:1630,y:755,t:1527030753361};\\\", \\\"{x:1633,y:753,t:1527030753378};\\\", \\\"{x:1637,y:749,t:1527030753394};\\\", \\\"{x:1638,y:748,t:1527030753411};\\\", \\\"{x:1642,y:746,t:1527030753428};\\\", \\\"{x:1644,y:744,t:1527030753445};\\\", \\\"{x:1646,y:742,t:1527030753461};\\\", \\\"{x:1650,y:740,t:1527030753478};\\\", \\\"{x:1651,y:739,t:1527030753495};\\\", \\\"{x:1653,y:737,t:1527030753511};\\\", \\\"{x:1655,y:735,t:1527030753528};\\\", \\\"{x:1658,y:733,t:1527030753545};\\\", \\\"{x:1660,y:732,t:1527030753562};\\\", \\\"{x:1662,y:731,t:1527030753579};\\\", \\\"{x:1663,y:729,t:1527030753595};\\\", \\\"{x:1664,y:729,t:1527030753614};\\\", \\\"{x:1667,y:728,t:1527030753630};\\\", \\\"{x:1668,y:726,t:1527030753645};\\\", \\\"{x:1670,y:724,t:1527030753661};\\\", \\\"{x:1674,y:721,t:1527030753678};\\\", \\\"{x:1675,y:720,t:1527030753695};\\\", \\\"{x:1676,y:718,t:1527030753711};\\\", \\\"{x:1677,y:716,t:1527030753728};\\\", \\\"{x:1678,y:715,t:1527030753745};\\\", \\\"{x:1678,y:714,t:1527030753918};\\\", \\\"{x:1679,y:713,t:1527030754031};\\\", \\\"{x:1680,y:712,t:1527030754046};\\\", \\\"{x:1681,y:709,t:1527030754062};\\\", \\\"{x:1681,y:705,t:1527030754078};\\\", \\\"{x:1681,y:703,t:1527030754095};\\\", \\\"{x:1681,y:699,t:1527030754112};\\\", \\\"{x:1682,y:697,t:1527030754128};\\\", \\\"{x:1682,y:696,t:1527030754145};\\\", \\\"{x:1683,y:693,t:1527030754162};\\\", \\\"{x:1683,y:691,t:1527030754178};\\\", \\\"{x:1684,y:687,t:1527030754196};\\\", \\\"{x:1684,y:686,t:1527030754212};\\\", \\\"{x:1685,y:684,t:1527030754228};\\\", \\\"{x:1685,y:683,t:1527030754245};\\\", \\\"{x:1687,y:680,t:1527030754262};\\\", \\\"{x:1688,y:678,t:1527030754278};\\\", \\\"{x:1688,y:676,t:1527030754295};\\\", \\\"{x:1688,y:674,t:1527030754312};\\\", \\\"{x:1690,y:671,t:1527030754328};\\\", \\\"{x:1691,y:670,t:1527030754345};\\\", \\\"{x:1691,y:669,t:1527030754362};\\\", \\\"{x:1689,y:671,t:1527030754463};\\\", \\\"{x:1681,y:674,t:1527030754479};\\\", \\\"{x:1677,y:677,t:1527030754495};\\\", \\\"{x:1674,y:680,t:1527030754513};\\\", \\\"{x:1672,y:681,t:1527030754529};\\\", \\\"{x:1671,y:682,t:1527030754545};\\\", \\\"{x:1670,y:684,t:1527030754563};\\\", \\\"{x:1670,y:685,t:1527030754582};\\\", \\\"{x:1669,y:687,t:1527030754598};\\\", \\\"{x:1669,y:689,t:1527030754613};\\\", \\\"{x:1665,y:695,t:1527030754629};\\\", \\\"{x:1662,y:700,t:1527030754645};\\\", \\\"{x:1657,y:710,t:1527030754662};\\\", \\\"{x:1649,y:722,t:1527030754679};\\\", \\\"{x:1643,y:737,t:1527030754695};\\\", \\\"{x:1632,y:756,t:1527030754712};\\\", \\\"{x:1620,y:775,t:1527030754730};\\\", \\\"{x:1609,y:795,t:1527030754745};\\\", \\\"{x:1595,y:816,t:1527030754762};\\\", \\\"{x:1582,y:833,t:1527030754779};\\\", \\\"{x:1571,y:848,t:1527030754796};\\\", \\\"{x:1565,y:860,t:1527030754812};\\\", \\\"{x:1558,y:869,t:1527030754830};\\\", \\\"{x:1547,y:882,t:1527030754846};\\\", \\\"{x:1543,y:888,t:1527030754862};\\\", \\\"{x:1541,y:891,t:1527030754879};\\\", \\\"{x:1541,y:892,t:1527030754896};\\\", \\\"{x:1539,y:895,t:1527030754912};\\\", \\\"{x:1537,y:896,t:1527030754929};\\\", \\\"{x:1536,y:898,t:1527030754947};\\\", \\\"{x:1535,y:900,t:1527030754962};\\\", \\\"{x:1533,y:902,t:1527030754979};\\\", \\\"{x:1532,y:903,t:1527030754996};\\\", \\\"{x:1530,y:905,t:1527030755012};\\\", \\\"{x:1529,y:907,t:1527030755030};\\\", \\\"{x:1523,y:913,t:1527030755046};\\\", \\\"{x:1522,y:916,t:1527030755062};\\\", \\\"{x:1518,y:922,t:1527030755079};\\\", \\\"{x:1515,y:925,t:1527030755096};\\\", \\\"{x:1512,y:928,t:1527030755113};\\\", \\\"{x:1510,y:931,t:1527030755129};\\\", \\\"{x:1508,y:933,t:1527030755146};\\\", \\\"{x:1507,y:935,t:1527030755162};\\\", \\\"{x:1504,y:938,t:1527030755179};\\\", \\\"{x:1501,y:940,t:1527030755196};\\\", \\\"{x:1499,y:942,t:1527030755212};\\\", \\\"{x:1497,y:945,t:1527030755229};\\\", \\\"{x:1496,y:946,t:1527030755246};\\\", \\\"{x:1495,y:946,t:1527030755278};\\\", \\\"{x:1494,y:948,t:1527030755296};\\\", \\\"{x:1493,y:948,t:1527030755313};\\\", \\\"{x:1491,y:949,t:1527030755329};\\\", \\\"{x:1490,y:950,t:1527030755346};\\\", \\\"{x:1489,y:951,t:1527030755363};\\\", \\\"{x:1488,y:952,t:1527030755379};\\\", \\\"{x:1486,y:953,t:1527030755415};\\\", \\\"{x:1486,y:954,t:1527030755438};\\\", \\\"{x:1485,y:954,t:1527030755446};\\\", \\\"{x:1485,y:955,t:1527030755463};\\\", \\\"{x:1483,y:955,t:1527030755534};\\\", \\\"{x:1482,y:955,t:1527030755558};\\\", \\\"{x:1480,y:955,t:1527030755574};\\\", \\\"{x:1479,y:954,t:1527030755590};\\\", \\\"{x:1479,y:952,t:1527030755599};\\\", \\\"{x:1479,y:951,t:1527030755613};\\\", \\\"{x:1479,y:944,t:1527030755630};\\\", \\\"{x:1483,y:930,t:1527030755646};\\\", \\\"{x:1489,y:919,t:1527030755663};\\\", \\\"{x:1497,y:906,t:1527030755680};\\\", \\\"{x:1506,y:889,t:1527030755696};\\\", \\\"{x:1523,y:865,t:1527030755713};\\\", \\\"{x:1541,y:836,t:1527030755730};\\\", \\\"{x:1554,y:815,t:1527030755746};\\\", \\\"{x:1572,y:792,t:1527030755764};\\\", \\\"{x:1584,y:777,t:1527030755780};\\\", \\\"{x:1593,y:768,t:1527030755796};\\\", \\\"{x:1599,y:758,t:1527030755814};\\\", \\\"{x:1607,y:746,t:1527030755831};\\\", \\\"{x:1610,y:739,t:1527030755845};\\\", \\\"{x:1614,y:734,t:1527030755862};\\\", \\\"{x:1618,y:729,t:1527030755879};\\\", \\\"{x:1623,y:723,t:1527030755896};\\\", \\\"{x:1628,y:714,t:1527030755912};\\\", \\\"{x:1632,y:710,t:1527030755929};\\\", \\\"{x:1635,y:706,t:1527030755946};\\\", \\\"{x:1636,y:702,t:1527030755962};\\\", \\\"{x:1637,y:702,t:1527030755980};\\\", \\\"{x:1638,y:701,t:1527030755996};\\\", \\\"{x:1631,y:703,t:1527030756085};\\\", \\\"{x:1624,y:708,t:1527030756096};\\\", \\\"{x:1607,y:721,t:1527030756112};\\\", \\\"{x:1592,y:738,t:1527030756130};\\\", \\\"{x:1580,y:753,t:1527030756146};\\\", \\\"{x:1570,y:768,t:1527030756163};\\\", \\\"{x:1557,y:789,t:1527030756180};\\\", \\\"{x:1545,y:806,t:1527030756196};\\\", \\\"{x:1534,y:820,t:1527030756213};\\\", \\\"{x:1522,y:838,t:1527030756231};\\\", \\\"{x:1519,y:846,t:1527030756247};\\\", \\\"{x:1515,y:854,t:1527030756263};\\\", \\\"{x:1512,y:863,t:1527030756280};\\\", \\\"{x:1507,y:874,t:1527030756297};\\\", \\\"{x:1502,y:884,t:1527030756313};\\\", \\\"{x:1500,y:892,t:1527030756330};\\\", \\\"{x:1498,y:898,t:1527030756347};\\\", \\\"{x:1497,y:903,t:1527030756363};\\\", \\\"{x:1496,y:905,t:1527030756380};\\\", \\\"{x:1495,y:908,t:1527030756397};\\\", \\\"{x:1493,y:911,t:1527030756414};\\\", \\\"{x:1492,y:917,t:1527030756430};\\\", \\\"{x:1491,y:921,t:1527030756446};\\\", \\\"{x:1490,y:925,t:1527030756464};\\\", \\\"{x:1489,y:929,t:1527030756480};\\\", \\\"{x:1487,y:933,t:1527030756497};\\\", \\\"{x:1486,y:934,t:1527030756513};\\\", \\\"{x:1484,y:937,t:1527030756531};\\\", \\\"{x:1484,y:938,t:1527030756552};\\\", \\\"{x:1483,y:940,t:1527030756563};\\\", \\\"{x:1482,y:943,t:1527030756580};\\\", \\\"{x:1481,y:944,t:1527030756597};\\\", \\\"{x:1481,y:946,t:1527030756613};\\\", \\\"{x:1480,y:947,t:1527030756630};\\\", \\\"{x:1479,y:947,t:1527030756743};\\\", \\\"{x:1479,y:945,t:1527030756752};\\\", \\\"{x:1479,y:942,t:1527030756763};\\\", \\\"{x:1477,y:938,t:1527030756780};\\\", \\\"{x:1475,y:929,t:1527030756796};\\\", \\\"{x:1471,y:918,t:1527030756813};\\\", \\\"{x:1469,y:911,t:1527030756829};\\\", \\\"{x:1467,y:905,t:1527030756847};\\\", \\\"{x:1465,y:897,t:1527030756864};\\\", \\\"{x:1460,y:888,t:1527030756880};\\\", \\\"{x:1457,y:879,t:1527030756896};\\\", \\\"{x:1454,y:873,t:1527030756913};\\\", \\\"{x:1449,y:865,t:1527030756930};\\\", \\\"{x:1445,y:859,t:1527030756947};\\\", \\\"{x:1442,y:853,t:1527030756964};\\\", \\\"{x:1440,y:849,t:1527030756980};\\\", \\\"{x:1439,y:847,t:1527030756997};\\\", \\\"{x:1436,y:842,t:1527030757014};\\\", \\\"{x:1434,y:837,t:1527030757030};\\\", \\\"{x:1431,y:831,t:1527030757047};\\\", \\\"{x:1429,y:823,t:1527030757064};\\\", \\\"{x:1426,y:815,t:1527030757080};\\\", \\\"{x:1422,y:808,t:1527030757097};\\\", \\\"{x:1419,y:799,t:1527030757115};\\\", \\\"{x:1415,y:790,t:1527030757130};\\\", \\\"{x:1413,y:779,t:1527030757147};\\\", \\\"{x:1409,y:768,t:1527030757164};\\\", \\\"{x:1404,y:752,t:1527030757180};\\\", \\\"{x:1399,y:738,t:1527030757198};\\\", \\\"{x:1394,y:718,t:1527030757214};\\\", \\\"{x:1390,y:706,t:1527030757230};\\\", \\\"{x:1388,y:697,t:1527030757247};\\\", \\\"{x:1387,y:682,t:1527030757264};\\\", \\\"{x:1383,y:662,t:1527030757281};\\\", \\\"{x:1380,y:645,t:1527030757297};\\\", \\\"{x:1376,y:623,t:1527030757314};\\\", \\\"{x:1373,y:608,t:1527030757331};\\\", \\\"{x:1369,y:593,t:1527030757347};\\\", \\\"{x:1368,y:588,t:1527030757364};\\\", \\\"{x:1367,y:586,t:1527030757381};\\\", \\\"{x:1366,y:584,t:1527030757397};\\\", \\\"{x:1365,y:582,t:1527030757414};\\\", \\\"{x:1363,y:577,t:1527030757432};\\\", \\\"{x:1359,y:569,t:1527030757448};\\\", \\\"{x:1352,y:559,t:1527030757464};\\\", \\\"{x:1344,y:552,t:1527030757481};\\\", \\\"{x:1336,y:545,t:1527030757497};\\\", \\\"{x:1330,y:540,t:1527030757514};\\\", \\\"{x:1323,y:535,t:1527030757531};\\\", \\\"{x:1317,y:534,t:1527030757547};\\\", \\\"{x:1315,y:533,t:1527030757564};\\\", \\\"{x:1315,y:535,t:1527030757814};\\\", \\\"{x:1312,y:542,t:1527030757831};\\\", \\\"{x:1307,y:547,t:1527030757849};\\\", \\\"{x:1307,y:548,t:1527030757865};\\\", \\\"{x:1306,y:548,t:1527030758223};\\\", \\\"{x:1296,y:546,t:1527030758231};\\\", \\\"{x:1267,y:535,t:1527030758248};\\\", \\\"{x:1230,y:525,t:1527030758266};\\\", \\\"{x:1199,y:516,t:1527030758281};\\\", \\\"{x:1167,y:508,t:1527030758298};\\\", \\\"{x:1130,y:499,t:1527030758316};\\\", \\\"{x:1098,y:496,t:1527030758331};\\\", \\\"{x:1064,y:493,t:1527030758349};\\\", \\\"{x:1036,y:493,t:1527030758365};\\\", \\\"{x:1009,y:493,t:1527030758381};\\\", \\\"{x:972,y:489,t:1527030758398};\\\", \\\"{x:949,y:489,t:1527030758417};\\\", \\\"{x:931,y:489,t:1527030758431};\\\", \\\"{x:918,y:486,t:1527030758448};\\\", \\\"{x:905,y:484,t:1527030758466};\\\", \\\"{x:891,y:480,t:1527030758482};\\\", \\\"{x:879,y:477,t:1527030758498};\\\", \\\"{x:867,y:476,t:1527030758516};\\\", \\\"{x:851,y:474,t:1527030758533};\\\", \\\"{x:826,y:474,t:1527030758549};\\\", \\\"{x:759,y:474,t:1527030758565};\\\", \\\"{x:686,y:474,t:1527030758583};\\\", \\\"{x:622,y:474,t:1527030758599};\\\", \\\"{x:553,y:474,t:1527030758616};\\\", \\\"{x:486,y:474,t:1527030758633};\\\", \\\"{x:438,y:474,t:1527030758649};\\\", \\\"{x:402,y:474,t:1527030758666};\\\", \\\"{x:379,y:474,t:1527030758683};\\\", \\\"{x:370,y:474,t:1527030758699};\\\", \\\"{x:365,y:474,t:1527030758716};\\\", \\\"{x:364,y:475,t:1527030758733};\\\", \\\"{x:363,y:475,t:1527030758806};\\\", \\\"{x:361,y:476,t:1527030758816};\\\", \\\"{x:355,y:479,t:1527030758833};\\\", \\\"{x:350,y:481,t:1527030758849};\\\", \\\"{x:347,y:482,t:1527030758866};\\\", \\\"{x:347,y:483,t:1527030758918};\\\", \\\"{x:347,y:484,t:1527030758933};\\\", \\\"{x:356,y:492,t:1527030758953};\\\", \\\"{x:373,y:502,t:1527030758965};\\\", \\\"{x:414,y:512,t:1527030758982};\\\", \\\"{x:492,y:515,t:1527030758999};\\\", \\\"{x:559,y:515,t:1527030759016};\\\", \\\"{x:595,y:515,t:1527030759033};\\\", \\\"{x:620,y:515,t:1527030759050};\\\", \\\"{x:632,y:515,t:1527030759065};\\\", \\\"{x:639,y:515,t:1527030759082};\\\", \\\"{x:640,y:516,t:1527030759100};\\\", \\\"{x:640,y:517,t:1527030759133};\\\", \\\"{x:639,y:518,t:1527030759152};\\\", \\\"{x:638,y:519,t:1527030759166};\\\", \\\"{x:636,y:519,t:1527030759245};\\\", \\\"{x:633,y:519,t:1527030759253};\\\", \\\"{x:632,y:519,t:1527030759266};\\\", \\\"{x:627,y:519,t:1527030759281};\\\", \\\"{x:624,y:517,t:1527030759300};\\\", \\\"{x:617,y:514,t:1527030759315};\\\", \\\"{x:612,y:511,t:1527030759333};\\\", \\\"{x:610,y:511,t:1527030759350};\\\", \\\"{x:609,y:511,t:1527030759470};\\\", \\\"{x:611,y:511,t:1527030759989};\\\", \\\"{x:620,y:511,t:1527030760000};\\\", \\\"{x:644,y:511,t:1527030760017};\\\", \\\"{x:671,y:511,t:1527030760034};\\\", \\\"{x:705,y:511,t:1527030760049};\\\", \\\"{x:744,y:511,t:1527030760068};\\\", \\\"{x:771,y:511,t:1527030760084};\\\", \\\"{x:791,y:511,t:1527030760099};\\\", \\\"{x:797,y:511,t:1527030760117};\\\", \\\"{x:798,y:511,t:1527030760134};\\\", \\\"{x:799,y:511,t:1527030760262};\\\", \\\"{x:801,y:511,t:1527030760390};\\\", \\\"{x:806,y:510,t:1527030760401};\\\", \\\"{x:822,y:504,t:1527030760418};\\\", \\\"{x:831,y:502,t:1527030760435};\\\", \\\"{x:838,y:501,t:1527030760450};\\\", \\\"{x:843,y:500,t:1527030760467};\\\", \\\"{x:846,y:499,t:1527030760484};\\\", \\\"{x:845,y:502,t:1527030760981};\\\", \\\"{x:842,y:504,t:1527030760989};\\\", \\\"{x:838,y:509,t:1527030761000};\\\", \\\"{x:828,y:521,t:1527030761019};\\\", \\\"{x:814,y:534,t:1527030761035};\\\", \\\"{x:800,y:546,t:1527030761050};\\\", \\\"{x:786,y:559,t:1527030761069};\\\", \\\"{x:771,y:572,t:1527030761084};\\\", \\\"{x:747,y:593,t:1527030761100};\\\", \\\"{x:729,y:607,t:1527030761118};\\\", \\\"{x:711,y:620,t:1527030761136};\\\", \\\"{x:694,y:630,t:1527030761151};\\\", \\\"{x:679,y:637,t:1527030761169};\\\", \\\"{x:668,y:642,t:1527030761184};\\\", \\\"{x:662,y:646,t:1527030761201};\\\", \\\"{x:657,y:650,t:1527030761218};\\\", \\\"{x:650,y:656,t:1527030761235};\\\", \\\"{x:640,y:663,t:1527030761252};\\\", \\\"{x:630,y:671,t:1527030761268};\\\", \\\"{x:616,y:683,t:1527030761285};\\\", \\\"{x:595,y:699,t:1527030761301};\\\", \\\"{x:582,y:709,t:1527030761318};\\\", \\\"{x:566,y:720,t:1527030761335};\\\", \\\"{x:545,y:727,t:1527030761353};\\\", \\\"{x:537,y:730,t:1527030761368};\\\", \\\"{x:531,y:731,t:1527030761385};\\\", \\\"{x:528,y:731,t:1527030761402};\\\", \\\"{x:526,y:731,t:1527030761429};\\\", \\\"{x:525,y:731,t:1527030761461};\\\", \\\"{x:523,y:731,t:1527030761469};\\\", \\\"{x:522,y:730,t:1527030761485};\\\", \\\"{x:522,y:723,t:1527030761501};\\\", \\\"{x:521,y:720,t:1527030761517};\\\", \\\"{x:521,y:719,t:1527030761535};\\\", \\\"{x:521,y:717,t:1527030761551};\\\", \\\"{x:521,y:718,t:1527030761694};\\\", \\\"{x:521,y:720,t:1527030761702};\\\", \\\"{x:521,y:726,t:1527030761717};\\\", \\\"{x:521,y:731,t:1527030761735};\\\", \\\"{x:520,y:735,t:1527030761751};\\\", \\\"{x:520,y:737,t:1527030761767};\\\", \\\"{x:520,y:738,t:1527030761785};\\\" ] }, { \\\"rt\\\": 8750, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 655810, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:738,t:1527030769374};\\\", \\\"{x:534,y:731,t:1527030769382};\\\", \\\"{x:548,y:721,t:1527030769395};\\\", \\\"{x:558,y:711,t:1527030769412};\\\", \\\"{x:559,y:709,t:1527030769427};\\\", \\\"{x:560,y:709,t:1527030769501};\\\", \\\"{x:561,y:708,t:1527030769966};\\\", \\\"{x:562,y:707,t:1527030770654};\\\", \\\"{x:567,y:705,t:1527030770662};\\\", \\\"{x:574,y:702,t:1527030770673};\\\", \\\"{x:595,y:694,t:1527030770690};\\\", \\\"{x:619,y:686,t:1527030770706};\\\", \\\"{x:645,y:684,t:1527030770725};\\\", \\\"{x:669,y:680,t:1527030770739};\\\", \\\"{x:691,y:678,t:1527030770756};\\\", \\\"{x:720,y:674,t:1527030770774};\\\", \\\"{x:739,y:672,t:1527030770790};\\\", \\\"{x:756,y:667,t:1527030770806};\\\", \\\"{x:771,y:662,t:1527030770824};\\\", \\\"{x:784,y:658,t:1527030770839};\\\", \\\"{x:797,y:656,t:1527030770856};\\\", \\\"{x:811,y:652,t:1527030770874};\\\", \\\"{x:823,y:648,t:1527030770889};\\\", \\\"{x:841,y:644,t:1527030770906};\\\", \\\"{x:855,y:640,t:1527030770924};\\\", \\\"{x:870,y:636,t:1527030770940};\\\", \\\"{x:889,y:633,t:1527030770956};\\\", \\\"{x:925,y:627,t:1527030770975};\\\", \\\"{x:957,y:625,t:1527030770991};\\\", \\\"{x:988,y:625,t:1527030771006};\\\", \\\"{x:1030,y:625,t:1527030771026};\\\", \\\"{x:1089,y:625,t:1527030771042};\\\", \\\"{x:1134,y:625,t:1527030771059};\\\", \\\"{x:1171,y:625,t:1527030771076};\\\", \\\"{x:1205,y:625,t:1527030771092};\\\", \\\"{x:1237,y:625,t:1527030771109};\\\", \\\"{x:1258,y:630,t:1527030771126};\\\", \\\"{x:1279,y:645,t:1527030771142};\\\", \\\"{x:1297,y:661,t:1527030771159};\\\", \\\"{x:1313,y:686,t:1527030771177};\\\", \\\"{x:1337,y:717,t:1527030771192};\\\", \\\"{x:1364,y:746,t:1527030771209};\\\", \\\"{x:1388,y:764,t:1527030771226};\\\", \\\"{x:1405,y:777,t:1527030771242};\\\", \\\"{x:1421,y:790,t:1527030771259};\\\", \\\"{x:1430,y:799,t:1527030771276};\\\", \\\"{x:1439,y:811,t:1527030771293};\\\", \\\"{x:1443,y:818,t:1527030771310};\\\", \\\"{x:1451,y:830,t:1527030771326};\\\", \\\"{x:1460,y:839,t:1527030771343};\\\", \\\"{x:1463,y:843,t:1527030771359};\\\", \\\"{x:1468,y:853,t:1527030771376};\\\", \\\"{x:1470,y:859,t:1527030771392};\\\", \\\"{x:1471,y:866,t:1527030771409};\\\", \\\"{x:1474,y:872,t:1527030771427};\\\", \\\"{x:1475,y:878,t:1527030771444};\\\", \\\"{x:1478,y:882,t:1527030771460};\\\", \\\"{x:1480,y:885,t:1527030771477};\\\", \\\"{x:1482,y:889,t:1527030771493};\\\", \\\"{x:1483,y:890,t:1527030771509};\\\", \\\"{x:1485,y:892,t:1527030771526};\\\", \\\"{x:1494,y:895,t:1527030771543};\\\", \\\"{x:1505,y:896,t:1527030771559};\\\", \\\"{x:1521,y:897,t:1527030771577};\\\", \\\"{x:1539,y:899,t:1527030771594};\\\", \\\"{x:1548,y:900,t:1527030771609};\\\", \\\"{x:1553,y:901,t:1527030771626};\\\", \\\"{x:1554,y:901,t:1527030771644};\\\", \\\"{x:1555,y:902,t:1527030771806};\\\", \\\"{x:1555,y:903,t:1527030771813};\\\", \\\"{x:1557,y:906,t:1527030771826};\\\", \\\"{x:1560,y:912,t:1527030771843};\\\", \\\"{x:1565,y:922,t:1527030771860};\\\", \\\"{x:1570,y:933,t:1527030771876};\\\", \\\"{x:1577,y:946,t:1527030771893};\\\", \\\"{x:1580,y:951,t:1527030771910};\\\", \\\"{x:1583,y:956,t:1527030771926};\\\", \\\"{x:1583,y:958,t:1527030771943};\\\", \\\"{x:1586,y:962,t:1527030771960};\\\", \\\"{x:1586,y:964,t:1527030771976};\\\", \\\"{x:1587,y:966,t:1527030771993};\\\", \\\"{x:1589,y:970,t:1527030772010};\\\", \\\"{x:1589,y:974,t:1527030772026};\\\", \\\"{x:1588,y:979,t:1527030772043};\\\", \\\"{x:1587,y:982,t:1527030772061};\\\", \\\"{x:1587,y:984,t:1527030772076};\\\", \\\"{x:1585,y:986,t:1527030772093};\\\", \\\"{x:1585,y:987,t:1527030772182};\\\", \\\"{x:1584,y:987,t:1527030772198};\\\", \\\"{x:1583,y:987,t:1527030772214};\\\", \\\"{x:1582,y:986,t:1527030772230};\\\", \\\"{x:1578,y:984,t:1527030772254};\\\", \\\"{x:1578,y:983,t:1527030772261};\\\", \\\"{x:1576,y:980,t:1527030772277};\\\", \\\"{x:1575,y:979,t:1527030772293};\\\", \\\"{x:1573,y:977,t:1527030772358};\\\", \\\"{x:1572,y:976,t:1527030772382};\\\", \\\"{x:1571,y:976,t:1527030772486};\\\", \\\"{x:1569,y:974,t:1527030772598};\\\", \\\"{x:1568,y:973,t:1527030772646};\\\", \\\"{x:1567,y:972,t:1527030772661};\\\", \\\"{x:1566,y:972,t:1527030772677};\\\", \\\"{x:1566,y:971,t:1527030772694};\\\", \\\"{x:1565,y:970,t:1527030772711};\\\", \\\"{x:1565,y:967,t:1527030772729};\\\", \\\"{x:1564,y:966,t:1527030772749};\\\", \\\"{x:1563,y:966,t:1527030772760};\\\", \\\"{x:1563,y:965,t:1527030772777};\\\", \\\"{x:1562,y:965,t:1527030772794};\\\", \\\"{x:1562,y:964,t:1527030772810};\\\", \\\"{x:1560,y:961,t:1527030772827};\\\", \\\"{x:1560,y:959,t:1527030772853};\\\", \\\"{x:1560,y:958,t:1527030772885};\\\", \\\"{x:1560,y:956,t:1527030772901};\\\", \\\"{x:1559,y:955,t:1527030772911};\\\", \\\"{x:1559,y:954,t:1527030772927};\\\", \\\"{x:1559,y:952,t:1527030772944};\\\", \\\"{x:1558,y:950,t:1527030772961};\\\", \\\"{x:1557,y:948,t:1527030772977};\\\", \\\"{x:1557,y:945,t:1527030772994};\\\", \\\"{x:1557,y:943,t:1527030773011};\\\", \\\"{x:1556,y:940,t:1527030773028};\\\", \\\"{x:1555,y:934,t:1527030773044};\\\", \\\"{x:1550,y:921,t:1527030773060};\\\", \\\"{x:1541,y:905,t:1527030773077};\\\", \\\"{x:1517,y:863,t:1527030773094};\\\", \\\"{x:1468,y:778,t:1527030773110};\\\", \\\"{x:1399,y:673,t:1527030773127};\\\", \\\"{x:1322,y:544,t:1527030773144};\\\", \\\"{x:1244,y:423,t:1527030773162};\\\", \\\"{x:1155,y:321,t:1527030773177};\\\", \\\"{x:1063,y:231,t:1527030773194};\\\", \\\"{x:960,y:158,t:1527030773211};\\\", \\\"{x:868,y:110,t:1527030773227};\\\", \\\"{x:798,y:86,t:1527030773244};\\\", \\\"{x:714,y:78,t:1527030773261};\\\", \\\"{x:677,y:78,t:1527030773278};\\\", \\\"{x:643,y:83,t:1527030773294};\\\", \\\"{x:618,y:90,t:1527030773312};\\\", \\\"{x:600,y:98,t:1527030773328};\\\", \\\"{x:588,y:103,t:1527030773345};\\\", \\\"{x:577,y:110,t:1527030773362};\\\", \\\"{x:568,y:114,t:1527030773377};\\\", \\\"{x:559,y:120,t:1527030773394};\\\", \\\"{x:550,y:127,t:1527030773412};\\\", \\\"{x:530,y:143,t:1527030773427};\\\", \\\"{x:513,y:157,t:1527030773445};\\\", \\\"{x:498,y:172,t:1527030773462};\\\", \\\"{x:495,y:181,t:1527030773478};\\\", \\\"{x:492,y:196,t:1527030773495};\\\", \\\"{x:492,y:215,t:1527030773511};\\\", \\\"{x:498,y:237,t:1527030773527};\\\", \\\"{x:525,y:270,t:1527030773545};\\\", \\\"{x:561,y:302,t:1527030773561};\\\", \\\"{x:590,y:329,t:1527030773579};\\\", \\\"{x:612,y:356,t:1527030773595};\\\", \\\"{x:628,y:371,t:1527030773612};\\\", \\\"{x:642,y:383,t:1527030773629};\\\", \\\"{x:648,y:388,t:1527030773644};\\\", \\\"{x:652,y:393,t:1527030773661};\\\", \\\"{x:654,y:398,t:1527030773678};\\\", \\\"{x:654,y:402,t:1527030773694};\\\", \\\"{x:655,y:414,t:1527030773712};\\\", \\\"{x:655,y:428,t:1527030773729};\\\", \\\"{x:648,y:444,t:1527030773745};\\\", \\\"{x:637,y:458,t:1527030773762};\\\", \\\"{x:618,y:473,t:1527030773779};\\\", \\\"{x:591,y:487,t:1527030773796};\\\", \\\"{x:542,y:504,t:1527030773811};\\\", \\\"{x:482,y:518,t:1527030773829};\\\", \\\"{x:411,y:525,t:1527030773845};\\\", \\\"{x:344,y:531,t:1527030773861};\\\", \\\"{x:324,y:531,t:1527030773878};\\\", \\\"{x:317,y:532,t:1527030773894};\\\", \\\"{x:316,y:533,t:1527030773911};\\\", \\\"{x:314,y:535,t:1527030773941};\\\", \\\"{x:312,y:538,t:1527030773948};\\\", \\\"{x:309,y:542,t:1527030773961};\\\", \\\"{x:302,y:549,t:1527030773978};\\\", \\\"{x:295,y:554,t:1527030773995};\\\", \\\"{x:292,y:555,t:1527030774012};\\\", \\\"{x:289,y:557,t:1527030774029};\\\", \\\"{x:288,y:557,t:1527030774046};\\\", \\\"{x:286,y:558,t:1527030774102};\\\", \\\"{x:282,y:560,t:1527030774113};\\\", \\\"{x:277,y:563,t:1527030774130};\\\", \\\"{x:271,y:566,t:1527030774146};\\\", \\\"{x:268,y:567,t:1527030774161};\\\", \\\"{x:266,y:568,t:1527030774179};\\\", \\\"{x:269,y:568,t:1527030774221};\\\", \\\"{x:277,y:568,t:1527030774230};\\\", \\\"{x:306,y:568,t:1527030774245};\\\", \\\"{x:368,y:559,t:1527030774262};\\\", \\\"{x:449,y:557,t:1527030774278};\\\", \\\"{x:538,y:558,t:1527030774295};\\\", \\\"{x:607,y:565,t:1527030774312};\\\", \\\"{x:640,y:570,t:1527030774328};\\\", \\\"{x:650,y:571,t:1527030774345};\\\", \\\"{x:649,y:571,t:1527030774381};\\\", \\\"{x:647,y:571,t:1527030774394};\\\", \\\"{x:639,y:571,t:1527030774411};\\\", \\\"{x:634,y:571,t:1527030774428};\\\", \\\"{x:630,y:573,t:1527030774445};\\\", \\\"{x:628,y:573,t:1527030774485};\\\", \\\"{x:627,y:573,t:1527030774516};\\\", \\\"{x:625,y:573,t:1527030774533};\\\", \\\"{x:624,y:573,t:1527030774557};\\\", \\\"{x:622,y:573,t:1527030774572};\\\", \\\"{x:621,y:573,t:1527030774581};\\\", \\\"{x:620,y:573,t:1527030774596};\\\", \\\"{x:619,y:573,t:1527030774612};\\\", \\\"{x:608,y:576,t:1527030774862};\\\", \\\"{x:592,y:583,t:1527030774880};\\\", \\\"{x:584,y:590,t:1527030774895};\\\", \\\"{x:574,y:597,t:1527030774913};\\\", \\\"{x:564,y:610,t:1527030774930};\\\", \\\"{x:557,y:621,t:1527030774945};\\\", \\\"{x:554,y:634,t:1527030774962};\\\", \\\"{x:553,y:646,t:1527030774979};\\\", \\\"{x:553,y:656,t:1527030774995};\\\", \\\"{x:553,y:666,t:1527030775012};\\\", \\\"{x:553,y:672,t:1527030775028};\\\", \\\"{x:552,y:680,t:1527030775045};\\\", \\\"{x:550,y:681,t:1527030775069};\\\", \\\"{x:550,y:682,t:1527030775079};\\\", \\\"{x:549,y:682,t:1527030775095};\\\", \\\"{x:547,y:684,t:1527030775350};\\\", \\\"{x:546,y:684,t:1527030775446};\\\", \\\"{x:545,y:684,t:1527030775462};\\\", \\\"{x:544,y:684,t:1527030775479};\\\", \\\"{x:543,y:684,t:1527030775496};\\\", \\\"{x:542,y:685,t:1527030775526};\\\", \\\"{x:540,y:686,t:1527030775533};\\\", \\\"{x:539,y:686,t:1527030775557};\\\", \\\"{x:539,y:687,t:1527030775566};\\\", \\\"{x:539,y:688,t:1527030775580};\\\", \\\"{x:539,y:691,t:1527030775597};\\\", \\\"{x:539,y:694,t:1527030775613};\\\", \\\"{x:540,y:698,t:1527030775630};\\\", \\\"{x:542,y:701,t:1527030775647};\\\", \\\"{x:542,y:707,t:1527030775662};\\\", \\\"{x:546,y:716,t:1527030775679};\\\", \\\"{x:549,y:729,t:1527030775698};\\\", \\\"{x:551,y:744,t:1527030775713};\\\", \\\"{x:554,y:753,t:1527030775729};\\\", \\\"{x:555,y:757,t:1527030775746};\\\", \\\"{x:555,y:760,t:1527030775763};\\\", \\\"{x:556,y:761,t:1527030775779};\\\", \\\"{x:558,y:761,t:1527030775796};\\\", \\\"{x:557,y:761,t:1527030775909};\\\", \\\"{x:554,y:761,t:1527030775918};\\\", \\\"{x:552,y:761,t:1527030775929};\\\", \\\"{x:548,y:760,t:1527030775947};\\\", \\\"{x:546,y:759,t:1527030775963};\\\", \\\"{x:544,y:758,t:1527030775982};\\\", \\\"{x:543,y:757,t:1527030775997};\\\", \\\"{x:541,y:756,t:1527030776014};\\\", \\\"{x:537,y:754,t:1527030776031};\\\", \\\"{x:534,y:752,t:1527030776046};\\\", \\\"{x:533,y:751,t:1527030776063};\\\", \\\"{x:532,y:750,t:1527030776079};\\\", \\\"{x:531,y:750,t:1527030776096};\\\", \\\"{x:531,y:749,t:1527030776113};\\\", \\\"{x:530,y:749,t:1527030776372};\\\", \\\"{x:530,y:748,t:1527030776396};\\\", \\\"{x:530,y:746,t:1527030776412};\\\", \\\"{x:531,y:745,t:1527030776430};\\\", \\\"{x:532,y:743,t:1527030776447};\\\", \\\"{x:533,y:741,t:1527030776463};\\\", \\\"{x:534,y:739,t:1527030776480};\\\", \\\"{x:535,y:737,t:1527030776496};\\\", \\\"{x:535,y:734,t:1527030776513};\\\", \\\"{x:537,y:733,t:1527030776530};\\\", \\\"{x:537,y:731,t:1527030777344};\\\" ] }, { \\\"rt\\\": 32171, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 689258, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-02 PM-X -X -K \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:553,y:737,t:1527030777587};\\\", \\\"{x:554,y:737,t:1527030787244};\\\", \\\"{x:565,y:734,t:1527030787255};\\\", \\\"{x:612,y:725,t:1527030787269};\\\", \\\"{x:671,y:717,t:1527030787285};\\\", \\\"{x:703,y:712,t:1527030787303};\\\", \\\"{x:724,y:706,t:1527030787320};\\\", \\\"{x:731,y:705,t:1527030787336};\\\", \\\"{x:734,y:703,t:1527030787353};\\\", \\\"{x:749,y:702,t:1527030787819};\\\", \\\"{x:762,y:702,t:1527030787827};\\\", \\\"{x:773,y:701,t:1527030787838};\\\", \\\"{x:786,y:701,t:1527030787854};\\\", \\\"{x:800,y:701,t:1527030787871};\\\", \\\"{x:819,y:701,t:1527030787888};\\\", \\\"{x:839,y:701,t:1527030787904};\\\", \\\"{x:860,y:700,t:1527030787921};\\\", \\\"{x:878,y:697,t:1527030787938};\\\", \\\"{x:897,y:695,t:1527030787954};\\\", \\\"{x:929,y:689,t:1527030787971};\\\", \\\"{x:954,y:689,t:1527030787987};\\\", \\\"{x:984,y:687,t:1527030788004};\\\", \\\"{x:1027,y:687,t:1527030788021};\\\", \\\"{x:1072,y:687,t:1527030788038};\\\", \\\"{x:1110,y:692,t:1527030788054};\\\", \\\"{x:1140,y:701,t:1527030788071};\\\", \\\"{x:1184,y:714,t:1527030788088};\\\", \\\"{x:1243,y:731,t:1527030788104};\\\", \\\"{x:1309,y:748,t:1527030788121};\\\", \\\"{x:1381,y:766,t:1527030788138};\\\", \\\"{x:1450,y:784,t:1527030788155};\\\", \\\"{x:1511,y:813,t:1527030788171};\\\", \\\"{x:1532,y:824,t:1527030788188};\\\", \\\"{x:1550,y:833,t:1527030788205};\\\", \\\"{x:1566,y:843,t:1527030788221};\\\", \\\"{x:1579,y:852,t:1527030788239};\\\", \\\"{x:1590,y:863,t:1527030788255};\\\", \\\"{x:1596,y:873,t:1527030788271};\\\", \\\"{x:1603,y:884,t:1527030788288};\\\", \\\"{x:1611,y:895,t:1527030788305};\\\", \\\"{x:1615,y:904,t:1527030788321};\\\", \\\"{x:1618,y:909,t:1527030788338};\\\", \\\"{x:1619,y:913,t:1527030788356};\\\", \\\"{x:1619,y:920,t:1527030788371};\\\", \\\"{x:1619,y:928,t:1527030788389};\\\", \\\"{x:1618,y:932,t:1527030788405};\\\", \\\"{x:1615,y:936,t:1527030788421};\\\", \\\"{x:1612,y:940,t:1527030788438};\\\", \\\"{x:1608,y:944,t:1527030788455};\\\", \\\"{x:1605,y:947,t:1527030788471};\\\", \\\"{x:1598,y:952,t:1527030788488};\\\", \\\"{x:1591,y:956,t:1527030788505};\\\", \\\"{x:1584,y:959,t:1527030788521};\\\", \\\"{x:1581,y:961,t:1527030788538};\\\", \\\"{x:1571,y:964,t:1527030788555};\\\", \\\"{x:1558,y:966,t:1527030788571};\\\", \\\"{x:1547,y:968,t:1527030788589};\\\", \\\"{x:1538,y:969,t:1527030788605};\\\", \\\"{x:1534,y:972,t:1527030788622};\\\", \\\"{x:1530,y:972,t:1527030788638};\\\", \\\"{x:1526,y:972,t:1527030788656};\\\", \\\"{x:1524,y:972,t:1527030788672};\\\", \\\"{x:1523,y:972,t:1527030788688};\\\", \\\"{x:1522,y:972,t:1527030788705};\\\", \\\"{x:1521,y:972,t:1527030788731};\\\", \\\"{x:1520,y:972,t:1527030788739};\\\", \\\"{x:1518,y:972,t:1527030788755};\\\", \\\"{x:1517,y:972,t:1527030788772};\\\", \\\"{x:1515,y:972,t:1527030788788};\\\", \\\"{x:1514,y:972,t:1527030788805};\\\", \\\"{x:1511,y:971,t:1527030788823};\\\", \\\"{x:1509,y:971,t:1527030788844};\\\", \\\"{x:1507,y:971,t:1527030788855};\\\", \\\"{x:1505,y:971,t:1527030788872};\\\", \\\"{x:1502,y:972,t:1527030788888};\\\", \\\"{x:1499,y:972,t:1527030788906};\\\", \\\"{x:1496,y:973,t:1527030788922};\\\", \\\"{x:1495,y:973,t:1527030788938};\\\", \\\"{x:1494,y:973,t:1527030788988};\\\", \\\"{x:1492,y:973,t:1527030789020};\\\", \\\"{x:1491,y:973,t:1527030789036};\\\", \\\"{x:1490,y:973,t:1527030789067};\\\", \\\"{x:1489,y:973,t:1527030789075};\\\", \\\"{x:1489,y:972,t:1527030789089};\\\", \\\"{x:1488,y:972,t:1527030789107};\\\", \\\"{x:1485,y:972,t:1527030789122};\\\", \\\"{x:1485,y:971,t:1527030789147};\\\", \\\"{x:1483,y:970,t:1527030789220};\\\", \\\"{x:1482,y:969,t:1527030789236};\\\", \\\"{x:1481,y:968,t:1527030789244};\\\", \\\"{x:1480,y:968,t:1527030789259};\\\", \\\"{x:1479,y:968,t:1527030789283};\\\", \\\"{x:1479,y:967,t:1527030789291};\\\", \\\"{x:1478,y:966,t:1527030789324};\\\", \\\"{x:1478,y:965,t:1527030789363};\\\", \\\"{x:1477,y:963,t:1527030789373};\\\", \\\"{x:1477,y:962,t:1527030789390};\\\", \\\"{x:1476,y:959,t:1527030789405};\\\", \\\"{x:1475,y:956,t:1527030789423};\\\", \\\"{x:1475,y:953,t:1527030789440};\\\", \\\"{x:1475,y:952,t:1527030789460};\\\", \\\"{x:1475,y:951,t:1527030789475};\\\", \\\"{x:1475,y:949,t:1527030789490};\\\", \\\"{x:1475,y:948,t:1527030789523};\\\", \\\"{x:1475,y:947,t:1527030789579};\\\", \\\"{x:1475,y:946,t:1527030789612};\\\", \\\"{x:1475,y:944,t:1527030789622};\\\", \\\"{x:1475,y:940,t:1527030789640};\\\", \\\"{x:1475,y:938,t:1527030789657};\\\", \\\"{x:1475,y:936,t:1527030789672};\\\", \\\"{x:1475,y:932,t:1527030789689};\\\", \\\"{x:1476,y:929,t:1527030789706};\\\", \\\"{x:1476,y:925,t:1527030789722};\\\", \\\"{x:1476,y:922,t:1527030789740};\\\", \\\"{x:1479,y:917,t:1527030789756};\\\", \\\"{x:1479,y:914,t:1527030789772};\\\", \\\"{x:1479,y:909,t:1527030789789};\\\", \\\"{x:1481,y:903,t:1527030789806};\\\", \\\"{x:1484,y:896,t:1527030789823};\\\", \\\"{x:1484,y:889,t:1527030789840};\\\", \\\"{x:1485,y:883,t:1527030789856};\\\", \\\"{x:1485,y:876,t:1527030789873};\\\", \\\"{x:1485,y:869,t:1527030789889};\\\", \\\"{x:1485,y:866,t:1527030789907};\\\", \\\"{x:1485,y:862,t:1527030789922};\\\", \\\"{x:1485,y:853,t:1527030789939};\\\", \\\"{x:1485,y:850,t:1527030789957};\\\", \\\"{x:1485,y:848,t:1527030789973};\\\", \\\"{x:1485,y:847,t:1527030789989};\\\", \\\"{x:1485,y:846,t:1527030790084};\\\", \\\"{x:1485,y:845,t:1527030790140};\\\", \\\"{x:1485,y:844,t:1527030790157};\\\", \\\"{x:1485,y:843,t:1527030790188};\\\", \\\"{x:1485,y:842,t:1527030790220};\\\", \\\"{x:1485,y:841,t:1527030790268};\\\", \\\"{x:1484,y:840,t:1527030790308};\\\", \\\"{x:1484,y:839,t:1527030790331};\\\", \\\"{x:1484,y:838,t:1527030790411};\\\", \\\"{x:1484,y:836,t:1527030792212};\\\", \\\"{x:1483,y:834,t:1527030792226};\\\", \\\"{x:1483,y:832,t:1527030792240};\\\", \\\"{x:1483,y:829,t:1527030792258};\\\", \\\"{x:1482,y:828,t:1527030792274};\\\", \\\"{x:1481,y:827,t:1527030792290};\\\", \\\"{x:1481,y:825,t:1527030792570};\\\", \\\"{x:1481,y:824,t:1527030792578};\\\", \\\"{x:1481,y:821,t:1527030792591};\\\", \\\"{x:1481,y:816,t:1527030792608};\\\", \\\"{x:1481,y:811,t:1527030792625};\\\", \\\"{x:1481,y:805,t:1527030792642};\\\", \\\"{x:1481,y:796,t:1527030792658};\\\", \\\"{x:1481,y:781,t:1527030792674};\\\", \\\"{x:1481,y:770,t:1527030792691};\\\", \\\"{x:1481,y:754,t:1527030792708};\\\", \\\"{x:1481,y:733,t:1527030792725};\\\", \\\"{x:1481,y:721,t:1527030792741};\\\", \\\"{x:1481,y:707,t:1527030792758};\\\", \\\"{x:1481,y:689,t:1527030792775};\\\", \\\"{x:1481,y:665,t:1527030792791};\\\", \\\"{x:1481,y:643,t:1527030792809};\\\", \\\"{x:1482,y:621,t:1527030792825};\\\", \\\"{x:1484,y:602,t:1527030792841};\\\", \\\"{x:1487,y:582,t:1527030792858};\\\", \\\"{x:1492,y:554,t:1527030792875};\\\", \\\"{x:1494,y:540,t:1527030792892};\\\", \\\"{x:1497,y:525,t:1527030792908};\\\", \\\"{x:1498,y:508,t:1527030792925};\\\", \\\"{x:1500,y:497,t:1527030792941};\\\", \\\"{x:1500,y:482,t:1527030792958};\\\", \\\"{x:1502,y:465,t:1527030792975};\\\", \\\"{x:1504,y:447,t:1527030792992};\\\", \\\"{x:1507,y:434,t:1527030793009};\\\", \\\"{x:1510,y:418,t:1527030793025};\\\", \\\"{x:1512,y:406,t:1527030793042};\\\", \\\"{x:1512,y:397,t:1527030793058};\\\", \\\"{x:1512,y:386,t:1527030793075};\\\", \\\"{x:1512,y:376,t:1527030793091};\\\", \\\"{x:1512,y:366,t:1527030793108};\\\", \\\"{x:1512,y:357,t:1527030793126};\\\", \\\"{x:1511,y:347,t:1527030793142};\\\", \\\"{x:1510,y:336,t:1527030793158};\\\", \\\"{x:1508,y:326,t:1527030793176};\\\", \\\"{x:1504,y:314,t:1527030793192};\\\", \\\"{x:1501,y:306,t:1527030793208};\\\", \\\"{x:1499,y:301,t:1527030793226};\\\", \\\"{x:1497,y:296,t:1527030793242};\\\", \\\"{x:1495,y:292,t:1527030793259};\\\", \\\"{x:1494,y:289,t:1527030793275};\\\", \\\"{x:1494,y:288,t:1527030793292};\\\", \\\"{x:1492,y:288,t:1527030793444};\\\", \\\"{x:1491,y:288,t:1527030793459};\\\", \\\"{x:1488,y:289,t:1527030793475};\\\", \\\"{x:1487,y:291,t:1527030793492};\\\", \\\"{x:1486,y:291,t:1527030793509};\\\", \\\"{x:1485,y:294,t:1527030793526};\\\", \\\"{x:1483,y:296,t:1527030793542};\\\", \\\"{x:1482,y:297,t:1527030793563};\\\", \\\"{x:1482,y:298,t:1527030794116};\\\", \\\"{x:1482,y:299,t:1527030794126};\\\", \\\"{x:1482,y:300,t:1527030794142};\\\", \\\"{x:1482,y:302,t:1527030794159};\\\", \\\"{x:1482,y:303,t:1527030794180};\\\", \\\"{x:1482,y:305,t:1527030794339};\\\", \\\"{x:1482,y:306,t:1527030794347};\\\", \\\"{x:1482,y:307,t:1527030794360};\\\", \\\"{x:1481,y:307,t:1527030794377};\\\", \\\"{x:1480,y:310,t:1527030794394};\\\", \\\"{x:1480,y:312,t:1527030794409};\\\", \\\"{x:1479,y:313,t:1527030794426};\\\", \\\"{x:1479,y:315,t:1527030794443};\\\", \\\"{x:1478,y:317,t:1527030794467};\\\", \\\"{x:1478,y:318,t:1527030794483};\\\", \\\"{x:1478,y:319,t:1527030794493};\\\", \\\"{x:1478,y:322,t:1527030794510};\\\", \\\"{x:1478,y:325,t:1527030794526};\\\", \\\"{x:1478,y:327,t:1527030794544};\\\", \\\"{x:1478,y:330,t:1527030794559};\\\", \\\"{x:1478,y:332,t:1527030794576};\\\", \\\"{x:1477,y:335,t:1527030794593};\\\", \\\"{x:1477,y:336,t:1527030794610};\\\", \\\"{x:1477,y:340,t:1527030794626};\\\", \\\"{x:1476,y:345,t:1527030794643};\\\", \\\"{x:1476,y:348,t:1527030794659};\\\", \\\"{x:1476,y:350,t:1527030794675};\\\", \\\"{x:1476,y:352,t:1527030794693};\\\", \\\"{x:1476,y:356,t:1527030794710};\\\", \\\"{x:1475,y:359,t:1527030794725};\\\", \\\"{x:1475,y:363,t:1527030794743};\\\", \\\"{x:1473,y:366,t:1527030794760};\\\", \\\"{x:1473,y:368,t:1527030794775};\\\", \\\"{x:1472,y:373,t:1527030794792};\\\", \\\"{x:1472,y:377,t:1527030794810};\\\", \\\"{x:1472,y:383,t:1527030794826};\\\", \\\"{x:1472,y:392,t:1527030794842};\\\", \\\"{x:1471,y:398,t:1527030794860};\\\", \\\"{x:1471,y:402,t:1527030794876};\\\", \\\"{x:1469,y:407,t:1527030794893};\\\", \\\"{x:1468,y:412,t:1527030794911};\\\", \\\"{x:1468,y:416,t:1527030794926};\\\", \\\"{x:1468,y:418,t:1527030794945};\\\", \\\"{x:1468,y:421,t:1527030794960};\\\", \\\"{x:1468,y:424,t:1527030794976};\\\", \\\"{x:1468,y:425,t:1527030794993};\\\", \\\"{x:1468,y:427,t:1527030795011};\\\", \\\"{x:1469,y:430,t:1527030795026};\\\", \\\"{x:1470,y:432,t:1527030795043};\\\", \\\"{x:1470,y:434,t:1527030795061};\\\", \\\"{x:1471,y:434,t:1527030795076};\\\", \\\"{x:1471,y:435,t:1527030795093};\\\", \\\"{x:1472,y:436,t:1527030795132};\\\", \\\"{x:1473,y:437,t:1527030795155};\\\", \\\"{x:1473,y:438,t:1527030795163};\\\", \\\"{x:1473,y:439,t:1527030795177};\\\", \\\"{x:1474,y:440,t:1527030795194};\\\", \\\"{x:1475,y:441,t:1527030795211};\\\", \\\"{x:1476,y:443,t:1527030795227};\\\", \\\"{x:1476,y:444,t:1527030795244};\\\", \\\"{x:1476,y:447,t:1527030795260};\\\", \\\"{x:1478,y:450,t:1527030795277};\\\", \\\"{x:1478,y:453,t:1527030795294};\\\", \\\"{x:1478,y:455,t:1527030795310};\\\", \\\"{x:1478,y:457,t:1527030795328};\\\", \\\"{x:1479,y:460,t:1527030795343};\\\", \\\"{x:1479,y:462,t:1527030795360};\\\", \\\"{x:1479,y:466,t:1527030795377};\\\", \\\"{x:1479,y:469,t:1527030795393};\\\", \\\"{x:1479,y:473,t:1527030795410};\\\", \\\"{x:1481,y:481,t:1527030795426};\\\", \\\"{x:1481,y:484,t:1527030795443};\\\", \\\"{x:1481,y:489,t:1527030795460};\\\", \\\"{x:1481,y:492,t:1527030795477};\\\", \\\"{x:1481,y:496,t:1527030795493};\\\", \\\"{x:1481,y:500,t:1527030795510};\\\", \\\"{x:1481,y:505,t:1527030795527};\\\", \\\"{x:1481,y:509,t:1527030795543};\\\", \\\"{x:1482,y:511,t:1527030795560};\\\", \\\"{x:1482,y:513,t:1527030795577};\\\", \\\"{x:1482,y:515,t:1527030795593};\\\", \\\"{x:1482,y:517,t:1527030795610};\\\", \\\"{x:1483,y:520,t:1527030795627};\\\", \\\"{x:1483,y:523,t:1527030795645};\\\", \\\"{x:1483,y:525,t:1527030795660};\\\", \\\"{x:1483,y:528,t:1527030795677};\\\", \\\"{x:1483,y:530,t:1527030795695};\\\", \\\"{x:1485,y:532,t:1527030795710};\\\", \\\"{x:1485,y:535,t:1527030795727};\\\", \\\"{x:1485,y:538,t:1527030795745};\\\", \\\"{x:1485,y:542,t:1527030795760};\\\", \\\"{x:1485,y:545,t:1527030795778};\\\", \\\"{x:1485,y:550,t:1527030795794};\\\", \\\"{x:1485,y:554,t:1527030795811};\\\", \\\"{x:1485,y:559,t:1527030795828};\\\", \\\"{x:1485,y:563,t:1527030795845};\\\", \\\"{x:1485,y:569,t:1527030795861};\\\", \\\"{x:1485,y:572,t:1527030795878};\\\", \\\"{x:1485,y:577,t:1527030795895};\\\", \\\"{x:1485,y:582,t:1527030795910};\\\", \\\"{x:1485,y:585,t:1527030795928};\\\", \\\"{x:1486,y:590,t:1527030795945};\\\", \\\"{x:1486,y:593,t:1527030795960};\\\", \\\"{x:1486,y:596,t:1527030795977};\\\", \\\"{x:1487,y:599,t:1527030795995};\\\", \\\"{x:1487,y:602,t:1527030796011};\\\", \\\"{x:1488,y:604,t:1527030796027};\\\", \\\"{x:1488,y:606,t:1527030796045};\\\", \\\"{x:1489,y:607,t:1527030796061};\\\", \\\"{x:1489,y:608,t:1527030796077};\\\", \\\"{x:1489,y:609,t:1527030796095};\\\", \\\"{x:1489,y:611,t:1527030796112};\\\", \\\"{x:1489,y:612,t:1527030796128};\\\", \\\"{x:1489,y:613,t:1527030796145};\\\", \\\"{x:1489,y:614,t:1527030796161};\\\", \\\"{x:1489,y:615,t:1527030796177};\\\", \\\"{x:1489,y:616,t:1527030796220};\\\", \\\"{x:1489,y:615,t:1527030796387};\\\", \\\"{x:1489,y:610,t:1527030796395};\\\", \\\"{x:1488,y:594,t:1527030796411};\\\", \\\"{x:1488,y:574,t:1527030796429};\\\", \\\"{x:1487,y:556,t:1527030796445};\\\", \\\"{x:1487,y:536,t:1527030796462};\\\", \\\"{x:1487,y:514,t:1527030796479};\\\", \\\"{x:1487,y:495,t:1527030796495};\\\", \\\"{x:1487,y:477,t:1527030796511};\\\", \\\"{x:1487,y:458,t:1527030796529};\\\", \\\"{x:1487,y:441,t:1527030796545};\\\", \\\"{x:1486,y:427,t:1527030796562};\\\", \\\"{x:1485,y:418,t:1527030796578};\\\", \\\"{x:1484,y:410,t:1527030796594};\\\", \\\"{x:1484,y:404,t:1527030796611};\\\", \\\"{x:1483,y:400,t:1527030796628};\\\", \\\"{x:1483,y:398,t:1527030796644};\\\", \\\"{x:1482,y:395,t:1527030796662};\\\", \\\"{x:1482,y:394,t:1527030796683};\\\", \\\"{x:1482,y:393,t:1527030796694};\\\", \\\"{x:1482,y:392,t:1527030796712};\\\", \\\"{x:1482,y:389,t:1527030796729};\\\", \\\"{x:1482,y:388,t:1527030796745};\\\", \\\"{x:1482,y:386,t:1527030796761};\\\", \\\"{x:1482,y:384,t:1527030796778};\\\", \\\"{x:1482,y:382,t:1527030796794};\\\", \\\"{x:1482,y:380,t:1527030796811};\\\", \\\"{x:1482,y:378,t:1527030796828};\\\", \\\"{x:1482,y:377,t:1527030796851};\\\", \\\"{x:1482,y:375,t:1527030796930};\\\", \\\"{x:1483,y:374,t:1527030796946};\\\", \\\"{x:1483,y:373,t:1527030796978};\\\", \\\"{x:1484,y:374,t:1527030800187};\\\", \\\"{x:1485,y:374,t:1527030800197};\\\", \\\"{x:1487,y:374,t:1527030800215};\\\", \\\"{x:1488,y:375,t:1527030800283};\\\", \\\"{x:1487,y:375,t:1527030803260};\\\", \\\"{x:1484,y:375,t:1527030803267};\\\", \\\"{x:1482,y:375,t:1527030803284};\\\", \\\"{x:1481,y:375,t:1527030803315};\\\", \\\"{x:1480,y:375,t:1527030803340};\\\", \\\"{x:1479,y:375,t:1527030803371};\\\", \\\"{x:1478,y:375,t:1527030803395};\\\", \\\"{x:1477,y:375,t:1527030803403};\\\", \\\"{x:1476,y:375,t:1527030803435};\\\", \\\"{x:1475,y:375,t:1527030803580};\\\", \\\"{x:1473,y:375,t:1527030803587};\\\", \\\"{x:1472,y:374,t:1527030803600};\\\", \\\"{x:1471,y:374,t:1527030803617};\\\", \\\"{x:1470,y:373,t:1527030803634};\\\", \\\"{x:1468,y:373,t:1527030803650};\\\", \\\"{x:1466,y:371,t:1527030803666};\\\", \\\"{x:1465,y:370,t:1527030803691};\\\", \\\"{x:1463,y:369,t:1527030803723};\\\", \\\"{x:1461,y:369,t:1527030803835};\\\", \\\"{x:1457,y:369,t:1527030803851};\\\", \\\"{x:1454,y:369,t:1527030803867};\\\", \\\"{x:1451,y:369,t:1527030803884};\\\", \\\"{x:1447,y:369,t:1527030803901};\\\", \\\"{x:1444,y:371,t:1527030803917};\\\", \\\"{x:1443,y:371,t:1527030803934};\\\", \\\"{x:1443,y:372,t:1527030803951};\\\", \\\"{x:1442,y:373,t:1527030803968};\\\", \\\"{x:1441,y:373,t:1527030804220};\\\", \\\"{x:1440,y:373,t:1527030804235};\\\", \\\"{x:1439,y:375,t:1527030804251};\\\", \\\"{x:1439,y:376,t:1527030804267};\\\", \\\"{x:1433,y:379,t:1527030806107};\\\", \\\"{x:1415,y:390,t:1527030806119};\\\", \\\"{x:1385,y:404,t:1527030806135};\\\", \\\"{x:1338,y:422,t:1527030806153};\\\", \\\"{x:1247,y:448,t:1527030806169};\\\", \\\"{x:1185,y:466,t:1527030806185};\\\", \\\"{x:1078,y:491,t:1527030806203};\\\", \\\"{x:1019,y:501,t:1527030806219};\\\", \\\"{x:955,y:510,t:1527030806236};\\\", \\\"{x:905,y:517,t:1527030806254};\\\", \\\"{x:871,y:523,t:1527030806268};\\\", \\\"{x:853,y:525,t:1527030806285};\\\", \\\"{x:840,y:527,t:1527030806302};\\\", \\\"{x:835,y:527,t:1527030806318};\\\", \\\"{x:828,y:527,t:1527030806335};\\\", \\\"{x:815,y:529,t:1527030806352};\\\", \\\"{x:805,y:530,t:1527030806368};\\\", \\\"{x:793,y:532,t:1527030806385};\\\", \\\"{x:768,y:537,t:1527030806401};\\\", \\\"{x:753,y:542,t:1527030806420};\\\", \\\"{x:742,y:547,t:1527030806435};\\\", \\\"{x:731,y:552,t:1527030806452};\\\", \\\"{x:721,y:558,t:1527030806470};\\\", \\\"{x:709,y:567,t:1527030806485};\\\", \\\"{x:690,y:580,t:1527030806503};\\\", \\\"{x:668,y:591,t:1527030806519};\\\", \\\"{x:648,y:601,t:1527030806535};\\\", \\\"{x:633,y:607,t:1527030806553};\\\", \\\"{x:622,y:612,t:1527030806569};\\\", \\\"{x:600,y:622,t:1527030806587};\\\", \\\"{x:585,y:623,t:1527030806603};\\\", \\\"{x:571,y:624,t:1527030806619};\\\", \\\"{x:563,y:624,t:1527030806635};\\\", \\\"{x:562,y:624,t:1527030806652};\\\", \\\"{x:559,y:624,t:1527030806669};\\\", \\\"{x:558,y:622,t:1527030806685};\\\", \\\"{x:554,y:619,t:1527030806702};\\\", \\\"{x:552,y:617,t:1527030806719};\\\", \\\"{x:550,y:615,t:1527030806735};\\\", \\\"{x:550,y:614,t:1527030806753};\\\", \\\"{x:549,y:613,t:1527030806770};\\\", \\\"{x:552,y:613,t:1527030806867};\\\", \\\"{x:552,y:612,t:1527030806874};\\\", \\\"{x:554,y:612,t:1527030806887};\\\", \\\"{x:556,y:611,t:1527030806902};\\\", \\\"{x:560,y:610,t:1527030806919};\\\", \\\"{x:563,y:608,t:1527030806936};\\\", \\\"{x:567,y:606,t:1527030806954};\\\", \\\"{x:569,y:605,t:1527030806969};\\\", \\\"{x:574,y:605,t:1527030806986};\\\", \\\"{x:582,y:602,t:1527030807002};\\\", \\\"{x:594,y:598,t:1527030807019};\\\", \\\"{x:601,y:596,t:1527030807037};\\\", \\\"{x:605,y:596,t:1527030807052};\\\", \\\"{x:606,y:595,t:1527030807107};\\\", \\\"{x:608,y:593,t:1527030807119};\\\", \\\"{x:613,y:585,t:1527030807137};\\\", \\\"{x:617,y:576,t:1527030807155};\\\", \\\"{x:618,y:574,t:1527030807169};\\\", \\\"{x:619,y:573,t:1527030807186};\\\", \\\"{x:618,y:576,t:1527030807402};\\\", \\\"{x:618,y:579,t:1527030807421};\\\", \\\"{x:617,y:580,t:1527030807436};\\\", \\\"{x:616,y:582,t:1527030807453};\\\", \\\"{x:616,y:583,t:1527030807469};\\\", \\\"{x:615,y:584,t:1527030807522};\\\", \\\"{x:615,y:585,t:1527030807546};\\\", \\\"{x:614,y:586,t:1527030807703};\\\", \\\"{x:614,y:586,t:1527030807783};\\\", \\\"{x:615,y:588,t:1527030807882};\\\", \\\"{x:616,y:589,t:1527030807898};\\\", \\\"{x:617,y:589,t:1527030807906};\\\", \\\"{x:619,y:589,t:1527030807946};\\\", \\\"{x:620,y:589,t:1527030807954};\\\", \\\"{x:621,y:589,t:1527030807970};\\\", \\\"{x:625,y:589,t:1527030807986};\\\", \\\"{x:631,y:589,t:1527030808004};\\\", \\\"{x:644,y:589,t:1527030808021};\\\", \\\"{x:652,y:589,t:1527030808037};\\\", \\\"{x:654,y:591,t:1527030808053};\\\", \\\"{x:654,y:596,t:1527030808070};\\\", \\\"{x:649,y:601,t:1527030808086};\\\", \\\"{x:637,y:605,t:1527030808104};\\\", \\\"{x:618,y:606,t:1527030808120};\\\", \\\"{x:579,y:614,t:1527030808138};\\\", \\\"{x:489,y:631,t:1527030808154};\\\", \\\"{x:346,y:662,t:1527030808172};\\\", \\\"{x:294,y:675,t:1527030808187};\\\", \\\"{x:271,y:677,t:1527030808204};\\\", \\\"{x:264,y:679,t:1527030808220};\\\", \\\"{x:265,y:677,t:1527030808274};\\\", \\\"{x:266,y:675,t:1527030808286};\\\", \\\"{x:270,y:671,t:1527030808304};\\\", \\\"{x:274,y:667,t:1527030808321};\\\", \\\"{x:279,y:663,t:1527030808337};\\\", \\\"{x:282,y:659,t:1527030808353};\\\", \\\"{x:285,y:656,t:1527030808369};\\\", \\\"{x:288,y:655,t:1527030808387};\\\", \\\"{x:295,y:649,t:1527030808403};\\\", \\\"{x:305,y:642,t:1527030808420};\\\", \\\"{x:314,y:637,t:1527030808437};\\\", \\\"{x:319,y:633,t:1527030808453};\\\", \\\"{x:322,y:631,t:1527030808470};\\\", \\\"{x:322,y:630,t:1527030808487};\\\", \\\"{x:324,y:629,t:1527030808504};\\\", \\\"{x:326,y:627,t:1527030808520};\\\", \\\"{x:328,y:625,t:1527030808538};\\\", \\\"{x:339,y:620,t:1527030808555};\\\", \\\"{x:347,y:616,t:1527030808571};\\\", \\\"{x:349,y:616,t:1527030808587};\\\", \\\"{x:354,y:616,t:1527030808605};\\\", \\\"{x:357,y:615,t:1527030808620};\\\", \\\"{x:362,y:612,t:1527030808639};\\\", \\\"{x:366,y:611,t:1527030808655};\\\", \\\"{x:370,y:609,t:1527030808670};\\\", \\\"{x:376,y:606,t:1527030808688};\\\", \\\"{x:381,y:602,t:1527030808704};\\\", \\\"{x:386,y:598,t:1527030808721};\\\", \\\"{x:388,y:596,t:1527030808737};\\\", \\\"{x:393,y:597,t:1527030809074};\\\", \\\"{x:396,y:601,t:1527030809087};\\\", \\\"{x:409,y:614,t:1527030809105};\\\", \\\"{x:423,y:628,t:1527030809121};\\\", \\\"{x:437,y:644,t:1527030809138};\\\", \\\"{x:446,y:655,t:1527030809154};\\\", \\\"{x:454,y:661,t:1527030809171};\\\", \\\"{x:463,y:669,t:1527030809187};\\\", \\\"{x:471,y:678,t:1527030809204};\\\", \\\"{x:485,y:689,t:1527030809222};\\\", \\\"{x:494,y:696,t:1527030809238};\\\", \\\"{x:503,y:701,t:1527030809254};\\\", \\\"{x:508,y:705,t:1527030809271};\\\", \\\"{x:512,y:707,t:1527030809288};\\\", \\\"{x:514,y:709,t:1527030809305};\\\", \\\"{x:516,y:711,t:1527030809322};\\\", \\\"{x:519,y:714,t:1527030809338};\\\", \\\"{x:522,y:717,t:1527030809354};\\\", \\\"{x:523,y:722,t:1527030809371};\\\", \\\"{x:525,y:727,t:1527030809388};\\\", \\\"{x:525,y:729,t:1527030809410};\\\", \\\"{x:525,y:730,t:1527030809421};\\\", \\\"{x:525,y:731,t:1527030809458};\\\", \\\"{x:525,y:734,t:1527030809472};\\\", \\\"{x:525,y:741,t:1527030809489};\\\", \\\"{x:527,y:746,t:1527030809504};\\\", \\\"{x:527,y:750,t:1527030809521};\\\", \\\"{x:527,y:752,t:1527030809538};\\\", \\\"{x:527,y:753,t:1527030810099};\\\" ] }, { \\\"rt\\\": 74344, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 764864, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"find the line going out from point 12PM on the x axis and find points on that path.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 10850, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"China\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 776718, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 26977, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Engineering\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 804715, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 13083, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 819123, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"ZY4DY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"ZY4DY\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 178, dom: 996, initialDom: 1102",
  "javascriptErrors": []
}