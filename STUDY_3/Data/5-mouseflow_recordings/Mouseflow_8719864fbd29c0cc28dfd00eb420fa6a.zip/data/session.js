var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8719864fbd29c0cc28dfd00eb420fa6a",
  "created": "2018-06-01T11:22:56.5094633-07:00",
  "lastActivity": "2018-06-01T11:23:08.1056257-07:00",
  "pageViews": [
    {
      "id": "060156586784d245a74d8a5fc51bdda157b9286a",
      "startTime": "2018-06-01T11:22:56.6876257-07:00",
      "endTime": "2018-06-01T11:23:08.1056257-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 11418,
      "engagementTime": 11410,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 11418,
  "engagementTime": 11410,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CE3B9",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6d0f003422c5b989c95c0176896b3309",
  "gdpr": false
}