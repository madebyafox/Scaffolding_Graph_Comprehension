var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "76a452fef41b5f4d4e9dfd6d0291cbad",
  "created": "2018-06-01T11:20:20.2162859-07:00",
  "lastActivity": "2018-06-01T11:24:56.0532859-07:00",
  "pageViews": [
    {
      "id": "06012005053368f7b6130958dc0ef7dfdc3b628d",
      "startTime": "2018-06-01T11:20:20.2162859-07:00",
      "endTime": "2018-06-01T11:24:56.0532859-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 275837,
      "engagementTime": 242182,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 275837,
  "engagementTime": 242182,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=5KWEX",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c9c9795474aa3bee41ad9a90b566b63a",
  "gdpr": false
}