var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "44c35976a43fbe10c8e1e90078569c2c",
  "created": "2018-05-29T14:15:25.2851751-07:00",
  "lastActivity": "2018-05-29T14:15:43.5081751-07:00",
  "pageViews": [
    {
      "id": "052925413660aac48f2db6ecc26ba36a839e99d2",
      "startTime": "2018-05-29T14:15:25.2851751-07:00",
      "endTime": "2018-05-29T14:15:43.5081751-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 18223,
      "engagementTime": 18182,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 18223,
  "engagementTime": 18182,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=NN1Z0",
    "CONDITION=115",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0c3d81b342985d1014d2c741a879ce0f",
  "gdpr": false
}