var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "fe597c6a5c2c06d23b80d5cb457d22ad",
  "created": "2018-05-21T13:17:17.3648079-07:00",
  "lastActivity": "2018-05-21T13:18:05.4889531-07:00",
  "pageViews": [
    {
      "id": "05211747983f37a9e8434e6041812f2aa287ad2b",
      "startTime": "2018-05-21T13:17:17.5258816-07:00",
      "endTime": "2018-05-21T13:18:05.4889531-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 48014,
      "engagementTime": 47946,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 48014,
  "engagementTime": 47946,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=5GELG",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7b96179eecb89b82fe0d5cd8ae76f9ce",
  "gdpr": false
}