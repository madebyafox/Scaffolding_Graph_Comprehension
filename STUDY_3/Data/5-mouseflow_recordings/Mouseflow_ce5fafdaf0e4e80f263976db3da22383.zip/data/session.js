var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ce5fafdaf0e4e80f263976db3da22383",
  "created": "2018-05-22T14:10:48.674585-07:00",
  "lastActivity": "2018-05-22T14:11:05.590585-07:00",
  "pageViews": [
    {
      "id": "052248280f1f98567711a2b0b0777c6576fda64e",
      "startTime": "2018-05-22T14:10:48.674585-07:00",
      "endTime": "2018-05-22T14:11:05.590585-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 16916,
      "engagementTime": 16809,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 16916,
  "engagementTime": 16809,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=QOJ6L",
    "CONDITION=121",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "da863d5c3012f04e10b69ece55903d23",
  "gdpr": false
}