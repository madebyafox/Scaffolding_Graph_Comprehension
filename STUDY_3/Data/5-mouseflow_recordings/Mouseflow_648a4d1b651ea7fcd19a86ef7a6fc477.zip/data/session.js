var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "648a4d1b651ea7fcd19a86ef7a6fc477",
  "created": "2018-06-01T10:11:52.0531132-07:00",
  "lastActivity": "2018-06-01T10:12:04.1124259-07:00",
  "pageViews": [
    {
      "id": "060152029703cf77ffcd2bb0307bf383d1b9d37d",
      "startTime": "2018-06-01T10:11:52.2542442-07:00",
      "endTime": "2018-06-01T10:12:04.1124259-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 12063,
      "engagementTime": 12027,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 12063,
  "engagementTime": 12027,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=1Z2H9",
    "CONDITION=115",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f63320220c7c74c5e9fa6a8294389ab6",
  "gdpr": false
}