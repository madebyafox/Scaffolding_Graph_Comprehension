var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6c632e750805ae3f2ea7924e7a18dbe9",
  "created": "2018-05-29T10:11:38.9276165-07:00",
  "lastActivity": "2018-05-29T10:12:26.0746165-07:00",
  "pageViews": [
    {
      "id": "0529399508a05f2eabcccf2315228dce6836524c",
      "startTime": "2018-05-29T10:11:38.9276165-07:00",
      "endTime": "2018-05-29T10:12:26.0746165-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 47147,
      "engagementTime": 43537,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 47147,
  "engagementTime": 43537,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=J80QC",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1f019fd267f44f48af72e88437154d2e",
  "gdpr": false
}