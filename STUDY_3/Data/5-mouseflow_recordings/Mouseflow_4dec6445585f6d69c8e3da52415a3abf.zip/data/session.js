var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4dec6445585f6d69c8e3da52415a3abf",
  "created": "2018-05-22T14:11:15.5065656-07:00",
  "lastActivity": "2018-05-22T14:12:07.0506534-07:00",
  "pageViews": [
    {
      "id": "05221583f5b869ac3c51074d035a756a9e13e9e6",
      "startTime": "2018-05-22T14:11:15.6136534-07:00",
      "endTime": "2018-05-22T14:12:07.0506534-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 51437,
      "engagementTime": 33835,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 51437,
  "engagementTime": 33835,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=T5SHZ",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8979a6e9e4923a7483e8734b0851426b",
  "gdpr": false
}