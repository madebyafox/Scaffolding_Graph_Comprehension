var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052916189a29dd0faa3eb6fd2d413270d1c55648"] = {
  "startTime": "2018-05-29T18:03:16.4786635Z",
  "websitePageUrl": "/16",
  "visitTime": 93269,
  "engagementTime": 88504,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "98b539a7fa0780f12727c386d1f0abe3",
    "created": "2018-05-29T18:03:16.4462545+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=1N858",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "5e9fe66e0209c3f3af0b72867ab570af",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/98b539a7fa0780f12727c386d1f0abe3/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 229,
      "e": 229,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 229,
      "e": 229,
      "ty": 2,
      "x": 560,
      "y": 727
    },
    {
      "t": 229,
      "e": 229,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 254,
      "e": 254,
      "ty": 41,
      "x": 52035,
      "y": 39830,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 559,
      "y": 716
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 2,
      "x": 557,
      "y": 713
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 41,
      "x": 51698,
      "y": 39055,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 554,
      "y": 707
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 551,
      "y": 702
    },
    {
      "t": 1252,
      "e": 1252,
      "ty": 41,
      "x": 50911,
      "y": 38390,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 550,
      "y": 701
    },
    {
      "t": 1402,
      "e": 1402,
      "ty": 2,
      "x": 548,
      "y": 697
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 2,
      "x": 545,
      "y": 693
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 50349,
      "y": 37947,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1602,
      "e": 1602,
      "ty": 2,
      "x": 535,
      "y": 680
    },
    {
      "t": 1702,
      "e": 1702,
      "ty": 2,
      "x": 513,
      "y": 649
    },
    {
      "t": 1752,
      "e": 1752,
      "ty": 41,
      "x": 46189,
      "y": 35011,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1802,
      "e": 1802,
      "ty": 2,
      "x": 503,
      "y": 631
    },
    {
      "t": 1902,
      "e": 1902,
      "ty": 2,
      "x": 485,
      "y": 604
    },
    {
      "t": 1919,
      "e": 1919,
      "ty": 6,
      "x": 481,
      "y": 600,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 470,
      "y": 589
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 41918,
      "y": 53613,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2102,
      "e": 2102,
      "ty": 2,
      "x": 457,
      "y": 582
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 446,
      "y": 577
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 39220,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2302,
      "e": 2302,
      "ty": 2,
      "x": 445,
      "y": 577
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 41,
      "x": 39108,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2693,
      "e": 2693,
      "ty": 3,
      "x": 445,
      "y": 577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2694,
      "e": 2694,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2820,
      "e": 2820,
      "ty": 4,
      "x": 39108,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2821,
      "e": 2821,
      "ty": 5,
      "x": 445,
      "y": 577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 445,
      "y": 576
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 41,
      "x": 39108,
      "y": 43095,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 492,
      "y": 576
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 497,
      "y": 576
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 44953,
      "y": 43095,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 520,
      "y": 574
    },
    {
      "t": 4154,
      "e": 4154,
      "ty": 7,
      "x": 645,
      "y": 606,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 767,
      "y": 640
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 7752,
      "y": 39249,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 908,
      "y": 705
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 874,
      "y": 765
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 2,
      "x": 806,
      "y": 811
    },
    {
      "t": 4501,
      "e": 4501,
      "ty": 41,
      "x": 1410,
      "y": 48202,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 801,
      "y": 813
    },
    {
      "t": 4752,
      "e": 4752,
      "ty": 41,
      "x": 1058,
      "y": 48345,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10001,
      "e": 9752,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 13042,
      "e": 9752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 13042,
      "e": 9752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13151,
      "e": 9861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "b"
    },
    {
      "t": 13240,
      "e": 9950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 13240,
      "e": 9950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13343,
      "e": 10053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "by"
    },
    {
      "t": 13496,
      "e": 10206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13497,
      "e": 10207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13590,
      "e": 10300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "by "
    },
    {
      "t": 13831,
      "e": 10541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 13831,
      "e": 10541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13904,
      "e": 10614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "by l"
    },
    {
      "t": 14048,
      "e": 10758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 14048,
      "e": 10758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14119,
      "e": 10829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 14208,
      "e": 10918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 14209,
      "e": 10919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14271,
      "e": 10981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 14384,
      "e": 11094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 14384,
      "e": 11094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14479,
      "e": 11189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 15399,
      "e": 12109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15400,
      "e": 12110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15503,
      "e": 12213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 15680,
      "e": 12390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 15681,
      "e": 12391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15768,
      "e": 12478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 15800,
      "e": 12510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 15800,
      "e": 12510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15927,
      "e": 12637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 15935,
      "e": 12645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15935,
      "e": 12645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16022,
      "e": 12732,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16159,
      "e": 12869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16160,
      "e": 12870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16280,
      "e": 12990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 16312,
      "e": 13022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16313,
      "e": 13023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16368,
      "e": 13078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16447,
      "e": 13157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16449,
      "e": 13159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16552,
      "e": 13262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16632,
      "e": 13342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16633,
      "e": 13343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16711,
      "e": 13421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16808,
      "e": 13518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16808,
      "e": 13518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16887,
      "e": 13597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 16943,
      "e": 13653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16943,
      "e": 13653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17023,
      "e": 13733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 17072,
      "e": 13782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17072,
      "e": 13782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17167,
      "e": 13877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17528,
      "e": 14238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 17529,
      "e": 14239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17656,
      "e": 14366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 17799,
      "e": 14509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17801,
      "e": 14511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17919,
      "e": 14629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18015,
      "e": 14725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18016,
      "e": 14726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18152,
      "e": 14862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 18296,
      "e": 15006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 18297,
      "e": 15007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18399,
      "e": 15109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 18487,
      "e": 15197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18488,
      "e": 15198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18584,
      "e": 15294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 18688,
      "e": 15398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 18689,
      "e": 15399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18799,
      "e": 15509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 18847,
      "e": 15557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18847,
      "e": 15557,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18944,
      "e": 15654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20001,
      "e": 16711,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 22224,
      "e": 18934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 22225,
      "e": 18935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22319,
      "e": 19029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22320,
      "e": 19030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22328,
      "e": 19038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||yo"
    },
    {
      "t": 22399,
      "e": 19109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22551,
      "e": 19261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 22552,
      "e": 19262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22622,
      "e": 19332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 22791,
      "e": 19501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22792,
      "e": 19502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22887,
      "e": 19597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22919,
      "e": 19629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 22919,
      "e": 19629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23023,
      "e": 19733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 23129,
      "e": 19839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23129,
      "e": 19839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23207,
      "e": 19917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 23287,
      "e": 19997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23287,
      "e": 19997,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23359,
      "e": 20069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 23480,
      "e": 20190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23480,
      "e": 20190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23599,
      "e": 20309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23743,
      "e": 20453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23743,
      "e": 20453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23847,
      "e": 20557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 23864,
      "e": 20574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 23864,
      "e": 20574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23943,
      "e": 20653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 24152,
      "e": 20862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24152,
      "e": 20862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24160,
      "e": 20870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 24160,
      "e": 20870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24215,
      "e": 20925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ol"
    },
    {
      "t": 24231,
      "e": 20941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24488,
      "e": 21198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 24489,
      "e": 21199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24567,
      "e": 21277,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 24584,
      "e": 21294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24584,
      "e": 21294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24655,
      "e": 21365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 24719,
      "e": 21429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24719,
      "e": 21429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24807,
      "e": 21517,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25575,
      "e": 22285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 25623,
      "e": 22333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "by looking at the x axis you see abolve"
    },
    {
      "t": 25711,
      "e": 22421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 25759,
      "e": 22469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "by looking at the x axis you see abolv"
    },
    {
      "t": 25823,
      "e": 22533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 25895,
      "e": 22605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "by looking at the x axis you see abol"
    },
    {
      "t": 25968,
      "e": 22678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26039,
      "e": 22749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "by looking at the x axis you see abo"
    },
    {
      "t": 26679,
      "e": 23389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 26680,
      "e": 23390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26759,
      "e": 23469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 26815,
      "e": 23525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26816,
      "e": 23526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26903,
      "e": 23613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26911,
      "e": 23621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26912,
      "e": 23622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27016,
      "e": 23726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27167,
      "e": 23877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 27167,
      "e": 23877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27287,
      "e": 23997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 27431,
      "e": 24141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 27433,
      "e": 24143,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27543,
      "e": 24253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 27672,
      "e": 24382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 27673,
      "e": 24383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27742,
      "e": 24452,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 27920,
      "e": 24630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 27921,
      "e": 24631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27984,
      "e": 24694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 28103,
      "e": 24813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28104,
      "e": 24814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28176,
      "e": 24886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30001,
      "e": 26711,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 34367,
      "e": 29886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 34367,
      "e": 29886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34487,
      "e": 30006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 34535,
      "e": 30054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34536,
      "e": 30055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34655,
      "e": 30174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34657,
      "e": 30176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34687,
      "e": 30206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hi"
    },
    {
      "t": 34804,
      "e": 30323,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "by looking at the x axis you see above 12pm whi"
    },
    {
      "t": 34823,
      "e": 30342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34832,
      "e": 30351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 34832,
      "e": 30351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34894,
      "e": 30413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34895,
      "e": 30414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34934,
      "e": 30453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ch"
    },
    {
      "t": 34999,
      "e": 30518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35055,
      "e": 30574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35056,
      "e": 30575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35175,
      "e": 30694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35312,
      "e": 30831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35313,
      "e": 30832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35383,
      "e": 30902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 35415,
      "e": 30934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 35415,
      "e": 30934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35487,
      "e": 31006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 35519,
      "e": 31038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35520,
      "e": 31039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35615,
      "e": 31134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 35639,
      "e": 31158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 35639,
      "e": 31158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35758,
      "e": 31277,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 35815,
      "e": 31334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35815,
      "e": 31334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35919,
      "e": 31438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 36120,
      "e": 31639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 36120,
      "e": 31639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36143,
      "e": 31662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 36143,
      "e": 31662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36151,
      "e": 31670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sw"
    },
    {
      "t": 36175,
      "e": 31694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36279,
      "e": 31798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36279,
      "e": 31798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36404,
      "e": 31923,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "by looking at the x axis you see above 12pm which eventsw "
    },
    {
      "t": 36423,
      "e": 31942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38840,
      "e": 34359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38902,
      "e": 34421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "by looking at the x axis you see above 12pm which eventsw"
    },
    {
      "t": 38982,
      "e": 34501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39055,
      "e": 34574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "by looking at the x axis you see above 12pm which events"
    },
    {
      "t": 39608,
      "e": 35127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39609,
      "e": 35128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39719,
      "e": 35238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39983,
      "e": 35502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39985,
      "e": 35504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40001,
      "e": 35520,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40071,
      "e": 35590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40086,
      "e": 35605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40086,
      "e": 35605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40174,
      "e": 35693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 40191,
      "e": 35710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40191,
      "e": 35710,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40255,
      "e": 35774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 40343,
      "e": 35862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40344,
      "e": 35863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40432,
      "e": 35951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40559,
      "e": 36078,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40560,
      "e": 36079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40663,
      "e": 36182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40719,
      "e": 36238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40719,
      "e": 36238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40807,
      "e": 36326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 40832,
      "e": 36351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40832,
      "e": 36351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40919,
      "e": 36438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40919,
      "e": 36438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40943,
      "e": 36462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 41039,
      "e": 36558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41095,
      "e": 36614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41096,
      "e": 36615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41175,
      "e": 36694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41319,
      "e": 36838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 41320,
      "e": 36839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41408,
      "e": 36927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 41520,
      "e": 37039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41520,
      "e": 37039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41615,
      "e": 37134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 41638,
      "e": 37157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41639,
      "e": 37158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41655,
      "e": 37174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41655,
      "e": 37174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41727,
      "e": 37246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 41792,
      "e": 37311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41966,
      "e": 37485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41967,
      "e": 37486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42038,
      "e": 37557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 42119,
      "e": 37638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 42119,
      "e": 37638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42199,
      "e": 37718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 42319,
      "e": 37838,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 42321,
      "e": 37840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42406,
      "e": 37925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 42414,
      "e": 37933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 42414,
      "e": 37933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42502,
      "e": 38021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 42535,
      "e": 38054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42535,
      "e": 38054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42599,
      "e": 38118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43201,
      "e": 38720,
      "ty": 2,
      "x": 761,
      "y": 784
    },
    {
      "t": 43251,
      "e": 38770,
      "ty": 41,
      "x": 63276,
      "y": 38334,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 43302,
      "e": 38821,
      "ty": 2,
      "x": 659,
      "y": 700
    },
    {
      "t": 43402,
      "e": 38921,
      "ty": 2,
      "x": 584,
      "y": 744
    },
    {
      "t": 43529,
      "e": 39048,
      "ty": 2,
      "x": 483,
      "y": 724
    },
    {
      "t": 43530,
      "e": 39049,
      "ty": 41,
      "x": 43379,
      "y": 39664,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 43629,
      "e": 39148,
      "ty": 2,
      "x": 436,
      "y": 699
    },
    {
      "t": 43645,
      "e": 39164,
      "ty": 6,
      "x": 420,
      "y": 681,
      "ta": "#strategyButton"
    },
    {
      "t": 43729,
      "e": 39248,
      "ty": 2,
      "x": 417,
      "y": 679
    },
    {
      "t": 43778,
      "e": 39297,
      "ty": 41,
      "x": 42819,
      "y": 46771,
      "ta": "#strategyButton"
    },
    {
      "t": 43807,
      "e": 39326,
      "ty": 3,
      "x": 417,
      "y": 679,
      "ta": "#strategyButton"
    },
    {
      "t": 43807,
      "e": 39326,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "by looking at the x axis you see above 12pm which events tart at that time "
    },
    {
      "t": 43808,
      "e": 39327,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43808,
      "e": 39327,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 43878,
      "e": 39397,
      "ty": 4,
      "x": 42819,
      "y": 46771,
      "ta": "#strategyButton"
    },
    {
      "t": 43888,
      "e": 39407,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 43889,
      "e": 39408,
      "ty": 5,
      "x": 417,
      "y": 679,
      "ta": "#strategyButton"
    },
    {
      "t": 43897,
      "e": 39416,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 44279,
      "e": 39798,
      "ty": 41,
      "x": 14085,
      "y": 35565,
      "ta": "html > body"
    },
    {
      "t": 44329,
      "e": 39848,
      "ty": 2,
      "x": 344,
      "y": 468
    },
    {
      "t": 44428,
      "e": 39947,
      "ty": 2,
      "x": 417,
      "y": 370
    },
    {
      "t": 44529,
      "e": 40048,
      "ty": 2,
      "x": 427,
      "y": 375
    },
    {
      "t": 44530,
      "e": 40049,
      "ty": 41,
      "x": 14429,
      "y": 20330,
      "ta": "html > body"
    },
    {
      "t": 44829,
      "e": 40348,
      "ty": 2,
      "x": 452,
      "y": 379
    },
    {
      "t": 44896,
      "e": 40415,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 44929,
      "e": 40448,
      "ty": 2,
      "x": 596,
      "y": 416
    },
    {
      "t": 45029,
      "e": 40548,
      "ty": 2,
      "x": 870,
      "y": 455
    },
    {
      "t": 45029,
      "e": 40548,
      "ty": 41,
      "x": 29685,
      "y": 24762,
      "ta": "html > body"
    },
    {
      "t": 45129,
      "e": 40648,
      "ty": 2,
      "x": 871,
      "y": 455
    },
    {
      "t": 45279,
      "e": 40798,
      "ty": 41,
      "x": 29719,
      "y": 24762,
      "ta": "html > body"
    },
    {
      "t": 45449,
      "e": 40968,
      "ty": 2,
      "x": 952,
      "y": 605
    },
    {
      "t": 45529,
      "e": 41048,
      "ty": 2,
      "x": 956,
      "y": 608
    },
    {
      "t": 45529,
      "e": 41048,
      "ty": 41,
      "x": 32010,
      "y": 16383,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 45629,
      "e": 41148,
      "ty": 2,
      "x": 957,
      "y": 604
    },
    {
      "t": 45728,
      "e": 41247,
      "ty": 2,
      "x": 955,
      "y": 581
    },
    {
      "t": 45779,
      "e": 41298,
      "ty": 41,
      "x": 31794,
      "y": 62011,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 45781,
      "e": 41300,
      "ty": 6,
      "x": 955,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45829,
      "e": 41348,
      "ty": 2,
      "x": 955,
      "y": 569
    },
    {
      "t": 45929,
      "e": 41448,
      "ty": 2,
      "x": 954,
      "y": 568
    },
    {
      "t": 45975,
      "e": 41494,
      "ty": 3,
      "x": 954,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 45975,
      "e": 41494,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46029,
      "e": 41548,
      "ty": 41,
      "x": 31577,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46093,
      "e": 41612,
      "ty": 4,
      "x": 31577,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46094,
      "e": 41613,
      "ty": 5,
      "x": 954,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46635,
      "e": 42154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 46635,
      "e": 42154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46713,
      "e": 42232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 46794,
      "e": 42313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 46796,
      "e": 42315,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46866,
      "e": 42385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 47465,
      "e": 42984,
      "ty": 7,
      "x": 949,
      "y": 582,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47529,
      "e": 43048,
      "ty": 2,
      "x": 913,
      "y": 634
    },
    {
      "t": 47529,
      "e": 43048,
      "ty": 41,
      "x": 22710,
      "y": 35938,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 47629,
      "e": 43148,
      "ty": 2,
      "x": 911,
      "y": 646
    },
    {
      "t": 47633,
      "e": 43152,
      "ty": 6,
      "x": 910,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47729,
      "e": 43248,
      "ty": 2,
      "x": 909,
      "y": 649
    },
    {
      "t": 47779,
      "e": 43298,
      "ty": 41,
      "x": 21845,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47782,
      "e": 43298,
      "ty": 3,
      "x": 909,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47783,
      "e": 43299,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 47784,
      "e": 43300,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47784,
      "e": 43300,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47894,
      "e": 43410,
      "ty": 4,
      "x": 21845,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47894,
      "e": 43410,
      "ty": 5,
      "x": 909,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48394,
      "e": 43910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 48530,
      "e": 44046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 48531,
      "e": 44047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48619,
      "e": 44135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 48754,
      "e": 44270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 48755,
      "e": 44271,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48891,
      "e": 44407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 48962,
      "e": 44478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 50107,
      "e": 45623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 50162,
      "e": 45678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 50266,
      "e": 45782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 50314,
      "e": 45830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 50378,
      "e": 45894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 50482,
      "e": 45998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 51770,
      "e": 47286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 51898,
      "e": 47414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 52579,
      "e": 48095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 52579,
      "e": 48095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52682,
      "e": 48198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 52882,
      "e": 48398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 52883,
      "e": 48399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53026,
      "e": 48542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 53826,
      "e": 49342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 53826,
      "e": 49342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53978,
      "e": 49494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 54388,
      "e": 49904,
      "ty": 7,
      "x": 940,
      "y": 674,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54404,
      "e": 49920,
      "ty": 6,
      "x": 951,
      "y": 685,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54428,
      "e": 49944,
      "ty": 2,
      "x": 960,
      "y": 698
    },
    {
      "t": 54454,
      "e": 49970,
      "ty": 7,
      "x": 973,
      "y": 709,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54528,
      "e": 50044,
      "ty": 2,
      "x": 974,
      "y": 709
    },
    {
      "t": 54528,
      "e": 50044,
      "ty": 41,
      "x": 33266,
      "y": 38833,
      "ta": "html > body"
    },
    {
      "t": 54608,
      "e": 50124,
      "ty": 6,
      "x": 976,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54628,
      "e": 50144,
      "ty": 2,
      "x": 976,
      "y": 706
    },
    {
      "t": 54729,
      "e": 50245,
      "ty": 2,
      "x": 975,
      "y": 693
    },
    {
      "t": 54779,
      "e": 50295,
      "ty": 41,
      "x": 40756,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54791,
      "e": 50307,
      "ty": 3,
      "x": 975,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54792,
      "e": 50308,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 54792,
      "e": 50308,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54793,
      "e": 50309,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54894,
      "e": 50410,
      "ty": 4,
      "x": 40756,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54894,
      "e": 50410,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54895,
      "e": 50411,
      "ty": 5,
      "x": 975,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 54895,
      "e": 50411,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 55528,
      "e": 51044,
      "ty": 2,
      "x": 902,
      "y": 660
    },
    {
      "t": 55529,
      "e": 51045,
      "ty": 41,
      "x": 30787,
      "y": 36119,
      "ta": "html > body"
    },
    {
      "t": 55628,
      "e": 51144,
      "ty": 2,
      "x": 439,
      "y": 463
    },
    {
      "t": 55728,
      "e": 51244,
      "ty": 2,
      "x": 392,
      "y": 435
    },
    {
      "t": 55778,
      "e": 51294,
      "ty": 41,
      "x": 13017,
      "y": 23156,
      "ta": "html > body"
    },
    {
      "t": 55828,
      "e": 51344,
      "ty": 2,
      "x": 386,
      "y": 421
    },
    {
      "t": 55910,
      "e": 51426,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 55929,
      "e": 51445,
      "ty": 2,
      "x": 396,
      "y": 396
    },
    {
      "t": 56028,
      "e": 51544,
      "ty": 2,
      "x": 426,
      "y": 385
    },
    {
      "t": 56028,
      "e": 51544,
      "ty": 41,
      "x": 14394,
      "y": 20884,
      "ta": "html > body"
    },
    {
      "t": 56128,
      "e": 51644,
      "ty": 2,
      "x": 434,
      "y": 387
    },
    {
      "t": 56228,
      "e": 51744,
      "ty": 2,
      "x": 654,
      "y": 573
    },
    {
      "t": 56278,
      "e": 51794,
      "ty": 41,
      "x": 24622,
      "y": 32296,
      "ta": "html > body"
    },
    {
      "t": 56328,
      "e": 51844,
      "ty": 2,
      "x": 758,
      "y": 590
    },
    {
      "t": 56428,
      "e": 51944,
      "ty": 2,
      "x": 816,
      "y": 520
    },
    {
      "t": 56528,
      "e": 52044,
      "ty": 2,
      "x": 820,
      "y": 495
    },
    {
      "t": 56528,
      "e": 52044,
      "ty": 41,
      "x": 27963,
      "y": 26978,
      "ta": "html > body"
    },
    {
      "t": 56629,
      "e": 52145,
      "ty": 2,
      "x": 820,
      "y": 493
    },
    {
      "t": 56707,
      "e": 52223,
      "ty": 6,
      "x": 830,
      "y": 319,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 56723,
      "e": 52239,
      "ty": 7,
      "x": 845,
      "y": 255,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 56728,
      "e": 52244,
      "ty": 2,
      "x": 845,
      "y": 255
    },
    {
      "t": 56778,
      "e": 52294,
      "ty": 41,
      "x": 14139,
      "y": 1195,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 56829,
      "e": 52345,
      "ty": 2,
      "x": 883,
      "y": 177
    },
    {
      "t": 57028,
      "e": 52544,
      "ty": 2,
      "x": 870,
      "y": 211
    },
    {
      "t": 57028,
      "e": 52544,
      "ty": 41,
      "x": 11528,
      "y": 13272,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 57128,
      "e": 52644,
      "ty": 2,
      "x": 865,
      "y": 235
    },
    {
      "t": 57228,
      "e": 52744,
      "ty": 2,
      "x": 854,
      "y": 253
    },
    {
      "t": 57278,
      "e": 52794,
      "ty": 41,
      "x": 19480,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 57329,
      "e": 52845,
      "ty": 2,
      "x": 844,
      "y": 261
    },
    {
      "t": 57372,
      "e": 52888,
      "ty": 6,
      "x": 839,
      "y": 264,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 57429,
      "e": 52945,
      "ty": 2,
      "x": 838,
      "y": 264
    },
    {
      "t": 57528,
      "e": 53044,
      "ty": 2,
      "x": 833,
      "y": 266
    },
    {
      "t": 57529,
      "e": 53045,
      "ty": 41,
      "x": 33161,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 57575,
      "e": 53091,
      "ty": 3,
      "x": 833,
      "y": 266,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 57576,
      "e": 53092,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 57679,
      "e": 53195,
      "ty": 4,
      "x": 33161,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 57679,
      "e": 53195,
      "ty": 5,
      "x": 833,
      "y": 266,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 57680,
      "e": 53196,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf",
      "v": "Spanish"
    },
    {
      "t": 57990,
      "e": 53506,
      "ty": 7,
      "x": 833,
      "y": 278,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 58007,
      "e": 53523,
      "ty": 6,
      "x": 837,
      "y": 292,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 58029,
      "e": 53524,
      "ty": 2,
      "x": 838,
      "y": 296
    },
    {
      "t": 58030,
      "e": 53525,
      "ty": 41,
      "x": 58367,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 58056,
      "e": 53551,
      "ty": 7,
      "x": 839,
      "y": 301,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 58128,
      "e": 53623,
      "ty": 2,
      "x": 842,
      "y": 310
    },
    {
      "t": 58228,
      "e": 53723,
      "ty": 2,
      "x": 843,
      "y": 311
    },
    {
      "t": 58278,
      "e": 53773,
      "ty": 41,
      "x": 5121,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 58529,
      "e": 54024,
      "ty": 2,
      "x": 848,
      "y": 340
    },
    {
      "t": 58529,
      "e": 54024,
      "ty": 41,
      "x": 6307,
      "y": 13376,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 58628,
      "e": 54123,
      "ty": 2,
      "x": 868,
      "y": 382
    },
    {
      "t": 58728,
      "e": 54223,
      "ty": 2,
      "x": 876,
      "y": 392
    },
    {
      "t": 58778,
      "e": 54273,
      "ty": 41,
      "x": 12952,
      "y": 10019,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 58929,
      "e": 54424,
      "ty": 2,
      "x": 862,
      "y": 388
    },
    {
      "t": 59029,
      "e": 54524,
      "ty": 2,
      "x": 874,
      "y": 387
    },
    {
      "t": 59029,
      "e": 54524,
      "ty": 41,
      "x": 12478,
      "y": 8665,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 59128,
      "e": 54623,
      "ty": 2,
      "x": 1072,
      "y": 407
    },
    {
      "t": 59229,
      "e": 54724,
      "ty": 2,
      "x": 1087,
      "y": 407
    },
    {
      "t": 59278,
      "e": 54773,
      "ty": 41,
      "x": 63028,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 59328,
      "e": 54823,
      "ty": 2,
      "x": 1083,
      "y": 408
    },
    {
      "t": 59429,
      "e": 54924,
      "ty": 2,
      "x": 1020,
      "y": 411
    },
    {
      "t": 59528,
      "e": 55023,
      "ty": 2,
      "x": 1015,
      "y": 414
    },
    {
      "t": 59529,
      "e": 55024,
      "ty": 41,
      "x": 45940,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 59628,
      "e": 55123,
      "ty": 2,
      "x": 921,
      "y": 463
    },
    {
      "t": 59728,
      "e": 55223,
      "ty": 2,
      "x": 876,
      "y": 512
    },
    {
      "t": 59778,
      "e": 55273,
      "ty": 41,
      "x": 59189,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 59829,
      "e": 55324,
      "ty": 2,
      "x": 872,
      "y": 517
    },
    {
      "t": 59928,
      "e": 55423,
      "ty": 2,
      "x": 843,
      "y": 500
    },
    {
      "t": 59958,
      "e": 55453,
      "ty": 6,
      "x": 839,
      "y": 497,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 60025,
      "e": 55520,
      "ty": 7,
      "x": 835,
      "y": 491,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 60028,
      "e": 55523,
      "ty": 2,
      "x": 835,
      "y": 491
    },
    {
      "t": 60029,
      "e": 55524,
      "ty": 41,
      "x": 12187,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 60129,
      "e": 55624,
      "ty": 2,
      "x": 829,
      "y": 482
    },
    {
      "t": 60229,
      "e": 55724,
      "ty": 2,
      "x": 826,
      "y": 477
    },
    {
      "t": 60243,
      "e": 55738,
      "ty": 6,
      "x": 826,
      "y": 476,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 60279,
      "e": 55774,
      "ty": 41,
      "x": 0,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 60328,
      "e": 55823,
      "ty": 2,
      "x": 826,
      "y": 476
    },
    {
      "t": 60431,
      "e": 55926,
      "ty": 3,
      "x": 826,
      "y": 476,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 60433,
      "e": 55928,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 60434,
      "e": 55929,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 60510,
      "e": 56005,
      "ty": 4,
      "x": 0,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 60510,
      "e": 56005,
      "ty": 5,
      "x": 826,
      "y": 476,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 60510,
      "e": 56005,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 60729,
      "e": 56224,
      "ty": 2,
      "x": 826,
      "y": 475
    },
    {
      "t": 60778,
      "e": 56273,
      "ty": 41,
      "x": 0,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 60959,
      "e": 56454,
      "ty": 7,
      "x": 838,
      "y": 481,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 61028,
      "e": 56523,
      "ty": 2,
      "x": 906,
      "y": 538
    },
    {
      "t": 61029,
      "e": 56524,
      "ty": 41,
      "x": 20072,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 61129,
      "e": 56624,
      "ty": 2,
      "x": 944,
      "y": 564
    },
    {
      "t": 61278,
      "e": 56773,
      "ty": 41,
      "x": 30989,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 61329,
      "e": 56824,
      "ty": 2,
      "x": 959,
      "y": 579
    },
    {
      "t": 61428,
      "e": 56923,
      "ty": 2,
      "x": 969,
      "y": 582
    },
    {
      "t": 61529,
      "e": 57024,
      "ty": 41,
      "x": 35023,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 61779,
      "e": 57274,
      "ty": 41,
      "x": 34549,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 61829,
      "e": 57324,
      "ty": 2,
      "x": 965,
      "y": 588
    },
    {
      "t": 61929,
      "e": 57424,
      "ty": 2,
      "x": 959,
      "y": 596
    },
    {
      "t": 62028,
      "e": 57523,
      "ty": 2,
      "x": 954,
      "y": 606
    },
    {
      "t": 62029,
      "e": 57524,
      "ty": 41,
      "x": 31464,
      "y": 33253,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 62129,
      "e": 57624,
      "ty": 2,
      "x": 926,
      "y": 657
    },
    {
      "t": 62229,
      "e": 57724,
      "ty": 2,
      "x": 898,
      "y": 736
    },
    {
      "t": 62280,
      "e": 57725,
      "ty": 41,
      "x": 42870,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 62329,
      "e": 57774,
      "ty": 2,
      "x": 896,
      "y": 845
    },
    {
      "t": 62428,
      "e": 57873,
      "ty": 2,
      "x": 895,
      "y": 863
    },
    {
      "t": 62528,
      "e": 57973,
      "ty": 2,
      "x": 895,
      "y": 866
    },
    {
      "t": 62529,
      "e": 57974,
      "ty": 41,
      "x": 17461,
      "y": 52682,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 63279,
      "e": 58724,
      "ty": 41,
      "x": 7256,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 63328,
      "e": 58773,
      "ty": 2,
      "x": 842,
      "y": 824
    },
    {
      "t": 63528,
      "e": 58973,
      "ty": 2,
      "x": 837,
      "y": 830
    },
    {
      "t": 63528,
      "e": 58973,
      "ty": 41,
      "x": 3697,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 63628,
      "e": 59073,
      "ty": 2,
      "x": 833,
      "y": 835
    },
    {
      "t": 63630,
      "e": 59075,
      "ty": 6,
      "x": 833,
      "y": 836,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 63729,
      "e": 59174,
      "ty": 2,
      "x": 833,
      "y": 836
    },
    {
      "t": 63779,
      "e": 59224,
      "ty": 41,
      "x": 33161,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 63951,
      "e": 59396,
      "ty": 7,
      "x": 833,
      "y": 834,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 64012,
      "e": 59457,
      "ty": 6,
      "x": 833,
      "y": 820,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 64028,
      "e": 59473,
      "ty": 2,
      "x": 833,
      "y": 820
    },
    {
      "t": 64028,
      "e": 59473,
      "ty": 41,
      "x": 33161,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 64129,
      "e": 59574,
      "ty": 2,
      "x": 833,
      "y": 814
    },
    {
      "t": 64228,
      "e": 59673,
      "ty": 2,
      "x": 833,
      "y": 810
    },
    {
      "t": 64281,
      "e": 59726,
      "ty": 41,
      "x": 33161,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 64328,
      "e": 59773,
      "ty": 2,
      "x": 833,
      "y": 808
    },
    {
      "t": 64349,
      "e": 59794,
      "ty": 7,
      "x": 833,
      "y": 807,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 64429,
      "e": 59874,
      "ty": 2,
      "x": 833,
      "y": 807
    },
    {
      "t": 64529,
      "e": 59974,
      "ty": 41,
      "x": 6833,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 64929,
      "e": 60374,
      "ty": 2,
      "x": 833,
      "y": 804
    },
    {
      "t": 65028,
      "e": 60473,
      "ty": 2,
      "x": 854,
      "y": 763
    },
    {
      "t": 65029,
      "e": 60474,
      "ty": 41,
      "x": 13593,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 65128,
      "e": 60573,
      "ty": 2,
      "x": 872,
      "y": 718
    },
    {
      "t": 65229,
      "e": 60674,
      "ty": 2,
      "x": 873,
      "y": 709
    },
    {
      "t": 65279,
      "e": 60724,
      "ty": 41,
      "x": 12996,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 65329,
      "e": 60774,
      "ty": 2,
      "x": 876,
      "y": 696
    },
    {
      "t": 65429,
      "e": 60874,
      "ty": 2,
      "x": 876,
      "y": 680
    },
    {
      "t": 65529,
      "e": 60974,
      "ty": 2,
      "x": 874,
      "y": 671
    },
    {
      "t": 65529,
      "e": 60974,
      "ty": 41,
      "x": 14117,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 65629,
      "e": 61074,
      "ty": 2,
      "x": 860,
      "y": 656
    },
    {
      "t": 65729,
      "e": 61174,
      "ty": 2,
      "x": 860,
      "y": 652
    },
    {
      "t": 65778,
      "e": 61223,
      "ty": 41,
      "x": 9155,
      "y": 9478,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 65828,
      "e": 61273,
      "ty": 2,
      "x": 863,
      "y": 650
    },
    {
      "t": 65929,
      "e": 61374,
      "ty": 2,
      "x": 903,
      "y": 644
    },
    {
      "t": 66029,
      "e": 61474,
      "ty": 2,
      "x": 934,
      "y": 644
    },
    {
      "t": 66029,
      "e": 61474,
      "ty": 41,
      "x": 26717,
      "y": 7853,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 66129,
      "e": 61574,
      "ty": 2,
      "x": 972,
      "y": 648
    },
    {
      "t": 66229,
      "e": 61674,
      "ty": 2,
      "x": 962,
      "y": 660
    },
    {
      "t": 66279,
      "e": 61724,
      "ty": 41,
      "x": 33717,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 66328,
      "e": 61773,
      "ty": 2,
      "x": 937,
      "y": 671
    },
    {
      "t": 66428,
      "e": 61873,
      "ty": 2,
      "x": 928,
      "y": 675
    },
    {
      "t": 66529,
      "e": 61974,
      "ty": 2,
      "x": 928,
      "y": 677
    },
    {
      "t": 66529,
      "e": 61974,
      "ty": 41,
      "x": 28616,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 67529,
      "e": 62974,
      "ty": 2,
      "x": 928,
      "y": 680
    },
    {
      "t": 67529,
      "e": 62974,
      "ty": 41,
      "x": 28616,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 67628,
      "e": 63073,
      "ty": 2,
      "x": 914,
      "y": 698
    },
    {
      "t": 67729,
      "e": 63174,
      "ty": 2,
      "x": 913,
      "y": 704
    },
    {
      "t": 67779,
      "e": 63224,
      "ty": 41,
      "x": 23076,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 67829,
      "e": 63274,
      "ty": 2,
      "x": 912,
      "y": 708
    },
    {
      "t": 67930,
      "e": 63275,
      "ty": 2,
      "x": 911,
      "y": 715
    },
    {
      "t": 68029,
      "e": 63374,
      "ty": 41,
      "x": 21259,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 68279,
      "e": 63624,
      "ty": 41,
      "x": 20784,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 68329,
      "e": 63674,
      "ty": 2,
      "x": 901,
      "y": 705
    },
    {
      "t": 68429,
      "e": 63774,
      "ty": 2,
      "x": 899,
      "y": 703
    },
    {
      "t": 68529,
      "e": 63874,
      "ty": 41,
      "x": 19548,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 68629,
      "e": 63974,
      "ty": 2,
      "x": 896,
      "y": 701
    },
    {
      "t": 68779,
      "e": 64124,
      "ty": 41,
      "x": 18792,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 69129,
      "e": 64474,
      "ty": 2,
      "x": 896,
      "y": 703
    },
    {
      "t": 69229,
      "e": 64574,
      "ty": 2,
      "x": 896,
      "y": 713
    },
    {
      "t": 69279,
      "e": 64624,
      "ty": 41,
      "x": 18969,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 69329,
      "e": 64674,
      "ty": 2,
      "x": 898,
      "y": 729
    },
    {
      "t": 69429,
      "e": 64774,
      "ty": 2,
      "x": 900,
      "y": 739
    },
    {
      "t": 69529,
      "e": 64874,
      "ty": 2,
      "x": 900,
      "y": 740
    },
    {
      "t": 69529,
      "e": 64874,
      "ty": 41,
      "x": 19722,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 69629,
      "e": 64974,
      "ty": 2,
      "x": 900,
      "y": 743
    },
    {
      "t": 69779,
      "e": 65124,
      "ty": 41,
      "x": 18648,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 69929,
      "e": 65274,
      "ty": 2,
      "x": 899,
      "y": 742
    },
    {
      "t": 70029,
      "e": 65374,
      "ty": 2,
      "x": 899,
      "y": 740
    },
    {
      "t": 70029,
      "e": 65374,
      "ty": 41,
      "x": 19471,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 71729,
      "e": 67074,
      "ty": 2,
      "x": 895,
      "y": 754
    },
    {
      "t": 71779,
      "e": 67124,
      "ty": 41,
      "x": 30283,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 71829,
      "e": 67174,
      "ty": 2,
      "x": 893,
      "y": 761
    },
    {
      "t": 71928,
      "e": 67273,
      "ty": 2,
      "x": 891,
      "y": 775
    },
    {
      "t": 72029,
      "e": 67374,
      "ty": 2,
      "x": 891,
      "y": 787
    },
    {
      "t": 72029,
      "e": 67374,
      "ty": 41,
      "x": 38951,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 72129,
      "e": 67474,
      "ty": 2,
      "x": 889,
      "y": 807
    },
    {
      "t": 72229,
      "e": 67574,
      "ty": 2,
      "x": 889,
      "y": 821
    },
    {
      "t": 72279,
      "e": 67624,
      "ty": 41,
      "x": 16037,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 72329,
      "e": 67674,
      "ty": 2,
      "x": 889,
      "y": 835
    },
    {
      "t": 72429,
      "e": 67774,
      "ty": 2,
      "x": 888,
      "y": 849
    },
    {
      "t": 72529,
      "e": 67874,
      "ty": 2,
      "x": 880,
      "y": 859
    },
    {
      "t": 72529,
      "e": 67874,
      "ty": 41,
      "x": 13902,
      "y": 52158,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 72629,
      "e": 67974,
      "ty": 2,
      "x": 869,
      "y": 860
    },
    {
      "t": 72729,
      "e": 68074,
      "ty": 2,
      "x": 855,
      "y": 820
    },
    {
      "t": 72779,
      "e": 68124,
      "ty": 41,
      "x": 17678,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 72829,
      "e": 68174,
      "ty": 2,
      "x": 853,
      "y": 765
    },
    {
      "t": 72929,
      "e": 68274,
      "ty": 2,
      "x": 849,
      "y": 748
    },
    {
      "t": 73029,
      "e": 68374,
      "ty": 2,
      "x": 848,
      "y": 743
    },
    {
      "t": 73030,
      "e": 68375,
      "ty": 41,
      "x": 6307,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 73128,
      "e": 68473,
      "ty": 2,
      "x": 846,
      "y": 737
    },
    {
      "t": 73229,
      "e": 68574,
      "ty": 2,
      "x": 845,
      "y": 732
    },
    {
      "t": 73279,
      "e": 68624,
      "ty": 41,
      "x": 5917,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 73329,
      "e": 68674,
      "ty": 2,
      "x": 843,
      "y": 728
    },
    {
      "t": 73429,
      "e": 68774,
      "ty": 2,
      "x": 839,
      "y": 719
    },
    {
      "t": 73486,
      "e": 68831,
      "ty": 6,
      "x": 836,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 73529,
      "e": 68874,
      "ty": 2,
      "x": 835,
      "y": 704
    },
    {
      "t": 73529,
      "e": 68874,
      "ty": 41,
      "x": 43243,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 73629,
      "e": 68974,
      "ty": 2,
      "x": 834,
      "y": 698
    },
    {
      "t": 73780,
      "e": 69125,
      "ty": 41,
      "x": 38202,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 74687,
      "e": 70032,
      "ty": 7,
      "x": 843,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 74729,
      "e": 70074,
      "ty": 2,
      "x": 954,
      "y": 756
    },
    {
      "t": 74779,
      "e": 70124,
      "ty": 41,
      "x": 39362,
      "y": 45038,
      "ta": "html > body"
    },
    {
      "t": 74829,
      "e": 70174,
      "ty": 2,
      "x": 1222,
      "y": 841
    },
    {
      "t": 74928,
      "e": 70273,
      "ty": 2,
      "x": 1225,
      "y": 842
    },
    {
      "t": 75029,
      "e": 70374,
      "ty": 41,
      "x": 41910,
      "y": 46201,
      "ta": "html > body"
    },
    {
      "t": 75728,
      "e": 71073,
      "ty": 2,
      "x": 1124,
      "y": 993
    },
    {
      "t": 75779,
      "e": 71124,
      "ty": 41,
      "x": 37054,
      "y": 57059,
      "ta": "html > body"
    },
    {
      "t": 75828,
      "e": 71173,
      "ty": 2,
      "x": 1043,
      "y": 1039
    },
    {
      "t": 75871,
      "e": 71216,
      "ty": 6,
      "x": 953,
      "y": 1021,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 75922,
      "e": 71267,
      "ty": 7,
      "x": 902,
      "y": 996,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 75928,
      "e": 71273,
      "ty": 2,
      "x": 902,
      "y": 996
    },
    {
      "t": 76028,
      "e": 71373,
      "ty": 2,
      "x": 844,
      "y": 966
    },
    {
      "t": 76029,
      "e": 71374,
      "ty": 41,
      "x": 18263,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 76228,
      "e": 71573,
      "ty": 2,
      "x": 840,
      "y": 955
    },
    {
      "t": 76278,
      "e": 71623,
      "ty": 41,
      "x": 4171,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 76329,
      "e": 71674,
      "ty": 2,
      "x": 839,
      "y": 952
    },
    {
      "t": 76655,
      "e": 72000,
      "ty": 6,
      "x": 832,
      "y": 958,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 76728,
      "e": 72073,
      "ty": 2,
      "x": 827,
      "y": 964
    },
    {
      "t": 76778,
      "e": 72123,
      "ty": 41,
      "x": 2914,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 76840,
      "e": 72124,
      "ty": 3,
      "x": 827,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 76842,
      "e": 72126,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 76843,
      "e": 72127,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 76981,
      "e": 72265,
      "ty": 4,
      "x": 2914,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 76981,
      "e": 72265,
      "ty": 5,
      "x": 827,
      "y": 964,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 76982,
      "e": 72266,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 77174,
      "e": 72458,
      "ty": 7,
      "x": 828,
      "y": 970,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 77228,
      "e": 72512,
      "ty": 2,
      "x": 851,
      "y": 995
    },
    {
      "t": 77278,
      "e": 72562,
      "ty": 41,
      "x": 32340,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 77329,
      "e": 72613,
      "ty": 2,
      "x": 854,
      "y": 998
    },
    {
      "t": 77373,
      "e": 72657,
      "ty": 6,
      "x": 859,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 77428,
      "e": 72712,
      "ty": 2,
      "x": 873,
      "y": 1022
    },
    {
      "t": 77529,
      "e": 72813,
      "ty": 2,
      "x": 878,
      "y": 1028
    },
    {
      "t": 77529,
      "e": 72813,
      "ty": 41,
      "x": 25036,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78174,
      "e": 73458,
      "ty": 3,
      "x": 878,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78175,
      "e": 73459,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 78175,
      "e": 73459,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78287,
      "e": 73571,
      "ty": 4,
      "x": 25036,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78287,
      "e": 73571,
      "ty": 5,
      "x": 878,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78288,
      "e": 73572,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 78288,
      "e": 73572,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 78973,
      "e": 74257,
      "ty": 7,
      "x": 914,
      "y": 991,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 79028,
      "e": 74312,
      "ty": 2,
      "x": 994,
      "y": 929
    },
    {
      "t": 79028,
      "e": 74312,
      "ty": 41,
      "x": 40957,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 79129,
      "e": 74413,
      "ty": 2,
      "x": 1071,
      "y": 847
    },
    {
      "t": 79228,
      "e": 74512,
      "ty": 2,
      "x": 1072,
      "y": 834
    },
    {
      "t": 79278,
      "e": 74562,
      "ty": 41,
      "x": 58993,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 79328,
      "e": 74612,
      "ty": 2,
      "x": 1070,
      "y": 832
    },
    {
      "t": 79349,
      "e": 74633,
      "ty": 3,
      "x": 1070,
      "y": 832,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 79350,
      "e": 74634,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 79470,
      "e": 74754,
      "ty": 4,
      "x": 58993,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 79470,
      "e": 74754,
      "ty": 5,
      "x": 1070,
      "y": 832,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 80228,
      "e": 75512,
      "ty": 2,
      "x": 1090,
      "y": 802
    },
    {
      "t": 80278,
      "e": 75562,
      "ty": 41,
      "x": 64689,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 80328,
      "e": 75612,
      "ty": 2,
      "x": 1094,
      "y": 798
    },
    {
      "t": 80429,
      "e": 75713,
      "ty": 2,
      "x": 1011,
      "y": 783
    },
    {
      "t": 80528,
      "e": 75812,
      "ty": 2,
      "x": 727,
      "y": 794
    },
    {
      "t": 80528,
      "e": 75812,
      "ty": 41,
      "x": 24760,
      "y": 43542,
      "ta": "html > body"
    },
    {
      "t": 80629,
      "e": 75913,
      "ty": 2,
      "x": 726,
      "y": 795
    },
    {
      "t": 80728,
      "e": 76012,
      "ty": 2,
      "x": 807,
      "y": 754
    },
    {
      "t": 80776,
      "e": 76060,
      "ty": 6,
      "x": 826,
      "y": 735,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 80779,
      "e": 76063,
      "ty": 41,
      "x": 0,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 80828,
      "e": 76112,
      "ty": 2,
      "x": 826,
      "y": 735
    },
    {
      "t": 81026,
      "e": 76310,
      "ty": 7,
      "x": 838,
      "y": 716,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 81028,
      "e": 76312,
      "ty": 2,
      "x": 838,
      "y": 716
    },
    {
      "t": 81028,
      "e": 76312,
      "ty": 41,
      "x": 3934,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 81128,
      "e": 76412,
      "ty": 2,
      "x": 850,
      "y": 694
    },
    {
      "t": 81279,
      "e": 76563,
      "ty": 41,
      "x": 7201,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 81428,
      "e": 76712,
      "ty": 2,
      "x": 850,
      "y": 695
    },
    {
      "t": 81529,
      "e": 76813,
      "ty": 41,
      "x": 7201,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 81628,
      "e": 76912,
      "ty": 2,
      "x": 839,
      "y": 695
    },
    {
      "t": 81728,
      "e": 77012,
      "ty": 2,
      "x": 836,
      "y": 695
    },
    {
      "t": 81778,
      "e": 77062,
      "ty": 41,
      "x": 2917,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 81828,
      "e": 77112,
      "ty": 6,
      "x": 831,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 81828,
      "e": 77112,
      "ty": 2,
      "x": 831,
      "y": 696
    },
    {
      "t": 81928,
      "e": 77212,
      "ty": 2,
      "x": 830,
      "y": 696
    },
    {
      "t": 82029,
      "e": 77313,
      "ty": 41,
      "x": 18037,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 82827,
      "e": 78111,
      "ty": 7,
      "x": 829,
      "y": 712,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 82829,
      "e": 78113,
      "ty": 2,
      "x": 829,
      "y": 712
    },
    {
      "t": 82911,
      "e": 78195,
      "ty": 6,
      "x": 829,
      "y": 724,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 82928,
      "e": 78212,
      "ty": 2,
      "x": 830,
      "y": 728
    },
    {
      "t": 82994,
      "e": 78278,
      "ty": 7,
      "x": 830,
      "y": 738,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 83029,
      "e": 78313,
      "ty": 2,
      "x": 831,
      "y": 744
    },
    {
      "t": 83029,
      "e": 78313,
      "ty": 41,
      "x": 2273,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 83061,
      "e": 78345,
      "ty": 6,
      "x": 832,
      "y": 754,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 83111,
      "e": 78395,
      "ty": 7,
      "x": 834,
      "y": 765,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 83128,
      "e": 78412,
      "ty": 2,
      "x": 835,
      "y": 768
    },
    {
      "t": 83211,
      "e": 78495,
      "ty": 6,
      "x": 837,
      "y": 782,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 83228,
      "e": 78512,
      "ty": 2,
      "x": 837,
      "y": 785
    },
    {
      "t": 83279,
      "e": 78563,
      "ty": 41,
      "x": 58367,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 83311,
      "e": 78595,
      "ty": 7,
      "x": 838,
      "y": 795,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 83329,
      "e": 78613,
      "ty": 2,
      "x": 839,
      "y": 797
    },
    {
      "t": 83378,
      "e": 78662,
      "ty": 6,
      "x": 839,
      "y": 811,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 83428,
      "e": 78712,
      "ty": 2,
      "x": 839,
      "y": 816
    },
    {
      "t": 83528,
      "e": 78812,
      "ty": 2,
      "x": 839,
      "y": 819
    },
    {
      "t": 83528,
      "e": 78812,
      "ty": 41,
      "x": 63408,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 83661,
      "e": 78945,
      "ty": 7,
      "x": 839,
      "y": 806,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 83711,
      "e": 78995,
      "ty": 6,
      "x": 836,
      "y": 792,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 83728,
      "e": 79012,
      "ty": 2,
      "x": 836,
      "y": 789
    },
    {
      "t": 83779,
      "e": 79063,
      "ty": 41,
      "x": 48284,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 83795,
      "e": 79079,
      "ty": 7,
      "x": 836,
      "y": 778,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 83828,
      "e": 79112,
      "ty": 2,
      "x": 836,
      "y": 770
    },
    {
      "t": 83877,
      "e": 79112,
      "ty": 6,
      "x": 836,
      "y": 763,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 83928,
      "e": 79163,
      "ty": 2,
      "x": 835,
      "y": 757
    },
    {
      "t": 83961,
      "e": 79196,
      "ty": 7,
      "x": 835,
      "y": 750,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 84028,
      "e": 79263,
      "ty": 2,
      "x": 835,
      "y": 739
    },
    {
      "t": 84028,
      "e": 79263,
      "ty": 41,
      "x": 3407,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 84045,
      "e": 79280,
      "ty": 6,
      "x": 835,
      "y": 735,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 84129,
      "e": 79364,
      "ty": 2,
      "x": 835,
      "y": 727
    },
    {
      "t": 84166,
      "e": 79401,
      "ty": 7,
      "x": 835,
      "y": 723,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 84228,
      "e": 79463,
      "ty": 2,
      "x": 835,
      "y": 720
    },
    {
      "t": 84288,
      "e": 79523,
      "ty": 41,
      "x": 3222,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 84329,
      "e": 79564,
      "ty": 2,
      "x": 836,
      "y": 709
    },
    {
      "t": 84345,
      "e": 79580,
      "ty": 6,
      "x": 836,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 84429,
      "e": 79664,
      "ty": 2,
      "x": 836,
      "y": 700
    },
    {
      "t": 84529,
      "e": 79764,
      "ty": 2,
      "x": 836,
      "y": 698
    },
    {
      "t": 84529,
      "e": 79764,
      "ty": 41,
      "x": 48284,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 84928,
      "e": 80163,
      "ty": 2,
      "x": 835,
      "y": 698
    },
    {
      "t": 85029,
      "e": 80264,
      "ty": 41,
      "x": 43243,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 85079,
      "e": 80314,
      "ty": 3,
      "x": 835,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 85080,
      "e": 80315,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 85189,
      "e": 80424,
      "ty": 4,
      "x": 43243,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 85189,
      "e": 80424,
      "ty": 5,
      "x": 835,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 85189,
      "e": 80424,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 85296,
      "e": 80531,
      "ty": 7,
      "x": 844,
      "y": 728,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 85328,
      "e": 80563,
      "ty": 2,
      "x": 870,
      "y": 788
    },
    {
      "t": 85429,
      "e": 80664,
      "ty": 2,
      "x": 968,
      "y": 1005
    },
    {
      "t": 85529,
      "e": 80764,
      "ty": 2,
      "x": 973,
      "y": 1037
    },
    {
      "t": 85529,
      "e": 80764,
      "ty": 41,
      "x": 35973,
      "y": 65460,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 85629,
      "e": 80864,
      "ty": 2,
      "x": 966,
      "y": 1036
    },
    {
      "t": 85729,
      "e": 80964,
      "ty": 2,
      "x": 961,
      "y": 1034
    },
    {
      "t": 85747,
      "e": 80982,
      "ty": 6,
      "x": 956,
      "y": 1034,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 85779,
      "e": 81014,
      "ty": 41,
      "x": 63175,
      "y": 57591,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 85828,
      "e": 81063,
      "ty": 2,
      "x": 923,
      "y": 1033
    },
    {
      "t": 85928,
      "e": 81163,
      "ty": 2,
      "x": 915,
      "y": 1033
    },
    {
      "t": 86029,
      "e": 81264,
      "ty": 41,
      "x": 44106,
      "y": 55605,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 87511,
      "e": 82746,
      "ty": 3,
      "x": 915,
      "y": 1033,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 87512,
      "e": 82747,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 87513,
      "e": 82748,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 87629,
      "e": 82864,
      "ty": 4,
      "x": 44106,
      "y": 55605,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 87629,
      "e": 82864,
      "ty": 5,
      "x": 915,
      "y": 1033,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 87632,
      "e": 82867,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 87632,
      "e": 82867,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 87634,
      "e": 82869,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 88029,
      "e": 83264,
      "ty": 2,
      "x": 914,
      "y": 1032
    },
    {
      "t": 88029,
      "e": 83264,
      "ty": 41,
      "x": 31200,
      "y": 56726,
      "ta": "html > body"
    },
    {
      "t": 88228,
      "e": 83463,
      "ty": 2,
      "x": 914,
      "y": 1009
    },
    {
      "t": 88278,
      "e": 83513,
      "ty": 41,
      "x": 31200,
      "y": 55341,
      "ta": "html > body"
    },
    {
      "t": 88328,
      "e": 83563,
      "ty": 2,
      "x": 914,
      "y": 1004
    },
    {
      "t": 88429,
      "e": 83664,
      "ty": 2,
      "x": 915,
      "y": 967
    },
    {
      "t": 88528,
      "e": 83763,
      "ty": 2,
      "x": 902,
      "y": 887
    },
    {
      "t": 88529,
      "e": 83764,
      "ty": 41,
      "x": 30787,
      "y": 48694,
      "ta": "html > body"
    },
    {
      "t": 88629,
      "e": 83864,
      "ty": 2,
      "x": 891,
      "y": 855
    },
    {
      "t": 88779,
      "e": 84014,
      "ty": 41,
      "x": 30408,
      "y": 46866,
      "ta": "html > body"
    },
    {
      "t": 88828,
      "e": 84063,
      "ty": 2,
      "x": 891,
      "y": 854
    },
    {
      "t": 88986,
      "e": 84221,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 89328,
      "e": 84563,
      "ty": 2,
      "x": 886,
      "y": 852
    },
    {
      "t": 89428,
      "e": 84663,
      "ty": 2,
      "x": 786,
      "y": 822
    },
    {
      "t": 89528,
      "e": 84763,
      "ty": 2,
      "x": 561,
      "y": 793
    },
    {
      "t": 89529,
      "e": 84764,
      "ty": 41,
      "x": 13162,
      "y": 53089,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 89629,
      "e": 84864,
      "ty": 2,
      "x": 479,
      "y": 767
    },
    {
      "t": 89728,
      "e": 84963,
      "ty": 2,
      "x": 543,
      "y": 755
    },
    {
      "t": 89779,
      "e": 85014,
      "ty": 41,
      "x": 27134,
      "y": 24612,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 89828,
      "e": 85063,
      "ty": 2,
      "x": 1097,
      "y": 967
    },
    {
      "t": 89928,
      "e": 85163,
      "ty": 2,
      "x": 1135,
      "y": 1012
    },
    {
      "t": 90029,
      "e": 85264,
      "ty": 2,
      "x": 1060,
      "y": 1048
    },
    {
      "t": 90029,
      "e": 85264,
      "ty": 41,
      "x": 37711,
      "y": 63825,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 90029,
      "e": 85264,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90083,
      "e": 85318,
      "ty": 6,
      "x": 988,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 90129,
      "e": 85364,
      "ty": 2,
      "x": 982,
      "y": 1076
    },
    {
      "t": 90228,
      "e": 85463,
      "ty": 2,
      "x": 981,
      "y": 1077
    },
    {
      "t": 90279,
      "e": 85514,
      "ty": 41,
      "x": 39047,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 90329,
      "e": 85564,
      "ty": 2,
      "x": 981,
      "y": 1086
    },
    {
      "t": 90529,
      "e": 85764,
      "ty": 41,
      "x": 39047,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 90719,
      "e": 85954,
      "ty": 3,
      "x": 981,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 90719,
      "e": 85954,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 90805,
      "e": 86040,
      "ty": 4,
      "x": 39047,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 90805,
      "e": 86040,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 90806,
      "e": 86041,
      "ty": 5,
      "x": 981,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 90806,
      "e": 86041,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 91729,
      "e": 86964,
      "ty": 2,
      "x": 981,
      "y": 1081
    },
    {
      "t": 91779,
      "e": 87014,
      "ty": 41,
      "x": 33507,
      "y": 59330,
      "ta": "html > body"
    },
    {
      "t": 91846,
      "e": 87081,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 92629,
      "e": 87864,
      "ty": 2,
      "x": 920,
      "y": 953
    },
    {
      "t": 92629,
      "e": 87864,
      "ty": 41,
      "x": 30493,
      "y": 32848,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 92728,
      "e": 87963,
      "ty": 2,
      "x": 1026,
      "y": 823
    },
    {
      "t": 92778,
      "e": 88013,
      "ty": 41,
      "x": 47480,
      "y": 32803,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 92829,
      "e": 88064,
      "ty": 2,
      "x": 1469,
      "y": 859
    },
    {
      "t": 92929,
      "e": 88164,
      "ty": 2,
      "x": 1557,
      "y": 1047
    },
    {
      "t": 93029,
      "e": 88264,
      "ty": 2,
      "x": 1093,
      "y": 898
    },
    {
      "t": 93029,
      "e": 88264,
      "ty": 41,
      "x": 40455,
      "y": 32835,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 93128,
      "e": 88363,
      "ty": 2,
      "x": 1072,
      "y": 709
    },
    {
      "t": 93229,
      "e": 88464,
      "ty": 2,
      "x": 1106,
      "y": 677
    },
    {
      "t": 93269,
      "e": 88504,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 9353, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 9356, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 2449, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 12905, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 9371, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"oscar\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 23279, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 23373, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 56999, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 17122, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 75123, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 16337, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 92713, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -A -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:992,y:1022,t:1527616638310};\\\", \\\"{x:987,y:1017,t:1527616638323};\\\", \\\"{x:967,y:996,t:1527616638339};\\\", \\\"{x:955,y:977,t:1527616638355};\\\", \\\"{x:948,y:959,t:1527616638373};\\\", \\\"{x:945,y:939,t:1527616638389};\\\", \\\"{x:944,y:926,t:1527616638406};\\\", \\\"{x:944,y:924,t:1527616638462};\\\", \\\"{x:944,y:923,t:1527616638478};\\\", \\\"{x:947,y:914,t:1527616638489};\\\", \\\"{x:989,y:837,t:1527616638507};\\\", \\\"{x:1042,y:752,t:1527616638523};\\\", \\\"{x:1111,y:665,t:1527616638539};\\\", \\\"{x:1191,y:585,t:1527616638556};\\\", \\\"{x:1270,y:520,t:1527616638572};\\\", \\\"{x:1348,y:465,t:1527616638589};\\\", \\\"{x:1411,y:418,t:1527616638606};\\\", \\\"{x:1422,y:410,t:1527616638623};\\\", \\\"{x:1424,y:410,t:1527616638639};\\\", \\\"{x:1425,y:414,t:1527616638694};\\\", \\\"{x:1426,y:424,t:1527616638706};\\\", \\\"{x:1427,y:447,t:1527616638723};\\\", \\\"{x:1430,y:471,t:1527616638740};\\\", \\\"{x:1430,y:496,t:1527616638757};\\\", \\\"{x:1430,y:519,t:1527616638772};\\\", \\\"{x:1430,y:541,t:1527616638790};\\\", \\\"{x:1423,y:563,t:1527616638806};\\\", \\\"{x:1414,y:578,t:1527616638823};\\\", \\\"{x:1402,y:589,t:1527616638839};\\\", \\\"{x:1387,y:601,t:1527616638857};\\\", \\\"{x:1372,y:610,t:1527616638872};\\\", \\\"{x:1357,y:618,t:1527616638889};\\\", \\\"{x:1341,y:627,t:1527616638906};\\\", \\\"{x:1320,y:638,t:1527616638924};\\\", \\\"{x:1295,y:644,t:1527616638939};\\\", \\\"{x:1271,y:644,t:1527616638956};\\\", \\\"{x:1253,y:643,t:1527616638974};\\\", \\\"{x:1238,y:643,t:1527616638989};\\\", \\\"{x:1223,y:643,t:1527616639006};\\\", \\\"{x:1219,y:643,t:1527616639023};\\\", \\\"{x:1216,y:643,t:1527616639040};\\\", \\\"{x:1215,y:643,t:1527616639094};\\\", \\\"{x:1214,y:643,t:1527616639106};\\\", \\\"{x:1213,y:644,t:1527616639123};\\\", \\\"{x:1212,y:644,t:1527616639140};\\\", \\\"{x:1211,y:644,t:1527616639157};\\\", \\\"{x:1209,y:645,t:1527616639173};\\\", \\\"{x:1209,y:646,t:1527616639189};\\\", \\\"{x:1207,y:647,t:1527616639207};\\\", \\\"{x:1206,y:649,t:1527616639223};\\\", \\\"{x:1205,y:650,t:1527616639239};\\\", \\\"{x:1204,y:654,t:1527616639256};\\\", \\\"{x:1203,y:655,t:1527616639274};\\\", \\\"{x:1202,y:657,t:1527616639289};\\\", \\\"{x:1202,y:659,t:1527616639307};\\\", \\\"{x:1201,y:660,t:1527616639324};\\\", \\\"{x:1200,y:661,t:1527616639339};\\\", \\\"{x:1200,y:662,t:1527616639382};\\\", \\\"{x:1199,y:662,t:1527616639405};\\\", \\\"{x:1198,y:665,t:1527616639414};\\\", \\\"{x:1197,y:666,t:1527616639423};\\\", \\\"{x:1197,y:667,t:1527616639441};\\\", \\\"{x:1197,y:669,t:1527616639456};\\\", \\\"{x:1196,y:670,t:1527616639474};\\\", \\\"{x:1195,y:672,t:1527616639490};\\\", \\\"{x:1195,y:673,t:1527616639507};\\\", \\\"{x:1194,y:675,t:1527616639524};\\\", \\\"{x:1193,y:678,t:1527616639541};\\\", \\\"{x:1193,y:681,t:1527616639556};\\\", \\\"{x:1192,y:683,t:1527616639574};\\\", \\\"{x:1191,y:686,t:1527616639589};\\\", \\\"{x:1191,y:687,t:1527616639614};\\\", \\\"{x:1191,y:689,t:1527616639624};\\\", \\\"{x:1190,y:690,t:1527616639641};\\\", \\\"{x:1189,y:692,t:1527616639656};\\\", \\\"{x:1187,y:696,t:1527616639674};\\\", \\\"{x:1187,y:699,t:1527616639691};\\\", \\\"{x:1186,y:703,t:1527616639706};\\\", \\\"{x:1184,y:707,t:1527616639723};\\\", \\\"{x:1183,y:709,t:1527616639740};\\\", \\\"{x:1182,y:713,t:1527616639757};\\\", \\\"{x:1181,y:716,t:1527616639774};\\\", \\\"{x:1179,y:720,t:1527616639790};\\\", \\\"{x:1179,y:722,t:1527616639807};\\\", \\\"{x:1176,y:727,t:1527616639823};\\\", \\\"{x:1175,y:730,t:1527616639840};\\\", \\\"{x:1173,y:734,t:1527616639858};\\\", \\\"{x:1171,y:738,t:1527616639874};\\\", \\\"{x:1169,y:745,t:1527616639891};\\\", \\\"{x:1166,y:750,t:1527616639908};\\\", \\\"{x:1164,y:755,t:1527616639924};\\\", \\\"{x:1163,y:760,t:1527616639941};\\\", \\\"{x:1160,y:766,t:1527616639957};\\\", \\\"{x:1158,y:768,t:1527616639974};\\\", \\\"{x:1155,y:773,t:1527616639991};\\\", \\\"{x:1154,y:777,t:1527616640008};\\\", \\\"{x:1153,y:780,t:1527616640024};\\\", \\\"{x:1152,y:783,t:1527616640041};\\\", \\\"{x:1150,y:787,t:1527616640058};\\\", \\\"{x:1148,y:791,t:1527616640073};\\\", \\\"{x:1146,y:794,t:1527616640091};\\\", \\\"{x:1144,y:801,t:1527616640107};\\\", \\\"{x:1143,y:805,t:1527616640123};\\\", \\\"{x:1142,y:811,t:1527616640140};\\\", \\\"{x:1141,y:814,t:1527616640157};\\\", \\\"{x:1140,y:818,t:1527616640173};\\\", \\\"{x:1139,y:823,t:1527616640191};\\\", \\\"{x:1139,y:826,t:1527616640208};\\\", \\\"{x:1138,y:830,t:1527616640224};\\\", \\\"{x:1137,y:834,t:1527616640241};\\\", \\\"{x:1137,y:838,t:1527616640257};\\\", \\\"{x:1137,y:843,t:1527616640273};\\\", \\\"{x:1137,y:847,t:1527616640290};\\\", \\\"{x:1137,y:850,t:1527616640307};\\\", \\\"{x:1137,y:852,t:1527616640324};\\\", \\\"{x:1137,y:853,t:1527616640341};\\\", \\\"{x:1137,y:855,t:1527616640358};\\\", \\\"{x:1137,y:856,t:1527616640374};\\\", \\\"{x:1137,y:858,t:1527616640391};\\\", \\\"{x:1139,y:863,t:1527616640408};\\\", \\\"{x:1142,y:864,t:1527616640424};\\\", \\\"{x:1146,y:868,t:1527616640441};\\\", \\\"{x:1146,y:881,t:1527616640458};\\\", \\\"{x:1146,y:900,t:1527616640475};\\\", \\\"{x:1146,y:913,t:1527616640491};\\\", \\\"{x:1147,y:921,t:1527616640508};\\\", \\\"{x:1149,y:922,t:1527616640524};\\\", \\\"{x:1149,y:923,t:1527616640540};\\\", \\\"{x:1150,y:923,t:1527616640758};\\\", \\\"{x:1151,y:924,t:1527616640789};\\\", \\\"{x:1152,y:924,t:1527616640990};\\\", \\\"{x:1152,y:925,t:1527616641022};\\\", \\\"{x:1152,y:926,t:1527616641038};\\\", \\\"{x:1152,y:927,t:1527616641046};\\\", \\\"{x:1151,y:928,t:1527616641062};\\\", \\\"{x:1150,y:929,t:1527616641075};\\\", \\\"{x:1149,y:930,t:1527616641091};\\\", \\\"{x:1148,y:931,t:1527616641230};\\\", \\\"{x:1148,y:932,t:1527616641286};\\\", \\\"{x:1146,y:933,t:1527616641293};\\\", \\\"{x:1146,y:934,t:1527616641310};\\\", \\\"{x:1145,y:934,t:1527616641324};\\\", \\\"{x:1142,y:936,t:1527616641342};\\\", \\\"{x:1140,y:936,t:1527616641358};\\\", \\\"{x:1137,y:936,t:1527616641375};\\\", \\\"{x:1133,y:937,t:1527616641392};\\\", \\\"{x:1127,y:939,t:1527616641408};\\\", \\\"{x:1124,y:939,t:1527616641425};\\\", \\\"{x:1120,y:940,t:1527616641442};\\\", \\\"{x:1117,y:941,t:1527616641458};\\\", \\\"{x:1116,y:942,t:1527616641526};\\\", \\\"{x:1116,y:943,t:1527616641630};\\\", \\\"{x:1117,y:943,t:1527616641838};\\\", \\\"{x:1118,y:943,t:1527616641846};\\\", \\\"{x:1118,y:944,t:1527616641858};\\\", \\\"{x:1119,y:944,t:1527616641876};\\\", \\\"{x:1121,y:944,t:1527616641892};\\\", \\\"{x:1123,y:944,t:1527616641908};\\\", \\\"{x:1124,y:945,t:1527616641934};\\\", \\\"{x:1126,y:945,t:1527616641958};\\\", \\\"{x:1127,y:945,t:1527616641973};\\\", \\\"{x:1129,y:945,t:1527616641998};\\\", \\\"{x:1130,y:945,t:1527616642009};\\\", \\\"{x:1131,y:946,t:1527616642026};\\\", \\\"{x:1133,y:946,t:1527616642042};\\\", \\\"{x:1135,y:946,t:1527616642059};\\\", \\\"{x:1137,y:946,t:1527616642075};\\\", \\\"{x:1139,y:946,t:1527616642091};\\\", \\\"{x:1141,y:946,t:1527616642109};\\\", \\\"{x:1145,y:946,t:1527616642125};\\\", \\\"{x:1147,y:946,t:1527616642142};\\\", \\\"{x:1152,y:946,t:1527616642158};\\\", \\\"{x:1156,y:946,t:1527616642176};\\\", \\\"{x:1161,y:946,t:1527616642191};\\\", \\\"{x:1164,y:946,t:1527616642208};\\\", \\\"{x:1168,y:946,t:1527616642225};\\\", \\\"{x:1171,y:946,t:1527616642243};\\\", \\\"{x:1174,y:946,t:1527616642258};\\\", \\\"{x:1176,y:946,t:1527616642275};\\\", \\\"{x:1177,y:946,t:1527616642294};\\\", \\\"{x:1178,y:946,t:1527616642308};\\\", \\\"{x:1179,y:946,t:1527616642326};\\\", \\\"{x:1180,y:946,t:1527616642342};\\\", \\\"{x:1181,y:946,t:1527616642359};\\\", \\\"{x:1182,y:946,t:1527616642376};\\\", \\\"{x:1183,y:946,t:1527616642393};\\\", \\\"{x:1185,y:946,t:1527616642409};\\\", \\\"{x:1187,y:946,t:1527616642426};\\\", \\\"{x:1190,y:946,t:1527616642443};\\\", \\\"{x:1193,y:946,t:1527616642459};\\\", \\\"{x:1199,y:947,t:1527616642476};\\\", \\\"{x:1202,y:947,t:1527616642493};\\\", \\\"{x:1207,y:947,t:1527616642508};\\\", \\\"{x:1210,y:947,t:1527616642526};\\\", \\\"{x:1217,y:947,t:1527616642543};\\\", \\\"{x:1222,y:949,t:1527616642559};\\\", \\\"{x:1227,y:949,t:1527616642576};\\\", \\\"{x:1233,y:949,t:1527616642592};\\\", \\\"{x:1240,y:949,t:1527616642609};\\\", \\\"{x:1249,y:950,t:1527616642626};\\\", \\\"{x:1253,y:950,t:1527616642643};\\\", \\\"{x:1257,y:950,t:1527616642658};\\\", \\\"{x:1259,y:950,t:1527616642676};\\\", \\\"{x:1260,y:950,t:1527616642774};\\\", \\\"{x:1261,y:951,t:1527616642789};\\\", \\\"{x:1262,y:951,t:1527616642797};\\\", \\\"{x:1265,y:953,t:1527616642810};\\\", \\\"{x:1267,y:953,t:1527616642825};\\\", \\\"{x:1268,y:955,t:1527616642843};\\\", \\\"{x:1271,y:956,t:1527616642859};\\\", \\\"{x:1273,y:958,t:1527616642878};\\\", \\\"{x:1274,y:958,t:1527616642902};\\\", \\\"{x:1275,y:959,t:1527616642910};\\\", \\\"{x:1275,y:961,t:1527616642934};\\\", \\\"{x:1276,y:961,t:1527616642942};\\\", \\\"{x:1277,y:962,t:1527616642959};\\\", \\\"{x:1278,y:960,t:1527616643126};\\\", \\\"{x:1279,y:955,t:1527616643143};\\\", \\\"{x:1279,y:950,t:1527616643159};\\\", \\\"{x:1279,y:944,t:1527616643176};\\\", \\\"{x:1280,y:940,t:1527616643192};\\\", \\\"{x:1281,y:934,t:1527616643210};\\\", \\\"{x:1282,y:930,t:1527616643227};\\\", \\\"{x:1282,y:926,t:1527616643242};\\\", \\\"{x:1282,y:922,t:1527616643259};\\\", \\\"{x:1284,y:918,t:1527616643277};\\\", \\\"{x:1284,y:916,t:1527616643293};\\\", \\\"{x:1285,y:912,t:1527616643310};\\\", \\\"{x:1287,y:910,t:1527616643326};\\\", \\\"{x:1288,y:907,t:1527616643343};\\\", \\\"{x:1289,y:902,t:1527616643360};\\\", \\\"{x:1289,y:897,t:1527616643377};\\\", \\\"{x:1291,y:891,t:1527616643393};\\\", \\\"{x:1292,y:885,t:1527616643410};\\\", \\\"{x:1293,y:880,t:1527616643427};\\\", \\\"{x:1293,y:876,t:1527616643443};\\\", \\\"{x:1293,y:871,t:1527616643459};\\\", \\\"{x:1293,y:868,t:1527616643477};\\\", \\\"{x:1293,y:865,t:1527616643493};\\\", \\\"{x:1293,y:861,t:1527616643511};\\\", \\\"{x:1293,y:859,t:1527616643526};\\\", \\\"{x:1293,y:857,t:1527616643543};\\\", \\\"{x:1293,y:855,t:1527616643560};\\\", \\\"{x:1293,y:854,t:1527616643577};\\\", \\\"{x:1292,y:852,t:1527616643592};\\\", \\\"{x:1292,y:851,t:1527616643609};\\\", \\\"{x:1292,y:848,t:1527616643626};\\\", \\\"{x:1292,y:846,t:1527616643642};\\\", \\\"{x:1291,y:844,t:1527616643660};\\\", \\\"{x:1289,y:838,t:1527616643677};\\\", \\\"{x:1285,y:832,t:1527616643694};\\\", \\\"{x:1283,y:830,t:1527616643710};\\\", \\\"{x:1280,y:827,t:1527616643727};\\\", \\\"{x:1278,y:824,t:1527616643744};\\\", \\\"{x:1277,y:823,t:1527616643759};\\\", \\\"{x:1276,y:821,t:1527616643777};\\\", \\\"{x:1276,y:820,t:1527616643814};\\\", \\\"{x:1278,y:823,t:1527616646286};\\\", \\\"{x:1283,y:825,t:1527616646295};\\\", \\\"{x:1285,y:827,t:1527616646311};\\\", \\\"{x:1286,y:827,t:1527616646329};\\\", \\\"{x:1280,y:827,t:1527616650902};\\\", \\\"{x:1258,y:820,t:1527616650915};\\\", \\\"{x:1200,y:803,t:1527616650932};\\\", \\\"{x:1154,y:788,t:1527616650949};\\\", \\\"{x:1086,y:776,t:1527616650965};\\\", \\\"{x:991,y:747,t:1527616650981};\\\", \\\"{x:937,y:727,t:1527616650999};\\\", \\\"{x:871,y:700,t:1527616651015};\\\", \\\"{x:795,y:672,t:1527616651033};\\\", \\\"{x:737,y:655,t:1527616651049};\\\", \\\"{x:697,y:644,t:1527616651065};\\\", \\\"{x:660,y:637,t:1527616651082};\\\", \\\"{x:609,y:628,t:1527616651100};\\\", \\\"{x:549,y:616,t:1527616651117};\\\", \\\"{x:488,y:600,t:1527616651133};\\\", \\\"{x:456,y:591,t:1527616651150};\\\", \\\"{x:447,y:584,t:1527616651166};\\\", \\\"{x:443,y:579,t:1527616651183};\\\", \\\"{x:440,y:574,t:1527616651200};\\\", \\\"{x:438,y:570,t:1527616651216};\\\", \\\"{x:434,y:565,t:1527616651232};\\\", \\\"{x:431,y:562,t:1527616651250};\\\", \\\"{x:427,y:558,t:1527616651267};\\\", \\\"{x:424,y:555,t:1527616651283};\\\", \\\"{x:423,y:554,t:1527616651300};\\\", \\\"{x:422,y:552,t:1527616651317};\\\", \\\"{x:421,y:551,t:1527616651390};\\\", \\\"{x:421,y:548,t:1527616651406};\\\", \\\"{x:420,y:547,t:1527616651421};\\\", \\\"{x:418,y:544,t:1527616651434};\\\", \\\"{x:415,y:541,t:1527616651450};\\\", \\\"{x:411,y:537,t:1527616651467};\\\", \\\"{x:409,y:535,t:1527616651484};\\\", \\\"{x:406,y:532,t:1527616651500};\\\", \\\"{x:404,y:530,t:1527616651517};\\\", \\\"{x:402,y:527,t:1527616651533};\\\", \\\"{x:400,y:525,t:1527616651549};\\\", \\\"{x:399,y:523,t:1527616651567};\\\", \\\"{x:397,y:523,t:1527616651583};\\\", \\\"{x:396,y:521,t:1527616651600};\\\", \\\"{x:394,y:521,t:1527616651617};\\\", \\\"{x:393,y:520,t:1527616651633};\\\", \\\"{x:391,y:520,t:1527616651650};\\\", \\\"{x:390,y:519,t:1527616651670};\\\", \\\"{x:389,y:519,t:1527616651684};\\\", \\\"{x:387,y:519,t:1527616651700};\\\", \\\"{x:382,y:519,t:1527616651717};\\\", \\\"{x:379,y:519,t:1527616651733};\\\", \\\"{x:378,y:519,t:1527616651749};\\\", \\\"{x:377,y:527,t:1527616652005};\\\", \\\"{x:388,y:546,t:1527616652017};\\\", \\\"{x:427,y:614,t:1527616652035};\\\", \\\"{x:457,y:669,t:1527616652050};\\\", \\\"{x:480,y:716,t:1527616652068};\\\", \\\"{x:507,y:755,t:1527616652084};\\\", \\\"{x:522,y:776,t:1527616652100};\\\", \\\"{x:531,y:788,t:1527616652117};\\\", \\\"{x:537,y:798,t:1527616652134};\\\", \\\"{x:538,y:800,t:1527616652150};\\\", \\\"{x:537,y:800,t:1527616652238};\\\", \\\"{x:534,y:800,t:1527616652250};\\\", \\\"{x:525,y:792,t:1527616652267};\\\", \\\"{x:515,y:772,t:1527616652284};\\\", \\\"{x:504,y:745,t:1527616652301};\\\", \\\"{x:503,y:729,t:1527616652317};\\\", \\\"{x:502,y:714,t:1527616652334};\\\", \\\"{x:502,y:712,t:1527616652351};\\\", \\\"{x:502,y:710,t:1527616652367};\\\", \\\"{x:502,y:709,t:1527616652384};\\\", \\\"{x:502,y:708,t:1527616652406};\\\", \\\"{x:502,y:707,t:1527616652417};\\\", \\\"{x:502,y:705,t:1527616652434};\\\", \\\"{x:502,y:704,t:1527616652451};\\\", \\\"{x:502,y:705,t:1527616652766};\\\", \\\"{x:502,y:706,t:1527616652798};\\\" ] }, { \\\"rt\\\": 13509, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 107496, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -D -E -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:706,t:1527616654782};\\\", \\\"{x:504,y:706,t:1527616654789};\\\", \\\"{x:518,y:706,t:1527616654915};\\\", \\\"{x:519,y:706,t:1527616654920};\\\", \\\"{x:521,y:706,t:1527616654936};\\\", \\\"{x:523,y:706,t:1527616654952};\\\", \\\"{x:525,y:706,t:1527616654969};\\\", \\\"{x:526,y:706,t:1527616654986};\\\", \\\"{x:527,y:706,t:1527616655013};\\\", \\\"{x:528,y:706,t:1527616655021};\\\", \\\"{x:529,y:706,t:1527616655036};\\\", \\\"{x:530,y:706,t:1527616655052};\\\", \\\"{x:531,y:706,t:1527616655069};\\\", \\\"{x:534,y:706,t:1527616655085};\\\", \\\"{x:535,y:706,t:1527616655103};\\\", \\\"{x:537,y:706,t:1527616655119};\\\", \\\"{x:541,y:705,t:1527616655136};\\\", \\\"{x:545,y:705,t:1527616655153};\\\", \\\"{x:550,y:705,t:1527616655169};\\\", \\\"{x:554,y:704,t:1527616655186};\\\", \\\"{x:558,y:704,t:1527616655203};\\\", \\\"{x:560,y:703,t:1527616655219};\\\", \\\"{x:564,y:702,t:1527616655236};\\\", \\\"{x:568,y:701,t:1527616655253};\\\", \\\"{x:574,y:699,t:1527616655269};\\\", \\\"{x:582,y:697,t:1527616655286};\\\", \\\"{x:587,y:695,t:1527616655303};\\\", \\\"{x:595,y:693,t:1527616655320};\\\", \\\"{x:602,y:691,t:1527616655336};\\\", \\\"{x:616,y:685,t:1527616655353};\\\", \\\"{x:629,y:682,t:1527616655370};\\\", \\\"{x:639,y:680,t:1527616655386};\\\", \\\"{x:647,y:678,t:1527616655403};\\\", \\\"{x:656,y:674,t:1527616655420};\\\", \\\"{x:660,y:673,t:1527616655436};\\\", \\\"{x:664,y:672,t:1527616655453};\\\", \\\"{x:669,y:670,t:1527616655469};\\\", \\\"{x:674,y:670,t:1527616655486};\\\", \\\"{x:678,y:670,t:1527616655503};\\\", \\\"{x:686,y:670,t:1527616655520};\\\", \\\"{x:699,y:670,t:1527616655536};\\\", \\\"{x:715,y:670,t:1527616655553};\\\", \\\"{x:733,y:670,t:1527616655570};\\\", \\\"{x:755,y:670,t:1527616655586};\\\", \\\"{x:779,y:670,t:1527616655603};\\\", \\\"{x:799,y:670,t:1527616655620};\\\", \\\"{x:819,y:670,t:1527616655636};\\\", \\\"{x:839,y:670,t:1527616655653};\\\", \\\"{x:866,y:670,t:1527616655670};\\\", \\\"{x:884,y:672,t:1527616655687};\\\", \\\"{x:902,y:673,t:1527616655703};\\\", \\\"{x:919,y:675,t:1527616655720};\\\", \\\"{x:934,y:678,t:1527616655737};\\\", \\\"{x:948,y:679,t:1527616655753};\\\", \\\"{x:959,y:682,t:1527616655770};\\\", \\\"{x:964,y:683,t:1527616655787};\\\", \\\"{x:971,y:684,t:1527616655803};\\\", \\\"{x:979,y:684,t:1527616655820};\\\", \\\"{x:989,y:688,t:1527616655837};\\\", \\\"{x:999,y:691,t:1527616655853};\\\", \\\"{x:1017,y:697,t:1527616655870};\\\", \\\"{x:1031,y:699,t:1527616655887};\\\", \\\"{x:1048,y:703,t:1527616655904};\\\", \\\"{x:1061,y:707,t:1527616655920};\\\", \\\"{x:1071,y:711,t:1527616655937};\\\", \\\"{x:1075,y:712,t:1527616655953};\\\", \\\"{x:1079,y:713,t:1527616655970};\\\", \\\"{x:1080,y:714,t:1527616656021};\\\", \\\"{x:1076,y:713,t:1527616656245};\\\", \\\"{x:1070,y:710,t:1527616656254};\\\", \\\"{x:1059,y:706,t:1527616656270};\\\", \\\"{x:1032,y:700,t:1527616656287};\\\", \\\"{x:999,y:697,t:1527616656304};\\\", \\\"{x:956,y:689,t:1527616656320};\\\", \\\"{x:925,y:681,t:1527616656338};\\\", \\\"{x:890,y:675,t:1527616656354};\\\", \\\"{x:852,y:666,t:1527616656370};\\\", \\\"{x:816,y:661,t:1527616656387};\\\", \\\"{x:788,y:659,t:1527616656404};\\\", \\\"{x:757,y:653,t:1527616656420};\\\", \\\"{x:724,y:649,t:1527616656438};\\\", \\\"{x:677,y:641,t:1527616656453};\\\", \\\"{x:652,y:632,t:1527616656470};\\\", \\\"{x:623,y:619,t:1527616656488};\\\", \\\"{x:610,y:614,t:1527616656504};\\\", \\\"{x:602,y:609,t:1527616656521};\\\", \\\"{x:587,y:601,t:1527616656537};\\\", \\\"{x:571,y:591,t:1527616656554};\\\", \\\"{x:549,y:581,t:1527616656570};\\\", \\\"{x:520,y:568,t:1527616656587};\\\", \\\"{x:504,y:564,t:1527616656604};\\\", \\\"{x:490,y:558,t:1527616656621};\\\", \\\"{x:476,y:550,t:1527616656637};\\\", \\\"{x:460,y:540,t:1527616656654};\\\", \\\"{x:456,y:537,t:1527616656671};\\\", \\\"{x:453,y:534,t:1527616656688};\\\", \\\"{x:452,y:532,t:1527616656705};\\\", \\\"{x:451,y:531,t:1527616656721};\\\", \\\"{x:450,y:528,t:1527616656737};\\\", \\\"{x:448,y:525,t:1527616656754};\\\", \\\"{x:447,y:522,t:1527616656771};\\\", \\\"{x:446,y:521,t:1527616656787};\\\", \\\"{x:445,y:518,t:1527616656804};\\\", \\\"{x:443,y:515,t:1527616656821};\\\", \\\"{x:443,y:512,t:1527616656837};\\\", \\\"{x:441,y:507,t:1527616656854};\\\", \\\"{x:441,y:504,t:1527616656872};\\\", \\\"{x:441,y:501,t:1527616656887};\\\", \\\"{x:441,y:499,t:1527616656904};\\\", \\\"{x:440,y:498,t:1527616656921};\\\", \\\"{x:439,y:497,t:1527616656937};\\\", \\\"{x:439,y:496,t:1527616656954};\\\", \\\"{x:438,y:494,t:1527616656971};\\\", \\\"{x:436,y:493,t:1527616656987};\\\", \\\"{x:434,y:490,t:1527616657004};\\\", \\\"{x:430,y:488,t:1527616657021};\\\", \\\"{x:430,y:487,t:1527616657238};\\\", \\\"{x:434,y:487,t:1527616657254};\\\", \\\"{x:436,y:487,t:1527616657271};\\\", \\\"{x:437,y:486,t:1527616657288};\\\", \\\"{x:438,y:486,t:1527616657445};\\\", \\\"{x:439,y:486,t:1527616657461};\\\", \\\"{x:440,y:486,t:1527616657472};\\\", \\\"{x:444,y:486,t:1527616657488};\\\", \\\"{x:450,y:486,t:1527616657504};\\\", \\\"{x:460,y:486,t:1527616657521};\\\", \\\"{x:473,y:488,t:1527616657538};\\\", \\\"{x:484,y:489,t:1527616657554};\\\", \\\"{x:492,y:490,t:1527616657571};\\\", \\\"{x:496,y:491,t:1527616657589};\\\", \\\"{x:499,y:491,t:1527616657604};\\\", \\\"{x:500,y:491,t:1527616657621};\\\", \\\"{x:505,y:491,t:1527616657637};\\\", \\\"{x:511,y:492,t:1527616657654};\\\", \\\"{x:521,y:494,t:1527616657671};\\\", \\\"{x:533,y:495,t:1527616657689};\\\", \\\"{x:548,y:498,t:1527616657704};\\\", \\\"{x:571,y:499,t:1527616657721};\\\", \\\"{x:593,y:500,t:1527616657738};\\\", \\\"{x:615,y:502,t:1527616657754};\\\", \\\"{x:641,y:504,t:1527616657771};\\\", \\\"{x:667,y:505,t:1527616657788};\\\", \\\"{x:694,y:506,t:1527616657805};\\\", \\\"{x:720,y:506,t:1527616657821};\\\", \\\"{x:768,y:508,t:1527616657839};\\\", \\\"{x:799,y:511,t:1527616657855};\\\", \\\"{x:831,y:517,t:1527616657871};\\\", \\\"{x:865,y:529,t:1527616657888};\\\", \\\"{x:893,y:536,t:1527616657905};\\\", \\\"{x:928,y:548,t:1527616657923};\\\", \\\"{x:965,y:562,t:1527616657938};\\\", \\\"{x:991,y:575,t:1527616657955};\\\", \\\"{x:1016,y:590,t:1527616657972};\\\", \\\"{x:1035,y:604,t:1527616657988};\\\", \\\"{x:1053,y:616,t:1527616658005};\\\", \\\"{x:1075,y:631,t:1527616658021};\\\", \\\"{x:1094,y:642,t:1527616658038};\\\", \\\"{x:1112,y:652,t:1527616658056};\\\", \\\"{x:1127,y:661,t:1527616658072};\\\", \\\"{x:1137,y:667,t:1527616658088};\\\", \\\"{x:1144,y:672,t:1527616658105};\\\", \\\"{x:1151,y:677,t:1527616658122};\\\", \\\"{x:1161,y:684,t:1527616658138};\\\", \\\"{x:1168,y:691,t:1527616658155};\\\", \\\"{x:1177,y:698,t:1527616658172};\\\", \\\"{x:1184,y:709,t:1527616658188};\\\", \\\"{x:1193,y:723,t:1527616658205};\\\", \\\"{x:1210,y:742,t:1527616658221};\\\", \\\"{x:1223,y:752,t:1527616658238};\\\", \\\"{x:1233,y:764,t:1527616658255};\\\", \\\"{x:1245,y:776,t:1527616658272};\\\", \\\"{x:1254,y:786,t:1527616658288};\\\", \\\"{x:1259,y:792,t:1527616658305};\\\", \\\"{x:1265,y:800,t:1527616658322};\\\", \\\"{x:1272,y:804,t:1527616658338};\\\", \\\"{x:1279,y:811,t:1527616658356};\\\", \\\"{x:1285,y:815,t:1527616658372};\\\", \\\"{x:1289,y:819,t:1527616658388};\\\", \\\"{x:1293,y:822,t:1527616658405};\\\", \\\"{x:1300,y:826,t:1527616658423};\\\", \\\"{x:1301,y:828,t:1527616658439};\\\", \\\"{x:1302,y:829,t:1527616658455};\\\", \\\"{x:1303,y:831,t:1527616658472};\\\", \\\"{x:1305,y:835,t:1527616658490};\\\", \\\"{x:1306,y:839,t:1527616658505};\\\", \\\"{x:1307,y:842,t:1527616658523};\\\", \\\"{x:1308,y:845,t:1527616658539};\\\", \\\"{x:1309,y:846,t:1527616658555};\\\", \\\"{x:1309,y:849,t:1527616658572};\\\", \\\"{x:1309,y:852,t:1527616658590};\\\", \\\"{x:1309,y:855,t:1527616658605};\\\", \\\"{x:1308,y:862,t:1527616658622};\\\", \\\"{x:1304,y:870,t:1527616658639};\\\", \\\"{x:1298,y:878,t:1527616658655};\\\", \\\"{x:1291,y:887,t:1527616658672};\\\", \\\"{x:1286,y:890,t:1527616658689};\\\", \\\"{x:1283,y:893,t:1527616658706};\\\", \\\"{x:1283,y:894,t:1527616658722};\\\", \\\"{x:1283,y:891,t:1527616658862};\\\", \\\"{x:1283,y:888,t:1527616658872};\\\", \\\"{x:1285,y:883,t:1527616658889};\\\", \\\"{x:1287,y:877,t:1527616658906};\\\", \\\"{x:1289,y:871,t:1527616658923};\\\", \\\"{x:1289,y:866,t:1527616658939};\\\", \\\"{x:1289,y:859,t:1527616658956};\\\", \\\"{x:1289,y:848,t:1527616658972};\\\", \\\"{x:1289,y:836,t:1527616658989};\\\", \\\"{x:1289,y:819,t:1527616659005};\\\", \\\"{x:1286,y:804,t:1527616659023};\\\", \\\"{x:1281,y:783,t:1527616659039};\\\", \\\"{x:1275,y:764,t:1527616659056};\\\", \\\"{x:1274,y:742,t:1527616659072};\\\", \\\"{x:1274,y:724,t:1527616659089};\\\", \\\"{x:1274,y:710,t:1527616659107};\\\", \\\"{x:1274,y:701,t:1527616659122};\\\", \\\"{x:1274,y:693,t:1527616659139};\\\", \\\"{x:1274,y:688,t:1527616659156};\\\", \\\"{x:1276,y:682,t:1527616659172};\\\", \\\"{x:1280,y:673,t:1527616659190};\\\", \\\"{x:1289,y:662,t:1527616659205};\\\", \\\"{x:1295,y:655,t:1527616659222};\\\", \\\"{x:1302,y:647,t:1527616659239};\\\", \\\"{x:1311,y:642,t:1527616659256};\\\", \\\"{x:1322,y:638,t:1527616659272};\\\", \\\"{x:1336,y:636,t:1527616659289};\\\", \\\"{x:1347,y:636,t:1527616659306};\\\", \\\"{x:1356,y:636,t:1527616659322};\\\", \\\"{x:1359,y:636,t:1527616659339};\\\", \\\"{x:1361,y:636,t:1527616659357};\\\", \\\"{x:1363,y:638,t:1527616659494};\\\", \\\"{x:1365,y:644,t:1527616659506};\\\", \\\"{x:1366,y:660,t:1527616659524};\\\", \\\"{x:1366,y:673,t:1527616659539};\\\", \\\"{x:1366,y:682,t:1527616659556};\\\", \\\"{x:1366,y:690,t:1527616659574};\\\", \\\"{x:1366,y:696,t:1527616659589};\\\", \\\"{x:1365,y:702,t:1527616659606};\\\", \\\"{x:1364,y:705,t:1527616659623};\\\", \\\"{x:1363,y:703,t:1527616659813};\\\", \\\"{x:1362,y:700,t:1527616659824};\\\", \\\"{x:1361,y:694,t:1527616659839};\\\", \\\"{x:1361,y:688,t:1527616659856};\\\", \\\"{x:1361,y:683,t:1527616659874};\\\", \\\"{x:1361,y:680,t:1527616659889};\\\", \\\"{x:1361,y:679,t:1527616659906};\\\", \\\"{x:1361,y:678,t:1527616659941};\\\", \\\"{x:1361,y:677,t:1527616659957};\\\", \\\"{x:1361,y:676,t:1527616659973};\\\", \\\"{x:1362,y:673,t:1527616659991};\\\", \\\"{x:1362,y:672,t:1527616660007};\\\", \\\"{x:1369,y:662,t:1527616661382};\\\", \\\"{x:1388,y:643,t:1527616661391};\\\", \\\"{x:1443,y:595,t:1527616661408};\\\", \\\"{x:1521,y:538,t:1527616661424};\\\", \\\"{x:1595,y:495,t:1527616661440};\\\", \\\"{x:1664,y:454,t:1527616661457};\\\", \\\"{x:1726,y:409,t:1527616661475};\\\", \\\"{x:1759,y:382,t:1527616661490};\\\", \\\"{x:1774,y:371,t:1527616661507};\\\", \\\"{x:1776,y:369,t:1527616661524};\\\", \\\"{x:1779,y:367,t:1527616661541};\\\", \\\"{x:1779,y:366,t:1527616661637};\\\", \\\"{x:1778,y:364,t:1527616661646};\\\", \\\"{x:1777,y:364,t:1527616661658};\\\", \\\"{x:1772,y:364,t:1527616661674};\\\", \\\"{x:1767,y:364,t:1527616661691};\\\", \\\"{x:1760,y:365,t:1527616661708};\\\", \\\"{x:1749,y:371,t:1527616661725};\\\", \\\"{x:1735,y:380,t:1527616661741};\\\", \\\"{x:1725,y:386,t:1527616661758};\\\", \\\"{x:1714,y:391,t:1527616661774};\\\", \\\"{x:1708,y:396,t:1527616661792};\\\", \\\"{x:1704,y:399,t:1527616661808};\\\", \\\"{x:1698,y:404,t:1527616661825};\\\", \\\"{x:1692,y:408,t:1527616661841};\\\", \\\"{x:1684,y:412,t:1527616661858};\\\", \\\"{x:1672,y:416,t:1527616661874};\\\", \\\"{x:1662,y:420,t:1527616661892};\\\", \\\"{x:1655,y:424,t:1527616661907};\\\", \\\"{x:1652,y:425,t:1527616661925};\\\", \\\"{x:1646,y:427,t:1527616661941};\\\", \\\"{x:1645,y:428,t:1527616661957};\\\", \\\"{x:1643,y:428,t:1527616661975};\\\", \\\"{x:1641,y:428,t:1527616661992};\\\", \\\"{x:1640,y:428,t:1527616662008};\\\", \\\"{x:1638,y:429,t:1527616662024};\\\", \\\"{x:1636,y:431,t:1527616662041};\\\", \\\"{x:1634,y:432,t:1527616662058};\\\", \\\"{x:1629,y:432,t:1527616662075};\\\", \\\"{x:1628,y:432,t:1527616662091};\\\", \\\"{x:1626,y:434,t:1527616662109};\\\", \\\"{x:1625,y:434,t:1527616662124};\\\", \\\"{x:1624,y:434,t:1527616662254};\\\", \\\"{x:1622,y:434,t:1527616662269};\\\", \\\"{x:1620,y:434,t:1527616662278};\\\", \\\"{x:1618,y:434,t:1527616662293};\\\", \\\"{x:1617,y:435,t:1527616662309};\\\", \\\"{x:1615,y:435,t:1527616662326};\\\", \\\"{x:1614,y:435,t:1527616662365};\\\", \\\"{x:1612,y:435,t:1527616662382};\\\", \\\"{x:1611,y:435,t:1527616662406};\\\", \\\"{x:1609,y:435,t:1527616662429};\\\", \\\"{x:1608,y:435,t:1527616662478};\\\", \\\"{x:1606,y:435,t:1527616662491};\\\", \\\"{x:1605,y:436,t:1527616663717};\\\", \\\"{x:1605,y:442,t:1527616663725};\\\", \\\"{x:1606,y:459,t:1527616663742};\\\", \\\"{x:1606,y:470,t:1527616663759};\\\", \\\"{x:1607,y:479,t:1527616663776};\\\", \\\"{x:1608,y:486,t:1527616663793};\\\", \\\"{x:1610,y:492,t:1527616663809};\\\", \\\"{x:1610,y:497,t:1527616663826};\\\", \\\"{x:1610,y:506,t:1527616663842};\\\", \\\"{x:1610,y:518,t:1527616663859};\\\", \\\"{x:1610,y:527,t:1527616663875};\\\", \\\"{x:1610,y:535,t:1527616663893};\\\", \\\"{x:1610,y:542,t:1527616663909};\\\", \\\"{x:1610,y:548,t:1527616663925};\\\", \\\"{x:1610,y:555,t:1527616663942};\\\", \\\"{x:1610,y:559,t:1527616663959};\\\", \\\"{x:1611,y:567,t:1527616663975};\\\", \\\"{x:1612,y:573,t:1527616663993};\\\", \\\"{x:1614,y:578,t:1527616664009};\\\", \\\"{x:1614,y:585,t:1527616664025};\\\", \\\"{x:1614,y:588,t:1527616664043};\\\", \\\"{x:1615,y:590,t:1527616664059};\\\", \\\"{x:1615,y:592,t:1527616664076};\\\", \\\"{x:1616,y:593,t:1527616664092};\\\", \\\"{x:1616,y:594,t:1527616664109};\\\", \\\"{x:1617,y:594,t:1527616664397};\\\", \\\"{x:1617,y:595,t:1527616664410};\\\", \\\"{x:1617,y:602,t:1527616664426};\\\", \\\"{x:1618,y:610,t:1527616664443};\\\", \\\"{x:1618,y:616,t:1527616664459};\\\", \\\"{x:1618,y:622,t:1527616664476};\\\", \\\"{x:1619,y:629,t:1527616664492};\\\", \\\"{x:1619,y:634,t:1527616664509};\\\", \\\"{x:1619,y:641,t:1527616664526};\\\", \\\"{x:1619,y:644,t:1527616664542};\\\", \\\"{x:1619,y:648,t:1527616664560};\\\", \\\"{x:1619,y:654,t:1527616664576};\\\", \\\"{x:1619,y:657,t:1527616664593};\\\", \\\"{x:1619,y:662,t:1527616664609};\\\", \\\"{x:1619,y:666,t:1527616664627};\\\", \\\"{x:1619,y:669,t:1527616664642};\\\", \\\"{x:1619,y:670,t:1527616664660};\\\", \\\"{x:1618,y:673,t:1527616664676};\\\", \\\"{x:1618,y:674,t:1527616664693};\\\", \\\"{x:1618,y:675,t:1527616664717};\\\", \\\"{x:1618,y:676,t:1527616664885};\\\", \\\"{x:1618,y:677,t:1527616664893};\\\", \\\"{x:1617,y:678,t:1527616664910};\\\", \\\"{x:1616,y:679,t:1527616664927};\\\", \\\"{x:1616,y:683,t:1527616664943};\\\", \\\"{x:1615,y:683,t:1527616664960};\\\", \\\"{x:1614,y:685,t:1527616664977};\\\", \\\"{x:1614,y:687,t:1527616664994};\\\", \\\"{x:1614,y:688,t:1527616665010};\\\", \\\"{x:1614,y:689,t:1527616665061};\\\", \\\"{x:1614,y:690,t:1527616665077};\\\", \\\"{x:1613,y:693,t:1527616665093};\\\", \\\"{x:1613,y:695,t:1527616665109};\\\", \\\"{x:1612,y:700,t:1527616665127};\\\", \\\"{x:1611,y:706,t:1527616665144};\\\", \\\"{x:1610,y:713,t:1527616665160};\\\", \\\"{x:1607,y:724,t:1527616665177};\\\", \\\"{x:1604,y:745,t:1527616665193};\\\", \\\"{x:1598,y:778,t:1527616665211};\\\", \\\"{x:1594,y:804,t:1527616665226};\\\", \\\"{x:1590,y:826,t:1527616665244};\\\", \\\"{x:1588,y:848,t:1527616665261};\\\", \\\"{x:1587,y:870,t:1527616665277};\\\", \\\"{x:1583,y:894,t:1527616665294};\\\", \\\"{x:1583,y:905,t:1527616665311};\\\", \\\"{x:1583,y:915,t:1527616665327};\\\", \\\"{x:1584,y:923,t:1527616665343};\\\", \\\"{x:1584,y:925,t:1527616665361};\\\", \\\"{x:1580,y:924,t:1527616665558};\\\", \\\"{x:1572,y:916,t:1527616665565};\\\", \\\"{x:1563,y:909,t:1527616665576};\\\", \\\"{x:1529,y:883,t:1527616665594};\\\", \\\"{x:1492,y:856,t:1527616665610};\\\", \\\"{x:1462,y:830,t:1527616665627};\\\", \\\"{x:1421,y:804,t:1527616665643};\\\", \\\"{x:1403,y:793,t:1527616665661};\\\", \\\"{x:1389,y:783,t:1527616665676};\\\", \\\"{x:1372,y:768,t:1527616665694};\\\", \\\"{x:1364,y:760,t:1527616665710};\\\", \\\"{x:1357,y:752,t:1527616665727};\\\", \\\"{x:1347,y:743,t:1527616665743};\\\", \\\"{x:1338,y:733,t:1527616665761};\\\", \\\"{x:1323,y:721,t:1527616665778};\\\", \\\"{x:1296,y:704,t:1527616665793};\\\", \\\"{x:1244,y:676,t:1527616665810};\\\", \\\"{x:1176,y:649,t:1527616665827};\\\", \\\"{x:1093,y:612,t:1527616665843};\\\", \\\"{x:1012,y:586,t:1527616665861};\\\", \\\"{x:905,y:559,t:1527616665878};\\\", \\\"{x:854,y:543,t:1527616665894};\\\", \\\"{x:804,y:537,t:1527616665911};\\\", \\\"{x:772,y:537,t:1527616665928};\\\", \\\"{x:756,y:537,t:1527616665945};\\\", \\\"{x:746,y:537,t:1527616665962};\\\", \\\"{x:737,y:537,t:1527616665979};\\\", \\\"{x:730,y:536,t:1527616665995};\\\", \\\"{x:716,y:535,t:1527616666012};\\\", \\\"{x:690,y:531,t:1527616666028};\\\", \\\"{x:658,y:529,t:1527616666044};\\\", \\\"{x:601,y:519,t:1527616666061};\\\", \\\"{x:572,y:516,t:1527616666078};\\\", \\\"{x:547,y:512,t:1527616666094};\\\", \\\"{x:520,y:507,t:1527616666111};\\\", \\\"{x:502,y:507,t:1527616666129};\\\", \\\"{x:489,y:507,t:1527616666145};\\\", \\\"{x:474,y:509,t:1527616666162};\\\", \\\"{x:454,y:515,t:1527616666178};\\\", \\\"{x:437,y:520,t:1527616666195};\\\", \\\"{x:425,y:525,t:1527616666211};\\\", \\\"{x:415,y:532,t:1527616666229};\\\", \\\"{x:412,y:535,t:1527616666245};\\\", \\\"{x:410,y:537,t:1527616666262};\\\", \\\"{x:408,y:540,t:1527616666278};\\\", \\\"{x:405,y:546,t:1527616666296};\\\", \\\"{x:401,y:551,t:1527616666312};\\\", \\\"{x:397,y:555,t:1527616666329};\\\", \\\"{x:393,y:558,t:1527616666346};\\\", \\\"{x:390,y:561,t:1527616666361};\\\", \\\"{x:386,y:564,t:1527616666379};\\\", \\\"{x:375,y:569,t:1527616666396};\\\", \\\"{x:358,y:576,t:1527616666411};\\\", \\\"{x:340,y:583,t:1527616666429};\\\", \\\"{x:308,y:588,t:1527616666445};\\\", \\\"{x:293,y:589,t:1527616666461};\\\", \\\"{x:276,y:592,t:1527616666479};\\\", \\\"{x:266,y:593,t:1527616666496};\\\", \\\"{x:259,y:593,t:1527616666512};\\\", \\\"{x:254,y:593,t:1527616666528};\\\", \\\"{x:248,y:593,t:1527616666545};\\\", \\\"{x:244,y:593,t:1527616666562};\\\", \\\"{x:239,y:594,t:1527616666578};\\\", \\\"{x:231,y:598,t:1527616666596};\\\", \\\"{x:221,y:600,t:1527616666612};\\\", \\\"{x:209,y:604,t:1527616666628};\\\", \\\"{x:194,y:609,t:1527616666645};\\\", \\\"{x:184,y:614,t:1527616666663};\\\", \\\"{x:179,y:618,t:1527616666679};\\\", \\\"{x:175,y:622,t:1527616666696};\\\", \\\"{x:172,y:627,t:1527616666713};\\\", \\\"{x:169,y:629,t:1527616666728};\\\", \\\"{x:165,y:633,t:1527616666746};\\\", \\\"{x:164,y:635,t:1527616666763};\\\", \\\"{x:163,y:636,t:1527616666778};\\\", \\\"{x:163,y:637,t:1527616666795};\\\", \\\"{x:162,y:638,t:1527616666812};\\\", \\\"{x:161,y:640,t:1527616666829};\\\", \\\"{x:158,y:641,t:1527616666846};\\\", \\\"{x:157,y:641,t:1527616666877};\\\", \\\"{x:156,y:641,t:1527616666893};\\\", \\\"{x:159,y:640,t:1527616667134};\\\", \\\"{x:169,y:640,t:1527616667145};\\\", \\\"{x:191,y:638,t:1527616667163};\\\", \\\"{x:216,y:638,t:1527616667180};\\\", \\\"{x:251,y:640,t:1527616667195};\\\", \\\"{x:284,y:643,t:1527616667213};\\\", \\\"{x:321,y:649,t:1527616667229};\\\", \\\"{x:346,y:652,t:1527616667246};\\\", \\\"{x:367,y:655,t:1527616667263};\\\", \\\"{x:389,y:660,t:1527616667279};\\\", \\\"{x:408,y:663,t:1527616667296};\\\", \\\"{x:427,y:669,t:1527616667312};\\\", \\\"{x:441,y:675,t:1527616667329};\\\", \\\"{x:456,y:682,t:1527616667345};\\\", \\\"{x:467,y:687,t:1527616667363};\\\", \\\"{x:471,y:689,t:1527616667380};\\\", \\\"{x:474,y:690,t:1527616667396};\\\", \\\"{x:474,y:691,t:1527616667414};\\\", \\\"{x:474,y:694,t:1527616667429};\\\", \\\"{x:474,y:695,t:1527616667445};\\\", \\\"{x:474,y:696,t:1527616667462};\\\", \\\"{x:475,y:699,t:1527616667480};\\\", \\\"{x:477,y:701,t:1527616667497};\\\", \\\"{x:478,y:704,t:1527616667513};\\\", \\\"{x:480,y:709,t:1527616667530};\\\", \\\"{x:482,y:711,t:1527616667547};\\\", \\\"{x:482,y:713,t:1527616667563};\\\", \\\"{x:483,y:714,t:1527616667579};\\\", \\\"{x:484,y:715,t:1527616667596};\\\", \\\"{x:485,y:715,t:1527616668061};\\\", \\\"{x:485,y:714,t:1527616668069};\\\", \\\"{x:485,y:713,t:1527616668085};\\\", \\\"{x:485,y:712,t:1527616668097};\\\", \\\"{x:487,y:710,t:1527616668113};\\\", \\\"{x:487,y:709,t:1527616668130};\\\", \\\"{x:487,y:708,t:1527616668146};\\\", \\\"{x:487,y:707,t:1527616668166};\\\", \\\"{x:487,y:706,t:1527616668181};\\\", \\\"{x:487,y:704,t:1527616668197};\\\", \\\"{x:488,y:701,t:1527616668213};\\\", \\\"{x:490,y:697,t:1527616668230};\\\", \\\"{x:491,y:693,t:1527616668247};\\\", \\\"{x:492,y:688,t:1527616668263};\\\", \\\"{x:495,y:681,t:1527616668279};\\\", \\\"{x:498,y:676,t:1527616668296};\\\", \\\"{x:502,y:672,t:1527616668314};\\\", \\\"{x:504,y:670,t:1527616668329};\\\", \\\"{x:507,y:667,t:1527616668347};\\\", \\\"{x:510,y:664,t:1527616668363};\\\", \\\"{x:513,y:661,t:1527616668381};\\\", \\\"{x:515,y:659,t:1527616668396};\\\", \\\"{x:519,y:656,t:1527616668413};\\\", \\\"{x:522,y:654,t:1527616668430};\\\", \\\"{x:529,y:650,t:1527616668447};\\\", \\\"{x:533,y:647,t:1527616668463};\\\", \\\"{x:541,y:643,t:1527616668481};\\\", \\\"{x:547,y:640,t:1527616668497};\\\", \\\"{x:554,y:635,t:1527616668513};\\\", \\\"{x:559,y:633,t:1527616668531};\\\", \\\"{x:563,y:631,t:1527616668547};\\\", \\\"{x:567,y:629,t:1527616668564};\\\", \\\"{x:569,y:628,t:1527616668581};\\\", \\\"{x:570,y:627,t:1527616668596};\\\", \\\"{x:572,y:626,t:1527616668613};\\\", \\\"{x:574,y:625,t:1527616668630};\\\", \\\"{x:577,y:624,t:1527616668646};\\\", \\\"{x:580,y:622,t:1527616668663};\\\", \\\"{x:581,y:621,t:1527616668681};\\\", \\\"{x:584,y:619,t:1527616668696};\\\", \\\"{x:585,y:618,t:1527616668713};\\\", \\\"{x:587,y:617,t:1527616668730};\\\", \\\"{x:588,y:617,t:1527616668746};\\\", \\\"{x:589,y:615,t:1527616668773};\\\", \\\"{x:591,y:614,t:1527616668820};\\\", \\\"{x:591,y:613,t:1527616668831};\\\", \\\"{x:593,y:612,t:1527616668847};\\\", \\\"{x:594,y:612,t:1527616668864};\\\", \\\"{x:594,y:611,t:1527616668886};\\\", \\\"{x:596,y:610,t:1527616668901};\\\" ] }, { \\\"rt\\\": 12341, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 121065, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-10 AM-C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:604,y:603,t:1527616669018};\\\", \\\"{x:607,y:601,t:1527616669049};\\\", \\\"{x:608,y:600,t:1527616669063};\\\", \\\"{x:610,y:598,t:1527616669081};\\\", \\\"{x:613,y:595,t:1527616669098};\\\", \\\"{x:617,y:592,t:1527616669113};\\\", \\\"{x:621,y:590,t:1527616669131};\\\", \\\"{x:638,y:578,t:1527616669161};\\\", \\\"{x:644,y:574,t:1527616669166};\\\", \\\"{x:648,y:572,t:1527616669181};\\\", \\\"{x:663,y:563,t:1527616669198};\\\", \\\"{x:672,y:559,t:1527616669215};\\\", \\\"{x:676,y:556,t:1527616669230};\\\", \\\"{x:681,y:554,t:1527616669248};\\\", \\\"{x:683,y:553,t:1527616669265};\\\", \\\"{x:684,y:552,t:1527616669281};\\\", \\\"{x:686,y:551,t:1527616669297};\\\", \\\"{x:688,y:551,t:1527616669315};\\\", \\\"{x:690,y:550,t:1527616669331};\\\", \\\"{x:691,y:549,t:1527616669486};\\\", \\\"{x:691,y:548,t:1527616669645};\\\", \\\"{x:690,y:548,t:1527616669653};\\\", \\\"{x:689,y:546,t:1527616669665};\\\", \\\"{x:686,y:545,t:1527616669681};\\\", \\\"{x:684,y:544,t:1527616669697};\\\", \\\"{x:681,y:543,t:1527616669715};\\\", \\\"{x:679,y:542,t:1527616669731};\\\", \\\"{x:677,y:541,t:1527616669748};\\\", \\\"{x:671,y:539,t:1527616669764};\\\", \\\"{x:657,y:533,t:1527616669782};\\\", \\\"{x:651,y:531,t:1527616669797};\\\", \\\"{x:642,y:528,t:1527616669815};\\\", \\\"{x:631,y:525,t:1527616669832};\\\", \\\"{x:616,y:521,t:1527616669848};\\\", \\\"{x:601,y:518,t:1527616669865};\\\", \\\"{x:592,y:515,t:1527616669882};\\\", \\\"{x:585,y:514,t:1527616669898};\\\", \\\"{x:581,y:514,t:1527616669914};\\\", \\\"{x:577,y:514,t:1527616669931};\\\", \\\"{x:572,y:512,t:1527616669947};\\\", \\\"{x:565,y:511,t:1527616669965};\\\", \\\"{x:557,y:508,t:1527616669981};\\\", \\\"{x:551,y:508,t:1527616669998};\\\", \\\"{x:543,y:507,t:1527616670014};\\\", \\\"{x:534,y:506,t:1527616670031};\\\", \\\"{x:519,y:506,t:1527616670048};\\\", \\\"{x:508,y:506,t:1527616670065};\\\", \\\"{x:498,y:504,t:1527616670082};\\\", \\\"{x:493,y:504,t:1527616670098};\\\", \\\"{x:490,y:504,t:1527616670115};\\\", \\\"{x:484,y:504,t:1527616670132};\\\", \\\"{x:478,y:504,t:1527616670148};\\\", \\\"{x:472,y:504,t:1527616670165};\\\", \\\"{x:465,y:504,t:1527616670181};\\\", \\\"{x:462,y:504,t:1527616670199};\\\", \\\"{x:459,y:504,t:1527616670214};\\\", \\\"{x:458,y:504,t:1527616670232};\\\", \\\"{x:457,y:504,t:1527616670302};\\\", \\\"{x:456,y:504,t:1527616670373};\\\", \\\"{x:456,y:503,t:1527616670389};\\\", \\\"{x:454,y:503,t:1527616670399};\\\", \\\"{x:449,y:503,t:1527616670415};\\\", \\\"{x:444,y:502,t:1527616670431};\\\", \\\"{x:435,y:501,t:1527616670449};\\\", \\\"{x:426,y:499,t:1527616670464};\\\", \\\"{x:419,y:498,t:1527616670481};\\\", \\\"{x:415,y:498,t:1527616670498};\\\", \\\"{x:414,y:497,t:1527616670515};\\\", \\\"{x:413,y:497,t:1527616670532};\\\", \\\"{x:413,y:495,t:1527616670710};\\\", \\\"{x:415,y:495,t:1527616670726};\\\", \\\"{x:416,y:494,t:1527616670741};\\\", \\\"{x:417,y:494,t:1527616670749};\\\", \\\"{x:420,y:492,t:1527616670765};\\\", \\\"{x:426,y:490,t:1527616670782};\\\", \\\"{x:433,y:489,t:1527616670799};\\\", \\\"{x:439,y:489,t:1527616670816};\\\", \\\"{x:445,y:489,t:1527616670831};\\\", \\\"{x:447,y:489,t:1527616670849};\\\", \\\"{x:448,y:489,t:1527616670865};\\\", \\\"{x:450,y:489,t:1527616670881};\\\", \\\"{x:454,y:489,t:1527616670899};\\\", \\\"{x:457,y:489,t:1527616670916};\\\", \\\"{x:463,y:489,t:1527616670931};\\\", \\\"{x:470,y:490,t:1527616670949};\\\", \\\"{x:483,y:493,t:1527616670965};\\\", \\\"{x:490,y:494,t:1527616670983};\\\", \\\"{x:497,y:494,t:1527616670999};\\\", \\\"{x:502,y:495,t:1527616671016};\\\", \\\"{x:504,y:496,t:1527616671033};\\\", \\\"{x:506,y:496,t:1527616671049};\\\", \\\"{x:507,y:496,t:1527616671066};\\\", \\\"{x:509,y:497,t:1527616671083};\\\", \\\"{x:511,y:497,t:1527616671098};\\\", \\\"{x:515,y:497,t:1527616671116};\\\", \\\"{x:517,y:497,t:1527616671132};\\\", \\\"{x:520,y:498,t:1527616671149};\\\", \\\"{x:521,y:498,t:1527616671165};\\\", \\\"{x:522,y:498,t:1527616671183};\\\", \\\"{x:524,y:498,t:1527616671199};\\\", \\\"{x:528,y:499,t:1527616671216};\\\", \\\"{x:531,y:500,t:1527616671232};\\\", \\\"{x:534,y:500,t:1527616671249};\\\", \\\"{x:536,y:500,t:1527616671266};\\\", \\\"{x:537,y:501,t:1527616671282};\\\", \\\"{x:538,y:501,t:1527616671298};\\\", \\\"{x:539,y:501,t:1527616671316};\\\", \\\"{x:540,y:501,t:1527616671333};\\\", \\\"{x:538,y:501,t:1527616671685};\\\", \\\"{x:537,y:500,t:1527616671700};\\\", \\\"{x:533,y:499,t:1527616671716};\\\", \\\"{x:532,y:499,t:1527616671733};\\\", \\\"{x:531,y:499,t:1527616671781};\\\", \\\"{x:529,y:498,t:1527616671797};\\\", \\\"{x:528,y:498,t:1527616671805};\\\", \\\"{x:523,y:498,t:1527616671815};\\\", \\\"{x:509,y:495,t:1527616671833};\\\", \\\"{x:496,y:493,t:1527616671850};\\\", \\\"{x:476,y:491,t:1527616671867};\\\", \\\"{x:456,y:488,t:1527616671883};\\\", \\\"{x:436,y:484,t:1527616671900};\\\", \\\"{x:416,y:482,t:1527616671917};\\\", \\\"{x:395,y:478,t:1527616671933};\\\", \\\"{x:376,y:475,t:1527616671949};\\\", \\\"{x:374,y:475,t:1527616671967};\\\", \\\"{x:375,y:475,t:1527616672166};\\\", \\\"{x:383,y:475,t:1527616672173};\\\", \\\"{x:389,y:475,t:1527616672183};\\\", \\\"{x:410,y:475,t:1527616672200};\\\", \\\"{x:434,y:475,t:1527616672217};\\\", \\\"{x:461,y:475,t:1527616672233};\\\", \\\"{x:480,y:475,t:1527616672250};\\\", \\\"{x:495,y:476,t:1527616672267};\\\", \\\"{x:502,y:477,t:1527616672284};\\\", \\\"{x:504,y:477,t:1527616672300};\\\", \\\"{x:506,y:478,t:1527616672781};\\\", \\\"{x:507,y:478,t:1527616672798};\\\", \\\"{x:508,y:478,t:1527616672805};\\\", \\\"{x:510,y:478,t:1527616672817};\\\", \\\"{x:512,y:478,t:1527616672834};\\\", \\\"{x:517,y:478,t:1527616672851};\\\", \\\"{x:522,y:478,t:1527616672867};\\\", \\\"{x:525,y:478,t:1527616672884};\\\", \\\"{x:528,y:478,t:1527616672901};\\\", \\\"{x:531,y:478,t:1527616672917};\\\", \\\"{x:533,y:479,t:1527616672934};\\\", \\\"{x:534,y:479,t:1527616672951};\\\", \\\"{x:535,y:479,t:1527616672966};\\\", \\\"{x:536,y:479,t:1527616672984};\\\", \\\"{x:538,y:479,t:1527616673000};\\\", \\\"{x:540,y:479,t:1527616673017};\\\", \\\"{x:544,y:479,t:1527616673034};\\\", \\\"{x:546,y:479,t:1527616673051};\\\", \\\"{x:548,y:479,t:1527616673067};\\\", \\\"{x:552,y:479,t:1527616673084};\\\", \\\"{x:555,y:479,t:1527616673101};\\\", \\\"{x:560,y:479,t:1527616673117};\\\", \\\"{x:567,y:479,t:1527616673134};\\\", \\\"{x:572,y:479,t:1527616673151};\\\", \\\"{x:578,y:479,t:1527616673168};\\\", \\\"{x:580,y:479,t:1527616673184};\\\", \\\"{x:583,y:479,t:1527616673201};\\\", \\\"{x:585,y:479,t:1527616673218};\\\", \\\"{x:588,y:479,t:1527616673234};\\\", \\\"{x:593,y:479,t:1527616673250};\\\", \\\"{x:599,y:479,t:1527616673267};\\\", \\\"{x:603,y:480,t:1527616673284};\\\", \\\"{x:611,y:480,t:1527616673301};\\\", \\\"{x:630,y:483,t:1527616673318};\\\", \\\"{x:646,y:484,t:1527616673334};\\\", \\\"{x:665,y:488,t:1527616673351};\\\", \\\"{x:684,y:490,t:1527616673368};\\\", \\\"{x:703,y:493,t:1527616673384};\\\", \\\"{x:723,y:495,t:1527616673400};\\\", \\\"{x:741,y:499,t:1527616673418};\\\", \\\"{x:759,y:502,t:1527616673433};\\\", \\\"{x:781,y:505,t:1527616673451};\\\", \\\"{x:799,y:507,t:1527616673469};\\\", \\\"{x:819,y:511,t:1527616673484};\\\", \\\"{x:838,y:515,t:1527616673501};\\\", \\\"{x:859,y:518,t:1527616673518};\\\", \\\"{x:872,y:520,t:1527616673534};\\\", \\\"{x:881,y:521,t:1527616673550};\\\", \\\"{x:887,y:521,t:1527616673567};\\\", \\\"{x:894,y:522,t:1527616673585};\\\", \\\"{x:901,y:524,t:1527616673601};\\\", \\\"{x:906,y:525,t:1527616673618};\\\", \\\"{x:913,y:526,t:1527616673635};\\\", \\\"{x:920,y:528,t:1527616673651};\\\", \\\"{x:930,y:529,t:1527616673667};\\\", \\\"{x:944,y:532,t:1527616673685};\\\", \\\"{x:957,y:534,t:1527616673701};\\\", \\\"{x:976,y:536,t:1527616673717};\\\", \\\"{x:987,y:539,t:1527616673735};\\\", \\\"{x:1000,y:540,t:1527616673751};\\\", \\\"{x:1016,y:544,t:1527616673768};\\\", \\\"{x:1033,y:548,t:1527616673785};\\\", \\\"{x:1047,y:550,t:1527616673801};\\\", \\\"{x:1061,y:553,t:1527616673818};\\\", \\\"{x:1069,y:554,t:1527616673835};\\\", \\\"{x:1078,y:555,t:1527616673851};\\\", \\\"{x:1085,y:556,t:1527616673868};\\\", \\\"{x:1092,y:558,t:1527616673885};\\\", \\\"{x:1099,y:559,t:1527616673901};\\\", \\\"{x:1110,y:564,t:1527616673918};\\\", \\\"{x:1120,y:567,t:1527616673935};\\\", \\\"{x:1125,y:567,t:1527616673951};\\\", \\\"{x:1130,y:569,t:1527616673968};\\\", \\\"{x:1135,y:571,t:1527616673985};\\\", \\\"{x:1136,y:571,t:1527616674002};\\\", \\\"{x:1137,y:571,t:1527616674101};\\\", \\\"{x:1138,y:572,t:1527616674782};\\\", \\\"{x:1141,y:574,t:1527616674789};\\\", \\\"{x:1143,y:579,t:1527616674802};\\\", \\\"{x:1147,y:585,t:1527616674819};\\\", \\\"{x:1155,y:598,t:1527616674836};\\\", \\\"{x:1161,y:606,t:1527616674852};\\\", \\\"{x:1166,y:613,t:1527616674869};\\\", \\\"{x:1171,y:621,t:1527616674885};\\\", \\\"{x:1173,y:624,t:1527616674901};\\\", \\\"{x:1175,y:629,t:1527616674919};\\\", \\\"{x:1176,y:631,t:1527616674936};\\\", \\\"{x:1179,y:639,t:1527616674952};\\\", \\\"{x:1184,y:651,t:1527616674969};\\\", \\\"{x:1189,y:660,t:1527616674986};\\\", \\\"{x:1191,y:668,t:1527616675002};\\\", \\\"{x:1194,y:674,t:1527616675019};\\\", \\\"{x:1197,y:680,t:1527616675036};\\\", \\\"{x:1200,y:689,t:1527616675052};\\\", \\\"{x:1208,y:709,t:1527616675069};\\\", \\\"{x:1209,y:717,t:1527616675085};\\\", \\\"{x:1211,y:723,t:1527616675102};\\\", \\\"{x:1214,y:731,t:1527616675119};\\\", \\\"{x:1217,y:743,t:1527616675136};\\\", \\\"{x:1218,y:753,t:1527616675152};\\\", \\\"{x:1218,y:761,t:1527616675168};\\\", \\\"{x:1221,y:773,t:1527616675186};\\\", \\\"{x:1222,y:783,t:1527616675202};\\\", \\\"{x:1225,y:797,t:1527616675219};\\\", \\\"{x:1228,y:813,t:1527616675235};\\\", \\\"{x:1232,y:825,t:1527616675253};\\\", \\\"{x:1235,y:833,t:1527616675269};\\\", \\\"{x:1236,y:841,t:1527616675286};\\\", \\\"{x:1237,y:846,t:1527616675303};\\\", \\\"{x:1239,y:852,t:1527616675319};\\\", \\\"{x:1240,y:857,t:1527616675336};\\\", \\\"{x:1240,y:860,t:1527616675352};\\\", \\\"{x:1240,y:864,t:1527616675369};\\\", \\\"{x:1240,y:868,t:1527616675386};\\\", \\\"{x:1240,y:871,t:1527616675403};\\\", \\\"{x:1240,y:877,t:1527616675419};\\\", \\\"{x:1238,y:884,t:1527616675435};\\\", \\\"{x:1233,y:896,t:1527616675453};\\\", \\\"{x:1230,y:905,t:1527616675469};\\\", \\\"{x:1225,y:916,t:1527616675486};\\\", \\\"{x:1222,y:919,t:1527616675503};\\\", \\\"{x:1218,y:924,t:1527616675519};\\\", \\\"{x:1216,y:928,t:1527616675536};\\\", \\\"{x:1214,y:931,t:1527616675553};\\\", \\\"{x:1212,y:933,t:1527616675569};\\\", \\\"{x:1211,y:935,t:1527616675586};\\\", \\\"{x:1211,y:936,t:1527616675603};\\\", \\\"{x:1210,y:938,t:1527616675620};\\\", \\\"{x:1209,y:942,t:1527616675636};\\\", \\\"{x:1208,y:945,t:1527616675653};\\\", \\\"{x:1207,y:948,t:1527616675669};\\\", \\\"{x:1207,y:950,t:1527616675686};\\\", \\\"{x:1207,y:954,t:1527616675703};\\\", \\\"{x:1207,y:958,t:1527616675720};\\\", \\\"{x:1207,y:963,t:1527616675736};\\\", \\\"{x:1207,y:970,t:1527616675753};\\\", \\\"{x:1207,y:972,t:1527616675774};\\\", \\\"{x:1207,y:973,t:1527616675786};\\\", \\\"{x:1207,y:976,t:1527616675803};\\\", \\\"{x:1207,y:979,t:1527616675821};\\\", \\\"{x:1207,y:980,t:1527616675836};\\\", \\\"{x:1207,y:982,t:1527616675853};\\\", \\\"{x:1207,y:984,t:1527616675869};\\\", \\\"{x:1208,y:985,t:1527616675886};\\\", \\\"{x:1209,y:985,t:1527616676157};\\\", \\\"{x:1210,y:985,t:1527616676170};\\\", \\\"{x:1210,y:983,t:1527616676197};\\\", \\\"{x:1211,y:982,t:1527616676205};\\\", \\\"{x:1211,y:980,t:1527616676221};\\\", \\\"{x:1212,y:978,t:1527616676237};\\\", \\\"{x:1212,y:976,t:1527616676253};\\\", \\\"{x:1213,y:972,t:1527616676270};\\\", \\\"{x:1213,y:968,t:1527616676287};\\\", \\\"{x:1214,y:964,t:1527616676303};\\\", \\\"{x:1214,y:958,t:1527616676320};\\\", \\\"{x:1214,y:951,t:1527616676337};\\\", \\\"{x:1214,y:947,t:1527616676353};\\\", \\\"{x:1214,y:944,t:1527616676370};\\\", \\\"{x:1214,y:940,t:1527616676387};\\\", \\\"{x:1214,y:936,t:1527616676403};\\\", \\\"{x:1214,y:931,t:1527616676421};\\\", \\\"{x:1214,y:922,t:1527616676437};\\\", \\\"{x:1214,y:911,t:1527616676453};\\\", \\\"{x:1214,y:906,t:1527616676470};\\\", \\\"{x:1214,y:900,t:1527616676487};\\\", \\\"{x:1214,y:893,t:1527616676504};\\\", \\\"{x:1214,y:888,t:1527616676520};\\\", \\\"{x:1214,y:881,t:1527616676537};\\\", \\\"{x:1214,y:873,t:1527616676554};\\\", \\\"{x:1215,y:869,t:1527616676570};\\\", \\\"{x:1215,y:868,t:1527616676587};\\\", \\\"{x:1215,y:865,t:1527616676604};\\\", \\\"{x:1215,y:863,t:1527616676621};\\\", \\\"{x:1215,y:859,t:1527616676637};\\\", \\\"{x:1215,y:856,t:1527616676653};\\\", \\\"{x:1215,y:853,t:1527616676670};\\\", \\\"{x:1215,y:852,t:1527616676688};\\\", \\\"{x:1215,y:850,t:1527616676717};\\\", \\\"{x:1215,y:848,t:1527616676725};\\\", \\\"{x:1215,y:845,t:1527616676737};\\\", \\\"{x:1215,y:839,t:1527616676754};\\\", \\\"{x:1215,y:835,t:1527616676770};\\\", \\\"{x:1215,y:833,t:1527616676787};\\\", \\\"{x:1215,y:831,t:1527616676804};\\\", \\\"{x:1216,y:830,t:1527616676829};\\\", \\\"{x:1223,y:830,t:1527616678094};\\\", \\\"{x:1242,y:836,t:1527616678105};\\\", \\\"{x:1265,y:846,t:1527616678122};\\\", \\\"{x:1285,y:855,t:1527616678139};\\\", \\\"{x:1307,y:862,t:1527616678155};\\\", \\\"{x:1324,y:867,t:1527616678172};\\\", \\\"{x:1335,y:869,t:1527616678188};\\\", \\\"{x:1340,y:872,t:1527616678205};\\\", \\\"{x:1333,y:872,t:1527616678549};\\\", \\\"{x:1324,y:872,t:1527616678557};\\\", \\\"{x:1313,y:871,t:1527616678572};\\\", \\\"{x:1264,y:864,t:1527616678589};\\\", \\\"{x:1219,y:850,t:1527616678606};\\\", \\\"{x:1171,y:836,t:1527616678622};\\\", \\\"{x:1122,y:824,t:1527616678639};\\\", \\\"{x:1072,y:810,t:1527616678655};\\\", \\\"{x:1027,y:796,t:1527616678672};\\\", \\\"{x:993,y:787,t:1527616678689};\\\", \\\"{x:959,y:777,t:1527616678705};\\\", \\\"{x:904,y:762,t:1527616678722};\\\", \\\"{x:855,y:743,t:1527616678739};\\\", \\\"{x:813,y:730,t:1527616678755};\\\", \\\"{x:765,y:716,t:1527616678772};\\\", \\\"{x:689,y:692,t:1527616678789};\\\", \\\"{x:625,y:671,t:1527616678805};\\\", \\\"{x:550,y:638,t:1527616678822};\\\", \\\"{x:490,y:616,t:1527616678840};\\\", \\\"{x:448,y:598,t:1527616678856};\\\", \\\"{x:426,y:590,t:1527616678872};\\\", \\\"{x:409,y:583,t:1527616678888};\\\", \\\"{x:397,y:578,t:1527616678905};\\\", \\\"{x:390,y:576,t:1527616678922};\\\", \\\"{x:388,y:575,t:1527616678939};\\\", \\\"{x:386,y:575,t:1527616678957};\\\", \\\"{x:383,y:572,t:1527616678972};\\\", \\\"{x:367,y:560,t:1527616678989};\\\", \\\"{x:361,y:557,t:1527616679005};\\\", \\\"{x:360,y:556,t:1527616679022};\\\", \\\"{x:359,y:556,t:1527616679053};\\\", \\\"{x:359,y:557,t:1527616679109};\\\", \\\"{x:359,y:561,t:1527616679122};\\\", \\\"{x:362,y:571,t:1527616679139};\\\", \\\"{x:364,y:574,t:1527616679155};\\\", \\\"{x:367,y:578,t:1527616679172};\\\", \\\"{x:371,y:583,t:1527616679189};\\\", \\\"{x:372,y:585,t:1527616679205};\\\", \\\"{x:372,y:588,t:1527616679222};\\\", \\\"{x:371,y:590,t:1527616679239};\\\", \\\"{x:362,y:594,t:1527616679256};\\\", \\\"{x:350,y:599,t:1527616679272};\\\", \\\"{x:333,y:604,t:1527616679289};\\\", \\\"{x:309,y:608,t:1527616679306};\\\", \\\"{x:277,y:610,t:1527616679322};\\\", \\\"{x:252,y:615,t:1527616679339};\\\", \\\"{x:224,y:619,t:1527616679357};\\\", \\\"{x:205,y:620,t:1527616679373};\\\", \\\"{x:184,y:625,t:1527616679389};\\\", \\\"{x:173,y:627,t:1527616679406};\\\", \\\"{x:165,y:631,t:1527616679422};\\\", \\\"{x:162,y:634,t:1527616679439};\\\", \\\"{x:161,y:636,t:1527616679456};\\\", \\\"{x:167,y:631,t:1527616679630};\\\", \\\"{x:177,y:625,t:1527616679639};\\\", \\\"{x:188,y:620,t:1527616679654};\\\", \\\"{x:202,y:610,t:1527616679671};\\\", \\\"{x:207,y:604,t:1527616679688};\\\", \\\"{x:209,y:600,t:1527616679703};\\\", \\\"{x:209,y:597,t:1527616679721};\\\", \\\"{x:209,y:593,t:1527616679738};\\\", \\\"{x:209,y:589,t:1527616679755};\\\", \\\"{x:209,y:586,t:1527616679770};\\\", \\\"{x:209,y:585,t:1527616679787};\\\", \\\"{x:206,y:584,t:1527616679804};\\\", \\\"{x:203,y:582,t:1527616679821};\\\", \\\"{x:199,y:582,t:1527616679838};\\\", \\\"{x:179,y:578,t:1527616679855};\\\", \\\"{x:170,y:574,t:1527616679871};\\\", \\\"{x:163,y:572,t:1527616679887};\\\", \\\"{x:158,y:570,t:1527616679905};\\\", \\\"{x:156,y:569,t:1527616679921};\\\", \\\"{x:155,y:568,t:1527616679937};\\\", \\\"{x:155,y:566,t:1527616679955};\\\", \\\"{x:155,y:563,t:1527616679970};\\\", \\\"{x:155,y:561,t:1527616679988};\\\", \\\"{x:155,y:559,t:1527616680005};\\\", \\\"{x:155,y:558,t:1527616680020};\\\", \\\"{x:155,y:557,t:1527616680487};\\\", \\\"{x:158,y:557,t:1527616680495};\\\", \\\"{x:164,y:557,t:1527616680504};\\\", \\\"{x:180,y:560,t:1527616680522};\\\", \\\"{x:220,y:576,t:1527616680538};\\\", \\\"{x:259,y:594,t:1527616680555};\\\", \\\"{x:295,y:609,t:1527616680573};\\\", \\\"{x:337,y:628,t:1527616680589};\\\", \\\"{x:383,y:647,t:1527616680604};\\\", \\\"{x:428,y:667,t:1527616680623};\\\", \\\"{x:478,y:689,t:1527616680639};\\\", \\\"{x:500,y:699,t:1527616680655};\\\", \\\"{x:516,y:706,t:1527616680673};\\\", \\\"{x:528,y:710,t:1527616680688};\\\", \\\"{x:535,y:715,t:1527616680704};\\\", \\\"{x:538,y:717,t:1527616680722};\\\", \\\"{x:541,y:718,t:1527616680738};\\\", \\\"{x:543,y:719,t:1527616680755};\\\", \\\"{x:543,y:720,t:1527616680772};\\\", \\\"{x:544,y:720,t:1527616680789};\\\", \\\"{x:544,y:722,t:1527616680814};\\\", \\\"{x:546,y:724,t:1527616680822};\\\", \\\"{x:549,y:731,t:1527616680839};\\\", \\\"{x:552,y:735,t:1527616680856};\\\", \\\"{x:553,y:736,t:1527616680872};\\\", \\\"{x:552,y:736,t:1527616681087};\\\", \\\"{x:551,y:732,t:1527616681095};\\\", \\\"{x:547,y:728,t:1527616681106};\\\", \\\"{x:542,y:717,t:1527616681122};\\\", \\\"{x:539,y:713,t:1527616681139};\\\", \\\"{x:539,y:712,t:1527616681156};\\\", \\\"{x:539,y:711,t:1527616681631};\\\", \\\"{x:539,y:710,t:1527616681655};\\\", \\\"{x:539,y:709,t:1527616681663};\\\", \\\"{x:540,y:708,t:1527616681679};\\\", \\\"{x:540,y:707,t:1527616681703};\\\", \\\"{x:541,y:706,t:1527616681718};\\\", \\\"{x:541,y:705,t:1527616681727};\\\", \\\"{x:542,y:705,t:1527616681738};\\\", \\\"{x:543,y:703,t:1527616681756};\\\", \\\"{x:544,y:702,t:1527616681773};\\\", \\\"{x:546,y:701,t:1527616681788};\\\", \\\"{x:548,y:698,t:1527616681806};\\\", \\\"{x:550,y:695,t:1527616681823};\\\", \\\"{x:552,y:693,t:1527616681839};\\\", \\\"{x:554,y:692,t:1527616681871};\\\", \\\"{x:554,y:691,t:1527616681887};\\\", \\\"{x:555,y:690,t:1527616681895};\\\", \\\"{x:556,y:690,t:1527616681906};\\\", \\\"{x:557,y:689,t:1527616681922};\\\", \\\"{x:558,y:688,t:1527616681939};\\\", \\\"{x:559,y:688,t:1527616682055};\\\", \\\"{x:560,y:687,t:1527616682135};\\\", \\\"{x:561,y:687,t:1527616682167};\\\", \\\"{x:562,y:686,t:1527616682174};\\\", \\\"{x:562,y:685,t:1527616682263};\\\" ] }, { \\\"rt\\\": 13101, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 135376, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-02 PM-03 PM-U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:565,y:684,t:1527616682570};\\\", \\\"{x:568,y:679,t:1527616682590};\\\", \\\"{x:576,y:668,t:1527616682607};\\\", \\\"{x:581,y:659,t:1527616682622};\\\", \\\"{x:585,y:652,t:1527616682640};\\\", \\\"{x:588,y:639,t:1527616682657};\\\", \\\"{x:593,y:622,t:1527616682679};\\\", \\\"{x:601,y:598,t:1527616682691};\\\", \\\"{x:608,y:576,t:1527616682707};\\\", \\\"{x:615,y:553,t:1527616682723};\\\", \\\"{x:619,y:535,t:1527616682740};\\\", \\\"{x:624,y:518,t:1527616682757};\\\", \\\"{x:625,y:507,t:1527616682773};\\\", \\\"{x:626,y:497,t:1527616682790};\\\", \\\"{x:630,y:478,t:1527616682807};\\\", \\\"{x:636,y:462,t:1527616682823};\\\", \\\"{x:647,y:439,t:1527616682839};\\\", \\\"{x:657,y:419,t:1527616682857};\\\", \\\"{x:660,y:417,t:1527616682873};\\\", \\\"{x:660,y:416,t:1527616682890};\\\", \\\"{x:649,y:419,t:1527616683759};\\\", \\\"{x:637,y:424,t:1527616683774};\\\", \\\"{x:623,y:439,t:1527616683791};\\\", \\\"{x:615,y:445,t:1527616683808};\\\", \\\"{x:605,y:456,t:1527616683824};\\\", \\\"{x:594,y:469,t:1527616683841};\\\", \\\"{x:587,y:482,t:1527616683858};\\\", \\\"{x:576,y:500,t:1527616683874};\\\", \\\"{x:566,y:519,t:1527616683892};\\\", \\\"{x:556,y:537,t:1527616683908};\\\", \\\"{x:546,y:549,t:1527616683925};\\\", \\\"{x:532,y:560,t:1527616683941};\\\", \\\"{x:516,y:567,t:1527616683958};\\\", \\\"{x:499,y:571,t:1527616683974};\\\", \\\"{x:474,y:572,t:1527616683991};\\\", \\\"{x:468,y:572,t:1527616684008};\\\", \\\"{x:465,y:572,t:1527616684024};\\\", \\\"{x:464,y:571,t:1527616684041};\\\", \\\"{x:464,y:568,t:1527616684058};\\\", \\\"{x:464,y:559,t:1527616684073};\\\", \\\"{x:466,y:542,t:1527616684091};\\\", \\\"{x:474,y:522,t:1527616684108};\\\", \\\"{x:484,y:505,t:1527616684126};\\\", \\\"{x:496,y:489,t:1527616684141};\\\", \\\"{x:516,y:477,t:1527616684158};\\\", \\\"{x:547,y:467,t:1527616684174};\\\", \\\"{x:567,y:462,t:1527616684191};\\\", \\\"{x:575,y:461,t:1527616684208};\\\", \\\"{x:577,y:460,t:1527616684225};\\\", \\\"{x:578,y:460,t:1527616684351};\\\", \\\"{x:578,y:461,t:1527616684359};\\\", \\\"{x:578,y:464,t:1527616684375};\\\", \\\"{x:579,y:468,t:1527616684391};\\\", \\\"{x:579,y:472,t:1527616684408};\\\", \\\"{x:582,y:481,t:1527616684425};\\\", \\\"{x:583,y:488,t:1527616684441};\\\", \\\"{x:586,y:497,t:1527616684458};\\\", \\\"{x:592,y:508,t:1527616684476};\\\", \\\"{x:598,y:519,t:1527616684491};\\\", \\\"{x:602,y:525,t:1527616684508};\\\", \\\"{x:604,y:528,t:1527616684525};\\\", \\\"{x:605,y:529,t:1527616684542};\\\", \\\"{x:605,y:530,t:1527616684558};\\\", \\\"{x:607,y:529,t:1527616684775};\\\", \\\"{x:607,y:526,t:1527616684792};\\\", \\\"{x:607,y:519,t:1527616684808};\\\", \\\"{x:608,y:514,t:1527616684825};\\\", \\\"{x:610,y:506,t:1527616684842};\\\", \\\"{x:610,y:501,t:1527616684859};\\\", \\\"{x:610,y:495,t:1527616684875};\\\", \\\"{x:610,y:490,t:1527616684892};\\\", \\\"{x:611,y:485,t:1527616684908};\\\", \\\"{x:613,y:480,t:1527616684925};\\\", \\\"{x:617,y:471,t:1527616684942};\\\", \\\"{x:622,y:465,t:1527616684959};\\\", \\\"{x:625,y:460,t:1527616684975};\\\", \\\"{x:626,y:459,t:1527616684992};\\\", \\\"{x:628,y:459,t:1527616685009};\\\", \\\"{x:630,y:459,t:1527616685030};\\\", \\\"{x:631,y:459,t:1527616685041};\\\", \\\"{x:634,y:459,t:1527616685059};\\\", \\\"{x:637,y:460,t:1527616685075};\\\", \\\"{x:638,y:461,t:1527616685092};\\\", \\\"{x:639,y:462,t:1527616685109};\\\", \\\"{x:640,y:462,t:1527616685125};\\\", \\\"{x:641,y:462,t:1527616685151};\\\", \\\"{x:642,y:462,t:1527616685175};\\\", \\\"{x:644,y:462,t:1527616685192};\\\", \\\"{x:646,y:459,t:1527616685209};\\\", \\\"{x:648,y:455,t:1527616685225};\\\", \\\"{x:653,y:448,t:1527616685242};\\\", \\\"{x:660,y:443,t:1527616685259};\\\", \\\"{x:664,y:438,t:1527616685275};\\\", \\\"{x:667,y:434,t:1527616685292};\\\", \\\"{x:669,y:431,t:1527616685309};\\\", \\\"{x:672,y:427,t:1527616685326};\\\", \\\"{x:675,y:425,t:1527616685342};\\\", \\\"{x:679,y:422,t:1527616685358};\\\", \\\"{x:682,y:422,t:1527616685375};\\\", \\\"{x:684,y:422,t:1527616685392};\\\", \\\"{x:685,y:421,t:1527616685409};\\\", \\\"{x:686,y:420,t:1527616685426};\\\", \\\"{x:686,y:416,t:1527616688470};\\\", \\\"{x:686,y:412,t:1527616688479};\\\", \\\"{x:683,y:406,t:1527616688494};\\\", \\\"{x:681,y:403,t:1527616688512};\\\", \\\"{x:685,y:406,t:1527616688551};\\\", \\\"{x:692,y:423,t:1527616688562};\\\", \\\"{x:705,y:454,t:1527616688578};\\\", \\\"{x:717,y:489,t:1527616688595};\\\", \\\"{x:724,y:521,t:1527616688613};\\\", \\\"{x:724,y:546,t:1527616688629};\\\", \\\"{x:708,y:588,t:1527616688646};\\\", \\\"{x:684,y:636,t:1527616688657};\\\", \\\"{x:667,y:664,t:1527616688673};\\\", \\\"{x:660,y:674,t:1527616688694};\\\", \\\"{x:658,y:674,t:1527616688735};\\\", \\\"{x:656,y:674,t:1527616688745};\\\", \\\"{x:646,y:665,t:1527616688762};\\\", \\\"{x:631,y:644,t:1527616688778};\\\", \\\"{x:609,y:610,t:1527616688795};\\\", \\\"{x:593,y:567,t:1527616688812};\\\", \\\"{x:587,y:538,t:1527616688828};\\\", \\\"{x:586,y:513,t:1527616688845};\\\", \\\"{x:586,y:495,t:1527616688861};\\\", \\\"{x:593,y:483,t:1527616688878};\\\", \\\"{x:621,y:478,t:1527616688894};\\\", \\\"{x:644,y:479,t:1527616688911};\\\", \\\"{x:671,y:489,t:1527616688928};\\\", \\\"{x:710,y:511,t:1527616688945};\\\", \\\"{x:757,y:544,t:1527616688962};\\\", \\\"{x:798,y:577,t:1527616688979};\\\", \\\"{x:821,y:600,t:1527616688996};\\\", \\\"{x:828,y:617,t:1527616689012};\\\", \\\"{x:827,y:633,t:1527616689028};\\\", \\\"{x:811,y:649,t:1527616689045};\\\", \\\"{x:778,y:662,t:1527616689062};\\\", \\\"{x:722,y:669,t:1527616689078};\\\", \\\"{x:594,y:670,t:1527616689094};\\\", \\\"{x:515,y:657,t:1527616689112};\\\", \\\"{x:484,y:643,t:1527616689129};\\\", \\\"{x:473,y:630,t:1527616689145};\\\", \\\"{x:473,y:615,t:1527616689163};\\\", \\\"{x:474,y:603,t:1527616689179};\\\", \\\"{x:498,y:586,t:1527616689195};\\\", \\\"{x:560,y:568,t:1527616689212};\\\", \\\"{x:637,y:559,t:1527616689229};\\\", \\\"{x:727,y:557,t:1527616689247};\\\", \\\"{x:843,y:557,t:1527616689262};\\\", \\\"{x:965,y:557,t:1527616689279};\\\", \\\"{x:1135,y:578,t:1527616689296};\\\", \\\"{x:1216,y:605,t:1527616689312};\\\", \\\"{x:1257,y:627,t:1527616689329};\\\", \\\"{x:1269,y:642,t:1527616689345};\\\", \\\"{x:1269,y:652,t:1527616689362};\\\", \\\"{x:1266,y:658,t:1527616689379};\\\", \\\"{x:1259,y:663,t:1527616689395};\\\", \\\"{x:1245,y:668,t:1527616689412};\\\", \\\"{x:1229,y:670,t:1527616689429};\\\", \\\"{x:1211,y:673,t:1527616689445};\\\", \\\"{x:1189,y:674,t:1527616689462};\\\", \\\"{x:1156,y:676,t:1527616689479};\\\", \\\"{x:1146,y:680,t:1527616689495};\\\", \\\"{x:1139,y:680,t:1527616689512};\\\", \\\"{x:1139,y:682,t:1527616689529};\\\", \\\"{x:1139,y:683,t:1527616689575};\\\", \\\"{x:1139,y:682,t:1527616689631};\\\", \\\"{x:1139,y:680,t:1527616690367};\\\", \\\"{x:1141,y:675,t:1527616690379};\\\", \\\"{x:1150,y:665,t:1527616690396};\\\", \\\"{x:1155,y:657,t:1527616690412};\\\", \\\"{x:1159,y:652,t:1527616690429};\\\", \\\"{x:1162,y:648,t:1527616690446};\\\", \\\"{x:1165,y:643,t:1527616690462};\\\", \\\"{x:1168,y:639,t:1527616690479};\\\", \\\"{x:1171,y:632,t:1527616690497};\\\", \\\"{x:1176,y:626,t:1527616690513};\\\", \\\"{x:1180,y:623,t:1527616690529};\\\", \\\"{x:1182,y:621,t:1527616690546};\\\", \\\"{x:1183,y:621,t:1527616690599};\\\", \\\"{x:1184,y:621,t:1527616690615};\\\", \\\"{x:1185,y:621,t:1527616690630};\\\", \\\"{x:1188,y:622,t:1527616690646};\\\", \\\"{x:1194,y:629,t:1527616690663};\\\", \\\"{x:1201,y:649,t:1527616690679};\\\", \\\"{x:1210,y:675,t:1527616690696};\\\", \\\"{x:1224,y:698,t:1527616690713};\\\", \\\"{x:1238,y:718,t:1527616690729};\\\", \\\"{x:1254,y:742,t:1527616690746};\\\", \\\"{x:1277,y:774,t:1527616690763};\\\", \\\"{x:1306,y:814,t:1527616690779};\\\", \\\"{x:1327,y:843,t:1527616690796};\\\", \\\"{x:1343,y:864,t:1527616690813};\\\", \\\"{x:1356,y:886,t:1527616690830};\\\", \\\"{x:1374,y:910,t:1527616690847};\\\", \\\"{x:1400,y:946,t:1527616690863};\\\", \\\"{x:1411,y:965,t:1527616690879};\\\", \\\"{x:1417,y:978,t:1527616690897};\\\", \\\"{x:1423,y:993,t:1527616690913};\\\", \\\"{x:1429,y:1007,t:1527616690929};\\\", \\\"{x:1434,y:1019,t:1527616690946};\\\", \\\"{x:1438,y:1027,t:1527616690963};\\\", \\\"{x:1441,y:1033,t:1527616690979};\\\", \\\"{x:1441,y:1034,t:1527616690997};\\\", \\\"{x:1442,y:1035,t:1527616691039};\\\", \\\"{x:1444,y:1037,t:1527616691063};\\\", \\\"{x:1447,y:1038,t:1527616691080};\\\", \\\"{x:1449,y:1038,t:1527616691096};\\\", \\\"{x:1453,y:1038,t:1527616691114};\\\", \\\"{x:1456,y:1036,t:1527616691131};\\\", \\\"{x:1457,y:1035,t:1527616691146};\\\", \\\"{x:1460,y:1031,t:1527616691163};\\\", \\\"{x:1463,y:1026,t:1527616691180};\\\", \\\"{x:1467,y:1021,t:1527616691196};\\\", \\\"{x:1471,y:1016,t:1527616691213};\\\", \\\"{x:1474,y:1011,t:1527616691230};\\\", \\\"{x:1476,y:1008,t:1527616691246};\\\", \\\"{x:1477,y:1006,t:1527616691263};\\\", \\\"{x:1477,y:1005,t:1527616691295};\\\", \\\"{x:1478,y:1004,t:1527616691302};\\\", \\\"{x:1478,y:1003,t:1527616691313};\\\", \\\"{x:1481,y:1001,t:1527616691330};\\\", \\\"{x:1484,y:997,t:1527616691346};\\\", \\\"{x:1487,y:995,t:1527616691363};\\\", \\\"{x:1490,y:990,t:1527616691381};\\\", \\\"{x:1494,y:987,t:1527616691396};\\\", \\\"{x:1495,y:986,t:1527616691413};\\\", \\\"{x:1497,y:985,t:1527616691430};\\\", \\\"{x:1498,y:984,t:1527616691447};\\\", \\\"{x:1499,y:984,t:1527616691463};\\\", \\\"{x:1502,y:984,t:1527616691480};\\\", \\\"{x:1508,y:984,t:1527616691497};\\\", \\\"{x:1513,y:984,t:1527616691513};\\\", \\\"{x:1519,y:984,t:1527616691530};\\\", \\\"{x:1522,y:983,t:1527616691547};\\\", \\\"{x:1527,y:981,t:1527616691563};\\\", \\\"{x:1531,y:979,t:1527616691580};\\\", \\\"{x:1535,y:977,t:1527616691596};\\\", \\\"{x:1536,y:977,t:1527616691613};\\\", \\\"{x:1537,y:977,t:1527616691631};\\\", \\\"{x:1538,y:976,t:1527616691807};\\\", \\\"{x:1538,y:975,t:1527616691814};\\\", \\\"{x:1538,y:974,t:1527616691830};\\\", \\\"{x:1538,y:973,t:1527616691847};\\\", \\\"{x:1538,y:971,t:1527616691863};\\\", \\\"{x:1536,y:969,t:1527616691880};\\\", \\\"{x:1530,y:967,t:1527616691897};\\\", \\\"{x:1525,y:964,t:1527616691914};\\\", \\\"{x:1517,y:962,t:1527616691931};\\\", \\\"{x:1508,y:962,t:1527616691947};\\\", \\\"{x:1496,y:959,t:1527616691963};\\\", \\\"{x:1486,y:958,t:1527616691980};\\\", \\\"{x:1478,y:958,t:1527616691997};\\\", \\\"{x:1472,y:958,t:1527616692013};\\\", \\\"{x:1470,y:958,t:1527616692030};\\\", \\\"{x:1469,y:957,t:1527616692382};\\\", \\\"{x:1469,y:956,t:1527616692397};\\\", \\\"{x:1469,y:953,t:1527616692414};\\\", \\\"{x:1469,y:949,t:1527616692431};\\\", \\\"{x:1470,y:943,t:1527616692447};\\\", \\\"{x:1470,y:941,t:1527616692464};\\\", \\\"{x:1471,y:935,t:1527616692481};\\\", \\\"{x:1472,y:925,t:1527616692497};\\\", \\\"{x:1474,y:917,t:1527616692514};\\\", \\\"{x:1474,y:912,t:1527616692531};\\\", \\\"{x:1474,y:905,t:1527616692548};\\\", \\\"{x:1474,y:897,t:1527616692564};\\\", \\\"{x:1474,y:890,t:1527616692580};\\\", \\\"{x:1474,y:884,t:1527616692598};\\\", \\\"{x:1469,y:874,t:1527616692615};\\\", \\\"{x:1460,y:859,t:1527616692631};\\\", \\\"{x:1454,y:853,t:1527616692648};\\\", \\\"{x:1454,y:852,t:1527616692665};\\\", \\\"{x:1455,y:851,t:1527616692735};\\\", \\\"{x:1458,y:851,t:1527616692747};\\\", \\\"{x:1464,y:849,t:1527616692764};\\\", \\\"{x:1470,y:848,t:1527616692780};\\\", \\\"{x:1474,y:846,t:1527616692798};\\\", \\\"{x:1475,y:846,t:1527616692814};\\\", \\\"{x:1476,y:845,t:1527616692832};\\\", \\\"{x:1477,y:843,t:1527616692848};\\\", \\\"{x:1478,y:841,t:1527616692864};\\\", \\\"{x:1480,y:837,t:1527616692881};\\\", \\\"{x:1480,y:835,t:1527616692898};\\\", \\\"{x:1481,y:831,t:1527616692914};\\\", \\\"{x:1482,y:830,t:1527616692931};\\\", \\\"{x:1482,y:829,t:1527616692948};\\\", \\\"{x:1482,y:828,t:1527616692964};\\\", \\\"{x:1482,y:830,t:1527616693326};\\\", \\\"{x:1482,y:831,t:1527616693343};\\\", \\\"{x:1482,y:832,t:1527616693399};\\\", \\\"{x:1477,y:834,t:1527616693654};\\\", \\\"{x:1465,y:834,t:1527616693664};\\\", \\\"{x:1425,y:835,t:1527616693681};\\\", \\\"{x:1361,y:835,t:1527616693699};\\\", \\\"{x:1275,y:835,t:1527616693715};\\\", \\\"{x:1191,y:833,t:1527616693731};\\\", \\\"{x:1086,y:819,t:1527616693749};\\\", \\\"{x:963,y:794,t:1527616693765};\\\", \\\"{x:841,y:762,t:1527616693781};\\\", \\\"{x:822,y:753,t:1527616693799};\\\", \\\"{x:816,y:755,t:1527616693815};\\\", \\\"{x:808,y:755,t:1527616693831};\\\", \\\"{x:780,y:751,t:1527616693848};\\\", \\\"{x:658,y:738,t:1527616693865};\\\", \\\"{x:625,y:734,t:1527616693882};\\\", \\\"{x:621,y:734,t:1527616693898};\\\", \\\"{x:618,y:734,t:1527616693914};\\\", \\\"{x:617,y:735,t:1527616693931};\\\", \\\"{x:615,y:735,t:1527616693967};\\\", \\\"{x:610,y:735,t:1527616693981};\\\", \\\"{x:597,y:731,t:1527616693999};\\\", \\\"{x:568,y:726,t:1527616694014};\\\", \\\"{x:554,y:722,t:1527616694032};\\\", \\\"{x:550,y:722,t:1527616694049};\\\", \\\"{x:548,y:720,t:1527616694065};\\\", \\\"{x:547,y:718,t:1527616694082};\\\", \\\"{x:546,y:716,t:1527616694097};\\\", \\\"{x:542,y:712,t:1527616694114};\\\", \\\"{x:540,y:708,t:1527616694131};\\\", \\\"{x:538,y:706,t:1527616694147};\\\", \\\"{x:535,y:704,t:1527616694164};\\\", \\\"{x:529,y:700,t:1527616694181};\\\", \\\"{x:523,y:696,t:1527616694197};\\\", \\\"{x:517,y:691,t:1527616694216};\\\", \\\"{x:515,y:689,t:1527616694233};\\\", \\\"{x:513,y:687,t:1527616694250};\\\", \\\"{x:510,y:686,t:1527616694266};\\\", \\\"{x:509,y:685,t:1527616694282};\\\", \\\"{x:516,y:677,t:1527616694299};\\\", \\\"{x:550,y:660,t:1527616694316};\\\", \\\"{x:581,y:641,t:1527616694332};\\\", \\\"{x:599,y:624,t:1527616694349};\\\", \\\"{x:611,y:608,t:1527616694367};\\\", \\\"{x:617,y:596,t:1527616694382};\\\", \\\"{x:625,y:580,t:1527616694400};\\\", \\\"{x:626,y:573,t:1527616694417};\\\", \\\"{x:629,y:568,t:1527616694433};\\\", \\\"{x:630,y:563,t:1527616694450};\\\", \\\"{x:633,y:555,t:1527616694466};\\\", \\\"{x:633,y:552,t:1527616694482};\\\", \\\"{x:633,y:550,t:1527616694499};\\\", \\\"{x:633,y:549,t:1527616694516};\\\", \\\"{x:632,y:551,t:1527616694663};\\\", \\\"{x:630,y:554,t:1527616694671};\\\", \\\"{x:627,y:558,t:1527616694683};\\\", \\\"{x:623,y:565,t:1527616694699};\\\", \\\"{x:618,y:572,t:1527616694717};\\\", \\\"{x:614,y:578,t:1527616694734};\\\", \\\"{x:612,y:580,t:1527616694749};\\\", \\\"{x:609,y:582,t:1527616694767};\\\", \\\"{x:607,y:583,t:1527616694782};\\\", \\\"{x:607,y:584,t:1527616694799};\\\", \\\"{x:605,y:586,t:1527616694816};\\\", \\\"{x:603,y:588,t:1527616694834};\\\", \\\"{x:603,y:590,t:1527616694850};\\\", \\\"{x:602,y:590,t:1527616695103};\\\", \\\"{x:600,y:597,t:1527616695117};\\\", \\\"{x:590,y:620,t:1527616695134};\\\", \\\"{x:577,y:645,t:1527616695150};\\\", \\\"{x:556,y:683,t:1527616695167};\\\", \\\"{x:544,y:700,t:1527616695183};\\\", \\\"{x:538,y:712,t:1527616695201};\\\", \\\"{x:535,y:724,t:1527616695217};\\\", \\\"{x:534,y:731,t:1527616695234};\\\", \\\"{x:534,y:737,t:1527616695251};\\\", \\\"{x:533,y:738,t:1527616695423};\\\", \\\"{x:533,y:737,t:1527616695434};\\\", \\\"{x:530,y:730,t:1527616695450};\\\", \\\"{x:526,y:721,t:1527616695466};\\\", \\\"{x:526,y:719,t:1527616695484};\\\", \\\"{x:526,y:718,t:1527616695500};\\\", \\\"{x:526,y:717,t:1527616695991};\\\", \\\"{x:530,y:715,t:1527616696062};\\\", \\\"{x:543,y:712,t:1527616696070};\\\", \\\"{x:557,y:710,t:1527616696084};\\\", \\\"{x:603,y:702,t:1527616696101};\\\", \\\"{x:660,y:690,t:1527616696117};\\\", \\\"{x:771,y:672,t:1527616696134};\\\", \\\"{x:845,y:663,t:1527616696151};\\\", \\\"{x:905,y:654,t:1527616696168};\\\", \\\"{x:970,y:638,t:1527616696184};\\\", \\\"{x:1017,y:628,t:1527616696201};\\\", \\\"{x:1048,y:617,t:1527616696217};\\\", \\\"{x:1070,y:609,t:1527616696234};\\\", \\\"{x:1080,y:604,t:1527616696250};\\\", \\\"{x:1083,y:601,t:1527616696267};\\\", \\\"{x:1084,y:601,t:1527616696710};\\\", \\\"{x:1085,y:600,t:1527616696719};\\\", \\\"{x:1091,y:593,t:1527616696735};\\\", \\\"{x:1095,y:589,t:1527616696751};\\\", \\\"{x:1096,y:588,t:1527616696769};\\\" ] }, { \\\"rt\\\": 77720, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 214302, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -12 PM-11 AM-I -I -12 PM-11 AM-01 PM-01 PM-H -H -O -F -F -F -F -F -F -F -01 PM-C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1100,y:585,t:1527616696872};\\\", \\\"{x:1100,y:584,t:1527616696884};\\\", \\\"{x:1100,y:583,t:1527616696950};\\\", \\\"{x:1100,y:582,t:1527616697230};\\\", \\\"{x:1098,y:581,t:1527616697239};\\\", \\\"{x:1094,y:581,t:1527616697251};\\\", \\\"{x:1080,y:580,t:1527616697269};\\\", \\\"{x:788,y:588,t:1527616697365};\\\", \\\"{x:781,y:588,t:1527616697369};\\\", \\\"{x:773,y:588,t:1527616697385};\\\", \\\"{x:765,y:588,t:1527616697401};\\\", \\\"{x:758,y:587,t:1527616697419};\\\", \\\"{x:748,y:586,t:1527616697435};\\\", \\\"{x:732,y:583,t:1527616697451};\\\", \\\"{x:701,y:578,t:1527616697469};\\\", \\\"{x:655,y:574,t:1527616697485};\\\", \\\"{x:592,y:569,t:1527616697502};\\\", \\\"{x:526,y:566,t:1527616697518};\\\", \\\"{x:500,y:564,t:1527616697535};\\\", \\\"{x:489,y:563,t:1527616697552};\\\", \\\"{x:483,y:563,t:1527616697569};\\\", \\\"{x:478,y:562,t:1527616697585};\\\", \\\"{x:474,y:562,t:1527616697602};\\\", \\\"{x:468,y:560,t:1527616697619};\\\", \\\"{x:458,y:557,t:1527616697636};\\\", \\\"{x:441,y:553,t:1527616697653};\\\", \\\"{x:424,y:550,t:1527616697668};\\\", \\\"{x:415,y:548,t:1527616697685};\\\", \\\"{x:412,y:546,t:1527616697703};\\\", \\\"{x:411,y:545,t:1527616697726};\\\", \\\"{x:410,y:544,t:1527616697735};\\\", \\\"{x:408,y:539,t:1527616697753};\\\", \\\"{x:404,y:535,t:1527616697769};\\\", \\\"{x:401,y:530,t:1527616697785};\\\", \\\"{x:400,y:524,t:1527616697802};\\\", \\\"{x:400,y:517,t:1527616697819};\\\", \\\"{x:400,y:510,t:1527616697835};\\\", \\\"{x:400,y:506,t:1527616697852};\\\", \\\"{x:400,y:503,t:1527616697869};\\\", \\\"{x:400,y:501,t:1527616697885};\\\", \\\"{x:401,y:497,t:1527616697903};\\\", \\\"{x:402,y:493,t:1527616697919};\\\", \\\"{x:404,y:491,t:1527616697942};\\\", \\\"{x:405,y:490,t:1527616697966};\\\", \\\"{x:406,y:488,t:1527616697982};\\\", \\\"{x:407,y:487,t:1527616698007};\\\", \\\"{x:408,y:486,t:1527616698018};\\\", \\\"{x:411,y:483,t:1527616698036};\\\", \\\"{x:413,y:482,t:1527616698053};\\\", \\\"{x:414,y:481,t:1527616698070};\\\", \\\"{x:416,y:481,t:1527616698095};\\\", \\\"{x:417,y:481,t:1527616698119};\\\", \\\"{x:421,y:481,t:1527616698135};\\\", \\\"{x:429,y:481,t:1527616698153};\\\", \\\"{x:442,y:481,t:1527616698170};\\\", \\\"{x:458,y:481,t:1527616698186};\\\", \\\"{x:475,y:481,t:1527616698202};\\\", \\\"{x:493,y:485,t:1527616698220};\\\", \\\"{x:510,y:487,t:1527616698235};\\\", \\\"{x:526,y:489,t:1527616698252};\\\", \\\"{x:547,y:490,t:1527616698270};\\\", \\\"{x:563,y:490,t:1527616698286};\\\", \\\"{x:580,y:491,t:1527616698303};\\\", \\\"{x:584,y:491,t:1527616698319};\\\", \\\"{x:587,y:491,t:1527616698336};\\\", \\\"{x:589,y:491,t:1527616698352};\\\", \\\"{x:591,y:491,t:1527616698370};\\\", \\\"{x:594,y:491,t:1527616698385};\\\", \\\"{x:599,y:491,t:1527616698403};\\\", \\\"{x:606,y:491,t:1527616698419};\\\", \\\"{x:612,y:490,t:1527616698435};\\\", \\\"{x:617,y:489,t:1527616698452};\\\", \\\"{x:621,y:489,t:1527616698469};\\\", \\\"{x:622,y:488,t:1527616698485};\\\", \\\"{x:624,y:487,t:1527616698502};\\\", \\\"{x:625,y:486,t:1527616698527};\\\", \\\"{x:627,y:485,t:1527616698543};\\\", \\\"{x:629,y:485,t:1527616698558};\\\", \\\"{x:630,y:485,t:1527616698570};\\\", \\\"{x:631,y:484,t:1527616698586};\\\", \\\"{x:632,y:483,t:1527616698602};\\\", \\\"{x:635,y:482,t:1527616698620};\\\", \\\"{x:638,y:479,t:1527616698636};\\\", \\\"{x:639,y:478,t:1527616698652};\\\", \\\"{x:641,y:477,t:1527616698669};\\\", \\\"{x:642,y:476,t:1527616698686};\\\", \\\"{x:636,y:476,t:1527616698951};\\\", \\\"{x:628,y:476,t:1527616698958};\\\", \\\"{x:616,y:476,t:1527616698969};\\\", \\\"{x:573,y:479,t:1527616698987};\\\", \\\"{x:527,y:482,t:1527616699002};\\\", \\\"{x:481,y:485,t:1527616699020};\\\", \\\"{x:456,y:486,t:1527616699037};\\\", \\\"{x:444,y:486,t:1527616699053};\\\", \\\"{x:442,y:486,t:1527616699070};\\\", \\\"{x:441,y:486,t:1527616699087};\\\", \\\"{x:441,y:487,t:1527616699566};\\\", \\\"{x:443,y:488,t:1527616699575};\\\", \\\"{x:449,y:490,t:1527616699587};\\\", \\\"{x:462,y:494,t:1527616699604};\\\", \\\"{x:479,y:497,t:1527616699621};\\\", \\\"{x:489,y:499,t:1527616699637};\\\", \\\"{x:495,y:500,t:1527616699653};\\\", \\\"{x:499,y:501,t:1527616699670};\\\", \\\"{x:501,y:501,t:1527616699686};\\\", \\\"{x:502,y:502,t:1527616699711};\\\", \\\"{x:503,y:502,t:1527616699734};\\\", \\\"{x:503,y:503,t:1527616699742};\\\", \\\"{x:505,y:503,t:1527616699754};\\\", \\\"{x:506,y:503,t:1527616699771};\\\", \\\"{x:508,y:503,t:1527616699786};\\\", \\\"{x:509,y:503,t:1527616699803};\\\", \\\"{x:510,y:503,t:1527616699820};\\\", \\\"{x:511,y:503,t:1527616699837};\\\", \\\"{x:512,y:503,t:1527616700038};\\\", \\\"{x:513,y:503,t:1527616700054};\\\", \\\"{x:513,y:502,t:1527616700070};\\\", \\\"{x:515,y:499,t:1527616700088};\\\", \\\"{x:516,y:497,t:1527616700119};\\\", \\\"{x:516,y:496,t:1527616700134};\\\", \\\"{x:518,y:495,t:1527616700143};\\\", \\\"{x:519,y:494,t:1527616700154};\\\", \\\"{x:522,y:492,t:1527616700170};\\\", \\\"{x:524,y:492,t:1527616700191};\\\", \\\"{x:525,y:492,t:1527616700207};\\\", \\\"{x:525,y:491,t:1527616700220};\\\", \\\"{x:526,y:490,t:1527616700238};\\\", \\\"{x:527,y:490,t:1527616700710};\\\", \\\"{x:528,y:490,t:1527616700734};\\\", \\\"{x:530,y:490,t:1527616700750};\\\", \\\"{x:531,y:490,t:1527616700783};\\\", \\\"{x:533,y:491,t:1527616700807};\\\", \\\"{x:534,y:491,t:1527616700820};\\\", \\\"{x:535,y:491,t:1527616700838};\\\", \\\"{x:538,y:492,t:1527616700854};\\\", \\\"{x:541,y:493,t:1527616700871};\\\", \\\"{x:548,y:493,t:1527616700887};\\\", \\\"{x:559,y:494,t:1527616700905};\\\", \\\"{x:572,y:495,t:1527616700921};\\\", \\\"{x:587,y:495,t:1527616700937};\\\", \\\"{x:598,y:495,t:1527616700955};\\\", \\\"{x:607,y:495,t:1527616700972};\\\", \\\"{x:614,y:497,t:1527616700987};\\\", \\\"{x:623,y:497,t:1527616701005};\\\", \\\"{x:632,y:497,t:1527616701021};\\\", \\\"{x:650,y:497,t:1527616701037};\\\", \\\"{x:681,y:498,t:1527616701054};\\\", \\\"{x:707,y:498,t:1527616701072};\\\", \\\"{x:730,y:500,t:1527616701088};\\\", \\\"{x:758,y:505,t:1527616701105};\\\", \\\"{x:788,y:510,t:1527616701122};\\\", \\\"{x:823,y:515,t:1527616701138};\\\", \\\"{x:859,y:522,t:1527616701155};\\\", \\\"{x:893,y:528,t:1527616701171};\\\", \\\"{x:928,y:537,t:1527616701188};\\\", \\\"{x:957,y:544,t:1527616701205};\\\", \\\"{x:989,y:554,t:1527616701222};\\\", \\\"{x:1064,y:576,t:1527616701238};\\\", \\\"{x:1120,y:593,t:1527616701255};\\\", \\\"{x:1179,y:612,t:1527616701272};\\\", \\\"{x:1238,y:632,t:1527616701289};\\\", \\\"{x:1296,y:658,t:1527616701304};\\\", \\\"{x:1346,y:682,t:1527616701321};\\\", \\\"{x:1391,y:702,t:1527616701339};\\\", \\\"{x:1419,y:715,t:1527616701355};\\\", \\\"{x:1437,y:724,t:1527616701371};\\\", \\\"{x:1447,y:732,t:1527616701388};\\\", \\\"{x:1450,y:735,t:1527616701405};\\\", \\\"{x:1455,y:740,t:1527616701422};\\\", \\\"{x:1463,y:751,t:1527616701439};\\\", \\\"{x:1464,y:754,t:1527616701455};\\\", \\\"{x:1465,y:756,t:1527616701472};\\\", \\\"{x:1465,y:757,t:1527616701489};\\\", \\\"{x:1466,y:758,t:1527616701511};\\\", \\\"{x:1466,y:760,t:1527616701558};\\\", \\\"{x:1466,y:761,t:1527616701571};\\\", \\\"{x:1466,y:764,t:1527616701589};\\\", \\\"{x:1466,y:767,t:1527616701605};\\\", \\\"{x:1466,y:768,t:1527616701622};\\\", \\\"{x:1465,y:778,t:1527616701638};\\\", \\\"{x:1462,y:791,t:1527616701656};\\\", \\\"{x:1461,y:804,t:1527616701671};\\\", \\\"{x:1459,y:817,t:1527616701689};\\\", \\\"{x:1458,y:828,t:1527616701706};\\\", \\\"{x:1458,y:832,t:1527616701722};\\\", \\\"{x:1458,y:835,t:1527616701739};\\\", \\\"{x:1458,y:836,t:1527616701758};\\\", \\\"{x:1457,y:836,t:1527616701772};\\\", \\\"{x:1457,y:838,t:1527616701789};\\\", \\\"{x:1456,y:842,t:1527616701806};\\\", \\\"{x:1454,y:850,t:1527616701822};\\\", \\\"{x:1450,y:863,t:1527616701839};\\\", \\\"{x:1449,y:869,t:1527616701856};\\\", \\\"{x:1449,y:874,t:1527616701872};\\\", \\\"{x:1448,y:880,t:1527616701888};\\\", \\\"{x:1446,y:889,t:1527616701905};\\\", \\\"{x:1445,y:900,t:1527616701921};\\\", \\\"{x:1444,y:909,t:1527616701939};\\\", \\\"{x:1444,y:913,t:1527616701955};\\\", \\\"{x:1444,y:916,t:1527616701973};\\\", \\\"{x:1444,y:917,t:1527616701988};\\\", \\\"{x:1444,y:919,t:1527616702006};\\\", \\\"{x:1444,y:920,t:1527616702022};\\\", \\\"{x:1444,y:921,t:1527616702039};\\\", \\\"{x:1445,y:922,t:1527616702055};\\\", \\\"{x:1446,y:922,t:1527616702102};\\\", \\\"{x:1446,y:920,t:1527616702159};\\\", \\\"{x:1447,y:914,t:1527616702172};\\\", \\\"{x:1451,y:901,t:1527616702188};\\\", \\\"{x:1456,y:884,t:1527616702205};\\\", \\\"{x:1461,y:862,t:1527616702223};\\\", \\\"{x:1462,y:851,t:1527616702239};\\\", \\\"{x:1465,y:837,t:1527616702256};\\\", \\\"{x:1465,y:822,t:1527616702273};\\\", \\\"{x:1465,y:804,t:1527616702289};\\\", \\\"{x:1465,y:781,t:1527616702305};\\\", \\\"{x:1465,y:763,t:1527616702322};\\\", \\\"{x:1465,y:747,t:1527616702339};\\\", \\\"{x:1465,y:740,t:1527616702355};\\\", \\\"{x:1462,y:728,t:1527616702373};\\\", \\\"{x:1458,y:721,t:1527616702388};\\\", \\\"{x:1455,y:714,t:1527616702406};\\\", \\\"{x:1448,y:707,t:1527616702423};\\\", \\\"{x:1445,y:703,t:1527616702439};\\\", \\\"{x:1441,y:701,t:1527616702456};\\\", \\\"{x:1433,y:698,t:1527616702473};\\\", \\\"{x:1419,y:695,t:1527616702489};\\\", \\\"{x:1397,y:691,t:1527616702506};\\\", \\\"{x:1380,y:688,t:1527616702523};\\\", \\\"{x:1363,y:685,t:1527616702540};\\\", \\\"{x:1332,y:675,t:1527616702555};\\\", \\\"{x:1310,y:669,t:1527616702573};\\\", \\\"{x:1303,y:667,t:1527616702589};\\\", \\\"{x:1300,y:665,t:1527616702606};\\\", \\\"{x:1299,y:664,t:1527616702623};\\\", \\\"{x:1297,y:660,t:1527616702640};\\\", \\\"{x:1297,y:654,t:1527616702656};\\\", \\\"{x:1297,y:649,t:1527616702673};\\\", \\\"{x:1297,y:642,t:1527616702690};\\\", \\\"{x:1297,y:632,t:1527616702705};\\\", \\\"{x:1297,y:620,t:1527616702722};\\\", \\\"{x:1299,y:610,t:1527616702739};\\\", \\\"{x:1301,y:597,t:1527616702756};\\\", \\\"{x:1303,y:585,t:1527616702773};\\\", \\\"{x:1303,y:580,t:1527616702790};\\\", \\\"{x:1303,y:579,t:1527616702806};\\\", \\\"{x:1303,y:576,t:1527616702822};\\\", \\\"{x:1303,y:575,t:1527616702840};\\\", \\\"{x:1303,y:574,t:1527616702857};\\\", \\\"{x:1303,y:573,t:1527616702878};\\\", \\\"{x:1303,y:571,t:1527616702894};\\\", \\\"{x:1303,y:568,t:1527616702907};\\\", \\\"{x:1304,y:565,t:1527616702923};\\\", \\\"{x:1307,y:549,t:1527616702940};\\\", \\\"{x:1308,y:540,t:1527616702957};\\\", \\\"{x:1308,y:537,t:1527616702973};\\\", \\\"{x:1309,y:533,t:1527616702990};\\\", \\\"{x:1310,y:530,t:1527616703007};\\\", \\\"{x:1311,y:527,t:1527616703023};\\\", \\\"{x:1313,y:520,t:1527616703039};\\\", \\\"{x:1313,y:519,t:1527616703057};\\\", \\\"{x:1313,y:516,t:1527616703073};\\\", \\\"{x:1314,y:514,t:1527616703089};\\\", \\\"{x:1314,y:513,t:1527616703110};\\\", \\\"{x:1314,y:511,t:1527616703127};\\\", \\\"{x:1314,y:510,t:1527616703140};\\\", \\\"{x:1314,y:508,t:1527616703157};\\\", \\\"{x:1314,y:507,t:1527616703173};\\\", \\\"{x:1315,y:507,t:1527616703189};\\\", \\\"{x:1315,y:505,t:1527616703207};\\\", \\\"{x:1315,y:504,t:1527616703223};\\\", \\\"{x:1315,y:503,t:1527616703263};\\\", \\\"{x:1315,y:502,t:1527616703274};\\\", \\\"{x:1315,y:501,t:1527616703290};\\\", \\\"{x:1317,y:500,t:1527616703687};\\\", \\\"{x:1317,y:502,t:1527616703694};\\\", \\\"{x:1318,y:507,t:1527616703707};\\\", \\\"{x:1318,y:512,t:1527616703723};\\\", \\\"{x:1318,y:516,t:1527616703740};\\\", \\\"{x:1318,y:520,t:1527616703756};\\\", \\\"{x:1318,y:523,t:1527616703773};\\\", \\\"{x:1318,y:528,t:1527616703791};\\\", \\\"{x:1318,y:533,t:1527616703807};\\\", \\\"{x:1319,y:539,t:1527616703823};\\\", \\\"{x:1321,y:543,t:1527616703840};\\\", \\\"{x:1321,y:551,t:1527616703857};\\\", \\\"{x:1322,y:559,t:1527616703874};\\\", \\\"{x:1323,y:569,t:1527616703891};\\\", \\\"{x:1326,y:583,t:1527616703906};\\\", \\\"{x:1327,y:599,t:1527616703924};\\\", \\\"{x:1330,y:617,t:1527616703941};\\\", \\\"{x:1331,y:629,t:1527616703957};\\\", \\\"{x:1332,y:642,t:1527616703974};\\\", \\\"{x:1335,y:660,t:1527616703991};\\\", \\\"{x:1337,y:675,t:1527616704006};\\\", \\\"{x:1340,y:689,t:1527616704024};\\\", \\\"{x:1342,y:703,t:1527616704041};\\\", \\\"{x:1342,y:718,t:1527616704057};\\\", \\\"{x:1345,y:730,t:1527616704074};\\\", \\\"{x:1346,y:744,t:1527616704091};\\\", \\\"{x:1348,y:758,t:1527616704107};\\\", \\\"{x:1351,y:771,t:1527616704124};\\\", \\\"{x:1351,y:784,t:1527616704141};\\\", \\\"{x:1354,y:802,t:1527616704157};\\\", \\\"{x:1354,y:819,t:1527616704174};\\\", \\\"{x:1354,y:845,t:1527616704191};\\\", \\\"{x:1354,y:861,t:1527616704208};\\\", \\\"{x:1354,y:876,t:1527616704224};\\\", \\\"{x:1354,y:891,t:1527616704241};\\\", \\\"{x:1354,y:905,t:1527616704258};\\\", \\\"{x:1354,y:910,t:1527616704274};\\\", \\\"{x:1354,y:912,t:1527616704290};\\\", \\\"{x:1354,y:915,t:1527616704308};\\\", \\\"{x:1354,y:918,t:1527616704324};\\\", \\\"{x:1354,y:922,t:1527616704341};\\\", \\\"{x:1354,y:924,t:1527616704358};\\\", \\\"{x:1354,y:927,t:1527616704374};\\\", \\\"{x:1354,y:929,t:1527616704391};\\\", \\\"{x:1354,y:932,t:1527616704408};\\\", \\\"{x:1354,y:934,t:1527616704424};\\\", \\\"{x:1354,y:936,t:1527616704441};\\\", \\\"{x:1352,y:940,t:1527616704458};\\\", \\\"{x:1351,y:944,t:1527616704474};\\\", \\\"{x:1350,y:946,t:1527616704490};\\\", \\\"{x:1348,y:950,t:1527616704508};\\\", \\\"{x:1346,y:953,t:1527616704524};\\\", \\\"{x:1342,y:957,t:1527616704540};\\\", \\\"{x:1336,y:963,t:1527616704558};\\\", \\\"{x:1333,y:966,t:1527616704574};\\\", \\\"{x:1329,y:968,t:1527616704591};\\\", \\\"{x:1328,y:969,t:1527616704608};\\\", \\\"{x:1328,y:970,t:1527616704624};\\\", \\\"{x:1326,y:972,t:1527616704641};\\\", \\\"{x:1324,y:973,t:1527616704658};\\\", \\\"{x:1320,y:976,t:1527616704675};\\\", \\\"{x:1316,y:980,t:1527616704691};\\\", \\\"{x:1313,y:981,t:1527616704707};\\\", \\\"{x:1311,y:982,t:1527616704726};\\\", \\\"{x:1310,y:982,t:1527616704741};\\\", \\\"{x:1306,y:984,t:1527616704758};\\\", \\\"{x:1303,y:986,t:1527616704775};\\\", \\\"{x:1300,y:986,t:1527616704791};\\\", \\\"{x:1298,y:986,t:1527616704808};\\\", \\\"{x:1297,y:986,t:1527616704830};\\\", \\\"{x:1296,y:986,t:1527616704887};\\\", \\\"{x:1295,y:986,t:1527616704894};\\\", \\\"{x:1293,y:986,t:1527616704910};\\\", \\\"{x:1292,y:986,t:1527616704925};\\\", \\\"{x:1291,y:985,t:1527616704940};\\\", \\\"{x:1290,y:984,t:1527616704958};\\\", \\\"{x:1289,y:984,t:1527616704982};\\\", \\\"{x:1289,y:983,t:1527616704998};\\\", \\\"{x:1288,y:982,t:1527616705030};\\\", \\\"{x:1287,y:981,t:1527616705041};\\\", \\\"{x:1286,y:981,t:1527616705062};\\\", \\\"{x:1286,y:980,t:1527616705094};\\\", \\\"{x:1285,y:979,t:1527616705111};\\\", \\\"{x:1285,y:978,t:1527616705391};\\\", \\\"{x:1286,y:977,t:1527616705407};\\\", \\\"{x:1286,y:976,t:1527616705414};\\\", \\\"{x:1287,y:976,t:1527616705425};\\\", \\\"{x:1290,y:976,t:1527616705442};\\\", \\\"{x:1291,y:976,t:1527616705458};\\\", \\\"{x:1292,y:974,t:1527616705475};\\\", \\\"{x:1293,y:974,t:1527616705495};\\\", \\\"{x:1295,y:974,t:1527616705509};\\\", \\\"{x:1296,y:974,t:1527616705525};\\\", \\\"{x:1298,y:973,t:1527616705542};\\\", \\\"{x:1299,y:973,t:1527616705559};\\\", \\\"{x:1300,y:973,t:1527616705583};\\\", \\\"{x:1301,y:972,t:1527616705592};\\\", \\\"{x:1302,y:972,t:1527616705615};\\\", \\\"{x:1303,y:971,t:1527616705638};\\\", \\\"{x:1305,y:970,t:1527616705646};\\\", \\\"{x:1306,y:970,t:1527616705659};\\\", \\\"{x:1307,y:968,t:1527616705675};\\\", \\\"{x:1308,y:968,t:1527616705691};\\\", \\\"{x:1309,y:967,t:1527616705708};\\\", \\\"{x:1310,y:967,t:1527616706351};\\\", \\\"{x:1311,y:967,t:1527616706407};\\\", \\\"{x:1312,y:967,t:1527616707055};\\\", \\\"{x:1313,y:967,t:1527616707078};\\\", \\\"{x:1314,y:968,t:1527616707094};\\\", \\\"{x:1315,y:968,t:1527616707118};\\\", \\\"{x:1316,y:968,t:1527616707143};\\\", \\\"{x:1317,y:968,t:1527616707159};\\\", \\\"{x:1318,y:968,t:1527616707206};\\\", \\\"{x:1317,y:960,t:1527616717496};\\\", \\\"{x:1316,y:953,t:1527616717504};\\\", \\\"{x:1315,y:950,t:1527616717519};\\\", \\\"{x:1315,y:947,t:1527616717535};\\\", \\\"{x:1315,y:946,t:1527616717551};\\\", \\\"{x:1315,y:945,t:1527616717569};\\\", \\\"{x:1315,y:944,t:1527616717599};\\\", \\\"{x:1315,y:943,t:1527616717622};\\\", \\\"{x:1315,y:942,t:1527616717634};\\\", \\\"{x:1315,y:940,t:1527616717652};\\\", \\\"{x:1315,y:938,t:1527616717669};\\\", \\\"{x:1315,y:937,t:1527616717687};\\\", \\\"{x:1315,y:936,t:1527616717703};\\\", \\\"{x:1315,y:934,t:1527616717719};\\\", \\\"{x:1315,y:931,t:1527616717735};\\\", \\\"{x:1315,y:927,t:1527616717751};\\\", \\\"{x:1315,y:924,t:1527616717769};\\\", \\\"{x:1315,y:920,t:1527616717785};\\\", \\\"{x:1315,y:917,t:1527616717802};\\\", \\\"{x:1315,y:913,t:1527616717819};\\\", \\\"{x:1315,y:911,t:1527616717835};\\\", \\\"{x:1315,y:909,t:1527616717852};\\\", \\\"{x:1315,y:906,t:1527616717869};\\\", \\\"{x:1315,y:902,t:1527616717885};\\\", \\\"{x:1315,y:899,t:1527616717902};\\\", \\\"{x:1314,y:895,t:1527616717920};\\\", \\\"{x:1314,y:893,t:1527616717936};\\\", \\\"{x:1314,y:891,t:1527616717953};\\\", \\\"{x:1313,y:890,t:1527616717969};\\\", \\\"{x:1313,y:889,t:1527616717991};\\\", \\\"{x:1313,y:888,t:1527616718002};\\\", \\\"{x:1313,y:887,t:1527616718019};\\\", \\\"{x:1313,y:885,t:1527616718036};\\\", \\\"{x:1313,y:884,t:1527616718052};\\\", \\\"{x:1313,y:882,t:1527616718069};\\\", \\\"{x:1313,y:881,t:1527616718086};\\\", \\\"{x:1313,y:880,t:1527616718102};\\\", \\\"{x:1313,y:879,t:1527616718119};\\\", \\\"{x:1313,y:877,t:1527616718135};\\\", \\\"{x:1313,y:875,t:1527616718152};\\\", \\\"{x:1313,y:874,t:1527616718169};\\\", \\\"{x:1313,y:872,t:1527616718186};\\\", \\\"{x:1313,y:871,t:1527616718207};\\\", \\\"{x:1313,y:870,t:1527616718231};\\\", \\\"{x:1313,y:869,t:1527616718240};\\\", \\\"{x:1313,y:866,t:1527616718256};\\\", \\\"{x:1313,y:865,t:1527616718269};\\\", \\\"{x:1313,y:859,t:1527616718286};\\\", \\\"{x:1313,y:851,t:1527616718302};\\\", \\\"{x:1313,y:850,t:1527616718319};\\\", \\\"{x:1313,y:849,t:1527616718336};\\\", \\\"{x:1314,y:847,t:1527616718352};\\\", \\\"{x:1314,y:846,t:1527616718369};\\\", \\\"{x:1314,y:843,t:1527616718387};\\\", \\\"{x:1315,y:837,t:1527616718404};\\\", \\\"{x:1315,y:834,t:1527616718420};\\\", \\\"{x:1315,y:832,t:1527616718436};\\\", \\\"{x:1315,y:830,t:1527616718453};\\\", \\\"{x:1315,y:829,t:1527616718470};\\\", \\\"{x:1315,y:828,t:1527616718487};\\\", \\\"{x:1315,y:827,t:1527616718504};\\\", \\\"{x:1317,y:824,t:1527616719016};\\\", \\\"{x:1318,y:813,t:1527616719024};\\\", \\\"{x:1319,y:804,t:1527616719037};\\\", \\\"{x:1320,y:786,t:1527616719053};\\\", \\\"{x:1322,y:772,t:1527616719071};\\\", \\\"{x:1322,y:766,t:1527616719087};\\\", \\\"{x:1322,y:758,t:1527616719104};\\\", \\\"{x:1322,y:751,t:1527616719120};\\\", \\\"{x:1322,y:745,t:1527616719136};\\\", \\\"{x:1322,y:737,t:1527616719154};\\\", \\\"{x:1322,y:727,t:1527616719170};\\\", \\\"{x:1322,y:720,t:1527616719186};\\\", \\\"{x:1322,y:714,t:1527616719204};\\\", \\\"{x:1323,y:707,t:1527616719221};\\\", \\\"{x:1324,y:702,t:1527616719237};\\\", \\\"{x:1325,y:692,t:1527616719253};\\\", \\\"{x:1325,y:678,t:1527616719271};\\\", \\\"{x:1325,y:664,t:1527616719286};\\\", \\\"{x:1332,y:644,t:1527616719303};\\\", \\\"{x:1333,y:635,t:1527616719320};\\\", \\\"{x:1333,y:625,t:1527616719338};\\\", \\\"{x:1333,y:614,t:1527616719353};\\\", \\\"{x:1332,y:599,t:1527616719370};\\\", \\\"{x:1330,y:582,t:1527616719387};\\\", \\\"{x:1326,y:570,t:1527616719403};\\\", \\\"{x:1322,y:559,t:1527616719420};\\\", \\\"{x:1320,y:551,t:1527616719437};\\\", \\\"{x:1316,y:539,t:1527616719453};\\\", \\\"{x:1310,y:523,t:1527616719471};\\\", \\\"{x:1306,y:513,t:1527616719487};\\\", \\\"{x:1305,y:504,t:1527616719504};\\\", \\\"{x:1300,y:490,t:1527616719520};\\\", \\\"{x:1296,y:483,t:1527616719538};\\\", \\\"{x:1296,y:482,t:1527616719554};\\\", \\\"{x:1295,y:481,t:1527616719570};\\\", \\\"{x:1298,y:481,t:1527616719712};\\\", \\\"{x:1301,y:481,t:1527616719720};\\\", \\\"{x:1311,y:484,t:1527616719738};\\\", \\\"{x:1315,y:488,t:1527616719755};\\\", \\\"{x:1320,y:490,t:1527616719770};\\\", \\\"{x:1322,y:491,t:1527616719787};\\\", \\\"{x:1323,y:492,t:1527616719805};\\\", \\\"{x:1323,y:493,t:1527616719824};\\\", \\\"{x:1324,y:493,t:1527616719837};\\\", \\\"{x:1324,y:494,t:1527616719855};\\\", \\\"{x:1325,y:495,t:1527616719870};\\\", \\\"{x:1325,y:496,t:1527616720087};\\\", \\\"{x:1325,y:497,t:1527616720104};\\\", \\\"{x:1323,y:498,t:1527616720120};\\\", \\\"{x:1322,y:498,t:1527616720136};\\\", \\\"{x:1321,y:499,t:1527616720153};\\\", \\\"{x:1319,y:499,t:1527616720375};\\\", \\\"{x:1316,y:499,t:1527616720404};\\\", \\\"{x:1315,y:499,t:1527616720438};\\\", \\\"{x:1314,y:485,t:1527616741378};\\\", \\\"{x:1305,y:461,t:1527616741384};\\\", \\\"{x:1298,y:450,t:1527616741401};\\\", \\\"{x:1292,y:447,t:1527616741418};\\\", \\\"{x:1289,y:447,t:1527616741434};\\\", \\\"{x:1280,y:452,t:1527616741451};\\\", \\\"{x:1259,y:479,t:1527616741468};\\\", \\\"{x:1235,y:513,t:1527616741484};\\\", \\\"{x:1212,y:547,t:1527616741501};\\\", \\\"{x:1191,y:576,t:1527616741518};\\\", \\\"{x:1170,y:611,t:1527616741534};\\\", \\\"{x:1153,y:650,t:1527616741551};\\\", \\\"{x:1143,y:681,t:1527616741568};\\\", \\\"{x:1136,y:706,t:1527616741584};\\\", \\\"{x:1131,y:727,t:1527616741601};\\\", \\\"{x:1126,y:747,t:1527616741618};\\\", \\\"{x:1126,y:759,t:1527616741635};\\\", \\\"{x:1126,y:773,t:1527616741652};\\\", \\\"{x:1134,y:794,t:1527616741669};\\\", \\\"{x:1149,y:821,t:1527616741684};\\\", \\\"{x:1161,y:841,t:1527616741701};\\\", \\\"{x:1175,y:860,t:1527616741718};\\\", \\\"{x:1179,y:870,t:1527616741735};\\\", \\\"{x:1186,y:880,t:1527616741751};\\\", \\\"{x:1193,y:887,t:1527616741768};\\\", \\\"{x:1199,y:893,t:1527616741785};\\\", \\\"{x:1205,y:901,t:1527616741801};\\\", \\\"{x:1211,y:906,t:1527616741818};\\\", \\\"{x:1217,y:912,t:1527616741835};\\\", \\\"{x:1223,y:917,t:1527616741851};\\\", \\\"{x:1231,y:922,t:1527616741868};\\\", \\\"{x:1244,y:929,t:1527616741885};\\\", \\\"{x:1259,y:934,t:1527616741902};\\\", \\\"{x:1272,y:939,t:1527616741918};\\\", \\\"{x:1290,y:944,t:1527616741935};\\\", \\\"{x:1294,y:946,t:1527616741952};\\\", \\\"{x:1301,y:948,t:1527616741968};\\\", \\\"{x:1308,y:951,t:1527616741985};\\\", \\\"{x:1314,y:951,t:1527616742001};\\\", \\\"{x:1317,y:951,t:1527616742018};\\\", \\\"{x:1318,y:951,t:1527616742035};\\\", \\\"{x:1320,y:952,t:1527616742051};\\\", \\\"{x:1321,y:952,t:1527616742068};\\\", \\\"{x:1325,y:952,t:1527616742085};\\\", \\\"{x:1330,y:953,t:1527616742102};\\\", \\\"{x:1334,y:954,t:1527616742119};\\\", \\\"{x:1339,y:956,t:1527616742134};\\\", \\\"{x:1342,y:957,t:1527616742152};\\\", \\\"{x:1346,y:958,t:1527616742168};\\\", \\\"{x:1348,y:958,t:1527616742191};\\\", \\\"{x:1349,y:959,t:1527616742207};\\\", \\\"{x:1349,y:960,t:1527616742218};\\\", \\\"{x:1350,y:961,t:1527616742236};\\\", \\\"{x:1351,y:961,t:1527616742255};\\\", \\\"{x:1352,y:962,t:1527616742303};\\\", \\\"{x:1352,y:963,t:1527616742318};\\\", \\\"{x:1352,y:964,t:1527616742336};\\\", \\\"{x:1353,y:967,t:1527616742353};\\\", \\\"{x:1353,y:970,t:1527616742369};\\\", \\\"{x:1353,y:972,t:1527616742386};\\\", \\\"{x:1355,y:975,t:1527616742402};\\\", \\\"{x:1355,y:977,t:1527616742418};\\\", \\\"{x:1355,y:979,t:1527616742435};\\\", \\\"{x:1356,y:979,t:1527616742453};\\\", \\\"{x:1356,y:980,t:1527616742496};\\\", \\\"{x:1356,y:981,t:1527616743072};\\\", \\\"{x:1356,y:983,t:1527616743086};\\\", \\\"{x:1354,y:983,t:1527616743103};\\\", \\\"{x:1353,y:984,t:1527616743119};\\\", \\\"{x:1351,y:984,t:1527616743136};\\\", \\\"{x:1350,y:984,t:1527616743152};\\\", \\\"{x:1348,y:984,t:1527616743169};\\\", \\\"{x:1346,y:984,t:1527616743187};\\\", \\\"{x:1342,y:984,t:1527616743203};\\\", \\\"{x:1339,y:984,t:1527616743219};\\\", \\\"{x:1334,y:983,t:1527616743237};\\\", \\\"{x:1332,y:982,t:1527616743252};\\\", \\\"{x:1329,y:981,t:1527616743270};\\\", \\\"{x:1324,y:979,t:1527616743287};\\\", \\\"{x:1322,y:979,t:1527616743303};\\\", \\\"{x:1320,y:978,t:1527616743320};\\\", \\\"{x:1317,y:977,t:1527616743336};\\\", \\\"{x:1315,y:976,t:1527616743352};\\\", \\\"{x:1312,y:974,t:1527616743370};\\\", \\\"{x:1306,y:972,t:1527616743387};\\\", \\\"{x:1300,y:971,t:1527616743403};\\\", \\\"{x:1285,y:966,t:1527616743420};\\\", \\\"{x:1267,y:961,t:1527616743437};\\\", \\\"{x:1246,y:955,t:1527616743453};\\\", \\\"{x:1228,y:950,t:1527616743470};\\\", \\\"{x:1211,y:945,t:1527616743487};\\\", \\\"{x:1199,y:941,t:1527616743504};\\\", \\\"{x:1195,y:940,t:1527616743519};\\\", \\\"{x:1192,y:938,t:1527616743537};\\\", \\\"{x:1188,y:936,t:1527616743554};\\\", \\\"{x:1186,y:935,t:1527616743569};\\\", \\\"{x:1185,y:934,t:1527616743591};\\\", \\\"{x:1184,y:933,t:1527616743603};\\\", \\\"{x:1183,y:933,t:1527616744111};\\\", \\\"{x:1185,y:933,t:1527616744159};\\\", \\\"{x:1186,y:934,t:1527616744183};\\\", \\\"{x:1188,y:934,t:1527616744207};\\\", \\\"{x:1189,y:935,t:1527616744263};\\\", \\\"{x:1190,y:935,t:1527616744279};\\\", \\\"{x:1191,y:935,t:1527616744303};\\\", \\\"{x:1193,y:937,t:1527616744320};\\\", \\\"{x:1194,y:937,t:1527616744336};\\\", \\\"{x:1195,y:937,t:1527616744354};\\\", \\\"{x:1197,y:938,t:1527616744370};\\\", \\\"{x:1198,y:938,t:1527616744387};\\\", \\\"{x:1199,y:939,t:1527616744404};\\\", \\\"{x:1200,y:939,t:1527616744420};\\\", \\\"{x:1200,y:940,t:1527616744438};\\\", \\\"{x:1201,y:940,t:1527616744453};\\\", \\\"{x:1203,y:941,t:1527616744471};\\\", \\\"{x:1206,y:943,t:1527616744487};\\\", \\\"{x:1208,y:944,t:1527616744511};\\\", \\\"{x:1210,y:946,t:1527616744527};\\\", \\\"{x:1211,y:947,t:1527616744537};\\\", \\\"{x:1212,y:948,t:1527616744553};\\\", \\\"{x:1217,y:950,t:1527616744571};\\\", \\\"{x:1221,y:950,t:1527616744587};\\\", \\\"{x:1226,y:951,t:1527616744604};\\\", \\\"{x:1230,y:951,t:1527616744621};\\\", \\\"{x:1235,y:951,t:1527616744637};\\\", \\\"{x:1241,y:951,t:1527616744654};\\\", \\\"{x:1248,y:951,t:1527616744671};\\\", \\\"{x:1262,y:951,t:1527616744688};\\\", \\\"{x:1276,y:951,t:1527616744704};\\\", \\\"{x:1284,y:951,t:1527616744721};\\\", \\\"{x:1292,y:951,t:1527616744737};\\\", \\\"{x:1297,y:950,t:1527616744754};\\\", \\\"{x:1300,y:950,t:1527616744771};\\\", \\\"{x:1302,y:950,t:1527616744792};\\\", \\\"{x:1304,y:950,t:1527616744804};\\\", \\\"{x:1311,y:950,t:1527616744821};\\\", \\\"{x:1315,y:950,t:1527616744837};\\\", \\\"{x:1322,y:950,t:1527616744854};\\\", \\\"{x:1329,y:950,t:1527616744870};\\\", \\\"{x:1346,y:951,t:1527616744888};\\\", \\\"{x:1355,y:952,t:1527616744905};\\\", \\\"{x:1362,y:953,t:1527616744921};\\\", \\\"{x:1363,y:954,t:1527616744938};\\\", \\\"{x:1364,y:955,t:1527616744954};\\\", \\\"{x:1366,y:955,t:1527616744975};\\\", \\\"{x:1366,y:956,t:1527616745000};\\\", \\\"{x:1367,y:957,t:1527616745008};\\\", \\\"{x:1367,y:958,t:1527616745020};\\\", \\\"{x:1367,y:960,t:1527616745037};\\\", \\\"{x:1368,y:963,t:1527616745055};\\\", \\\"{x:1368,y:964,t:1527616745070};\\\", \\\"{x:1368,y:965,t:1527616745096};\\\", \\\"{x:1367,y:965,t:1527616745127};\\\", \\\"{x:1366,y:965,t:1527616745137};\\\", \\\"{x:1364,y:966,t:1527616745154};\\\", \\\"{x:1363,y:966,t:1527616745183};\\\", \\\"{x:1362,y:966,t:1527616745192};\\\", \\\"{x:1359,y:966,t:1527616745204};\\\", \\\"{x:1355,y:966,t:1527616745221};\\\", \\\"{x:1348,y:958,t:1527616745237};\\\", \\\"{x:1340,y:952,t:1527616745255};\\\", \\\"{x:1337,y:947,t:1527616745271};\\\", \\\"{x:1333,y:941,t:1527616745287};\\\", \\\"{x:1333,y:935,t:1527616745305};\\\", \\\"{x:1331,y:932,t:1527616745322};\\\", \\\"{x:1331,y:927,t:1527616745337};\\\", \\\"{x:1331,y:922,t:1527616745354};\\\", \\\"{x:1331,y:917,t:1527616745372};\\\", \\\"{x:1331,y:912,t:1527616745388};\\\", \\\"{x:1331,y:909,t:1527616745404};\\\", \\\"{x:1331,y:908,t:1527616745422};\\\", \\\"{x:1331,y:906,t:1527616745438};\\\", \\\"{x:1331,y:902,t:1527616745455};\\\", \\\"{x:1330,y:898,t:1527616745472};\\\", \\\"{x:1330,y:897,t:1527616745567};\\\", \\\"{x:1328,y:897,t:1527616745582};\\\", \\\"{x:1327,y:895,t:1527616745591};\\\", \\\"{x:1326,y:895,t:1527616745604};\\\", \\\"{x:1322,y:893,t:1527616745621};\\\", \\\"{x:1319,y:892,t:1527616745639};\\\", \\\"{x:1317,y:891,t:1527616745654};\\\", \\\"{x:1310,y:890,t:1527616745671};\\\", \\\"{x:1300,y:890,t:1527616745687};\\\", \\\"{x:1292,y:890,t:1527616745705};\\\", \\\"{x:1288,y:882,t:1527616745895};\\\", \\\"{x:1288,y:867,t:1527616745904};\\\", \\\"{x:1288,y:852,t:1527616745921};\\\", \\\"{x:1290,y:846,t:1527616745938};\\\", \\\"{x:1290,y:843,t:1527616745954};\\\", \\\"{x:1291,y:840,t:1527616745972};\\\", \\\"{x:1293,y:832,t:1527616745988};\\\", \\\"{x:1297,y:824,t:1527616746004};\\\", \\\"{x:1301,y:815,t:1527616746022};\\\", \\\"{x:1305,y:809,t:1527616746038};\\\", \\\"{x:1306,y:803,t:1527616746055};\\\", \\\"{x:1307,y:800,t:1527616746071};\\\", \\\"{x:1309,y:796,t:1527616746088};\\\", \\\"{x:1310,y:791,t:1527616746105};\\\", \\\"{x:1314,y:787,t:1527616746121};\\\", \\\"{x:1317,y:783,t:1527616746139};\\\", \\\"{x:1321,y:777,t:1527616746155};\\\", \\\"{x:1322,y:776,t:1527616746171};\\\", \\\"{x:1323,y:776,t:1527616746247};\\\", \\\"{x:1327,y:776,t:1527616746255};\\\", \\\"{x:1335,y:786,t:1527616746271};\\\", \\\"{x:1342,y:794,t:1527616746288};\\\", \\\"{x:1347,y:802,t:1527616746305};\\\", \\\"{x:1353,y:809,t:1527616746321};\\\", \\\"{x:1356,y:813,t:1527616746338};\\\", \\\"{x:1357,y:817,t:1527616746355};\\\", \\\"{x:1357,y:823,t:1527616746371};\\\", \\\"{x:1359,y:828,t:1527616746388};\\\", \\\"{x:1359,y:832,t:1527616746405};\\\", \\\"{x:1359,y:836,t:1527616746421};\\\", \\\"{x:1359,y:839,t:1527616746438};\\\", \\\"{x:1359,y:846,t:1527616746455};\\\", \\\"{x:1358,y:852,t:1527616746471};\\\", \\\"{x:1355,y:858,t:1527616746488};\\\", \\\"{x:1354,y:864,t:1527616746505};\\\", \\\"{x:1353,y:869,t:1527616746521};\\\", \\\"{x:1351,y:874,t:1527616746539};\\\", \\\"{x:1350,y:876,t:1527616746556};\\\", \\\"{x:1350,y:877,t:1527616746575};\\\", \\\"{x:1350,y:879,t:1527616746591};\\\", \\\"{x:1350,y:880,t:1527616746607};\\\", \\\"{x:1350,y:882,t:1527616746623};\\\", \\\"{x:1350,y:883,t:1527616746655};\\\", \\\"{x:1350,y:885,t:1527616746904};\\\", \\\"{x:1350,y:886,t:1527616746912};\\\", \\\"{x:1350,y:887,t:1527616746923};\\\", \\\"{x:1352,y:889,t:1527616746938};\\\", \\\"{x:1352,y:891,t:1527616746956};\\\", \\\"{x:1354,y:893,t:1527616746973};\\\", \\\"{x:1354,y:895,t:1527616746989};\\\", \\\"{x:1355,y:895,t:1527616747005};\\\", \\\"{x:1355,y:896,t:1527616747031};\\\", \\\"{x:1357,y:900,t:1527616747038};\\\", \\\"{x:1363,y:908,t:1527616747055};\\\", \\\"{x:1369,y:918,t:1527616747072};\\\", \\\"{x:1375,y:930,t:1527616747089};\\\", \\\"{x:1383,y:940,t:1527616747105};\\\", \\\"{x:1387,y:944,t:1527616747122};\\\", \\\"{x:1388,y:947,t:1527616747140};\\\", \\\"{x:1391,y:950,t:1527616747156};\\\", \\\"{x:1393,y:954,t:1527616747172};\\\", \\\"{x:1397,y:958,t:1527616747190};\\\", \\\"{x:1400,y:962,t:1527616747205};\\\", \\\"{x:1403,y:966,t:1527616747223};\\\", \\\"{x:1406,y:969,t:1527616747239};\\\", \\\"{x:1409,y:972,t:1527616747255};\\\", \\\"{x:1411,y:975,t:1527616747272};\\\", \\\"{x:1413,y:978,t:1527616747290};\\\", \\\"{x:1416,y:980,t:1527616747305};\\\", \\\"{x:1417,y:980,t:1527616747799};\\\", \\\"{x:1416,y:980,t:1527616747815};\\\", \\\"{x:1409,y:977,t:1527616747823};\\\", \\\"{x:1392,y:972,t:1527616747839};\\\", \\\"{x:1371,y:966,t:1527616747856};\\\", \\\"{x:1351,y:961,t:1527616747874};\\\", \\\"{x:1336,y:955,t:1527616747889};\\\", \\\"{x:1328,y:954,t:1527616747907};\\\", \\\"{x:1326,y:952,t:1527616747923};\\\", \\\"{x:1323,y:950,t:1527616747940};\\\", \\\"{x:1320,y:946,t:1527616747956};\\\", \\\"{x:1310,y:937,t:1527616747973};\\\", \\\"{x:1292,y:922,t:1527616747990};\\\", \\\"{x:1274,y:910,t:1527616748006};\\\", \\\"{x:1244,y:892,t:1527616748022};\\\", \\\"{x:1227,y:882,t:1527616748039};\\\", \\\"{x:1214,y:875,t:1527616748056};\\\", \\\"{x:1206,y:868,t:1527616748074};\\\", \\\"{x:1199,y:863,t:1527616748089};\\\", \\\"{x:1190,y:856,t:1527616748107};\\\", \\\"{x:1180,y:848,t:1527616748124};\\\", \\\"{x:1165,y:837,t:1527616748139};\\\", \\\"{x:1150,y:828,t:1527616748157};\\\", \\\"{x:1135,y:823,t:1527616748174};\\\", \\\"{x:1126,y:820,t:1527616748190};\\\", \\\"{x:1122,y:817,t:1527616748206};\\\", \\\"{x:1114,y:809,t:1527616748224};\\\", \\\"{x:1111,y:803,t:1527616748239};\\\", \\\"{x:1109,y:798,t:1527616748256};\\\", \\\"{x:1107,y:792,t:1527616748273};\\\", \\\"{x:1105,y:786,t:1527616748289};\\\", \\\"{x:1105,y:777,t:1527616748307};\\\", \\\"{x:1104,y:772,t:1527616748323};\\\", \\\"{x:1103,y:767,t:1527616748340};\\\", \\\"{x:1101,y:760,t:1527616748357};\\\", \\\"{x:1099,y:745,t:1527616748373};\\\", \\\"{x:1099,y:719,t:1527616748390};\\\", \\\"{x:1099,y:708,t:1527616748406};\\\", \\\"{x:1099,y:689,t:1527616748423};\\\", \\\"{x:1099,y:672,t:1527616748440};\\\", \\\"{x:1099,y:658,t:1527616748457};\\\", \\\"{x:1099,y:649,t:1527616748473};\\\", \\\"{x:1098,y:633,t:1527616748491};\\\", \\\"{x:1094,y:619,t:1527616748507};\\\", \\\"{x:1089,y:606,t:1527616748523};\\\", \\\"{x:1086,y:593,t:1527616748541};\\\", \\\"{x:1085,y:585,t:1527616748557};\\\", \\\"{x:1084,y:581,t:1527616748573};\\\", \\\"{x:1084,y:578,t:1527616748590};\\\", \\\"{x:1084,y:577,t:1527616748607};\\\", \\\"{x:1084,y:576,t:1527616748623};\\\", \\\"{x:1086,y:576,t:1527616748887};\\\", \\\"{x:1095,y:576,t:1527616748895};\\\", \\\"{x:1106,y:576,t:1527616748908};\\\", \\\"{x:1128,y:576,t:1527616748924};\\\", \\\"{x:1151,y:576,t:1527616748941};\\\", \\\"{x:1177,y:579,t:1527616748957};\\\", \\\"{x:1196,y:581,t:1527616748975};\\\", \\\"{x:1214,y:581,t:1527616748991};\\\", \\\"{x:1233,y:581,t:1527616749007};\\\", \\\"{x:1246,y:581,t:1527616749024};\\\", \\\"{x:1258,y:581,t:1527616749041};\\\", \\\"{x:1268,y:581,t:1527616749058};\\\", \\\"{x:1281,y:581,t:1527616749074};\\\", \\\"{x:1294,y:581,t:1527616749091};\\\", \\\"{x:1308,y:581,t:1527616749108};\\\", \\\"{x:1327,y:581,t:1527616749123};\\\", \\\"{x:1350,y:581,t:1527616749140};\\\", \\\"{x:1376,y:581,t:1527616749158};\\\", \\\"{x:1390,y:581,t:1527616749173};\\\", \\\"{x:1396,y:581,t:1527616749190};\\\", \\\"{x:1398,y:581,t:1527616749208};\\\", \\\"{x:1399,y:581,t:1527616749223};\\\", \\\"{x:1401,y:581,t:1527616749255};\\\", \\\"{x:1402,y:581,t:1527616749263};\\\", \\\"{x:1403,y:581,t:1527616749275};\\\", \\\"{x:1406,y:581,t:1527616749291};\\\", \\\"{x:1409,y:580,t:1527616749308};\\\", \\\"{x:1410,y:580,t:1527616749960};\\\", \\\"{x:1412,y:580,t:1527616749976};\\\", \\\"{x:1414,y:580,t:1527616750000};\\\", \\\"{x:1415,y:580,t:1527616750081};\\\", \\\"{x:1417,y:580,t:1527616750104};\\\", \\\"{x:1418,y:580,t:1527616750144};\\\", \\\"{x:1420,y:580,t:1527616750216};\\\", \\\"{x:1420,y:583,t:1527616750568};\\\", \\\"{x:1420,y:587,t:1527616750576};\\\", \\\"{x:1420,y:595,t:1527616750592};\\\", \\\"{x:1419,y:604,t:1527616750609};\\\", \\\"{x:1419,y:611,t:1527616750625};\\\", \\\"{x:1417,y:617,t:1527616750642};\\\", \\\"{x:1417,y:623,t:1527616750660};\\\", \\\"{x:1416,y:626,t:1527616750676};\\\", \\\"{x:1415,y:631,t:1527616750691};\\\", \\\"{x:1415,y:635,t:1527616750708};\\\", \\\"{x:1415,y:640,t:1527616750725};\\\", \\\"{x:1415,y:645,t:1527616750741};\\\", \\\"{x:1415,y:651,t:1527616750758};\\\", \\\"{x:1415,y:664,t:1527616750775};\\\", \\\"{x:1415,y:675,t:1527616750792};\\\", \\\"{x:1415,y:681,t:1527616750809};\\\", \\\"{x:1415,y:687,t:1527616750826};\\\", \\\"{x:1415,y:696,t:1527616750842};\\\", \\\"{x:1415,y:704,t:1527616750859};\\\", \\\"{x:1416,y:714,t:1527616750876};\\\", \\\"{x:1417,y:724,t:1527616750892};\\\", \\\"{x:1418,y:732,t:1527616750909};\\\", \\\"{x:1418,y:741,t:1527616750926};\\\", \\\"{x:1418,y:752,t:1527616750941};\\\", \\\"{x:1418,y:758,t:1527616750959};\\\", \\\"{x:1418,y:767,t:1527616750975};\\\", \\\"{x:1417,y:777,t:1527616750992};\\\", \\\"{x:1416,y:787,t:1527616751009};\\\", \\\"{x:1416,y:794,t:1527616751026};\\\", \\\"{x:1415,y:803,t:1527616751043};\\\", \\\"{x:1413,y:809,t:1527616751058};\\\", \\\"{x:1412,y:817,t:1527616751075};\\\", \\\"{x:1410,y:825,t:1527616751092};\\\", \\\"{x:1409,y:832,t:1527616751108};\\\", \\\"{x:1409,y:838,t:1527616751125};\\\", \\\"{x:1408,y:852,t:1527616751142};\\\", \\\"{x:1408,y:857,t:1527616751159};\\\", \\\"{x:1408,y:863,t:1527616751175};\\\", \\\"{x:1408,y:869,t:1527616751192};\\\", \\\"{x:1407,y:873,t:1527616751209};\\\", \\\"{x:1406,y:878,t:1527616751226};\\\", \\\"{x:1406,y:884,t:1527616751243};\\\", \\\"{x:1406,y:889,t:1527616751258};\\\", \\\"{x:1406,y:895,t:1527616751276};\\\", \\\"{x:1406,y:899,t:1527616751293};\\\", \\\"{x:1406,y:902,t:1527616751309};\\\", \\\"{x:1406,y:908,t:1527616751325};\\\", \\\"{x:1408,y:915,t:1527616751343};\\\", \\\"{x:1409,y:929,t:1527616751360};\\\", \\\"{x:1410,y:938,t:1527616751376};\\\", \\\"{x:1410,y:944,t:1527616751393};\\\", \\\"{x:1410,y:949,t:1527616751409};\\\", \\\"{x:1410,y:950,t:1527616751426};\\\", \\\"{x:1412,y:953,t:1527616751443};\\\", \\\"{x:1412,y:954,t:1527616751460};\\\", \\\"{x:1413,y:955,t:1527616751475};\\\", \\\"{x:1415,y:959,t:1527616751493};\\\", \\\"{x:1415,y:961,t:1527616751509};\\\", \\\"{x:1416,y:963,t:1527616751526};\\\", \\\"{x:1416,y:965,t:1527616751543};\\\", \\\"{x:1416,y:966,t:1527616751560};\\\", \\\"{x:1416,y:967,t:1527616751576};\\\", \\\"{x:1416,y:969,t:1527616751592};\\\", \\\"{x:1416,y:971,t:1527616751638};\\\", \\\"{x:1416,y:972,t:1527616751655};\\\", \\\"{x:1415,y:973,t:1527616751662};\\\", \\\"{x:1415,y:974,t:1527616751678};\\\", \\\"{x:1414,y:974,t:1527616751992};\\\", \\\"{x:1413,y:974,t:1527616752023};\\\", \\\"{x:1412,y:974,t:1527616752063};\\\", \\\"{x:1412,y:972,t:1527616752076};\\\", \\\"{x:1412,y:971,t:1527616752093};\\\", \\\"{x:1412,y:969,t:1527616752110};\\\", \\\"{x:1412,y:966,t:1527616752127};\\\", \\\"{x:1412,y:965,t:1527616752143};\\\", \\\"{x:1412,y:964,t:1527616752224};\\\", \\\"{x:1412,y:963,t:1527616752263};\\\", \\\"{x:1412,y:962,t:1527616752280};\\\", \\\"{x:1412,y:961,t:1527616752311};\\\", \\\"{x:1412,y:960,t:1527616752343};\\\", \\\"{x:1413,y:959,t:1527616752359};\\\", \\\"{x:1413,y:957,t:1527616752377};\\\", \\\"{x:1413,y:956,t:1527616752399};\\\", \\\"{x:1414,y:954,t:1527616752422};\\\", \\\"{x:1414,y:952,t:1527616752438};\\\", \\\"{x:1415,y:950,t:1527616752447};\\\", \\\"{x:1415,y:949,t:1527616752459};\\\", \\\"{x:1416,y:947,t:1527616752477};\\\", \\\"{x:1416,y:946,t:1527616752493};\\\", \\\"{x:1417,y:944,t:1527616752509};\\\", \\\"{x:1417,y:943,t:1527616752527};\\\", \\\"{x:1418,y:939,t:1527616752544};\\\", \\\"{x:1419,y:937,t:1527616752559};\\\", \\\"{x:1420,y:932,t:1527616752577};\\\", \\\"{x:1420,y:930,t:1527616752594};\\\", \\\"{x:1420,y:926,t:1527616752609};\\\", \\\"{x:1420,y:925,t:1527616752631};\\\", \\\"{x:1420,y:924,t:1527616752643};\\\", \\\"{x:1420,y:923,t:1527616752660};\\\", \\\"{x:1420,y:921,t:1527616752676};\\\", \\\"{x:1420,y:919,t:1527616752693};\\\", \\\"{x:1420,y:913,t:1527616752711};\\\", \\\"{x:1420,y:905,t:1527616752727};\\\", \\\"{x:1420,y:895,t:1527616752743};\\\", \\\"{x:1420,y:886,t:1527616752761};\\\", \\\"{x:1420,y:879,t:1527616752777};\\\", \\\"{x:1420,y:870,t:1527616752794};\\\", \\\"{x:1420,y:857,t:1527616752811};\\\", \\\"{x:1420,y:843,t:1527616752827};\\\", \\\"{x:1420,y:828,t:1527616752844};\\\", \\\"{x:1420,y:810,t:1527616752861};\\\", \\\"{x:1420,y:790,t:1527616752877};\\\", \\\"{x:1420,y:768,t:1527616752893};\\\", \\\"{x:1421,y:749,t:1527616752911};\\\", \\\"{x:1423,y:740,t:1527616752927};\\\", \\\"{x:1423,y:733,t:1527616752944};\\\", \\\"{x:1423,y:728,t:1527616752960};\\\", \\\"{x:1423,y:726,t:1527616752977};\\\", \\\"{x:1423,y:724,t:1527616752993};\\\", \\\"{x:1423,y:722,t:1527616753010};\\\", \\\"{x:1423,y:721,t:1527616753031};\\\", \\\"{x:1423,y:719,t:1527616753432};\\\", \\\"{x:1423,y:710,t:1527616753444};\\\", \\\"{x:1423,y:698,t:1527616753461};\\\", \\\"{x:1423,y:687,t:1527616753478};\\\", \\\"{x:1424,y:678,t:1527616753494};\\\", \\\"{x:1424,y:669,t:1527616753511};\\\", \\\"{x:1424,y:665,t:1527616753527};\\\", \\\"{x:1424,y:659,t:1527616753543};\\\", \\\"{x:1424,y:652,t:1527616753561};\\\", \\\"{x:1424,y:645,t:1527616753578};\\\", \\\"{x:1424,y:638,t:1527616753593};\\\", \\\"{x:1424,y:635,t:1527616753610};\\\", \\\"{x:1425,y:631,t:1527616753627};\\\", \\\"{x:1426,y:628,t:1527616753645};\\\", \\\"{x:1426,y:624,t:1527616753660};\\\", \\\"{x:1426,y:620,t:1527616753678};\\\", \\\"{x:1426,y:613,t:1527616753694};\\\", \\\"{x:1428,y:606,t:1527616753710};\\\", \\\"{x:1429,y:592,t:1527616753727};\\\", \\\"{x:1429,y:584,t:1527616753745};\\\", \\\"{x:1429,y:577,t:1527616753761};\\\", \\\"{x:1429,y:571,t:1527616753777};\\\", \\\"{x:1429,y:566,t:1527616753795};\\\", \\\"{x:1429,y:561,t:1527616753810};\\\", \\\"{x:1428,y:556,t:1527616753828};\\\", \\\"{x:1427,y:549,t:1527616753845};\\\", \\\"{x:1426,y:547,t:1527616753861};\\\", \\\"{x:1425,y:547,t:1527616753878};\\\", \\\"{x:1425,y:546,t:1527616753912};\\\", \\\"{x:1423,y:546,t:1527616754103};\\\", \\\"{x:1417,y:550,t:1527616754110};\\\", \\\"{x:1408,y:557,t:1527616754128};\\\", \\\"{x:1404,y:561,t:1527616754145};\\\", \\\"{x:1403,y:562,t:1527616754161};\\\", \\\"{x:1403,y:564,t:1527616754544};\\\", \\\"{x:1404,y:564,t:1527616754551};\\\", \\\"{x:1405,y:565,t:1527616754567};\\\", \\\"{x:1407,y:566,t:1527616754579};\\\", \\\"{x:1408,y:566,t:1527616754596};\\\", \\\"{x:1411,y:567,t:1527616754612};\\\", \\\"{x:1412,y:567,t:1527616754655};\\\", \\\"{x:1414,y:568,t:1527616754664};\\\", \\\"{x:1416,y:568,t:1527616754695};\\\", \\\"{x:1417,y:568,t:1527616754775};\\\", \\\"{x:1417,y:567,t:1527616756599};\\\", \\\"{x:1416,y:565,t:1527616756613};\\\", \\\"{x:1416,y:564,t:1527616756629};\\\", \\\"{x:1415,y:563,t:1527616756647};\\\", \\\"{x:1414,y:562,t:1527616756671};\\\", \\\"{x:1413,y:561,t:1527616756696};\\\", \\\"{x:1410,y:562,t:1527616757456};\\\", \\\"{x:1404,y:568,t:1527616757464};\\\", \\\"{x:1383,y:583,t:1527616757481};\\\", \\\"{x:1360,y:595,t:1527616757497};\\\", \\\"{x:1334,y:608,t:1527616757514};\\\", \\\"{x:1312,y:618,t:1527616757531};\\\", \\\"{x:1293,y:626,t:1527616757548};\\\", \\\"{x:1280,y:633,t:1527616757564};\\\", \\\"{x:1266,y:640,t:1527616757581};\\\", \\\"{x:1255,y:648,t:1527616757598};\\\", \\\"{x:1246,y:655,t:1527616757613};\\\", \\\"{x:1223,y:669,t:1527616757631};\\\", \\\"{x:1208,y:678,t:1527616757648};\\\", \\\"{x:1196,y:686,t:1527616757664};\\\", \\\"{x:1184,y:696,t:1527616757681};\\\", \\\"{x:1175,y:705,t:1527616757697};\\\", \\\"{x:1165,y:715,t:1527616757714};\\\", \\\"{x:1157,y:727,t:1527616757731};\\\", \\\"{x:1145,y:742,t:1527616757748};\\\", \\\"{x:1133,y:759,t:1527616757764};\\\", \\\"{x:1122,y:774,t:1527616757780};\\\", \\\"{x:1115,y:781,t:1527616757798};\\\", \\\"{x:1110,y:785,t:1527616757815};\\\", \\\"{x:1110,y:787,t:1527616757831};\\\", \\\"{x:1113,y:787,t:1527616757935};\\\", \\\"{x:1121,y:784,t:1527616757948};\\\", \\\"{x:1146,y:779,t:1527616757964};\\\", \\\"{x:1180,y:774,t:1527616757981};\\\", \\\"{x:1219,y:768,t:1527616757998};\\\", \\\"{x:1274,y:762,t:1527616758015};\\\", \\\"{x:1298,y:759,t:1527616758030};\\\", \\\"{x:1319,y:756,t:1527616758048};\\\", \\\"{x:1329,y:756,t:1527616758065};\\\", \\\"{x:1337,y:755,t:1527616758080};\\\", \\\"{x:1341,y:755,t:1527616758098};\\\", \\\"{x:1344,y:755,t:1527616758114};\\\", \\\"{x:1347,y:753,t:1527616758131};\\\", \\\"{x:1349,y:753,t:1527616758148};\\\", \\\"{x:1350,y:753,t:1527616758165};\\\", \\\"{x:1351,y:753,t:1527616758180};\\\", \\\"{x:1355,y:753,t:1527616758198};\\\", \\\"{x:1362,y:753,t:1527616758215};\\\", \\\"{x:1363,y:753,t:1527616758230};\\\", \\\"{x:1365,y:753,t:1527616758248};\\\", \\\"{x:1368,y:754,t:1527616758265};\\\", \\\"{x:1369,y:754,t:1527616758280};\\\", \\\"{x:1370,y:754,t:1527616758298};\\\", \\\"{x:1371,y:754,t:1527616758314};\\\", \\\"{x:1375,y:755,t:1527616758331};\\\", \\\"{x:1378,y:757,t:1527616758348};\\\", \\\"{x:1382,y:758,t:1527616758365};\\\", \\\"{x:1383,y:759,t:1527616758381};\\\", \\\"{x:1384,y:759,t:1527616758398};\\\", \\\"{x:1385,y:759,t:1527616758431};\\\", \\\"{x:1386,y:759,t:1527616758455};\\\", \\\"{x:1387,y:759,t:1527616758470};\\\", \\\"{x:1387,y:760,t:1527616758495};\\\", \\\"{x:1386,y:760,t:1527616758847};\\\", \\\"{x:1385,y:760,t:1527616758865};\\\", \\\"{x:1384,y:760,t:1527616759047};\\\", \\\"{x:1383,y:761,t:1527616759063};\\\", \\\"{x:1381,y:761,t:1527616759103};\\\", \\\"{x:1381,y:762,t:1527616759114};\\\", \\\"{x:1380,y:762,t:1527616759135};\\\", \\\"{x:1379,y:762,t:1527616759151};\\\", \\\"{x:1378,y:762,t:1527616759165};\\\", \\\"{x:1378,y:764,t:1527616760199};\\\", \\\"{x:1378,y:770,t:1527616760216};\\\", \\\"{x:1378,y:777,t:1527616760233};\\\", \\\"{x:1378,y:780,t:1527616760250};\\\", \\\"{x:1378,y:784,t:1527616760266};\\\", \\\"{x:1378,y:786,t:1527616760283};\\\", \\\"{x:1378,y:788,t:1527616760300};\\\", \\\"{x:1378,y:790,t:1527616760319};\\\", \\\"{x:1379,y:792,t:1527616760333};\\\", \\\"{x:1379,y:794,t:1527616760350};\\\", \\\"{x:1379,y:798,t:1527616760365};\\\", \\\"{x:1379,y:804,t:1527616760383};\\\", \\\"{x:1382,y:808,t:1527616760400};\\\", \\\"{x:1382,y:812,t:1527616760416};\\\", \\\"{x:1386,y:822,t:1527616760433};\\\", \\\"{x:1388,y:836,t:1527616760450};\\\", \\\"{x:1389,y:848,t:1527616760466};\\\", \\\"{x:1390,y:859,t:1527616760483};\\\", \\\"{x:1391,y:871,t:1527616760500};\\\", \\\"{x:1391,y:878,t:1527616760516};\\\", \\\"{x:1392,y:885,t:1527616760533};\\\", \\\"{x:1395,y:897,t:1527616760550};\\\", \\\"{x:1395,y:914,t:1527616760567};\\\", \\\"{x:1395,y:924,t:1527616760583};\\\", \\\"{x:1395,y:929,t:1527616760600};\\\", \\\"{x:1397,y:933,t:1527616760617};\\\", \\\"{x:1397,y:937,t:1527616760632};\\\", \\\"{x:1399,y:940,t:1527616760650};\\\", \\\"{x:1399,y:942,t:1527616760670};\\\", \\\"{x:1399,y:943,t:1527616760694};\\\", \\\"{x:1399,y:945,t:1527616760703};\\\", \\\"{x:1399,y:947,t:1527616760719};\\\", \\\"{x:1398,y:948,t:1527616760733};\\\", \\\"{x:1398,y:949,t:1527616760750};\\\", \\\"{x:1397,y:950,t:1527616760766};\\\", \\\"{x:1397,y:952,t:1527616760783};\\\", \\\"{x:1396,y:952,t:1527616760800};\\\", \\\"{x:1395,y:953,t:1527616760817};\\\", \\\"{x:1395,y:955,t:1527616760833};\\\", \\\"{x:1393,y:956,t:1527616760850};\\\", \\\"{x:1392,y:958,t:1527616760867};\\\", \\\"{x:1390,y:960,t:1527616760883};\\\", \\\"{x:1388,y:961,t:1527616760900};\\\", \\\"{x:1388,y:962,t:1527616760917};\\\", \\\"{x:1387,y:962,t:1527616760935};\\\", \\\"{x:1386,y:963,t:1527616761000};\\\", \\\"{x:1385,y:964,t:1527616761017};\\\", \\\"{x:1385,y:965,t:1527616761034};\\\", \\\"{x:1384,y:965,t:1527616761050};\\\", \\\"{x:1384,y:966,t:1527616761079};\\\", \\\"{x:1383,y:968,t:1527616761111};\\\", \\\"{x:1382,y:968,t:1527616761127};\\\", \\\"{x:1382,y:969,t:1527616761176};\\\", \\\"{x:1381,y:969,t:1527616761238};\\\", \\\"{x:1380,y:969,t:1527616761991};\\\", \\\"{x:1380,y:968,t:1527616762030};\\\", \\\"{x:1380,y:967,t:1527616762038};\\\", \\\"{x:1379,y:967,t:1527616762051};\\\", \\\"{x:1378,y:966,t:1527616762068};\\\", \\\"{x:1378,y:965,t:1527616762084};\\\", \\\"{x:1378,y:964,t:1527616762111};\\\", \\\"{x:1378,y:963,t:1527616762119};\\\", \\\"{x:1378,y:962,t:1527616762135};\\\", \\\"{x:1378,y:961,t:1527616762151};\\\", \\\"{x:1378,y:960,t:1527616762167};\\\", \\\"{x:1377,y:958,t:1527616762184};\\\", \\\"{x:1377,y:956,t:1527616762201};\\\", \\\"{x:1377,y:955,t:1527616762218};\\\", \\\"{x:1377,y:952,t:1527616762234};\\\", \\\"{x:1377,y:949,t:1527616762251};\\\", \\\"{x:1377,y:946,t:1527616762268};\\\", \\\"{x:1377,y:942,t:1527616762284};\\\", \\\"{x:1376,y:934,t:1527616762301};\\\", \\\"{x:1376,y:929,t:1527616762318};\\\", \\\"{x:1376,y:924,t:1527616762334};\\\", \\\"{x:1376,y:919,t:1527616762351};\\\", \\\"{x:1376,y:913,t:1527616762368};\\\", \\\"{x:1376,y:908,t:1527616762384};\\\", \\\"{x:1376,y:901,t:1527616762401};\\\", \\\"{x:1376,y:891,t:1527616762418};\\\", \\\"{x:1376,y:884,t:1527616762435};\\\", \\\"{x:1376,y:878,t:1527616762451};\\\", \\\"{x:1376,y:872,t:1527616762467};\\\", \\\"{x:1376,y:863,t:1527616762485};\\\", \\\"{x:1376,y:855,t:1527616762501};\\\", \\\"{x:1376,y:846,t:1527616762518};\\\", \\\"{x:1376,y:837,t:1527616762535};\\\", \\\"{x:1376,y:834,t:1527616762551};\\\", \\\"{x:1376,y:830,t:1527616762568};\\\", \\\"{x:1376,y:824,t:1527616762585};\\\", \\\"{x:1376,y:820,t:1527616762602};\\\", \\\"{x:1376,y:815,t:1527616762617};\\\", \\\"{x:1376,y:809,t:1527616762635};\\\", \\\"{x:1376,y:805,t:1527616762651};\\\", \\\"{x:1376,y:801,t:1527616762668};\\\", \\\"{x:1376,y:797,t:1527616762685};\\\", \\\"{x:1376,y:794,t:1527616762700};\\\", \\\"{x:1376,y:786,t:1527616762718};\\\", \\\"{x:1376,y:780,t:1527616762734};\\\", \\\"{x:1376,y:775,t:1527616762752};\\\", \\\"{x:1376,y:771,t:1527616762768};\\\", \\\"{x:1376,y:766,t:1527616762785};\\\", \\\"{x:1376,y:762,t:1527616762801};\\\", \\\"{x:1376,y:761,t:1527616762818};\\\", \\\"{x:1376,y:759,t:1527616762835};\\\", \\\"{x:1376,y:757,t:1527616762852};\\\", \\\"{x:1376,y:755,t:1527616762868};\\\", \\\"{x:1376,y:754,t:1527616762885};\\\", \\\"{x:1376,y:759,t:1527616769016};\\\", \\\"{x:1376,y:765,t:1527616769024};\\\", \\\"{x:1367,y:783,t:1527616769040};\\\", \\\"{x:1361,y:795,t:1527616769057};\\\", \\\"{x:1357,y:802,t:1527616769074};\\\", \\\"{x:1355,y:807,t:1527616769090};\\\", \\\"{x:1353,y:812,t:1527616769107};\\\", \\\"{x:1352,y:816,t:1527616769124};\\\", \\\"{x:1351,y:821,t:1527616769141};\\\", \\\"{x:1349,y:829,t:1527616769157};\\\", \\\"{x:1348,y:842,t:1527616769173};\\\", \\\"{x:1348,y:850,t:1527616769190};\\\", \\\"{x:1348,y:857,t:1527616769206};\\\", \\\"{x:1348,y:858,t:1527616769224};\\\", \\\"{x:1348,y:861,t:1527616769241};\\\", \\\"{x:1350,y:865,t:1527616769256};\\\", \\\"{x:1352,y:872,t:1527616769274};\\\", \\\"{x:1354,y:876,t:1527616769291};\\\", \\\"{x:1355,y:883,t:1527616769307};\\\", \\\"{x:1357,y:887,t:1527616769324};\\\", \\\"{x:1358,y:888,t:1527616769340};\\\", \\\"{x:1360,y:892,t:1527616769357};\\\", \\\"{x:1362,y:894,t:1527616769373};\\\", \\\"{x:1364,y:896,t:1527616769391};\\\", \\\"{x:1365,y:897,t:1527616769407};\\\", \\\"{x:1366,y:894,t:1527616769455};\\\", \\\"{x:1367,y:891,t:1527616769463};\\\", \\\"{x:1370,y:886,t:1527616769474};\\\", \\\"{x:1377,y:873,t:1527616769491};\\\", \\\"{x:1384,y:860,t:1527616769508};\\\", \\\"{x:1389,y:850,t:1527616769524};\\\", \\\"{x:1392,y:842,t:1527616769540};\\\", \\\"{x:1393,y:834,t:1527616769557};\\\", \\\"{x:1393,y:829,t:1527616769573};\\\", \\\"{x:1393,y:819,t:1527616769592};\\\", \\\"{x:1393,y:814,t:1527616769607};\\\", \\\"{x:1393,y:807,t:1527616769624};\\\", \\\"{x:1393,y:801,t:1527616769640};\\\", \\\"{x:1393,y:798,t:1527616769657};\\\", \\\"{x:1393,y:794,t:1527616769674};\\\", \\\"{x:1393,y:791,t:1527616769690};\\\", \\\"{x:1393,y:788,t:1527616769708};\\\", \\\"{x:1392,y:786,t:1527616769724};\\\", \\\"{x:1392,y:785,t:1527616769740};\\\", \\\"{x:1391,y:782,t:1527616769757};\\\", \\\"{x:1390,y:779,t:1527616769773};\\\", \\\"{x:1389,y:776,t:1527616769791};\\\", \\\"{x:1388,y:775,t:1527616769807};\\\", \\\"{x:1388,y:773,t:1527616769824};\\\", \\\"{x:1388,y:772,t:1527616769840};\\\", \\\"{x:1388,y:770,t:1527616769858};\\\", \\\"{x:1386,y:768,t:1527616769874};\\\", \\\"{x:1386,y:767,t:1527616769903};\\\", \\\"{x:1385,y:765,t:1527616770760};\\\", \\\"{x:1383,y:762,t:1527616770776};\\\", \\\"{x:1382,y:760,t:1527616770791};\\\", \\\"{x:1381,y:759,t:1527616770808};\\\", \\\"{x:1381,y:758,t:1527616771080};\\\", \\\"{x:1379,y:759,t:1527616771096};\\\", \\\"{x:1379,y:760,t:1527616771109};\\\", \\\"{x:1378,y:765,t:1527616771124};\\\", \\\"{x:1378,y:766,t:1527616771142};\\\", \\\"{x:1378,y:769,t:1527616771160};\\\", \\\"{x:1377,y:772,t:1527616771175};\\\", \\\"{x:1377,y:776,t:1527616771192};\\\", \\\"{x:1377,y:780,t:1527616771209};\\\", \\\"{x:1377,y:784,t:1527616771225};\\\", \\\"{x:1377,y:790,t:1527616771241};\\\", \\\"{x:1377,y:793,t:1527616771258};\\\", \\\"{x:1377,y:798,t:1527616771276};\\\", \\\"{x:1379,y:803,t:1527616771291};\\\", \\\"{x:1380,y:810,t:1527616771308};\\\", \\\"{x:1384,y:819,t:1527616771326};\\\", \\\"{x:1387,y:828,t:1527616771342};\\\", \\\"{x:1390,y:837,t:1527616771359};\\\", \\\"{x:1393,y:844,t:1527616771374};\\\", \\\"{x:1397,y:851,t:1527616771391};\\\", \\\"{x:1399,y:859,t:1527616771409};\\\", \\\"{x:1403,y:872,t:1527616771425};\\\", \\\"{x:1404,y:879,t:1527616771442};\\\", \\\"{x:1404,y:888,t:1527616771459};\\\", \\\"{x:1404,y:896,t:1527616771476};\\\", \\\"{x:1404,y:902,t:1527616771492};\\\", \\\"{x:1405,y:912,t:1527616771509};\\\", \\\"{x:1407,y:919,t:1527616771526};\\\", \\\"{x:1408,y:925,t:1527616771542};\\\", \\\"{x:1409,y:931,t:1527616771559};\\\", \\\"{x:1409,y:934,t:1527616771575};\\\", \\\"{x:1409,y:937,t:1527616771591};\\\", \\\"{x:1409,y:942,t:1527616771609};\\\", \\\"{x:1409,y:945,t:1527616771625};\\\", \\\"{x:1409,y:949,t:1527616771642};\\\", \\\"{x:1409,y:952,t:1527616771659};\\\", \\\"{x:1409,y:957,t:1527616771676};\\\", \\\"{x:1409,y:961,t:1527616771692};\\\", \\\"{x:1407,y:965,t:1527616771708};\\\", \\\"{x:1404,y:969,t:1527616771725};\\\", \\\"{x:1399,y:974,t:1527616771743};\\\", \\\"{x:1396,y:974,t:1527616771758};\\\", \\\"{x:1394,y:975,t:1527616771776};\\\", \\\"{x:1392,y:976,t:1527616771799};\\\", \\\"{x:1391,y:976,t:1527616771839};\\\", \\\"{x:1390,y:976,t:1527616771846};\\\", \\\"{x:1389,y:976,t:1527616771858};\\\", \\\"{x:1385,y:976,t:1527616771875};\\\", \\\"{x:1383,y:976,t:1527616771892};\\\", \\\"{x:1380,y:976,t:1527616771908};\\\", \\\"{x:1378,y:976,t:1527616771926};\\\", \\\"{x:1377,y:976,t:1527616771967};\\\", \\\"{x:1377,y:974,t:1527616772343};\\\", \\\"{x:1376,y:972,t:1527616772359};\\\", \\\"{x:1375,y:970,t:1527616772376};\\\", \\\"{x:1374,y:967,t:1527616772393};\\\", \\\"{x:1373,y:967,t:1527616772409};\\\", \\\"{x:1372,y:965,t:1527616772426};\\\", \\\"{x:1372,y:964,t:1527616772443};\\\", \\\"{x:1371,y:962,t:1527616772459};\\\", \\\"{x:1370,y:961,t:1527616772476};\\\", \\\"{x:1368,y:958,t:1527616772493};\\\", \\\"{x:1366,y:955,t:1527616772510};\\\", \\\"{x:1366,y:954,t:1527616772526};\\\", \\\"{x:1363,y:947,t:1527616772542};\\\", \\\"{x:1359,y:939,t:1527616772560};\\\", \\\"{x:1353,y:927,t:1527616772576};\\\", \\\"{x:1347,y:915,t:1527616772592};\\\", \\\"{x:1338,y:904,t:1527616772610};\\\", \\\"{x:1323,y:886,t:1527616772626};\\\", \\\"{x:1306,y:869,t:1527616772643};\\\", \\\"{x:1283,y:852,t:1527616772660};\\\", \\\"{x:1261,y:840,t:1527616772676};\\\", \\\"{x:1237,y:830,t:1527616772693};\\\", \\\"{x:1211,y:818,t:1527616772710};\\\", \\\"{x:1160,y:791,t:1527616772727};\\\", \\\"{x:1113,y:773,t:1527616772743};\\\", \\\"{x:1043,y:747,t:1527616772759};\\\", \\\"{x:952,y:724,t:1527616772776};\\\", \\\"{x:862,y:705,t:1527616772793};\\\", \\\"{x:777,y:690,t:1527616772810};\\\", \\\"{x:714,y:675,t:1527616772826};\\\", \\\"{x:664,y:667,t:1527616772843};\\\", \\\"{x:639,y:665,t:1527616772859};\\\", \\\"{x:617,y:661,t:1527616772877};\\\", \\\"{x:602,y:659,t:1527616772893};\\\", \\\"{x:579,y:653,t:1527616772910};\\\", \\\"{x:556,y:642,t:1527616772927};\\\", \\\"{x:540,y:638,t:1527616772943};\\\", \\\"{x:522,y:632,t:1527616772961};\\\", \\\"{x:508,y:627,t:1527616772978};\\\", \\\"{x:502,y:625,t:1527616772994};\\\", \\\"{x:500,y:623,t:1527616773010};\\\", \\\"{x:498,y:622,t:1527616773027};\\\", \\\"{x:497,y:620,t:1527616773044};\\\", \\\"{x:497,y:619,t:1527616773060};\\\", \\\"{x:496,y:618,t:1527616773079};\\\", \\\"{x:495,y:617,t:1527616773093};\\\", \\\"{x:489,y:613,t:1527616773110};\\\", \\\"{x:483,y:609,t:1527616773127};\\\", \\\"{x:474,y:606,t:1527616773143};\\\", \\\"{x:461,y:603,t:1527616773160};\\\", \\\"{x:452,y:602,t:1527616773177};\\\", \\\"{x:448,y:600,t:1527616773193};\\\", \\\"{x:440,y:598,t:1527616773210};\\\", \\\"{x:435,y:598,t:1527616773227};\\\", \\\"{x:427,y:597,t:1527616773244};\\\", \\\"{x:423,y:596,t:1527616773261};\\\", \\\"{x:417,y:596,t:1527616773277};\\\", \\\"{x:406,y:594,t:1527616773293};\\\", \\\"{x:395,y:594,t:1527616773310};\\\", \\\"{x:391,y:594,t:1527616773327};\\\", \\\"{x:389,y:594,t:1527616773343};\\\", \\\"{x:388,y:592,t:1527616773431};\\\", \\\"{x:387,y:590,t:1527616773446};\\\", \\\"{x:387,y:588,t:1527616773463};\\\", \\\"{x:385,y:586,t:1527616773478};\\\", \\\"{x:384,y:583,t:1527616773494};\\\", \\\"{x:384,y:581,t:1527616773510};\\\", \\\"{x:383,y:580,t:1527616773550};\\\", \\\"{x:383,y:578,t:1527616773615};\\\", \\\"{x:388,y:586,t:1527616773839};\\\", \\\"{x:396,y:597,t:1527616773846};\\\", \\\"{x:404,y:607,t:1527616773861};\\\", \\\"{x:432,y:639,t:1527616773878};\\\", \\\"{x:485,y:718,t:1527616773895};\\\", \\\"{x:505,y:747,t:1527616773911};\\\", \\\"{x:516,y:765,t:1527616773928};\\\", \\\"{x:523,y:776,t:1527616773944};\\\", \\\"{x:525,y:781,t:1527616773961};\\\", \\\"{x:525,y:783,t:1527616773977};\\\", \\\"{x:525,y:782,t:1527616774118};\\\", \\\"{x:524,y:778,t:1527616774128};\\\", \\\"{x:524,y:770,t:1527616774144};\\\", \\\"{x:523,y:763,t:1527616774162};\\\", \\\"{x:521,y:758,t:1527616774178};\\\", \\\"{x:521,y:757,t:1527616774194};\\\", \\\"{x:519,y:754,t:1527616774328};\\\", \\\"{x:516,y:752,t:1527616774345};\\\", \\\"{x:515,y:749,t:1527616774362};\\\", \\\"{x:514,y:744,t:1527616774378};\\\", \\\"{x:512,y:742,t:1527616774395};\\\", \\\"{x:511,y:738,t:1527616774412};\\\", \\\"{x:511,y:736,t:1527616774428};\\\", \\\"{x:511,y:735,t:1527616774454};\\\", \\\"{x:513,y:735,t:1527616775160};\\\", \\\"{x:519,y:741,t:1527616775167};\\\", \\\"{x:525,y:747,t:1527616775179};\\\", \\\"{x:536,y:762,t:1527616775196};\\\", \\\"{x:546,y:779,t:1527616775212};\\\", \\\"{x:549,y:788,t:1527616775228};\\\", \\\"{x:550,y:788,t:1527616775935};\\\" ] }, { \\\"rt\\\": 8498, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 224339, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:549,y:788,t:1527616776135};\\\", \\\"{x:546,y:788,t:1527616776313};\\\", \\\"{x:544,y:788,t:1527616776329};\\\", \\\"{x:543,y:788,t:1527616776346};\\\", \\\"{x:541,y:789,t:1527616776363};\\\", \\\"{x:540,y:789,t:1527616776735};\\\", \\\"{x:535,y:791,t:1527616776751};\\\", \\\"{x:530,y:792,t:1527616776763};\\\", \\\"{x:520,y:796,t:1527616776780};\\\", \\\"{x:514,y:797,t:1527616776797};\\\", \\\"{x:513,y:797,t:1527616776814};\\\", \\\"{x:508,y:797,t:1527616776830};\\\", \\\"{x:502,y:797,t:1527616776846};\\\", \\\"{x:499,y:796,t:1527616776863};\\\", \\\"{x:494,y:793,t:1527616776879};\\\", \\\"{x:489,y:791,t:1527616776897};\\\", \\\"{x:486,y:788,t:1527616776914};\\\", \\\"{x:484,y:781,t:1527616776930};\\\", \\\"{x:482,y:774,t:1527616776947};\\\", \\\"{x:479,y:768,t:1527616776964};\\\", \\\"{x:479,y:767,t:1527616777007};\\\", \\\"{x:479,y:766,t:1527616777014};\\\", \\\"{x:479,y:764,t:1527616777030};\\\", \\\"{x:479,y:756,t:1527616777046};\\\", \\\"{x:480,y:747,t:1527616777065};\\\", \\\"{x:482,y:741,t:1527616777080};\\\", \\\"{x:485,y:735,t:1527616777096};\\\", \\\"{x:490,y:727,t:1527616777113};\\\", \\\"{x:498,y:717,t:1527616777130};\\\", \\\"{x:508,y:703,t:1527616777147};\\\", \\\"{x:518,y:692,t:1527616777164};\\\", \\\"{x:524,y:685,t:1527616777181};\\\", \\\"{x:527,y:681,t:1527616777197};\\\", \\\"{x:533,y:674,t:1527616777214};\\\", \\\"{x:542,y:664,t:1527616777231};\\\", \\\"{x:543,y:661,t:1527616777247};\\\", \\\"{x:544,y:661,t:1527616777279};\\\", \\\"{x:545,y:660,t:1527616777287};\\\", \\\"{x:546,y:659,t:1527616777296};\\\", \\\"{x:547,y:657,t:1527616777314};\\\", \\\"{x:547,y:656,t:1527616777351};\\\", \\\"{x:547,y:655,t:1527616777364};\\\", \\\"{x:548,y:653,t:1527616777380};\\\", \\\"{x:548,y:652,t:1527616777470};\\\", \\\"{x:547,y:652,t:1527616777480};\\\", \\\"{x:546,y:651,t:1527616777498};\\\", \\\"{x:545,y:651,t:1527616777656};\\\", \\\"{x:542,y:648,t:1527616777664};\\\", \\\"{x:536,y:638,t:1527616777681};\\\", \\\"{x:524,y:624,t:1527616777699};\\\", \\\"{x:512,y:611,t:1527616777714};\\\", \\\"{x:503,y:604,t:1527616777731};\\\", \\\"{x:497,y:598,t:1527616777748};\\\", \\\"{x:489,y:586,t:1527616777765};\\\", \\\"{x:486,y:582,t:1527616777781};\\\", \\\"{x:484,y:580,t:1527616777797};\\\", \\\"{x:477,y:573,t:1527616777816};\\\", \\\"{x:477,y:572,t:1527616777830};\\\", \\\"{x:477,y:571,t:1527616777863};\\\", \\\"{x:477,y:570,t:1527616777887};\\\", \\\"{x:477,y:569,t:1527616777911};\\\", \\\"{x:477,y:568,t:1527616777926};\\\", \\\"{x:477,y:565,t:1527616777934};\\\", \\\"{x:477,y:564,t:1527616777947};\\\", \\\"{x:477,y:562,t:1527616777966};\\\", \\\"{x:478,y:561,t:1527616777980};\\\", \\\"{x:478,y:560,t:1527616777998};\\\", \\\"{x:483,y:559,t:1527616778015};\\\", \\\"{x:502,y:557,t:1527616778032};\\\", \\\"{x:547,y:550,t:1527616778049};\\\", \\\"{x:592,y:544,t:1527616778065};\\\", \\\"{x:619,y:544,t:1527616778081};\\\", \\\"{x:640,y:544,t:1527616778098};\\\", \\\"{x:661,y:544,t:1527616778115};\\\", \\\"{x:686,y:544,t:1527616778131};\\\", \\\"{x:719,y:547,t:1527616778147};\\\", \\\"{x:759,y:554,t:1527616778166};\\\", \\\"{x:782,y:559,t:1527616778181};\\\", \\\"{x:792,y:564,t:1527616778198};\\\", \\\"{x:801,y:569,t:1527616778214};\\\", \\\"{x:815,y:579,t:1527616778230};\\\", \\\"{x:836,y:591,t:1527616778248};\\\", \\\"{x:862,y:604,t:1527616778265};\\\", \\\"{x:888,y:618,t:1527616778281};\\\", \\\"{x:924,y:642,t:1527616778298};\\\", \\\"{x:964,y:671,t:1527616778315};\\\", \\\"{x:1008,y:699,t:1527616778330};\\\", \\\"{x:1068,y:735,t:1527616778347};\\\", \\\"{x:1118,y:764,t:1527616778364};\\\", \\\"{x:1154,y:789,t:1527616778381};\\\", \\\"{x:1172,y:800,t:1527616778398};\\\", \\\"{x:1190,y:813,t:1527616778414};\\\", \\\"{x:1194,y:815,t:1527616778431};\\\", \\\"{x:1196,y:816,t:1527616778448};\\\", \\\"{x:1196,y:817,t:1527616778648};\\\", \\\"{x:1194,y:822,t:1527616778666};\\\", \\\"{x:1190,y:831,t:1527616778682};\\\", \\\"{x:1188,y:834,t:1527616778698};\\\", \\\"{x:1186,y:838,t:1527616778716};\\\", \\\"{x:1186,y:839,t:1527616778732};\\\", \\\"{x:1186,y:840,t:1527616778847};\\\", \\\"{x:1185,y:841,t:1527616778854};\\\", \\\"{x:1182,y:845,t:1527616778864};\\\", \\\"{x:1176,y:860,t:1527616778882};\\\", \\\"{x:1164,y:884,t:1527616778897};\\\", \\\"{x:1149,y:920,t:1527616778914};\\\", \\\"{x:1136,y:953,t:1527616778932};\\\", \\\"{x:1124,y:980,t:1527616778947};\\\", \\\"{x:1117,y:992,t:1527616778964};\\\", \\\"{x:1115,y:996,t:1527616778982};\\\", \\\"{x:1114,y:998,t:1527616778997};\\\", \\\"{x:1114,y:999,t:1527616779021};\\\", \\\"{x:1114,y:998,t:1527616779126};\\\", \\\"{x:1114,y:991,t:1527616779135};\\\", \\\"{x:1114,y:983,t:1527616779148};\\\", \\\"{x:1114,y:965,t:1527616779165};\\\", \\\"{x:1114,y:947,t:1527616779182};\\\", \\\"{x:1116,y:927,t:1527616779198};\\\", \\\"{x:1120,y:896,t:1527616779215};\\\", \\\"{x:1120,y:872,t:1527616779232};\\\", \\\"{x:1122,y:847,t:1527616779248};\\\", \\\"{x:1122,y:821,t:1527616779265};\\\", \\\"{x:1125,y:798,t:1527616779281};\\\", \\\"{x:1128,y:782,t:1527616779298};\\\", \\\"{x:1128,y:746,t:1527616779315};\\\", \\\"{x:1127,y:705,t:1527616779332};\\\", \\\"{x:1121,y:684,t:1527616779348};\\\", \\\"{x:1119,y:674,t:1527616779365};\\\", \\\"{x:1117,y:671,t:1527616779381};\\\", \\\"{x:1117,y:668,t:1527616779398};\\\", \\\"{x:1116,y:667,t:1527616779415};\\\", \\\"{x:1114,y:664,t:1527616779447};\\\", \\\"{x:1112,y:659,t:1527616779455};\\\", \\\"{x:1110,y:658,t:1527616779465};\\\", \\\"{x:1110,y:655,t:1527616779511};\\\", \\\"{x:1109,y:655,t:1527616779519};\\\", \\\"{x:1108,y:654,t:1527616779532};\\\", \\\"{x:1107,y:654,t:1527616779548};\\\", \\\"{x:1106,y:654,t:1527616779792};\\\", \\\"{x:1104,y:654,t:1527616779799};\\\", \\\"{x:1095,y:662,t:1527616779815};\\\", \\\"{x:1092,y:668,t:1527616779823};\\\", \\\"{x:1092,y:668,t:1527616779838};\\\", \\\"{x:709,y:789,t:1527616781003};\\\", \\\"{x:709,y:789,t:1527616781089};\\\", \\\"{x:706,y:789,t:1527616781151};\\\", \\\"{x:702,y:787,t:1527616781165};\\\", \\\"{x:700,y:785,t:1527616781183};\\\", \\\"{x:699,y:785,t:1527616781198};\\\", \\\"{x:681,y:777,t:1527616781215};\\\", \\\"{x:647,y:754,t:1527616781233};\\\", \\\"{x:606,y:732,t:1527616781248};\\\", \\\"{x:571,y:710,t:1527616781265};\\\", \\\"{x:541,y:679,t:1527616781283};\\\", \\\"{x:496,y:620,t:1527616781300};\\\", \\\"{x:453,y:559,t:1527616781316};\\\", \\\"{x:405,y:503,t:1527616781332};\\\", \\\"{x:339,y:436,t:1527616781351};\\\", \\\"{x:298,y:399,t:1527616781367};\\\", \\\"{x:265,y:367,t:1527616781383};\\\", \\\"{x:238,y:334,t:1527616781401};\\\", \\\"{x:225,y:319,t:1527616781417};\\\", \\\"{x:219,y:307,t:1527616781434};\\\", \\\"{x:216,y:297,t:1527616781450};\\\", \\\"{x:215,y:292,t:1527616781467};\\\", \\\"{x:215,y:287,t:1527616781483};\\\", \\\"{x:215,y:286,t:1527616781501};\\\", \\\"{x:215,y:285,t:1527616781526};\\\", \\\"{x:217,y:294,t:1527616781566};\\\", \\\"{x:226,y:308,t:1527616781574};\\\", \\\"{x:235,y:321,t:1527616781584};\\\", \\\"{x:254,y:347,t:1527616781601};\\\", \\\"{x:272,y:372,t:1527616781617};\\\", \\\"{x:289,y:398,t:1527616781634};\\\", \\\"{x:298,y:415,t:1527616781651};\\\", \\\"{x:306,y:433,t:1527616781666};\\\", \\\"{x:315,y:453,t:1527616781684};\\\", \\\"{x:323,y:473,t:1527616781701};\\\", \\\"{x:329,y:486,t:1527616781717};\\\", \\\"{x:332,y:492,t:1527616781734};\\\", \\\"{x:333,y:494,t:1527616781751};\\\", \\\"{x:334,y:495,t:1527616781767};\\\", \\\"{x:335,y:495,t:1527616781784};\\\", \\\"{x:336,y:497,t:1527616781801};\\\", \\\"{x:341,y:498,t:1527616781818};\\\", \\\"{x:350,y:503,t:1527616781834};\\\", \\\"{x:366,y:509,t:1527616781850};\\\", \\\"{x:385,y:517,t:1527616781868};\\\", \\\"{x:401,y:523,t:1527616781884};\\\", \\\"{x:417,y:530,t:1527616781901};\\\", \\\"{x:431,y:535,t:1527616781918};\\\", \\\"{x:441,y:538,t:1527616781934};\\\", \\\"{x:449,y:539,t:1527616781950};\\\", \\\"{x:450,y:539,t:1527616781968};\\\", \\\"{x:452,y:539,t:1527616781991};\\\", \\\"{x:454,y:539,t:1527616782006};\\\", \\\"{x:460,y:537,t:1527616782018};\\\", \\\"{x:475,y:534,t:1527616782034};\\\", \\\"{x:495,y:527,t:1527616782051};\\\", \\\"{x:523,y:519,t:1527616782068};\\\", \\\"{x:558,y:512,t:1527616782085};\\\", \\\"{x:581,y:509,t:1527616782101};\\\", \\\"{x:595,y:508,t:1527616782117};\\\", \\\"{x:599,y:507,t:1527616782133};\\\", \\\"{x:601,y:507,t:1527616782151};\\\", \\\"{x:602,y:507,t:1527616782175};\\\", \\\"{x:603,y:507,t:1527616782206};\\\", \\\"{x:605,y:507,t:1527616782254};\\\", \\\"{x:606,y:507,t:1527616782267};\\\", \\\"{x:607,y:507,t:1527616782284};\\\", \\\"{x:609,y:508,t:1527616782300};\\\", \\\"{x:611,y:509,t:1527616782317};\\\", \\\"{x:612,y:513,t:1527616782790};\\\", \\\"{x:611,y:518,t:1527616782802};\\\", \\\"{x:606,y:528,t:1527616782818};\\\", \\\"{x:602,y:535,t:1527616782835};\\\", \\\"{x:598,y:542,t:1527616782851};\\\", \\\"{x:596,y:546,t:1527616782868};\\\", \\\"{x:596,y:547,t:1527616782884};\\\", \\\"{x:595,y:548,t:1527616782902};\\\", \\\"{x:595,y:550,t:1527616782917};\\\", \\\"{x:595,y:552,t:1527616782935};\\\", \\\"{x:596,y:554,t:1527616782951};\\\", \\\"{x:598,y:558,t:1527616782968};\\\", \\\"{x:602,y:563,t:1527616782986};\\\", \\\"{x:606,y:566,t:1527616783002};\\\", \\\"{x:608,y:569,t:1527616783018};\\\", \\\"{x:612,y:570,t:1527616783035};\\\", \\\"{x:618,y:570,t:1527616783052};\\\", \\\"{x:633,y:570,t:1527616783069};\\\", \\\"{x:653,y:570,t:1527616783086};\\\", \\\"{x:674,y:567,t:1527616783102};\\\", \\\"{x:689,y:563,t:1527616783118};\\\", \\\"{x:698,y:560,t:1527616783135};\\\", \\\"{x:705,y:558,t:1527616783151};\\\", \\\"{x:710,y:556,t:1527616783168};\\\", \\\"{x:717,y:554,t:1527616783186};\\\", \\\"{x:732,y:551,t:1527616783203};\\\", \\\"{x:753,y:544,t:1527616783218};\\\", \\\"{x:775,y:538,t:1527616783235};\\\", \\\"{x:790,y:537,t:1527616783252};\\\", \\\"{x:802,y:536,t:1527616783269};\\\", \\\"{x:809,y:533,t:1527616783284};\\\", \\\"{x:811,y:533,t:1527616783302};\\\", \\\"{x:817,y:533,t:1527616783318};\\\", \\\"{x:821,y:532,t:1527616783335};\\\", \\\"{x:822,y:532,t:1527616783352};\\\", \\\"{x:824,y:532,t:1527616783370};\\\", \\\"{x:825,y:532,t:1527616783385};\\\", \\\"{x:827,y:533,t:1527616783402};\\\", \\\"{x:830,y:535,t:1527616783419};\\\", \\\"{x:831,y:539,t:1527616783436};\\\", \\\"{x:832,y:541,t:1527616783451};\\\", \\\"{x:833,y:544,t:1527616783469};\\\", \\\"{x:834,y:545,t:1527616783495};\\\", \\\"{x:835,y:545,t:1527616783534};\\\", \\\"{x:837,y:545,t:1527616783559};\\\", \\\"{x:838,y:545,t:1527616783582};\\\", \\\"{x:838,y:544,t:1527616783591};\\\", \\\"{x:839,y:544,t:1527616783603};\\\", \\\"{x:839,y:543,t:1527616783623};\\\", \\\"{x:839,y:542,t:1527616783636};\\\", \\\"{x:839,y:541,t:1527616783870};\\\", \\\"{x:835,y:543,t:1527616783886};\\\", \\\"{x:813,y:560,t:1527616783902};\\\", \\\"{x:714,y:607,t:1527616783919};\\\", \\\"{x:642,y:638,t:1527616783936};\\\", \\\"{x:546,y:676,t:1527616783953};\\\", \\\"{x:484,y:697,t:1527616783968};\\\", \\\"{x:447,y:711,t:1527616783986};\\\", \\\"{x:426,y:719,t:1527616784002};\\\", \\\"{x:407,y:726,t:1527616784019};\\\", \\\"{x:394,y:732,t:1527616784036};\\\", \\\"{x:391,y:734,t:1527616784053};\\\", \\\"{x:385,y:742,t:1527616784069};\\\", \\\"{x:378,y:748,t:1527616784086};\\\", \\\"{x:370,y:757,t:1527616784102};\\\", \\\"{x:368,y:758,t:1527616784119};\\\", \\\"{x:369,y:758,t:1527616784175};\\\", \\\"{x:376,y:752,t:1527616784185};\\\", \\\"{x:389,y:749,t:1527616784203};\\\", \\\"{x:411,y:746,t:1527616784219};\\\", \\\"{x:429,y:745,t:1527616784236};\\\", \\\"{x:447,y:745,t:1527616784253};\\\", \\\"{x:453,y:745,t:1527616784268};\\\", \\\"{x:457,y:745,t:1527616784286};\\\", \\\"{x:460,y:745,t:1527616784303};\\\", \\\"{x:464,y:745,t:1527616784320};\\\", \\\"{x:467,y:745,t:1527616784336};\\\", \\\"{x:468,y:745,t:1527616784353};\\\", \\\"{x:471,y:745,t:1527616784370};\\\", \\\"{x:473,y:744,t:1527616784387};\\\", \\\"{x:475,y:742,t:1527616784403};\\\", \\\"{x:483,y:738,t:1527616784420};\\\", \\\"{x:489,y:733,t:1527616784457};\\\", \\\"{x:489,y:732,t:1527616784478};\\\", \\\"{x:490,y:732,t:1527616785110};\\\", \\\"{x:490,y:731,t:1527616785134};\\\", \\\"{x:491,y:731,t:1527616785142};\\\", \\\"{x:492,y:729,t:1527616785154};\\\", \\\"{x:492,y:727,t:1527616785169};\\\", \\\"{x:492,y:726,t:1527616785187};\\\", \\\"{x:493,y:725,t:1527616785202};\\\", \\\"{x:493,y:723,t:1527616785220};\\\", \\\"{x:494,y:720,t:1527616785237};\\\", \\\"{x:495,y:718,t:1527616785254};\\\", \\\"{x:496,y:713,t:1527616785270};\\\", \\\"{x:496,y:708,t:1527616785286};\\\", \\\"{x:497,y:705,t:1527616785303};\\\", \\\"{x:500,y:700,t:1527616785320};\\\", \\\"{x:500,y:696,t:1527616785337};\\\", \\\"{x:503,y:690,t:1527616785354};\\\", \\\"{x:503,y:686,t:1527616785370};\\\", \\\"{x:507,y:674,t:1527616785387};\\\", \\\"{x:510,y:662,t:1527616785404};\\\", \\\"{x:514,y:649,t:1527616785420};\\\", \\\"{x:519,y:638,t:1527616785438};\\\", \\\"{x:522,y:627,t:1527616785454};\\\", \\\"{x:523,y:623,t:1527616785470};\\\", \\\"{x:525,y:618,t:1527616785487};\\\", \\\"{x:528,y:614,t:1527616785505};\\\", \\\"{x:531,y:608,t:1527616785520};\\\", \\\"{x:532,y:606,t:1527616785537};\\\", \\\"{x:534,y:604,t:1527616785554};\\\", \\\"{x:535,y:602,t:1527616785570};\\\", \\\"{x:537,y:600,t:1527616785588};\\\", \\\"{x:537,y:599,t:1527616785605};\\\", \\\"{x:538,y:596,t:1527616785620};\\\", \\\"{x:540,y:594,t:1527616785637};\\\", \\\"{x:542,y:592,t:1527616785697};\\\", \\\"{x:542,y:591,t:1527616785725};\\\" ] }, { \\\"rt\\\": 19191, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 244808, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5-C -H -H -Z -Z -B -B -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:588,t:1527616786670};\\\", \\\"{x:530,y:583,t:1527616786682};\\\", \\\"{x:523,y:576,t:1527616786690};\\\", \\\"{x:502,y:564,t:1527616786707};\\\", \\\"{x:481,y:550,t:1527616786724};\\\", \\\"{x:465,y:542,t:1527616786740};\\\", \\\"{x:452,y:533,t:1527616786755};\\\", \\\"{x:441,y:524,t:1527616786771};\\\", \\\"{x:435,y:519,t:1527616786788};\\\", \\\"{x:428,y:514,t:1527616786806};\\\", \\\"{x:418,y:508,t:1527616786821};\\\", \\\"{x:409,y:504,t:1527616786838};\\\", \\\"{x:401,y:500,t:1527616786855};\\\", \\\"{x:393,y:496,t:1527616786871};\\\", \\\"{x:384,y:492,t:1527616786888};\\\", \\\"{x:373,y:488,t:1527616786906};\\\", \\\"{x:365,y:486,t:1527616786922};\\\", \\\"{x:355,y:483,t:1527616786938};\\\", \\\"{x:351,y:483,t:1527616786955};\\\", \\\"{x:345,y:481,t:1527616786971};\\\", \\\"{x:342,y:481,t:1527616786988};\\\", \\\"{x:339,y:481,t:1527616787005};\\\", \\\"{x:335,y:480,t:1527616787022};\\\", \\\"{x:333,y:479,t:1527616787038};\\\", \\\"{x:328,y:479,t:1527616787055};\\\", \\\"{x:323,y:478,t:1527616787071};\\\", \\\"{x:320,y:478,t:1527616787088};\\\", \\\"{x:318,y:478,t:1527616787105};\\\", \\\"{x:317,y:478,t:1527616787143};\\\", \\\"{x:319,y:478,t:1527616787408};\\\", \\\"{x:324,y:478,t:1527616787423};\\\", \\\"{x:344,y:478,t:1527616787439};\\\", \\\"{x:362,y:475,t:1527616787456};\\\", \\\"{x:373,y:475,t:1527616787472};\\\", \\\"{x:379,y:474,t:1527616787490};\\\", \\\"{x:382,y:474,t:1527616787506};\\\", \\\"{x:385,y:473,t:1527616787522};\\\", \\\"{x:387,y:473,t:1527616787539};\\\", \\\"{x:388,y:473,t:1527616787556};\\\", \\\"{x:390,y:472,t:1527616787573};\\\", \\\"{x:392,y:472,t:1527616787591};\\\", \\\"{x:394,y:471,t:1527616787605};\\\", \\\"{x:397,y:471,t:1527616787623};\\\", \\\"{x:398,y:470,t:1527616787639};\\\", \\\"{x:399,y:470,t:1527616787687};\\\", \\\"{x:401,y:470,t:1527616787743};\\\", \\\"{x:401,y:469,t:1527616787904};\\\", \\\"{x:401,y:468,t:1527616787910};\\\", \\\"{x:401,y:467,t:1527616787974};\\\", \\\"{x:402,y:467,t:1527616787989};\\\", \\\"{x:403,y:466,t:1527616788006};\\\", \\\"{x:404,y:466,t:1527616788022};\\\", \\\"{x:406,y:466,t:1527616788127};\\\", \\\"{x:408,y:466,t:1527616788139};\\\", \\\"{x:421,y:465,t:1527616788156};\\\", \\\"{x:428,y:465,t:1527616788173};\\\", \\\"{x:434,y:465,t:1527616788189};\\\", \\\"{x:437,y:465,t:1527616788207};\\\", \\\"{x:439,y:465,t:1527616788224};\\\", \\\"{x:440,y:465,t:1527616788239};\\\", \\\"{x:445,y:465,t:1527616788256};\\\", \\\"{x:450,y:465,t:1527616788273};\\\", \\\"{x:456,y:465,t:1527616788290};\\\", \\\"{x:462,y:465,t:1527616788306};\\\", \\\"{x:466,y:465,t:1527616788323};\\\", \\\"{x:471,y:464,t:1527616788339};\\\", \\\"{x:476,y:464,t:1527616788356};\\\", \\\"{x:483,y:464,t:1527616788373};\\\", \\\"{x:491,y:464,t:1527616788389};\\\", \\\"{x:505,y:464,t:1527616788407};\\\", \\\"{x:515,y:464,t:1527616788422};\\\", \\\"{x:525,y:464,t:1527616788439};\\\", \\\"{x:533,y:464,t:1527616788457};\\\", \\\"{x:540,y:464,t:1527616788473};\\\", \\\"{x:547,y:464,t:1527616788489};\\\", \\\"{x:548,y:464,t:1527616788506};\\\", \\\"{x:550,y:464,t:1527616788567};\\\", \\\"{x:551,y:464,t:1527616788591};\\\", \\\"{x:555,y:464,t:1527616788607};\\\", \\\"{x:560,y:464,t:1527616788623};\\\", \\\"{x:565,y:464,t:1527616788641};\\\", \\\"{x:573,y:464,t:1527616788657};\\\", \\\"{x:582,y:464,t:1527616788673};\\\", \\\"{x:592,y:464,t:1527616788690};\\\", \\\"{x:599,y:464,t:1527616788706};\\\", \\\"{x:607,y:464,t:1527616788723};\\\", \\\"{x:614,y:464,t:1527616788740};\\\", \\\"{x:624,y:464,t:1527616788756};\\\", \\\"{x:635,y:464,t:1527616788773};\\\", \\\"{x:651,y:464,t:1527616788790};\\\", \\\"{x:659,y:464,t:1527616788806};\\\", \\\"{x:662,y:464,t:1527616788823};\\\", \\\"{x:663,y:464,t:1527616788841};\\\", \\\"{x:664,y:464,t:1527616788856};\\\", \\\"{x:665,y:464,t:1527616788873};\\\", \\\"{x:666,y:464,t:1527616788890};\\\", \\\"{x:667,y:464,t:1527616788911};\\\", \\\"{x:668,y:464,t:1527616788924};\\\", \\\"{x:669,y:464,t:1527616788940};\\\", \\\"{x:676,y:467,t:1527616789374};\\\", \\\"{x:700,y:485,t:1527616789390};\\\", \\\"{x:725,y:503,t:1527616789408};\\\", \\\"{x:750,y:518,t:1527616789424};\\\", \\\"{x:776,y:533,t:1527616789440};\\\", \\\"{x:866,y:587,t:1527616789474};\\\", \\\"{x:908,y:614,t:1527616789491};\\\", \\\"{x:931,y:629,t:1527616789507};\\\", \\\"{x:951,y:645,t:1527616789524};\\\", \\\"{x:969,y:661,t:1527616789540};\\\", \\\"{x:982,y:676,t:1527616789557};\\\", \\\"{x:1001,y:699,t:1527616789574};\\\", \\\"{x:1015,y:716,t:1527616789590};\\\", \\\"{x:1026,y:733,t:1527616789607};\\\", \\\"{x:1036,y:755,t:1527616789624};\\\", \\\"{x:1041,y:773,t:1527616789641};\\\", \\\"{x:1045,y:787,t:1527616789657};\\\", \\\"{x:1054,y:801,t:1527616789674};\\\", \\\"{x:1064,y:820,t:1527616789690};\\\", \\\"{x:1072,y:833,t:1527616789707};\\\", \\\"{x:1077,y:843,t:1527616789724};\\\", \\\"{x:1082,y:853,t:1527616789741};\\\", \\\"{x:1084,y:860,t:1527616789758};\\\", \\\"{x:1086,y:864,t:1527616789775};\\\", \\\"{x:1087,y:867,t:1527616789791};\\\", \\\"{x:1089,y:870,t:1527616789807};\\\", \\\"{x:1091,y:876,t:1527616789824};\\\", \\\"{x:1095,y:886,t:1527616789841};\\\", \\\"{x:1096,y:895,t:1527616789858};\\\", \\\"{x:1098,y:899,t:1527616789875};\\\", \\\"{x:1099,y:902,t:1527616789891};\\\", \\\"{x:1099,y:903,t:1527616789907};\\\", \\\"{x:1099,y:905,t:1527616789924};\\\", \\\"{x:1099,y:909,t:1527616789941};\\\", \\\"{x:1099,y:912,t:1527616789957};\\\", \\\"{x:1099,y:917,t:1527616789974};\\\", \\\"{x:1099,y:921,t:1527616789990};\\\", \\\"{x:1099,y:926,t:1527616790007};\\\", \\\"{x:1099,y:928,t:1527616790024};\\\", \\\"{x:1099,y:930,t:1527616790042};\\\", \\\"{x:1098,y:934,t:1527616790058};\\\", \\\"{x:1098,y:936,t:1527616790075};\\\", \\\"{x:1096,y:938,t:1527616790091};\\\", \\\"{x:1095,y:942,t:1527616790107};\\\", \\\"{x:1093,y:944,t:1527616790124};\\\", \\\"{x:1091,y:946,t:1527616790141};\\\", \\\"{x:1090,y:946,t:1527616790167};\\\", \\\"{x:1089,y:946,t:1527616790183};\\\", \\\"{x:1088,y:946,t:1527616790215};\\\", \\\"{x:1087,y:946,t:1527616790224};\\\", \\\"{x:1085,y:940,t:1527616790242};\\\", \\\"{x:1084,y:927,t:1527616790259};\\\", \\\"{x:1084,y:913,t:1527616790275};\\\", \\\"{x:1084,y:901,t:1527616790292};\\\", \\\"{x:1084,y:893,t:1527616790307};\\\", \\\"{x:1084,y:887,t:1527616790324};\\\", \\\"{x:1085,y:874,t:1527616790341};\\\", \\\"{x:1090,y:844,t:1527616790358};\\\", \\\"{x:1092,y:822,t:1527616790374};\\\", \\\"{x:1095,y:800,t:1527616790391};\\\", \\\"{x:1096,y:785,t:1527616790409};\\\", \\\"{x:1096,y:771,t:1527616790425};\\\", \\\"{x:1096,y:754,t:1527616790441};\\\", \\\"{x:1096,y:728,t:1527616790459};\\\", \\\"{x:1095,y:705,t:1527616790474};\\\", \\\"{x:1091,y:684,t:1527616790492};\\\", \\\"{x:1090,y:669,t:1527616790508};\\\", \\\"{x:1090,y:659,t:1527616790525};\\\", \\\"{x:1091,y:643,t:1527616790542};\\\", \\\"{x:1095,y:626,t:1527616790558};\\\", \\\"{x:1095,y:616,t:1527616790575};\\\", \\\"{x:1094,y:609,t:1527616790592};\\\", \\\"{x:1093,y:605,t:1527616790609};\\\", \\\"{x:1092,y:602,t:1527616790625};\\\", \\\"{x:1092,y:599,t:1527616790641};\\\", \\\"{x:1092,y:598,t:1527616790659};\\\", \\\"{x:1091,y:597,t:1527616790686};\\\", \\\"{x:1087,y:597,t:1527616790718};\\\", \\\"{x:1081,y:598,t:1527616790726};\\\", \\\"{x:1074,y:601,t:1527616790741};\\\", \\\"{x:1058,y:620,t:1527616790758};\\\", \\\"{x:1050,y:627,t:1527616790775};\\\", \\\"{x:1044,y:633,t:1527616790791};\\\", \\\"{x:1041,y:637,t:1527616790808};\\\", \\\"{x:1041,y:638,t:1527616790825};\\\", \\\"{x:1040,y:638,t:1527616790841};\\\", \\\"{x:1041,y:638,t:1527616790998};\\\", \\\"{x:1042,y:638,t:1527616791022};\\\", \\\"{x:1043,y:638,t:1527616791031};\\\", \\\"{x:1044,y:638,t:1527616791046};\\\", \\\"{x:1047,y:637,t:1527616791059};\\\", \\\"{x:1056,y:636,t:1527616791076};\\\", \\\"{x:1071,y:634,t:1527616791093};\\\", \\\"{x:1086,y:632,t:1527616791108};\\\", \\\"{x:1096,y:632,t:1527616791125};\\\", \\\"{x:1113,y:631,t:1527616791142};\\\", \\\"{x:1121,y:631,t:1527616791158};\\\", \\\"{x:1126,y:631,t:1527616791176};\\\", \\\"{x:1128,y:631,t:1527616791193};\\\", \\\"{x:1130,y:631,t:1527616791209};\\\", \\\"{x:1131,y:631,t:1527616791226};\\\", \\\"{x:1136,y:631,t:1527616791243};\\\", \\\"{x:1143,y:631,t:1527616791258};\\\", \\\"{x:1151,y:631,t:1527616791275};\\\", \\\"{x:1159,y:631,t:1527616791292};\\\", \\\"{x:1167,y:631,t:1527616791309};\\\", \\\"{x:1173,y:631,t:1527616791325};\\\", \\\"{x:1184,y:631,t:1527616791343};\\\", \\\"{x:1193,y:631,t:1527616791359};\\\", \\\"{x:1207,y:631,t:1527616791375};\\\", \\\"{x:1227,y:631,t:1527616791393};\\\", \\\"{x:1246,y:631,t:1527616791409};\\\", \\\"{x:1265,y:631,t:1527616791426};\\\", \\\"{x:1278,y:631,t:1527616791443};\\\", \\\"{x:1288,y:631,t:1527616791459};\\\", \\\"{x:1294,y:631,t:1527616791476};\\\", \\\"{x:1299,y:631,t:1527616791492};\\\", \\\"{x:1303,y:630,t:1527616791509};\\\", \\\"{x:1307,y:630,t:1527616791525};\\\", \\\"{x:1322,y:630,t:1527616791542};\\\", \\\"{x:1340,y:630,t:1527616791559};\\\", \\\"{x:1365,y:630,t:1527616791575};\\\", \\\"{x:1392,y:628,t:1527616791592};\\\", \\\"{x:1414,y:628,t:1527616791609};\\\", \\\"{x:1436,y:628,t:1527616791625};\\\", \\\"{x:1451,y:628,t:1527616791644};\\\", \\\"{x:1462,y:628,t:1527616791660};\\\", \\\"{x:1473,y:628,t:1527616791676};\\\", \\\"{x:1482,y:628,t:1527616791692};\\\", \\\"{x:1488,y:628,t:1527616791709};\\\", \\\"{x:1494,y:627,t:1527616791726};\\\", \\\"{x:1498,y:626,t:1527616791742};\\\", \\\"{x:1500,y:626,t:1527616791774};\\\", \\\"{x:1501,y:626,t:1527616791782};\\\", \\\"{x:1503,y:625,t:1527616791793};\\\", \\\"{x:1507,y:624,t:1527616791810};\\\", \\\"{x:1512,y:624,t:1527616791826};\\\", \\\"{x:1519,y:623,t:1527616791843};\\\", \\\"{x:1525,y:623,t:1527616791860};\\\", \\\"{x:1538,y:623,t:1527616791876};\\\", \\\"{x:1553,y:623,t:1527616791893};\\\", \\\"{x:1569,y:623,t:1527616791910};\\\", \\\"{x:1580,y:623,t:1527616791927};\\\", \\\"{x:1581,y:623,t:1527616792231};\\\", \\\"{x:1582,y:623,t:1527616792271};\\\", \\\"{x:1583,y:623,t:1527616792295};\\\", \\\"{x:1584,y:623,t:1527616792309};\\\", \\\"{x:1586,y:627,t:1527616792328};\\\", \\\"{x:1588,y:633,t:1527616792344};\\\", \\\"{x:1589,y:638,t:1527616792359};\\\", \\\"{x:1592,y:642,t:1527616792377};\\\", \\\"{x:1594,y:645,t:1527616792394};\\\", \\\"{x:1595,y:646,t:1527616792410};\\\", \\\"{x:1595,y:647,t:1527616792426};\\\", \\\"{x:1595,y:648,t:1527616792444};\\\", \\\"{x:1596,y:648,t:1527616792460};\\\", \\\"{x:1598,y:652,t:1527616792477};\\\", \\\"{x:1600,y:658,t:1527616792493};\\\", \\\"{x:1605,y:667,t:1527616792511};\\\", \\\"{x:1607,y:669,t:1527616792527};\\\", \\\"{x:1608,y:671,t:1527616792544};\\\", \\\"{x:1609,y:671,t:1527616792561};\\\", \\\"{x:1610,y:672,t:1527616792577};\\\", \\\"{x:1611,y:674,t:1527616792594};\\\", \\\"{x:1612,y:675,t:1527616792611};\\\", \\\"{x:1615,y:679,t:1527616792627};\\\", \\\"{x:1617,y:682,t:1527616792644};\\\", \\\"{x:1619,y:685,t:1527616792661};\\\", \\\"{x:1619,y:686,t:1527616792677};\\\", \\\"{x:1620,y:686,t:1527616792952};\\\", \\\"{x:1620,y:687,t:1527616792992};\\\", \\\"{x:1620,y:688,t:1527616792999};\\\", \\\"{x:1620,y:689,t:1527616793015};\\\", \\\"{x:1620,y:690,t:1527616793028};\\\", \\\"{x:1620,y:691,t:1527616793044};\\\", \\\"{x:1620,y:693,t:1527616793061};\\\", \\\"{x:1620,y:694,t:1527616793078};\\\", \\\"{x:1620,y:695,t:1527616793094};\\\", \\\"{x:1620,y:696,t:1527616793287};\\\", \\\"{x:1618,y:696,t:1527616797525};\\\", \\\"{x:1613,y:694,t:1527616797534};\\\", \\\"{x:1609,y:693,t:1527616797549};\\\", \\\"{x:1597,y:690,t:1527616797564};\\\", \\\"{x:1581,y:690,t:1527616797582};\\\", \\\"{x:1553,y:690,t:1527616797597};\\\", \\\"{x:1537,y:690,t:1527616797614};\\\", \\\"{x:1524,y:690,t:1527616797631};\\\", \\\"{x:1517,y:690,t:1527616797648};\\\", \\\"{x:1511,y:690,t:1527616797666};\\\", \\\"{x:1508,y:690,t:1527616797681};\\\", \\\"{x:1506,y:690,t:1527616797698};\\\", \\\"{x:1501,y:690,t:1527616797715};\\\", \\\"{x:1489,y:690,t:1527616797731};\\\", \\\"{x:1471,y:690,t:1527616797748};\\\", \\\"{x:1452,y:690,t:1527616797765};\\\", \\\"{x:1433,y:690,t:1527616797782};\\\", \\\"{x:1400,y:690,t:1527616797798};\\\", \\\"{x:1379,y:690,t:1527616797815};\\\", \\\"{x:1365,y:690,t:1527616797832};\\\", \\\"{x:1353,y:690,t:1527616797848};\\\", \\\"{x:1341,y:690,t:1527616797865};\\\", \\\"{x:1333,y:690,t:1527616797882};\\\", \\\"{x:1326,y:690,t:1527616797898};\\\", \\\"{x:1319,y:690,t:1527616797916};\\\", \\\"{x:1314,y:690,t:1527616797932};\\\", \\\"{x:1312,y:690,t:1527616797949};\\\", \\\"{x:1314,y:690,t:1527616798599};\\\", \\\"{x:1320,y:690,t:1527616798616};\\\", \\\"{x:1324,y:690,t:1527616798632};\\\", \\\"{x:1327,y:690,t:1527616798650};\\\", \\\"{x:1329,y:690,t:1527616798666};\\\", \\\"{x:1331,y:690,t:1527616798682};\\\", \\\"{x:1332,y:690,t:1527616798699};\\\", \\\"{x:1334,y:690,t:1527616798715};\\\", \\\"{x:1335,y:690,t:1527616798774};\\\", \\\"{x:1337,y:690,t:1527616798799};\\\", \\\"{x:1338,y:690,t:1527616799344};\\\", \\\"{x:1338,y:691,t:1527616799639};\\\", \\\"{x:1339,y:692,t:1527616799650};\\\", \\\"{x:1341,y:696,t:1527616799667};\\\", \\\"{x:1341,y:697,t:1527616799683};\\\", \\\"{x:1341,y:698,t:1527616799700};\\\", \\\"{x:1341,y:700,t:1527616799716};\\\", \\\"{x:1341,y:701,t:1527616799734};\\\", \\\"{x:1341,y:705,t:1527616799750};\\\", \\\"{x:1341,y:708,t:1527616799766};\\\", \\\"{x:1341,y:711,t:1527616799811};\\\", \\\"{x:1341,y:715,t:1527616799829};\\\", \\\"{x:1341,y:718,t:1527616799844};\\\", \\\"{x:1341,y:722,t:1527616799861};\\\", \\\"{x:1341,y:726,t:1527616799878};\\\", \\\"{x:1341,y:730,t:1527616799894};\\\", \\\"{x:1342,y:734,t:1527616799912};\\\", \\\"{x:1342,y:737,t:1527616799929};\\\", \\\"{x:1343,y:740,t:1527616799945};\\\", \\\"{x:1344,y:742,t:1527616799962};\\\", \\\"{x:1344,y:745,t:1527616799979};\\\", \\\"{x:1345,y:748,t:1527616799995};\\\", \\\"{x:1345,y:751,t:1527616800012};\\\", \\\"{x:1347,y:754,t:1527616800028};\\\", \\\"{x:1348,y:757,t:1527616800046};\\\", \\\"{x:1348,y:759,t:1527616800062};\\\", \\\"{x:1348,y:761,t:1527616800078};\\\", \\\"{x:1348,y:765,t:1527616800095};\\\", \\\"{x:1348,y:771,t:1527616800112};\\\", \\\"{x:1348,y:777,t:1527616800129};\\\", \\\"{x:1349,y:782,t:1527616800145};\\\", \\\"{x:1349,y:786,t:1527616800162};\\\", \\\"{x:1351,y:792,t:1527616800178};\\\", \\\"{x:1351,y:795,t:1527616800196};\\\", \\\"{x:1351,y:798,t:1527616800212};\\\", \\\"{x:1351,y:801,t:1527616800229};\\\", \\\"{x:1351,y:805,t:1527616800246};\\\", \\\"{x:1351,y:809,t:1527616800262};\\\", \\\"{x:1351,y:814,t:1527616800279};\\\", \\\"{x:1349,y:820,t:1527616800296};\\\", \\\"{x:1349,y:825,t:1527616800312};\\\", \\\"{x:1348,y:833,t:1527616800328};\\\", \\\"{x:1348,y:840,t:1527616800346};\\\", \\\"{x:1348,y:850,t:1527616800362};\\\", \\\"{x:1348,y:858,t:1527616800379};\\\", \\\"{x:1348,y:865,t:1527616800396};\\\", \\\"{x:1347,y:873,t:1527616800413};\\\", \\\"{x:1347,y:882,t:1527616800429};\\\", \\\"{x:1347,y:893,t:1527616800445};\\\", \\\"{x:1347,y:901,t:1527616800462};\\\", \\\"{x:1347,y:909,t:1527616800478};\\\", \\\"{x:1347,y:913,t:1527616800495};\\\", \\\"{x:1347,y:916,t:1527616800512};\\\", \\\"{x:1347,y:917,t:1527616800585};\\\", \\\"{x:1346,y:912,t:1527616800641};\\\", \\\"{x:1341,y:902,t:1527616800649};\\\", \\\"{x:1334,y:891,t:1527616800663};\\\", \\\"{x:1316,y:869,t:1527616800680};\\\", \\\"{x:1294,y:844,t:1527616800695};\\\", \\\"{x:1277,y:830,t:1527616800712};\\\", \\\"{x:1269,y:825,t:1527616800729};\\\", \\\"{x:1263,y:821,t:1527616800745};\\\", \\\"{x:1257,y:818,t:1527616800761};\\\", \\\"{x:1255,y:817,t:1527616800779};\\\", \\\"{x:1254,y:817,t:1527616800795};\\\", \\\"{x:1250,y:816,t:1527616800813};\\\", \\\"{x:1247,y:814,t:1527616800830};\\\", \\\"{x:1239,y:813,t:1527616800845};\\\", \\\"{x:1228,y:812,t:1527616800862};\\\", \\\"{x:1211,y:811,t:1527616800880};\\\", \\\"{x:1187,y:811,t:1527616800895};\\\", \\\"{x:1154,y:808,t:1527616800912};\\\", \\\"{x:1116,y:805,t:1527616800930};\\\", \\\"{x:1085,y:802,t:1527616800946};\\\", \\\"{x:1048,y:794,t:1527616800963};\\\", \\\"{x:1040,y:792,t:1527616800980};\\\", \\\"{x:1038,y:791,t:1527616800996};\\\", \\\"{x:1035,y:790,t:1527616801013};\\\", \\\"{x:1033,y:790,t:1527616801030};\\\", \\\"{x:1032,y:790,t:1527616801051};\\\", \\\"{x:1030,y:790,t:1527616801062};\\\", \\\"{x:1023,y:792,t:1527616801079};\\\", \\\"{x:1012,y:792,t:1527616801097};\\\", \\\"{x:1000,y:792,t:1527616801113};\\\", \\\"{x:982,y:792,t:1527616801129};\\\", \\\"{x:952,y:792,t:1527616801147};\\\", \\\"{x:938,y:792,t:1527616801163};\\\", \\\"{x:918,y:792,t:1527616801180};\\\", \\\"{x:904,y:792,t:1527616801197};\\\", \\\"{x:893,y:792,t:1527616801212};\\\", \\\"{x:884,y:792,t:1527616801229};\\\", \\\"{x:874,y:792,t:1527616801246};\\\", \\\"{x:862,y:792,t:1527616801262};\\\", \\\"{x:848,y:790,t:1527616801279};\\\", \\\"{x:837,y:789,t:1527616801296};\\\", \\\"{x:824,y:787,t:1527616801313};\\\", \\\"{x:815,y:786,t:1527616801329};\\\", \\\"{x:807,y:785,t:1527616801346};\\\", \\\"{x:803,y:785,t:1527616801363};\\\", \\\"{x:799,y:785,t:1527616801380};\\\", \\\"{x:795,y:785,t:1527616801396};\\\", \\\"{x:792,y:785,t:1527616801413};\\\", \\\"{x:791,y:785,t:1527616801429};\\\", \\\"{x:788,y:785,t:1527616801446};\\\", \\\"{x:787,y:785,t:1527616801462};\\\", \\\"{x:779,y:783,t:1527616801479};\\\", \\\"{x:763,y:783,t:1527616801496};\\\", \\\"{x:753,y:783,t:1527616801513};\\\", \\\"{x:748,y:783,t:1527616801529};\\\", \\\"{x:740,y:783,t:1527616801546};\\\", \\\"{x:738,y:783,t:1527616801563};\\\", \\\"{x:737,y:783,t:1527616801579};\\\", \\\"{x:735,y:783,t:1527616801596};\\\", \\\"{x:734,y:783,t:1527616801613};\\\", \\\"{x:731,y:783,t:1527616801629};\\\", \\\"{x:723,y:783,t:1527616801646};\\\", \\\"{x:710,y:783,t:1527616801663};\\\", \\\"{x:698,y:783,t:1527616801679};\\\", \\\"{x:685,y:783,t:1527616801696};\\\", \\\"{x:677,y:783,t:1527616801713};\\\", \\\"{x:667,y:782,t:1527616801730};\\\", \\\"{x:666,y:782,t:1527616801746};\\\", \\\"{x:665,y:782,t:1527616801794};\\\", \\\"{x:663,y:782,t:1527616801802};\\\", \\\"{x:661,y:781,t:1527616801814};\\\", \\\"{x:653,y:778,t:1527616801830};\\\", \\\"{x:640,y:773,t:1527616801846};\\\", \\\"{x:628,y:767,t:1527616801863};\\\", \\\"{x:620,y:763,t:1527616801881};\\\", \\\"{x:617,y:760,t:1527616801896};\\\", \\\"{x:615,y:758,t:1527616801914};\\\", \\\"{x:614,y:754,t:1527616801930};\\\", \\\"{x:612,y:749,t:1527616801946};\\\", \\\"{x:610,y:742,t:1527616801963};\\\", \\\"{x:607,y:732,t:1527616801981};\\\", \\\"{x:605,y:721,t:1527616801996};\\\", \\\"{x:602,y:708,t:1527616802014};\\\", \\\"{x:600,y:695,t:1527616802031};\\\", \\\"{x:598,y:683,t:1527616802048};\\\", \\\"{x:595,y:670,t:1527616802063};\\\", \\\"{x:591,y:659,t:1527616802081};\\\", \\\"{x:587,y:647,t:1527616802097};\\\", \\\"{x:583,y:637,t:1527616802113};\\\", \\\"{x:574,y:624,t:1527616802132};\\\", \\\"{x:569,y:619,t:1527616802147};\\\", \\\"{x:565,y:615,t:1527616802163};\\\", \\\"{x:563,y:612,t:1527616802178};\\\", \\\"{x:561,y:611,t:1527616802194};\\\", \\\"{x:561,y:610,t:1527616802211};\\\", \\\"{x:560,y:609,t:1527616802227};\\\", \\\"{x:559,y:609,t:1527616802244};\\\", \\\"{x:555,y:607,t:1527616802261};\\\", \\\"{x:552,y:605,t:1527616802277};\\\", \\\"{x:545,y:602,t:1527616802294};\\\", \\\"{x:528,y:597,t:1527616802312};\\\", \\\"{x:513,y:594,t:1527616802327};\\\", \\\"{x:502,y:591,t:1527616802345};\\\", \\\"{x:490,y:587,t:1527616802362};\\\", \\\"{x:480,y:585,t:1527616802378};\\\", \\\"{x:469,y:581,t:1527616802395};\\\", \\\"{x:461,y:581,t:1527616802412};\\\", \\\"{x:446,y:576,t:1527616802429};\\\", \\\"{x:431,y:572,t:1527616802445};\\\", \\\"{x:419,y:568,t:1527616802461};\\\", \\\"{x:407,y:562,t:1527616802479};\\\", \\\"{x:400,y:559,t:1527616802495};\\\", \\\"{x:391,y:556,t:1527616802511};\\\", \\\"{x:381,y:553,t:1527616802528};\\\", \\\"{x:369,y:552,t:1527616802545};\\\", \\\"{x:352,y:549,t:1527616802561};\\\", \\\"{x:313,y:549,t:1527616802578};\\\", \\\"{x:284,y:549,t:1527616802596};\\\", \\\"{x:263,y:549,t:1527616802612};\\\", \\\"{x:243,y:549,t:1527616802628};\\\", \\\"{x:232,y:549,t:1527616802645};\\\", \\\"{x:221,y:549,t:1527616802662};\\\", \\\"{x:209,y:549,t:1527616802679};\\\", \\\"{x:199,y:549,t:1527616802696};\\\", \\\"{x:189,y:550,t:1527616802713};\\\", \\\"{x:182,y:553,t:1527616802728};\\\", \\\"{x:174,y:555,t:1527616802746};\\\", \\\"{x:165,y:559,t:1527616802762};\\\", \\\"{x:162,y:562,t:1527616802778};\\\", \\\"{x:160,y:562,t:1527616802906};\\\", \\\"{x:157,y:561,t:1527616802923};\\\", \\\"{x:155,y:559,t:1527616802931};\\\", \\\"{x:155,y:557,t:1527616802945};\\\", \\\"{x:150,y:549,t:1527616802961};\\\", \\\"{x:148,y:545,t:1527616802978};\\\", \\\"{x:148,y:543,t:1527616802996};\\\", \\\"{x:148,y:542,t:1527616803089};\\\", \\\"{x:148,y:541,t:1527616803137};\\\", \\\"{x:148,y:540,t:1527616803145};\\\", \\\"{x:151,y:539,t:1527616803396};\\\", \\\"{x:172,y:539,t:1527616803413};\\\", \\\"{x:211,y:539,t:1527616803429};\\\", \\\"{x:244,y:539,t:1527616803446};\\\", \\\"{x:300,y:541,t:1527616803463};\\\", \\\"{x:354,y:549,t:1527616803479};\\\", \\\"{x:417,y:556,t:1527616803496};\\\", \\\"{x:473,y:556,t:1527616803512};\\\", \\\"{x:529,y:556,t:1527616803529};\\\", \\\"{x:588,y:556,t:1527616803545};\\\", \\\"{x:622,y:556,t:1527616803562};\\\", \\\"{x:644,y:556,t:1527616803579};\\\", \\\"{x:658,y:556,t:1527616803596};\\\", \\\"{x:664,y:554,t:1527616803613};\\\", \\\"{x:667,y:552,t:1527616803629};\\\", \\\"{x:668,y:552,t:1527616803646};\\\", \\\"{x:668,y:551,t:1527616803662};\\\", \\\"{x:670,y:549,t:1527616803680};\\\", \\\"{x:672,y:547,t:1527616803696};\\\", \\\"{x:675,y:545,t:1527616803712};\\\", \\\"{x:676,y:544,t:1527616803729};\\\", \\\"{x:679,y:544,t:1527616803851};\\\", \\\"{x:683,y:547,t:1527616803862};\\\", \\\"{x:688,y:552,t:1527616803880};\\\", \\\"{x:699,y:556,t:1527616803898};\\\", \\\"{x:715,y:560,t:1527616803912};\\\", \\\"{x:747,y:561,t:1527616803929};\\\", \\\"{x:774,y:561,t:1527616803945};\\\", \\\"{x:802,y:560,t:1527616803962};\\\", \\\"{x:815,y:552,t:1527616803979};\\\", \\\"{x:822,y:548,t:1527616803996};\\\", \\\"{x:824,y:547,t:1527616804012};\\\", \\\"{x:826,y:545,t:1527616804033};\\\", \\\"{x:826,y:544,t:1527616804050};\\\", \\\"{x:828,y:541,t:1527616804063};\\\", \\\"{x:831,y:539,t:1527616804079};\\\", \\\"{x:832,y:536,t:1527616804096};\\\", \\\"{x:834,y:534,t:1527616804112};\\\", \\\"{x:835,y:531,t:1527616804129};\\\", \\\"{x:838,y:526,t:1527616804146};\\\", \\\"{x:839,y:521,t:1527616804164};\\\", \\\"{x:839,y:520,t:1527616804179};\\\", \\\"{x:839,y:519,t:1527616804196};\\\", \\\"{x:839,y:518,t:1527616804214};\\\", \\\"{x:839,y:517,t:1527616804232};\\\", \\\"{x:839,y:515,t:1527616804247};\\\", \\\"{x:839,y:513,t:1527616804264};\\\", \\\"{x:839,y:509,t:1527616804280};\\\", \\\"{x:839,y:507,t:1527616804296};\\\", \\\"{x:839,y:505,t:1527616804314};\\\", \\\"{x:839,y:504,t:1527616804329};\\\", \\\"{x:839,y:503,t:1527616804354};\\\", \\\"{x:833,y:507,t:1527616804561};\\\", \\\"{x:820,y:514,t:1527616804570};\\\", \\\"{x:803,y:523,t:1527616804581};\\\", \\\"{x:763,y:546,t:1527616804597};\\\", \\\"{x:719,y:574,t:1527616804614};\\\", \\\"{x:668,y:608,t:1527616804631};\\\", \\\"{x:627,y:636,t:1527616804647};\\\", \\\"{x:594,y:657,t:1527616804663};\\\", \\\"{x:568,y:678,t:1527616804680};\\\", \\\"{x:536,y:706,t:1527616804698};\\\", \\\"{x:516,y:718,t:1527616804713};\\\", \\\"{x:498,y:727,t:1527616804731};\\\", \\\"{x:485,y:732,t:1527616804748};\\\", \\\"{x:477,y:736,t:1527616804764};\\\", \\\"{x:470,y:739,t:1527616804780};\\\", \\\"{x:469,y:740,t:1527616804797};\\\", \\\"{x:468,y:740,t:1527616805330};\\\", \\\"{x:473,y:736,t:1527616805347};\\\", \\\"{x:489,y:731,t:1527616805365};\\\", \\\"{x:502,y:727,t:1527616805381};\\\", \\\"{x:512,y:724,t:1527616805397};\\\", \\\"{x:529,y:722,t:1527616805415};\\\", \\\"{x:543,y:720,t:1527616805430};\\\", \\\"{x:560,y:717,t:1527616805448};\\\", \\\"{x:582,y:711,t:1527616805464};\\\", \\\"{x:615,y:707,t:1527616805481};\\\", \\\"{x:674,y:691,t:1527616805498};\\\", \\\"{x:716,y:681,t:1527616805514};\\\", \\\"{x:761,y:668,t:1527616805530};\\\", \\\"{x:801,y:659,t:1527616805547};\\\", \\\"{x:834,y:653,t:1527616805564};\\\", \\\"{x:860,y:648,t:1527616805580};\\\", \\\"{x:885,y:646,t:1527616805598};\\\", \\\"{x:902,y:642,t:1527616805615};\\\", \\\"{x:920,y:639,t:1527616805631};\\\", \\\"{x:934,y:637,t:1527616805648};\\\", \\\"{x:944,y:636,t:1527616805664};\\\", \\\"{x:954,y:634,t:1527616805680};\\\", \\\"{x:963,y:633,t:1527616805698};\\\", \\\"{x:967,y:632,t:1527616805714};\\\", \\\"{x:969,y:631,t:1527616805730};\\\" ] }, { \\\"rt\\\": 39590, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 285908, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-L -B -B -B -B -B -B -X -X -M -M -M -X -J -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:965,y:628,t:1527616807090};\\\", \\\"{x:956,y:623,t:1527616807098};\\\", \\\"{x:943,y:618,t:1527616807116};\\\", \\\"{x:928,y:612,t:1527616807131};\\\", \\\"{x:920,y:607,t:1527616807148};\\\", \\\"{x:898,y:606,t:1527616807166};\\\", \\\"{x:873,y:604,t:1527616807182};\\\", \\\"{x:846,y:603,t:1527616807198};\\\", \\\"{x:807,y:602,t:1527616807216};\\\", \\\"{x:740,y:595,t:1527616807233};\\\", \\\"{x:663,y:588,t:1527616807249};\\\", \\\"{x:557,y:576,t:1527616807265};\\\", \\\"{x:509,y:570,t:1527616807283};\\\", \\\"{x:477,y:564,t:1527616807300};\\\", \\\"{x:455,y:561,t:1527616807316};\\\", \\\"{x:434,y:557,t:1527616807333};\\\", \\\"{x:416,y:552,t:1527616807349};\\\", \\\"{x:402,y:547,t:1527616807366};\\\", \\\"{x:394,y:544,t:1527616807382};\\\", \\\"{x:384,y:539,t:1527616807398};\\\", \\\"{x:376,y:535,t:1527616807416};\\\", \\\"{x:369,y:530,t:1527616807433};\\\", \\\"{x:366,y:529,t:1527616807449};\\\", \\\"{x:357,y:523,t:1527616807466};\\\", \\\"{x:352,y:519,t:1527616807482};\\\", \\\"{x:349,y:517,t:1527616807500};\\\", \\\"{x:346,y:515,t:1527616807516};\\\", \\\"{x:343,y:513,t:1527616807533};\\\", \\\"{x:339,y:510,t:1527616807548};\\\", \\\"{x:333,y:506,t:1527616807566};\\\", \\\"{x:329,y:503,t:1527616807582};\\\", \\\"{x:323,y:500,t:1527616807599};\\\", \\\"{x:316,y:498,t:1527616807615};\\\", \\\"{x:308,y:494,t:1527616807632};\\\", \\\"{x:299,y:490,t:1527616807648};\\\", \\\"{x:295,y:488,t:1527616807665};\\\", \\\"{x:294,y:488,t:1527616807682};\\\", \\\"{x:294,y:487,t:1527616807699};\\\", \\\"{x:293,y:487,t:1527616807716};\\\", \\\"{x:292,y:486,t:1527616807834};\\\", \\\"{x:292,y:485,t:1527616808090};\\\", \\\"{x:295,y:482,t:1527616808100};\\\", \\\"{x:299,y:479,t:1527616808117};\\\", \\\"{x:301,y:477,t:1527616808133};\\\", \\\"{x:303,y:475,t:1527616808149};\\\", \\\"{x:304,y:473,t:1527616808167};\\\", \\\"{x:305,y:471,t:1527616808183};\\\", \\\"{x:307,y:470,t:1527616808199};\\\", \\\"{x:309,y:468,t:1527616808217};\\\", \\\"{x:311,y:466,t:1527616808234};\\\", \\\"{x:313,y:464,t:1527616808250};\\\", \\\"{x:315,y:463,t:1527616808267};\\\", \\\"{x:315,y:462,t:1527616808284};\\\", \\\"{x:317,y:461,t:1527616808300};\\\", \\\"{x:319,y:460,t:1527616808316};\\\", \\\"{x:321,y:459,t:1527616808333};\\\", \\\"{x:325,y:458,t:1527616808351};\\\", \\\"{x:328,y:457,t:1527616808367};\\\", \\\"{x:329,y:456,t:1527616808384};\\\", \\\"{x:333,y:455,t:1527616808401};\\\", \\\"{x:335,y:455,t:1527616808417};\\\", \\\"{x:336,y:455,t:1527616808442};\\\", \\\"{x:337,y:455,t:1527616808450};\\\", \\\"{x:338,y:455,t:1527616808490};\\\", \\\"{x:339,y:455,t:1527616808506};\\\", \\\"{x:340,y:455,t:1527616808531};\\\", \\\"{x:341,y:455,t:1527616808547};\\\", \\\"{x:342,y:455,t:1527616808561};\\\", \\\"{x:342,y:456,t:1527616808569};\\\", \\\"{x:343,y:456,t:1527616808585};\\\", \\\"{x:344,y:456,t:1527616808642};\\\", \\\"{x:345,y:457,t:1527616808650};\\\", \\\"{x:347,y:457,t:1527616808667};\\\", \\\"{x:352,y:457,t:1527616808684};\\\", \\\"{x:357,y:458,t:1527616808700};\\\", \\\"{x:360,y:458,t:1527616808718};\\\", \\\"{x:364,y:460,t:1527616808735};\\\", \\\"{x:366,y:460,t:1527616808751};\\\", \\\"{x:368,y:460,t:1527616808768};\\\", \\\"{x:371,y:460,t:1527616808784};\\\", \\\"{x:374,y:460,t:1527616808801};\\\", \\\"{x:378,y:461,t:1527616808818};\\\", \\\"{x:382,y:462,t:1527616808835};\\\", \\\"{x:387,y:462,t:1527616808851};\\\", \\\"{x:393,y:463,t:1527616808868};\\\", \\\"{x:397,y:463,t:1527616808885};\\\", \\\"{x:401,y:463,t:1527616808900};\\\", \\\"{x:403,y:463,t:1527616808918};\\\", \\\"{x:406,y:463,t:1527616808935};\\\", \\\"{x:410,y:463,t:1527616808951};\\\", \\\"{x:415,y:463,t:1527616808968};\\\", \\\"{x:424,y:463,t:1527616808985};\\\", \\\"{x:446,y:463,t:1527616809002};\\\", \\\"{x:462,y:463,t:1527616809018};\\\", \\\"{x:478,y:463,t:1527616809035};\\\", \\\"{x:490,y:463,t:1527616809052};\\\", \\\"{x:503,y:463,t:1527616809067};\\\", \\\"{x:515,y:463,t:1527616809085};\\\", \\\"{x:522,y:463,t:1527616809102};\\\", \\\"{x:525,y:463,t:1527616809117};\\\", \\\"{x:527,y:463,t:1527616809134};\\\", \\\"{x:528,y:463,t:1527616809178};\\\", \\\"{x:531,y:463,t:1527616809185};\\\", \\\"{x:534,y:463,t:1527616809201};\\\", \\\"{x:538,y:463,t:1527616809218};\\\", \\\"{x:543,y:463,t:1527616809235};\\\", \\\"{x:546,y:463,t:1527616809251};\\\", \\\"{x:552,y:463,t:1527616809268};\\\", \\\"{x:553,y:463,t:1527616809285};\\\", \\\"{x:555,y:463,t:1527616809302};\\\", \\\"{x:556,y:464,t:1527616809545};\\\", \\\"{x:554,y:464,t:1527616809561};\\\", \\\"{x:553,y:464,t:1527616809569};\\\", \\\"{x:548,y:464,t:1527616809585};\\\", \\\"{x:545,y:464,t:1527616809601};\\\", \\\"{x:543,y:464,t:1527616809618};\\\", \\\"{x:541,y:464,t:1527616809641};\\\", \\\"{x:540,y:464,t:1527616809657};\\\", \\\"{x:539,y:464,t:1527616809668};\\\", \\\"{x:538,y:464,t:1527616809685};\\\", \\\"{x:535,y:464,t:1527616809702};\\\", \\\"{x:531,y:464,t:1527616809719};\\\", \\\"{x:526,y:463,t:1527616809736};\\\", \\\"{x:518,y:462,t:1527616809753};\\\", \\\"{x:498,y:459,t:1527616809769};\\\", \\\"{x:466,y:456,t:1527616809786};\\\", \\\"{x:447,y:453,t:1527616809803};\\\", \\\"{x:436,y:452,t:1527616809819};\\\", \\\"{x:429,y:451,t:1527616809836};\\\", \\\"{x:427,y:449,t:1527616809852};\\\", \\\"{x:426,y:449,t:1527616810186};\\\", \\\"{x:433,y:449,t:1527616810203};\\\", \\\"{x:454,y:449,t:1527616810219};\\\", \\\"{x:473,y:449,t:1527616810237};\\\", \\\"{x:490,y:450,t:1527616810252};\\\", \\\"{x:499,y:451,t:1527616810269};\\\", \\\"{x:502,y:451,t:1527616810286};\\\", \\\"{x:503,y:451,t:1527616810305};\\\", \\\"{x:505,y:451,t:1527616810387};\\\", \\\"{x:511,y:451,t:1527616810403};\\\", \\\"{x:519,y:451,t:1527616810420};\\\", \\\"{x:527,y:451,t:1527616810437};\\\", \\\"{x:541,y:451,t:1527616810454};\\\", \\\"{x:552,y:451,t:1527616810469};\\\", \\\"{x:564,y:451,t:1527616810486};\\\", \\\"{x:574,y:451,t:1527616810503};\\\", \\\"{x:581,y:451,t:1527616810520};\\\", \\\"{x:589,y:451,t:1527616810536};\\\", \\\"{x:593,y:451,t:1527616810553};\\\", \\\"{x:594,y:451,t:1527616810570};\\\", \\\"{x:596,y:451,t:1527616810586};\\\", \\\"{x:599,y:451,t:1527616810604};\\\", \\\"{x:604,y:451,t:1527616810621};\\\", \\\"{x:610,y:451,t:1527616810637};\\\", \\\"{x:618,y:451,t:1527616810653};\\\", \\\"{x:623,y:451,t:1527616810671};\\\", \\\"{x:630,y:451,t:1527616810686};\\\", \\\"{x:633,y:451,t:1527616810704};\\\", \\\"{x:635,y:451,t:1527616810720};\\\", \\\"{x:638,y:451,t:1527616810737};\\\", \\\"{x:641,y:451,t:1527616810753};\\\", \\\"{x:643,y:451,t:1527616810771};\\\", \\\"{x:648,y:451,t:1527616810787};\\\", \\\"{x:654,y:451,t:1527616810803};\\\", \\\"{x:663,y:451,t:1527616810820};\\\", \\\"{x:677,y:451,t:1527616810838};\\\", \\\"{x:689,y:451,t:1527616810853};\\\", \\\"{x:707,y:455,t:1527616810871};\\\", \\\"{x:727,y:456,t:1527616810888};\\\", \\\"{x:749,y:459,t:1527616810903};\\\", \\\"{x:768,y:461,t:1527616810921};\\\", \\\"{x:796,y:465,t:1527616810937};\\\", \\\"{x:806,y:466,t:1527616810955};\\\", \\\"{x:812,y:467,t:1527616810970};\\\", \\\"{x:816,y:468,t:1527616810988};\\\", \\\"{x:817,y:469,t:1527616811005};\\\", \\\"{x:820,y:469,t:1527616811020};\\\", \\\"{x:822,y:470,t:1527616811038};\\\", \\\"{x:825,y:472,t:1527616811055};\\\", \\\"{x:829,y:474,t:1527616811071};\\\", \\\"{x:833,y:474,t:1527616811088};\\\", \\\"{x:834,y:475,t:1527616811401};\\\", \\\"{x:836,y:476,t:1527616811410};\\\", \\\"{x:838,y:479,t:1527616811421};\\\", \\\"{x:842,y:490,t:1527616811439};\\\", \\\"{x:846,y:503,t:1527616811455};\\\", \\\"{x:849,y:513,t:1527616811472};\\\", \\\"{x:851,y:516,t:1527616811486};\\\", \\\"{x:852,y:518,t:1527616811503};\\\", \\\"{x:855,y:521,t:1527616811518};\\\", \\\"{x:858,y:527,t:1527616811536};\\\", \\\"{x:865,y:536,t:1527616811552};\\\", \\\"{x:873,y:547,t:1527616811569};\\\", \\\"{x:882,y:558,t:1527616811586};\\\", \\\"{x:886,y:563,t:1527616811603};\\\", \\\"{x:892,y:569,t:1527616811618};\\\", \\\"{x:899,y:576,t:1527616811635};\\\", \\\"{x:910,y:584,t:1527616811653};\\\", \\\"{x:915,y:589,t:1527616811669};\\\", \\\"{x:922,y:594,t:1527616811686};\\\", \\\"{x:926,y:597,t:1527616811703};\\\", \\\"{x:929,y:598,t:1527616811718};\\\", \\\"{x:929,y:599,t:1527616811736};\\\", \\\"{x:930,y:599,t:1527616811786};\\\", \\\"{x:934,y:599,t:1527616811803};\\\", \\\"{x:942,y:599,t:1527616811819};\\\", \\\"{x:950,y:597,t:1527616811836};\\\", \\\"{x:963,y:594,t:1527616811853};\\\", \\\"{x:975,y:590,t:1527616811870};\\\", \\\"{x:984,y:587,t:1527616811886};\\\", \\\"{x:991,y:585,t:1527616811903};\\\", \\\"{x:999,y:581,t:1527616811920};\\\", \\\"{x:1007,y:578,t:1527616811936};\\\", \\\"{x:1015,y:574,t:1527616811952};\\\", \\\"{x:1025,y:570,t:1527616811969};\\\", \\\"{x:1031,y:568,t:1527616811985};\\\", \\\"{x:1039,y:565,t:1527616812003};\\\", \\\"{x:1046,y:563,t:1527616812019};\\\", \\\"{x:1054,y:557,t:1527616812036};\\\", \\\"{x:1063,y:554,t:1527616812053};\\\", \\\"{x:1070,y:549,t:1527616812070};\\\", \\\"{x:1075,y:545,t:1527616812086};\\\", \\\"{x:1080,y:540,t:1527616812103};\\\", \\\"{x:1083,y:536,t:1527616812120};\\\", \\\"{x:1086,y:530,t:1527616812136};\\\", \\\"{x:1087,y:523,t:1527616812153};\\\", \\\"{x:1087,y:515,t:1527616812169};\\\", \\\"{x:1087,y:511,t:1527616812187};\\\", \\\"{x:1086,y:507,t:1527616812202};\\\", \\\"{x:1085,y:505,t:1527616812219};\\\", \\\"{x:1085,y:503,t:1527616812250};\\\", \\\"{x:1086,y:502,t:1527616812593};\\\", \\\"{x:1089,y:502,t:1527616812603};\\\", \\\"{x:1100,y:502,t:1527616812619};\\\", \\\"{x:1117,y:502,t:1527616812637};\\\", \\\"{x:1142,y:502,t:1527616812652};\\\", \\\"{x:1168,y:502,t:1527616812670};\\\", \\\"{x:1195,y:502,t:1527616812687};\\\", \\\"{x:1215,y:502,t:1527616812704};\\\", \\\"{x:1230,y:502,t:1527616812720};\\\", \\\"{x:1244,y:501,t:1527616812736};\\\", \\\"{x:1260,y:497,t:1527616812753};\\\", \\\"{x:1269,y:496,t:1527616812770};\\\", \\\"{x:1285,y:492,t:1527616812786};\\\", \\\"{x:1300,y:491,t:1527616812804};\\\", \\\"{x:1319,y:489,t:1527616812820};\\\", \\\"{x:1336,y:486,t:1527616812837};\\\", \\\"{x:1347,y:484,t:1527616812855};\\\", \\\"{x:1359,y:482,t:1527616812870};\\\", \\\"{x:1378,y:480,t:1527616812887};\\\", \\\"{x:1399,y:478,t:1527616812904};\\\", \\\"{x:1418,y:476,t:1527616812920};\\\", \\\"{x:1433,y:475,t:1527616812937};\\\", \\\"{x:1461,y:474,t:1527616812953};\\\", \\\"{x:1481,y:474,t:1527616812970};\\\", \\\"{x:1504,y:474,t:1527616812987};\\\", \\\"{x:1523,y:474,t:1527616813004};\\\", \\\"{x:1540,y:474,t:1527616813019};\\\", \\\"{x:1550,y:474,t:1527616813036};\\\", \\\"{x:1554,y:474,t:1527616813054};\\\", \\\"{x:1558,y:474,t:1527616813069};\\\", \\\"{x:1559,y:474,t:1527616813087};\\\", \\\"{x:1560,y:474,t:1527616813122};\\\", \\\"{x:1562,y:474,t:1527616813145};\\\", \\\"{x:1563,y:474,t:1527616813162};\\\", \\\"{x:1564,y:474,t:1527616813171};\\\", \\\"{x:1567,y:476,t:1527616813187};\\\", \\\"{x:1569,y:476,t:1527616813204};\\\", \\\"{x:1571,y:478,t:1527616813221};\\\", \\\"{x:1573,y:478,t:1527616813237};\\\", \\\"{x:1574,y:478,t:1527616813254};\\\", \\\"{x:1576,y:479,t:1527616813271};\\\", \\\"{x:1580,y:480,t:1527616813287};\\\", \\\"{x:1582,y:480,t:1527616813304};\\\", \\\"{x:1583,y:480,t:1527616813322};\\\", \\\"{x:1584,y:481,t:1527616813337};\\\", \\\"{x:1587,y:481,t:1527616813353};\\\", \\\"{x:1591,y:483,t:1527616813371};\\\", \\\"{x:1592,y:483,t:1527616813387};\\\", \\\"{x:1594,y:485,t:1527616813404};\\\", \\\"{x:1595,y:485,t:1527616813421};\\\", \\\"{x:1596,y:485,t:1527616813449};\\\", \\\"{x:1597,y:489,t:1527616813969};\\\", \\\"{x:1597,y:501,t:1527616813977};\\\", \\\"{x:1595,y:515,t:1527616813988};\\\", \\\"{x:1587,y:540,t:1527616814004};\\\", \\\"{x:1578,y:564,t:1527616814021};\\\", \\\"{x:1571,y:585,t:1527616814037};\\\", \\\"{x:1562,y:606,t:1527616814055};\\\", \\\"{x:1554,y:627,t:1527616814071};\\\", \\\"{x:1545,y:643,t:1527616814088};\\\", \\\"{x:1538,y:656,t:1527616814104};\\\", \\\"{x:1531,y:667,t:1527616814120};\\\", \\\"{x:1526,y:675,t:1527616814138};\\\", \\\"{x:1522,y:680,t:1527616814155};\\\", \\\"{x:1517,y:684,t:1527616814171};\\\", \\\"{x:1508,y:690,t:1527616814188};\\\", \\\"{x:1499,y:695,t:1527616814205};\\\", \\\"{x:1486,y:701,t:1527616814221};\\\", \\\"{x:1470,y:707,t:1527616814237};\\\", \\\"{x:1453,y:714,t:1527616814255};\\\", \\\"{x:1429,y:719,t:1527616814270};\\\", \\\"{x:1409,y:727,t:1527616814288};\\\", \\\"{x:1389,y:735,t:1527616814304};\\\", \\\"{x:1368,y:741,t:1527616814320};\\\", \\\"{x:1350,y:749,t:1527616814338};\\\", \\\"{x:1346,y:751,t:1527616814355};\\\", \\\"{x:1345,y:752,t:1527616814371};\\\", \\\"{x:1344,y:753,t:1527616814388};\\\", \\\"{x:1343,y:753,t:1527616814405};\\\", \\\"{x:1342,y:754,t:1527616814421};\\\", \\\"{x:1340,y:755,t:1527616814437};\\\", \\\"{x:1339,y:756,t:1527616814455};\\\", \\\"{x:1336,y:758,t:1527616814470};\\\", \\\"{x:1335,y:759,t:1527616814487};\\\", \\\"{x:1333,y:760,t:1527616814504};\\\", \\\"{x:1335,y:760,t:1527616814818};\\\", \\\"{x:1336,y:760,t:1527616814825};\\\", \\\"{x:1338,y:760,t:1527616814838};\\\", \\\"{x:1339,y:760,t:1527616814855};\\\", \\\"{x:1340,y:760,t:1527616814889};\\\", \\\"{x:1341,y:760,t:1527616814905};\\\", \\\"{x:1342,y:760,t:1527616814921};\\\", \\\"{x:1343,y:760,t:1527616814939};\\\", \\\"{x:1345,y:760,t:1527616814955};\\\", \\\"{x:1346,y:763,t:1527616821562};\\\", \\\"{x:1347,y:769,t:1527616821579};\\\", \\\"{x:1349,y:780,t:1527616821593};\\\", \\\"{x:1350,y:783,t:1527616821610};\\\", \\\"{x:1350,y:787,t:1527616821628};\\\", \\\"{x:1350,y:789,t:1527616821644};\\\", \\\"{x:1351,y:792,t:1527616821660};\\\", \\\"{x:1351,y:795,t:1527616821677};\\\", \\\"{x:1352,y:797,t:1527616821694};\\\", \\\"{x:1353,y:801,t:1527616821711};\\\", \\\"{x:1353,y:804,t:1527616821728};\\\", \\\"{x:1353,y:808,t:1527616821745};\\\", \\\"{x:1353,y:811,t:1527616821760};\\\", \\\"{x:1353,y:814,t:1527616821777};\\\", \\\"{x:1353,y:818,t:1527616821793};\\\", \\\"{x:1353,y:821,t:1527616821810};\\\", \\\"{x:1353,y:829,t:1527616821827};\\\", \\\"{x:1353,y:835,t:1527616821844};\\\", \\\"{x:1353,y:840,t:1527616821860};\\\", \\\"{x:1353,y:843,t:1527616821877};\\\", \\\"{x:1353,y:846,t:1527616821894};\\\", \\\"{x:1353,y:849,t:1527616821911};\\\", \\\"{x:1353,y:850,t:1527616821927};\\\", \\\"{x:1353,y:854,t:1527616821944};\\\", \\\"{x:1353,y:859,t:1527616821961};\\\", \\\"{x:1352,y:867,t:1527616821977};\\\", \\\"{x:1351,y:870,t:1527616821994};\\\", \\\"{x:1351,y:873,t:1527616822011};\\\", \\\"{x:1350,y:875,t:1527616822027};\\\", \\\"{x:1350,y:878,t:1527616822044};\\\", \\\"{x:1349,y:881,t:1527616822061};\\\", \\\"{x:1349,y:885,t:1527616822077};\\\", \\\"{x:1349,y:887,t:1527616822095};\\\", \\\"{x:1349,y:890,t:1527616822111};\\\", \\\"{x:1348,y:893,t:1527616822127};\\\", \\\"{x:1345,y:899,t:1527616822144};\\\", \\\"{x:1345,y:903,t:1527616822161};\\\", \\\"{x:1345,y:904,t:1527616822178};\\\", \\\"{x:1345,y:906,t:1527616822194};\\\", \\\"{x:1345,y:909,t:1527616822211};\\\", \\\"{x:1345,y:912,t:1527616822227};\\\", \\\"{x:1345,y:915,t:1527616822244};\\\", \\\"{x:1345,y:919,t:1527616822261};\\\", \\\"{x:1345,y:922,t:1527616822277};\\\", \\\"{x:1345,y:924,t:1527616822294};\\\", \\\"{x:1345,y:925,t:1527616822311};\\\", \\\"{x:1345,y:928,t:1527616822327};\\\", \\\"{x:1345,y:930,t:1527616822344};\\\", \\\"{x:1345,y:934,t:1527616822361};\\\", \\\"{x:1345,y:936,t:1527616822377};\\\", \\\"{x:1345,y:938,t:1527616822394};\\\", \\\"{x:1345,y:941,t:1527616822411};\\\", \\\"{x:1345,y:945,t:1527616822428};\\\", \\\"{x:1345,y:948,t:1527616822444};\\\", \\\"{x:1345,y:953,t:1527616822461};\\\", \\\"{x:1345,y:955,t:1527616822478};\\\", \\\"{x:1345,y:956,t:1527616822601};\\\", \\\"{x:1345,y:957,t:1527616822618};\\\", \\\"{x:1345,y:958,t:1527616822628};\\\", \\\"{x:1345,y:959,t:1527616822682};\\\", \\\"{x:1345,y:960,t:1527616822697};\\\", \\\"{x:1345,y:961,t:1527616822711};\\\", \\\"{x:1345,y:962,t:1527616822730};\\\", \\\"{x:1345,y:963,t:1527616822744};\\\", \\\"{x:1345,y:964,t:1527616822761};\\\", \\\"{x:1345,y:965,t:1527616822817};\\\", \\\"{x:1345,y:966,t:1527616822841};\\\", \\\"{x:1345,y:967,t:1527616825019};\\\", \\\"{x:1345,y:965,t:1527616829474};\\\", \\\"{x:1345,y:963,t:1527616829484};\\\", \\\"{x:1345,y:955,t:1527616829501};\\\", \\\"{x:1345,y:951,t:1527616829517};\\\", \\\"{x:1344,y:947,t:1527616829534};\\\", \\\"{x:1344,y:944,t:1527616829551};\\\", \\\"{x:1342,y:941,t:1527616829566};\\\", \\\"{x:1341,y:934,t:1527616829584};\\\", \\\"{x:1341,y:927,t:1527616829601};\\\", \\\"{x:1340,y:920,t:1527616829616};\\\", \\\"{x:1340,y:914,t:1527616829634};\\\", \\\"{x:1340,y:908,t:1527616829651};\\\", \\\"{x:1340,y:902,t:1527616829667};\\\", \\\"{x:1340,y:895,t:1527616829684};\\\", \\\"{x:1340,y:888,t:1527616829701};\\\", \\\"{x:1340,y:880,t:1527616829716};\\\", \\\"{x:1340,y:871,t:1527616829733};\\\", \\\"{x:1340,y:861,t:1527616829751};\\\", \\\"{x:1342,y:853,t:1527616829767};\\\", \\\"{x:1343,y:841,t:1527616829784};\\\", \\\"{x:1343,y:830,t:1527616829801};\\\", \\\"{x:1346,y:815,t:1527616829817};\\\", \\\"{x:1347,y:808,t:1527616829833};\\\", \\\"{x:1347,y:800,t:1527616829850};\\\", \\\"{x:1347,y:789,t:1527616829868};\\\", \\\"{x:1347,y:775,t:1527616829884};\\\", \\\"{x:1347,y:764,t:1527616829900};\\\", \\\"{x:1347,y:758,t:1527616829917};\\\", \\\"{x:1347,y:754,t:1527616829934};\\\", \\\"{x:1348,y:753,t:1527616829950};\\\", \\\"{x:1348,y:748,t:1527616829967};\\\", \\\"{x:1348,y:745,t:1527616829983};\\\", \\\"{x:1348,y:743,t:1527616830000};\\\", \\\"{x:1348,y:741,t:1527616830018};\\\", \\\"{x:1348,y:740,t:1527616830033};\\\", \\\"{x:1348,y:745,t:1527616830298};\\\", \\\"{x:1348,y:749,t:1527616830306};\\\", \\\"{x:1348,y:753,t:1527616830317};\\\", \\\"{x:1348,y:757,t:1527616830335};\\\", \\\"{x:1348,y:761,t:1527616830351};\\\", \\\"{x:1348,y:764,t:1527616830368};\\\", \\\"{x:1348,y:766,t:1527616830385};\\\", \\\"{x:1348,y:767,t:1527616830400};\\\", \\\"{x:1348,y:769,t:1527616830474};\\\", \\\"{x:1348,y:771,t:1527616830485};\\\", \\\"{x:1348,y:775,t:1527616830500};\\\", \\\"{x:1348,y:777,t:1527616830517};\\\", \\\"{x:1348,y:779,t:1527616830535};\\\", \\\"{x:1348,y:780,t:1527616830551};\\\", \\\"{x:1348,y:781,t:1527616830577};\\\", \\\"{x:1348,y:782,t:1527616830593};\\\", \\\"{x:1350,y:784,t:1527616830602};\\\", \\\"{x:1351,y:786,t:1527616830625};\\\", \\\"{x:1351,y:788,t:1527616830642};\\\", \\\"{x:1352,y:789,t:1527616830651};\\\", \\\"{x:1354,y:792,t:1527616830668};\\\", \\\"{x:1355,y:795,t:1527616830685};\\\", \\\"{x:1357,y:801,t:1527616830702};\\\", \\\"{x:1361,y:810,t:1527616830718};\\\", \\\"{x:1363,y:814,t:1527616830735};\\\", \\\"{x:1366,y:820,t:1527616830752};\\\", \\\"{x:1369,y:828,t:1527616830767};\\\", \\\"{x:1372,y:835,t:1527616830784};\\\", \\\"{x:1375,y:843,t:1527616830801};\\\", \\\"{x:1376,y:849,t:1527616830818};\\\", \\\"{x:1378,y:851,t:1527616830834};\\\", \\\"{x:1379,y:855,t:1527616830851};\\\", \\\"{x:1382,y:859,t:1527616830868};\\\", \\\"{x:1382,y:863,t:1527616830884};\\\", \\\"{x:1383,y:867,t:1527616830901};\\\", \\\"{x:1384,y:870,t:1527616830918};\\\", \\\"{x:1384,y:874,t:1527616830935};\\\", \\\"{x:1385,y:877,t:1527616830952};\\\", \\\"{x:1386,y:880,t:1527616830967};\\\", \\\"{x:1387,y:883,t:1527616830985};\\\", \\\"{x:1387,y:886,t:1527616831001};\\\", \\\"{x:1387,y:887,t:1527616831017};\\\", \\\"{x:1387,y:889,t:1527616831105};\\\", \\\"{x:1389,y:889,t:1527616831507};\\\", \\\"{x:1393,y:888,t:1527616831519};\\\", \\\"{x:1397,y:884,t:1527616831535};\\\", \\\"{x:1402,y:880,t:1527616831552};\\\", \\\"{x:1409,y:876,t:1527616831570};\\\", \\\"{x:1413,y:872,t:1527616831585};\\\", \\\"{x:1418,y:866,t:1527616831601};\\\", \\\"{x:1422,y:863,t:1527616831618};\\\", \\\"{x:1428,y:857,t:1527616831635};\\\", \\\"{x:1432,y:852,t:1527616831652};\\\", \\\"{x:1441,y:845,t:1527616831669};\\\", \\\"{x:1448,y:842,t:1527616831686};\\\", \\\"{x:1451,y:839,t:1527616831702};\\\", \\\"{x:1453,y:837,t:1527616831719};\\\", \\\"{x:1454,y:836,t:1527616831736};\\\", \\\"{x:1455,y:835,t:1527616831752};\\\", \\\"{x:1456,y:834,t:1527616831769};\\\", \\\"{x:1461,y:829,t:1527616831786};\\\", \\\"{x:1463,y:827,t:1527616831802};\\\", \\\"{x:1466,y:825,t:1527616831818};\\\", \\\"{x:1467,y:824,t:1527616831836};\\\", \\\"{x:1469,y:824,t:1527616832081};\\\", \\\"{x:1472,y:824,t:1527616832098};\\\", \\\"{x:1473,y:824,t:1527616832106};\\\", \\\"{x:1474,y:824,t:1527616832119};\\\", \\\"{x:1475,y:824,t:1527616832137};\\\", \\\"{x:1478,y:825,t:1527616832153};\\\", \\\"{x:1478,y:824,t:1527616834610};\\\", \\\"{x:1478,y:822,t:1527616834626};\\\", \\\"{x:1478,y:821,t:1527616834650};\\\", \\\"{x:1478,y:820,t:1527616834674};\\\", \\\"{x:1478,y:819,t:1527616834706};\\\", \\\"{x:1478,y:818,t:1527616834730};\\\", \\\"{x:1478,y:817,t:1527616834738};\\\", \\\"{x:1477,y:816,t:1527616834754};\\\", \\\"{x:1477,y:815,t:1527616834771};\\\", \\\"{x:1477,y:814,t:1527616834789};\\\", \\\"{x:1477,y:813,t:1527616834818};\\\", \\\"{x:1476,y:812,t:1527616834834};\\\", \\\"{x:1476,y:811,t:1527616834842};\\\", \\\"{x:1475,y:811,t:1527616834875};\\\", \\\"{x:1475,y:810,t:1527616835026};\\\", \\\"{x:1472,y:809,t:1527616835038};\\\", \\\"{x:1464,y:808,t:1527616835056};\\\", \\\"{x:1448,y:808,t:1527616835072};\\\", \\\"{x:1433,y:808,t:1527616835089};\\\", \\\"{x:1420,y:808,t:1527616835106};\\\", \\\"{x:1415,y:808,t:1527616835121};\\\", \\\"{x:1414,y:808,t:1527616835138};\\\", \\\"{x:1411,y:809,t:1527616835155};\\\", \\\"{x:1408,y:812,t:1527616835172};\\\", \\\"{x:1403,y:818,t:1527616835189};\\\", \\\"{x:1395,y:827,t:1527616835205};\\\", \\\"{x:1388,y:835,t:1527616835223};\\\", \\\"{x:1385,y:841,t:1527616835238};\\\", \\\"{x:1383,y:847,t:1527616835255};\\\", \\\"{x:1381,y:851,t:1527616835273};\\\", \\\"{x:1380,y:856,t:1527616835288};\\\", \\\"{x:1379,y:860,t:1527616835305};\\\", \\\"{x:1378,y:868,t:1527616835322};\\\", \\\"{x:1377,y:874,t:1527616835339};\\\", \\\"{x:1376,y:883,t:1527616835355};\\\", \\\"{x:1376,y:886,t:1527616835372};\\\", \\\"{x:1376,y:890,t:1527616835388};\\\", \\\"{x:1376,y:892,t:1527616835406};\\\", \\\"{x:1376,y:896,t:1527616835423};\\\", \\\"{x:1376,y:898,t:1527616835438};\\\", \\\"{x:1376,y:900,t:1527616835456};\\\", \\\"{x:1376,y:902,t:1527616835472};\\\", \\\"{x:1376,y:904,t:1527616835488};\\\", \\\"{x:1377,y:908,t:1527616835505};\\\", \\\"{x:1377,y:910,t:1527616835522};\\\", \\\"{x:1377,y:911,t:1527616835538};\\\", \\\"{x:1377,y:913,t:1527616835555};\\\", \\\"{x:1378,y:914,t:1527616835573};\\\", \\\"{x:1379,y:917,t:1527616835588};\\\", \\\"{x:1380,y:920,t:1527616835605};\\\", \\\"{x:1380,y:923,t:1527616835622};\\\", \\\"{x:1381,y:927,t:1527616835640};\\\", \\\"{x:1381,y:930,t:1527616835655};\\\", \\\"{x:1381,y:933,t:1527616835672};\\\", \\\"{x:1381,y:936,t:1527616835689};\\\", \\\"{x:1381,y:938,t:1527616835705};\\\", \\\"{x:1382,y:943,t:1527616835721};\\\", \\\"{x:1382,y:946,t:1527616835738};\\\", \\\"{x:1384,y:950,t:1527616835754};\\\", \\\"{x:1384,y:954,t:1527616835771};\\\", \\\"{x:1384,y:955,t:1527616835788};\\\", \\\"{x:1384,y:957,t:1527616835809};\\\", \\\"{x:1383,y:959,t:1527616835825};\\\", \\\"{x:1383,y:960,t:1527616835841};\\\", \\\"{x:1383,y:961,t:1527616835855};\\\", \\\"{x:1382,y:961,t:1527616835872};\\\", \\\"{x:1382,y:962,t:1527616835889};\\\", \\\"{x:1380,y:964,t:1527616835904};\\\", \\\"{x:1379,y:966,t:1527616835929};\\\", \\\"{x:1378,y:967,t:1527616835944};\\\", \\\"{x:1377,y:968,t:1527616835961};\\\", \\\"{x:1378,y:968,t:1527616836273};\\\", \\\"{x:1380,y:967,t:1527616836289};\\\", \\\"{x:1381,y:967,t:1527616836306};\\\", \\\"{x:1382,y:966,t:1527616836322};\\\", \\\"{x:1383,y:966,t:1527616836339};\\\", \\\"{x:1384,y:966,t:1527616836355};\\\", \\\"{x:1385,y:965,t:1527616836371};\\\", \\\"{x:1386,y:964,t:1527616836389};\\\", \\\"{x:1387,y:963,t:1527616836406};\\\", \\\"{x:1389,y:962,t:1527616836450};\\\", \\\"{x:1389,y:961,t:1527616836481};\\\", \\\"{x:1389,y:957,t:1527616836650};\\\", \\\"{x:1389,y:954,t:1527616836658};\\\", \\\"{x:1389,y:952,t:1527616836673};\\\", \\\"{x:1383,y:942,t:1527616836688};\\\", \\\"{x:1364,y:925,t:1527616836705};\\\", \\\"{x:1350,y:917,t:1527616836723};\\\", \\\"{x:1340,y:911,t:1527616836739};\\\", \\\"{x:1334,y:908,t:1527616836756};\\\", \\\"{x:1333,y:908,t:1527616836773};\\\", \\\"{x:1333,y:907,t:1527616836923};\\\", \\\"{x:1340,y:903,t:1527616836941};\\\", \\\"{x:1351,y:899,t:1527616836955};\\\", \\\"{x:1365,y:894,t:1527616836973};\\\", \\\"{x:1377,y:891,t:1527616836990};\\\", \\\"{x:1386,y:889,t:1527616837006};\\\", \\\"{x:1395,y:885,t:1527616837023};\\\", \\\"{x:1403,y:881,t:1527616837039};\\\", \\\"{x:1413,y:877,t:1527616837056};\\\", \\\"{x:1424,y:871,t:1527616837072};\\\", \\\"{x:1435,y:863,t:1527616837089};\\\", \\\"{x:1444,y:859,t:1527616837106};\\\", \\\"{x:1449,y:858,t:1527616837123};\\\", \\\"{x:1451,y:856,t:1527616837140};\\\", \\\"{x:1453,y:855,t:1527616837155};\\\", \\\"{x:1454,y:854,t:1527616837173};\\\", \\\"{x:1455,y:852,t:1527616837190};\\\", \\\"{x:1457,y:849,t:1527616837206};\\\", \\\"{x:1460,y:846,t:1527616837223};\\\", \\\"{x:1463,y:843,t:1527616837240};\\\", \\\"{x:1466,y:840,t:1527616837256};\\\", \\\"{x:1468,y:837,t:1527616837273};\\\", \\\"{x:1471,y:834,t:1527616837289};\\\", \\\"{x:1471,y:833,t:1527616837322};\\\", \\\"{x:1472,y:832,t:1527616837369};\\\", \\\"{x:1472,y:831,t:1527616837377};\\\", \\\"{x:1473,y:831,t:1527616837425};\\\", \\\"{x:1473,y:830,t:1527616837458};\\\", \\\"{x:1474,y:829,t:1527616837475};\\\", \\\"{x:1474,y:828,t:1527616837490};\\\", \\\"{x:1474,y:827,t:1527616837507};\\\", \\\"{x:1476,y:825,t:1527616837524};\\\", \\\"{x:1477,y:824,t:1527616837540};\\\", \\\"{x:1477,y:823,t:1527616837557};\\\", \\\"{x:1477,y:822,t:1527616837573};\\\", \\\"{x:1479,y:818,t:1527616837590};\\\", \\\"{x:1481,y:816,t:1527616837607};\\\", \\\"{x:1482,y:815,t:1527616837623};\\\", \\\"{x:1483,y:812,t:1527616837640};\\\", \\\"{x:1486,y:808,t:1527616837658};\\\", \\\"{x:1487,y:806,t:1527616837673};\\\", \\\"{x:1488,y:804,t:1527616837690};\\\", \\\"{x:1488,y:803,t:1527616837707};\\\", \\\"{x:1489,y:802,t:1527616837723};\\\", \\\"{x:1489,y:800,t:1527616837740};\\\", \\\"{x:1490,y:796,t:1527616837757};\\\", \\\"{x:1492,y:791,t:1527616837773};\\\", \\\"{x:1494,y:788,t:1527616837790};\\\", \\\"{x:1496,y:786,t:1527616837807};\\\", \\\"{x:1497,y:785,t:1527616837824};\\\", \\\"{x:1498,y:784,t:1527616837839};\\\", \\\"{x:1499,y:784,t:1527616838427};\\\", \\\"{x:1500,y:784,t:1527616838458};\\\", \\\"{x:1501,y:784,t:1527616838474};\\\", \\\"{x:1502,y:784,t:1527616838498};\\\", \\\"{x:1504,y:784,t:1527616838530};\\\", \\\"{x:1505,y:784,t:1527616838548};\\\", \\\"{x:1506,y:784,t:1527616838557};\\\", \\\"{x:1507,y:784,t:1527616838574};\\\", \\\"{x:1509,y:784,t:1527616838591};\\\", \\\"{x:1512,y:785,t:1527616838607};\\\", \\\"{x:1513,y:785,t:1527616838624};\\\", \\\"{x:1514,y:785,t:1527616838641};\\\", \\\"{x:1515,y:785,t:1527616838658};\\\", \\\"{x:1516,y:785,t:1527616838673};\\\", \\\"{x:1517,y:785,t:1527616838691};\\\", \\\"{x:1519,y:786,t:1527616838713};\\\", \\\"{x:1514,y:786,t:1527616838954};\\\", \\\"{x:1508,y:787,t:1527616838962};\\\", \\\"{x:1500,y:787,t:1527616838975};\\\", \\\"{x:1483,y:791,t:1527616838992};\\\", \\\"{x:1464,y:794,t:1527616839009};\\\", \\\"{x:1447,y:796,t:1527616839025};\\\", \\\"{x:1433,y:800,t:1527616839042};\\\", \\\"{x:1419,y:804,t:1527616839058};\\\", \\\"{x:1410,y:806,t:1527616839075};\\\", \\\"{x:1403,y:808,t:1527616839092};\\\", \\\"{x:1392,y:811,t:1527616839107};\\\", \\\"{x:1381,y:816,t:1527616839124};\\\", \\\"{x:1371,y:820,t:1527616839141};\\\", \\\"{x:1360,y:824,t:1527616839158};\\\", \\\"{x:1350,y:827,t:1527616839175};\\\", \\\"{x:1337,y:829,t:1527616839191};\\\", \\\"{x:1324,y:830,t:1527616839208};\\\", \\\"{x:1305,y:833,t:1527616839225};\\\", \\\"{x:1298,y:833,t:1527616839241};\\\", \\\"{x:1282,y:834,t:1527616839258};\\\", \\\"{x:1275,y:835,t:1527616839275};\\\", \\\"{x:1266,y:835,t:1527616839291};\\\", \\\"{x:1258,y:835,t:1527616839308};\\\", \\\"{x:1250,y:835,t:1527616839325};\\\", \\\"{x:1238,y:835,t:1527616839341};\\\", \\\"{x:1232,y:835,t:1527616839358};\\\", \\\"{x:1231,y:835,t:1527616839375};\\\", \\\"{x:1230,y:835,t:1527616839391};\\\", \\\"{x:1229,y:835,t:1527616839409};\\\", \\\"{x:1227,y:835,t:1527616839441};\\\", \\\"{x:1224,y:835,t:1527616839458};\\\", \\\"{x:1221,y:835,t:1527616839475};\\\", \\\"{x:1220,y:835,t:1527616839491};\\\", \\\"{x:1219,y:835,t:1527616839537};\\\", \\\"{x:1218,y:835,t:1527616839545};\\\", \\\"{x:1217,y:835,t:1527616839558};\\\", \\\"{x:1214,y:835,t:1527616839575};\\\", \\\"{x:1213,y:835,t:1527616839592};\\\", \\\"{x:1210,y:835,t:1527616839609};\\\", \\\"{x:1208,y:834,t:1527616839625};\\\", \\\"{x:1207,y:834,t:1527616839642};\\\", \\\"{x:1205,y:832,t:1527616839658};\\\", \\\"{x:1203,y:830,t:1527616839675};\\\", \\\"{x:1202,y:828,t:1527616839693};\\\", \\\"{x:1202,y:827,t:1527616839708};\\\", \\\"{x:1201,y:826,t:1527616839726};\\\", \\\"{x:1203,y:826,t:1527616840067};\\\", \\\"{x:1206,y:826,t:1527616840075};\\\", \\\"{x:1208,y:826,t:1527616840093};\\\", \\\"{x:1209,y:827,t:1527616840109};\\\", \\\"{x:1210,y:827,t:1527616840125};\\\", \\\"{x:1211,y:827,t:1527616840142};\\\", \\\"{x:1212,y:828,t:1527616840281};\\\", \\\"{x:1213,y:828,t:1527616840337};\\\", \\\"{x:1214,y:828,t:1527616840353};\\\", \\\"{x:1215,y:828,t:1527616840378};\\\", \\\"{x:1217,y:829,t:1527616840394};\\\", \\\"{x:1214,y:823,t:1527616843667};\\\", \\\"{x:1204,y:814,t:1527616843679};\\\", \\\"{x:1180,y:797,t:1527616843695};\\\", \\\"{x:1158,y:784,t:1527616843711};\\\", \\\"{x:1128,y:769,t:1527616843728};\\\", \\\"{x:1105,y:759,t:1527616843745};\\\", \\\"{x:1099,y:757,t:1527616843761};\\\", \\\"{x:1097,y:757,t:1527616843778};\\\", \\\"{x:1095,y:756,t:1527616843795};\\\", \\\"{x:1093,y:755,t:1527616843817};\\\", \\\"{x:1092,y:755,t:1527616843828};\\\", \\\"{x:1088,y:753,t:1527616843845};\\\", \\\"{x:1073,y:748,t:1527616843862};\\\", \\\"{x:1064,y:744,t:1527616843878};\\\", \\\"{x:1052,y:740,t:1527616843895};\\\", \\\"{x:1038,y:737,t:1527616843911};\\\", \\\"{x:1029,y:735,t:1527616843928};\\\", \\\"{x:1017,y:733,t:1527616843945};\\\", \\\"{x:1012,y:731,t:1527616843962};\\\", \\\"{x:1003,y:730,t:1527616843978};\\\", \\\"{x:992,y:730,t:1527616843996};\\\", \\\"{x:979,y:727,t:1527616844013};\\\", \\\"{x:963,y:724,t:1527616844028};\\\", \\\"{x:945,y:721,t:1527616844045};\\\", \\\"{x:926,y:718,t:1527616844062};\\\", \\\"{x:902,y:710,t:1527616844078};\\\", \\\"{x:879,y:703,t:1527616844096};\\\", \\\"{x:860,y:698,t:1527616844112};\\\", \\\"{x:837,y:691,t:1527616844129};\\\", \\\"{x:809,y:678,t:1527616844146};\\\", \\\"{x:798,y:670,t:1527616844161};\\\", \\\"{x:788,y:662,t:1527616844179};\\\", \\\"{x:773,y:650,t:1527616844196};\\\", \\\"{x:755,y:639,t:1527616844212};\\\", \\\"{x:736,y:629,t:1527616844229};\\\", \\\"{x:703,y:613,t:1527616844246};\\\", \\\"{x:655,y:596,t:1527616844262};\\\", \\\"{x:607,y:580,t:1527616844280};\\\", \\\"{x:575,y:570,t:1527616844295};\\\", \\\"{x:546,y:563,t:1527616844312};\\\", \\\"{x:505,y:556,t:1527616844329};\\\", \\\"{x:450,y:540,t:1527616844345};\\\", \\\"{x:389,y:524,t:1527616844362};\\\", \\\"{x:334,y:512,t:1527616844380};\\\", \\\"{x:287,y:499,t:1527616844396};\\\", \\\"{x:258,y:490,t:1527616844413};\\\", \\\"{x:244,y:485,t:1527616844429};\\\", \\\"{x:240,y:483,t:1527616844446};\\\", \\\"{x:239,y:482,t:1527616844462};\\\", \\\"{x:239,y:481,t:1527616844505};\\\", \\\"{x:239,y:479,t:1527616844545};\\\", \\\"{x:244,y:476,t:1527616844562};\\\", \\\"{x:253,y:474,t:1527616844579};\\\", \\\"{x:272,y:471,t:1527616844595};\\\", \\\"{x:309,y:467,t:1527616844613};\\\", \\\"{x:327,y:467,t:1527616844629};\\\", \\\"{x:342,y:467,t:1527616844645};\\\", \\\"{x:351,y:470,t:1527616844662};\\\", \\\"{x:353,y:470,t:1527616844680};\\\", \\\"{x:355,y:471,t:1527616844695};\\\", \\\"{x:355,y:472,t:1527616844786};\\\", \\\"{x:352,y:474,t:1527616844795};\\\", \\\"{x:332,y:479,t:1527616844812};\\\", \\\"{x:306,y:483,t:1527616844829};\\\", \\\"{x:282,y:485,t:1527616844845};\\\", \\\"{x:263,y:485,t:1527616844862};\\\", \\\"{x:250,y:487,t:1527616844880};\\\", \\\"{x:239,y:487,t:1527616844895};\\\", \\\"{x:224,y:487,t:1527616844913};\\\", \\\"{x:214,y:487,t:1527616844929};\\\", \\\"{x:208,y:487,t:1527616844947};\\\", \\\"{x:207,y:487,t:1527616844963};\\\", \\\"{x:206,y:487,t:1527616844980};\\\", \\\"{x:205,y:488,t:1527616845009};\\\", \\\"{x:203,y:488,t:1527616845026};\\\", \\\"{x:201,y:489,t:1527616845034};\\\", \\\"{x:199,y:491,t:1527616845046};\\\", \\\"{x:193,y:493,t:1527616845063};\\\", \\\"{x:189,y:496,t:1527616845081};\\\", \\\"{x:184,y:498,t:1527616845097};\\\", \\\"{x:180,y:500,t:1527616845113};\\\", \\\"{x:178,y:500,t:1527616845129};\\\", \\\"{x:176,y:500,t:1527616845153};\\\", \\\"{x:176,y:501,t:1527616845163};\\\", \\\"{x:175,y:502,t:1527616845179};\\\", \\\"{x:173,y:502,t:1527616845197};\\\", \\\"{x:172,y:503,t:1527616845225};\\\", \\\"{x:170,y:503,t:1527616845250};\\\", \\\"{x:169,y:503,t:1527616845274};\\\", \\\"{x:170,y:509,t:1527616845529};\\\", \\\"{x:193,y:526,t:1527616845548};\\\", \\\"{x:233,y:555,t:1527616845563};\\\", \\\"{x:286,y:593,t:1527616845580};\\\", \\\"{x:347,y:634,t:1527616845597};\\\", \\\"{x:409,y:678,t:1527616845613};\\\", \\\"{x:451,y:709,t:1527616845631};\\\", \\\"{x:485,y:732,t:1527616845646};\\\", \\\"{x:501,y:743,t:1527616845663};\\\", \\\"{x:515,y:750,t:1527616845680};\\\", \\\"{x:522,y:755,t:1527616845697};\\\", \\\"{x:527,y:758,t:1527616845713};\\\", \\\"{x:529,y:759,t:1527616845730};\\\", \\\"{x:529,y:760,t:1527616845746};\\\", \\\"{x:531,y:761,t:1527616845763};\\\", \\\"{x:532,y:762,t:1527616845834};\\\", \\\"{x:532,y:759,t:1527616845921};\\\", \\\"{x:532,y:752,t:1527616845931};\\\", \\\"{x:532,y:746,t:1527616845947};\\\", \\\"{x:532,y:742,t:1527616845963};\\\", \\\"{x:532,y:741,t:1527616845980};\\\", \\\"{x:532,y:738,t:1527616846818};\\\", \\\"{x:535,y:736,t:1527616846832};\\\", \\\"{x:540,y:732,t:1527616846848};\\\", \\\"{x:544,y:729,t:1527616846865};\\\", \\\"{x:548,y:726,t:1527616846881};\\\", \\\"{x:550,y:725,t:1527616846898};\\\", \\\"{x:553,y:723,t:1527616846915};\\\", \\\"{x:559,y:720,t:1527616846931};\\\", \\\"{x:568,y:715,t:1527616846947};\\\", \\\"{x:578,y:709,t:1527616846964};\\\", \\\"{x:592,y:701,t:1527616846982};\\\", \\\"{x:607,y:693,t:1527616846997};\\\", \\\"{x:623,y:683,t:1527616847015};\\\", \\\"{x:646,y:672,t:1527616847031};\\\", \\\"{x:670,y:659,t:1527616847048};\\\", \\\"{x:701,y:645,t:1527616847064};\\\", \\\"{x:737,y:629,t:1527616847081};\\\", \\\"{x:767,y:617,t:1527616847097};\\\", \\\"{x:789,y:611,t:1527616847114};\\\", \\\"{x:805,y:606,t:1527616847132};\\\", \\\"{x:810,y:605,t:1527616847149};\\\" ] }, { \\\"rt\\\": 12515, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 299659, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-J -J -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:774,y:593,t:1527616847436};\\\", \\\"{x:773,y:592,t:1527616847497};\\\", \\\"{x:772,y:592,t:1527616847513};\\\", \\\"{x:771,y:591,t:1527616847618};\\\", \\\"{x:771,y:589,t:1527616847630};\\\", \\\"{x:770,y:584,t:1527616847648};\\\", \\\"{x:770,y:576,t:1527616847665};\\\", \\\"{x:770,y:571,t:1527616847681};\\\", \\\"{x:770,y:567,t:1527616847698};\\\", \\\"{x:775,y:561,t:1527616847715};\\\", \\\"{x:780,y:556,t:1527616847731};\\\", \\\"{x:787,y:550,t:1527616847749};\\\", \\\"{x:797,y:545,t:1527616847765};\\\", \\\"{x:809,y:537,t:1527616847781};\\\", \\\"{x:821,y:530,t:1527616847798};\\\", \\\"{x:834,y:524,t:1527616847816};\\\", \\\"{x:845,y:517,t:1527616847832};\\\", \\\"{x:853,y:515,t:1527616847848};\\\", \\\"{x:860,y:512,t:1527616847865};\\\", \\\"{x:856,y:513,t:1527616848007};\\\", \\\"{x:847,y:517,t:1527616848015};\\\", \\\"{x:821,y:526,t:1527616848035};\\\", \\\"{x:813,y:530,t:1527616848048};\\\", \\\"{x:787,y:537,t:1527616848064};\\\", \\\"{x:764,y:542,t:1527616848082};\\\", \\\"{x:738,y:545,t:1527616848098};\\\", \\\"{x:699,y:545,t:1527616848116};\\\", \\\"{x:657,y:545,t:1527616848132};\\\", \\\"{x:612,y:545,t:1527616848148};\\\", \\\"{x:572,y:544,t:1527616848166};\\\", \\\"{x:530,y:538,t:1527616848182};\\\", \\\"{x:482,y:531,t:1527616848198};\\\", \\\"{x:457,y:529,t:1527616848215};\\\", \\\"{x:431,y:523,t:1527616848232};\\\", \\\"{x:398,y:513,t:1527616848250};\\\", \\\"{x:387,y:509,t:1527616848265};\\\", \\\"{x:382,y:507,t:1527616848282};\\\", \\\"{x:379,y:505,t:1527616848298};\\\", \\\"{x:378,y:505,t:1527616848316};\\\", \\\"{x:377,y:504,t:1527616848361};\\\", \\\"{x:376,y:504,t:1527616848369};\\\", \\\"{x:375,y:502,t:1527616848383};\\\", \\\"{x:374,y:500,t:1527616848398};\\\", \\\"{x:373,y:498,t:1527616848415};\\\", \\\"{x:372,y:494,t:1527616848433};\\\", \\\"{x:370,y:491,t:1527616848449};\\\", \\\"{x:370,y:490,t:1527616848465};\\\", \\\"{x:373,y:484,t:1527616848483};\\\", \\\"{x:384,y:478,t:1527616848499};\\\", \\\"{x:400,y:472,t:1527616848515};\\\", \\\"{x:412,y:467,t:1527616848533};\\\", \\\"{x:424,y:465,t:1527616848549};\\\", \\\"{x:440,y:464,t:1527616848566};\\\", \\\"{x:453,y:464,t:1527616848582};\\\", \\\"{x:466,y:464,t:1527616848600};\\\", \\\"{x:474,y:464,t:1527616848615};\\\", \\\"{x:480,y:464,t:1527616848632};\\\", \\\"{x:485,y:464,t:1527616848648};\\\", \\\"{x:486,y:464,t:1527616848665};\\\", \\\"{x:489,y:464,t:1527616849036};\\\", \\\"{x:497,y:464,t:1527616849049};\\\", \\\"{x:510,y:466,t:1527616849066};\\\", \\\"{x:519,y:468,t:1527616849083};\\\", \\\"{x:525,y:470,t:1527616849100};\\\", \\\"{x:528,y:471,t:1527616849116};\\\", \\\"{x:529,y:471,t:1527616849132};\\\", \\\"{x:531,y:472,t:1527616849149};\\\", \\\"{x:532,y:473,t:1527616849169};\\\", \\\"{x:533,y:473,t:1527616849182};\\\", \\\"{x:536,y:473,t:1527616849200};\\\", \\\"{x:540,y:476,t:1527616849216};\\\", \\\"{x:551,y:481,t:1527616849233};\\\", \\\"{x:566,y:485,t:1527616849249};\\\", \\\"{x:591,y:490,t:1527616849267};\\\", \\\"{x:621,y:496,t:1527616849284};\\\", \\\"{x:646,y:499,t:1527616849300};\\\", \\\"{x:670,y:503,t:1527616849316};\\\", \\\"{x:687,y:505,t:1527616849332};\\\", \\\"{x:696,y:505,t:1527616849349};\\\", \\\"{x:697,y:505,t:1527616849366};\\\", \\\"{x:696,y:505,t:1527616849554};\\\", \\\"{x:694,y:504,t:1527616849567};\\\", \\\"{x:692,y:503,t:1527616849583};\\\", \\\"{x:689,y:501,t:1527616849599};\\\", \\\"{x:686,y:499,t:1527616849617};\\\", \\\"{x:680,y:496,t:1527616849634};\\\", \\\"{x:675,y:495,t:1527616849649};\\\", \\\"{x:670,y:492,t:1527616849666};\\\", \\\"{x:667,y:492,t:1527616849684};\\\", \\\"{x:665,y:491,t:1527616849699};\\\", \\\"{x:665,y:490,t:1527616849922};\\\", \\\"{x:665,y:489,t:1527616849937};\\\", \\\"{x:666,y:488,t:1527616849950};\\\", \\\"{x:671,y:485,t:1527616849968};\\\", \\\"{x:674,y:484,t:1527616849984};\\\", \\\"{x:677,y:481,t:1527616849998};\\\", \\\"{x:678,y:481,t:1527616850015};\\\", \\\"{x:679,y:479,t:1527616850031};\\\", \\\"{x:680,y:478,t:1527616850048};\\\", \\\"{x:683,y:474,t:1527616850065};\\\", \\\"{x:686,y:470,t:1527616850081};\\\", \\\"{x:694,y:466,t:1527616850099};\\\", \\\"{x:699,y:462,t:1527616850115};\\\", \\\"{x:705,y:459,t:1527616850131};\\\", \\\"{x:710,y:457,t:1527616850149};\\\", \\\"{x:714,y:455,t:1527616850164};\\\", \\\"{x:717,y:454,t:1527616850181};\\\", \\\"{x:720,y:454,t:1527616850198};\\\", \\\"{x:721,y:454,t:1527616850214};\\\", \\\"{x:723,y:452,t:1527616850232};\\\", \\\"{x:726,y:452,t:1527616850249};\\\", \\\"{x:730,y:452,t:1527616850265};\\\", \\\"{x:742,y:452,t:1527616850281};\\\", \\\"{x:758,y:457,t:1527616850298};\\\", \\\"{x:775,y:462,t:1527616850314};\\\", \\\"{x:795,y:468,t:1527616850331};\\\", \\\"{x:815,y:475,t:1527616850348};\\\", \\\"{x:829,y:479,t:1527616850364};\\\", \\\"{x:840,y:483,t:1527616850381};\\\", \\\"{x:845,y:485,t:1527616850398};\\\", \\\"{x:850,y:488,t:1527616850415};\\\", \\\"{x:856,y:491,t:1527616850431};\\\", \\\"{x:867,y:497,t:1527616850451};\\\", \\\"{x:879,y:502,t:1527616850468};\\\", \\\"{x:894,y:508,t:1527616850483};\\\", \\\"{x:910,y:515,t:1527616850500};\\\", \\\"{x:927,y:522,t:1527616850518};\\\", \\\"{x:948,y:529,t:1527616850535};\\\", \\\"{x:968,y:539,t:1527616850551};\\\", \\\"{x:985,y:545,t:1527616850567};\\\", \\\"{x:1004,y:551,t:1527616850584};\\\", \\\"{x:1019,y:556,t:1527616850600};\\\", \\\"{x:1043,y:563,t:1527616850617};\\\", \\\"{x:1054,y:567,t:1527616850634};\\\", \\\"{x:1063,y:569,t:1527616850650};\\\", \\\"{x:1072,y:571,t:1527616850668};\\\", \\\"{x:1081,y:575,t:1527616850685};\\\", \\\"{x:1090,y:577,t:1527616850701};\\\", \\\"{x:1099,y:578,t:1527616850718};\\\", \\\"{x:1112,y:579,t:1527616850735};\\\", \\\"{x:1123,y:581,t:1527616850750};\\\", \\\"{x:1133,y:583,t:1527616850767};\\\", \\\"{x:1149,y:584,t:1527616850784};\\\", \\\"{x:1161,y:586,t:1527616850800};\\\", \\\"{x:1181,y:589,t:1527616850818};\\\", \\\"{x:1191,y:590,t:1527616850835};\\\", \\\"{x:1203,y:593,t:1527616850850};\\\", \\\"{x:1214,y:594,t:1527616850868};\\\", \\\"{x:1224,y:595,t:1527616850884};\\\", \\\"{x:1234,y:598,t:1527616850900};\\\", \\\"{x:1246,y:598,t:1527616850918};\\\", \\\"{x:1251,y:598,t:1527616850935};\\\", \\\"{x:1255,y:598,t:1527616850951};\\\", \\\"{x:1260,y:598,t:1527616850968};\\\", \\\"{x:1264,y:598,t:1527616850985};\\\", \\\"{x:1269,y:598,t:1527616851002};\\\", \\\"{x:1272,y:598,t:1527616851017};\\\", \\\"{x:1276,y:599,t:1527616851034};\\\", \\\"{x:1279,y:600,t:1527616851051};\\\", \\\"{x:1283,y:600,t:1527616851068};\\\", \\\"{x:1286,y:601,t:1527616851084};\\\", \\\"{x:1288,y:601,t:1527616851101};\\\", \\\"{x:1289,y:601,t:1527616851117};\\\", \\\"{x:1290,y:602,t:1527616851137};\\\", \\\"{x:1291,y:602,t:1527616851242};\\\", \\\"{x:1291,y:605,t:1527616851257};\\\", \\\"{x:1291,y:609,t:1527616851267};\\\", \\\"{x:1289,y:618,t:1527616851285};\\\", \\\"{x:1287,y:627,t:1527616851302};\\\", \\\"{x:1285,y:634,t:1527616851318};\\\", \\\"{x:1285,y:636,t:1527616851335};\\\", \\\"{x:1285,y:639,t:1527616851352};\\\", \\\"{x:1284,y:639,t:1527616851369};\\\", \\\"{x:1284,y:640,t:1527616851384};\\\", \\\"{x:1284,y:642,t:1527616851402};\\\", \\\"{x:1284,y:644,t:1527616851418};\\\", \\\"{x:1284,y:650,t:1527616851435};\\\", \\\"{x:1284,y:658,t:1527616851452};\\\", \\\"{x:1286,y:664,t:1527616851469};\\\", \\\"{x:1288,y:671,t:1527616851485};\\\", \\\"{x:1289,y:675,t:1527616851502};\\\", \\\"{x:1290,y:679,t:1527616851519};\\\", \\\"{x:1292,y:682,t:1527616851535};\\\", \\\"{x:1293,y:686,t:1527616851552};\\\", \\\"{x:1296,y:691,t:1527616851569};\\\", \\\"{x:1300,y:696,t:1527616851586};\\\", \\\"{x:1304,y:701,t:1527616851602};\\\", \\\"{x:1306,y:704,t:1527616851619};\\\", \\\"{x:1308,y:706,t:1527616851635};\\\", \\\"{x:1313,y:710,t:1527616851651};\\\", \\\"{x:1319,y:714,t:1527616851669};\\\", \\\"{x:1328,y:720,t:1527616851685};\\\", \\\"{x:1338,y:725,t:1527616851702};\\\", \\\"{x:1342,y:728,t:1527616851718};\\\", \\\"{x:1349,y:730,t:1527616851735};\\\", \\\"{x:1353,y:731,t:1527616851752};\\\", \\\"{x:1361,y:733,t:1527616851768};\\\", \\\"{x:1374,y:736,t:1527616851785};\\\", \\\"{x:1387,y:738,t:1527616851801};\\\", \\\"{x:1401,y:739,t:1527616851819};\\\", \\\"{x:1415,y:742,t:1527616851836};\\\", \\\"{x:1425,y:742,t:1527616851852};\\\", \\\"{x:1432,y:742,t:1527616851869};\\\", \\\"{x:1435,y:742,t:1527616851886};\\\", \\\"{x:1436,y:742,t:1527616851905};\\\", \\\"{x:1437,y:742,t:1527616851922};\\\", \\\"{x:1438,y:742,t:1527616851938};\\\", \\\"{x:1439,y:741,t:1527616851954};\\\", \\\"{x:1440,y:740,t:1527616851969};\\\", \\\"{x:1440,y:739,t:1527616851986};\\\", \\\"{x:1440,y:736,t:1527616852001};\\\", \\\"{x:1440,y:733,t:1527616852019};\\\", \\\"{x:1440,y:729,t:1527616852036};\\\", \\\"{x:1439,y:727,t:1527616852051};\\\", \\\"{x:1439,y:726,t:1527616852069};\\\", \\\"{x:1437,y:724,t:1527616852086};\\\", \\\"{x:1435,y:723,t:1527616852102};\\\", \\\"{x:1434,y:722,t:1527616852118};\\\", \\\"{x:1432,y:722,t:1527616852136};\\\", \\\"{x:1426,y:722,t:1527616852152};\\\", \\\"{x:1420,y:722,t:1527616852169};\\\", \\\"{x:1408,y:722,t:1527616852185};\\\", \\\"{x:1400,y:722,t:1527616852203};\\\", \\\"{x:1393,y:723,t:1527616852219};\\\", \\\"{x:1391,y:723,t:1527616852236};\\\", \\\"{x:1389,y:724,t:1527616852253};\\\", \\\"{x:1387,y:725,t:1527616852269};\\\", \\\"{x:1384,y:728,t:1527616852286};\\\", \\\"{x:1379,y:732,t:1527616852303};\\\", \\\"{x:1375,y:736,t:1527616852319};\\\", \\\"{x:1373,y:739,t:1527616852336};\\\", \\\"{x:1371,y:740,t:1527616852353};\\\", \\\"{x:1370,y:742,t:1527616852369};\\\", \\\"{x:1370,y:745,t:1527616852386};\\\", \\\"{x:1369,y:748,t:1527616852403};\\\", \\\"{x:1369,y:752,t:1527616852419};\\\", \\\"{x:1369,y:757,t:1527616852436};\\\", \\\"{x:1369,y:762,t:1527616852453};\\\", \\\"{x:1368,y:767,t:1527616852468};\\\", \\\"{x:1367,y:769,t:1527616852485};\\\", \\\"{x:1367,y:771,t:1527616852502};\\\", \\\"{x:1367,y:772,t:1527616852518};\\\", \\\"{x:1367,y:774,t:1527616852536};\\\", \\\"{x:1365,y:777,t:1527616852553};\\\", \\\"{x:1365,y:780,t:1527616852569};\\\", \\\"{x:1363,y:782,t:1527616852585};\\\", \\\"{x:1360,y:786,t:1527616852603};\\\", \\\"{x:1357,y:788,t:1527616852620};\\\", \\\"{x:1353,y:790,t:1527616852636};\\\", \\\"{x:1346,y:793,t:1527616852653};\\\", \\\"{x:1341,y:795,t:1527616852669};\\\", \\\"{x:1332,y:795,t:1527616852685};\\\", \\\"{x:1322,y:797,t:1527616852703};\\\", \\\"{x:1316,y:798,t:1527616852719};\\\", \\\"{x:1313,y:799,t:1527616852736};\\\", \\\"{x:1310,y:799,t:1527616852753};\\\", \\\"{x:1308,y:800,t:1527616852769};\\\", \\\"{x:1307,y:800,t:1527616852785};\\\", \\\"{x:1304,y:802,t:1527616852803};\\\", \\\"{x:1303,y:802,t:1527616852819};\\\", \\\"{x:1301,y:804,t:1527616852836};\\\", \\\"{x:1300,y:804,t:1527616852853};\\\", \\\"{x:1301,y:804,t:1527616853010};\\\", \\\"{x:1304,y:802,t:1527616853020};\\\", \\\"{x:1307,y:798,t:1527616853037};\\\", \\\"{x:1310,y:795,t:1527616853053};\\\", \\\"{x:1314,y:791,t:1527616853070};\\\", \\\"{x:1319,y:788,t:1527616853087};\\\", \\\"{x:1324,y:784,t:1527616853103};\\\", \\\"{x:1329,y:780,t:1527616853119};\\\", \\\"{x:1332,y:777,t:1527616853136};\\\", \\\"{x:1333,y:776,t:1527616853153};\\\", \\\"{x:1334,y:773,t:1527616853169};\\\", \\\"{x:1334,y:772,t:1527616853233};\\\", \\\"{x:1334,y:771,t:1527616853241};\\\", \\\"{x:1333,y:771,t:1527616853252};\\\", \\\"{x:1328,y:769,t:1527616853269};\\\", \\\"{x:1323,y:769,t:1527616853286};\\\", \\\"{x:1314,y:769,t:1527616853303};\\\", \\\"{x:1304,y:769,t:1527616853320};\\\", \\\"{x:1289,y:771,t:1527616853337};\\\", \\\"{x:1276,y:776,t:1527616853352};\\\", \\\"{x:1259,y:783,t:1527616853369};\\\", \\\"{x:1247,y:788,t:1527616853386};\\\", \\\"{x:1239,y:794,t:1527616853404};\\\", \\\"{x:1235,y:798,t:1527616853419};\\\", \\\"{x:1231,y:801,t:1527616853437};\\\", \\\"{x:1227,y:806,t:1527616853453};\\\", \\\"{x:1223,y:812,t:1527616853469};\\\", \\\"{x:1220,y:815,t:1527616853486};\\\", \\\"{x:1217,y:820,t:1527616853503};\\\", \\\"{x:1216,y:823,t:1527616853519};\\\", \\\"{x:1215,y:826,t:1527616853537};\\\", \\\"{x:1215,y:829,t:1527616853553};\\\", \\\"{x:1215,y:831,t:1527616853570};\\\", \\\"{x:1215,y:832,t:1527616853586};\\\", \\\"{x:1215,y:834,t:1527616853603};\\\", \\\"{x:1215,y:835,t:1527616853619};\\\", \\\"{x:1215,y:836,t:1527616853787};\\\", \\\"{x:1214,y:836,t:1527616853804};\\\", \\\"{x:1213,y:836,t:1527616853822};\\\", \\\"{x:1211,y:836,t:1527616853838};\\\", \\\"{x:1210,y:836,t:1527616853891};\\\", \\\"{x:1210,y:835,t:1527616854010};\\\", \\\"{x:1210,y:833,t:1527616854050};\\\", \\\"{x:1210,y:832,t:1527616854071};\\\", \\\"{x:1210,y:830,t:1527616854090};\\\", \\\"{x:1210,y:829,t:1527616854122};\\\", \\\"{x:1211,y:829,t:1527616855313};\\\", \\\"{x:1212,y:829,t:1527616855378};\\\", \\\"{x:1211,y:829,t:1527616855810};\\\", \\\"{x:1209,y:829,t:1527616855826};\\\", \\\"{x:1208,y:829,t:1527616855843};\\\", \\\"{x:1207,y:829,t:1527616855858};\\\", \\\"{x:1206,y:829,t:1527616855890};\\\", \\\"{x:1205,y:829,t:1527616855914};\\\", \\\"{x:1204,y:829,t:1527616855946};\\\", \\\"{x:1203,y:828,t:1527616855969};\\\", \\\"{x:1201,y:828,t:1527616855986};\\\", \\\"{x:1199,y:828,t:1527616856002};\\\", \\\"{x:1198,y:828,t:1527616856010};\\\", \\\"{x:1197,y:828,t:1527616856022};\\\", \\\"{x:1194,y:827,t:1527616856039};\\\", \\\"{x:1190,y:827,t:1527616856055};\\\", \\\"{x:1185,y:826,t:1527616856072};\\\", \\\"{x:1179,y:825,t:1527616856088};\\\", \\\"{x:1172,y:825,t:1527616856105};\\\", \\\"{x:1165,y:824,t:1527616856121};\\\", \\\"{x:1161,y:824,t:1527616856138};\\\", \\\"{x:1158,y:823,t:1527616856155};\\\", \\\"{x:1157,y:823,t:1527616856171};\\\", \\\"{x:1156,y:822,t:1527616856189};\\\", \\\"{x:1156,y:819,t:1527616857938};\\\", \\\"{x:1156,y:815,t:1527616857945};\\\", \\\"{x:1157,y:810,t:1527616857957};\\\", \\\"{x:1163,y:802,t:1527616857974};\\\", \\\"{x:1167,y:793,t:1527616857990};\\\", \\\"{x:1169,y:788,t:1527616858006};\\\", \\\"{x:1171,y:783,t:1527616858024};\\\", \\\"{x:1173,y:776,t:1527616858041};\\\", \\\"{x:1175,y:769,t:1527616858057};\\\", \\\"{x:1176,y:765,t:1527616858074};\\\", \\\"{x:1177,y:761,t:1527616858091};\\\", \\\"{x:1177,y:760,t:1527616858107};\\\", \\\"{x:1177,y:759,t:1527616858193};\\\", \\\"{x:1175,y:757,t:1527616858208};\\\", \\\"{x:1160,y:751,t:1527616858224};\\\", \\\"{x:1106,y:733,t:1527616858241};\\\", \\\"{x:1050,y:716,t:1527616858258};\\\", \\\"{x:987,y:699,t:1527616858275};\\\", \\\"{x:896,y:678,t:1527616858292};\\\", \\\"{x:810,y:655,t:1527616858307};\\\", \\\"{x:734,y:637,t:1527616858324};\\\", \\\"{x:645,y:614,t:1527616858341};\\\", \\\"{x:553,y:584,t:1527616858359};\\\", \\\"{x:402,y:548,t:1527616858390};\\\", \\\"{x:365,y:537,t:1527616858406};\\\", \\\"{x:341,y:527,t:1527616858424};\\\", \\\"{x:306,y:516,t:1527616858441};\\\", \\\"{x:283,y:508,t:1527616858456};\\\", \\\"{x:273,y:502,t:1527616858474};\\\", \\\"{x:273,y:501,t:1527616858496};\\\", \\\"{x:271,y:501,t:1527616858507};\\\", \\\"{x:269,y:500,t:1527616858523};\\\", \\\"{x:262,y:497,t:1527616858540};\\\", \\\"{x:250,y:493,t:1527616858557};\\\", \\\"{x:237,y:489,t:1527616858573};\\\", \\\"{x:227,y:488,t:1527616858590};\\\", \\\"{x:219,y:486,t:1527616858607};\\\", \\\"{x:215,y:485,t:1527616858623};\\\", \\\"{x:212,y:483,t:1527616858640};\\\", \\\"{x:209,y:483,t:1527616858656};\\\", \\\"{x:206,y:483,t:1527616858674};\\\", \\\"{x:204,y:483,t:1527616858690};\\\", \\\"{x:202,y:483,t:1527616858707};\\\", \\\"{x:199,y:483,t:1527616858724};\\\", \\\"{x:196,y:483,t:1527616858740};\\\", \\\"{x:189,y:483,t:1527616858757};\\\", \\\"{x:183,y:483,t:1527616858774};\\\", \\\"{x:180,y:485,t:1527616858791};\\\", \\\"{x:176,y:486,t:1527616858807};\\\", \\\"{x:170,y:488,t:1527616858825};\\\", \\\"{x:161,y:492,t:1527616858841};\\\", \\\"{x:156,y:494,t:1527616858857};\\\", \\\"{x:154,y:495,t:1527616858873};\\\", \\\"{x:154,y:496,t:1527616859200};\\\", \\\"{x:159,y:504,t:1527616859209};\\\", \\\"{x:180,y:522,t:1527616859225};\\\", \\\"{x:208,y:541,t:1527616859241};\\\", \\\"{x:247,y:566,t:1527616859258};\\\", \\\"{x:292,y:597,t:1527616859274};\\\", \\\"{x:340,y:623,t:1527616859291};\\\", \\\"{x:373,y:642,t:1527616859308};\\\", \\\"{x:395,y:654,t:1527616859325};\\\", \\\"{x:413,y:664,t:1527616859341};\\\", \\\"{x:423,y:669,t:1527616859358};\\\", \\\"{x:430,y:672,t:1527616859374};\\\", \\\"{x:435,y:675,t:1527616859391};\\\", \\\"{x:439,y:677,t:1527616859407};\\\", \\\"{x:442,y:678,t:1527616859424};\\\", \\\"{x:445,y:680,t:1527616859441};\\\", \\\"{x:448,y:681,t:1527616859458};\\\", \\\"{x:450,y:682,t:1527616859474};\\\", \\\"{x:452,y:684,t:1527616859490};\\\", \\\"{x:457,y:689,t:1527616859507};\\\", \\\"{x:470,y:702,t:1527616859524};\\\", \\\"{x:487,y:714,t:1527616859540};\\\", \\\"{x:504,y:726,t:1527616859558};\\\", \\\"{x:514,y:734,t:1527616859575};\\\", \\\"{x:520,y:736,t:1527616859590};\\\", \\\"{x:523,y:738,t:1527616859608};\\\", \\\"{x:526,y:739,t:1527616859625};\\\", \\\"{x:526,y:740,t:1527616859697};\\\", \\\"{x:528,y:741,t:1527616859708};\\\", \\\"{x:532,y:743,t:1527616859725};\\\", \\\"{x:534,y:745,t:1527616859741};\\\", \\\"{x:535,y:745,t:1527616860221};\\\", \\\"{x:535,y:744,t:1527616860261};\\\", \\\"{x:536,y:741,t:1527616860270};\\\", \\\"{x:537,y:739,t:1527616860286};\\\", \\\"{x:538,y:736,t:1527616860302};\\\", \\\"{x:538,y:734,t:1527616860319};\\\", \\\"{x:539,y:731,t:1527616860336};\\\", \\\"{x:540,y:730,t:1527616860357};\\\", \\\"{x:540,y:729,t:1527616860369};\\\", \\\"{x:541,y:728,t:1527616860387};\\\", \\\"{x:543,y:727,t:1527616860403};\\\", \\\"{x:543,y:725,t:1527616860420};\\\", \\\"{x:545,y:723,t:1527616860437};\\\", \\\"{x:545,y:722,t:1527616860453};\\\", \\\"{x:547,y:720,t:1527616860470};\\\", \\\"{x:547,y:719,t:1527616860486};\\\", \\\"{x:550,y:717,t:1527616860503};\\\", \\\"{x:551,y:715,t:1527616860520};\\\", \\\"{x:551,y:712,t:1527616860537};\\\", \\\"{x:553,y:710,t:1527616860553};\\\", \\\"{x:555,y:708,t:1527616860569};\\\", \\\"{x:556,y:706,t:1527616860587};\\\", \\\"{x:557,y:706,t:1527616860604};\\\", \\\"{x:557,y:704,t:1527616860619};\\\", \\\"{x:558,y:702,t:1527616860637};\\\", \\\"{x:559,y:700,t:1527616860653};\\\", \\\"{x:560,y:698,t:1527616860669};\\\", \\\"{x:560,y:697,t:1527616860687};\\\", \\\"{x:561,y:695,t:1527616860704};\\\", \\\"{x:562,y:694,t:1527616860720};\\\", \\\"{x:562,y:692,t:1527616860736};\\\", \\\"{x:562,y:691,t:1527616860754};\\\", \\\"{x:563,y:688,t:1527616860769};\\\", \\\"{x:564,y:686,t:1527616860789};\\\", \\\"{x:564,y:684,t:1527616860806};\\\", \\\"{x:564,y:683,t:1527616860822};\\\", \\\"{x:565,y:682,t:1527616860837};\\\", \\\"{x:565,y:680,t:1527616860853};\\\", \\\"{x:565,y:679,t:1527616860870};\\\", \\\"{x:566,y:676,t:1527616860887};\\\", \\\"{x:566,y:674,t:1527616860904};\\\", \\\"{x:566,y:673,t:1527616860921};\\\", \\\"{x:566,y:671,t:1527616860937};\\\", \\\"{x:566,y:670,t:1527616860954};\\\", \\\"{x:566,y:665,t:1527616860985};\\\", \\\"{x:566,y:662,t:1527616860997};\\\", \\\"{x:566,y:661,t:1527616861005};\\\", \\\"{x:566,y:659,t:1527616861021};\\\", \\\"{x:566,y:657,t:1527616861036};\\\", \\\"{x:566,y:656,t:1527616861053};\\\" ] }, { \\\"rt\\\": 31229, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 332108, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -Z -F -F -B -B -M -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:563,y:648,t:1527616861172};\\\", \\\"{x:562,y:647,t:1527616861186};\\\", \\\"{x:548,y:618,t:1527616861628};\\\", \\\"{x:544,y:609,t:1527616861638};\\\", \\\"{x:540,y:602,t:1527616861654};\\\", \\\"{x:534,y:593,t:1527616861671};\\\", \\\"{x:527,y:583,t:1527616861687};\\\", \\\"{x:520,y:572,t:1527616861703};\\\", \\\"{x:512,y:561,t:1527616861721};\\\", \\\"{x:504,y:552,t:1527616861738};\\\", \\\"{x:501,y:548,t:1527616861754};\\\", \\\"{x:498,y:544,t:1527616861771};\\\", \\\"{x:495,y:539,t:1527616861788};\\\", \\\"{x:491,y:534,t:1527616861805};\\\", \\\"{x:489,y:531,t:1527616861821};\\\", \\\"{x:489,y:526,t:1527616861838};\\\", \\\"{x:489,y:521,t:1527616861855};\\\", \\\"{x:489,y:517,t:1527616861871};\\\", \\\"{x:487,y:512,t:1527616861888};\\\", \\\"{x:487,y:511,t:1527616861904};\\\", \\\"{x:487,y:508,t:1527616861921};\\\", \\\"{x:488,y:505,t:1527616861938};\\\", \\\"{x:490,y:502,t:1527616861954};\\\", \\\"{x:490,y:501,t:1527616861970};\\\", \\\"{x:491,y:500,t:1527616861988};\\\", \\\"{x:492,y:498,t:1527616862004};\\\", \\\"{x:493,y:495,t:1527616862021};\\\", \\\"{x:494,y:494,t:1527616862037};\\\", \\\"{x:494,y:492,t:1527616862053};\\\", \\\"{x:495,y:490,t:1527616862071};\\\", \\\"{x:497,y:487,t:1527616862088};\\\", \\\"{x:497,y:485,t:1527616862105};\\\", \\\"{x:498,y:483,t:1527616862121};\\\", \\\"{x:500,y:480,t:1527616862138};\\\", \\\"{x:501,y:478,t:1527616862155};\\\", \\\"{x:501,y:477,t:1527616862171};\\\", \\\"{x:502,y:475,t:1527616862188};\\\", \\\"{x:503,y:472,t:1527616862205};\\\", \\\"{x:504,y:470,t:1527616862221};\\\", \\\"{x:506,y:468,t:1527616862238};\\\", \\\"{x:510,y:464,t:1527616862255};\\\", \\\"{x:515,y:460,t:1527616862272};\\\", \\\"{x:519,y:457,t:1527616862288};\\\", \\\"{x:522,y:456,t:1527616862305};\\\", \\\"{x:526,y:455,t:1527616862322};\\\", \\\"{x:529,y:455,t:1527616862338};\\\", \\\"{x:534,y:455,t:1527616862355};\\\", \\\"{x:538,y:455,t:1527616862372};\\\", \\\"{x:547,y:457,t:1527616862388};\\\", \\\"{x:572,y:463,t:1527616862406};\\\", \\\"{x:591,y:468,t:1527616862422};\\\", \\\"{x:612,y:471,t:1527616862438};\\\", \\\"{x:631,y:476,t:1527616862455};\\\", \\\"{x:649,y:480,t:1527616862472};\\\", \\\"{x:667,y:481,t:1527616862488};\\\", \\\"{x:682,y:485,t:1527616862506};\\\", \\\"{x:692,y:488,t:1527616862524};\\\", \\\"{x:703,y:491,t:1527616862537};\\\", \\\"{x:710,y:493,t:1527616862555};\\\", \\\"{x:719,y:497,t:1527616862571};\\\", \\\"{x:732,y:500,t:1527616862588};\\\", \\\"{x:763,y:509,t:1527616862605};\\\", \\\"{x:785,y:516,t:1527616862622};\\\", \\\"{x:809,y:521,t:1527616862638};\\\", \\\"{x:828,y:527,t:1527616862655};\\\", \\\"{x:852,y:533,t:1527616862672};\\\", \\\"{x:874,y:539,t:1527616862688};\\\", \\\"{x:898,y:547,t:1527616862704};\\\", \\\"{x:919,y:554,t:1527616862722};\\\", \\\"{x:941,y:563,t:1527616862739};\\\", \\\"{x:959,y:572,t:1527616862755};\\\", \\\"{x:981,y:583,t:1527616862772};\\\", \\\"{x:998,y:591,t:1527616862788};\\\", \\\"{x:1026,y:604,t:1527616862805};\\\", \\\"{x:1041,y:611,t:1527616862821};\\\", \\\"{x:1055,y:619,t:1527616862839};\\\", \\\"{x:1073,y:631,t:1527616862855};\\\", \\\"{x:1085,y:641,t:1527616862872};\\\", \\\"{x:1099,y:654,t:1527616862889};\\\", \\\"{x:1112,y:664,t:1527616862905};\\\", \\\"{x:1126,y:676,t:1527616862922};\\\", \\\"{x:1144,y:691,t:1527616862938};\\\", \\\"{x:1164,y:708,t:1527616862955};\\\", \\\"{x:1184,y:726,t:1527616862972};\\\", \\\"{x:1216,y:749,t:1527616862989};\\\", \\\"{x:1235,y:764,t:1527616863005};\\\", \\\"{x:1250,y:774,t:1527616863022};\\\", \\\"{x:1262,y:780,t:1527616863039};\\\", \\\"{x:1275,y:786,t:1527616863054};\\\", \\\"{x:1279,y:790,t:1527616863072};\\\", \\\"{x:1284,y:793,t:1527616863089};\\\", \\\"{x:1288,y:794,t:1527616863105};\\\", \\\"{x:1291,y:796,t:1527616863122};\\\", \\\"{x:1295,y:796,t:1527616863140};\\\", \\\"{x:1301,y:796,t:1527616863155};\\\", \\\"{x:1306,y:796,t:1527616863173};\\\", \\\"{x:1317,y:794,t:1527616863190};\\\", \\\"{x:1324,y:783,t:1527616863206};\\\", \\\"{x:1332,y:768,t:1527616863223};\\\", \\\"{x:1339,y:756,t:1527616863240};\\\", \\\"{x:1344,y:751,t:1527616863256};\\\", \\\"{x:1348,y:746,t:1527616863271};\\\", \\\"{x:1349,y:743,t:1527616863290};\\\", \\\"{x:1349,y:741,t:1527616863305};\\\", \\\"{x:1349,y:736,t:1527616863322};\\\", \\\"{x:1350,y:733,t:1527616863339};\\\", \\\"{x:1351,y:728,t:1527616863356};\\\", \\\"{x:1352,y:726,t:1527616863371};\\\", \\\"{x:1355,y:722,t:1527616863388};\\\", \\\"{x:1355,y:718,t:1527616863406};\\\", \\\"{x:1357,y:713,t:1527616863422};\\\", \\\"{x:1358,y:708,t:1527616863439};\\\", \\\"{x:1359,y:704,t:1527616863456};\\\", \\\"{x:1359,y:701,t:1527616863472};\\\", \\\"{x:1359,y:699,t:1527616863489};\\\", \\\"{x:1359,y:698,t:1527616863506};\\\", \\\"{x:1359,y:696,t:1527616863522};\\\", \\\"{x:1358,y:694,t:1527616863539};\\\", \\\"{x:1357,y:693,t:1527616863556};\\\", \\\"{x:1356,y:692,t:1527616863605};\\\", \\\"{x:1355,y:692,t:1527616863654};\\\", \\\"{x:1354,y:691,t:1527616863702};\\\", \\\"{x:1354,y:695,t:1527616865126};\\\", \\\"{x:1354,y:703,t:1527616865140};\\\", \\\"{x:1354,y:720,t:1527616865158};\\\", \\\"{x:1354,y:730,t:1527616865174};\\\", \\\"{x:1355,y:735,t:1527616865191};\\\", \\\"{x:1356,y:743,t:1527616865207};\\\", \\\"{x:1358,y:751,t:1527616865224};\\\", \\\"{x:1362,y:762,t:1527616865240};\\\", \\\"{x:1365,y:772,t:1527616865257};\\\", \\\"{x:1366,y:786,t:1527616865274};\\\", \\\"{x:1368,y:799,t:1527616865290};\\\", \\\"{x:1370,y:810,t:1527616865307};\\\", \\\"{x:1370,y:820,t:1527616865324};\\\", \\\"{x:1370,y:829,t:1527616865340};\\\", \\\"{x:1370,y:842,t:1527616865356};\\\", \\\"{x:1370,y:850,t:1527616865374};\\\", \\\"{x:1370,y:856,t:1527616865391};\\\", \\\"{x:1370,y:865,t:1527616865407};\\\", \\\"{x:1370,y:873,t:1527616865424};\\\", \\\"{x:1368,y:881,t:1527616865441};\\\", \\\"{x:1365,y:888,t:1527616865458};\\\", \\\"{x:1364,y:895,t:1527616865474};\\\", \\\"{x:1361,y:903,t:1527616865491};\\\", \\\"{x:1360,y:908,t:1527616865507};\\\", \\\"{x:1357,y:916,t:1527616865525};\\\", \\\"{x:1353,y:925,t:1527616865541};\\\", \\\"{x:1352,y:931,t:1527616865558};\\\", \\\"{x:1350,y:936,t:1527616865575};\\\", \\\"{x:1347,y:943,t:1527616865591};\\\", \\\"{x:1343,y:951,t:1527616865607};\\\", \\\"{x:1341,y:957,t:1527616865625};\\\", \\\"{x:1340,y:960,t:1527616865641};\\\", \\\"{x:1340,y:961,t:1527616865657};\\\", \\\"{x:1340,y:956,t:1527616865829};\\\", \\\"{x:1340,y:946,t:1527616865841};\\\", \\\"{x:1339,y:932,t:1527616865858};\\\", \\\"{x:1338,y:921,t:1527616865874};\\\", \\\"{x:1336,y:915,t:1527616865891};\\\", \\\"{x:1335,y:906,t:1527616865908};\\\", \\\"{x:1334,y:896,t:1527616865924};\\\", \\\"{x:1331,y:880,t:1527616865941};\\\", \\\"{x:1330,y:870,t:1527616865958};\\\", \\\"{x:1329,y:860,t:1527616865974};\\\", \\\"{x:1329,y:853,t:1527616865991};\\\", \\\"{x:1329,y:842,t:1527616866008};\\\", \\\"{x:1329,y:836,t:1527616866024};\\\", \\\"{x:1329,y:833,t:1527616866041};\\\", \\\"{x:1329,y:829,t:1527616866058};\\\", \\\"{x:1329,y:825,t:1527616866073};\\\", \\\"{x:1329,y:819,t:1527616866091};\\\", \\\"{x:1332,y:809,t:1527616866108};\\\", \\\"{x:1335,y:800,t:1527616866124};\\\", \\\"{x:1340,y:783,t:1527616866140};\\\", \\\"{x:1342,y:774,t:1527616866158};\\\", \\\"{x:1344,y:768,t:1527616866173};\\\", \\\"{x:1346,y:761,t:1527616866191};\\\", \\\"{x:1346,y:758,t:1527616866208};\\\", \\\"{x:1346,y:754,t:1527616866224};\\\", \\\"{x:1346,y:751,t:1527616866241};\\\", \\\"{x:1348,y:747,t:1527616866257};\\\", \\\"{x:1349,y:745,t:1527616866275};\\\", \\\"{x:1349,y:743,t:1527616866290};\\\", \\\"{x:1349,y:741,t:1527616866308};\\\", \\\"{x:1349,y:737,t:1527616866324};\\\", \\\"{x:1350,y:733,t:1527616866341};\\\", \\\"{x:1351,y:731,t:1527616866357};\\\", \\\"{x:1351,y:727,t:1527616866375};\\\", \\\"{x:1351,y:725,t:1527616866391};\\\", \\\"{x:1351,y:723,t:1527616866408};\\\", \\\"{x:1351,y:720,t:1527616866424};\\\", \\\"{x:1351,y:717,t:1527616866441};\\\", \\\"{x:1351,y:713,t:1527616866458};\\\", \\\"{x:1351,y:711,t:1527616866475};\\\", \\\"{x:1351,y:710,t:1527616866491};\\\", \\\"{x:1351,y:708,t:1527616866508};\\\", \\\"{x:1351,y:707,t:1527616869534};\\\", \\\"{x:1354,y:706,t:1527616870973};\\\", \\\"{x:1365,y:705,t:1527616870981};\\\", \\\"{x:1379,y:703,t:1527616870995};\\\", \\\"{x:1417,y:699,t:1527616871012};\\\", \\\"{x:1465,y:696,t:1527616871028};\\\", \\\"{x:1533,y:696,t:1527616871044};\\\", \\\"{x:1563,y:696,t:1527616871061};\\\", \\\"{x:1579,y:696,t:1527616871078};\\\", \\\"{x:1586,y:695,t:1527616871095};\\\", \\\"{x:1587,y:695,t:1527616871111};\\\", \\\"{x:1590,y:695,t:1527616871350};\\\", \\\"{x:1592,y:695,t:1527616871365};\\\", \\\"{x:1593,y:695,t:1527616871379};\\\", \\\"{x:1594,y:695,t:1527616871396};\\\", \\\"{x:1595,y:695,t:1527616871413};\\\", \\\"{x:1596,y:695,t:1527616871502};\\\", \\\"{x:1599,y:695,t:1527616871517};\\\", \\\"{x:1599,y:696,t:1527616871528};\\\", \\\"{x:1603,y:696,t:1527616871546};\\\", \\\"{x:1606,y:696,t:1527616871562};\\\", \\\"{x:1610,y:696,t:1527616871580};\\\", \\\"{x:1612,y:697,t:1527616871596};\\\", \\\"{x:1614,y:698,t:1527616871612};\\\", \\\"{x:1615,y:698,t:1527616871661};\\\", \\\"{x:1616,y:698,t:1527616871677};\\\", \\\"{x:1617,y:699,t:1527616871701};\\\", \\\"{x:1618,y:699,t:1527616871712};\\\", \\\"{x:1619,y:699,t:1527616871730};\\\", \\\"{x:1619,y:700,t:1527616874558};\\\", \\\"{x:1618,y:700,t:1527616874598};\\\", \\\"{x:1592,y:705,t:1527616874616};\\\", \\\"{x:1555,y:712,t:1527616874632};\\\", \\\"{x:1492,y:717,t:1527616874648};\\\", \\\"{x:1430,y:719,t:1527616874665};\\\", \\\"{x:1390,y:719,t:1527616874682};\\\", \\\"{x:1369,y:719,t:1527616874699};\\\", \\\"{x:1364,y:719,t:1527616874715};\\\", \\\"{x:1363,y:719,t:1527616874941};\\\", \\\"{x:1361,y:719,t:1527616874949};\\\", \\\"{x:1360,y:719,t:1527616874964};\\\", \\\"{x:1356,y:718,t:1527616874981};\\\", \\\"{x:1355,y:716,t:1527616874998};\\\", \\\"{x:1353,y:713,t:1527616875015};\\\", \\\"{x:1353,y:712,t:1527616875037};\\\", \\\"{x:1352,y:711,t:1527616875094};\\\", \\\"{x:1351,y:710,t:1527616875134};\\\", \\\"{x:1350,y:709,t:1527616875149};\\\", \\\"{x:1350,y:708,t:1527616875165};\\\", \\\"{x:1349,y:708,t:1527616875182};\\\", \\\"{x:1349,y:706,t:1527616875199};\\\", \\\"{x:1348,y:705,t:1527616875216};\\\", \\\"{x:1347,y:705,t:1527616875232};\\\", \\\"{x:1347,y:704,t:1527616875249};\\\", \\\"{x:1346,y:703,t:1527616875266};\\\", \\\"{x:1346,y:702,t:1527616875282};\\\", \\\"{x:1345,y:702,t:1527616875300};\\\", \\\"{x:1344,y:701,t:1527616875375};\\\", \\\"{x:1344,y:700,t:1527616875420};\\\", \\\"{x:1346,y:709,t:1527616882647};\\\", \\\"{x:1347,y:718,t:1527616882656};\\\", \\\"{x:1349,y:729,t:1527616882671};\\\", \\\"{x:1349,y:734,t:1527616882688};\\\", \\\"{x:1349,y:737,t:1527616882705};\\\", \\\"{x:1349,y:739,t:1527616882721};\\\", \\\"{x:1349,y:740,t:1527616882738};\\\", \\\"{x:1349,y:743,t:1527616882756};\\\", \\\"{x:1350,y:746,t:1527616882772};\\\", \\\"{x:1351,y:749,t:1527616882788};\\\", \\\"{x:1351,y:757,t:1527616882806};\\\", \\\"{x:1353,y:761,t:1527616882821};\\\", \\\"{x:1354,y:763,t:1527616882839};\\\", \\\"{x:1354,y:764,t:1527616882856};\\\", \\\"{x:1355,y:765,t:1527616882872};\\\", \\\"{x:1355,y:766,t:1527616882894};\\\", \\\"{x:1356,y:766,t:1527616882925};\\\", \\\"{x:1357,y:773,t:1527616883917};\\\", \\\"{x:1358,y:782,t:1527616883924};\\\", \\\"{x:1358,y:797,t:1527616883938};\\\", \\\"{x:1359,y:818,t:1527616883956};\\\", \\\"{x:1361,y:831,t:1527616883972};\\\", \\\"{x:1363,y:844,t:1527616883988};\\\", \\\"{x:1364,y:848,t:1527616884006};\\\", \\\"{x:1365,y:849,t:1527616884021};\\\", \\\"{x:1365,y:852,t:1527616884038};\\\", \\\"{x:1366,y:858,t:1527616884056};\\\", \\\"{x:1368,y:865,t:1527616884071};\\\", \\\"{x:1369,y:869,t:1527616884089};\\\", \\\"{x:1370,y:873,t:1527616884106};\\\", \\\"{x:1371,y:876,t:1527616884121};\\\", \\\"{x:1371,y:878,t:1527616884139};\\\", \\\"{x:1372,y:882,t:1527616884155};\\\", \\\"{x:1372,y:884,t:1527616884172};\\\", \\\"{x:1373,y:888,t:1527616884189};\\\", \\\"{x:1373,y:890,t:1527616884206};\\\", \\\"{x:1374,y:892,t:1527616884222};\\\", \\\"{x:1374,y:894,t:1527616884239};\\\", \\\"{x:1375,y:895,t:1527616884256};\\\", \\\"{x:1376,y:895,t:1527616884518};\\\", \\\"{x:1378,y:895,t:1527616884565};\\\", \\\"{x:1379,y:895,t:1527616884597};\\\", \\\"{x:1381,y:895,t:1527616884629};\\\", \\\"{x:1382,y:895,t:1527616884678};\\\", \\\"{x:1386,y:889,t:1527616886543};\\\", \\\"{x:1396,y:878,t:1527616886557};\\\", \\\"{x:1401,y:872,t:1527616886575};\\\", \\\"{x:1408,y:865,t:1527616886592};\\\", \\\"{x:1415,y:860,t:1527616886609};\\\", \\\"{x:1417,y:859,t:1527616886624};\\\", \\\"{x:1419,y:857,t:1527616886642};\\\", \\\"{x:1423,y:854,t:1527616886658};\\\", \\\"{x:1428,y:849,t:1527616886674};\\\", \\\"{x:1433,y:845,t:1527616886692};\\\", \\\"{x:1436,y:841,t:1527616886708};\\\", \\\"{x:1440,y:839,t:1527616886724};\\\", \\\"{x:1442,y:838,t:1527616886741};\\\", \\\"{x:1443,y:836,t:1527616886758};\\\", \\\"{x:1445,y:835,t:1527616886774};\\\", \\\"{x:1446,y:833,t:1527616886792};\\\", \\\"{x:1451,y:829,t:1527616886808};\\\", \\\"{x:1457,y:823,t:1527616886825};\\\", \\\"{x:1463,y:819,t:1527616886841};\\\", \\\"{x:1467,y:817,t:1527616886858};\\\", \\\"{x:1467,y:816,t:1527616886875};\\\", \\\"{x:1468,y:816,t:1527616886910};\\\", \\\"{x:1469,y:815,t:1527616886949};\\\", \\\"{x:1470,y:814,t:1527616886974};\\\", \\\"{x:1472,y:814,t:1527616887086};\\\", \\\"{x:1474,y:814,t:1527616887094};\\\", \\\"{x:1475,y:814,t:1527616887108};\\\", \\\"{x:1477,y:814,t:1527616887126};\\\", \\\"{x:1478,y:814,t:1527616887141};\\\", \\\"{x:1479,y:814,t:1527616887159};\\\", \\\"{x:1481,y:816,t:1527616887175};\\\", \\\"{x:1482,y:816,t:1527616887191};\\\", \\\"{x:1482,y:817,t:1527616887213};\\\", \\\"{x:1483,y:817,t:1527616887237};\\\", \\\"{x:1484,y:817,t:1527616887253};\\\", \\\"{x:1485,y:817,t:1527616887270};\\\", \\\"{x:1485,y:818,t:1527616887326};\\\", \\\"{x:1487,y:819,t:1527616887341};\\\", \\\"{x:1488,y:821,t:1527616887359};\\\", \\\"{x:1488,y:822,t:1527616887375};\\\", \\\"{x:1489,y:823,t:1527616887391};\\\", \\\"{x:1489,y:824,t:1527616887645};\\\", \\\"{x:1489,y:826,t:1527616887658};\\\", \\\"{x:1488,y:826,t:1527616887677};\\\", \\\"{x:1487,y:826,t:1527616887701};\\\", \\\"{x:1487,y:827,t:1527616887709};\\\", \\\"{x:1486,y:828,t:1527616888118};\\\", \\\"{x:1486,y:830,t:1527616888125};\\\", \\\"{x:1486,y:837,t:1527616888143};\\\", \\\"{x:1485,y:843,t:1527616888159};\\\", \\\"{x:1484,y:846,t:1527616888176};\\\", \\\"{x:1484,y:847,t:1527616888193};\\\", \\\"{x:1484,y:849,t:1527616888210};\\\", \\\"{x:1484,y:851,t:1527616888225};\\\", \\\"{x:1484,y:855,t:1527616888242};\\\", \\\"{x:1484,y:857,t:1527616888259};\\\", \\\"{x:1484,y:859,t:1527616888276};\\\", \\\"{x:1484,y:860,t:1527616888292};\\\", \\\"{x:1482,y:861,t:1527616888374};\\\", \\\"{x:1477,y:861,t:1527616888381};\\\", \\\"{x:1475,y:859,t:1527616888392};\\\", \\\"{x:1474,y:858,t:1527616888409};\\\", \\\"{x:1473,y:855,t:1527616888427};\\\", \\\"{x:1472,y:854,t:1527616888442};\\\", \\\"{x:1472,y:853,t:1527616888462};\\\", \\\"{x:1472,y:852,t:1527616888476};\\\", \\\"{x:1472,y:851,t:1527616888493};\\\", \\\"{x:1472,y:850,t:1527616888509};\\\", \\\"{x:1472,y:848,t:1527616888527};\\\", \\\"{x:1472,y:847,t:1527616888543};\\\", \\\"{x:1472,y:846,t:1527616888560};\\\", \\\"{x:1472,y:845,t:1527616888597};\\\", \\\"{x:1472,y:844,t:1527616888613};\\\", \\\"{x:1472,y:843,t:1527616888627};\\\", \\\"{x:1472,y:841,t:1527616888643};\\\", \\\"{x:1472,y:837,t:1527616888659};\\\", \\\"{x:1472,y:835,t:1527616888677};\\\", \\\"{x:1472,y:834,t:1527616888693};\\\", \\\"{x:1472,y:833,t:1527616888709};\\\", \\\"{x:1472,y:832,t:1527616888733};\\\", \\\"{x:1472,y:825,t:1527616889446};\\\", \\\"{x:1472,y:817,t:1527616889461};\\\", \\\"{x:1466,y:795,t:1527616889477};\\\", \\\"{x:1460,y:769,t:1527616889493};\\\", \\\"{x:1458,y:763,t:1527616889510};\\\", \\\"{x:1457,y:761,t:1527616889527};\\\", \\\"{x:1457,y:759,t:1527616889543};\\\", \\\"{x:1457,y:758,t:1527616889560};\\\", \\\"{x:1455,y:756,t:1527616889749};\\\", \\\"{x:1447,y:754,t:1527616889761};\\\", \\\"{x:1416,y:754,t:1527616889777};\\\", \\\"{x:1355,y:754,t:1527616889793};\\\", \\\"{x:1260,y:754,t:1527616889811};\\\", \\\"{x:1155,y:754,t:1527616889827};\\\", \\\"{x:1039,y:754,t:1527616889843};\\\", \\\"{x:936,y:754,t:1527616889860};\\\", \\\"{x:808,y:754,t:1527616889877};\\\", \\\"{x:772,y:754,t:1527616889894};\\\", \\\"{x:751,y:754,t:1527616889910};\\\", \\\"{x:743,y:754,t:1527616889928};\\\", \\\"{x:738,y:754,t:1527616889944};\\\", \\\"{x:730,y:754,t:1527616889961};\\\", \\\"{x:712,y:753,t:1527616889977};\\\", \\\"{x:678,y:748,t:1527616889992};\\\", \\\"{x:620,y:739,t:1527616890009};\\\", \\\"{x:542,y:728,t:1527616890027};\\\", \\\"{x:470,y:720,t:1527616890043};\\\", \\\"{x:412,y:711,t:1527616890060};\\\", \\\"{x:382,y:705,t:1527616890070};\\\", \\\"{x:371,y:703,t:1527616890086};\\\", \\\"{x:368,y:703,t:1527616890103};\\\", \\\"{x:372,y:703,t:1527616890364};\\\", \\\"{x:379,y:703,t:1527616890372};\\\", \\\"{x:390,y:704,t:1527616890387};\\\", \\\"{x:414,y:704,t:1527616890403};\\\", \\\"{x:437,y:704,t:1527616890420};\\\", \\\"{x:460,y:690,t:1527616890437};\\\", \\\"{x:466,y:682,t:1527616890454};\\\", \\\"{x:469,y:669,t:1527616890470};\\\", \\\"{x:469,y:657,t:1527616890487};\\\", \\\"{x:455,y:632,t:1527616890511};\\\", \\\"{x:440,y:616,t:1527616890528};\\\", \\\"{x:424,y:602,t:1527616890544};\\\", \\\"{x:402,y:586,t:1527616890562};\\\", \\\"{x:375,y:570,t:1527616890577};\\\", \\\"{x:333,y:552,t:1527616890594};\\\", \\\"{x:304,y:543,t:1527616890611};\\\", \\\"{x:287,y:538,t:1527616890628};\\\", \\\"{x:287,y:537,t:1527616890644};\\\", \\\"{x:287,y:536,t:1527616890684};\\\", \\\"{x:288,y:535,t:1527616890700};\\\", \\\"{x:291,y:533,t:1527616890716};\\\", \\\"{x:293,y:533,t:1527616890728};\\\", \\\"{x:297,y:531,t:1527616890744};\\\", \\\"{x:303,y:529,t:1527616890760};\\\", \\\"{x:323,y:522,t:1527616890778};\\\", \\\"{x:344,y:518,t:1527616890793};\\\", \\\"{x:369,y:515,t:1527616890811};\\\", \\\"{x:412,y:515,t:1527616890828};\\\", \\\"{x:445,y:515,t:1527616890844};\\\", \\\"{x:480,y:521,t:1527616890861};\\\", \\\"{x:506,y:525,t:1527616890878};\\\", \\\"{x:525,y:527,t:1527616890894};\\\", \\\"{x:538,y:530,t:1527616890911};\\\", \\\"{x:553,y:535,t:1527616890928};\\\", \\\"{x:562,y:537,t:1527616890944};\\\", \\\"{x:571,y:540,t:1527616890961};\\\", \\\"{x:574,y:541,t:1527616890978};\\\", \\\"{x:577,y:543,t:1527616890994};\\\", \\\"{x:578,y:543,t:1527616891045};\\\", \\\"{x:580,y:544,t:1527616891061};\\\", \\\"{x:585,y:547,t:1527616891078};\\\", \\\"{x:594,y:552,t:1527616891094};\\\", \\\"{x:606,y:557,t:1527616891112};\\\", \\\"{x:625,y:565,t:1527616891129};\\\", \\\"{x:643,y:575,t:1527616891145};\\\", \\\"{x:653,y:577,t:1527616891161};\\\", \\\"{x:657,y:579,t:1527616891178};\\\", \\\"{x:660,y:580,t:1527616891195};\\\", \\\"{x:662,y:580,t:1527616891211};\\\", \\\"{x:659,y:580,t:1527616891357};\\\", \\\"{x:655,y:580,t:1527616891365};\\\", \\\"{x:650,y:580,t:1527616891378};\\\", \\\"{x:641,y:582,t:1527616891395};\\\", \\\"{x:637,y:582,t:1527616891411};\\\", \\\"{x:630,y:583,t:1527616891428};\\\", \\\"{x:629,y:584,t:1527616891446};\\\", \\\"{x:627,y:584,t:1527616891557};\\\", \\\"{x:624,y:584,t:1527616891565};\\\", \\\"{x:622,y:584,t:1527616891578};\\\", \\\"{x:615,y:584,t:1527616891596};\\\", \\\"{x:608,y:584,t:1527616891613};\\\", \\\"{x:605,y:584,t:1527616891629};\\\", \\\"{x:604,y:584,t:1527616891878};\\\", \\\"{x:596,y:589,t:1527616891895};\\\", \\\"{x:582,y:610,t:1527616891913};\\\", \\\"{x:569,y:631,t:1527616891928};\\\", \\\"{x:555,y:650,t:1527616891946};\\\", \\\"{x:543,y:664,t:1527616891962};\\\", \\\"{x:534,y:680,t:1527616891978};\\\", \\\"{x:531,y:693,t:1527616891995};\\\", \\\"{x:531,y:705,t:1527616892012};\\\", \\\"{x:529,y:715,t:1527616892028};\\\", \\\"{x:529,y:721,t:1527616892045};\\\", \\\"{x:526,y:727,t:1527616892062};\\\", \\\"{x:526,y:729,t:1527616892079};\\\", \\\"{x:526,y:730,t:1527616892149};\\\", \\\"{x:527,y:730,t:1527616892253};\\\", \\\"{x:526,y:730,t:1527616892692};\\\", \\\"{x:526,y:729,t:1527616892700};\\\", \\\"{x:525,y:728,t:1527616892713};\\\", \\\"{x:525,y:725,t:1527616892729};\\\", \\\"{x:524,y:724,t:1527616892746};\\\", \\\"{x:524,y:722,t:1527616892763};\\\", \\\"{x:524,y:721,t:1527616892779};\\\", \\\"{x:523,y:719,t:1527616892796};\\\", \\\"{x:523,y:718,t:1527616892812};\\\", \\\"{x:523,y:716,t:1527616892829};\\\", \\\"{x:522,y:714,t:1527616892845};\\\", \\\"{x:522,y:712,t:1527616892868};\\\", \\\"{x:522,y:710,t:1527616892884};\\\", \\\"{x:522,y:708,t:1527616892896};\\\", \\\"{x:522,y:707,t:1527616892916};\\\", \\\"{x:521,y:706,t:1527616892932};\\\", \\\"{x:521,y:705,t:1527616892956};\\\", \\\"{x:520,y:703,t:1527616892972};\\\" ] }, { \\\"rt\\\": 12138, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 345512, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -12 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:700,t:1527616894257};\\\", \\\"{x:519,y:699,t:1527616895196};\\\", \\\"{x:525,y:695,t:1527616895204};\\\", \\\"{x:534,y:690,t:1527616895214};\\\", \\\"{x:547,y:685,t:1527616895231};\\\", \\\"{x:564,y:683,t:1527616895248};\\\", \\\"{x:583,y:680,t:1527616895264};\\\", \\\"{x:604,y:678,t:1527616895281};\\\", \\\"{x:628,y:673,t:1527616895298};\\\", \\\"{x:658,y:668,t:1527616895315};\\\", \\\"{x:692,y:665,t:1527616895331};\\\", \\\"{x:758,y:655,t:1527616895348};\\\", \\\"{x:806,y:647,t:1527616895365};\\\", \\\"{x:852,y:640,t:1527616895382};\\\", \\\"{x:881,y:634,t:1527616895399};\\\", \\\"{x:913,y:628,t:1527616895416};\\\", \\\"{x:938,y:626,t:1527616895431};\\\", \\\"{x:955,y:620,t:1527616895448};\\\", \\\"{x:965,y:618,t:1527616895464};\\\", \\\"{x:975,y:617,t:1527616895480};\\\", \\\"{x:985,y:615,t:1527616895498};\\\", \\\"{x:999,y:615,t:1527616895514};\\\", \\\"{x:1014,y:612,t:1527616895530};\\\", \\\"{x:1033,y:609,t:1527616895548};\\\", \\\"{x:1068,y:605,t:1527616895564};\\\", \\\"{x:1092,y:603,t:1527616895580};\\\", \\\"{x:1108,y:602,t:1527616895598};\\\", \\\"{x:1125,y:604,t:1527616895614};\\\", \\\"{x:1137,y:608,t:1527616895631};\\\", \\\"{x:1143,y:610,t:1527616895647};\\\", \\\"{x:1156,y:614,t:1527616895663};\\\", \\\"{x:1172,y:622,t:1527616895680};\\\", \\\"{x:1191,y:633,t:1527616895698};\\\", \\\"{x:1213,y:644,t:1527616895715};\\\", \\\"{x:1236,y:658,t:1527616895730};\\\", \\\"{x:1259,y:673,t:1527616895748};\\\", \\\"{x:1285,y:692,t:1527616895764};\\\", \\\"{x:1296,y:700,t:1527616895780};\\\", \\\"{x:1302,y:705,t:1527616895797};\\\", \\\"{x:1306,y:711,t:1527616895814};\\\", \\\"{x:1310,y:715,t:1527616895831};\\\", \\\"{x:1313,y:719,t:1527616895848};\\\", \\\"{x:1316,y:726,t:1527616895865};\\\", \\\"{x:1318,y:736,t:1527616895881};\\\", \\\"{x:1320,y:743,t:1527616895898};\\\", \\\"{x:1323,y:750,t:1527616895915};\\\", \\\"{x:1325,y:754,t:1527616895930};\\\", \\\"{x:1326,y:755,t:1527616895948};\\\", \\\"{x:1326,y:757,t:1527616895966};\\\", \\\"{x:1326,y:759,t:1527616896629};\\\", \\\"{x:1333,y:768,t:1527616896648};\\\", \\\"{x:1338,y:776,t:1527616896664};\\\", \\\"{x:1344,y:791,t:1527616896681};\\\", \\\"{x:1349,y:805,t:1527616896698};\\\", \\\"{x:1353,y:817,t:1527616896715};\\\", \\\"{x:1355,y:822,t:1527616896730};\\\", \\\"{x:1357,y:828,t:1527616896747};\\\", \\\"{x:1359,y:835,t:1527616896764};\\\", \\\"{x:1362,y:838,t:1527616896780};\\\", \\\"{x:1363,y:842,t:1527616896798};\\\", \\\"{x:1365,y:847,t:1527616896814};\\\", \\\"{x:1366,y:858,t:1527616896830};\\\", \\\"{x:1367,y:868,t:1527616896847};\\\", \\\"{x:1371,y:878,t:1527616896864};\\\", \\\"{x:1374,y:887,t:1527616896880};\\\", \\\"{x:1377,y:897,t:1527616896899};\\\", \\\"{x:1380,y:906,t:1527616896915};\\\", \\\"{x:1383,y:912,t:1527616896931};\\\", \\\"{x:1387,y:917,t:1527616896947};\\\", \\\"{x:1391,y:925,t:1527616896965};\\\", \\\"{x:1392,y:926,t:1527616896980};\\\", \\\"{x:1392,y:927,t:1527616897038};\\\", \\\"{x:1392,y:928,t:1527616897048};\\\", \\\"{x:1392,y:929,t:1527616897065};\\\", \\\"{x:1393,y:932,t:1527616897080};\\\", \\\"{x:1396,y:937,t:1527616897098};\\\", \\\"{x:1400,y:943,t:1527616897115};\\\", \\\"{x:1404,y:948,t:1527616897131};\\\", \\\"{x:1408,y:952,t:1527616897148};\\\", \\\"{x:1411,y:955,t:1527616897165};\\\", \\\"{x:1414,y:956,t:1527616897182};\\\", \\\"{x:1416,y:957,t:1527616897198};\\\", \\\"{x:1418,y:957,t:1527616897221};\\\", \\\"{x:1420,y:957,t:1527616897237};\\\", \\\"{x:1421,y:957,t:1527616897248};\\\", \\\"{x:1425,y:957,t:1527616897265};\\\", \\\"{x:1427,y:957,t:1527616897281};\\\", \\\"{x:1425,y:957,t:1527616897476};\\\", \\\"{x:1423,y:957,t:1527616897484};\\\", \\\"{x:1419,y:957,t:1527616897497};\\\", \\\"{x:1410,y:957,t:1527616897515};\\\", \\\"{x:1398,y:959,t:1527616897530};\\\", \\\"{x:1386,y:960,t:1527616897547};\\\", \\\"{x:1375,y:961,t:1527616897565};\\\", \\\"{x:1369,y:963,t:1527616897581};\\\", \\\"{x:1368,y:964,t:1527616897597};\\\", \\\"{x:1367,y:964,t:1527616897614};\\\", \\\"{x:1365,y:964,t:1527616897645};\\\", \\\"{x:1364,y:964,t:1527616897653};\\\", \\\"{x:1361,y:965,t:1527616897665};\\\", \\\"{x:1355,y:967,t:1527616897680};\\\", \\\"{x:1348,y:967,t:1527616897698};\\\", \\\"{x:1344,y:968,t:1527616897714};\\\", \\\"{x:1339,y:970,t:1527616897731};\\\", \\\"{x:1336,y:970,t:1527616897748};\\\", \\\"{x:1335,y:971,t:1527616897764};\\\", \\\"{x:1334,y:971,t:1527616897846};\\\", \\\"{x:1338,y:970,t:1527616898070};\\\", \\\"{x:1339,y:970,t:1527616898082};\\\", \\\"{x:1342,y:967,t:1527616898099};\\\", \\\"{x:1344,y:964,t:1527616898115};\\\", \\\"{x:1346,y:963,t:1527616898132};\\\", \\\"{x:1346,y:962,t:1527616898148};\\\", \\\"{x:1346,y:961,t:1527616898869};\\\", \\\"{x:1346,y:958,t:1527616898882};\\\", \\\"{x:1346,y:949,t:1527616898898};\\\", \\\"{x:1346,y:938,t:1527616898915};\\\", \\\"{x:1346,y:927,t:1527616898932};\\\", \\\"{x:1346,y:917,t:1527616898948};\\\", \\\"{x:1346,y:902,t:1527616898966};\\\", \\\"{x:1346,y:891,t:1527616898982};\\\", \\\"{x:1348,y:878,t:1527616898998};\\\", \\\"{x:1348,y:865,t:1527616899015};\\\", \\\"{x:1348,y:854,t:1527616899032};\\\", \\\"{x:1348,y:842,t:1527616899048};\\\", \\\"{x:1348,y:832,t:1527616899065};\\\", \\\"{x:1348,y:821,t:1527616899082};\\\", \\\"{x:1348,y:814,t:1527616899098};\\\", \\\"{x:1348,y:810,t:1527616899115};\\\", \\\"{x:1348,y:802,t:1527616899132};\\\", \\\"{x:1347,y:795,t:1527616899148};\\\", \\\"{x:1344,y:782,t:1527616899165};\\\", \\\"{x:1342,y:773,t:1527616899181};\\\", \\\"{x:1342,y:769,t:1527616899198};\\\", \\\"{x:1342,y:764,t:1527616899216};\\\", \\\"{x:1342,y:757,t:1527616899233};\\\", \\\"{x:1342,y:753,t:1527616899248};\\\", \\\"{x:1341,y:749,t:1527616899265};\\\", \\\"{x:1341,y:748,t:1527616899282};\\\", \\\"{x:1340,y:747,t:1527616899366};\\\", \\\"{x:1340,y:744,t:1527616899606};\\\", \\\"{x:1340,y:733,t:1527616899615};\\\", \\\"{x:1340,y:710,t:1527616899632};\\\", \\\"{x:1334,y:686,t:1527616899649};\\\", \\\"{x:1329,y:668,t:1527616899664};\\\", \\\"{x:1323,y:657,t:1527616899682};\\\", \\\"{x:1321,y:655,t:1527616899699};\\\", \\\"{x:1320,y:653,t:1527616899716};\\\", \\\"{x:1319,y:653,t:1527616899813};\\\", \\\"{x:1317,y:652,t:1527616899832};\\\", \\\"{x:1310,y:652,t:1527616899849};\\\", \\\"{x:1292,y:655,t:1527616899865};\\\", \\\"{x:1274,y:660,t:1527616899882};\\\", \\\"{x:1254,y:667,t:1527616899899};\\\", \\\"{x:1234,y:672,t:1527616899915};\\\", \\\"{x:1217,y:676,t:1527616899932};\\\", \\\"{x:1196,y:680,t:1527616899949};\\\", \\\"{x:1192,y:681,t:1527616899966};\\\", \\\"{x:1191,y:681,t:1527616899982};\\\", \\\"{x:1190,y:681,t:1527616900093};\\\", \\\"{x:1187,y:681,t:1527616900102};\\\", \\\"{x:1183,y:681,t:1527616900115};\\\", \\\"{x:1174,y:681,t:1527616900132};\\\", \\\"{x:1144,y:681,t:1527616900149};\\\", \\\"{x:1121,y:681,t:1527616900165};\\\", \\\"{x:1096,y:681,t:1527616900182};\\\", \\\"{x:1074,y:681,t:1527616900199};\\\", \\\"{x:1054,y:681,t:1527616900216};\\\", \\\"{x:1037,y:681,t:1527616900232};\\\", \\\"{x:1021,y:681,t:1527616900249};\\\", \\\"{x:1001,y:681,t:1527616900265};\\\", \\\"{x:985,y:683,t:1527616900281};\\\", \\\"{x:975,y:687,t:1527616900299};\\\", \\\"{x:964,y:691,t:1527616900314};\\\", \\\"{x:957,y:695,t:1527616900332};\\\", \\\"{x:945,y:703,t:1527616900348};\\\", \\\"{x:938,y:708,t:1527616900364};\\\", \\\"{x:931,y:714,t:1527616900381};\\\", \\\"{x:922,y:725,t:1527616900398};\\\", \\\"{x:907,y:744,t:1527616900415};\\\", \\\"{x:894,y:762,t:1527616900431};\\\", \\\"{x:884,y:775,t:1527616900448};\\\", \\\"{x:876,y:782,t:1527616900465};\\\", \\\"{x:870,y:787,t:1527616900481};\\\", \\\"{x:865,y:791,t:1527616900499};\\\", \\\"{x:855,y:794,t:1527616900515};\\\", \\\"{x:846,y:798,t:1527616900532};\\\", \\\"{x:827,y:807,t:1527616900549};\\\", \\\"{x:811,y:814,t:1527616900565};\\\", \\\"{x:798,y:818,t:1527616900582};\\\", \\\"{x:783,y:822,t:1527616900599};\\\", \\\"{x:769,y:823,t:1527616900615};\\\", \\\"{x:759,y:825,t:1527616900632};\\\", \\\"{x:753,y:825,t:1527616900649};\\\", \\\"{x:751,y:825,t:1527616900667};\\\", \\\"{x:749,y:825,t:1527616900682};\\\", \\\"{x:746,y:825,t:1527616900699};\\\", \\\"{x:744,y:825,t:1527616900717};\\\", \\\"{x:743,y:825,t:1527616900731};\\\", \\\"{x:740,y:825,t:1527616900748};\\\", \\\"{x:739,y:825,t:1527616900764};\\\", \\\"{x:737,y:825,t:1527616900782};\\\", \\\"{x:736,y:823,t:1527616900798};\\\", \\\"{x:732,y:820,t:1527616900815};\\\", \\\"{x:725,y:811,t:1527616900831};\\\", \\\"{x:720,y:800,t:1527616900848};\\\", \\\"{x:714,y:790,t:1527616900864};\\\", \\\"{x:706,y:778,t:1527616900881};\\\", \\\"{x:703,y:774,t:1527616900899};\\\", \\\"{x:700,y:770,t:1527616900915};\\\", \\\"{x:698,y:766,t:1527616900932};\\\", \\\"{x:694,y:761,t:1527616900949};\\\", \\\"{x:694,y:758,t:1527616900965};\\\", \\\"{x:692,y:756,t:1527616900982};\\\", \\\"{x:689,y:753,t:1527616900999};\\\", \\\"{x:683,y:747,t:1527616901015};\\\", \\\"{x:669,y:735,t:1527616901032};\\\", \\\"{x:652,y:722,t:1527616901049};\\\", \\\"{x:639,y:710,t:1527616901067};\\\", \\\"{x:623,y:696,t:1527616901082};\\\", \\\"{x:608,y:684,t:1527616901099};\\\", \\\"{x:595,y:672,t:1527616901114};\\\", \\\"{x:585,y:662,t:1527616901131};\\\", \\\"{x:569,y:642,t:1527616901148};\\\", \\\"{x:559,y:632,t:1527616901164};\\\", \\\"{x:550,y:625,t:1527616901182};\\\", \\\"{x:541,y:618,t:1527616901198};\\\", \\\"{x:529,y:610,t:1527616901215};\\\", \\\"{x:514,y:601,t:1527616901235};\\\", \\\"{x:484,y:590,t:1527616901252};\\\", \\\"{x:463,y:583,t:1527616901269};\\\", \\\"{x:439,y:575,t:1527616901285};\\\", \\\"{x:420,y:572,t:1527616901303};\\\", \\\"{x:409,y:569,t:1527616901320};\\\", \\\"{x:403,y:568,t:1527616901335};\\\", \\\"{x:400,y:567,t:1527616901353};\\\", \\\"{x:399,y:567,t:1527616901369};\\\", \\\"{x:397,y:566,t:1527616901387};\\\", \\\"{x:394,y:565,t:1527616901403};\\\", \\\"{x:391,y:565,t:1527616901420};\\\", \\\"{x:388,y:565,t:1527616901436};\\\", \\\"{x:387,y:563,t:1527616901645};\\\", \\\"{x:387,y:559,t:1527616901654};\\\", \\\"{x:387,y:555,t:1527616901670};\\\", \\\"{x:387,y:547,t:1527616901687};\\\", \\\"{x:387,y:541,t:1527616901704};\\\", \\\"{x:387,y:536,t:1527616901719};\\\", \\\"{x:383,y:530,t:1527616901737};\\\", \\\"{x:380,y:528,t:1527616901754};\\\", \\\"{x:376,y:527,t:1527616901769};\\\", \\\"{x:372,y:527,t:1527616901786};\\\", \\\"{x:363,y:527,t:1527616901803};\\\", \\\"{x:350,y:527,t:1527616901819};\\\", \\\"{x:316,y:528,t:1527616901836};\\\", \\\"{x:290,y:532,t:1527616901853};\\\", \\\"{x:259,y:536,t:1527616901870};\\\", \\\"{x:230,y:541,t:1527616901887};\\\", \\\"{x:203,y:542,t:1527616901904};\\\", \\\"{x:176,y:542,t:1527616901920};\\\", \\\"{x:153,y:542,t:1527616901937};\\\", \\\"{x:138,y:542,t:1527616901953};\\\", \\\"{x:131,y:543,t:1527616901970};\\\", \\\"{x:129,y:544,t:1527616901987};\\\", \\\"{x:128,y:545,t:1527616902004};\\\", \\\"{x:129,y:545,t:1527616902174};\\\", \\\"{x:131,y:544,t:1527616902186};\\\", \\\"{x:132,y:544,t:1527616902203};\\\", \\\"{x:135,y:542,t:1527616902220};\\\", \\\"{x:136,y:542,t:1527616902260};\\\", \\\"{x:136,y:541,t:1527616902276};\\\", \\\"{x:138,y:541,t:1527616902292};\\\", \\\"{x:139,y:541,t:1527616902304};\\\", \\\"{x:141,y:541,t:1527616902321};\\\", \\\"{x:142,y:541,t:1527616902336};\\\", \\\"{x:144,y:541,t:1527616902354};\\\", \\\"{x:145,y:541,t:1527616902437};\\\", \\\"{x:146,y:541,t:1527616902461};\\\", \\\"{x:147,y:541,t:1527616902470};\\\", \\\"{x:148,y:541,t:1527616902487};\\\", \\\"{x:150,y:541,t:1527616902909};\\\", \\\"{x:152,y:541,t:1527616902920};\\\", \\\"{x:166,y:542,t:1527616902938};\\\", \\\"{x:190,y:546,t:1527616902955};\\\", \\\"{x:221,y:549,t:1527616902971};\\\", \\\"{x:256,y:556,t:1527616902987};\\\", \\\"{x:317,y:565,t:1527616903005};\\\", \\\"{x:346,y:568,t:1527616903020};\\\", \\\"{x:375,y:569,t:1527616903037};\\\", \\\"{x:403,y:571,t:1527616903054};\\\", \\\"{x:422,y:571,t:1527616903070};\\\", \\\"{x:436,y:571,t:1527616903087};\\\", \\\"{x:448,y:571,t:1527616903104};\\\", \\\"{x:458,y:571,t:1527616903120};\\\", \\\"{x:470,y:571,t:1527616903138};\\\", \\\"{x:487,y:571,t:1527616903155};\\\", \\\"{x:509,y:571,t:1527616903171};\\\", \\\"{x:530,y:571,t:1527616903188};\\\", \\\"{x:562,y:571,t:1527616903205};\\\", \\\"{x:581,y:572,t:1527616903220};\\\", \\\"{x:603,y:573,t:1527616903238};\\\", \\\"{x:625,y:575,t:1527616903255};\\\", \\\"{x:641,y:577,t:1527616903271};\\\", \\\"{x:659,y:577,t:1527616903288};\\\", \\\"{x:677,y:577,t:1527616903304};\\\", \\\"{x:697,y:577,t:1527616903321};\\\", \\\"{x:723,y:577,t:1527616903337};\\\", \\\"{x:752,y:577,t:1527616903355};\\\", \\\"{x:782,y:577,t:1527616903372};\\\", \\\"{x:813,y:577,t:1527616903388};\\\", \\\"{x:850,y:577,t:1527616903404};\\\", \\\"{x:868,y:577,t:1527616903422};\\\", \\\"{x:874,y:577,t:1527616903437};\\\", \\\"{x:875,y:577,t:1527616903455};\\\", \\\"{x:876,y:577,t:1527616903525};\\\", \\\"{x:876,y:575,t:1527616903538};\\\", \\\"{x:876,y:570,t:1527616903554};\\\", \\\"{x:876,y:563,t:1527616903572};\\\", \\\"{x:876,y:555,t:1527616903588};\\\", \\\"{x:871,y:541,t:1527616903605};\\\", \\\"{x:868,y:535,t:1527616903622};\\\", \\\"{x:866,y:531,t:1527616903637};\\\", \\\"{x:863,y:528,t:1527616903654};\\\", \\\"{x:860,y:524,t:1527616903672};\\\", \\\"{x:858,y:522,t:1527616903687};\\\", \\\"{x:856,y:518,t:1527616903705};\\\", \\\"{x:853,y:515,t:1527616903723};\\\", \\\"{x:850,y:510,t:1527616903740};\\\", \\\"{x:849,y:509,t:1527616903755};\\\", \\\"{x:849,y:508,t:1527616903771};\\\", \\\"{x:847,y:506,t:1527616903788};\\\", \\\"{x:846,y:506,t:1527616903805};\\\", \\\"{x:846,y:505,t:1527616903822};\\\", \\\"{x:846,y:504,t:1527616903838};\\\", \\\"{x:844,y:502,t:1527616903855};\\\", \\\"{x:844,y:500,t:1527616903871};\\\", \\\"{x:843,y:500,t:1527616903889};\\\", \\\"{x:843,y:499,t:1527616903905};\\\", \\\"{x:836,y:499,t:1527616904204};\\\", \\\"{x:817,y:500,t:1527616904212};\\\", \\\"{x:792,y:500,t:1527616904221};\\\", \\\"{x:699,y:505,t:1527616904239};\\\", \\\"{x:591,y:505,t:1527616904256};\\\", \\\"{x:472,y:505,t:1527616904272};\\\", \\\"{x:361,y:505,t:1527616904289};\\\", \\\"{x:267,y:505,t:1527616904307};\\\", \\\"{x:192,y:505,t:1527616904321};\\\", \\\"{x:147,y:505,t:1527616904339};\\\", \\\"{x:125,y:506,t:1527616904356};\\\", \\\"{x:119,y:506,t:1527616904372};\\\", \\\"{x:117,y:507,t:1527616904389};\\\", \\\"{x:116,y:507,t:1527616904428};\\\", \\\"{x:115,y:507,t:1527616904445};\\\", \\\"{x:113,y:507,t:1527616904456};\\\", \\\"{x:110,y:509,t:1527616904472};\\\", \\\"{x:108,y:510,t:1527616904489};\\\", \\\"{x:107,y:514,t:1527616904505};\\\", \\\"{x:107,y:520,t:1527616904522};\\\", \\\"{x:107,y:523,t:1527616904538};\\\", \\\"{x:107,y:526,t:1527616904557};\\\", \\\"{x:113,y:531,t:1527616904573};\\\", \\\"{x:125,y:532,t:1527616904588};\\\", \\\"{x:135,y:535,t:1527616904606};\\\", \\\"{x:142,y:537,t:1527616904623};\\\", \\\"{x:148,y:537,t:1527616904639};\\\", \\\"{x:151,y:537,t:1527616904657};\\\", \\\"{x:153,y:537,t:1527616904700};\\\", \\\"{x:154,y:537,t:1527616904708};\\\", \\\"{x:157,y:537,t:1527616904722};\\\", \\\"{x:163,y:537,t:1527616904738};\\\", \\\"{x:167,y:536,t:1527616904755};\\\", \\\"{x:171,y:536,t:1527616905092};\\\", \\\"{x:180,y:544,t:1527616905105};\\\", \\\"{x:211,y:570,t:1527616905123};\\\", \\\"{x:263,y:600,t:1527616905140};\\\", \\\"{x:320,y:629,t:1527616905156};\\\", \\\"{x:401,y:666,t:1527616905172};\\\", \\\"{x:431,y:679,t:1527616905190};\\\", \\\"{x:444,y:685,t:1527616905206};\\\", \\\"{x:448,y:687,t:1527616905222};\\\", \\\"{x:449,y:688,t:1527616905268};\\\", \\\"{x:450,y:689,t:1527616905316};\\\", \\\"{x:450,y:690,t:1527616905324};\\\", \\\"{x:450,y:691,t:1527616905340};\\\", \\\"{x:451,y:692,t:1527616905356};\\\", \\\"{x:451,y:694,t:1527616905372};\\\", \\\"{x:451,y:695,t:1527616905396};\\\", \\\"{x:452,y:697,t:1527616905407};\\\", \\\"{x:454,y:700,t:1527616905423};\\\", \\\"{x:456,y:702,t:1527616905440};\\\", \\\"{x:458,y:704,t:1527616905457};\\\", \\\"{x:460,y:706,t:1527616905473};\\\", \\\"{x:464,y:711,t:1527616905490};\\\", \\\"{x:472,y:719,t:1527616905507};\\\", \\\"{x:480,y:728,t:1527616905523};\\\", \\\"{x:486,y:735,t:1527616905539};\\\", \\\"{x:495,y:743,t:1527616905556};\\\", \\\"{x:496,y:745,t:1527616905572};\\\", \\\"{x:496,y:744,t:1527616905980};\\\", \\\"{x:496,y:743,t:1527616905989};\\\", \\\"{x:496,y:741,t:1527616906012};\\\", \\\"{x:496,y:740,t:1527616906260};\\\", \\\"{x:496,y:739,t:1527616906284};\\\" ] }, { \\\"rt\\\": 6317, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 353043, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -M -12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:738,t:1527616907902};\\\", \\\"{x:500,y:738,t:1527616907910};\\\", \\\"{x:508,y:738,t:1527616907926};\\\", \\\"{x:520,y:731,t:1527616907944};\\\", \\\"{x:530,y:727,t:1527616907959};\\\", \\\"{x:538,y:722,t:1527616907976};\\\", \\\"{x:541,y:718,t:1527616907993};\\\", \\\"{x:541,y:714,t:1527616908009};\\\", \\\"{x:541,y:712,t:1527616908025};\\\", \\\"{x:540,y:709,t:1527616908041};\\\", \\\"{x:538,y:709,t:1527616908058};\\\", \\\"{x:539,y:708,t:1527616908341};\\\", \\\"{x:552,y:706,t:1527616908359};\\\", \\\"{x:553,y:706,t:1527616908375};\\\", \\\"{x:559,y:708,t:1527616908392};\\\", \\\"{x:568,y:712,t:1527616908409};\\\", \\\"{x:588,y:715,t:1527616908425};\\\", \\\"{x:613,y:715,t:1527616908442};\\\", \\\"{x:646,y:719,t:1527616908459};\\\", \\\"{x:685,y:725,t:1527616908475};\\\", \\\"{x:737,y:736,t:1527616908491};\\\", \\\"{x:818,y:744,t:1527616908509};\\\", \\\"{x:874,y:752,t:1527616908525};\\\", \\\"{x:938,y:762,t:1527616908542};\\\", \\\"{x:992,y:764,t:1527616908560};\\\", \\\"{x:1039,y:770,t:1527616908576};\\\", \\\"{x:1084,y:776,t:1527616908592};\\\", \\\"{x:1132,y:783,t:1527616908609};\\\", \\\"{x:1173,y:787,t:1527616908626};\\\", \\\"{x:1219,y:794,t:1527616908643};\\\", \\\"{x:1261,y:800,t:1527616908659};\\\", \\\"{x:1296,y:804,t:1527616908677};\\\", \\\"{x:1329,y:804,t:1527616908692};\\\", \\\"{x:1374,y:804,t:1527616908709};\\\", \\\"{x:1398,y:804,t:1527616908726};\\\", \\\"{x:1419,y:804,t:1527616908742};\\\", \\\"{x:1434,y:801,t:1527616908759};\\\", \\\"{x:1440,y:796,t:1527616908776};\\\", \\\"{x:1442,y:794,t:1527616908792};\\\", \\\"{x:1442,y:792,t:1527616908809};\\\", \\\"{x:1442,y:789,t:1527616908827};\\\", \\\"{x:1442,y:784,t:1527616908842};\\\", \\\"{x:1437,y:777,t:1527616908860};\\\", \\\"{x:1429,y:771,t:1527616908877};\\\", \\\"{x:1419,y:767,t:1527616908892};\\\", \\\"{x:1392,y:759,t:1527616908909};\\\", \\\"{x:1375,y:757,t:1527616908927};\\\", \\\"{x:1364,y:755,t:1527616908942};\\\", \\\"{x:1361,y:755,t:1527616908959};\\\", \\\"{x:1359,y:754,t:1527616908976};\\\", \\\"{x:1356,y:751,t:1527616908992};\\\", \\\"{x:1355,y:748,t:1527616909009};\\\", \\\"{x:1354,y:746,t:1527616909026};\\\", \\\"{x:1352,y:741,t:1527616909043};\\\", \\\"{x:1352,y:738,t:1527616909059};\\\", \\\"{x:1351,y:731,t:1527616909076};\\\", \\\"{x:1351,y:727,t:1527616909093};\\\", \\\"{x:1351,y:723,t:1527616909109};\\\", \\\"{x:1351,y:720,t:1527616909126};\\\", \\\"{x:1351,y:717,t:1527616909144};\\\", \\\"{x:1351,y:715,t:1527616909160};\\\", \\\"{x:1350,y:714,t:1527616909246};\\\", \\\"{x:1350,y:717,t:1527616909261};\\\", \\\"{x:1350,y:725,t:1527616909277};\\\", \\\"{x:1350,y:770,t:1527616909292};\\\", \\\"{x:1350,y:802,t:1527616909309};\\\", \\\"{x:1360,y:831,t:1527616909326};\\\", \\\"{x:1373,y:859,t:1527616909344};\\\", \\\"{x:1379,y:877,t:1527616909359};\\\", \\\"{x:1383,y:890,t:1527616909376};\\\", \\\"{x:1384,y:899,t:1527616909397};\\\", \\\"{x:1384,y:904,t:1527616909409};\\\", \\\"{x:1382,y:911,t:1527616909425};\\\", \\\"{x:1381,y:921,t:1527616909443};\\\", \\\"{x:1377,y:931,t:1527616909459};\\\", \\\"{x:1369,y:948,t:1527616909475};\\\", \\\"{x:1362,y:957,t:1527616909492};\\\", \\\"{x:1359,y:963,t:1527616909510};\\\", \\\"{x:1355,y:969,t:1527616909526};\\\", \\\"{x:1354,y:971,t:1527616909543};\\\", \\\"{x:1354,y:974,t:1527616909560};\\\", \\\"{x:1354,y:976,t:1527616909576};\\\", \\\"{x:1354,y:978,t:1527616909593};\\\", \\\"{x:1354,y:980,t:1527616909610};\\\", \\\"{x:1354,y:981,t:1527616909626};\\\", \\\"{x:1354,y:983,t:1527616909644};\\\", \\\"{x:1352,y:982,t:1527616909829};\\\", \\\"{x:1350,y:980,t:1527616909844};\\\", \\\"{x:1340,y:971,t:1527616909860};\\\", \\\"{x:1327,y:961,t:1527616909878};\\\", \\\"{x:1327,y:959,t:1527616909981};\\\", \\\"{x:1328,y:956,t:1527616909993};\\\", \\\"{x:1333,y:948,t:1527616910011};\\\", \\\"{x:1338,y:940,t:1527616910027};\\\", \\\"{x:1345,y:928,t:1527616910043};\\\", \\\"{x:1350,y:914,t:1527616910060};\\\", \\\"{x:1356,y:899,t:1527616910077};\\\", \\\"{x:1358,y:885,t:1527616910094};\\\", \\\"{x:1361,y:874,t:1527616910110};\\\", \\\"{x:1362,y:862,t:1527616910128};\\\", \\\"{x:1365,y:852,t:1527616910143};\\\", \\\"{x:1366,y:843,t:1527616910160};\\\", \\\"{x:1367,y:833,t:1527616910177};\\\", \\\"{x:1367,y:823,t:1527616910194};\\\", \\\"{x:1367,y:815,t:1527616910211};\\\", \\\"{x:1367,y:808,t:1527616910228};\\\", \\\"{x:1367,y:802,t:1527616910243};\\\", \\\"{x:1367,y:795,t:1527616910260};\\\", \\\"{x:1364,y:777,t:1527616910277};\\\", \\\"{x:1360,y:762,t:1527616910294};\\\", \\\"{x:1358,y:754,t:1527616910310};\\\", \\\"{x:1358,y:748,t:1527616910328};\\\", \\\"{x:1356,y:744,t:1527616910345};\\\", \\\"{x:1356,y:742,t:1527616910360};\\\", \\\"{x:1356,y:740,t:1527616910377};\\\", \\\"{x:1355,y:739,t:1527616910453};\\\", \\\"{x:1353,y:742,t:1527616910461};\\\", \\\"{x:1351,y:758,t:1527616910477};\\\", \\\"{x:1351,y:782,t:1527616910494};\\\", \\\"{x:1351,y:808,t:1527616910510};\\\", \\\"{x:1351,y:828,t:1527616910527};\\\", \\\"{x:1354,y:845,t:1527616910545};\\\", \\\"{x:1360,y:861,t:1527616910561};\\\", \\\"{x:1363,y:872,t:1527616910578};\\\", \\\"{x:1364,y:878,t:1527616910594};\\\", \\\"{x:1365,y:882,t:1527616910610};\\\", \\\"{x:1367,y:888,t:1527616910627};\\\", \\\"{x:1372,y:897,t:1527616910644};\\\", \\\"{x:1373,y:900,t:1527616910660};\\\", \\\"{x:1379,y:918,t:1527616910677};\\\", \\\"{x:1382,y:928,t:1527616910694};\\\", \\\"{x:1385,y:936,t:1527616910710};\\\", \\\"{x:1386,y:940,t:1527616910727};\\\", \\\"{x:1388,y:945,t:1527616910744};\\\", \\\"{x:1390,y:951,t:1527616910761};\\\", \\\"{x:1390,y:959,t:1527616910777};\\\", \\\"{x:1393,y:964,t:1527616910795};\\\", \\\"{x:1393,y:970,t:1527616910812};\\\", \\\"{x:1393,y:971,t:1527616910827};\\\", \\\"{x:1393,y:973,t:1527616910844};\\\", \\\"{x:1393,y:976,t:1527616910861};\\\", \\\"{x:1393,y:978,t:1527616910877};\\\", \\\"{x:1392,y:979,t:1527616910895};\\\", \\\"{x:1391,y:980,t:1527616910912};\\\", \\\"{x:1390,y:981,t:1527616910927};\\\", \\\"{x:1388,y:981,t:1527616910956};\\\", \\\"{x:1385,y:981,t:1527616910965};\\\", \\\"{x:1382,y:981,t:1527616910977};\\\", \\\"{x:1377,y:973,t:1527616910995};\\\", \\\"{x:1369,y:959,t:1527616911012};\\\", \\\"{x:1360,y:941,t:1527616911027};\\\", \\\"{x:1347,y:913,t:1527616911045};\\\", \\\"{x:1340,y:899,t:1527616911061};\\\", \\\"{x:1333,y:885,t:1527616911077};\\\", \\\"{x:1328,y:875,t:1527616911094};\\\", \\\"{x:1323,y:866,t:1527616911111};\\\", \\\"{x:1313,y:853,t:1527616911128};\\\", \\\"{x:1302,y:841,t:1527616911144};\\\", \\\"{x:1283,y:827,t:1527616911161};\\\", \\\"{x:1259,y:816,t:1527616911177};\\\", \\\"{x:1224,y:802,t:1527616911194};\\\", \\\"{x:1194,y:791,t:1527616911212};\\\", \\\"{x:1126,y:774,t:1527616911229};\\\", \\\"{x:1104,y:770,t:1527616911245};\\\", \\\"{x:1036,y:755,t:1527616911261};\\\", \\\"{x:985,y:748,t:1527616911278};\\\", \\\"{x:927,y:739,t:1527616911295};\\\", \\\"{x:859,y:727,t:1527616911311};\\\", \\\"{x:776,y:718,t:1527616911329};\\\", \\\"{x:676,y:702,t:1527616911344};\\\", \\\"{x:540,y:679,t:1527616911362};\\\", \\\"{x:415,y:660,t:1527616911379};\\\", \\\"{x:298,y:654,t:1527616911394};\\\", \\\"{x:144,y:618,t:1527616911428};\\\", \\\"{x:140,y:617,t:1527616911444};\\\", \\\"{x:140,y:616,t:1527616911484};\\\", \\\"{x:138,y:615,t:1527616911524};\\\", \\\"{x:136,y:614,t:1527616911532};\\\", \\\"{x:135,y:613,t:1527616911544};\\\", \\\"{x:132,y:610,t:1527616911561};\\\", \\\"{x:131,y:607,t:1527616911578};\\\", \\\"{x:130,y:606,t:1527616911594};\\\", \\\"{x:130,y:605,t:1527616911611};\\\", \\\"{x:130,y:604,t:1527616911628};\\\", \\\"{x:129,y:602,t:1527616911645};\\\", \\\"{x:129,y:601,t:1527616911661};\\\", \\\"{x:129,y:600,t:1527616911686};\\\", \\\"{x:129,y:599,t:1527616911700};\\\", \\\"{x:129,y:598,t:1527616911710};\\\", \\\"{x:130,y:596,t:1527616911728};\\\", \\\"{x:132,y:591,t:1527616911746};\\\", \\\"{x:135,y:587,t:1527616911761};\\\", \\\"{x:137,y:584,t:1527616911777};\\\", \\\"{x:138,y:582,t:1527616911795};\\\", \\\"{x:139,y:581,t:1527616911810};\\\", \\\"{x:141,y:577,t:1527616911828};\\\", \\\"{x:141,y:573,t:1527616911844};\\\", \\\"{x:141,y:570,t:1527616911861};\\\", \\\"{x:143,y:568,t:1527616911878};\\\", \\\"{x:144,y:566,t:1527616911895};\\\", \\\"{x:144,y:563,t:1527616911911};\\\", \\\"{x:145,y:559,t:1527616911930};\\\", \\\"{x:147,y:557,t:1527616911945};\\\", \\\"{x:148,y:553,t:1527616911962};\\\", \\\"{x:149,y:551,t:1527616911978};\\\", \\\"{x:149,y:549,t:1527616911995};\\\", \\\"{x:152,y:544,t:1527616912012};\\\", \\\"{x:152,y:543,t:1527616912036};\\\", \\\"{x:152,y:542,t:1527616912276};\\\", \\\"{x:158,y:546,t:1527616912307};\\\", \\\"{x:166,y:557,t:1527616912317};\\\", \\\"{x:178,y:573,t:1527616912328};\\\", \\\"{x:218,y:613,t:1527616912345};\\\", \\\"{x:280,y:663,t:1527616912363};\\\", \\\"{x:357,y:704,t:1527616912378};\\\", \\\"{x:432,y:742,t:1527616912395};\\\", \\\"{x:523,y:777,t:1527616912412};\\\", \\\"{x:560,y:788,t:1527616912428};\\\", \\\"{x:572,y:789,t:1527616912445};\\\", \\\"{x:574,y:789,t:1527616912461};\\\", \\\"{x:575,y:786,t:1527616912533};\\\", \\\"{x:576,y:783,t:1527616912545};\\\", \\\"{x:579,y:777,t:1527616912562};\\\", \\\"{x:579,y:773,t:1527616912580};\\\", \\\"{x:579,y:765,t:1527616912595};\\\", \\\"{x:576,y:756,t:1527616912612};\\\", \\\"{x:573,y:752,t:1527616912629};\\\", \\\"{x:570,y:748,t:1527616912645};\\\", \\\"{x:567,y:746,t:1527616912662};\\\", \\\"{x:563,y:744,t:1527616912680};\\\", \\\"{x:554,y:741,t:1527616912695};\\\", \\\"{x:540,y:737,t:1527616912712};\\\", \\\"{x:523,y:735,t:1527616912729};\\\", \\\"{x:509,y:734,t:1527616912745};\\\", \\\"{x:499,y:731,t:1527616912762};\\\", \\\"{x:495,y:731,t:1527616912779};\\\", \\\"{x:494,y:730,t:1527616912796};\\\", \\\"{x:492,y:730,t:1527616913005};\\\", \\\"{x:491,y:728,t:1527616913013};\\\", \\\"{x:486,y:727,t:1527616913030};\\\", \\\"{x:483,y:726,t:1527616913046};\\\", \\\"{x:479,y:724,t:1527616913062};\\\", \\\"{x:478,y:724,t:1527616913079};\\\", \\\"{x:477,y:722,t:1527616914285};\\\", \\\"{x:477,y:721,t:1527616914298};\\\", \\\"{x:478,y:719,t:1527616914313};\\\", \\\"{x:482,y:718,t:1527616914331};\\\", \\\"{x:487,y:716,t:1527616914357};\\\", \\\"{x:489,y:714,t:1527616914363};\\\", \\\"{x:491,y:713,t:1527616914380};\\\", \\\"{x:493,y:713,t:1527616914397};\\\", \\\"{x:497,y:711,t:1527616914412};\\\", \\\"{x:498,y:710,t:1527616914430};\\\", \\\"{x:502,y:709,t:1527616914446};\\\", \\\"{x:506,y:707,t:1527616914462};\\\", \\\"{x:511,y:706,t:1527616914480};\\\", \\\"{x:522,y:706,t:1527616914497};\\\" ] }, { \\\"rt\\\": 35905, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 390226, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-I -L -L -Z -02 PM-X -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:611,y:706,t:1527616914615};\\\", \\\"{x:626,y:709,t:1527616914647};\\\", \\\"{x:627,y:710,t:1527616914668};\\\", \\\"{x:628,y:712,t:1527616914747};\\\", \\\"{x:628,y:714,t:1527616914764};\\\", \\\"{x:629,y:720,t:1527616914779};\\\", \\\"{x:630,y:724,t:1527616914797};\\\", \\\"{x:630,y:728,t:1527616914814};\\\", \\\"{x:630,y:731,t:1527616914829};\\\", \\\"{x:630,y:735,t:1527616914847};\\\", \\\"{x:630,y:736,t:1527616914864};\\\", \\\"{x:630,y:737,t:1527616914880};\\\", \\\"{x:630,y:738,t:1527616914933};\\\", \\\"{x:626,y:734,t:1527616915013};\\\", \\\"{x:626,y:733,t:1527616915022};\\\", \\\"{x:625,y:732,t:1527616915030};\\\", \\\"{x:624,y:731,t:1527616915140};\\\", \\\"{x:623,y:731,t:1527616915156};\\\", \\\"{x:622,y:731,t:1527616915172};\\\", \\\"{x:618,y:728,t:1527616915180};\\\", \\\"{x:614,y:727,t:1527616915197};\\\", \\\"{x:603,y:722,t:1527616915214};\\\", \\\"{x:592,y:717,t:1527616915231};\\\", \\\"{x:582,y:708,t:1527616915247};\\\", \\\"{x:572,y:697,t:1527616915264};\\\", \\\"{x:560,y:684,t:1527616915282};\\\", \\\"{x:548,y:671,t:1527616915297};\\\", \\\"{x:537,y:659,t:1527616915314};\\\", \\\"{x:527,y:646,t:1527616915331};\\\", \\\"{x:519,y:634,t:1527616915347};\\\", \\\"{x:508,y:615,t:1527616915364};\\\", \\\"{x:502,y:601,t:1527616915381};\\\", \\\"{x:496,y:589,t:1527616915398};\\\", \\\"{x:488,y:581,t:1527616915414};\\\", \\\"{x:483,y:575,t:1527616915431};\\\", \\\"{x:478,y:565,t:1527616915448};\\\", \\\"{x:474,y:560,t:1527616915464};\\\", \\\"{x:469,y:553,t:1527616915481};\\\", \\\"{x:466,y:548,t:1527616915497};\\\", \\\"{x:463,y:540,t:1527616915514};\\\", \\\"{x:456,y:532,t:1527616915531};\\\", \\\"{x:450,y:522,t:1527616915548};\\\", \\\"{x:448,y:519,t:1527616915564};\\\", \\\"{x:448,y:514,t:1527616915581};\\\", \\\"{x:448,y:512,t:1527616915598};\\\", \\\"{x:448,y:509,t:1527616915614};\\\", \\\"{x:448,y:507,t:1527616915631};\\\", \\\"{x:448,y:505,t:1527616915647};\\\", \\\"{x:448,y:503,t:1527616915664};\\\", \\\"{x:450,y:499,t:1527616915681};\\\", \\\"{x:456,y:494,t:1527616915698};\\\", \\\"{x:467,y:487,t:1527616915714};\\\", \\\"{x:475,y:480,t:1527616915733};\\\", \\\"{x:481,y:477,t:1527616915747};\\\", \\\"{x:487,y:475,t:1527616915764};\\\", \\\"{x:488,y:475,t:1527616915782};\\\", \\\"{x:490,y:473,t:1527616915798};\\\", \\\"{x:492,y:473,t:1527616915821};\\\", \\\"{x:494,y:473,t:1527616915831};\\\", \\\"{x:499,y:473,t:1527616915849};\\\", \\\"{x:508,y:474,t:1527616915865};\\\", \\\"{x:517,y:475,t:1527616915881};\\\", \\\"{x:521,y:476,t:1527616915898};\\\", \\\"{x:522,y:476,t:1527616915915};\\\", \\\"{x:523,y:477,t:1527616915931};\\\", \\\"{x:526,y:478,t:1527616915949};\\\", \\\"{x:527,y:478,t:1527616915966};\\\", \\\"{x:530,y:479,t:1527616915982};\\\", \\\"{x:531,y:480,t:1527616915999};\\\", \\\"{x:532,y:480,t:1527616916015};\\\", \\\"{x:534,y:480,t:1527616916141};\\\", \\\"{x:534,y:479,t:1527616916149};\\\", \\\"{x:539,y:472,t:1527616916166};\\\", \\\"{x:542,y:464,t:1527616916183};\\\", \\\"{x:545,y:459,t:1527616916200};\\\", \\\"{x:547,y:451,t:1527616916215};\\\", \\\"{x:549,y:448,t:1527616916232};\\\", \\\"{x:550,y:447,t:1527616916250};\\\", \\\"{x:550,y:445,t:1527616916266};\\\", \\\"{x:553,y:443,t:1527616916283};\\\", \\\"{x:553,y:442,t:1527616916300};\\\", \\\"{x:556,y:439,t:1527616916316};\\\", \\\"{x:560,y:434,t:1527616916333};\\\", \\\"{x:564,y:430,t:1527616916349};\\\", \\\"{x:577,y:424,t:1527616916366};\\\", \\\"{x:591,y:423,t:1527616916383};\\\", \\\"{x:608,y:423,t:1527616916399};\\\", \\\"{x:627,y:426,t:1527616916417};\\\", \\\"{x:647,y:431,t:1527616916432};\\\", \\\"{x:664,y:436,t:1527616916449};\\\", \\\"{x:689,y:442,t:1527616916467};\\\", \\\"{x:715,y:447,t:1527616916483};\\\", \\\"{x:732,y:451,t:1527616916499};\\\", \\\"{x:750,y:458,t:1527616916516};\\\", \\\"{x:759,y:463,t:1527616916533};\\\", \\\"{x:768,y:467,t:1527616916550};\\\", \\\"{x:772,y:470,t:1527616916567};\\\", \\\"{x:773,y:470,t:1527616916583};\\\", \\\"{x:773,y:471,t:1527616916600};\\\", \\\"{x:773,y:480,t:1527616916884};\\\", \\\"{x:773,y:499,t:1527616916900};\\\", \\\"{x:773,y:507,t:1527616916917};\\\", \\\"{x:773,y:508,t:1527616916933};\\\", \\\"{x:770,y:513,t:1527616917788};\\\", \\\"{x:768,y:513,t:1527616917799};\\\", \\\"{x:765,y:512,t:1527616917816};\\\", \\\"{x:746,y:513,t:1527616917833};\\\", \\\"{x:734,y:513,t:1527616917849};\\\", \\\"{x:727,y:513,t:1527616917866};\\\", \\\"{x:724,y:513,t:1527616917882};\\\", \\\"{x:723,y:514,t:1527616917899};\\\", \\\"{x:722,y:514,t:1527616917916};\\\", \\\"{x:722,y:515,t:1527616917933};\\\", \\\"{x:736,y:524,t:1527616917949};\\\", \\\"{x:765,y:554,t:1527616917967};\\\", \\\"{x:809,y:602,t:1527616917983};\\\", \\\"{x:865,y:652,t:1527616918000};\\\", \\\"{x:937,y:699,t:1527616918016};\\\", \\\"{x:997,y:736,t:1527616918033};\\\", \\\"{x:1064,y:765,t:1527616918049};\\\", \\\"{x:1142,y:791,t:1527616918066};\\\", \\\"{x:1201,y:810,t:1527616918083};\\\", \\\"{x:1241,y:817,t:1527616918100};\\\", \\\"{x:1280,y:818,t:1527616918116};\\\", \\\"{x:1297,y:818,t:1527616918133};\\\", \\\"{x:1306,y:815,t:1527616918150};\\\", \\\"{x:1308,y:814,t:1527616918167};\\\", \\\"{x:1312,y:811,t:1527616918517};\\\", \\\"{x:1352,y:746,t:1527616918534};\\\", \\\"{x:1388,y:693,t:1527616918551};\\\", \\\"{x:1434,y:629,t:1527616918567};\\\", \\\"{x:1465,y:586,t:1527616918584};\\\", \\\"{x:1504,y:516,t:1527616918601};\\\", \\\"{x:1558,y:442,t:1527616918617};\\\", \\\"{x:1590,y:408,t:1527616918633};\\\", \\\"{x:1606,y:391,t:1527616918650};\\\", \\\"{x:1613,y:380,t:1527616918668};\\\", \\\"{x:1615,y:378,t:1527616918684};\\\", \\\"{x:1615,y:377,t:1527616918717};\\\", \\\"{x:1614,y:377,t:1527616918788};\\\", \\\"{x:1611,y:377,t:1527616918800};\\\", \\\"{x:1595,y:380,t:1527616918817};\\\", \\\"{x:1572,y:384,t:1527616918833};\\\", \\\"{x:1534,y:384,t:1527616918850};\\\", \\\"{x:1492,y:389,t:1527616918867};\\\", \\\"{x:1451,y:392,t:1527616918883};\\\", \\\"{x:1420,y:392,t:1527616918900};\\\", \\\"{x:1416,y:392,t:1527616918917};\\\", \\\"{x:1414,y:392,t:1527616918933};\\\", \\\"{x:1413,y:394,t:1527616919125};\\\", \\\"{x:1413,y:399,t:1527616919134};\\\", \\\"{x:1419,y:412,t:1527616919150};\\\", \\\"{x:1426,y:427,t:1527616919167};\\\", \\\"{x:1436,y:448,t:1527616919185};\\\", \\\"{x:1447,y:470,t:1527616919201};\\\", \\\"{x:1461,y:494,t:1527616919218};\\\", \\\"{x:1476,y:513,t:1527616919234};\\\", \\\"{x:1485,y:527,t:1527616919251};\\\", \\\"{x:1491,y:536,t:1527616919268};\\\", \\\"{x:1496,y:547,t:1527616919284};\\\", \\\"{x:1498,y:551,t:1527616919300};\\\", \\\"{x:1499,y:555,t:1527616919318};\\\", \\\"{x:1499,y:556,t:1527616919335};\\\", \\\"{x:1499,y:558,t:1527616919350};\\\", \\\"{x:1499,y:560,t:1527616919368};\\\", \\\"{x:1499,y:563,t:1527616919385};\\\", \\\"{x:1499,y:566,t:1527616919400};\\\", \\\"{x:1499,y:574,t:1527616919418};\\\", \\\"{x:1499,y:582,t:1527616919434};\\\", \\\"{x:1499,y:592,t:1527616919451};\\\", \\\"{x:1498,y:599,t:1527616919468};\\\", \\\"{x:1497,y:607,t:1527616919485};\\\", \\\"{x:1495,y:614,t:1527616919501};\\\", \\\"{x:1495,y:624,t:1527616919518};\\\", \\\"{x:1499,y:636,t:1527616919535};\\\", \\\"{x:1511,y:651,t:1527616919551};\\\", \\\"{x:1532,y:677,t:1527616919567};\\\", \\\"{x:1565,y:711,t:1527616919585};\\\", \\\"{x:1586,y:731,t:1527616919602};\\\", \\\"{x:1611,y:759,t:1527616919618};\\\", \\\"{x:1629,y:783,t:1527616919635};\\\", \\\"{x:1638,y:799,t:1527616919651};\\\", \\\"{x:1642,y:814,t:1527616919668};\\\", \\\"{x:1641,y:835,t:1527616919685};\\\", \\\"{x:1622,y:847,t:1527616919702};\\\", \\\"{x:1593,y:849,t:1527616919718};\\\", \\\"{x:1545,y:850,t:1527616919735};\\\", \\\"{x:1434,y:835,t:1527616919752};\\\", \\\"{x:1331,y:801,t:1527616919768};\\\", \\\"{x:1260,y:762,t:1527616919784};\\\", \\\"{x:1208,y:719,t:1527616919802};\\\", \\\"{x:1187,y:681,t:1527616919817};\\\", \\\"{x:1195,y:656,t:1527616919835};\\\", \\\"{x:1233,y:618,t:1527616919851};\\\", \\\"{x:1320,y:575,t:1527616919894};\\\", \\\"{x:1486,y:523,t:1527616919911};\\\", \\\"{x:1607,y:515,t:1527616919928};\\\", \\\"{x:1719,y:541,t:1527616919944};\\\", \\\"{x:1802,y:592,t:1527616919961};\\\", \\\"{x:1854,y:657,t:1527616919979};\\\", \\\"{x:1867,y:735,t:1527616919994};\\\", \\\"{x:1854,y:803,t:1527616920011};\\\", \\\"{x:1807,y:870,t:1527616920029};\\\", \\\"{x:1731,y:912,t:1527616920045};\\\", \\\"{x:1640,y:952,t:1527616920061};\\\", \\\"{x:1569,y:966,t:1527616920079};\\\", \\\"{x:1531,y:964,t:1527616920095};\\\", \\\"{x:1516,y:945,t:1527616920112};\\\", \\\"{x:1515,y:911,t:1527616920129};\\\", \\\"{x:1528,y:861,t:1527616920145};\\\", \\\"{x:1575,y:812,t:1527616920162};\\\", \\\"{x:1649,y:769,t:1527616920179};\\\", \\\"{x:1718,y:747,t:1527616920196};\\\", \\\"{x:1762,y:745,t:1527616920211};\\\", \\\"{x:1779,y:755,t:1527616920229};\\\", \\\"{x:1782,y:782,t:1527616920246};\\\", \\\"{x:1774,y:840,t:1527616920262};\\\", \\\"{x:1717,y:906,t:1527616920279};\\\", \\\"{x:1565,y:967,t:1527616920295};\\\", \\\"{x:1421,y:969,t:1527616920312};\\\", \\\"{x:1257,y:948,t:1527616920330};\\\", \\\"{x:1098,y:906,t:1527616920346};\\\", \\\"{x:1000,y:874,t:1527616920362};\\\", \\\"{x:965,y:841,t:1527616920379};\\\", \\\"{x:961,y:815,t:1527616920396};\\\", \\\"{x:976,y:786,t:1527616920412};\\\", \\\"{x:1037,y:745,t:1527616920429};\\\", \\\"{x:1141,y:704,t:1527616920446};\\\", \\\"{x:1259,y:679,t:1527616920462};\\\", \\\"{x:1352,y:673,t:1527616920478};\\\", \\\"{x:1436,y:718,t:1527616920495};\\\", \\\"{x:1459,y:773,t:1527616920513};\\\", \\\"{x:1461,y:835,t:1527616920529};\\\", \\\"{x:1442,y:892,t:1527616920546};\\\", \\\"{x:1397,y:940,t:1527616920563};\\\", \\\"{x:1343,y:961,t:1527616920579};\\\", \\\"{x:1278,y:964,t:1527616920597};\\\", \\\"{x:1227,y:950,t:1527616920616};\\\", \\\"{x:1178,y:924,t:1527616920628};\\\", \\\"{x:1153,y:889,t:1527616920645};\\\", \\\"{x:1142,y:845,t:1527616920662};\\\", \\\"{x:1142,y:814,t:1527616920679};\\\", \\\"{x:1179,y:753,t:1527616920695};\\\", \\\"{x:1219,y:722,t:1527616920713};\\\", \\\"{x:1257,y:698,t:1527616920728};\\\", \\\"{x:1288,y:681,t:1527616920746};\\\", \\\"{x:1308,y:674,t:1527616920762};\\\", \\\"{x:1325,y:674,t:1527616920779};\\\", \\\"{x:1338,y:679,t:1527616920796};\\\", \\\"{x:1354,y:696,t:1527616920812};\\\", \\\"{x:1365,y:717,t:1527616920829};\\\", \\\"{x:1370,y:733,t:1527616920845};\\\", \\\"{x:1372,y:747,t:1527616920862};\\\", \\\"{x:1372,y:761,t:1527616920879};\\\", \\\"{x:1372,y:783,t:1527616920895};\\\", \\\"{x:1361,y:803,t:1527616920913};\\\", \\\"{x:1342,y:823,t:1527616920929};\\\", \\\"{x:1319,y:834,t:1527616920946};\\\", \\\"{x:1297,y:838,t:1527616920963};\\\", \\\"{x:1275,y:838,t:1527616920979};\\\", \\\"{x:1264,y:838,t:1527616920996};\\\", \\\"{x:1256,y:837,t:1527616921013};\\\", \\\"{x:1252,y:835,t:1527616921029};\\\", \\\"{x:1250,y:835,t:1527616921046};\\\", \\\"{x:1249,y:835,t:1527616921208};\\\", \\\"{x:1248,y:835,t:1527616921216};\\\", \\\"{x:1248,y:834,t:1527616921231};\\\", \\\"{x:1246,y:832,t:1527616921320};\\\", \\\"{x:1245,y:832,t:1527616921336};\\\", \\\"{x:1243,y:831,t:1527616921346};\\\", \\\"{x:1241,y:830,t:1527616921368};\\\", \\\"{x:1239,y:829,t:1527616921408};\\\", \\\"{x:1239,y:828,t:1527616921416};\\\", \\\"{x:1235,y:825,t:1527616921430};\\\", \\\"{x:1230,y:820,t:1527616921447};\\\", \\\"{x:1221,y:808,t:1527616921463};\\\", \\\"{x:1216,y:798,t:1527616921480};\\\", \\\"{x:1213,y:790,t:1527616921496};\\\", \\\"{x:1211,y:773,t:1527616921513};\\\", \\\"{x:1209,y:753,t:1527616921530};\\\", \\\"{x:1209,y:727,t:1527616921547};\\\", \\\"{x:1216,y:696,t:1527616921564};\\\", \\\"{x:1229,y:667,t:1527616921580};\\\", \\\"{x:1241,y:646,t:1527616921597};\\\", \\\"{x:1259,y:622,t:1527616921613};\\\", \\\"{x:1276,y:603,t:1527616921630};\\\", \\\"{x:1290,y:587,t:1527616921647};\\\", \\\"{x:1300,y:574,t:1527616921663};\\\", \\\"{x:1310,y:563,t:1527616921680};\\\", \\\"{x:1311,y:562,t:1527616921697};\\\", \\\"{x:1321,y:554,t:1527616921903};\\\", \\\"{x:1333,y:548,t:1527616921913};\\\", \\\"{x:1351,y:537,t:1527616921930};\\\", \\\"{x:1368,y:524,t:1527616921946};\\\", \\\"{x:1381,y:510,t:1527616921963};\\\", \\\"{x:1395,y:490,t:1527616921980};\\\", \\\"{x:1403,y:476,t:1527616921996};\\\", \\\"{x:1409,y:466,t:1527616922013};\\\", \\\"{x:1414,y:450,t:1527616922030};\\\", \\\"{x:1418,y:439,t:1527616922046};\\\", \\\"{x:1421,y:429,t:1527616922063};\\\", \\\"{x:1422,y:423,t:1527616922079};\\\", \\\"{x:1423,y:416,t:1527616922096};\\\", \\\"{x:1423,y:412,t:1527616922114};\\\", \\\"{x:1425,y:406,t:1527616922129};\\\", \\\"{x:1425,y:404,t:1527616922151};\\\", \\\"{x:1425,y:403,t:1527616922164};\\\", \\\"{x:1426,y:399,t:1527616922179};\\\", \\\"{x:1426,y:393,t:1527616922197};\\\", \\\"{x:1427,y:391,t:1527616922213};\\\", \\\"{x:1427,y:387,t:1527616922230};\\\", \\\"{x:1429,y:384,t:1527616922247};\\\", \\\"{x:1430,y:377,t:1527616922264};\\\", \\\"{x:1431,y:376,t:1527616922279};\\\", \\\"{x:1432,y:375,t:1527616922297};\\\", \\\"{x:1433,y:373,t:1527616922314};\\\", \\\"{x:1434,y:373,t:1527616922672};\\\", \\\"{x:1439,y:373,t:1527616922681};\\\", \\\"{x:1462,y:392,t:1527616922697};\\\", \\\"{x:1481,y:410,t:1527616922714};\\\", \\\"{x:1499,y:426,t:1527616922731};\\\", \\\"{x:1511,y:434,t:1527616922746};\\\", \\\"{x:1522,y:443,t:1527616922763};\\\", \\\"{x:1529,y:448,t:1527616922780};\\\", \\\"{x:1535,y:453,t:1527616922797};\\\", \\\"{x:1537,y:455,t:1527616922813};\\\", \\\"{x:1538,y:455,t:1527616922831};\\\", \\\"{x:1538,y:456,t:1527616922847};\\\", \\\"{x:1540,y:457,t:1527616922863};\\\", \\\"{x:1543,y:459,t:1527616922881};\\\", \\\"{x:1548,y:463,t:1527616922897};\\\", \\\"{x:1555,y:469,t:1527616922914};\\\", \\\"{x:1561,y:473,t:1527616922931};\\\", \\\"{x:1566,y:476,t:1527616922947};\\\", \\\"{x:1569,y:479,t:1527616922964};\\\", \\\"{x:1571,y:481,t:1527616922981};\\\", \\\"{x:1572,y:482,t:1527616922998};\\\", \\\"{x:1577,y:487,t:1527616923014};\\\", \\\"{x:1583,y:494,t:1527616923033};\\\", \\\"{x:1593,y:515,t:1527616923048};\\\", \\\"{x:1603,y:539,t:1527616923063};\\\", \\\"{x:1616,y:570,t:1527616923081};\\\", \\\"{x:1633,y:609,t:1527616923097};\\\", \\\"{x:1643,y:633,t:1527616923113};\\\", \\\"{x:1648,y:651,t:1527616923131};\\\", \\\"{x:1651,y:663,t:1527616923148};\\\", \\\"{x:1653,y:672,t:1527616923164};\\\", \\\"{x:1653,y:677,t:1527616923180};\\\", \\\"{x:1654,y:682,t:1527616923198};\\\", \\\"{x:1654,y:685,t:1527616923213};\\\", \\\"{x:1655,y:689,t:1527616923231};\\\", \\\"{x:1655,y:692,t:1527616923248};\\\", \\\"{x:1655,y:693,t:1527616923264};\\\", \\\"{x:1655,y:694,t:1527616923281};\\\", \\\"{x:1655,y:695,t:1527616923345};\\\", \\\"{x:1655,y:696,t:1527616923352};\\\", \\\"{x:1655,y:697,t:1527616923365};\\\", \\\"{x:1654,y:697,t:1527616923381};\\\", \\\"{x:1651,y:698,t:1527616923398};\\\", \\\"{x:1649,y:698,t:1527616923413};\\\", \\\"{x:1648,y:698,t:1527616923430};\\\", \\\"{x:1647,y:698,t:1527616923455};\\\", \\\"{x:1646,y:698,t:1527616923471};\\\", \\\"{x:1644,y:699,t:1527616923487};\\\", \\\"{x:1642,y:700,t:1527616923503};\\\", \\\"{x:1641,y:700,t:1527616923519};\\\", \\\"{x:1641,y:701,t:1527616923531};\\\", \\\"{x:1638,y:701,t:1527616923547};\\\", \\\"{x:1637,y:702,t:1527616923565};\\\", \\\"{x:1634,y:702,t:1527616923581};\\\", \\\"{x:1633,y:702,t:1527616923598};\\\", \\\"{x:1632,y:703,t:1527616923615};\\\", \\\"{x:1631,y:703,t:1527616923631};\\\", \\\"{x:1628,y:703,t:1527616923648};\\\", \\\"{x:1623,y:703,t:1527616923665};\\\", \\\"{x:1621,y:703,t:1527616923681};\\\", \\\"{x:1620,y:703,t:1527616923698};\\\", \\\"{x:1618,y:703,t:1527616923715};\\\", \\\"{x:1617,y:703,t:1527616923737};\\\", \\\"{x:1616,y:703,t:1527616923760};\\\", \\\"{x:1615,y:703,t:1527616923776};\\\", \\\"{x:1614,y:703,t:1527616925441};\\\", \\\"{x:1613,y:702,t:1527616925464};\\\", \\\"{x:1613,y:701,t:1527616925488};\\\", \\\"{x:1612,y:700,t:1527616925503};\\\", \\\"{x:1612,y:706,t:1527616926953};\\\", \\\"{x:1612,y:719,t:1527616926967};\\\", \\\"{x:1612,y:743,t:1527616926984};\\\", \\\"{x:1612,y:750,t:1527616927000};\\\", \\\"{x:1612,y:754,t:1527616927017};\\\", \\\"{x:1612,y:758,t:1527616927033};\\\", \\\"{x:1612,y:763,t:1527616927050};\\\", \\\"{x:1612,y:766,t:1527616927067};\\\", \\\"{x:1612,y:771,t:1527616927084};\\\", \\\"{x:1612,y:776,t:1527616927100};\\\", \\\"{x:1612,y:781,t:1527616927116};\\\", \\\"{x:1612,y:787,t:1527616927134};\\\", \\\"{x:1612,y:792,t:1527616927149};\\\", \\\"{x:1612,y:796,t:1527616927167};\\\", \\\"{x:1612,y:802,t:1527616927184};\\\", \\\"{x:1612,y:805,t:1527616927199};\\\", \\\"{x:1612,y:807,t:1527616927217};\\\", \\\"{x:1612,y:811,t:1527616927233};\\\", \\\"{x:1612,y:814,t:1527616927250};\\\", \\\"{x:1612,y:818,t:1527616927267};\\\", \\\"{x:1612,y:823,t:1527616927283};\\\", \\\"{x:1612,y:830,t:1527616927301};\\\", \\\"{x:1613,y:836,t:1527616927317};\\\", \\\"{x:1613,y:842,t:1527616927334};\\\", \\\"{x:1613,y:848,t:1527616927351};\\\", \\\"{x:1613,y:853,t:1527616927367};\\\", \\\"{x:1614,y:861,t:1527616927384};\\\", \\\"{x:1614,y:866,t:1527616927401};\\\", \\\"{x:1615,y:872,t:1527616927418};\\\", \\\"{x:1615,y:878,t:1527616927435};\\\", \\\"{x:1615,y:885,t:1527616927451};\\\", \\\"{x:1615,y:892,t:1527616927467};\\\", \\\"{x:1615,y:901,t:1527616927484};\\\", \\\"{x:1615,y:909,t:1527616927501};\\\", \\\"{x:1615,y:918,t:1527616927517};\\\", \\\"{x:1615,y:923,t:1527616927534};\\\", \\\"{x:1615,y:929,t:1527616927551};\\\", \\\"{x:1615,y:932,t:1527616927567};\\\", \\\"{x:1615,y:938,t:1527616927584};\\\", \\\"{x:1615,y:942,t:1527616927601};\\\", \\\"{x:1615,y:947,t:1527616927617};\\\", \\\"{x:1615,y:951,t:1527616927635};\\\", \\\"{x:1615,y:954,t:1527616927652};\\\", \\\"{x:1615,y:955,t:1527616927696};\\\", \\\"{x:1616,y:956,t:1527616927704};\\\", \\\"{x:1616,y:957,t:1527616927718};\\\", \\\"{x:1616,y:958,t:1527616927776};\\\", \\\"{x:1616,y:960,t:1527616927815};\\\", \\\"{x:1616,y:961,t:1527616927903};\\\", \\\"{x:1616,y:963,t:1527616927968};\\\", \\\"{x:1606,y:962,t:1527616933040};\\\", \\\"{x:1572,y:952,t:1527616933056};\\\", \\\"{x:1508,y:936,t:1527616933072};\\\", \\\"{x:1446,y:922,t:1527616933088};\\\", \\\"{x:1391,y:908,t:1527616933105};\\\", \\\"{x:1356,y:899,t:1527616933122};\\\", \\\"{x:1331,y:890,t:1527616933139};\\\", \\\"{x:1289,y:876,t:1527616933156};\\\", \\\"{x:1243,y:859,t:1527616933172};\\\", \\\"{x:1196,y:837,t:1527616933189};\\\", \\\"{x:1140,y:810,t:1527616933205};\\\", \\\"{x:1067,y:786,t:1527616933222};\\\", \\\"{x:980,y:757,t:1527616933238};\\\", \\\"{x:888,y:730,t:1527616933255};\\\", \\\"{x:837,y:714,t:1527616933271};\\\", \\\"{x:781,y:698,t:1527616933288};\\\", \\\"{x:697,y:669,t:1527616933306};\\\", \\\"{x:638,y:651,t:1527616933322};\\\", \\\"{x:608,y:639,t:1527616933338};\\\", \\\"{x:581,y:633,t:1527616933355};\\\", \\\"{x:564,y:627,t:1527616933373};\\\", \\\"{x:550,y:623,t:1527616933388};\\\", \\\"{x:530,y:618,t:1527616933405};\\\", \\\"{x:495,y:609,t:1527616933423};\\\", \\\"{x:474,y:602,t:1527616933439};\\\", \\\"{x:456,y:594,t:1527616933456};\\\", \\\"{x:443,y:590,t:1527616933473};\\\", \\\"{x:424,y:585,t:1527616933488};\\\", \\\"{x:409,y:581,t:1527616933507};\\\", \\\"{x:399,y:579,t:1527616933523};\\\", \\\"{x:392,y:578,t:1527616933539};\\\", \\\"{x:385,y:578,t:1527616933556};\\\", \\\"{x:376,y:576,t:1527616933572};\\\", \\\"{x:365,y:576,t:1527616933590};\\\", \\\"{x:353,y:576,t:1527616933605};\\\", \\\"{x:343,y:576,t:1527616933623};\\\", \\\"{x:342,y:576,t:1527616933671};\\\", \\\"{x:342,y:574,t:1527616933687};\\\", \\\"{x:343,y:573,t:1527616933695};\\\", \\\"{x:345,y:572,t:1527616933706};\\\", \\\"{x:349,y:569,t:1527616933724};\\\", \\\"{x:355,y:566,t:1527616933739};\\\", \\\"{x:357,y:564,t:1527616933756};\\\", \\\"{x:358,y:562,t:1527616933774};\\\", \\\"{x:360,y:560,t:1527616933790};\\\", \\\"{x:361,y:559,t:1527616933806};\\\", \\\"{x:362,y:557,t:1527616933822};\\\", \\\"{x:362,y:555,t:1527616933840};\\\", \\\"{x:362,y:553,t:1527616933856};\\\", \\\"{x:358,y:552,t:1527616933872};\\\", \\\"{x:355,y:551,t:1527616933890};\\\", \\\"{x:350,y:551,t:1527616933906};\\\", \\\"{x:342,y:550,t:1527616933923};\\\", \\\"{x:327,y:550,t:1527616933939};\\\", \\\"{x:305,y:550,t:1527616933956};\\\", \\\"{x:283,y:550,t:1527616933972};\\\", \\\"{x:264,y:551,t:1527616933991};\\\", \\\"{x:252,y:554,t:1527616934006};\\\", \\\"{x:241,y:558,t:1527616934024};\\\", \\\"{x:237,y:559,t:1527616934040};\\\", \\\"{x:235,y:561,t:1527616934056};\\\", \\\"{x:232,y:564,t:1527616934074};\\\", \\\"{x:229,y:566,t:1527616934090};\\\", \\\"{x:221,y:570,t:1527616934106};\\\", \\\"{x:212,y:574,t:1527616934123};\\\", \\\"{x:201,y:578,t:1527616934140};\\\", \\\"{x:190,y:584,t:1527616934156};\\\", \\\"{x:179,y:588,t:1527616934173};\\\", \\\"{x:169,y:593,t:1527616934190};\\\", \\\"{x:162,y:598,t:1527616934207};\\\", \\\"{x:161,y:600,t:1527616934223};\\\", \\\"{x:161,y:602,t:1527616934256};\\\", \\\"{x:161,y:603,t:1527616934273};\\\", \\\"{x:163,y:604,t:1527616934290};\\\", \\\"{x:164,y:604,t:1527616934307};\\\", \\\"{x:171,y:604,t:1527616934323};\\\", \\\"{x:180,y:604,t:1527616934340};\\\", \\\"{x:192,y:604,t:1527616934357};\\\", \\\"{x:209,y:601,t:1527616934373};\\\", \\\"{x:227,y:600,t:1527616934390};\\\", \\\"{x:256,y:599,t:1527616934407};\\\", \\\"{x:275,y:596,t:1527616934423};\\\", \\\"{x:293,y:594,t:1527616934440};\\\", \\\"{x:313,y:591,t:1527616934458};\\\", \\\"{x:337,y:587,t:1527616934473};\\\", \\\"{x:366,y:584,t:1527616934490};\\\", \\\"{x:389,y:584,t:1527616934507};\\\", \\\"{x:411,y:580,t:1527616934524};\\\", \\\"{x:429,y:580,t:1527616934540};\\\", \\\"{x:445,y:580,t:1527616934557};\\\", \\\"{x:461,y:580,t:1527616934573};\\\", \\\"{x:474,y:580,t:1527616934590};\\\", \\\"{x:486,y:580,t:1527616934607};\\\", \\\"{x:491,y:580,t:1527616934623};\\\", \\\"{x:498,y:580,t:1527616934640};\\\", \\\"{x:507,y:580,t:1527616934659};\\\", \\\"{x:516,y:580,t:1527616934673};\\\", \\\"{x:532,y:580,t:1527616934690};\\\", \\\"{x:547,y:580,t:1527616934707};\\\", \\\"{x:566,y:580,t:1527616934724};\\\", \\\"{x:586,y:580,t:1527616934740};\\\", \\\"{x:599,y:580,t:1527616934757};\\\", \\\"{x:608,y:580,t:1527616934774};\\\", \\\"{x:613,y:580,t:1527616934790};\\\", \\\"{x:614,y:580,t:1527616934807};\\\", \\\"{x:615,y:580,t:1527616934824};\\\", \\\"{x:622,y:580,t:1527616935343};\\\", \\\"{x:637,y:587,t:1527616935357};\\\", \\\"{x:698,y:604,t:1527616935375};\\\", \\\"{x:843,y:648,t:1527616935391};\\\", \\\"{x:968,y:688,t:1527616935407};\\\", \\\"{x:1095,y:728,t:1527616935425};\\\", \\\"{x:1221,y:773,t:1527616935441};\\\", \\\"{x:1342,y:824,t:1527616935457};\\\", \\\"{x:1444,y:865,t:1527616935474};\\\", \\\"{x:1515,y:896,t:1527616935491};\\\", \\\"{x:1552,y:914,t:1527616935508};\\\", \\\"{x:1573,y:926,t:1527616935525};\\\", \\\"{x:1588,y:935,t:1527616935541};\\\", \\\"{x:1596,y:942,t:1527616935557};\\\", \\\"{x:1602,y:947,t:1527616935574};\\\", \\\"{x:1611,y:956,t:1527616935592};\\\", \\\"{x:1613,y:958,t:1527616935607};\\\", \\\"{x:1613,y:959,t:1527616935680};\\\", \\\"{x:1611,y:959,t:1527616935692};\\\", \\\"{x:1603,y:959,t:1527616935709};\\\", \\\"{x:1593,y:959,t:1527616935725};\\\", \\\"{x:1579,y:962,t:1527616935742};\\\", \\\"{x:1565,y:963,t:1527616935759};\\\", \\\"{x:1554,y:964,t:1527616935775};\\\", \\\"{x:1535,y:967,t:1527616935792};\\\", \\\"{x:1527,y:969,t:1527616935808};\\\", \\\"{x:1519,y:970,t:1527616935825};\\\", \\\"{x:1513,y:971,t:1527616935842};\\\", \\\"{x:1510,y:972,t:1527616935859};\\\", \\\"{x:1508,y:973,t:1527616935875};\\\", \\\"{x:1507,y:973,t:1527616935892};\\\", \\\"{x:1506,y:973,t:1527616935909};\\\", \\\"{x:1502,y:973,t:1527616935924};\\\", \\\"{x:1495,y:973,t:1527616935941};\\\", \\\"{x:1490,y:973,t:1527616935959};\\\", \\\"{x:1485,y:973,t:1527616935975};\\\", \\\"{x:1482,y:973,t:1527616935992};\\\", \\\"{x:1481,y:973,t:1527616936009};\\\", \\\"{x:1479,y:973,t:1527616936088};\\\", \\\"{x:1478,y:973,t:1527616936096};\\\", \\\"{x:1478,y:972,t:1527616936108};\\\", \\\"{x:1478,y:971,t:1527616936125};\\\", \\\"{x:1477,y:969,t:1527616936142};\\\", \\\"{x:1475,y:964,t:1527616936159};\\\", \\\"{x:1474,y:956,t:1527616936176};\\\", \\\"{x:1474,y:948,t:1527616936192};\\\", \\\"{x:1473,y:939,t:1527616936209};\\\", \\\"{x:1471,y:927,t:1527616936225};\\\", \\\"{x:1471,y:915,t:1527616936242};\\\", \\\"{x:1471,y:904,t:1527616936259};\\\", \\\"{x:1471,y:894,t:1527616936275};\\\", \\\"{x:1471,y:887,t:1527616936292};\\\", \\\"{x:1472,y:883,t:1527616936309};\\\", \\\"{x:1472,y:881,t:1527616936326};\\\", \\\"{x:1472,y:875,t:1527616936342};\\\", \\\"{x:1472,y:873,t:1527616936359};\\\", \\\"{x:1472,y:872,t:1527616936376};\\\", \\\"{x:1474,y:870,t:1527616936392};\\\", \\\"{x:1474,y:867,t:1527616936409};\\\", \\\"{x:1475,y:864,t:1527616936426};\\\", \\\"{x:1476,y:861,t:1527616936441};\\\", \\\"{x:1477,y:855,t:1527616936459};\\\", \\\"{x:1477,y:852,t:1527616936476};\\\", \\\"{x:1477,y:848,t:1527616936492};\\\", \\\"{x:1477,y:846,t:1527616936509};\\\", \\\"{x:1477,y:842,t:1527616936526};\\\", \\\"{x:1477,y:837,t:1527616936542};\\\", \\\"{x:1477,y:834,t:1527616936559};\\\", \\\"{x:1477,y:831,t:1527616936576};\\\", \\\"{x:1477,y:830,t:1527616936599};\\\", \\\"{x:1477,y:829,t:1527616943536};\\\", \\\"{x:1476,y:829,t:1527616943547};\\\", \\\"{x:1474,y:829,t:1527616943565};\\\", \\\"{x:1463,y:829,t:1527616943581};\\\", \\\"{x:1452,y:829,t:1527616943597};\\\", \\\"{x:1438,y:829,t:1527616943614};\\\", \\\"{x:1423,y:829,t:1527616943631};\\\", \\\"{x:1409,y:829,t:1527616943647};\\\", \\\"{x:1381,y:827,t:1527616943663};\\\", \\\"{x:1362,y:824,t:1527616943681};\\\", \\\"{x:1344,y:821,t:1527616943697};\\\", \\\"{x:1323,y:816,t:1527616943714};\\\", \\\"{x:1305,y:814,t:1527616943731};\\\", \\\"{x:1284,y:810,t:1527616943747};\\\", \\\"{x:1267,y:807,t:1527616943764};\\\", \\\"{x:1247,y:802,t:1527616943781};\\\", \\\"{x:1229,y:797,t:1527616943798};\\\", \\\"{x:1214,y:794,t:1527616943813};\\\", \\\"{x:1202,y:793,t:1527616943830};\\\", \\\"{x:1193,y:793,t:1527616943847};\\\", \\\"{x:1188,y:792,t:1527616943863};\\\", \\\"{x:1184,y:790,t:1527616943881};\\\", \\\"{x:1178,y:789,t:1527616943897};\\\", \\\"{x:1172,y:788,t:1527616943913};\\\", \\\"{x:1169,y:787,t:1527616943930};\\\", \\\"{x:1167,y:786,t:1527616943947};\\\", \\\"{x:1165,y:786,t:1527616943964};\\\", \\\"{x:1163,y:786,t:1527616943981};\\\", \\\"{x:1164,y:786,t:1527616944510};\\\", \\\"{x:1165,y:786,t:1527616944534};\\\", \\\"{x:1166,y:786,t:1527616944567};\\\", \\\"{x:1167,y:787,t:1527616944581};\\\", \\\"{x:1168,y:787,t:1527616944599};\\\", \\\"{x:1170,y:787,t:1527616944614};\\\", \\\"{x:1172,y:787,t:1527616944630};\\\", \\\"{x:1173,y:787,t:1527616944647};\\\", \\\"{x:1176,y:787,t:1527616944664};\\\", \\\"{x:1179,y:787,t:1527616944681};\\\", \\\"{x:1180,y:787,t:1527616944697};\\\", \\\"{x:1181,y:787,t:1527616944714};\\\", \\\"{x:1183,y:787,t:1527616944731};\\\", \\\"{x:1185,y:787,t:1527616944747};\\\", \\\"{x:1187,y:786,t:1527616944765};\\\", \\\"{x:1189,y:786,t:1527616944781};\\\", \\\"{x:1191,y:786,t:1527616944797};\\\", \\\"{x:1194,y:786,t:1527616944814};\\\", \\\"{x:1198,y:785,t:1527616944831};\\\", \\\"{x:1202,y:785,t:1527616944847};\\\", \\\"{x:1207,y:784,t:1527616944864};\\\", \\\"{x:1213,y:784,t:1527616944881};\\\", \\\"{x:1218,y:784,t:1527616944897};\\\", \\\"{x:1224,y:783,t:1527616944914};\\\", \\\"{x:1230,y:783,t:1527616944931};\\\", \\\"{x:1236,y:782,t:1527616944947};\\\", \\\"{x:1240,y:782,t:1527616944964};\\\", \\\"{x:1245,y:781,t:1527616944981};\\\", \\\"{x:1251,y:781,t:1527616944998};\\\", \\\"{x:1258,y:781,t:1527616945015};\\\", \\\"{x:1263,y:781,t:1527616945031};\\\", \\\"{x:1271,y:781,t:1527616945048};\\\", \\\"{x:1279,y:781,t:1527616945064};\\\", \\\"{x:1287,y:778,t:1527616945081};\\\", \\\"{x:1294,y:778,t:1527616945098};\\\", \\\"{x:1299,y:778,t:1527616945114};\\\", \\\"{x:1303,y:778,t:1527616945131};\\\", \\\"{x:1306,y:778,t:1527616945148};\\\", \\\"{x:1307,y:778,t:1527616945164};\\\", \\\"{x:1310,y:778,t:1527616945181};\\\", \\\"{x:1316,y:778,t:1527616945199};\\\", \\\"{x:1321,y:778,t:1527616945214};\\\", \\\"{x:1325,y:778,t:1527616945231};\\\", \\\"{x:1328,y:778,t:1527616945249};\\\", \\\"{x:1330,y:778,t:1527616945264};\\\", \\\"{x:1331,y:778,t:1527616945282};\\\", \\\"{x:1333,y:778,t:1527616945298};\\\", \\\"{x:1334,y:778,t:1527616945314};\\\", \\\"{x:1338,y:778,t:1527616945331};\\\", \\\"{x:1340,y:778,t:1527616945348};\\\", \\\"{x:1342,y:778,t:1527616945364};\\\", \\\"{x:1344,y:778,t:1527616945381};\\\", \\\"{x:1345,y:778,t:1527616945398};\\\", \\\"{x:1346,y:778,t:1527616945415};\\\", \\\"{x:1347,y:777,t:1527616945439};\\\", \\\"{x:1350,y:776,t:1527616945486};\\\", \\\"{x:1351,y:775,t:1527616945687};\\\", \\\"{x:1351,y:774,t:1527616945702};\\\", \\\"{x:1351,y:773,t:1527616945718};\\\", \\\"{x:1351,y:772,t:1527616945734};\\\", \\\"{x:1351,y:771,t:1527616945751};\\\", \\\"{x:1350,y:770,t:1527616945765};\\\", \\\"{x:1350,y:769,t:1527616945863};\\\", \\\"{x:1350,y:768,t:1527616947767};\\\", \\\"{x:1350,y:767,t:1527616947784};\\\", \\\"{x:1350,y:766,t:1527616947800};\\\", \\\"{x:1350,y:765,t:1527616947817};\\\", \\\"{x:1350,y:764,t:1527616947833};\\\", \\\"{x:1350,y:763,t:1527616948192};\\\", \\\"{x:1351,y:764,t:1527616949536};\\\", \\\"{x:1355,y:768,t:1527616949553};\\\", \\\"{x:1358,y:770,t:1527616949568};\\\", \\\"{x:1358,y:771,t:1527616949587};\\\", \\\"{x:1359,y:773,t:1527616949602};\\\", \\\"{x:1359,y:776,t:1527616949618};\\\", \\\"{x:1359,y:781,t:1527616949636};\\\", \\\"{x:1351,y:786,t:1527616949652};\\\", \\\"{x:1338,y:792,t:1527616949668};\\\", \\\"{x:1313,y:805,t:1527616949686};\\\", \\\"{x:1275,y:827,t:1527616949703};\\\", \\\"{x:1224,y:853,t:1527616949719};\\\", \\\"{x:1148,y:876,t:1527616949736};\\\", \\\"{x:1133,y:887,t:1527616949751};\\\", \\\"{x:1128,y:887,t:1527616949769};\\\", \\\"{x:1126,y:883,t:1527616949786};\\\", \\\"{x:1106,y:881,t:1527616949803};\\\", \\\"{x:1059,y:861,t:1527616949819};\\\", \\\"{x:964,y:815,t:1527616949835};\\\", \\\"{x:854,y:769,t:1527616949853};\\\", \\\"{x:746,y:722,t:1527616949869};\\\", \\\"{x:645,y:685,t:1527616949885};\\\", \\\"{x:557,y:660,t:1527616949903};\\\", \\\"{x:527,y:643,t:1527616949918};\\\", \\\"{x:478,y:633,t:1527616949935};\\\", \\\"{x:465,y:629,t:1527616949953};\\\", \\\"{x:457,y:625,t:1527616949968};\\\", \\\"{x:456,y:625,t:1527616950071};\\\", \\\"{x:459,y:635,t:1527616950087};\\\", \\\"{x:464,y:649,t:1527616950103};\\\", \\\"{x:473,y:661,t:1527616950120};\\\", \\\"{x:485,y:676,t:1527616950136};\\\", \\\"{x:493,y:688,t:1527616950153};\\\", \\\"{x:500,y:698,t:1527616950170};\\\", \\\"{x:507,y:709,t:1527616950187};\\\", \\\"{x:510,y:714,t:1527616950203};\\\", \\\"{x:511,y:716,t:1527616950220};\\\", \\\"{x:513,y:718,t:1527616950237};\\\", \\\"{x:516,y:723,t:1527616950254};\\\", \\\"{x:525,y:732,t:1527616950269};\\\", \\\"{x:527,y:736,t:1527616950287};\\\", \\\"{x:528,y:737,t:1527616950311};\\\", \\\"{x:533,y:736,t:1527616950538};\\\", \\\"{x:537,y:734,t:1527616950552};\\\", \\\"{x:539,y:733,t:1527616950569};\\\", \\\"{x:540,y:732,t:1527616950655};\\\", \\\"{x:540,y:731,t:1527616950669};\\\", \\\"{x:546,y:726,t:1527616950687};\\\", \\\"{x:556,y:721,t:1527616950702};\\\", \\\"{x:569,y:716,t:1527616950720};\\\", \\\"{x:588,y:711,t:1527616950736};\\\", \\\"{x:608,y:705,t:1527616950753};\\\", \\\"{x:633,y:698,t:1527616950769};\\\", \\\"{x:679,y:684,t:1527616950787};\\\", \\\"{x:735,y:667,t:1527616950803};\\\", \\\"{x:798,y:650,t:1527616950820};\\\", \\\"{x:873,y:632,t:1527616950836};\\\", \\\"{x:956,y:607,t:1527616950853};\\\", \\\"{x:1043,y:590,t:1527616950870};\\\", \\\"{x:1162,y:572,t:1527616950887};\\\", \\\"{x:1229,y:561,t:1527616950903};\\\", \\\"{x:1286,y:550,t:1527616950919};\\\", \\\"{x:1320,y:540,t:1527616950937};\\\", \\\"{x:1337,y:534,t:1527616950953};\\\", \\\"{x:1341,y:534,t:1527616950970};\\\" ] }, { \\\"rt\\\": 19486, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 410971, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7-B -B -10 AM-11 AM-12 PM-01 PM-X -X -M -M -12 PM-12 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1341,y:533,t:1527616952244};\\\", \\\"{x:1335,y:530,t:1527616952255};\\\", \\\"{x:1313,y:530,t:1527616952270};\\\", \\\"{x:1283,y:525,t:1527616952287};\\\", \\\"{x:1250,y:523,t:1527616952304};\\\", \\\"{x:1197,y:515,t:1527616952321};\\\", \\\"{x:1129,y:503,t:1527616952338};\\\", \\\"{x:1063,y:494,t:1527616952355};\\\", \\\"{x:1000,y:491,t:1527616952371};\\\", \\\"{x:948,y:486,t:1527616952388};\\\", \\\"{x:877,y:483,t:1527616952405};\\\", \\\"{x:824,y:483,t:1527616952421};\\\", \\\"{x:785,y:483,t:1527616952438};\\\", \\\"{x:734,y:483,t:1527616952455};\\\", \\\"{x:703,y:483,t:1527616952471};\\\", \\\"{x:658,y:483,t:1527616952488};\\\", \\\"{x:608,y:483,t:1527616952505};\\\", \\\"{x:563,y:483,t:1527616952521};\\\", \\\"{x:518,y:483,t:1527616952537};\\\", \\\"{x:491,y:483,t:1527616952555};\\\", \\\"{x:467,y:483,t:1527616952571};\\\", \\\"{x:450,y:483,t:1527616952588};\\\", \\\"{x:433,y:483,t:1527616952605};\\\", \\\"{x:417,y:483,t:1527616952621};\\\", \\\"{x:407,y:485,t:1527616952638};\\\", \\\"{x:403,y:486,t:1527616952655};\\\", \\\"{x:401,y:486,t:1527616952671};\\\", \\\"{x:401,y:487,t:1527616952759};\\\", \\\"{x:401,y:488,t:1527616952771};\\\", \\\"{x:405,y:492,t:1527616952787};\\\", \\\"{x:425,y:494,t:1527616952805};\\\", \\\"{x:457,y:494,t:1527616952822};\\\", \\\"{x:484,y:497,t:1527616952838};\\\", \\\"{x:535,y:497,t:1527616952855};\\\", \\\"{x:583,y:498,t:1527616952872};\\\", \\\"{x:628,y:498,t:1527616952888};\\\", \\\"{x:679,y:499,t:1527616952905};\\\", \\\"{x:712,y:499,t:1527616952921};\\\", \\\"{x:743,y:499,t:1527616952940};\\\", \\\"{x:767,y:503,t:1527616952954};\\\", \\\"{x:792,y:506,t:1527616952972};\\\", \\\"{x:816,y:506,t:1527616952989};\\\", \\\"{x:838,y:508,t:1527616953005};\\\", \\\"{x:860,y:512,t:1527616953022};\\\", \\\"{x:893,y:515,t:1527616953039};\\\", \\\"{x:913,y:517,t:1527616953055};\\\", \\\"{x:936,y:521,t:1527616953073};\\\", \\\"{x:960,y:527,t:1527616953089};\\\", \\\"{x:989,y:539,t:1527616953105};\\\", \\\"{x:1030,y:553,t:1527616953122};\\\", \\\"{x:1083,y:578,t:1527616953139};\\\", \\\"{x:1121,y:595,t:1527616953156};\\\", \\\"{x:1162,y:618,t:1527616953172};\\\", \\\"{x:1200,y:640,t:1527616953190};\\\", \\\"{x:1232,y:659,t:1527616953207};\\\", \\\"{x:1254,y:671,t:1527616953223};\\\", \\\"{x:1289,y:694,t:1527616953239};\\\", \\\"{x:1307,y:706,t:1527616953255};\\\", \\\"{x:1319,y:718,t:1527616953273};\\\", \\\"{x:1330,y:731,t:1527616953289};\\\", \\\"{x:1339,y:746,t:1527616953306};\\\", \\\"{x:1346,y:754,t:1527616953322};\\\", \\\"{x:1351,y:760,t:1527616953341};\\\", \\\"{x:1355,y:767,t:1527616953357};\\\", \\\"{x:1358,y:771,t:1527616953372};\\\", \\\"{x:1361,y:780,t:1527616953389};\\\", \\\"{x:1363,y:788,t:1527616953406};\\\", \\\"{x:1366,y:798,t:1527616953423};\\\", \\\"{x:1366,y:803,t:1527616953440};\\\", \\\"{x:1367,y:809,t:1527616953457};\\\", \\\"{x:1368,y:815,t:1527616953473};\\\", \\\"{x:1370,y:822,t:1527616953490};\\\", \\\"{x:1370,y:830,t:1527616953506};\\\", \\\"{x:1370,y:836,t:1527616953524};\\\", \\\"{x:1370,y:841,t:1527616953539};\\\", \\\"{x:1370,y:842,t:1527616953557};\\\", \\\"{x:1370,y:843,t:1527616953574};\\\", \\\"{x:1370,y:844,t:1527616953591};\\\", \\\"{x:1370,y:842,t:1527616953728};\\\", \\\"{x:1370,y:838,t:1527616953741};\\\", \\\"{x:1370,y:833,t:1527616953757};\\\", \\\"{x:1370,y:827,t:1527616953772};\\\", \\\"{x:1370,y:819,t:1527616953790};\\\", \\\"{x:1366,y:813,t:1527616953807};\\\", \\\"{x:1361,y:807,t:1527616953822};\\\", \\\"{x:1354,y:801,t:1527616953840};\\\", \\\"{x:1344,y:794,t:1527616953857};\\\", \\\"{x:1334,y:790,t:1527616953873};\\\", \\\"{x:1326,y:785,t:1527616953889};\\\", \\\"{x:1321,y:784,t:1527616953907};\\\", \\\"{x:1316,y:782,t:1527616953923};\\\", \\\"{x:1314,y:782,t:1527616953940};\\\", \\\"{x:1312,y:782,t:1527616953975};\\\", \\\"{x:1311,y:782,t:1527616953990};\\\", \\\"{x:1306,y:784,t:1527616954006};\\\", \\\"{x:1301,y:790,t:1527616954024};\\\", \\\"{x:1294,y:800,t:1527616954040};\\\", \\\"{x:1290,y:809,t:1527616954056};\\\", \\\"{x:1285,y:815,t:1527616954073};\\\", \\\"{x:1281,y:822,t:1527616954090};\\\", \\\"{x:1279,y:828,t:1527616954106};\\\", \\\"{x:1276,y:834,t:1527616954124};\\\", \\\"{x:1274,y:838,t:1527616954140};\\\", \\\"{x:1271,y:841,t:1527616954156};\\\", \\\"{x:1267,y:845,t:1527616954174};\\\", \\\"{x:1264,y:848,t:1527616954190};\\\", \\\"{x:1260,y:850,t:1527616954207};\\\", \\\"{x:1255,y:853,t:1527616954223};\\\", \\\"{x:1248,y:857,t:1527616954241};\\\", \\\"{x:1243,y:857,t:1527616954258};\\\", \\\"{x:1237,y:857,t:1527616954274};\\\", \\\"{x:1226,y:857,t:1527616954291};\\\", \\\"{x:1214,y:857,t:1527616954307};\\\", \\\"{x:1196,y:855,t:1527616954323};\\\", \\\"{x:1175,y:848,t:1527616954341};\\\", \\\"{x:1152,y:842,t:1527616954358};\\\", \\\"{x:1133,y:831,t:1527616954374};\\\", \\\"{x:1109,y:816,t:1527616954391};\\\", \\\"{x:1099,y:806,t:1527616954408};\\\", \\\"{x:1094,y:799,t:1527616954424};\\\", \\\"{x:1092,y:794,t:1527616954441};\\\", \\\"{x:1092,y:792,t:1527616954458};\\\", \\\"{x:1091,y:787,t:1527616954474};\\\", \\\"{x:1091,y:783,t:1527616954490};\\\", \\\"{x:1092,y:778,t:1527616954508};\\\", \\\"{x:1096,y:774,t:1527616954525};\\\", \\\"{x:1101,y:770,t:1527616954541};\\\", \\\"{x:1110,y:767,t:1527616954558};\\\", \\\"{x:1118,y:765,t:1527616954574};\\\", \\\"{x:1121,y:764,t:1527616954591};\\\", \\\"{x:1122,y:764,t:1527616954608};\\\", \\\"{x:1123,y:763,t:1527616954678};\\\", \\\"{x:1124,y:763,t:1527616955191};\\\", \\\"{x:1124,y:762,t:1527616955199};\\\", \\\"{x:1124,y:761,t:1527616955215};\\\", \\\"{x:1124,y:760,t:1527616955226};\\\", \\\"{x:1125,y:758,t:1527616955243};\\\", \\\"{x:1125,y:757,t:1527616955271};\\\", \\\"{x:1126,y:756,t:1527616955287};\\\", \\\"{x:1127,y:756,t:1527616955416};\\\", \\\"{x:1132,y:756,t:1527616955479};\\\", \\\"{x:1134,y:757,t:1527616955493};\\\", \\\"{x:1138,y:758,t:1527616955510};\\\", \\\"{x:1161,y:773,t:1527616955527};\\\", \\\"{x:1176,y:781,t:1527616955543};\\\", \\\"{x:1191,y:790,t:1527616955560};\\\", \\\"{x:1201,y:795,t:1527616955578};\\\", \\\"{x:1217,y:801,t:1527616955593};\\\", \\\"{x:1226,y:805,t:1527616955610};\\\", \\\"{x:1235,y:807,t:1527616955627};\\\", \\\"{x:1238,y:808,t:1527616955643};\\\", \\\"{x:1239,y:809,t:1527616955660};\\\", \\\"{x:1237,y:809,t:1527616955912};\\\", \\\"{x:1233,y:808,t:1527616955927};\\\", \\\"{x:1226,y:807,t:1527616955944};\\\", \\\"{x:1206,y:802,t:1527616955962};\\\", \\\"{x:1189,y:805,t:1527616955978};\\\", \\\"{x:1184,y:810,t:1527616955994};\\\", \\\"{x:1184,y:813,t:1527616956159};\\\", \\\"{x:1184,y:822,t:1527616956166};\\\", \\\"{x:1184,y:834,t:1527616956177};\\\", \\\"{x:1184,y:860,t:1527616956194};\\\", \\\"{x:1184,y:887,t:1527616956211};\\\", \\\"{x:1186,y:922,t:1527616956227};\\\", \\\"{x:1189,y:948,t:1527616956245};\\\", \\\"{x:1196,y:970,t:1527616956261};\\\", \\\"{x:1201,y:989,t:1527616956277};\\\", \\\"{x:1211,y:1011,t:1527616956294};\\\", \\\"{x:1215,y:1016,t:1527616956310};\\\", \\\"{x:1218,y:1021,t:1527616956328};\\\", \\\"{x:1219,y:1024,t:1527616956344};\\\", \\\"{x:1220,y:1027,t:1527616956367};\\\", \\\"{x:1221,y:1028,t:1527616956383};\\\", \\\"{x:1222,y:1029,t:1527616956398};\\\", \\\"{x:1222,y:1030,t:1527616956412};\\\", \\\"{x:1223,y:1032,t:1527616956428};\\\", \\\"{x:1223,y:1033,t:1527616956444};\\\", \\\"{x:1224,y:1034,t:1527616956462};\\\", \\\"{x:1226,y:1034,t:1527616956478};\\\", \\\"{x:1227,y:1034,t:1527616956494};\\\", \\\"{x:1231,y:1035,t:1527616956511};\\\", \\\"{x:1239,y:1033,t:1527616956529};\\\", \\\"{x:1249,y:1027,t:1527616956545};\\\", \\\"{x:1264,y:1017,t:1527616956561};\\\", \\\"{x:1279,y:1006,t:1527616956579};\\\", \\\"{x:1294,y:993,t:1527616956595};\\\", \\\"{x:1311,y:979,t:1527616956611};\\\", \\\"{x:1320,y:971,t:1527616956629};\\\", \\\"{x:1324,y:966,t:1527616956645};\\\", \\\"{x:1326,y:964,t:1527616956662};\\\", \\\"{x:1326,y:967,t:1527616956806};\\\", \\\"{x:1326,y:975,t:1527616956814};\\\", \\\"{x:1326,y:982,t:1527616956829};\\\", \\\"{x:1329,y:996,t:1527616956845};\\\", \\\"{x:1330,y:1010,t:1527616956862};\\\", \\\"{x:1330,y:1015,t:1527616956879};\\\", \\\"{x:1330,y:1017,t:1527616956896};\\\", \\\"{x:1331,y:1018,t:1527616956918};\\\", \\\"{x:1326,y:1018,t:1527616957102};\\\", \\\"{x:1324,y:1016,t:1527616957112};\\\", \\\"{x:1320,y:1015,t:1527616957130};\\\", \\\"{x:1316,y:1014,t:1527616957146};\\\", \\\"{x:1312,y:1012,t:1527616957162};\\\", \\\"{x:1311,y:1012,t:1527616957182};\\\", \\\"{x:1310,y:1012,t:1527616957302};\\\", \\\"{x:1309,y:1011,t:1527616957334};\\\", \\\"{x:1308,y:1009,t:1527616957346};\\\", \\\"{x:1305,y:1002,t:1527616957362};\\\", \\\"{x:1304,y:995,t:1527616957379};\\\", \\\"{x:1301,y:987,t:1527616957397};\\\", \\\"{x:1300,y:979,t:1527616957413};\\\", \\\"{x:1300,y:972,t:1527616957430};\\\", \\\"{x:1300,y:968,t:1527616957446};\\\", \\\"{x:1300,y:967,t:1527616957463};\\\", \\\"{x:1300,y:965,t:1527616957480};\\\", \\\"{x:1303,y:965,t:1527616957735};\\\", \\\"{x:1308,y:967,t:1527616957747};\\\", \\\"{x:1310,y:968,t:1527616957763};\\\", \\\"{x:1311,y:969,t:1527616957782};\\\", \\\"{x:1311,y:970,t:1527616957798};\\\", \\\"{x:1313,y:972,t:1527616958095};\\\", \\\"{x:1317,y:973,t:1527616958102};\\\", \\\"{x:1319,y:973,t:1527616958115};\\\", \\\"{x:1322,y:973,t:1527616958159};\\\", \\\"{x:1327,y:973,t:1527616958167};\\\", \\\"{x:1332,y:970,t:1527616958181};\\\", \\\"{x:1343,y:963,t:1527616958198};\\\", \\\"{x:1350,y:959,t:1527616958214};\\\", \\\"{x:1352,y:958,t:1527616958232};\\\", \\\"{x:1353,y:957,t:1527616958248};\\\", \\\"{x:1354,y:957,t:1527616958382};\\\", \\\"{x:1368,y:957,t:1527616958399};\\\", \\\"{x:1382,y:955,t:1527616958415};\\\", \\\"{x:1387,y:955,t:1527616958432};\\\", \\\"{x:1396,y:954,t:1527616958449};\\\", \\\"{x:1398,y:953,t:1527616958465};\\\", \\\"{x:1399,y:953,t:1527616958543};\\\", \\\"{x:1401,y:953,t:1527616958551};\\\", \\\"{x:1403,y:953,t:1527616958566};\\\", \\\"{x:1408,y:953,t:1527616958582};\\\", \\\"{x:1411,y:953,t:1527616958599};\\\", \\\"{x:1412,y:953,t:1527616958615};\\\", \\\"{x:1413,y:953,t:1527616958694};\\\", \\\"{x:1413,y:954,t:1527616958774};\\\", \\\"{x:1414,y:956,t:1527616958807};\\\", \\\"{x:1414,y:957,t:1527616958816};\\\", \\\"{x:1418,y:959,t:1527616958833};\\\", \\\"{x:1424,y:960,t:1527616958850};\\\", \\\"{x:1425,y:961,t:1527616958866};\\\", \\\"{x:1426,y:961,t:1527616958884};\\\", \\\"{x:1427,y:962,t:1527616958900};\\\", \\\"{x:1427,y:961,t:1527616959575};\\\", \\\"{x:1427,y:960,t:1527616959592};\\\", \\\"{x:1427,y:959,t:1527616959608};\\\", \\\"{x:1427,y:958,t:1527616959623};\\\", \\\"{x:1427,y:957,t:1527616959712};\\\", \\\"{x:1427,y:956,t:1527616959719};\\\", \\\"{x:1427,y:955,t:1527616959735};\\\", \\\"{x:1426,y:955,t:1527616959798};\\\", \\\"{x:1424,y:954,t:1527616959823};\\\", \\\"{x:1423,y:954,t:1527616959846};\\\", \\\"{x:1421,y:953,t:1527616959871};\\\", \\\"{x:1420,y:953,t:1527616959887};\\\", \\\"{x:1419,y:952,t:1527616959953};\\\", \\\"{x:1418,y:952,t:1527616959968};\\\", \\\"{x:1417,y:952,t:1527616959986};\\\", \\\"{x:1415,y:952,t:1527616960016};\\\", \\\"{x:1414,y:952,t:1527616960703};\\\", \\\"{x:1411,y:955,t:1527616960799};\\\", \\\"{x:1410,y:961,t:1527616960806};\\\", \\\"{x:1409,y:963,t:1527616960820};\\\", \\\"{x:1409,y:968,t:1527616960838};\\\", \\\"{x:1407,y:970,t:1527616960853};\\\", \\\"{x:1407,y:971,t:1527616960870};\\\", \\\"{x:1406,y:973,t:1527616960927};\\\", \\\"{x:1406,y:974,t:1527616960959};\\\", \\\"{x:1405,y:974,t:1527616960971};\\\", \\\"{x:1405,y:976,t:1527616960999};\\\", \\\"{x:1404,y:976,t:1527616961007};\\\", \\\"{x:1402,y:976,t:1527616961183};\\\", \\\"{x:1401,y:975,t:1527616961304};\\\", \\\"{x:1400,y:975,t:1527616961343};\\\", \\\"{x:1398,y:975,t:1527616961355};\\\", \\\"{x:1392,y:972,t:1527616961372};\\\", \\\"{x:1385,y:970,t:1527616961388};\\\", \\\"{x:1378,y:968,t:1527616961404};\\\", \\\"{x:1374,y:967,t:1527616961421};\\\", \\\"{x:1373,y:967,t:1527616961438};\\\", \\\"{x:1374,y:967,t:1527616961935};\\\", \\\"{x:1377,y:967,t:1527616961944};\\\", \\\"{x:1380,y:966,t:1527616961956};\\\", \\\"{x:1388,y:963,t:1527616961972};\\\", \\\"{x:1394,y:962,t:1527616961989};\\\", \\\"{x:1397,y:960,t:1527616962005};\\\", \\\"{x:1401,y:959,t:1527616962022};\\\", \\\"{x:1406,y:958,t:1527616962039};\\\", \\\"{x:1413,y:955,t:1527616962057};\\\", \\\"{x:1418,y:955,t:1527616962073};\\\", \\\"{x:1424,y:952,t:1527616962089};\\\", \\\"{x:1426,y:952,t:1527616962106};\\\", \\\"{x:1427,y:952,t:1527616962122};\\\", \\\"{x:1428,y:951,t:1527616962139};\\\", \\\"{x:1429,y:951,t:1527616962270};\\\", \\\"{x:1431,y:951,t:1527616962279};\\\", \\\"{x:1435,y:952,t:1527616962289};\\\", \\\"{x:1437,y:952,t:1527616962306};\\\", \\\"{x:1440,y:953,t:1527616962323};\\\", \\\"{x:1443,y:955,t:1527616962339};\\\", \\\"{x:1445,y:957,t:1527616962356};\\\", \\\"{x:1448,y:959,t:1527616962374};\\\", \\\"{x:1451,y:961,t:1527616962390};\\\", \\\"{x:1453,y:963,t:1527616962406};\\\", \\\"{x:1457,y:965,t:1527616962423};\\\", \\\"{x:1459,y:966,t:1527616962440};\\\", \\\"{x:1460,y:967,t:1527616962456};\\\", \\\"{x:1462,y:967,t:1527616962473};\\\", \\\"{x:1463,y:967,t:1527616962527};\\\", \\\"{x:1464,y:967,t:1527616962541};\\\", \\\"{x:1465,y:967,t:1527616962557};\\\", \\\"{x:1471,y:967,t:1527616962573};\\\", \\\"{x:1487,y:964,t:1527616962591};\\\", \\\"{x:1488,y:961,t:1527616963184};\\\", \\\"{x:1488,y:955,t:1527616963192};\\\", \\\"{x:1488,y:948,t:1527616963209};\\\", \\\"{x:1488,y:938,t:1527616963225};\\\", \\\"{x:1488,y:935,t:1527616963242};\\\", \\\"{x:1488,y:932,t:1527616963259};\\\", \\\"{x:1488,y:929,t:1527616963275};\\\", \\\"{x:1488,y:926,t:1527616963292};\\\", \\\"{x:1487,y:923,t:1527616963309};\\\", \\\"{x:1487,y:921,t:1527616963326};\\\", \\\"{x:1487,y:918,t:1527616963342};\\\", \\\"{x:1487,y:916,t:1527616963359};\\\", \\\"{x:1486,y:915,t:1527616963376};\\\", \\\"{x:1486,y:913,t:1527616963392};\\\", \\\"{x:1486,y:912,t:1527616963409};\\\", \\\"{x:1486,y:909,t:1527616963426};\\\", \\\"{x:1486,y:906,t:1527616963442};\\\", \\\"{x:1486,y:902,t:1527616963459};\\\", \\\"{x:1486,y:900,t:1527616963476};\\\", \\\"{x:1486,y:897,t:1527616963493};\\\", \\\"{x:1486,y:893,t:1527616963509};\\\", \\\"{x:1486,y:889,t:1527616963526};\\\", \\\"{x:1486,y:881,t:1527616963543};\\\", \\\"{x:1486,y:868,t:1527616963559};\\\", \\\"{x:1485,y:865,t:1527616963575};\\\", \\\"{x:1485,y:863,t:1527616963599};\\\", \\\"{x:1485,y:862,t:1527616963610};\\\", \\\"{x:1484,y:860,t:1527616963626};\\\", \\\"{x:1484,y:859,t:1527616963648};\\\", \\\"{x:1484,y:857,t:1527616963663};\\\", \\\"{x:1484,y:856,t:1527616963679};\\\", \\\"{x:1484,y:855,t:1527616963703};\\\", \\\"{x:1483,y:855,t:1527616963711};\\\", \\\"{x:1483,y:853,t:1527616963759};\\\", \\\"{x:1483,y:852,t:1527616963776};\\\", \\\"{x:1483,y:849,t:1527616963793};\\\", \\\"{x:1483,y:843,t:1527616963810};\\\", \\\"{x:1483,y:838,t:1527616963826};\\\", \\\"{x:1483,y:835,t:1527616963844};\\\", \\\"{x:1483,y:831,t:1527616963860};\\\", \\\"{x:1483,y:828,t:1527616963876};\\\", \\\"{x:1483,y:827,t:1527616963892};\\\", \\\"{x:1483,y:826,t:1527616964112};\\\", \\\"{x:1482,y:824,t:1527616964128};\\\", \\\"{x:1479,y:821,t:1527616964144};\\\", \\\"{x:1479,y:819,t:1527616964167};\\\", \\\"{x:1477,y:819,t:1527616964720};\\\", \\\"{x:1474,y:829,t:1527616964729};\\\", \\\"{x:1461,y:851,t:1527616964745};\\\", \\\"{x:1452,y:871,t:1527616964762};\\\", \\\"{x:1442,y:895,t:1527616964778};\\\", \\\"{x:1432,y:915,t:1527616964795};\\\", \\\"{x:1425,y:931,t:1527616964812};\\\", \\\"{x:1419,y:944,t:1527616964828};\\\", \\\"{x:1414,y:956,t:1527616964845};\\\", \\\"{x:1409,y:968,t:1527616964862};\\\", \\\"{x:1401,y:987,t:1527616964879};\\\", \\\"{x:1399,y:991,t:1527616964895};\\\", \\\"{x:1394,y:1004,t:1527616964912};\\\", \\\"{x:1392,y:1006,t:1527616964929};\\\", \\\"{x:1391,y:1010,t:1527616964945};\\\", \\\"{x:1391,y:1011,t:1527616964975};\\\", \\\"{x:1390,y:1012,t:1527616964984};\\\", \\\"{x:1389,y:1013,t:1527616965007};\\\", \\\"{x:1389,y:1014,t:1527616965015};\\\", \\\"{x:1388,y:1014,t:1527616965029};\\\", \\\"{x:1387,y:1015,t:1527616965045};\\\", \\\"{x:1386,y:1016,t:1527616965061};\\\", \\\"{x:1385,y:1015,t:1527616965272};\\\", \\\"{x:1385,y:1012,t:1527616965279};\\\", \\\"{x:1385,y:1007,t:1527616965295};\\\", \\\"{x:1383,y:1000,t:1527616965313};\\\", \\\"{x:1382,y:997,t:1527616965329};\\\", \\\"{x:1382,y:995,t:1527616965346};\\\", \\\"{x:1382,y:993,t:1527616965363};\\\", \\\"{x:1382,y:992,t:1527616965380};\\\", \\\"{x:1382,y:989,t:1527616965396};\\\", \\\"{x:1382,y:986,t:1527616965413};\\\", \\\"{x:1382,y:984,t:1527616965430};\\\", \\\"{x:1383,y:982,t:1527616965446};\\\", \\\"{x:1383,y:978,t:1527616965464};\\\", \\\"{x:1384,y:974,t:1527616965479};\\\", \\\"{x:1384,y:970,t:1527616965496};\\\", \\\"{x:1386,y:961,t:1527616965512};\\\", \\\"{x:1386,y:957,t:1527616965530};\\\", \\\"{x:1386,y:953,t:1527616965547};\\\", \\\"{x:1386,y:946,t:1527616965563};\\\", \\\"{x:1386,y:941,t:1527616965580};\\\", \\\"{x:1386,y:939,t:1527616965600};\\\", \\\"{x:1386,y:938,t:1527616965615};\\\", \\\"{x:1386,y:936,t:1527616965631};\\\", \\\"{x:1386,y:935,t:1527616965648};\\\", \\\"{x:1386,y:933,t:1527616965671};\\\", \\\"{x:1386,y:932,t:1527616965687};\\\", \\\"{x:1386,y:930,t:1527616965712};\\\", \\\"{x:1386,y:929,t:1527616965726};\\\", \\\"{x:1386,y:927,t:1527616965742};\\\", \\\"{x:1386,y:925,t:1527616965758};\\\", \\\"{x:1386,y:924,t:1527616965766};\\\", \\\"{x:1386,y:922,t:1527616965782};\\\", \\\"{x:1386,y:921,t:1527616965796};\\\", \\\"{x:1386,y:919,t:1527616965814};\\\", \\\"{x:1386,y:916,t:1527616965829};\\\", \\\"{x:1385,y:913,t:1527616965846};\\\", \\\"{x:1385,y:910,t:1527616965863};\\\", \\\"{x:1385,y:907,t:1527616965881};\\\", \\\"{x:1383,y:904,t:1527616965896};\\\", \\\"{x:1383,y:903,t:1527616965914};\\\", \\\"{x:1383,y:901,t:1527616965935};\\\", \\\"{x:1382,y:900,t:1527616965947};\\\", \\\"{x:1381,y:898,t:1527616965963};\\\", \\\"{x:1380,y:895,t:1527616965981};\\\", \\\"{x:1380,y:894,t:1527616965996};\\\", \\\"{x:1379,y:893,t:1527616966014};\\\", \\\"{x:1379,y:892,t:1527616966576};\\\", \\\"{x:1378,y:887,t:1527616966585};\\\", \\\"{x:1378,y:883,t:1527616966599};\\\", \\\"{x:1375,y:874,t:1527616966616};\\\", \\\"{x:1370,y:864,t:1527616966632};\\\", \\\"{x:1366,y:854,t:1527616966650};\\\", \\\"{x:1363,y:841,t:1527616966665};\\\", \\\"{x:1360,y:836,t:1527616966682};\\\", \\\"{x:1358,y:831,t:1527616966699};\\\", \\\"{x:1356,y:827,t:1527616966715};\\\", \\\"{x:1356,y:825,t:1527616966732};\\\", \\\"{x:1354,y:821,t:1527616966750};\\\", \\\"{x:1353,y:817,t:1527616966765};\\\", \\\"{x:1352,y:812,t:1527616966782};\\\", \\\"{x:1352,y:807,t:1527616966799};\\\", \\\"{x:1349,y:801,t:1527616966815};\\\", \\\"{x:1345,y:788,t:1527616966832};\\\", \\\"{x:1344,y:784,t:1527616966849};\\\", \\\"{x:1341,y:779,t:1527616966866};\\\", \\\"{x:1337,y:773,t:1527616966882};\\\", \\\"{x:1335,y:768,t:1527616966899};\\\", \\\"{x:1334,y:765,t:1527616966916};\\\", \\\"{x:1333,y:763,t:1527616966932};\\\", \\\"{x:1332,y:761,t:1527616966950};\\\", \\\"{x:1332,y:759,t:1527616966966};\\\", \\\"{x:1332,y:758,t:1527616966983};\\\", \\\"{x:1331,y:758,t:1527616967080};\\\", \\\"{x:1331,y:762,t:1527616967096};\\\", \\\"{x:1331,y:768,t:1527616967104};\\\", \\\"{x:1331,y:774,t:1527616967116};\\\", \\\"{x:1331,y:786,t:1527616967133};\\\", \\\"{x:1331,y:801,t:1527616967150};\\\", \\\"{x:1331,y:815,t:1527616967166};\\\", \\\"{x:1339,y:851,t:1527616967183};\\\", \\\"{x:1347,y:878,t:1527616967200};\\\", \\\"{x:1355,y:901,t:1527616967216};\\\", \\\"{x:1359,y:920,t:1527616967233};\\\", \\\"{x:1360,y:929,t:1527616967250};\\\", \\\"{x:1361,y:936,t:1527616967266};\\\", \\\"{x:1362,y:944,t:1527616967284};\\\", \\\"{x:1364,y:957,t:1527616967300};\\\", \\\"{x:1368,y:969,t:1527616967317};\\\", \\\"{x:1369,y:980,t:1527616967333};\\\", \\\"{x:1369,y:987,t:1527616967350};\\\", \\\"{x:1372,y:996,t:1527616967366};\\\", \\\"{x:1372,y:998,t:1527616967382};\\\", \\\"{x:1372,y:1000,t:1527616967399};\\\", \\\"{x:1372,y:1001,t:1527616967511};\\\", \\\"{x:1371,y:993,t:1527616967518};\\\", \\\"{x:1367,y:986,t:1527616967534};\\\", \\\"{x:1365,y:970,t:1527616967550};\\\", \\\"{x:1361,y:941,t:1527616967567};\\\", \\\"{x:1360,y:931,t:1527616967583};\\\", \\\"{x:1358,y:920,t:1527616967600};\\\", \\\"{x:1357,y:908,t:1527616967617};\\\", \\\"{x:1357,y:900,t:1527616967634};\\\", \\\"{x:1357,y:892,t:1527616967651};\\\", \\\"{x:1357,y:885,t:1527616967666};\\\", \\\"{x:1356,y:877,t:1527616967684};\\\", \\\"{x:1355,y:868,t:1527616967701};\\\", \\\"{x:1354,y:860,t:1527616967717};\\\", \\\"{x:1353,y:854,t:1527616967734};\\\", \\\"{x:1353,y:847,t:1527616967751};\\\", \\\"{x:1353,y:842,t:1527616967767};\\\", \\\"{x:1352,y:838,t:1527616967784};\\\", \\\"{x:1351,y:833,t:1527616967803};\\\", \\\"{x:1351,y:827,t:1527616967818};\\\", \\\"{x:1350,y:816,t:1527616967834};\\\", \\\"{x:1350,y:810,t:1527616967851};\\\", \\\"{x:1348,y:799,t:1527616967868};\\\", \\\"{x:1345,y:784,t:1527616967884};\\\", \\\"{x:1344,y:780,t:1527616967902};\\\", \\\"{x:1344,y:777,t:1527616967918};\\\", \\\"{x:1343,y:775,t:1527616967934};\\\", \\\"{x:1343,y:772,t:1527616967951};\\\", \\\"{x:1343,y:769,t:1527616967967};\\\", \\\"{x:1343,y:768,t:1527616967986};\\\", \\\"{x:1342,y:766,t:1527616968001};\\\", \\\"{x:1341,y:764,t:1527616968018};\\\", \\\"{x:1341,y:762,t:1527616968035};\\\", \\\"{x:1341,y:761,t:1527616968055};\\\", \\\"{x:1341,y:759,t:1527616968088};\\\", \\\"{x:1341,y:758,t:1527616968120};\\\", \\\"{x:1341,y:756,t:1527616968159};\\\", \\\"{x:1340,y:755,t:1527616968311};\\\", \\\"{x:1341,y:756,t:1527616968583};\\\", \\\"{x:1342,y:758,t:1527616968592};\\\", \\\"{x:1342,y:760,t:1527616968616};\\\", \\\"{x:1342,y:761,t:1527616968624};\\\", \\\"{x:1342,y:762,t:1527616968639};\\\", \\\"{x:1342,y:763,t:1527616968652};\\\", \\\"{x:1336,y:765,t:1527616968670};\\\", \\\"{x:1323,y:765,t:1527616968686};\\\", \\\"{x:1303,y:765,t:1527616968703};\\\", \\\"{x:1232,y:765,t:1527616968719};\\\", \\\"{x:1148,y:762,t:1527616968736};\\\", \\\"{x:1048,y:747,t:1527616968753};\\\", \\\"{x:923,y:730,t:1527616968769};\\\", \\\"{x:795,y:705,t:1527616968786};\\\", \\\"{x:669,y:677,t:1527616968803};\\\", \\\"{x:558,y:647,t:1527616968819};\\\", \\\"{x:476,y:628,t:1527616968838};\\\", \\\"{x:429,y:616,t:1527616968852};\\\", \\\"{x:398,y:610,t:1527616968870};\\\", \\\"{x:376,y:608,t:1527616968884};\\\", \\\"{x:354,y:603,t:1527616968902};\\\", \\\"{x:333,y:600,t:1527616968918};\\\", \\\"{x:307,y:594,t:1527616968934};\\\", \\\"{x:290,y:589,t:1527616968952};\\\", \\\"{x:277,y:584,t:1527616968967};\\\", \\\"{x:271,y:583,t:1527616968986};\\\", \\\"{x:270,y:583,t:1527616969002};\\\", \\\"{x:269,y:582,t:1527616969046};\\\", \\\"{x:271,y:581,t:1527616969071};\\\", \\\"{x:273,y:580,t:1527616969085};\\\", \\\"{x:278,y:579,t:1527616969101};\\\", \\\"{x:288,y:574,t:1527616969118};\\\", \\\"{x:297,y:570,t:1527616969135};\\\", \\\"{x:304,y:566,t:1527616969152};\\\", \\\"{x:307,y:564,t:1527616969168};\\\", \\\"{x:309,y:563,t:1527616969184};\\\", \\\"{x:309,y:561,t:1527616969208};\\\", \\\"{x:309,y:560,t:1527616969222};\\\", \\\"{x:307,y:557,t:1527616969234};\\\", \\\"{x:294,y:552,t:1527616969252};\\\", \\\"{x:277,y:549,t:1527616969269};\\\", \\\"{x:260,y:547,t:1527616969285};\\\", \\\"{x:245,y:547,t:1527616969302};\\\", \\\"{x:228,y:547,t:1527616969318};\\\", \\\"{x:224,y:548,t:1527616969335};\\\", \\\"{x:220,y:548,t:1527616969352};\\\", \\\"{x:217,y:551,t:1527616969368};\\\", \\\"{x:212,y:553,t:1527616969384};\\\", \\\"{x:205,y:556,t:1527616969402};\\\", \\\"{x:197,y:561,t:1527616969419};\\\", \\\"{x:185,y:564,t:1527616969435};\\\", \\\"{x:171,y:565,t:1527616969451};\\\", \\\"{x:160,y:566,t:1527616969469};\\\", \\\"{x:153,y:566,t:1527616969485};\\\", \\\"{x:150,y:566,t:1527616969501};\\\", \\\"{x:146,y:566,t:1527616969519};\\\", \\\"{x:143,y:565,t:1527616969535};\\\", \\\"{x:140,y:562,t:1527616969553};\\\", \\\"{x:136,y:555,t:1527616969568};\\\", \\\"{x:130,y:547,t:1527616969586};\\\", \\\"{x:127,y:541,t:1527616969601};\\\", \\\"{x:126,y:539,t:1527616969618};\\\", \\\"{x:125,y:537,t:1527616969635};\\\", \\\"{x:125,y:536,t:1527616969654};\\\", \\\"{x:125,y:535,t:1527616969671};\\\", \\\"{x:126,y:533,t:1527616969686};\\\", \\\"{x:127,y:533,t:1527616969727};\\\", \\\"{x:130,y:533,t:1527616969824};\\\", \\\"{x:134,y:533,t:1527616969835};\\\", \\\"{x:136,y:533,t:1527616969855};\\\", \\\"{x:136,y:534,t:1527616969869};\\\", \\\"{x:137,y:534,t:1527616969887};\\\", \\\"{x:140,y:536,t:1527616969975};\\\", \\\"{x:141,y:536,t:1527616969986};\\\", \\\"{x:143,y:538,t:1527616970001};\\\", \\\"{x:145,y:540,t:1527616970018};\\\", \\\"{x:146,y:540,t:1527616970035};\\\", \\\"{x:147,y:541,t:1527616970052};\\\", \\\"{x:148,y:542,t:1527616970068};\\\", \\\"{x:148,y:543,t:1527616970118};\\\", \\\"{x:149,y:543,t:1527616970143};\\\", \\\"{x:150,y:543,t:1527616970695};\\\", \\\"{x:153,y:545,t:1527616970702};\\\", \\\"{x:167,y:553,t:1527616970720};\\\", \\\"{x:195,y:576,t:1527616970736};\\\", \\\"{x:244,y:605,t:1527616970753};\\\", \\\"{x:314,y:640,t:1527616970770};\\\", \\\"{x:386,y:672,t:1527616970786};\\\", \\\"{x:441,y:695,t:1527616970802};\\\", \\\"{x:482,y:713,t:1527616970819};\\\", \\\"{x:513,y:726,t:1527616970838};\\\", \\\"{x:528,y:732,t:1527616970853};\\\", \\\"{x:534,y:735,t:1527616970870};\\\", \\\"{x:532,y:735,t:1527616972335};\\\", \\\"{x:531,y:735,t:1527616972342};\\\", \\\"{x:529,y:735,t:1527616972358};\\\", \\\"{x:529,y:734,t:1527616972370};\\\", \\\"{x:527,y:733,t:1527616972387};\\\" ] }, { \\\"rt\\\": 22960, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 435160, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:722,t:1527616972492};\\\", \\\"{x:517,y:721,t:1527616972510};\\\", \\\"{x:517,y:720,t:1527616972534};\\\", \\\"{x:516,y:719,t:1527616972550};\\\", \\\"{x:515,y:718,t:1527616972574};\\\", \\\"{x:514,y:717,t:1527616972614};\\\", \\\"{x:514,y:716,t:1527616972662};\\\", \\\"{x:513,y:715,t:1527616972670};\\\", \\\"{x:512,y:714,t:1527616972687};\\\", \\\"{x:511,y:712,t:1527616972735};\\\", \\\"{x:510,y:711,t:1527616972758};\\\", \\\"{x:510,y:710,t:1527616972771};\\\", \\\"{x:509,y:710,t:1527616972788};\\\", \\\"{x:509,y:709,t:1527616972804};\\\", \\\"{x:508,y:708,t:1527616972821};\\\", \\\"{x:507,y:706,t:1527616972838};\\\", \\\"{x:505,y:704,t:1527616972854};\\\", \\\"{x:504,y:701,t:1527616972870};\\\", \\\"{x:498,y:691,t:1527616972964};\\\", \\\"{x:497,y:690,t:1527616972971};\\\", \\\"{x:497,y:689,t:1527616972987};\\\", \\\"{x:495,y:688,t:1527616973005};\\\", \\\"{x:494,y:686,t:1527616973020};\\\", \\\"{x:492,y:682,t:1527616973038};\\\", \\\"{x:488,y:674,t:1527616973054};\\\", \\\"{x:482,y:666,t:1527616973071};\\\", \\\"{x:476,y:652,t:1527616973088};\\\", \\\"{x:468,y:639,t:1527616973105};\\\", \\\"{x:457,y:621,t:1527616973121};\\\", \\\"{x:449,y:608,t:1527616973138};\\\", \\\"{x:439,y:593,t:1527616973155};\\\", \\\"{x:432,y:579,t:1527616973171};\\\", \\\"{x:423,y:565,t:1527616973188};\\\", \\\"{x:415,y:553,t:1527616973205};\\\", \\\"{x:407,y:538,t:1527616973222};\\\", \\\"{x:400,y:525,t:1527616973238};\\\", \\\"{x:396,y:518,t:1527616973254};\\\", \\\"{x:392,y:512,t:1527616973271};\\\", \\\"{x:390,y:508,t:1527616973289};\\\", \\\"{x:389,y:506,t:1527616973305};\\\", \\\"{x:388,y:501,t:1527616973322};\\\", \\\"{x:387,y:499,t:1527616973339};\\\", \\\"{x:386,y:496,t:1527616973354};\\\", \\\"{x:385,y:493,t:1527616973371};\\\", \\\"{x:385,y:488,t:1527616973389};\\\", \\\"{x:385,y:483,t:1527616973404};\\\", \\\"{x:391,y:478,t:1527616973422};\\\", \\\"{x:401,y:472,t:1527616973439};\\\", \\\"{x:410,y:468,t:1527616973456};\\\", \\\"{x:419,y:463,t:1527616973472};\\\", \\\"{x:427,y:459,t:1527616973488};\\\", \\\"{x:431,y:458,t:1527616973506};\\\", \\\"{x:435,y:456,t:1527616973521};\\\", \\\"{x:441,y:456,t:1527616973539};\\\", \\\"{x:450,y:455,t:1527616973555};\\\", \\\"{x:464,y:455,t:1527616973571};\\\", \\\"{x:480,y:455,t:1527616973589};\\\", \\\"{x:495,y:455,t:1527616973606};\\\", \\\"{x:511,y:455,t:1527616973623};\\\", \\\"{x:522,y:455,t:1527616973638};\\\", \\\"{x:530,y:455,t:1527616973656};\\\", \\\"{x:539,y:455,t:1527616973673};\\\", \\\"{x:546,y:455,t:1527616973689};\\\", \\\"{x:555,y:455,t:1527616973706};\\\", \\\"{x:568,y:455,t:1527616973722};\\\", \\\"{x:582,y:455,t:1527616973740};\\\", \\\"{x:600,y:456,t:1527616973756};\\\", \\\"{x:620,y:456,t:1527616973773};\\\", \\\"{x:645,y:456,t:1527616973790};\\\", \\\"{x:666,y:456,t:1527616973806};\\\", \\\"{x:696,y:457,t:1527616973823};\\\", \\\"{x:714,y:459,t:1527616973840};\\\", \\\"{x:726,y:459,t:1527616973857};\\\", \\\"{x:733,y:461,t:1527616973873};\\\", \\\"{x:736,y:462,t:1527616973890};\\\", \\\"{x:737,y:462,t:1527616973956};\\\", \\\"{x:738,y:464,t:1527616973962};\\\", \\\"{x:738,y:465,t:1527616973974};\\\", \\\"{x:738,y:472,t:1527616973989};\\\", \\\"{x:737,y:483,t:1527616974006};\\\", \\\"{x:731,y:495,t:1527616974023};\\\", \\\"{x:725,y:506,t:1527616974040};\\\", \\\"{x:716,y:519,t:1527616974057};\\\", \\\"{x:700,y:534,t:1527616974072};\\\", \\\"{x:686,y:546,t:1527616974089};\\\", \\\"{x:674,y:552,t:1527616974105};\\\", \\\"{x:665,y:558,t:1527616974122};\\\", \\\"{x:655,y:562,t:1527616974138};\\\", \\\"{x:650,y:564,t:1527616974155};\\\", \\\"{x:643,y:567,t:1527616974172};\\\", \\\"{x:637,y:569,t:1527616974189};\\\", \\\"{x:629,y:571,t:1527616974205};\\\", \\\"{x:621,y:571,t:1527616974222};\\\", \\\"{x:602,y:572,t:1527616974238};\\\", \\\"{x:586,y:572,t:1527616974255};\\\", \\\"{x:568,y:572,t:1527616974273};\\\", \\\"{x:555,y:570,t:1527616974289};\\\", \\\"{x:547,y:568,t:1527616974307};\\\", \\\"{x:545,y:567,t:1527616974322};\\\", \\\"{x:544,y:566,t:1527616974339};\\\", \\\"{x:542,y:566,t:1527616974356};\\\", \\\"{x:540,y:564,t:1527616974372};\\\", \\\"{x:538,y:563,t:1527616974389};\\\", \\\"{x:536,y:561,t:1527616974406};\\\", \\\"{x:535,y:559,t:1527616974422};\\\", \\\"{x:534,y:559,t:1527616974439};\\\", \\\"{x:533,y:558,t:1527616974456};\\\", \\\"{x:530,y:556,t:1527616974472};\\\", \\\"{x:527,y:555,t:1527616974489};\\\", \\\"{x:525,y:553,t:1527616974505};\\\", \\\"{x:524,y:553,t:1527616974522};\\\", \\\"{x:524,y:552,t:1527616974631};\\\", \\\"{x:524,y:551,t:1527616974639};\\\", \\\"{x:530,y:551,t:1527616974656};\\\", \\\"{x:538,y:549,t:1527616974672};\\\", \\\"{x:550,y:546,t:1527616974689};\\\", \\\"{x:564,y:545,t:1527616974706};\\\", \\\"{x:582,y:543,t:1527616974723};\\\", \\\"{x:602,y:541,t:1527616974739};\\\", \\\"{x:625,y:541,t:1527616974756};\\\", \\\"{x:651,y:541,t:1527616974773};\\\", \\\"{x:677,y:541,t:1527616974789};\\\", \\\"{x:704,y:541,t:1527616974806};\\\", \\\"{x:729,y:543,t:1527616974824};\\\", \\\"{x:747,y:546,t:1527616974839};\\\", \\\"{x:761,y:547,t:1527616974856};\\\", \\\"{x:768,y:548,t:1527616974873};\\\", \\\"{x:770,y:549,t:1527616974890};\\\", \\\"{x:772,y:550,t:1527616974907};\\\", \\\"{x:775,y:550,t:1527616974923};\\\", \\\"{x:779,y:552,t:1527616974940};\\\", \\\"{x:783,y:554,t:1527616974957};\\\", \\\"{x:788,y:555,t:1527616974973};\\\", \\\"{x:790,y:555,t:1527616974990};\\\", \\\"{x:792,y:557,t:1527616975007};\\\", \\\"{x:793,y:557,t:1527616975023};\\\", \\\"{x:791,y:557,t:1527616975136};\\\", \\\"{x:789,y:557,t:1527616975143};\\\", \\\"{x:785,y:557,t:1527616975157};\\\", \\\"{x:766,y:557,t:1527616975175};\\\", \\\"{x:737,y:556,t:1527616975190};\\\", \\\"{x:688,y:549,t:1527616975208};\\\", \\\"{x:658,y:543,t:1527616975224};\\\", \\\"{x:636,y:540,t:1527616975240};\\\", \\\"{x:625,y:539,t:1527616975257};\\\", \\\"{x:617,y:538,t:1527616975273};\\\", \\\"{x:614,y:538,t:1527616975290};\\\", \\\"{x:614,y:537,t:1527616975307};\\\", \\\"{x:612,y:537,t:1527616975323};\\\", \\\"{x:610,y:537,t:1527616975340};\\\", \\\"{x:606,y:536,t:1527616975357};\\\", \\\"{x:603,y:535,t:1527616975373};\\\", \\\"{x:601,y:535,t:1527616975390};\\\", \\\"{x:599,y:535,t:1527616975407};\\\", \\\"{x:598,y:535,t:1527616976152};\\\", \\\"{x:598,y:534,t:1527616976158};\\\", \\\"{x:598,y:533,t:1527616976174};\\\", \\\"{x:597,y:531,t:1527616976190};\\\", \\\"{x:597,y:529,t:1527616976206};\\\", \\\"{x:596,y:528,t:1527616976224};\\\", \\\"{x:596,y:526,t:1527616976239};\\\", \\\"{x:596,y:525,t:1527616976262};\\\", \\\"{x:596,y:524,t:1527616976287};\\\", \\\"{x:596,y:523,t:1527616976294};\\\", \\\"{x:597,y:523,t:1527616976319};\\\", \\\"{x:598,y:522,t:1527616976326};\\\", \\\"{x:599,y:522,t:1527616976350};\\\", \\\"{x:600,y:522,t:1527616976359};\\\", \\\"{x:601,y:521,t:1527616976374};\\\", \\\"{x:603,y:520,t:1527616976391};\\\", \\\"{x:607,y:519,t:1527616976406};\\\", \\\"{x:609,y:519,t:1527616976424};\\\", \\\"{x:613,y:518,t:1527616976441};\\\", \\\"{x:616,y:517,t:1527616976457};\\\", \\\"{x:620,y:517,t:1527616976474};\\\", \\\"{x:622,y:517,t:1527616976492};\\\", \\\"{x:624,y:517,t:1527616976507};\\\", \\\"{x:628,y:517,t:1527616976524};\\\", \\\"{x:632,y:517,t:1527616976541};\\\", \\\"{x:641,y:517,t:1527616976557};\\\", \\\"{x:654,y:519,t:1527616976575};\\\", \\\"{x:675,y:523,t:1527616976591};\\\", \\\"{x:691,y:528,t:1527616976607};\\\", \\\"{x:705,y:534,t:1527616976624};\\\", \\\"{x:725,y:539,t:1527616976641};\\\", \\\"{x:750,y:546,t:1527616976658};\\\", \\\"{x:777,y:553,t:1527616976674};\\\", \\\"{x:806,y:562,t:1527616976691};\\\", \\\"{x:825,y:568,t:1527616976708};\\\", \\\"{x:846,y:573,t:1527616976724};\\\", \\\"{x:868,y:580,t:1527616976742};\\\", \\\"{x:895,y:589,t:1527616976757};\\\", \\\"{x:938,y:603,t:1527616976774};\\\", \\\"{x:970,y:614,t:1527616976791};\\\", \\\"{x:997,y:623,t:1527616976807};\\\", \\\"{x:1021,y:633,t:1527616976824};\\\", \\\"{x:1045,y:643,t:1527616976841};\\\", \\\"{x:1061,y:652,t:1527616976858};\\\", \\\"{x:1075,y:658,t:1527616976874};\\\", \\\"{x:1081,y:663,t:1527616976891};\\\", \\\"{x:1085,y:667,t:1527616976907};\\\", \\\"{x:1086,y:670,t:1527616976924};\\\", \\\"{x:1088,y:674,t:1527616976941};\\\", \\\"{x:1089,y:677,t:1527616976957};\\\", \\\"{x:1091,y:682,t:1527616976974};\\\", \\\"{x:1091,y:690,t:1527616976991};\\\", \\\"{x:1089,y:698,t:1527616977008};\\\", \\\"{x:1084,y:703,t:1527616977024};\\\", \\\"{x:1076,y:710,t:1527616977041};\\\", \\\"{x:1063,y:716,t:1527616977057};\\\", \\\"{x:1041,y:717,t:1527616977074};\\\", \\\"{x:1009,y:718,t:1527616977090};\\\", \\\"{x:953,y:718,t:1527616977107};\\\", \\\"{x:889,y:711,t:1527616977124};\\\", \\\"{x:838,y:695,t:1527616977140};\\\", \\\"{x:771,y:674,t:1527616977157};\\\", \\\"{x:703,y:647,t:1527616977174};\\\", \\\"{x:665,y:633,t:1527616977191};\\\", \\\"{x:618,y:612,t:1527616977207};\\\", \\\"{x:602,y:606,t:1527616977226};\\\", \\\"{x:591,y:603,t:1527616977241};\\\", \\\"{x:579,y:601,t:1527616977257};\\\", \\\"{x:570,y:597,t:1527616977275};\\\", \\\"{x:565,y:596,t:1527616977291};\\\", \\\"{x:561,y:593,t:1527616977308};\\\", \\\"{x:558,y:592,t:1527616977325};\\\", \\\"{x:557,y:592,t:1527616977340};\\\", \\\"{x:555,y:591,t:1527616977358};\\\", \\\"{x:553,y:590,t:1527616977375};\\\", \\\"{x:554,y:590,t:1527616977543};\\\", \\\"{x:556,y:590,t:1527616977558};\\\", \\\"{x:561,y:591,t:1527616977575};\\\", \\\"{x:567,y:591,t:1527616977592};\\\", \\\"{x:571,y:591,t:1527616977608};\\\", \\\"{x:575,y:591,t:1527616977626};\\\", \\\"{x:576,y:591,t:1527616977643};\\\", \\\"{x:578,y:591,t:1527616977658};\\\", \\\"{x:580,y:591,t:1527616977675};\\\", \\\"{x:582,y:591,t:1527616977692};\\\", \\\"{x:583,y:591,t:1527616977708};\\\", \\\"{x:584,y:591,t:1527616977725};\\\", \\\"{x:586,y:591,t:1527616977742};\\\", \\\"{x:587,y:591,t:1527616977758};\\\", \\\"{x:590,y:591,t:1527616977775};\\\", \\\"{x:592,y:591,t:1527616977792};\\\", \\\"{x:593,y:592,t:1527616977809};\\\", \\\"{x:595,y:592,t:1527616977825};\\\", \\\"{x:596,y:592,t:1527616977854};\\\", \\\"{x:596,y:593,t:1527616977879};\\\", \\\"{x:598,y:594,t:1527616977903};\\\", \\\"{x:600,y:594,t:1527616977927};\\\", \\\"{x:601,y:594,t:1527616977942};\\\", \\\"{x:602,y:594,t:1527616977959};\\\", \\\"{x:604,y:594,t:1527616977974};\\\", \\\"{x:605,y:594,t:1527616978006};\\\", \\\"{x:599,y:592,t:1527616978785};\\\", \\\"{x:588,y:582,t:1527616978794};\\\", \\\"{x:566,y:568,t:1527616978811};\\\", \\\"{x:527,y:542,t:1527616978826};\\\", \\\"{x:493,y:524,t:1527616978843};\\\", \\\"{x:462,y:507,t:1527616978859};\\\", \\\"{x:436,y:494,t:1527616978876};\\\", \\\"{x:420,y:483,t:1527616978893};\\\", \\\"{x:413,y:478,t:1527616978909};\\\", \\\"{x:406,y:472,t:1527616978926};\\\", \\\"{x:404,y:469,t:1527616978942};\\\", \\\"{x:403,y:468,t:1527616978959};\\\", \\\"{x:403,y:466,t:1527616978976};\\\", \\\"{x:401,y:465,t:1527616978992};\\\", \\\"{x:401,y:464,t:1527616979014};\\\", \\\"{x:401,y:463,t:1527616979031};\\\", \\\"{x:401,y:462,t:1527616979063};\\\", \\\"{x:402,y:462,t:1527616979087};\\\", \\\"{x:403,y:462,t:1527616979095};\\\", \\\"{x:404,y:462,t:1527616979110};\\\", \\\"{x:409,y:462,t:1527616979126};\\\", \\\"{x:418,y:462,t:1527616979143};\\\", \\\"{x:426,y:462,t:1527616979160};\\\", \\\"{x:438,y:463,t:1527616979176};\\\", \\\"{x:452,y:463,t:1527616979192};\\\", \\\"{x:465,y:464,t:1527616979210};\\\", \\\"{x:482,y:467,t:1527616979227};\\\", \\\"{x:500,y:467,t:1527616979243};\\\", \\\"{x:517,y:467,t:1527616979260};\\\", \\\"{x:529,y:467,t:1527616979277};\\\", \\\"{x:538,y:467,t:1527616979292};\\\", \\\"{x:544,y:467,t:1527616979310};\\\", \\\"{x:552,y:468,t:1527616979326};\\\", \\\"{x:556,y:468,t:1527616979343};\\\", \\\"{x:560,y:468,t:1527616979360};\\\", \\\"{x:563,y:468,t:1527616979377};\\\", \\\"{x:566,y:468,t:1527616979393};\\\", \\\"{x:567,y:468,t:1527616979414};\\\", \\\"{x:569,y:468,t:1527616979543};\\\", \\\"{x:570,y:468,t:1527616979551};\\\", \\\"{x:573,y:468,t:1527616979560};\\\", \\\"{x:579,y:466,t:1527616979577};\\\", \\\"{x:587,y:465,t:1527616979594};\\\", \\\"{x:599,y:462,t:1527616979611};\\\", \\\"{x:607,y:461,t:1527616979628};\\\", \\\"{x:619,y:460,t:1527616979645};\\\", \\\"{x:633,y:460,t:1527616979661};\\\", \\\"{x:644,y:460,t:1527616979677};\\\", \\\"{x:656,y:460,t:1527616979694};\\\", \\\"{x:667,y:460,t:1527616979711};\\\", \\\"{x:672,y:460,t:1527616979728};\\\", \\\"{x:674,y:460,t:1527616979745};\\\", \\\"{x:675,y:460,t:1527616979761};\\\", \\\"{x:676,y:460,t:1527616979777};\\\", \\\"{x:677,y:460,t:1527616979855};\\\", \\\"{x:679,y:461,t:1527616979863};\\\", \\\"{x:679,y:463,t:1527616979878};\\\", \\\"{x:676,y:466,t:1527616979894};\\\", \\\"{x:663,y:469,t:1527616979938};\\\", \\\"{x:651,y:471,t:1527616979955};\\\", \\\"{x:640,y:471,t:1527616979972};\\\", \\\"{x:628,y:471,t:1527616979988};\\\", \\\"{x:614,y:471,t:1527616980005};\\\", \\\"{x:603,y:471,t:1527616980022};\\\", \\\"{x:588,y:471,t:1527616980039};\\\", \\\"{x:571,y:471,t:1527616980056};\\\", \\\"{x:555,y:471,t:1527616980072};\\\", \\\"{x:541,y:471,t:1527616980089};\\\", \\\"{x:529,y:471,t:1527616980105};\\\", \\\"{x:509,y:471,t:1527616980122};\\\", \\\"{x:496,y:471,t:1527616980139};\\\", \\\"{x:483,y:471,t:1527616980155};\\\", \\\"{x:469,y:471,t:1527616980173};\\\", \\\"{x:456,y:471,t:1527616980189};\\\", \\\"{x:443,y:471,t:1527616980206};\\\", \\\"{x:433,y:471,t:1527616980223};\\\", \\\"{x:425,y:471,t:1527616980239};\\\", \\\"{x:420,y:471,t:1527616980255};\\\", \\\"{x:418,y:471,t:1527616980273};\\\", \\\"{x:417,y:472,t:1527616980362};\\\", \\\"{x:417,y:473,t:1527616980386};\\\", \\\"{x:419,y:474,t:1527616980410};\\\", \\\"{x:420,y:474,t:1527616980426};\\\", \\\"{x:421,y:474,t:1527616980440};\\\", \\\"{x:424,y:474,t:1527616980456};\\\", \\\"{x:428,y:474,t:1527616980473};\\\", \\\"{x:433,y:474,t:1527616980490};\\\", \\\"{x:437,y:474,t:1527616980505};\\\", \\\"{x:444,y:474,t:1527616980522};\\\", \\\"{x:447,y:474,t:1527616980540};\\\", \\\"{x:449,y:474,t:1527616980555};\\\", \\\"{x:451,y:474,t:1527616980573};\\\", \\\"{x:452,y:474,t:1527616980595};\\\", \\\"{x:454,y:474,t:1527616980618};\\\", \\\"{x:455,y:474,t:1527616980642};\\\", \\\"{x:458,y:474,t:1527616980657};\\\", \\\"{x:459,y:474,t:1527616980673};\\\", \\\"{x:461,y:474,t:1527616980690};\\\", \\\"{x:465,y:474,t:1527616980707};\\\", \\\"{x:468,y:473,t:1527616980723};\\\", \\\"{x:472,y:473,t:1527616980740};\\\", \\\"{x:476,y:473,t:1527616980756};\\\", \\\"{x:481,y:473,t:1527616980773};\\\", \\\"{x:490,y:473,t:1527616980789};\\\", \\\"{x:496,y:473,t:1527616980807};\\\", \\\"{x:508,y:473,t:1527616980823};\\\", \\\"{x:518,y:473,t:1527616980839};\\\", \\\"{x:526,y:473,t:1527616980857};\\\", \\\"{x:533,y:473,t:1527616980874};\\\", \\\"{x:539,y:473,t:1527616980890};\\\", \\\"{x:548,y:473,t:1527616980906};\\\", \\\"{x:553,y:473,t:1527616980925};\\\", \\\"{x:561,y:473,t:1527616980940};\\\", \\\"{x:571,y:473,t:1527616980957};\\\", \\\"{x:582,y:473,t:1527616980974};\\\", \\\"{x:592,y:473,t:1527616980989};\\\", \\\"{x:601,y:473,t:1527616981007};\\\", \\\"{x:608,y:473,t:1527616981023};\\\", \\\"{x:612,y:473,t:1527616981041};\\\", \\\"{x:617,y:473,t:1527616981056};\\\", \\\"{x:619,y:473,t:1527616981074};\\\", \\\"{x:622,y:473,t:1527616981090};\\\", \\\"{x:623,y:473,t:1527616981233};\\\", \\\"{x:624,y:473,t:1527616981241};\\\", \\\"{x:625,y:473,t:1527616981257};\\\", \\\"{x:629,y:474,t:1527616981273};\\\", \\\"{x:646,y:482,t:1527616981290};\\\", \\\"{x:660,y:486,t:1527616981308};\\\", \\\"{x:675,y:490,t:1527616981324};\\\", \\\"{x:692,y:495,t:1527616981341};\\\", \\\"{x:709,y:501,t:1527616981358};\\\", \\\"{x:733,y:507,t:1527616981375};\\\", \\\"{x:758,y:515,t:1527616981390};\\\", \\\"{x:780,y:520,t:1527616981406};\\\", \\\"{x:802,y:527,t:1527616981422};\\\", \\\"{x:825,y:534,t:1527616981438};\\\", \\\"{x:843,y:540,t:1527616981456};\\\", \\\"{x:866,y:551,t:1527616981473};\\\", \\\"{x:890,y:562,t:1527616981488};\\\", \\\"{x:923,y:579,t:1527616981506};\\\", \\\"{x:939,y:589,t:1527616981522};\\\", \\\"{x:950,y:596,t:1527616981538};\\\", \\\"{x:964,y:606,t:1527616981556};\\\", \\\"{x:981,y:622,t:1527616981573};\\\", \\\"{x:988,y:632,t:1527616981588};\\\", \\\"{x:997,y:642,t:1527616981606};\\\", \\\"{x:1011,y:659,t:1527616981623};\\\", \\\"{x:1025,y:677,t:1527616981640};\\\", \\\"{x:1041,y:695,t:1527616981656};\\\", \\\"{x:1056,y:716,t:1527616981673};\\\", \\\"{x:1075,y:743,t:1527616981689};\\\", \\\"{x:1110,y:808,t:1527616981706};\\\", \\\"{x:1133,y:848,t:1527616981722};\\\", \\\"{x:1149,y:874,t:1527616981740};\\\", \\\"{x:1155,y:883,t:1527616981756};\\\", \\\"{x:1156,y:885,t:1527616981775};\\\", \\\"{x:1156,y:886,t:1527616981829};\\\", \\\"{x:1157,y:887,t:1527616981849};\\\", \\\"{x:1157,y:888,t:1527616981857};\\\", \\\"{x:1158,y:890,t:1527616981873};\\\", \\\"{x:1158,y:891,t:1527616981891};\\\", \\\"{x:1158,y:894,t:1527616981906};\\\", \\\"{x:1158,y:895,t:1527616981930};\\\", \\\"{x:1158,y:897,t:1527616981940};\\\", \\\"{x:1157,y:898,t:1527616981956};\\\", \\\"{x:1157,y:900,t:1527616981973};\\\", \\\"{x:1156,y:904,t:1527616981990};\\\", \\\"{x:1155,y:906,t:1527616982008};\\\", \\\"{x:1152,y:911,t:1527616982023};\\\", \\\"{x:1149,y:916,t:1527616982040};\\\", \\\"{x:1149,y:917,t:1527616982058};\\\", \\\"{x:1148,y:918,t:1527616982075};\\\", \\\"{x:1147,y:919,t:1527616982091};\\\", \\\"{x:1146,y:919,t:1527616982138};\\\", \\\"{x:1145,y:919,t:1527616982154};\\\", \\\"{x:1144,y:919,t:1527616982179};\\\", \\\"{x:1143,y:919,t:1527616982192};\\\", \\\"{x:1142,y:919,t:1527616982208};\\\", \\\"{x:1139,y:919,t:1527616982225};\\\", \\\"{x:1137,y:919,t:1527616982242};\\\", \\\"{x:1134,y:918,t:1527616982258};\\\", \\\"{x:1130,y:915,t:1527616982275};\\\", \\\"{x:1121,y:905,t:1527616982291};\\\", \\\"{x:1116,y:896,t:1527616982309};\\\", \\\"{x:1115,y:891,t:1527616982325};\\\", \\\"{x:1111,y:883,t:1527616982341};\\\", \\\"{x:1108,y:875,t:1527616982358};\\\", \\\"{x:1103,y:859,t:1527616982375};\\\", \\\"{x:1100,y:844,t:1527616982391};\\\", \\\"{x:1097,y:835,t:1527616982408};\\\", \\\"{x:1094,y:827,t:1527616982425};\\\", \\\"{x:1093,y:825,t:1527616982442};\\\", \\\"{x:1093,y:824,t:1527616982458};\\\", \\\"{x:1093,y:823,t:1527616982476};\\\", \\\"{x:1094,y:822,t:1527616982658};\\\", \\\"{x:1096,y:821,t:1527616982666};\\\", \\\"{x:1098,y:821,t:1527616982676};\\\", \\\"{x:1105,y:819,t:1527616982693};\\\", \\\"{x:1110,y:819,t:1527616982709};\\\", \\\"{x:1115,y:819,t:1527616982727};\\\", \\\"{x:1116,y:819,t:1527616982744};\\\", \\\"{x:1118,y:819,t:1527616982760};\\\", \\\"{x:1122,y:820,t:1527616982777};\\\", \\\"{x:1132,y:823,t:1527616982793};\\\", \\\"{x:1144,y:825,t:1527616982810};\\\", \\\"{x:1155,y:829,t:1527616982827};\\\", \\\"{x:1165,y:831,t:1527616982843};\\\", \\\"{x:1169,y:832,t:1527616982861};\\\", \\\"{x:1172,y:832,t:1527616982877};\\\", \\\"{x:1175,y:832,t:1527616982893};\\\", \\\"{x:1176,y:832,t:1527616982910};\\\", \\\"{x:1178,y:832,t:1527616982928};\\\", \\\"{x:1180,y:832,t:1527616982944};\\\", \\\"{x:1184,y:832,t:1527616982961};\\\", \\\"{x:1189,y:832,t:1527616982978};\\\", \\\"{x:1191,y:832,t:1527616982994};\\\", \\\"{x:1193,y:832,t:1527616983011};\\\", \\\"{x:1194,y:832,t:1527616983028};\\\", \\\"{x:1196,y:832,t:1527616983045};\\\", \\\"{x:1201,y:832,t:1527616983061};\\\", \\\"{x:1203,y:832,t:1527616983078};\\\", \\\"{x:1206,y:832,t:1527616983095};\\\", \\\"{x:1209,y:832,t:1527616983112};\\\", \\\"{x:1210,y:831,t:1527616983128};\\\", \\\"{x:1211,y:831,t:1527616983162};\\\", \\\"{x:1212,y:831,t:1527616983194};\\\", \\\"{x:1213,y:831,t:1527616983218};\\\", \\\"{x:1214,y:831,t:1527616983229};\\\", \\\"{x:1215,y:831,t:1527616983245};\\\", \\\"{x:1215,y:827,t:1527616991250};\\\", \\\"{x:1189,y:814,t:1527616991260};\\\", \\\"{x:1155,y:799,t:1527616991273};\\\", \\\"{x:1014,y:745,t:1527616991291};\\\", \\\"{x:933,y:717,t:1527616991308};\\\", \\\"{x:866,y:698,t:1527616991324};\\\", \\\"{x:839,y:688,t:1527616991341};\\\", \\\"{x:826,y:682,t:1527616991357};\\\", \\\"{x:818,y:678,t:1527616991375};\\\", \\\"{x:808,y:672,t:1527616991391};\\\", \\\"{x:795,y:664,t:1527616991407};\\\", \\\"{x:777,y:651,t:1527616991424};\\\", \\\"{x:749,y:637,t:1527616991443};\\\", \\\"{x:709,y:618,t:1527616991458};\\\", \\\"{x:654,y:593,t:1527616991498};\\\", \\\"{x:647,y:591,t:1527616991513};\\\", \\\"{x:647,y:590,t:1527616991537};\\\", \\\"{x:646,y:590,t:1527616991554};\\\", \\\"{x:645,y:590,t:1527616991563};\\\", \\\"{x:641,y:589,t:1527616991580};\\\", \\\"{x:639,y:589,t:1527616991596};\\\", \\\"{x:638,y:589,t:1527616991626};\\\", \\\"{x:636,y:589,t:1527616991650};\\\", \\\"{x:635,y:591,t:1527616991664};\\\", \\\"{x:633,y:596,t:1527616991681};\\\", \\\"{x:633,y:601,t:1527616991697};\\\", \\\"{x:631,y:606,t:1527616991715};\\\", \\\"{x:631,y:608,t:1527616991732};\\\", \\\"{x:631,y:611,t:1527616991746};\\\", \\\"{x:631,y:612,t:1527616991763};\\\", \\\"{x:630,y:614,t:1527616991781};\\\", \\\"{x:630,y:617,t:1527616991797};\\\", \\\"{x:629,y:622,t:1527616991814};\\\", \\\"{x:627,y:626,t:1527616991830};\\\", \\\"{x:627,y:628,t:1527616991847};\\\", \\\"{x:626,y:630,t:1527616991864};\\\", \\\"{x:625,y:633,t:1527616991881};\\\", \\\"{x:623,y:633,t:1527616991897};\\\", \\\"{x:622,y:635,t:1527616991913};\\\", \\\"{x:622,y:636,t:1527616991931};\\\", \\\"{x:620,y:638,t:1527616991947};\\\", \\\"{x:619,y:638,t:1527616991965};\\\", \\\"{x:618,y:638,t:1527616991980};\\\", \\\"{x:616,y:638,t:1527616993322};\\\", \\\"{x:609,y:637,t:1527616993332};\\\", \\\"{x:597,y:632,t:1527616993349};\\\", \\\"{x:587,y:630,t:1527616993365};\\\", \\\"{x:575,y:627,t:1527616993382};\\\", \\\"{x:565,y:623,t:1527616993399};\\\", \\\"{x:560,y:621,t:1527616993415};\\\", \\\"{x:554,y:619,t:1527616993431};\\\", \\\"{x:542,y:614,t:1527616993449};\\\", \\\"{x:516,y:608,t:1527616993466};\\\", \\\"{x:500,y:602,t:1527616993481};\\\", \\\"{x:478,y:599,t:1527616993498};\\\", \\\"{x:458,y:597,t:1527616993515};\\\", \\\"{x:439,y:594,t:1527616993532};\\\", \\\"{x:424,y:591,t:1527616993547};\\\", \\\"{x:415,y:589,t:1527616993566};\\\", \\\"{x:409,y:589,t:1527616993581};\\\", \\\"{x:408,y:589,t:1527616993598};\\\", \\\"{x:406,y:588,t:1527616993625};\\\", \\\"{x:403,y:587,t:1527616993634};\\\", \\\"{x:401,y:587,t:1527616993649};\\\", \\\"{x:396,y:587,t:1527616993665};\\\", \\\"{x:392,y:587,t:1527616993682};\\\", \\\"{x:391,y:588,t:1527616993699};\\\", \\\"{x:391,y:589,t:1527616993715};\\\", \\\"{x:391,y:592,t:1527616993732};\\\", \\\"{x:391,y:594,t:1527616993749};\\\", \\\"{x:392,y:597,t:1527616993765};\\\", \\\"{x:399,y:599,t:1527616993782};\\\", \\\"{x:419,y:605,t:1527616993800};\\\", \\\"{x:446,y:607,t:1527616993816};\\\", \\\"{x:488,y:609,t:1527616993833};\\\", \\\"{x:530,y:609,t:1527616993849};\\\", \\\"{x:575,y:609,t:1527616993865};\\\", \\\"{x:623,y:609,t:1527616993882};\\\", \\\"{x:635,y:611,t:1527616993899};\\\", \\\"{x:642,y:610,t:1527616993916};\\\", \\\"{x:647,y:609,t:1527616993932};\\\", \\\"{x:648,y:609,t:1527616993948};\\\", \\\"{x:649,y:609,t:1527616993978};\\\", \\\"{x:650,y:609,t:1527616993985};\\\", \\\"{x:652,y:609,t:1527616993999};\\\", \\\"{x:657,y:608,t:1527616994016};\\\", \\\"{x:660,y:607,t:1527616994032};\\\", \\\"{x:663,y:606,t:1527616994049};\\\", \\\"{x:664,y:606,t:1527616994114};\\\", \\\"{x:664,y:604,t:1527616994130};\\\", \\\"{x:662,y:602,t:1527616994138};\\\", \\\"{x:660,y:601,t:1527616994150};\\\", \\\"{x:656,y:598,t:1527616994166};\\\", \\\"{x:652,y:596,t:1527616994183};\\\", \\\"{x:647,y:595,t:1527616994200};\\\", \\\"{x:643,y:595,t:1527616994216};\\\", \\\"{x:640,y:595,t:1527616994233};\\\", \\\"{x:638,y:595,t:1527616994249};\\\", \\\"{x:634,y:594,t:1527616994266};\\\", \\\"{x:633,y:594,t:1527616994306};\\\", \\\"{x:632,y:593,t:1527616994316};\\\", \\\"{x:631,y:593,t:1527616994332};\\\", \\\"{x:630,y:593,t:1527616994349};\\\", \\\"{x:628,y:593,t:1527616994366};\\\", \\\"{x:624,y:592,t:1527616994382};\\\", \\\"{x:623,y:592,t:1527616994399};\\\", \\\"{x:622,y:592,t:1527616994416};\\\", \\\"{x:620,y:591,t:1527616994433};\\\", \\\"{x:616,y:591,t:1527616994762};\\\", \\\"{x:613,y:595,t:1527616994769};\\\", \\\"{x:611,y:597,t:1527616994783};\\\", \\\"{x:606,y:603,t:1527616994799};\\\", \\\"{x:602,y:610,t:1527616994816};\\\", \\\"{x:599,y:620,t:1527616994833};\\\", \\\"{x:595,y:638,t:1527616994849};\\\", \\\"{x:592,y:652,t:1527616994866};\\\", \\\"{x:587,y:665,t:1527616994882};\\\", \\\"{x:582,y:680,t:1527616994900};\\\", \\\"{x:577,y:697,t:1527616994916};\\\", \\\"{x:574,y:708,t:1527616994933};\\\", \\\"{x:572,y:715,t:1527616994950};\\\", \\\"{x:570,y:720,t:1527616994965};\\\", \\\"{x:569,y:722,t:1527616994983};\\\", \\\"{x:569,y:725,t:1527616995000};\\\", \\\"{x:568,y:727,t:1527616995016};\\\", \\\"{x:567,y:729,t:1527616995033};\\\", \\\"{x:566,y:729,t:1527616995050};\\\", \\\"{x:565,y:732,t:1527616995066};\\\", \\\"{x:565,y:733,t:1527616995106};\\\", \\\"{x:563,y:734,t:1527616995117};\\\", \\\"{x:563,y:735,t:1527616995134};\\\", \\\"{x:561,y:739,t:1527616995152};\\\", \\\"{x:558,y:742,t:1527616995166};\\\", \\\"{x:557,y:745,t:1527616995183};\\\", \\\"{x:552,y:747,t:1527616995199};\\\", \\\"{x:549,y:750,t:1527616995216};\\\", \\\"{x:546,y:751,t:1527616995233};\\\", \\\"{x:544,y:752,t:1527616995248};\\\", \\\"{x:544,y:751,t:1527616995923};\\\", \\\"{x:544,y:750,t:1527616995934};\\\", \\\"{x:544,y:748,t:1527616995951};\\\", \\\"{x:546,y:745,t:1527616995967};\\\", \\\"{x:547,y:743,t:1527616995984};\\\", \\\"{x:548,y:742,t:1527616996009};\\\", \\\"{x:548,y:741,t:1527616996034};\\\", \\\"{x:549,y:741,t:1527616996050};\\\", \\\"{x:549,y:740,t:1527616996067};\\\", \\\"{x:550,y:739,t:1527616996090};\\\", \\\"{x:551,y:738,t:1527616996106};\\\", \\\"{x:552,y:737,t:1527616996130};\\\", \\\"{x:552,y:736,t:1527616996138};\\\", \\\"{x:553,y:736,t:1527616996150};\\\", \\\"{x:554,y:736,t:1527616996167};\\\", \\\"{x:554,y:735,t:1527616996184};\\\", \\\"{x:555,y:734,t:1527616996200};\\\", \\\"{x:555,y:733,t:1527616996258};\\\", \\\"{x:555,y:732,t:1527616996427};\\\", \\\"{x:556,y:731,t:1527616996434};\\\", \\\"{x:557,y:730,t:1527616996451};\\\" ] }, { \\\"rt\\\": 43653, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 480102, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"by looking at the x axis you see above 12pm which events tart at that time \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 10000, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 491109, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 31724, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Spanish\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 523846, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 1829, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 527020, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"1N858\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"1N858\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 159, dom: 550, initialDom: 613",
  "javascriptErrors": []
}