var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d7af306ce5fd96e25cc25dd00507e5b0",
  "created": "2018-05-18T11:07:52.5195243-07:00",
  "lastActivity": "2018-05-18T11:10:49.8826767-07:00",
  "pageViews": [
    {
      "id": "051852412b6f80caec8a73383eb7b4f7a5057018",
      "startTime": "2018-05-18T11:07:52.5195243-07:00",
      "endTime": "2018-05-18T11:10:49.8826767-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 177489,
      "engagementTime": 45394,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 177489,
  "engagementTime": 45394,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e83941ab4c9ba95f05be898af4337ae9",
  "gdpr": false
}