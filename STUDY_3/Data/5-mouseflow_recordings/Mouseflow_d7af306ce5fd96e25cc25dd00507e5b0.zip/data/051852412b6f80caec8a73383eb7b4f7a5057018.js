var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["051852412b6f80caec8a73383eb7b4f7a5057018"] = {
  "startTime": "2018-05-18T18:07:52.5195243Z",
  "websitePageUrl": "/",
  "visitTime": 177489,
  "engagementTime": 45394,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "d7af306ce5fd96e25cc25dd00507e5b0",
    "created": "2018-05-18T18:07:52.5195243+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "e83941ab4c9ba95f05be898af4337ae9",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/d7af306ce5fd96e25cc25dd00507e5b0/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 316,
      "e": 316,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 2,
      "x": 395,
      "y": 340
    },
    {
      "t": 2003,
      "e": 2003,
      "ty": 41,
      "x": 1938,
      "y": 15851,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 385,
      "y": 344
    },
    {
      "t": 2252,
      "e": 2252,
      "ty": 41,
      "x": 1392,
      "y": 16178,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 384,
      "y": 344
    },
    {
      "t": 6002,
      "e": 6002,
      "ty": 41,
      "x": 1338,
      "y": 16178,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 383,
      "y": 344
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 1283,
      "y": 16178,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 44900,
      "e": 11251,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 44900,
      "e": 11251,
      "ty": 2,
      "x": 383,
      "y": 410
    },
    {
      "t": 45000,
      "e": 11351,
      "ty": 41,
      "x": 1283,
      "y": 17243,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 50001,
      "e": 16351,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140258,
      "e": 16351,
      "ty": 41,
      "x": 6766,
      "y": 11706,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 140309,
      "e": 16402,
      "ty": 2,
      "x": 459,
      "y": 494
    },
    {
      "t": 140409,
      "e": 16502,
      "ty": 2,
      "x": 501,
      "y": 541
    },
    {
      "t": 140508,
      "e": 16601,
      "ty": 2,
      "x": 501,
      "y": 584
    },
    {
      "t": 140509,
      "e": 16602,
      "ty": 41,
      "x": 10210,
      "y": 47074,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 140608,
      "e": 16701,
      "ty": 2,
      "x": 547,
      "y": 688
    },
    {
      "t": 140708,
      "e": 16801,
      "ty": 2,
      "x": 577,
      "y": 765
    },
    {
      "t": 140758,
      "e": 16851,
      "ty": 41,
      "x": 15868,
      "y": 54044,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 140809,
      "e": 16902,
      "ty": 2,
      "x": 668,
      "y": 861
    },
    {
      "t": 140908,
      "e": 17001,
      "ty": 2,
      "x": 704,
      "y": 868
    },
    {
      "t": 141008,
      "e": 17101,
      "ty": 2,
      "x": 733,
      "y": 886
    },
    {
      "t": 141009,
      "e": 17102,
      "ty": 41,
      "x": 21624,
      "y": 64383,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 141108,
      "e": 17201,
      "ty": 2,
      "x": 858,
      "y": 930
    },
    {
      "t": 141208,
      "e": 17301,
      "ty": 2,
      "x": 877,
      "y": 933
    },
    {
      "t": 141258,
      "e": 17351,
      "ty": 41,
      "x": 28708,
      "y": 63310,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 141308,
      "e": 17401,
      "ty": 2,
      "x": 879,
      "y": 933
    },
    {
      "t": 141508,
      "e": 17601,
      "ty": 2,
      "x": 875,
      "y": 934
    },
    {
      "t": 141509,
      "e": 17602,
      "ty": 41,
      "x": 28610,
      "y": 55931,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 141608,
      "e": 17701,
      "ty": 2,
      "x": 846,
      "y": 935
    },
    {
      "t": 141759,
      "e": 17852,
      "ty": 41,
      "x": 27183,
      "y": 56000,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 142109,
      "e": 18202,
      "ty": 2,
      "x": 845,
      "y": 934
    },
    {
      "t": 142208,
      "e": 18301,
      "ty": 2,
      "x": 842,
      "y": 928
    },
    {
      "t": 142259,
      "e": 18352,
      "ty": 41,
      "x": 8097,
      "y": 59623,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 143508,
      "e": 19601,
      "ty": 2,
      "x": 839,
      "y": 927
    },
    {
      "t": 143509,
      "e": 19602,
      "ty": 41,
      "x": 7467,
      "y": 56644,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 143609,
      "e": 19702,
      "ty": 2,
      "x": 831,
      "y": 928
    },
    {
      "t": 143708,
      "e": 19801,
      "ty": 2,
      "x": 824,
      "y": 930
    },
    {
      "t": 143758,
      "e": 19851,
      "ty": 41,
      "x": 25806,
      "y": 58790,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 143808,
      "e": 19901,
      "ty": 2,
      "x": 817,
      "y": 931
    },
    {
      "t": 143909,
      "e": 20002,
      "ty": 2,
      "x": 814,
      "y": 931
    },
    {
      "t": 144008,
      "e": 20101,
      "ty": 2,
      "x": 812,
      "y": 930
    },
    {
      "t": 144008,
      "e": 20101,
      "ty": 41,
      "x": 28057,
      "y": 62309,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 144056,
      "e": 20149,
      "ty": 3,
      "x": 812,
      "y": 930,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 144173,
      "e": 20266,
      "ty": 4,
      "x": 28057,
      "y": 62309,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 144174,
      "e": 20267,
      "ty": 5,
      "x": 812,
      "y": 930,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 144174,
      "e": 20267,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 144179,
      "e": 20272,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 144408,
      "e": 20501,
      "ty": 2,
      "x": 811,
      "y": 937
    },
    {
      "t": 144508,
      "e": 20601,
      "ty": 2,
      "x": 818,
      "y": 948
    },
    {
      "t": 144509,
      "e": 20602,
      "ty": 41,
      "x": 25806,
      "y": 56900,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 144609,
      "e": 20702,
      "ty": 2,
      "x": 893,
      "y": 1012
    },
    {
      "t": 144708,
      "e": 20801,
      "ty": 2,
      "x": 1008,
      "y": 1100
    },
    {
      "t": 144758,
      "e": 20851,
      "ty": 41,
      "x": 54339,
      "y": 58427,
      "ta": "#start"
    },
    {
      "t": 144808,
      "e": 20901,
      "ty": 2,
      "x": 1009,
      "y": 1104
    },
    {
      "t": 144909,
      "e": 21002,
      "ty": 2,
      "x": 1009,
      "y": 1111
    },
    {
      "t": 145008,
      "e": 21101,
      "ty": 2,
      "x": 1007,
      "y": 1111
    },
    {
      "t": 145009,
      "e": 21102,
      "ty": 41,
      "x": 55002,
      "y": 21224,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 145109,
      "e": 21202,
      "ty": 2,
      "x": 1004,
      "y": 1098
    },
    {
      "t": 145208,
      "e": 21301,
      "ty": 2,
      "x": 1002,
      "y": 1094
    },
    {
      "t": 145259,
      "e": 21352,
      "ty": 41,
      "x": 50516,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 145367,
      "e": 21460,
      "ty": 3,
      "x": 1002,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 145368,
      "e": 21461,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 145368,
      "e": 21461,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 145469,
      "e": 21562,
      "ty": 4,
      "x": 50516,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 145470,
      "e": 21563,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 145471,
      "e": 21564,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 145472,
      "e": 21565,
      "ty": 5,
      "x": 1002,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 146479,
      "e": 22572,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 147007,
      "e": 23100,
      "ty": 2,
      "x": 1002,
      "y": 1093
    },
    {
      "t": 147007,
      "e": 23100,
      "ty": 41,
      "x": 34231,
      "y": 60106,
      "ta": "html > body"
    },
    {
      "t": 147207,
      "e": 23300,
      "ty": 2,
      "x": 994,
      "y": 1072
    },
    {
      "t": 147257,
      "e": 23350,
      "ty": 41,
      "x": 31854,
      "y": 52405,
      "ta": "html > body"
    },
    {
      "t": 147307,
      "e": 23400,
      "ty": 2,
      "x": 884,
      "y": 847
    },
    {
      "t": 147408,
      "e": 23501,
      "ty": 2,
      "x": 849,
      "y": 726
    },
    {
      "t": 147445,
      "e": 23538,
      "ty": 6,
      "x": 849,
      "y": 688,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 147461,
      "e": 23554,
      "ty": 7,
      "x": 849,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 147507,
      "e": 23600,
      "ty": 2,
      "x": 849,
      "y": 649
    },
    {
      "t": 147507,
      "e": 23600,
      "ty": 41,
      "x": 8867,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 147595,
      "e": 23688,
      "ty": 6,
      "x": 850,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 147607,
      "e": 23700,
      "ty": 2,
      "x": 850,
      "y": 606
    },
    {
      "t": 147707,
      "e": 23800,
      "ty": 2,
      "x": 850,
      "y": 603
    },
    {
      "t": 147757,
      "e": 23850,
      "ty": 41,
      "x": 9084,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 147807,
      "e": 23900,
      "ty": 2,
      "x": 850,
      "y": 599
    },
    {
      "t": 147907,
      "e": 24000,
      "ty": 2,
      "x": 850,
      "y": 597
    },
    {
      "t": 148008,
      "e": 24101,
      "ty": 41,
      "x": 9084,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148959,
      "e": 25052,
      "ty": 3,
      "x": 850,
      "y": 597,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148960,
      "e": 25053,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 149069,
      "e": 25162,
      "ty": 4,
      "x": 9084,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 149069,
      "e": 25162,
      "ty": 5,
      "x": 850,
      "y": 597,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 149787,
      "e": 25880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 149906,
      "e": 25999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 149907,
      "e": 26000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 149993,
      "e": 26086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "M"
    },
    {
      "t": 150007,
      "e": 26100,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 150057,
      "e": 26150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 150058,
      "e": 26151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 150153,
      "e": 26246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ME"
    },
    {
      "t": 150184,
      "e": 26277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 150185,
      "e": 26278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 150249,
      "e": 26342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MEN"
    },
    {
      "t": 150305,
      "e": 26398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MEN"
    },
    {
      "t": 151007,
      "e": 27100,
      "ty": 2,
      "x": 857,
      "y": 600
    },
    {
      "t": 151008,
      "e": 27101,
      "ty": 41,
      "x": 10598,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 151015,
      "e": 27108,
      "ty": 7,
      "x": 857,
      "y": 618,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 151098,
      "e": 27191,
      "ty": 6,
      "x": 857,
      "y": 689,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151107,
      "e": 27200,
      "ty": 2,
      "x": 857,
      "y": 689
    },
    {
      "t": 151114,
      "e": 27207,
      "ty": 7,
      "x": 857,
      "y": 701,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151208,
      "e": 27301,
      "ty": 2,
      "x": 857,
      "y": 704
    },
    {
      "t": 151257,
      "e": 27350,
      "ty": 41,
      "x": 10598,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 151407,
      "e": 27500,
      "ty": 2,
      "x": 860,
      "y": 701
    },
    {
      "t": 151431,
      "e": 27524,
      "ty": 6,
      "x": 860,
      "y": 699,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151508,
      "e": 27601,
      "ty": 2,
      "x": 861,
      "y": 697
    },
    {
      "t": 151508,
      "e": 27601,
      "ty": 41,
      "x": 11463,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151608,
      "e": 27701,
      "ty": 2,
      "x": 864,
      "y": 693
    },
    {
      "t": 151708,
      "e": 27801,
      "ty": 2,
      "x": 864,
      "y": 692
    },
    {
      "t": 151758,
      "e": 27851,
      "ty": 41,
      "x": 12112,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151823,
      "e": 27916,
      "ty": 3,
      "x": 864,
      "y": 692,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151823,
      "e": 27916,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MEN"
    },
    {
      "t": 151825,
      "e": 27918,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 151825,
      "e": 27918,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151941,
      "e": 28034,
      "ty": 4,
      "x": 12112,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151941,
      "e": 28034,
      "ty": 5,
      "x": 864,
      "y": 692,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 153058,
      "e": 29151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 153058,
      "e": 29151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 153137,
      "e": 29230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 153226,
      "e": 29319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 153226,
      "e": 29319,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 153345,
      "e": 29438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 153474,
      "e": 29567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "51"
    },
    {
      "t": 153474,
      "e": 29567,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 153545,
      "e": 29638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 154150,
      "e": 30243,
      "ty": 7,
      "x": 875,
      "y": 704,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 154208,
      "e": 30301,
      "ty": 2,
      "x": 889,
      "y": 717
    },
    {
      "t": 154257,
      "e": 30350,
      "ty": 41,
      "x": 30477,
      "y": 39387,
      "ta": "html > body"
    },
    {
      "t": 154266,
      "e": 30359,
      "ty": 6,
      "x": 895,
      "y": 721,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 154308,
      "e": 30401,
      "ty": 2,
      "x": 901,
      "y": 725
    },
    {
      "t": 154408,
      "e": 30501,
      "ty": 2,
      "x": 910,
      "y": 727
    },
    {
      "t": 154508,
      "e": 30601,
      "ty": 2,
      "x": 915,
      "y": 728
    },
    {
      "t": 154508,
      "e": 30601,
      "ty": 41,
      "x": 9832,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 154558,
      "e": 30651,
      "ty": 3,
      "x": 915,
      "y": 728,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 154560,
      "e": 30653,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 154560,
      "e": 30653,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 154561,
      "e": 30654,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 154677,
      "e": 30770,
      "ty": 4,
      "x": 9832,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 154678,
      "e": 30771,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 154680,
      "e": 30773,
      "ty": 5,
      "x": 915,
      "y": 728,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 154680,
      "e": 30773,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 155772,
      "e": 31865,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 155801,
      "e": 31894,
      "ty": 6,
      "x": 915,
      "y": 728,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 160008,
      "e": 36101,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 168258,
      "e": 36894,
      "ty": 41,
      "x": 29586,
      "y": 53868,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 168262,
      "e": 36898,
      "ty": 7,
      "x": 916,
      "y": 758,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 168262,
      "e": 36898,
      "ty": 6,
      "x": 916,
      "y": 758,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 168278,
      "e": 36914,
      "ty": 7,
      "x": 916,
      "y": 786,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 168307,
      "e": 36943,
      "ty": 2,
      "x": 916,
      "y": 806
    },
    {
      "t": 168407,
      "e": 37043,
      "ty": 2,
      "x": 905,
      "y": 894
    },
    {
      "t": 168508,
      "e": 37144,
      "ty": 2,
      "x": 903,
      "y": 948
    },
    {
      "t": 168508,
      "e": 37144,
      "ty": 41,
      "x": 29987,
      "y": 56900,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 168607,
      "e": 37243,
      "ty": 2,
      "x": 917,
      "y": 1012
    },
    {
      "t": 168679,
      "e": 37315,
      "ty": 6,
      "x": 931,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 168707,
      "e": 37343,
      "ty": 2,
      "x": 934,
      "y": 1083
    },
    {
      "t": 168758,
      "e": 37394,
      "ty": 41,
      "x": 16656,
      "y": 56499,
      "ta": "#start"
    },
    {
      "t": 168761,
      "e": 37397,
      "ty": 7,
      "x": 943,
      "y": 1108,
      "ta": "#start"
    },
    {
      "t": 168807,
      "e": 37443,
      "ty": 2,
      "x": 944,
      "y": 1111
    },
    {
      "t": 168907,
      "e": 37543,
      "ty": 2,
      "x": 955,
      "y": 1128
    },
    {
      "t": 169007,
      "e": 37643,
      "ty": 2,
      "x": 957,
      "y": 1121
    },
    {
      "t": 169008,
      "e": 37644,
      "ty": 41,
      "x": 31597,
      "y": 26764,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 169096,
      "e": 37732,
      "ty": 6,
      "x": 964,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 169108,
      "e": 37744,
      "ty": 2,
      "x": 964,
      "y": 1106
    },
    {
      "t": 169207,
      "e": 37843,
      "ty": 2,
      "x": 966,
      "y": 1101
    },
    {
      "t": 169257,
      "e": 37893,
      "ty": 41,
      "x": 31402,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 169308,
      "e": 37944,
      "ty": 2,
      "x": 967,
      "y": 1100
    },
    {
      "t": 169519,
      "e": 38155,
      "ty": 3,
      "x": 967,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 169520,
      "e": 38156,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 169637,
      "e": 38273,
      "ty": 4,
      "x": 31402,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 169638,
      "e": 38274,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 169639,
      "e": 38275,
      "ty": 5,
      "x": 967,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 169641,
      "e": 38277,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 170508,
      "e": 39144,
      "ty": 2,
      "x": 965,
      "y": 1100
    },
    {
      "t": 170508,
      "e": 39144,
      "ty": 41,
      "x": 32956,
      "y": 60493,
      "ta": "html > body"
    },
    {
      "t": 170608,
      "e": 39244,
      "ty": 2,
      "x": 964,
      "y": 1101
    },
    {
      "t": 170641,
      "e": 39277,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 170758,
      "e": 39394,
      "ty": 41,
      "x": 32922,
      "y": 60549,
      "ta": "html > body"
    },
    {
      "t": 171408,
      "e": 40044,
      "ty": 2,
      "x": 963,
      "y": 1099
    },
    {
      "t": 171507,
      "e": 40143,
      "ty": 2,
      "x": 963,
      "y": 1098
    },
    {
      "t": 171509,
      "e": 40145,
      "ty": 41,
      "x": 32888,
      "y": 60383,
      "ta": "html > body"
    },
    {
      "t": 171608,
      "e": 40244,
      "ty": 2,
      "x": 957,
      "y": 1087
    },
    {
      "t": 171758,
      "e": 40394,
      "ty": 41,
      "x": 32681,
      "y": 59773,
      "ta": "html > body"
    },
    {
      "t": 176484,
      "e": 45120,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 177489,
      "e": 45394,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 66, dom: 596, initialDom: 1953",
  "javascriptErrors": []
}