var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "75efd447a12686f58517f0d8a811872b",
  "created": "2018-05-25T09:15:31.8258149-07:00",
  "lastActivity": "2018-05-25T09:17:06.6518961-07:00",
  "pageViews": [
    {
      "id": "05253165aa9b21594e7005da15ab7b57bdf2a263",
      "startTime": "2018-05-25T09:15:32.0878961-07:00",
      "endTime": "2018-05-25T09:17:06.6518961-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 94564,
      "engagementTime": 85145,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 94564,
  "engagementTime": 85145,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MW3RC",
    "CONDITION=115",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "96c0ed48a72693f82d8fd9c2596fdd00",
  "gdpr": false
}