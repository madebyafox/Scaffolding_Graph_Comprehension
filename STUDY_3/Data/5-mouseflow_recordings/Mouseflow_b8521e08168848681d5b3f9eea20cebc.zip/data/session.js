var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b8521e08168848681d5b3f9eea20cebc",
  "created": "2018-05-21T10:12:32.4789221-07:00",
  "lastActivity": "2018-05-21T10:12:51.9320493-07:00",
  "pageViews": [
    {
      "id": "05213204a16f0f03d2259c9138eadfc7984a5be7",
      "startTime": "2018-05-21T10:12:32.6010493-07:00",
      "endTime": "2018-05-21T10:12:51.9320493-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 19331,
      "engagementTime": 17582,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 19331,
  "engagementTime": 17582,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.48",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=YE3VQ",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c10312659a8f52bd7aebab258755a7e5",
  "gdpr": false
}