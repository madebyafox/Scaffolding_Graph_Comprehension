var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0b5e6e1a045544ab5c3cbd845eb03dd3",
  "created": "2018-05-18T11:18:43.1369209-07:00",
  "lastActivity": "2018-05-18T11:18:55.9739209-07:00",
  "pageViews": [
    {
      "id": "0518436557ef2d7508878dad78830c4c2b134e69",
      "startTime": "2018-05-18T11:18:43.1369209-07:00",
      "endTime": "2018-05-18T11:18:55.9739209-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 12837,
      "engagementTime": 12820,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 12837,
  "engagementTime": 12820,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=08WET",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "2c86c3c3e904bfc563a41389f0b56675",
  "gdpr": false
}