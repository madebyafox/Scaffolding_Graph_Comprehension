var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06043382b0877c57d1bec7586be278952f7b7237"] = {
  "startTime": "2018-06-04T19:16:33.3401713Z",
  "websitePageUrl": "/9",
  "visitTime": 47396,
  "engagementTime": 36413,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "49b2c6e60e1451dbfa4125b92c0ef15b",
    "created": "2018-06-04T19:16:32.9178783+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/9",
    "tags": [
      "form-interact"
    ],
    "variables": [
      "SID=1N65C",
      "CONDITION=311",
      "TRI_CORRECT=1",
      "ORTH_CORRECT=1"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "1e0603c26eee5315bace43f5986d8ca8",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/49b2c6e60e1451dbfa4125b92c0ef15b/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 675,
      "e": 675,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 688,
      "e": 688,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 5254,
      "e": 5100,
      "ty": 41,
      "x": 50516,
      "y": 11384,
      "ta": "#testingButton"
    },
    {
      "t": 5264,
      "e": 5110,
      "ty": 7,
      "x": 619,
      "y": 709,
      "ta": "#testingButton"
    },
    {
      "t": 5304,
      "e": 5150,
      "ty": 2,
      "x": 853,
      "y": 677
    },
    {
      "t": 5403,
      "e": 5249,
      "ty": 2,
      "x": 1074,
      "y": 650
    },
    {
      "t": 5503,
      "e": 5349,
      "ty": 2,
      "x": 1546,
      "y": 644
    },
    {
      "t": 5504,
      "e": 5350,
      "ty": 41,
      "x": 39814,
      "y": 36241,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5603,
      "e": 5449,
      "ty": 2,
      "x": 1613,
      "y": 617
    },
    {
      "t": 5755,
      "e": 5601,
      "ty": 41,
      "x": 44535,
      "y": 34307,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6004,
      "e": 5850,
      "ty": 2,
      "x": 1606,
      "y": 620
    },
    {
      "t": 6004,
      "e": 5850,
      "ty": 41,
      "x": 44042,
      "y": 34522,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6704,
      "e": 6550,
      "ty": 2,
      "x": 1567,
      "y": 639
    },
    {
      "t": 6754,
      "e": 6600,
      "ty": 41,
      "x": 40800,
      "y": 36312,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6804,
      "e": 6650,
      "ty": 2,
      "x": 1547,
      "y": 660
    },
    {
      "t": 6903,
      "e": 6749,
      "ty": 2,
      "x": 1517,
      "y": 693
    },
    {
      "t": 7004,
      "e": 6850,
      "ty": 2,
      "x": 1481,
      "y": 754
    },
    {
      "t": 7005,
      "e": 6851,
      "ty": 41,
      "x": 35233,
      "y": 44119,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7104,
      "e": 6950,
      "ty": 2,
      "x": 1471,
      "y": 791
    },
    {
      "t": 7254,
      "e": 7100,
      "ty": 41,
      "x": 34529,
      "y": 46769,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7754,
      "e": 7600,
      "ty": 41,
      "x": 34529,
      "y": 46483,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7804,
      "e": 7650,
      "ty": 2,
      "x": 1474,
      "y": 785
    },
    {
      "t": 7904,
      "e": 7750,
      "ty": 2,
      "x": 1611,
      "y": 775
    },
    {
      "t": 8004,
      "e": 7850,
      "ty": 2,
      "x": 1698,
      "y": 736
    },
    {
      "t": 8004,
      "e": 7850,
      "ty": 41,
      "x": 50525,
      "y": 42830,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8104,
      "e": 7950,
      "ty": 2,
      "x": 1686,
      "y": 694
    },
    {
      "t": 8203,
      "e": 8049,
      "ty": 2,
      "x": 1620,
      "y": 626
    },
    {
      "t": 8255,
      "e": 8101,
      "ty": 41,
      "x": 44676,
      "y": 32516,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8304,
      "e": 8150,
      "ty": 2,
      "x": 1614,
      "y": 578
    },
    {
      "t": 8404,
      "e": 8250,
      "ty": 2,
      "x": 1614,
      "y": 572
    },
    {
      "t": 8505,
      "e": 8351,
      "ty": 41,
      "x": 44606,
      "y": 31084,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8703,
      "e": 8549,
      "ty": 2,
      "x": 1595,
      "y": 545
    },
    {
      "t": 8754,
      "e": 8600,
      "ty": 41,
      "x": 42844,
      "y": 28434,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8803,
      "e": 8649,
      "ty": 2,
      "x": 1585,
      "y": 530
    },
    {
      "t": 8904,
      "e": 8750,
      "ty": 2,
      "x": 1584,
      "y": 527
    },
    {
      "t": 9004,
      "e": 8850,
      "ty": 2,
      "x": 1583,
      "y": 527
    },
    {
      "t": 9005,
      "e": 8851,
      "ty": 41,
      "x": 42421,
      "y": 27861,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9204,
      "e": 9050,
      "ty": 2,
      "x": 1578,
      "y": 527
    },
    {
      "t": 9254,
      "e": 9100,
      "ty": 41,
      "x": 41435,
      "y": 28720,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9304,
      "e": 9150,
      "ty": 2,
      "x": 1550,
      "y": 568
    },
    {
      "t": 9404,
      "e": 9250,
      "ty": 2,
      "x": 1515,
      "y": 691
    },
    {
      "t": 9504,
      "e": 9350,
      "ty": 2,
      "x": 1500,
      "y": 780
    },
    {
      "t": 9504,
      "e": 9350,
      "ty": 41,
      "x": 36572,
      "y": 45981,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9604,
      "e": 9450,
      "ty": 2,
      "x": 1488,
      "y": 821
    },
    {
      "t": 9704,
      "e": 9550,
      "ty": 2,
      "x": 1464,
      "y": 862
    },
    {
      "t": 9755,
      "e": 9601,
      "ty": 41,
      "x": 32485,
      "y": 52786,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9803,
      "e": 9649,
      "ty": 2,
      "x": 1401,
      "y": 885
    },
    {
      "t": 9903,
      "e": 9749,
      "ty": 2,
      "x": 1243,
      "y": 893
    },
    {
      "t": 10004,
      "e": 9850,
      "ty": 2,
      "x": 1205,
      "y": 871
    },
    {
      "t": 10004,
      "e": 9850,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10006,
      "e": 9852,
      "ty": 41,
      "x": 15784,
      "y": 52499,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10104,
      "e": 9950,
      "ty": 2,
      "x": 1203,
      "y": 853
    },
    {
      "t": 10204,
      "e": 10050,
      "ty": 2,
      "x": 1204,
      "y": 842
    },
    {
      "t": 10254,
      "e": 10100,
      "ty": 41,
      "x": 15784,
      "y": 50207,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10304,
      "e": 10150,
      "ty": 2,
      "x": 1205,
      "y": 833
    },
    {
      "t": 10404,
      "e": 10250,
      "ty": 2,
      "x": 1206,
      "y": 831
    },
    {
      "t": 10504,
      "e": 10350,
      "ty": 41,
      "x": 15855,
      "y": 49634,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11203,
      "e": 11049,
      "ty": 2,
      "x": 1209,
      "y": 830
    },
    {
      "t": 11255,
      "e": 11101,
      "ty": 41,
      "x": 9101,
      "y": 29126,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[10] > circle"
    },
    {
      "t": 11304,
      "e": 11150,
      "ty": 2,
      "x": 1210,
      "y": 829
    },
    {
      "t": 13254,
      "e": 13100,
      "ty": 41,
      "x": 14563,
      "y": 29126,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[10] > circle"
    },
    {
      "t": 13304,
      "e": 13150,
      "ty": 2,
      "x": 1187,
      "y": 785
    },
    {
      "t": 13404,
      "e": 13250,
      "ty": 2,
      "x": 1178,
      "y": 773
    },
    {
      "t": 13504,
      "e": 13350,
      "ty": 41,
      "x": 13882,
      "y": 45480,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 13604,
      "e": 13450,
      "ty": 2,
      "x": 1178,
      "y": 772
    },
    {
      "t": 13704,
      "e": 13550,
      "ty": 2,
      "x": 1178,
      "y": 767
    },
    {
      "t": 13753,
      "e": 13599,
      "ty": 41,
      "x": 16383,
      "y": 32767,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[9] > circle"
    },
    {
      "t": 13804,
      "e": 13650,
      "ty": 2,
      "x": 1178,
      "y": 763
    },
    {
      "t": 16903,
      "e": 16749,
      "ty": 2,
      "x": 1231,
      "y": 621
    },
    {
      "t": 17003,
      "e": 16849,
      "ty": 2,
      "x": 1292,
      "y": 513
    },
    {
      "t": 17003,
      "e": 16849,
      "ty": 41,
      "x": 21915,
      "y": 26858,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 17103,
      "e": 16949,
      "ty": 2,
      "x": 1297,
      "y": 500
    },
    {
      "t": 17254,
      "e": 17100,
      "ty": 41,
      "x": 22267,
      "y": 27001,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 17303,
      "e": 17149,
      "ty": 2,
      "x": 1296,
      "y": 540
    },
    {
      "t": 17403,
      "e": 17249,
      "ty": 2,
      "x": 1292,
      "y": 554
    },
    {
      "t": 17504,
      "e": 17350,
      "ty": 2,
      "x": 1288,
      "y": 558
    },
    {
      "t": 17504,
      "e": 17350,
      "ty": 41,
      "x": 21633,
      "y": 30081,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 17603,
      "e": 17449,
      "ty": 2,
      "x": 1283,
      "y": 560
    },
    {
      "t": 17703,
      "e": 17549,
      "ty": 2,
      "x": 1279,
      "y": 563
    },
    {
      "t": 17754,
      "e": 17600,
      "ty": 41,
      "x": 21845,
      "y": 32767,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[5] > circle"
    },
    {
      "t": 20004,
      "e": 19850,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 27898,
      "e": 22600,
      "ty": 6,
      "x": 775,
      "y": 548,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[8]"
    },
    {
      "t": 27903,
      "e": 22605,
      "ty": 2,
      "x": 775,
      "y": 548
    },
    {
      "t": 27915,
      "e": 22617,
      "ty": 7,
      "x": 651,
      "y": 535,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[8]"
    },
    {
      "t": 27915,
      "e": 22617,
      "ty": 6,
      "x": 651,
      "y": 535,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[7]"
    },
    {
      "t": 27931,
      "e": 22633,
      "ty": 7,
      "x": 537,
      "y": 517,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[7]"
    },
    {
      "t": 27931,
      "e": 22633,
      "ty": 6,
      "x": 537,
      "y": 517,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[3]"
    },
    {
      "t": 27944,
      "e": 22646,
      "ty": 7,
      "x": 454,
      "y": 506,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[3]"
    },
    {
      "t": 27944,
      "e": 22646,
      "ty": 6,
      "x": 454,
      "y": 506,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[2]"
    },
    {
      "t": 28003,
      "e": 22705,
      "ty": 2,
      "x": 428,
      "y": 502
    },
    {
      "t": 28003,
      "e": 22705,
      "ty": 41,
      "x": 44855,
      "y": 32562,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[2]"
    },
    {
      "t": 28094,
      "e": 22796,
      "ty": 7,
      "x": 490,
      "y": 486,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[2]"
    },
    {
      "t": 28104,
      "e": 22806,
      "ty": 2,
      "x": 490,
      "y": 486
    },
    {
      "t": 28204,
      "e": 22906,
      "ty": 2,
      "x": 754,
      "y": 484
    },
    {
      "t": 28254,
      "e": 22956,
      "ty": 41,
      "x": 50245,
      "y": 17168,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 28303,
      "e": 23005,
      "ty": 2,
      "x": 755,
      "y": 484
    },
    {
      "t": 28314,
      "e": 23016,
      "ty": 6,
      "x": 753,
      "y": 487,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[4]"
    },
    {
      "t": 28378,
      "e": 23080,
      "ty": 7,
      "x": 711,
      "y": 501,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[4]"
    },
    {
      "t": 28379,
      "e": 23081,
      "ty": 6,
      "x": 711,
      "y": 501,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[3]"
    },
    {
      "t": 28403,
      "e": 23105,
      "ty": 2,
      "x": 696,
      "y": 503
    },
    {
      "t": 28503,
      "e": 23205,
      "ty": 2,
      "x": 634,
      "y": 514
    },
    {
      "t": 28503,
      "e": 23205,
      "ty": 41,
      "x": 39163,
      "y": 58776,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[3]"
    },
    {
      "t": 28604,
      "e": 23306,
      "ty": 2,
      "x": 624,
      "y": 514
    },
    {
      "t": 28704,
      "e": 23406,
      "ty": 2,
      "x": 617,
      "y": 514
    },
    {
      "t": 28754,
      "e": 23456,
      "ty": 41,
      "x": 51404,
      "y": 61951,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[3] > label > div"
    },
    {
      "t": 28804,
      "e": 23506,
      "ty": 2,
      "x": 616,
      "y": 512
    },
    {
      "t": 29003,
      "e": 23705,
      "ty": 2,
      "x": 615,
      "y": 512
    },
    {
      "t": 29004,
      "e": 23706,
      "ty": 41,
      "x": 48127,
      "y": 61951,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[3] > label > div"
    },
    {
      "t": 39640,
      "e": 28706,
      "ty": 7,
      "x": 675,
      "y": 527,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[3]"
    },
    {
      "t": 39640,
      "e": 28706,
      "ty": 6,
      "x": 675,
      "y": 527,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[7]"
    },
    {
      "t": 39669,
      "e": 28735,
      "ty": 7,
      "x": 801,
      "y": 559,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[7]"
    },
    {
      "t": 39686,
      "e": 28752,
      "ty": 6,
      "x": 866,
      "y": 571,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[12]"
    },
    {
      "t": 39704,
      "e": 28770,
      "ty": 2,
      "x": 930,
      "y": 571
    },
    {
      "t": 39721,
      "e": 28787,
      "ty": 7,
      "x": 970,
      "y": 576,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[12]"
    },
    {
      "t": 39755,
      "e": 28821,
      "ty": 41,
      "x": 65198,
      "y": 39078,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 39804,
      "e": 28870,
      "ty": 2,
      "x": 976,
      "y": 576
    },
    {
      "t": 39904,
      "e": 28970,
      "ty": 2,
      "x": 1043,
      "y": 589
    },
    {
      "t": 40004,
      "e": 29070,
      "ty": 2,
      "x": 1643,
      "y": 834
    },
    {
      "t": 40005,
      "e": 29071,
      "ty": 41,
      "x": 46649,
      "y": 49849,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 40005,
      "e": 29071,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40104,
      "e": 29170,
      "ty": 2,
      "x": 1715,
      "y": 904
    },
    {
      "t": 40203,
      "e": 29269,
      "ty": 2,
      "x": 1642,
      "y": 878
    },
    {
      "t": 40255,
      "e": 29321,
      "ty": 41,
      "x": 17694,
      "y": 47731,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[7]"
    },
    {
      "t": 40304,
      "e": 29370,
      "ty": 2,
      "x": 1311,
      "y": 784
    },
    {
      "t": 40403,
      "e": 29469,
      "ty": 2,
      "x": 1310,
      "y": 781
    },
    {
      "t": 40504,
      "e": 29570,
      "ty": 2,
      "x": 1329,
      "y": 762
    },
    {
      "t": 40504,
      "e": 29570,
      "ty": 41,
      "x": 24522,
      "y": 44692,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 40603,
      "e": 29669,
      "ty": 2,
      "x": 1335,
      "y": 760
    },
    {
      "t": 40703,
      "e": 29769,
      "ty": 2,
      "x": 1344,
      "y": 756
    },
    {
      "t": 40754,
      "e": 29820,
      "ty": 41,
      "x": 11007,
      "y": 56172,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[2] > text"
    },
    {
      "t": 41003,
      "e": 30069,
      "ty": 2,
      "x": 1318,
      "y": 809
    },
    {
      "t": 41003,
      "e": 30069,
      "ty": 41,
      "x": 23747,
      "y": 48059,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 41103,
      "e": 30169,
      "ty": 2,
      "x": 1296,
      "y": 854
    },
    {
      "t": 41203,
      "e": 30269,
      "ty": 2,
      "x": 1289,
      "y": 875
    },
    {
      "t": 41254,
      "e": 30320,
      "ty": 41,
      "x": 21422,
      "y": 53645,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 41303,
      "e": 30369,
      "ty": 2,
      "x": 1279,
      "y": 901
    },
    {
      "t": 41403,
      "e": 30469,
      "ty": 2,
      "x": 1259,
      "y": 941
    },
    {
      "t": 41503,
      "e": 30569,
      "ty": 2,
      "x": 1247,
      "y": 961
    },
    {
      "t": 41504,
      "e": 30570,
      "ty": 41,
      "x": 18744,
      "y": 58945,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 41603,
      "e": 30669,
      "ty": 2,
      "x": 1243,
      "y": 967
    },
    {
      "t": 41754,
      "e": 30820,
      "ty": 41,
      "x": 18462,
      "y": 59375,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 42254,
      "e": 31320,
      "ty": 41,
      "x": 18039,
      "y": 59518,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 42304,
      "e": 31370,
      "ty": 2,
      "x": 1054,
      "y": 970
    },
    {
      "t": 42403,
      "e": 31469,
      "ty": 2,
      "x": 708,
      "y": 886
    },
    {
      "t": 42503,
      "e": 31569,
      "ty": 2,
      "x": 596,
      "y": 749
    },
    {
      "t": 42503,
      "e": 31569,
      "ty": 41,
      "x": 39603,
      "y": 41049,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 42533,
      "e": 31599,
      "ty": 6,
      "x": 564,
      "y": 734,
      "ta": "#testingButton"
    },
    {
      "t": 42589,
      "e": 31655,
      "ty": 7,
      "x": 563,
      "y": 721,
      "ta": "#testingButton"
    },
    {
      "t": 42604,
      "e": 31670,
      "ty": 2,
      "x": 563,
      "y": 721
    },
    {
      "t": 42703,
      "e": 31769,
      "ty": 2,
      "x": 572,
      "y": 711
    },
    {
      "t": 42754,
      "e": 31820,
      "ty": 41,
      "x": 37987,
      "y": 38944,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 43304,
      "e": 32370,
      "ty": 2,
      "x": 567,
      "y": 694
    },
    {
      "t": 43341,
      "e": 32407,
      "ty": 6,
      "x": 519,
      "y": 628,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[15]"
    },
    {
      "t": 43357,
      "e": 32423,
      "ty": 7,
      "x": 481,
      "y": 598,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[15]"
    },
    {
      "t": 43373,
      "e": 32439,
      "ty": 6,
      "x": 434,
      "y": 565,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[10]"
    },
    {
      "t": 43391,
      "e": 32457,
      "ty": 7,
      "x": 389,
      "y": 535,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[10]"
    },
    {
      "t": 43391,
      "e": 32457,
      "ty": 6,
      "x": 389,
      "y": 535,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[6]"
    },
    {
      "t": 43403,
      "e": 32469,
      "ty": 2,
      "x": 389,
      "y": 535
    },
    {
      "t": 43407,
      "e": 32473,
      "ty": 7,
      "x": 356,
      "y": 516,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[6]"
    },
    {
      "t": 43407,
      "e": 32473,
      "ty": 6,
      "x": 356,
      "y": 516,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[2]"
    },
    {
      "t": 43440,
      "e": 32506,
      "ty": 7,
      "x": 312,
      "y": 478,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[2]"
    },
    {
      "t": 43503,
      "e": 32569,
      "ty": 2,
      "x": 296,
      "y": 459
    },
    {
      "t": 43503,
      "e": 32569,
      "ty": 41,
      "x": 19397,
      "y": 41910,
      "ta": "#bigset.starttime+before+endtime+during > p"
    },
    {
      "t": 43691,
      "e": 32757,
      "ty": 6,
      "x": 312,
      "y": 497,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[2]"
    },
    {
      "t": 43703,
      "e": 32769,
      "ty": 2,
      "x": 312,
      "y": 497
    },
    {
      "t": 43723,
      "e": 32789,
      "ty": 7,
      "x": 331,
      "y": 531,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[2]"
    },
    {
      "t": 43723,
      "e": 32789,
      "ty": 6,
      "x": 331,
      "y": 531,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[6]"
    },
    {
      "t": 43754,
      "e": 32820,
      "ty": 41,
      "x": 19581,
      "y": 45669,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[6]"
    },
    {
      "t": 43774,
      "e": 32840,
      "ty": 7,
      "x": 347,
      "y": 559,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[6]"
    },
    {
      "t": 43804,
      "e": 32870,
      "ty": 2,
      "x": 347,
      "y": 560
    },
    {
      "t": 43824,
      "e": 32890,
      "ty": 6,
      "x": 348,
      "y": 564,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[10]"
    },
    {
      "t": 43903,
      "e": 32969,
      "ty": 2,
      "x": 336,
      "y": 569
    },
    {
      "t": 43941,
      "e": 33007,
      "ty": 7,
      "x": 220,
      "y": 571,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[10]"
    },
    {
      "t": 43942,
      "e": 33008,
      "ty": 6,
      "x": 220,
      "y": 571,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[9]"
    },
    {
      "t": 43974,
      "e": 33040,
      "ty": 7,
      "x": 135,
      "y": 560,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[9]"
    },
    {
      "t": 43991,
      "e": 33057,
      "ty": 6,
      "x": 115,
      "y": 553,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[5]"
    },
    {
      "t": 44003,
      "e": 33069,
      "ty": 2,
      "x": 115,
      "y": 553
    },
    {
      "t": 44003,
      "e": 33069,
      "ty": 41,
      "x": 19463,
      "y": 60961,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[5]"
    },
    {
      "t": 44104,
      "e": 33170,
      "ty": 2,
      "x": 108,
      "y": 528
    },
    {
      "t": 44108,
      "e": 33174,
      "ty": 7,
      "x": 113,
      "y": 515,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[5]"
    },
    {
      "t": 44108,
      "e": 33174,
      "ty": 6,
      "x": 113,
      "y": 515,
      "ta": "#bigset.starttime+before+endtime+during > ul > li"
    },
    {
      "t": 44203,
      "e": 33269,
      "ty": 2,
      "x": 128,
      "y": 491
    },
    {
      "t": 44253,
      "e": 33319,
      "ty": 41,
      "x": 23821,
      "y": 6348,
      "ta": "#bigset.starttime+before+endtime+during > ul > li"
    },
    {
      "t": 44304,
      "e": 33370,
      "ty": 2,
      "x": 130,
      "y": 490
    },
    {
      "t": 44338,
      "e": 33404,
      "ty": 3,
      "x": 130,
      "y": 490,
      "ta": "#bigset.starttime+before+endtime+during > ul > li"
    },
    {
      "t": 44456,
      "e": 33522,
      "ty": 4,
      "x": 23821,
      "y": 6348,
      "ta": "#bigset.starttime+before+endtime+during > ul > li"
    },
    {
      "t": 44503,
      "e": 33569,
      "ty": 2,
      "x": 131,
      "y": 490
    },
    {
      "t": 44504,
      "e": 33570,
      "ty": 41,
      "x": 24111,
      "y": 6348,
      "ta": "#bigset.starttime+before+endtime+during > ul > li"
    },
    {
      "t": 44604,
      "e": 33670,
      "ty": 2,
      "x": 146,
      "y": 495
    },
    {
      "t": 44703,
      "e": 33769,
      "ty": 2,
      "x": 204,
      "y": 509
    },
    {
      "t": 44753,
      "e": 33819,
      "ty": 41,
      "x": 45318,
      "y": 47854,
      "ta": "#bigset.starttime+before+endtime+during > ul > li"
    },
    {
      "t": 44803,
      "e": 33869,
      "ty": 2,
      "x": 202,
      "y": 509
    },
    {
      "t": 44903,
      "e": 33969,
      "ty": 2,
      "x": 144,
      "y": 494
    },
    {
      "t": 44935,
      "e": 34001,
      "ty": 3,
      "x": 144,
      "y": 494,
      "ta": "#bigset.starttime+before+endtime+during > ul > li"
    },
    {
      "t": 45003,
      "e": 34069,
      "ty": 41,
      "x": 27888,
      "y": 15086,
      "ta": "#bigset.starttime+before+endtime+during > ul > li"
    },
    {
      "t": 45024,
      "e": 34090,
      "ty": 4,
      "x": 27888,
      "y": 15086,
      "ta": "#bigset.starttime+before+endtime+during > ul > li"
    },
    {
      "t": 45204,
      "e": 34270,
      "ty": 2,
      "x": 156,
      "y": 499
    },
    {
      "t": 45253,
      "e": 34270,
      "ty": 41,
      "x": 13055,
      "y": 25906,
      "ta": "#bigset.starttime+before+endtime+during > ul > li > label > div"
    },
    {
      "t": 45304,
      "e": 34321,
      "ty": 2,
      "x": 157,
      "y": 501
    },
    {
      "t": 45360,
      "e": 34377,
      "ty": 3,
      "x": 157,
      "y": 501,
      "ta": "#bigset.starttime+before+endtime+during > ul > li > label > div"
    },
    {
      "t": 45440,
      "e": 34457,
      "ty": 4,
      "x": 13055,
      "y": 25906,
      "ta": "#bigset.starttime+before+endtime+during > ul > li > label > div"
    },
    {
      "t": 45441,
      "e": 34458,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.starttime+before+endtime+during > ul > li > label > input"
    },
    {
      "t": 45445,
      "e": 34462,
      "ty": 5,
      "x": 157,
      "y": 501,
      "ta": "#bigset.starttime+before+endtime+during > ul > li > label > input"
    },
    {
      "t": 45446,
      "e": 34463,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.starttime+before+endtime+during > ul > li > label > input",
      "v": "I"
    },
    {
      "t": 45575,
      "e": 34592,
      "ty": 7,
      "x": 180,
      "y": 528,
      "ta": "#bigset.starttime+before+endtime+during > ul > li"
    },
    {
      "t": 45575,
      "e": 34592,
      "ty": 6,
      "x": 180,
      "y": 528,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[5]"
    },
    {
      "t": 45591,
      "e": 34608,
      "ty": 7,
      "x": 210,
      "y": 563,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[5]"
    },
    {
      "t": 45592,
      "e": 34609,
      "ty": 6,
      "x": 210,
      "y": 563,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[9]"
    },
    {
      "t": 45604,
      "e": 34621,
      "ty": 2,
      "x": 210,
      "y": 563
    },
    {
      "t": 45608,
      "e": 34625,
      "ty": 7,
      "x": 249,
      "y": 605,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[9]"
    },
    {
      "t": 45609,
      "e": 34626,
      "ty": 6,
      "x": 249,
      "y": 605,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[13]"
    },
    {
      "t": 45625,
      "e": 34642,
      "ty": 7,
      "x": 302,
      "y": 654,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[13]"
    },
    {
      "t": 45625,
      "e": 34642,
      "ty": 6,
      "x": 302,
      "y": 654,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[18]"
    },
    {
      "t": 45642,
      "e": 34659,
      "ty": 7,
      "x": 377,
      "y": 723,
      "ta": "#bigset.starttime+before+endtime+during > ul > li:[18]"
    },
    {
      "t": 45704,
      "e": 34721,
      "ty": 2,
      "x": 586,
      "y": 902
    },
    {
      "t": 45754,
      "e": 34771,
      "ty": 41,
      "x": 43914,
      "y": 52627,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 45803,
      "e": 34820,
      "ty": 2,
      "x": 663,
      "y": 962
    },
    {
      "t": 45903,
      "e": 34920,
      "ty": 2,
      "x": 661,
      "y": 925
    },
    {
      "t": 46004,
      "e": 35021,
      "ty": 2,
      "x": 578,
      "y": 803
    },
    {
      "t": 46005,
      "e": 35022,
      "ty": 41,
      "x": 38391,
      "y": 44040,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 46103,
      "e": 35120,
      "ty": 2,
      "x": 550,
      "y": 764
    },
    {
      "t": 46142,
      "e": 35159,
      "ty": 6,
      "x": 536,
      "y": 750,
      "ta": "#testingButton"
    },
    {
      "t": 46203,
      "e": 35220,
      "ty": 2,
      "x": 532,
      "y": 743
    },
    {
      "t": 46225,
      "e": 35242,
      "ty": 3,
      "x": 532,
      "y": 743,
      "ta": "#testingButton"
    },
    {
      "t": 46226,
      "e": 35243,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.starttime+before+endtime+during > ul > li > label > input"
    },
    {
      "t": 46226,
      "e": 35243,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#testingButton"
    },
    {
      "t": 46254,
      "e": 35271,
      "ty": 41,
      "x": 47785,
      "y": 44151,
      "ta": "#testingButton"
    },
    {
      "t": 46368,
      "e": 35385,
      "ty": 4,
      "x": 47785,
      "y": 44151,
      "ta": "#testingButton"
    },
    {
      "t": 46380,
      "e": 35397,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#testingButton"
    },
    {
      "t": 46381,
      "e": 35398,
      "ty": 5,
      "x": 532,
      "y": 743,
      "ta": "#testingButton"
    },
    {
      "t": 46387,
      "e": 35404,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 47396,
      "e": 36413,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2303},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2315},\"parentNode\":{\"id\":2301}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2342},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2344},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2346},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2348},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2350},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2352},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2354},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2356},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2358},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2360},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2362},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2364},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2366},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2368},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2370},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2372},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2374},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2376},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2378},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2380},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2382},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2384},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2386},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2388},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2390},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":1,\"id\":2393,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2392},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2345}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2347}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2349}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2351}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2353}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2355}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2357}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2359}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2361}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2363}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2365}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2367}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2369}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2371}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2373}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2375}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2377}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2379}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2381}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2383}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2385}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2387}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2389}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2391}},{\"nodeType\":3,\"id\":2418,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2393}},{\"nodeType\":1,\"id\":2419,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2343}},{\"nodeType\":3,\"id\":2420,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2419}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2434},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2436},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2438},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2440},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2442},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2444},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2446},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2448},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2450},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2452},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2454},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2456},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2458},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":1,\"id\":2461,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2460},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2462,\"textContent\":\"0\",\"parentNode\":{\"id\":2437}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"1\",\"parentNode\":{\"id\":2439}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"2\",\"parentNode\":{\"id\":2441}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"3\",\"parentNode\":{\"id\":2443}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"4\",\"parentNode\":{\"id\":2445}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"5\",\"parentNode\":{\"id\":2447}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"6\",\"parentNode\":{\"id\":2449}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"7\",\"parentNode\":{\"id\":2451}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"8\",\"parentNode\":{\"id\":2453}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"9\",\"parentNode\":{\"id\":2455}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"10\",\"parentNode\":{\"id\":2457}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"11\",\"parentNode\":{\"id\":2459}},{\"nodeType\":3,\"id\":2474,\"textContent\":\"12\",\"parentNode\":{\"id\":2461}},{\"nodeType\":1,\"id\":2475,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2435}},{\"nodeType\":3,\"id\":2476,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2475}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2477},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2487},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2477}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2488}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2501},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2523},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2541},\"parentNode\":{\"id\":2316}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2543},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2545},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2547},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2549},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2551},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2553},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2555},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2557},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2559},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2561},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2563},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2565},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2567},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2569},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2571},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2573},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2575},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2542}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2577},\"parentNode\":{\"id\":2542}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"A \",\"parentNode\":{\"id\":2544}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"B \",\"parentNode\":{\"id\":2546}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"C \",\"parentNode\":{\"id\":2548}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"D \",\"parentNode\":{\"id\":2550}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"E \",\"parentNode\":{\"id\":2552}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"F \",\"parentNode\":{\"id\":2554}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"G \",\"parentNode\":{\"id\":2556}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"H \",\"parentNode\":{\"id\":2558}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"I \",\"parentNode\":{\"id\":2560}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"J \",\"parentNode\":{\"id\":2562}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"K \",\"parentNode\":{\"id\":2564}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"L \",\"parentNode\":{\"id\":2566}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"M \",\"parentNode\":{\"id\":2568}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"N \",\"parentNode\":{\"id\":2570}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"O \",\"parentNode\":{\"id\":2572}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"P \",\"parentNode\":{\"id\":2574}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"Z \",\"parentNode\":{\"id\":2576}},{\"nodeType\":3,\"id\":2596,\"textContent\":\"X \",\"parentNode\":{\"id\":2578}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":5}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2312},{\"id\":2317},{\"id\":2318},{\"id\":2344},{\"id\":2345},{\"id\":2394},{\"id\":2319},{\"id\":2346},{\"id\":2347},{\"id\":2395},{\"id\":2320},{\"id\":2348},{\"id\":2349},{\"id\":2396},{\"id\":2321},{\"id\":2350},{\"id\":2351},{\"id\":2397},{\"id\":2322},{\"id\":2352},{\"id\":2353},{\"id\":2398},{\"id\":2323},{\"id\":2354},{\"id\":2355},{\"id\":2399},{\"id\":2324},{\"id\":2356},{\"id\":2357},{\"id\":2400},{\"id\":2325},{\"id\":2358},{\"id\":2359},{\"id\":2401},{\"id\":2326},{\"id\":2360},{\"id\":2361},{\"id\":2402},{\"id\":2327},{\"id\":2362},{\"id\":2363},{\"id\":2403},{\"id\":2328},{\"id\":2364},{\"id\":2365},{\"id\":2404},{\"id\":2329},{\"id\":2366},{\"id\":2367},{\"id\":2405},{\"id\":2330},{\"id\":2368},{\"id\":2369},{\"id\":2406},{\"id\":2331},{\"id\":2370},{\"id\":2371},{\"id\":2407},{\"id\":2332},{\"id\":2372},{\"id\":2373},{\"id\":2408},{\"id\":2333},{\"id\":2374},{\"id\":2375},{\"id\":2409},{\"id\":2334},{\"id\":2376},{\"id\":2377},{\"id\":2410},{\"id\":2335},{\"id\":2378},{\"id\":2379},{\"id\":2411},{\"id\":2336},{\"id\":2380},{\"id\":2381},{\"id\":2412},{\"id\":2337},{\"id\":2382},{\"id\":2383},{\"id\":2413},{\"id\":2338},{\"id\":2384},{\"id\":2385},{\"id\":2414},{\"id\":2339},{\"id\":2386},{\"id\":2387},{\"id\":2415},{\"id\":2340},{\"id\":2388},{\"id\":2389},{\"id\":2416},{\"id\":2341},{\"id\":2390},{\"id\":2391},{\"id\":2417},{\"id\":2342},{\"id\":2392},{\"id\":2393},{\"id\":2418},{\"id\":2343},{\"id\":2419},{\"id\":2420},{\"id\":2313},{\"id\":2421},{\"id\":2422},{\"id\":2436},{\"id\":2437},{\"id\":2462},{\"id\":2423},{\"id\":2438},{\"id\":2439},{\"id\":2463},{\"id\":2424},{\"id\":2440},{\"id\":2441},{\"id\":2464},{\"id\":2425},{\"id\":2442},{\"id\":2443},{\"id\":2465},{\"id\":2426},{\"id\":2444},{\"id\":2445},{\"id\":2466},{\"id\":2427},{\"id\":2446},{\"id\":2447},{\"id\":2467},{\"id\":2428},{\"id\":2448},{\"id\":2449},{\"id\":2468},{\"id\":2429},{\"id\":2450},{\"id\":2451},{\"id\":2469},{\"id\":2430},{\"id\":2452},{\"id\":2453},{\"id\":2470},{\"id\":2431},{\"id\":2454},{\"id\":2455},{\"id\":2471},{\"id\":2432},{\"id\":2456},{\"id\":2457},{\"id\":2472},{\"id\":2433},{\"id\":2458},{\"id\":2459},{\"id\":2473},{\"id\":2434},{\"id\":2460},{\"id\":2461},{\"id\":2474},{\"id\":2435},{\"id\":2475},{\"id\":2476},{\"id\":2314},{\"id\":2477},{\"id\":2489},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2488},{\"id\":2500},{\"id\":2315},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2316},{\"id\":2525},{\"id\":2543},{\"id\":2544},{\"id\":2579},{\"id\":2526},{\"id\":2545},{\"id\":2546},{\"id\":2580},{\"id\":2527},{\"id\":2547},{\"id\":2548},{\"id\":2581},{\"id\":2528},{\"id\":2549},{\"id\":2550},{\"id\":2582},{\"id\":2529},{\"id\":2551},{\"id\":2552},{\"id\":2583},{\"id\":2530},{\"id\":2553},{\"id\":2554},{\"id\":2584},{\"id\":2531},{\"id\":2555},{\"id\":2556},{\"id\":2585},{\"id\":2532},{\"id\":2557},{\"id\":2558},{\"id\":2586},{\"id\":2533},{\"id\":2559},{\"id\":2560},{\"id\":2587},{\"id\":2534},{\"id\":2561},{\"id\":2562},{\"id\":2588},{\"id\":2535},{\"id\":2563},{\"id\":2564},{\"id\":2589},{\"id\":2536},{\"id\":2565},{\"id\":2566},{\"id\":2590},{\"id\":2537},{\"id\":2567},{\"id\":2568},{\"id\":2591},{\"id\":2538},{\"id\":2569},{\"id\":2570},{\"id\":2592},{\"id\":2539},{\"id\":2571},{\"id\":2572},{\"id\":2593},{\"id\":2540},{\"id\":2573},{\"id\":2574},{\"id\":2594},{\"id\":2541},{\"id\":2575},{\"id\":2576},{\"id\":2595},{\"id\":2542},{\"id\":2577},{\"id\":2578},{\"id\":2596},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"nodeType\":3,\"id\":2597,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2309},{\"id\":2310},{\"nodeType\":3,\"id\":2598,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2311}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":5,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":6,\"textContent\":\" \"},{\"nodeType\":1,\"id\":7,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":8,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":9,\"textContent\":\" \"},{\"nodeType\":8,\"id\":10},{\"nodeType\":3,\"id\":11,\"textContent\":\" \"},{\"nodeType\":1,\"id\":12,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":13,\"textContent\":\" \"},{\"nodeType\":1,\"id\":14,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":15,\"textContent\":\" \"},{\"nodeType\":1,\"id\":16,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":17,\"textContent\":\" \"},{\"nodeType\":1,\"id\":18,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":19,\"textContent\":\" \"},{\"nodeType\":1,\"id\":20,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":21,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":22,\"textContent\":\" \"},{\"nodeType\":8,\"id\":23},{\"nodeType\":3,\"id\":24,\"textContent\":\" \"},{\"nodeType\":1,\"id\":25,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":26,\"textContent\":\" \"},{\"nodeType\":1,\"id\":27,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":28,\"textContent\":\" \"},{\"nodeType\":1,\"id\":29,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":30,\"textContent\":\" \"},{\"nodeType\":1,\"id\":31,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":32,\"textContent\":\" \"},{\"nodeType\":1,\"id\":33,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":34,\"textContent\":\" \"},{\"nodeType\":1,\"id\":35,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":36,\"textContent\":\" \"},{\"nodeType\":1,\"id\":37,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":38,\"textContent\":\" \"},{\"nodeType\":8,\"id\":39},{\"nodeType\":3,\"id\":40,\"textContent\":\" \"},{\"nodeType\":1,\"id\":41,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":42,\"textContent\":\" \"},{\"nodeType\":8,\"id\":43},{\"nodeType\":3,\"id\":44,\"textContent\":\" \"},{\"nodeType\":8,\"id\":45},{\"nodeType\":3,\"id\":46,\"textContent\":\" \"},{\"nodeType\":1,\"id\":47,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":48,\"textContent\":\" \"},{\"nodeType\":1,\"id\":49,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":50,\"textContent\":\" \"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":52,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":53,\"textContent\":\" \"},{\"nodeType\":8,\"id\":54},{\"nodeType\":3,\"id\":55,\"textContent\":\" \"},{\"nodeType\":1,\"id\":56,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":57,\"textContent\":\" \"},{\"nodeType\":1,\"id\":58,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":59,\"textContent\":\" \"},{\"nodeType\":8,\"id\":60},{\"nodeType\":3,\"id\":61,\"textContent\":\" \"},{\"nodeType\":1,\"id\":62,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":63,\"textContent\":\" \"},{\"nodeType\":1,\"id\":64,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":65,\"textContent\":\" \"},{\"nodeType\":1,\"id\":66,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":67,\"textContent\":\" \"},{\"nodeType\":1,\"id\":68,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":69,\"textContent\":\" \"},{\"nodeType\":1,\"id\":70,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":71,\"textContent\":\" \"},{\"nodeType\":1,\"id\":72,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":73,\"textContent\":\" \"},{\"nodeType\":1,\"id\":74,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":75,\"textContent\":\" \"},{\"nodeType\":1,\"id\":76,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":77,\"textContent\":\"1N65C\"}]},{\"nodeType\":3,\"id\":78,\"textContent\":\" \"},{\"nodeType\":1,\"id\":79,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":80,\"textContent\":\" \"},{\"nodeType\":8,\"id\":81},{\"nodeType\":3,\"id\":82,\"textContent\":\" \"},{\"nodeType\":1,\"id\":83,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":84,\"textContent\":\" \"},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":86,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":88,\"textContent\":\" \"},{\"nodeType\":8,\"id\":89},{\"nodeType\":3,\"id\":90,\"textContent\":\" \"},{\"nodeType\":8,\"id\":91},{\"nodeType\":3,\"id\":92,\"textContent\":\" \"},{\"nodeType\":1,\"id\":93,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":94,\"textContent\":\" \"},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":96,\"textContent\":\" \"},{\"nodeType\":1,\"id\":97,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":98,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":99,\"textContent\":\" \"},{\"nodeType\":1,\"id\":100,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":106,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":114,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":122,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":130,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":138,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":146,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":154,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":162,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":170,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":178,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":186,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":197,\"textContent\":\" \"},{\"nodeType\":1,\"id\":198,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":199,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":200,\"textContent\":\" \"},{\"nodeType\":1,\"id\":201,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":202,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":203,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":205,\"textContent\":\" \"},{\"nodeType\":1,\"id\":206,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":207,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":208,\"textContent\":\" \"},{\"nodeType\":1,\"id\":209,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":210,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":211,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":213,\"textContent\":\" \"},{\"nodeType\":1,\"id\":214,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":215,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":216,\"textContent\":\" \"},{\"nodeType\":1,\"id\":217,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":218,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":219,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":223,\"textContent\":\" \"},{\"nodeType\":1,\"id\":224,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":226,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":227,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":228,\"textContent\":\" \"},{\"nodeType\":1,\"id\":229,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":235,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":243,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":251,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":259,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":267,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":275,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":283,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":291,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":299,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":307,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":315,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":323,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":331,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":339,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":347,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":356,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":364,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":372,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":380,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":388,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":396,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":404,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":412,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":420,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":428,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":444,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":452,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":460,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":468,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":476,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":481,\"textContent\":\" \"},{\"nodeType\":1,\"id\":482,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":483,\"textContent\":\" \"},{\"nodeType\":1,\"id\":484,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":485,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":486,\"textContent\":\" \"},{\"nodeType\":1,\"id\":487,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":488,\"textContent\":\" \"},{\"nodeType\":1,\"id\":489,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":490,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":491,\"textContent\":\" \"},{\"nodeType\":1,\"id\":492,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":493,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":494,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":496,\"textContent\":\" \"},{\"nodeType\":1,\"id\":497,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":498,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":499,\"textContent\":\" \"},{\"nodeType\":1,\"id\":500,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":501,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":502,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":504,\"textContent\":\" \"},{\"nodeType\":1,\"id\":505,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":506,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":508,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":509,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":510,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":517,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":525,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":533,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":541,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":549,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":557,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":565,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":573,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":581,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":589,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":597,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":605,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":610,\"textContent\":\" \"},{\"nodeType\":1,\"id\":611,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":612,\"textContent\":\" \"},{\"nodeType\":1,\"id\":613,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":614,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":615,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":616,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":617,\"textContent\":\" \"},{\"nodeType\":1,\"id\":618,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":620,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":621,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":622,\"textContent\":\" \"},{\"nodeType\":1,\"id\":623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":624,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":625,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":628,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":630,\"textContent\":\" \"},{\"nodeType\":1,\"id\":631,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":632,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":633,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":636,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":638,\"textContent\":\" \"},{\"nodeType\":1,\"id\":639,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":640,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":641,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":644,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":645,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":646,\"textContent\":\" \"},{\"nodeType\":1,\"id\":647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":648,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":649,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":652,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":653,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":654,\"textContent\":\" \"},{\"nodeType\":1,\"id\":655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":656,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":657,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":659,\"textContent\":\" \"},{\"nodeType\":1,\"id\":660,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":662,\"textContent\":\" \"},{\"nodeType\":1,\"id\":663,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":664,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":665,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":667,\"textContent\":\" \"},{\"nodeType\":1,\"id\":668,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":670,\"textContent\":\" \"},{\"nodeType\":1,\"id\":671,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":672,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":673,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":675,\"textContent\":\" \"},{\"nodeType\":1,\"id\":676,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":677,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":678,\"textContent\":\" \"},{\"nodeType\":1,\"id\":679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":680,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":681,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":683,\"textContent\":\" \"},{\"nodeType\":1,\"id\":684,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":685,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":686,\"textContent\":\" \"},{\"nodeType\":1,\"id\":687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":688,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":689,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":691,\"textContent\":\" \"},{\"nodeType\":1,\"id\":692,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":694,\"textContent\":\" \"},{\"nodeType\":1,\"id\":695,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":696,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":697,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":699,\"textContent\":\" \"},{\"nodeType\":1,\"id\":700,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":702,\"textContent\":\" \"},{\"nodeType\":1,\"id\":703,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":704,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":705,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":707,\"textContent\":\" \"},{\"nodeType\":1,\"id\":708,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":710,\"textContent\":\" \"},{\"nodeType\":1,\"id\":711,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":712,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":713,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":715,\"textContent\":\" \"},{\"nodeType\":1,\"id\":716,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":718,\"textContent\":\" \"},{\"nodeType\":1,\"id\":719,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":720,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":723,\"textContent\":\" \"},{\"nodeType\":1,\"id\":724,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":725,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":726,\"textContent\":\" \"},{\"nodeType\":1,\"id\":727,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":728,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":731,\"textContent\":\" \"},{\"nodeType\":1,\"id\":732,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":733,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":734,\"textContent\":\" \"},{\"nodeType\":1,\"id\":735,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":736,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":737,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":741,\"textContent\":\" \"},{\"nodeType\":1,\"id\":742,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":743,\"textContent\":\" \"},{\"nodeType\":1,\"id\":744,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":745,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":746,\"textContent\":\" \"},{\"nodeType\":1,\"id\":747,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":749,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":750,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":751,\"textContent\":\" \"},{\"nodeType\":1,\"id\":752,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":753,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":754,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":757,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":758,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":759,\"textContent\":\" \"},{\"nodeType\":1,\"id\":760,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":761,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":762,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":765,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":766,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":767,\"textContent\":\" \"},{\"nodeType\":1,\"id\":768,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":769,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":770,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":773,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":774,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":775,\"textContent\":\" \"},{\"nodeType\":1,\"id\":776,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":777,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":778,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":781,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":782,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":783,\"textContent\":\" \"},{\"nodeType\":1,\"id\":784,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":785,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":786,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":789,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":790,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":791,\"textContent\":\" \"},{\"nodeType\":1,\"id\":792,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":793,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":794,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":797,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":798,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":799,\"textContent\":\" \"},{\"nodeType\":1,\"id\":800,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":801,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":802,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":805,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":806,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":807,\"textContent\":\" \"},{\"nodeType\":1,\"id\":808,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":809,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":810,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":812,\"textContent\":\" \"},{\"nodeType\":1,\"id\":813,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":814,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":815,\"textContent\":\" \"},{\"nodeType\":1,\"id\":816,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":817,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":818,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":820,\"textContent\":\" \"},{\"nodeType\":1,\"id\":821,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":822,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":823,\"textContent\":\" \"},{\"nodeType\":1,\"id\":824,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":825,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":826,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":828,\"textContent\":\" \"},{\"nodeType\":1,\"id\":829,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":830,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":831,\"textContent\":\" \"},{\"nodeType\":1,\"id\":832,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":833,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":834,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":836,\"textContent\":\" \"},{\"nodeType\":1,\"id\":837,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":838,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":839,\"textContent\":\" \"},{\"nodeType\":1,\"id\":840,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":841,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":842,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":844,\"textContent\":\" \"},{\"nodeType\":1,\"id\":845,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":846,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":847,\"textContent\":\" \"},{\"nodeType\":1,\"id\":848,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":849,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":850,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":852,\"textContent\":\" \"},{\"nodeType\":1,\"id\":853,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":854,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":855,\"textContent\":\" \"},{\"nodeType\":1,\"id\":856,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":857,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":858,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":860,\"textContent\":\" \"},{\"nodeType\":1,\"id\":861,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":862,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":863,\"textContent\":\" \"},{\"nodeType\":1,\"id\":864,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":865,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":866,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":868,\"textContent\":\" \"},{\"nodeType\":1,\"id\":869,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":870,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":871,\"textContent\":\" \"},{\"nodeType\":1,\"id\":872,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":873,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":874,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":876,\"textContent\":\" \"},{\"nodeType\":1,\"id\":877,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":878,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":879,\"textContent\":\" \"},{\"nodeType\":1,\"id\":880,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":881,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":882,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":884,\"textContent\":\" \"},{\"nodeType\":1,\"id\":885,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":886,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":887,\"textContent\":\" \"},{\"nodeType\":1,\"id\":888,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":889,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":890,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":894,\"textContent\":\" \"},{\"nodeType\":1,\"id\":895,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":896,\"textContent\":\" \"},{\"nodeType\":1,\"id\":897,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":898,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":899,\"textContent\":\" \"},{\"nodeType\":1,\"id\":900,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":902,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":903,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":904,\"textContent\":\" \"},{\"nodeType\":1,\"id\":905,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":906,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":907,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":910,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":911,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":912,\"textContent\":\" \"},{\"nodeType\":1,\"id\":913,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":914,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":915,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":918,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":919,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":920,\"textContent\":\" \"},{\"nodeType\":1,\"id\":921,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":922,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":923,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":926,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":927,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":928,\"textContent\":\" \"},{\"nodeType\":1,\"id\":929,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":930,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":931,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":934,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":935,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":936,\"textContent\":\" \"},{\"nodeType\":1,\"id\":937,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":938,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":939,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":942,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":943,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":944,\"textContent\":\" \"},{\"nodeType\":1,\"id\":945,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":946,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":947,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":950,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":951,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":952,\"textContent\":\" \"},{\"nodeType\":1,\"id\":953,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":954,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":955,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":958,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":959,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":960,\"textContent\":\" \"},{\"nodeType\":1,\"id\":961,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":962,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":963,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":965,\"textContent\":\" \"},{\"nodeType\":1,\"id\":966,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":967,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":968,\"textContent\":\" \"},{\"nodeType\":1,\"id\":969,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":970,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":971,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":973,\"textContent\":\" \"},{\"nodeType\":1,\"id\":974,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":975,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":976,\"textContent\":\" \"},{\"nodeType\":1,\"id\":977,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":978,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":979,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":981,\"textContent\":\" \"},{\"nodeType\":1,\"id\":982,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":983,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":984,\"textContent\":\" \"},{\"nodeType\":1,\"id\":985,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":986,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":987,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":989,\"textContent\":\" \"},{\"nodeType\":1,\"id\":990,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":991,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":992,\"textContent\":\" \"},{\"nodeType\":1,\"id\":993,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":994,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":995,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":997,\"textContent\":\" \"},{\"nodeType\":1,\"id\":998,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":999,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1000,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1001,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1002,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1003,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1005,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1006,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1007,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1008,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1009,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1010,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1011,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1013,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1014,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1015,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1016,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1017,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1018,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1019,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1021,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1022,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1023,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1024,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1025,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1026,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1027,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1029,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1030,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1031,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1032,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1033,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1034,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1035,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1037,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1038,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1039,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1040,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1041,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1042,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1043,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1047,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1048,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1049,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1050,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1051,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1052,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1053,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1055,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1056,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1057,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1058,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1059,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1060,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1063,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1064,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1065,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1066,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1067,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1068,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1071,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1072,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1073,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1074,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1075,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1076,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1079,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1080,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1081,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1082,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1083,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1084,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1087,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1088,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1089,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1090,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1091,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1092,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1095,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1096,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1097,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1098,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1099,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1100,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1103,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1104,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1105,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1106,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1107,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1108,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1111,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1112,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1113,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1114,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1115,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1116,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1118,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1119,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1120,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1121,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1122,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1123,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1124,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1131,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1139,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1147,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1155,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1163,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1171,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1179,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1187,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1195,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1200,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1201,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1202,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1203,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1204,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1205,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1206,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1208,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1209,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1210,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1211,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1212,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1213,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1216,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1217,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1218,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1219,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1220,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1221,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1223,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1224,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1225,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1226,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1227,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1228,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1229,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1231,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1232,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1233,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1234,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1235,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1236,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1237,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1239,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1240,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1241,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1242,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1243,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1244,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1245,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1247,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1248,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1249,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1250,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1251,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1252,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1253,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1255,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1256,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1257,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1258,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1259,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1260,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1261,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1263,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1264,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1265,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1266,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1267,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1268,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1269,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1271,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1272,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1273,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1275,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1276,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1277,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1279,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1280,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1281,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1282,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1283,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1284,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1285,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1288,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1289,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1291,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1292,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1293,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1295,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1296,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1297,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1298,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1299,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1300,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1301,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1303,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1304,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1305,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1307,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1308,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1309,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1311,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1312,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1313,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1314,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1315,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1316,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1317,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1319,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1320,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1321,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1322,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1323,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1324,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1325,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1327,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1328,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1329,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1330,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1331,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1332,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1333,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1335,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1336,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1337,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1338,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1339,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1340,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1341,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1343,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1344,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1345,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1346,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1347,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1348,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1349,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1354,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1355,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1356,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1357,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1359,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1360,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1361,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1362,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1363,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1364,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1365,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1366,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1368,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1369,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1370,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1371,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1372,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1373,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1374,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1376,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1377,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1378,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1379,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1380,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1381,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1382,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1384,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1385,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1386,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1387,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1388,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1389,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1390,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1392,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1393,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1394,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1395,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1396,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1397,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1398,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1400,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1401,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1402,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1403,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1404,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1405,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1406,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1408,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1409,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1410,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1411,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1412,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1413,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1414,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1416,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1417,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1418,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1419,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1420,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1421,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1422,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1424,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1425,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1426,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1427,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1428,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1429,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1430,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1432,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1433,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1434,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1435,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1436,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1437,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1438,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1440,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1441,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1442,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1443,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1444,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1445,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1446,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1448,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1449,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1450,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1451,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1452,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1453,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1454,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1456,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1457,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1458,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1459,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1460,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1461,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1462,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1464,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1465,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1466,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1467,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1468,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1469,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1470,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1472,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1473,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1474,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1475,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1476,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1477,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1478,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1481,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1482,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1483,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1484,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1485,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1486,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1488,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1489,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1490,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1491,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1492,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1493,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1494,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1496,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1497,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1498,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1499,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1500,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1501,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1502,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1507,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1508,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1509,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1510,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1512,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1513,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1514,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1515,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1516,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1517,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1518,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1519,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1521,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1522,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1523,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1524,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1525,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1526,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1527,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1529,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1530,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1531,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1532,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1533,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1534,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1535,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1537,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1538,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1539,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1540,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1541,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1542,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1543,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1545,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1546,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1547,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1548,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1549,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1550,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1551,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1553,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1554,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1555,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1556,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1557,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1558,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1559,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1561,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1562,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1563,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1564,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1565,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1566,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1567,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1569,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1570,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1571,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1572,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1573,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1574,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1575,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1577,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1578,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1579,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1580,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1581,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1582,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1583,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1585,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1586,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1587,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1588,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1589,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1590,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1591,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1594,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1595,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1596,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1597,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1598,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1599,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1601,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1602,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1603,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1604,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1605,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1606,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1607,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1610,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1611,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1612,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1613,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1614,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1615,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1617,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1618,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1619,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1620,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1621,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1622,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1623,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1625,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1626,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1627,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1628,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1629,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1630,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1631,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1633,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1634,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1635,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1636,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1637,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1638,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1639,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1641,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1642,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1643,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1644,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1645,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1646,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1647,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1649,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1650,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1651,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1652,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1654,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1655,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1659,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1660,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1662,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1663,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1664,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1665,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1671,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1687,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1695,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1703,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1711,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1719,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1735,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1738,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1739,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1740,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1741,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1742,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1743,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1744,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1746,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1747,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1748,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1749,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1750,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1751,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1752,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1754,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1755,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1756,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1757,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1758,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1759,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1760,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1762,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1763,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1764,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1765,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1766,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1767,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1768,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1770,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1771,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1772,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1773,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1774,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1775,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1776,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1778,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1779,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1780,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1781,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1782,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1783,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1784,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1786,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1787,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1788,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1789,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1790,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1791,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1792,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1794,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1795,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1796,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1797,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1798,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1799,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1800,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1802,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1803,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1804,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1805,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1806,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1807,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1808,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1812,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1813,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1815,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1816,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1817,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1818,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1824,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1832,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1840,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1848,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1856,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1864,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1872,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1880,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1888,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1891,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1892,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1893,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1894,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1895,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1896,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1897,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1899,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1900,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1901,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1902,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1903,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1904,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1905,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1907,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1908,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1909,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1910,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1911,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1912,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1913,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1915,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1916,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1917,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1918,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1919,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1920,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1921,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1923,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1924,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1925,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1926,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1927,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1928,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1929,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1931,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1932,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1933,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1934,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1935,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1936,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1937,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1939,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1940,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1941,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1942,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1943,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1944,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1945,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1947,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1948,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1949,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1950,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1951,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1952,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1953,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1955,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1956,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1957,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1958,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1959,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1960,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1961,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1965,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1966,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1968,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1969,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1970,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1971,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1977,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1985,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1993,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2001,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2009,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2017,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2025,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2033,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2041,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2044,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2045,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2046,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2047,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2048,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2049,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2050,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2052,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2053,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2054,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2055,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2056,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2057,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2058,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2060,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2061,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2062,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2063,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2064,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2065,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2066,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2068,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2069,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2070,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2071,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2072,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2073,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2074,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2076,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2077,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2078,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2079,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2080,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2081,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2082,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2084,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2085,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2086,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2087,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2088,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2089,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2090,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2092,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2093,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2094,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2095,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2096,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2097,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2098,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2105,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2113,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2118,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2119,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2121,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2122,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2123,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2124,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2126,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2128,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2129,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2130,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2131,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2132,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2136,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2137,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2138,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2139,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2140,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2141,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2144,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2145,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2146,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2147,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2148,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2149,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2152,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2153,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2154,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2155,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2156,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2157,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2160,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2161,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2162,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2163,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2164,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2165,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2168,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2169,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2170,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2171,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2172,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2173,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2176,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2177,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2178,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2179,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2180,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2181,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2184,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2185,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2186,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2187,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2188,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2189,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2192,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2193,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2194,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2195,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2196,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2197,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2200,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2201,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2202,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2203,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2204,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2205,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2208,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2209,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2210,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2211,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2212,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2213,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2216,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2217,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2218,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2219,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2220,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2221,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2223,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2224,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2225,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2226,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2227,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2228,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2229,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2231,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2232,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2233,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2234,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2235,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2236,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2237,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2239,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2240,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2241,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2242,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2243,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2244,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2245,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2247,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2248,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2249,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2250,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2251,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2252,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2253,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2255,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2256,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2257,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2258,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2259,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2260,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2261,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2263,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2264,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2265,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2266,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2267,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2268,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2269,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2274,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2275,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2276,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2277,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2279,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2282,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2283},{\"nodeType\":3,\"id\":2284,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2285},{\"nodeType\":3,\"id\":2286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2287,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2289,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2290,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2291,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2292,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2293,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2296,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2297},{\"nodeType\":3,\"id\":2298,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2305,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2306},{\"nodeType\":3,\"id\":2307,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2308,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2310,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2311,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 81, dom: 275, initialDom: 386",
  "javascriptErrors": []
}