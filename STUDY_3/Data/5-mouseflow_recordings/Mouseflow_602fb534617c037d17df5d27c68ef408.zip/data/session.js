var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "602fb534617c037d17df5d27c68ef408",
  "created": "2018-05-21T13:18:12.6207285-07:00",
  "lastActivity": "2018-05-21T13:18:31.3477583-07:00",
  "pageViews": [
    {
      "id": "05211246d9db5c7f058a318d5634547465cee544",
      "startTime": "2018-05-21T13:18:12.9442587-07:00",
      "endTime": "2018-05-21T13:18:31.3477583-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 18525,
      "engagementTime": 18525,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 18525,
  "engagementTime": 18525,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ELUPZ",
    "CONDITION=113",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d49452d956fcfb19c7baf8c0ac62b883",
  "gdpr": false
}