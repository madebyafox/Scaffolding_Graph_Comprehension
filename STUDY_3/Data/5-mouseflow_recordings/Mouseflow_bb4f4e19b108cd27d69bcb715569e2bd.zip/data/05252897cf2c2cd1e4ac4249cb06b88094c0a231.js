var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05252897cf2c2cd1e4ac4249cb06b88094c0a231"] = {
  "startTime": "2018-05-25T18:20:28.1179534Z",
  "websitePageUrl": "/16",
  "visitTime": 97356,
  "engagementTime": 96655,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "bb4f4e19b108cd27d69bcb715569e2bd",
    "created": "2018-05-25T18:20:28.1179534+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=YFWR3",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "4611c8ba0ad920ffec3d4bfa4e565781",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/bb4f4e19b108cd27d69bcb715569e2bd/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 238,
      "e": 238,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 238,
      "e": 238,
      "ty": 1,
      "x": 0,
      "y": 14
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 489,
      "y": 736
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 476,
      "y": 646
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 42592,
      "y": 35343,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1074,
      "e": 1074,
      "ty": 6,
      "x": 487,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 488,
      "y": 601
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 495,
      "y": 580
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 45065,
      "y": 44713,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 500,
      "y": 577
    },
    {
      "t": 1330,
      "e": 1330,
      "ty": 3,
      "x": 500,
      "y": 577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1330,
      "e": 1330,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1418,
      "e": 1418,
      "ty": 4,
      "x": 45290,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1418,
      "e": 1418,
      "ty": 5,
      "x": 500,
      "y": 577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 45290,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 500,
      "y": 576
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 45290,
      "y": 43095,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 516,
      "y": 587
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 47089,
      "y": 51995,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5510,
      "e": 5510,
      "ty": 7,
      "x": 562,
      "y": 616,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 868,
      "y": 757
    },
    {
      "t": 5700,
      "e": 5700,
      "ty": 2,
      "x": 1005,
      "y": 844
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 20577,
      "y": 54433,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 1111,
      "y": 930
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1121,
      "y": 945
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 2,
      "x": 1122,
      "y": 950
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 23678,
      "y": 58157,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6200,
      "e": 6200,
      "ty": 2,
      "x": 1127,
      "y": 955
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 24101,
      "y": 58659,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6300,
      "e": 6300,
      "ty": 2,
      "x": 1137,
      "y": 957
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 1142,
      "y": 952
    },
    {
      "t": 6500,
      "e": 6500,
      "ty": 2,
      "x": 1146,
      "y": 927
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 25369,
      "y": 56510,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1150,
      "y": 862
    },
    {
      "t": 6700,
      "e": 6700,
      "ty": 2,
      "x": 1157,
      "y": 769
    },
    {
      "t": 6752,
      "e": 6752,
      "ty": 41,
      "x": 35711,
      "y": 0,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[2] > text"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 1152,
      "y": 739
    },
    {
      "t": 7000,
      "e": 7000,
      "ty": 2,
      "x": 1152,
      "y": 750
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 41,
      "x": 35711,
      "y": 28086,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[2] > text"
    },
    {
      "t": 7100,
      "e": 7100,
      "ty": 2,
      "x": 1175,
      "y": 862
    },
    {
      "t": 7201,
      "e": 7201,
      "ty": 2,
      "x": 1161,
      "y": 939
    },
    {
      "t": 7250,
      "e": 7250,
      "ty": 41,
      "x": 25862,
      "y": 58730,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7300,
      "e": 7300,
      "ty": 2,
      "x": 1149,
      "y": 965
    },
    {
      "t": 7400,
      "e": 7400,
      "ty": 2,
      "x": 1148,
      "y": 966
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 1003,
      "y": 720
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 15292,
      "y": 41684,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 949,
      "y": 681
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 11416,
      "y": 38819,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 2,
      "x": 945,
      "y": 680
    },
    {
      "t": 7901,
      "e": 7901,
      "ty": 2,
      "x": 918,
      "y": 669
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 2,
      "x": 918,
      "y": 668
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 41,
      "x": 9302,
      "y": 37960,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10736,
      "e": 10736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 10831,
      "e": 10831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 10832,
      "e": 10832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10902,
      "e": 10902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 10951,
      "e": 10951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 11031,
      "e": 11031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11031,
      "e": 11031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11062,
      "e": 11062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 11150,
      "e": 11150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11150,
      "e": 11150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11222,
      "e": 11222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Loo"
    },
    {
      "t": 11311,
      "e": 11311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 11312,
      "e": 11312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11414,
      "e": 11414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 11519,
      "e": 11519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11519,
      "e": 11519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11598,
      "e": 11598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11598,
      "e": 11598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11614,
      "e": 11614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 11654,
      "e": 11654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11654,
      "e": 11654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11718,
      "e": 11718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 11751,
      "e": 11751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11840,
      "e": 11840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11840,
      "e": 11840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11903,
      "e": 11903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 11904,
      "e": 11904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11918,
      "e": 11918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 12006,
      "e": 12006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12030,
      "e": 12030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12031,
      "e": 12031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12086,
      "e": 12086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 12102,
      "e": 12102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12103,
      "e": 12103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12206,
      "e": 12206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12238,
      "e": 12238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 12238,
      "e": 12238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12343,
      "e": 12343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 12503,
      "e": 12503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12613,
      "e": 12613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look atthe "
    },
    {
      "t": 12775,
      "e": 12775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12830,
      "e": 12830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look atthe"
    },
    {
      "t": 12894,
      "e": 12894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12990,
      "e": 12990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look atth"
    },
    {
      "t": 13015,
      "e": 13015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13134,
      "e": 13134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look att"
    },
    {
      "t": 13183,
      "e": 13183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13262,
      "e": 13262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at"
    },
    {
      "t": 13559,
      "e": 13559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13559,
      "e": 13559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13654,
      "e": 13654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14750,
      "e": 14750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14775,
      "e": 14775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at"
    },
    {
      "t": 14806,
      "e": 14806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14821,
      "e": 14821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look a"
    },
    {
      "t": 14846,
      "e": 14846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14926,
      "e": 14926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look "
    },
    {
      "t": 14950,
      "e": 14950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14958,
      "e": 14958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 15022,
      "e": 15022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15095,
      "e": 15095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Loo"
    },
    {
      "t": 15151,
      "e": 15151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15207,
      "e": 15207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 15359,
      "e": 15359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15398,
      "e": 15398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 15494,
      "e": 15494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15550,
      "e": 15550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 15566,
      "e": 15566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15646,
      "e": 15646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 15999,
      "e": 15999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 16085,
      "e": 16085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 16086,
      "e": 16086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16142,
      "e": 16142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 16198,
      "e": 16198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 16199,
      "e": 16199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16199,
      "e": 16199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16254,
      "e": 16254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 16254,
      "e": 16254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16302,
      "e": 16302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fin"
    },
    {
      "t": 16327,
      "e": 16327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 16327,
      "e": 16327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16334,
      "e": 16334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find"
    },
    {
      "t": 16422,
      "e": 16422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16423,
      "e": 16423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16446,
      "e": 16446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16486,
      "e": 16486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16493,
      "e": 16493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16494,
      "e": 16494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16582,
      "e": 16582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16583,
      "e": 16583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16590,
      "e": 16590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 16639,
      "e": 16639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16639,
      "e": 16639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16654,
      "e": 16654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 16735,
      "e": 16735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16766,
      "e": 16766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16767,
      "e": 16767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16861,
      "e": 16861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16910,
      "e": 16910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 16911,
      "e": 16911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16975,
      "e": 16975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 16975,
      "e": 16975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17070,
      "e": 17070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 17110,
      "e": 17110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17270,
      "e": 17270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17327,
      "e": 17327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 17327,
      "e": 17327,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17422,
      "e": 17422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 17455,
      "e": 17455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 17456,
      "e": 17456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17526,
      "e": 17526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 17533,
      "e": 17533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17663,
      "e": 17663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17663,
      "e": 17663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17758,
      "e": 17758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18550,
      "e": 18550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 18552,
      "e": 18552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18630,
      "e": 18630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18630,
      "e": 18630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18646,
      "e": 18646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ma"
    },
    {
      "t": 18726,
      "e": 18726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18726,
      "e": 18726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18766,
      "e": 18766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 18823,
      "e": 18823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18824,
      "e": 18824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 18825,
      "e": 18825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18870,
      "e": 18825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 19003,
      "e": 18958,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark"
    },
    {
      "t": 19382,
      "e": 19337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19383,
      "e": 19338,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19454,
      "e": 19409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19750,
      "e": 19705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19752,
      "e": 19707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19845,
      "e": 19800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19846,
      "e": 19801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19878,
      "e": 19833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 19901,
      "e": 19856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20003,
      "e": 19958,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on"
    },
    {
      "t": 20303,
      "e": 20258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20303,
      "e": 20258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20391,
      "e": 20346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20567,
      "e": 20522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20568,
      "e": 20523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20654,
      "e": 20609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20655,
      "e": 20610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20677,
      "e": 20632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 20734,
      "e": 20689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20774,
      "e": 20729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20774,
      "e": 20729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20854,
      "e": 20809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20854,
      "e": 20809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20878,
      "e": 20833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 20933,
      "e": 20888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21223,
      "e": 21178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 21223,
      "e": 21178,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21302,
      "e": 21257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 21463,
      "e": 21418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21517,
      "e": 21472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the "
    },
    {
      "t": 21606,
      "e": 21561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21702,
      "e": 21657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the"
    },
    {
      "t": 21759,
      "e": 21714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 21760,
      "e": 21715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21790,
      "e": 21745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 21950,
      "e": 21905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21950,
      "e": 21905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22038,
      "e": 21993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22191,
      "e": 22146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22192,
      "e": 22147,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22301,
      "e": 22256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 22487,
      "e": 22442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22558,
      "e": 22513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on thex "
    },
    {
      "t": 22623,
      "e": 22578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22694,
      "e": 22649,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on thex"
    },
    {
      "t": 22782,
      "e": 22737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22838,
      "e": 22793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the"
    },
    {
      "t": 22982,
      "e": 22937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22982,
      "e": 22937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23101,
      "e": 23056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23262,
      "e": 23217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23264,
      "e": 23219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23382,
      "e": 23337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 23550,
      "e": 23505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23630,
      "e": 23585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the "
    },
    {
      "t": 23661,
      "e": 23616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 23661,
      "e": 23616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23767,
      "e": 23722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 23798,
      "e": 23753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23799,
      "e": 23754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23886,
      "e": 23841,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23934,
      "e": 23889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23934,
      "e": 23889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24071,
      "e": 24026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 24103,
      "e": 24058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 24103,
      "e": 24058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24158,
      "e": 24113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 24270,
      "e": 24225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 24270,
      "e": 24225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24367,
      "e": 24322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24370,
      "e": 24325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24389,
      "e": 24344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||xi"
    },
    {
      "t": 24454,
      "e": 24409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24598,
      "e": 24553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24678,
      "e": 24633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x asx"
    },
    {
      "t": 24742,
      "e": 24697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24799,
      "e": 24754,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x as"
    },
    {
      "t": 24902,
      "e": 24857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24950,
      "e": 24905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x a"
    },
    {
      "t": 25023,
      "e": 24978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 25023,
      "e": 24978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25127,
      "e": 25082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 25128,
      "e": 25083,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25134,
      "e": 25089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||xi"
    },
    {
      "t": 25206,
      "e": 25161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25221,
      "e": 25176,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 25222,
      "e": 25177,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25302,
      "e": 25257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 25303,
      "e": 25258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25303,
      "e": 25258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25366,
      "e": 25321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25398,
      "e": 25353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25398,
      "e": 25353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25462,
      "e": 25417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 25463,
      "e": 25418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25486,
      "e": 25441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 25557,
      "e": 25512,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 25557,
      "e": 25512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25565,
      "e": 25520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 25645,
      "e": 25600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25670,
      "e": 25625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25670,
      "e": 25625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25734,
      "e": 25689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25743,
      "e": 25698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25743,
      "e": 25698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25814,
      "e": 25769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25831,
      "e": 25786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25831,
      "e": 25786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25902,
      "e": 25857,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 25934,
      "e": 25889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25934,
      "e": 25889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26006,
      "e": 25961,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 26006,
      "e": 25961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26022,
      "e": 25977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 26101,
      "e": 26056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26202,
      "e": 26157,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then"
    },
    {
      "t": 26294,
      "e": 26249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26295,
      "e": 26250,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26366,
      "e": 26321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26470,
      "e": 26425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 26471,
      "e": 26426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26542,
      "e": 26497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26542,
      "e": 26497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26606,
      "e": 26561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||mo"
    },
    {
      "t": 26613,
      "e": 26568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 26613,
      "e": 26568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26646,
      "e": 26601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 26734,
      "e": 26689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26735,
      "e": 26690,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26758,
      "e": 26713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26758,
      "e": 26713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26766,
      "e": 26721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 26838,
      "e": 26793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26862,
      "e": 26817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27142,
      "e": 27097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27165,
      "e": 27120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move"
    },
    {
      "t": 27415,
      "e": 27370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27415,
      "e": 27370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27502,
      "e": 27457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27646,
      "e": 27601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 27647,
      "e": 27602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27734,
      "e": 27689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 27783,
      "e": 27738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27783,
      "e": 27738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27894,
      "e": 27849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 28183,
      "e": 28138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 28184,
      "e": 28139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28230,
      "e": 28185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 28341,
      "e": 28296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28342,
      "e": 28297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28430,
      "e": 28385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28445,
      "e": 28400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28446,
      "e": 28401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28534,
      "e": 28489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 28558,
      "e": 28513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 28560,
      "e": 28515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28614,
      "e": 28569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28614,
      "e": 28569,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28661,
      "e": 28616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 28694,
      "e": 28649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 28694,
      "e": 28649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28750,
      "e": 28705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 28751,
      "e": 28706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28838,
      "e": 28793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 28840,
      "e": 28795,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28926,
      "e": 28881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 28934,
      "e": 28889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 28934,
      "e": 28889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29006,
      "e": 28961,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29006,
      "e": 28961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29014,
      "e": 28969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 29093,
      "e": 29048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29204,
      "e": 29159,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move vertically "
    },
    {
      "t": 29215,
      "e": 29170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 29215,
      "e": 29170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29301,
      "e": 29256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 29302,
      "e": 29257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29342,
      "e": 29297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||up"
    },
    {
      "t": 29349,
      "e": 29304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29646,
      "e": 29601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 29647,
      "e": 29602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29749,
      "e": 29704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 29814,
      "e": 29769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 29814,
      "e": 29769,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29878,
      "e": 29833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 29879,
      "e": 29834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29942,
      "e": 29897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 29974,
      "e": 29929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30046,
      "e": 30001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 30047,
      "e": 30002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30167,
      "e": 30122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 31399,
      "e": 31354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31400,
      "e": 31355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31493,
      "e": 31448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31613,
      "e": 31568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31614,
      "e": 31569,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31695,
      "e": 31650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31695,
      "e": 31650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31742,
      "e": 31697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 31806,
      "e": 31761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31830,
      "e": 31785,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31830,
      "e": 31785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31926,
      "e": 31881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 31926,
      "e": 31881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31935,
      "e": 31890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| f"
    },
    {
      "t": 31989,
      "e": 31944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32038,
      "e": 31993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32038,
      "e": 31993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32086,
      "e": 31993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32087,
      "e": 31994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32142,
      "e": 32049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 32158,
      "e": 32065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32190,
      "e": 32097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 32191,
      "e": 32098,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32254,
      "e": 32161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32254,
      "e": 32161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32286,
      "e": 32193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 32326,
      "e": 32233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32342,
      "e": 32249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32343,
      "e": 32250,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32431,
      "e": 32338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32432,
      "e": 32339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32446,
      "e": 32353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 32510,
      "e": 32417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32510,
      "e": 32417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32526,
      "e": 32433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 32614,
      "e": 32521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32614,
      "e": 32521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32615,
      "e": 32522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32726,
      "e": 32633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32751,
      "e": 32658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 32751,
      "e": 32658,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32854,
      "e": 32761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 32861,
      "e": 32768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32862,
      "e": 32769,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32934,
      "e": 32841,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32934,
      "e": 32841,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32958,
      "e": 32865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ot"
    },
    {
      "t": 33022,
      "e": 32929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33023,
      "e": 32930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33094,
      "e": 33001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 33150,
      "e": 33057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33150,
      "e": 33057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33157,
      "e": 33064,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33238,
      "e": 33145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33238,
      "e": 33145,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33246,
      "e": 33153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33374,
      "e": 33281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33375,
      "e": 33282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33376,
      "e": 33283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33461,
      "e": 33368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 33461,
      "e": 33368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33485,
      "e": 33392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 33517,
      "e": 33424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33517,
      "e": 33424,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33590,
      "e": 33497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33630,
      "e": 33537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33630,
      "e": 33537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33638,
      "e": 33545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33726,
      "e": 33633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33798,
      "e": 33705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 33799,
      "e": 33706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33911,
      "e": 33818,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 34111,
      "e": 34018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34182,
      "e": 34089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34182,
      "e": 34089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34190,
      "e": 34097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 34190,
      "e": 34097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34222,
      "e": 34129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move vertically upward to find the dots that ar"
    },
    {
      "t": 34270,
      "e": 34177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34270,
      "e": 34177,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34293,
      "e": 34200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 34342,
      "e": 34249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34374,
      "e": 34281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34374,
      "e": 34281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34382,
      "e": 34289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34454,
      "e": 34361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34494,
      "e": 34401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 34494,
      "e": 34401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34603,
      "e": 34510,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move vertically upward to find the dots that are g"
    },
    {
      "t": 34630,
      "e": 34537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 34759,
      "e": 34666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35257,
      "e": 35164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35290,
      "e": 35197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35323,
      "e": 35230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35356,
      "e": 35263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35389,
      "e": 35296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35422,
      "e": 35329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35455,
      "e": 35362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35489,
      "e": 35396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35521,
      "e": 35428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35554,
      "e": 35461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35587,
      "e": 35494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35620,
      "e": 35527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35654,
      "e": 35561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35686,
      "e": 35593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35719,
      "e": 35626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35752,
      "e": 35659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35785,
      "e": 35692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35818,
      "e": 35725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35851,
      "e": 35758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35884,
      "e": 35791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35917,
      "e": 35824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35950,
      "e": 35857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35983,
      "e": 35890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36016,
      "e": 35923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36049,
      "e": 35956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36082,
      "e": 35989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36115,
      "e": 36022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36148,
      "e": 36055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36181,
      "e": 36088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36214,
      "e": 36121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36247,
      "e": 36154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36280,
      "e": 36187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36314,
      "e": 36187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36347,
      "e": 36220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36379,
      "e": 36252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36412,
      "e": 36285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36445,
      "e": 36318,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36461,
      "e": 36334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move vertica"
    },
    {
      "t": 36603,
      "e": 36476,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move vertica"
    },
    {
      "t": 36614,
      "e": 36487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36686,
      "e": 36559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move vertic"
    },
    {
      "t": 36782,
      "e": 36655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36870,
      "e": 36743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move verti"
    },
    {
      "t": 36958,
      "e": 36831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37021,
      "e": 36894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move vert"
    },
    {
      "t": 37118,
      "e": 36991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37182,
      "e": 37055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move ver"
    },
    {
      "t": 37270,
      "e": 37143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37341,
      "e": 37214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move ve"
    },
    {
      "t": 37461,
      "e": 37334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37486,
      "e": 37359,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move v"
    },
    {
      "t": 37603,
      "e": 37476,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move v"
    },
    {
      "t": 37615,
      "e": 37488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 37669,
      "e": 37542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move "
    },
    {
      "t": 37803,
      "e": 37676,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move "
    },
    {
      "t": 37821,
      "e": 37694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 37822,
      "e": 37695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37910,
      "e": 37783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 38142,
      "e": 38015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 38142,
      "e": 38015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38237,
      "e": 38110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 38238,
      "e": 38111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 38238,
      "e": 38111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38326,
      "e": 38199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38326,
      "e": 38199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38342,
      "e": 38215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 38479,
      "e": 38352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 38479,
      "e": 38352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38493,
      "e": 38366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 38550,
      "e": 38423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38655,
      "e": 38528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38655,
      "e": 38528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38750,
      "e": 38623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38751,
      "e": 38624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38758,
      "e": 38631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||tl"
    },
    {
      "t": 38837,
      "e": 38710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38862,
      "e": 38735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 38862,
      "e": 38735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38925,
      "e": 38798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38925,
      "e": 38798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38958,
      "e": 38831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 39014,
      "e": 38887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39125,
      "e": 38998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 39126,
      "e": 38999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39214,
      "e": 39087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 39214,
      "e": 39087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39237,
      "e": 39110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||up"
    },
    {
      "t": 39309,
      "e": 39182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39414,
      "e": 39287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39415,
      "e": 39288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39493,
      "e": 39366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39534,
      "e": 39407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39534,
      "e": 39407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39590,
      "e": 39407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 39591,
      "e": 39408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39621,
      "e": 39438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 39661,
      "e": 39478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39661,
      "e": 39478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39685,
      "e": 39502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39782,
      "e": 39599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40054,
      "e": 39871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 40055,
      "e": 39872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40158,
      "e": 39975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40158,
      "e": 39975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40166,
      "e": 39983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fi"
    },
    {
      "t": 40230,
      "e": 40047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40231,
      "e": 40048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40294,
      "e": 40111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 40326,
      "e": 40143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40350,
      "e": 40167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 40351,
      "e": 40168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40422,
      "e": 40239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 40431,
      "e": 40248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40431,
      "e": 40248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40509,
      "e": 40326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40550,
      "e": 40367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40550,
      "e": 40367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40630,
      "e": 40447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 40630,
      "e": 40447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40646,
      "e": 40463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 40758,
      "e": 40575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41543,
      "e": 41360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41544,
      "e": 41361,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41621,
      "e": 41438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 41637,
      "e": 41454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41638,
      "e": 41455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41741,
      "e": 41558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41749,
      "e": 41566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 41750,
      "e": 41567,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41830,
      "e": 41647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 41831,
      "e": 41648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41846,
      "e": 41663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||do"
    },
    {
      "t": 41934,
      "e": 41751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41950,
      "e": 41767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41950,
      "e": 41767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42030,
      "e": 41847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 42031,
      "e": 41848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42126,
      "e": 41943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 42134,
      "e": 41951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42134,
      "e": 41951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42157,
      "e": 41974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42214,
      "e": 42031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43902,
      "e": 43719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43903,
      "e": 43720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44006,
      "e": 43823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 44045,
      "e": 43862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44046,
      "e": 43863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44134,
      "e": 43951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 44182,
      "e": 43999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 44182,
      "e": 43999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44221,
      "e": 44038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44222,
      "e": 44039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44285,
      "e": 44102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 44358,
      "e": 44175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47278,
      "e": 47095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47279,
      "e": 47096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47365,
      "e": 47182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47422,
      "e": 47239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 47422,
      "e": 47239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47478,
      "e": 47295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 47478,
      "e": 47295,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47550,
      "e": 47367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 47550,
      "e": 47367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47574,
      "e": 47391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||are"
    },
    {
      "t": 47638,
      "e": 47455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47670,
      "e": 47487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47718,
      "e": 47535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47719,
      "e": 47536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47805,
      "e": 47622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 47805,
      "e": 47622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47813,
      "e": 47630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| r"
    },
    {
      "t": 47925,
      "e": 47742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47934,
      "e": 47751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 47934,
      "e": 47751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48014,
      "e": 47831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 48014,
      "e": 47831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48029,
      "e": 47846,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ig"
    },
    {
      "t": 48093,
      "e": 47910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48102,
      "e": 47919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 48102,
      "e": 47919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48158,
      "e": 47975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48158,
      "e": 47975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48181,
      "e": 47998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ht"
    },
    {
      "t": 48262,
      "e": 48079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48269,
      "e": 48086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48270,
      "e": 48087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48326,
      "e": 48143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 48326,
      "e": 48143,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48374,
      "e": 48191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 48424,
      "e": 48241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 48424,
      "e": 48241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48477,
      "e": 48294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 48509,
      "e": 48326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 48509,
      "e": 48326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48517,
      "e": 48334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 48606,
      "e": 48423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48621,
      "e": 48438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 48622,
      "e": 48439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48693,
      "e": 48510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48693,
      "e": 48510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48725,
      "e": 48542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 48765,
      "e": 48582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48765,
      "e": 48582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48798,
      "e": 48615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48830,
      "e": 48647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48862,
      "e": 48679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48862,
      "e": 48679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48950,
      "e": 48767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 48951,
      "e": 48768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48965,
      "e": 48782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 49005,
      "e": 48822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 49006,
      "e": 48823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49054,
      "e": 48871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 49069,
      "e": 48886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 49069,
      "e": 48886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49093,
      "e": 48910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 49165,
      "e": 48982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49167,
      "e": 48984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49174,
      "e": 48991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49261,
      "e": 49078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49269,
      "e": 49086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 49269,
      "e": 49086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49325,
      "e": 49142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 49326,
      "e": 49143,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49381,
      "e": 49198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 49414,
      "e": 49231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49526,
      "e": 49343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 49527,
      "e": 49344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49582,
      "e": 49344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 49582,
      "e": 49344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49645,
      "e": 49407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 49669,
      "e": 49431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49669,
      "e": 49431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 49669,
      "e": 49431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49781,
      "e": 49543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 49810,
      "e": 49572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 49810,
      "e": 49572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49853,
      "e": 49615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 50002,
      "e": 49764,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move directly up to find the dots that are right above this point."
    },
    {
      "t": 50500,
      "e": 50262,
      "ty": 2,
      "x": 1207,
      "y": 480
    },
    {
      "t": 50501,
      "e": 50263,
      "ty": 41,
      "x": 29668,
      "y": 24495,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 50600,
      "e": 50362,
      "ty": 2,
      "x": 691,
      "y": 639
    },
    {
      "t": 50701,
      "e": 50463,
      "ty": 2,
      "x": 648,
      "y": 661
    },
    {
      "t": 50751,
      "e": 50513,
      "ty": 41,
      "x": 61252,
      "y": 36340,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 50800,
      "e": 50562,
      "ty": 2,
      "x": 619,
      "y": 664
    },
    {
      "t": 50900,
      "e": 50662,
      "ty": 2,
      "x": 508,
      "y": 658
    },
    {
      "t": 51000,
      "e": 50762,
      "ty": 2,
      "x": 450,
      "y": 643
    },
    {
      "t": 51001,
      "e": 50763,
      "ty": 41,
      "x": 61512,
      "y": 13936,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 51100,
      "e": 50862,
      "ty": 2,
      "x": 449,
      "y": 643
    },
    {
      "t": 51163,
      "e": 50925,
      "ty": 6,
      "x": 440,
      "y": 658,
      "ta": "#strategyButton"
    },
    {
      "t": 51200,
      "e": 50962,
      "ty": 2,
      "x": 434,
      "y": 662
    },
    {
      "t": 51250,
      "e": 51012,
      "ty": 41,
      "x": 51557,
      "y": 14004,
      "ta": "#strategyButton"
    },
    {
      "t": 51282,
      "e": 51044,
      "ty": 3,
      "x": 433,
      "y": 662,
      "ta": "#strategyButton"
    },
    {
      "t": 51282,
      "e": 51044,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Find the 12PM mark on the x axis and then move directly up to find the dots that are right above this point."
    },
    {
      "t": 51283,
      "e": 51045,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51283,
      "e": 51045,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 51300,
      "e": 51062,
      "ty": 2,
      "x": 433,
      "y": 662
    },
    {
      "t": 51378,
      "e": 51140,
      "ty": 4,
      "x": 51557,
      "y": 14004,
      "ta": "#strategyButton"
    },
    {
      "t": 51388,
      "e": 51150,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 51391,
      "e": 51153,
      "ty": 5,
      "x": 433,
      "y": 662,
      "ta": "#strategyButton"
    },
    {
      "t": 51400,
      "e": 51162,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 51600,
      "e": 51362,
      "ty": 2,
      "x": 410,
      "y": 687
    },
    {
      "t": 51750,
      "e": 51512,
      "ty": 41,
      "x": 13843,
      "y": 37614,
      "ta": "html > body"
    },
    {
      "t": 52398,
      "e": 52160,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 52700,
      "e": 52462,
      "ty": 2,
      "x": 457,
      "y": 692
    },
    {
      "t": 52751,
      "e": 52513,
      "ty": 41,
      "x": 15738,
      "y": 37891,
      "ta": "html > body"
    },
    {
      "t": 52801,
      "e": 52563,
      "ty": 2,
      "x": 523,
      "y": 679
    },
    {
      "t": 52900,
      "e": 52662,
      "ty": 2,
      "x": 704,
      "y": 636
    },
    {
      "t": 53000,
      "e": 52762,
      "ty": 2,
      "x": 759,
      "y": 621
    },
    {
      "t": 53000,
      "e": 52762,
      "ty": 41,
      "x": 25862,
      "y": 33958,
      "ta": "html > body"
    },
    {
      "t": 53400,
      "e": 53162,
      "ty": 2,
      "x": 841,
      "y": 585
    },
    {
      "t": 53500,
      "e": 53262,
      "ty": 2,
      "x": 889,
      "y": 576
    },
    {
      "t": 53500,
      "e": 53262,
      "ty": 41,
      "x": 17519,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 53600,
      "e": 53362,
      "ty": 2,
      "x": 890,
      "y": 575
    },
    {
      "t": 53627,
      "e": 53389,
      "ty": 3,
      "x": 890,
      "y": 575,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 53722,
      "e": 53484,
      "ty": 4,
      "x": 17735,
      "y": 59897,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 53722,
      "e": 53484,
      "ty": 5,
      "x": 890,
      "y": 575,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 53750,
      "e": 53512,
      "ty": 41,
      "x": 17735,
      "y": 59897,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 53811,
      "e": 53573,
      "ty": 6,
      "x": 894,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53900,
      "e": 53662,
      "ty": 2,
      "x": 905,
      "y": 565
    },
    {
      "t": 53906,
      "e": 53668,
      "ty": 3,
      "x": 905,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53906,
      "e": 53668,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53961,
      "e": 53723,
      "ty": 4,
      "x": 20979,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53962,
      "e": 53724,
      "ty": 5,
      "x": 905,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54000,
      "e": 53762,
      "ty": 41,
      "x": 20979,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54682,
      "e": 54444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 54683,
      "e": 54445,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54770,
      "e": 54532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 54771,
      "e": 54533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54818,
      "e": 54580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 54874,
      "e": 54636,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 54970,
      "e": 54732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 54971,
      "e": 54733,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 54971,
      "e": 54733,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 54973,
      "e": 54735,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55097,
      "e": 54859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 55226,
      "e": 54988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 55322,
      "e": 55084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 55323,
      "e": 55085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55404,
      "e": 55166,
      "ty": 2,
      "x": 905,
      "y": 564
    },
    {
      "t": 55417,
      "e": 55179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 55505,
      "e": 55267,
      "ty": 41,
      "x": 20979,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55714,
      "e": 55476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 55850,
      "e": 55612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "190"
    },
    {
      "t": 55851,
      "e": 55613,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55969,
      "e": 55731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U."
    },
    {
      "t": 56170,
      "e": 55932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 56249,
      "e": 56011,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 56353,
      "e": 56115,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 56354,
      "e": 56116,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56425,
      "e": 56187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 56425,
      "e": 56187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56506,
      "e": 56268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 56529,
      "e": 56291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 56534,
      "e": 56296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 56535,
      "e": 56297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56569,
      "e": 56331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 56570,
      "e": 56332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56601,
      "e": 56363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unite"
    },
    {
      "t": 56649,
      "e": 56411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 56745,
      "e": 56507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 56746,
      "e": 56508,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56810,
      "e": 56572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 56842,
      "e": 56604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 56843,
      "e": 56604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56898,
      "e": 56659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 56985,
      "e": 56746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 57026,
      "e": 56787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 57026,
      "e": 56787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57073,
      "e": 56834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 57137,
      "e": 56898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 57137,
      "e": 56898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57177,
      "e": 56938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 57242,
      "e": 57003,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 57250,
      "e": 57011,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 57250,
      "e": 57011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57353,
      "e": 57114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 57354,
      "e": 57115,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57385,
      "e": 57146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||at"
    },
    {
      "t": 57433,
      "e": 57194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 57434,
      "e": 57195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57490,
      "e": 57251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 57521,
      "e": 57282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 57522,
      "e": 57283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57577,
      "e": 57338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 57697,
      "e": 57458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 58090,
      "e": 57851,
      "ty": 7,
      "x": 888,
      "y": 576,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58104,
      "e": 57865,
      "ty": 2,
      "x": 888,
      "y": 576
    },
    {
      "t": 58189,
      "e": 57950,
      "ty": 6,
      "x": 846,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58205,
      "e": 57966,
      "ty": 2,
      "x": 846,
      "y": 647
    },
    {
      "t": 58255,
      "e": 58016,
      "ty": 41,
      "x": 11463,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58304,
      "e": 58065,
      "ty": 2,
      "x": 901,
      "y": 664
    },
    {
      "t": 58405,
      "e": 58166,
      "ty": 2,
      "x": 917,
      "y": 666
    },
    {
      "t": 58405,
      "e": 58166,
      "ty": 7,
      "x": 924,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58439,
      "e": 58200,
      "ty": 6,
      "x": 933,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58505,
      "e": 58266,
      "ty": 2,
      "x": 936,
      "y": 685
    },
    {
      "t": 58505,
      "e": 58266,
      "ty": 41,
      "x": 20655,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58604,
      "e": 58365,
      "ty": 2,
      "x": 940,
      "y": 702
    },
    {
      "t": 58662,
      "e": 58423,
      "ty": 3,
      "x": 940,
      "y": 702,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58664,
      "e": 58425,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 58664,
      "e": 58425,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58664,
      "e": 58425,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58755,
      "e": 58516,
      "ty": 41,
      "x": 22717,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58765,
      "e": 58526,
      "ty": 4,
      "x": 22717,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58765,
      "e": 58526,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58766,
      "e": 58527,
      "ty": 5,
      "x": 940,
      "y": 702,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 58766,
      "e": 58527,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 59405,
      "e": 59166,
      "ty": 2,
      "x": 940,
      "y": 705
    },
    {
      "t": 59505,
      "e": 59266,
      "ty": 2,
      "x": 939,
      "y": 705
    },
    {
      "t": 59505,
      "e": 59266,
      "ty": 41,
      "x": 32061,
      "y": 38611,
      "ta": "html > body"
    },
    {
      "t": 59704,
      "e": 59465,
      "ty": 2,
      "x": 938,
      "y": 707
    },
    {
      "t": 59755,
      "e": 59516,
      "ty": 41,
      "x": 32027,
      "y": 38778,
      "ta": "html > body"
    },
    {
      "t": 59788,
      "e": 59549,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 59805,
      "e": 59566,
      "ty": 2,
      "x": 938,
      "y": 708
    },
    {
      "t": 60504,
      "e": 60265,
      "ty": 2,
      "x": 917,
      "y": 691
    },
    {
      "t": 60505,
      "e": 60266,
      "ty": 41,
      "x": 22683,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 60605,
      "e": 60366,
      "ty": 2,
      "x": 913,
      "y": 330
    },
    {
      "t": 60704,
      "e": 60465,
      "ty": 2,
      "x": 916,
      "y": 309
    },
    {
      "t": 60754,
      "e": 60515,
      "ty": 41,
      "x": 22445,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 60804,
      "e": 60565,
      "ty": 2,
      "x": 915,
      "y": 302
    },
    {
      "t": 60904,
      "e": 60665,
      "ty": 2,
      "x": 894,
      "y": 289
    },
    {
      "t": 61005,
      "e": 60766,
      "ty": 2,
      "x": 871,
      "y": 234
    },
    {
      "t": 61005,
      "e": 60766,
      "ty": 41,
      "x": 40597,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 61104,
      "e": 60865,
      "ty": 2,
      "x": 857,
      "y": 211
    },
    {
      "t": 61204,
      "e": 60965,
      "ty": 2,
      "x": 846,
      "y": 215
    },
    {
      "t": 61254,
      "e": 61015,
      "ty": 41,
      "x": 4883,
      "y": 17005,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 61305,
      "e": 61066,
      "ty": 2,
      "x": 842,
      "y": 220
    },
    {
      "t": 61404,
      "e": 61165,
      "ty": 2,
      "x": 841,
      "y": 223
    },
    {
      "t": 61442,
      "e": 61203,
      "ty": 6,
      "x": 837,
      "y": 232,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 61505,
      "e": 61266,
      "ty": 2,
      "x": 835,
      "y": 234
    },
    {
      "t": 61505,
      "e": 61266,
      "ty": 41,
      "x": 43243,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 61605,
      "e": 61366,
      "ty": 2,
      "x": 834,
      "y": 236
    },
    {
      "t": 61726,
      "e": 61487,
      "ty": 3,
      "x": 834,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 61727,
      "e": 61488,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 61755,
      "e": 61516,
      "ty": 41,
      "x": 38202,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 61837,
      "e": 61598,
      "ty": 4,
      "x": 38202,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 61837,
      "e": 61598,
      "ty": 5,
      "x": 834,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 61837,
      "e": 61598,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 62142,
      "e": 61903,
      "ty": 7,
      "x": 833,
      "y": 246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 62175,
      "e": 61936,
      "ty": 6,
      "x": 832,
      "y": 262,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 62204,
      "e": 61965,
      "ty": 2,
      "x": 832,
      "y": 268
    },
    {
      "t": 62209,
      "e": 61970,
      "ty": 7,
      "x": 832,
      "y": 278,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 62226,
      "e": 61970,
      "ty": 6,
      "x": 836,
      "y": 290,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 62254,
      "e": 61998,
      "ty": 41,
      "x": 53325,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 62259,
      "e": 62003,
      "ty": 7,
      "x": 839,
      "y": 307,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 62304,
      "e": 62048,
      "ty": 2,
      "x": 840,
      "y": 314
    },
    {
      "t": 62505,
      "e": 62249,
      "ty": 41,
      "x": 18442,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 62944,
      "e": 62688,
      "ty": 6,
      "x": 838,
      "y": 317,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 63005,
      "e": 62749,
      "ty": 2,
      "x": 838,
      "y": 318
    },
    {
      "t": 63005,
      "e": 62749,
      "ty": 41,
      "x": 58367,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 63104,
      "e": 62848,
      "ty": 2,
      "x": 838,
      "y": 319
    },
    {
      "t": 63205,
      "e": 62949,
      "ty": 2,
      "x": 837,
      "y": 323
    },
    {
      "t": 63227,
      "e": 62971,
      "ty": 7,
      "x": 834,
      "y": 329,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 63254,
      "e": 62998,
      "ty": 41,
      "x": 10501,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 63304,
      "e": 63048,
      "ty": 2,
      "x": 829,
      "y": 337
    },
    {
      "t": 63505,
      "e": 63249,
      "ty": 41,
      "x": 1798,
      "y": 13151,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 63604,
      "e": 63348,
      "ty": 2,
      "x": 828,
      "y": 344
    },
    {
      "t": 63705,
      "e": 63449,
      "ty": 2,
      "x": 826,
      "y": 345
    },
    {
      "t": 63755,
      "e": 63499,
      "ty": 41,
      "x": 849,
      "y": 14048,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 63805,
      "e": 63549,
      "ty": 2,
      "x": 823,
      "y": 353
    },
    {
      "t": 64005,
      "e": 63749,
      "ty": 41,
      "x": 374,
      "y": 14347,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 64105,
      "e": 63849,
      "ty": 2,
      "x": 817,
      "y": 362
    },
    {
      "t": 64205,
      "e": 63949,
      "ty": 2,
      "x": 816,
      "y": 362
    },
    {
      "t": 64255,
      "e": 63999,
      "ty": 41,
      "x": 27825,
      "y": 19610,
      "ta": "html > body"
    },
    {
      "t": 65205,
      "e": 64949,
      "ty": 2,
      "x": 817,
      "y": 365
    },
    {
      "t": 65255,
      "e": 64999,
      "ty": 41,
      "x": 0,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 65305,
      "e": 65049,
      "ty": 2,
      "x": 821,
      "y": 380
    },
    {
      "t": 65404,
      "e": 65148,
      "ty": 2,
      "x": 827,
      "y": 394
    },
    {
      "t": 65505,
      "e": 65249,
      "ty": 2,
      "x": 827,
      "y": 395
    },
    {
      "t": 65505,
      "e": 65249,
      "ty": 41,
      "x": 1323,
      "y": 10832,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 65805,
      "e": 65549,
      "ty": 2,
      "x": 830,
      "y": 421
    },
    {
      "t": 65813,
      "e": 65557,
      "ty": 6,
      "x": 835,
      "y": 438,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 65845,
      "e": 65589,
      "ty": 7,
      "x": 842,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 65905,
      "e": 65649,
      "ty": 2,
      "x": 842,
      "y": 449
    },
    {
      "t": 66005,
      "e": 65749,
      "ty": 41,
      "x": 16436,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 66105,
      "e": 65849,
      "ty": 2,
      "x": 841,
      "y": 435
    },
    {
      "t": 66255,
      "e": 65999,
      "ty": 41,
      "x": 3934,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 66305,
      "e": 66049,
      "ty": 2,
      "x": 836,
      "y": 428
    },
    {
      "t": 66379,
      "e": 66123,
      "ty": 6,
      "x": 833,
      "y": 419,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 66404,
      "e": 66148,
      "ty": 2,
      "x": 833,
      "y": 419
    },
    {
      "t": 66505,
      "e": 66249,
      "ty": 41,
      "x": 33161,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 66512,
      "e": 66256,
      "ty": 3,
      "x": 833,
      "y": 419,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 66513,
      "e": 66257,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 66513,
      "e": 66257,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 66597,
      "e": 66341,
      "ty": 4,
      "x": 33161,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 66597,
      "e": 66341,
      "ty": 5,
      "x": 833,
      "y": 419,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 66597,
      "e": 66341,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 66918,
      "e": 66662,
      "ty": 7,
      "x": 833,
      "y": 424,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 66997,
      "e": 66741,
      "ty": 6,
      "x": 833,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 67005,
      "e": 66749,
      "ty": 2,
      "x": 833,
      "y": 437
    },
    {
      "t": 67005,
      "e": 66749,
      "ty": 41,
      "x": 33161,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 67105,
      "e": 66849,
      "ty": 2,
      "x": 837,
      "y": 445
    },
    {
      "t": 67112,
      "e": 66856,
      "ty": 7,
      "x": 839,
      "y": 450,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 67204,
      "e": 66948,
      "ty": 2,
      "x": 840,
      "y": 459
    },
    {
      "t": 67255,
      "e": 66948,
      "ty": 41,
      "x": 4409,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 67305,
      "e": 66998,
      "ty": 2,
      "x": 841,
      "y": 459
    },
    {
      "t": 67404,
      "e": 67097,
      "ty": 2,
      "x": 843,
      "y": 477
    },
    {
      "t": 67505,
      "e": 67198,
      "ty": 2,
      "x": 858,
      "y": 534
    },
    {
      "t": 67505,
      "e": 67198,
      "ty": 41,
      "x": 42806,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 67755,
      "e": 67448,
      "ty": 41,
      "x": 8918,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 67805,
      "e": 67498,
      "ty": 2,
      "x": 863,
      "y": 570
    },
    {
      "t": 67904,
      "e": 67597,
      "ty": 2,
      "x": 864,
      "y": 572
    },
    {
      "t": 68005,
      "e": 67698,
      "ty": 41,
      "x": 10104,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 68505,
      "e": 68198,
      "ty": 2,
      "x": 850,
      "y": 608
    },
    {
      "t": 68505,
      "e": 68198,
      "ty": 41,
      "x": 6782,
      "y": 33402,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 68605,
      "e": 68298,
      "ty": 2,
      "x": 845,
      "y": 616
    },
    {
      "t": 68705,
      "e": 68398,
      "ty": 2,
      "x": 844,
      "y": 628
    },
    {
      "t": 68755,
      "e": 68448,
      "ty": 41,
      "x": 5358,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 68805,
      "e": 68498,
      "ty": 2,
      "x": 845,
      "y": 637
    },
    {
      "t": 68905,
      "e": 68598,
      "ty": 2,
      "x": 847,
      "y": 658
    },
    {
      "t": 69005,
      "e": 68698,
      "ty": 2,
      "x": 847,
      "y": 661
    },
    {
      "t": 69005,
      "e": 68698,
      "ty": 41,
      "x": 6070,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 69204,
      "e": 68897,
      "ty": 2,
      "x": 843,
      "y": 669
    },
    {
      "t": 69255,
      "e": 68948,
      "ty": 41,
      "x": 5256,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 69281,
      "e": 68974,
      "ty": 6,
      "x": 839,
      "y": 676,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 69305,
      "e": 68998,
      "ty": 2,
      "x": 838,
      "y": 677
    },
    {
      "t": 69405,
      "e": 69098,
      "ty": 2,
      "x": 838,
      "y": 678
    },
    {
      "t": 69446,
      "e": 69139,
      "ty": 3,
      "x": 838,
      "y": 678,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 69448,
      "e": 69141,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 69448,
      "e": 69141,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 69505,
      "e": 69198,
      "ty": 41,
      "x": 58367,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 69541,
      "e": 69234,
      "ty": 4,
      "x": 58367,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 69541,
      "e": 69234,
      "ty": 5,
      "x": 838,
      "y": 678,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 69541,
      "e": 69234,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 69982,
      "e": 69675,
      "ty": 7,
      "x": 834,
      "y": 690,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 69999,
      "e": 69692,
      "ty": 6,
      "x": 832,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 70005,
      "e": 69698,
      "ty": 2,
      "x": 832,
      "y": 703
    },
    {
      "t": 70005,
      "e": 69698,
      "ty": 41,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 70016,
      "e": 69709,
      "ty": 7,
      "x": 832,
      "y": 715,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 70031,
      "e": 69724,
      "ty": 6,
      "x": 836,
      "y": 730,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 70048,
      "e": 69741,
      "ty": 7,
      "x": 839,
      "y": 747,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 70105,
      "e": 69798,
      "ty": 2,
      "x": 844,
      "y": 780
    },
    {
      "t": 70205,
      "e": 69898,
      "ty": 2,
      "x": 845,
      "y": 786
    },
    {
      "t": 70255,
      "e": 69948,
      "ty": 41,
      "x": 13199,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 70305,
      "e": 69998,
      "ty": 2,
      "x": 845,
      "y": 805
    },
    {
      "t": 70405,
      "e": 70098,
      "ty": 2,
      "x": 845,
      "y": 821
    },
    {
      "t": 70448,
      "e": 70098,
      "ty": 6,
      "x": 839,
      "y": 838,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 70482,
      "e": 70132,
      "ty": 7,
      "x": 832,
      "y": 850,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 70505,
      "e": 70155,
      "ty": 2,
      "x": 831,
      "y": 851
    },
    {
      "t": 70505,
      "e": 70155,
      "ty": 41,
      "x": 6748,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 70605,
      "e": 70255,
      "ty": 2,
      "x": 829,
      "y": 854
    },
    {
      "t": 70705,
      "e": 70355,
      "ty": 2,
      "x": 823,
      "y": 870
    },
    {
      "t": 70755,
      "e": 70405,
      "ty": 41,
      "x": 2035,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 70805,
      "e": 70455,
      "ty": 2,
      "x": 863,
      "y": 949
    },
    {
      "t": 70905,
      "e": 70555,
      "ty": 2,
      "x": 868,
      "y": 958
    },
    {
      "t": 71005,
      "e": 70655,
      "ty": 2,
      "x": 868,
      "y": 962
    },
    {
      "t": 71006,
      "e": 70656,
      "ty": 41,
      "x": 37677,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 71105,
      "e": 70755,
      "ty": 2,
      "x": 863,
      "y": 962
    },
    {
      "t": 71205,
      "e": 70855,
      "ty": 2,
      "x": 854,
      "y": 944
    },
    {
      "t": 71255,
      "e": 70905,
      "ty": 41,
      "x": 31214,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 71305,
      "e": 70955,
      "ty": 2,
      "x": 847,
      "y": 941
    },
    {
      "t": 71405,
      "e": 71055,
      "ty": 2,
      "x": 840,
      "y": 941
    },
    {
      "t": 71505,
      "e": 71155,
      "ty": 2,
      "x": 834,
      "y": 941
    },
    {
      "t": 71505,
      "e": 71155,
      "ty": 41,
      "x": 13738,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 72766,
      "e": 72416,
      "ty": 3,
      "x": 834,
      "y": 941,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 72768,
      "e": 72418,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 72861,
      "e": 72511,
      "ty": 4,
      "x": 13738,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 72861,
      "e": 72511,
      "ty": 5,
      "x": 834,
      "y": 941,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 72861,
      "e": 72511,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 72862,
      "e": 72512,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 73204,
      "e": 72854,
      "ty": 2,
      "x": 834,
      "y": 948
    },
    {
      "t": 73255,
      "e": 72905,
      "ty": 41,
      "x": 12601,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 73304,
      "e": 72954,
      "ty": 2,
      "x": 837,
      "y": 954
    },
    {
      "t": 73622,
      "e": 73272,
      "ty": 6,
      "x": 837,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 73652,
      "e": 73302,
      "ty": 7,
      "x": 841,
      "y": 974,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 73702,
      "e": 73352,
      "ty": 6,
      "x": 862,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 73705,
      "e": 73355,
      "ty": 2,
      "x": 862,
      "y": 1005
    },
    {
      "t": 73754,
      "e": 73404,
      "ty": 41,
      "x": 17305,
      "y": 3971,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 73804,
      "e": 73454,
      "ty": 2,
      "x": 864,
      "y": 1011
    },
    {
      "t": 73904,
      "e": 73554,
      "ty": 2,
      "x": 865,
      "y": 1013
    },
    {
      "t": 73982,
      "e": 73632,
      "ty": 3,
      "x": 865,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 73985,
      "e": 73635,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 73985,
      "e": 73635,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74004,
      "e": 73654,
      "ty": 2,
      "x": 865,
      "y": 1014
    },
    {
      "t": 74004,
      "e": 73654,
      "ty": 41,
      "x": 18336,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74101,
      "e": 73751,
      "ty": 4,
      "x": 18851,
      "y": 19859,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74101,
      "e": 73751,
      "ty": 5,
      "x": 866,
      "y": 1015,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74104,
      "e": 73754,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 74104,
      "e": 73754,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 74106,
      "e": 73756,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 74108,
      "e": 73758,
      "ty": 2,
      "x": 866,
      "y": 1015
    },
    {
      "t": 74254,
      "e": 73904,
      "ty": 41,
      "x": 29547,
      "y": 55785,
      "ta": "html > body"
    },
    {
      "t": 74905,
      "e": 74555,
      "ty": 2,
      "x": 869,
      "y": 1013
    },
    {
      "t": 75004,
      "e": 74654,
      "ty": 2,
      "x": 870,
      "y": 1011
    },
    {
      "t": 75005,
      "e": 74655,
      "ty": 41,
      "x": 29685,
      "y": 55563,
      "ta": "html > body"
    },
    {
      "t": 75305,
      "e": 74955,
      "ty": 2,
      "x": 872,
      "y": 1008
    },
    {
      "t": 75434,
      "e": 75084,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 75504,
      "e": 75154,
      "ty": 2,
      "x": 874,
      "y": 1004
    },
    {
      "t": 75504,
      "e": 75154,
      "ty": 41,
      "x": 28561,
      "y": 60778,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 75604,
      "e": 75254,
      "ty": 2,
      "x": 875,
      "y": 1002
    },
    {
      "t": 75754,
      "e": 75404,
      "ty": 41,
      "x": 28610,
      "y": 60640,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 75904,
      "e": 75554,
      "ty": 2,
      "x": 884,
      "y": 997
    },
    {
      "t": 76004,
      "e": 75654,
      "ty": 2,
      "x": 902,
      "y": 1012
    },
    {
      "t": 76005,
      "e": 75655,
      "ty": 41,
      "x": 29938,
      "y": 61332,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76104,
      "e": 75754,
      "ty": 2,
      "x": 906,
      "y": 1020
    },
    {
      "t": 76206,
      "e": 75756,
      "ty": 2,
      "x": 902,
      "y": 1025
    },
    {
      "t": 76254,
      "e": 75804,
      "ty": 41,
      "x": 29840,
      "y": 62302,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76304,
      "e": 75854,
      "ty": 2,
      "x": 898,
      "y": 1028
    },
    {
      "t": 76404,
      "e": 75954,
      "ty": 2,
      "x": 897,
      "y": 1036
    },
    {
      "t": 76504,
      "e": 76054,
      "ty": 2,
      "x": 897,
      "y": 1041
    },
    {
      "t": 76504,
      "e": 76054,
      "ty": 41,
      "x": 29692,
      "y": 63340,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76605,
      "e": 76155,
      "ty": 2,
      "x": 907,
      "y": 1051
    },
    {
      "t": 76704,
      "e": 76254,
      "ty": 2,
      "x": 915,
      "y": 1057
    },
    {
      "t": 76755,
      "e": 76305,
      "ty": 41,
      "x": 30725,
      "y": 64587,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76804,
      "e": 76354,
      "ty": 2,
      "x": 923,
      "y": 1062
    },
    {
      "t": 76904,
      "e": 76454,
      "ty": 2,
      "x": 928,
      "y": 1064
    },
    {
      "t": 77004,
      "e": 76554,
      "ty": 2,
      "x": 930,
      "y": 1064
    },
    {
      "t": 77005,
      "e": 76555,
      "ty": 41,
      "x": 31316,
      "y": 64933,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 77304,
      "e": 76854,
      "ty": 2,
      "x": 933,
      "y": 1064
    },
    {
      "t": 77404,
      "e": 76954,
      "ty": 2,
      "x": 939,
      "y": 1063
    },
    {
      "t": 77504,
      "e": 77054,
      "ty": 2,
      "x": 940,
      "y": 1062
    },
    {
      "t": 77504,
      "e": 77054,
      "ty": 41,
      "x": 31808,
      "y": 64794,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 82755,
      "e": 82054,
      "ty": 41,
      "x": 31808,
      "y": 64864,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 82804,
      "e": 82103,
      "ty": 2,
      "x": 940,
      "y": 1063
    },
    {
      "t": 86004,
      "e": 85303,
      "ty": 2,
      "x": 946,
      "y": 1057
    },
    {
      "t": 86005,
      "e": 85304,
      "ty": 41,
      "x": 32103,
      "y": 64448,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86105,
      "e": 85404,
      "ty": 2,
      "x": 950,
      "y": 1053
    },
    {
      "t": 86255,
      "e": 85554,
      "ty": 41,
      "x": 32300,
      "y": 64171,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86905,
      "e": 86204,
      "ty": 2,
      "x": 951,
      "y": 1053
    },
    {
      "t": 87006,
      "e": 86305,
      "ty": 41,
      "x": 32349,
      "y": 64171,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 87105,
      "e": 86404,
      "ty": 2,
      "x": 952,
      "y": 1054
    },
    {
      "t": 87255,
      "e": 86554,
      "ty": 41,
      "x": 32398,
      "y": 64240,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 89005,
      "e": 88304,
      "ty": 2,
      "x": 953,
      "y": 1062
    },
    {
      "t": 89005,
      "e": 88304,
      "ty": 41,
      "x": 32447,
      "y": 64794,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 89105,
      "e": 88404,
      "ty": 2,
      "x": 953,
      "y": 1063
    },
    {
      "t": 89205,
      "e": 88504,
      "ty": 2,
      "x": 953,
      "y": 1065
    },
    {
      "t": 89256,
      "e": 88555,
      "ty": 41,
      "x": 32447,
      "y": 65002,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 89304,
      "e": 88603,
      "ty": 2,
      "x": 953,
      "y": 1066
    },
    {
      "t": 89404,
      "e": 88703,
      "ty": 2,
      "x": 952,
      "y": 1067
    },
    {
      "t": 89504,
      "e": 88803,
      "ty": 2,
      "x": 951,
      "y": 1069
    },
    {
      "t": 89505,
      "e": 88804,
      "ty": 41,
      "x": 32349,
      "y": 65279,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 89598,
      "e": 88897,
      "ty": 6,
      "x": 949,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 89605,
      "e": 88904,
      "ty": 2,
      "x": 949,
      "y": 1072
    },
    {
      "t": 89705,
      "e": 89004,
      "ty": 2,
      "x": 948,
      "y": 1073
    },
    {
      "t": 89755,
      "e": 89054,
      "ty": 41,
      "x": 21025,
      "y": 2529,
      "ta": "#start"
    },
    {
      "t": 89805,
      "e": 89104,
      "ty": 2,
      "x": 948,
      "y": 1074
    },
    {
      "t": 89905,
      "e": 89204,
      "ty": 2,
      "x": 948,
      "y": 1075
    },
    {
      "t": 90005,
      "e": 89304,
      "ty": 2,
      "x": 948,
      "y": 1077
    },
    {
      "t": 90006,
      "e": 89305,
      "ty": 41,
      "x": 21025,
      "y": 8312,
      "ta": "#start"
    },
    {
      "t": 90006,
      "e": 89305,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90405,
      "e": 89704,
      "ty": 2,
      "x": 948,
      "y": 1078
    },
    {
      "t": 90505,
      "e": 89804,
      "ty": 2,
      "x": 961,
      "y": 1072
    },
    {
      "t": 90505,
      "e": 89804,
      "ty": 41,
      "x": 28125,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 90532,
      "e": 89831,
      "ty": 7,
      "x": 964,
      "y": 1071,
      "ta": "#start"
    },
    {
      "t": 90605,
      "e": 89904,
      "ty": 2,
      "x": 968,
      "y": 1068
    },
    {
      "t": 90705,
      "e": 90004,
      "ty": 2,
      "x": 970,
      "y": 1067
    },
    {
      "t": 90755,
      "e": 90054,
      "ty": 41,
      "x": 33333,
      "y": 65141,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 90805,
      "e": 90104,
      "ty": 2,
      "x": 971,
      "y": 1067
    },
    {
      "t": 93604,
      "e": 92903,
      "ty": 2,
      "x": 970,
      "y": 1067
    },
    {
      "t": 93705,
      "e": 93004,
      "ty": 2,
      "x": 969,
      "y": 1067
    },
    {
      "t": 93755,
      "e": 93054,
      "ty": 41,
      "x": 33234,
      "y": 65141,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 93805,
      "e": 93104,
      "ty": 2,
      "x": 966,
      "y": 1067
    },
    {
      "t": 93905,
      "e": 93204,
      "ty": 2,
      "x": 961,
      "y": 1070
    },
    {
      "t": 94005,
      "e": 93304,
      "ty": 2,
      "x": 960,
      "y": 1070
    },
    {
      "t": 94005,
      "e": 93304,
      "ty": 41,
      "x": 32792,
      "y": 65348,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94095,
      "e": 93394,
      "ty": 6,
      "x": 960,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 94105,
      "e": 93404,
      "ty": 2,
      "x": 960,
      "y": 1072
    },
    {
      "t": 94205,
      "e": 93504,
      "ty": 2,
      "x": 958,
      "y": 1073
    },
    {
      "t": 94255,
      "e": 93554,
      "ty": 41,
      "x": 26487,
      "y": 602,
      "ta": "#start"
    },
    {
      "t": 94526,
      "e": 93825,
      "ty": 3,
      "x": 958,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 94527,
      "e": 93826,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 94628,
      "e": 93927,
      "ty": 4,
      "x": 26487,
      "y": 602,
      "ta": "#start"
    },
    {
      "t": 94629,
      "e": 93928,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 94630,
      "e": 93929,
      "ty": 5,
      "x": 958,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 94630,
      "e": 93929,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 95675,
      "e": 94974,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 97257,
      "e": 96556,
      "ty": 41,
      "x": 32686,
      "y": 32860,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 97306,
      "e": 96605,
      "ty": 2,
      "x": 938,
      "y": 1073
    },
    {
      "t": 97356,
      "e": 96655,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 120175, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 120180, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 4211, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 125726, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 32289, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"NOVEMBER\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 159022, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 5743, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 165848, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 5527, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 172377, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 44259, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 217990, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-8\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1262,y:180,t:1527271757119};\\\", \\\"{x:1253,y:187,t:1527271757127};\\\", \\\"{x:1240,y:195,t:1527271757138};\\\", \\\"{x:1215,y:216,t:1527271757155};\\\", \\\"{x:1194,y:240,t:1527271757171};\\\", \\\"{x:1188,y:247,t:1527271757188};\\\", \\\"{x:1178,y:257,t:1527271757205};\\\", \\\"{x:1172,y:265,t:1527271757221};\\\", \\\"{x:1166,y:272,t:1527271757238};\\\", \\\"{x:1155,y:281,t:1527271757255};\\\", \\\"{x:1140,y:294,t:1527271757271};\\\", \\\"{x:1127,y:306,t:1527271757288};\\\", \\\"{x:1124,y:310,t:1527271757305};\\\", \\\"{x:1109,y:323,t:1527271757321};\\\", \\\"{x:1091,y:337,t:1527271757338};\\\", \\\"{x:1074,y:352,t:1527271757355};\\\", \\\"{x:1065,y:357,t:1527271757370};\\\", \\\"{x:1053,y:363,t:1527271757387};\\\", \\\"{x:1043,y:368,t:1527271757405};\\\", \\\"{x:1042,y:368,t:1527271757422};\\\", \\\"{x:1042,y:370,t:1527271759399};\\\", \\\"{x:1042,y:371,t:1527271759407};\\\", \\\"{x:1044,y:378,t:1527271759423};\\\", \\\"{x:1049,y:387,t:1527271759440};\\\", \\\"{x:1053,y:400,t:1527271759456};\\\", \\\"{x:1054,y:412,t:1527271759473};\\\", \\\"{x:1056,y:422,t:1527271759489};\\\", \\\"{x:1056,y:430,t:1527271759505};\\\", \\\"{x:1056,y:440,t:1527271759522};\\\", \\\"{x:1048,y:453,t:1527271759539};\\\", \\\"{x:1035,y:467,t:1527271759556};\\\", \\\"{x:1005,y:495,t:1527271759572};\\\", \\\"{x:946,y:540,t:1527271759589};\\\", \\\"{x:908,y:574,t:1527271759607};\\\", \\\"{x:871,y:602,t:1527271759623};\\\", \\\"{x:842,y:626,t:1527271759639};\\\", \\\"{x:787,y:659,t:1527271759655};\\\", \\\"{x:744,y:680,t:1527271759673};\\\", \\\"{x:711,y:695,t:1527271759690};\\\", \\\"{x:683,y:710,t:1527271759707};\\\", \\\"{x:663,y:718,t:1527271759722};\\\", \\\"{x:662,y:719,t:1527271759739};\\\", \\\"{x:667,y:720,t:1527271759798};\\\", \\\"{x:669,y:720,t:1527271759806};\\\", \\\"{x:678,y:718,t:1527271759822};\\\", \\\"{x:682,y:718,t:1527271759840};\\\", \\\"{x:684,y:718,t:1527271759856};\\\", \\\"{x:684,y:717,t:1527271760391};\\\", \\\"{x:685,y:715,t:1527271760431};\\\", \\\"{x:686,y:714,t:1527271760463};\\\", \\\"{x:689,y:713,t:1527271760495};\\\", \\\"{x:689,y:712,t:1527271760519};\\\", \\\"{x:691,y:711,t:1527271760535};\\\", \\\"{x:696,y:712,t:1527271760559};\\\", \\\"{x:699,y:721,t:1527271760575};\\\", \\\"{x:702,y:724,t:1527271760591};\\\", \\\"{x:792,y:754,t:1527271760607};\\\", \\\"{x:878,y:779,t:1527271760624};\\\", \\\"{x:932,y:798,t:1527271760641};\\\", \\\"{x:980,y:819,t:1527271760657};\\\", \\\"{x:1007,y:833,t:1527271760674};\\\", \\\"{x:1032,y:841,t:1527271760691};\\\", \\\"{x:1056,y:853,t:1527271760707};\\\", \\\"{x:1074,y:861,t:1527271760724};\\\", \\\"{x:1079,y:865,t:1527271760741};\\\", \\\"{x:1082,y:871,t:1527271760757};\\\", \\\"{x:1085,y:871,t:1527271760775};\\\", \\\"{x:1086,y:872,t:1527271760888};\\\", \\\"{x:1086,y:873,t:1527271760893};\\\", \\\"{x:1089,y:876,t:1527271760926};\\\", \\\"{x:1091,y:878,t:1527271760941};\\\", \\\"{x:1092,y:879,t:1527271760956};\\\", \\\"{x:1093,y:881,t:1527271760973};\\\", \\\"{x:1094,y:887,t:1527271760990};\\\", \\\"{x:1094,y:889,t:1527271761006};\\\", \\\"{x:1096,y:893,t:1527271761023};\\\", \\\"{x:1096,y:894,t:1527271761046};\\\", \\\"{x:1096,y:895,t:1527271761135};\\\", \\\"{x:1097,y:895,t:1527271761143};\\\", \\\"{x:1099,y:896,t:1527271761159};\\\", \\\"{x:1100,y:896,t:1527271761174};\\\", \\\"{x:1107,y:899,t:1527271761191};\\\", \\\"{x:1112,y:902,t:1527271761209};\\\", \\\"{x:1123,y:908,t:1527271761225};\\\", \\\"{x:1129,y:913,t:1527271761241};\\\", \\\"{x:1130,y:916,t:1527271761258};\\\", \\\"{x:1132,y:918,t:1527271761275};\\\", \\\"{x:1132,y:919,t:1527271761375};\\\", \\\"{x:1133,y:919,t:1527271762813};\\\", \\\"{x:1135,y:919,t:1527271762822};\\\", \\\"{x:1138,y:918,t:1527271762840};\\\", \\\"{x:1143,y:915,t:1527271762857};\\\", \\\"{x:1149,y:909,t:1527271762873};\\\", \\\"{x:1153,y:906,t:1527271762890};\\\", \\\"{x:1155,y:902,t:1527271762906};\\\", \\\"{x:1157,y:895,t:1527271762922};\\\", \\\"{x:1161,y:891,t:1527271762940};\\\", \\\"{x:1166,y:885,t:1527271762956};\\\", \\\"{x:1167,y:883,t:1527271762972};\\\", \\\"{x:1171,y:879,t:1527271762990};\\\", \\\"{x:1174,y:876,t:1527271763006};\\\", \\\"{x:1179,y:875,t:1527271763023};\\\", \\\"{x:1183,y:872,t:1527271763040};\\\", \\\"{x:1186,y:871,t:1527271763056};\\\", \\\"{x:1189,y:871,t:1527271763074};\\\", \\\"{x:1190,y:871,t:1527271763090};\\\", \\\"{x:1193,y:871,t:1527271763106};\\\", \\\"{x:1195,y:873,t:1527271763122};\\\", \\\"{x:1204,y:877,t:1527271763139};\\\", \\\"{x:1209,y:880,t:1527271763156};\\\", \\\"{x:1213,y:884,t:1527271763173};\\\", \\\"{x:1217,y:885,t:1527271763189};\\\", \\\"{x:1220,y:886,t:1527271763206};\\\", \\\"{x:1223,y:888,t:1527271763251};\\\", \\\"{x:1223,y:889,t:1527271763307};\\\", \\\"{x:1224,y:891,t:1527271763324};\\\", \\\"{x:1225,y:893,t:1527271763339};\\\", \\\"{x:1227,y:893,t:1527271763356};\\\", \\\"{x:1228,y:893,t:1527271763412};\\\", \\\"{x:1228,y:894,t:1527271763436};\\\", \\\"{x:1228,y:895,t:1527271763444};\\\", \\\"{x:1228,y:897,t:1527271763457};\\\", \\\"{x:1228,y:900,t:1527271763473};\\\", \\\"{x:1226,y:905,t:1527271763490};\\\", \\\"{x:1224,y:907,t:1527271763506};\\\", \\\"{x:1222,y:909,t:1527271763523};\\\", \\\"{x:1222,y:910,t:1527271763540};\\\", \\\"{x:1222,y:911,t:1527271763629};\\\", \\\"{x:1222,y:912,t:1527271763640};\\\", \\\"{x:1222,y:914,t:1527271763656};\\\", \\\"{x:1222,y:915,t:1527271763684};\\\", \\\"{x:1222,y:917,t:1527271763725};\\\", \\\"{x:1219,y:917,t:1527271763788};\\\", \\\"{x:1210,y:916,t:1527271763796};\\\", \\\"{x:1203,y:910,t:1527271763807};\\\", \\\"{x:1158,y:889,t:1527271763824};\\\", \\\"{x:1097,y:871,t:1527271763841};\\\", \\\"{x:1092,y:864,t:1527271763857};\\\", \\\"{x:1073,y:856,t:1527271763873};\\\", \\\"{x:1061,y:842,t:1527271763890};\\\", \\\"{x:1043,y:830,t:1527271763906};\\\", \\\"{x:1023,y:814,t:1527271763923};\\\", \\\"{x:1012,y:804,t:1527271763940};\\\", \\\"{x:1000,y:798,t:1527271763956};\\\", \\\"{x:987,y:792,t:1527271763973};\\\", \\\"{x:978,y:789,t:1527271763990};\\\", \\\"{x:974,y:785,t:1527271764007};\\\", \\\"{x:961,y:780,t:1527271764023};\\\", \\\"{x:951,y:777,t:1527271764040};\\\", \\\"{x:946,y:774,t:1527271764057};\\\", \\\"{x:899,y:765,t:1527271764073};\\\", \\\"{x:814,y:746,t:1527271764090};\\\", \\\"{x:691,y:708,t:1527271764107};\\\", \\\"{x:648,y:691,t:1527271764123};\\\", \\\"{x:633,y:680,t:1527271764140};\\\", \\\"{x:615,y:667,t:1527271764158};\\\", \\\"{x:605,y:655,t:1527271764173};\\\", \\\"{x:593,y:645,t:1527271764191};\\\", \\\"{x:589,y:641,t:1527271764207};\\\", \\\"{x:585,y:635,t:1527271764223};\\\", \\\"{x:581,y:626,t:1527271764240};\\\", \\\"{x:580,y:625,t:1527271764256};\\\", \\\"{x:572,y:614,t:1527271764274};\\\", \\\"{x:552,y:587,t:1527271764291};\\\", \\\"{x:544,y:581,t:1527271764307};\\\", \\\"{x:535,y:573,t:1527271764325};\\\", \\\"{x:529,y:567,t:1527271764341};\\\", \\\"{x:519,y:557,t:1527271764356};\\\", \\\"{x:510,y:550,t:1527271764374};\\\", \\\"{x:507,y:547,t:1527271764390};\\\", \\\"{x:491,y:533,t:1527271764408};\\\", \\\"{x:470,y:518,t:1527271764424};\\\", \\\"{x:456,y:510,t:1527271764441};\\\", \\\"{x:451,y:503,t:1527271764459};\\\", \\\"{x:434,y:501,t:1527271764474};\\\", \\\"{x:424,y:501,t:1527271764491};\\\", \\\"{x:422,y:501,t:1527271764507};\\\", \\\"{x:421,y:501,t:1527271764524};\\\", \\\"{x:420,y:501,t:1527271764541};\\\", \\\"{x:419,y:502,t:1527271764557};\\\", \\\"{x:417,y:503,t:1527271764574};\\\", \\\"{x:416,y:503,t:1527271764591};\\\", \\\"{x:416,y:505,t:1527271764607};\\\", \\\"{x:413,y:508,t:1527271764625};\\\", \\\"{x:412,y:510,t:1527271764641};\\\", \\\"{x:405,y:514,t:1527271764658};\\\", \\\"{x:402,y:518,t:1527271764674};\\\", \\\"{x:394,y:523,t:1527271764692};\\\", \\\"{x:388,y:526,t:1527271764707};\\\", \\\"{x:387,y:528,t:1527271764724};\\\", \\\"{x:384,y:531,t:1527271764744};\\\", \\\"{x:383,y:531,t:1527271764758};\\\", \\\"{x:381,y:533,t:1527271764774};\\\", \\\"{x:381,y:534,t:1527271765403};\\\", \\\"{x:381,y:532,t:1527271765532};\\\", \\\"{x:381,y:531,t:1527271765555};\\\", \\\"{x:381,y:529,t:1527271765579};\\\", \\\"{x:381,y:528,t:1527271765595};\\\", \\\"{x:382,y:526,t:1527271765611};\\\", \\\"{x:382,y:525,t:1527271765625};\\\", \\\"{x:382,y:522,t:1527271765641};\\\", \\\"{x:382,y:520,t:1527271765658};\\\", \\\"{x:382,y:516,t:1527271765675};\\\", \\\"{x:382,y:515,t:1527271765691};\\\", \\\"{x:384,y:514,t:1527271765708};\\\", \\\"{x:384,y:513,t:1527271765725};\\\", \\\"{x:385,y:513,t:1527271766148};\\\", \\\"{x:387,y:513,t:1527271766163};\\\", \\\"{x:390,y:516,t:1527271766175};\\\", \\\"{x:393,y:520,t:1527271766192};\\\", \\\"{x:394,y:527,t:1527271766208};\\\", \\\"{x:404,y:537,t:1527271766225};\\\", \\\"{x:407,y:543,t:1527271766242};\\\", \\\"{x:424,y:561,t:1527271766259};\\\", \\\"{x:433,y:571,t:1527271766274};\\\", \\\"{x:442,y:585,t:1527271766293};\\\", \\\"{x:447,y:592,t:1527271766309};\\\", \\\"{x:456,y:604,t:1527271766325};\\\", \\\"{x:457,y:607,t:1527271766342};\\\", \\\"{x:460,y:610,t:1527271766359};\\\", \\\"{x:460,y:614,t:1527271766375};\\\", \\\"{x:460,y:617,t:1527271766403};\\\", \\\"{x:461,y:621,t:1527271766412};\\\", \\\"{x:461,y:624,t:1527271766426};\\\", \\\"{x:462,y:635,t:1527271766442};\\\", \\\"{x:462,y:647,t:1527271766459};\\\", \\\"{x:462,y:652,t:1527271766476};\\\", \\\"{x:462,y:655,t:1527271766492};\\\", \\\"{x:462,y:656,t:1527271766509};\\\", \\\"{x:462,y:657,t:1527271766587};\\\", \\\"{x:462,y:658,t:1527271766603};\\\", \\\"{x:462,y:659,t:1527271766619};\\\", \\\"{x:462,y:660,t:1527271766627};\\\", \\\"{x:464,y:661,t:1527271766642};\\\", \\\"{x:465,y:663,t:1527271766659};\\\", \\\"{x:465,y:664,t:1527271766676};\\\", \\\"{x:467,y:668,t:1527271766692};\\\", \\\"{x:469,y:672,t:1527271766709};\\\", \\\"{x:472,y:677,t:1527271766726};\\\", \\\"{x:476,y:685,t:1527271766742};\\\", \\\"{x:478,y:687,t:1527271766759};\\\", \\\"{x:478,y:688,t:1527271766780};\\\", \\\"{x:480,y:691,t:1527271766796};\\\", \\\"{x:480,y:693,t:1527271766836};\\\", \\\"{x:480,y:694,t:1527271766844};\\\", \\\"{x:480,y:695,t:1527271766867};\\\", \\\"{x:480,y:696,t:1527271766876};\\\", \\\"{x:480,y:698,t:1527271766893};\\\", \\\"{x:480,y:700,t:1527271766908};\\\", \\\"{x:482,y:704,t:1527271766926};\\\", \\\"{x:484,y:708,t:1527271766942};\\\", \\\"{x:486,y:711,t:1527271766963};\\\", \\\"{x:487,y:712,t:1527271766976};\\\", \\\"{x:490,y:718,t:1527271766993};\\\", \\\"{x:492,y:722,t:1527271767009};\\\", \\\"{x:492,y:723,t:1527271767059};\\\", \\\"{x:492,y:724,t:1527271767164};\\\", \\\"{x:494,y:724,t:1527271800292};\\\", \\\"{x:494,y:723,t:1527271800299};\\\", \\\"{x:495,y:723,t:1527271800314};\\\", \\\"{x:499,y:720,t:1527271800331};\\\", \\\"{x:502,y:719,t:1527271800347};\\\", \\\"{x:503,y:718,t:1527271800364};\\\", \\\"{x:505,y:717,t:1527271800381};\\\" ] }, { \\\"rt\\\": 8203, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 227469, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -F -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:717,t:1527271802506};\\\", \\\"{x:507,y:714,t:1527271803211};\\\", \\\"{x:507,y:712,t:1527271803224};\\\", \\\"{x:507,y:707,t:1527271803241};\\\", \\\"{x:510,y:703,t:1527271803258};\\\", \\\"{x:516,y:697,t:1527271803275};\\\", \\\"{x:532,y:683,t:1527271803290};\\\", \\\"{x:537,y:678,t:1527271803306};\\\", \\\"{x:555,y:666,t:1527271803323};\\\", \\\"{x:573,y:654,t:1527271803339};\\\", \\\"{x:584,y:646,t:1527271803357};\\\", \\\"{x:599,y:640,t:1527271803372};\\\", \\\"{x:604,y:637,t:1527271803388};\\\", \\\"{x:610,y:634,t:1527271803405};\\\", \\\"{x:615,y:632,t:1527271803422};\\\", \\\"{x:621,y:631,t:1527271803438};\\\", \\\"{x:624,y:629,t:1527271803456};\\\", \\\"{x:626,y:629,t:1527271803472};\\\", \\\"{x:630,y:628,t:1527271803489};\\\", \\\"{x:635,y:627,t:1527271803505};\\\", \\\"{x:649,y:625,t:1527271803523};\\\", \\\"{x:665,y:623,t:1527271803538};\\\", \\\"{x:689,y:618,t:1527271803556};\\\", \\\"{x:732,y:611,t:1527271803572};\\\", \\\"{x:796,y:602,t:1527271803588};\\\", \\\"{x:900,y:596,t:1527271803605};\\\", \\\"{x:1003,y:592,t:1527271803623};\\\", \\\"{x:1009,y:589,t:1527271803639};\\\", \\\"{x:1065,y:587,t:1527271803656};\\\", \\\"{x:1117,y:590,t:1527271803672};\\\", \\\"{x:1125,y:590,t:1527271803689};\\\", \\\"{x:1131,y:596,t:1527271803706};\\\", \\\"{x:1138,y:600,t:1527271803723};\\\", \\\"{x:1138,y:602,t:1527271803746};\\\", \\\"{x:1140,y:604,t:1527271803755};\\\", \\\"{x:1148,y:609,t:1527271803773};\\\", \\\"{x:1152,y:613,t:1527271803788};\\\", \\\"{x:1159,y:618,t:1527271803806};\\\", \\\"{x:1163,y:624,t:1527271803822};\\\", \\\"{x:1163,y:627,t:1527271803840};\\\", \\\"{x:1165,y:631,t:1527271803856};\\\", \\\"{x:1166,y:639,t:1527271803873};\\\", \\\"{x:1166,y:642,t:1527271803890};\\\", \\\"{x:1166,y:651,t:1527271803906};\\\", \\\"{x:1176,y:673,t:1527271803922};\\\", \\\"{x:1180,y:681,t:1527271803939};\\\", \\\"{x:1185,y:687,t:1527271803955};\\\", \\\"{x:1186,y:690,t:1527271803972};\\\", \\\"{x:1189,y:697,t:1527271803989};\\\", \\\"{x:1194,y:706,t:1527271804006};\\\", \\\"{x:1199,y:720,t:1527271804022};\\\", \\\"{x:1202,y:732,t:1527271804040};\\\", \\\"{x:1206,y:742,t:1527271804056};\\\", \\\"{x:1208,y:751,t:1527271804073};\\\", \\\"{x:1214,y:765,t:1527271804090};\\\", \\\"{x:1215,y:768,t:1527271804106};\\\", \\\"{x:1219,y:774,t:1527271804123};\\\", \\\"{x:1219,y:775,t:1527271804140};\\\", \\\"{x:1220,y:777,t:1527271804156};\\\", \\\"{x:1220,y:778,t:1527271804173};\\\", \\\"{x:1222,y:784,t:1527271804190};\\\", \\\"{x:1224,y:785,t:1527271804206};\\\", \\\"{x:1225,y:787,t:1527271804223};\\\", \\\"{x:1228,y:792,t:1527271804240};\\\", \\\"{x:1228,y:796,t:1527271804256};\\\", \\\"{x:1228,y:799,t:1527271804273};\\\", \\\"{x:1228,y:800,t:1527271804290};\\\", \\\"{x:1228,y:802,t:1527271804339};\\\", \\\"{x:1229,y:804,t:1527271804484};\\\", \\\"{x:1233,y:806,t:1527271804491};\\\", \\\"{x:1240,y:809,t:1527271804507};\\\", \\\"{x:1242,y:822,t:1527271804522};\\\", \\\"{x:1242,y:823,t:1527271804539};\\\", \\\"{x:1246,y:827,t:1527271804556};\\\", \\\"{x:1249,y:830,t:1527271804573};\\\", \\\"{x:1264,y:831,t:1527271804589};\\\", \\\"{x:1271,y:831,t:1527271804606};\\\", \\\"{x:1279,y:831,t:1527271804624};\\\", \\\"{x:1281,y:831,t:1527271804639};\\\", \\\"{x:1295,y:826,t:1527271804657};\\\", \\\"{x:1305,y:818,t:1527271804672};\\\", \\\"{x:1318,y:812,t:1527271804689};\\\", \\\"{x:1338,y:802,t:1527271804707};\\\", \\\"{x:1343,y:799,t:1527271804723};\\\", \\\"{x:1349,y:796,t:1527271804740};\\\", \\\"{x:1355,y:794,t:1527271804757};\\\", \\\"{x:1359,y:793,t:1527271804774};\\\", \\\"{x:1361,y:791,t:1527271804789};\\\", \\\"{x:1362,y:790,t:1527271804811};\\\", \\\"{x:1363,y:789,t:1527271804824};\\\", \\\"{x:1366,y:787,t:1527271804839};\\\", \\\"{x:1367,y:786,t:1527271804857};\\\", \\\"{x:1371,y:782,t:1527271804873};\\\", \\\"{x:1377,y:779,t:1527271804890};\\\", \\\"{x:1381,y:776,t:1527271804907};\\\", \\\"{x:1383,y:773,t:1527271804924};\\\", \\\"{x:1384,y:772,t:1527271804939};\\\", \\\"{x:1385,y:771,t:1527271805284};\\\", \\\"{x:1385,y:769,t:1527271805300};\\\", \\\"{x:1383,y:769,t:1527271805307};\\\", \\\"{x:1380,y:766,t:1527271805324};\\\", \\\"{x:1379,y:760,t:1527271805340};\\\", \\\"{x:1374,y:749,t:1527271805358};\\\", \\\"{x:1369,y:743,t:1527271805375};\\\", \\\"{x:1358,y:730,t:1527271805391};\\\", \\\"{x:1350,y:720,t:1527271805407};\\\", \\\"{x:1347,y:714,t:1527271805424};\\\", \\\"{x:1343,y:705,t:1527271805441};\\\", \\\"{x:1337,y:684,t:1527271805457};\\\", \\\"{x:1329,y:664,t:1527271805474};\\\", \\\"{x:1318,y:637,t:1527271805491};\\\", \\\"{x:1313,y:623,t:1527271805507};\\\", \\\"{x:1309,y:609,t:1527271805524};\\\", \\\"{x:1308,y:599,t:1527271805541};\\\", \\\"{x:1306,y:592,t:1527271805557};\\\", \\\"{x:1306,y:591,t:1527271805574};\\\", \\\"{x:1306,y:589,t:1527271805620};\\\", \\\"{x:1306,y:588,t:1527271805635};\\\", \\\"{x:1306,y:587,t:1527271805643};\\\", \\\"{x:1307,y:586,t:1527271805658};\\\", \\\"{x:1313,y:577,t:1527271805674};\\\", \\\"{x:1320,y:563,t:1527271805692};\\\", \\\"{x:1323,y:558,t:1527271805708};\\\", \\\"{x:1333,y:537,t:1527271805724};\\\", \\\"{x:1342,y:521,t:1527271805741};\\\", \\\"{x:1351,y:510,t:1527271805758};\\\", \\\"{x:1356,y:500,t:1527271805774};\\\", \\\"{x:1360,y:496,t:1527271805791};\\\", \\\"{x:1363,y:493,t:1527271805808};\\\", \\\"{x:1365,y:491,t:1527271805824};\\\", \\\"{x:1366,y:491,t:1527271806059};\\\", \\\"{x:1368,y:491,t:1527271806074};\\\", \\\"{x:1371,y:489,t:1527271806091};\\\", \\\"{x:1372,y:489,t:1527271806164};\\\", \\\"{x:1375,y:489,t:1527271806175};\\\", \\\"{x:1379,y:488,t:1527271806192};\\\", \\\"{x:1390,y:484,t:1527271806208};\\\", \\\"{x:1401,y:484,t:1527271806225};\\\", \\\"{x:1419,y:483,t:1527271806241};\\\", \\\"{x:1428,y:481,t:1527271806258};\\\", \\\"{x:1453,y:479,t:1527271806275};\\\", \\\"{x:1465,y:475,t:1527271806292};\\\", \\\"{x:1471,y:473,t:1527271806308};\\\", \\\"{x:1483,y:467,t:1527271806325};\\\", \\\"{x:1492,y:463,t:1527271806341};\\\", \\\"{x:1498,y:460,t:1527271806358};\\\", \\\"{x:1502,y:458,t:1527271806375};\\\", \\\"{x:1504,y:457,t:1527271806391};\\\", \\\"{x:1504,y:456,t:1527271806408};\\\", \\\"{x:1506,y:454,t:1527271806425};\\\", \\\"{x:1508,y:453,t:1527271806442};\\\", \\\"{x:1510,y:452,t:1527271806458};\\\", \\\"{x:1513,y:450,t:1527271806475};\\\", \\\"{x:1516,y:448,t:1527271806491};\\\", \\\"{x:1521,y:447,t:1527271806508};\\\", \\\"{x:1536,y:438,t:1527271806525};\\\", \\\"{x:1539,y:435,t:1527271806542};\\\", \\\"{x:1543,y:435,t:1527271806558};\\\", \\\"{x:1553,y:433,t:1527271806575};\\\", \\\"{x:1554,y:433,t:1527271806592};\\\", \\\"{x:1558,y:433,t:1527271806608};\\\", \\\"{x:1559,y:433,t:1527271806627};\\\", \\\"{x:1561,y:433,t:1527271806715};\\\", \\\"{x:1563,y:433,t:1527271806755};\\\", \\\"{x:1565,y:433,t:1527271806772};\\\", \\\"{x:1566,y:433,t:1527271806804};\\\", \\\"{x:1566,y:435,t:1527271806819};\\\", \\\"{x:1566,y:437,t:1527271806827};\\\", \\\"{x:1566,y:440,t:1527271806842};\\\", \\\"{x:1567,y:450,t:1527271806858};\\\", \\\"{x:1569,y:463,t:1527271806875};\\\", \\\"{x:1569,y:468,t:1527271806892};\\\", \\\"{x:1569,y:475,t:1527271806909};\\\", \\\"{x:1569,y:481,t:1527271806925};\\\", \\\"{x:1569,y:484,t:1527271806942};\\\", \\\"{x:1569,y:487,t:1527271806959};\\\", \\\"{x:1569,y:488,t:1527271807011};\\\", \\\"{x:1569,y:490,t:1527271807025};\\\", \\\"{x:1569,y:491,t:1527271807042};\\\", \\\"{x:1570,y:496,t:1527271807059};\\\", \\\"{x:1571,y:500,t:1527271807075};\\\", \\\"{x:1573,y:506,t:1527271807093};\\\", \\\"{x:1575,y:514,t:1527271807109};\\\", \\\"{x:1576,y:519,t:1527271807125};\\\", \\\"{x:1581,y:527,t:1527271807142};\\\", \\\"{x:1581,y:533,t:1527271807159};\\\", \\\"{x:1584,y:544,t:1527271807175};\\\", \\\"{x:1585,y:552,t:1527271807192};\\\", \\\"{x:1589,y:567,t:1527271807209};\\\", \\\"{x:1592,y:582,t:1527271807225};\\\", \\\"{x:1596,y:597,t:1527271807242};\\\", \\\"{x:1597,y:607,t:1527271807259};\\\", \\\"{x:1597,y:608,t:1527271807275};\\\", \\\"{x:1597,y:609,t:1527271807292};\\\", \\\"{x:1597,y:610,t:1527271807309};\\\", \\\"{x:1596,y:612,t:1527271807326};\\\", \\\"{x:1596,y:614,t:1527271807342};\\\", \\\"{x:1594,y:614,t:1527271807359};\\\", \\\"{x:1592,y:617,t:1527271807375};\\\", \\\"{x:1587,y:621,t:1527271807392};\\\", \\\"{x:1581,y:622,t:1527271807409};\\\", \\\"{x:1574,y:626,t:1527271807426};\\\", \\\"{x:1556,y:628,t:1527271807442};\\\", \\\"{x:1541,y:630,t:1527271807459};\\\", \\\"{x:1488,y:631,t:1527271807476};\\\", \\\"{x:1428,y:634,t:1527271807492};\\\", \\\"{x:1332,y:629,t:1527271807509};\\\", \\\"{x:1202,y:608,t:1527271807526};\\\", \\\"{x:1083,y:576,t:1527271807542};\\\", \\\"{x:929,y:541,t:1527271807559};\\\", \\\"{x:781,y:511,t:1527271807578};\\\", \\\"{x:645,y:483,t:1527271807592};\\\", \\\"{x:548,y:459,t:1527271807608};\\\", \\\"{x:518,y:453,t:1527271807625};\\\", \\\"{x:507,y:452,t:1527271807642};\\\", \\\"{x:506,y:451,t:1527271807730};\\\", \\\"{x:507,y:451,t:1527271807851};\\\", \\\"{x:508,y:451,t:1527271807859};\\\", \\\"{x:517,y:456,t:1527271807876};\\\", \\\"{x:523,y:461,t:1527271807894};\\\", \\\"{x:526,y:463,t:1527271807909};\\\", \\\"{x:526,y:468,t:1527271807926};\\\", \\\"{x:526,y:473,t:1527271807943};\\\", \\\"{x:519,y:483,t:1527271807959};\\\", \\\"{x:505,y:491,t:1527271807976};\\\", \\\"{x:485,y:494,t:1527271807992};\\\", \\\"{x:470,y:498,t:1527271808009};\\\", \\\"{x:454,y:502,t:1527271808025};\\\", \\\"{x:440,y:507,t:1527271808044};\\\", \\\"{x:439,y:507,t:1527271808059};\\\", \\\"{x:437,y:507,t:1527271808075};\\\", \\\"{x:436,y:507,t:1527271808093};\\\", \\\"{x:435,y:508,t:1527271808138};\\\", \\\"{x:432,y:510,t:1527271808154};\\\", \\\"{x:430,y:513,t:1527271808171};\\\", \\\"{x:422,y:521,t:1527271808178};\\\", \\\"{x:414,y:527,t:1527271808192};\\\", \\\"{x:403,y:539,t:1527271808210};\\\", \\\"{x:398,y:549,t:1527271808226};\\\", \\\"{x:390,y:566,t:1527271808242};\\\", \\\"{x:385,y:572,t:1527271808260};\\\", \\\"{x:377,y:576,t:1527271808276};\\\", \\\"{x:368,y:581,t:1527271808293};\\\", \\\"{x:358,y:584,t:1527271808310};\\\", \\\"{x:351,y:584,t:1527271808325};\\\", \\\"{x:330,y:574,t:1527271808344};\\\", \\\"{x:317,y:561,t:1527271808359};\\\", \\\"{x:290,y:554,t:1527271808375};\\\", \\\"{x:282,y:551,t:1527271808392};\\\", \\\"{x:279,y:548,t:1527271808409};\\\", \\\"{x:278,y:548,t:1527271808514};\\\", \\\"{x:277,y:548,t:1527271808526};\\\", \\\"{x:270,y:549,t:1527271808544};\\\", \\\"{x:263,y:553,t:1527271808559};\\\", \\\"{x:255,y:557,t:1527271808576};\\\", \\\"{x:245,y:560,t:1527271808593};\\\", \\\"{x:236,y:563,t:1527271808610};\\\", \\\"{x:234,y:565,t:1527271808625};\\\", \\\"{x:220,y:569,t:1527271808643};\\\", \\\"{x:210,y:571,t:1527271808660};\\\", \\\"{x:195,y:574,t:1527271808675};\\\", \\\"{x:181,y:576,t:1527271808694};\\\", \\\"{x:173,y:580,t:1527271808709};\\\", \\\"{x:171,y:580,t:1527271808727};\\\", \\\"{x:169,y:581,t:1527271808742};\\\", \\\"{x:167,y:583,t:1527271808761};\\\", \\\"{x:164,y:587,t:1527271808777};\\\", \\\"{x:162,y:592,t:1527271808793};\\\", \\\"{x:160,y:599,t:1527271808809};\\\", \\\"{x:159,y:607,t:1527271808825};\\\", \\\"{x:159,y:610,t:1527271808843};\\\", \\\"{x:160,y:615,t:1527271808860};\\\", \\\"{x:161,y:621,t:1527271808877};\\\", \\\"{x:161,y:623,t:1527271808939};\\\", \\\"{x:161,y:624,t:1527271808946};\\\", \\\"{x:161,y:625,t:1527271808960};\\\", \\\"{x:160,y:627,t:1527271808977};\\\", \\\"{x:160,y:628,t:1527271808992};\\\", \\\"{x:160,y:629,t:1527271809314};\\\", \\\"{x:162,y:629,t:1527271809327};\\\", \\\"{x:173,y:631,t:1527271809344};\\\", \\\"{x:184,y:641,t:1527271809359};\\\", \\\"{x:200,y:652,t:1527271809377};\\\", \\\"{x:248,y:670,t:1527271809394};\\\", \\\"{x:331,y:690,t:1527271809410};\\\", \\\"{x:365,y:709,t:1527271809426};\\\", \\\"{x:366,y:719,t:1527271809443};\\\", \\\"{x:389,y:728,t:1527271809460};\\\", \\\"{x:394,y:737,t:1527271809476};\\\", \\\"{x:399,y:740,t:1527271809494};\\\", \\\"{x:398,y:742,t:1527271809562};\\\", \\\"{x:395,y:742,t:1527271809578};\\\", \\\"{x:394,y:744,t:1527271809594};\\\", \\\"{x:386,y:744,t:1527271809610};\\\", \\\"{x:371,y:744,t:1527271809626};\\\", \\\"{x:364,y:744,t:1527271809644};\\\", \\\"{x:363,y:744,t:1527271809660};\\\", \\\"{x:363,y:743,t:1527271809706};\\\", \\\"{x:363,y:742,t:1527271809714};\\\", \\\"{x:363,y:741,t:1527271809727};\\\", \\\"{x:368,y:737,t:1527271809744};\\\", \\\"{x:378,y:732,t:1527271809760};\\\", \\\"{x:400,y:725,t:1527271809777};\\\", \\\"{x:411,y:724,t:1527271809793};\\\", \\\"{x:436,y:722,t:1527271809811};\\\", \\\"{x:455,y:720,t:1527271809829};\\\", \\\"{x:461,y:719,t:1527271809851};\\\", \\\"{x:462,y:718,t:1527271809861};\\\", \\\"{x:463,y:718,t:1527271809877};\\\", \\\"{x:464,y:718,t:1527271810060};\\\", \\\"{x:464,y:718,t:1527271810170};\\\", \\\"{x:465,y:718,t:1527271810427};\\\" ] }, { \\\"rt\\\": 22894, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 251586, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-10 AM-C -11 AM-11 AM-12 PM-12 PM-Z -Z -Z -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:468,y:717,t:1527271811651};\\\", \\\"{x:472,y:716,t:1527271811662};\\\", \\\"{x:476,y:713,t:1527271811706};\\\", \\\"{x:476,y:712,t:1527271811714};\\\", \\\"{x:479,y:711,t:1527271811729};\\\", \\\"{x:479,y:710,t:1527271811745};\\\", \\\"{x:485,y:705,t:1527271811841};\\\", \\\"{x:492,y:702,t:1527271811848};\\\", \\\"{x:497,y:698,t:1527271811863};\\\", \\\"{x:502,y:694,t:1527271811879};\\\", \\\"{x:507,y:691,t:1527271811895};\\\", \\\"{x:511,y:687,t:1527271811911};\\\", \\\"{x:524,y:678,t:1527271811928};\\\", \\\"{x:531,y:674,t:1527271811946};\\\", \\\"{x:552,y:670,t:1527271811962};\\\", \\\"{x:631,y:666,t:1527271811979};\\\", \\\"{x:693,y:666,t:1527271811995};\\\", \\\"{x:738,y:666,t:1527271812011};\\\", \\\"{x:806,y:660,t:1527271812028};\\\", \\\"{x:830,y:660,t:1527271812046};\\\", \\\"{x:867,y:659,t:1527271812062};\\\", \\\"{x:877,y:659,t:1527271812079};\\\", \\\"{x:885,y:659,t:1527271812095};\\\", \\\"{x:887,y:659,t:1527271812111};\\\", \\\"{x:888,y:659,t:1527271812212};\\\", \\\"{x:886,y:652,t:1527271812218};\\\", \\\"{x:867,y:641,t:1527271812229};\\\", \\\"{x:774,y:624,t:1527271812246};\\\", \\\"{x:698,y:610,t:1527271812264};\\\", \\\"{x:660,y:605,t:1527271812279};\\\", \\\"{x:638,y:594,t:1527271812296};\\\", \\\"{x:607,y:581,t:1527271812314};\\\", \\\"{x:592,y:571,t:1527271812329};\\\", \\\"{x:587,y:564,t:1527271812345};\\\", \\\"{x:586,y:562,t:1527271812515};\\\", \\\"{x:585,y:562,t:1527271812531};\\\", \\\"{x:585,y:561,t:1527271812546};\\\", \\\"{x:580,y:559,t:1527271812562};\\\", \\\"{x:578,y:556,t:1527271812580};\\\", \\\"{x:571,y:554,t:1527271812596};\\\", \\\"{x:563,y:552,t:1527271812613};\\\", \\\"{x:563,y:551,t:1527271812629};\\\", \\\"{x:562,y:549,t:1527271812646};\\\", \\\"{x:555,y:546,t:1527271812663};\\\", \\\"{x:541,y:542,t:1527271812681};\\\", \\\"{x:529,y:539,t:1527271812696};\\\", \\\"{x:512,y:533,t:1527271812714};\\\", \\\"{x:500,y:529,t:1527271812730};\\\", \\\"{x:490,y:521,t:1527271812746};\\\", \\\"{x:478,y:515,t:1527271812762};\\\", \\\"{x:466,y:511,t:1527271812779};\\\", \\\"{x:456,y:506,t:1527271812795};\\\", \\\"{x:451,y:502,t:1527271812813};\\\", \\\"{x:446,y:499,t:1527271812830};\\\", \\\"{x:442,y:496,t:1527271812845};\\\", \\\"{x:439,y:493,t:1527271812862};\\\", \\\"{x:438,y:491,t:1527271812879};\\\", \\\"{x:436,y:488,t:1527271812896};\\\", \\\"{x:434,y:486,t:1527271812913};\\\", \\\"{x:432,y:485,t:1527271812930};\\\", \\\"{x:432,y:484,t:1527271812947};\\\", \\\"{x:430,y:484,t:1527271812963};\\\", \\\"{x:427,y:481,t:1527271812980};\\\", \\\"{x:421,y:478,t:1527271812996};\\\", \\\"{x:415,y:475,t:1527271813012};\\\", \\\"{x:414,y:474,t:1527271813035};\\\", \\\"{x:414,y:473,t:1527271813051};\\\", \\\"{x:412,y:472,t:1527271813063};\\\", \\\"{x:409,y:469,t:1527271813080};\\\", \\\"{x:399,y:467,t:1527271813097};\\\", \\\"{x:389,y:463,t:1527271813113};\\\", \\\"{x:379,y:460,t:1527271813131};\\\", \\\"{x:375,y:459,t:1527271813147};\\\", \\\"{x:374,y:459,t:1527271813186};\\\", \\\"{x:373,y:459,t:1527271813197};\\\", \\\"{x:375,y:459,t:1527271813475};\\\", \\\"{x:383,y:460,t:1527271813483};\\\", \\\"{x:392,y:460,t:1527271813507};\\\", \\\"{x:401,y:462,t:1527271813515};\\\", \\\"{x:414,y:463,t:1527271813530};\\\", \\\"{x:418,y:466,t:1527271813547};\\\", \\\"{x:506,y:474,t:1527271813564};\\\", \\\"{x:586,y:485,t:1527271813580};\\\", \\\"{x:674,y:495,t:1527271813597};\\\", \\\"{x:772,y:511,t:1527271813616};\\\", \\\"{x:828,y:521,t:1527271813629};\\\", \\\"{x:893,y:531,t:1527271813646};\\\", \\\"{x:926,y:540,t:1527271813664};\\\", \\\"{x:934,y:546,t:1527271813680};\\\", \\\"{x:959,y:552,t:1527271813697};\\\", \\\"{x:973,y:556,t:1527271813714};\\\", \\\"{x:983,y:558,t:1527271813730};\\\", \\\"{x:985,y:558,t:1527271813746};\\\", \\\"{x:985,y:563,t:1527271813923};\\\", \\\"{x:985,y:566,t:1527271813931};\\\", \\\"{x:987,y:570,t:1527271813947};\\\", \\\"{x:999,y:586,t:1527271813964};\\\", \\\"{x:1008,y:608,t:1527271813981};\\\", \\\"{x:1020,y:631,t:1527271813997};\\\", \\\"{x:1036,y:654,t:1527271814014};\\\", \\\"{x:1048,y:673,t:1527271814031};\\\", \\\"{x:1071,y:696,t:1527271814047};\\\", \\\"{x:1094,y:719,t:1527271814064};\\\", \\\"{x:1138,y:744,t:1527271814080};\\\", \\\"{x:1163,y:761,t:1527271814097};\\\", \\\"{x:1173,y:771,t:1527271814113};\\\", \\\"{x:1174,y:779,t:1527271814130};\\\", \\\"{x:1174,y:781,t:1527271814147};\\\", \\\"{x:1177,y:784,t:1527271814347};\\\", \\\"{x:1178,y:789,t:1527271814365};\\\", \\\"{x:1182,y:792,t:1527271814381};\\\", \\\"{x:1185,y:796,t:1527271814398};\\\", \\\"{x:1189,y:799,t:1527271814415};\\\", \\\"{x:1191,y:799,t:1527271814432};\\\", \\\"{x:1193,y:799,t:1527271814449};\\\", \\\"{x:1199,y:802,t:1527271814464};\\\", \\\"{x:1209,y:810,t:1527271814482};\\\", \\\"{x:1222,y:820,t:1527271814498};\\\", \\\"{x:1229,y:828,t:1527271814515};\\\", \\\"{x:1246,y:844,t:1527271814531};\\\", \\\"{x:1256,y:856,t:1527271814549};\\\", \\\"{x:1260,y:860,t:1527271814565};\\\", \\\"{x:1260,y:861,t:1527271814581};\\\", \\\"{x:1261,y:862,t:1527271814599};\\\", \\\"{x:1260,y:861,t:1527271814715};\\\", \\\"{x:1259,y:860,t:1527271814787};\\\", \\\"{x:1259,y:859,t:1527271814799};\\\", \\\"{x:1259,y:858,t:1527271814815};\\\", \\\"{x:1257,y:855,t:1527271814831};\\\", \\\"{x:1253,y:850,t:1527271814848};\\\", \\\"{x:1253,y:847,t:1527271814866};\\\", \\\"{x:1250,y:845,t:1527271814881};\\\", \\\"{x:1244,y:841,t:1527271814899};\\\", \\\"{x:1243,y:839,t:1527271814916};\\\", \\\"{x:1242,y:838,t:1527271814963};\\\", \\\"{x:1241,y:837,t:1527271814971};\\\", \\\"{x:1239,y:837,t:1527271815036};\\\", \\\"{x:1238,y:837,t:1527271815091};\\\", \\\"{x:1236,y:837,t:1527271815155};\\\", \\\"{x:1235,y:838,t:1527271815165};\\\", \\\"{x:1234,y:839,t:1527271815182};\\\", \\\"{x:1233,y:840,t:1527271815198};\\\", \\\"{x:1231,y:841,t:1527271815216};\\\", \\\"{x:1230,y:841,t:1527271815233};\\\", \\\"{x:1228,y:842,t:1527271815251};\\\", \\\"{x:1227,y:843,t:1527271815265};\\\", \\\"{x:1226,y:843,t:1527271815331};\\\", \\\"{x:1225,y:843,t:1527271815435};\\\", \\\"{x:1224,y:843,t:1527271815459};\\\", \\\"{x:1222,y:843,t:1527271815467};\\\", \\\"{x:1218,y:840,t:1527271815482};\\\", \\\"{x:1214,y:838,t:1527271815498};\\\", \\\"{x:1207,y:835,t:1527271815516};\\\", \\\"{x:1204,y:834,t:1527271815533};\\\", \\\"{x:1203,y:834,t:1527271815549};\\\", \\\"{x:1202,y:833,t:1527271815565};\\\", \\\"{x:1202,y:832,t:1527271816132};\\\", \\\"{x:1201,y:836,t:1527271816149};\\\", \\\"{x:1201,y:846,t:1527271816167};\\\", \\\"{x:1202,y:854,t:1527271816183};\\\", \\\"{x:1206,y:864,t:1527271816199};\\\", \\\"{x:1212,y:881,t:1527271816217};\\\", \\\"{x:1215,y:890,t:1527271816232};\\\", \\\"{x:1222,y:907,t:1527271816249};\\\", \\\"{x:1228,y:930,t:1527271816267};\\\", \\\"{x:1229,y:935,t:1527271816283};\\\", \\\"{x:1231,y:949,t:1527271816300};\\\", \\\"{x:1231,y:957,t:1527271816316};\\\", \\\"{x:1231,y:963,t:1527271816333};\\\", \\\"{x:1231,y:968,t:1527271816350};\\\", \\\"{x:1231,y:972,t:1527271816367};\\\", \\\"{x:1232,y:978,t:1527271816384};\\\", \\\"{x:1232,y:980,t:1527271816400};\\\", \\\"{x:1232,y:982,t:1527271816416};\\\", \\\"{x:1232,y:983,t:1527271816483};\\\", \\\"{x:1232,y:984,t:1527271816499};\\\", \\\"{x:1232,y:985,t:1527271816532};\\\", \\\"{x:1232,y:986,t:1527271816549};\\\", \\\"{x:1230,y:986,t:1527271816603};\\\", \\\"{x:1229,y:986,t:1527271816635};\\\", \\\"{x:1228,y:986,t:1527271816651};\\\", \\\"{x:1226,y:986,t:1527271816667};\\\", \\\"{x:1225,y:986,t:1527271816683};\\\", \\\"{x:1223,y:984,t:1527271816699};\\\", \\\"{x:1223,y:983,t:1527271816717};\\\", \\\"{x:1220,y:976,t:1527271816733};\\\", \\\"{x:1217,y:968,t:1527271816750};\\\", \\\"{x:1211,y:954,t:1527271816766};\\\", \\\"{x:1209,y:949,t:1527271816784};\\\", \\\"{x:1203,y:932,t:1527271816799};\\\", \\\"{x:1201,y:921,t:1527271816816};\\\", \\\"{x:1199,y:904,t:1527271816834};\\\", \\\"{x:1199,y:890,t:1527271816849};\\\", \\\"{x:1203,y:878,t:1527271816866};\\\", \\\"{x:1209,y:870,t:1527271816883};\\\", \\\"{x:1211,y:866,t:1527271816898};\\\", \\\"{x:1212,y:866,t:1527271816922};\\\", \\\"{x:1212,y:865,t:1527271816937};\\\", \\\"{x:1212,y:864,t:1527271816953};\\\", \\\"{x:1212,y:862,t:1527271816978};\\\", \\\"{x:1212,y:860,t:1527271816985};\\\", \\\"{x:1212,y:859,t:1527271816999};\\\", \\\"{x:1212,y:855,t:1527271817015};\\\", \\\"{x:1212,y:852,t:1527271817033};\\\", \\\"{x:1210,y:843,t:1527271817049};\\\", \\\"{x:1207,y:837,t:1527271817065};\\\", \\\"{x:1207,y:834,t:1527271817083};\\\", \\\"{x:1206,y:830,t:1527271817100};\\\", \\\"{x:1206,y:829,t:1527271817116};\\\", \\\"{x:1206,y:828,t:1527271817132};\\\", \\\"{x:1206,y:827,t:1527271817150};\\\", \\\"{x:1206,y:826,t:1527271817165};\\\", \\\"{x:1206,y:825,t:1527271817183};\\\", \\\"{x:1206,y:824,t:1527271817251};\\\", \\\"{x:1205,y:824,t:1527271817483};\\\", \\\"{x:1201,y:824,t:1527271817500};\\\", \\\"{x:1196,y:825,t:1527271817518};\\\", \\\"{x:1191,y:825,t:1527271817533};\\\", \\\"{x:1185,y:825,t:1527271817550};\\\", \\\"{x:1175,y:825,t:1527271817567};\\\", \\\"{x:1169,y:827,t:1527271817584};\\\", \\\"{x:1165,y:827,t:1527271817600};\\\", \\\"{x:1164,y:827,t:1527271817659};\\\", \\\"{x:1168,y:827,t:1527271817707};\\\", \\\"{x:1174,y:827,t:1527271817717};\\\", \\\"{x:1179,y:827,t:1527271817733};\\\", \\\"{x:1186,y:827,t:1527271817750};\\\", \\\"{x:1193,y:829,t:1527271817768};\\\", \\\"{x:1201,y:829,t:1527271817784};\\\", \\\"{x:1208,y:830,t:1527271817800};\\\", \\\"{x:1215,y:830,t:1527271817819};\\\", \\\"{x:1220,y:831,t:1527271817834};\\\", \\\"{x:1221,y:831,t:1527271817851};\\\", \\\"{x:1231,y:834,t:1527271817867};\\\", \\\"{x:1239,y:835,t:1527271817884};\\\", \\\"{x:1246,y:838,t:1527271817900};\\\", \\\"{x:1247,y:838,t:1527271818124};\\\", \\\"{x:1244,y:838,t:1527271818155};\\\", \\\"{x:1243,y:838,t:1527271818167};\\\", \\\"{x:1237,y:837,t:1527271818184};\\\", \\\"{x:1235,y:834,t:1527271818200};\\\", \\\"{x:1233,y:833,t:1527271818218};\\\", \\\"{x:1232,y:845,t:1527271818532};\\\", \\\"{x:1233,y:874,t:1527271818539};\\\", \\\"{x:1242,y:915,t:1527271818552};\\\", \\\"{x:1253,y:967,t:1527271818568};\\\", \\\"{x:1260,y:1007,t:1527271818585};\\\", \\\"{x:1262,y:1027,t:1527271818601};\\\", \\\"{x:1264,y:1033,t:1527271818617};\\\", \\\"{x:1264,y:1035,t:1527271818634};\\\", \\\"{x:1264,y:1034,t:1527271818748};\\\", \\\"{x:1264,y:1031,t:1527271818755};\\\", \\\"{x:1263,y:1027,t:1527271818768};\\\", \\\"{x:1260,y:1024,t:1527271818784};\\\", \\\"{x:1259,y:1018,t:1527271818801};\\\", \\\"{x:1256,y:1010,t:1527271818818};\\\", \\\"{x:1253,y:1007,t:1527271818835};\\\", \\\"{x:1253,y:1002,t:1527271818851};\\\", \\\"{x:1253,y:998,t:1527271818868};\\\", \\\"{x:1253,y:994,t:1527271818885};\\\", \\\"{x:1253,y:990,t:1527271818902};\\\", \\\"{x:1256,y:986,t:1527271818918};\\\", \\\"{x:1257,y:983,t:1527271818935};\\\", \\\"{x:1258,y:982,t:1527271818951};\\\", \\\"{x:1261,y:980,t:1527271818969};\\\", \\\"{x:1264,y:977,t:1527271818985};\\\", \\\"{x:1267,y:975,t:1527271819002};\\\", \\\"{x:1271,y:970,t:1527271819019};\\\", \\\"{x:1273,y:969,t:1527271819034};\\\", \\\"{x:1274,y:967,t:1527271819066};\\\", \\\"{x:1275,y:967,t:1527271819227};\\\", \\\"{x:1277,y:967,t:1527271819235};\\\", \\\"{x:1278,y:971,t:1527271819251};\\\", \\\"{x:1278,y:975,t:1527271819269};\\\", \\\"{x:1281,y:980,t:1527271819285};\\\", \\\"{x:1281,y:981,t:1527271819302};\\\", \\\"{x:1282,y:982,t:1527271819404};\\\", \\\"{x:1290,y:982,t:1527271819419};\\\", \\\"{x:1303,y:978,t:1527271819435};\\\", \\\"{x:1311,y:975,t:1527271819451};\\\", \\\"{x:1318,y:973,t:1527271819468};\\\", \\\"{x:1319,y:973,t:1527271819484};\\\", \\\"{x:1321,y:972,t:1527271819659};\\\", \\\"{x:1324,y:971,t:1527271819668};\\\", \\\"{x:1331,y:969,t:1527271819685};\\\", \\\"{x:1340,y:969,t:1527271819703};\\\", \\\"{x:1342,y:968,t:1527271819719};\\\", \\\"{x:1346,y:967,t:1527271819736};\\\", \\\"{x:1352,y:966,t:1527271819752};\\\", \\\"{x:1355,y:966,t:1527271819768};\\\", \\\"{x:1354,y:966,t:1527271819955};\\\", \\\"{x:1354,y:967,t:1527271819969};\\\", \\\"{x:1352,y:970,t:1527271819986};\\\", \\\"{x:1350,y:971,t:1527271820002};\\\", \\\"{x:1349,y:972,t:1527271820019};\\\", \\\"{x:1349,y:973,t:1527271820035};\\\", \\\"{x:1349,y:969,t:1527271820380};\\\", \\\"{x:1349,y:965,t:1527271820388};\\\", \\\"{x:1349,y:958,t:1527271820402};\\\", \\\"{x:1353,y:948,t:1527271820419};\\\", \\\"{x:1356,y:937,t:1527271820436};\\\", \\\"{x:1358,y:928,t:1527271820452};\\\", \\\"{x:1358,y:924,t:1527271820468};\\\", \\\"{x:1358,y:919,t:1527271820486};\\\", \\\"{x:1357,y:916,t:1527271820502};\\\", \\\"{x:1357,y:911,t:1527271820518};\\\", \\\"{x:1357,y:909,t:1527271820536};\\\", \\\"{x:1355,y:907,t:1527271820552};\\\", \\\"{x:1355,y:906,t:1527271820578};\\\", \\\"{x:1354,y:904,t:1527271820610};\\\", \\\"{x:1354,y:903,t:1527271820635};\\\", \\\"{x:1353,y:902,t:1527271820651};\\\", \\\"{x:1352,y:901,t:1527271820667};\\\", \\\"{x:1350,y:899,t:1527271820686};\\\", \\\"{x:1344,y:897,t:1527271820702};\\\", \\\"{x:1342,y:895,t:1527271820719};\\\", \\\"{x:1339,y:892,t:1527271820736};\\\", \\\"{x:1338,y:890,t:1527271820752};\\\", \\\"{x:1337,y:887,t:1527271820769};\\\", \\\"{x:1335,y:883,t:1527271820786};\\\", \\\"{x:1334,y:881,t:1527271820810};\\\", \\\"{x:1334,y:880,t:1527271820939};\\\", \\\"{x:1334,y:879,t:1527271821075};\\\", \\\"{x:1334,y:878,t:1527271821115};\\\", \\\"{x:1334,y:877,t:1527271821123};\\\", \\\"{x:1334,y:876,t:1527271821139};\\\", \\\"{x:1335,y:875,t:1527271821153};\\\", \\\"{x:1339,y:874,t:1527271821170};\\\", \\\"{x:1340,y:873,t:1527271821252};\\\", \\\"{x:1341,y:873,t:1527271821258};\\\", \\\"{x:1343,y:873,t:1527271821270};\\\", \\\"{x:1347,y:881,t:1527271821287};\\\", \\\"{x:1351,y:892,t:1527271821304};\\\", \\\"{x:1356,y:899,t:1527271821321};\\\", \\\"{x:1360,y:905,t:1527271821337};\\\", \\\"{x:1361,y:906,t:1527271821353};\\\", \\\"{x:1362,y:906,t:1527271821483};\\\", \\\"{x:1362,y:905,t:1527271821490};\\\", \\\"{x:1362,y:902,t:1527271821504};\\\", \\\"{x:1362,y:896,t:1527271821521};\\\", \\\"{x:1364,y:886,t:1527271821537};\\\", \\\"{x:1364,y:877,t:1527271821554};\\\", \\\"{x:1366,y:864,t:1527271821571};\\\", \\\"{x:1366,y:860,t:1527271821587};\\\", \\\"{x:1366,y:856,t:1527271821604};\\\", \\\"{x:1365,y:849,t:1527271821620};\\\", \\\"{x:1364,y:846,t:1527271821637};\\\", \\\"{x:1362,y:842,t:1527271821654};\\\", \\\"{x:1358,y:836,t:1527271821671};\\\", \\\"{x:1355,y:830,t:1527271821687};\\\", \\\"{x:1351,y:823,t:1527271821704};\\\", \\\"{x:1350,y:816,t:1527271821721};\\\", \\\"{x:1349,y:808,t:1527271821737};\\\", \\\"{x:1347,y:804,t:1527271821754};\\\", \\\"{x:1346,y:801,t:1527271821771};\\\", \\\"{x:1346,y:798,t:1527271821787};\\\", \\\"{x:1346,y:801,t:1527271821897};\\\", \\\"{x:1346,y:805,t:1527271821905};\\\", \\\"{x:1346,y:811,t:1527271821919};\\\", \\\"{x:1346,y:824,t:1527271821936};\\\", \\\"{x:1349,y:841,t:1527271821952};\\\", \\\"{x:1353,y:865,t:1527271821969};\\\", \\\"{x:1355,y:880,t:1527271821985};\\\", \\\"{x:1357,y:890,t:1527271822002};\\\", \\\"{x:1360,y:899,t:1527271822019};\\\", \\\"{x:1362,y:903,t:1527271822035};\\\", \\\"{x:1362,y:905,t:1527271822051};\\\", \\\"{x:1362,y:906,t:1527271822068};\\\", \\\"{x:1362,y:907,t:1527271822298};\\\", \\\"{x:1361,y:907,t:1527271822313};\\\", \\\"{x:1359,y:906,t:1527271822329};\\\", \\\"{x:1359,y:905,t:1527271822345};\\\", \\\"{x:1358,y:905,t:1527271822353};\\\", \\\"{x:1357,y:903,t:1527271822369};\\\", \\\"{x:1356,y:903,t:1527271822394};\\\", \\\"{x:1356,y:902,t:1527271822403};\\\", \\\"{x:1355,y:902,t:1527271822418};\\\", \\\"{x:1355,y:901,t:1527271822436};\\\", \\\"{x:1353,y:900,t:1527271822897};\\\", \\\"{x:1342,y:897,t:1527271822905};\\\", \\\"{x:1315,y:894,t:1527271822920};\\\", \\\"{x:1238,y:876,t:1527271822936};\\\", \\\"{x:1052,y:843,t:1527271822953};\\\", \\\"{x:912,y:808,t:1527271822970};\\\", \\\"{x:775,y:778,t:1527271822986};\\\", \\\"{x:643,y:744,t:1527271823002};\\\", \\\"{x:545,y:725,t:1527271823021};\\\", \\\"{x:449,y:707,t:1527271823037};\\\", \\\"{x:394,y:699,t:1527271823053};\\\", \\\"{x:372,y:693,t:1527271823069};\\\", \\\"{x:370,y:693,t:1527271823086};\\\", \\\"{x:367,y:691,t:1527271823232};\\\", \\\"{x:360,y:687,t:1527271823240};\\\", \\\"{x:351,y:683,t:1527271823253};\\\", \\\"{x:340,y:677,t:1527271823269};\\\", \\\"{x:335,y:673,t:1527271823289};\\\", \\\"{x:334,y:673,t:1527271823313};\\\", \\\"{x:333,y:673,t:1527271823320};\\\", \\\"{x:332,y:672,t:1527271823337};\\\", \\\"{x:332,y:671,t:1527271823353};\\\", \\\"{x:332,y:668,t:1527271823370};\\\", \\\"{x:336,y:664,t:1527271823387};\\\", \\\"{x:347,y:652,t:1527271823403};\\\", \\\"{x:359,y:645,t:1527271823421};\\\", \\\"{x:380,y:630,t:1527271823437};\\\", \\\"{x:397,y:617,t:1527271823454};\\\", \\\"{x:421,y:603,t:1527271823470};\\\", \\\"{x:444,y:590,t:1527271823486};\\\", \\\"{x:454,y:584,t:1527271823503};\\\", \\\"{x:454,y:583,t:1527271823519};\\\", \\\"{x:466,y:575,t:1527271823536};\\\", \\\"{x:468,y:575,t:1527271823553};\\\", \\\"{x:470,y:574,t:1527271823722};\\\", \\\"{x:472,y:573,t:1527271823744};\\\", \\\"{x:476,y:573,t:1527271823754};\\\", \\\"{x:484,y:576,t:1527271823771};\\\", \\\"{x:500,y:578,t:1527271823787};\\\", \\\"{x:522,y:583,t:1527271823804};\\\", \\\"{x:554,y:593,t:1527271823819};\\\", \\\"{x:569,y:596,t:1527271823836};\\\", \\\"{x:583,y:597,t:1527271823853};\\\", \\\"{x:590,y:599,t:1527271823870};\\\", \\\"{x:594,y:599,t:1527271823886};\\\", \\\"{x:596,y:599,t:1527271823993};\\\", \\\"{x:598,y:599,t:1527271824004};\\\", \\\"{x:605,y:599,t:1527271824021};\\\", \\\"{x:609,y:599,t:1527271824037};\\\", \\\"{x:616,y:599,t:1527271824054};\\\", \\\"{x:622,y:599,t:1527271824071};\\\", \\\"{x:631,y:601,t:1527271824086};\\\", \\\"{x:644,y:601,t:1527271824105};\\\", \\\"{x:656,y:601,t:1527271824120};\\\", \\\"{x:663,y:601,t:1527271824136};\\\", \\\"{x:670,y:600,t:1527271824153};\\\", \\\"{x:675,y:600,t:1527271824170};\\\", \\\"{x:683,y:599,t:1527271824186};\\\", \\\"{x:691,y:597,t:1527271824204};\\\", \\\"{x:693,y:596,t:1527271824220};\\\", \\\"{x:699,y:595,t:1527271824238};\\\", \\\"{x:702,y:595,t:1527271824253};\\\", \\\"{x:707,y:595,t:1527271824271};\\\", \\\"{x:711,y:595,t:1527271824287};\\\", \\\"{x:715,y:594,t:1527271824303};\\\", \\\"{x:720,y:593,t:1527271824320};\\\", \\\"{x:728,y:592,t:1527271824338};\\\", \\\"{x:736,y:592,t:1527271824354};\\\", \\\"{x:746,y:592,t:1527271824370};\\\", \\\"{x:748,y:592,t:1527271824387};\\\", \\\"{x:751,y:592,t:1527271824403};\\\", \\\"{x:751,y:595,t:1527271824474};\\\", \\\"{x:746,y:599,t:1527271824486};\\\", \\\"{x:745,y:599,t:1527271824504};\\\", \\\"{x:736,y:604,t:1527271824520};\\\", \\\"{x:727,y:609,t:1527271824537};\\\", \\\"{x:713,y:616,t:1527271824554};\\\", \\\"{x:704,y:622,t:1527271824571};\\\", \\\"{x:696,y:626,t:1527271824588};\\\", \\\"{x:692,y:629,t:1527271824603};\\\", \\\"{x:689,y:630,t:1527271824620};\\\", \\\"{x:685,y:630,t:1527271824638};\\\", \\\"{x:678,y:633,t:1527271824654};\\\", \\\"{x:677,y:633,t:1527271824670};\\\", \\\"{x:671,y:633,t:1527271824687};\\\", \\\"{x:662,y:634,t:1527271824705};\\\", \\\"{x:645,y:634,t:1527271824720};\\\", \\\"{x:620,y:634,t:1527271824739};\\\", \\\"{x:593,y:630,t:1527271824755};\\\", \\\"{x:561,y:630,t:1527271824770};\\\", \\\"{x:526,y:623,t:1527271824787};\\\", \\\"{x:511,y:618,t:1527271824805};\\\", \\\"{x:495,y:615,t:1527271824820};\\\", \\\"{x:494,y:614,t:1527271824837};\\\", \\\"{x:493,y:614,t:1527271824854};\\\", \\\"{x:492,y:614,t:1527271824912};\\\", \\\"{x:491,y:614,t:1527271824929};\\\", \\\"{x:490,y:615,t:1527271824938};\\\", \\\"{x:488,y:618,t:1527271824955};\\\", \\\"{x:485,y:622,t:1527271824971};\\\", \\\"{x:479,y:626,t:1527271824987};\\\", \\\"{x:471,y:629,t:1527271825005};\\\", \\\"{x:454,y:633,t:1527271825020};\\\", \\\"{x:431,y:633,t:1527271825038};\\\", \\\"{x:405,y:634,t:1527271825055};\\\", \\\"{x:385,y:632,t:1527271825071};\\\", \\\"{x:349,y:628,t:1527271825088};\\\", \\\"{x:313,y:611,t:1527271825105};\\\", \\\"{x:303,y:602,t:1527271825121};\\\", \\\"{x:282,y:592,t:1527271825138};\\\", \\\"{x:265,y:587,t:1527271825155};\\\", \\\"{x:260,y:585,t:1527271825171};\\\", \\\"{x:259,y:585,t:1527271825257};\\\", \\\"{x:258,y:585,t:1527271825271};\\\", \\\"{x:253,y:589,t:1527271825288};\\\", \\\"{x:252,y:590,t:1527271825304};\\\", \\\"{x:252,y:591,t:1527271825321};\\\", \\\"{x:250,y:592,t:1527271825338};\\\", \\\"{x:249,y:593,t:1527271825355};\\\", \\\"{x:247,y:593,t:1527271825377};\\\", \\\"{x:243,y:592,t:1527271825393};\\\", \\\"{x:239,y:589,t:1527271825406};\\\", \\\"{x:223,y:579,t:1527271825423};\\\", \\\"{x:219,y:573,t:1527271825440};\\\", \\\"{x:198,y:562,t:1527271825454};\\\", \\\"{x:181,y:550,t:1527271825471};\\\", \\\"{x:169,y:539,t:1527271825488};\\\", \\\"{x:167,y:538,t:1527271825504};\\\", \\\"{x:166,y:537,t:1527271825649};\\\", \\\"{x:165,y:537,t:1527271825665};\\\", \\\"{x:164,y:537,t:1527271825697};\\\", \\\"{x:164,y:540,t:1527271825705};\\\", \\\"{x:162,y:545,t:1527271825723};\\\", \\\"{x:162,y:549,t:1527271825739};\\\", \\\"{x:162,y:552,t:1527271825755};\\\", \\\"{x:162,y:553,t:1527271826144};\\\", \\\"{x:163,y:553,t:1527271826155};\\\", \\\"{x:165,y:552,t:1527271826171};\\\", \\\"{x:166,y:552,t:1527271826188};\\\", \\\"{x:186,y:556,t:1527271826205};\\\", \\\"{x:221,y:570,t:1527271826222};\\\", \\\"{x:292,y:590,t:1527271826239};\\\", \\\"{x:377,y:610,t:1527271826255};\\\", \\\"{x:464,y:639,t:1527271826272};\\\", \\\"{x:639,y:676,t:1527271826288};\\\", \\\"{x:761,y:714,t:1527271826306};\\\", \\\"{x:873,y:734,t:1527271826323};\\\", \\\"{x:969,y:754,t:1527271826338};\\\", \\\"{x:1047,y:767,t:1527271826355};\\\", \\\"{x:1082,y:780,t:1527271826373};\\\", \\\"{x:1092,y:784,t:1527271826389};\\\", \\\"{x:1105,y:791,t:1527271826406};\\\", \\\"{x:1116,y:797,t:1527271826423};\\\", \\\"{x:1129,y:807,t:1527271826439};\\\", \\\"{x:1140,y:816,t:1527271826456};\\\", \\\"{x:1155,y:830,t:1527271826473};\\\", \\\"{x:1164,y:835,t:1527271826490};\\\", \\\"{x:1174,y:844,t:1527271826505};\\\", \\\"{x:1188,y:857,t:1527271826522};\\\", \\\"{x:1203,y:871,t:1527271826539};\\\", \\\"{x:1209,y:873,t:1527271826555};\\\", \\\"{x:1235,y:894,t:1527271826572};\\\", \\\"{x:1250,y:905,t:1527271826589};\\\", \\\"{x:1252,y:909,t:1527271826605};\\\", \\\"{x:1256,y:911,t:1527271826623};\\\", \\\"{x:1258,y:915,t:1527271826639};\\\", \\\"{x:1260,y:916,t:1527271826656};\\\", \\\"{x:1262,y:918,t:1527271826672};\\\", \\\"{x:1263,y:918,t:1527271826689};\\\", \\\"{x:1265,y:920,t:1527271826707};\\\", \\\"{x:1266,y:921,t:1527271826723};\\\", \\\"{x:1267,y:921,t:1527271826740};\\\", \\\"{x:1268,y:922,t:1527271826757};\\\", \\\"{x:1269,y:923,t:1527271826785};\\\", \\\"{x:1270,y:923,t:1527271826809};\\\", \\\"{x:1271,y:922,t:1527271826823};\\\", \\\"{x:1272,y:921,t:1527271826841};\\\", \\\"{x:1273,y:921,t:1527271826857};\\\", \\\"{x:1273,y:920,t:1527271826936};\\\", \\\"{x:1271,y:917,t:1527271826944};\\\", \\\"{x:1268,y:915,t:1527271826956};\\\", \\\"{x:1260,y:911,t:1527271826974};\\\", \\\"{x:1252,y:902,t:1527271826990};\\\", \\\"{x:1240,y:884,t:1527271827007};\\\", \\\"{x:1228,y:870,t:1527271827024};\\\", \\\"{x:1213,y:854,t:1527271827040};\\\", \\\"{x:1210,y:854,t:1527271827057};\\\", \\\"{x:1209,y:852,t:1527271827073};\\\", \\\"{x:1208,y:851,t:1527271827091};\\\", \\\"{x:1208,y:850,t:1527271827107};\\\", \\\"{x:1207,y:849,t:1527271827129};\\\", \\\"{x:1207,y:848,t:1527271827141};\\\", \\\"{x:1207,y:847,t:1527271827258};\\\", \\\"{x:1207,y:846,t:1527271827275};\\\", \\\"{x:1207,y:845,t:1527271827297};\\\", \\\"{x:1207,y:844,t:1527271827329};\\\", \\\"{x:1207,y:843,t:1527271827343};\\\", \\\"{x:1207,y:842,t:1527271827358};\\\", \\\"{x:1207,y:840,t:1527271827375};\\\", \\\"{x:1207,y:839,t:1527271827393};\\\", \\\"{x:1207,y:838,t:1527271827409};\\\", \\\"{x:1207,y:837,t:1527271827425};\\\", \\\"{x:1207,y:836,t:1527271827442};\\\", \\\"{x:1207,y:840,t:1527271827833};\\\", \\\"{x:1207,y:846,t:1527271827843};\\\", \\\"{x:1210,y:861,t:1527271827859};\\\", \\\"{x:1218,y:882,t:1527271827876};\\\", \\\"{x:1224,y:897,t:1527271827893};\\\", \\\"{x:1227,y:907,t:1527271827910};\\\", \\\"{x:1228,y:917,t:1527271827927};\\\", \\\"{x:1229,y:925,t:1527271827943};\\\", \\\"{x:1229,y:926,t:1527271827960};\\\", \\\"{x:1229,y:930,t:1527271827977};\\\", \\\"{x:1228,y:938,t:1527271827993};\\\", \\\"{x:1227,y:940,t:1527271828010};\\\", \\\"{x:1227,y:941,t:1527271828027};\\\", \\\"{x:1227,y:942,t:1527271828043};\\\", \\\"{x:1226,y:943,t:1527271828060};\\\", \\\"{x:1224,y:944,t:1527271828077};\\\", \\\"{x:1223,y:945,t:1527271828093};\\\", \\\"{x:1222,y:946,t:1527271828110};\\\", \\\"{x:1221,y:946,t:1527271828127};\\\", \\\"{x:1219,y:946,t:1527271828143};\\\", \\\"{x:1217,y:945,t:1527271828160};\\\", \\\"{x:1213,y:938,t:1527271828177};\\\", \\\"{x:1212,y:930,t:1527271828194};\\\", \\\"{x:1211,y:923,t:1527271828210};\\\", \\\"{x:1210,y:911,t:1527271828227};\\\", \\\"{x:1209,y:906,t:1527271828244};\\\", \\\"{x:1209,y:896,t:1527271828261};\\\", \\\"{x:1209,y:889,t:1527271828277};\\\", \\\"{x:1209,y:885,t:1527271828294};\\\", \\\"{x:1209,y:881,t:1527271828311};\\\", \\\"{x:1208,y:874,t:1527271828327};\\\", \\\"{x:1206,y:868,t:1527271828344};\\\", \\\"{x:1205,y:865,t:1527271828361};\\\", \\\"{x:1201,y:860,t:1527271828377};\\\", \\\"{x:1192,y:855,t:1527271828394};\\\", \\\"{x:1189,y:853,t:1527271828412};\\\", \\\"{x:1187,y:853,t:1527271828427};\\\", \\\"{x:1186,y:853,t:1527271828570};\\\", \\\"{x:1190,y:853,t:1527271828673};\\\", \\\"{x:1196,y:856,t:1527271828681};\\\", \\\"{x:1202,y:859,t:1527271828695};\\\", \\\"{x:1217,y:868,t:1527271828712};\\\", \\\"{x:1226,y:875,t:1527271828728};\\\", \\\"{x:1230,y:883,t:1527271828745};\\\", \\\"{x:1231,y:886,t:1527271828762};\\\", \\\"{x:1232,y:886,t:1527271828778};\\\", \\\"{x:1233,y:886,t:1527271828795};\\\", \\\"{x:1233,y:887,t:1527271828812};\\\", \\\"{x:1233,y:889,t:1527271828828};\\\", \\\"{x:1233,y:892,t:1527271828845};\\\", \\\"{x:1233,y:893,t:1527271828862};\\\", \\\"{x:1233,y:896,t:1527271828929};\\\", \\\"{x:1233,y:902,t:1527271828945};\\\", \\\"{x:1233,y:906,t:1527271828962};\\\", \\\"{x:1234,y:910,t:1527271828980};\\\", \\\"{x:1238,y:915,t:1527271828996};\\\", \\\"{x:1241,y:917,t:1527271829013};\\\", \\\"{x:1245,y:919,t:1527271829029};\\\", \\\"{x:1247,y:920,t:1527271829045};\\\", \\\"{x:1247,y:921,t:1527271829062};\\\", \\\"{x:1248,y:921,t:1527271829078};\\\", \\\"{x:1250,y:922,t:1527271829095};\\\", \\\"{x:1251,y:922,t:1527271829120};\\\", \\\"{x:1252,y:922,t:1527271829136};\\\", \\\"{x:1253,y:922,t:1527271829146};\\\", \\\"{x:1254,y:922,t:1527271829162};\\\", \\\"{x:1255,y:922,t:1527271829216};\\\", \\\"{x:1258,y:922,t:1527271829229};\\\", \\\"{x:1266,y:930,t:1527271829246};\\\", \\\"{x:1274,y:940,t:1527271829263};\\\", \\\"{x:1279,y:944,t:1527271829280};\\\", \\\"{x:1283,y:949,t:1527271829296};\\\", \\\"{x:1285,y:952,t:1527271829313};\\\", \\\"{x:1286,y:952,t:1527271829401};\\\", \\\"{x:1287,y:952,t:1527271829413};\\\", \\\"{x:1290,y:954,t:1527271829431};\\\", \\\"{x:1291,y:954,t:1527271829457};\\\", \\\"{x:1293,y:954,t:1527271829465};\\\", \\\"{x:1297,y:954,t:1527271829480};\\\", \\\"{x:1306,y:954,t:1527271829496};\\\", \\\"{x:1311,y:954,t:1527271829513};\\\", \\\"{x:1316,y:954,t:1527271829529};\\\", \\\"{x:1323,y:954,t:1527271829546};\\\", \\\"{x:1324,y:954,t:1527271829754};\\\", \\\"{x:1325,y:954,t:1527271829777};\\\", \\\"{x:1327,y:954,t:1527271829792};\\\", \\\"{x:1329,y:954,t:1527271829857};\\\", \\\"{x:1330,y:954,t:1527271829865};\\\", \\\"{x:1332,y:956,t:1527271829880};\\\", \\\"{x:1338,y:959,t:1527271829898};\\\", \\\"{x:1342,y:961,t:1527271829914};\\\", \\\"{x:1344,y:962,t:1527271829931};\\\", \\\"{x:1345,y:962,t:1527271830097};\\\", \\\"{x:1349,y:961,t:1527271830115};\\\", \\\"{x:1353,y:957,t:1527271830133};\\\", \\\"{x:1356,y:954,t:1527271830148};\\\", \\\"{x:1358,y:950,t:1527271830165};\\\", \\\"{x:1360,y:947,t:1527271830182};\\\", \\\"{x:1361,y:943,t:1527271830198};\\\", \\\"{x:1361,y:942,t:1527271830241};\\\", \\\"{x:1361,y:941,t:1527271830256};\\\", \\\"{x:1361,y:940,t:1527271830265};\\\", \\\"{x:1361,y:939,t:1527271830282};\\\", \\\"{x:1361,y:937,t:1527271830300};\\\", \\\"{x:1361,y:933,t:1527271830316};\\\", \\\"{x:1361,y:927,t:1527271830332};\\\", \\\"{x:1355,y:915,t:1527271830349};\\\", \\\"{x:1347,y:901,t:1527271830365};\\\", \\\"{x:1338,y:888,t:1527271830382};\\\", \\\"{x:1328,y:874,t:1527271830399};\\\", \\\"{x:1327,y:868,t:1527271830416};\\\", \\\"{x:1325,y:867,t:1527271830432};\\\", \\\"{x:1325,y:865,t:1527271830521};\\\", \\\"{x:1325,y:864,t:1527271830537};\\\", \\\"{x:1326,y:862,t:1527271830553};\\\", \\\"{x:1328,y:860,t:1527271830566};\\\", \\\"{x:1332,y:857,t:1527271830584};\\\", \\\"{x:1337,y:854,t:1527271830599};\\\", \\\"{x:1343,y:849,t:1527271830616};\\\", \\\"{x:1350,y:838,t:1527271830633};\\\", \\\"{x:1354,y:834,t:1527271830650};\\\", \\\"{x:1359,y:827,t:1527271830666};\\\", \\\"{x:1363,y:820,t:1527271830683};\\\", \\\"{x:1365,y:815,t:1527271830700};\\\", \\\"{x:1366,y:813,t:1527271830716};\\\", \\\"{x:1367,y:809,t:1527271830733};\\\", \\\"{x:1368,y:808,t:1527271830750};\\\", \\\"{x:1370,y:806,t:1527271830766};\\\", \\\"{x:1371,y:806,t:1527271830783};\\\", \\\"{x:1372,y:804,t:1527271830801};\\\", \\\"{x:1373,y:803,t:1527271830816};\\\", \\\"{x:1373,y:801,t:1527271830833};\\\", \\\"{x:1373,y:800,t:1527271830850};\\\", \\\"{x:1374,y:798,t:1527271830867};\\\", \\\"{x:1374,y:797,t:1527271830905};\\\", \\\"{x:1374,y:794,t:1527271830917};\\\", \\\"{x:1374,y:789,t:1527271830933};\\\", \\\"{x:1374,y:785,t:1527271830950};\\\", \\\"{x:1374,y:780,t:1527271830967};\\\", \\\"{x:1374,y:775,t:1527271830985};\\\", \\\"{x:1373,y:772,t:1527271831000};\\\", \\\"{x:1371,y:771,t:1527271831017};\\\", \\\"{x:1371,y:768,t:1527271831034};\\\", \\\"{x:1369,y:766,t:1527271831050};\\\", \\\"{x:1369,y:765,t:1527271831067};\\\", \\\"{x:1368,y:764,t:1527271831084};\\\", \\\"{x:1367,y:761,t:1527271831101};\\\", \\\"{x:1366,y:759,t:1527271831118};\\\", \\\"{x:1365,y:755,t:1527271831134};\\\", \\\"{x:1365,y:751,t:1527271831151};\\\", \\\"{x:1365,y:749,t:1527271831167};\\\", \\\"{x:1362,y:742,t:1527271831185};\\\", \\\"{x:1361,y:736,t:1527271831199};\\\", \\\"{x:1358,y:728,t:1527271831217};\\\", \\\"{x:1356,y:722,t:1527271831233};\\\", \\\"{x:1356,y:718,t:1527271831251};\\\", \\\"{x:1354,y:714,t:1527271831267};\\\", \\\"{x:1353,y:713,t:1527271831284};\\\", \\\"{x:1352,y:713,t:1527271831304};\\\", \\\"{x:1352,y:712,t:1527271831401};\\\", \\\"{x:1347,y:712,t:1527271831418};\\\", \\\"{x:1341,y:714,t:1527271831435};\\\", \\\"{x:1335,y:717,t:1527271831451};\\\", \\\"{x:1334,y:717,t:1527271831489};\\\", \\\"{x:1333,y:717,t:1527271831545};\\\", \\\"{x:1333,y:718,t:1527271832737};\\\", \\\"{x:1320,y:724,t:1527271832754};\\\", \\\"{x:1311,y:727,t:1527271832771};\\\", \\\"{x:1305,y:727,t:1527271832789};\\\", \\\"{x:1299,y:730,t:1527271832806};\\\", \\\"{x:1292,y:731,t:1527271832821};\\\", \\\"{x:1285,y:736,t:1527271832838};\\\", \\\"{x:1271,y:741,t:1527271832855};\\\", \\\"{x:1259,y:745,t:1527271832871};\\\", \\\"{x:1235,y:749,t:1527271832888};\\\", \\\"{x:1197,y:750,t:1527271832905};\\\", \\\"{x:1168,y:749,t:1527271832922};\\\", \\\"{x:1122,y:747,t:1527271832938};\\\", \\\"{x:1066,y:738,t:1527271832955};\\\", \\\"{x:996,y:727,t:1527271832972};\\\", \\\"{x:917,y:711,t:1527271832989};\\\", \\\"{x:870,y:706,t:1527271833005};\\\", \\\"{x:813,y:698,t:1527271833022};\\\", \\\"{x:741,y:699,t:1527271833038};\\\", \\\"{x:655,y:699,t:1527271833055};\\\", \\\"{x:609,y:699,t:1527271833072};\\\", \\\"{x:580,y:700,t:1527271833088};\\\", \\\"{x:556,y:700,t:1527271833106};\\\", \\\"{x:554,y:701,t:1527271833123};\\\", \\\"{x:553,y:702,t:1527271833139};\\\", \\\"{x:553,y:705,t:1527271833216};\\\", \\\"{x:553,y:709,t:1527271833228};\\\", \\\"{x:553,y:719,t:1527271833243};\\\", \\\"{x:553,y:729,t:1527271833261};\\\", \\\"{x:553,y:738,t:1527271833278};\\\", \\\"{x:553,y:743,t:1527271833295};\\\", \\\"{x:553,y:745,t:1527271833310};\\\", \\\"{x:553,y:746,t:1527271833327};\\\", \\\"{x:553,y:745,t:1527271833521};\\\", \\\"{x:552,y:744,t:1527271833528};\\\", \\\"{x:548,y:739,t:1527271833544};\\\", \\\"{x:547,y:736,t:1527271833561};\\\", \\\"{x:545,y:734,t:1527271833578};\\\", \\\"{x:542,y:731,t:1527271833595};\\\", \\\"{x:542,y:730,t:1527271833611};\\\", \\\"{x:542,y:728,t:1527271834392};\\\", \\\"{x:542,y:727,t:1527271834400};\\\", \\\"{x:541,y:725,t:1527271834448};\\\" ] }, { \\\"rt\\\": 71640, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 324440, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-U -U -J -U -U -U -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:541,y:724,t:1527271835825};\\\", \\\"{x:534,y:724,t:1527271835966};\\\", \\\"{x:535,y:724,t:1527271836160};\\\", \\\"{x:537,y:723,t:1527271836168};\\\", \\\"{x:539,y:722,t:1527271836183};\\\", \\\"{x:541,y:721,t:1527271836199};\\\", \\\"{x:606,y:724,t:1527271836217};\\\", \\\"{x:656,y:736,t:1527271836233};\\\", \\\"{x:718,y:744,t:1527271836247};\\\", \\\"{x:845,y:759,t:1527271836263};\\\", \\\"{x:999,y:778,t:1527271836280};\\\", \\\"{x:1108,y:796,t:1527271836296};\\\", \\\"{x:1185,y:805,t:1527271836312};\\\", \\\"{x:1218,y:810,t:1527271836330};\\\", \\\"{x:1234,y:811,t:1527271836347};\\\", \\\"{x:1245,y:811,t:1527271836363};\\\", \\\"{x:1247,y:811,t:1527271836380};\\\", \\\"{x:1248,y:811,t:1527271837713};\\\", \\\"{x:1254,y:811,t:1527271837732};\\\", \\\"{x:1271,y:811,t:1527271837747};\\\", \\\"{x:1281,y:809,t:1527271837765};\\\", \\\"{x:1292,y:807,t:1527271837782};\\\", \\\"{x:1299,y:807,t:1527271837800};\\\", \\\"{x:1318,y:807,t:1527271837814};\\\", \\\"{x:1339,y:807,t:1527271837832};\\\", \\\"{x:1367,y:818,t:1527271837849};\\\", \\\"{x:1421,y:833,t:1527271837865};\\\", \\\"{x:1443,y:843,t:1527271837881};\\\", \\\"{x:1452,y:853,t:1527271837898};\\\", \\\"{x:1479,y:865,t:1527271837914};\\\", \\\"{x:1501,y:871,t:1527271837932};\\\", \\\"{x:1521,y:880,t:1527271837949};\\\", \\\"{x:1533,y:886,t:1527271837964};\\\", \\\"{x:1546,y:889,t:1527271837981};\\\", \\\"{x:1553,y:892,t:1527271837998};\\\", \\\"{x:1562,y:896,t:1527271838015};\\\", \\\"{x:1570,y:898,t:1527271838032};\\\", \\\"{x:1572,y:901,t:1527271838049};\\\", \\\"{x:1573,y:901,t:1527271838745};\\\", \\\"{x:1574,y:901,t:1527271838786};\\\", \\\"{x:1575,y:901,t:1527271838800};\\\", \\\"{x:1577,y:901,t:1527271838816};\\\", \\\"{x:1578,y:901,t:1527271838831};\\\", \\\"{x:1578,y:902,t:1527271838873};\\\", \\\"{x:1578,y:903,t:1527271838888};\\\", \\\"{x:1578,y:905,t:1527271838920};\\\", \\\"{x:1578,y:906,t:1527271838931};\\\", \\\"{x:1576,y:907,t:1527271838948};\\\", \\\"{x:1574,y:909,t:1527271838965};\\\", \\\"{x:1572,y:910,t:1527271838982};\\\", \\\"{x:1571,y:910,t:1527271838998};\\\", \\\"{x:1567,y:910,t:1527271839015};\\\", \\\"{x:1563,y:915,t:1527271839032};\\\", \\\"{x:1559,y:918,t:1527271839049};\\\", \\\"{x:1554,y:920,t:1527271839065};\\\", \\\"{x:1551,y:921,t:1527271839082};\\\", \\\"{x:1549,y:922,t:1527271839098};\\\", \\\"{x:1548,y:923,t:1527271839120};\\\", \\\"{x:1547,y:924,t:1527271839377};\\\", \\\"{x:1545,y:922,t:1527271839400};\\\", \\\"{x:1544,y:920,t:1527271839416};\\\", \\\"{x:1539,y:913,t:1527271839432};\\\", \\\"{x:1536,y:908,t:1527271839448};\\\", \\\"{x:1531,y:902,t:1527271839465};\\\", \\\"{x:1526,y:897,t:1527271839482};\\\", \\\"{x:1519,y:889,t:1527271839499};\\\", \\\"{x:1515,y:883,t:1527271839515};\\\", \\\"{x:1510,y:874,t:1527271839532};\\\", \\\"{x:1507,y:872,t:1527271839552};\\\", \\\"{x:1507,y:871,t:1527271839566};\\\", \\\"{x:1502,y:866,t:1527271839582};\\\", \\\"{x:1498,y:862,t:1527271839599};\\\", \\\"{x:1497,y:859,t:1527271839615};\\\", \\\"{x:1495,y:857,t:1527271839633};\\\", \\\"{x:1495,y:856,t:1527271839650};\\\", \\\"{x:1494,y:855,t:1527271839666};\\\", \\\"{x:1493,y:854,t:1527271839721};\\\", \\\"{x:1493,y:853,t:1527271839745};\\\", \\\"{x:1491,y:852,t:1527271839825};\\\", \\\"{x:1490,y:852,t:1527271839841};\\\", \\\"{x:1489,y:851,t:1527271839849};\\\", \\\"{x:1488,y:850,t:1527271839866};\\\", \\\"{x:1486,y:848,t:1527271839883};\\\", \\\"{x:1475,y:843,t:1527271839901};\\\", \\\"{x:1468,y:840,t:1527271839916};\\\", \\\"{x:1466,y:837,t:1527271839932};\\\", \\\"{x:1460,y:833,t:1527271839950};\\\", \\\"{x:1457,y:833,t:1527271839965};\\\", \\\"{x:1459,y:833,t:1527271840209};\\\", \\\"{x:1461,y:833,t:1527271840216};\\\", \\\"{x:1465,y:840,t:1527271840232};\\\", \\\"{x:1467,y:844,t:1527271840257};\\\", \\\"{x:1470,y:848,t:1527271840266};\\\", \\\"{x:1477,y:854,t:1527271840283};\\\", \\\"{x:1482,y:859,t:1527271840301};\\\", \\\"{x:1486,y:864,t:1527271840316};\\\", \\\"{x:1487,y:867,t:1527271840332};\\\", \\\"{x:1488,y:870,t:1527271840349};\\\", \\\"{x:1490,y:872,t:1527271840366};\\\", \\\"{x:1491,y:879,t:1527271840381};\\\", \\\"{x:1491,y:883,t:1527271840399};\\\", \\\"{x:1495,y:894,t:1527271840416};\\\", \\\"{x:1498,y:907,t:1527271840432};\\\", \\\"{x:1498,y:912,t:1527271840449};\\\", \\\"{x:1498,y:913,t:1527271840466};\\\", \\\"{x:1498,y:915,t:1527271840482};\\\", \\\"{x:1498,y:916,t:1527271840537};\\\", \\\"{x:1497,y:916,t:1527271840576};\\\", \\\"{x:1496,y:918,t:1527271840592};\\\", \\\"{x:1496,y:919,t:1527271840617};\\\", \\\"{x:1495,y:919,t:1527271840632};\\\", \\\"{x:1493,y:921,t:1527271840649};\\\", \\\"{x:1492,y:923,t:1527271840667};\\\", \\\"{x:1491,y:925,t:1527271840683};\\\", \\\"{x:1491,y:926,t:1527271840701};\\\", \\\"{x:1490,y:930,t:1527271840717};\\\", \\\"{x:1487,y:934,t:1527271840734};\\\", \\\"{x:1484,y:938,t:1527271840749};\\\", \\\"{x:1484,y:940,t:1527271840767};\\\", \\\"{x:1482,y:943,t:1527271840784};\\\", \\\"{x:1480,y:945,t:1527271840799};\\\", \\\"{x:1480,y:946,t:1527271840816};\\\", \\\"{x:1480,y:945,t:1527271841025};\\\", \\\"{x:1480,y:940,t:1527271841034};\\\", \\\"{x:1480,y:934,t:1527271841050};\\\", \\\"{x:1479,y:922,t:1527271841067};\\\", \\\"{x:1479,y:918,t:1527271841084};\\\", \\\"{x:1479,y:913,t:1527271841101};\\\", \\\"{x:1479,y:905,t:1527271841117};\\\", \\\"{x:1476,y:898,t:1527271841133};\\\", \\\"{x:1476,y:893,t:1527271841150};\\\", \\\"{x:1476,y:889,t:1527271841167};\\\", \\\"{x:1477,y:884,t:1527271841184};\\\", \\\"{x:1477,y:880,t:1527271841200};\\\", \\\"{x:1477,y:875,t:1527271841216};\\\", \\\"{x:1477,y:873,t:1527271841234};\\\", \\\"{x:1477,y:868,t:1527271841250};\\\", \\\"{x:1477,y:866,t:1527271841273};\\\", \\\"{x:1478,y:865,t:1527271841617};\\\", \\\"{x:1478,y:863,t:1527271841634};\\\", \\\"{x:1479,y:862,t:1527271841651};\\\", \\\"{x:1479,y:860,t:1527271841667};\\\", \\\"{x:1479,y:859,t:1527271841684};\\\", \\\"{x:1480,y:858,t:1527271841713};\\\", \\\"{x:1480,y:857,t:1527271842081};\\\", \\\"{x:1481,y:857,t:1527271842121};\\\", \\\"{x:1481,y:856,t:1527271842137};\\\", \\\"{x:1483,y:855,t:1527271842153};\\\", \\\"{x:1483,y:854,t:1527271842176};\\\", \\\"{x:1484,y:854,t:1527271842185};\\\", \\\"{x:1484,y:853,t:1527271842200};\\\", \\\"{x:1485,y:852,t:1527271842217};\\\", \\\"{x:1485,y:851,t:1527271842234};\\\", \\\"{x:1485,y:850,t:1527271842251};\\\", \\\"{x:1486,y:849,t:1527271842305};\\\", \\\"{x:1486,y:848,t:1527271842321};\\\", \\\"{x:1486,y:847,t:1527271842361};\\\", \\\"{x:1486,y:846,t:1527271842466};\\\", \\\"{x:1486,y:845,t:1527271842472};\\\", \\\"{x:1486,y:844,t:1527271842484};\\\", \\\"{x:1486,y:843,t:1527271842537};\\\", \\\"{x:1486,y:842,t:1527271842551};\\\", \\\"{x:1486,y:841,t:1527271842625};\\\", \\\"{x:1486,y:840,t:1527271842673};\\\", \\\"{x:1486,y:838,t:1527271842685};\\\", \\\"{x:1486,y:837,t:1527271843809};\\\", \\\"{x:1486,y:836,t:1527271843819};\\\", \\\"{x:1486,y:834,t:1527271843835};\\\", \\\"{x:1486,y:831,t:1527271843855};\\\", \\\"{x:1486,y:829,t:1527271843884};\\\", \\\"{x:1486,y:828,t:1527271843936};\\\", \\\"{x:1485,y:826,t:1527271843976};\\\", \\\"{x:1484,y:825,t:1527271844000};\\\", \\\"{x:1483,y:825,t:1527271844441};\\\", \\\"{x:1483,y:826,t:1527271844451};\\\", \\\"{x:1481,y:828,t:1527271844468};\\\", \\\"{x:1480,y:828,t:1527271844485};\\\", \\\"{x:1479,y:830,t:1527271844501};\\\", \\\"{x:1479,y:831,t:1527271844520};\\\", \\\"{x:1479,y:832,t:1527271844535};\\\", \\\"{x:1478,y:832,t:1527271844551};\\\", \\\"{x:1478,y:833,t:1527271844568};\\\", \\\"{x:1478,y:834,t:1527271844592};\\\", \\\"{x:1478,y:835,t:1527271844602};\\\", \\\"{x:1477,y:836,t:1527271844641};\\\", \\\"{x:1477,y:834,t:1527271845001};\\\", \\\"{x:1475,y:828,t:1527271845018};\\\", \\\"{x:1475,y:827,t:1527271845035};\\\", \\\"{x:1470,y:812,t:1527271845052};\\\", \\\"{x:1466,y:784,t:1527271845068};\\\", \\\"{x:1465,y:741,t:1527271845086};\\\", \\\"{x:1461,y:688,t:1527271845103};\\\", \\\"{x:1458,y:642,t:1527271845119};\\\", \\\"{x:1440,y:547,t:1527271845135};\\\", \\\"{x:1420,y:431,t:1527271845152};\\\", \\\"{x:1420,y:364,t:1527271845169};\\\", \\\"{x:1415,y:304,t:1527271845185};\\\", \\\"{x:1417,y:244,t:1527271845202};\\\", \\\"{x:1417,y:161,t:1527271845218};\\\", \\\"{x:1415,y:90,t:1527271845235};\\\", \\\"{x:1415,y:39,t:1527271845252};\\\", \\\"{x:1422,y:14,t:1527271845270};\\\", \\\"{x:1427,y:14,t:1527271845285};\\\", \\\"{x:1432,y:14,t:1527271845302};\\\", \\\"{x:1437,y:14,t:1527271845319};\\\", \\\"{x:1438,y:14,t:1527271845377};\\\", \\\"{x:1437,y:14,t:1527271845440};\\\", \\\"{x:1436,y:14,t:1527271845452};\\\", \\\"{x:1430,y:24,t:1527271845469};\\\", \\\"{x:1428,y:36,t:1527271845485};\\\", \\\"{x:1425,y:55,t:1527271845502};\\\", \\\"{x:1425,y:81,t:1527271845520};\\\", \\\"{x:1425,y:107,t:1527271845535};\\\", \\\"{x:1436,y:145,t:1527271845553};\\\", \\\"{x:1442,y:165,t:1527271845570};\\\", \\\"{x:1442,y:169,t:1527271845586};\\\", \\\"{x:1441,y:171,t:1527271845602};\\\", \\\"{x:1441,y:177,t:1527271845620};\\\", \\\"{x:1441,y:187,t:1527271845636};\\\", \\\"{x:1441,y:196,t:1527271845652};\\\", \\\"{x:1441,y:202,t:1527271845670};\\\", \\\"{x:1441,y:209,t:1527271845685};\\\", \\\"{x:1441,y:217,t:1527271845702};\\\", \\\"{x:1438,y:228,t:1527271845719};\\\", \\\"{x:1436,y:239,t:1527271845736};\\\", \\\"{x:1435,y:247,t:1527271845752};\\\", \\\"{x:1433,y:254,t:1527271845769};\\\", \\\"{x:1433,y:260,t:1527271845785};\\\", \\\"{x:1432,y:262,t:1527271845802};\\\", \\\"{x:1431,y:266,t:1527271845820};\\\", \\\"{x:1430,y:267,t:1527271845841};\\\", \\\"{x:1429,y:268,t:1527271845856};\\\", \\\"{x:1429,y:269,t:1527271845870};\\\", \\\"{x:1428,y:271,t:1527271846289};\\\", \\\"{x:1427,y:273,t:1527271846303};\\\", \\\"{x:1424,y:278,t:1527271846320};\\\", \\\"{x:1417,y:297,t:1527271846337};\\\", \\\"{x:1409,y:322,t:1527271846354};\\\", \\\"{x:1408,y:384,t:1527271846370};\\\", \\\"{x:1408,y:470,t:1527271846387};\\\", \\\"{x:1402,y:547,t:1527271846403};\\\", \\\"{x:1402,y:583,t:1527271846419};\\\", \\\"{x:1402,y:602,t:1527271846437};\\\", \\\"{x:1405,y:614,t:1527271846453};\\\", \\\"{x:1411,y:627,t:1527271846470};\\\", \\\"{x:1422,y:649,t:1527271846487};\\\", \\\"{x:1430,y:669,t:1527271846504};\\\", \\\"{x:1434,y:678,t:1527271846520};\\\", \\\"{x:1436,y:691,t:1527271846537};\\\", \\\"{x:1441,y:701,t:1527271846554};\\\", \\\"{x:1442,y:704,t:1527271846570};\\\", \\\"{x:1442,y:706,t:1527271846586};\\\", \\\"{x:1443,y:708,t:1527271846604};\\\", \\\"{x:1443,y:710,t:1527271846620};\\\", \\\"{x:1444,y:713,t:1527271846637};\\\", \\\"{x:1445,y:724,t:1527271846654};\\\", \\\"{x:1449,y:733,t:1527271846670};\\\", \\\"{x:1453,y:744,t:1527271846687};\\\", \\\"{x:1457,y:751,t:1527271846703};\\\", \\\"{x:1463,y:760,t:1527271846720};\\\", \\\"{x:1479,y:772,t:1527271846737};\\\", \\\"{x:1489,y:786,t:1527271846753};\\\", \\\"{x:1493,y:801,t:1527271846769};\\\", \\\"{x:1509,y:815,t:1527271846786};\\\", \\\"{x:1528,y:831,t:1527271846804};\\\", \\\"{x:1544,y:850,t:1527271846819};\\\", \\\"{x:1546,y:854,t:1527271846837};\\\", \\\"{x:1549,y:856,t:1527271846853};\\\", \\\"{x:1548,y:856,t:1527271847001};\\\", \\\"{x:1547,y:856,t:1527271847009};\\\", \\\"{x:1547,y:857,t:1527271847021};\\\", \\\"{x:1548,y:857,t:1527271847241};\\\", \\\"{x:1550,y:857,t:1527271847254};\\\", \\\"{x:1555,y:857,t:1527271847271};\\\", \\\"{x:1559,y:857,t:1527271847287};\\\", \\\"{x:1560,y:857,t:1527271847304};\\\", \\\"{x:1561,y:857,t:1527271847321};\\\", \\\"{x:1567,y:857,t:1527271847337};\\\", \\\"{x:1573,y:857,t:1527271847353};\\\", \\\"{x:1585,y:857,t:1527271847371};\\\", \\\"{x:1591,y:856,t:1527271847387};\\\", \\\"{x:1597,y:853,t:1527271847404};\\\", \\\"{x:1601,y:852,t:1527271847421};\\\", \\\"{x:1602,y:851,t:1527271847752};\\\", \\\"{x:1603,y:851,t:1527271847760};\\\", \\\"{x:1603,y:849,t:1527271847783};\\\", \\\"{x:1603,y:848,t:1527271847792};\\\", \\\"{x:1605,y:845,t:1527271847803};\\\", \\\"{x:1605,y:844,t:1527271847820};\\\", \\\"{x:1608,y:840,t:1527271847837};\\\", \\\"{x:1610,y:837,t:1527271847854};\\\", \\\"{x:1613,y:831,t:1527271847870};\\\", \\\"{x:1617,y:828,t:1527271847887};\\\", \\\"{x:1621,y:824,t:1527271847903};\\\", \\\"{x:1623,y:820,t:1527271847920};\\\", \\\"{x:1623,y:819,t:1527271847937};\\\", \\\"{x:1625,y:818,t:1527271847953};\\\", \\\"{x:1626,y:817,t:1527271848089};\\\", \\\"{x:1626,y:816,t:1527271848103};\\\", \\\"{x:1626,y:815,t:1527271851977};\\\", \\\"{x:1622,y:815,t:1527271851990};\\\", \\\"{x:1609,y:815,t:1527271852007};\\\", \\\"{x:1601,y:817,t:1527271852023};\\\", \\\"{x:1579,y:827,t:1527271852040};\\\", \\\"{x:1566,y:834,t:1527271852056};\\\", \\\"{x:1565,y:834,t:1527271852073};\\\", \\\"{x:1564,y:834,t:1527271852169};\\\", \\\"{x:1564,y:835,t:1527271852176};\\\", \\\"{x:1563,y:836,t:1527271852190};\\\", \\\"{x:1563,y:838,t:1527271852207};\\\", \\\"{x:1561,y:839,t:1527271852224};\\\", \\\"{x:1558,y:845,t:1527271852240};\\\", \\\"{x:1550,y:852,t:1527271852256};\\\", \\\"{x:1548,y:855,t:1527271852274};\\\", \\\"{x:1542,y:859,t:1527271852290};\\\", \\\"{x:1527,y:869,t:1527271852307};\\\", \\\"{x:1523,y:872,t:1527271852324};\\\", \\\"{x:1515,y:879,t:1527271852340};\\\", \\\"{x:1505,y:884,t:1527271852358};\\\", \\\"{x:1502,y:884,t:1527271852374};\\\", \\\"{x:1500,y:886,t:1527271852673};\\\", \\\"{x:1486,y:906,t:1527271852690};\\\", \\\"{x:1478,y:919,t:1527271852707};\\\", \\\"{x:1476,y:922,t:1527271852724};\\\", \\\"{x:1475,y:924,t:1527271852741};\\\", \\\"{x:1474,y:924,t:1527271852849};\\\", \\\"{x:1473,y:925,t:1527271852872};\\\", \\\"{x:1473,y:926,t:1527271852881};\\\", \\\"{x:1472,y:927,t:1527271852896};\\\", \\\"{x:1471,y:928,t:1527271852928};\\\", \\\"{x:1467,y:931,t:1527271853209};\\\", \\\"{x:1457,y:935,t:1527271853224};\\\", \\\"{x:1445,y:936,t:1527271853241};\\\", \\\"{x:1440,y:941,t:1527271853257};\\\", \\\"{x:1439,y:941,t:1527271853274};\\\", \\\"{x:1438,y:941,t:1527271853313};\\\", \\\"{x:1439,y:941,t:1527271853368};\\\", \\\"{x:1442,y:941,t:1527271853376};\\\", \\\"{x:1443,y:940,t:1527271853392};\\\", \\\"{x:1446,y:936,t:1527271853408};\\\", \\\"{x:1447,y:934,t:1527271853473};\\\", \\\"{x:1449,y:930,t:1527271853491};\\\", \\\"{x:1451,y:927,t:1527271853508};\\\", \\\"{x:1454,y:923,t:1527271853524};\\\", \\\"{x:1457,y:922,t:1527271853541};\\\", \\\"{x:1457,y:921,t:1527271853558};\\\", \\\"{x:1457,y:920,t:1527271853576};\\\", \\\"{x:1457,y:919,t:1527271853591};\\\", \\\"{x:1457,y:915,t:1527271853608};\\\", \\\"{x:1455,y:912,t:1527271853624};\\\", \\\"{x:1451,y:904,t:1527271853640};\\\", \\\"{x:1447,y:897,t:1527271853658};\\\", \\\"{x:1440,y:886,t:1527271853675};\\\", \\\"{x:1439,y:885,t:1527271853691};\\\", \\\"{x:1431,y:872,t:1527271853709};\\\", \\\"{x:1428,y:865,t:1527271853724};\\\", \\\"{x:1424,y:855,t:1527271853741};\\\", \\\"{x:1422,y:848,t:1527271853758};\\\", \\\"{x:1422,y:847,t:1527271853774};\\\", \\\"{x:1422,y:842,t:1527271853791};\\\", \\\"{x:1425,y:837,t:1527271853808};\\\", \\\"{x:1426,y:835,t:1527271853824};\\\", \\\"{x:1427,y:833,t:1527271853857};\\\", \\\"{x:1427,y:832,t:1527271853874};\\\", \\\"{x:1427,y:831,t:1527271853891};\\\", \\\"{x:1427,y:829,t:1527271853908};\\\", \\\"{x:1428,y:823,t:1527271853926};\\\", \\\"{x:1429,y:817,t:1527271853941};\\\", \\\"{x:1430,y:812,t:1527271853958};\\\", \\\"{x:1431,y:810,t:1527271853975};\\\", \\\"{x:1432,y:809,t:1527271853992};\\\", \\\"{x:1433,y:808,t:1527271854008};\\\", \\\"{x:1434,y:807,t:1527271854032};\\\", \\\"{x:1434,y:806,t:1527271854080};\\\", \\\"{x:1434,y:805,t:1527271854091};\\\", \\\"{x:1434,y:804,t:1527271854108};\\\", \\\"{x:1434,y:803,t:1527271854169};\\\", \\\"{x:1434,y:802,t:1527271854176};\\\", \\\"{x:1435,y:801,t:1527271854281};\\\", \\\"{x:1435,y:799,t:1527271854296};\\\", \\\"{x:1435,y:797,t:1527271854309};\\\", \\\"{x:1435,y:796,t:1527271854325};\\\", \\\"{x:1435,y:795,t:1527271854341};\\\", \\\"{x:1435,y:793,t:1527271854358};\\\", \\\"{x:1435,y:792,t:1527271854374};\\\", \\\"{x:1435,y:790,t:1527271854391};\\\", \\\"{x:1435,y:788,t:1527271854407};\\\", \\\"{x:1435,y:787,t:1527271856233};\\\", \\\"{x:1434,y:788,t:1527271856345};\\\", \\\"{x:1428,y:787,t:1527271856359};\\\", \\\"{x:1418,y:787,t:1527271856376};\\\", \\\"{x:1407,y:791,t:1527271856393};\\\", \\\"{x:1399,y:794,t:1527271856409};\\\", \\\"{x:1397,y:795,t:1527271856433};\\\", \\\"{x:1395,y:796,t:1527271856465};\\\", \\\"{x:1394,y:798,t:1527271856477};\\\", \\\"{x:1390,y:799,t:1527271856493};\\\", \\\"{x:1387,y:801,t:1527271856508};\\\", \\\"{x:1377,y:802,t:1527271856526};\\\", \\\"{x:1366,y:802,t:1527271856542};\\\", \\\"{x:1363,y:802,t:1527271856558};\\\", \\\"{x:1357,y:802,t:1527271856576};\\\", \\\"{x:1356,y:802,t:1527271856593};\\\", \\\"{x:1353,y:802,t:1527271856704};\\\", \\\"{x:1352,y:802,t:1527271856720};\\\", \\\"{x:1351,y:802,t:1527271856784};\\\", \\\"{x:1350,y:803,t:1527271856833};\\\", \\\"{x:1350,y:804,t:1527271856865};\\\", \\\"{x:1350,y:805,t:1527271856969};\\\", \\\"{x:1351,y:806,t:1527271856976};\\\", \\\"{x:1355,y:809,t:1527271856993};\\\", \\\"{x:1358,y:816,t:1527271857010};\\\", \\\"{x:1361,y:817,t:1527271857026};\\\", \\\"{x:1368,y:823,t:1527271857043};\\\", \\\"{x:1376,y:830,t:1527271857060};\\\", \\\"{x:1384,y:838,t:1527271857076};\\\", \\\"{x:1392,y:847,t:1527271857092};\\\", \\\"{x:1394,y:851,t:1527271857109};\\\", \\\"{x:1399,y:857,t:1527271857125};\\\", \\\"{x:1401,y:861,t:1527271857143};\\\", \\\"{x:1403,y:862,t:1527271857160};\\\", \\\"{x:1404,y:863,t:1527271857185};\\\", \\\"{x:1404,y:864,t:1527271857194};\\\", \\\"{x:1404,y:865,t:1527271857225};\\\", \\\"{x:1406,y:867,t:1527271857256};\\\", \\\"{x:1407,y:869,t:1527271857272};\\\", \\\"{x:1409,y:871,t:1527271857288};\\\", \\\"{x:1410,y:872,t:1527271857313};\\\", \\\"{x:1411,y:873,t:1527271857327};\\\", \\\"{x:1412,y:874,t:1527271857343};\\\", \\\"{x:1413,y:874,t:1527271857368};\\\", \\\"{x:1415,y:874,t:1527271857383};\\\", \\\"{x:1416,y:874,t:1527271857416};\\\", \\\"{x:1422,y:874,t:1527271857426};\\\", \\\"{x:1429,y:868,t:1527271857442};\\\", \\\"{x:1436,y:866,t:1527271857459};\\\", \\\"{x:1450,y:862,t:1527271857477};\\\", \\\"{x:1457,y:859,t:1527271857492};\\\", \\\"{x:1467,y:854,t:1527271857510};\\\", \\\"{x:1476,y:852,t:1527271857526};\\\", \\\"{x:1484,y:849,t:1527271857543};\\\", \\\"{x:1488,y:847,t:1527271857559};\\\", \\\"{x:1489,y:847,t:1527271857577};\\\", \\\"{x:1490,y:846,t:1527271857592};\\\", \\\"{x:1490,y:845,t:1527271857712};\\\", \\\"{x:1490,y:843,t:1527271857727};\\\", \\\"{x:1490,y:842,t:1527271857743};\\\", \\\"{x:1484,y:835,t:1527271857759};\\\", \\\"{x:1482,y:832,t:1527271857776};\\\", \\\"{x:1480,y:830,t:1527271857793};\\\", \\\"{x:1480,y:828,t:1527271857809};\\\", \\\"{x:1480,y:827,t:1527271857826};\\\", \\\"{x:1480,y:825,t:1527271857843};\\\", \\\"{x:1480,y:823,t:1527271857864};\\\", \\\"{x:1480,y:822,t:1527271857879};\\\", \\\"{x:1479,y:821,t:1527271857893};\\\", \\\"{x:1479,y:822,t:1527271858224};\\\", \\\"{x:1479,y:824,t:1527271858552};\\\", \\\"{x:1479,y:825,t:1527271858567};\\\", \\\"{x:1479,y:826,t:1527271858593};\\\", \\\"{x:1480,y:827,t:1527271858610};\\\", \\\"{x:1481,y:829,t:1527271858752};\\\", \\\"{x:1481,y:830,t:1527271859567};\\\", \\\"{x:1481,y:831,t:1527271859583};\\\", \\\"{x:1481,y:832,t:1527271859671};\\\", \\\"{x:1481,y:833,t:1527271859679};\\\", \\\"{x:1480,y:832,t:1527271859968};\\\", \\\"{x:1479,y:831,t:1527271859979};\\\", \\\"{x:1476,y:826,t:1527271859996};\\\", \\\"{x:1470,y:820,t:1527271860011};\\\", \\\"{x:1461,y:810,t:1527271860028};\\\", \\\"{x:1456,y:804,t:1527271860046};\\\", \\\"{x:1453,y:801,t:1527271860061};\\\", \\\"{x:1451,y:800,t:1527271860079};\\\", \\\"{x:1451,y:797,t:1527271860095};\\\", \\\"{x:1449,y:791,t:1527271860111};\\\", \\\"{x:1449,y:790,t:1527271860128};\\\", \\\"{x:1449,y:787,t:1527271860145};\\\", \\\"{x:1448,y:786,t:1527271860162};\\\", \\\"{x:1448,y:785,t:1527271860178};\\\", \\\"{x:1448,y:783,t:1527271860208};\\\", \\\"{x:1448,y:782,t:1527271860232};\\\", \\\"{x:1448,y:781,t:1527271860248};\\\", \\\"{x:1448,y:780,t:1527271860263};\\\", \\\"{x:1449,y:778,t:1527271860279};\\\", \\\"{x:1451,y:775,t:1527271860295};\\\", \\\"{x:1452,y:769,t:1527271860312};\\\", \\\"{x:1452,y:766,t:1527271860328};\\\", \\\"{x:1452,y:761,t:1527271860345};\\\", \\\"{x:1452,y:759,t:1527271860362};\\\", \\\"{x:1452,y:758,t:1527271860393};\\\", \\\"{x:1450,y:757,t:1527271860625};\\\", \\\"{x:1447,y:759,t:1527271860633};\\\", \\\"{x:1446,y:760,t:1527271860645};\\\", \\\"{x:1445,y:761,t:1527271860663};\\\", \\\"{x:1445,y:763,t:1527271860689};\\\", \\\"{x:1444,y:763,t:1527271862056};\\\", \\\"{x:1443,y:761,t:1527271862063};\\\", \\\"{x:1441,y:759,t:1527271862078};\\\", \\\"{x:1438,y:752,t:1527271862095};\\\", \\\"{x:1436,y:752,t:1527271862112};\\\", \\\"{x:1436,y:749,t:1527271862129};\\\", \\\"{x:1435,y:748,t:1527271862146};\\\", \\\"{x:1435,y:746,t:1527271862162};\\\", \\\"{x:1435,y:745,t:1527271862178};\\\", \\\"{x:1436,y:742,t:1527271862195};\\\", \\\"{x:1436,y:740,t:1527271862212};\\\", \\\"{x:1436,y:737,t:1527271862228};\\\", \\\"{x:1436,y:733,t:1527271862246};\\\", \\\"{x:1436,y:729,t:1527271862262};\\\", \\\"{x:1436,y:727,t:1527271862278};\\\", \\\"{x:1436,y:723,t:1527271862295};\\\", \\\"{x:1436,y:721,t:1527271862313};\\\", \\\"{x:1436,y:717,t:1527271862330};\\\", \\\"{x:1436,y:711,t:1527271862346};\\\", \\\"{x:1436,y:705,t:1527271862362};\\\", \\\"{x:1436,y:703,t:1527271862380};\\\", \\\"{x:1433,y:700,t:1527271862395};\\\", \\\"{x:1430,y:697,t:1527271862412};\\\", \\\"{x:1428,y:696,t:1527271862429};\\\", \\\"{x:1426,y:696,t:1527271862445};\\\", \\\"{x:1425,y:696,t:1527271862719};\\\", \\\"{x:1425,y:695,t:1527271862729};\\\", \\\"{x:1423,y:695,t:1527271862746};\\\", \\\"{x:1422,y:695,t:1527271862919};\\\", \\\"{x:1420,y:695,t:1527271862930};\\\", \\\"{x:1415,y:696,t:1527271862946};\\\", \\\"{x:1415,y:698,t:1527271864711};\\\", \\\"{x:1415,y:699,t:1527271864775};\\\", \\\"{x:1415,y:700,t:1527271864783};\\\", \\\"{x:1415,y:701,t:1527271864888};\\\", \\\"{x:1415,y:702,t:1527271864898};\\\", \\\"{x:1415,y:703,t:1527271864919};\\\", \\\"{x:1415,y:704,t:1527271864930};\\\", \\\"{x:1415,y:706,t:1527271864947};\\\", \\\"{x:1414,y:708,t:1527271865000};\\\", \\\"{x:1414,y:710,t:1527271865055};\\\", \\\"{x:1415,y:712,t:1527271865103};\\\", \\\"{x:1417,y:713,t:1527271865127};\\\", \\\"{x:1418,y:714,t:1527271865135};\\\", \\\"{x:1419,y:715,t:1527271865148};\\\", \\\"{x:1419,y:716,t:1527271865163};\\\", \\\"{x:1424,y:722,t:1527271865207};\\\", \\\"{x:1428,y:724,t:1527271865215};\\\", \\\"{x:1434,y:730,t:1527271865230};\\\", \\\"{x:1446,y:739,t:1527271865247};\\\", \\\"{x:1451,y:743,t:1527271865264};\\\", \\\"{x:1453,y:746,t:1527271865281};\\\", \\\"{x:1455,y:749,t:1527271865299};\\\", \\\"{x:1457,y:752,t:1527271865315};\\\", \\\"{x:1459,y:757,t:1527271865330};\\\", \\\"{x:1461,y:760,t:1527271865348};\\\", \\\"{x:1462,y:763,t:1527271865365};\\\", \\\"{x:1465,y:767,t:1527271865381};\\\", \\\"{x:1466,y:769,t:1527271865398};\\\", \\\"{x:1467,y:770,t:1527271865414};\\\", \\\"{x:1468,y:771,t:1527271865430};\\\", \\\"{x:1468,y:772,t:1527271865448};\\\", \\\"{x:1469,y:776,t:1527271865471};\\\", \\\"{x:1469,y:777,t:1527271865480};\\\", \\\"{x:1469,y:779,t:1527271865498};\\\", \\\"{x:1470,y:779,t:1527271865514};\\\", \\\"{x:1470,y:780,t:1527271865615};\\\", \\\"{x:1470,y:782,t:1527271865631};\\\", \\\"{x:1471,y:788,t:1527271865647};\\\", \\\"{x:1475,y:793,t:1527271865665};\\\", \\\"{x:1477,y:798,t:1527271865681};\\\", \\\"{x:1477,y:799,t:1527271865697};\\\", \\\"{x:1477,y:801,t:1527271865714};\\\", \\\"{x:1477,y:802,t:1527271865730};\\\", \\\"{x:1477,y:805,t:1527271865748};\\\", \\\"{x:1477,y:806,t:1527271865765};\\\", \\\"{x:1477,y:808,t:1527271865782};\\\", \\\"{x:1477,y:809,t:1527271865799};\\\", \\\"{x:1477,y:810,t:1527271865814};\\\", \\\"{x:1477,y:811,t:1527271865831};\\\", \\\"{x:1476,y:812,t:1527271865855};\\\", \\\"{x:1475,y:813,t:1527271865871};\\\", \\\"{x:1475,y:814,t:1527271865881};\\\", \\\"{x:1473,y:816,t:1527271865898};\\\", \\\"{x:1469,y:817,t:1527271865915};\\\", \\\"{x:1468,y:818,t:1527271865932};\\\", \\\"{x:1462,y:819,t:1527271865947};\\\", \\\"{x:1456,y:819,t:1527271865964};\\\", \\\"{x:1445,y:821,t:1527271865982};\\\", \\\"{x:1434,y:821,t:1527271865997};\\\", \\\"{x:1423,y:822,t:1527271866015};\\\", \\\"{x:1411,y:827,t:1527271866031};\\\", \\\"{x:1405,y:831,t:1527271866048};\\\", \\\"{x:1401,y:833,t:1527271866065};\\\", \\\"{x:1398,y:835,t:1527271866082};\\\", \\\"{x:1395,y:838,t:1527271866098};\\\", \\\"{x:1393,y:840,t:1527271866115};\\\", \\\"{x:1391,y:840,t:1527271866132};\\\", \\\"{x:1389,y:841,t:1527271866148};\\\", \\\"{x:1390,y:840,t:1527271866463};\\\", \\\"{x:1391,y:839,t:1527271866471};\\\", \\\"{x:1391,y:838,t:1527271866481};\\\", \\\"{x:1394,y:835,t:1527271866498};\\\", \\\"{x:1395,y:832,t:1527271866515};\\\", \\\"{x:1397,y:827,t:1527271866532};\\\", \\\"{x:1397,y:819,t:1527271866549};\\\", \\\"{x:1397,y:810,t:1527271866565};\\\", \\\"{x:1398,y:802,t:1527271866581};\\\", \\\"{x:1401,y:795,t:1527271866599};\\\", \\\"{x:1404,y:784,t:1527271866615};\\\", \\\"{x:1406,y:782,t:1527271866631};\\\", \\\"{x:1407,y:777,t:1527271866648};\\\", \\\"{x:1407,y:776,t:1527271866665};\\\", \\\"{x:1409,y:773,t:1527271866682};\\\", \\\"{x:1409,y:772,t:1527271866711};\\\", \\\"{x:1410,y:770,t:1527271866719};\\\", \\\"{x:1410,y:768,t:1527271866807};\\\", \\\"{x:1410,y:766,t:1527271866823};\\\", \\\"{x:1410,y:765,t:1527271866831};\\\", \\\"{x:1410,y:764,t:1527271866848};\\\", \\\"{x:1411,y:763,t:1527271866872};\\\", \\\"{x:1411,y:762,t:1527271866882};\\\", \\\"{x:1412,y:762,t:1527271869704};\\\", \\\"{x:1413,y:763,t:1527271869717};\\\", \\\"{x:1420,y:768,t:1527271869734};\\\", \\\"{x:1426,y:773,t:1527271869750};\\\", \\\"{x:1437,y:780,t:1527271869766};\\\", \\\"{x:1438,y:781,t:1527271869784};\\\", \\\"{x:1440,y:783,t:1527271869800};\\\", \\\"{x:1443,y:785,t:1527271869817};\\\", \\\"{x:1443,y:789,t:1527271869839};\\\", \\\"{x:1444,y:789,t:1527271869855};\\\", \\\"{x:1445,y:790,t:1527271869867};\\\", \\\"{x:1446,y:792,t:1527271869884};\\\", \\\"{x:1446,y:793,t:1527271869901};\\\", \\\"{x:1446,y:794,t:1527271869919};\\\", \\\"{x:1448,y:796,t:1527271869943};\\\", \\\"{x:1448,y:799,t:1527271869983};\\\", \\\"{x:1449,y:801,t:1527271870007};\\\", \\\"{x:1450,y:801,t:1527271870031};\\\", \\\"{x:1450,y:802,t:1527271870038};\\\", \\\"{x:1450,y:804,t:1527271870055};\\\", \\\"{x:1451,y:804,t:1527271870067};\\\", \\\"{x:1452,y:806,t:1527271870084};\\\", \\\"{x:1452,y:808,t:1527271870101};\\\", \\\"{x:1454,y:810,t:1527271870117};\\\", \\\"{x:1455,y:813,t:1527271870133};\\\", \\\"{x:1457,y:814,t:1527271870150};\\\", \\\"{x:1457,y:815,t:1527271870191};\\\", \\\"{x:1457,y:816,t:1527271870201};\\\", \\\"{x:1445,y:816,t:1527271870495};\\\", \\\"{x:1410,y:807,t:1527271870503};\\\", \\\"{x:1339,y:787,t:1527271870518};\\\", \\\"{x:1276,y:769,t:1527271870534};\\\", \\\"{x:1171,y:742,t:1527271870551};\\\", \\\"{x:1069,y:734,t:1527271870567};\\\", \\\"{x:1051,y:733,t:1527271870584};\\\", \\\"{x:1049,y:732,t:1527271870601};\\\", \\\"{x:1047,y:732,t:1527271870664};\\\", \\\"{x:1045,y:732,t:1527271870672};\\\", \\\"{x:1043,y:732,t:1527271870684};\\\", \\\"{x:1040,y:732,t:1527271870701};\\\", \\\"{x:1038,y:733,t:1527271870718};\\\", \\\"{x:1035,y:736,t:1527271870735};\\\", \\\"{x:1018,y:738,t:1527271870751};\\\", \\\"{x:994,y:743,t:1527271870768};\\\", \\\"{x:992,y:743,t:1527271870791};\\\", \\\"{x:986,y:743,t:1527271870801};\\\", \\\"{x:985,y:739,t:1527271870818};\\\", \\\"{x:962,y:732,t:1527271870835};\\\", \\\"{x:914,y:716,t:1527271870852};\\\", \\\"{x:907,y:709,t:1527271870869};\\\", \\\"{x:899,y:696,t:1527271870884};\\\", \\\"{x:887,y:691,t:1527271870902};\\\", \\\"{x:884,y:690,t:1527271870936};\\\", \\\"{x:882,y:688,t:1527271870951};\\\", \\\"{x:882,y:685,t:1527271870968};\\\", \\\"{x:882,y:682,t:1527271870984};\\\", \\\"{x:875,y:677,t:1527271871001};\\\", \\\"{x:862,y:667,t:1527271871018};\\\", \\\"{x:849,y:651,t:1527271871034};\\\", \\\"{x:845,y:646,t:1527271871051};\\\", \\\"{x:828,y:635,t:1527271871068};\\\", \\\"{x:804,y:631,t:1527271871085};\\\", \\\"{x:786,y:624,t:1527271871101};\\\", \\\"{x:782,y:624,t:1527271871118};\\\", \\\"{x:772,y:624,t:1527271871191};\\\", \\\"{x:768,y:624,t:1527271871201};\\\", \\\"{x:760,y:624,t:1527271871218};\\\", \\\"{x:756,y:624,t:1527271871240};\\\", \\\"{x:755,y:624,t:1527271871251};\\\", \\\"{x:731,y:624,t:1527271871268};\\\", \\\"{x:685,y:624,t:1527271871286};\\\", \\\"{x:602,y:607,t:1527271871301};\\\", \\\"{x:588,y:603,t:1527271871318};\\\", \\\"{x:573,y:591,t:1527271871341};\\\", \\\"{x:561,y:586,t:1527271871358};\\\", \\\"{x:555,y:580,t:1527271871375};\\\", \\\"{x:553,y:579,t:1527271871391};\\\", \\\"{x:553,y:578,t:1527271871487};\\\", \\\"{x:555,y:577,t:1527271871495};\\\", \\\"{x:558,y:577,t:1527271871551};\\\", \\\"{x:561,y:577,t:1527271871559};\\\", \\\"{x:564,y:577,t:1527271871574};\\\", \\\"{x:566,y:578,t:1527271871591};\\\", \\\"{x:568,y:582,t:1527271871656};\\\", \\\"{x:576,y:591,t:1527271871674};\\\", \\\"{x:580,y:599,t:1527271871692};\\\", \\\"{x:585,y:608,t:1527271871708};\\\", \\\"{x:593,y:615,t:1527271871725};\\\", \\\"{x:597,y:618,t:1527271871741};\\\", \\\"{x:598,y:618,t:1527271871839};\\\", \\\"{x:599,y:618,t:1527271871855};\\\", \\\"{x:600,y:618,t:1527271871863};\\\", \\\"{x:603,y:618,t:1527271871879};\\\", \\\"{x:604,y:617,t:1527271871892};\\\", \\\"{x:604,y:616,t:1527271871908};\\\", \\\"{x:605,y:613,t:1527271871925};\\\", \\\"{x:607,y:610,t:1527271871943};\\\", \\\"{x:607,y:609,t:1527271871959};\\\", \\\"{x:608,y:609,t:1527271871974};\\\", \\\"{x:610,y:607,t:1527271871992};\\\", \\\"{x:610,y:606,t:1527271872009};\\\", \\\"{x:612,y:606,t:1527271872025};\\\", \\\"{x:609,y:613,t:1527271906449};\\\", \\\"{x:607,y:627,t:1527271906466};\\\", \\\"{x:602,y:638,t:1527271906483};\\\", \\\"{x:596,y:646,t:1527271906499};\\\", \\\"{x:593,y:652,t:1527271906516};\\\", \\\"{x:589,y:656,t:1527271906532};\\\", \\\"{x:589,y:660,t:1527271906556};\\\", \\\"{x:586,y:665,t:1527271906572};\\\", \\\"{x:585,y:672,t:1527271906588};\\\", \\\"{x:583,y:675,t:1527271906605};\\\", \\\"{x:579,y:679,t:1527271906622};\\\", \\\"{x:577,y:683,t:1527271906639};\\\", \\\"{x:574,y:686,t:1527271906656};\\\", \\\"{x:571,y:690,t:1527271906672};\\\", \\\"{x:568,y:693,t:1527271906688};\\\", \\\"{x:563,y:698,t:1527271906706};\\\", \\\"{x:561,y:701,t:1527271906722};\\\", \\\"{x:560,y:702,t:1527271906739};\\\", \\\"{x:559,y:703,t:1527271906769};\\\", \\\"{x:556,y:704,t:1527271906776};\\\", \\\"{x:553,y:705,t:1527271906788};\\\", \\\"{x:550,y:707,t:1527271906805};\\\", \\\"{x:549,y:707,t:1527271906821};\\\", \\\"{x:547,y:708,t:1527271906865};\\\", \\\"{x:543,y:708,t:1527271906873};\\\", \\\"{x:542,y:708,t:1527271906888};\\\", \\\"{x:534,y:709,t:1527271906906};\\\", \\\"{x:530,y:710,t:1527271906922};\\\", \\\"{x:529,y:711,t:1527271906939};\\\" ] }, { \\\"rt\\\": 131547, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 457508, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-U -U -F -I -03 PM-03 PM-03 PM-03 PM-03 PM-03 PM-02 PM-4-X \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:531,y:710,t:1527271910169};\\\", \\\"{x:538,y:710,t:1527271910177};\\\", \\\"{x:545,y:710,t:1527271910192};\\\", \\\"{x:547,y:710,t:1527271910207};\\\", \\\"{x:547,y:711,t:1527271910232};\\\", \\\"{x:542,y:715,t:1527271910242};\\\", \\\"{x:534,y:717,t:1527271910257};\\\", \\\"{x:508,y:724,t:1527271910275};\\\", \\\"{x:476,y:730,t:1527271910292};\\\", \\\"{x:441,y:736,t:1527271910309};\\\", \\\"{x:396,y:736,t:1527271910325};\\\", \\\"{x:372,y:736,t:1527271910342};\\\", \\\"{x:371,y:736,t:1527271910359};\\\", \\\"{x:375,y:736,t:1527271910375};\\\", \\\"{x:398,y:735,t:1527271910391};\\\", \\\"{x:520,y:755,t:1527271910409};\\\", \\\"{x:671,y:787,t:1527271910425};\\\", \\\"{x:831,y:814,t:1527271910442};\\\", \\\"{x:944,y:840,t:1527271910459};\\\", \\\"{x:1026,y:848,t:1527271910475};\\\", \\\"{x:1045,y:846,t:1527271910492};\\\", \\\"{x:1052,y:846,t:1527271910509};\\\", \\\"{x:1045,y:843,t:1527271910561};\\\", \\\"{x:1038,y:840,t:1527271910575};\\\", \\\"{x:1027,y:830,t:1527271910592};\\\", \\\"{x:879,y:785,t:1527271910609};\\\", \\\"{x:735,y:741,t:1527271910625};\\\", \\\"{x:624,y:713,t:1527271910642};\\\", \\\"{x:506,y:682,t:1527271910659};\\\", \\\"{x:432,y:655,t:1527271910675};\\\", \\\"{x:411,y:644,t:1527271910692};\\\", \\\"{x:410,y:643,t:1527271910709};\\\", \\\"{x:410,y:641,t:1527271910724};\\\", \\\"{x:410,y:640,t:1527271910742};\\\", \\\"{x:411,y:637,t:1527271910759};\\\", \\\"{x:417,y:633,t:1527271910775};\\\", \\\"{x:417,y:632,t:1527271910824};\\\", \\\"{x:419,y:631,t:1527271910832};\\\", \\\"{x:423,y:629,t:1527271910841};\\\", \\\"{x:430,y:622,t:1527271910859};\\\", \\\"{x:432,y:620,t:1527271910874};\\\", \\\"{x:433,y:619,t:1527271910891};\\\", \\\"{x:427,y:618,t:1527271911793};\\\", \\\"{x:422,y:617,t:1527271911810};\\\", \\\"{x:421,y:617,t:1527271912193};\\\", \\\"{x:425,y:617,t:1527271912210};\\\", \\\"{x:429,y:617,t:1527271912228};\\\", \\\"{x:440,y:616,t:1527271912243};\\\", \\\"{x:468,y:616,t:1527271912261};\\\", \\\"{x:507,y:616,t:1527271912280};\\\", \\\"{x:557,y:620,t:1527271912293};\\\", \\\"{x:667,y:627,t:1527271912311};\\\", \\\"{x:790,y:634,t:1527271912327};\\\", \\\"{x:906,y:650,t:1527271912343};\\\", \\\"{x:986,y:661,t:1527271912361};\\\", \\\"{x:1142,y:666,t:1527271912377};\\\", \\\"{x:1267,y:683,t:1527271912393};\\\", \\\"{x:1396,y:715,t:1527271912410};\\\", \\\"{x:1486,y:748,t:1527271912427};\\\", \\\"{x:1524,y:770,t:1527271912443};\\\", \\\"{x:1543,y:786,t:1527271912460};\\\", \\\"{x:1555,y:796,t:1527271912477};\\\", \\\"{x:1558,y:800,t:1527271912494};\\\", \\\"{x:1561,y:804,t:1527271912510};\\\", \\\"{x:1561,y:809,t:1527271912528};\\\", \\\"{x:1561,y:811,t:1527271912544};\\\", \\\"{x:1561,y:812,t:1527271912610};\\\", \\\"{x:1560,y:812,t:1527271912634};\\\", \\\"{x:1557,y:813,t:1527271912645};\\\", \\\"{x:1555,y:813,t:1527271912666};\\\", \\\"{x:1554,y:814,t:1527271912682};\\\", \\\"{x:1551,y:814,t:1527271912706};\\\", \\\"{x:1548,y:814,t:1527271912714};\\\", \\\"{x:1547,y:814,t:1527271912727};\\\", \\\"{x:1542,y:814,t:1527271912744};\\\", \\\"{x:1535,y:814,t:1527271912761};\\\", \\\"{x:1518,y:815,t:1527271912778};\\\", \\\"{x:1501,y:820,t:1527271912795};\\\", \\\"{x:1486,y:826,t:1527271912811};\\\", \\\"{x:1474,y:831,t:1527271912828};\\\", \\\"{x:1468,y:835,t:1527271912845};\\\", \\\"{x:1463,y:840,t:1527271912861};\\\", \\\"{x:1447,y:844,t:1527271912878};\\\", \\\"{x:1433,y:850,t:1527271912894};\\\", \\\"{x:1429,y:852,t:1527271912911};\\\", \\\"{x:1426,y:852,t:1527271912928};\\\", \\\"{x:1425,y:853,t:1527271912945};\\\", \\\"{x:1423,y:853,t:1527271912961};\\\", \\\"{x:1423,y:855,t:1527271912978};\\\", \\\"{x:1422,y:855,t:1527271913106};\\\", \\\"{x:1416,y:860,t:1527271913179};\\\", \\\"{x:1406,y:861,t:1527271913195};\\\", \\\"{x:1397,y:866,t:1527271913212};\\\", \\\"{x:1395,y:867,t:1527271913227};\\\", \\\"{x:1393,y:867,t:1527271913245};\\\", \\\"{x:1390,y:869,t:1527271913262};\\\", \\\"{x:1388,y:869,t:1527271913305};\\\", \\\"{x:1388,y:870,t:1527271913346};\\\", \\\"{x:1388,y:871,t:1527271913362};\\\", \\\"{x:1388,y:873,t:1527271913378};\\\", \\\"{x:1388,y:875,t:1527271913395};\\\", \\\"{x:1388,y:878,t:1527271913412};\\\", \\\"{x:1389,y:882,t:1527271913428};\\\", \\\"{x:1393,y:887,t:1527271913444};\\\", \\\"{x:1397,y:891,t:1527271913462};\\\", \\\"{x:1399,y:893,t:1527271913478};\\\", \\\"{x:1400,y:895,t:1527271913495};\\\", \\\"{x:1400,y:896,t:1527271913530};\\\", \\\"{x:1401,y:898,t:1527271913554};\\\", \\\"{x:1402,y:899,t:1527271913570};\\\", \\\"{x:1402,y:900,t:1527271913586};\\\", \\\"{x:1403,y:901,t:1527271913595};\\\", \\\"{x:1403,y:902,t:1527271913634};\\\", \\\"{x:1403,y:903,t:1527271913650};\\\", \\\"{x:1404,y:904,t:1527271913850};\\\", \\\"{x:1407,y:904,t:1527271913866};\\\", \\\"{x:1410,y:904,t:1527271913879};\\\", \\\"{x:1411,y:904,t:1527271913896};\\\", \\\"{x:1415,y:902,t:1527271913912};\\\", \\\"{x:1418,y:901,t:1527271913929};\\\", \\\"{x:1424,y:895,t:1527271913946};\\\", \\\"{x:1435,y:883,t:1527271913962};\\\", \\\"{x:1448,y:871,t:1527271913979};\\\", \\\"{x:1458,y:862,t:1527271913996};\\\", \\\"{x:1464,y:857,t:1527271914012};\\\", \\\"{x:1468,y:853,t:1527271914029};\\\", \\\"{x:1470,y:851,t:1527271914046};\\\", \\\"{x:1471,y:849,t:1527271914062};\\\", \\\"{x:1471,y:847,t:1527271914079};\\\", \\\"{x:1473,y:844,t:1527271914096};\\\", \\\"{x:1474,y:840,t:1527271914112};\\\", \\\"{x:1476,y:832,t:1527271914132};\\\", \\\"{x:1480,y:827,t:1527271914144};\\\", \\\"{x:1481,y:823,t:1527271914162};\\\", \\\"{x:1481,y:822,t:1527271914730};\\\", \\\"{x:1481,y:821,t:1527271914746};\\\", \\\"{x:1481,y:820,t:1527271914763};\\\", \\\"{x:1481,y:819,t:1527271914780};\\\", \\\"{x:1481,y:818,t:1527271914796};\\\", \\\"{x:1481,y:816,t:1527271914812};\\\", \\\"{x:1481,y:815,t:1527271914830};\\\", \\\"{x:1481,y:814,t:1527271914846};\\\", \\\"{x:1482,y:812,t:1527271914862};\\\", \\\"{x:1485,y:810,t:1527271914881};\\\", \\\"{x:1486,y:808,t:1527271914895};\\\", \\\"{x:1486,y:806,t:1527271914913};\\\", \\\"{x:1486,y:803,t:1527271914930};\\\", \\\"{x:1486,y:802,t:1527271914946};\\\", \\\"{x:1486,y:801,t:1527271915106};\\\", \\\"{x:1486,y:800,t:1527271915131};\\\", \\\"{x:1483,y:796,t:1527271915146};\\\", \\\"{x:1480,y:794,t:1527271915163};\\\", \\\"{x:1470,y:789,t:1527271915180};\\\", \\\"{x:1466,y:787,t:1527271915197};\\\", \\\"{x:1461,y:783,t:1527271915213};\\\", \\\"{x:1452,y:781,t:1527271915230};\\\", \\\"{x:1445,y:778,t:1527271915247};\\\", \\\"{x:1442,y:778,t:1527271915263};\\\", \\\"{x:1440,y:778,t:1527271915280};\\\", \\\"{x:1437,y:778,t:1527271915297};\\\", \\\"{x:1434,y:777,t:1527271915313};\\\", \\\"{x:1433,y:777,t:1527271915330};\\\", \\\"{x:1429,y:777,t:1527271915347};\\\", \\\"{x:1425,y:776,t:1527271915363};\\\", \\\"{x:1413,y:769,t:1527271915380};\\\", \\\"{x:1395,y:760,t:1527271915397};\\\", \\\"{x:1381,y:748,t:1527271915413};\\\", \\\"{x:1373,y:737,t:1527271915431};\\\", \\\"{x:1365,y:724,t:1527271915447};\\\", \\\"{x:1357,y:699,t:1527271915463};\\\", \\\"{x:1346,y:654,t:1527271915479};\\\", \\\"{x:1339,y:627,t:1527271915497};\\\", \\\"{x:1338,y:618,t:1527271915513};\\\", \\\"{x:1338,y:611,t:1527271915530};\\\", \\\"{x:1340,y:605,t:1527271915546};\\\", \\\"{x:1342,y:603,t:1527271915594};\\\", \\\"{x:1343,y:601,t:1527271915602};\\\", \\\"{x:1343,y:599,t:1527271915614};\\\", \\\"{x:1344,y:594,t:1527271915630};\\\", \\\"{x:1344,y:587,t:1527271915647};\\\", \\\"{x:1344,y:585,t:1527271915664};\\\", \\\"{x:1344,y:583,t:1527271915679};\\\", \\\"{x:1344,y:580,t:1527271915697};\\\", \\\"{x:1343,y:575,t:1527271915714};\\\", \\\"{x:1342,y:573,t:1527271915730};\\\", \\\"{x:1342,y:570,t:1527271915747};\\\", \\\"{x:1341,y:569,t:1527271915764};\\\", \\\"{x:1336,y:562,t:1527271915794};\\\", \\\"{x:1335,y:560,t:1527271915801};\\\", \\\"{x:1334,y:560,t:1527271915814};\\\", \\\"{x:1331,y:558,t:1527271915830};\\\", \\\"{x:1331,y:556,t:1527271915847};\\\", \\\"{x:1330,y:555,t:1527271915864};\\\", \\\"{x:1330,y:554,t:1527271915930};\\\", \\\"{x:1330,y:553,t:1527271915962};\\\", \\\"{x:1330,y:552,t:1527271915970};\\\", \\\"{x:1330,y:551,t:1527271915980};\\\", \\\"{x:1330,y:548,t:1527271915997};\\\", \\\"{x:1330,y:545,t:1527271916014};\\\", \\\"{x:1327,y:540,t:1527271916030};\\\", \\\"{x:1327,y:537,t:1527271916047};\\\", \\\"{x:1324,y:530,t:1527271916063};\\\", \\\"{x:1323,y:526,t:1527271916081};\\\", \\\"{x:1321,y:520,t:1527271916097};\\\", \\\"{x:1319,y:514,t:1527271916114};\\\", \\\"{x:1318,y:511,t:1527271916130};\\\", \\\"{x:1318,y:510,t:1527271916147};\\\", \\\"{x:1316,y:507,t:1527271916164};\\\", \\\"{x:1315,y:505,t:1527271916181};\\\", \\\"{x:1315,y:503,t:1527271916210};\\\", \\\"{x:1314,y:503,t:1527271916217};\\\", \\\"{x:1314,y:502,t:1527271916231};\\\", \\\"{x:1314,y:501,t:1527271916786};\\\", \\\"{x:1313,y:501,t:1527271916797};\\\", \\\"{x:1313,y:503,t:1527271916815};\\\", \\\"{x:1313,y:504,t:1527271916831};\\\", \\\"{x:1313,y:505,t:1527271916848};\\\", \\\"{x:1313,y:508,t:1527271916864};\\\", \\\"{x:1313,y:512,t:1527271916880};\\\", \\\"{x:1313,y:515,t:1527271916897};\\\", \\\"{x:1313,y:516,t:1527271916914};\\\", \\\"{x:1313,y:517,t:1527271916961};\\\", \\\"{x:1313,y:518,t:1527271916969};\\\", \\\"{x:1313,y:519,t:1527271916981};\\\", \\\"{x:1314,y:523,t:1527271916998};\\\", \\\"{x:1314,y:527,t:1527271917015};\\\", \\\"{x:1317,y:530,t:1527271917030};\\\", \\\"{x:1318,y:533,t:1527271917047};\\\", \\\"{x:1318,y:535,t:1527271917065};\\\", \\\"{x:1319,y:539,t:1527271917081};\\\", \\\"{x:1321,y:545,t:1527271917097};\\\", \\\"{x:1322,y:549,t:1527271917114};\\\", \\\"{x:1323,y:556,t:1527271917130};\\\", \\\"{x:1325,y:563,t:1527271917148};\\\", \\\"{x:1326,y:570,t:1527271917165};\\\", \\\"{x:1326,y:576,t:1527271917180};\\\", \\\"{x:1326,y:580,t:1527271917198};\\\", \\\"{x:1325,y:582,t:1527271917214};\\\", \\\"{x:1324,y:583,t:1527271917231};\\\", \\\"{x:1324,y:585,t:1527271917247};\\\", \\\"{x:1324,y:588,t:1527271917264};\\\", \\\"{x:1324,y:591,t:1527271917280};\\\", \\\"{x:1324,y:598,t:1527271917297};\\\", \\\"{x:1324,y:606,t:1527271917315};\\\", \\\"{x:1325,y:611,t:1527271917331};\\\", \\\"{x:1326,y:619,t:1527271917348};\\\", \\\"{x:1326,y:622,t:1527271917364};\\\", \\\"{x:1328,y:626,t:1527271917382};\\\", \\\"{x:1328,y:629,t:1527271917398};\\\", \\\"{x:1328,y:631,t:1527271917414};\\\", \\\"{x:1328,y:634,t:1527271917431};\\\", \\\"{x:1328,y:636,t:1527271917447};\\\", \\\"{x:1328,y:638,t:1527271917464};\\\", \\\"{x:1327,y:642,t:1527271917482};\\\", \\\"{x:1327,y:646,t:1527271917497};\\\", \\\"{x:1327,y:651,t:1527271917514};\\\", \\\"{x:1327,y:657,t:1527271917531};\\\", \\\"{x:1327,y:659,t:1527271917547};\\\", \\\"{x:1327,y:664,t:1527271917593};\\\", \\\"{x:1327,y:667,t:1527271917609};\\\", \\\"{x:1327,y:669,t:1527271917617};\\\", \\\"{x:1327,y:671,t:1527271917631};\\\", \\\"{x:1327,y:675,t:1527271917647};\\\", \\\"{x:1327,y:678,t:1527271917664};\\\", \\\"{x:1327,y:681,t:1527271917681};\\\", \\\"{x:1327,y:683,t:1527271917697};\\\", \\\"{x:1327,y:684,t:1527271917722};\\\", \\\"{x:1327,y:685,t:1527271917738};\\\", \\\"{x:1325,y:686,t:1527271917748};\\\", \\\"{x:1325,y:688,t:1527271917769};\\\", \\\"{x:1324,y:688,t:1527271917782};\\\", \\\"{x:1322,y:690,t:1527271917798};\\\", \\\"{x:1321,y:692,t:1527271917815};\\\", \\\"{x:1320,y:694,t:1527271917834};\\\", \\\"{x:1320,y:695,t:1527271917848};\\\", \\\"{x:1318,y:696,t:1527271917866};\\\", \\\"{x:1316,y:701,t:1527271917882};\\\", \\\"{x:1315,y:702,t:1527271917899};\\\", \\\"{x:1315,y:703,t:1527271917945};\\\", \\\"{x:1315,y:704,t:1527271917986};\\\", \\\"{x:1315,y:706,t:1527271918002};\\\", \\\"{x:1315,y:708,t:1527271918018};\\\", \\\"{x:1314,y:711,t:1527271918034};\\\", \\\"{x:1314,y:713,t:1527271918049};\\\", \\\"{x:1312,y:719,t:1527271918065};\\\", \\\"{x:1310,y:723,t:1527271918082};\\\", \\\"{x:1307,y:727,t:1527271918099};\\\", \\\"{x:1307,y:729,t:1527271918115};\\\", \\\"{x:1307,y:731,t:1527271918131};\\\", \\\"{x:1308,y:733,t:1527271918151};\\\", \\\"{x:1308,y:734,t:1527271918165};\\\", \\\"{x:1308,y:735,t:1527271918209};\\\", \\\"{x:1308,y:736,t:1527271918225};\\\", \\\"{x:1308,y:737,t:1527271918240};\\\", \\\"{x:1308,y:738,t:1527271918249};\\\", \\\"{x:1309,y:738,t:1527271918272};\\\", \\\"{x:1309,y:740,t:1527271918313};\\\", \\\"{x:1309,y:741,t:1527271918321};\\\", \\\"{x:1311,y:743,t:1527271918353};\\\", \\\"{x:1311,y:744,t:1527271918393};\\\", \\\"{x:1311,y:745,t:1527271918417};\\\", \\\"{x:1311,y:746,t:1527271918441};\\\", \\\"{x:1312,y:747,t:1527271918482};\\\", \\\"{x:1312,y:748,t:1527271918642};\\\", \\\"{x:1312,y:749,t:1527271918650};\\\", \\\"{x:1312,y:750,t:1527271918666};\\\", \\\"{x:1313,y:753,t:1527271918684};\\\", \\\"{x:1313,y:754,t:1527271918699};\\\", \\\"{x:1313,y:756,t:1527271918716};\\\", \\\"{x:1313,y:760,t:1527271918733};\\\", \\\"{x:1313,y:762,t:1527271918750};\\\", \\\"{x:1313,y:764,t:1527271918765};\\\", \\\"{x:1316,y:768,t:1527271918783};\\\", \\\"{x:1318,y:772,t:1527271918798};\\\", \\\"{x:1319,y:775,t:1527271918815};\\\", \\\"{x:1319,y:778,t:1527271918833};\\\", \\\"{x:1319,y:779,t:1527271918848};\\\", \\\"{x:1319,y:780,t:1527271918865};\\\", \\\"{x:1320,y:781,t:1527271918889};\\\", \\\"{x:1320,y:782,t:1527271918905};\\\", \\\"{x:1320,y:783,t:1527271918921};\\\", \\\"{x:1320,y:784,t:1527271918953};\\\", \\\"{x:1320,y:787,t:1527271918985};\\\", \\\"{x:1320,y:788,t:1527271918999};\\\", \\\"{x:1320,y:791,t:1527271919016};\\\", \\\"{x:1320,y:793,t:1527271919033};\\\", \\\"{x:1320,y:796,t:1527271919049};\\\", \\\"{x:1320,y:799,t:1527271919065};\\\", \\\"{x:1320,y:800,t:1527271919082};\\\", \\\"{x:1320,y:803,t:1527271919100};\\\", \\\"{x:1318,y:806,t:1527271919116};\\\", \\\"{x:1316,y:809,t:1527271919133};\\\", \\\"{x:1314,y:814,t:1527271919150};\\\", \\\"{x:1313,y:815,t:1527271919166};\\\", \\\"{x:1310,y:819,t:1527271919182};\\\", \\\"{x:1310,y:822,t:1527271919200};\\\", \\\"{x:1307,y:829,t:1527271919215};\\\", \\\"{x:1306,y:835,t:1527271919233};\\\", \\\"{x:1306,y:841,t:1527271919249};\\\", \\\"{x:1303,y:844,t:1527271919265};\\\", \\\"{x:1301,y:851,t:1527271919282};\\\", \\\"{x:1299,y:855,t:1527271919299};\\\", \\\"{x:1298,y:856,t:1527271919315};\\\", \\\"{x:1298,y:861,t:1527271919332};\\\", \\\"{x:1298,y:866,t:1527271919349};\\\", \\\"{x:1298,y:870,t:1527271919366};\\\", \\\"{x:1298,y:879,t:1527271919383};\\\", \\\"{x:1296,y:884,t:1527271919399};\\\", \\\"{x:1296,y:885,t:1527271919416};\\\", \\\"{x:1295,y:892,t:1527271919432};\\\", \\\"{x:1295,y:896,t:1527271919449};\\\", \\\"{x:1295,y:899,t:1527271919466};\\\", \\\"{x:1295,y:903,t:1527271919483};\\\", \\\"{x:1295,y:904,t:1527271919506};\\\", \\\"{x:1295,y:906,t:1527271919516};\\\", \\\"{x:1295,y:907,t:1527271919533};\\\", \\\"{x:1295,y:909,t:1527271919550};\\\", \\\"{x:1296,y:915,t:1527271919567};\\\", \\\"{x:1297,y:919,t:1527271919583};\\\", \\\"{x:1299,y:925,t:1527271919600};\\\", \\\"{x:1301,y:933,t:1527271919617};\\\", \\\"{x:1303,y:939,t:1527271919633};\\\", \\\"{x:1304,y:945,t:1527271919650};\\\", \\\"{x:1304,y:948,t:1527271919667};\\\", \\\"{x:1304,y:954,t:1527271919682};\\\", \\\"{x:1304,y:955,t:1527271919700};\\\", \\\"{x:1305,y:961,t:1527271919717};\\\", \\\"{x:1309,y:967,t:1527271919733};\\\", \\\"{x:1309,y:970,t:1527271919750};\\\", \\\"{x:1309,y:972,t:1527271919767};\\\", \\\"{x:1309,y:973,t:1527271919783};\\\", \\\"{x:1311,y:974,t:1527271919800};\\\", \\\"{x:1312,y:974,t:1527271929754};\\\", \\\"{x:1313,y:974,t:1527271929762};\\\", \\\"{x:1316,y:974,t:1527271929774};\\\", \\\"{x:1321,y:974,t:1527271929792};\\\", \\\"{x:1328,y:968,t:1527271929809};\\\", \\\"{x:1334,y:967,t:1527271929824};\\\", \\\"{x:1342,y:963,t:1527271929842};\\\", \\\"{x:1349,y:963,t:1527271929858};\\\", \\\"{x:1369,y:963,t:1527271929874};\\\", \\\"{x:1387,y:965,t:1527271929891};\\\", \\\"{x:1398,y:965,t:1527271929908};\\\", \\\"{x:1410,y:965,t:1527271929925};\\\", \\\"{x:1415,y:965,t:1527271929942};\\\", \\\"{x:1416,y:965,t:1527271929958};\\\", \\\"{x:1417,y:965,t:1527271929974};\\\", \\\"{x:1418,y:965,t:1527271929993};\\\", \\\"{x:1419,y:965,t:1527271930202};\\\", \\\"{x:1421,y:964,t:1527271930209};\\\", \\\"{x:1424,y:962,t:1527271930225};\\\", \\\"{x:1434,y:962,t:1527271930242};\\\", \\\"{x:1455,y:964,t:1527271930258};\\\", \\\"{x:1466,y:964,t:1527271930275};\\\", \\\"{x:1476,y:964,t:1527271930292};\\\", \\\"{x:1479,y:964,t:1527271930308};\\\", \\\"{x:1482,y:964,t:1527271930325};\\\", \\\"{x:1484,y:964,t:1527271930342};\\\", \\\"{x:1485,y:964,t:1527271930358};\\\", \\\"{x:1486,y:964,t:1527271930554};\\\", \\\"{x:1487,y:963,t:1527271930578};\\\", \\\"{x:1487,y:962,t:1527271930610};\\\", \\\"{x:1491,y:962,t:1527271931114};\\\", \\\"{x:1493,y:962,t:1527271931125};\\\", \\\"{x:1499,y:960,t:1527271931143};\\\", \\\"{x:1500,y:960,t:1527271931218};\\\", \\\"{x:1502,y:960,t:1527271931258};\\\", \\\"{x:1505,y:960,t:1527271931266};\\\", \\\"{x:1506,y:960,t:1527271931298};\\\", \\\"{x:1507,y:960,t:1527271931309};\\\", \\\"{x:1513,y:960,t:1527271931326};\\\", \\\"{x:1518,y:960,t:1527271931342};\\\", \\\"{x:1531,y:960,t:1527271931360};\\\", \\\"{x:1535,y:960,t:1527271931377};\\\", \\\"{x:1537,y:960,t:1527271931393};\\\", \\\"{x:1536,y:960,t:1527271931578};\\\", \\\"{x:1535,y:960,t:1527271931649};\\\", \\\"{x:1534,y:960,t:1527271931659};\\\", \\\"{x:1533,y:960,t:1527271931677};\\\", \\\"{x:1531,y:960,t:1527271931693};\\\", \\\"{x:1530,y:962,t:1527271931709};\\\", \\\"{x:1530,y:964,t:1527271931726};\\\", \\\"{x:1529,y:967,t:1527271931743};\\\", \\\"{x:1529,y:970,t:1527271931759};\\\", \\\"{x:1527,y:972,t:1527271931777};\\\", \\\"{x:1526,y:975,t:1527271931793};\\\", \\\"{x:1526,y:976,t:1527271931882};\\\", \\\"{x:1527,y:976,t:1527271932034};\\\", \\\"{x:1528,y:976,t:1527271932050};\\\", \\\"{x:1529,y:976,t:1527271932059};\\\", \\\"{x:1532,y:976,t:1527271932077};\\\", \\\"{x:1534,y:976,t:1527271932094};\\\", \\\"{x:1535,y:976,t:1527271932109};\\\", \\\"{x:1538,y:976,t:1527271932127};\\\", \\\"{x:1546,y:975,t:1527271932144};\\\", \\\"{x:1551,y:972,t:1527271932159};\\\", \\\"{x:1555,y:971,t:1527271932176};\\\", \\\"{x:1559,y:969,t:1527271932192};\\\", \\\"{x:1560,y:969,t:1527271932209};\\\", \\\"{x:1561,y:968,t:1527271933635};\\\", \\\"{x:1561,y:966,t:1527271933673};\\\", \\\"{x:1560,y:966,t:1527271933682};\\\", \\\"{x:1557,y:964,t:1527271933882};\\\", \\\"{x:1556,y:963,t:1527271933921};\\\", \\\"{x:1555,y:962,t:1527271933978};\\\", \\\"{x:1554,y:962,t:1527271934009};\\\", \\\"{x:1553,y:962,t:1527271934017};\\\", \\\"{x:1551,y:961,t:1527271934042};\\\", \\\"{x:1550,y:961,t:1527271934282};\\\", \\\"{x:1549,y:961,t:1527271934297};\\\", \\\"{x:1548,y:961,t:1527271934311};\\\", \\\"{x:1547,y:962,t:1527271934328};\\\", \\\"{x:1544,y:963,t:1527271934361};\\\", \\\"{x:1543,y:963,t:1527271934378};\\\", \\\"{x:1542,y:963,t:1527271934400};\\\", \\\"{x:1542,y:963,t:1527271934546};\\\", \\\"{x:1542,y:964,t:1527271935298};\\\", \\\"{x:1540,y:965,t:1527271935312};\\\", \\\"{x:1539,y:966,t:1527271935330};\\\", \\\"{x:1539,y:967,t:1527271935345};\\\", \\\"{x:1539,y:973,t:1527271935363};\\\", \\\"{x:1539,y:976,t:1527271935380};\\\", \\\"{x:1539,y:979,t:1527271935395};\\\", \\\"{x:1540,y:983,t:1527271935412};\\\", \\\"{x:1541,y:986,t:1527271935430};\\\", \\\"{x:1543,y:989,t:1527271935446};\\\", \\\"{x:1543,y:990,t:1527271935463};\\\", \\\"{x:1544,y:991,t:1527271935479};\\\", \\\"{x:1545,y:991,t:1527271935666};\\\", \\\"{x:1546,y:991,t:1527271935681};\\\", \\\"{x:1548,y:991,t:1527271935697};\\\", \\\"{x:1549,y:991,t:1527271935713};\\\", \\\"{x:1549,y:989,t:1527271935746};\\\", \\\"{x:1549,y:988,t:1527271935763};\\\", \\\"{x:1549,y:987,t:1527271935780};\\\", \\\"{x:1549,y:984,t:1527271935797};\\\", \\\"{x:1548,y:983,t:1527271935812};\\\", \\\"{x:1547,y:982,t:1527271935830};\\\", \\\"{x:1546,y:981,t:1527271936105};\\\", \\\"{x:1545,y:980,t:1527271936112};\\\", \\\"{x:1544,y:980,t:1527271936136};\\\", \\\"{x:1542,y:979,t:1527271936152};\\\", \\\"{x:1542,y:978,t:1527271936169};\\\", \\\"{x:1541,y:977,t:1527271936193};\\\", \\\"{x:1540,y:977,t:1527271936274};\\\", \\\"{x:1538,y:977,t:1527271936297};\\\", \\\"{x:1537,y:976,t:1527271936315};\\\", \\\"{x:1535,y:976,t:1527271936354};\\\", \\\"{x:1534,y:976,t:1527271936364};\\\", \\\"{x:1532,y:976,t:1527271936381};\\\", \\\"{x:1528,y:976,t:1527271936398};\\\", \\\"{x:1525,y:976,t:1527271936415};\\\", \\\"{x:1524,y:976,t:1527271936537};\\\", \\\"{x:1528,y:976,t:1527271936706};\\\", \\\"{x:1533,y:976,t:1527271936716};\\\", \\\"{x:1538,y:976,t:1527271936732};\\\", \\\"{x:1540,y:976,t:1527271936746};\\\", \\\"{x:1544,y:976,t:1527271936762};\\\", \\\"{x:1546,y:976,t:1527271936792};\\\", \\\"{x:1548,y:975,t:1527271936800};\\\", \\\"{x:1548,y:974,t:1527271936813};\\\", \\\"{x:1550,y:974,t:1527271936830};\\\", \\\"{x:1553,y:974,t:1527271936846};\\\", \\\"{x:1556,y:974,t:1527271936863};\\\", \\\"{x:1559,y:974,t:1527271936880};\\\", \\\"{x:1563,y:974,t:1527271936896};\\\", \\\"{x:1564,y:974,t:1527271936913};\\\", \\\"{x:1566,y:974,t:1527271936961};\\\", \\\"{x:1567,y:974,t:1527271936978};\\\", \\\"{x:1569,y:974,t:1527271936993};\\\", \\\"{x:1569,y:974,t:1527271937185};\\\", \\\"{x:1567,y:975,t:1527271937249};\\\", \\\"{x:1562,y:975,t:1527271937263};\\\", \\\"{x:1539,y:975,t:1527271937281};\\\", \\\"{x:1495,y:970,t:1527271937297};\\\", \\\"{x:1397,y:952,t:1527271937314};\\\", \\\"{x:1249,y:921,t:1527271937330};\\\", \\\"{x:1095,y:877,t:1527271937347};\\\", \\\"{x:938,y:810,t:1527271937364};\\\", \\\"{x:773,y:716,t:1527271937380};\\\", \\\"{x:632,y:652,t:1527271937398};\\\", \\\"{x:546,y:611,t:1527271937414};\\\", \\\"{x:546,y:606,t:1527271937430};\\\", \\\"{x:546,y:605,t:1527271937545};\\\", \\\"{x:546,y:604,t:1527271937625};\\\", \\\"{x:546,y:603,t:1527271937633};\\\", \\\"{x:546,y:599,t:1527271937647};\\\", \\\"{x:538,y:591,t:1527271937666};\\\", \\\"{x:527,y:590,t:1527271937680};\\\", \\\"{x:511,y:582,t:1527271937698};\\\", \\\"{x:502,y:580,t:1527271937714};\\\", \\\"{x:494,y:581,t:1527271937731};\\\", \\\"{x:483,y:581,t:1527271937747};\\\", \\\"{x:474,y:581,t:1527271937764};\\\", \\\"{x:468,y:581,t:1527271937781};\\\", \\\"{x:465,y:581,t:1527271937797};\\\", \\\"{x:467,y:581,t:1527271937889};\\\", \\\"{x:476,y:581,t:1527271937897};\\\", \\\"{x:487,y:582,t:1527271937914};\\\", \\\"{x:503,y:588,t:1527271937932};\\\", \\\"{x:533,y:598,t:1527271937948};\\\", \\\"{x:556,y:603,t:1527271937964};\\\", \\\"{x:564,y:606,t:1527271937981};\\\", \\\"{x:573,y:613,t:1527271937997};\\\", \\\"{x:585,y:615,t:1527271938015};\\\", \\\"{x:590,y:616,t:1527271938031};\\\", \\\"{x:591,y:616,t:1527271938047};\\\", \\\"{x:591,y:615,t:1527271938241};\\\", \\\"{x:591,y:610,t:1527271938248};\\\", \\\"{x:591,y:608,t:1527271938264};\\\", \\\"{x:588,y:595,t:1527271938282};\\\", \\\"{x:590,y:586,t:1527271938298};\\\", \\\"{x:601,y:566,t:1527271938314};\\\", \\\"{x:608,y:551,t:1527271938332};\\\", \\\"{x:613,y:545,t:1527271938348};\\\", \\\"{x:617,y:540,t:1527271938364};\\\", \\\"{x:617,y:541,t:1527271938554};\\\", \\\"{x:616,y:543,t:1527271938564};\\\", \\\"{x:616,y:544,t:1527271938582};\\\", \\\"{x:617,y:557,t:1527271938604};\\\", \\\"{x:621,y:569,t:1527271938615};\\\", \\\"{x:627,y:578,t:1527271938631};\\\", \\\"{x:630,y:584,t:1527271938649};\\\", \\\"{x:633,y:594,t:1527271938665};\\\", \\\"{x:634,y:602,t:1527271938682};\\\", \\\"{x:634,y:605,t:1527271938704};\\\", \\\"{x:634,y:606,t:1527271938720};\\\", \\\"{x:634,y:608,t:1527271938744};\\\", \\\"{x:634,y:609,t:1527271938760};\\\", \\\"{x:632,y:610,t:1527271938769};\\\", \\\"{x:631,y:611,t:1527271938792};\\\", \\\"{x:629,y:612,t:1527271938817};\\\", \\\"{x:627,y:613,t:1527271938831};\\\", \\\"{x:624,y:614,t:1527271938849};\\\", \\\"{x:622,y:616,t:1527271938865};\\\", \\\"{x:620,y:616,t:1527271938881};\\\", \\\"{x:619,y:616,t:1527271938899};\\\", \\\"{x:627,y:616,t:1527271939120};\\\", \\\"{x:631,y:617,t:1527271939132};\\\", \\\"{x:644,y:627,t:1527271939149};\\\", \\\"{x:689,y:633,t:1527271939165};\\\", \\\"{x:752,y:647,t:1527271939181};\\\", \\\"{x:841,y:663,t:1527271939198};\\\", \\\"{x:957,y:677,t:1527271939214};\\\", \\\"{x:1058,y:693,t:1527271939232};\\\", \\\"{x:1125,y:705,t:1527271939248};\\\", \\\"{x:1156,y:712,t:1527271939265};\\\", \\\"{x:1165,y:715,t:1527271939281};\\\", \\\"{x:1169,y:718,t:1527271939299};\\\", \\\"{x:1171,y:718,t:1527271939314};\\\", \\\"{x:1171,y:719,t:1527271939346};\\\", \\\"{x:1172,y:722,t:1527271939353};\\\", \\\"{x:1172,y:724,t:1527271939369};\\\", \\\"{x:1172,y:726,t:1527271939382};\\\", \\\"{x:1172,y:733,t:1527271939398};\\\", \\\"{x:1175,y:741,t:1527271939414};\\\", \\\"{x:1176,y:746,t:1527271939432};\\\", \\\"{x:1182,y:756,t:1527271939449};\\\", \\\"{x:1190,y:768,t:1527271939464};\\\", \\\"{x:1206,y:783,t:1527271939481};\\\", \\\"{x:1223,y:795,t:1527271939499};\\\", \\\"{x:1240,y:805,t:1527271939515};\\\", \\\"{x:1250,y:815,t:1527271939532};\\\", \\\"{x:1250,y:822,t:1527271939549};\\\", \\\"{x:1257,y:830,t:1527271939565};\\\", \\\"{x:1273,y:839,t:1527271939582};\\\", \\\"{x:1285,y:847,t:1527271939599};\\\", \\\"{x:1286,y:850,t:1527271939615};\\\", \\\"{x:1287,y:850,t:1527271939914};\\\", \\\"{x:1291,y:842,t:1527271939932};\\\", \\\"{x:1295,y:829,t:1527271939949};\\\", \\\"{x:1300,y:820,t:1527271939965};\\\", \\\"{x:1303,y:800,t:1527271939982};\\\", \\\"{x:1305,y:781,t:1527271939999};\\\", \\\"{x:1308,y:759,t:1527271940015};\\\", \\\"{x:1313,y:743,t:1527271940032};\\\", \\\"{x:1316,y:735,t:1527271940049};\\\", \\\"{x:1316,y:733,t:1527271940065};\\\", \\\"{x:1319,y:721,t:1527271940081};\\\", \\\"{x:1323,y:708,t:1527271940098};\\\", \\\"{x:1324,y:702,t:1527271940115};\\\", \\\"{x:1324,y:697,t:1527271940132};\\\", \\\"{x:1325,y:690,t:1527271940149};\\\", \\\"{x:1325,y:688,t:1527271940165};\\\", \\\"{x:1325,y:683,t:1527271940378};\\\", \\\"{x:1325,y:672,t:1527271940386};\\\", \\\"{x:1325,y:661,t:1527271940399};\\\", \\\"{x:1325,y:641,t:1527271940415};\\\", \\\"{x:1322,y:631,t:1527271940432};\\\", \\\"{x:1312,y:594,t:1527271940449};\\\", \\\"{x:1299,y:552,t:1527271940465};\\\", \\\"{x:1294,y:515,t:1527271940482};\\\", \\\"{x:1292,y:496,t:1527271940500};\\\", \\\"{x:1292,y:487,t:1527271940514};\\\", \\\"{x:1292,y:484,t:1527271940532};\\\", \\\"{x:1291,y:482,t:1527271940549};\\\", \\\"{x:1290,y:481,t:1527271940730};\\\", \\\"{x:1289,y:481,t:1527271940753};\\\", \\\"{x:1290,y:483,t:1527271940769};\\\", \\\"{x:1291,y:484,t:1527271940782};\\\", \\\"{x:1292,y:485,t:1527271940799};\\\", \\\"{x:1294,y:486,t:1527271940815};\\\", \\\"{x:1294,y:487,t:1527271940842};\\\", \\\"{x:1295,y:488,t:1527271940849};\\\", \\\"{x:1295,y:489,t:1527271940889};\\\", \\\"{x:1295,y:490,t:1527271940899};\\\", \\\"{x:1295,y:491,t:1527271940914};\\\", \\\"{x:1298,y:494,t:1527271940931};\\\", \\\"{x:1298,y:496,t:1527271940948};\\\", \\\"{x:1299,y:498,t:1527271940993};\\\", \\\"{x:1299,y:499,t:1527271941081};\\\", \\\"{x:1303,y:503,t:1527271942131};\\\", \\\"{x:1308,y:515,t:1527271942142};\\\", \\\"{x:1324,y:540,t:1527271942157};\\\", \\\"{x:1341,y:579,t:1527271942174};\\\", \\\"{x:1371,y:622,t:1527271942191};\\\", \\\"{x:1382,y:637,t:1527271942207};\\\", \\\"{x:1442,y:677,t:1527271942224};\\\", \\\"{x:1497,y:711,t:1527271942242};\\\", \\\"{x:1512,y:727,t:1527271942257};\\\", \\\"{x:1528,y:743,t:1527271942274};\\\", \\\"{x:1537,y:749,t:1527271942291};\\\", \\\"{x:1541,y:751,t:1527271942307};\\\", \\\"{x:1542,y:753,t:1527271942324};\\\", \\\"{x:1543,y:754,t:1527271942341};\\\", \\\"{x:1543,y:755,t:1527271942371};\\\", \\\"{x:1543,y:758,t:1527271942379};\\\", \\\"{x:1540,y:761,t:1527271942391};\\\", \\\"{x:1537,y:763,t:1527271942407};\\\", \\\"{x:1525,y:772,t:1527271942425};\\\", \\\"{x:1511,y:777,t:1527271942441};\\\", \\\"{x:1498,y:781,t:1527271942457};\\\", \\\"{x:1481,y:782,t:1527271942475};\\\", \\\"{x:1475,y:783,t:1527271942491};\\\", \\\"{x:1472,y:783,t:1527271942508};\\\", \\\"{x:1470,y:783,t:1527271942525};\\\", \\\"{x:1469,y:783,t:1527271942588};\\\", \\\"{x:1465,y:783,t:1527271942595};\\\", \\\"{x:1460,y:783,t:1527271942607};\\\", \\\"{x:1445,y:783,t:1527271942625};\\\", \\\"{x:1427,y:786,t:1527271942642};\\\", \\\"{x:1417,y:787,t:1527271942658};\\\", \\\"{x:1406,y:791,t:1527271942674};\\\", \\\"{x:1396,y:795,t:1527271942691};\\\", \\\"{x:1386,y:796,t:1527271942707};\\\", \\\"{x:1368,y:797,t:1527271942725};\\\", \\\"{x:1344,y:794,t:1527271942742};\\\", \\\"{x:1313,y:788,t:1527271942758};\\\", \\\"{x:1304,y:777,t:1527271942775};\\\", \\\"{x:1271,y:772,t:1527271942792};\\\", \\\"{x:1267,y:772,t:1527271942807};\\\", \\\"{x:1265,y:772,t:1527271942825};\\\", \\\"{x:1263,y:772,t:1527271942939};\\\", \\\"{x:1260,y:772,t:1527271942955};\\\", \\\"{x:1257,y:772,t:1527271942963};\\\", \\\"{x:1256,y:772,t:1527271942974};\\\", \\\"{x:1254,y:772,t:1527271942990};\\\", \\\"{x:1248,y:772,t:1527271943007};\\\", \\\"{x:1244,y:772,t:1527271943024};\\\", \\\"{x:1241,y:771,t:1527271943041};\\\", \\\"{x:1236,y:771,t:1527271943057};\\\", \\\"{x:1227,y:769,t:1527271943074};\\\", \\\"{x:1220,y:767,t:1527271943090};\\\", \\\"{x:1214,y:766,t:1527271943107};\\\", \\\"{x:1210,y:762,t:1527271943124};\\\", \\\"{x:1209,y:761,t:1527271943142};\\\", \\\"{x:1205,y:761,t:1527271944500};\\\", \\\"{x:1202,y:761,t:1527271944507};\\\", \\\"{x:1195,y:760,t:1527271944525};\\\", \\\"{x:1187,y:759,t:1527271944541};\\\", \\\"{x:1179,y:757,t:1527271944558};\\\", \\\"{x:1167,y:755,t:1527271944574};\\\", \\\"{x:1164,y:755,t:1527271944590};\\\", \\\"{x:1163,y:755,t:1527271944608};\\\", \\\"{x:1162,y:755,t:1527271944763};\\\", \\\"{x:1162,y:753,t:1527271944979};\\\", \\\"{x:1163,y:751,t:1527271944995};\\\", \\\"{x:1163,y:749,t:1527271945007};\\\", \\\"{x:1167,y:744,t:1527271945024};\\\", \\\"{x:1172,y:737,t:1527271945040};\\\", \\\"{x:1176,y:730,t:1527271945057};\\\", \\\"{x:1181,y:722,t:1527271945075};\\\", \\\"{x:1189,y:712,t:1527271945091};\\\", \\\"{x:1198,y:693,t:1527271945107};\\\", \\\"{x:1213,y:670,t:1527271945124};\\\", \\\"{x:1223,y:652,t:1527271945141};\\\", \\\"{x:1235,y:632,t:1527271945158};\\\", \\\"{x:1246,y:620,t:1527271945175};\\\", \\\"{x:1254,y:609,t:1527271945190};\\\", \\\"{x:1261,y:601,t:1527271945208};\\\", \\\"{x:1266,y:595,t:1527271945225};\\\", \\\"{x:1269,y:592,t:1527271945240};\\\", \\\"{x:1271,y:591,t:1527271945258};\\\", \\\"{x:1272,y:591,t:1527271945274};\\\", \\\"{x:1273,y:591,t:1527271945411};\\\", \\\"{x:1275,y:589,t:1527271945424};\\\", \\\"{x:1277,y:585,t:1527271945441};\\\", \\\"{x:1281,y:570,t:1527271945458};\\\", \\\"{x:1286,y:549,t:1527271945475};\\\", \\\"{x:1295,y:538,t:1527271945491};\\\", \\\"{x:1302,y:531,t:1527271945507};\\\", \\\"{x:1313,y:518,t:1527271945524};\\\", \\\"{x:1315,y:515,t:1527271945540};\\\", \\\"{x:1319,y:508,t:1527271945559};\\\", \\\"{x:1320,y:504,t:1527271945574};\\\", \\\"{x:1320,y:503,t:1527271945674};\\\", \\\"{x:1320,y:502,t:1527271945690};\\\", \\\"{x:1320,y:501,t:1527271945795};\\\", \\\"{x:1321,y:501,t:1527271945807};\\\", \\\"{x:1322,y:501,t:1527271945825};\\\", \\\"{x:1326,y:499,t:1527271945841};\\\", \\\"{x:1329,y:498,t:1527271945857};\\\", \\\"{x:1334,y:496,t:1527271945874};\\\", \\\"{x:1337,y:495,t:1527271945890};\\\", \\\"{x:1340,y:494,t:1527271945907};\\\", \\\"{x:1344,y:491,t:1527271945924};\\\", \\\"{x:1352,y:488,t:1527271945940};\\\", \\\"{x:1357,y:487,t:1527271945957};\\\", \\\"{x:1359,y:486,t:1527271945974};\\\", \\\"{x:1360,y:486,t:1527271946010};\\\", \\\"{x:1360,y:485,t:1527271946035};\\\", \\\"{x:1361,y:485,t:1527271946043};\\\", \\\"{x:1362,y:485,t:1527271946057};\\\", \\\"{x:1371,y:485,t:1527271946074};\\\", \\\"{x:1379,y:485,t:1527271946091};\\\", \\\"{x:1392,y:486,t:1527271946108};\\\", \\\"{x:1406,y:487,t:1527271946125};\\\", \\\"{x:1418,y:487,t:1527271946141};\\\", \\\"{x:1430,y:487,t:1527271946158};\\\", \\\"{x:1444,y:485,t:1527271946174};\\\", \\\"{x:1455,y:484,t:1527271946190};\\\", \\\"{x:1464,y:482,t:1527271946207};\\\", \\\"{x:1468,y:482,t:1527271946224};\\\", \\\"{x:1475,y:482,t:1527271946240};\\\", \\\"{x:1485,y:482,t:1527271946257};\\\", \\\"{x:1491,y:482,t:1527271946275};\\\", \\\"{x:1492,y:482,t:1527271946299};\\\", \\\"{x:1495,y:482,t:1527271946339};\\\", \\\"{x:1498,y:482,t:1527271946355};\\\", \\\"{x:1505,y:482,t:1527271946362};\\\", \\\"{x:1509,y:482,t:1527271946374};\\\", \\\"{x:1524,y:482,t:1527271946390};\\\", \\\"{x:1539,y:482,t:1527271946407};\\\", \\\"{x:1558,y:483,t:1527271946424};\\\", \\\"{x:1580,y:485,t:1527271946441};\\\", \\\"{x:1591,y:487,t:1527271946457};\\\", \\\"{x:1611,y:490,t:1527271946473};\\\", \\\"{x:1626,y:490,t:1527271946490};\\\", \\\"{x:1631,y:490,t:1527271946508};\\\", \\\"{x:1633,y:491,t:1527271946524};\\\", \\\"{x:1634,y:492,t:1527271946628};\\\", \\\"{x:1635,y:492,t:1527271946641};\\\", \\\"{x:1640,y:492,t:1527271946658};\\\", \\\"{x:1642,y:491,t:1527271946674};\\\", \\\"{x:1647,y:491,t:1527271946691};\\\", \\\"{x:1648,y:491,t:1527271947251};\\\", \\\"{x:1648,y:492,t:1527271947258};\\\", \\\"{x:1647,y:492,t:1527271947273};\\\", \\\"{x:1634,y:495,t:1527271947291};\\\", \\\"{x:1617,y:495,t:1527271947307};\\\", \\\"{x:1596,y:495,t:1527271947324};\\\", \\\"{x:1578,y:495,t:1527271947340};\\\", \\\"{x:1551,y:495,t:1527271947357};\\\", \\\"{x:1540,y:494,t:1527271947373};\\\", \\\"{x:1522,y:494,t:1527271947390};\\\", \\\"{x:1510,y:492,t:1527271947407};\\\", \\\"{x:1500,y:490,t:1527271947423};\\\", \\\"{x:1488,y:489,t:1527271947440};\\\", \\\"{x:1480,y:489,t:1527271947457};\\\", \\\"{x:1475,y:489,t:1527271947473};\\\", \\\"{x:1472,y:489,t:1527271947490};\\\", \\\"{x:1466,y:489,t:1527271947507};\\\", \\\"{x:1455,y:489,t:1527271947523};\\\", \\\"{x:1433,y:489,t:1527271947540};\\\", \\\"{x:1395,y:489,t:1527271947557};\\\", \\\"{x:1373,y:485,t:1527271947573};\\\", \\\"{x:1344,y:483,t:1527271947590};\\\", \\\"{x:1327,y:480,t:1527271947607};\\\", \\\"{x:1317,y:478,t:1527271947623};\\\", \\\"{x:1310,y:477,t:1527271947640};\\\", \\\"{x:1305,y:477,t:1527271947657};\\\", \\\"{x:1302,y:477,t:1527271947673};\\\", \\\"{x:1283,y:485,t:1527271947691};\\\", \\\"{x:1272,y:491,t:1527271947707};\\\", \\\"{x:1266,y:494,t:1527271947723};\\\", \\\"{x:1255,y:495,t:1527271947741};\\\", \\\"{x:1249,y:495,t:1527271947757};\\\", \\\"{x:1242,y:498,t:1527271947774};\\\", \\\"{x:1226,y:501,t:1527271947790};\\\", \\\"{x:1211,y:502,t:1527271947807};\\\", \\\"{x:1200,y:503,t:1527271947823};\\\", \\\"{x:1181,y:503,t:1527271947840};\\\", \\\"{x:1162,y:505,t:1527271947857};\\\", \\\"{x:1152,y:505,t:1527271947873};\\\", \\\"{x:1125,y:505,t:1527271947890};\\\", \\\"{x:1108,y:504,t:1527271947908};\\\", \\\"{x:1100,y:503,t:1527271947924};\\\", \\\"{x:1098,y:502,t:1527271947941};\\\", \\\"{x:1097,y:502,t:1527271947958};\\\", \\\"{x:1095,y:503,t:1527271948011};\\\", \\\"{x:1094,y:503,t:1527271948024};\\\", \\\"{x:1092,y:503,t:1527271948040};\\\", \\\"{x:1090,y:505,t:1527271948067};\\\", \\\"{x:1089,y:505,t:1527271948091};\\\", \\\"{x:1089,y:506,t:1527271948108};\\\", \\\"{x:1088,y:506,t:1527271948147};\\\", \\\"{x:1086,y:506,t:1527271948163};\\\", \\\"{x:1086,y:507,t:1527271948173};\\\", \\\"{x:1082,y:510,t:1527271948190};\\\", \\\"{x:1078,y:511,t:1527271948207};\\\", \\\"{x:1073,y:513,t:1527271948223};\\\", \\\"{x:1069,y:515,t:1527271948240};\\\", \\\"{x:1068,y:515,t:1527271948257};\\\", \\\"{x:1063,y:517,t:1527271948273};\\\", \\\"{x:1055,y:520,t:1527271948290};\\\", \\\"{x:1050,y:523,t:1527271948307};\\\", \\\"{x:1045,y:523,t:1527271948323};\\\", \\\"{x:1038,y:523,t:1527271948340};\\\", \\\"{x:1035,y:524,t:1527271948357};\\\", \\\"{x:1032,y:526,t:1527271948373};\\\", \\\"{x:1030,y:526,t:1527271948390};\\\", \\\"{x:1029,y:526,t:1527271948407};\\\", \\\"{x:1028,y:527,t:1527271948423};\\\", \\\"{x:1027,y:527,t:1527271948482};\\\", \\\"{x:1025,y:528,t:1527271948490};\\\", \\\"{x:1024,y:529,t:1527271948507};\\\", \\\"{x:1022,y:530,t:1527271948524};\\\", \\\"{x:1021,y:530,t:1527271948540};\\\", \\\"{x:1019,y:531,t:1527271948558};\\\", \\\"{x:1017,y:532,t:1527271948587};\\\", \\\"{x:1015,y:534,t:1527271948603};\\\", \\\"{x:1015,y:535,t:1527271948643};\\\", \\\"{x:1014,y:535,t:1527271948707};\\\", \\\"{x:1011,y:535,t:1527271948724};\\\", \\\"{x:1009,y:537,t:1527271948741};\\\", \\\"{x:1008,y:537,t:1527271948757};\\\", \\\"{x:1004,y:537,t:1527271948773};\\\", \\\"{x:998,y:538,t:1527271948791};\\\", \\\"{x:996,y:538,t:1527271948807};\\\", \\\"{x:986,y:541,t:1527271948824};\\\", \\\"{x:967,y:543,t:1527271948840};\\\", \\\"{x:944,y:545,t:1527271948859};\\\", \\\"{x:923,y:545,t:1527271948873};\\\", \\\"{x:902,y:545,t:1527271948889};\\\", \\\"{x:898,y:545,t:1527271948898};\\\", \\\"{x:891,y:546,t:1527271948915};\\\", \\\"{x:887,y:548,t:1527271948932};\\\", \\\"{x:883,y:550,t:1527271948948};\\\", \\\"{x:881,y:550,t:1527271948965};\\\", \\\"{x:876,y:551,t:1527271948982};\\\", \\\"{x:876,y:552,t:1527271948998};\\\", \\\"{x:875,y:553,t:1527271949016};\\\", \\\"{x:874,y:553,t:1527271949032};\\\", \\\"{x:873,y:554,t:1527271949049};\\\", \\\"{x:871,y:554,t:1527271949066};\\\", \\\"{x:867,y:556,t:1527271949083};\\\", \\\"{x:863,y:557,t:1527271949099};\\\", \\\"{x:862,y:558,t:1527271949117};\\\", \\\"{x:860,y:560,t:1527271949146};\\\", \\\"{x:859,y:560,t:1527271949154};\\\", \\\"{x:858,y:561,t:1527271949171};\\\", \\\"{x:857,y:562,t:1527271949210};\\\", \\\"{x:856,y:563,t:1527271981978};\\\", \\\"{x:855,y:564,t:1527271981985};\\\", \\\"{x:851,y:566,t:1527271982002};\\\", \\\"{x:848,y:569,t:1527271982019};\\\", \\\"{x:845,y:571,t:1527271982036};\\\", \\\"{x:844,y:574,t:1527271982053};\\\", \\\"{x:842,y:575,t:1527271982069};\\\", \\\"{x:839,y:578,t:1527271982086};\\\", \\\"{x:833,y:583,t:1527271982103};\\\", \\\"{x:830,y:585,t:1527271982121};\\\", \\\"{x:824,y:586,t:1527271982135};\\\", \\\"{x:817,y:591,t:1527271982152};\\\", \\\"{x:810,y:594,t:1527271982176};\\\", \\\"{x:808,y:595,t:1527271982192};\\\", \\\"{x:801,y:598,t:1527271982210};\\\", \\\"{x:795,y:600,t:1527271982226};\\\", \\\"{x:791,y:602,t:1527271982243};\\\", \\\"{x:788,y:603,t:1527271982260};\\\", \\\"{x:776,y:606,t:1527271982276};\\\", \\\"{x:759,y:613,t:1527271982293};\\\", \\\"{x:747,y:614,t:1527271982309};\\\", \\\"{x:731,y:617,t:1527271982327};\\\", \\\"{x:722,y:617,t:1527271982345};\\\", \\\"{x:719,y:618,t:1527271982360};\\\", \\\"{x:718,y:618,t:1527271982377};\\\", \\\"{x:716,y:618,t:1527271982392};\\\", \\\"{x:714,y:618,t:1527271982442};\\\", \\\"{x:709,y:618,t:1527271982460};\\\", \\\"{x:708,y:618,t:1527271982482};\\\", \\\"{x:701,y:620,t:1527271982506};\\\", \\\"{x:697,y:620,t:1527271982514};\\\", \\\"{x:694,y:620,t:1527271982527};\\\", \\\"{x:685,y:620,t:1527271982543};\\\", \\\"{x:675,y:620,t:1527271982560};\\\", \\\"{x:672,y:620,t:1527271982577};\\\", \\\"{x:671,y:620,t:1527271982715};\\\", \\\"{x:670,y:620,t:1527271982726};\\\", \\\"{x:668,y:621,t:1527271982743};\\\", \\\"{x:667,y:621,t:1527271982760};\\\", \\\"{x:666,y:621,t:1527271982776};\\\", \\\"{x:660,y:621,t:1527271982794};\\\", \\\"{x:656,y:619,t:1527271982810};\\\", \\\"{x:654,y:617,t:1527271982827};\\\", \\\"{x:652,y:617,t:1527271982843};\\\", \\\"{x:651,y:617,t:1527271982860};\\\", \\\"{x:647,y:616,t:1527271984442};\\\", \\\"{x:635,y:611,t:1527271984450};\\\", \\\"{x:629,y:607,t:1527271984461};\\\", \\\"{x:616,y:598,t:1527271984477};\\\", \\\"{x:608,y:592,t:1527271984495};\\\", \\\"{x:599,y:591,t:1527271984512};\\\", \\\"{x:596,y:591,t:1527271984987};\\\", \\\"{x:595,y:592,t:1527271984995};\\\", \\\"{x:595,y:594,t:1527271985034};\\\", \\\"{x:595,y:595,t:1527271985050};\\\", \\\"{x:596,y:596,t:1527271985063};\\\", \\\"{x:597,y:596,t:1527271985146};\\\", \\\"{x:598,y:596,t:1527271985161};\\\", \\\"{x:599,y:596,t:1527271985314};\\\", \\\"{x:599,y:597,t:1527271985402};\\\", \\\"{x:599,y:599,t:1527271985433};\\\", \\\"{x:599,y:600,t:1527271985446};\\\", \\\"{x:599,y:601,t:1527271985466};\\\", \\\"{x:599,y:602,t:1527271985479};\\\", \\\"{x:599,y:604,t:1527271985496};\\\", \\\"{x:599,y:605,t:1527271985512};\\\", \\\"{x:599,y:607,t:1527271985528};\\\", \\\"{x:600,y:607,t:1527271985545};\\\", \\\"{x:600,y:609,t:1527271985569};\\\", \\\"{x:601,y:610,t:1527271985618};\\\", \\\"{x:604,y:610,t:1527271986002};\\\", \\\"{x:605,y:610,t:1527271986017};\\\", \\\"{x:605,y:609,t:1527271986030};\\\", \\\"{x:611,y:606,t:1527271986046};\\\", \\\"{x:612,y:606,t:1527271986163};\\\", \\\"{x:615,y:606,t:1527271987074};\\\", \\\"{x:646,y:613,t:1527271987082};\\\", \\\"{x:649,y:620,t:1527271987097};\\\", \\\"{x:678,y:630,t:1527271987113};\\\", \\\"{x:714,y:647,t:1527271987130};\\\", \\\"{x:727,y:652,t:1527271987147};\\\", \\\"{x:732,y:656,t:1527271987163};\\\", \\\"{x:739,y:658,t:1527271987180};\\\", \\\"{x:741,y:659,t:1527271987197};\\\", \\\"{x:743,y:659,t:1527271987213};\\\", \\\"{x:750,y:659,t:1527271987229};\\\", \\\"{x:754,y:660,t:1527271987246};\\\", \\\"{x:756,y:662,t:1527271987264};\\\", \\\"{x:758,y:663,t:1527271987280};\\\", \\\"{x:759,y:665,t:1527271987296};\\\", \\\"{x:760,y:668,t:1527271987322};\\\", \\\"{x:760,y:670,t:1527271987346};\\\", \\\"{x:761,y:670,t:1527271987353};\\\", \\\"{x:761,y:671,t:1527271987370};\\\", \\\"{x:762,y:673,t:1527271987385};\\\", \\\"{x:767,y:673,t:1527271987396};\\\", \\\"{x:782,y:677,t:1527271987414};\\\", \\\"{x:793,y:678,t:1527271987429};\\\", \\\"{x:826,y:684,t:1527271987446};\\\", \\\"{x:914,y:691,t:1527271987464};\\\", \\\"{x:1025,y:707,t:1527271987481};\\\", \\\"{x:1111,y:722,t:1527271987496};\\\", \\\"{x:1202,y:730,t:1527271987513};\\\", \\\"{x:1219,y:730,t:1527271987531};\\\", \\\"{x:1230,y:728,t:1527271987546};\\\", \\\"{x:1235,y:729,t:1527271987563};\\\", \\\"{x:1235,y:731,t:1527271991858};\\\", \\\"{x:1232,y:734,t:1527271991874};\\\", \\\"{x:1223,y:737,t:1527271991885};\\\", \\\"{x:1203,y:753,t:1527271991900};\\\", \\\"{x:1162,y:773,t:1527271991917};\\\", \\\"{x:1086,y:810,t:1527271991935};\\\", \\\"{x:1080,y:813,t:1527271991950};\\\", \\\"{x:975,y:869,t:1527271991967};\\\", \\\"{x:860,y:940,t:1527271991984};\\\", \\\"{x:765,y:1005,t:1527271992000};\\\", \\\"{x:701,y:1049,t:1527271992016};\\\", \\\"{x:641,y:1093,t:1527271992033};\\\", \\\"{x:619,y:1105,t:1527271992049};\\\", \\\"{x:608,y:1112,t:1527271992067};\\\", \\\"{x:599,y:1117,t:1527271992084};\\\", \\\"{x:592,y:1123,t:1527271992101};\\\", \\\"{x:583,y:1126,t:1527271992116};\\\", \\\"{x:576,y:1130,t:1527271992133};\\\", \\\"{x:574,y:1130,t:1527271992150};\\\", \\\"{x:565,y:1135,t:1527271992167};\\\", \\\"{x:549,y:1145,t:1527271992183};\\\", \\\"{x:525,y:1150,t:1527271992201};\\\", \\\"{x:509,y:1154,t:1527271992217};\\\", \\\"{x:507,y:1154,t:1527271992249};\\\", \\\"{x:505,y:1154,t:1527271992258};\\\", \\\"{x:497,y:1154,t:1527271992266};\\\", \\\"{x:476,y:1160,t:1527271992284};\\\", \\\"{x:444,y:1161,t:1527271992301};\\\", \\\"{x:438,y:1160,t:1527271992317};\\\", \\\"{x:433,y:1161,t:1527271992334};\\\", \\\"{x:418,y:1163,t:1527271992351};\\\", \\\"{x:386,y:1165,t:1527271992368};\\\", \\\"{x:340,y:1164,t:1527271992385};\\\", \\\"{x:254,y:1157,t:1527271992401};\\\", \\\"{x:205,y:1152,t:1527271992417};\\\", \\\"{x:172,y:1150,t:1527271992434};\\\", \\\"{x:160,y:1151,t:1527271992452};\\\", \\\"{x:137,y:1151,t:1527271992467};\\\", \\\"{x:114,y:1151,t:1527271992485};\\\", \\\"{x:91,y:1151,t:1527271992501};\\\", \\\"{x:74,y:1152,t:1527271992517};\\\", \\\"{x:55,y:1155,t:1527271992534};\\\", \\\"{x:41,y:1156,t:1527271992551};\\\", \\\"{x:30,y:1162,t:1527271992567};\\\", \\\"{x:18,y:1165,t:1527271992584};\\\", \\\"{x:9,y:1166,t:1527271992601};\\\", \\\"{x:5,y:1164,t:1527271992618};\\\", \\\"{x:4,y:1163,t:1527271992635};\\\", \\\"{x:3,y:1163,t:1527271992803};\\\", \\\"{x:7,y:1161,t:1527271992818};\\\", \\\"{x:9,y:1161,t:1527271992834};\\\", \\\"{x:13,y:1161,t:1527271992852};\\\", \\\"{x:16,y:1161,t:1527271992868};\\\", \\\"{x:17,y:1161,t:1527271992884};\\\", \\\"{x:18,y:1161,t:1527271992922};\\\", \\\"{x:23,y:1160,t:1527271992934};\\\", \\\"{x:37,y:1148,t:1527271992952};\\\", \\\"{x:51,y:1133,t:1527271992968};\\\", \\\"{x:79,y:1082,t:1527271992984};\\\", \\\"{x:95,y:1038,t:1527271993001};\\\", \\\"{x:105,y:935,t:1527271993018};\\\", \\\"{x:100,y:860,t:1527271993034};\\\", \\\"{x:90,y:837,t:1527271993052};\\\", \\\"{x:58,y:795,t:1527271993068};\\\", \\\"{x:46,y:781,t:1527271993084};\\\", \\\"{x:7,y:753,t:1527271993102};\\\", \\\"{x:0,y:725,t:1527271993118};\\\", \\\"{x:0,y:706,t:1527271993135};\\\", \\\"{x:0,y:681,t:1527271993152};\\\", \\\"{x:0,y:665,t:1527271993169};\\\", \\\"{x:0,y:649,t:1527271993185};\\\", \\\"{x:0,y:637,t:1527271993202};\\\", \\\"{x:0,y:623,t:1527271993217};\\\", \\\"{x:0,y:614,t:1527271993235};\\\", \\\"{x:0,y:594,t:1527271993252};\\\", \\\"{x:0,y:580,t:1527271993268};\\\", \\\"{x:0,y:528,t:1527271993285};\\\", \\\"{x:0,y:416,t:1527271993301};\\\", \\\"{x:0,y:305,t:1527271993318};\\\", \\\"{x:5,y:260,t:1527271993335};\\\", \\\"{x:40,y:175,t:1527271993352};\\\", \\\"{x:80,y:112,t:1527271993368};\\\", \\\"{x:98,y:87,t:1527271993385};\\\", \\\"{x:114,y:71,t:1527271993401};\\\", \\\"{x:129,y:54,t:1527271993418};\\\", \\\"{x:139,y:44,t:1527271993435};\\\", \\\"{x:156,y:40,t:1527271993451};\\\", \\\"{x:195,y:38,t:1527271993468};\\\", \\\"{x:282,y:41,t:1527271993485};\\\", \\\"{x:381,y:49,t:1527271993501};\\\", \\\"{x:501,y:57,t:1527271993518};\\\", \\\"{x:652,y:68,t:1527271993535};\\\", \\\"{x:797,y:77,t:1527271993551};\\\", \\\"{x:960,y:77,t:1527271993568};\\\", \\\"{x:1099,y:96,t:1527271993585};\\\", \\\"{x:1305,y:144,t:1527271993601};\\\", \\\"{x:1408,y:164,t:1527271993618};\\\", \\\"{x:1448,y:185,t:1527271993635};\\\", \\\"{x:1457,y:188,t:1527271993652};\\\", \\\"{x:1460,y:194,t:1527271993668};\\\", \\\"{x:1461,y:194,t:1527271993685};\\\", \\\"{x:1462,y:194,t:1527271993851};\\\", \\\"{x:1463,y:195,t:1527271993858};\\\", \\\"{x:1463,y:197,t:1527271993868};\\\", \\\"{x:1463,y:203,t:1527271993886};\\\", \\\"{x:1463,y:208,t:1527271993902};\\\", \\\"{x:1464,y:209,t:1527271994026};\\\", \\\"{x:1466,y:209,t:1527271994036};\\\", \\\"{x:1470,y:209,t:1527271994052};\\\", \\\"{x:1473,y:206,t:1527271994069};\\\", \\\"{x:1480,y:202,t:1527271994086};\\\", \\\"{x:1485,y:197,t:1527271994102};\\\", \\\"{x:1489,y:193,t:1527271994119};\\\", \\\"{x:1490,y:191,t:1527271994136};\\\", \\\"{x:1490,y:188,t:1527271994152};\\\", \\\"{x:1490,y:185,t:1527271994170};\\\", \\\"{x:1490,y:182,t:1527271994186};\\\", \\\"{x:1489,y:179,t:1527271994203};\\\", \\\"{x:1489,y:177,t:1527271994220};\\\", \\\"{x:1489,y:174,t:1527271994236};\\\", \\\"{x:1489,y:173,t:1527271994252};\\\", \\\"{x:1489,y:172,t:1527271994270};\\\", \\\"{x:1489,y:171,t:1527271994286};\\\", \\\"{x:1489,y:169,t:1527271994302};\\\", \\\"{x:1489,y:168,t:1527271994319};\\\", \\\"{x:1489,y:167,t:1527271994335};\\\", \\\"{x:1488,y:166,t:1527271994547};\\\", \\\"{x:1487,y:166,t:1527271994586};\\\", \\\"{x:1486,y:166,t:1527271994603};\\\", \\\"{x:1485,y:166,t:1527271994637};\\\", \\\"{x:1484,y:166,t:1527271994652};\\\", \\\"{x:1481,y:164,t:1527271994698};\\\", \\\"{x:1479,y:164,t:1527271994722};\\\", \\\"{x:1477,y:164,t:1527271994986};\\\", \\\"{x:1472,y:164,t:1527271995003};\\\", \\\"{x:1470,y:171,t:1527271995020};\\\", \\\"{x:1465,y:184,t:1527271995036};\\\", \\\"{x:1463,y:199,t:1527271995054};\\\", \\\"{x:1457,y:211,t:1527271995069};\\\", \\\"{x:1454,y:238,t:1527271995087};\\\", \\\"{x:1453,y:262,t:1527271995104};\\\", \\\"{x:1451,y:276,t:1527271995119};\\\", \\\"{x:1451,y:284,t:1527271995137};\\\", \\\"{x:1451,y:296,t:1527271995154};\\\", \\\"{x:1451,y:315,t:1527271995170};\\\", \\\"{x:1451,y:326,t:1527271995186};\\\", \\\"{x:1451,y:332,t:1527271995203};\\\", \\\"{x:1451,y:335,t:1527271995219};\\\", \\\"{x:1451,y:341,t:1527271995237};\\\", \\\"{x:1451,y:346,t:1527271995253};\\\", \\\"{x:1453,y:354,t:1527271995269};\\\", \\\"{x:1453,y:367,t:1527271995286};\\\", \\\"{x:1453,y:374,t:1527271995304};\\\", \\\"{x:1449,y:378,t:1527271995320};\\\", \\\"{x:1445,y:390,t:1527271995336};\\\", \\\"{x:1443,y:395,t:1527271995354};\\\", \\\"{x:1436,y:402,t:1527271995370};\\\", \\\"{x:1424,y:419,t:1527271995387};\\\", \\\"{x:1403,y:441,t:1527271995403};\\\", \\\"{x:1389,y:458,t:1527271995419};\\\", \\\"{x:1371,y:472,t:1527271995436};\\\", \\\"{x:1353,y:488,t:1527271995454};\\\", \\\"{x:1343,y:496,t:1527271995469};\\\", \\\"{x:1342,y:497,t:1527271995487};\\\", \\\"{x:1340,y:498,t:1527271995699};\\\", \\\"{x:1339,y:499,t:1527271995826};\\\", \\\"{x:1339,y:500,t:1527271995837};\\\", \\\"{x:1337,y:501,t:1527271995854};\\\", \\\"{x:1335,y:501,t:1527271995870};\\\", \\\"{x:1332,y:501,t:1527271995888};\\\", \\\"{x:1331,y:501,t:1527271995902};\\\", \\\"{x:1329,y:501,t:1527271995921};\\\", \\\"{x:1328,y:501,t:1527271995936};\\\", \\\"{x:1324,y:501,t:1527271995952};\\\", \\\"{x:1323,y:501,t:1527271995977};\\\", \\\"{x:1323,y:500,t:1527271996626};\\\", \\\"{x:1322,y:500,t:1527272002060};\\\", \\\"{x:1310,y:502,t:1527272002067};\\\", \\\"{x:1303,y:505,t:1527272002085};\\\", \\\"{x:1204,y:532,t:1527272002101};\\\", \\\"{x:1128,y:558,t:1527272002118};\\\", \\\"{x:1055,y:581,t:1527272002135};\\\", \\\"{x:984,y:609,t:1527272002151};\\\", \\\"{x:927,y:629,t:1527272002168};\\\", \\\"{x:881,y:645,t:1527272002184};\\\", \\\"{x:865,y:657,t:1527272002201};\\\", \\\"{x:856,y:663,t:1527272002219};\\\", \\\"{x:836,y:683,t:1527272002235};\\\", \\\"{x:822,y:698,t:1527272002252};\\\", \\\"{x:753,y:713,t:1527272002267};\\\", \\\"{x:685,y:727,t:1527272002284};\\\", \\\"{x:635,y:741,t:1527272002301};\\\", \\\"{x:591,y:754,t:1527272002319};\\\", \\\"{x:581,y:764,t:1527272002334};\\\", \\\"{x:558,y:769,t:1527272002352};\\\", \\\"{x:548,y:771,t:1527272002369};\\\", \\\"{x:546,y:772,t:1527272002532};\\\", \\\"{x:545,y:771,t:1527272002547};\\\", \\\"{x:544,y:767,t:1527272002555};\\\", \\\"{x:543,y:763,t:1527272002568};\\\", \\\"{x:543,y:756,t:1527272002584};\\\", \\\"{x:542,y:753,t:1527272002601};\\\", \\\"{x:542,y:752,t:1527272002618};\\\", \\\"{x:541,y:752,t:1527272002635};\\\", \\\"{x:541,y:751,t:1527272002715};\\\", \\\"{x:541,y:750,t:1527272002731};\\\", \\\"{x:541,y:748,t:1527272002740};\\\", \\\"{x:541,y:747,t:1527272002866};\\\", \\\"{x:541,y:743,t:1527272020668};\\\", \\\"{x:549,y:738,t:1527272020682};\\\", \\\"{x:558,y:733,t:1527272020699};\\\" ] }, { \\\"rt\\\": 8082, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 467150, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:557,y:729,t:1527272042476};\\\", \\\"{x:555,y:724,t:1527272042483};\\\", \\\"{x:546,y:717,t:1527272042502};\\\", \\\"{x:535,y:705,t:1527272042516};\\\", \\\"{x:525,y:701,t:1527272042534};\\\", \\\"{x:521,y:694,t:1527272042552};\\\", \\\"{x:514,y:680,t:1527272042568};\\\", \\\"{x:506,y:674,t:1527272042585};\\\", \\\"{x:504,y:672,t:1527272042601};\\\", \\\"{x:504,y:671,t:1527272042618};\\\", \\\"{x:503,y:669,t:1527272042635};\\\", \\\"{x:504,y:667,t:1527272042691};\\\", \\\"{x:504,y:666,t:1527272042747};\\\", \\\"{x:504,y:665,t:1527272042795};\\\", \\\"{x:505,y:664,t:1527272042811};\\\", \\\"{x:506,y:664,t:1527272042818};\\\", \\\"{x:508,y:662,t:1527272042834};\\\", \\\"{x:509,y:662,t:1527272042852};\\\", \\\"{x:510,y:661,t:1527272042868};\\\", \\\"{x:509,y:661,t:1527272043282};\\\", \\\"{x:506,y:661,t:1527272043306};\\\", \\\"{x:504,y:661,t:1527272043371};\\\", \\\"{x:503,y:661,t:1527272043385};\\\", \\\"{x:494,y:663,t:1527272043407};\\\", \\\"{x:480,y:664,t:1527272043418};\\\", \\\"{x:421,y:664,t:1527272043435};\\\", \\\"{x:410,y:664,t:1527272043451};\\\", \\\"{x:396,y:664,t:1527272043468};\\\", \\\"{x:390,y:664,t:1527272043486};\\\", \\\"{x:389,y:664,t:1527272043501};\\\", \\\"{x:388,y:664,t:1527272043682};\\\", \\\"{x:387,y:664,t:1527272043698};\\\", \\\"{x:386,y:664,t:1527272043714};\\\", \\\"{x:382,y:664,t:1527272043722};\\\", \\\"{x:380,y:661,t:1527272043738};\\\", \\\"{x:375,y:658,t:1527272043752};\\\", \\\"{x:359,y:646,t:1527272043769};\\\", \\\"{x:346,y:638,t:1527272043786};\\\", \\\"{x:341,y:632,t:1527272043802};\\\", \\\"{x:338,y:627,t:1527272043820};\\\", \\\"{x:337,y:625,t:1527272043835};\\\", \\\"{x:338,y:622,t:1527272043882};\\\", \\\"{x:341,y:622,t:1527272043890};\\\", \\\"{x:342,y:621,t:1527272043901};\\\", \\\"{x:345,y:617,t:1527272044210};\\\", \\\"{x:345,y:614,t:1527272044218};\\\", \\\"{x:347,y:607,t:1527272044234};\\\", \\\"{x:347,y:605,t:1527272044251};\\\", \\\"{x:347,y:604,t:1527272044290};\\\", \\\"{x:348,y:603,t:1527272044301};\\\", \\\"{x:356,y:593,t:1527272044318};\\\", \\\"{x:366,y:574,t:1527272044334};\\\", \\\"{x:374,y:566,t:1527272044352};\\\", \\\"{x:379,y:563,t:1527272044369};\\\", \\\"{x:381,y:562,t:1527272044386};\\\", \\\"{x:385,y:559,t:1527272044402};\\\", \\\"{x:386,y:558,t:1527272044498};\\\", \\\"{x:387,y:557,t:1527272044506};\\\", \\\"{x:390,y:557,t:1527272044519};\\\", \\\"{x:391,y:557,t:1527272044535};\\\", \\\"{x:392,y:557,t:1527272045187};\\\", \\\"{x:391,y:559,t:1527272045203};\\\", \\\"{x:379,y:562,t:1527272045220};\\\", \\\"{x:375,y:564,t:1527272045238};\\\", \\\"{x:375,y:565,t:1527272045266};\\\", \\\"{x:376,y:565,t:1527272045274};\\\", \\\"{x:388,y:565,t:1527272045285};\\\", \\\"{x:416,y:565,t:1527272045302};\\\", \\\"{x:430,y:565,t:1527272045319};\\\", \\\"{x:450,y:562,t:1527272045337};\\\", \\\"{x:469,y:556,t:1527272045353};\\\", \\\"{x:475,y:554,t:1527272045370};\\\", \\\"{x:477,y:554,t:1527272045386};\\\", \\\"{x:478,y:553,t:1527272045531};\\\", \\\"{x:483,y:550,t:1527272045538};\\\", \\\"{x:492,y:545,t:1527272045553};\\\", \\\"{x:524,y:530,t:1527272045572};\\\", \\\"{x:531,y:520,t:1527272045587};\\\", \\\"{x:558,y:509,t:1527272045604};\\\", \\\"{x:570,y:502,t:1527272045620};\\\", \\\"{x:575,y:499,t:1527272045636};\\\", \\\"{x:576,y:499,t:1527272045654};\\\", \\\"{x:577,y:499,t:1527272045915};\\\", \\\"{x:579,y:499,t:1527272045930};\\\", \\\"{x:583,y:499,t:1527272046227};\\\", \\\"{x:593,y:499,t:1527272046238};\\\", \\\"{x:599,y:504,t:1527272046254};\\\", \\\"{x:616,y:510,t:1527272046271};\\\", \\\"{x:658,y:523,t:1527272046288};\\\", \\\"{x:729,y:539,t:1527272046305};\\\", \\\"{x:775,y:555,t:1527272046320};\\\", \\\"{x:787,y:566,t:1527272046338};\\\", \\\"{x:787,y:570,t:1527272046354};\\\", \\\"{x:789,y:572,t:1527272046371};\\\", \\\"{x:790,y:572,t:1527272046475};\\\", \\\"{x:795,y:572,t:1527272046488};\\\", \\\"{x:801,y:568,t:1527272046504};\\\", \\\"{x:807,y:567,t:1527272046520};\\\", \\\"{x:810,y:565,t:1527272046538};\\\", \\\"{x:817,y:563,t:1527272046555};\\\", \\\"{x:823,y:560,t:1527272046572};\\\", \\\"{x:826,y:559,t:1527272046587};\\\", \\\"{x:833,y:555,t:1527272046605};\\\", \\\"{x:835,y:554,t:1527272046621};\\\", \\\"{x:836,y:552,t:1527272046638};\\\", \\\"{x:837,y:551,t:1527272046658};\\\", \\\"{x:837,y:550,t:1527272047050};\\\", \\\"{x:831,y:549,t:1527272047058};\\\", \\\"{x:824,y:549,t:1527272047071};\\\", \\\"{x:820,y:549,t:1527272047087};\\\", \\\"{x:817,y:548,t:1527272047104};\\\", \\\"{x:810,y:546,t:1527272047129};\\\", \\\"{x:801,y:545,t:1527272047138};\\\", \\\"{x:792,y:541,t:1527272047155};\\\", \\\"{x:787,y:540,t:1527272047171};\\\", \\\"{x:786,y:540,t:1527272047188};\\\", \\\"{x:784,y:540,t:1527272047205};\\\", \\\"{x:778,y:539,t:1527272047222};\\\", \\\"{x:771,y:536,t:1527272047238};\\\", \\\"{x:761,y:532,t:1527272047255};\\\", \\\"{x:753,y:527,t:1527272047272};\\\", \\\"{x:746,y:525,t:1527272047288};\\\", \\\"{x:736,y:523,t:1527272047307};\\\", \\\"{x:721,y:522,t:1527272047322};\\\", \\\"{x:713,y:519,t:1527272047338};\\\", \\\"{x:712,y:519,t:1527272047363};\\\", \\\"{x:711,y:518,t:1527272047402};\\\", \\\"{x:706,y:518,t:1527272047419};\\\", \\\"{x:700,y:516,t:1527272047426};\\\", \\\"{x:693,y:516,t:1527272047439};\\\", \\\"{x:678,y:516,t:1527272047455};\\\", \\\"{x:671,y:516,t:1527272047472};\\\", \\\"{x:659,y:516,t:1527272047487};\\\", \\\"{x:651,y:516,t:1527272047505};\\\", \\\"{x:641,y:516,t:1527272047521};\\\", \\\"{x:639,y:516,t:1527272047538};\\\", \\\"{x:638,y:516,t:1527272047562};\\\", \\\"{x:637,y:516,t:1527272047572};\\\", \\\"{x:636,y:516,t:1527272047995};\\\", \\\"{x:635,y:516,t:1527272048006};\\\", \\\"{x:630,y:519,t:1527272048024};\\\", \\\"{x:623,y:523,t:1527272048038};\\\", \\\"{x:620,y:526,t:1527272048055};\\\", \\\"{x:620,y:530,t:1527272048073};\\\", \\\"{x:618,y:532,t:1527272048088};\\\", \\\"{x:614,y:538,t:1527272048105};\\\", \\\"{x:610,y:543,t:1527272048122};\\\", \\\"{x:608,y:546,t:1527272048139};\\\", \\\"{x:607,y:547,t:1527272048155};\\\", \\\"{x:607,y:544,t:1527272048242};\\\", \\\"{x:607,y:541,t:1527272048256};\\\", \\\"{x:611,y:536,t:1527272048272};\\\", \\\"{x:615,y:529,t:1527272048289};\\\", \\\"{x:620,y:519,t:1527272048307};\\\", \\\"{x:620,y:513,t:1527272048322};\\\", \\\"{x:620,y:508,t:1527272048338};\\\", \\\"{x:620,y:504,t:1527272048355};\\\", \\\"{x:620,y:502,t:1527272048373};\\\", \\\"{x:620,y:501,t:1527272048388};\\\", \\\"{x:620,y:500,t:1527272048426};\\\", \\\"{x:619,y:500,t:1527272048771};\\\", \\\"{x:618,y:500,t:1527272048778};\\\", \\\"{x:617,y:500,t:1527272048790};\\\", \\\"{x:613,y:503,t:1527272048805};\\\", \\\"{x:612,y:504,t:1527272048835};\\\", \\\"{x:609,y:507,t:1527272048842};\\\", \\\"{x:607,y:509,t:1527272048856};\\\", \\\"{x:606,y:510,t:1527272048872};\\\", \\\"{x:603,y:514,t:1527272048891};\\\", \\\"{x:602,y:516,t:1527272048921};\\\", \\\"{x:602,y:517,t:1527272048929};\\\", \\\"{x:599,y:520,t:1527272048940};\\\", \\\"{x:598,y:522,t:1527272048956};\\\", \\\"{x:595,y:525,t:1527272048973};\\\", \\\"{x:591,y:528,t:1527272049002};\\\", \\\"{x:589,y:531,t:1527272049017};\\\", \\\"{x:588,y:532,t:1527272049025};\\\", \\\"{x:586,y:535,t:1527272049039};\\\", \\\"{x:582,y:540,t:1527272049055};\\\", \\\"{x:577,y:546,t:1527272049073};\\\", \\\"{x:572,y:553,t:1527272049090};\\\", \\\"{x:569,y:560,t:1527272049107};\\\", \\\"{x:563,y:572,t:1527272049124};\\\", \\\"{x:550,y:594,t:1527272049140};\\\", \\\"{x:535,y:624,t:1527272049157};\\\", \\\"{x:521,y:640,t:1527272049173};\\\", \\\"{x:502,y:667,t:1527272049189};\\\", \\\"{x:491,y:689,t:1527272049206};\\\", \\\"{x:486,y:697,t:1527272049222};\\\", \\\"{x:484,y:700,t:1527272049239};\\\", \\\"{x:481,y:703,t:1527272049256};\\\", \\\"{x:479,y:707,t:1527272049273};\\\", \\\"{x:479,y:713,t:1527272049289};\\\", \\\"{x:478,y:716,t:1527272049306};\\\", \\\"{x:478,y:721,t:1527272049323};\\\", \\\"{x:477,y:726,t:1527272049340};\\\", \\\"{x:477,y:729,t:1527272049357};\\\", \\\"{x:477,y:730,t:1527272049378};\\\", \\\"{x:477,y:732,t:1527272049410};\\\", \\\"{x:477,y:733,t:1527272049651};\\\", \\\"{x:477,y:735,t:1527272049667};\\\" ] }, { \\\"rt\\\": 20795, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 489164, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:477,y:736,t:1527272053490};\\\", \\\"{x:456,y:737,t:1527272054131};\\\", \\\"{x:378,y:737,t:1527272054147};\\\", \\\"{x:279,y:730,t:1527272054163};\\\", \\\"{x:180,y:720,t:1527272054180};\\\", \\\"{x:152,y:720,t:1527272054194};\\\", \\\"{x:131,y:720,t:1527272054209};\\\", \\\"{x:137,y:719,t:1527272054250};\\\", \\\"{x:160,y:719,t:1527272054260};\\\", \\\"{x:194,y:722,t:1527272054276};\\\", \\\"{x:341,y:724,t:1527272054294};\\\", \\\"{x:467,y:723,t:1527272054312};\\\", \\\"{x:591,y:735,t:1527272054327};\\\", \\\"{x:682,y:744,t:1527272054344};\\\", \\\"{x:798,y:759,t:1527272054361};\\\", \\\"{x:819,y:770,t:1527272054376};\\\", \\\"{x:829,y:772,t:1527272054394};\\\", \\\"{x:826,y:772,t:1527272054459};\\\", \\\"{x:824,y:772,t:1527272054467};\\\", \\\"{x:820,y:772,t:1527272054476};\\\", \\\"{x:817,y:772,t:1527272054494};\\\", \\\"{x:812,y:772,t:1527272054511};\\\", \\\"{x:803,y:772,t:1527272054527};\\\", \\\"{x:797,y:772,t:1527272054544};\\\", \\\"{x:796,y:773,t:1527272054561};\\\", \\\"{x:794,y:773,t:1527272054603};\\\", \\\"{x:793,y:773,t:1527272054618};\\\", \\\"{x:789,y:773,t:1527272054627};\\\", \\\"{x:787,y:770,t:1527272054644};\\\", \\\"{x:785,y:770,t:1527272054662};\\\", \\\"{x:783,y:768,t:1527272054677};\\\", \\\"{x:781,y:765,t:1527272054698};\\\", \\\"{x:780,y:762,t:1527272054710};\\\", \\\"{x:778,y:757,t:1527272054727};\\\", \\\"{x:774,y:748,t:1527272054743};\\\", \\\"{x:774,y:744,t:1527272054761};\\\", \\\"{x:774,y:742,t:1527272054786};\\\", \\\"{x:774,y:741,t:1527272054794};\\\", \\\"{x:774,y:740,t:1527272054811};\\\", \\\"{x:775,y:736,t:1527272054828};\\\", \\\"{x:782,y:733,t:1527272054844};\\\", \\\"{x:788,y:729,t:1527272054861};\\\", \\\"{x:789,y:728,t:1527272054878};\\\", \\\"{x:791,y:727,t:1527272054893};\\\", \\\"{x:794,y:725,t:1527272054911};\\\", \\\"{x:795,y:725,t:1527272054928};\\\", \\\"{x:798,y:723,t:1527272054944};\\\", \\\"{x:799,y:723,t:1527272054961};\\\", \\\"{x:800,y:723,t:1527272054977};\\\", \\\"{x:801,y:723,t:1527272055001};\\\", \\\"{x:809,y:723,t:1527272055731};\\\", \\\"{x:814,y:723,t:1527272055745};\\\", \\\"{x:845,y:726,t:1527272055762};\\\", \\\"{x:868,y:728,t:1527272055778};\\\", \\\"{x:881,y:731,t:1527272055796};\\\", \\\"{x:892,y:734,t:1527272055813};\\\", \\\"{x:903,y:738,t:1527272055828};\\\", \\\"{x:905,y:738,t:1527272055845};\\\", \\\"{x:909,y:738,t:1527272055862};\\\", \\\"{x:912,y:739,t:1527272055879};\\\", \\\"{x:915,y:739,t:1527272055895};\\\", \\\"{x:917,y:740,t:1527272055912};\\\", \\\"{x:917,y:741,t:1527272056098};\\\", \\\"{x:917,y:742,t:1527272056112};\\\", \\\"{x:916,y:742,t:1527272056146};\\\", \\\"{x:916,y:745,t:1527272056595};\\\", \\\"{x:915,y:745,t:1527272056634};\\\", \\\"{x:914,y:745,t:1527272057019};\\\", \\\"{x:911,y:746,t:1527272057243};\\\", \\\"{x:909,y:748,t:1527272057770};\\\", \\\"{x:908,y:748,t:1527272057827};\\\", \\\"{x:907,y:748,t:1527272057867};\\\", \\\"{x:907,y:749,t:1527272057946};\\\", \\\"{x:906,y:750,t:1527272058003};\\\", \\\"{x:905,y:750,t:1527272058019};\\\", \\\"{x:904,y:751,t:1527272058030};\\\", \\\"{x:903,y:751,t:1527272058047};\\\", \\\"{x:902,y:751,t:1527272058074};\\\", \\\"{x:901,y:751,t:1527272058091};\\\", \\\"{x:899,y:751,t:1527272058122};\\\", \\\"{x:897,y:751,t:1527272058130};\\\", \\\"{x:894,y:751,t:1527272058146};\\\", \\\"{x:891,y:751,t:1527272058163};\\\", \\\"{x:889,y:751,t:1527272058180};\\\", \\\"{x:888,y:751,t:1527272058197};\\\", \\\"{x:886,y:751,t:1527272058214};\\\", \\\"{x:885,y:751,t:1527272058231};\\\", \\\"{x:878,y:751,t:1527272058247};\\\", \\\"{x:873,y:751,t:1527272058264};\\\", \\\"{x:871,y:751,t:1527272058280};\\\", \\\"{x:861,y:750,t:1527272058298};\\\", \\\"{x:849,y:747,t:1527272058314};\\\", \\\"{x:831,y:746,t:1527272058330};\\\", \\\"{x:827,y:746,t:1527272058354};\\\", \\\"{x:825,y:746,t:1527272058364};\\\", \\\"{x:821,y:745,t:1527272058380};\\\", \\\"{x:820,y:745,t:1527272058397};\\\", \\\"{x:817,y:745,t:1527272058414};\\\", \\\"{x:816,y:745,t:1527272058450};\\\", \\\"{x:815,y:745,t:1527272058722};\\\", \\\"{x:812,y:745,t:1527272058794};\\\", \\\"{x:811,y:746,t:1527272058810};\\\", \\\"{x:810,y:747,t:1527272058827};\\\", \\\"{x:809,y:747,t:1527272058843};\\\", \\\"{x:808,y:747,t:1527272058858};\\\", \\\"{x:807,y:748,t:1527272058869};\\\", \\\"{x:805,y:750,t:1527272058898};\\\", \\\"{x:803,y:750,t:1527272058914};\\\", \\\"{x:797,y:750,t:1527272058930};\\\", \\\"{x:794,y:750,t:1527272058947};\\\", \\\"{x:790,y:750,t:1527272058964};\\\", \\\"{x:788,y:750,t:1527272058980};\\\", \\\"{x:787,y:750,t:1527272058997};\\\", \\\"{x:784,y:750,t:1527272059014};\\\", \\\"{x:781,y:750,t:1527272059030};\\\", \\\"{x:780,y:750,t:1527272059048};\\\", \\\"{x:779,y:750,t:1527272059064};\\\", \\\"{x:778,y:750,t:1527272059082};\\\", \\\"{x:777,y:750,t:1527272059106};\\\", \\\"{x:776,y:750,t:1527272059114};\\\", \\\"{x:775,y:750,t:1527272059131};\\\", \\\"{x:770,y:750,t:1527272059148};\\\", \\\"{x:760,y:748,t:1527272059164};\\\", \\\"{x:758,y:748,t:1527272059181};\\\", \\\"{x:749,y:748,t:1527272059197};\\\", \\\"{x:737,y:748,t:1527272059214};\\\", \\\"{x:736,y:748,t:1527272059231};\\\", \\\"{x:735,y:748,t:1527272059247};\\\", \\\"{x:733,y:748,t:1527272059313};\\\", \\\"{x:731,y:746,t:1527272063045};\\\", \\\"{x:726,y:731,t:1527272063060};\\\", \\\"{x:723,y:721,t:1527272063078};\\\", \\\"{x:720,y:714,t:1527272063094};\\\", \\\"{x:720,y:713,t:1527272063110};\\\", \\\"{x:720,y:710,t:1527272063128};\\\", \\\"{x:722,y:706,t:1527272063143};\\\", \\\"{x:724,y:703,t:1527272063161};\\\", \\\"{x:726,y:698,t:1527272063178};\\\", \\\"{x:726,y:690,t:1527272063194};\\\", \\\"{x:725,y:687,t:1527272063211};\\\", \\\"{x:723,y:684,t:1527272063228};\\\", \\\"{x:703,y:666,t:1527272063244};\\\", \\\"{x:683,y:653,t:1527272063260};\\\", \\\"{x:653,y:634,t:1527272063277};\\\", \\\"{x:616,y:611,t:1527272063295};\\\", \\\"{x:588,y:594,t:1527272063310};\\\", \\\"{x:558,y:570,t:1527272063328};\\\", \\\"{x:551,y:563,t:1527272063338};\\\", \\\"{x:532,y:551,t:1527272063357};\\\", \\\"{x:531,y:550,t:1527272063373};\\\", \\\"{x:530,y:549,t:1527272063393};\\\", \\\"{x:526,y:548,t:1527272063411};\\\", \\\"{x:518,y:548,t:1527272063427};\\\", \\\"{x:508,y:550,t:1527272063444};\\\", \\\"{x:496,y:551,t:1527272063462};\\\", \\\"{x:486,y:555,t:1527272063478};\\\", \\\"{x:475,y:557,t:1527272063494};\\\", \\\"{x:468,y:562,t:1527272063510};\\\", \\\"{x:454,y:565,t:1527272063528};\\\", \\\"{x:444,y:568,t:1527272063544};\\\", \\\"{x:436,y:569,t:1527272063561};\\\", \\\"{x:407,y:569,t:1527272063578};\\\", \\\"{x:391,y:566,t:1527272063594};\\\", \\\"{x:340,y:561,t:1527272063612};\\\", \\\"{x:325,y:556,t:1527272063627};\\\", \\\"{x:310,y:551,t:1527272063644};\\\", \\\"{x:302,y:550,t:1527272063661};\\\", \\\"{x:301,y:550,t:1527272063678};\\\", \\\"{x:300,y:548,t:1527272064205};\\\", \\\"{x:299,y:548,t:1527272064212};\\\", \\\"{x:290,y:547,t:1527272064228};\\\", \\\"{x:287,y:545,t:1527272064245};\\\", \\\"{x:286,y:541,t:1527272064262};\\\", \\\"{x:284,y:540,t:1527272064278};\\\", \\\"{x:271,y:535,t:1527272064297};\\\", \\\"{x:264,y:534,t:1527272064310};\\\", \\\"{x:242,y:534,t:1527272064327};\\\", \\\"{x:226,y:531,t:1527272064345};\\\", \\\"{x:216,y:526,t:1527272064361};\\\", \\\"{x:203,y:526,t:1527272064378};\\\", \\\"{x:198,y:526,t:1527272064395};\\\", \\\"{x:197,y:526,t:1527272064412};\\\", \\\"{x:196,y:526,t:1527272064444};\\\", \\\"{x:193,y:526,t:1527272064540};\\\", \\\"{x:192,y:526,t:1527272064564};\\\", \\\"{x:189,y:526,t:1527272064578};\\\", \\\"{x:185,y:527,t:1527272064595};\\\", \\\"{x:181,y:534,t:1527272064613};\\\", \\\"{x:177,y:538,t:1527272064629};\\\", \\\"{x:176,y:539,t:1527272064645};\\\", \\\"{x:176,y:540,t:1527272064662};\\\", \\\"{x:178,y:540,t:1527272064907};\\\", \\\"{x:181,y:539,t:1527272064915};\\\", \\\"{x:184,y:539,t:1527272064929};\\\", \\\"{x:187,y:537,t:1527272064945};\\\", \\\"{x:198,y:537,t:1527272064962};\\\", \\\"{x:219,y:537,t:1527272064979};\\\", \\\"{x:233,y:541,t:1527272064995};\\\", \\\"{x:244,y:544,t:1527272065012};\\\", \\\"{x:260,y:549,t:1527272065029};\\\", \\\"{x:272,y:548,t:1527272065045};\\\", \\\"{x:272,y:547,t:1527272065062};\\\", \\\"{x:275,y:546,t:1527272065081};\\\", \\\"{x:277,y:546,t:1527272065095};\\\", \\\"{x:280,y:545,t:1527272065112};\\\", \\\"{x:284,y:544,t:1527272065139};\\\", \\\"{x:288,y:543,t:1527272065147};\\\", \\\"{x:293,y:543,t:1527272065162};\\\", \\\"{x:304,y:542,t:1527272065179};\\\", \\\"{x:308,y:540,t:1527272065195};\\\", \\\"{x:314,y:540,t:1527272065212};\\\", \\\"{x:317,y:540,t:1527272065229};\\\", \\\"{x:321,y:540,t:1527272065246};\\\", \\\"{x:324,y:541,t:1527272065262};\\\", \\\"{x:327,y:541,t:1527272065279};\\\", \\\"{x:331,y:541,t:1527272065297};\\\", \\\"{x:336,y:542,t:1527272065313};\\\", \\\"{x:342,y:545,t:1527272065329};\\\", \\\"{x:347,y:546,t:1527272065346};\\\", \\\"{x:354,y:547,t:1527272065362};\\\", \\\"{x:359,y:552,t:1527272065379};\\\", \\\"{x:365,y:555,t:1527272065396};\\\", \\\"{x:377,y:557,t:1527272065413};\\\", \\\"{x:379,y:559,t:1527272065430};\\\", \\\"{x:383,y:560,t:1527272065446};\\\", \\\"{x:384,y:561,t:1527272065462};\\\", \\\"{x:389,y:562,t:1527272065479};\\\", \\\"{x:396,y:564,t:1527272065496};\\\", \\\"{x:399,y:565,t:1527272065512};\\\", \\\"{x:409,y:567,t:1527272065529};\\\", \\\"{x:426,y:570,t:1527272065547};\\\", \\\"{x:436,y:572,t:1527272065562};\\\", \\\"{x:449,y:573,t:1527272065579};\\\", \\\"{x:458,y:573,t:1527272065596};\\\", \\\"{x:487,y:575,t:1527272065611};\\\", \\\"{x:499,y:575,t:1527272065630};\\\", \\\"{x:515,y:580,t:1527272065646};\\\", \\\"{x:533,y:583,t:1527272065662};\\\", \\\"{x:547,y:585,t:1527272065679};\\\", \\\"{x:561,y:591,t:1527272065696};\\\", \\\"{x:561,y:592,t:1527272065723};\\\", \\\"{x:561,y:593,t:1527272065988};\\\", \\\"{x:562,y:595,t:1527272065998};\\\", \\\"{x:571,y:600,t:1527272066012};\\\", \\\"{x:579,y:604,t:1527272066030};\\\", \\\"{x:591,y:609,t:1527272066045};\\\", \\\"{x:605,y:613,t:1527272066063};\\\", \\\"{x:619,y:616,t:1527272066080};\\\", \\\"{x:621,y:618,t:1527272066096};\\\", \\\"{x:625,y:618,t:1527272066113};\\\", \\\"{x:628,y:618,t:1527272066130};\\\", \\\"{x:632,y:618,t:1527272066146};\\\", \\\"{x:640,y:618,t:1527272066163};\\\", \\\"{x:642,y:617,t:1527272066179};\\\", \\\"{x:647,y:614,t:1527272066197};\\\", \\\"{x:649,y:613,t:1527272066213};\\\", \\\"{x:650,y:613,t:1527272066230};\\\", \\\"{x:652,y:609,t:1527272066246};\\\", \\\"{x:653,y:608,t:1527272066263};\\\", \\\"{x:649,y:605,t:1527272066284};\\\", \\\"{x:647,y:605,t:1527272066300};\\\", \\\"{x:626,y:603,t:1527272066313};\\\", \\\"{x:542,y:599,t:1527272066331};\\\", \\\"{x:456,y:588,t:1527272066346};\\\", \\\"{x:405,y:576,t:1527272066364};\\\", \\\"{x:396,y:572,t:1527272066380};\\\", \\\"{x:397,y:570,t:1527272066419};\\\", \\\"{x:399,y:568,t:1527272066430};\\\", \\\"{x:422,y:558,t:1527272066447};\\\", \\\"{x:478,y:549,t:1527272066464};\\\", \\\"{x:572,y:523,t:1527272066481};\\\", \\\"{x:671,y:501,t:1527272066499};\\\", \\\"{x:707,y:492,t:1527272066513};\\\", \\\"{x:762,y:474,t:1527272066531};\\\", \\\"{x:797,y:465,t:1527272066547};\\\", \\\"{x:807,y:460,t:1527272066563};\\\", \\\"{x:808,y:458,t:1527272066580};\\\", \\\"{x:811,y:458,t:1527272066675};\\\", \\\"{x:812,y:461,t:1527272066684};\\\", \\\"{x:813,y:462,t:1527272066697};\\\", \\\"{x:817,y:470,t:1527272066713};\\\", \\\"{x:817,y:471,t:1527272066730};\\\", \\\"{x:821,y:481,t:1527272066747};\\\", \\\"{x:828,y:494,t:1527272066764};\\\", \\\"{x:838,y:502,t:1527272066780};\\\", \\\"{x:842,y:506,t:1527272066797};\\\", \\\"{x:849,y:511,t:1527272066813};\\\", \\\"{x:850,y:513,t:1527272066831};\\\", \\\"{x:852,y:514,t:1527272066847};\\\", \\\"{x:850,y:515,t:1527272067380};\\\", \\\"{x:847,y:516,t:1527272067398};\\\", \\\"{x:841,y:519,t:1527272067416};\\\", \\\"{x:839,y:519,t:1527272067431};\\\", \\\"{x:837,y:521,t:1527272067447};\\\", \\\"{x:837,y:520,t:1527272067596};\\\", \\\"{x:838,y:520,t:1527272067603};\\\", \\\"{x:840,y:516,t:1527272067837};\\\", \\\"{x:840,y:513,t:1527272067848};\\\", \\\"{x:843,y:509,t:1527272067864};\\\", \\\"{x:845,y:504,t:1527272067881};\\\", \\\"{x:838,y:509,t:1527272068292};\\\", \\\"{x:830,y:515,t:1527272068300};\\\", \\\"{x:803,y:541,t:1527272068315};\\\", \\\"{x:757,y:572,t:1527272068331};\\\", \\\"{x:706,y:602,t:1527272068348};\\\", \\\"{x:687,y:617,t:1527272068365};\\\", \\\"{x:665,y:634,t:1527272068381};\\\", \\\"{x:648,y:647,t:1527272068398};\\\", \\\"{x:632,y:658,t:1527272068415};\\\", \\\"{x:624,y:664,t:1527272068431};\\\", \\\"{x:624,y:665,t:1527272068448};\\\", \\\"{x:624,y:666,t:1527272068628};\\\", \\\"{x:620,y:670,t:1527272068636};\\\", \\\"{x:614,y:673,t:1527272068650};\\\", \\\"{x:605,y:677,t:1527272068666};\\\", \\\"{x:582,y:690,t:1527272068683};\\\", \\\"{x:565,y:698,t:1527272068700};\\\", \\\"{x:563,y:699,t:1527272068716};\\\", \\\"{x:562,y:700,t:1527272068733};\\\", \\\"{x:561,y:700,t:1527272068844};\\\", \\\"{x:556,y:706,t:1527272068892};\\\", \\\"{x:553,y:709,t:1527272068900};\\\", \\\"{x:546,y:719,t:1527272068917};\\\", \\\"{x:535,y:731,t:1527272068935};\\\", \\\"{x:527,y:735,t:1527272068949};\\\", \\\"{x:519,y:742,t:1527272068965};\\\", \\\"{x:514,y:747,t:1527272068982};\\\", \\\"{x:513,y:748,t:1527272068998};\\\", \\\"{x:512,y:749,t:1527272069015};\\\", \\\"{x:508,y:752,t:1527272069032};\\\", \\\"{x:507,y:753,t:1527272069048};\\\" ] }, { \\\"rt\\\": 69211, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 559640, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -X -04 PM-M -F -G -F -B -X -03 PM-04 PM-04 PM-E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:766,t:1527272079363};\\\", \\\"{x:570,y:790,t:1527272079371};\\\", \\\"{x:708,y:827,t:1527272079387};\\\", \\\"{x:842,y:857,t:1527272079404};\\\", \\\"{x:917,y:865,t:1527272079422};\\\", \\\"{x:993,y:869,t:1527272079439};\\\", \\\"{x:1009,y:876,t:1527272079456};\\\", \\\"{x:1013,y:875,t:1527272079472};\\\", \\\"{x:1014,y:875,t:1527272079488};\\\", \\\"{x:1016,y:874,t:1527272079507};\\\", \\\"{x:1016,y:873,t:1527272079572};\\\", \\\"{x:1019,y:872,t:1527272079589};\\\", \\\"{x:1024,y:871,t:1527272079606};\\\", \\\"{x:1028,y:868,t:1527272079622};\\\", \\\"{x:1036,y:865,t:1527272079639};\\\", \\\"{x:1036,y:864,t:1527272079667};\\\", \\\"{x:1036,y:862,t:1527272079676};\\\", \\\"{x:1040,y:861,t:1527272079688};\\\", \\\"{x:1043,y:858,t:1527272079706};\\\", \\\"{x:1044,y:858,t:1527272079722};\\\", \\\"{x:1048,y:857,t:1527272079739};\\\", \\\"{x:1050,y:856,t:1527272079756};\\\", \\\"{x:1052,y:854,t:1527272079884};\\\", \\\"{x:1053,y:853,t:1527272079891};\\\", \\\"{x:1054,y:852,t:1527272079906};\\\", \\\"{x:1058,y:846,t:1527272079922};\\\", \\\"{x:1060,y:843,t:1527272079938};\\\", \\\"{x:1064,y:838,t:1527272079955};\\\", \\\"{x:1066,y:837,t:1527272079972};\\\", \\\"{x:1067,y:835,t:1527272079989};\\\", \\\"{x:1068,y:834,t:1527272080006};\\\", \\\"{x:1068,y:833,t:1527272080022};\\\", \\\"{x:1069,y:832,t:1527272080039};\\\", \\\"{x:1070,y:831,t:1527272080057};\\\", \\\"{x:1072,y:829,t:1527272080072};\\\", \\\"{x:1072,y:828,t:1527272080089};\\\", \\\"{x:1073,y:827,t:1527272080106};\\\", \\\"{x:1073,y:826,t:1527272080749};\\\", \\\"{x:1078,y:828,t:1527272080756};\\\", \\\"{x:1093,y:832,t:1527272080773};\\\", \\\"{x:1095,y:832,t:1527272080789};\\\", \\\"{x:1100,y:837,t:1527272080807};\\\", \\\"{x:1111,y:842,t:1527272080823};\\\", \\\"{x:1115,y:843,t:1527272080839};\\\", \\\"{x:1124,y:843,t:1527272080856};\\\", \\\"{x:1140,y:843,t:1527272080874};\\\", \\\"{x:1150,y:843,t:1527272080890};\\\", \\\"{x:1152,y:843,t:1527272080906};\\\", \\\"{x:1158,y:843,t:1527272080923};\\\", \\\"{x:1176,y:843,t:1527272080939};\\\", \\\"{x:1180,y:841,t:1527272080956};\\\", \\\"{x:1195,y:841,t:1527272080973};\\\", \\\"{x:1210,y:841,t:1527272080988};\\\", \\\"{x:1216,y:843,t:1527272081006};\\\", \\\"{x:1220,y:843,t:1527272081022};\\\", \\\"{x:1234,y:847,t:1527272081039};\\\", \\\"{x:1247,y:848,t:1527272081056};\\\", \\\"{x:1252,y:848,t:1527272081073};\\\", \\\"{x:1253,y:848,t:1527272081089};\\\", \\\"{x:1260,y:848,t:1527272081105};\\\", \\\"{x:1271,y:848,t:1527272081123};\\\", \\\"{x:1287,y:843,t:1527272081139};\\\", \\\"{x:1294,y:841,t:1527272081156};\\\", \\\"{x:1295,y:841,t:1527272081196};\\\", \\\"{x:1301,y:841,t:1527272081206};\\\", \\\"{x:1316,y:839,t:1527272081223};\\\", \\\"{x:1323,y:839,t:1527272081240};\\\", \\\"{x:1330,y:838,t:1527272081256};\\\", \\\"{x:1336,y:838,t:1527272081273};\\\", \\\"{x:1341,y:838,t:1527272081290};\\\", \\\"{x:1346,y:838,t:1527272081306};\\\", \\\"{x:1357,y:838,t:1527272081331};\\\", \\\"{x:1368,y:838,t:1527272081365};\\\", \\\"{x:1370,y:838,t:1527272081373};\\\", \\\"{x:1374,y:838,t:1527272081390};\\\", \\\"{x:1380,y:838,t:1527272081405};\\\", \\\"{x:1385,y:838,t:1527272081423};\\\", \\\"{x:1388,y:838,t:1527272081440};\\\", \\\"{x:1391,y:839,t:1527272081455};\\\", \\\"{x:1401,y:841,t:1527272081473};\\\", \\\"{x:1405,y:841,t:1527272081490};\\\", \\\"{x:1412,y:843,t:1527272081506};\\\", \\\"{x:1417,y:843,t:1527272081523};\\\", \\\"{x:1428,y:844,t:1527272081540};\\\", \\\"{x:1429,y:844,t:1527272081556};\\\", \\\"{x:1432,y:844,t:1527272081572};\\\", \\\"{x:1439,y:844,t:1527272081589};\\\", \\\"{x:1443,y:842,t:1527272081605};\\\", \\\"{x:1454,y:842,t:1527272081622};\\\", \\\"{x:1463,y:841,t:1527272081640};\\\", \\\"{x:1471,y:841,t:1527272081656};\\\", \\\"{x:1475,y:839,t:1527272081673};\\\", \\\"{x:1473,y:841,t:1527272082059};\\\", \\\"{x:1471,y:842,t:1527272082072};\\\", \\\"{x:1462,y:844,t:1527272082090};\\\", \\\"{x:1447,y:844,t:1527272082107};\\\", \\\"{x:1444,y:845,t:1527272082123};\\\", \\\"{x:1440,y:845,t:1527272082140};\\\", \\\"{x:1426,y:847,t:1527272082156};\\\", \\\"{x:1414,y:847,t:1527272082172};\\\", \\\"{x:1407,y:848,t:1527272082190};\\\", \\\"{x:1393,y:848,t:1527272082206};\\\", \\\"{x:1383,y:848,t:1527272082223};\\\", \\\"{x:1378,y:848,t:1527272082240};\\\", \\\"{x:1381,y:847,t:1527272082468};\\\", \\\"{x:1383,y:844,t:1527272082476};\\\", \\\"{x:1387,y:842,t:1527272082490};\\\", \\\"{x:1394,y:834,t:1527272082507};\\\", \\\"{x:1401,y:827,t:1527272082523};\\\", \\\"{x:1406,y:821,t:1527272082540};\\\", \\\"{x:1413,y:815,t:1527272082558};\\\", \\\"{x:1416,y:812,t:1527272082573};\\\", \\\"{x:1417,y:810,t:1527272082591};\\\", \\\"{x:1418,y:809,t:1527272082607};\\\", \\\"{x:1419,y:807,t:1527272082623};\\\", \\\"{x:1419,y:805,t:1527272082640};\\\", \\\"{x:1419,y:802,t:1527272082657};\\\", \\\"{x:1420,y:801,t:1527272082673};\\\", \\\"{x:1420,y:798,t:1527272082692};\\\", \\\"{x:1420,y:795,t:1527272082707};\\\", \\\"{x:1422,y:783,t:1527272082724};\\\", \\\"{x:1422,y:775,t:1527272082740};\\\", \\\"{x:1423,y:766,t:1527272082757};\\\", \\\"{x:1423,y:758,t:1527272082775};\\\", \\\"{x:1423,y:748,t:1527272082791};\\\", \\\"{x:1424,y:743,t:1527272082807};\\\", \\\"{x:1424,y:737,t:1527272082825};\\\", \\\"{x:1425,y:726,t:1527272082840};\\\", \\\"{x:1425,y:713,t:1527272082857};\\\", \\\"{x:1423,y:706,t:1527272082875};\\\", \\\"{x:1423,y:705,t:1527272082891};\\\", \\\"{x:1423,y:703,t:1527272082906};\\\", \\\"{x:1423,y:702,t:1527272082979};\\\", \\\"{x:1424,y:700,t:1527272082990};\\\", \\\"{x:1424,y:698,t:1527272083011};\\\", \\\"{x:1424,y:697,t:1527272083027};\\\", \\\"{x:1424,y:696,t:1527272083044};\\\", \\\"{x:1424,y:695,t:1527272083059};\\\", \\\"{x:1424,y:694,t:1527272083075};\\\", \\\"{x:1424,y:693,t:1527272083090};\\\", \\\"{x:1424,y:692,t:1527272083107};\\\", \\\"{x:1424,y:690,t:1527272083124};\\\", \\\"{x:1424,y:689,t:1527272083140};\\\", \\\"{x:1424,y:687,t:1527272083157};\\\", \\\"{x:1424,y:686,t:1527272083180};\\\", \\\"{x:1424,y:685,t:1527272083195};\\\", \\\"{x:1424,y:684,t:1527272083207};\\\", \\\"{x:1424,y:683,t:1527272083228};\\\", \\\"{x:1424,y:681,t:1527272083241};\\\", \\\"{x:1424,y:680,t:1527272083257};\\\", \\\"{x:1424,y:679,t:1527272083274};\\\", \\\"{x:1424,y:678,t:1527272083290};\\\", \\\"{x:1424,y:677,t:1527272083307};\\\", \\\"{x:1424,y:675,t:1527272083324};\\\", \\\"{x:1423,y:674,t:1527272083340};\\\", \\\"{x:1422,y:667,t:1527272083357};\\\", \\\"{x:1422,y:665,t:1527272083374};\\\", \\\"{x:1422,y:661,t:1527272083390};\\\", \\\"{x:1421,y:660,t:1527272083407};\\\", \\\"{x:1420,y:656,t:1527272083425};\\\", \\\"{x:1420,y:654,t:1527272083441};\\\", \\\"{x:1419,y:653,t:1527272083457};\\\", \\\"{x:1418,y:650,t:1527272083475};\\\", \\\"{x:1418,y:649,t:1527272083491};\\\", \\\"{x:1418,y:648,t:1527272083507};\\\", \\\"{x:1417,y:647,t:1527272083524};\\\", \\\"{x:1415,y:645,t:1527272083547};\\\", \\\"{x:1414,y:642,t:1527272083557};\\\", \\\"{x:1414,y:640,t:1527272083574};\\\", \\\"{x:1414,y:639,t:1527272083591};\\\", \\\"{x:1413,y:639,t:1527272083607};\\\", \\\"{x:1413,y:638,t:1527272083624};\\\", \\\"{x:1412,y:637,t:1527272083641};\\\", \\\"{x:1411,y:637,t:1527272083796};\\\", \\\"{x:1409,y:637,t:1527272083828};\\\", \\\"{x:1408,y:637,t:1527272083844};\\\", \\\"{x:1407,y:637,t:1527272083868};\\\", \\\"{x:1406,y:638,t:1527272083876};\\\", \\\"{x:1405,y:638,t:1527272083891};\\\", \\\"{x:1395,y:641,t:1527272084316};\\\", \\\"{x:1384,y:643,t:1527272084324};\\\", \\\"{x:1353,y:650,t:1527272084341};\\\", \\\"{x:1316,y:655,t:1527272084357};\\\", \\\"{x:1288,y:655,t:1527272084374};\\\", \\\"{x:1253,y:653,t:1527272084391};\\\", \\\"{x:1236,y:650,t:1527272084407};\\\", \\\"{x:1221,y:643,t:1527272084425};\\\", \\\"{x:1205,y:638,t:1527272084442};\\\", \\\"{x:1126,y:641,t:1527272084458};\\\", \\\"{x:1026,y:628,t:1527272084474};\\\", \\\"{x:901,y:613,t:1527272084493};\\\", \\\"{x:809,y:599,t:1527272084508};\\\", \\\"{x:791,y:597,t:1527272084523};\\\", \\\"{x:775,y:593,t:1527272084546};\\\", \\\"{x:775,y:592,t:1527272084561};\\\", \\\"{x:775,y:588,t:1527272084578};\\\", \\\"{x:771,y:586,t:1527272084595};\\\", \\\"{x:771,y:583,t:1527272084675};\\\", \\\"{x:769,y:582,t:1527272084683};\\\", \\\"{x:762,y:579,t:1527272084694};\\\", \\\"{x:752,y:576,t:1527272084711};\\\", \\\"{x:736,y:571,t:1527272084727};\\\", \\\"{x:694,y:554,t:1527272084747};\\\", \\\"{x:609,y:532,t:1527272084762};\\\", \\\"{x:547,y:512,t:1527272084779};\\\", \\\"{x:476,y:492,t:1527272084796};\\\", \\\"{x:422,y:471,t:1527272084811};\\\", \\\"{x:357,y:452,t:1527272084828};\\\", \\\"{x:321,y:437,t:1527272084844};\\\", \\\"{x:320,y:436,t:1527272084861};\\\", \\\"{x:311,y:432,t:1527272084878};\\\", \\\"{x:303,y:426,t:1527272084895};\\\", \\\"{x:298,y:425,t:1527272084911};\\\", \\\"{x:296,y:425,t:1527272085212};\\\", \\\"{x:293,y:425,t:1527272085227};\\\", \\\"{x:291,y:426,t:1527272085243};\\\", \\\"{x:290,y:427,t:1527272085261};\\\", \\\"{x:288,y:427,t:1527272085277};\\\", \\\"{x:286,y:429,t:1527272085294};\\\", \\\"{x:284,y:432,t:1527272085788};\\\", \\\"{x:283,y:432,t:1527272085820};\\\", \\\"{x:283,y:433,t:1527272085827};\\\", \\\"{x:282,y:433,t:1527272085843};\\\", \\\"{x:279,y:435,t:1527272085860};\\\", \\\"{x:271,y:439,t:1527272085876};\\\", \\\"{x:269,y:439,t:1527272085893};\\\", \\\"{x:267,y:441,t:1527272085909};\\\", \\\"{x:263,y:442,t:1527272085926};\\\", \\\"{x:256,y:444,t:1527272085943};\\\", \\\"{x:254,y:444,t:1527272085958};\\\", \\\"{x:253,y:445,t:1527272085976};\\\", \\\"{x:250,y:446,t:1527272085993};\\\", \\\"{x:246,y:447,t:1527272086008};\\\", \\\"{x:243,y:447,t:1527272086026};\\\", \\\"{x:242,y:447,t:1527272086043};\\\", \\\"{x:241,y:448,t:1527272086643};\\\", \\\"{x:239,y:449,t:1527272086658};\\\", \\\"{x:237,y:450,t:1527272086675};\\\", \\\"{x:236,y:450,t:1527272086772};\\\", \\\"{x:234,y:451,t:1527272086788};\\\", \\\"{x:233,y:451,t:1527272086795};\\\", \\\"{x:232,y:452,t:1527272086811};\\\", \\\"{x:231,y:452,t:1527272086824};\\\", \\\"{x:232,y:452,t:1527272086956};\\\", \\\"{x:242,y:452,t:1527272086971};\\\", \\\"{x:246,y:452,t:1527272086979};\\\", \\\"{x:252,y:452,t:1527272086991};\\\", \\\"{x:259,y:451,t:1527272087007};\\\", \\\"{x:263,y:453,t:1527272087024};\\\", \\\"{x:321,y:466,t:1527272087041};\\\", \\\"{x:442,y:476,t:1527272087058};\\\", \\\"{x:553,y:496,t:1527272087076};\\\", \\\"{x:663,y:521,t:1527272087091};\\\", \\\"{x:754,y:540,t:1527272087106};\\\", \\\"{x:848,y:565,t:1527272087130};\\\", \\\"{x:857,y:575,t:1527272087146};\\\", \\\"{x:898,y:581,t:1527272087163};\\\", \\\"{x:916,y:584,t:1527272087179};\\\", \\\"{x:917,y:586,t:1527272087197};\\\", \\\"{x:919,y:586,t:1527272087213};\\\", \\\"{x:918,y:586,t:1527272087372};\\\", \\\"{x:917,y:586,t:1527272087476};\\\", \\\"{x:921,y:583,t:1527272087483};\\\", \\\"{x:935,y:581,t:1527272087496};\\\", \\\"{x:969,y:577,t:1527272087515};\\\", \\\"{x:1013,y:574,t:1527272087529};\\\", \\\"{x:1109,y:571,t:1527272087546};\\\", \\\"{x:1176,y:571,t:1527272087564};\\\", \\\"{x:1237,y:571,t:1527272087581};\\\", \\\"{x:1304,y:571,t:1527272087597};\\\", \\\"{x:1322,y:572,t:1527272087614};\\\", \\\"{x:1339,y:575,t:1527272087631};\\\", \\\"{x:1344,y:575,t:1527272087647};\\\", \\\"{x:1347,y:577,t:1527272087664};\\\", \\\"{x:1348,y:577,t:1527272087877};\\\", \\\"{x:1348,y:578,t:1527272087884};\\\", \\\"{x:1347,y:578,t:1527272087972};\\\", \\\"{x:1346,y:579,t:1527272087982};\\\", \\\"{x:1345,y:580,t:1527272088004};\\\", \\\"{x:1344,y:581,t:1527272088027};\\\", \\\"{x:1343,y:582,t:1527272088052};\\\", \\\"{x:1341,y:582,t:1527272088068};\\\", \\\"{x:1340,y:585,t:1527272088082};\\\", \\\"{x:1340,y:586,t:1527272088099};\\\", \\\"{x:1338,y:588,t:1527272088114};\\\", \\\"{x:1336,y:591,t:1527272088131};\\\", \\\"{x:1335,y:591,t:1527272088155};\\\", \\\"{x:1334,y:592,t:1527272088171};\\\", \\\"{x:1333,y:593,t:1527272088362};\\\", \\\"{x:1332,y:594,t:1527272088403};\\\", \\\"{x:1330,y:596,t:1527272088467};\\\", \\\"{x:1329,y:597,t:1527272088523};\\\", \\\"{x:1328,y:598,t:1527272088596};\\\", \\\"{x:1328,y:599,t:1527272088620};\\\", \\\"{x:1327,y:599,t:1527272088636};\\\", \\\"{x:1326,y:600,t:1527272088651};\\\", \\\"{x:1326,y:601,t:1527272088666};\\\", \\\"{x:1325,y:601,t:1527272088682};\\\", \\\"{x:1325,y:602,t:1527272088707};\\\", \\\"{x:1324,y:603,t:1527272088715};\\\", \\\"{x:1323,y:604,t:1527272088772};\\\", \\\"{x:1322,y:604,t:1527272088788};\\\", \\\"{x:1321,y:604,t:1527272088812};\\\", \\\"{x:1321,y:605,t:1527272088820};\\\", \\\"{x:1320,y:605,t:1527272088852};\\\", \\\"{x:1319,y:605,t:1527272088995};\\\", \\\"{x:1316,y:605,t:1527272089027};\\\", \\\"{x:1315,y:605,t:1527272089035};\\\", \\\"{x:1314,y:605,t:1527272089124};\\\", \\\"{x:1313,y:604,t:1527272089140};\\\", \\\"{x:1312,y:603,t:1527272089155};\\\", \\\"{x:1310,y:602,t:1527272089172};\\\", \\\"{x:1309,y:600,t:1527272089187};\\\", \\\"{x:1309,y:599,t:1527272089236};\\\", \\\"{x:1308,y:599,t:1527272089249};\\\", \\\"{x:1308,y:598,t:1527272089265};\\\", \\\"{x:1307,y:598,t:1527272089395};\\\", \\\"{x:1307,y:600,t:1527272089403};\\\", \\\"{x:1307,y:602,t:1527272089416};\\\", \\\"{x:1307,y:608,t:1527272089432};\\\", \\\"{x:1306,y:614,t:1527272089449};\\\", \\\"{x:1305,y:618,t:1527272089467};\\\", \\\"{x:1305,y:626,t:1527272089483};\\\", \\\"{x:1305,y:639,t:1527272089500};\\\", \\\"{x:1305,y:648,t:1527272089517};\\\", \\\"{x:1307,y:658,t:1527272089532};\\\", \\\"{x:1312,y:670,t:1527272089550};\\\", \\\"{x:1314,y:680,t:1527272089567};\\\", \\\"{x:1315,y:688,t:1527272089582};\\\", \\\"{x:1317,y:697,t:1527272089600};\\\", \\\"{x:1320,y:708,t:1527272089616};\\\", \\\"{x:1320,y:713,t:1527272089632};\\\", \\\"{x:1321,y:718,t:1527272089649};\\\", \\\"{x:1324,y:723,t:1527272089667};\\\", \\\"{x:1324,y:729,t:1527272089682};\\\", \\\"{x:1324,y:740,t:1527272089699};\\\", \\\"{x:1322,y:746,t:1527272089717};\\\", \\\"{x:1320,y:753,t:1527272089733};\\\", \\\"{x:1318,y:759,t:1527272089749};\\\", \\\"{x:1318,y:762,t:1527272089766};\\\", \\\"{x:1317,y:763,t:1527272089804};\\\", \\\"{x:1316,y:758,t:1527272089876};\\\", \\\"{x:1315,y:753,t:1527272089883};\\\", \\\"{x:1315,y:732,t:1527272089899};\\\", \\\"{x:1315,y:710,t:1527272089916};\\\", \\\"{x:1315,y:691,t:1527272089933};\\\", \\\"{x:1315,y:673,t:1527272089950};\\\", \\\"{x:1314,y:657,t:1527272089966};\\\", \\\"{x:1309,y:628,t:1527272089983};\\\", \\\"{x:1308,y:607,t:1527272090000};\\\", \\\"{x:1308,y:585,t:1527272090016};\\\", \\\"{x:1309,y:568,t:1527272090033};\\\", \\\"{x:1311,y:549,t:1527272090050};\\\", \\\"{x:1315,y:539,t:1527272090066};\\\", \\\"{x:1315,y:530,t:1527272090083};\\\", \\\"{x:1315,y:528,t:1527272090100};\\\", \\\"{x:1315,y:527,t:1527272090116};\\\", \\\"{x:1314,y:523,t:1527272090147};\\\", \\\"{x:1314,y:522,t:1527272090179};\\\", \\\"{x:1313,y:519,t:1527272090203};\\\", \\\"{x:1312,y:519,t:1527272090216};\\\", \\\"{x:1311,y:517,t:1527272090234};\\\", \\\"{x:1307,y:512,t:1527272090251};\\\", \\\"{x:1301,y:502,t:1527272090267};\\\", \\\"{x:1295,y:491,t:1527272090284};\\\", \\\"{x:1289,y:484,t:1527272090300};\\\", \\\"{x:1286,y:481,t:1527272090318};\\\", \\\"{x:1285,y:480,t:1527272090333};\\\", \\\"{x:1283,y:480,t:1527272090460};\\\", \\\"{x:1281,y:485,t:1527272090468};\\\", \\\"{x:1280,y:500,t:1527272090484};\\\", \\\"{x:1280,y:522,t:1527272090501};\\\", \\\"{x:1280,y:556,t:1527272090517};\\\", \\\"{x:1280,y:581,t:1527272090534};\\\", \\\"{x:1280,y:624,t:1527272090550};\\\", \\\"{x:1280,y:653,t:1527272090568};\\\", \\\"{x:1280,y:717,t:1527272090583};\\\", \\\"{x:1275,y:788,t:1527272090600};\\\", \\\"{x:1268,y:855,t:1527272090618};\\\", \\\"{x:1260,y:913,t:1527272090635};\\\", \\\"{x:1241,y:993,t:1527272090651};\\\", \\\"{x:1233,y:1046,t:1527272090667};\\\", \\\"{x:1231,y:1069,t:1527272090684};\\\", \\\"{x:1223,y:1079,t:1527272090700};\\\", \\\"{x:1219,y:1089,t:1527272090717};\\\", \\\"{x:1218,y:1091,t:1527272090734};\\\", \\\"{x:1217,y:1093,t:1527272091084};\\\", \\\"{x:1220,y:1094,t:1527272091108};\\\", \\\"{x:1225,y:1095,t:1527272091118};\\\", \\\"{x:1233,y:1099,t:1527272091134};\\\", \\\"{x:1248,y:1099,t:1527272091152};\\\", \\\"{x:1286,y:1104,t:1527272091168};\\\", \\\"{x:1315,y:1107,t:1527272091184};\\\", \\\"{x:1330,y:1112,t:1527272091201};\\\", \\\"{x:1340,y:1119,t:1527272091217};\\\", \\\"{x:1351,y:1122,t:1527272091235};\\\", \\\"{x:1367,y:1125,t:1527272091251};\\\", \\\"{x:1380,y:1127,t:1527272091267};\\\", \\\"{x:1391,y:1127,t:1527272091284};\\\", \\\"{x:1397,y:1127,t:1527272091301};\\\", \\\"{x:1400,y:1126,t:1527272091318};\\\", \\\"{x:1402,y:1125,t:1527272091340};\\\", \\\"{x:1402,y:1123,t:1527272091355};\\\", \\\"{x:1403,y:1121,t:1527272091369};\\\", \\\"{x:1406,y:1117,t:1527272091385};\\\", \\\"{x:1406,y:1110,t:1527272091401};\\\", \\\"{x:1409,y:1097,t:1527272091418};\\\", \\\"{x:1410,y:1077,t:1527272091435};\\\", \\\"{x:1404,y:1007,t:1527272091452};\\\", \\\"{x:1387,y:938,t:1527272091468};\\\", \\\"{x:1349,y:815,t:1527272091484};\\\", \\\"{x:1307,y:703,t:1527272091501};\\\", \\\"{x:1265,y:604,t:1527272091518};\\\", \\\"{x:1235,y:530,t:1527272091535};\\\", \\\"{x:1211,y:473,t:1527272091551};\\\", \\\"{x:1195,y:456,t:1527272091568};\\\", \\\"{x:1184,y:447,t:1527272091584};\\\", \\\"{x:1175,y:441,t:1527272091601};\\\", \\\"{x:1173,y:440,t:1527272091619};\\\", \\\"{x:1171,y:442,t:1527272091659};\\\", \\\"{x:1171,y:443,t:1527272091668};\\\", \\\"{x:1169,y:447,t:1527272091685};\\\", \\\"{x:1168,y:449,t:1527272091701};\\\", \\\"{x:1167,y:451,t:1527272091717};\\\", \\\"{x:1167,y:452,t:1527272091735};\\\", \\\"{x:1167,y:454,t:1527272091751};\\\", \\\"{x:1167,y:456,t:1527272091768};\\\", \\\"{x:1168,y:459,t:1527272091827};\\\", \\\"{x:1169,y:463,t:1527272091835};\\\", \\\"{x:1174,y:479,t:1527272091851};\\\", \\\"{x:1180,y:493,t:1527272091868};\\\", \\\"{x:1184,y:502,t:1527272091886};\\\", \\\"{x:1190,y:515,t:1527272091901};\\\", \\\"{x:1197,y:542,t:1527272091918};\\\", \\\"{x:1205,y:565,t:1527272091936};\\\", \\\"{x:1207,y:587,t:1527272091951};\\\", \\\"{x:1212,y:615,t:1527272091969};\\\", \\\"{x:1210,y:638,t:1527272091985};\\\", \\\"{x:1211,y:670,t:1527272092003};\\\", \\\"{x:1210,y:696,t:1527272092019};\\\", \\\"{x:1206,y:730,t:1527272092035};\\\", \\\"{x:1204,y:755,t:1527272092052};\\\", \\\"{x:1204,y:776,t:1527272092069};\\\", \\\"{x:1200,y:790,t:1527272092085};\\\", \\\"{x:1196,y:799,t:1527272092101};\\\", \\\"{x:1190,y:808,t:1527272092118};\\\", \\\"{x:1186,y:812,t:1527272092135};\\\", \\\"{x:1182,y:815,t:1527272092152};\\\", \\\"{x:1179,y:817,t:1527272092168};\\\", \\\"{x:1177,y:817,t:1527272092186};\\\", \\\"{x:1175,y:819,t:1527272092202};\\\", \\\"{x:1220,y:816,t:1527272095596};\\\", \\\"{x:1296,y:809,t:1527272095606};\\\", \\\"{x:1370,y:809,t:1527272095623};\\\", \\\"{x:1425,y:803,t:1527272095640};\\\", \\\"{x:1426,y:803,t:1527272095655};\\\", \\\"{x:1427,y:803,t:1527272095860};\\\", \\\"{x:1428,y:804,t:1527272095873};\\\", \\\"{x:1431,y:808,t:1527272095890};\\\", \\\"{x:1448,y:812,t:1527272095905};\\\", \\\"{x:1456,y:813,t:1527272095922};\\\", \\\"{x:1480,y:813,t:1527272095938};\\\", \\\"{x:1481,y:813,t:1527272095956};\\\", \\\"{x:1482,y:813,t:1527272095972};\\\", \\\"{x:1483,y:813,t:1527272096043};\\\", \\\"{x:1486,y:814,t:1527272096056};\\\", \\\"{x:1490,y:814,t:1527272096073};\\\", \\\"{x:1500,y:814,t:1527272096089};\\\", \\\"{x:1504,y:814,t:1527272096106};\\\", \\\"{x:1507,y:814,t:1527272096123};\\\", \\\"{x:1508,y:815,t:1527272096140};\\\", \\\"{x:1511,y:815,t:1527272096156};\\\", \\\"{x:1511,y:816,t:1527272096173};\\\", \\\"{x:1513,y:816,t:1527272096268};\\\", \\\"{x:1515,y:817,t:1527272096283};\\\", \\\"{x:1516,y:818,t:1527272096308};\\\", \\\"{x:1525,y:819,t:1527272096324};\\\", \\\"{x:1529,y:819,t:1527272096348};\\\", \\\"{x:1532,y:820,t:1527272096357};\\\", \\\"{x:1545,y:822,t:1527272096374};\\\", \\\"{x:1553,y:826,t:1527272096390};\\\", \\\"{x:1561,y:827,t:1527272096406};\\\", \\\"{x:1570,y:828,t:1527272096424};\\\", \\\"{x:1578,y:828,t:1527272096440};\\\", \\\"{x:1586,y:828,t:1527272096457};\\\", \\\"{x:1590,y:828,t:1527272096474};\\\", \\\"{x:1591,y:828,t:1527272096508};\\\", \\\"{x:1595,y:827,t:1527272096804};\\\", \\\"{x:1598,y:826,t:1527272096812};\\\", \\\"{x:1600,y:824,t:1527272096823};\\\", \\\"{x:1606,y:822,t:1527272096841};\\\", \\\"{x:1611,y:819,t:1527272096856};\\\", \\\"{x:1613,y:817,t:1527272096873};\\\", \\\"{x:1618,y:816,t:1527272096891};\\\", \\\"{x:1619,y:815,t:1527272096907};\\\", \\\"{x:1620,y:815,t:1527272096924};\\\", \\\"{x:1621,y:815,t:1527272097035};\\\", \\\"{x:1623,y:815,t:1527272097043};\\\", \\\"{x:1624,y:815,t:1527272097058};\\\", \\\"{x:1624,y:822,t:1527272097074};\\\", \\\"{x:1626,y:837,t:1527272097092};\\\", \\\"{x:1628,y:846,t:1527272097108};\\\", \\\"{x:1629,y:861,t:1527272097124};\\\", \\\"{x:1630,y:868,t:1527272097141};\\\", \\\"{x:1630,y:882,t:1527272097158};\\\", \\\"{x:1630,y:893,t:1527272097174};\\\", \\\"{x:1629,y:904,t:1527272097191};\\\", \\\"{x:1624,y:919,t:1527272097208};\\\", \\\"{x:1616,y:942,t:1527272097224};\\\", \\\"{x:1605,y:961,t:1527272097241};\\\", \\\"{x:1595,y:979,t:1527272097258};\\\", \\\"{x:1583,y:995,t:1527272097275};\\\", \\\"{x:1566,y:1010,t:1527272097291};\\\", \\\"{x:1562,y:1011,t:1527272097308};\\\", \\\"{x:1557,y:1012,t:1527272097324};\\\", \\\"{x:1555,y:1012,t:1527272097341};\\\", \\\"{x:1547,y:1010,t:1527272097358};\\\", \\\"{x:1544,y:1001,t:1527272097375};\\\", \\\"{x:1533,y:993,t:1527272097391};\\\", \\\"{x:1506,y:978,t:1527272097408};\\\", \\\"{x:1489,y:965,t:1527272097424};\\\", \\\"{x:1455,y:953,t:1527272097441};\\\", \\\"{x:1449,y:946,t:1527272097458};\\\", \\\"{x:1421,y:931,t:1527272097476};\\\", \\\"{x:1414,y:924,t:1527272097491};\\\", \\\"{x:1397,y:909,t:1527272097507};\\\", \\\"{x:1394,y:907,t:1527272097525};\\\", \\\"{x:1394,y:905,t:1527272097541};\\\", \\\"{x:1392,y:904,t:1527272097558};\\\", \\\"{x:1392,y:903,t:1527272097575};\\\", \\\"{x:1390,y:902,t:1527272097636};\\\", \\\"{x:1389,y:901,t:1527272097643};\\\", \\\"{x:1388,y:901,t:1527272097716};\\\", \\\"{x:1381,y:900,t:1527272097727};\\\", \\\"{x:1370,y:899,t:1527272097742};\\\", \\\"{x:1362,y:895,t:1527272097757};\\\", \\\"{x:1357,y:892,t:1527272097774};\\\", \\\"{x:1346,y:888,t:1527272097791};\\\", \\\"{x:1340,y:884,t:1527272097807};\\\", \\\"{x:1338,y:880,t:1527272097824};\\\", \\\"{x:1336,y:878,t:1527272097841};\\\", \\\"{x:1334,y:876,t:1527272097857};\\\", \\\"{x:1333,y:875,t:1527272097875};\\\", \\\"{x:1332,y:874,t:1527272097891};\\\", \\\"{x:1331,y:873,t:1527272097963};\\\", \\\"{x:1329,y:870,t:1527272097975};\\\", \\\"{x:1328,y:870,t:1527272097991};\\\", \\\"{x:1324,y:866,t:1527272098009};\\\", \\\"{x:1323,y:865,t:1527272098084};\\\", \\\"{x:1323,y:864,t:1527272098107};\\\", \\\"{x:1321,y:863,t:1527272098114};\\\", \\\"{x:1320,y:859,t:1527272098125};\\\", \\\"{x:1315,y:854,t:1527272098141};\\\", \\\"{x:1310,y:847,t:1527272098159};\\\", \\\"{x:1310,y:846,t:1527272098174};\\\", \\\"{x:1309,y:845,t:1527272098192};\\\", \\\"{x:1307,y:841,t:1527272098208};\\\", \\\"{x:1304,y:835,t:1527272098225};\\\", \\\"{x:1303,y:832,t:1527272098241};\\\", \\\"{x:1303,y:829,t:1527272098259};\\\", \\\"{x:1302,y:828,t:1527272098275};\\\", \\\"{x:1300,y:825,t:1527272098291};\\\", \\\"{x:1300,y:824,t:1527272098348};\\\", \\\"{x:1298,y:820,t:1527272098359};\\\", \\\"{x:1297,y:818,t:1527272098376};\\\", \\\"{x:1293,y:813,t:1527272098392};\\\", \\\"{x:1292,y:811,t:1527272098409};\\\", \\\"{x:1291,y:807,t:1527272098426};\\\", \\\"{x:1291,y:805,t:1527272098442};\\\", \\\"{x:1291,y:802,t:1527272098459};\\\", \\\"{x:1294,y:794,t:1527272098476};\\\", \\\"{x:1296,y:791,t:1527272098491};\\\", \\\"{x:1298,y:789,t:1527272098509};\\\", \\\"{x:1301,y:787,t:1527272098526};\\\", \\\"{x:1304,y:784,t:1527272098541};\\\", \\\"{x:1307,y:781,t:1527272098558};\\\", \\\"{x:1309,y:781,t:1527272098575};\\\", \\\"{x:1313,y:779,t:1527272098592};\\\", \\\"{x:1324,y:777,t:1527272098609};\\\", \\\"{x:1328,y:777,t:1527272098626};\\\", \\\"{x:1329,y:777,t:1527272098651};\\\", \\\"{x:1330,y:777,t:1527272099228};\\\", \\\"{x:1332,y:776,t:1527272099243};\\\", \\\"{x:1334,y:771,t:1527272099260};\\\", \\\"{x:1335,y:765,t:1527272099276};\\\", \\\"{x:1337,y:760,t:1527272099293};\\\", \\\"{x:1339,y:754,t:1527272099309};\\\", \\\"{x:1340,y:749,t:1527272099327};\\\", \\\"{x:1343,y:738,t:1527272099343};\\\", \\\"{x:1348,y:726,t:1527272099360};\\\", \\\"{x:1348,y:718,t:1527272099377};\\\", \\\"{x:1349,y:714,t:1527272099393};\\\", \\\"{x:1349,y:713,t:1527272099410};\\\", \\\"{x:1350,y:710,t:1527272099427};\\\", \\\"{x:1350,y:708,t:1527272099443};\\\", \\\"{x:1350,y:707,t:1527272099460};\\\", \\\"{x:1350,y:705,t:1527272099477};\\\", \\\"{x:1350,y:703,t:1527272099492};\\\", \\\"{x:1350,y:701,t:1527272099511};\\\", \\\"{x:1350,y:700,t:1527272099547};\\\", \\\"{x:1350,y:699,t:1527272099804};\\\", \\\"{x:1350,y:698,t:1527272099811};\\\", \\\"{x:1350,y:697,t:1527272099827};\\\", \\\"{x:1348,y:695,t:1527272099843};\\\", \\\"{x:1348,y:694,t:1527272099859};\\\", \\\"{x:1347,y:692,t:1527272099876};\\\", \\\"{x:1348,y:692,t:1527272101292};\\\", \\\"{x:1353,y:692,t:1527272101300};\\\", \\\"{x:1357,y:692,t:1527272101315};\\\", \\\"{x:1360,y:692,t:1527272101329};\\\", \\\"{x:1365,y:692,t:1527272101345};\\\", \\\"{x:1369,y:692,t:1527272101362};\\\", \\\"{x:1372,y:692,t:1527272101379};\\\", \\\"{x:1373,y:692,t:1527272101395};\\\", \\\"{x:1375,y:692,t:1527272101427};\\\", \\\"{x:1376,y:692,t:1527272101435};\\\", \\\"{x:1378,y:692,t:1527272101445};\\\", \\\"{x:1379,y:692,t:1527272101462};\\\", \\\"{x:1381,y:692,t:1527272101479};\\\", \\\"{x:1383,y:692,t:1527272101532};\\\", \\\"{x:1385,y:692,t:1527272101545};\\\", \\\"{x:1390,y:692,t:1527272101562};\\\", \\\"{x:1400,y:692,t:1527272101580};\\\", \\\"{x:1404,y:693,t:1527272101595};\\\", \\\"{x:1407,y:693,t:1527272101612};\\\", \\\"{x:1409,y:693,t:1527272101629};\\\", \\\"{x:1417,y:695,t:1527272101646};\\\", \\\"{x:1428,y:695,t:1527272101662};\\\", \\\"{x:1439,y:696,t:1527272101679};\\\", \\\"{x:1453,y:697,t:1527272101696};\\\", \\\"{x:1466,y:698,t:1527272101712};\\\", \\\"{x:1467,y:698,t:1527272101729};\\\", \\\"{x:1469,y:698,t:1527272101746};\\\", \\\"{x:1469,y:699,t:1527272101956};\\\", \\\"{x:1470,y:699,t:1527272101964};\\\", \\\"{x:1471,y:699,t:1527272102036};\\\", \\\"{x:1471,y:698,t:1527272102092};\\\", \\\"{x:1469,y:698,t:1527272102099};\\\", \\\"{x:1469,y:696,t:1527272102113};\\\", \\\"{x:1466,y:694,t:1527272102129};\\\", \\\"{x:1461,y:685,t:1527272102146};\\\", \\\"{x:1442,y:661,t:1527272102163};\\\", \\\"{x:1431,y:648,t:1527272102179};\\\", \\\"{x:1413,y:634,t:1527272102195};\\\", \\\"{x:1400,y:623,t:1527272102213};\\\", \\\"{x:1395,y:618,t:1527272102229};\\\", \\\"{x:1393,y:616,t:1527272102246};\\\", \\\"{x:1389,y:613,t:1527272102263};\\\", \\\"{x:1386,y:612,t:1527272102279};\\\", \\\"{x:1373,y:608,t:1527272102296};\\\", \\\"{x:1347,y:598,t:1527272102313};\\\", \\\"{x:1332,y:591,t:1527272102330};\\\", \\\"{x:1315,y:586,t:1527272102347};\\\", \\\"{x:1296,y:582,t:1527272102363};\\\", \\\"{x:1296,y:580,t:1527272102388};\\\", \\\"{x:1294,y:580,t:1527272102419};\\\", \\\"{x:1290,y:580,t:1527272102430};\\\", \\\"{x:1282,y:576,t:1527272102446};\\\", \\\"{x:1280,y:573,t:1527272102463};\\\", \\\"{x:1275,y:569,t:1527272102480};\\\", \\\"{x:1273,y:566,t:1527272102496};\\\", \\\"{x:1268,y:563,t:1527272102513};\\\", \\\"{x:1268,y:562,t:1527272102572};\\\", \\\"{x:1268,y:560,t:1527272102946};\\\", \\\"{x:1272,y:559,t:1527272102962};\\\", \\\"{x:1287,y:559,t:1527272102979};\\\", \\\"{x:1308,y:559,t:1527272102996};\\\", \\\"{x:1326,y:559,t:1527272103014};\\\", \\\"{x:1333,y:559,t:1527272103030};\\\", \\\"{x:1335,y:559,t:1527272103047};\\\", \\\"{x:1338,y:560,t:1527272103063};\\\", \\\"{x:1339,y:560,t:1527272103091};\\\", \\\"{x:1340,y:560,t:1527272103099};\\\", \\\"{x:1341,y:560,t:1527272103147};\\\", \\\"{x:1342,y:560,t:1527272103163};\\\", \\\"{x:1344,y:560,t:1527272103180};\\\", \\\"{x:1347,y:560,t:1527272103419};\\\", \\\"{x:1350,y:560,t:1527272103431};\\\", \\\"{x:1362,y:560,t:1527272103446};\\\", \\\"{x:1374,y:560,t:1527272103464};\\\", \\\"{x:1384,y:560,t:1527272103481};\\\", \\\"{x:1398,y:560,t:1527272103496};\\\", \\\"{x:1404,y:560,t:1527272103513};\\\", \\\"{x:1405,y:560,t:1527272103530};\\\", \\\"{x:1406,y:560,t:1527272103546};\\\", \\\"{x:1408,y:560,t:1527272103563};\\\", \\\"{x:1410,y:560,t:1527272103581};\\\", \\\"{x:1412,y:560,t:1527272104028};\\\", \\\"{x:1417,y:560,t:1527272104035};\\\", \\\"{x:1420,y:560,t:1527272104049};\\\", \\\"{x:1427,y:560,t:1527272104065};\\\", \\\"{x:1431,y:560,t:1527272104081};\\\", \\\"{x:1434,y:560,t:1527272104099};\\\", \\\"{x:1437,y:559,t:1527272104115};\\\", \\\"{x:1438,y:559,t:1527272104164};\\\", \\\"{x:1439,y:558,t:1527272104171};\\\", \\\"{x:1440,y:558,t:1527272104188};\\\", \\\"{x:1441,y:558,t:1527272104203};\\\", \\\"{x:1442,y:558,t:1527272104228};\\\", \\\"{x:1443,y:558,t:1527272104236};\\\", \\\"{x:1443,y:557,t:1527272104252};\\\", \\\"{x:1445,y:557,t:1527272104265};\\\", \\\"{x:1449,y:556,t:1527272104281};\\\", \\\"{x:1450,y:554,t:1527272104297};\\\", \\\"{x:1456,y:552,t:1527272104314};\\\", \\\"{x:1458,y:552,t:1527272104331};\\\", \\\"{x:1461,y:552,t:1527272104347};\\\", \\\"{x:1463,y:552,t:1527272104371};\\\", \\\"{x:1465,y:552,t:1527272104381};\\\", \\\"{x:1467,y:552,t:1527272104398};\\\", \\\"{x:1470,y:553,t:1527272104668};\\\", \\\"{x:1471,y:553,t:1527272104682};\\\", \\\"{x:1473,y:554,t:1527272104699};\\\", \\\"{x:1474,y:554,t:1527272104828};\\\", \\\"{x:1475,y:554,t:1527272104892};\\\", \\\"{x:1476,y:554,t:1527272104906};\\\", \\\"{x:1477,y:554,t:1527272104922};\\\", \\\"{x:1478,y:555,t:1527272104995};\\\", \\\"{x:1480,y:557,t:1527272105042};\\\", \\\"{x:1481,y:557,t:1527272105051};\\\", \\\"{x:1482,y:557,t:1527272105065};\\\", \\\"{x:1484,y:557,t:1527272105082};\\\", \\\"{x:1485,y:557,t:1527272105108};\\\", \\\"{x:1486,y:557,t:1527272105123};\\\", \\\"{x:1487,y:557,t:1527272105132};\\\", \\\"{x:1488,y:557,t:1527272105444};\\\", \\\"{x:1488,y:558,t:1527272105451};\\\", \\\"{x:1488,y:559,t:1527272105476};\\\", \\\"{x:1488,y:560,t:1527272105508};\\\", \\\"{x:1488,y:561,t:1527272105516};\\\", \\\"{x:1488,y:562,t:1527272105715};\\\", \\\"{x:1488,y:563,t:1527272105820};\\\", \\\"{x:1486,y:564,t:1527272105844};\\\", \\\"{x:1485,y:565,t:1527272105868};\\\", \\\"{x:1483,y:565,t:1527272106004};\\\", \\\"{x:1482,y:565,t:1527272106035};\\\", \\\"{x:1481,y:565,t:1527272106052};\\\", \\\"{x:1480,y:565,t:1527272106084};\\\", \\\"{x:1479,y:565,t:1527272106101};\\\", \\\"{x:1478,y:565,t:1527272106147};\\\", \\\"{x:1477,y:565,t:1527272106244};\\\", \\\"{x:1475,y:566,t:1527272107076};\\\", \\\"{x:1474,y:566,t:1527272107108};\\\", \\\"{x:1473,y:566,t:1527272107140};\\\", \\\"{x:1473,y:567,t:1527272107172};\\\", \\\"{x:1472,y:567,t:1527272108452};\\\", \\\"{x:1471,y:569,t:1527272109548};\\\", \\\"{x:1470,y:569,t:1527272109563};\\\", \\\"{x:1469,y:569,t:1527272109587};\\\", \\\"{x:1469,y:570,t:1527272109603};\\\", \\\"{x:1467,y:572,t:1527272109621};\\\", \\\"{x:1463,y:575,t:1527272109638};\\\", \\\"{x:1459,y:576,t:1527272109655};\\\", \\\"{x:1455,y:578,t:1527272109671};\\\", \\\"{x:1451,y:580,t:1527272109689};\\\", \\\"{x:1447,y:583,t:1527272109704};\\\", \\\"{x:1442,y:584,t:1527272109721};\\\", \\\"{x:1439,y:586,t:1527272109738};\\\", \\\"{x:1438,y:586,t:1527272109755};\\\", \\\"{x:1437,y:586,t:1527272109771};\\\", \\\"{x:1431,y:593,t:1527272109787};\\\", \\\"{x:1425,y:599,t:1527272109804};\\\", \\\"{x:1416,y:605,t:1527272109820};\\\", \\\"{x:1408,y:613,t:1527272109837};\\\", \\\"{x:1400,y:619,t:1527272109855};\\\", \\\"{x:1392,y:628,t:1527272109870};\\\", \\\"{x:1386,y:633,t:1527272109890};\\\", \\\"{x:1380,y:639,t:1527272109905};\\\", \\\"{x:1374,y:645,t:1527272109921};\\\", \\\"{x:1368,y:651,t:1527272109937};\\\", \\\"{x:1359,y:661,t:1527272109954};\\\", \\\"{x:1355,y:668,t:1527272109971};\\\", \\\"{x:1354,y:670,t:1527272109988};\\\", \\\"{x:1350,y:675,t:1527272110005};\\\", \\\"{x:1348,y:678,t:1527272110021};\\\", \\\"{x:1345,y:682,t:1527272110037};\\\", \\\"{x:1345,y:686,t:1527272110054};\\\", \\\"{x:1342,y:689,t:1527272110072};\\\", \\\"{x:1340,y:692,t:1527272110089};\\\", \\\"{x:1337,y:696,t:1527272110105};\\\", \\\"{x:1335,y:700,t:1527272110122};\\\", \\\"{x:1335,y:706,t:1527272110138};\\\", \\\"{x:1334,y:712,t:1527272110154};\\\", \\\"{x:1334,y:721,t:1527272110172};\\\", \\\"{x:1334,y:725,t:1527272110187};\\\", \\\"{x:1334,y:727,t:1527272110204};\\\", \\\"{x:1334,y:730,t:1527272110221};\\\", \\\"{x:1334,y:739,t:1527272110238};\\\", \\\"{x:1336,y:746,t:1527272110254};\\\", \\\"{x:1339,y:754,t:1527272110271};\\\", \\\"{x:1340,y:759,t:1527272110290};\\\", \\\"{x:1340,y:762,t:1527272110304};\\\", \\\"{x:1341,y:766,t:1527272110322};\\\", \\\"{x:1342,y:768,t:1527272110338};\\\", \\\"{x:1345,y:768,t:1527272114092};\\\", \\\"{x:1352,y:768,t:1527272114110};\\\", \\\"{x:1362,y:768,t:1527272114126};\\\", \\\"{x:1374,y:768,t:1527272114141};\\\", \\\"{x:1381,y:768,t:1527272114158};\\\", \\\"{x:1396,y:769,t:1527272114175};\\\", \\\"{x:1411,y:769,t:1527272114192};\\\", \\\"{x:1421,y:769,t:1527272114209};\\\", \\\"{x:1432,y:769,t:1527272114226};\\\", \\\"{x:1444,y:769,t:1527272114242};\\\", \\\"{x:1451,y:768,t:1527272114259};\\\", \\\"{x:1456,y:768,t:1527272114275};\\\", \\\"{x:1459,y:768,t:1527272114292};\\\", \\\"{x:1462,y:768,t:1527272114347};\\\", \\\"{x:1466,y:768,t:1527272114358};\\\", \\\"{x:1471,y:768,t:1527272114376};\\\", \\\"{x:1478,y:768,t:1527272114392};\\\", \\\"{x:1486,y:771,t:1527272114408};\\\", \\\"{x:1493,y:775,t:1527272114425};\\\", \\\"{x:1499,y:778,t:1527272114442};\\\", \\\"{x:1500,y:779,t:1527272114459};\\\", \\\"{x:1500,y:780,t:1527272114476};\\\", \\\"{x:1505,y:785,t:1527272114493};\\\", \\\"{x:1508,y:789,t:1527272114508};\\\", \\\"{x:1509,y:794,t:1527272114526};\\\", \\\"{x:1512,y:799,t:1527272114542};\\\", \\\"{x:1513,y:803,t:1527272114559};\\\", \\\"{x:1515,y:806,t:1527272114576};\\\", \\\"{x:1515,y:807,t:1527272114595};\\\", \\\"{x:1515,y:810,t:1527272114627};\\\", \\\"{x:1512,y:813,t:1527272114643};\\\", \\\"{x:1511,y:814,t:1527272114659};\\\", \\\"{x:1504,y:817,t:1527272114675};\\\", \\\"{x:1498,y:819,t:1527272114693};\\\", \\\"{x:1497,y:820,t:1527272114709};\\\", \\\"{x:1496,y:821,t:1527272115011};\\\", \\\"{x:1495,y:821,t:1527272115027};\\\", \\\"{x:1493,y:821,t:1527272115043};\\\", \\\"{x:1490,y:821,t:1527272115059};\\\", \\\"{x:1489,y:821,t:1527272115084};\\\", \\\"{x:1488,y:821,t:1527272115356};\\\", \\\"{x:1486,y:824,t:1527272115363};\\\", \\\"{x:1485,y:824,t:1527272115377};\\\", \\\"{x:1484,y:826,t:1527272115394};\\\", \\\"{x:1482,y:828,t:1527272115409};\\\", \\\"{x:1482,y:829,t:1527272115915};\\\", \\\"{x:1482,y:831,t:1527272115931};\\\", \\\"{x:1482,y:832,t:1527272115972};\\\", \\\"{x:1482,y:835,t:1527272116003};\\\", \\\"{x:1482,y:836,t:1527272116012};\\\", \\\"{x:1484,y:840,t:1527272116027};\\\", \\\"{x:1488,y:846,t:1527272116043};\\\", \\\"{x:1492,y:856,t:1527272116061};\\\", \\\"{x:1501,y:867,t:1527272116077};\\\", \\\"{x:1507,y:880,t:1527272116094};\\\", \\\"{x:1511,y:891,t:1527272116110};\\\", \\\"{x:1515,y:900,t:1527272116128};\\\", \\\"{x:1519,y:912,t:1527272116144};\\\", \\\"{x:1525,y:925,t:1527272116161};\\\", \\\"{x:1525,y:930,t:1527272116177};\\\", \\\"{x:1527,y:943,t:1527272116194};\\\", \\\"{x:1532,y:949,t:1527272116211};\\\", \\\"{x:1533,y:954,t:1527272116227};\\\", \\\"{x:1535,y:956,t:1527272116412};\\\", \\\"{x:1535,y:958,t:1527272116427};\\\", \\\"{x:1536,y:959,t:1527272116445};\\\", \\\"{x:1538,y:961,t:1527272116461};\\\", \\\"{x:1540,y:962,t:1527272116477};\\\", \\\"{x:1540,y:964,t:1527272116495};\\\", \\\"{x:1542,y:965,t:1527272116511};\\\", \\\"{x:1542,y:966,t:1527272116527};\\\", \\\"{x:1544,y:967,t:1527272116544};\\\", \\\"{x:1544,y:968,t:1527272116561};\\\", \\\"{x:1544,y:969,t:1527272116578};\\\", \\\"{x:1544,y:970,t:1527272116595};\\\", \\\"{x:1544,y:971,t:1527272116611};\\\", \\\"{x:1545,y:972,t:1527272116708};\\\", \\\"{x:1547,y:972,t:1527272116715};\\\", \\\"{x:1549,y:972,t:1527272116727};\\\", \\\"{x:1557,y:972,t:1527272116744};\\\", \\\"{x:1559,y:972,t:1527272116761};\\\", \\\"{x:1561,y:972,t:1527272116777};\\\", \\\"{x:1562,y:972,t:1527272116795};\\\", \\\"{x:1566,y:972,t:1527272116811};\\\", \\\"{x:1571,y:972,t:1527272116827};\\\", \\\"{x:1573,y:972,t:1527272116845};\\\", \\\"{x:1577,y:972,t:1527272116861};\\\", \\\"{x:1580,y:971,t:1527272116877};\\\", \\\"{x:1582,y:971,t:1527272116895};\\\", \\\"{x:1587,y:971,t:1527272116912};\\\", \\\"{x:1593,y:970,t:1527272116928};\\\", \\\"{x:1595,y:970,t:1527272116944};\\\", \\\"{x:1598,y:969,t:1527272116961};\\\", \\\"{x:1603,y:969,t:1527272116978};\\\", \\\"{x:1612,y:969,t:1527272116994};\\\", \\\"{x:1614,y:969,t:1527272117011};\\\", \\\"{x:1615,y:969,t:1527272117034};\\\", \\\"{x:1616,y:969,t:1527272120372};\\\", \\\"{x:1618,y:968,t:1527272120382};\\\", \\\"{x:1619,y:968,t:1527272120398};\\\", \\\"{x:1620,y:967,t:1527272120415};\\\", \\\"{x:1626,y:964,t:1527272120432};\\\", \\\"{x:1628,y:964,t:1527272120448};\\\", \\\"{x:1630,y:964,t:1527272120464};\\\", \\\"{x:1632,y:963,t:1527272120482};\\\", \\\"{x:1636,y:961,t:1527272120499};\\\", \\\"{x:1639,y:960,t:1527272120515};\\\", \\\"{x:1641,y:960,t:1527272120531};\\\", \\\"{x:1643,y:959,t:1527272120548};\\\", \\\"{x:1644,y:958,t:1527272120564};\\\", \\\"{x:1646,y:957,t:1527272120587};\\\", \\\"{x:1647,y:957,t:1527272120598};\\\", \\\"{x:1659,y:958,t:1527272120615};\\\", \\\"{x:1667,y:959,t:1527272120632};\\\", \\\"{x:1674,y:959,t:1527272120648};\\\", \\\"{x:1686,y:962,t:1527272120666};\\\", \\\"{x:1690,y:963,t:1527272120682};\\\", \\\"{x:1688,y:963,t:1527272120867};\\\", \\\"{x:1687,y:963,t:1527272120882};\\\", \\\"{x:1684,y:961,t:1527272120900};\\\", \\\"{x:1683,y:961,t:1527272120916};\\\", \\\"{x:1681,y:960,t:1527272120933};\\\", \\\"{x:1680,y:959,t:1527272120948};\\\", \\\"{x:1677,y:957,t:1527272121371};\\\", \\\"{x:1675,y:954,t:1527272121382};\\\", \\\"{x:1671,y:951,t:1527272121400};\\\", \\\"{x:1669,y:948,t:1527272121416};\\\", \\\"{x:1669,y:947,t:1527272121433};\\\", \\\"{x:1669,y:946,t:1527272121451};\\\", \\\"{x:1668,y:945,t:1527272121465};\\\", \\\"{x:1668,y:944,t:1527272121564};\\\", \\\"{x:1668,y:943,t:1527272121579};\\\", \\\"{x:1668,y:942,t:1527272121587};\\\", \\\"{x:1668,y:941,t:1527272121600};\\\", \\\"{x:1668,y:942,t:1527272121771};\\\", \\\"{x:1668,y:945,t:1527272121783};\\\", \\\"{x:1668,y:947,t:1527272121800};\\\", \\\"{x:1668,y:948,t:1527272121819};\\\", \\\"{x:1668,y:949,t:1527272121843};\\\", \\\"{x:1669,y:951,t:1527272121884};\\\", \\\"{x:1670,y:953,t:1527272121906};\\\", \\\"{x:1671,y:953,t:1527272121917};\\\", \\\"{x:1672,y:954,t:1527272121933};\\\", \\\"{x:1672,y:955,t:1527272122270};\\\", \\\"{x:1672,y:956,t:1527272122285};\\\", \\\"{x:1674,y:959,t:1527272122301};\\\", \\\"{x:1675,y:961,t:1527272122310};\\\", \\\"{x:1677,y:963,t:1527272122326};\\\", \\\"{x:1678,y:964,t:1527272122814};\\\", \\\"{x:1679,y:964,t:1527272122829};\\\", \\\"{x:1679,y:963,t:1527272122844};\\\", \\\"{x:1678,y:957,t:1527272122861};\\\", \\\"{x:1678,y:953,t:1527272122878};\\\", \\\"{x:1677,y:949,t:1527272122894};\\\", \\\"{x:1675,y:945,t:1527272122910};\\\", \\\"{x:1674,y:940,t:1527272122927};\\\", \\\"{x:1674,y:936,t:1527272122944};\\\", \\\"{x:1672,y:933,t:1527272122960};\\\", \\\"{x:1672,y:931,t:1527272122977};\\\", \\\"{x:1671,y:927,t:1527272122994};\\\", \\\"{x:1671,y:925,t:1527272123011};\\\", \\\"{x:1671,y:921,t:1527272123027};\\\", \\\"{x:1670,y:918,t:1527272123044};\\\", \\\"{x:1670,y:917,t:1527272123060};\\\", \\\"{x:1670,y:916,t:1527272123092};\\\", \\\"{x:1670,y:915,t:1527272123100};\\\", \\\"{x:1669,y:913,t:1527272123111};\\\", \\\"{x:1667,y:909,t:1527272123132};\\\", \\\"{x:1667,y:906,t:1527272123145};\\\", \\\"{x:1666,y:901,t:1527272123160};\\\", \\\"{x:1665,y:896,t:1527272123177};\\\", \\\"{x:1665,y:886,t:1527272123195};\\\", \\\"{x:1665,y:877,t:1527272123210};\\\", \\\"{x:1665,y:873,t:1527272123228};\\\", \\\"{x:1665,y:854,t:1527272123244};\\\", \\\"{x:1665,y:852,t:1527272123260};\\\", \\\"{x:1665,y:841,t:1527272123277};\\\", \\\"{x:1665,y:834,t:1527272123294};\\\", \\\"{x:1668,y:830,t:1527272123311};\\\", \\\"{x:1668,y:828,t:1527272123328};\\\", \\\"{x:1670,y:826,t:1527272123344};\\\", \\\"{x:1671,y:822,t:1527272123362};\\\", \\\"{x:1672,y:820,t:1527272123377};\\\", \\\"{x:1672,y:818,t:1527272123395};\\\", \\\"{x:1672,y:816,t:1527272123411};\\\", \\\"{x:1673,y:814,t:1527272123437};\\\", \\\"{x:1672,y:814,t:1527272123574};\\\", \\\"{x:1669,y:817,t:1527272123581};\\\", \\\"{x:1668,y:818,t:1527272123595};\\\", \\\"{x:1666,y:821,t:1527272123611};\\\", \\\"{x:1662,y:836,t:1527272123629};\\\", \\\"{x:1658,y:844,t:1527272123645};\\\", \\\"{x:1657,y:856,t:1527272123661};\\\", \\\"{x:1655,y:860,t:1527272123678};\\\", \\\"{x:1648,y:872,t:1527272123695};\\\", \\\"{x:1642,y:882,t:1527272123712};\\\", \\\"{x:1635,y:890,t:1527272123729};\\\", \\\"{x:1629,y:896,t:1527272123745};\\\", \\\"{x:1626,y:899,t:1527272123762};\\\", \\\"{x:1621,y:904,t:1527272123779};\\\", \\\"{x:1613,y:909,t:1527272123795};\\\", \\\"{x:1607,y:913,t:1527272123812};\\\", \\\"{x:1596,y:918,t:1527272123829};\\\", \\\"{x:1596,y:919,t:1527272123861};\\\", \\\"{x:1595,y:920,t:1527272123879};\\\", \\\"{x:1594,y:921,t:1527272123942};\\\", \\\"{x:1593,y:922,t:1527272123949};\\\", \\\"{x:1593,y:923,t:1527272123962};\\\", \\\"{x:1592,y:925,t:1527272123978};\\\", \\\"{x:1592,y:926,t:1527272123996};\\\", \\\"{x:1592,y:927,t:1527272124012};\\\", \\\"{x:1592,y:934,t:1527272124029};\\\", \\\"{x:1592,y:937,t:1527272124045};\\\", \\\"{x:1592,y:940,t:1527272124062};\\\", \\\"{x:1592,y:943,t:1527272124317};\\\", \\\"{x:1592,y:945,t:1527272124329};\\\", \\\"{x:1592,y:953,t:1527272124346};\\\", \\\"{x:1595,y:962,t:1527272124362};\\\", \\\"{x:1600,y:971,t:1527272124379};\\\", \\\"{x:1602,y:973,t:1527272124396};\\\", \\\"{x:1603,y:974,t:1527272124413};\\\", \\\"{x:1603,y:975,t:1527272124501};\\\", \\\"{x:1604,y:975,t:1527272124512};\\\", \\\"{x:1605,y:975,t:1527272124573};\\\", \\\"{x:1606,y:975,t:1527272124581};\\\", \\\"{x:1607,y:975,t:1527272124596};\\\", \\\"{x:1609,y:975,t:1527272124613};\\\", \\\"{x:1611,y:974,t:1527272124629};\\\", \\\"{x:1612,y:973,t:1527272124646};\\\", \\\"{x:1613,y:972,t:1527272124663};\\\", \\\"{x:1615,y:970,t:1527272124684};\\\", \\\"{x:1616,y:968,t:1527272124830};\\\", \\\"{x:1616,y:967,t:1527272124869};\\\", \\\"{x:1617,y:966,t:1527272124880};\\\", \\\"{x:1618,y:965,t:1527272124901};\\\", \\\"{x:1618,y:964,t:1527272124913};\\\", \\\"{x:1618,y:962,t:1527272124930};\\\", \\\"{x:1621,y:956,t:1527272124947};\\\", \\\"{x:1621,y:952,t:1527272124963};\\\", \\\"{x:1622,y:949,t:1527272124980};\\\", \\\"{x:1622,y:944,t:1527272124997};\\\", \\\"{x:1622,y:940,t:1527272125013};\\\", \\\"{x:1622,y:936,t:1527272125030};\\\", \\\"{x:1624,y:932,t:1527272125047};\\\", \\\"{x:1624,y:929,t:1527272125062};\\\", \\\"{x:1624,y:925,t:1527272125080};\\\", \\\"{x:1624,y:919,t:1527272125097};\\\", \\\"{x:1624,y:915,t:1527272125113};\\\", \\\"{x:1624,y:912,t:1527272125129};\\\", \\\"{x:1624,y:909,t:1527272125147};\\\", \\\"{x:1625,y:905,t:1527272125163};\\\", \\\"{x:1626,y:896,t:1527272125180};\\\", \\\"{x:1626,y:892,t:1527272125197};\\\", \\\"{x:1626,y:891,t:1527272125212};\\\", \\\"{x:1625,y:889,t:1527272125229};\\\", \\\"{x:1624,y:883,t:1527272125247};\\\", \\\"{x:1620,y:871,t:1527272125263};\\\", \\\"{x:1620,y:870,t:1527272125279};\\\", \\\"{x:1619,y:864,t:1527272125297};\\\", \\\"{x:1617,y:857,t:1527272125314};\\\", \\\"{x:1614,y:849,t:1527272125330};\\\", \\\"{x:1613,y:845,t:1527272125347};\\\", \\\"{x:1612,y:841,t:1527272125364};\\\", \\\"{x:1610,y:836,t:1527272125380};\\\", \\\"{x:1609,y:828,t:1527272125398};\\\", \\\"{x:1608,y:826,t:1527272125414};\\\", \\\"{x:1608,y:824,t:1527272125429};\\\", \\\"{x:1608,y:822,t:1527272125446};\\\", \\\"{x:1608,y:821,t:1527272125476};\\\", \\\"{x:1608,y:827,t:1527272125718};\\\", \\\"{x:1608,y:832,t:1527272125731};\\\", \\\"{x:1608,y:841,t:1527272125747};\\\", \\\"{x:1615,y:862,t:1527272125764};\\\", \\\"{x:1627,y:886,t:1527272125780};\\\", \\\"{x:1635,y:899,t:1527272125797};\\\", \\\"{x:1638,y:906,t:1527272125814};\\\", \\\"{x:1640,y:908,t:1527272125831};\\\", \\\"{x:1642,y:910,t:1527272125847};\\\", \\\"{x:1642,y:911,t:1527272125864};\\\", \\\"{x:1643,y:911,t:1527272125885};\\\", \\\"{x:1643,y:912,t:1527272125898};\\\", \\\"{x:1644,y:914,t:1527272125913};\\\", \\\"{x:1646,y:916,t:1527272125930};\\\", \\\"{x:1647,y:916,t:1527272125946};\\\", \\\"{x:1647,y:917,t:1527272125972};\\\", \\\"{x:1648,y:918,t:1527272125980};\\\", \\\"{x:1649,y:919,t:1527272126004};\\\", \\\"{x:1644,y:915,t:1527272126157};\\\", \\\"{x:1637,y:910,t:1527272126164};\\\", \\\"{x:1621,y:895,t:1527272126180};\\\", \\\"{x:1599,y:882,t:1527272126197};\\\", \\\"{x:1551,y:859,t:1527272126214};\\\", \\\"{x:1491,y:839,t:1527272126230};\\\", \\\"{x:1475,y:823,t:1527272126248};\\\", \\\"{x:1463,y:810,t:1527272126264};\\\", \\\"{x:1453,y:802,t:1527272126281};\\\", \\\"{x:1451,y:799,t:1527272126298};\\\", \\\"{x:1446,y:796,t:1527272126315};\\\", \\\"{x:1445,y:795,t:1527272126331};\\\", \\\"{x:1445,y:793,t:1527272126349};\\\", \\\"{x:1445,y:791,t:1527272126373};\\\", \\\"{x:1442,y:788,t:1527272126389};\\\", \\\"{x:1442,y:786,t:1527272126397};\\\", \\\"{x:1438,y:781,t:1527272126414};\\\", \\\"{x:1429,y:770,t:1527272126431};\\\", \\\"{x:1420,y:759,t:1527272126448};\\\", \\\"{x:1407,y:745,t:1527272126465};\\\", \\\"{x:1395,y:733,t:1527272126481};\\\", \\\"{x:1387,y:724,t:1527272126498};\\\", \\\"{x:1375,y:708,t:1527272126514};\\\", \\\"{x:1359,y:690,t:1527272126531};\\\", \\\"{x:1356,y:680,t:1527272126547};\\\", \\\"{x:1338,y:656,t:1527272126564};\\\", \\\"{x:1333,y:650,t:1527272126581};\\\", \\\"{x:1332,y:650,t:1527272126598};\\\", \\\"{x:1331,y:649,t:1527272126628};\\\", \\\"{x:1330,y:649,t:1527272126693};\\\", \\\"{x:1329,y:648,t:1527272126709};\\\", \\\"{x:1328,y:648,t:1527272126861};\\\", \\\"{x:1327,y:646,t:1527272126956};\\\", \\\"{x:1326,y:644,t:1527272126964};\\\", \\\"{x:1324,y:642,t:1527272126981};\\\", \\\"{x:1322,y:640,t:1527272126998};\\\", \\\"{x:1321,y:639,t:1527272127014};\\\", \\\"{x:1321,y:637,t:1527272127031};\\\", \\\"{x:1317,y:631,t:1527272127048};\\\", \\\"{x:1313,y:624,t:1527272127064};\\\", \\\"{x:1307,y:612,t:1527272127081};\\\", \\\"{x:1299,y:599,t:1527272127098};\\\", \\\"{x:1292,y:590,t:1527272127114};\\\", \\\"{x:1288,y:580,t:1527272127132};\\\", \\\"{x:1285,y:572,t:1527272127149};\\\", \\\"{x:1285,y:571,t:1527272127165};\\\", \\\"{x:1285,y:570,t:1527272127182};\\\", \\\"{x:1285,y:569,t:1527272127199};\\\", \\\"{x:1285,y:568,t:1527272127215};\\\", \\\"{x:1285,y:565,t:1527272127233};\\\", \\\"{x:1285,y:564,t:1527272127265};\\\", \\\"{x:1285,y:563,t:1527272127645};\\\", \\\"{x:1286,y:562,t:1527272127685};\\\", \\\"{x:1287,y:562,t:1527272127838};\\\", \\\"{x:1288,y:562,t:1527272127853};\\\", \\\"{x:1291,y:562,t:1527272127866};\\\", \\\"{x:1294,y:562,t:1527272127883};\\\", \\\"{x:1295,y:561,t:1527272127900};\\\", \\\"{x:1297,y:561,t:1527272127916};\\\", \\\"{x:1302,y:561,t:1527272127933};\\\", \\\"{x:1307,y:561,t:1527272127949};\\\", \\\"{x:1312,y:562,t:1527272127966};\\\", \\\"{x:1317,y:563,t:1527272127983};\\\", \\\"{x:1321,y:565,t:1527272128000};\\\", \\\"{x:1323,y:565,t:1527272128016};\\\", \\\"{x:1326,y:565,t:1527272128033};\\\", \\\"{x:1328,y:565,t:1527272128050};\\\", \\\"{x:1330,y:565,t:1527272128066};\\\", \\\"{x:1331,y:565,t:1527272128085};\\\", \\\"{x:1332,y:565,t:1527272128100};\\\", \\\"{x:1333,y:565,t:1527272128116};\\\", \\\"{x:1335,y:564,t:1527272128133};\\\", \\\"{x:1336,y:564,t:1527272128150};\\\", \\\"{x:1338,y:564,t:1527272128166};\\\", \\\"{x:1340,y:564,t:1527272128453};\\\", \\\"{x:1343,y:564,t:1527272128467};\\\", \\\"{x:1350,y:564,t:1527272128483};\\\", \\\"{x:1358,y:564,t:1527272128500};\\\", \\\"{x:1378,y:562,t:1527272128517};\\\", \\\"{x:1384,y:561,t:1527272128533};\\\", \\\"{x:1387,y:561,t:1527272128550};\\\", \\\"{x:1390,y:561,t:1527272128567};\\\", \\\"{x:1392,y:561,t:1527272128646};\\\", \\\"{x:1392,y:560,t:1527272128669};\\\", \\\"{x:1393,y:560,t:1527272128734};\\\", \\\"{x:1394,y:559,t:1527272128757};\\\", \\\"{x:1395,y:559,t:1527272128767};\\\", \\\"{x:1396,y:559,t:1527272128805};\\\", \\\"{x:1398,y:559,t:1527272128829};\\\", \\\"{x:1400,y:559,t:1527272128837};\\\", \\\"{x:1403,y:559,t:1527272128850};\\\", \\\"{x:1406,y:559,t:1527272128867};\\\", \\\"{x:1408,y:559,t:1527272128884};\\\", \\\"{x:1411,y:561,t:1527272128901};\\\", \\\"{x:1417,y:561,t:1527272129036};\\\", \\\"{x:1428,y:562,t:1527272129051};\\\", \\\"{x:1449,y:563,t:1527272129067};\\\", \\\"{x:1472,y:567,t:1527272129084};\\\", \\\"{x:1494,y:567,t:1527272129100};\\\", \\\"{x:1508,y:568,t:1527272129117};\\\", \\\"{x:1511,y:568,t:1527272129134};\\\", \\\"{x:1512,y:568,t:1527272129150};\\\", \\\"{x:1513,y:568,t:1527272129166};\\\", \\\"{x:1514,y:569,t:1527272129277};\\\", \\\"{x:1514,y:570,t:1527272129284};\\\", \\\"{x:1511,y:571,t:1527272129301};\\\", \\\"{x:1498,y:571,t:1527272129318};\\\", \\\"{x:1480,y:570,t:1527272129333};\\\", \\\"{x:1464,y:569,t:1527272129351};\\\", \\\"{x:1459,y:567,t:1527272129368};\\\", \\\"{x:1452,y:566,t:1527272129384};\\\", \\\"{x:1451,y:566,t:1527272129401};\\\", \\\"{x:1452,y:565,t:1527272129534};\\\", \\\"{x:1453,y:565,t:1527272129551};\\\", \\\"{x:1454,y:565,t:1527272129568};\\\", \\\"{x:1455,y:565,t:1527272129646};\\\", \\\"{x:1457,y:565,t:1527272129653};\\\", \\\"{x:1458,y:565,t:1527272129669};\\\", \\\"{x:1460,y:565,t:1527272129685};\\\", \\\"{x:1462,y:565,t:1527272129701};\\\", \\\"{x:1464,y:565,t:1527272129718};\\\", \\\"{x:1465,y:565,t:1527272129748};\\\", \\\"{x:1467,y:565,t:1527272129764};\\\", \\\"{x:1469,y:565,t:1527272129780};\\\", \\\"{x:1471,y:565,t:1527272129788};\\\", \\\"{x:1473,y:565,t:1527272129800};\\\", \\\"{x:1474,y:565,t:1527272129817};\\\", \\\"{x:1477,y:565,t:1527272129834};\\\", \\\"{x:1478,y:565,t:1527272129948};\\\", \\\"{x:1478,y:564,t:1527272130301};\\\", \\\"{x:1480,y:563,t:1527272130319};\\\", \\\"{x:1481,y:562,t:1527272130405};\\\", \\\"{x:1475,y:562,t:1527272139990};\\\", \\\"{x:1467,y:563,t:1527272139997};\\\", \\\"{x:1448,y:567,t:1527272140013};\\\", \\\"{x:1424,y:569,t:1527272140029};\\\", \\\"{x:1376,y:578,t:1527272140045};\\\", \\\"{x:1347,y:581,t:1527272140063};\\\", \\\"{x:1239,y:581,t:1527272140078};\\\", \\\"{x:1128,y:581,t:1527272140096};\\\", \\\"{x:1031,y:581,t:1527272140112};\\\", \\\"{x:919,y:574,t:1527272140130};\\\", \\\"{x:832,y:571,t:1527272140144};\\\", \\\"{x:788,y:573,t:1527272140162};\\\", \\\"{x:769,y:573,t:1527272140180};\\\", \\\"{x:766,y:573,t:1527272140198};\\\", \\\"{x:765,y:573,t:1527272140219};\\\", \\\"{x:762,y:573,t:1527272140236};\\\", \\\"{x:759,y:573,t:1527272140248};\\\", \\\"{x:754,y:573,t:1527272140268};\\\", \\\"{x:750,y:574,t:1527272140281};\\\", \\\"{x:736,y:574,t:1527272140298};\\\", \\\"{x:722,y:574,t:1527272140316};\\\", \\\"{x:705,y:571,t:1527272140331};\\\", \\\"{x:702,y:570,t:1527272140348};\\\", \\\"{x:698,y:569,t:1527272140365};\\\", \\\"{x:696,y:566,t:1527272140501};\\\", \\\"{x:688,y:559,t:1527272140517};\\\", \\\"{x:680,y:552,t:1527272140533};\\\", \\\"{x:676,y:548,t:1527272140550};\\\", \\\"{x:673,y:546,t:1527272140566};\\\", \\\"{x:670,y:542,t:1527272140583};\\\", \\\"{x:666,y:538,t:1527272140599};\\\", \\\"{x:660,y:533,t:1527272140615};\\\", \\\"{x:654,y:528,t:1527272140633};\\\", \\\"{x:647,y:524,t:1527272140651};\\\", \\\"{x:638,y:517,t:1527272140666};\\\", \\\"{x:632,y:513,t:1527272140683};\\\", \\\"{x:622,y:508,t:1527272140700};\\\", \\\"{x:614,y:505,t:1527272140717};\\\", \\\"{x:610,y:503,t:1527272140733};\\\", \\\"{x:608,y:501,t:1527272140750};\\\", \\\"{x:605,y:500,t:1527272140766};\\\", \\\"{x:601,y:500,t:1527272140783};\\\", \\\"{x:600,y:499,t:1527272140800};\\\", \\\"{x:600,y:498,t:1527272140853};\\\", \\\"{x:599,y:498,t:1527272141334};\\\", \\\"{x:596,y:498,t:1527272141350};\\\", \\\"{x:594,y:500,t:1527272141367};\\\", \\\"{x:591,y:501,t:1527272141385};\\\", \\\"{x:584,y:511,t:1527272141400};\\\", \\\"{x:578,y:526,t:1527272141418};\\\", \\\"{x:575,y:541,t:1527272141434};\\\", \\\"{x:570,y:554,t:1527272141450};\\\", \\\"{x:564,y:568,t:1527272141468};\\\", \\\"{x:547,y:613,t:1527272141484};\\\", \\\"{x:539,y:627,t:1527272141500};\\\", \\\"{x:539,y:635,t:1527272141517};\\\", \\\"{x:539,y:637,t:1527272141534};\\\", \\\"{x:536,y:644,t:1527272141551};\\\", \\\"{x:534,y:648,t:1527272141572};\\\", \\\"{x:534,y:649,t:1527272141584};\\\", \\\"{x:533,y:652,t:1527272141601};\\\", \\\"{x:533,y:654,t:1527272141617};\\\", \\\"{x:532,y:656,t:1527272141634};\\\", \\\"{x:532,y:659,t:1527272141651};\\\", \\\"{x:530,y:662,t:1527272141666};\\\", \\\"{x:529,y:667,t:1527272141683};\\\", \\\"{x:528,y:670,t:1527272141700};\\\", \\\"{x:527,y:673,t:1527272141718};\\\", \\\"{x:524,y:676,t:1527272141734};\\\", \\\"{x:522,y:681,t:1527272141751};\\\", \\\"{x:521,y:684,t:1527272141768};\\\", \\\"{x:519,y:687,t:1527272141784};\\\", \\\"{x:519,y:689,t:1527272141801};\\\", \\\"{x:519,y:690,t:1527272141819};\\\", \\\"{x:518,y:693,t:1527272141835};\\\", \\\"{x:516,y:698,t:1527272141851};\\\", \\\"{x:512,y:707,t:1527272141868};\\\", \\\"{x:510,y:714,t:1527272141884};\\\", \\\"{x:506,y:720,t:1527272141903};\\\", \\\"{x:506,y:722,t:1527272141918};\\\", \\\"{x:505,y:723,t:1527272141934};\\\", \\\"{x:505,y:724,t:1527272141951};\\\", \\\"{x:504,y:725,t:1527272141996};\\\", \\\"{x:503,y:726,t:1527272142020};\\\" ] }, { \\\"rt\\\": 21796, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 583076, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:725,t:1527272145413};\\\", \\\"{x:505,y:724,t:1527272145420};\\\", \\\"{x:509,y:723,t:1527272145437};\\\", \\\"{x:511,y:721,t:1527272145453};\\\", \\\"{x:522,y:720,t:1527272145470};\\\", \\\"{x:534,y:715,t:1527272145489};\\\", \\\"{x:552,y:712,t:1527272145503};\\\", \\\"{x:574,y:712,t:1527272145520};\\\", \\\"{x:593,y:712,t:1527272145537};\\\", \\\"{x:627,y:703,t:1527272145552};\\\", \\\"{x:682,y:690,t:1527272145570};\\\", \\\"{x:732,y:667,t:1527272145587};\\\", \\\"{x:753,y:657,t:1527272145603};\\\", \\\"{x:767,y:649,t:1527272145620};\\\", \\\"{x:778,y:641,t:1527272145637};\\\", \\\"{x:786,y:635,t:1527272145654};\\\", \\\"{x:792,y:629,t:1527272145671};\\\", \\\"{x:795,y:626,t:1527272145687};\\\", \\\"{x:796,y:625,t:1527272149572};\\\", \\\"{x:815,y:619,t:1527272149590};\\\", \\\"{x:829,y:617,t:1527272149608};\\\", \\\"{x:834,y:615,t:1527272149623};\\\", \\\"{x:840,y:615,t:1527272149639};\\\", \\\"{x:849,y:612,t:1527272149657};\\\", \\\"{x:855,y:610,t:1527272149672};\\\", \\\"{x:858,y:608,t:1527272149690};\\\", \\\"{x:862,y:607,t:1527272149707};\\\", \\\"{x:863,y:607,t:1527272149723};\\\", \\\"{x:874,y:607,t:1527272149741};\\\", \\\"{x:887,y:607,t:1527272149757};\\\", \\\"{x:891,y:607,t:1527272149773};\\\", \\\"{x:893,y:607,t:1527272149819};\\\", \\\"{x:904,y:607,t:1527272149828};\\\", \\\"{x:913,y:607,t:1527272149840};\\\", \\\"{x:931,y:607,t:1527272149858};\\\", \\\"{x:936,y:605,t:1527272149874};\\\", \\\"{x:951,y:605,t:1527272149892};\\\", \\\"{x:979,y:607,t:1527272149907};\\\", \\\"{x:983,y:616,t:1527272149923};\\\", \\\"{x:1015,y:620,t:1527272149941};\\\", \\\"{x:1024,y:622,t:1527272149957};\\\", \\\"{x:1026,y:624,t:1527272149975};\\\", \\\"{x:1033,y:629,t:1527272149990};\\\", \\\"{x:1038,y:630,t:1527272150007};\\\", \\\"{x:1049,y:638,t:1527272150024};\\\", \\\"{x:1057,y:646,t:1527272150040};\\\", \\\"{x:1063,y:653,t:1527272150058};\\\", \\\"{x:1067,y:661,t:1527272150074};\\\", \\\"{x:1069,y:662,t:1527272150090};\\\", \\\"{x:1073,y:668,t:1527272150107};\\\", \\\"{x:1074,y:669,t:1527272150148};\\\", \\\"{x:1074,y:671,t:1527272150197};\\\", \\\"{x:1076,y:673,t:1527272150220};\\\", \\\"{x:1076,y:674,t:1527272150244};\\\", \\\"{x:1077,y:675,t:1527272150257};\\\", \\\"{x:1080,y:678,t:1527272150274};\\\", \\\"{x:1086,y:681,t:1527272150292};\\\", \\\"{x:1102,y:683,t:1527272150308};\\\", \\\"{x:1131,y:688,t:1527272150325};\\\", \\\"{x:1141,y:691,t:1527272150342};\\\", \\\"{x:1141,y:693,t:1527272150358};\\\", \\\"{x:1144,y:693,t:1527272150375};\\\", \\\"{x:1144,y:694,t:1527272150392};\\\", \\\"{x:1145,y:695,t:1527272150407};\\\", \\\"{x:1146,y:695,t:1527272150424};\\\", \\\"{x:1147,y:695,t:1527272150701};\\\", \\\"{x:1148,y:697,t:1527272150708};\\\", \\\"{x:1150,y:703,t:1527272150726};\\\", \\\"{x:1151,y:709,t:1527272150742};\\\", \\\"{x:1156,y:719,t:1527272150759};\\\", \\\"{x:1157,y:723,t:1527272150775};\\\", \\\"{x:1157,y:724,t:1527272150792};\\\", \\\"{x:1157,y:725,t:1527272150820};\\\", \\\"{x:1158,y:727,t:1527272151765};\\\", \\\"{x:1158,y:728,t:1527272151813};\\\", \\\"{x:1158,y:731,t:1527272151827};\\\", \\\"{x:1158,y:733,t:1527272151843};\\\", \\\"{x:1159,y:738,t:1527272151860};\\\", \\\"{x:1162,y:747,t:1527272151877};\\\", \\\"{x:1163,y:749,t:1527272151894};\\\", \\\"{x:1164,y:749,t:1527272151910};\\\", \\\"{x:1164,y:750,t:1527272151933};\\\", \\\"{x:1165,y:751,t:1527272152013};\\\", \\\"{x:1166,y:752,t:1527272152028};\\\", \\\"{x:1166,y:754,t:1527272152045};\\\", \\\"{x:1167,y:755,t:1527272152059};\\\", \\\"{x:1170,y:757,t:1527272152093};\\\", \\\"{x:1176,y:762,t:1527272152113};\\\", \\\"{x:1184,y:765,t:1527272152127};\\\", \\\"{x:1195,y:767,t:1527272152143};\\\", \\\"{x:1198,y:770,t:1527272152160};\\\", \\\"{x:1205,y:773,t:1527272152176};\\\", \\\"{x:1212,y:776,t:1527272152193};\\\", \\\"{x:1224,y:782,t:1527272152211};\\\", \\\"{x:1237,y:785,t:1527272152227};\\\", \\\"{x:1244,y:791,t:1527272152243};\\\", \\\"{x:1254,y:797,t:1527272152260};\\\", \\\"{x:1260,y:801,t:1527272152277};\\\", \\\"{x:1264,y:804,t:1527272152294};\\\", \\\"{x:1268,y:806,t:1527272152310};\\\", \\\"{x:1271,y:806,t:1527272152327};\\\", \\\"{x:1273,y:806,t:1527272152343};\\\", \\\"{x:1274,y:806,t:1527272152373};\\\", \\\"{x:1276,y:806,t:1527272152404};\\\", \\\"{x:1278,y:807,t:1527272152461};\\\", \\\"{x:1278,y:808,t:1527272152477};\\\", \\\"{x:1280,y:811,t:1527272152493};\\\", \\\"{x:1283,y:816,t:1527272152511};\\\", \\\"{x:1284,y:822,t:1527272152528};\\\", \\\"{x:1286,y:829,t:1527272152543};\\\", \\\"{x:1287,y:832,t:1527272152560};\\\", \\\"{x:1287,y:835,t:1527272152578};\\\", \\\"{x:1287,y:838,t:1527272152594};\\\", \\\"{x:1287,y:839,t:1527272152628};\\\", \\\"{x:1284,y:842,t:1527272152644};\\\", \\\"{x:1280,y:847,t:1527272152661};\\\", \\\"{x:1275,y:850,t:1527272152678};\\\", \\\"{x:1269,y:856,t:1527272152694};\\\", \\\"{x:1264,y:860,t:1527272152710};\\\", \\\"{x:1263,y:863,t:1527272152727};\\\", \\\"{x:1261,y:864,t:1527272152745};\\\", \\\"{x:1259,y:866,t:1527272152761};\\\", \\\"{x:1258,y:867,t:1527272152778};\\\", \\\"{x:1257,y:868,t:1527272152795};\\\", \\\"{x:1256,y:869,t:1527272152811};\\\", \\\"{x:1255,y:870,t:1527272152828};\\\", \\\"{x:1255,y:871,t:1527272152844};\\\", \\\"{x:1254,y:871,t:1527272152860};\\\", \\\"{x:1252,y:877,t:1527272152878};\\\", \\\"{x:1251,y:880,t:1527272152894};\\\", \\\"{x:1251,y:884,t:1527272152911};\\\", \\\"{x:1250,y:888,t:1527272152927};\\\", \\\"{x:1249,y:891,t:1527272152944};\\\", \\\"{x:1247,y:892,t:1527272152961};\\\", \\\"{x:1247,y:896,t:1527272152978};\\\", \\\"{x:1247,y:899,t:1527272152995};\\\", \\\"{x:1247,y:902,t:1527272153011};\\\", \\\"{x:1247,y:904,t:1527272153028};\\\", \\\"{x:1247,y:907,t:1527272153068};\\\", \\\"{x:1247,y:908,t:1527272153077};\\\", \\\"{x:1249,y:915,t:1527272153095};\\\", \\\"{x:1252,y:917,t:1527272153111};\\\", \\\"{x:1256,y:922,t:1527272153128};\\\", \\\"{x:1256,y:923,t:1527272153145};\\\", \\\"{x:1260,y:929,t:1527272153162};\\\", \\\"{x:1263,y:933,t:1527272153178};\\\", \\\"{x:1263,y:934,t:1527272153195};\\\", \\\"{x:1264,y:935,t:1527272153212};\\\", \\\"{x:1263,y:932,t:1527272153444};\\\", \\\"{x:1262,y:931,t:1527272153452};\\\", \\\"{x:1258,y:927,t:1527272153462};\\\", \\\"{x:1255,y:923,t:1527272153478};\\\", \\\"{x:1250,y:918,t:1527272153495};\\\", \\\"{x:1248,y:916,t:1527272153511};\\\", \\\"{x:1243,y:912,t:1527272153528};\\\", \\\"{x:1243,y:909,t:1527272153545};\\\", \\\"{x:1242,y:908,t:1527272153561};\\\", \\\"{x:1241,y:907,t:1527272153579};\\\", \\\"{x:1241,y:906,t:1527272153805};\\\", \\\"{x:1241,y:905,t:1527272153813};\\\", \\\"{x:1240,y:902,t:1527272153829};\\\", \\\"{x:1239,y:895,t:1527272153845};\\\", \\\"{x:1234,y:886,t:1527272153863};\\\", \\\"{x:1229,y:875,t:1527272153878};\\\", \\\"{x:1227,y:871,t:1527272153895};\\\", \\\"{x:1225,y:868,t:1527272153911};\\\", \\\"{x:1223,y:864,t:1527272153926};\\\", \\\"{x:1223,y:860,t:1527272153943};\\\", \\\"{x:1222,y:858,t:1527272153960};\\\", \\\"{x:1222,y:855,t:1527272153977};\\\", \\\"{x:1222,y:850,t:1527272153994};\\\", \\\"{x:1222,y:846,t:1527272154010};\\\", \\\"{x:1222,y:839,t:1527272154027};\\\", \\\"{x:1222,y:838,t:1527272154043};\\\", \\\"{x:1223,y:835,t:1527272154061};\\\", \\\"{x:1223,y:834,t:1527272154078};\\\", \\\"{x:1224,y:834,t:1527272154083};\\\", \\\"{x:1224,y:834,t:1527272154093};\\\", \\\"{x:1225,y:834,t:1527272154124};\\\", \\\"{x:1226,y:833,t:1527272154132};\\\", \\\"{x:1226,y:832,t:1527272154172};\\\", \\\"{x:1224,y:826,t:1527272155501};\\\", \\\"{x:1221,y:824,t:1527272155512};\\\", \\\"{x:1220,y:817,t:1527272155529};\\\", \\\"{x:1207,y:809,t:1527272155546};\\\", \\\"{x:1199,y:803,t:1527272155562};\\\", \\\"{x:1196,y:798,t:1527272155579};\\\", \\\"{x:1193,y:796,t:1527272155596};\\\", \\\"{x:1192,y:795,t:1527272155629};\\\", \\\"{x:1191,y:795,t:1527272155646};\\\", \\\"{x:1191,y:794,t:1527272156093};\\\", \\\"{x:1191,y:793,t:1527272156101};\\\", \\\"{x:1191,y:791,t:1527272156113};\\\", \\\"{x:1191,y:789,t:1527272156129};\\\", \\\"{x:1188,y:785,t:1527272156146};\\\", \\\"{x:1186,y:782,t:1527272156163};\\\", \\\"{x:1183,y:778,t:1527272156179};\\\", \\\"{x:1183,y:777,t:1527272156196};\\\", \\\"{x:1182,y:776,t:1527272156213};\\\", \\\"{x:1180,y:775,t:1527272156236};\\\", \\\"{x:1180,y:774,t:1527272156252};\\\", \\\"{x:1179,y:772,t:1527272156268};\\\", \\\"{x:1179,y:770,t:1527272156309};\\\", \\\"{x:1179,y:769,t:1527272156868};\\\", \\\"{x:1181,y:768,t:1527272156880};\\\", \\\"{x:1183,y:766,t:1527272156897};\\\", \\\"{x:1184,y:766,t:1527272156913};\\\", \\\"{x:1187,y:765,t:1527272156931};\\\", \\\"{x:1189,y:764,t:1527272156957};\\\", \\\"{x:1190,y:764,t:1527272156981};\\\", \\\"{x:1191,y:764,t:1527272157004};\\\", \\\"{x:1192,y:764,t:1527272157013};\\\", \\\"{x:1193,y:764,t:1527272157037};\\\", \\\"{x:1196,y:764,t:1527272157060};\\\", \\\"{x:1197,y:764,t:1527272157068};\\\", \\\"{x:1199,y:764,t:1527272157080};\\\", \\\"{x:1200,y:764,t:1527272157097};\\\", \\\"{x:1202,y:764,t:1527272157114};\\\", \\\"{x:1204,y:764,t:1527272157130};\\\", \\\"{x:1206,y:764,t:1527272157147};\\\", \\\"{x:1207,y:764,t:1527272157164};\\\", \\\"{x:1208,y:764,t:1527272157212};\\\", \\\"{x:1211,y:764,t:1527272157230};\\\", \\\"{x:1215,y:766,t:1527272157247};\\\", \\\"{x:1216,y:766,t:1527272157268};\\\", \\\"{x:1218,y:766,t:1527272157284};\\\", \\\"{x:1219,y:766,t:1527272157297};\\\", \\\"{x:1222,y:766,t:1527272157314};\\\", \\\"{x:1223,y:766,t:1527272157365};\\\", \\\"{x:1224,y:766,t:1527272157493};\\\", \\\"{x:1225,y:766,t:1527272157765};\\\", \\\"{x:1228,y:765,t:1527272157780};\\\", \\\"{x:1229,y:765,t:1527272157796};\\\", \\\"{x:1232,y:765,t:1527272157813};\\\", \\\"{x:1235,y:765,t:1527272157830};\\\", \\\"{x:1240,y:765,t:1527272157846};\\\", \\\"{x:1249,y:765,t:1527272157864};\\\", \\\"{x:1254,y:769,t:1527272157880};\\\", \\\"{x:1258,y:772,t:1527272157898};\\\", \\\"{x:1262,y:773,t:1527272157914};\\\", \\\"{x:1263,y:773,t:1527272157930};\\\", \\\"{x:1267,y:774,t:1527272157948};\\\", \\\"{x:1268,y:774,t:1527272158069};\\\", \\\"{x:1270,y:774,t:1527272158132};\\\", \\\"{x:1271,y:773,t:1527272158156};\\\", \\\"{x:1273,y:772,t:1527272158164};\\\", \\\"{x:1277,y:770,t:1527272158180};\\\", \\\"{x:1281,y:770,t:1527272158198};\\\", \\\"{x:1284,y:768,t:1527272158214};\\\", \\\"{x:1290,y:766,t:1527272158231};\\\", \\\"{x:1299,y:763,t:1527272158248};\\\", \\\"{x:1308,y:761,t:1527272158264};\\\", \\\"{x:1320,y:761,t:1527272158281};\\\", \\\"{x:1328,y:761,t:1527272158297};\\\", \\\"{x:1332,y:761,t:1527272158315};\\\", \\\"{x:1333,y:761,t:1527272158331};\\\", \\\"{x:1332,y:762,t:1527272158516};\\\", \\\"{x:1331,y:763,t:1527272158540};\\\", \\\"{x:1330,y:763,t:1527272158548};\\\", \\\"{x:1334,y:763,t:1527272158693};\\\", \\\"{x:1338,y:763,t:1527272158700};\\\", \\\"{x:1345,y:764,t:1527272158715};\\\", \\\"{x:1359,y:767,t:1527272158733};\\\", \\\"{x:1365,y:768,t:1527272158748};\\\", \\\"{x:1368,y:768,t:1527272158765};\\\", \\\"{x:1370,y:768,t:1527272158837};\\\", \\\"{x:1371,y:768,t:1527272158848};\\\", \\\"{x:1372,y:768,t:1527272158884};\\\", \\\"{x:1373,y:768,t:1527272158898};\\\", \\\"{x:1374,y:768,t:1527272158915};\\\", \\\"{x:1376,y:768,t:1527272158933};\\\", \\\"{x:1379,y:768,t:1527272158948};\\\", \\\"{x:1382,y:768,t:1527272158966};\\\", \\\"{x:1383,y:768,t:1527272158982};\\\", \\\"{x:1381,y:767,t:1527272159117};\\\", \\\"{x:1353,y:761,t:1527272159132};\\\", \\\"{x:1310,y:758,t:1527272159150};\\\", \\\"{x:1278,y:747,t:1527272159165};\\\", \\\"{x:1219,y:737,t:1527272159182};\\\", \\\"{x:1151,y:721,t:1527272159199};\\\", \\\"{x:1103,y:708,t:1527272159215};\\\", \\\"{x:1005,y:688,t:1527272159232};\\\", \\\"{x:916,y:672,t:1527272159250};\\\", \\\"{x:864,y:664,t:1527272159265};\\\", \\\"{x:837,y:656,t:1527272159282};\\\", \\\"{x:802,y:650,t:1527272159299};\\\", \\\"{x:780,y:640,t:1527272159315};\\\", \\\"{x:761,y:638,t:1527272159332};\\\", \\\"{x:746,y:635,t:1527272159348};\\\", \\\"{x:737,y:635,t:1527272159364};\\\", \\\"{x:729,y:633,t:1527272159382};\\\", \\\"{x:726,y:633,t:1527272159398};\\\", \\\"{x:725,y:633,t:1527272159414};\\\", \\\"{x:723,y:633,t:1527272159432};\\\", \\\"{x:712,y:630,t:1527272159449};\\\", \\\"{x:707,y:629,t:1527272159465};\\\", \\\"{x:700,y:625,t:1527272159481};\\\", \\\"{x:682,y:621,t:1527272159498};\\\", \\\"{x:657,y:610,t:1527272159515};\\\", \\\"{x:640,y:599,t:1527272159532};\\\", \\\"{x:630,y:593,t:1527272159549};\\\", \\\"{x:622,y:586,t:1527272159564};\\\", \\\"{x:615,y:583,t:1527272159583};\\\", \\\"{x:615,y:582,t:1527272159619};\\\", \\\"{x:615,y:581,t:1527272159632};\\\", \\\"{x:617,y:575,t:1527272159648};\\\", \\\"{x:632,y:565,t:1527272159665};\\\", \\\"{x:651,y:556,t:1527272159682};\\\", \\\"{x:664,y:550,t:1527272159699};\\\", \\\"{x:675,y:543,t:1527272159716};\\\", \\\"{x:682,y:542,t:1527272159732};\\\", \\\"{x:686,y:539,t:1527272159748};\\\", \\\"{x:688,y:537,t:1527272159764};\\\", \\\"{x:684,y:537,t:1527272159901};\\\", \\\"{x:681,y:537,t:1527272159915};\\\", \\\"{x:655,y:533,t:1527272159932};\\\", \\\"{x:607,y:531,t:1527272159949};\\\", \\\"{x:510,y:531,t:1527272159965};\\\", \\\"{x:414,y:524,t:1527272159982};\\\", \\\"{x:301,y:507,t:1527272159999};\\\", \\\"{x:193,y:493,t:1527272160016};\\\", \\\"{x:132,y:484,t:1527272160032};\\\", \\\"{x:119,y:476,t:1527272160049};\\\", \\\"{x:107,y:473,t:1527272160065};\\\", \\\"{x:106,y:473,t:1527272160082};\\\", \\\"{x:105,y:473,t:1527272160277};\\\", \\\"{x:106,y:474,t:1527272160283};\\\", \\\"{x:107,y:476,t:1527272160299};\\\", \\\"{x:113,y:481,t:1527272160316};\\\", \\\"{x:120,y:484,t:1527272160332};\\\", \\\"{x:125,y:486,t:1527272160349};\\\", \\\"{x:131,y:494,t:1527272160367};\\\", \\\"{x:133,y:495,t:1527272160383};\\\", \\\"{x:137,y:499,t:1527272160399};\\\", \\\"{x:138,y:501,t:1527272160416};\\\", \\\"{x:139,y:501,t:1527272160540};\\\", \\\"{x:141,y:501,t:1527272160620};\\\", \\\"{x:144,y:501,t:1527272160632};\\\", \\\"{x:146,y:501,t:1527272160649};\\\", \\\"{x:147,y:501,t:1527272160666};\\\", \\\"{x:149,y:502,t:1527272160876};\\\", \\\"{x:157,y:506,t:1527272160885};\\\", \\\"{x:172,y:514,t:1527272160899};\\\", \\\"{x:214,y:536,t:1527272160915};\\\", \\\"{x:282,y:573,t:1527272160933};\\\", \\\"{x:379,y:623,t:1527272160950};\\\", \\\"{x:486,y:684,t:1527272160966};\\\", \\\"{x:558,y:727,t:1527272160983};\\\", \\\"{x:588,y:755,t:1527272161000};\\\", \\\"{x:609,y:774,t:1527272161015};\\\", \\\"{x:630,y:790,t:1527272161033};\\\", \\\"{x:636,y:795,t:1527272161049};\\\", \\\"{x:636,y:796,t:1527272161124};\\\", \\\"{x:632,y:796,t:1527272161133};\\\", \\\"{x:620,y:785,t:1527272161149};\\\", \\\"{x:589,y:762,t:1527272161166};\\\", \\\"{x:560,y:743,t:1527272161183};\\\", \\\"{x:510,y:708,t:1527272161199};\\\", \\\"{x:484,y:684,t:1527272161216};\\\", \\\"{x:443,y:660,t:1527272161233};\\\", \\\"{x:414,y:637,t:1527272161250};\\\", \\\"{x:393,y:623,t:1527272161267};\\\", \\\"{x:381,y:612,t:1527272161282};\\\", \\\"{x:378,y:610,t:1527272161299};\\\", \\\"{x:378,y:609,t:1527272161317};\\\", \\\"{x:377,y:607,t:1527272161348};\\\", \\\"{x:376,y:606,t:1527272161363};\\\", \\\"{x:374,y:604,t:1527272161396};\\\", \\\"{x:372,y:602,t:1527272161403};\\\", \\\"{x:367,y:595,t:1527272161417};\\\", \\\"{x:344,y:584,t:1527272161433};\\\", \\\"{x:318,y:570,t:1527272161449};\\\", \\\"{x:289,y:555,t:1527272161468};\\\", \\\"{x:248,y:547,t:1527272161484};\\\", \\\"{x:226,y:534,t:1527272161500};\\\", \\\"{x:220,y:528,t:1527272161517};\\\", \\\"{x:218,y:527,t:1527272161532};\\\", \\\"{x:217,y:527,t:1527272161550};\\\", \\\"{x:217,y:526,t:1527272161571};\\\", \\\"{x:217,y:525,t:1527272161583};\\\", \\\"{x:217,y:523,t:1527272161601};\\\", \\\"{x:219,y:521,t:1527272161616};\\\", \\\"{x:222,y:520,t:1527272161634};\\\", \\\"{x:223,y:520,t:1527272161649};\\\", \\\"{x:222,y:520,t:1527272161748};\\\", \\\"{x:220,y:520,t:1527272161756};\\\", \\\"{x:218,y:523,t:1527272161767};\\\", \\\"{x:213,y:523,t:1527272161784};\\\", \\\"{x:214,y:523,t:1527272161956};\\\", \\\"{x:216,y:523,t:1527272161972};\\\", \\\"{x:216,y:522,t:1527272161985};\\\", \\\"{x:216,y:521,t:1527272162789};\\\", \\\"{x:215,y:521,t:1527272162804};\\\", \\\"{x:214,y:521,t:1527272162828};\\\", \\\"{x:213,y:521,t:1527272162909};\\\", \\\"{x:210,y:521,t:1527272162924};\\\", \\\"{x:209,y:521,t:1527272162940};\\\", \\\"{x:208,y:520,t:1527272162955};\\\", \\\"{x:206,y:519,t:1527272163021};\\\", \\\"{x:204,y:517,t:1527272163039};\\\", \\\"{x:202,y:515,t:1527272163055};\\\", \\\"{x:201,y:515,t:1527272163365};\\\", \\\"{x:200,y:515,t:1527272163372};\\\", \\\"{x:198,y:515,t:1527272163385};\\\", \\\"{x:197,y:513,t:1527272163461};\\\", \\\"{x:196,y:513,t:1527272163492};\\\", \\\"{x:195,y:513,t:1527272163502};\\\", \\\"{x:194,y:513,t:1527272163519};\\\", \\\"{x:193,y:513,t:1527272163676};\\\", \\\"{x:192,y:512,t:1527272164004};\\\", \\\"{x:191,y:511,t:1527272164019};\\\", \\\"{x:186,y:505,t:1527272164037};\\\", \\\"{x:183,y:502,t:1527272164052};\\\", \\\"{x:180,y:500,t:1527272164069};\\\", \\\"{x:178,y:500,t:1527272164084};\\\", \\\"{x:177,y:498,t:1527272164102};\\\", \\\"{x:176,y:498,t:1527272164118};\\\", \\\"{x:173,y:497,t:1527272164147};\\\", \\\"{x:172,y:497,t:1527272164155};\\\", \\\"{x:171,y:497,t:1527272164171};\\\", \\\"{x:169,y:497,t:1527272164184};\\\", \\\"{x:164,y:495,t:1527272164202};\\\", \\\"{x:162,y:494,t:1527272164218};\\\", \\\"{x:162,y:493,t:1527272164235};\\\", \\\"{x:176,y:503,t:1527272164717};\\\", \\\"{x:215,y:531,t:1527272164726};\\\", \\\"{x:233,y:539,t:1527272164736};\\\", \\\"{x:321,y:595,t:1527272164753};\\\", \\\"{x:360,y:627,t:1527272164769};\\\", \\\"{x:391,y:654,t:1527272164786};\\\", \\\"{x:409,y:665,t:1527272164803};\\\", \\\"{x:424,y:672,t:1527272164819};\\\", \\\"{x:431,y:675,t:1527272164835};\\\", \\\"{x:431,y:676,t:1527272164853};\\\", \\\"{x:429,y:676,t:1527272164931};\\\", \\\"{x:428,y:676,t:1527272164939};\\\", \\\"{x:427,y:676,t:1527272164956};\\\", \\\"{x:426,y:676,t:1527272164970};\\\", \\\"{x:423,y:678,t:1527272164985};\\\", \\\"{x:423,y:679,t:1527272165100};\\\", \\\"{x:427,y:683,t:1527272165108};\\\", \\\"{x:428,y:686,t:1527272165120};\\\", \\\"{x:430,y:688,t:1527272165141};\\\", \\\"{x:436,y:695,t:1527272165153};\\\", \\\"{x:448,y:712,t:1527272165170};\\\", \\\"{x:456,y:720,t:1527272165190};\\\", \\\"{x:461,y:720,t:1527272165203};\\\", \\\"{x:467,y:724,t:1527272165219};\\\" ] }, { \\\"rt\\\": 74804, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 659116, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -O -F -F -B -B -G -F -F -M -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:468,y:725,t:1527272181732};\\\", \\\"{x:470,y:725,t:1527272181751};\\\", \\\"{x:471,y:725,t:1527272181775};\\\", \\\"{x:472,y:724,t:1527272182107};\\\", \\\"{x:475,y:723,t:1527272182115};\\\", \\\"{x:479,y:719,t:1527272182127};\\\", \\\"{x:514,y:703,t:1527272182142};\\\", \\\"{x:535,y:691,t:1527272182158};\\\", \\\"{x:544,y:679,t:1527272182174};\\\", \\\"{x:568,y:666,t:1527272182190};\\\", \\\"{x:575,y:663,t:1527272182207};\\\", \\\"{x:595,y:657,t:1527272182224};\\\", \\\"{x:626,y:652,t:1527272182241};\\\", \\\"{x:645,y:650,t:1527272182257};\\\", \\\"{x:665,y:650,t:1527272182273};\\\", \\\"{x:678,y:650,t:1527272182290};\\\", \\\"{x:687,y:650,t:1527272182306};\\\", \\\"{x:694,y:650,t:1527272182324};\\\", \\\"{x:700,y:650,t:1527272182341};\\\", \\\"{x:703,y:650,t:1527272182357};\\\", \\\"{x:713,y:650,t:1527272182374};\\\", \\\"{x:740,y:650,t:1527272182390};\\\", \\\"{x:762,y:651,t:1527272182408};\\\", \\\"{x:793,y:656,t:1527272182424};\\\", \\\"{x:842,y:665,t:1527272182441};\\\", \\\"{x:920,y:678,t:1527272182458};\\\", \\\"{x:977,y:690,t:1527272182474};\\\", \\\"{x:1019,y:703,t:1527272182492};\\\", \\\"{x:1075,y:711,t:1527272182508};\\\", \\\"{x:1118,y:716,t:1527272182524};\\\", \\\"{x:1136,y:717,t:1527272182541};\\\", \\\"{x:1147,y:717,t:1527272182558};\\\", \\\"{x:1162,y:716,t:1527272182574};\\\", \\\"{x:1180,y:712,t:1527272182591};\\\", \\\"{x:1204,y:711,t:1527272182608};\\\", \\\"{x:1220,y:710,t:1527272182624};\\\", \\\"{x:1237,y:707,t:1527272182641};\\\", \\\"{x:1245,y:708,t:1527272182658};\\\", \\\"{x:1262,y:710,t:1527272182674};\\\", \\\"{x:1276,y:710,t:1527272182692};\\\", \\\"{x:1286,y:709,t:1527272182708};\\\", \\\"{x:1293,y:708,t:1527272182725};\\\", \\\"{x:1306,y:707,t:1527272182741};\\\", \\\"{x:1320,y:705,t:1527272182758};\\\", \\\"{x:1338,y:701,t:1527272182775};\\\", \\\"{x:1344,y:701,t:1527272182793};\\\", \\\"{x:1346,y:701,t:1527272182939};\\\", \\\"{x:1347,y:701,t:1527272182971};\\\", \\\"{x:1349,y:701,t:1527272182986};\\\", \\\"{x:1354,y:701,t:1527272182996};\\\", \\\"{x:1358,y:701,t:1527272183008};\\\", \\\"{x:1363,y:701,t:1527272183025};\\\", \\\"{x:1367,y:701,t:1527272183040};\\\", \\\"{x:1370,y:701,t:1527272183058};\\\", \\\"{x:1374,y:701,t:1527272183074};\\\", \\\"{x:1378,y:700,t:1527272183092};\\\", \\\"{x:1383,y:700,t:1527272183107};\\\", \\\"{x:1388,y:698,t:1527272183125};\\\", \\\"{x:1392,y:697,t:1527272183142};\\\", \\\"{x:1394,y:697,t:1527272183157};\\\", \\\"{x:1401,y:697,t:1527272183175};\\\", \\\"{x:1407,y:697,t:1527272183192};\\\", \\\"{x:1415,y:697,t:1527272183208};\\\", \\\"{x:1421,y:697,t:1527272183225};\\\", \\\"{x:1424,y:697,t:1527272183242};\\\", \\\"{x:1425,y:697,t:1527272183258};\\\", \\\"{x:1426,y:697,t:1527272183355};\\\", \\\"{x:1429,y:697,t:1527272183363};\\\", \\\"{x:1431,y:697,t:1527272183387};\\\", \\\"{x:1434,y:697,t:1527272183403};\\\", \\\"{x:1438,y:697,t:1527272183411};\\\", \\\"{x:1439,y:697,t:1527272183425};\\\", \\\"{x:1441,y:697,t:1527272183442};\\\", \\\"{x:1449,y:697,t:1527272183459};\\\", \\\"{x:1454,y:697,t:1527272183475};\\\", \\\"{x:1458,y:697,t:1527272183492};\\\", \\\"{x:1460,y:697,t:1527272183532};\\\", \\\"{x:1461,y:697,t:1527272183547};\\\", \\\"{x:1463,y:697,t:1527272183563};\\\", \\\"{x:1464,y:697,t:1527272183780};\\\", \\\"{x:1465,y:697,t:1527272183792};\\\", \\\"{x:1466,y:697,t:1527272183809};\\\", \\\"{x:1467,y:697,t:1527272183826};\\\", \\\"{x:1470,y:697,t:1527272183841};\\\", \\\"{x:1475,y:697,t:1527272183858};\\\", \\\"{x:1477,y:697,t:1527272183876};\\\", \\\"{x:1479,y:698,t:1527272183892};\\\", \\\"{x:1480,y:698,t:1527272183909};\\\", \\\"{x:1481,y:698,t:1527272183926};\\\", \\\"{x:1481,y:700,t:1527272186084};\\\", \\\"{x:1481,y:703,t:1527272186095};\\\", \\\"{x:1480,y:710,t:1527272186111};\\\", \\\"{x:1478,y:722,t:1527272186129};\\\", \\\"{x:1476,y:732,t:1527272186146};\\\", \\\"{x:1474,y:743,t:1527272186162};\\\", \\\"{x:1469,y:750,t:1527272186179};\\\", \\\"{x:1462,y:769,t:1527272186195};\\\", \\\"{x:1459,y:782,t:1527272186212};\\\", \\\"{x:1454,y:800,t:1527272186228};\\\", \\\"{x:1449,y:817,t:1527272186246};\\\", \\\"{x:1445,y:833,t:1527272186263};\\\", \\\"{x:1441,y:846,t:1527272186279};\\\", \\\"{x:1441,y:857,t:1527272186295};\\\", \\\"{x:1438,y:867,t:1527272186312};\\\", \\\"{x:1438,y:876,t:1527272186329};\\\", \\\"{x:1440,y:881,t:1527272186345};\\\", \\\"{x:1441,y:888,t:1527272186363};\\\", \\\"{x:1444,y:892,t:1527272186378};\\\", \\\"{x:1448,y:897,t:1527272186395};\\\", \\\"{x:1451,y:901,t:1527272186412};\\\", \\\"{x:1454,y:904,t:1527272186429};\\\", \\\"{x:1458,y:907,t:1527272186445};\\\", \\\"{x:1458,y:908,t:1527272186463};\\\", \\\"{x:1458,y:910,t:1527272186478};\\\", \\\"{x:1459,y:912,t:1527272186496};\\\", \\\"{x:1459,y:913,t:1527272186512};\\\", \\\"{x:1459,y:915,t:1527272186530};\\\", \\\"{x:1459,y:918,t:1527272186562};\\\", \\\"{x:1460,y:919,t:1527272186579};\\\", \\\"{x:1461,y:922,t:1527272186595};\\\", \\\"{x:1461,y:923,t:1527272186612};\\\", \\\"{x:1461,y:925,t:1527272186635};\\\", \\\"{x:1461,y:929,t:1527272186651};\\\", \\\"{x:1461,y:932,t:1527272186666};\\\", \\\"{x:1459,y:934,t:1527272186679};\\\", \\\"{x:1458,y:937,t:1527272186695};\\\", \\\"{x:1457,y:939,t:1527272186712};\\\", \\\"{x:1457,y:940,t:1527272186819};\\\", \\\"{x:1457,y:941,t:1527272186851};\\\", \\\"{x:1455,y:942,t:1527272186875};\\\", \\\"{x:1455,y:943,t:1527272186995};\\\", \\\"{x:1455,y:944,t:1527272187002};\\\", \\\"{x:1455,y:945,t:1527272187012};\\\", \\\"{x:1455,y:946,t:1527272187034};\\\", \\\"{x:1455,y:947,t:1527272187046};\\\", \\\"{x:1455,y:949,t:1527272187062};\\\", \\\"{x:1455,y:950,t:1527272187079};\\\", \\\"{x:1455,y:951,t:1527272187098};\\\", \\\"{x:1454,y:949,t:1527272187299};\\\", \\\"{x:1454,y:948,t:1527272187314};\\\", \\\"{x:1453,y:946,t:1527272187329};\\\", \\\"{x:1451,y:941,t:1527272187346};\\\", \\\"{x:1448,y:934,t:1527272187364};\\\", \\\"{x:1448,y:931,t:1527272187379};\\\", \\\"{x:1448,y:928,t:1527272187396};\\\", \\\"{x:1448,y:920,t:1527272187413};\\\", \\\"{x:1449,y:908,t:1527272187429};\\\", \\\"{x:1450,y:892,t:1527272187446};\\\", \\\"{x:1450,y:874,t:1527272187463};\\\", \\\"{x:1448,y:854,t:1527272187480};\\\", \\\"{x:1447,y:834,t:1527272187496};\\\", \\\"{x:1454,y:812,t:1527272187513};\\\", \\\"{x:1460,y:791,t:1527272187530};\\\", \\\"{x:1465,y:781,t:1527272187547};\\\", \\\"{x:1467,y:766,t:1527272187562};\\\", \\\"{x:1471,y:755,t:1527272187580};\\\", \\\"{x:1471,y:752,t:1527272187596};\\\", \\\"{x:1471,y:749,t:1527272187613};\\\", \\\"{x:1470,y:747,t:1527272187630};\\\", \\\"{x:1470,y:746,t:1527272187647};\\\", \\\"{x:1470,y:745,t:1527272187663};\\\", \\\"{x:1471,y:743,t:1527272187680};\\\", \\\"{x:1471,y:741,t:1527272187696};\\\", \\\"{x:1472,y:739,t:1527272187714};\\\", \\\"{x:1473,y:737,t:1527272187730};\\\", \\\"{x:1473,y:735,t:1527272187746};\\\", \\\"{x:1473,y:730,t:1527272187764};\\\", \\\"{x:1473,y:726,t:1527272187781};\\\", \\\"{x:1472,y:721,t:1527272187796};\\\", \\\"{x:1472,y:716,t:1527272187813};\\\", \\\"{x:1471,y:712,t:1527272187830};\\\", \\\"{x:1471,y:710,t:1527272187847};\\\", \\\"{x:1471,y:709,t:1527272187863};\\\", \\\"{x:1475,y:714,t:1527272188107};\\\", \\\"{x:1479,y:720,t:1527272188115};\\\", \\\"{x:1484,y:726,t:1527272188131};\\\", \\\"{x:1500,y:744,t:1527272188147};\\\", \\\"{x:1512,y:754,t:1527272188164};\\\", \\\"{x:1525,y:768,t:1527272188181};\\\", \\\"{x:1532,y:777,t:1527272188197};\\\", \\\"{x:1535,y:783,t:1527272188215};\\\", \\\"{x:1537,y:786,t:1527272188231};\\\", \\\"{x:1537,y:789,t:1527272188248};\\\", \\\"{x:1539,y:794,t:1527272188265};\\\", \\\"{x:1541,y:804,t:1527272188280};\\\", \\\"{x:1544,y:812,t:1527272188298};\\\", \\\"{x:1547,y:819,t:1527272188315};\\\", \\\"{x:1549,y:827,t:1527272188330};\\\", \\\"{x:1552,y:831,t:1527272188347};\\\", \\\"{x:1554,y:836,t:1527272188364};\\\", \\\"{x:1555,y:839,t:1527272188381};\\\", \\\"{x:1558,y:839,t:1527272188398};\\\", \\\"{x:1563,y:851,t:1527272188415};\\\", \\\"{x:1565,y:859,t:1527272188430};\\\", \\\"{x:1569,y:862,t:1527272188447};\\\", \\\"{x:1574,y:873,t:1527272188464};\\\", \\\"{x:1581,y:887,t:1527272188481};\\\", \\\"{x:1583,y:892,t:1527272188498};\\\", \\\"{x:1583,y:895,t:1527272188515};\\\", \\\"{x:1579,y:889,t:1527272188644};\\\", \\\"{x:1576,y:885,t:1527272188651};\\\", \\\"{x:1575,y:882,t:1527272188665};\\\", \\\"{x:1569,y:875,t:1527272188681};\\\", \\\"{x:1568,y:873,t:1527272188697};\\\", \\\"{x:1562,y:863,t:1527272188715};\\\", \\\"{x:1561,y:859,t:1527272188732};\\\", \\\"{x:1557,y:850,t:1527272188749};\\\", \\\"{x:1552,y:842,t:1527272188765};\\\", \\\"{x:1549,y:836,t:1527272188781};\\\", \\\"{x:1538,y:825,t:1527272188799};\\\", \\\"{x:1528,y:817,t:1527272188814};\\\", \\\"{x:1527,y:816,t:1527272188831};\\\", \\\"{x:1513,y:805,t:1527272188848};\\\", \\\"{x:1493,y:791,t:1527272188864};\\\", \\\"{x:1470,y:776,t:1527272188881};\\\", \\\"{x:1444,y:757,t:1527272188898};\\\", \\\"{x:1426,y:742,t:1527272188914};\\\", \\\"{x:1424,y:741,t:1527272188931};\\\", \\\"{x:1424,y:740,t:1527272189035};\\\", \\\"{x:1423,y:741,t:1527272189588};\\\", \\\"{x:1422,y:741,t:1527272189602};\\\", \\\"{x:1421,y:741,t:1527272189615};\\\", \\\"{x:1419,y:741,t:1527272189632};\\\", \\\"{x:1412,y:741,t:1527272189648};\\\", \\\"{x:1400,y:735,t:1527272189665};\\\", \\\"{x:1382,y:719,t:1527272189682};\\\", \\\"{x:1365,y:708,t:1527272189698};\\\", \\\"{x:1350,y:702,t:1527272189715};\\\", \\\"{x:1344,y:701,t:1527272189732};\\\", \\\"{x:1344,y:700,t:1527272189749};\\\", \\\"{x:1343,y:700,t:1527272190083};\\\", \\\"{x:1343,y:699,t:1527272190155};\\\", \\\"{x:1338,y:701,t:1527272190168};\\\", \\\"{x:1329,y:704,t:1527272190182};\\\", \\\"{x:1326,y:705,t:1527272190199};\\\", \\\"{x:1325,y:706,t:1527272190217};\\\", \\\"{x:1327,y:703,t:1527272190475};\\\", \\\"{x:1330,y:702,t:1527272190483};\\\", \\\"{x:1334,y:699,t:1527272190499};\\\", \\\"{x:1336,y:698,t:1527272190516};\\\", \\\"{x:1350,y:694,t:1527272190534};\\\", \\\"{x:1354,y:693,t:1527272190550};\\\", \\\"{x:1357,y:692,t:1527272190566};\\\", \\\"{x:1358,y:691,t:1527272192044};\\\", \\\"{x:1360,y:690,t:1527272192051};\\\", \\\"{x:1361,y:690,t:1527272192069};\\\", \\\"{x:1364,y:688,t:1527272192085};\\\", \\\"{x:1366,y:688,t:1527272192102};\\\", \\\"{x:1368,y:688,t:1527272192119};\\\", \\\"{x:1374,y:688,t:1527272192134};\\\", \\\"{x:1376,y:688,t:1527272192152};\\\", \\\"{x:1381,y:688,t:1527272192169};\\\", \\\"{x:1388,y:688,t:1527272192185};\\\", \\\"{x:1400,y:689,t:1527272192201};\\\", \\\"{x:1413,y:689,t:1527272192219};\\\", \\\"{x:1417,y:690,t:1527272192235};\\\", \\\"{x:1425,y:690,t:1527272192252};\\\", \\\"{x:1427,y:690,t:1527272192268};\\\", \\\"{x:1428,y:690,t:1527272192307};\\\", \\\"{x:1429,y:690,t:1527272192324};\\\", \\\"{x:1432,y:688,t:1527272192579};\\\", \\\"{x:1434,y:688,t:1527272192587};\\\", \\\"{x:1440,y:688,t:1527272192603};\\\", \\\"{x:1449,y:688,t:1527272192619};\\\", \\\"{x:1456,y:688,t:1527272192636};\\\", \\\"{x:1458,y:688,t:1527272192652};\\\", \\\"{x:1465,y:688,t:1527272192669};\\\", \\\"{x:1467,y:688,t:1527272192686};\\\", \\\"{x:1468,y:688,t:1527272192931};\\\", \\\"{x:1468,y:689,t:1527272192939};\\\", \\\"{x:1468,y:690,t:1527272192953};\\\", \\\"{x:1466,y:693,t:1527272192970};\\\", \\\"{x:1464,y:696,t:1527272192986};\\\", \\\"{x:1458,y:700,t:1527272193003};\\\", \\\"{x:1453,y:704,t:1527272193019};\\\", \\\"{x:1444,y:707,t:1527272193035};\\\", \\\"{x:1442,y:707,t:1527272193053};\\\", \\\"{x:1438,y:708,t:1527272193069};\\\", \\\"{x:1423,y:718,t:1527272193085};\\\", \\\"{x:1413,y:728,t:1527272193103};\\\", \\\"{x:1407,y:733,t:1527272193120};\\\", \\\"{x:1404,y:735,t:1527272193136};\\\", \\\"{x:1403,y:736,t:1527272193153};\\\", \\\"{x:1402,y:737,t:1527272193170};\\\", \\\"{x:1399,y:740,t:1527272193187};\\\", \\\"{x:1397,y:742,t:1527272193203};\\\", \\\"{x:1395,y:742,t:1527272193363};\\\", \\\"{x:1395,y:743,t:1527272193379};\\\", \\\"{x:1393,y:743,t:1527272193387};\\\", \\\"{x:1389,y:743,t:1527272193403};\\\", \\\"{x:1384,y:745,t:1527272193420};\\\", \\\"{x:1379,y:747,t:1527272193437};\\\", \\\"{x:1375,y:747,t:1527272193453};\\\", \\\"{x:1370,y:750,t:1527272193470};\\\", \\\"{x:1360,y:751,t:1527272193487};\\\", \\\"{x:1358,y:751,t:1527272193504};\\\", \\\"{x:1351,y:753,t:1527272193520};\\\", \\\"{x:1345,y:754,t:1527272193537};\\\", \\\"{x:1344,y:755,t:1527272193553};\\\", \\\"{x:1340,y:756,t:1527272193570};\\\", \\\"{x:1339,y:756,t:1527272193587};\\\", \\\"{x:1337,y:756,t:1527272193603};\\\", \\\"{x:1337,y:758,t:1527272193652};\\\", \\\"{x:1336,y:758,t:1527272193667};\\\", \\\"{x:1335,y:759,t:1527272193683};\\\", \\\"{x:1333,y:760,t:1527272193691};\\\", \\\"{x:1331,y:761,t:1527272193704};\\\", \\\"{x:1330,y:762,t:1527272193720};\\\", \\\"{x:1328,y:764,t:1527272193737};\\\", \\\"{x:1327,y:765,t:1527272193755};\\\", \\\"{x:1326,y:765,t:1527272193770};\\\", \\\"{x:1323,y:766,t:1527272193786};\\\", \\\"{x:1322,y:766,t:1527272193803};\\\", \\\"{x:1326,y:764,t:1527272195067};\\\", \\\"{x:1334,y:764,t:1527272195075};\\\", \\\"{x:1338,y:763,t:1527272195089};\\\", \\\"{x:1350,y:762,t:1527272195106};\\\", \\\"{x:1361,y:762,t:1527272195123};\\\", \\\"{x:1365,y:762,t:1527272195139};\\\", \\\"{x:1369,y:762,t:1527272195155};\\\", \\\"{x:1368,y:763,t:1527272195339};\\\", \\\"{x:1367,y:764,t:1527272195355};\\\", \\\"{x:1366,y:765,t:1527272195372};\\\", \\\"{x:1363,y:767,t:1527272195389};\\\", \\\"{x:1362,y:767,t:1527272195540};\\\", \\\"{x:1364,y:766,t:1527272195555};\\\", \\\"{x:1371,y:765,t:1527272195572};\\\", \\\"{x:1384,y:763,t:1527272195589};\\\", \\\"{x:1391,y:763,t:1527272195606};\\\", \\\"{x:1398,y:763,t:1527272195621};\\\", \\\"{x:1402,y:763,t:1527272195638};\\\", \\\"{x:1404,y:764,t:1527272195656};\\\", \\\"{x:1406,y:764,t:1527272195859};\\\", \\\"{x:1408,y:764,t:1527272195873};\\\", \\\"{x:1412,y:764,t:1527272195888};\\\", \\\"{x:1420,y:764,t:1527272195905};\\\", \\\"{x:1424,y:764,t:1527272195922};\\\", \\\"{x:1427,y:767,t:1527272195939};\\\", \\\"{x:1429,y:767,t:1527272195955};\\\", \\\"{x:1430,y:767,t:1527272196219};\\\", \\\"{x:1431,y:767,t:1527272196492};\\\", \\\"{x:1432,y:766,t:1527272196548};\\\", \\\"{x:1433,y:765,t:1527272196557};\\\", \\\"{x:1435,y:765,t:1527272196635};\\\", \\\"{x:1436,y:764,t:1527272196643};\\\", \\\"{x:1437,y:764,t:1527272196667};\\\", \\\"{x:1439,y:763,t:1527272196675};\\\", \\\"{x:1440,y:763,t:1527272196690};\\\", \\\"{x:1443,y:762,t:1527272196707};\\\", \\\"{x:1444,y:761,t:1527272196724};\\\", \\\"{x:1445,y:760,t:1527272196747};\\\", \\\"{x:1447,y:759,t:1527272196757};\\\", \\\"{x:1449,y:759,t:1527272196774};\\\", \\\"{x:1449,y:758,t:1527272196803};\\\", \\\"{x:1448,y:758,t:1527272197427};\\\", \\\"{x:1446,y:759,t:1527272198252};\\\", \\\"{x:1445,y:759,t:1527272198259};\\\", \\\"{x:1441,y:761,t:1527272198275};\\\", \\\"{x:1439,y:761,t:1527272198323};\\\", \\\"{x:1438,y:761,t:1527272198331};\\\", \\\"{x:1437,y:761,t:1527272198347};\\\", \\\"{x:1436,y:761,t:1527272198359};\\\", \\\"{x:1435,y:761,t:1527272198375};\\\", \\\"{x:1435,y:759,t:1527272198395};\\\", \\\"{x:1435,y:757,t:1527272198409};\\\", \\\"{x:1436,y:755,t:1527272198425};\\\", \\\"{x:1437,y:754,t:1527272198443};\\\", \\\"{x:1439,y:753,t:1527272198459};\\\", \\\"{x:1439,y:752,t:1527272198747};\\\", \\\"{x:1440,y:752,t:1527272198759};\\\", \\\"{x:1440,y:751,t:1527272198803};\\\", \\\"{x:1439,y:752,t:1527272200228};\\\", \\\"{x:1434,y:754,t:1527272200244};\\\", \\\"{x:1428,y:756,t:1527272200261};\\\", \\\"{x:1418,y:760,t:1527272200277};\\\", \\\"{x:1412,y:760,t:1527272200299};\\\", \\\"{x:1410,y:760,t:1527272200311};\\\", \\\"{x:1408,y:760,t:1527272200327};\\\", \\\"{x:1400,y:765,t:1527272200344};\\\", \\\"{x:1386,y:770,t:1527272200361};\\\", \\\"{x:1365,y:776,t:1527272200378};\\\", \\\"{x:1362,y:777,t:1527272200394};\\\", \\\"{x:1345,y:786,t:1527272200411};\\\", \\\"{x:1340,y:788,t:1527272200427};\\\", \\\"{x:1338,y:789,t:1527272200444};\\\", \\\"{x:1338,y:788,t:1527272200604};\\\", \\\"{x:1341,y:788,t:1527272200699};\\\", \\\"{x:1341,y:787,t:1527272200739};\\\", \\\"{x:1344,y:787,t:1527272201699};\\\", \\\"{x:1347,y:787,t:1527272201712};\\\", \\\"{x:1348,y:787,t:1527272201729};\\\", \\\"{x:1355,y:787,t:1527272201746};\\\", \\\"{x:1360,y:785,t:1527272201762};\\\", \\\"{x:1377,y:784,t:1527272201779};\\\", \\\"{x:1383,y:783,t:1527272201797};\\\", \\\"{x:1392,y:780,t:1527272201812};\\\", \\\"{x:1394,y:780,t:1527272201830};\\\", \\\"{x:1403,y:777,t:1527272201846};\\\", \\\"{x:1409,y:772,t:1527272201862};\\\", \\\"{x:1417,y:768,t:1527272201879};\\\", \\\"{x:1423,y:765,t:1527272201896};\\\", \\\"{x:1430,y:762,t:1527272201913};\\\", \\\"{x:1437,y:759,t:1527272201930};\\\", \\\"{x:1442,y:757,t:1527272201946};\\\", \\\"{x:1447,y:752,t:1527272201963};\\\", \\\"{x:1447,y:751,t:1527272201986};\\\", \\\"{x:1446,y:749,t:1527272202740};\\\", \\\"{x:1440,y:746,t:1527272202747};\\\", \\\"{x:1433,y:744,t:1527272202764};\\\", \\\"{x:1430,y:739,t:1527272202780};\\\", \\\"{x:1428,y:738,t:1527272202797};\\\", \\\"{x:1427,y:737,t:1527272202813};\\\", \\\"{x:1425,y:735,t:1527272202830};\\\", \\\"{x:1425,y:733,t:1527272202867};\\\", \\\"{x:1425,y:732,t:1527272202883};\\\", \\\"{x:1425,y:730,t:1527272202907};\\\", \\\"{x:1424,y:730,t:1527272202915};\\\", \\\"{x:1423,y:729,t:1527272202930};\\\", \\\"{x:1417,y:728,t:1527272202947};\\\", \\\"{x:1412,y:728,t:1527272202964};\\\", \\\"{x:1405,y:724,t:1527272202980};\\\", \\\"{x:1390,y:716,t:1527272202997};\\\", \\\"{x:1386,y:715,t:1527272203014};\\\", \\\"{x:1385,y:714,t:1527272203030};\\\", \\\"{x:1383,y:713,t:1527272203059};\\\", \\\"{x:1383,y:711,t:1527272203164};\\\", \\\"{x:1383,y:710,t:1527272203180};\\\", \\\"{x:1383,y:708,t:1527272203197};\\\", \\\"{x:1383,y:705,t:1527272203214};\\\", \\\"{x:1383,y:703,t:1527272203231};\\\", \\\"{x:1382,y:699,t:1527272203248};\\\", \\\"{x:1382,y:698,t:1527272203264};\\\", \\\"{x:1382,y:692,t:1527272203281};\\\", \\\"{x:1380,y:691,t:1527272203297};\\\", \\\"{x:1375,y:679,t:1527272203314};\\\", \\\"{x:1365,y:660,t:1527272203330};\\\", \\\"{x:1363,y:658,t:1527272203347};\\\", \\\"{x:1359,y:649,t:1527272203365};\\\", \\\"{x:1357,y:644,t:1527272203382};\\\", \\\"{x:1356,y:641,t:1527272203397};\\\", \\\"{x:1352,y:630,t:1527272203413};\\\", \\\"{x:1349,y:627,t:1527272203430};\\\", \\\"{x:1349,y:626,t:1527272203447};\\\", \\\"{x:1348,y:624,t:1527272203463};\\\", \\\"{x:1348,y:623,t:1527272203480};\\\", \\\"{x:1348,y:622,t:1527272203498};\\\", \\\"{x:1347,y:622,t:1527272203554};\\\", \\\"{x:1347,y:621,t:1527272203852};\\\", \\\"{x:1345,y:619,t:1527272203864};\\\", \\\"{x:1342,y:615,t:1527272203881};\\\", \\\"{x:1342,y:612,t:1527272203898};\\\", \\\"{x:1340,y:610,t:1527272203915};\\\", \\\"{x:1339,y:609,t:1527272203955};\\\", \\\"{x:1338,y:608,t:1527272203965};\\\", \\\"{x:1335,y:605,t:1527272203981};\\\", \\\"{x:1333,y:601,t:1527272203999};\\\", \\\"{x:1325,y:594,t:1527272204016};\\\", \\\"{x:1319,y:590,t:1527272204031};\\\", \\\"{x:1315,y:587,t:1527272204049};\\\", \\\"{x:1312,y:584,t:1527272204065};\\\", \\\"{x:1309,y:582,t:1527272204082};\\\", \\\"{x:1306,y:580,t:1527272204099};\\\", \\\"{x:1297,y:574,t:1527272204114};\\\", \\\"{x:1295,y:572,t:1527272204131};\\\", \\\"{x:1294,y:571,t:1527272204149};\\\", \\\"{x:1294,y:570,t:1527272204219};\\\", \\\"{x:1294,y:569,t:1527272204232};\\\", \\\"{x:1294,y:567,t:1527272204251};\\\", \\\"{x:1294,y:566,t:1527272204275};\\\", \\\"{x:1294,y:564,t:1527272204291};\\\", \\\"{x:1295,y:564,t:1527272204299};\\\", \\\"{x:1298,y:562,t:1527272204314};\\\", \\\"{x:1304,y:562,t:1527272204332};\\\", \\\"{x:1308,y:562,t:1527272204349};\\\", \\\"{x:1320,y:562,t:1527272204365};\\\", \\\"{x:1326,y:565,t:1527272204382};\\\", \\\"{x:1338,y:567,t:1527272204398};\\\", \\\"{x:1345,y:568,t:1527272204414};\\\", \\\"{x:1348,y:568,t:1527272204432};\\\", \\\"{x:1351,y:568,t:1527272204449};\\\", \\\"{x:1352,y:569,t:1527272204465};\\\", \\\"{x:1354,y:569,t:1527272204772};\\\", \\\"{x:1354,y:570,t:1527272204781};\\\", \\\"{x:1358,y:570,t:1527272204798};\\\", \\\"{x:1359,y:570,t:1527272204819};\\\", \\\"{x:1361,y:570,t:1527272204832};\\\", \\\"{x:1366,y:570,t:1527272204849};\\\", \\\"{x:1370,y:571,t:1527272204866};\\\", \\\"{x:1374,y:572,t:1527272204882};\\\", \\\"{x:1376,y:572,t:1527272204899};\\\", \\\"{x:1378,y:572,t:1527272204916};\\\", \\\"{x:1379,y:572,t:1527272204932};\\\", \\\"{x:1380,y:572,t:1527272204950};\\\", \\\"{x:1381,y:572,t:1527272204995};\\\", \\\"{x:1383,y:572,t:1527272205003};\\\", \\\"{x:1386,y:572,t:1527272205015};\\\", \\\"{x:1394,y:572,t:1527272205032};\\\", \\\"{x:1395,y:572,t:1527272205048};\\\", \\\"{x:1401,y:572,t:1527272205066};\\\", \\\"{x:1406,y:574,t:1527272205081};\\\", \\\"{x:1407,y:574,t:1527272205130};\\\", \\\"{x:1408,y:574,t:1527272205146};\\\", \\\"{x:1411,y:578,t:1527272205170};\\\", \\\"{x:1415,y:583,t:1527272205182};\\\", \\\"{x:1422,y:598,t:1527272205199};\\\", \\\"{x:1430,y:610,t:1527272205216};\\\", \\\"{x:1438,y:632,t:1527272205233};\\\", \\\"{x:1439,y:640,t:1527272205249};\\\", \\\"{x:1438,y:660,t:1527272205266};\\\", \\\"{x:1432,y:687,t:1527272205282};\\\", \\\"{x:1426,y:695,t:1527272205299};\\\", \\\"{x:1421,y:699,t:1527272205316};\\\", \\\"{x:1415,y:701,t:1527272205387};\\\", \\\"{x:1409,y:701,t:1527272205402};\\\", \\\"{x:1408,y:701,t:1527272205416};\\\", \\\"{x:1402,y:701,t:1527272205434};\\\", \\\"{x:1401,y:701,t:1527272205450};\\\", \\\"{x:1400,y:701,t:1527272205466};\\\", \\\"{x:1399,y:701,t:1527272205483};\\\", \\\"{x:1398,y:701,t:1527272205555};\\\", \\\"{x:1396,y:701,t:1527272205571};\\\", \\\"{x:1392,y:701,t:1527272205584};\\\", \\\"{x:1383,y:700,t:1527272205601};\\\", \\\"{x:1377,y:700,t:1527272205616};\\\", \\\"{x:1376,y:699,t:1527272205731};\\\", \\\"{x:1375,y:698,t:1527272205739};\\\", \\\"{x:1375,y:697,t:1527272205763};\\\", \\\"{x:1375,y:696,t:1527272205779};\\\", \\\"{x:1375,y:695,t:1527272205828};\\\", \\\"{x:1375,y:694,t:1527272205835};\\\", \\\"{x:1375,y:691,t:1527272205867};\\\", \\\"{x:1378,y:691,t:1527272205883};\\\", \\\"{x:1384,y:691,t:1527272205900};\\\", \\\"{x:1390,y:691,t:1527272205917};\\\", \\\"{x:1405,y:691,t:1527272205934};\\\", \\\"{x:1423,y:695,t:1527272205950};\\\", \\\"{x:1439,y:697,t:1527272205968};\\\", \\\"{x:1451,y:697,t:1527272205983};\\\", \\\"{x:1462,y:697,t:1527272206001};\\\", \\\"{x:1466,y:697,t:1527272206017};\\\", \\\"{x:1469,y:697,t:1527272206034};\\\", \\\"{x:1471,y:697,t:1527272206050};\\\", \\\"{x:1471,y:696,t:1527272206315};\\\", \\\"{x:1472,y:695,t:1527272206324};\\\", \\\"{x:1473,y:694,t:1527272206334};\\\", \\\"{x:1474,y:694,t:1527272206351};\\\", \\\"{x:1479,y:693,t:1527272206368};\\\", \\\"{x:1482,y:693,t:1527272206385};\\\", \\\"{x:1483,y:692,t:1527272206401};\\\", \\\"{x:1485,y:691,t:1527272206417};\\\", \\\"{x:1486,y:690,t:1527272206435};\\\", \\\"{x:1486,y:691,t:1527272206636};\\\", \\\"{x:1486,y:692,t:1527272206650};\\\", \\\"{x:1486,y:693,t:1527272206747};\\\", \\\"{x:1485,y:694,t:1527272206755};\\\", \\\"{x:1485,y:695,t:1527272206779};\\\", \\\"{x:1485,y:696,t:1527272206803};\\\", \\\"{x:1484,y:699,t:1527272206817};\\\", \\\"{x:1484,y:700,t:1527272206833};\\\", \\\"{x:1482,y:701,t:1527272206851};\\\", \\\"{x:1481,y:702,t:1527272206868};\\\", \\\"{x:1482,y:701,t:1527272207002};\\\", \\\"{x:1483,y:688,t:1527272207018};\\\", \\\"{x:1483,y:675,t:1527272207034};\\\", \\\"{x:1484,y:657,t:1527272207051};\\\", \\\"{x:1484,y:642,t:1527272207067};\\\", \\\"{x:1484,y:633,t:1527272207085};\\\", \\\"{x:1484,y:625,t:1527272207101};\\\", \\\"{x:1484,y:612,t:1527272207118};\\\", \\\"{x:1484,y:607,t:1527272207135};\\\", \\\"{x:1484,y:606,t:1527272207151};\\\", \\\"{x:1484,y:602,t:1527272207168};\\\", \\\"{x:1484,y:596,t:1527272207185};\\\", \\\"{x:1484,y:595,t:1527272207219};\\\", \\\"{x:1484,y:594,t:1527272207267};\\\", \\\"{x:1484,y:591,t:1527272207286};\\\", \\\"{x:1483,y:587,t:1527272207302};\\\", \\\"{x:1481,y:581,t:1527272207318};\\\", \\\"{x:1476,y:573,t:1527272207335};\\\", \\\"{x:1469,y:566,t:1527272207352};\\\", \\\"{x:1457,y:558,t:1527272207368};\\\", \\\"{x:1446,y:552,t:1527272207386};\\\", \\\"{x:1436,y:550,t:1527272207402};\\\", \\\"{x:1429,y:547,t:1527272207419};\\\", \\\"{x:1424,y:544,t:1527272207435};\\\", \\\"{x:1421,y:544,t:1527272207453};\\\", \\\"{x:1416,y:543,t:1527272207469};\\\", \\\"{x:1414,y:543,t:1527272207485};\\\", \\\"{x:1412,y:543,t:1527272207502};\\\", \\\"{x:1409,y:545,t:1527272207518};\\\", \\\"{x:1405,y:548,t:1527272207535};\\\", \\\"{x:1404,y:549,t:1527272207555};\\\", \\\"{x:1402,y:551,t:1527272207569};\\\", \\\"{x:1392,y:555,t:1527272207585};\\\", \\\"{x:1382,y:559,t:1527272207603};\\\", \\\"{x:1370,y:561,t:1527272207619};\\\", \\\"{x:1365,y:564,t:1527272207635};\\\", \\\"{x:1360,y:566,t:1527272207652};\\\", \\\"{x:1352,y:568,t:1527272207669};\\\", \\\"{x:1349,y:570,t:1527272207685};\\\", \\\"{x:1344,y:571,t:1527272207703};\\\", \\\"{x:1342,y:572,t:1527272207720};\\\", \\\"{x:1342,y:573,t:1527272207735};\\\", \\\"{x:1343,y:572,t:1527272207892};\\\", \\\"{x:1346,y:571,t:1527272207902};\\\", \\\"{x:1350,y:568,t:1527272207919};\\\", \\\"{x:1357,y:566,t:1527272207937};\\\", \\\"{x:1365,y:564,t:1527272207952};\\\", \\\"{x:1367,y:563,t:1527272207970};\\\", \\\"{x:1371,y:561,t:1527272207987};\\\", \\\"{x:1372,y:561,t:1527272208002};\\\", \\\"{x:1373,y:561,t:1527272208027};\\\", \\\"{x:1379,y:560,t:1527272208037};\\\", \\\"{x:1381,y:560,t:1527272208053};\\\", \\\"{x:1384,y:560,t:1527272208069};\\\", \\\"{x:1386,y:560,t:1527272208087};\\\", \\\"{x:1389,y:560,t:1527272208103};\\\", \\\"{x:1391,y:560,t:1527272208119};\\\", \\\"{x:1392,y:560,t:1527272208136};\\\", \\\"{x:1393,y:560,t:1527272208152};\\\", \\\"{x:1399,y:561,t:1527272208169};\\\", \\\"{x:1405,y:561,t:1527272208186};\\\", \\\"{x:1407,y:562,t:1527272208211};\\\", \\\"{x:1410,y:562,t:1527272208220};\\\", \\\"{x:1414,y:563,t:1527272208236};\\\", \\\"{x:1416,y:566,t:1527272208252};\\\", \\\"{x:1417,y:567,t:1527272208269};\\\", \\\"{x:1420,y:567,t:1527272208287};\\\", \\\"{x:1423,y:569,t:1527272208303};\\\", \\\"{x:1426,y:569,t:1527272208319};\\\", \\\"{x:1427,y:569,t:1527272208347};\\\", \\\"{x:1428,y:569,t:1527272208363};\\\", \\\"{x:1429,y:569,t:1527272208371};\\\", \\\"{x:1433,y:569,t:1527272208386};\\\", \\\"{x:1437,y:567,t:1527272208403};\\\", \\\"{x:1440,y:567,t:1527272208419};\\\", \\\"{x:1442,y:566,t:1527272208436};\\\", \\\"{x:1444,y:565,t:1527272208454};\\\", \\\"{x:1452,y:563,t:1527272208469};\\\", \\\"{x:1461,y:563,t:1527272208485};\\\", \\\"{x:1465,y:563,t:1527272208503};\\\", \\\"{x:1466,y:563,t:1527272208519};\\\", \\\"{x:1469,y:563,t:1527272208535};\\\", \\\"{x:1470,y:563,t:1527272208561};\\\", \\\"{x:1471,y:563,t:1527272208602};\\\", \\\"{x:1472,y:562,t:1527272208617};\\\", \\\"{x:1473,y:562,t:1527272208730};\\\", \\\"{x:1474,y:562,t:1527272208819};\\\", \\\"{x:1477,y:560,t:1527272208826};\\\", \\\"{x:1478,y:559,t:1527272208836};\\\", \\\"{x:1481,y:558,t:1527272208853};\\\", \\\"{x:1482,y:558,t:1527272208871};\\\", \\\"{x:1483,y:557,t:1527272208886};\\\", \\\"{x:1484,y:557,t:1527272209299};\\\", \\\"{x:1483,y:558,t:1527272209315};\\\", \\\"{x:1483,y:559,t:1527272209387};\\\", \\\"{x:1482,y:560,t:1527272209433};\\\", \\\"{x:1481,y:561,t:1527272209450};\\\", \\\"{x:1480,y:562,t:1527272209715};\\\", \\\"{x:1480,y:563,t:1527272209723};\\\", \\\"{x:1478,y:564,t:1527272209755};\\\", \\\"{x:1474,y:569,t:1527272212051};\\\", \\\"{x:1469,y:571,t:1527272212058};\\\", \\\"{x:1464,y:574,t:1527272212073};\\\", \\\"{x:1447,y:581,t:1527272212090};\\\", \\\"{x:1439,y:585,t:1527272212106};\\\", \\\"{x:1430,y:589,t:1527272212123};\\\", \\\"{x:1426,y:591,t:1527272212141};\\\", \\\"{x:1423,y:593,t:1527272212157};\\\", \\\"{x:1419,y:594,t:1527272212174};\\\", \\\"{x:1416,y:597,t:1527272212191};\\\", \\\"{x:1411,y:598,t:1527272212208};\\\", \\\"{x:1407,y:603,t:1527272212223};\\\", \\\"{x:1401,y:605,t:1527272212240};\\\", \\\"{x:1393,y:608,t:1527272212257};\\\", \\\"{x:1390,y:609,t:1527272212274};\\\", \\\"{x:1385,y:613,t:1527272212291};\\\", \\\"{x:1383,y:616,t:1527272212307};\\\", \\\"{x:1379,y:622,t:1527272212323};\\\", \\\"{x:1377,y:624,t:1527272212340};\\\", \\\"{x:1372,y:628,t:1527272212357};\\\", \\\"{x:1366,y:633,t:1527272212374};\\\", \\\"{x:1362,y:636,t:1527272212391};\\\", \\\"{x:1358,y:640,t:1527272212408};\\\", \\\"{x:1354,y:645,t:1527272212425};\\\", \\\"{x:1349,y:648,t:1527272212441};\\\", \\\"{x:1346,y:651,t:1527272212458};\\\", \\\"{x:1340,y:655,t:1527272212474};\\\", \\\"{x:1338,y:656,t:1527272212490};\\\", \\\"{x:1337,y:658,t:1527272212508};\\\", \\\"{x:1335,y:659,t:1527272212524};\\\", \\\"{x:1335,y:660,t:1527272212540};\\\", \\\"{x:1335,y:661,t:1527272212578};\\\", \\\"{x:1334,y:664,t:1527272212619};\\\", \\\"{x:1333,y:665,t:1527272212642};\\\", \\\"{x:1333,y:667,t:1527272212659};\\\", \\\"{x:1332,y:670,t:1527272212675};\\\", \\\"{x:1332,y:671,t:1527272212691};\\\", \\\"{x:1332,y:672,t:1527272212738};\\\", \\\"{x:1332,y:674,t:1527272212755};\\\", \\\"{x:1332,y:675,t:1527272212932};\\\", \\\"{x:1332,y:676,t:1527272212941};\\\", \\\"{x:1332,y:680,t:1527272212958};\\\", \\\"{x:1338,y:687,t:1527272212975};\\\", \\\"{x:1342,y:690,t:1527272212992};\\\", \\\"{x:1344,y:691,t:1527272213008};\\\", \\\"{x:1344,y:692,t:1527272213025};\\\", \\\"{x:1345,y:694,t:1527272213058};\\\", \\\"{x:1350,y:697,t:1527272213074};\\\", \\\"{x:1351,y:697,t:1527272213091};\\\", \\\"{x:1354,y:697,t:1527272213110};\\\", \\\"{x:1365,y:700,t:1527272213124};\\\", \\\"{x:1371,y:701,t:1527272213142};\\\", \\\"{x:1374,y:701,t:1527272213159};\\\", \\\"{x:1378,y:701,t:1527272213174};\\\", \\\"{x:1384,y:701,t:1527272213193};\\\", \\\"{x:1392,y:701,t:1527272213209};\\\", \\\"{x:1395,y:701,t:1527272213224};\\\", \\\"{x:1398,y:701,t:1527272213241};\\\", \\\"{x:1399,y:701,t:1527272213258};\\\", \\\"{x:1401,y:701,t:1527272213371};\\\", \\\"{x:1402,y:701,t:1527272213387};\\\", \\\"{x:1406,y:701,t:1527272213395};\\\", \\\"{x:1409,y:701,t:1527272213408};\\\", \\\"{x:1413,y:701,t:1527272213425};\\\", \\\"{x:1416,y:699,t:1527272213441};\\\", \\\"{x:1422,y:699,t:1527272213458};\\\", \\\"{x:1429,y:697,t:1527272213475};\\\", \\\"{x:1431,y:697,t:1527272213490};\\\", \\\"{x:1435,y:697,t:1527272213546};\\\", \\\"{x:1437,y:697,t:1527272213562};\\\", \\\"{x:1439,y:696,t:1527272213691};\\\", \\\"{x:1440,y:696,t:1527272213708};\\\", \\\"{x:1441,y:695,t:1527272213726};\\\", \\\"{x:1445,y:693,t:1527272213743};\\\", \\\"{x:1450,y:693,t:1527272213758};\\\", \\\"{x:1454,y:692,t:1527272213775};\\\", \\\"{x:1461,y:691,t:1527272213792};\\\", \\\"{x:1463,y:690,t:1527272213809};\\\", \\\"{x:1465,y:688,t:1527272213826};\\\", \\\"{x:1467,y:688,t:1527272213843};\\\", \\\"{x:1468,y:688,t:1527272213922};\\\", \\\"{x:1470,y:688,t:1527272213947};\\\", \\\"{x:1471,y:688,t:1527272213963};\\\", \\\"{x:1472,y:688,t:1527272214315};\\\", \\\"{x:1473,y:689,t:1527272214330};\\\", \\\"{x:1473,y:691,t:1527272214342};\\\", \\\"{x:1474,y:694,t:1527272214360};\\\", \\\"{x:1474,y:695,t:1527272214377};\\\", \\\"{x:1474,y:697,t:1527272214392};\\\", \\\"{x:1474,y:698,t:1527272214409};\\\", \\\"{x:1474,y:700,t:1527272214425};\\\", \\\"{x:1474,y:702,t:1527272214442};\\\", \\\"{x:1474,y:703,t:1527272214482};\\\", \\\"{x:1474,y:704,t:1527272214492};\\\", \\\"{x:1474,y:705,t:1527272214509};\\\", \\\"{x:1474,y:707,t:1527272214546};\\\", \\\"{x:1474,y:708,t:1527272214562};\\\", \\\"{x:1474,y:709,t:1527272214576};\\\", \\\"{x:1471,y:713,t:1527272214593};\\\", \\\"{x:1470,y:719,t:1527272214609};\\\", \\\"{x:1470,y:727,t:1527272214627};\\\", \\\"{x:1470,y:731,t:1527272214643};\\\", \\\"{x:1470,y:735,t:1527272214659};\\\", \\\"{x:1470,y:738,t:1527272214676};\\\", \\\"{x:1470,y:740,t:1527272214693};\\\", \\\"{x:1469,y:741,t:1527272214709};\\\", \\\"{x:1468,y:742,t:1527272215091};\\\", \\\"{x:1465,y:742,t:1527272215203};\\\", \\\"{x:1462,y:742,t:1527272215210};\\\", \\\"{x:1458,y:735,t:1527272215227};\\\", \\\"{x:1458,y:729,t:1527272215243};\\\", \\\"{x:1458,y:723,t:1527272215260};\\\", \\\"{x:1457,y:723,t:1527272215278};\\\", \\\"{x:1457,y:722,t:1527272215294};\\\", \\\"{x:1457,y:721,t:1527272215311};\\\", \\\"{x:1457,y:720,t:1527272215338};\\\", \\\"{x:1457,y:719,t:1527272215403};\\\", \\\"{x:1458,y:718,t:1527272215427};\\\", \\\"{x:1459,y:717,t:1527272215443};\\\", \\\"{x:1460,y:716,t:1527272215461};\\\", \\\"{x:1462,y:714,t:1527272215477};\\\", \\\"{x:1466,y:711,t:1527272215495};\\\", \\\"{x:1467,y:710,t:1527272215511};\\\", \\\"{x:1469,y:710,t:1527272215528};\\\", \\\"{x:1471,y:708,t:1527272215544};\\\", \\\"{x:1472,y:707,t:1527272215563};\\\", \\\"{x:1473,y:707,t:1527272215578};\\\", \\\"{x:1474,y:705,t:1527272215611};\\\", \\\"{x:1475,y:703,t:1527272215643};\\\", \\\"{x:1475,y:702,t:1527272215683};\\\", \\\"{x:1476,y:702,t:1527272215695};\\\", \\\"{x:1476,y:701,t:1527272215715};\\\", \\\"{x:1477,y:698,t:1527272215747};\\\", \\\"{x:1478,y:697,t:1527272215972};\\\", \\\"{x:1479,y:697,t:1527272215995};\\\", \\\"{x:1480,y:696,t:1527272216011};\\\", \\\"{x:1481,y:696,t:1527272216029};\\\", \\\"{x:1481,y:695,t:1527272220324};\\\", \\\"{x:1481,y:694,t:1527272220333};\\\", \\\"{x:1481,y:693,t:1527272220350};\\\", \\\"{x:1481,y:691,t:1527272220366};\\\", \\\"{x:1480,y:690,t:1527272220383};\\\", \\\"{x:1479,y:689,t:1527272220427};\\\", \\\"{x:1479,y:687,t:1527272220483};\\\", \\\"{x:1479,y:686,t:1527272220506};\\\", \\\"{x:1479,y:683,t:1527272220522};\\\", \\\"{x:1479,y:682,t:1527272220533};\\\", \\\"{x:1477,y:675,t:1527272220550};\\\", \\\"{x:1474,y:668,t:1527272220567};\\\", \\\"{x:1474,y:658,t:1527272220583};\\\", \\\"{x:1474,y:648,t:1527272220600};\\\", \\\"{x:1473,y:639,t:1527272220617};\\\", \\\"{x:1473,y:636,t:1527272220633};\\\", \\\"{x:1473,y:629,t:1527272220650};\\\", \\\"{x:1473,y:618,t:1527272220666};\\\", \\\"{x:1473,y:613,t:1527272220682};\\\", \\\"{x:1473,y:607,t:1527272220700};\\\", \\\"{x:1473,y:606,t:1527272220716};\\\", \\\"{x:1473,y:605,t:1527272220733};\\\", \\\"{x:1473,y:603,t:1527272220750};\\\", \\\"{x:1474,y:600,t:1527272220767};\\\", \\\"{x:1475,y:598,t:1527272220782};\\\", \\\"{x:1476,y:597,t:1527272220803};\\\", \\\"{x:1478,y:595,t:1527272220818};\\\", \\\"{x:1478,y:593,t:1527272220833};\\\", \\\"{x:1478,y:591,t:1527272220850};\\\", \\\"{x:1480,y:588,t:1527272220866};\\\", \\\"{x:1481,y:587,t:1527272221155};\\\", \\\"{x:1481,y:586,t:1527272221171};\\\", \\\"{x:1482,y:586,t:1527272221183};\\\", \\\"{x:1482,y:584,t:1527272221211};\\\", \\\"{x:1483,y:584,t:1527272221218};\\\", \\\"{x:1483,y:583,t:1527272221234};\\\", \\\"{x:1483,y:582,t:1527272221251};\\\", \\\"{x:1484,y:580,t:1527272221266};\\\", \\\"{x:1484,y:579,t:1527272221306};\\\", \\\"{x:1484,y:577,t:1527272221355};\\\", \\\"{x:1484,y:576,t:1527272221379};\\\", \\\"{x:1485,y:575,t:1527272221427};\\\", \\\"{x:1485,y:574,t:1527272221458};\\\", \\\"{x:1483,y:574,t:1527272223004};\\\", \\\"{x:1457,y:574,t:1527272223019};\\\", \\\"{x:1445,y:571,t:1527272223036};\\\", \\\"{x:1392,y:560,t:1527272223053};\\\", \\\"{x:1350,y:550,t:1527272223069};\\\", \\\"{x:1231,y:531,t:1527272223086};\\\", \\\"{x:1072,y:498,t:1527272223103};\\\", \\\"{x:906,y:476,t:1527272223119};\\\", \\\"{x:718,y:451,t:1527272223136};\\\", \\\"{x:547,y:429,t:1527272223154};\\\", \\\"{x:442,y:413,t:1527272223168};\\\", \\\"{x:350,y:411,t:1527272223186};\\\", \\\"{x:294,y:411,t:1527272223202};\\\", \\\"{x:287,y:411,t:1527272223219};\\\", \\\"{x:286,y:412,t:1527272223236};\\\", \\\"{x:284,y:414,t:1527272223252};\\\", \\\"{x:283,y:415,t:1527272223269};\\\", \\\"{x:280,y:418,t:1527272223286};\\\", \\\"{x:280,y:424,t:1527272223303};\\\", \\\"{x:280,y:430,t:1527272223319};\\\", \\\"{x:280,y:438,t:1527272223336};\\\", \\\"{x:284,y:446,t:1527272223353};\\\", \\\"{x:291,y:454,t:1527272223370};\\\", \\\"{x:291,y:457,t:1527272223386};\\\", \\\"{x:307,y:472,t:1527272223403};\\\", \\\"{x:318,y:480,t:1527272223419};\\\", \\\"{x:329,y:485,t:1527272223436};\\\", \\\"{x:335,y:486,t:1527272223453};\\\", \\\"{x:338,y:488,t:1527272223472};\\\", \\\"{x:339,y:489,t:1527272223485};\\\", \\\"{x:342,y:489,t:1527272223513};\\\", \\\"{x:352,y:489,t:1527272223523};\\\", \\\"{x:377,y:489,t:1527272223540};\\\", \\\"{x:399,y:487,t:1527272223556};\\\", \\\"{x:415,y:481,t:1527272223573};\\\", \\\"{x:428,y:477,t:1527272223590};\\\", \\\"{x:452,y:477,t:1527272223606};\\\", \\\"{x:474,y:477,t:1527272223623};\\\", \\\"{x:477,y:477,t:1527272223641};\\\", \\\"{x:481,y:478,t:1527272223794};\\\", \\\"{x:483,y:480,t:1527272223808};\\\", \\\"{x:494,y:485,t:1527272223824};\\\", \\\"{x:497,y:487,t:1527272223841};\\\", \\\"{x:509,y:489,t:1527272223858};\\\", \\\"{x:510,y:489,t:1527272223874};\\\", \\\"{x:517,y:489,t:1527272223890};\\\", \\\"{x:520,y:489,t:1527272223908};\\\", \\\"{x:521,y:488,t:1527272224043};\\\", \\\"{x:522,y:487,t:1527272224058};\\\", \\\"{x:526,y:485,t:1527272224075};\\\", \\\"{x:531,y:481,t:1527272224090};\\\", \\\"{x:534,y:481,t:1527272224107};\\\", \\\"{x:538,y:479,t:1527272224124};\\\", \\\"{x:542,y:479,t:1527272224141};\\\", \\\"{x:547,y:479,t:1527272224158};\\\", \\\"{x:556,y:480,t:1527272224174};\\\", \\\"{x:563,y:482,t:1527272224191};\\\", \\\"{x:569,y:483,t:1527272224208};\\\", \\\"{x:570,y:486,t:1527272224323};\\\", \\\"{x:571,y:488,t:1527272224339};\\\", \\\"{x:572,y:488,t:1527272224359};\\\", \\\"{x:575,y:492,t:1527272224375};\\\", \\\"{x:578,y:495,t:1527272224391};\\\", \\\"{x:579,y:495,t:1527272224409};\\\", \\\"{x:581,y:497,t:1527272224425};\\\", \\\"{x:594,y:498,t:1527272224441};\\\", \\\"{x:605,y:499,t:1527272224458};\\\", \\\"{x:606,y:499,t:1527272224474};\\\", \\\"{x:607,y:499,t:1527272224498};\\\", \\\"{x:608,y:499,t:1527272224507};\\\", \\\"{x:609,y:499,t:1527272224524};\\\", \\\"{x:610,y:499,t:1527272225027};\\\", \\\"{x:610,y:501,t:1527272225739};\\\", \\\"{x:614,y:507,t:1527272225746};\\\", \\\"{x:617,y:511,t:1527272225759};\\\", \\\"{x:628,y:520,t:1527272225777};\\\", \\\"{x:643,y:531,t:1527272225794};\\\", \\\"{x:656,y:538,t:1527272225809};\\\", \\\"{x:676,y:549,t:1527272225825};\\\", \\\"{x:686,y:560,t:1527272225841};\\\", \\\"{x:695,y:570,t:1527272225859};\\\", \\\"{x:714,y:583,t:1527272225875};\\\", \\\"{x:741,y:590,t:1527272225893};\\\", \\\"{x:775,y:602,t:1527272225909};\\\", \\\"{x:788,y:613,t:1527272225925};\\\", \\\"{x:840,y:637,t:1527272225943};\\\", \\\"{x:877,y:658,t:1527272225959};\\\", \\\"{x:888,y:670,t:1527272225976};\\\", \\\"{x:928,y:691,t:1527272225993};\\\", \\\"{x:934,y:700,t:1527272226008};\\\", \\\"{x:1033,y:741,t:1527272226025};\\\", \\\"{x:1054,y:760,t:1527272226043};\\\", \\\"{x:1077,y:776,t:1527272226060};\\\", \\\"{x:1112,y:787,t:1527272226076};\\\", \\\"{x:1133,y:799,t:1527272226093};\\\", \\\"{x:1143,y:807,t:1527272226109};\\\", \\\"{x:1145,y:808,t:1527272226125};\\\", \\\"{x:1146,y:808,t:1527272226179};\\\", \\\"{x:1147,y:809,t:1527272226874};\\\", \\\"{x:1149,y:809,t:1527272226882};\\\", \\\"{x:1151,y:809,t:1527272226893};\\\", \\\"{x:1165,y:807,t:1527272226909};\\\", \\\"{x:1178,y:801,t:1527272226927};\\\", \\\"{x:1194,y:796,t:1527272226944};\\\", \\\"{x:1202,y:794,t:1527272226959};\\\", \\\"{x:1213,y:787,t:1527272226977};\\\", \\\"{x:1242,y:782,t:1527272226994};\\\", \\\"{x:1248,y:779,t:1527272227010};\\\", \\\"{x:1279,y:771,t:1527272227026};\\\", \\\"{x:1296,y:766,t:1527272227044};\\\", \\\"{x:1302,y:764,t:1527272227060};\\\", \\\"{x:1311,y:764,t:1527272227077};\\\", \\\"{x:1320,y:763,t:1527272227094};\\\", \\\"{x:1323,y:762,t:1527272227110};\\\", \\\"{x:1324,y:761,t:1527272227403};\\\", \\\"{x:1325,y:761,t:1527272227411};\\\", \\\"{x:1327,y:762,t:1527272227427};\\\", \\\"{x:1329,y:764,t:1527272227445};\\\", \\\"{x:1329,y:769,t:1527272227461};\\\", \\\"{x:1330,y:772,t:1527272227477};\\\", \\\"{x:1333,y:776,t:1527272227494};\\\", \\\"{x:1334,y:781,t:1527272227511};\\\", \\\"{x:1336,y:785,t:1527272227527};\\\", \\\"{x:1336,y:790,t:1527272227544};\\\", \\\"{x:1336,y:794,t:1527272227561};\\\", \\\"{x:1335,y:796,t:1527272227577};\\\", \\\"{x:1332,y:799,t:1527272227594};\\\", \\\"{x:1330,y:801,t:1527272227610};\\\", \\\"{x:1326,y:802,t:1527272227628};\\\", \\\"{x:1315,y:803,t:1527272227644};\\\", \\\"{x:1312,y:803,t:1527272227661};\\\", \\\"{x:1308,y:802,t:1527272227678};\\\", \\\"{x:1304,y:802,t:1527272227694};\\\", \\\"{x:1296,y:797,t:1527272227710};\\\", \\\"{x:1287,y:792,t:1527272227728};\\\", \\\"{x:1276,y:788,t:1527272227744};\\\", \\\"{x:1268,y:786,t:1527272227761};\\\", \\\"{x:1261,y:782,t:1527272227779};\\\", \\\"{x:1261,y:781,t:1527272227802};\\\", \\\"{x:1260,y:780,t:1527272227825};\\\", \\\"{x:1258,y:780,t:1527272227841};\\\", \\\"{x:1257,y:780,t:1527272227849};\\\", \\\"{x:1253,y:779,t:1527272227860};\\\", \\\"{x:1244,y:778,t:1527272227878};\\\", \\\"{x:1237,y:776,t:1527272227893};\\\", \\\"{x:1232,y:776,t:1527272227910};\\\", \\\"{x:1229,y:776,t:1527272227927};\\\", \\\"{x:1228,y:775,t:1527272227946};\\\", \\\"{x:1225,y:775,t:1527272227978};\\\", \\\"{x:1220,y:774,t:1527272227994};\\\", \\\"{x:1216,y:773,t:1527272228011};\\\", \\\"{x:1215,y:773,t:1527272228028};\\\", \\\"{x:1213,y:773,t:1527272228044};\\\", \\\"{x:1212,y:773,t:1527272228107};\\\", \\\"{x:1211,y:773,t:1527272228122};\\\", \\\"{x:1209,y:773,t:1527272228130};\\\", \\\"{x:1208,y:773,t:1527272228144};\\\", \\\"{x:1207,y:773,t:1527272228162};\\\", \\\"{x:1206,y:773,t:1527272228179};\\\", \\\"{x:1205,y:773,t:1527272228195};\\\", \\\"{x:1203,y:773,t:1527272228211};\\\", \\\"{x:1202,y:773,t:1527272228283};\\\", \\\"{x:1200,y:773,t:1527272228306};\\\", \\\"{x:1200,y:772,t:1527272228331};\\\", \\\"{x:1199,y:770,t:1527272228419};\\\", \\\"{x:1198,y:770,t:1527272228428};\\\", \\\"{x:1198,y:769,t:1527272228450};\\\", \\\"{x:1197,y:769,t:1527272228474};\\\", \\\"{x:1195,y:767,t:1527272228499};\\\", \\\"{x:1194,y:766,t:1527272228514};\\\", \\\"{x:1192,y:765,t:1527272228531};\\\", \\\"{x:1190,y:765,t:1527272228547};\\\", \\\"{x:1189,y:765,t:1527272228938};\\\", \\\"{x:1188,y:765,t:1527272228963};\\\", \\\"{x:1187,y:765,t:1527272229019};\\\", \\\"{x:1188,y:768,t:1527272229029};\\\", \\\"{x:1193,y:774,t:1527272229045};\\\", \\\"{x:1201,y:780,t:1527272229062};\\\", \\\"{x:1219,y:791,t:1527272229079};\\\", \\\"{x:1234,y:800,t:1527272229095};\\\", \\\"{x:1243,y:808,t:1527272229112};\\\", \\\"{x:1246,y:814,t:1527272229129};\\\", \\\"{x:1246,y:815,t:1527272229186};\\\", \\\"{x:1246,y:816,t:1527272229195};\\\", \\\"{x:1244,y:819,t:1527272229212};\\\", \\\"{x:1241,y:825,t:1527272229229};\\\", \\\"{x:1238,y:828,t:1527272229246};\\\", \\\"{x:1232,y:833,t:1527272229262};\\\", \\\"{x:1230,y:835,t:1527272229280};\\\", \\\"{x:1226,y:838,t:1527272229296};\\\", \\\"{x:1223,y:840,t:1527272229312};\\\", \\\"{x:1221,y:843,t:1527272229329};\\\", \\\"{x:1221,y:844,t:1527272229346};\\\", \\\"{x:1221,y:846,t:1527272229379};\\\", \\\"{x:1221,y:849,t:1527272229396};\\\", \\\"{x:1229,y:855,t:1527272229412};\\\", \\\"{x:1252,y:863,t:1527272229429};\\\", \\\"{x:1254,y:870,t:1527272229446};\\\", \\\"{x:1263,y:877,t:1527272229463};\\\", \\\"{x:1270,y:878,t:1527272229479};\\\", \\\"{x:1282,y:884,t:1527272229496};\\\", \\\"{x:1291,y:889,t:1527272229512};\\\", \\\"{x:1296,y:892,t:1527272229529};\\\", \\\"{x:1298,y:893,t:1527272229546};\\\", \\\"{x:1299,y:894,t:1527272229707};\\\", \\\"{x:1302,y:897,t:1527272229714};\\\", \\\"{x:1313,y:898,t:1527272229729};\\\", \\\"{x:1320,y:899,t:1527272229746};\\\", \\\"{x:1334,y:899,t:1527272229763};\\\", \\\"{x:1345,y:899,t:1527272229779};\\\", \\\"{x:1353,y:899,t:1527272229797};\\\", \\\"{x:1356,y:899,t:1527272229814};\\\", \\\"{x:1357,y:899,t:1527272229850};\\\", \\\"{x:1359,y:899,t:1527272229875};\\\", \\\"{x:1359,y:898,t:1527272229891};\\\", \\\"{x:1359,y:897,t:1527272229898};\\\", \\\"{x:1360,y:897,t:1527272229913};\\\", \\\"{x:1361,y:896,t:1527272229930};\\\", \\\"{x:1362,y:894,t:1527272229947};\\\", \\\"{x:1364,y:893,t:1527272229963};\\\", \\\"{x:1366,y:891,t:1527272229979};\\\", \\\"{x:1368,y:891,t:1527272230010};\\\", \\\"{x:1369,y:890,t:1527272230025};\\\", \\\"{x:1371,y:890,t:1527272230177};\\\", \\\"{x:1373,y:890,t:1527272230193};\\\", \\\"{x:1375,y:892,t:1527272230209};\\\", \\\"{x:1376,y:893,t:1527272230218};\\\", \\\"{x:1378,y:895,t:1527272230230};\\\", \\\"{x:1380,y:896,t:1527272230246};\\\", \\\"{x:1383,y:898,t:1527272230262};\\\", \\\"{x:1385,y:898,t:1527272230282};\\\", \\\"{x:1387,y:899,t:1527272230296};\\\", \\\"{x:1388,y:899,t:1527272230330};\\\", \\\"{x:1389,y:899,t:1527272230395};\\\", \\\"{x:1390,y:899,t:1527272230515};\\\", \\\"{x:1392,y:899,t:1527272230867};\\\", \\\"{x:1393,y:899,t:1527272230882};\\\", \\\"{x:1397,y:899,t:1527272230897};\\\", \\\"{x:1411,y:896,t:1527272230915};\\\", \\\"{x:1412,y:896,t:1527272230954};\\\", \\\"{x:1413,y:896,t:1527272230964};\\\", \\\"{x:1415,y:894,t:1527272230981};\\\", \\\"{x:1416,y:894,t:1527272231379};\\\", \\\"{x:1417,y:894,t:1527272231386};\\\", \\\"{x:1419,y:894,t:1527272231398};\\\", \\\"{x:1424,y:893,t:1527272231414};\\\", \\\"{x:1427,y:893,t:1527272231431};\\\", \\\"{x:1431,y:893,t:1527272231447};\\\", \\\"{x:1434,y:892,t:1527272231465};\\\", \\\"{x:1438,y:891,t:1527272231481};\\\", \\\"{x:1442,y:891,t:1527272231497};\\\", \\\"{x:1450,y:891,t:1527272231514};\\\", \\\"{x:1462,y:891,t:1527272231531};\\\", \\\"{x:1469,y:891,t:1527272231547};\\\", \\\"{x:1475,y:891,t:1527272231564};\\\", \\\"{x:1477,y:891,t:1527272231586};\\\", \\\"{x:1477,y:892,t:1527272232698};\\\", \\\"{x:1476,y:892,t:1527272232745};\\\", \\\"{x:1474,y:893,t:1527272233113};\\\", \\\"{x:1471,y:893,t:1527272233121};\\\", \\\"{x:1464,y:893,t:1527272233137};\\\", \\\"{x:1456,y:893,t:1527272233148};\\\", \\\"{x:1443,y:893,t:1527272233165};\\\", \\\"{x:1432,y:893,t:1527272233181};\\\", \\\"{x:1430,y:893,t:1527272233198};\\\", \\\"{x:1429,y:893,t:1527272233214};\\\", \\\"{x:1429,y:894,t:1527272233379};\\\", \\\"{x:1429,y:896,t:1527272233394};\\\", \\\"{x:1429,y:897,t:1527272233402};\\\", \\\"{x:1429,y:898,t:1527272233426};\\\", \\\"{x:1430,y:898,t:1527272233499};\\\", \\\"{x:1431,y:898,t:1527272233517};\\\", \\\"{x:1434,y:898,t:1527272233532};\\\", \\\"{x:1435,y:898,t:1527272233562};\\\", \\\"{x:1436,y:898,t:1527272233610};\\\", \\\"{x:1437,y:898,t:1527272233667};\\\", \\\"{x:1438,y:898,t:1527272233682};\\\", \\\"{x:1439,y:898,t:1527272233851};\\\", \\\"{x:1440,y:898,t:1527272235355};\\\", \\\"{x:1436,y:892,t:1527272235426};\\\", \\\"{x:1434,y:885,t:1527272235434};\\\", \\\"{x:1427,y:869,t:1527272235451};\\\", \\\"{x:1420,y:856,t:1527272235467};\\\", \\\"{x:1417,y:843,t:1527272235485};\\\", \\\"{x:1405,y:827,t:1527272235502};\\\", \\\"{x:1390,y:812,t:1527272235518};\\\", \\\"{x:1380,y:802,t:1527272235534};\\\", \\\"{x:1378,y:798,t:1527272235552};\\\", \\\"{x:1373,y:793,t:1527272235568};\\\", \\\"{x:1373,y:791,t:1527272235584};\\\", \\\"{x:1373,y:790,t:1527272235962};\\\", \\\"{x:1373,y:787,t:1527272235971};\\\", \\\"{x:1373,y:782,t:1527272235984};\\\", \\\"{x:1375,y:776,t:1527272236002};\\\", \\\"{x:1379,y:766,t:1527272236018};\\\", \\\"{x:1380,y:762,t:1527272236035};\\\", \\\"{x:1384,y:756,t:1527272236051};\\\", \\\"{x:1387,y:751,t:1527272236068};\\\", \\\"{x:1389,y:747,t:1527272236084};\\\", \\\"{x:1394,y:731,t:1527272236102};\\\", \\\"{x:1400,y:692,t:1527272236119};\\\", \\\"{x:1406,y:665,t:1527272236134};\\\", \\\"{x:1406,y:659,t:1527272236151};\\\", \\\"{x:1408,y:654,t:1527272236168};\\\", \\\"{x:1409,y:647,t:1527272236184};\\\", \\\"{x:1412,y:642,t:1527272236202};\\\", \\\"{x:1413,y:628,t:1527272236219};\\\", \\\"{x:1414,y:618,t:1527272236235};\\\", \\\"{x:1414,y:611,t:1527272236251};\\\", \\\"{x:1416,y:606,t:1527272236269};\\\", \\\"{x:1416,y:604,t:1527272236286};\\\", \\\"{x:1416,y:603,t:1527272236301};\\\", \\\"{x:1416,y:602,t:1527272236319};\\\", \\\"{x:1416,y:601,t:1527272236379};\\\", \\\"{x:1414,y:602,t:1527272236395};\\\", \\\"{x:1413,y:602,t:1527272236402};\\\", \\\"{x:1411,y:602,t:1527272236427};\\\", \\\"{x:1410,y:605,t:1527272236435};\\\", \\\"{x:1408,y:609,t:1527272236452};\\\", \\\"{x:1408,y:617,t:1527272236469};\\\", \\\"{x:1408,y:630,t:1527272236486};\\\", \\\"{x:1415,y:638,t:1527272236502};\\\", \\\"{x:1421,y:646,t:1527272236518};\\\", \\\"{x:1422,y:649,t:1527272236535};\\\", \\\"{x:1422,y:651,t:1527272236552};\\\", \\\"{x:1423,y:651,t:1527272236635};\\\", \\\"{x:1424,y:651,t:1527272236659};\\\", \\\"{x:1425,y:651,t:1527272236668};\\\", \\\"{x:1426,y:651,t:1527272236685};\\\", \\\"{x:1427,y:651,t:1527272236703};\\\", \\\"{x:1428,y:651,t:1527272236738};\\\", \\\"{x:1427,y:651,t:1527272236817};\\\", \\\"{x:1413,y:654,t:1527272236835};\\\", \\\"{x:1397,y:660,t:1527272236852};\\\", \\\"{x:1388,y:663,t:1527272236868};\\\", \\\"{x:1388,y:664,t:1527272236885};\\\", \\\"{x:1388,y:665,t:1527272236905};\\\", \\\"{x:1386,y:667,t:1527272236918};\\\", \\\"{x:1380,y:670,t:1527272236935};\\\", \\\"{x:1373,y:673,t:1527272236951};\\\", \\\"{x:1362,y:680,t:1527272236968};\\\", \\\"{x:1344,y:688,t:1527272236985};\\\", \\\"{x:1310,y:708,t:1527272237001};\\\", \\\"{x:1267,y:721,t:1527272237018};\\\", \\\"{x:1259,y:721,t:1527272237035};\\\", \\\"{x:1247,y:721,t:1527272237052};\\\", \\\"{x:1202,y:721,t:1527272237069};\\\", \\\"{x:1127,y:721,t:1527272237085};\\\", \\\"{x:1037,y:716,t:1527272237102};\\\", \\\"{x:1021,y:710,t:1527272237119};\\\", \\\"{x:1009,y:710,t:1527272237135};\\\", \\\"{x:997,y:711,t:1527272237153};\\\", \\\"{x:991,y:711,t:1527272237169};\\\", \\\"{x:988,y:714,t:1527272237185};\\\", \\\"{x:986,y:715,t:1527272237235};\\\", \\\"{x:980,y:720,t:1527272237253};\\\", \\\"{x:975,y:726,t:1527272237270};\\\", \\\"{x:966,y:733,t:1527272237285};\\\", \\\"{x:959,y:739,t:1527272237302};\\\", \\\"{x:957,y:742,t:1527272237320};\\\", \\\"{x:954,y:745,t:1527272237335};\\\", \\\"{x:949,y:749,t:1527272237353};\\\", \\\"{x:943,y:754,t:1527272237369};\\\", \\\"{x:933,y:762,t:1527272237386};\\\", \\\"{x:908,y:776,t:1527272237402};\\\", \\\"{x:883,y:782,t:1527272237419};\\\", \\\"{x:863,y:790,t:1527272237437};\\\", \\\"{x:850,y:792,t:1527272237452};\\\", \\\"{x:841,y:792,t:1527272237469};\\\", \\\"{x:829,y:792,t:1527272237486};\\\", \\\"{x:807,y:792,t:1527272237502};\\\", \\\"{x:792,y:792,t:1527272237520};\\\", \\\"{x:780,y:792,t:1527272237536};\\\", \\\"{x:768,y:792,t:1527272237552};\\\", \\\"{x:765,y:792,t:1527272237569};\\\", \\\"{x:764,y:792,t:1527272237586};\\\", \\\"{x:763,y:792,t:1527272237602};\\\", \\\"{x:758,y:792,t:1527272237620};\\\", \\\"{x:752,y:792,t:1527272237636};\\\", \\\"{x:752,y:791,t:1527272240866};\\\", \\\"{x:768,y:791,t:1527272240874};\\\", \\\"{x:815,y:791,t:1527272240889};\\\", \\\"{x:849,y:791,t:1527272240905};\\\", \\\"{x:851,y:792,t:1527272240922};\\\", \\\"{x:850,y:793,t:1527272240938};\\\", \\\"{x:843,y:793,t:1527272240955};\\\", \\\"{x:830,y:792,t:1527272240972};\\\", \\\"{x:824,y:790,t:1527272240988};\\\", \\\"{x:817,y:790,t:1527272241005};\\\", \\\"{x:810,y:788,t:1527272241022};\\\", \\\"{x:795,y:787,t:1527272241038};\\\", \\\"{x:770,y:785,t:1527272241054};\\\", \\\"{x:753,y:784,t:1527272241072};\\\", \\\"{x:738,y:784,t:1527272241089};\\\", \\\"{x:735,y:784,t:1527272241105};\\\", \\\"{x:727,y:784,t:1527272241122};\\\", \\\"{x:719,y:784,t:1527272241139};\\\", \\\"{x:702,y:784,t:1527272241155};\\\", \\\"{x:686,y:781,t:1527272241172};\\\", \\\"{x:670,y:780,t:1527272241190};\\\", \\\"{x:662,y:778,t:1527272241206};\\\", \\\"{x:654,y:775,t:1527272241223};\\\", \\\"{x:632,y:775,t:1527272241239};\\\", \\\"{x:629,y:775,t:1527272241255};\\\", \\\"{x:602,y:771,t:1527272241272};\\\", \\\"{x:589,y:772,t:1527272241289};\\\", \\\"{x:582,y:772,t:1527272241306};\\\", \\\"{x:579,y:772,t:1527272241322};\\\", \\\"{x:578,y:772,t:1527272241346};\\\", \\\"{x:577,y:772,t:1527272241356};\\\", \\\"{x:576,y:772,t:1527272241373};\\\", \\\"{x:570,y:770,t:1527272241391};\\\", \\\"{x:563,y:765,t:1527272241406};\\\", \\\"{x:546,y:758,t:1527272241423};\\\", \\\"{x:537,y:753,t:1527272241441};\\\", \\\"{x:534,y:753,t:1527272241456};\\\", \\\"{x:533,y:752,t:1527272241471};\\\", \\\"{x:533,y:751,t:1527272241529};\\\", \\\"{x:531,y:749,t:1527272241538};\\\", \\\"{x:530,y:747,t:1527272241555};\\\", \\\"{x:528,y:743,t:1527272241571};\\\", \\\"{x:527,y:741,t:1527272241588};\\\", \\\"{x:526,y:739,t:1527272241605};\\\", \\\"{x:525,y:736,t:1527272241622};\\\", \\\"{x:525,y:734,t:1527272241641};\\\", \\\"{x:525,y:733,t:1527272241753};\\\", \\\"{x:525,y:733,t:1527272241812};\\\", \\\"{x:523,y:733,t:1527272242189};\\\", \\\"{x:522,y:733,t:1527272242213};\\\", \\\"{x:521,y:733,t:1527272242225};\\\", \\\"{x:520,y:733,t:1527272242269};\\\", \\\"{x:519,y:733,t:1527272242614};\\\", \\\"{x:517,y:733,t:1527272242625};\\\", \\\"{x:515,y:733,t:1527272242642};\\\", \\\"{x:512,y:732,t:1527272242659};\\\", \\\"{x:511,y:731,t:1527272242675};\\\", \\\"{x:509,y:729,t:1527272242692};\\\", \\\"{x:504,y:727,t:1527272242709};\\\", \\\"{x:501,y:726,t:1527272242725};\\\", \\\"{x:500,y:726,t:1527272242852};\\\", \\\"{x:498,y:726,t:1527272242860};\\\", \\\"{x:496,y:725,t:1527272242875};\\\", \\\"{x:494,y:725,t:1527272242892};\\\", \\\"{x:490,y:723,t:1527272242909};\\\", \\\"{x:488,y:722,t:1527272242925};\\\", \\\"{x:487,y:722,t:1527272242956};\\\", \\\"{x:486,y:721,t:1527272242988};\\\", \\\"{x:484,y:719,t:1527272243149};\\\", \\\"{x:481,y:719,t:1527272243159};\\\" ] }, { \\\"rt\\\": 12725, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 673381, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:447,y:714,t:1527272243330};\\\", \\\"{x:446,y:714,t:1527272245693};\\\", \\\"{x:438,y:713,t:1527272245712};\\\", \\\"{x:437,y:713,t:1527272245729};\\\", \\\"{x:435,y:713,t:1527272246230};\\\", \\\"{x:434,y:713,t:1527272246301};\\\", \\\"{x:433,y:713,t:1527272246312};\\\", \\\"{x:431,y:713,t:1527272246358};\\\", \\\"{x:430,y:713,t:1527272246365};\\\", \\\"{x:429,y:713,t:1527272246389};\\\", \\\"{x:428,y:713,t:1527272246397};\\\", \\\"{x:427,y:713,t:1527272246414};\\\", \\\"{x:426,y:713,t:1527272246428};\\\", \\\"{x:424,y:713,t:1527272246445};\\\", \\\"{x:422,y:713,t:1527272246462};\\\", \\\"{x:420,y:713,t:1527272249029};\\\", \\\"{x:419,y:713,t:1527272249085};\\\", \\\"{x:418,y:715,t:1527272249096};\\\", \\\"{x:417,y:715,t:1527272249114};\\\", \\\"{x:414,y:715,t:1527272249130};\\\", \\\"{x:411,y:715,t:1527272249147};\\\", \\\"{x:404,y:715,t:1527272249164};\\\", \\\"{x:369,y:715,t:1527272249181};\\\", \\\"{x:368,y:715,t:1527272249198};\\\", \\\"{x:350,y:712,t:1527272249214};\\\", \\\"{x:329,y:709,t:1527272249231};\\\", \\\"{x:312,y:703,t:1527272249248};\\\", \\\"{x:296,y:695,t:1527272249264};\\\", \\\"{x:289,y:688,t:1527272249280};\\\", \\\"{x:284,y:687,t:1527272249299};\\\", \\\"{x:283,y:685,t:1527272249314};\\\", \\\"{x:281,y:684,t:1527272249331};\\\", \\\"{x:280,y:683,t:1527272249348};\\\", \\\"{x:279,y:682,t:1527272249933};\\\", \\\"{x:283,y:678,t:1527272249947};\\\", \\\"{x:302,y:669,t:1527272249966};\\\", \\\"{x:306,y:664,t:1527272249980};\\\", \\\"{x:314,y:662,t:1527272249998};\\\", \\\"{x:317,y:660,t:1527272250014};\\\", \\\"{x:325,y:659,t:1527272250031};\\\", \\\"{x:336,y:659,t:1527272250048};\\\", \\\"{x:355,y:664,t:1527272250064};\\\", \\\"{x:367,y:671,t:1527272250082};\\\", \\\"{x:376,y:676,t:1527272250099};\\\", \\\"{x:386,y:684,t:1527272250114};\\\", \\\"{x:394,y:686,t:1527272250131};\\\", \\\"{x:405,y:694,t:1527272250148};\\\", \\\"{x:408,y:697,t:1527272250164};\\\", \\\"{x:410,y:704,t:1527272250181};\\\", \\\"{x:413,y:711,t:1527272250199};\\\", \\\"{x:422,y:724,t:1527272250215};\\\", \\\"{x:431,y:731,t:1527272250232};\\\", \\\"{x:433,y:734,t:1527272250249};\\\", \\\"{x:438,y:737,t:1527272250265};\\\", \\\"{x:439,y:737,t:1527272250282};\\\", \\\"{x:440,y:737,t:1527272250299};\\\", \\\"{x:441,y:737,t:1527272250374};\\\", \\\"{x:442,y:737,t:1527272250382};\\\", \\\"{x:443,y:737,t:1527272250405};\\\", \\\"{x:444,y:737,t:1527272250447};\\\", \\\"{x:446,y:736,t:1527272250476};\\\", \\\"{x:448,y:735,t:1527272250484};\\\", \\\"{x:449,y:735,t:1527272250500};\\\", \\\"{x:450,y:734,t:1527272250532};\\\", \\\"{x:453,y:733,t:1527272250837};\\\", \\\"{x:459,y:726,t:1527272250849};\\\", \\\"{x:473,y:712,t:1527272250867};\\\", \\\"{x:482,y:699,t:1527272250882};\\\", \\\"{x:487,y:670,t:1527272250899};\\\", \\\"{x:493,y:651,t:1527272250915};\\\", \\\"{x:498,y:635,t:1527272250932};\\\", \\\"{x:512,y:602,t:1527272250949};\\\", \\\"{x:520,y:588,t:1527272250966};\\\", \\\"{x:530,y:574,t:1527272250982};\\\", \\\"{x:544,y:559,t:1527272250999};\\\", \\\"{x:566,y:543,t:1527272251016};\\\", \\\"{x:581,y:531,t:1527272251033};\\\", \\\"{x:589,y:525,t:1527272251049};\\\", \\\"{x:595,y:521,t:1527272251066};\\\", \\\"{x:601,y:518,t:1527272251083};\\\", \\\"{x:605,y:515,t:1527272251099};\\\", \\\"{x:607,y:514,t:1527272251116};\\\", \\\"{x:610,y:513,t:1527272251133};\\\", \\\"{x:611,y:511,t:1527272251148};\\\", \\\"{x:615,y:511,t:1527272251165};\\\", \\\"{x:618,y:511,t:1527272251183};\\\", \\\"{x:617,y:511,t:1527272251270};\\\", \\\"{x:616,y:512,t:1527272251283};\\\", \\\"{x:611,y:513,t:1527272251300};\\\", \\\"{x:606,y:517,t:1527272251316};\\\", \\\"{x:598,y:523,t:1527272251332};\\\", \\\"{x:583,y:531,t:1527272251350};\\\", \\\"{x:562,y:541,t:1527272251366};\\\", \\\"{x:522,y:560,t:1527272251382};\\\", \\\"{x:470,y:572,t:1527272251400};\\\", \\\"{x:415,y:587,t:1527272251415};\\\", \\\"{x:339,y:600,t:1527272251433};\\\", \\\"{x:272,y:601,t:1527272251449};\\\", \\\"{x:218,y:603,t:1527272251466};\\\", \\\"{x:196,y:602,t:1527272251482};\\\", \\\"{x:189,y:604,t:1527272251500};\\\", \\\"{x:188,y:604,t:1527272251515};\\\", \\\"{x:189,y:603,t:1527272251710};\\\", \\\"{x:190,y:602,t:1527272251716};\\\", \\\"{x:191,y:601,t:1527272251732};\\\", \\\"{x:193,y:598,t:1527272251750};\\\", \\\"{x:193,y:597,t:1527272251767};\\\", \\\"{x:194,y:596,t:1527272251783};\\\", \\\"{x:194,y:593,t:1527272251801};\\\", \\\"{x:194,y:592,t:1527272251817};\\\", \\\"{x:194,y:590,t:1527272251833};\\\", \\\"{x:194,y:588,t:1527272251849};\\\", \\\"{x:194,y:587,t:1527272251867};\\\", \\\"{x:190,y:582,t:1527272251883};\\\", \\\"{x:186,y:579,t:1527272251899};\\\", \\\"{x:181,y:574,t:1527272251916};\\\", \\\"{x:177,y:571,t:1527272251932};\\\", \\\"{x:171,y:565,t:1527272251949};\\\", \\\"{x:167,y:557,t:1527272251967};\\\", \\\"{x:165,y:554,t:1527272251989};\\\", \\\"{x:162,y:553,t:1527272251999};\\\", \\\"{x:161,y:552,t:1527272252017};\\\", \\\"{x:161,y:551,t:1527272252033};\\\", \\\"{x:161,y:550,t:1527272252076};\\\", \\\"{x:161,y:549,t:1527272252141};\\\", \\\"{x:161,y:548,t:1527272252404};\\\", \\\"{x:161,y:547,t:1527272252429};\\\", \\\"{x:163,y:547,t:1527272252437};\\\", \\\"{x:166,y:547,t:1527272252449};\\\", \\\"{x:177,y:548,t:1527272252467};\\\", \\\"{x:189,y:553,t:1527272252483};\\\", \\\"{x:207,y:557,t:1527272252500};\\\", \\\"{x:244,y:560,t:1527272252517};\\\", \\\"{x:299,y:564,t:1527272252534};\\\", \\\"{x:352,y:571,t:1527272252549};\\\", \\\"{x:374,y:573,t:1527272252566};\\\", \\\"{x:393,y:574,t:1527272252584};\\\", \\\"{x:405,y:574,t:1527272252600};\\\", \\\"{x:410,y:576,t:1527272252616};\\\", \\\"{x:413,y:575,t:1527272252845};\\\", \\\"{x:418,y:575,t:1527272252854};\\\", \\\"{x:428,y:575,t:1527272252867};\\\", \\\"{x:459,y:575,t:1527272252884};\\\", \\\"{x:564,y:575,t:1527272252900};\\\", \\\"{x:650,y:575,t:1527272252917};\\\", \\\"{x:742,y:575,t:1527272252934};\\\", \\\"{x:825,y:575,t:1527272252951};\\\", \\\"{x:867,y:575,t:1527272252968};\\\", \\\"{x:882,y:575,t:1527272252983};\\\", \\\"{x:885,y:575,t:1527272253001};\\\", \\\"{x:885,y:576,t:1527272253173};\\\", \\\"{x:884,y:576,t:1527272253184};\\\", \\\"{x:880,y:576,t:1527272253201};\\\", \\\"{x:875,y:576,t:1527272253218};\\\", \\\"{x:870,y:577,t:1527272253234};\\\", \\\"{x:865,y:577,t:1527272253252};\\\", \\\"{x:856,y:578,t:1527272253268};\\\", \\\"{x:840,y:578,t:1527272253284};\\\", \\\"{x:806,y:578,t:1527272253301};\\\", \\\"{x:784,y:576,t:1527272253317};\\\", \\\"{x:777,y:576,t:1527272253334};\\\", \\\"{x:776,y:575,t:1527272253351};\\\", \\\"{x:776,y:573,t:1527272253373};\\\", \\\"{x:777,y:570,t:1527272253383};\\\", \\\"{x:787,y:563,t:1527272253401};\\\", \\\"{x:799,y:553,t:1527272253419};\\\", \\\"{x:807,y:544,t:1527272253434};\\\", \\\"{x:814,y:534,t:1527272253450};\\\", \\\"{x:820,y:527,t:1527272253467};\\\", \\\"{x:829,y:520,t:1527272253485};\\\", \\\"{x:831,y:517,t:1527272253501};\\\", \\\"{x:832,y:516,t:1527272253517};\\\", \\\"{x:833,y:515,t:1527272253612};\\\", \\\"{x:833,y:513,t:1527272253629};\\\", \\\"{x:833,y:514,t:1527272254255};\\\", \\\"{x:832,y:514,t:1527272254268};\\\", \\\"{x:830,y:514,t:1527272254284};\\\", \\\"{x:829,y:515,t:1527272254302};\\\", \\\"{x:826,y:517,t:1527272254348};\\\", \\\"{x:822,y:521,t:1527272254357};\\\", \\\"{x:818,y:523,t:1527272254368};\\\", \\\"{x:810,y:530,t:1527272254385};\\\", \\\"{x:796,y:542,t:1527272254402};\\\", \\\"{x:772,y:560,t:1527272254419};\\\", \\\"{x:750,y:574,t:1527272254435};\\\", \\\"{x:725,y:589,t:1527272254451};\\\", \\\"{x:689,y:613,t:1527272254469};\\\", \\\"{x:668,y:627,t:1527272254484};\\\", \\\"{x:657,y:636,t:1527272254503};\\\", \\\"{x:649,y:642,t:1527272254518};\\\", \\\"{x:642,y:646,t:1527272254535};\\\", \\\"{x:638,y:650,t:1527272254551};\\\", \\\"{x:630,y:658,t:1527272254569};\\\", \\\"{x:624,y:665,t:1527272254586};\\\", \\\"{x:618,y:673,t:1527272254602};\\\", \\\"{x:612,y:682,t:1527272254619};\\\", \\\"{x:608,y:689,t:1527272254637};\\\", \\\"{x:604,y:695,t:1527272254653};\\\", \\\"{x:598,y:715,t:1527272254669};\\\", \\\"{x:596,y:730,t:1527272254685};\\\", \\\"{x:594,y:740,t:1527272254703};\\\", \\\"{x:591,y:749,t:1527272254720};\\\", \\\"{x:587,y:754,t:1527272254736};\\\", \\\"{x:582,y:769,t:1527272254752};\\\", \\\"{x:579,y:772,t:1527272254769};\\\", \\\"{x:571,y:783,t:1527272254786};\\\", \\\"{x:570,y:788,t:1527272254802};\\\", \\\"{x:569,y:791,t:1527272254819};\\\", \\\"{x:568,y:794,t:1527272254837};\\\", \\\"{x:566,y:796,t:1527272254853};\\\", \\\"{x:566,y:799,t:1527272255005};\\\", \\\"{x:563,y:805,t:1527272255019};\\\", \\\"{x:557,y:812,t:1527272255036};\\\", \\\"{x:545,y:828,t:1527272255053};\\\", \\\"{x:539,y:834,t:1527272255070};\\\", \\\"{x:536,y:839,t:1527272255087};\\\", \\\"{x:532,y:843,t:1527272255103};\\\", \\\"{x:531,y:843,t:1527272255120};\\\", \\\"{x:530,y:844,t:1527272255137};\\\", \\\"{x:529,y:844,t:1527272255349};\\\", \\\"{x:527,y:844,t:1527272255357};\\\", \\\"{x:527,y:841,t:1527272255370};\\\", \\\"{x:525,y:832,t:1527272255387};\\\", \\\"{x:524,y:817,t:1527272255403};\\\", \\\"{x:522,y:811,t:1527272255420};\\\", \\\"{x:521,y:806,t:1527272255437};\\\", \\\"{x:521,y:805,t:1527272255461};\\\", \\\"{x:521,y:803,t:1527272255485};\\\", \\\"{x:522,y:803,t:1527272255509};\\\", \\\"{x:522,y:802,t:1527272255525};\\\", \\\"{x:523,y:802,t:1527272255537};\\\", \\\"{x:524,y:801,t:1527272255554};\\\", \\\"{x:525,y:801,t:1527272255571};\\\", \\\"{x:526,y:801,t:1527272255588};\\\", \\\"{x:528,y:799,t:1527272255604};\\\", \\\"{x:531,y:795,t:1527272255620};\\\", \\\"{x:532,y:789,t:1527272255637};\\\", \\\"{x:535,y:784,t:1527272255654};\\\", \\\"{x:536,y:777,t:1527272255671};\\\", \\\"{x:539,y:770,t:1527272255687};\\\", \\\"{x:540,y:764,t:1527272255704};\\\", \\\"{x:541,y:760,t:1527272255721};\\\", \\\"{x:541,y:757,t:1527272255737};\\\", \\\"{x:541,y:755,t:1527272255755};\\\", \\\"{x:542,y:753,t:1527272255773};\\\", \\\"{x:542,y:750,t:1527272255787};\\\", \\\"{x:543,y:747,t:1527272255803};\\\", \\\"{x:543,y:744,t:1527272255820};\\\", \\\"{x:543,y:743,t:1527272255836};\\\", \\\"{x:543,y:741,t:1527272255852};\\\" ] }, { \\\"rt\\\": 9179, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 683789, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:543,y:740,t:1527272257516};\\\", \\\"{x:542,y:740,t:1527272258012};\\\", \\\"{x:539,y:740,t:1527272258060};\\\", \\\"{x:536,y:740,t:1527272258071};\\\", \\\"{x:534,y:740,t:1527272258088};\\\", \\\"{x:532,y:740,t:1527272258105};\\\", \\\"{x:530,y:740,t:1527272258121};\\\", \\\"{x:529,y:741,t:1527272258138};\\\", \\\"{x:526,y:741,t:1527272258749};\\\", \\\"{x:523,y:742,t:1527272258757};\\\", \\\"{x:522,y:742,t:1527272258772};\\\", \\\"{x:519,y:742,t:1527272258789};\\\", \\\"{x:513,y:745,t:1527272258805};\\\", \\\"{x:511,y:745,t:1527272258822};\\\", \\\"{x:510,y:745,t:1527272258844};\\\", \\\"{x:509,y:745,t:1527272258855};\\\", \\\"{x:507,y:745,t:1527272258872};\\\", \\\"{x:507,y:746,t:1527272259509};\\\", \\\"{x:505,y:747,t:1527272259525};\\\", \\\"{x:503,y:748,t:1527272259540};\\\", \\\"{x:502,y:748,t:1527272259557};\\\", \\\"{x:501,y:749,t:1527272259573};\\\", \\\"{x:500,y:749,t:1527272259589};\\\", \\\"{x:499,y:751,t:1527272259607};\\\", \\\"{x:499,y:750,t:1527272259726};\\\", \\\"{x:500,y:748,t:1527272259740};\\\", \\\"{x:500,y:747,t:1527272259821};\\\", \\\"{x:505,y:744,t:1527272262589};\\\", \\\"{x:526,y:744,t:1527272262597};\\\", \\\"{x:538,y:744,t:1527272262608};\\\", \\\"{x:545,y:743,t:1527272262624};\\\", \\\"{x:544,y:743,t:1527272262669};\\\", \\\"{x:501,y:741,t:1527272262677};\\\", \\\"{x:427,y:731,t:1527272262693};\\\", \\\"{x:120,y:694,t:1527272262708};\\\", \\\"{x:0,y:653,t:1527272262724};\\\", \\\"{x:0,y:638,t:1527272262741};\\\", \\\"{x:0,y:636,t:1527272262758};\\\", \\\"{x:0,y:617,t:1527272262775};\\\", \\\"{x:0,y:622,t:1527272262792};\\\", \\\"{x:0,y:625,t:1527272262808};\\\", \\\"{x:11,y:620,t:1527272262844};\\\", \\\"{x:30,y:619,t:1527272262858};\\\", \\\"{x:127,y:622,t:1527272262876};\\\", \\\"{x:296,y:634,t:1527272262893};\\\", \\\"{x:378,y:633,t:1527272262908};\\\", \\\"{x:433,y:633,t:1527272262925};\\\", \\\"{x:475,y:633,t:1527272262942};\\\", \\\"{x:491,y:627,t:1527272262960};\\\", \\\"{x:502,y:621,t:1527272262976};\\\", \\\"{x:512,y:617,t:1527272262992};\\\", \\\"{x:515,y:614,t:1527272263009};\\\", \\\"{x:520,y:606,t:1527272263025};\\\", \\\"{x:539,y:577,t:1527272263043};\\\", \\\"{x:562,y:527,t:1527272263059};\\\", \\\"{x:580,y:490,t:1527272263075};\\\", \\\"{x:593,y:465,t:1527272263093};\\\", \\\"{x:598,y:450,t:1527272263109};\\\", \\\"{x:601,y:447,t:1527272263125};\\\", \\\"{x:602,y:446,t:1527272263142};\\\", \\\"{x:602,y:445,t:1527272263159};\\\", \\\"{x:602,y:444,t:1527272263204};\\\", \\\"{x:602,y:440,t:1527272263212};\\\", \\\"{x:594,y:435,t:1527272263225};\\\", \\\"{x:582,y:430,t:1527272263242};\\\", \\\"{x:569,y:430,t:1527272263260};\\\", \\\"{x:555,y:430,t:1527272263276};\\\", \\\"{x:532,y:441,t:1527272263293};\\\", \\\"{x:510,y:452,t:1527272263309};\\\", \\\"{x:495,y:459,t:1527272263325};\\\", \\\"{x:485,y:468,t:1527272263342};\\\", \\\"{x:472,y:480,t:1527272263359};\\\", \\\"{x:454,y:494,t:1527272263376};\\\", \\\"{x:438,y:508,t:1527272263392};\\\", \\\"{x:426,y:518,t:1527272263409};\\\", \\\"{x:418,y:528,t:1527272263426};\\\", \\\"{x:409,y:535,t:1527272263442};\\\", \\\"{x:399,y:543,t:1527272263459};\\\", \\\"{x:390,y:550,t:1527272263476};\\\", \\\"{x:388,y:555,t:1527272263492};\\\", \\\"{x:385,y:558,t:1527272263509};\\\", \\\"{x:383,y:559,t:1527272263526};\\\", \\\"{x:382,y:560,t:1527272263542};\\\", \\\"{x:379,y:561,t:1527272263559};\\\", \\\"{x:375,y:561,t:1527272263576};\\\", \\\"{x:370,y:561,t:1527272263592};\\\", \\\"{x:363,y:561,t:1527272263609};\\\", \\\"{x:356,y:561,t:1527272263626};\\\", \\\"{x:346,y:561,t:1527272263642};\\\", \\\"{x:332,y:561,t:1527272263660};\\\", \\\"{x:322,y:563,t:1527272263678};\\\", \\\"{x:319,y:564,t:1527272263691};\\\", \\\"{x:315,y:564,t:1527272263709};\\\", \\\"{x:307,y:568,t:1527272263726};\\\", \\\"{x:298,y:569,t:1527272263741};\\\", \\\"{x:291,y:570,t:1527272263759};\\\", \\\"{x:289,y:571,t:1527272263776};\\\", \\\"{x:281,y:571,t:1527272263792};\\\", \\\"{x:272,y:571,t:1527272263810};\\\", \\\"{x:264,y:571,t:1527272263825};\\\", \\\"{x:263,y:571,t:1527272263842};\\\", \\\"{x:259,y:571,t:1527272263860};\\\", \\\"{x:256,y:571,t:1527272263877};\\\", \\\"{x:253,y:570,t:1527272263892};\\\", \\\"{x:251,y:570,t:1527272263966};\\\", \\\"{x:250,y:569,t:1527272263976};\\\", \\\"{x:245,y:566,t:1527272263993};\\\", \\\"{x:240,y:562,t:1527272264011};\\\", \\\"{x:236,y:562,t:1527272264026};\\\", \\\"{x:233,y:560,t:1527272264043};\\\", \\\"{x:232,y:558,t:1527272264084};\\\", \\\"{x:226,y:555,t:1527272264094};\\\", \\\"{x:223,y:552,t:1527272264109};\\\", \\\"{x:216,y:537,t:1527272264126};\\\", \\\"{x:210,y:526,t:1527272264143};\\\", \\\"{x:192,y:519,t:1527272264160};\\\", \\\"{x:186,y:516,t:1527272264177};\\\", \\\"{x:185,y:516,t:1527272264193};\\\", \\\"{x:184,y:517,t:1527272264389};\\\", \\\"{x:183,y:519,t:1527272264398};\\\", \\\"{x:183,y:521,t:1527272264410};\\\", \\\"{x:183,y:526,t:1527272264426};\\\", \\\"{x:182,y:530,t:1527272264444};\\\", \\\"{x:181,y:532,t:1527272264459};\\\", \\\"{x:180,y:533,t:1527272264483};\\\", \\\"{x:180,y:534,t:1527272264508};\\\", \\\"{x:179,y:535,t:1527272264540};\\\", \\\"{x:178,y:537,t:1527272264548};\\\", \\\"{x:177,y:538,t:1527272264560};\\\", \\\"{x:176,y:540,t:1527272264576};\\\", \\\"{x:174,y:544,t:1527272264593};\\\", \\\"{x:172,y:545,t:1527272264611};\\\", \\\"{x:171,y:546,t:1527272264626};\\\", \\\"{x:172,y:546,t:1527272264957};\\\", \\\"{x:175,y:544,t:1527272264965};\\\", \\\"{x:180,y:546,t:1527272264981};\\\", \\\"{x:181,y:550,t:1527272264993};\\\", \\\"{x:189,y:553,t:1527272265011};\\\", \\\"{x:192,y:563,t:1527272265028};\\\", \\\"{x:205,y:574,t:1527272265043};\\\", \\\"{x:219,y:584,t:1527272265060};\\\", \\\"{x:219,y:587,t:1527272265077};\\\", \\\"{x:227,y:588,t:1527272265093};\\\", \\\"{x:228,y:589,t:1527272265110};\\\", \\\"{x:231,y:594,t:1527272265127};\\\", \\\"{x:236,y:598,t:1527272265143};\\\", \\\"{x:242,y:604,t:1527272265161};\\\", \\\"{x:247,y:608,t:1527272265177};\\\", \\\"{x:254,y:617,t:1527272265194};\\\", \\\"{x:273,y:633,t:1527272265211};\\\", \\\"{x:284,y:646,t:1527272265228};\\\", \\\"{x:301,y:664,t:1527272265244};\\\", \\\"{x:303,y:669,t:1527272265260};\\\", \\\"{x:303,y:675,t:1527272265278};\\\", \\\"{x:309,y:678,t:1527272265293};\\\", \\\"{x:316,y:680,t:1527272265310};\\\", \\\"{x:322,y:683,t:1527272265328};\\\", \\\"{x:326,y:683,t:1527272265344};\\\", \\\"{x:339,y:685,t:1527272265361};\\\", \\\"{x:360,y:687,t:1527272265378};\\\", \\\"{x:363,y:693,t:1527272265395};\\\", \\\"{x:374,y:696,t:1527272265411};\\\", \\\"{x:381,y:697,t:1527272265428};\\\", \\\"{x:388,y:697,t:1527272265444};\\\", \\\"{x:389,y:697,t:1527272265461};\\\", \\\"{x:390,y:697,t:1527272265479};\\\", \\\"{x:393,y:697,t:1527272265494};\\\", \\\"{x:395,y:697,t:1527272265511};\\\", \\\"{x:397,y:696,t:1527272265528};\\\", \\\"{x:403,y:696,t:1527272265545};\\\", \\\"{x:408,y:696,t:1527272265561};\\\", \\\"{x:421,y:696,t:1527272265578};\\\", \\\"{x:438,y:704,t:1527272265596};\\\", \\\"{x:460,y:714,t:1527272265612};\\\", \\\"{x:472,y:729,t:1527272265629};\\\", \\\"{x:485,y:730,t:1527272265645};\\\", \\\"{x:511,y:742,t:1527272265661};\\\", \\\"{x:533,y:748,t:1527272265677};\\\", \\\"{x:539,y:752,t:1527272265694};\\\", \\\"{x:542,y:754,t:1527272265711};\\\", \\\"{x:542,y:755,t:1527272265813};\\\", \\\"{x:542,y:756,t:1527272265836};\\\", \\\"{x:543,y:756,t:1527272266246};\\\", \\\"{x:544,y:755,t:1527272266261};\\\", \\\"{x:544,y:752,t:1527272266279};\\\", \\\"{x:544,y:748,t:1527272266294};\\\", \\\"{x:545,y:748,t:1527272266311};\\\" ] }, { \\\"rt\\\": 63838, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 748837, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -O -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:543,y:748,t:1527272269069};\\\", \\\"{x:519,y:733,t:1527272269097};\\\", \\\"{x:511,y:725,t:1527272269100};\\\", \\\"{x:459,y:700,t:1527272269117};\\\", \\\"{x:356,y:653,t:1527272269133};\\\", \\\"{x:302,y:630,t:1527272269148};\\\", \\\"{x:215,y:599,t:1527272269163};\\\", \\\"{x:167,y:577,t:1527272269181};\\\", \\\"{x:150,y:561,t:1527272269197};\\\", \\\"{x:146,y:554,t:1527272269213};\\\", \\\"{x:147,y:544,t:1527272269230};\\\", \\\"{x:167,y:517,t:1527272269248};\\\", \\\"{x:192,y:489,t:1527272269263};\\\", \\\"{x:219,y:461,t:1527272269281};\\\", \\\"{x:250,y:427,t:1527272269298};\\\", \\\"{x:298,y:390,t:1527272269313};\\\", \\\"{x:360,y:374,t:1527272269330};\\\", \\\"{x:404,y:363,t:1527272269347};\\\", \\\"{x:446,y:363,t:1527272269363};\\\", \\\"{x:540,y:367,t:1527272269380};\\\", \\\"{x:609,y:388,t:1527272269397};\\\", \\\"{x:684,y:409,t:1527272269414};\\\", \\\"{x:695,y:418,t:1527272269430};\\\", \\\"{x:702,y:427,t:1527272269447};\\\", \\\"{x:711,y:437,t:1527272269464};\\\", \\\"{x:716,y:451,t:1527272269480};\\\", \\\"{x:719,y:470,t:1527272269499};\\\", \\\"{x:720,y:486,t:1527272269514};\\\", \\\"{x:723,y:511,t:1527272269531};\\\", \\\"{x:726,y:530,t:1527272269548};\\\", \\\"{x:726,y:543,t:1527272269565};\\\", \\\"{x:726,y:547,t:1527272269580};\\\", \\\"{x:721,y:555,t:1527272269599};\\\", \\\"{x:719,y:559,t:1527272269615};\\\", \\\"{x:717,y:560,t:1527272269631};\\\", \\\"{x:715,y:561,t:1527272269648};\\\", \\\"{x:713,y:562,t:1527272269664};\\\", \\\"{x:712,y:563,t:1527272269702};\\\", \\\"{x:711,y:564,t:1527272269716};\\\", \\\"{x:710,y:564,t:1527272269730};\\\", \\\"{x:707,y:564,t:1527272269755};\\\", \\\"{x:702,y:566,t:1527272269764};\\\", \\\"{x:697,y:566,t:1527272269781};\\\", \\\"{x:685,y:566,t:1527272269797};\\\", \\\"{x:677,y:566,t:1527272269814};\\\", \\\"{x:660,y:569,t:1527272269831};\\\", \\\"{x:658,y:569,t:1527272269847};\\\", \\\"{x:656,y:569,t:1527272269865};\\\", \\\"{x:642,y:571,t:1527272269882};\\\", \\\"{x:617,y:571,t:1527272269898};\\\", \\\"{x:611,y:571,t:1527272269914};\\\", \\\"{x:605,y:571,t:1527272269931};\\\", \\\"{x:604,y:571,t:1527272269948};\\\", \\\"{x:603,y:570,t:1527272269989};\\\", \\\"{x:602,y:570,t:1527272269997};\\\", \\\"{x:599,y:570,t:1527272270015};\\\", \\\"{x:584,y:567,t:1527272270030};\\\", \\\"{x:578,y:564,t:1527272270047};\\\", \\\"{x:571,y:562,t:1527272270065};\\\", \\\"{x:568,y:562,t:1527272270081};\\\", \\\"{x:561,y:558,t:1527272270098};\\\", \\\"{x:549,y:555,t:1527272270116};\\\", \\\"{x:542,y:550,t:1527272270131};\\\", \\\"{x:526,y:549,t:1527272270147};\\\", \\\"{x:511,y:547,t:1527272270164};\\\", \\\"{x:502,y:546,t:1527272270181};\\\", \\\"{x:501,y:546,t:1527272270197};\\\", \\\"{x:498,y:546,t:1527272270215};\\\", \\\"{x:491,y:546,t:1527272270231};\\\", \\\"{x:487,y:546,t:1527272270247};\\\", \\\"{x:483,y:546,t:1527272270264};\\\", \\\"{x:479,y:546,t:1527272270281};\\\", \\\"{x:471,y:546,t:1527272270297};\\\", \\\"{x:468,y:546,t:1527272270314};\\\", \\\"{x:464,y:546,t:1527272270331};\\\", \\\"{x:451,y:549,t:1527272270347};\\\", \\\"{x:434,y:559,t:1527272270366};\\\", \\\"{x:421,y:567,t:1527272270383};\\\", \\\"{x:413,y:572,t:1527272270398};\\\", \\\"{x:407,y:573,t:1527272270414};\\\", \\\"{x:405,y:574,t:1527272270431};\\\", \\\"{x:404,y:575,t:1527272270448};\\\", \\\"{x:403,y:575,t:1527272270464};\\\", \\\"{x:401,y:576,t:1527272270532};\\\", \\\"{x:397,y:576,t:1527272270548};\\\", \\\"{x:394,y:578,t:1527272270565};\\\", \\\"{x:391,y:578,t:1527272270581};\\\", \\\"{x:386,y:579,t:1527272270599};\\\", \\\"{x:381,y:579,t:1527272270615};\\\", \\\"{x:378,y:579,t:1527272270631};\\\", \\\"{x:375,y:579,t:1527272270648};\\\", \\\"{x:373,y:580,t:1527272270665};\\\", \\\"{x:369,y:580,t:1527272270682};\\\", \\\"{x:367,y:580,t:1527272270698};\\\", \\\"{x:366,y:580,t:1527272270715};\\\", \\\"{x:364,y:580,t:1527272270732};\\\", \\\"{x:363,y:580,t:1527272270748};\\\", \\\"{x:362,y:580,t:1527272270766};\\\", \\\"{x:358,y:580,t:1527272270781};\\\", \\\"{x:357,y:580,t:1527272270799};\\\", \\\"{x:356,y:580,t:1527272270815};\\\", \\\"{x:353,y:580,t:1527272270831};\\\", \\\"{x:346,y:580,t:1527272270849};\\\", \\\"{x:342,y:580,t:1527272270865};\\\", \\\"{x:340,y:580,t:1527272270881};\\\", \\\"{x:335,y:580,t:1527272270899};\\\", \\\"{x:331,y:579,t:1527272270916};\\\", \\\"{x:323,y:577,t:1527272270932};\\\", \\\"{x:319,y:576,t:1527272270949};\\\", \\\"{x:319,y:575,t:1527272270965};\\\", \\\"{x:318,y:575,t:1527272271012};\\\", \\\"{x:317,y:575,t:1527272271021};\\\", \\\"{x:316,y:575,t:1527272271031};\\\", \\\"{x:315,y:575,t:1527272271053};\\\", \\\"{x:313,y:575,t:1527272271077};\\\", \\\"{x:312,y:576,t:1527272271125};\\\", \\\"{x:310,y:578,t:1527272271189};\\\", \\\"{x:309,y:578,t:1527272271204};\\\", \\\"{x:307,y:579,t:1527272271220};\\\", \\\"{x:306,y:580,t:1527272271233};\\\", \\\"{x:304,y:580,t:1527272271249};\\\", \\\"{x:302,y:581,t:1527272271266};\\\", \\\"{x:300,y:582,t:1527272271282};\\\", \\\"{x:299,y:583,t:1527272271298};\\\", \\\"{x:298,y:584,t:1527272271324};\\\", \\\"{x:297,y:585,t:1527272271332};\\\", \\\"{x:297,y:584,t:1527272271597};\\\", \\\"{x:297,y:583,t:1527272271613};\\\", \\\"{x:299,y:583,t:1527272271621};\\\", \\\"{x:300,y:582,t:1527272271633};\\\", \\\"{x:304,y:579,t:1527272271650};\\\", \\\"{x:305,y:578,t:1527272271666};\\\", \\\"{x:310,y:576,t:1527272271682};\\\", \\\"{x:314,y:574,t:1527272271700};\\\", \\\"{x:317,y:572,t:1527272271716};\\\", \\\"{x:321,y:570,t:1527272271732};\\\", \\\"{x:323,y:569,t:1527272271749};\\\", \\\"{x:324,y:567,t:1527272271765};\\\", \\\"{x:327,y:565,t:1527272284621};\\\", \\\"{x:330,y:565,t:1527272284628};\\\", \\\"{x:350,y:552,t:1527272284646};\\\", \\\"{x:378,y:530,t:1527272284661};\\\", \\\"{x:418,y:515,t:1527272284678};\\\", \\\"{x:465,y:487,t:1527272284710};\\\", \\\"{x:481,y:480,t:1527272284726};\\\", \\\"{x:488,y:475,t:1527272284743};\\\", \\\"{x:491,y:473,t:1527272284759};\\\", \\\"{x:493,y:473,t:1527272285716};\\\", \\\"{x:502,y:474,t:1527272285725};\\\", \\\"{x:513,y:480,t:1527272285741};\\\", \\\"{x:533,y:495,t:1527272285759};\\\", \\\"{x:588,y:514,t:1527272285774};\\\", \\\"{x:670,y:539,t:1527272285793};\\\", \\\"{x:764,y:567,t:1527272285810};\\\", \\\"{x:849,y:588,t:1527272285827};\\\", \\\"{x:942,y:606,t:1527272285844};\\\", \\\"{x:985,y:621,t:1527272285861};\\\", \\\"{x:1024,y:632,t:1527272285877};\\\", \\\"{x:1038,y:641,t:1527272285894};\\\", \\\"{x:1052,y:646,t:1527272285910};\\\", \\\"{x:1063,y:651,t:1527272285928};\\\", \\\"{x:1066,y:653,t:1527272285944};\\\", \\\"{x:1075,y:657,t:1527272285961};\\\", \\\"{x:1085,y:667,t:1527272285977};\\\", \\\"{x:1093,y:675,t:1527272285994};\\\", \\\"{x:1108,y:685,t:1527272286011};\\\", \\\"{x:1121,y:692,t:1527272286027};\\\", \\\"{x:1152,y:704,t:1527272286044};\\\", \\\"{x:1160,y:710,t:1527272286061};\\\", \\\"{x:1171,y:716,t:1527272286077};\\\", \\\"{x:1175,y:718,t:1527272286094};\\\", \\\"{x:1194,y:721,t:1527272286111};\\\", \\\"{x:1218,y:722,t:1527272286128};\\\", \\\"{x:1239,y:723,t:1527272286145};\\\", \\\"{x:1265,y:725,t:1527272286162};\\\", \\\"{x:1277,y:728,t:1527272286178};\\\", \\\"{x:1290,y:736,t:1527272286194};\\\", \\\"{x:1300,y:736,t:1527272286211};\\\", \\\"{x:1339,y:742,t:1527272286229};\\\", \\\"{x:1367,y:749,t:1527272286244};\\\", \\\"{x:1380,y:753,t:1527272286262};\\\", \\\"{x:1391,y:755,t:1527272286278};\\\", \\\"{x:1395,y:757,t:1527272286294};\\\", \\\"{x:1397,y:758,t:1527272286312};\\\", \\\"{x:1397,y:759,t:1527272286356};\\\", \\\"{x:1397,y:760,t:1527272286372};\\\", \\\"{x:1400,y:763,t:1527272286389};\\\", \\\"{x:1403,y:763,t:1527272286397};\\\", \\\"{x:1407,y:765,t:1527272286412};\\\", \\\"{x:1416,y:768,t:1527272286429};\\\", \\\"{x:1420,y:768,t:1527272286445};\\\", \\\"{x:1423,y:768,t:1527272286462};\\\", \\\"{x:1430,y:768,t:1527272286479};\\\", \\\"{x:1431,y:768,t:1527272286495};\\\", \\\"{x:1439,y:768,t:1527272286512};\\\", \\\"{x:1449,y:769,t:1527272286528};\\\", \\\"{x:1467,y:772,t:1527272286546};\\\", \\\"{x:1489,y:774,t:1527272286563};\\\", \\\"{x:1506,y:778,t:1527272286579};\\\", \\\"{x:1521,y:778,t:1527272286595};\\\", \\\"{x:1528,y:778,t:1527272286613};\\\", \\\"{x:1533,y:778,t:1527272286629};\\\", \\\"{x:1536,y:778,t:1527272286646};\\\", \\\"{x:1537,y:778,t:1527272286741};\\\", \\\"{x:1539,y:778,t:1527272286756};\\\", \\\"{x:1540,y:778,t:1527272286765};\\\", \\\"{x:1541,y:778,t:1527272286779};\\\", \\\"{x:1542,y:777,t:1527272286795};\\\", \\\"{x:1543,y:777,t:1527272286828};\\\", \\\"{x:1543,y:775,t:1527272286908};\\\", \\\"{x:1543,y:773,t:1527272286916};\\\", \\\"{x:1541,y:769,t:1527272286929};\\\", \\\"{x:1535,y:761,t:1527272286946};\\\", \\\"{x:1522,y:748,t:1527272286962};\\\", \\\"{x:1504,y:735,t:1527272286979};\\\", \\\"{x:1480,y:719,t:1527272286995};\\\", \\\"{x:1463,y:710,t:1527272287012};\\\", \\\"{x:1452,y:706,t:1527272287029};\\\", \\\"{x:1436,y:702,t:1527272287046};\\\", \\\"{x:1433,y:700,t:1527272287062};\\\", \\\"{x:1425,y:698,t:1527272287079};\\\", \\\"{x:1418,y:697,t:1527272287096};\\\", \\\"{x:1416,y:695,t:1527272287113};\\\", \\\"{x:1415,y:695,t:1527272287732};\\\", \\\"{x:1414,y:695,t:1527272287747};\\\", \\\"{x:1413,y:695,t:1527272287764};\\\", \\\"{x:1412,y:695,t:1527272287780};\\\", \\\"{x:1411,y:696,t:1527272287877};\\\", \\\"{x:1410,y:696,t:1527272287885};\\\", \\\"{x:1410,y:698,t:1527272288277};\\\", \\\"{x:1418,y:699,t:1527272288285};\\\", \\\"{x:1422,y:700,t:1527272288298};\\\", \\\"{x:1438,y:703,t:1527272288316};\\\", \\\"{x:1453,y:705,t:1527272288331};\\\", \\\"{x:1466,y:705,t:1527272288348};\\\", \\\"{x:1472,y:705,t:1527272288366};\\\", \\\"{x:1473,y:705,t:1527272288382};\\\", \\\"{x:1475,y:705,t:1527272288398};\\\", \\\"{x:1478,y:705,t:1527272288415};\\\", \\\"{x:1483,y:704,t:1527272288432};\\\", \\\"{x:1485,y:703,t:1527272288449};\\\", \\\"{x:1486,y:702,t:1527272288466};\\\", \\\"{x:1487,y:702,t:1527272288483};\\\", \\\"{x:1487,y:701,t:1527272288781};\\\", \\\"{x:1488,y:700,t:1527272288877};\\\", \\\"{x:1491,y:701,t:1527272288885};\\\", \\\"{x:1493,y:702,t:1527272288899};\\\", \\\"{x:1503,y:710,t:1527272288916};\\\", \\\"{x:1508,y:718,t:1527272288932};\\\", \\\"{x:1514,y:721,t:1527272288950};\\\", \\\"{x:1522,y:726,t:1527272288967};\\\", \\\"{x:1523,y:726,t:1527272288982};\\\", \\\"{x:1528,y:727,t:1527272289000};\\\", \\\"{x:1532,y:727,t:1527272289017};\\\", \\\"{x:1534,y:727,t:1527272289034};\\\", \\\"{x:1536,y:727,t:1527272289050};\\\", \\\"{x:1538,y:727,t:1527272289066};\\\", \\\"{x:1540,y:726,t:1527272289084};\\\", \\\"{x:1544,y:722,t:1527272289100};\\\", \\\"{x:1549,y:717,t:1527272289116};\\\", \\\"{x:1551,y:713,t:1527272289134};\\\", \\\"{x:1554,y:708,t:1527272289150};\\\", \\\"{x:1555,y:704,t:1527272289167};\\\", \\\"{x:1556,y:700,t:1527272289184};\\\", \\\"{x:1556,y:699,t:1527272289199};\\\", \\\"{x:1556,y:697,t:1527272289217};\\\", \\\"{x:1556,y:698,t:1527272289325};\\\", \\\"{x:1556,y:701,t:1527272289334};\\\", \\\"{x:1556,y:709,t:1527272289350};\\\", \\\"{x:1556,y:717,t:1527272289367};\\\", \\\"{x:1561,y:730,t:1527272289383};\\\", \\\"{x:1571,y:739,t:1527272289400};\\\", \\\"{x:1581,y:745,t:1527272289416};\\\", \\\"{x:1584,y:747,t:1527272289434};\\\", \\\"{x:1589,y:747,t:1527272289451};\\\", \\\"{x:1594,y:747,t:1527272289468};\\\", \\\"{x:1596,y:747,t:1527272289484};\\\", \\\"{x:1596,y:745,t:1527272289500};\\\", \\\"{x:1598,y:742,t:1527272289517};\\\", \\\"{x:1598,y:741,t:1527272289533};\\\", \\\"{x:1599,y:737,t:1527272289550};\\\", \\\"{x:1600,y:734,t:1527272289567};\\\", \\\"{x:1600,y:728,t:1527272289583};\\\", \\\"{x:1601,y:725,t:1527272289600};\\\", \\\"{x:1604,y:721,t:1527272289617};\\\", \\\"{x:1604,y:716,t:1527272289634};\\\", \\\"{x:1604,y:709,t:1527272289650};\\\", \\\"{x:1604,y:704,t:1527272289667};\\\", \\\"{x:1603,y:701,t:1527272289684};\\\", \\\"{x:1603,y:700,t:1527272289700};\\\", \\\"{x:1603,y:699,t:1527272289717};\\\", \\\"{x:1602,y:697,t:1527272289735};\\\", \\\"{x:1600,y:697,t:1527272292085};\\\", \\\"{x:1599,y:697,t:1527272292509};\\\", \\\"{x:1597,y:697,t:1527272293789};\\\", \\\"{x:1585,y:699,t:1527272293796};\\\", \\\"{x:1564,y:700,t:1527272293808};\\\", \\\"{x:1466,y:702,t:1527272293825};\\\", \\\"{x:1317,y:702,t:1527272293842};\\\", \\\"{x:1156,y:696,t:1527272293858};\\\", \\\"{x:968,y:696,t:1527272293875};\\\", \\\"{x:779,y:692,t:1527272293892};\\\", \\\"{x:547,y:672,t:1527272293908};\\\", \\\"{x:466,y:668,t:1527272293926};\\\", \\\"{x:448,y:668,t:1527272293941};\\\", \\\"{x:447,y:668,t:1527272294116};\\\", \\\"{x:451,y:663,t:1527272294133};\\\", \\\"{x:459,y:651,t:1527272294150};\\\", \\\"{x:474,y:635,t:1527272294168};\\\", \\\"{x:485,y:617,t:1527272294184};\\\", \\\"{x:497,y:603,t:1527272294200};\\\", \\\"{x:512,y:588,t:1527272294216};\\\", \\\"{x:520,y:580,t:1527272294233};\\\", \\\"{x:529,y:568,t:1527272294250};\\\", \\\"{x:533,y:559,t:1527272294268};\\\", \\\"{x:533,y:548,t:1527272294283};\\\", \\\"{x:533,y:534,t:1527272294300};\\\", \\\"{x:533,y:531,t:1527272294317};\\\", \\\"{x:531,y:529,t:1527272294334};\\\", \\\"{x:528,y:529,t:1527272294350};\\\", \\\"{x:527,y:529,t:1527272294367};\\\", \\\"{x:522,y:528,t:1527272294384};\\\", \\\"{x:518,y:527,t:1527272294401};\\\", \\\"{x:514,y:527,t:1527272294418};\\\", \\\"{x:501,y:525,t:1527272294434};\\\", \\\"{x:493,y:523,t:1527272294452};\\\", \\\"{x:461,y:522,t:1527272294468};\\\", \\\"{x:443,y:524,t:1527272294484};\\\", \\\"{x:421,y:531,t:1527272294500};\\\", \\\"{x:391,y:542,t:1527272294517};\\\", \\\"{x:370,y:548,t:1527272294535};\\\", \\\"{x:363,y:558,t:1527272294551};\\\", \\\"{x:356,y:563,t:1527272294567};\\\", \\\"{x:341,y:570,t:1527272294584};\\\", \\\"{x:326,y:575,t:1527272294600};\\\", \\\"{x:325,y:575,t:1527272294617};\\\", \\\"{x:325,y:576,t:1527272294667};\\\", \\\"{x:323,y:576,t:1527272294684};\\\", \\\"{x:321,y:578,t:1527272294756};\\\", \\\"{x:320,y:579,t:1527272294768};\\\", \\\"{x:305,y:583,t:1527272294784};\\\", \\\"{x:270,y:590,t:1527272294803};\\\", \\\"{x:245,y:599,t:1527272294818};\\\", \\\"{x:200,y:605,t:1527272294835};\\\", \\\"{x:182,y:614,t:1527272294852};\\\", \\\"{x:166,y:617,t:1527272294867};\\\", \\\"{x:163,y:619,t:1527272294884};\\\", \\\"{x:162,y:620,t:1527272294996};\\\", \\\"{x:161,y:621,t:1527272295020};\\\", \\\"{x:159,y:624,t:1527272295034};\\\", \\\"{x:155,y:630,t:1527272295051};\\\", \\\"{x:154,y:632,t:1527272295069};\\\", \\\"{x:156,y:632,t:1527272295149};\\\", \\\"{x:157,y:632,t:1527272295164};\\\", \\\"{x:157,y:630,t:1527272295174};\\\", \\\"{x:166,y:629,t:1527272295188};\\\", \\\"{x:177,y:624,t:1527272295200};\\\", \\\"{x:211,y:617,t:1527272295217};\\\", \\\"{x:226,y:610,t:1527272295234};\\\", \\\"{x:228,y:608,t:1527272295251};\\\", \\\"{x:248,y:602,t:1527272295267};\\\", \\\"{x:252,y:601,t:1527272295284};\\\", \\\"{x:252,y:600,t:1527272295357};\\\", \\\"{x:252,y:599,t:1527272295368};\\\", \\\"{x:254,y:598,t:1527272295384};\\\", \\\"{x:259,y:596,t:1527272295401};\\\", \\\"{x:274,y:591,t:1527272295419};\\\", \\\"{x:287,y:588,t:1527272295434};\\\", \\\"{x:311,y:584,t:1527272295451};\\\", \\\"{x:389,y:573,t:1527272295468};\\\", \\\"{x:422,y:565,t:1527272295485};\\\", \\\"{x:489,y:559,t:1527272295503};\\\", \\\"{x:535,y:555,t:1527272295519};\\\", \\\"{x:553,y:553,t:1527272295536};\\\", \\\"{x:563,y:553,t:1527272295551};\\\", \\\"{x:578,y:550,t:1527272295568};\\\", \\\"{x:597,y:549,t:1527272295584};\\\", \\\"{x:599,y:549,t:1527272295601};\\\", \\\"{x:598,y:552,t:1527272295877};\\\", \\\"{x:598,y:554,t:1527272295885};\\\", \\\"{x:597,y:563,t:1527272295903};\\\", \\\"{x:596,y:571,t:1527272295918};\\\", \\\"{x:594,y:583,t:1527272295934};\\\", \\\"{x:594,y:586,t:1527272295951};\\\", \\\"{x:594,y:590,t:1527272295969};\\\", \\\"{x:590,y:596,t:1527272295985};\\\", \\\"{x:588,y:598,t:1527272296001};\\\", \\\"{x:587,y:599,t:1527272296020};\\\", \\\"{x:586,y:599,t:1527272296044};\\\", \\\"{x:584,y:599,t:1527272296052};\\\", \\\"{x:575,y:599,t:1527272296068};\\\", \\\"{x:566,y:603,t:1527272296090};\\\", \\\"{x:556,y:603,t:1527272296101};\\\", \\\"{x:550,y:603,t:1527272296118};\\\", \\\"{x:548,y:603,t:1527272296135};\\\", \\\"{x:545,y:603,t:1527272296152};\\\", \\\"{x:545,y:600,t:1527272296168};\\\", \\\"{x:551,y:592,t:1527272296186};\\\", \\\"{x:569,y:578,t:1527272296202};\\\", \\\"{x:596,y:559,t:1527272296219};\\\", \\\"{x:669,y:521,t:1527272296235};\\\", \\\"{x:759,y:488,t:1527272296252};\\\", \\\"{x:793,y:474,t:1527272296270};\\\", \\\"{x:825,y:468,t:1527272296286};\\\", \\\"{x:840,y:467,t:1527272296302};\\\", \\\"{x:860,y:463,t:1527272296318};\\\", \\\"{x:878,y:459,t:1527272296336};\\\", \\\"{x:883,y:458,t:1527272296353};\\\", \\\"{x:884,y:458,t:1527272296368};\\\", \\\"{x:884,y:459,t:1527272296477};\\\", \\\"{x:880,y:463,t:1527272296486};\\\", \\\"{x:870,y:472,t:1527272296502};\\\", \\\"{x:860,y:480,t:1527272296518};\\\", \\\"{x:850,y:488,t:1527272296537};\\\", \\\"{x:845,y:492,t:1527272296552};\\\", \\\"{x:842,y:496,t:1527272296569};\\\", \\\"{x:841,y:497,t:1527272296585};\\\", \\\"{x:841,y:498,t:1527272296602};\\\", \\\"{x:839,y:499,t:1527272296619};\\\", \\\"{x:837,y:501,t:1527272300813};\\\", \\\"{x:831,y:504,t:1527272300822};\\\", \\\"{x:821,y:515,t:1527272300841};\\\", \\\"{x:818,y:541,t:1527272300857};\\\", \\\"{x:818,y:571,t:1527272300889};\\\", \\\"{x:828,y:596,t:1527272300904};\\\", \\\"{x:829,y:600,t:1527272300922};\\\", \\\"{x:871,y:609,t:1527272301854};\\\", \\\"{x:1011,y:622,t:1527272301874};\\\", \\\"{x:1121,y:632,t:1527272301890};\\\", \\\"{x:1189,y:636,t:1527272301907};\\\", \\\"{x:1216,y:636,t:1527272301923};\\\", \\\"{x:1220,y:637,t:1527272301940};\\\", \\\"{x:1220,y:638,t:1527272302069};\\\", \\\"{x:1220,y:639,t:1527272302076};\\\", \\\"{x:1220,y:640,t:1527272302091};\\\", \\\"{x:1219,y:650,t:1527272302108};\\\", \\\"{x:1226,y:658,t:1527272302124};\\\", \\\"{x:1238,y:672,t:1527272302141};\\\", \\\"{x:1260,y:697,t:1527272302158};\\\", \\\"{x:1277,y:707,t:1527272302174};\\\", \\\"{x:1287,y:718,t:1527272302196};\\\", \\\"{x:1292,y:727,t:1527272302213};\\\", \\\"{x:1299,y:732,t:1527272302230};\\\", \\\"{x:1312,y:736,t:1527272302246};\\\", \\\"{x:1315,y:737,t:1527272302263};\\\", \\\"{x:1318,y:737,t:1527272302279};\\\", \\\"{x:1319,y:737,t:1527272302296};\\\", \\\"{x:1322,y:737,t:1527272302313};\\\", \\\"{x:1323,y:737,t:1527272302329};\\\", \\\"{x:1326,y:737,t:1527272302368};\\\", \\\"{x:1329,y:737,t:1527272302379};\\\", \\\"{x:1333,y:737,t:1527272302397};\\\", \\\"{x:1344,y:741,t:1527272302412};\\\", \\\"{x:1356,y:745,t:1527272302429};\\\", \\\"{x:1370,y:748,t:1527272302447};\\\", \\\"{x:1382,y:752,t:1527272302462};\\\", \\\"{x:1388,y:753,t:1527272302479};\\\", \\\"{x:1389,y:754,t:1527272302497};\\\", \\\"{x:1390,y:754,t:1527272302513};\\\", \\\"{x:1392,y:756,t:1527272302641};\\\", \\\"{x:1393,y:757,t:1527272302649};\\\", \\\"{x:1397,y:757,t:1527272302663};\\\", \\\"{x:1400,y:758,t:1527272302680};\\\", \\\"{x:1404,y:758,t:1527272302696};\\\", \\\"{x:1407,y:759,t:1527272302714};\\\", \\\"{x:1409,y:759,t:1527272302730};\\\", \\\"{x:1412,y:761,t:1527272302746};\\\", \\\"{x:1417,y:761,t:1527272302764};\\\", \\\"{x:1421,y:761,t:1527272302780};\\\", \\\"{x:1425,y:761,t:1527272302797};\\\", \\\"{x:1429,y:762,t:1527272302813};\\\", \\\"{x:1430,y:762,t:1527272302830};\\\", \\\"{x:1431,y:762,t:1527272302847};\\\", \\\"{x:1433,y:762,t:1527272302873};\\\", \\\"{x:1434,y:762,t:1527272302897};\\\", \\\"{x:1437,y:762,t:1527272302914};\\\", \\\"{x:1438,y:762,t:1527272303185};\\\", \\\"{x:1438,y:763,t:1527272303225};\\\", \\\"{x:1437,y:764,t:1527272303241};\\\", \\\"{x:1433,y:764,t:1527272303249};\\\", \\\"{x:1430,y:765,t:1527272303265};\\\", \\\"{x:1427,y:766,t:1527272303281};\\\", \\\"{x:1424,y:766,t:1527272303298};\\\", \\\"{x:1427,y:766,t:1527272303425};\\\", \\\"{x:1430,y:766,t:1527272303432};\\\", \\\"{x:1445,y:769,t:1527272303449};\\\", \\\"{x:1457,y:770,t:1527272303465};\\\", \\\"{x:1473,y:771,t:1527272303482};\\\", \\\"{x:1476,y:771,t:1527272303498};\\\", \\\"{x:1480,y:771,t:1527272303515};\\\", \\\"{x:1483,y:772,t:1527272303532};\\\", \\\"{x:1487,y:773,t:1527272303549};\\\", \\\"{x:1489,y:773,t:1527272303601};\\\", \\\"{x:1490,y:773,t:1527272303753};\\\", \\\"{x:1492,y:772,t:1527272303801};\\\", \\\"{x:1501,y:770,t:1527272303817};\\\", \\\"{x:1507,y:768,t:1527272303833};\\\", \\\"{x:1515,y:767,t:1527272303852};\\\", \\\"{x:1527,y:767,t:1527272303867};\\\", \\\"{x:1543,y:767,t:1527272303882};\\\", \\\"{x:1550,y:767,t:1527272303898};\\\", \\\"{x:1556,y:767,t:1527272303916};\\\", \\\"{x:1560,y:767,t:1527272303932};\\\", \\\"{x:1562,y:765,t:1527272303949};\\\", \\\"{x:1562,y:764,t:1527272303966};\\\", \\\"{x:1563,y:764,t:1527272303982};\\\", \\\"{x:1563,y:763,t:1527272304385};\\\", \\\"{x:1554,y:762,t:1527272304401};\\\", \\\"{x:1550,y:762,t:1527272304417};\\\", \\\"{x:1545,y:762,t:1527272304434};\\\", \\\"{x:1540,y:762,t:1527272304451};\\\", \\\"{x:1535,y:762,t:1527272304468};\\\", \\\"{x:1527,y:762,t:1527272304485};\\\", \\\"{x:1517,y:762,t:1527272304501};\\\", \\\"{x:1515,y:762,t:1527272304518};\\\", \\\"{x:1514,y:762,t:1527272304534};\\\", \\\"{x:1512,y:762,t:1527272304575};\\\", \\\"{x:1511,y:762,t:1527272305817};\\\", \\\"{x:1512,y:763,t:1527272305825};\\\", \\\"{x:1515,y:764,t:1527272305837};\\\", \\\"{x:1516,y:764,t:1527272305855};\\\", \\\"{x:1522,y:764,t:1527272305872};\\\", \\\"{x:1529,y:764,t:1527272305888};\\\", \\\"{x:1539,y:766,t:1527272305905};\\\", \\\"{x:1544,y:766,t:1527272305921};\\\", \\\"{x:1547,y:766,t:1527272305937};\\\", \\\"{x:1549,y:766,t:1527272305955};\\\", \\\"{x:1551,y:766,t:1527272305993};\\\", \\\"{x:1553,y:766,t:1527272306065};\\\", \\\"{x:1556,y:766,t:1527272306088};\\\", \\\"{x:1558,y:765,t:1527272306232};\\\", \\\"{x:1560,y:765,t:1527272306240};\\\", \\\"{x:1563,y:765,t:1527272306254};\\\", \\\"{x:1568,y:765,t:1527272306271};\\\", \\\"{x:1574,y:765,t:1527272306287};\\\", \\\"{x:1584,y:765,t:1527272306305};\\\", \\\"{x:1589,y:765,t:1527272306321};\\\", \\\"{x:1596,y:765,t:1527272306338};\\\", \\\"{x:1600,y:764,t:1527272306355};\\\", \\\"{x:1603,y:761,t:1527272306371};\\\", \\\"{x:1605,y:760,t:1527272306391};\\\", \\\"{x:1607,y:759,t:1527272306405};\\\", \\\"{x:1608,y:758,t:1527272306422};\\\", \\\"{x:1611,y:755,t:1527272306438};\\\", \\\"{x:1612,y:755,t:1527272306617};\\\", \\\"{x:1612,y:754,t:1527272306641};\\\", \\\"{x:1613,y:753,t:1527272306656};\\\", \\\"{x:1616,y:753,t:1527272306673};\\\", \\\"{x:1621,y:753,t:1527272306689};\\\", \\\"{x:1622,y:753,t:1527272306706};\\\", \\\"{x:1623,y:753,t:1527272306753};\\\", \\\"{x:1626,y:753,t:1527272306761};\\\", \\\"{x:1633,y:754,t:1527272306773};\\\", \\\"{x:1635,y:754,t:1527272306789};\\\", \\\"{x:1640,y:754,t:1527272306807};\\\", \\\"{x:1641,y:754,t:1527272306823};\\\", \\\"{x:1636,y:754,t:1527272307185};\\\", \\\"{x:1634,y:754,t:1527272307193};\\\", \\\"{x:1630,y:753,t:1527272307208};\\\", \\\"{x:1628,y:753,t:1527272307223};\\\", \\\"{x:1625,y:753,t:1527272307241};\\\", \\\"{x:1620,y:753,t:1527272307258};\\\", \\\"{x:1619,y:753,t:1527272307321};\\\", \\\"{x:1617,y:753,t:1527272311304};\\\", \\\"{x:1612,y:754,t:1527272311316};\\\", \\\"{x:1602,y:754,t:1527272311334};\\\", \\\"{x:1584,y:754,t:1527272311350};\\\", \\\"{x:1562,y:752,t:1527272311366};\\\", \\\"{x:1549,y:747,t:1527272311383};\\\", \\\"{x:1529,y:742,t:1527272311400};\\\", \\\"{x:1520,y:738,t:1527272311416};\\\", \\\"{x:1513,y:736,t:1527272311434};\\\", \\\"{x:1506,y:734,t:1527272311451};\\\", \\\"{x:1500,y:733,t:1527272311468};\\\", \\\"{x:1488,y:733,t:1527272311484};\\\", \\\"{x:1478,y:729,t:1527272311500};\\\", \\\"{x:1476,y:728,t:1527272311518};\\\", \\\"{x:1475,y:728,t:1527272311534};\\\", \\\"{x:1473,y:727,t:1527272311551};\\\", \\\"{x:1470,y:727,t:1527272311568};\\\", \\\"{x:1463,y:726,t:1527272311585};\\\", \\\"{x:1456,y:725,t:1527272311600};\\\", \\\"{x:1451,y:725,t:1527272311618};\\\", \\\"{x:1447,y:724,t:1527272311635};\\\", \\\"{x:1441,y:723,t:1527272311651};\\\", \\\"{x:1435,y:722,t:1527272311668};\\\", \\\"{x:1431,y:721,t:1527272311685};\\\", \\\"{x:1428,y:721,t:1527272311700};\\\", \\\"{x:1427,y:721,t:1527272311745};\\\", \\\"{x:1429,y:726,t:1527272319584};\\\", \\\"{x:1435,y:734,t:1527272319591};\\\", \\\"{x:1437,y:740,t:1527272319602};\\\", \\\"{x:1451,y:754,t:1527272319619};\\\", \\\"{x:1465,y:764,t:1527272319636};\\\", \\\"{x:1478,y:776,t:1527272319653};\\\", \\\"{x:1481,y:780,t:1527272319670};\\\", \\\"{x:1486,y:785,t:1527272319687};\\\", \\\"{x:1490,y:789,t:1527272319702};\\\", \\\"{x:1492,y:792,t:1527272319720};\\\", \\\"{x:1493,y:794,t:1527272319737};\\\", \\\"{x:1494,y:795,t:1527272319753};\\\", \\\"{x:1494,y:796,t:1527272319776};\\\", \\\"{x:1494,y:797,t:1527272319787};\\\", \\\"{x:1496,y:802,t:1527272319804};\\\", \\\"{x:1496,y:804,t:1527272319821};\\\", \\\"{x:1496,y:809,t:1527272319837};\\\", \\\"{x:1496,y:810,t:1527272319854};\\\", \\\"{x:1495,y:816,t:1527272319871};\\\", \\\"{x:1487,y:828,t:1527272319887};\\\", \\\"{x:1468,y:838,t:1527272319904};\\\", \\\"{x:1457,y:840,t:1527272319920};\\\", \\\"{x:1437,y:844,t:1527272319937};\\\", \\\"{x:1411,y:847,t:1527272319954};\\\", \\\"{x:1384,y:847,t:1527272319971};\\\", \\\"{x:1363,y:847,t:1527272319988};\\\", \\\"{x:1348,y:847,t:1527272320004};\\\", \\\"{x:1340,y:847,t:1527272320021};\\\", \\\"{x:1337,y:847,t:1527272320037};\\\", \\\"{x:1336,y:847,t:1527272320054};\\\", \\\"{x:1335,y:847,t:1527272320144};\\\", \\\"{x:1339,y:843,t:1527272320160};\\\", \\\"{x:1348,y:840,t:1527272320171};\\\", \\\"{x:1361,y:834,t:1527272320188};\\\", \\\"{x:1386,y:829,t:1527272320204};\\\", \\\"{x:1411,y:829,t:1527272320221};\\\", \\\"{x:1438,y:829,t:1527272320238};\\\", \\\"{x:1459,y:829,t:1527272320255};\\\", \\\"{x:1470,y:835,t:1527272320271};\\\", \\\"{x:1479,y:838,t:1527272320289};\\\", \\\"{x:1480,y:838,t:1527272320305};\\\", \\\"{x:1481,y:838,t:1527272320641};\\\", \\\"{x:1481,y:837,t:1527272320656};\\\", \\\"{x:1472,y:834,t:1527272320673};\\\", \\\"{x:1467,y:834,t:1527272320689};\\\", \\\"{x:1464,y:834,t:1527272320706};\\\", \\\"{x:1463,y:834,t:1527272320722};\\\", \\\"{x:1463,y:833,t:1527272320785};\\\", \\\"{x:1464,y:833,t:1527272320856};\\\", \\\"{x:1477,y:837,t:1527272320873};\\\", \\\"{x:1488,y:843,t:1527272320889};\\\", \\\"{x:1497,y:847,t:1527272320907};\\\", \\\"{x:1505,y:850,t:1527272320923};\\\", \\\"{x:1510,y:854,t:1527272320940};\\\", \\\"{x:1521,y:859,t:1527272320956};\\\", \\\"{x:1533,y:861,t:1527272320973};\\\", \\\"{x:1537,y:865,t:1527272320990};\\\", \\\"{x:1543,y:867,t:1527272321006};\\\", \\\"{x:1547,y:868,t:1527272321022};\\\", \\\"{x:1551,y:868,t:1527272321039};\\\", \\\"{x:1552,y:868,t:1527272321056};\\\", \\\"{x:1553,y:867,t:1527272321072};\\\", \\\"{x:1555,y:865,t:1527272321090};\\\", \\\"{x:1557,y:864,t:1527272321107};\\\", \\\"{x:1559,y:858,t:1527272321123};\\\", \\\"{x:1564,y:851,t:1527272321140};\\\", \\\"{x:1564,y:848,t:1527272321156};\\\", \\\"{x:1565,y:843,t:1527272321173};\\\", \\\"{x:1566,y:837,t:1527272321190};\\\", \\\"{x:1566,y:833,t:1527272321207};\\\", \\\"{x:1566,y:829,t:1527272321223};\\\", \\\"{x:1563,y:823,t:1527272321240};\\\", \\\"{x:1563,y:822,t:1527272321272};\\\", \\\"{x:1563,y:825,t:1527272321361};\\\", \\\"{x:1563,y:830,t:1527272321374};\\\", \\\"{x:1566,y:839,t:1527272321392};\\\", \\\"{x:1572,y:847,t:1527272321408};\\\", \\\"{x:1585,y:855,t:1527272321424};\\\", \\\"{x:1592,y:858,t:1527272321441};\\\", \\\"{x:1596,y:858,t:1527272321457};\\\", \\\"{x:1596,y:859,t:1527272321474};\\\", \\\"{x:1598,y:859,t:1527272321537};\\\", \\\"{x:1600,y:859,t:1527272321545};\\\", \\\"{x:1604,y:857,t:1527272321559};\\\", \\\"{x:1611,y:850,t:1527272321574};\\\", \\\"{x:1617,y:846,t:1527272321592};\\\", \\\"{x:1621,y:839,t:1527272321608};\\\", \\\"{x:1621,y:836,t:1527272321625};\\\", \\\"{x:1621,y:835,t:1527272321642};\\\", \\\"{x:1621,y:834,t:1527272321658};\\\", \\\"{x:1621,y:833,t:1527272321737};\\\", \\\"{x:1620,y:833,t:1527272321745};\\\", \\\"{x:1616,y:833,t:1527272321758};\\\", \\\"{x:1599,y:833,t:1527272321776};\\\", \\\"{x:1558,y:835,t:1527272321791};\\\", \\\"{x:1403,y:822,t:1527272321808};\\\", \\\"{x:1230,y:813,t:1527272321825};\\\", \\\"{x:1050,y:776,t:1527272321841};\\\", \\\"{x:865,y:726,t:1527272321858};\\\", \\\"{x:677,y:676,t:1527272321875};\\\", \\\"{x:517,y:629,t:1527272321893};\\\", \\\"{x:386,y:586,t:1527272321908};\\\", \\\"{x:328,y:563,t:1527272321924};\\\", \\\"{x:323,y:557,t:1527272321944};\\\", \\\"{x:322,y:554,t:1527272321961};\\\", \\\"{x:322,y:547,t:1527272321977};\\\", \\\"{x:322,y:540,t:1527272321993};\\\", \\\"{x:324,y:538,t:1527272322010};\\\", \\\"{x:327,y:533,t:1527272322028};\\\", \\\"{x:328,y:530,t:1527272322043};\\\", \\\"{x:331,y:524,t:1527272322061};\\\", \\\"{x:336,y:513,t:1527272322078};\\\", \\\"{x:352,y:497,t:1527272322094};\\\", \\\"{x:365,y:477,t:1527272322112};\\\", \\\"{x:375,y:472,t:1527272322126};\\\", \\\"{x:403,y:460,t:1527272322144};\\\", \\\"{x:411,y:456,t:1527272322160};\\\", \\\"{x:415,y:452,t:1527272322177};\\\", \\\"{x:416,y:452,t:1527272322194};\\\", \\\"{x:421,y:451,t:1527272322210};\\\", \\\"{x:425,y:449,t:1527272322227};\\\", \\\"{x:429,y:449,t:1527272322336};\\\", \\\"{x:432,y:452,t:1527272322352};\\\", \\\"{x:439,y:459,t:1527272322360};\\\", \\\"{x:448,y:471,t:1527272322377};\\\", \\\"{x:454,y:486,t:1527272322394};\\\", \\\"{x:455,y:504,t:1527272322412};\\\", \\\"{x:455,y:519,t:1527272322428};\\\", \\\"{x:446,y:530,t:1527272322444};\\\", \\\"{x:435,y:538,t:1527272322460};\\\", \\\"{x:426,y:544,t:1527272322478};\\\", \\\"{x:417,y:548,t:1527272322494};\\\", \\\"{x:414,y:551,t:1527272322511};\\\", \\\"{x:412,y:553,t:1527272322527};\\\", \\\"{x:411,y:554,t:1527272322544};\\\", \\\"{x:411,y:557,t:1527272322561};\\\", \\\"{x:416,y:564,t:1527272322577};\\\", \\\"{x:423,y:569,t:1527272322595};\\\", \\\"{x:441,y:569,t:1527272322610};\\\", \\\"{x:463,y:569,t:1527272322628};\\\", \\\"{x:484,y:569,t:1527272322645};\\\", \\\"{x:513,y:569,t:1527272322661};\\\", \\\"{x:535,y:569,t:1527272322678};\\\", \\\"{x:555,y:569,t:1527272322695};\\\", \\\"{x:562,y:569,t:1527272322711};\\\", \\\"{x:563,y:569,t:1527272322784};\\\", \\\"{x:565,y:569,t:1527272322816};\\\", \\\"{x:566,y:570,t:1527272322832};\\\", \\\"{x:567,y:571,t:1527272322845};\\\", \\\"{x:569,y:573,t:1527272322861};\\\", \\\"{x:571,y:578,t:1527272322878};\\\", \\\"{x:573,y:581,t:1527272322895};\\\", \\\"{x:574,y:583,t:1527272322912};\\\", \\\"{x:574,y:584,t:1527272322935};\\\", \\\"{x:575,y:584,t:1527272322951};\\\", \\\"{x:576,y:585,t:1527272322962};\\\", \\\"{x:577,y:587,t:1527272322979};\\\", \\\"{x:579,y:587,t:1527272322995};\\\", \\\"{x:580,y:587,t:1527272323012};\\\", \\\"{x:584,y:587,t:1527272323029};\\\", \\\"{x:589,y:587,t:1527272323045};\\\", \\\"{x:594,y:588,t:1527272323062};\\\", \\\"{x:597,y:590,t:1527272323079};\\\", \\\"{x:599,y:590,t:1527272323096};\\\", \\\"{x:603,y:586,t:1527272323114};\\\", \\\"{x:606,y:585,t:1527272323129};\\\", \\\"{x:606,y:584,t:1527272323399};\\\", \\\"{x:607,y:584,t:1527272323423};\\\", \\\"{x:609,y:583,t:1527272323704};\\\", \\\"{x:613,y:581,t:1527272323712};\\\", \\\"{x:628,y:574,t:1527272323733};\\\", \\\"{x:648,y:567,t:1527272323745};\\\", \\\"{x:660,y:562,t:1527272323762};\\\", \\\"{x:733,y:560,t:1527272323779};\\\", \\\"{x:833,y:558,t:1527272323794};\\\", \\\"{x:952,y:558,t:1527272323811};\\\", \\\"{x:1088,y:558,t:1527272323829};\\\", \\\"{x:1196,y:558,t:1527272323845};\\\", \\\"{x:1344,y:549,t:1527272323862};\\\", \\\"{x:1450,y:529,t:1527272323879};\\\", \\\"{x:1483,y:518,t:1527272323894};\\\", \\\"{x:1520,y:511,t:1527272323912};\\\", \\\"{x:1524,y:509,t:1527272323928};\\\", \\\"{x:1526,y:508,t:1527272323945};\\\", \\\"{x:1527,y:508,t:1527272324024};\\\", \\\"{x:1524,y:517,t:1527272326657};\\\", \\\"{x:1514,y:526,t:1527272326664};\\\", \\\"{x:1499,y:540,t:1527272326682};\\\", \\\"{x:1493,y:546,t:1527272326698};\\\", \\\"{x:1487,y:551,t:1527272326714};\\\", \\\"{x:1485,y:553,t:1527272326731};\\\", \\\"{x:1483,y:556,t:1527272326748};\\\", \\\"{x:1482,y:557,t:1527272326764};\\\", \\\"{x:1480,y:558,t:1527272326782};\\\", \\\"{x:1480,y:559,t:1527272326798};\\\", \\\"{x:1479,y:560,t:1527272326815};\\\", \\\"{x:1479,y:561,t:1527272326832};\\\", \\\"{x:1478,y:561,t:1527272326881};\\\", \\\"{x:1475,y:562,t:1527272326897};\\\", \\\"{x:1468,y:564,t:1527272326915};\\\", \\\"{x:1462,y:568,t:1527272326931};\\\", \\\"{x:1446,y:568,t:1527272326948};\\\", \\\"{x:1423,y:568,t:1527272326965};\\\", \\\"{x:1396,y:568,t:1527272326981};\\\", \\\"{x:1377,y:568,t:1527272326998};\\\", \\\"{x:1365,y:568,t:1527272327014};\\\", \\\"{x:1351,y:568,t:1527272327031};\\\", \\\"{x:1339,y:568,t:1527272327047};\\\", \\\"{x:1327,y:570,t:1527272327064};\\\", \\\"{x:1323,y:570,t:1527272327081};\\\", \\\"{x:1322,y:570,t:1527272327099};\\\", \\\"{x:1321,y:571,t:1527272327368};\\\", \\\"{x:1323,y:572,t:1527272327384};\\\", \\\"{x:1327,y:573,t:1527272327399};\\\", \\\"{x:1334,y:575,t:1527272327415};\\\", \\\"{x:1338,y:576,t:1527272327431};\\\", \\\"{x:1341,y:577,t:1527272327449};\\\", \\\"{x:1342,y:577,t:1527272327497};\\\", \\\"{x:1344,y:577,t:1527272327505};\\\", \\\"{x:1346,y:577,t:1527272327514};\\\", \\\"{x:1348,y:577,t:1527272327531};\\\", \\\"{x:1355,y:577,t:1527272327548};\\\", \\\"{x:1357,y:577,t:1527272327565};\\\", \\\"{x:1366,y:576,t:1527272327581};\\\", \\\"{x:1375,y:574,t:1527272327598};\\\", \\\"{x:1378,y:574,t:1527272327615};\\\", \\\"{x:1382,y:574,t:1527272327631};\\\", \\\"{x:1389,y:573,t:1527272327647};\\\", \\\"{x:1392,y:573,t:1527272327665};\\\", \\\"{x:1392,y:572,t:1527272327681};\\\", \\\"{x:1394,y:572,t:1527272327698};\\\", \\\"{x:1395,y:572,t:1527272327715};\\\", \\\"{x:1396,y:571,t:1527272327731};\\\", \\\"{x:1398,y:569,t:1527272327776};\\\", \\\"{x:1399,y:569,t:1527272327784};\\\", \\\"{x:1400,y:569,t:1527272327798};\\\", \\\"{x:1402,y:567,t:1527272327815};\\\", \\\"{x:1404,y:566,t:1527272327831};\\\", \\\"{x:1407,y:564,t:1527272327848};\\\", \\\"{x:1408,y:564,t:1527272327865};\\\", \\\"{x:1410,y:564,t:1527272328041};\\\", \\\"{x:1412,y:564,t:1527272328072};\\\", \\\"{x:1414,y:564,t:1527272328081};\\\", \\\"{x:1421,y:565,t:1527272328099};\\\", \\\"{x:1428,y:566,t:1527272328116};\\\", \\\"{x:1435,y:568,t:1527272328132};\\\", \\\"{x:1439,y:569,t:1527272328149};\\\", \\\"{x:1442,y:569,t:1527272328166};\\\", \\\"{x:1444,y:570,t:1527272328181};\\\", \\\"{x:1445,y:571,t:1527272328199};\\\", \\\"{x:1449,y:572,t:1527272328216};\\\", \\\"{x:1450,y:572,t:1527272328233};\\\", \\\"{x:1452,y:572,t:1527272328248};\\\", \\\"{x:1453,y:572,t:1527272328266};\\\", \\\"{x:1456,y:572,t:1527272328282};\\\", \\\"{x:1459,y:572,t:1527272328298};\\\", \\\"{x:1460,y:572,t:1527272328316};\\\", \\\"{x:1461,y:571,t:1527272328352};\\\", \\\"{x:1462,y:571,t:1527272328366};\\\", \\\"{x:1464,y:569,t:1527272328383};\\\", \\\"{x:1465,y:569,t:1527272328398};\\\", \\\"{x:1467,y:567,t:1527272328416};\\\", \\\"{x:1468,y:567,t:1527272328432};\\\", \\\"{x:1469,y:567,t:1527272328449};\\\", \\\"{x:1470,y:567,t:1527272328520};\\\", \\\"{x:1472,y:567,t:1527272328532};\\\", \\\"{x:1473,y:567,t:1527272328549};\\\", \\\"{x:1475,y:566,t:1527272328565};\\\", \\\"{x:1477,y:565,t:1527272328584};\\\", \\\"{x:1479,y:565,t:1527272328599};\\\", \\\"{x:1481,y:565,t:1527272328625};\\\", \\\"{x:1482,y:565,t:1527272328745};\\\", \\\"{x:1483,y:565,t:1527272328775};\\\", \\\"{x:1483,y:566,t:1527272328783};\\\", \\\"{x:1484,y:569,t:1527272328798};\\\", \\\"{x:1485,y:572,t:1527272328814};\\\", \\\"{x:1488,y:579,t:1527272328831};\\\", \\\"{x:1490,y:581,t:1527272328848};\\\", \\\"{x:1490,y:584,t:1527272328864};\\\", \\\"{x:1491,y:585,t:1527272328881};\\\", \\\"{x:1492,y:585,t:1527272328899};\\\", \\\"{x:1493,y:585,t:1527272328915};\\\", \\\"{x:1494,y:585,t:1527272328943};\\\", \\\"{x:1496,y:585,t:1527272328959};\\\", \\\"{x:1499,y:585,t:1527272328967};\\\", \\\"{x:1502,y:585,t:1527272328982};\\\", \\\"{x:1507,y:585,t:1527272328999};\\\", \\\"{x:1513,y:585,t:1527272329014};\\\", \\\"{x:1518,y:585,t:1527272329032};\\\", \\\"{x:1521,y:585,t:1527272329049};\\\", \\\"{x:1524,y:584,t:1527272329065};\\\", \\\"{x:1526,y:581,t:1527272329082};\\\", \\\"{x:1529,y:581,t:1527272329099};\\\", \\\"{x:1534,y:578,t:1527272329115};\\\", \\\"{x:1539,y:577,t:1527272329132};\\\", \\\"{x:1542,y:575,t:1527272329149};\\\", \\\"{x:1546,y:573,t:1527272329165};\\\", \\\"{x:1549,y:572,t:1527272329182};\\\", \\\"{x:1552,y:571,t:1527272329199};\\\", \\\"{x:1556,y:568,t:1527272329216};\\\", \\\"{x:1557,y:568,t:1527272329232};\\\", \\\"{x:1559,y:567,t:1527272329250};\\\", \\\"{x:1560,y:567,t:1527272329266};\\\", \\\"{x:1561,y:565,t:1527272329283};\\\", \\\"{x:1562,y:565,t:1527272329300};\\\", \\\"{x:1563,y:565,t:1527272329472};\\\", \\\"{x:1564,y:565,t:1527272329483};\\\", \\\"{x:1567,y:570,t:1527272329500};\\\", \\\"{x:1573,y:578,t:1527272329516};\\\", \\\"{x:1576,y:583,t:1527272329532};\\\", \\\"{x:1579,y:586,t:1527272329549};\\\", \\\"{x:1580,y:587,t:1527272329566};\\\", \\\"{x:1581,y:587,t:1527272329582};\\\", \\\"{x:1583,y:587,t:1527272329599};\\\", \\\"{x:1588,y:587,t:1527272329615};\\\", \\\"{x:1592,y:587,t:1527272329632};\\\", \\\"{x:1595,y:587,t:1527272329649};\\\", \\\"{x:1600,y:587,t:1527272329666};\\\", \\\"{x:1601,y:587,t:1527272329687};\\\", \\\"{x:1603,y:587,t:1527272329699};\\\", \\\"{x:1604,y:585,t:1527272329716};\\\", \\\"{x:1606,y:584,t:1527272329732};\\\", \\\"{x:1608,y:582,t:1527272329750};\\\", \\\"{x:1612,y:578,t:1527272329767};\\\", \\\"{x:1614,y:577,t:1527272329784};\\\", \\\"{x:1616,y:572,t:1527272329800};\\\", \\\"{x:1617,y:570,t:1527272329816};\\\", \\\"{x:1617,y:569,t:1527272329834};\\\", \\\"{x:1617,y:568,t:1527272329850};\\\", \\\"{x:1618,y:567,t:1527272329953};\\\", \\\"{x:1618,y:566,t:1527272329967};\\\", \\\"{x:1618,y:565,t:1527272329984};\\\", \\\"{x:1619,y:564,t:1527272329999};\\\", \\\"{x:1620,y:561,t:1527272330016};\\\", \\\"{x:1621,y:560,t:1527272330040};\\\", \\\"{x:1621,y:561,t:1527272330120};\\\", \\\"{x:1621,y:564,t:1527272330134};\\\", \\\"{x:1621,y:568,t:1527272330150};\\\", \\\"{x:1621,y:571,t:1527272330166};\\\", \\\"{x:1623,y:573,t:1527272330200};\\\", \\\"{x:1628,y:573,t:1527272330216};\\\", \\\"{x:1633,y:573,t:1527272330234};\\\", \\\"{x:1639,y:571,t:1527272330251};\\\", \\\"{x:1644,y:570,t:1527272330267};\\\", \\\"{x:1649,y:570,t:1527272330283};\\\", \\\"{x:1651,y:569,t:1527272330300};\\\", \\\"{x:1653,y:566,t:1527272330317};\\\", \\\"{x:1653,y:565,t:1527272330385};\\\", \\\"{x:1601,y:551,t:1527272330400};\\\", \\\"{x:1513,y:541,t:1527272330417};\\\", \\\"{x:1403,y:529,t:1527272330434};\\\", \\\"{x:1292,y:517,t:1527272330451};\\\", \\\"{x:1199,y:509,t:1527272330466};\\\", \\\"{x:1177,y:505,t:1527272330484};\\\", \\\"{x:1146,y:507,t:1527272330501};\\\", \\\"{x:1126,y:515,t:1527272330515};\\\", \\\"{x:1120,y:519,t:1527272330533};\\\", \\\"{x:1117,y:519,t:1527272330550};\\\", \\\"{x:1104,y:522,t:1527272330566};\\\", \\\"{x:1091,y:532,t:1527272330583};\\\", \\\"{x:1029,y:550,t:1527272330599};\\\", \\\"{x:974,y:563,t:1527272330616};\\\", \\\"{x:924,y:577,t:1527272330633};\\\", \\\"{x:891,y:585,t:1527272330650};\\\", \\\"{x:863,y:592,t:1527272330666};\\\", \\\"{x:844,y:598,t:1527272330684};\\\", \\\"{x:825,y:605,t:1527272330701};\\\", \\\"{x:802,y:615,t:1527272330717};\\\", \\\"{x:776,y:624,t:1527272330734};\\\", \\\"{x:733,y:636,t:1527272330752};\\\", \\\"{x:713,y:645,t:1527272330767};\\\", \\\"{x:689,y:652,t:1527272330783};\\\", \\\"{x:668,y:659,t:1527272330801};\\\", \\\"{x:662,y:665,t:1527272330817};\\\", \\\"{x:661,y:666,t:1527272330833};\\\", \\\"{x:652,y:669,t:1527272330851};\\\", \\\"{x:644,y:672,t:1527272330868};\\\", \\\"{x:636,y:675,t:1527272330884};\\\", \\\"{x:633,y:676,t:1527272330901};\\\", \\\"{x:627,y:679,t:1527272330918};\\\", \\\"{x:625,y:680,t:1527272330934};\\\", \\\"{x:624,y:682,t:1527272330951};\\\", \\\"{x:623,y:683,t:1527272330975};\\\", \\\"{x:621,y:684,t:1527272330983};\\\", \\\"{x:616,y:684,t:1527272331002};\\\", \\\"{x:613,y:684,t:1527272331019};\\\", \\\"{x:605,y:686,t:1527272331034};\\\", \\\"{x:600,y:686,t:1527272331051};\\\", \\\"{x:589,y:688,t:1527272331069};\\\", \\\"{x:587,y:688,t:1527272331084};\\\", \\\"{x:586,y:688,t:1527272331101};\\\", \\\"{x:584,y:688,t:1527272331118};\\\", \\\"{x:582,y:689,t:1527272331135};\\\", \\\"{x:580,y:691,t:1527272331152};\\\", \\\"{x:567,y:698,t:1527272331167};\\\", \\\"{x:558,y:704,t:1527272331184};\\\", \\\"{x:552,y:709,t:1527272331201};\\\", \\\"{x:545,y:716,t:1527272331218};\\\", \\\"{x:541,y:719,t:1527272331234};\\\", \\\"{x:536,y:724,t:1527272331252};\\\", \\\"{x:532,y:730,t:1527272331268};\\\", \\\"{x:528,y:734,t:1527272331284};\\\", \\\"{x:524,y:739,t:1527272331301};\\\", \\\"{x:523,y:743,t:1527272331318};\\\", \\\"{x:521,y:746,t:1527272331334};\\\", \\\"{x:520,y:747,t:1527272331351};\\\", \\\"{x:519,y:747,t:1527272331368};\\\", \\\"{x:519,y:749,t:1527272331385};\\\", \\\"{x:518,y:749,t:1527272331407};\\\", \\\"{x:518,y:750,t:1527272331435};\\\", \\\"{x:518,y:750,t:1527272331534};\\\" ] }, { \\\"rt\\\": 44273, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 794662, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-I -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:748,t:1527272333067};\\\", \\\"{x:521,y:747,t:1527272333086};\\\", \\\"{x:523,y:746,t:1527272333169};\\\", \\\"{x:524,y:744,t:1527272333215};\\\", \\\"{x:525,y:743,t:1527272333223};\\\", \\\"{x:535,y:727,t:1527272333336};\\\", \\\"{x:536,y:727,t:1527272333352};\\\", \\\"{x:537,y:727,t:1527272333368};\\\", \\\"{x:538,y:724,t:1527272333386};\\\", \\\"{x:539,y:723,t:1527272333406};\\\", \\\"{x:540,y:723,t:1527272333431};\\\", \\\"{x:541,y:722,t:1527272333439};\\\", \\\"{x:541,y:720,t:1527272333840};\\\", \\\"{x:541,y:718,t:1527272333865};\\\", \\\"{x:542,y:717,t:1527272333886};\\\", \\\"{x:542,y:716,t:1527272333927};\\\", \\\"{x:543,y:714,t:1527272333937};\\\", \\\"{x:543,y:713,t:1527272333953};\\\", \\\"{x:543,y:710,t:1527272333970};\\\", \\\"{x:543,y:706,t:1527272333987};\\\", \\\"{x:544,y:699,t:1527272334003};\\\", \\\"{x:547,y:690,t:1527272334020};\\\", \\\"{x:549,y:683,t:1527272334037};\\\", \\\"{x:549,y:679,t:1527272334053};\\\", \\\"{x:553,y:673,t:1527272334070};\\\", \\\"{x:554,y:661,t:1527272334088};\\\", \\\"{x:554,y:654,t:1527272334103};\\\", \\\"{x:554,y:643,t:1527272334120};\\\", \\\"{x:554,y:637,t:1527272334137};\\\", \\\"{x:554,y:633,t:1527272334153};\\\", \\\"{x:553,y:632,t:1527272334170};\\\", \\\"{x:552,y:630,t:1527272334188};\\\", \\\"{x:552,y:629,t:1527272334223};\\\", \\\"{x:553,y:628,t:1527272334256};\\\", \\\"{x:553,y:626,t:1527272334296};\\\", \\\"{x:554,y:625,t:1527272334335};\\\", \\\"{x:554,y:624,t:1527272334343};\\\", \\\"{x:555,y:623,t:1527272334353};\\\", \\\"{x:556,y:623,t:1527272334371};\\\", \\\"{x:565,y:623,t:1527272334728};\\\", \\\"{x:610,y:623,t:1527272334738};\\\", \\\"{x:707,y:631,t:1527272334754};\\\", \\\"{x:806,y:641,t:1527272334772};\\\", \\\"{x:908,y:651,t:1527272334787};\\\", \\\"{x:980,y:673,t:1527272334804};\\\", \\\"{x:1088,y:687,t:1527272334821};\\\", \\\"{x:1182,y:698,t:1527272334837};\\\", \\\"{x:1240,y:711,t:1527272334854};\\\", \\\"{x:1251,y:714,t:1527272334871};\\\", \\\"{x:1255,y:714,t:1527272334887};\\\", \\\"{x:1256,y:715,t:1527272335088};\\\", \\\"{x:1276,y:732,t:1527272335104};\\\", \\\"{x:1314,y:762,t:1527272335122};\\\", \\\"{x:1332,y:782,t:1527272335137};\\\", \\\"{x:1354,y:804,t:1527272335155};\\\", \\\"{x:1374,y:822,t:1527272335171};\\\", \\\"{x:1399,y:846,t:1527272335188};\\\", \\\"{x:1433,y:870,t:1527272335205};\\\", \\\"{x:1450,y:881,t:1527272335221};\\\", \\\"{x:1457,y:888,t:1527272335238};\\\", \\\"{x:1460,y:887,t:1527272335255};\\\", \\\"{x:1473,y:887,t:1527272335272};\\\", \\\"{x:1477,y:887,t:1527272335289};\\\", \\\"{x:1478,y:887,t:1527272335312};\\\", \\\"{x:1479,y:887,t:1527272335336};\\\", \\\"{x:1480,y:887,t:1527272335344};\\\", \\\"{x:1482,y:887,t:1527272335360};\\\", \\\"{x:1483,y:887,t:1527272335372};\\\", \\\"{x:1493,y:885,t:1527272335389};\\\", \\\"{x:1498,y:885,t:1527272335405};\\\", \\\"{x:1505,y:883,t:1527272335422};\\\", \\\"{x:1508,y:883,t:1527272335439};\\\", \\\"{x:1515,y:883,t:1527272335455};\\\", \\\"{x:1524,y:883,t:1527272335472};\\\", \\\"{x:1533,y:887,t:1527272335488};\\\", \\\"{x:1543,y:896,t:1527272335505};\\\", \\\"{x:1548,y:901,t:1527272335522};\\\", \\\"{x:1555,y:911,t:1527272335539};\\\", \\\"{x:1561,y:918,t:1527272335555};\\\", \\\"{x:1561,y:921,t:1527272335571};\\\", \\\"{x:1562,y:924,t:1527272335589};\\\", \\\"{x:1562,y:926,t:1527272335605};\\\", \\\"{x:1562,y:931,t:1527272335622};\\\", \\\"{x:1561,y:937,t:1527272335639};\\\", \\\"{x:1560,y:942,t:1527272335655};\\\", \\\"{x:1556,y:947,t:1527272335672};\\\", \\\"{x:1554,y:948,t:1527272335688};\\\", \\\"{x:1552,y:950,t:1527272335705};\\\", \\\"{x:1548,y:950,t:1527272335722};\\\", \\\"{x:1547,y:950,t:1527272336192};\\\", \\\"{x:1546,y:949,t:1527272336205};\\\", \\\"{x:1546,y:948,t:1527272336223};\\\", \\\"{x:1546,y:947,t:1527272336239};\\\", \\\"{x:1546,y:945,t:1527272336256};\\\", \\\"{x:1546,y:944,t:1527272336544};\\\", \\\"{x:1546,y:942,t:1527272336556};\\\", \\\"{x:1546,y:937,t:1527272336572};\\\", \\\"{x:1546,y:933,t:1527272336588};\\\", \\\"{x:1545,y:927,t:1527272336605};\\\", \\\"{x:1544,y:922,t:1527272336622};\\\", \\\"{x:1544,y:911,t:1527272336639};\\\", \\\"{x:1549,y:899,t:1527272336655};\\\", \\\"{x:1552,y:886,t:1527272336672};\\\", \\\"{x:1552,y:879,t:1527272336689};\\\", \\\"{x:1553,y:873,t:1527272336705};\\\", \\\"{x:1553,y:864,t:1527272336723};\\\", \\\"{x:1555,y:858,t:1527272336740};\\\", \\\"{x:1556,y:852,t:1527272336755};\\\", \\\"{x:1559,y:842,t:1527272336772};\\\", \\\"{x:1564,y:833,t:1527272336789};\\\", \\\"{x:1567,y:828,t:1527272336805};\\\", \\\"{x:1567,y:824,t:1527272336823};\\\", \\\"{x:1570,y:812,t:1527272336840};\\\", \\\"{x:1576,y:794,t:1527272336856};\\\", \\\"{x:1576,y:780,t:1527272336873};\\\", \\\"{x:1576,y:764,t:1527272336890};\\\", \\\"{x:1577,y:741,t:1527272336905};\\\", \\\"{x:1577,y:720,t:1527272336923};\\\", \\\"{x:1571,y:703,t:1527272336940};\\\", \\\"{x:1561,y:683,t:1527272336956};\\\", \\\"{x:1557,y:673,t:1527272336972};\\\", \\\"{x:1556,y:669,t:1527272336990};\\\", \\\"{x:1556,y:667,t:1527272337006};\\\", \\\"{x:1556,y:662,t:1527272337023};\\\", \\\"{x:1558,y:648,t:1527272337039};\\\", \\\"{x:1559,y:639,t:1527272337056};\\\", \\\"{x:1560,y:621,t:1527272337073};\\\", \\\"{x:1563,y:611,t:1527272337090};\\\", \\\"{x:1563,y:608,t:1527272337106};\\\", \\\"{x:1563,y:607,t:1527272337123};\\\", \\\"{x:1563,y:605,t:1527272337140};\\\", \\\"{x:1570,y:586,t:1527272337156};\\\", \\\"{x:1574,y:577,t:1527272337172};\\\", \\\"{x:1575,y:572,t:1527272337190};\\\", \\\"{x:1577,y:563,t:1527272337208};\\\", \\\"{x:1583,y:553,t:1527272337223};\\\", \\\"{x:1583,y:548,t:1527272337240};\\\", \\\"{x:1583,y:544,t:1527272337255};\\\", \\\"{x:1583,y:541,t:1527272337273};\\\", \\\"{x:1583,y:540,t:1527272337290};\\\", \\\"{x:1583,y:538,t:1527272337307};\\\", \\\"{x:1583,y:535,t:1527272337323};\\\", \\\"{x:1580,y:522,t:1527272337340};\\\", \\\"{x:1577,y:515,t:1527272337357};\\\", \\\"{x:1575,y:512,t:1527272337373};\\\", \\\"{x:1573,y:508,t:1527272337390};\\\", \\\"{x:1569,y:503,t:1527272337407};\\\", \\\"{x:1562,y:494,t:1527272337422};\\\", \\\"{x:1557,y:489,t:1527272337440};\\\", \\\"{x:1556,y:488,t:1527272337513};\\\", \\\"{x:1556,y:487,t:1527272337528};\\\", \\\"{x:1554,y:487,t:1527272337540};\\\", \\\"{x:1553,y:487,t:1527272337632};\\\", \\\"{x:1552,y:487,t:1527272337639};\\\", \\\"{x:1551,y:487,t:1527272338457};\\\", \\\"{x:1550,y:487,t:1527272338488};\\\", \\\"{x:1549,y:487,t:1527272338496};\\\", \\\"{x:1548,y:488,t:1527272338507};\\\", \\\"{x:1542,y:491,t:1527272338524};\\\", \\\"{x:1525,y:495,t:1527272338541};\\\", \\\"{x:1507,y:498,t:1527272338558};\\\", \\\"{x:1487,y:502,t:1527272338574};\\\", \\\"{x:1479,y:505,t:1527272338591};\\\", \\\"{x:1411,y:506,t:1527272338608};\\\", \\\"{x:1338,y:508,t:1527272338624};\\\", \\\"{x:1272,y:511,t:1527272338641};\\\", \\\"{x:1179,y:504,t:1527272338658};\\\", \\\"{x:1083,y:500,t:1527272338674};\\\", \\\"{x:1053,y:497,t:1527272338691};\\\", \\\"{x:1036,y:498,t:1527272338708};\\\", \\\"{x:1034,y:498,t:1527272338724};\\\", \\\"{x:1032,y:498,t:1527272338960};\\\", \\\"{x:1031,y:498,t:1527272338973};\\\", \\\"{x:1027,y:501,t:1527272338991};\\\", \\\"{x:1019,y:503,t:1527272339008};\\\", \\\"{x:1015,y:506,t:1527272339024};\\\", \\\"{x:1012,y:508,t:1527272339041};\\\", \\\"{x:1011,y:508,t:1527272339058};\\\", \\\"{x:1010,y:508,t:1527272339075};\\\", \\\"{x:1009,y:508,t:1527272339169};\\\", \\\"{x:1009,y:509,t:1527272339184};\\\", \\\"{x:1008,y:509,t:1527272339192};\\\", \\\"{x:1006,y:509,t:1527272339208};\\\", \\\"{x:1005,y:511,t:1527272339224};\\\", \\\"{x:1004,y:511,t:1527272339256};\\\", \\\"{x:1003,y:512,t:1527272340585};\\\", \\\"{x:1001,y:513,t:1527272340591};\\\", \\\"{x:1000,y:513,t:1527272340608};\\\", \\\"{x:999,y:513,t:1527272340640};\\\", \\\"{x:997,y:513,t:1527272340648};\\\", \\\"{x:994,y:513,t:1527272340658};\\\", \\\"{x:993,y:513,t:1527272340676};\\\", \\\"{x:989,y:513,t:1527272340692};\\\", \\\"{x:986,y:513,t:1527272340709};\\\", \\\"{x:984,y:513,t:1527272340726};\\\", \\\"{x:981,y:514,t:1527272340742};\\\", \\\"{x:977,y:515,t:1527272340759};\\\", \\\"{x:972,y:515,t:1527272340776};\\\", \\\"{x:970,y:515,t:1527272340792};\\\", \\\"{x:969,y:515,t:1527272340816};\\\", \\\"{x:974,y:516,t:1527272341232};\\\", \\\"{x:981,y:516,t:1527272341244};\\\", \\\"{x:992,y:517,t:1527272341259};\\\", \\\"{x:1006,y:519,t:1527272341276};\\\", \\\"{x:1023,y:526,t:1527272341293};\\\", \\\"{x:1051,y:536,t:1527272341309};\\\", \\\"{x:1088,y:545,t:1527272341326};\\\", \\\"{x:1119,y:559,t:1527272341343};\\\", \\\"{x:1148,y:576,t:1527272341360};\\\", \\\"{x:1217,y:597,t:1527272341376};\\\", \\\"{x:1234,y:599,t:1527272341393};\\\", \\\"{x:1252,y:605,t:1527272341409};\\\", \\\"{x:1278,y:608,t:1527272341426};\\\", \\\"{x:1299,y:609,t:1527272341443};\\\", \\\"{x:1311,y:610,t:1527272341460};\\\", \\\"{x:1321,y:612,t:1527272341476};\\\", \\\"{x:1329,y:612,t:1527272341493};\\\", \\\"{x:1332,y:612,t:1527272341510};\\\", \\\"{x:1337,y:612,t:1527272341526};\\\", \\\"{x:1339,y:612,t:1527272341543};\\\", \\\"{x:1343,y:612,t:1527272341560};\\\", \\\"{x:1340,y:612,t:1527272341665};\\\", \\\"{x:1339,y:611,t:1527272341676};\\\", \\\"{x:1333,y:608,t:1527272341694};\\\", \\\"{x:1328,y:605,t:1527272341710};\\\", \\\"{x:1323,y:601,t:1527272341726};\\\", \\\"{x:1320,y:599,t:1527272341743};\\\", \\\"{x:1319,y:598,t:1527272341760};\\\", \\\"{x:1318,y:598,t:1527272341776};\\\", \\\"{x:1317,y:598,t:1527272342008};\\\", \\\"{x:1316,y:598,t:1527272342016};\\\", \\\"{x:1315,y:598,t:1527272342027};\\\", \\\"{x:1314,y:598,t:1527272342043};\\\", \\\"{x:1311,y:599,t:1527272342060};\\\", \\\"{x:1310,y:599,t:1527272342077};\\\", \\\"{x:1308,y:599,t:1527272342096};\\\", \\\"{x:1304,y:599,t:1527272342110};\\\", \\\"{x:1297,y:599,t:1527272342127};\\\", \\\"{x:1294,y:599,t:1527272342143};\\\", \\\"{x:1285,y:597,t:1527272342160};\\\", \\\"{x:1274,y:592,t:1527272342177};\\\", \\\"{x:1262,y:586,t:1527272342193};\\\", \\\"{x:1247,y:578,t:1527272342210};\\\", \\\"{x:1240,y:573,t:1527272342227};\\\", \\\"{x:1236,y:572,t:1527272342243};\\\", \\\"{x:1236,y:571,t:1527272342260};\\\", \\\"{x:1235,y:571,t:1527272342321};\\\", \\\"{x:1235,y:570,t:1527272342327};\\\", \\\"{x:1235,y:569,t:1527272342344};\\\", \\\"{x:1238,y:567,t:1527272342359};\\\", \\\"{x:1240,y:566,t:1527272342377};\\\", \\\"{x:1242,y:565,t:1527272342394};\\\", \\\"{x:1243,y:564,t:1527272342410};\\\", \\\"{x:1244,y:564,t:1527272342427};\\\", \\\"{x:1246,y:562,t:1527272342472};\\\", \\\"{x:1249,y:562,t:1527272342504};\\\", \\\"{x:1252,y:563,t:1527272342512};\\\", \\\"{x:1256,y:565,t:1527272342528};\\\", \\\"{x:1263,y:571,t:1527272342544};\\\", \\\"{x:1267,y:575,t:1527272342559};\\\", \\\"{x:1274,y:582,t:1527272342577};\\\", \\\"{x:1281,y:588,t:1527272342593};\\\", \\\"{x:1292,y:596,t:1527272342609};\\\", \\\"{x:1296,y:599,t:1527272342626};\\\", \\\"{x:1305,y:603,t:1527272342643};\\\", \\\"{x:1310,y:605,t:1527272342660};\\\", \\\"{x:1314,y:605,t:1527272342676};\\\", \\\"{x:1319,y:607,t:1527272342694};\\\", \\\"{x:1326,y:609,t:1527272342709};\\\", \\\"{x:1331,y:611,t:1527272342727};\\\", \\\"{x:1334,y:612,t:1527272342744};\\\", \\\"{x:1336,y:612,t:1527272342768};\\\", \\\"{x:1337,y:612,t:1527272342784};\\\", \\\"{x:1338,y:611,t:1527272342794};\\\", \\\"{x:1340,y:611,t:1527272342809};\\\", \\\"{x:1343,y:609,t:1527272342827};\\\", \\\"{x:1346,y:603,t:1527272342844};\\\", \\\"{x:1350,y:598,t:1527272342859};\\\", \\\"{x:1352,y:588,t:1527272342877};\\\", \\\"{x:1353,y:577,t:1527272342894};\\\", \\\"{x:1353,y:572,t:1527272342911};\\\", \\\"{x:1353,y:567,t:1527272342928};\\\", \\\"{x:1348,y:561,t:1527272342944};\\\", \\\"{x:1347,y:559,t:1527272342961};\\\", \\\"{x:1345,y:557,t:1527272342977};\\\", \\\"{x:1342,y:557,t:1527272343073};\\\", \\\"{x:1341,y:559,t:1527272343080};\\\", \\\"{x:1340,y:562,t:1527272343094};\\\", \\\"{x:1341,y:566,t:1527272343111};\\\", \\\"{x:1345,y:573,t:1527272343127};\\\", \\\"{x:1352,y:582,t:1527272343144};\\\", \\\"{x:1358,y:591,t:1527272343161};\\\", \\\"{x:1364,y:599,t:1527272343177};\\\", \\\"{x:1369,y:606,t:1527272343195};\\\", \\\"{x:1371,y:607,t:1527272343212};\\\", \\\"{x:1372,y:608,t:1527272343228};\\\", \\\"{x:1373,y:609,t:1527272343256};\\\", \\\"{x:1374,y:609,t:1527272343272};\\\", \\\"{x:1375,y:609,t:1527272343280};\\\", \\\"{x:1377,y:608,t:1527272343294};\\\", \\\"{x:1385,y:604,t:1527272343312};\\\", \\\"{x:1399,y:594,t:1527272343328};\\\", \\\"{x:1409,y:586,t:1527272343344};\\\", \\\"{x:1419,y:578,t:1527272343361};\\\", \\\"{x:1426,y:573,t:1527272343378};\\\", \\\"{x:1430,y:568,t:1527272343394};\\\", \\\"{x:1431,y:567,t:1527272343411};\\\", \\\"{x:1433,y:565,t:1527272343428};\\\", \\\"{x:1433,y:566,t:1527272343576};\\\", \\\"{x:1433,y:567,t:1527272343584};\\\", \\\"{x:1432,y:568,t:1527272343594};\\\", \\\"{x:1430,y:571,t:1527272343611};\\\", \\\"{x:1430,y:576,t:1527272343628};\\\", \\\"{x:1433,y:582,t:1527272343644};\\\", \\\"{x:1435,y:586,t:1527272343661};\\\", \\\"{x:1439,y:589,t:1527272343678};\\\", \\\"{x:1441,y:591,t:1527272343695};\\\", \\\"{x:1441,y:594,t:1527272343711};\\\", \\\"{x:1444,y:599,t:1527272343728};\\\", \\\"{x:1449,y:604,t:1527272343744};\\\", \\\"{x:1450,y:604,t:1527272343761};\\\", \\\"{x:1452,y:604,t:1527272343792};\\\", \\\"{x:1453,y:604,t:1527272343808};\\\", \\\"{x:1454,y:604,t:1527272343816};\\\", \\\"{x:1455,y:603,t:1527272343828};\\\", \\\"{x:1458,y:600,t:1527272343845};\\\", \\\"{x:1462,y:597,t:1527272343862};\\\", \\\"{x:1467,y:593,t:1527272343879};\\\", \\\"{x:1478,y:585,t:1527272343895};\\\", \\\"{x:1494,y:573,t:1527272343912};\\\", \\\"{x:1501,y:566,t:1527272343928};\\\", \\\"{x:1506,y:562,t:1527272343945};\\\", \\\"{x:1510,y:559,t:1527272343962};\\\", \\\"{x:1511,y:558,t:1527272343978};\\\", \\\"{x:1511,y:561,t:1527272344192};\\\", \\\"{x:1512,y:563,t:1527272344201};\\\", \\\"{x:1513,y:567,t:1527272344212};\\\", \\\"{x:1516,y:578,t:1527272344228};\\\", \\\"{x:1519,y:588,t:1527272344245};\\\", \\\"{x:1523,y:595,t:1527272344262};\\\", \\\"{x:1524,y:597,t:1527272344278};\\\", \\\"{x:1525,y:599,t:1527272344296};\\\", \\\"{x:1526,y:600,t:1527272344311};\\\", \\\"{x:1527,y:600,t:1527272344360};\\\", \\\"{x:1528,y:600,t:1527272344368};\\\", \\\"{x:1529,y:600,t:1527272344384};\\\", \\\"{x:1531,y:600,t:1527272344395};\\\", \\\"{x:1533,y:600,t:1527272344412};\\\", \\\"{x:1533,y:599,t:1527272344428};\\\", \\\"{x:1534,y:598,t:1527272344445};\\\", \\\"{x:1535,y:598,t:1527272344463};\\\", \\\"{x:1537,y:596,t:1527272344479};\\\", \\\"{x:1539,y:594,t:1527272344495};\\\", \\\"{x:1544,y:590,t:1527272344512};\\\", \\\"{x:1547,y:585,t:1527272344528};\\\", \\\"{x:1548,y:582,t:1527272344544};\\\", \\\"{x:1550,y:578,t:1527272344561};\\\", \\\"{x:1550,y:575,t:1527272344577};\\\", \\\"{x:1550,y:573,t:1527272344594};\\\", \\\"{x:1550,y:572,t:1527272344612};\\\", \\\"{x:1550,y:571,t:1527272344751};\\\", \\\"{x:1549,y:573,t:1527272344761};\\\", \\\"{x:1548,y:584,t:1527272344778};\\\", \\\"{x:1548,y:601,t:1527272344795};\\\", \\\"{x:1548,y:623,t:1527272344812};\\\", \\\"{x:1551,y:646,t:1527272344829};\\\", \\\"{x:1557,y:674,t:1527272344845};\\\", \\\"{x:1559,y:699,t:1527272344861};\\\", \\\"{x:1567,y:726,t:1527272344879};\\\", \\\"{x:1574,y:750,t:1527272344895};\\\", \\\"{x:1575,y:772,t:1527272344912};\\\", \\\"{x:1575,y:790,t:1527272344929};\\\", \\\"{x:1573,y:811,t:1527272344945};\\\", \\\"{x:1572,y:821,t:1527272344962};\\\", \\\"{x:1572,y:830,t:1527272344979};\\\", \\\"{x:1572,y:842,t:1527272344995};\\\", \\\"{x:1570,y:850,t:1527272345012};\\\", \\\"{x:1569,y:857,t:1527272345028};\\\", \\\"{x:1565,y:866,t:1527272345045};\\\", \\\"{x:1563,y:870,t:1527272345061};\\\", \\\"{x:1563,y:874,t:1527272345078};\\\", \\\"{x:1560,y:880,t:1527272345095};\\\", \\\"{x:1559,y:888,t:1527272345112};\\\", \\\"{x:1556,y:893,t:1527272345129};\\\", \\\"{x:1549,y:908,t:1527272345145};\\\", \\\"{x:1544,y:919,t:1527272345162};\\\", \\\"{x:1539,y:929,t:1527272345179};\\\", \\\"{x:1537,y:935,t:1527272345195};\\\", \\\"{x:1536,y:941,t:1527272345212};\\\", \\\"{x:1535,y:944,t:1527272345229};\\\", \\\"{x:1534,y:944,t:1527272345264};\\\", \\\"{x:1534,y:946,t:1527272345321};\\\", \\\"{x:1533,y:947,t:1527272345336};\\\", \\\"{x:1533,y:948,t:1527272345346};\\\", \\\"{x:1533,y:949,t:1527272345362};\\\", \\\"{x:1533,y:950,t:1527272345400};\\\", \\\"{x:1533,y:951,t:1527272345412};\\\", \\\"{x:1533,y:952,t:1527272345464};\\\", \\\"{x:1533,y:953,t:1527272345488};\\\", \\\"{x:1533,y:955,t:1527272345552};\\\", \\\"{x:1534,y:955,t:1527272345575};\\\", \\\"{x:1536,y:956,t:1527272345592};\\\", \\\"{x:1536,y:957,t:1527272345600};\\\", \\\"{x:1538,y:958,t:1527272345616};\\\", \\\"{x:1538,y:956,t:1527272345776};\\\", \\\"{x:1538,y:952,t:1527272345783};\\\", \\\"{x:1538,y:946,t:1527272345796};\\\", \\\"{x:1542,y:933,t:1527272345813};\\\", \\\"{x:1542,y:925,t:1527272345829};\\\", \\\"{x:1542,y:916,t:1527272345846};\\\", \\\"{x:1542,y:905,t:1527272345863};\\\", \\\"{x:1549,y:888,t:1527272345880};\\\", \\\"{x:1551,y:877,t:1527272345896};\\\", \\\"{x:1555,y:867,t:1527272345913};\\\", \\\"{x:1557,y:857,t:1527272345929};\\\", \\\"{x:1560,y:847,t:1527272345946};\\\", \\\"{x:1561,y:838,t:1527272345963};\\\", \\\"{x:1561,y:832,t:1527272345979};\\\", \\\"{x:1564,y:824,t:1527272345996};\\\", \\\"{x:1566,y:820,t:1527272346013};\\\", \\\"{x:1566,y:818,t:1527272346029};\\\", \\\"{x:1568,y:816,t:1527272346046};\\\", \\\"{x:1568,y:813,t:1527272346063};\\\", \\\"{x:1568,y:809,t:1527272346079};\\\", \\\"{x:1568,y:808,t:1527272346095};\\\", \\\"{x:1566,y:808,t:1527272346168};\\\", \\\"{x:1565,y:808,t:1527272346179};\\\", \\\"{x:1562,y:809,t:1527272346197};\\\", \\\"{x:1558,y:813,t:1527272346213};\\\", \\\"{x:1558,y:821,t:1527272346230};\\\", \\\"{x:1558,y:831,t:1527272346246};\\\", \\\"{x:1555,y:850,t:1527272346264};\\\", \\\"{x:1552,y:855,t:1527272346279};\\\", \\\"{x:1549,y:873,t:1527272346296};\\\", \\\"{x:1549,y:882,t:1527272346314};\\\", \\\"{x:1549,y:891,t:1527272346330};\\\", \\\"{x:1549,y:903,t:1527272346346};\\\", \\\"{x:1548,y:909,t:1527272346362};\\\", \\\"{x:1547,y:918,t:1527272346379};\\\", \\\"{x:1547,y:922,t:1527272346396};\\\", \\\"{x:1547,y:924,t:1527272346487};\\\", \\\"{x:1547,y:925,t:1527272346503};\\\", \\\"{x:1547,y:926,t:1527272346544};\\\", \\\"{x:1547,y:927,t:1527272346551};\\\", \\\"{x:1547,y:928,t:1527272346563};\\\", \\\"{x:1547,y:929,t:1527272346591};\\\", \\\"{x:1547,y:931,t:1527272346616};\\\", \\\"{x:1547,y:932,t:1527272346688};\\\", \\\"{x:1547,y:929,t:1527272346833};\\\", \\\"{x:1549,y:921,t:1527272346847};\\\", \\\"{x:1551,y:900,t:1527272346864};\\\", \\\"{x:1551,y:889,t:1527272346880};\\\", \\\"{x:1552,y:880,t:1527272346897};\\\", \\\"{x:1554,y:876,t:1527272346913};\\\", \\\"{x:1559,y:868,t:1527272346930};\\\", \\\"{x:1564,y:860,t:1527272346948};\\\", \\\"{x:1570,y:853,t:1527272346963};\\\", \\\"{x:1573,y:847,t:1527272346981};\\\", \\\"{x:1578,y:839,t:1527272346998};\\\", \\\"{x:1581,y:830,t:1527272347013};\\\", \\\"{x:1582,y:824,t:1527272347031};\\\", \\\"{x:1582,y:817,t:1527272347047};\\\", \\\"{x:1582,y:806,t:1527272347064};\\\", \\\"{x:1582,y:800,t:1527272347080};\\\", \\\"{x:1580,y:793,t:1527272347097};\\\", \\\"{x:1580,y:790,t:1527272347114};\\\", \\\"{x:1579,y:786,t:1527272347131};\\\", \\\"{x:1577,y:781,t:1527272347147};\\\", \\\"{x:1573,y:777,t:1527272347164};\\\", \\\"{x:1569,y:771,t:1527272347180};\\\", \\\"{x:1567,y:770,t:1527272347197};\\\", \\\"{x:1567,y:769,t:1527272347216};\\\", \\\"{x:1567,y:768,t:1527272347231};\\\", \\\"{x:1566,y:768,t:1527272347247};\\\", \\\"{x:1564,y:766,t:1527272347345};\\\", \\\"{x:1563,y:765,t:1527272347368};\\\", \\\"{x:1562,y:764,t:1527272347380};\\\", \\\"{x:1562,y:763,t:1527272347398};\\\", \\\"{x:1560,y:760,t:1527272347417};\\\", \\\"{x:1559,y:759,t:1527272347430};\\\", \\\"{x:1556,y:756,t:1527272347447};\\\", \\\"{x:1553,y:755,t:1527272347465};\\\", \\\"{x:1550,y:753,t:1527272347480};\\\", \\\"{x:1549,y:753,t:1527272347497};\\\", \\\"{x:1547,y:752,t:1527272347704};\\\", \\\"{x:1547,y:749,t:1527272347714};\\\", \\\"{x:1545,y:740,t:1527272347732};\\\", \\\"{x:1544,y:737,t:1527272347747};\\\", \\\"{x:1543,y:734,t:1527272347764};\\\", \\\"{x:1543,y:730,t:1527272347782};\\\", \\\"{x:1542,y:728,t:1527272347797};\\\", \\\"{x:1541,y:727,t:1527272347815};\\\", \\\"{x:1541,y:725,t:1527272347831};\\\", \\\"{x:1541,y:722,t:1527272347848};\\\", \\\"{x:1541,y:720,t:1527272347864};\\\", \\\"{x:1541,y:718,t:1527272347896};\\\", \\\"{x:1541,y:717,t:1527272347915};\\\", \\\"{x:1541,y:716,t:1527272347932};\\\", \\\"{x:1541,y:715,t:1527272347947};\\\", \\\"{x:1541,y:714,t:1527272347964};\\\", \\\"{x:1541,y:712,t:1527272347981};\\\", \\\"{x:1541,y:711,t:1527272347997};\\\", \\\"{x:1541,y:710,t:1527272348016};\\\", \\\"{x:1541,y:709,t:1527272348032};\\\", \\\"{x:1541,y:708,t:1527272348104};\\\", \\\"{x:1541,y:707,t:1527272348136};\\\", \\\"{x:1541,y:706,t:1527272348154};\\\", \\\"{x:1541,y:705,t:1527272348164};\\\", \\\"{x:1542,y:704,t:1527272348181};\\\", \\\"{x:1542,y:703,t:1527272348198};\\\", \\\"{x:1544,y:702,t:1527272348214};\\\", \\\"{x:1544,y:700,t:1527272348231};\\\", \\\"{x:1542,y:700,t:1527272348568};\\\", \\\"{x:1541,y:700,t:1527272348592};\\\", \\\"{x:1540,y:700,t:1527272348608};\\\", \\\"{x:1538,y:701,t:1527272348624};\\\", \\\"{x:1537,y:701,t:1527272348631};\\\", \\\"{x:1525,y:702,t:1527272348648};\\\", \\\"{x:1509,y:702,t:1527272348665};\\\", \\\"{x:1492,y:704,t:1527272348681};\\\", \\\"{x:1477,y:704,t:1527272348699};\\\", \\\"{x:1455,y:704,t:1527272348715};\\\", \\\"{x:1435,y:703,t:1527272348731};\\\", \\\"{x:1419,y:702,t:1527272348748};\\\", \\\"{x:1411,y:700,t:1527272348765};\\\", \\\"{x:1405,y:700,t:1527272348781};\\\", \\\"{x:1394,y:700,t:1527272348799};\\\", \\\"{x:1388,y:700,t:1527272348816};\\\", \\\"{x:1385,y:700,t:1527272348832};\\\", \\\"{x:1385,y:699,t:1527272349112};\\\", \\\"{x:1386,y:699,t:1527272349169};\\\", \\\"{x:1387,y:700,t:1527272349281};\\\", \\\"{x:1389,y:700,t:1527272349287};\\\", \\\"{x:1392,y:701,t:1527272349298};\\\", \\\"{x:1398,y:707,t:1527272349315};\\\", \\\"{x:1408,y:712,t:1527272349333};\\\", \\\"{x:1422,y:719,t:1527272349349};\\\", \\\"{x:1432,y:723,t:1527272349365};\\\", \\\"{x:1440,y:725,t:1527272349382};\\\", \\\"{x:1442,y:725,t:1527272349399};\\\", \\\"{x:1443,y:725,t:1527272349415};\\\", \\\"{x:1447,y:724,t:1527272349432};\\\", \\\"{x:1448,y:723,t:1527272349448};\\\", \\\"{x:1451,y:722,t:1527272349466};\\\", \\\"{x:1453,y:720,t:1527272349482};\\\", \\\"{x:1454,y:719,t:1527272349499};\\\", \\\"{x:1456,y:719,t:1527272349527};\\\", \\\"{x:1456,y:718,t:1527272349535};\\\", \\\"{x:1457,y:718,t:1527272349548};\\\", \\\"{x:1457,y:717,t:1527272349564};\\\", \\\"{x:1458,y:717,t:1527272349581};\\\", \\\"{x:1459,y:717,t:1527272349598};\\\", \\\"{x:1460,y:716,t:1527272349647};\\\", \\\"{x:1459,y:716,t:1527272349792};\\\", \\\"{x:1459,y:718,t:1527272349800};\\\", \\\"{x:1459,y:722,t:1527272349816};\\\", \\\"{x:1460,y:729,t:1527272349833};\\\", \\\"{x:1463,y:736,t:1527272349850};\\\", \\\"{x:1466,y:738,t:1527272349865};\\\", \\\"{x:1466,y:742,t:1527272349882};\\\", \\\"{x:1468,y:742,t:1527272349927};\\\", \\\"{x:1469,y:742,t:1527272349953};\\\", \\\"{x:1472,y:742,t:1527272350040};\\\", \\\"{x:1477,y:740,t:1527272350049};\\\", \\\"{x:1484,y:735,t:1527272350066};\\\", \\\"{x:1487,y:732,t:1527272350083};\\\", \\\"{x:1491,y:729,t:1527272350100};\\\", \\\"{x:1491,y:728,t:1527272350116};\\\", \\\"{x:1499,y:728,t:1527272350744};\\\", \\\"{x:1505,y:729,t:1527272350753};\\\", \\\"{x:1513,y:729,t:1527272350766};\\\", \\\"{x:1527,y:730,t:1527272350783};\\\", \\\"{x:1537,y:729,t:1527272350800};\\\", \\\"{x:1545,y:727,t:1527272350816};\\\", \\\"{x:1557,y:721,t:1527272350834};\\\", \\\"{x:1567,y:715,t:1527272350850};\\\", \\\"{x:1572,y:711,t:1527272350866};\\\", \\\"{x:1579,y:704,t:1527272350883};\\\", \\\"{x:1588,y:695,t:1527272350899};\\\", \\\"{x:1593,y:685,t:1527272350917};\\\", \\\"{x:1599,y:678,t:1527272350934};\\\", \\\"{x:1600,y:672,t:1527272350950};\\\", \\\"{x:1601,y:670,t:1527272350966};\\\", \\\"{x:1602,y:666,t:1527272350983};\\\", \\\"{x:1602,y:665,t:1527272350999};\\\", \\\"{x:1601,y:663,t:1527272351016};\\\", \\\"{x:1601,y:662,t:1527272351095};\\\", \\\"{x:1599,y:662,t:1527272351103};\\\", \\\"{x:1598,y:662,t:1527272351115};\\\", \\\"{x:1594,y:662,t:1527272351360};\\\", \\\"{x:1588,y:662,t:1527272351368};\\\", \\\"{x:1581,y:662,t:1527272351384};\\\", \\\"{x:1580,y:663,t:1527272351399};\\\", \\\"{x:1579,y:663,t:1527272351480};\\\", \\\"{x:1578,y:664,t:1527272351487};\\\", \\\"{x:1576,y:664,t:1527272351511};\\\", \\\"{x:1575,y:664,t:1527272351528};\\\", \\\"{x:1574,y:664,t:1527272351576};\\\", \\\"{x:1573,y:664,t:1527272351591};\\\", \\\"{x:1572,y:664,t:1527272351600};\\\", \\\"{x:1566,y:662,t:1527272351618};\\\", \\\"{x:1558,y:656,t:1527272351634};\\\", \\\"{x:1557,y:656,t:1527272351651};\\\", \\\"{x:1552,y:652,t:1527272351668};\\\", \\\"{x:1549,y:650,t:1527272351683};\\\", \\\"{x:1547,y:650,t:1527272351700};\\\", \\\"{x:1545,y:648,t:1527272351717};\\\", \\\"{x:1542,y:647,t:1527272351733};\\\", \\\"{x:1541,y:645,t:1527272351750};\\\", \\\"{x:1533,y:641,t:1527272351767};\\\", \\\"{x:1529,y:638,t:1527272351783};\\\", \\\"{x:1524,y:635,t:1527272351801};\\\", \\\"{x:1517,y:631,t:1527272351818};\\\", \\\"{x:1499,y:629,t:1527272351833};\\\", \\\"{x:1485,y:627,t:1527272351850};\\\", \\\"{x:1472,y:625,t:1527272351867};\\\", \\\"{x:1464,y:624,t:1527272351883};\\\", \\\"{x:1459,y:624,t:1527272351900};\\\", \\\"{x:1459,y:623,t:1527272351918};\\\", \\\"{x:1459,y:625,t:1527272352872};\\\", \\\"{x:1459,y:626,t:1527272352887};\\\", \\\"{x:1458,y:627,t:1527272352901};\\\", \\\"{x:1457,y:628,t:1527272352920};\\\", \\\"{x:1456,y:629,t:1527272353200};\\\", \\\"{x:1453,y:633,t:1527272353219};\\\", \\\"{x:1451,y:640,t:1527272353235};\\\", \\\"{x:1447,y:645,t:1527272353252};\\\", \\\"{x:1447,y:647,t:1527272353268};\\\", \\\"{x:1445,y:649,t:1527272353285};\\\", \\\"{x:1444,y:651,t:1527272353302};\\\", \\\"{x:1443,y:652,t:1527272353319};\\\", \\\"{x:1441,y:653,t:1527272353408};\\\", \\\"{x:1440,y:656,t:1527272353418};\\\", \\\"{x:1437,y:659,t:1527272353436};\\\", \\\"{x:1434,y:662,t:1527272353452};\\\", \\\"{x:1430,y:665,t:1527272353469};\\\", \\\"{x:1424,y:675,t:1527272353485};\\\", \\\"{x:1417,y:685,t:1527272353502};\\\", \\\"{x:1404,y:695,t:1527272353518};\\\", \\\"{x:1375,y:732,t:1527272353535};\\\", \\\"{x:1346,y:772,t:1527272353552};\\\", \\\"{x:1326,y:793,t:1527272353568};\\\", \\\"{x:1314,y:803,t:1527272353586};\\\", \\\"{x:1304,y:810,t:1527272353602};\\\", \\\"{x:1298,y:814,t:1527272353619};\\\", \\\"{x:1295,y:817,t:1527272353635};\\\", \\\"{x:1293,y:820,t:1527272353651};\\\", \\\"{x:1291,y:824,t:1527272353669};\\\", \\\"{x:1289,y:825,t:1527272353685};\\\", \\\"{x:1286,y:829,t:1527272353702};\\\", \\\"{x:1283,y:834,t:1527272353718};\\\", \\\"{x:1282,y:839,t:1527272353736};\\\", \\\"{x:1282,y:840,t:1527272353753};\\\", \\\"{x:1282,y:841,t:1527272353769};\\\", \\\"{x:1281,y:842,t:1527272353816};\\\", \\\"{x:1280,y:844,t:1527272353831};\\\", \\\"{x:1279,y:845,t:1527272353872};\\\", \\\"{x:1278,y:846,t:1527272353885};\\\", \\\"{x:1276,y:846,t:1527272353903};\\\", \\\"{x:1272,y:847,t:1527272353918};\\\", \\\"{x:1257,y:847,t:1527272353936};\\\", \\\"{x:1239,y:843,t:1527272353954};\\\", \\\"{x:1223,y:836,t:1527272353968};\\\", \\\"{x:1202,y:825,t:1527272353986};\\\", \\\"{x:1197,y:825,t:1527272354003};\\\", \\\"{x:1166,y:815,t:1527272354018};\\\", \\\"{x:1150,y:807,t:1527272354036};\\\", \\\"{x:1130,y:801,t:1527272354053};\\\", \\\"{x:1086,y:787,t:1527272354068};\\\", \\\"{x:1034,y:768,t:1527272354085};\\\", \\\"{x:1007,y:756,t:1527272354102};\\\", \\\"{x:983,y:748,t:1527272354118};\\\", \\\"{x:949,y:736,t:1527272354136};\\\", \\\"{x:930,y:731,t:1527272354153};\\\", \\\"{x:912,y:724,t:1527272354168};\\\", \\\"{x:897,y:720,t:1527272354185};\\\", \\\"{x:879,y:710,t:1527272354203};\\\", \\\"{x:868,y:699,t:1527272354218};\\\", \\\"{x:838,y:692,t:1527272354236};\\\", \\\"{x:804,y:680,t:1527272354253};\\\", \\\"{x:772,y:670,t:1527272354269};\\\", \\\"{x:746,y:664,t:1527272354286};\\\", \\\"{x:717,y:661,t:1527272354302};\\\", \\\"{x:684,y:653,t:1527272354319};\\\", \\\"{x:669,y:652,t:1527272354335};\\\", \\\"{x:659,y:651,t:1527272354353};\\\", \\\"{x:655,y:650,t:1527272354370};\\\", \\\"{x:655,y:649,t:1527272354464};\\\", \\\"{x:656,y:648,t:1527272354472};\\\", \\\"{x:663,y:645,t:1527272354485};\\\", \\\"{x:669,y:642,t:1527272354503};\\\", \\\"{x:687,y:638,t:1527272354519};\\\", \\\"{x:695,y:638,t:1527272354535};\\\", \\\"{x:705,y:640,t:1527272354552};\\\", \\\"{x:737,y:651,t:1527272354569};\\\", \\\"{x:777,y:666,t:1527272354585};\\\", \\\"{x:819,y:683,t:1527272354603};\\\", \\\"{x:859,y:704,t:1527272354620};\\\", \\\"{x:890,y:715,t:1527272354635};\\\", \\\"{x:917,y:722,t:1527272354652};\\\", \\\"{x:935,y:726,t:1527272354669};\\\", \\\"{x:943,y:729,t:1527272354686};\\\", \\\"{x:946,y:729,t:1527272354702};\\\", \\\"{x:950,y:730,t:1527272354719};\\\", \\\"{x:956,y:730,t:1527272354735};\\\", \\\"{x:967,y:732,t:1527272354753};\\\", \\\"{x:979,y:735,t:1527272354769};\\\", \\\"{x:1001,y:741,t:1527272354787};\\\", \\\"{x:1022,y:749,t:1527272354802};\\\", \\\"{x:1041,y:757,t:1527272354820};\\\", \\\"{x:1051,y:760,t:1527272354836};\\\", \\\"{x:1060,y:763,t:1527272354852};\\\", \\\"{x:1063,y:764,t:1527272354869};\\\", \\\"{x:1064,y:764,t:1527272354945};\\\", \\\"{x:1064,y:763,t:1527272354967};\\\", \\\"{x:1066,y:763,t:1527272354992};\\\", \\\"{x:1068,y:763,t:1527272355002};\\\", \\\"{x:1074,y:763,t:1527272355020};\\\", \\\"{x:1082,y:763,t:1527272355037};\\\", \\\"{x:1092,y:763,t:1527272355053};\\\", \\\"{x:1095,y:763,t:1527272355070};\\\", \\\"{x:1107,y:763,t:1527272355087};\\\", \\\"{x:1120,y:765,t:1527272355103};\\\", \\\"{x:1131,y:768,t:1527272355120};\\\", \\\"{x:1132,y:768,t:1527272355209};\\\", \\\"{x:1135,y:768,t:1527272355220};\\\", \\\"{x:1139,y:768,t:1527272355236};\\\", \\\"{x:1142,y:770,t:1527272355254};\\\", \\\"{x:1148,y:772,t:1527272355269};\\\", \\\"{x:1152,y:773,t:1527272355286};\\\", \\\"{x:1154,y:773,t:1527272355304};\\\", \\\"{x:1155,y:774,t:1527272355432};\\\", \\\"{x:1156,y:774,t:1527272355447};\\\", \\\"{x:1157,y:774,t:1527272355456};\\\", \\\"{x:1158,y:774,t:1527272355470};\\\", \\\"{x:1163,y:772,t:1527272355486};\\\", \\\"{x:1167,y:770,t:1527272355503};\\\", \\\"{x:1169,y:769,t:1527272355520};\\\", \\\"{x:1172,y:769,t:1527272355537};\\\", \\\"{x:1176,y:768,t:1527272355553};\\\", \\\"{x:1179,y:766,t:1527272355572};\\\", \\\"{x:1183,y:765,t:1527272355586};\\\", \\\"{x:1186,y:763,t:1527272355602};\\\", \\\"{x:1186,y:761,t:1527272355623};\\\", \\\"{x:1188,y:761,t:1527272355760};\\\", \\\"{x:1189,y:761,t:1527272355791};\\\", \\\"{x:1190,y:761,t:1527272355848};\\\", \\\"{x:1192,y:762,t:1527272355856};\\\", \\\"{x:1192,y:763,t:1527272357240};\\\", \\\"{x:1191,y:764,t:1527272374642};\\\", \\\"{x:1180,y:764,t:1527272374652};\\\", \\\"{x:1121,y:764,t:1527272374670};\\\", \\\"{x:1027,y:764,t:1527272374687};\\\", \\\"{x:919,y:763,t:1527272374703};\\\", \\\"{x:809,y:755,t:1527272374720};\\\", \\\"{x:750,y:750,t:1527272374737};\\\", \\\"{x:733,y:750,t:1527272374755};\\\", \\\"{x:726,y:749,t:1527272374915};\\\", \\\"{x:715,y:747,t:1527272374922};\\\", \\\"{x:710,y:743,t:1527272374938};\\\", \\\"{x:625,y:728,t:1527272374956};\\\", \\\"{x:512,y:697,t:1527272374970};\\\", \\\"{x:412,y:667,t:1527272374989};\\\", \\\"{x:370,y:651,t:1527272375004};\\\", \\\"{x:355,y:642,t:1527272375020};\\\", \\\"{x:352,y:641,t:1527272375039};\\\", \\\"{x:351,y:640,t:1527272375057};\\\", \\\"{x:351,y:639,t:1527272375072};\\\", \\\"{x:351,y:638,t:1527272375203};\\\", \\\"{x:351,y:636,t:1527272375233};\\\", \\\"{x:360,y:634,t:1527272375242};\\\", \\\"{x:372,y:634,t:1527272375257};\\\", \\\"{x:393,y:633,t:1527272375273};\\\", \\\"{x:421,y:631,t:1527272375291};\\\", \\\"{x:449,y:628,t:1527272375307};\\\", \\\"{x:467,y:624,t:1527272375323};\\\", \\\"{x:475,y:623,t:1527272375340};\\\", \\\"{x:479,y:621,t:1527272375357};\\\", \\\"{x:480,y:621,t:1527272375372};\\\", \\\"{x:484,y:619,t:1527272375389};\\\", \\\"{x:491,y:614,t:1527272375407};\\\", \\\"{x:503,y:604,t:1527272375424};\\\", \\\"{x:516,y:596,t:1527272375441};\\\", \\\"{x:530,y:588,t:1527272375458};\\\", \\\"{x:542,y:579,t:1527272375472};\\\", \\\"{x:549,y:574,t:1527272375489};\\\", \\\"{x:555,y:571,t:1527272375507};\\\", \\\"{x:561,y:568,t:1527272375523};\\\", \\\"{x:565,y:567,t:1527272375539};\\\", \\\"{x:568,y:566,t:1527272375557};\\\", \\\"{x:569,y:566,t:1527272375573};\\\", \\\"{x:570,y:566,t:1527272376027};\\\", \\\"{x:571,y:566,t:1527272376040};\\\", \\\"{x:572,y:566,t:1527272376356};\\\", \\\"{x:575,y:566,t:1527272376362};\\\", \\\"{x:581,y:568,t:1527272376375};\\\", \\\"{x:586,y:572,t:1527272376391};\\\", \\\"{x:593,y:573,t:1527272376407};\\\", \\\"{x:607,y:574,t:1527272376425};\\\", \\\"{x:611,y:575,t:1527272376441};\\\", \\\"{x:611,y:576,t:1527272376456};\\\", \\\"{x:610,y:580,t:1527272376697};\\\", \\\"{x:606,y:590,t:1527272376708};\\\", \\\"{x:575,y:619,t:1527272376724};\\\", \\\"{x:530,y:649,t:1527272376742};\\\", \\\"{x:500,y:672,t:1527272376758};\\\", \\\"{x:491,y:677,t:1527272376774};\\\", \\\"{x:479,y:680,t:1527272376791};\\\", \\\"{x:469,y:686,t:1527272376808};\\\", \\\"{x:462,y:691,t:1527272376823};\\\", \\\"{x:457,y:695,t:1527272376841};\\\", \\\"{x:449,y:705,t:1527272376857};\\\", \\\"{x:448,y:707,t:1527272376874};\\\", \\\"{x:450,y:708,t:1527272376994};\\\", \\\"{x:456,y:708,t:1527272377008};\\\", \\\"{x:462,y:707,t:1527272377025};\\\", \\\"{x:467,y:707,t:1527272377041};\\\", \\\"{x:473,y:708,t:1527272377059};\\\", \\\"{x:476,y:709,t:1527272377074};\\\", \\\"{x:479,y:712,t:1527272377091};\\\", \\\"{x:480,y:712,t:1527272377108};\\\", \\\"{x:483,y:717,t:1527272377125};\\\", \\\"{x:486,y:724,t:1527272377142};\\\", \\\"{x:488,y:731,t:1527272377158};\\\", \\\"{x:490,y:735,t:1527272377174};\\\", \\\"{x:492,y:738,t:1527272377190};\\\", \\\"{x:492,y:739,t:1527272377208};\\\", \\\"{x:492,y:741,t:1527272377682};\\\", \\\"{x:493,y:743,t:1527272378418};\\\" ] }, { \\\"rt\\\": 48702, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 844584, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -B -02 PM-02 PM-M -X -X -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:743,t:1527272379843};\\\", \\\"{x:496,y:743,t:1527272379859};\\\", \\\"{x:497,y:742,t:1527272379877};\\\", \\\"{x:500,y:741,t:1527272379892};\\\", \\\"{x:505,y:737,t:1527272379909};\\\", \\\"{x:514,y:733,t:1527272379927};\\\", \\\"{x:526,y:726,t:1527272379942};\\\", \\\"{x:542,y:717,t:1527272379959};\\\", \\\"{x:550,y:714,t:1527272379977};\\\", \\\"{x:558,y:711,t:1527272379993};\\\", \\\"{x:605,y:700,t:1527272380010};\\\", \\\"{x:639,y:697,t:1527272380026};\\\", \\\"{x:684,y:692,t:1527272380043};\\\", \\\"{x:729,y:693,t:1527272380060};\\\", \\\"{x:799,y:693,t:1527272380077};\\\", \\\"{x:877,y:693,t:1527272380093};\\\", \\\"{x:920,y:693,t:1527272380110};\\\", \\\"{x:976,y:693,t:1527272380128};\\\", \\\"{x:983,y:693,t:1527272380144};\\\", \\\"{x:998,y:693,t:1527272380160};\\\", \\\"{x:1004,y:693,t:1527272380177};\\\", \\\"{x:1015,y:695,t:1527272380394};\\\", \\\"{x:1030,y:702,t:1527272380410};\\\", \\\"{x:1090,y:714,t:1527272380427};\\\", \\\"{x:1179,y:727,t:1527272380444};\\\", \\\"{x:1298,y:743,t:1527272380460};\\\", \\\"{x:1387,y:757,t:1527272380477};\\\", \\\"{x:1426,y:760,t:1527272380494};\\\", \\\"{x:1428,y:761,t:1527272380511};\\\", \\\"{x:1429,y:762,t:1527272381307};\\\", \\\"{x:1429,y:764,t:1527272381314};\\\", \\\"{x:1426,y:770,t:1527272381327};\\\", \\\"{x:1419,y:781,t:1527272381345};\\\", \\\"{x:1413,y:787,t:1527272381362};\\\", \\\"{x:1407,y:791,t:1527272381380};\\\", \\\"{x:1399,y:795,t:1527272381394};\\\", \\\"{x:1391,y:799,t:1527272381411};\\\", \\\"{x:1382,y:802,t:1527272381428};\\\", \\\"{x:1374,y:804,t:1527272381444};\\\", \\\"{x:1368,y:806,t:1527272381462};\\\", \\\"{x:1363,y:810,t:1527272381478};\\\", \\\"{x:1358,y:812,t:1527272381494};\\\", \\\"{x:1357,y:812,t:1527272381512};\\\", \\\"{x:1357,y:813,t:1527272381529};\\\", \\\"{x:1354,y:813,t:1527272381545};\\\", \\\"{x:1353,y:815,t:1527272381562};\\\", \\\"{x:1347,y:816,t:1527272381579};\\\", \\\"{x:1342,y:819,t:1527272381594};\\\", \\\"{x:1337,y:821,t:1527272381613};\\\", \\\"{x:1333,y:823,t:1527272381629};\\\", \\\"{x:1329,y:823,t:1527272381645};\\\", \\\"{x:1326,y:826,t:1527272381661};\\\", \\\"{x:1323,y:826,t:1527272381679};\\\", \\\"{x:1322,y:828,t:1527272381695};\\\", \\\"{x:1321,y:829,t:1527272381711};\\\", \\\"{x:1319,y:830,t:1527272381729};\\\", \\\"{x:1315,y:832,t:1527272381746};\\\", \\\"{x:1311,y:834,t:1527272381762};\\\", \\\"{x:1300,y:837,t:1527272381780};\\\", \\\"{x:1289,y:842,t:1527272381795};\\\", \\\"{x:1285,y:843,t:1527272381811};\\\", \\\"{x:1284,y:845,t:1527272381829};\\\", \\\"{x:1283,y:845,t:1527272381939};\\\", \\\"{x:1282,y:845,t:1527272381946};\\\", \\\"{x:1280,y:845,t:1527272381962};\\\", \\\"{x:1276,y:845,t:1527272381979};\\\", \\\"{x:1272,y:845,t:1527272381996};\\\", \\\"{x:1269,y:845,t:1527272382012};\\\", \\\"{x:1267,y:844,t:1527272382028};\\\", \\\"{x:1258,y:843,t:1527272382046};\\\", \\\"{x:1251,y:841,t:1527272382061};\\\", \\\"{x:1246,y:840,t:1527272382078};\\\", \\\"{x:1238,y:839,t:1527272382096};\\\", \\\"{x:1230,y:838,t:1527272382112};\\\", \\\"{x:1222,y:836,t:1527272382129};\\\", \\\"{x:1214,y:835,t:1527272382148};\\\", \\\"{x:1203,y:834,t:1527272382161};\\\", \\\"{x:1197,y:833,t:1527272382178};\\\", \\\"{x:1196,y:833,t:1527272382194};\\\", \\\"{x:1196,y:832,t:1527272382226};\\\", \\\"{x:1196,y:830,t:1527272382281};\\\", \\\"{x:1196,y:829,t:1527272382298};\\\", \\\"{x:1197,y:829,t:1527272382311};\\\", \\\"{x:1198,y:829,t:1527272382370};\\\", \\\"{x:1198,y:828,t:1527272382380};\\\", \\\"{x:1199,y:828,t:1527272382395};\\\", \\\"{x:1200,y:826,t:1527272382435};\\\", \\\"{x:1201,y:826,t:1527272382446};\\\", \\\"{x:1202,y:826,t:1527272382507};\\\", \\\"{x:1203,y:829,t:1527272382530};\\\", \\\"{x:1204,y:830,t:1527272382547};\\\", \\\"{x:1209,y:838,t:1527272382563};\\\", \\\"{x:1213,y:843,t:1527272382579};\\\", \\\"{x:1216,y:847,t:1527272382595};\\\", \\\"{x:1220,y:851,t:1527272382612};\\\", \\\"{x:1227,y:854,t:1527272382629};\\\", \\\"{x:1233,y:856,t:1527272382645};\\\", \\\"{x:1239,y:861,t:1527272382663};\\\", \\\"{x:1244,y:862,t:1527272382679};\\\", \\\"{x:1248,y:864,t:1527272382695};\\\", \\\"{x:1249,y:865,t:1527272382712};\\\", \\\"{x:1251,y:865,t:1527272382730};\\\", \\\"{x:1252,y:863,t:1527272382786};\\\", \\\"{x:1254,y:862,t:1527272382796};\\\", \\\"{x:1257,y:860,t:1527272382812};\\\", \\\"{x:1261,y:856,t:1527272382829};\\\", \\\"{x:1263,y:854,t:1527272382846};\\\", \\\"{x:1264,y:852,t:1527272382863};\\\", \\\"{x:1264,y:851,t:1527272382878};\\\", \\\"{x:1264,y:849,t:1527272382896};\\\", \\\"{x:1262,y:847,t:1527272382913};\\\", \\\"{x:1261,y:846,t:1527272382928};\\\", \\\"{x:1261,y:845,t:1527272382946};\\\", \\\"{x:1260,y:842,t:1527272382962};\\\", \\\"{x:1260,y:841,t:1527272382979};\\\", \\\"{x:1260,y:839,t:1527272382996};\\\", \\\"{x:1260,y:838,t:1527272383018};\\\", \\\"{x:1261,y:836,t:1527272383034};\\\", \\\"{x:1262,y:835,t:1527272383045};\\\", \\\"{x:1263,y:834,t:1527272383063};\\\", \\\"{x:1264,y:833,t:1527272383078};\\\", \\\"{x:1265,y:832,t:1527272383096};\\\", \\\"{x:1266,y:833,t:1527272383195};\\\", \\\"{x:1269,y:839,t:1527272383213};\\\", \\\"{x:1271,y:845,t:1527272383230};\\\", \\\"{x:1274,y:848,t:1527272383245};\\\", \\\"{x:1275,y:849,t:1527272383263};\\\", \\\"{x:1276,y:850,t:1527272383279};\\\", \\\"{x:1277,y:851,t:1527272383296};\\\", \\\"{x:1277,y:852,t:1527272383313};\\\", \\\"{x:1279,y:852,t:1527272383330};\\\", \\\"{x:1282,y:852,t:1527272383345};\\\", \\\"{x:1289,y:854,t:1527272383362};\\\", \\\"{x:1294,y:856,t:1527272383380};\\\", \\\"{x:1299,y:857,t:1527272383396};\\\", \\\"{x:1302,y:857,t:1527272383413};\\\", \\\"{x:1302,y:858,t:1527272383430};\\\", \\\"{x:1304,y:858,t:1527272383446};\\\", \\\"{x:1307,y:858,t:1527272383463};\\\", \\\"{x:1310,y:857,t:1527272383480};\\\", \\\"{x:1313,y:855,t:1527272383496};\\\", \\\"{x:1316,y:854,t:1527272383513};\\\", \\\"{x:1319,y:853,t:1527272383530};\\\", \\\"{x:1321,y:853,t:1527272383545};\\\", \\\"{x:1322,y:852,t:1527272383563};\\\", \\\"{x:1323,y:852,t:1527272383579};\\\", \\\"{x:1323,y:851,t:1527272383658};\\\", \\\"{x:1324,y:850,t:1527272383666};\\\", \\\"{x:1325,y:849,t:1527272383680};\\\", \\\"{x:1327,y:847,t:1527272383695};\\\", \\\"{x:1329,y:846,t:1527272383755};\\\", \\\"{x:1329,y:845,t:1527272383786};\\\", \\\"{x:1330,y:844,t:1527272383810};\\\", \\\"{x:1330,y:843,t:1527272383818};\\\", \\\"{x:1330,y:842,t:1527272384181};\\\", \\\"{x:1332,y:840,t:1527272384196};\\\", \\\"{x:1332,y:838,t:1527272384213};\\\", \\\"{x:1332,y:837,t:1527272384229};\\\", \\\"{x:1334,y:836,t:1527272384246};\\\", \\\"{x:1334,y:835,t:1527272384262};\\\", \\\"{x:1335,y:833,t:1527272384297};\\\", \\\"{x:1336,y:832,t:1527272384312};\\\", \\\"{x:1336,y:829,t:1527272384329};\\\", \\\"{x:1336,y:822,t:1527272384346};\\\", \\\"{x:1341,y:807,t:1527272384363};\\\", \\\"{x:1342,y:796,t:1527272384379};\\\", \\\"{x:1342,y:789,t:1527272384397};\\\", \\\"{x:1344,y:784,t:1527272384414};\\\", \\\"{x:1345,y:780,t:1527272384429};\\\", \\\"{x:1345,y:777,t:1527272384447};\\\", \\\"{x:1345,y:771,t:1527272384463};\\\", \\\"{x:1346,y:766,t:1527272384480};\\\", \\\"{x:1346,y:763,t:1527272384496};\\\", \\\"{x:1348,y:760,t:1527272384513};\\\", \\\"{x:1348,y:759,t:1527272389723};\\\", \\\"{x:1352,y:758,t:1527272389739};\\\", \\\"{x:1358,y:761,t:1527272389750};\\\", \\\"{x:1361,y:767,t:1527272389767};\\\", \\\"{x:1359,y:774,t:1527272389783};\\\", \\\"{x:1355,y:781,t:1527272389800};\\\", \\\"{x:1350,y:788,t:1527272389817};\\\", \\\"{x:1350,y:799,t:1527272389833};\\\", \\\"{x:1350,y:831,t:1527272389850};\\\", \\\"{x:1353,y:854,t:1527272389866};\\\", \\\"{x:1353,y:860,t:1527272389883};\\\", \\\"{x:1353,y:863,t:1527272389900};\\\", \\\"{x:1357,y:864,t:1527272389917};\\\", \\\"{x:1359,y:868,t:1527272389933};\\\", \\\"{x:1367,y:872,t:1527272389950};\\\", \\\"{x:1376,y:872,t:1527272389967};\\\", \\\"{x:1383,y:874,t:1527272389983};\\\", \\\"{x:1384,y:874,t:1527272390000};\\\", \\\"{x:1392,y:875,t:1527272390017};\\\", \\\"{x:1402,y:876,t:1527272390034};\\\", \\\"{x:1434,y:881,t:1527272390050};\\\", \\\"{x:1457,y:891,t:1527272390066};\\\", \\\"{x:1509,y:902,t:1527272390083};\\\", \\\"{x:1536,y:917,t:1527272390100};\\\", \\\"{x:1551,y:927,t:1527272390117};\\\", \\\"{x:1562,y:934,t:1527272390134};\\\", \\\"{x:1566,y:937,t:1527272390150};\\\", \\\"{x:1568,y:937,t:1527272390167};\\\", \\\"{x:1568,y:938,t:1527272390186};\\\", \\\"{x:1567,y:938,t:1527272390226};\\\", \\\"{x:1564,y:940,t:1527272390275};\\\", \\\"{x:1563,y:941,t:1527272390290};\\\", \\\"{x:1561,y:942,t:1527272390300};\\\", \\\"{x:1559,y:943,t:1527272390317};\\\", \\\"{x:1557,y:953,t:1527272390334};\\\", \\\"{x:1557,y:956,t:1527272390350};\\\", \\\"{x:1557,y:957,t:1527272390367};\\\", \\\"{x:1556,y:959,t:1527272390384};\\\", \\\"{x:1555,y:962,t:1527272390400};\\\", \\\"{x:1554,y:962,t:1527272390539};\\\", \\\"{x:1554,y:963,t:1527272390551};\\\", \\\"{x:1552,y:963,t:1527272390567};\\\", \\\"{x:1541,y:960,t:1527272390584};\\\", \\\"{x:1532,y:950,t:1527272390600};\\\", \\\"{x:1524,y:936,t:1527272390617};\\\", \\\"{x:1497,y:905,t:1527272390634};\\\", \\\"{x:1472,y:868,t:1527272390650};\\\", \\\"{x:1457,y:846,t:1527272390667};\\\", \\\"{x:1438,y:823,t:1527272390684};\\\", \\\"{x:1410,y:778,t:1527272390701};\\\", \\\"{x:1395,y:743,t:1527272390717};\\\", \\\"{x:1391,y:727,t:1527272390734};\\\", \\\"{x:1389,y:724,t:1527272390751};\\\", \\\"{x:1388,y:722,t:1527272390767};\\\", \\\"{x:1386,y:711,t:1527272390784};\\\", \\\"{x:1386,y:700,t:1527272390801};\\\", \\\"{x:1384,y:693,t:1527272390817};\\\", \\\"{x:1381,y:689,t:1527272390834};\\\", \\\"{x:1378,y:683,t:1527272390850};\\\", \\\"{x:1376,y:679,t:1527272390867};\\\", \\\"{x:1369,y:672,t:1527272390884};\\\", \\\"{x:1362,y:666,t:1527272390901};\\\", \\\"{x:1360,y:662,t:1527272390917};\\\", \\\"{x:1360,y:661,t:1527272390934};\\\", \\\"{x:1360,y:660,t:1527272390951};\\\", \\\"{x:1360,y:659,t:1527272390970};\\\", \\\"{x:1359,y:655,t:1527272390984};\\\", \\\"{x:1358,y:653,t:1527272391001};\\\", \\\"{x:1358,y:649,t:1527272391017};\\\", \\\"{x:1348,y:630,t:1527272391034};\\\", \\\"{x:1340,y:619,t:1527272391050};\\\", \\\"{x:1335,y:614,t:1527272391067};\\\", \\\"{x:1327,y:607,t:1527272391084};\\\", \\\"{x:1321,y:600,t:1527272391101};\\\", \\\"{x:1314,y:596,t:1527272391117};\\\", \\\"{x:1308,y:591,t:1527272391134};\\\", \\\"{x:1302,y:588,t:1527272391151};\\\", \\\"{x:1299,y:585,t:1527272391167};\\\", \\\"{x:1296,y:581,t:1527272391184};\\\", \\\"{x:1292,y:576,t:1527272391200};\\\", \\\"{x:1290,y:575,t:1527272391217};\\\", \\\"{x:1289,y:576,t:1527272391658};\\\", \\\"{x:1287,y:576,t:1527272391668};\\\", \\\"{x:1287,y:579,t:1527272391684};\\\", \\\"{x:1286,y:591,t:1527272391701};\\\", \\\"{x:1286,y:604,t:1527272391718};\\\", \\\"{x:1286,y:619,t:1527272391734};\\\", \\\"{x:1292,y:636,t:1527272391751};\\\", \\\"{x:1295,y:650,t:1527272391768};\\\", \\\"{x:1297,y:666,t:1527272391784};\\\", \\\"{x:1300,y:679,t:1527272391801};\\\", \\\"{x:1303,y:695,t:1527272391817};\\\", \\\"{x:1304,y:703,t:1527272391834};\\\", \\\"{x:1305,y:708,t:1527272391851};\\\", \\\"{x:1305,y:711,t:1527272391868};\\\", \\\"{x:1305,y:713,t:1527272391914};\\\", \\\"{x:1305,y:714,t:1527272391946};\\\", \\\"{x:1305,y:715,t:1527272391970};\\\", \\\"{x:1305,y:717,t:1527272391986};\\\", \\\"{x:1304,y:717,t:1527272392001};\\\", \\\"{x:1303,y:718,t:1527272392059};\\\", \\\"{x:1302,y:718,t:1527272392068};\\\", \\\"{x:1301,y:720,t:1527272392085};\\\", \\\"{x:1300,y:721,t:1527272392101};\\\", \\\"{x:1298,y:722,t:1527272392118};\\\", \\\"{x:1297,y:722,t:1527272392135};\\\", \\\"{x:1296,y:723,t:1527272392151};\\\", \\\"{x:1294,y:724,t:1527272392168};\\\", \\\"{x:1289,y:724,t:1527272392185};\\\", \\\"{x:1278,y:726,t:1527272392201};\\\", \\\"{x:1254,y:726,t:1527272392218};\\\", \\\"{x:1247,y:726,t:1527272392235};\\\", \\\"{x:1229,y:726,t:1527272392251};\\\", \\\"{x:1216,y:725,t:1527272392268};\\\", \\\"{x:1210,y:724,t:1527272392285};\\\", \\\"{x:1206,y:724,t:1527272392301};\\\", \\\"{x:1205,y:724,t:1527272392318};\\\", \\\"{x:1203,y:724,t:1527272392335};\\\", \\\"{x:1202,y:725,t:1527272392352};\\\", \\\"{x:1200,y:727,t:1527272392368};\\\", \\\"{x:1198,y:729,t:1527272392385};\\\", \\\"{x:1197,y:730,t:1527272392402};\\\", \\\"{x:1196,y:731,t:1527272392418};\\\", \\\"{x:1196,y:736,t:1527272392435};\\\", \\\"{x:1193,y:740,t:1527272392452};\\\", \\\"{x:1193,y:748,t:1527272392468};\\\", \\\"{x:1192,y:753,t:1527272392485};\\\", \\\"{x:1192,y:759,t:1527272392502};\\\", \\\"{x:1191,y:762,t:1527272392518};\\\", \\\"{x:1190,y:766,t:1527272392535};\\\", \\\"{x:1189,y:770,t:1527272392552};\\\", \\\"{x:1187,y:776,t:1527272392568};\\\", \\\"{x:1184,y:782,t:1527272392585};\\\", \\\"{x:1176,y:790,t:1527272392602};\\\", \\\"{x:1173,y:794,t:1527272392618};\\\", \\\"{x:1171,y:797,t:1527272392635};\\\", \\\"{x:1170,y:798,t:1527272392652};\\\", \\\"{x:1172,y:797,t:1527272392795};\\\", \\\"{x:1174,y:796,t:1527272392810};\\\", \\\"{x:1176,y:794,t:1527272392818};\\\", \\\"{x:1179,y:791,t:1527272392835};\\\", \\\"{x:1184,y:787,t:1527272392852};\\\", \\\"{x:1189,y:783,t:1527272392868};\\\", \\\"{x:1191,y:780,t:1527272392886};\\\", \\\"{x:1194,y:775,t:1527272392902};\\\", \\\"{x:1194,y:774,t:1527272392918};\\\", \\\"{x:1194,y:772,t:1527272392935};\\\", \\\"{x:1194,y:771,t:1527272392952};\\\", \\\"{x:1194,y:770,t:1527272393026};\\\", \\\"{x:1194,y:768,t:1527272393050};\\\", \\\"{x:1193,y:768,t:1527272393058};\\\", \\\"{x:1192,y:768,t:1527272393074};\\\", \\\"{x:1191,y:768,t:1527272393085};\\\", \\\"{x:1190,y:768,t:1527272393180};\\\", \\\"{x:1190,y:767,t:1527272393490};\\\", \\\"{x:1191,y:768,t:1527272393747};\\\", \\\"{x:1193,y:770,t:1527272393754};\\\", \\\"{x:1195,y:771,t:1527272393769};\\\", \\\"{x:1203,y:779,t:1527272393786};\\\", \\\"{x:1210,y:784,t:1527272393802};\\\", \\\"{x:1210,y:785,t:1527272393819};\\\", \\\"{x:1213,y:788,t:1527272393836};\\\", \\\"{x:1215,y:789,t:1527272393852};\\\", \\\"{x:1217,y:789,t:1527272393869};\\\", \\\"{x:1219,y:789,t:1527272393987};\\\", \\\"{x:1224,y:787,t:1527272394002};\\\", \\\"{x:1227,y:784,t:1527272394019};\\\", \\\"{x:1234,y:781,t:1527272394036};\\\", \\\"{x:1238,y:779,t:1527272394053};\\\", \\\"{x:1241,y:776,t:1527272394069};\\\", \\\"{x:1242,y:775,t:1527272394086};\\\", \\\"{x:1245,y:775,t:1527272394139};\\\", \\\"{x:1250,y:779,t:1527272394153};\\\", \\\"{x:1260,y:789,t:1527272394169};\\\", \\\"{x:1270,y:808,t:1527272394186};\\\", \\\"{x:1277,y:822,t:1527272394202};\\\", \\\"{x:1280,y:829,t:1527272394220};\\\", \\\"{x:1286,y:835,t:1527272394236};\\\", \\\"{x:1287,y:836,t:1527272394266};\\\", \\\"{x:1288,y:836,t:1527272394315};\\\", \\\"{x:1292,y:836,t:1527272394322};\\\", \\\"{x:1296,y:834,t:1527272394336};\\\", \\\"{x:1306,y:826,t:1527272394353};\\\", \\\"{x:1315,y:816,t:1527272394369};\\\", \\\"{x:1320,y:811,t:1527272394386};\\\", \\\"{x:1323,y:809,t:1527272394403};\\\", \\\"{x:1323,y:806,t:1527272394419};\\\", \\\"{x:1322,y:806,t:1527272394499};\\\", \\\"{x:1321,y:806,t:1527272394506};\\\", \\\"{x:1320,y:806,t:1527272394519};\\\", \\\"{x:1319,y:809,t:1527272394537};\\\", \\\"{x:1320,y:819,t:1527272394553};\\\", \\\"{x:1325,y:831,t:1527272394569};\\\", \\\"{x:1335,y:844,t:1527272394586};\\\", \\\"{x:1339,y:848,t:1527272394603};\\\", \\\"{x:1342,y:851,t:1527272394621};\\\", \\\"{x:1343,y:853,t:1527272394636};\\\", \\\"{x:1346,y:854,t:1527272394653};\\\", \\\"{x:1348,y:854,t:1527272394674};\\\", \\\"{x:1350,y:854,t:1527272394698};\\\", \\\"{x:1355,y:852,t:1527272394714};\\\", \\\"{x:1357,y:850,t:1527272394730};\\\", \\\"{x:1359,y:848,t:1527272394738};\\\", \\\"{x:1361,y:844,t:1527272394753};\\\", \\\"{x:1368,y:837,t:1527272394770};\\\", \\\"{x:1375,y:829,t:1527272394786};\\\", \\\"{x:1384,y:823,t:1527272394804};\\\", \\\"{x:1389,y:821,t:1527272394826};\\\", \\\"{x:1390,y:820,t:1527272394837};\\\", \\\"{x:1395,y:818,t:1527272394853};\\\", \\\"{x:1391,y:819,t:1527272395010};\\\", \\\"{x:1389,y:821,t:1527272395020};\\\", \\\"{x:1385,y:823,t:1527272395036};\\\", \\\"{x:1383,y:825,t:1527272395053};\\\", \\\"{x:1381,y:828,t:1527272395070};\\\", \\\"{x:1380,y:833,t:1527272395087};\\\", \\\"{x:1380,y:840,t:1527272395103};\\\", \\\"{x:1380,y:845,t:1527272395120};\\\", \\\"{x:1386,y:854,t:1527272395136};\\\", \\\"{x:1405,y:881,t:1527272395153};\\\", \\\"{x:1432,y:914,t:1527272395170};\\\", \\\"{x:1454,y:934,t:1527272395185};\\\", \\\"{x:1468,y:951,t:1527272395203};\\\", \\\"{x:1489,y:966,t:1527272395220};\\\", \\\"{x:1494,y:973,t:1527272395237};\\\", \\\"{x:1509,y:985,t:1527272395252};\\\", \\\"{x:1519,y:994,t:1527272395270};\\\", \\\"{x:1528,y:1004,t:1527272395287};\\\", \\\"{x:1529,y:1008,t:1527272395302};\\\", \\\"{x:1530,y:1009,t:1527272395320};\\\", \\\"{x:1530,y:1010,t:1527272395337};\\\", \\\"{x:1530,y:1011,t:1527272395353};\\\", \\\"{x:1530,y:1012,t:1527272395611};\\\", \\\"{x:1529,y:1012,t:1527272395620};\\\", \\\"{x:1527,y:1012,t:1527272395637};\\\", \\\"{x:1525,y:1010,t:1527272395653};\\\", \\\"{x:1522,y:1006,t:1527272395670};\\\", \\\"{x:1521,y:1005,t:1527272395688};\\\", \\\"{x:1518,y:1002,t:1527272395703};\\\", \\\"{x:1518,y:1000,t:1527272395721};\\\", \\\"{x:1514,y:996,t:1527272395737};\\\", \\\"{x:1511,y:994,t:1527272395753};\\\", \\\"{x:1507,y:990,t:1527272395770};\\\", \\\"{x:1506,y:988,t:1527272395787};\\\", \\\"{x:1504,y:985,t:1527272395804};\\\", \\\"{x:1503,y:984,t:1527272395820};\\\", \\\"{x:1501,y:982,t:1527272395837};\\\", \\\"{x:1500,y:981,t:1527272395854};\\\", \\\"{x:1498,y:978,t:1527272395870};\\\", \\\"{x:1495,y:973,t:1527272395887};\\\", \\\"{x:1494,y:973,t:1527272395903};\\\", \\\"{x:1491,y:970,t:1527272395920};\\\", \\\"{x:1489,y:968,t:1527272395938};\\\", \\\"{x:1488,y:967,t:1527272395954};\\\", \\\"{x:1488,y:966,t:1527272395986};\\\", \\\"{x:1487,y:965,t:1527272396522};\\\", \\\"{x:1486,y:965,t:1527272396537};\\\", \\\"{x:1486,y:964,t:1527272396554};\\\", \\\"{x:1486,y:963,t:1527272396570};\\\", \\\"{x:1486,y:960,t:1527272396587};\\\", \\\"{x:1486,y:959,t:1527272396609};\\\", \\\"{x:1486,y:957,t:1527272396625};\\\", \\\"{x:1486,y:956,t:1527272396657};\\\", \\\"{x:1485,y:956,t:1527272400211};\\\", \\\"{x:1484,y:956,t:1527272400258};\\\", \\\"{x:1483,y:957,t:1527272400755};\\\", \\\"{x:1482,y:957,t:1527272400762};\\\", \\\"{x:1480,y:958,t:1527272400779};\\\", \\\"{x:1478,y:960,t:1527272400802};\\\", \\\"{x:1477,y:961,t:1527272400818};\\\", \\\"{x:1477,y:962,t:1527272400826};\\\", \\\"{x:1476,y:962,t:1527272401107};\\\", \\\"{x:1474,y:956,t:1527272401123};\\\", \\\"{x:1473,y:950,t:1527272401140};\\\", \\\"{x:1468,y:940,t:1527272401157};\\\", \\\"{x:1468,y:933,t:1527272401174};\\\", \\\"{x:1465,y:927,t:1527272401190};\\\", \\\"{x:1465,y:926,t:1527272401210};\\\", \\\"{x:1465,y:925,t:1527272401224};\\\", \\\"{x:1465,y:922,t:1527272401241};\\\", \\\"{x:1463,y:917,t:1527272401258};\\\", \\\"{x:1461,y:914,t:1527272401273};\\\", \\\"{x:1457,y:909,t:1527272401290};\\\", \\\"{x:1456,y:908,t:1527272401307};\\\", \\\"{x:1454,y:906,t:1527272401858};\\\", \\\"{x:1443,y:901,t:1527272401874};\\\", \\\"{x:1438,y:897,t:1527272401890};\\\", \\\"{x:1434,y:895,t:1527272401907};\\\", \\\"{x:1434,y:894,t:1527272401925};\\\", \\\"{x:1433,y:893,t:1527272401946};\\\", \\\"{x:1431,y:893,t:1527272402194};\\\", \\\"{x:1430,y:893,t:1527272402207};\\\", \\\"{x:1425,y:893,t:1527272402224};\\\", \\\"{x:1419,y:894,t:1527272402242};\\\", \\\"{x:1416,y:894,t:1527272402257};\\\", \\\"{x:1409,y:894,t:1527272402274};\\\", \\\"{x:1408,y:894,t:1527272402291};\\\", \\\"{x:1405,y:894,t:1527272402307};\\\", \\\"{x:1402,y:894,t:1527272402324};\\\", \\\"{x:1392,y:893,t:1527272402341};\\\", \\\"{x:1379,y:891,t:1527272402358};\\\", \\\"{x:1370,y:887,t:1527272402375};\\\", \\\"{x:1365,y:882,t:1527272402391};\\\", \\\"{x:1363,y:882,t:1527272402407};\\\", \\\"{x:1362,y:881,t:1527272402497};\\\", \\\"{x:1361,y:880,t:1527272402507};\\\", \\\"{x:1359,y:876,t:1527272402524};\\\", \\\"{x:1358,y:875,t:1527272402541};\\\", \\\"{x:1354,y:870,t:1527272402557};\\\", \\\"{x:1350,y:863,t:1527272402574};\\\", \\\"{x:1347,y:857,t:1527272402591};\\\", \\\"{x:1345,y:851,t:1527272402607};\\\", \\\"{x:1342,y:844,t:1527272402624};\\\", \\\"{x:1339,y:835,t:1527272402641};\\\", \\\"{x:1337,y:828,t:1527272402658};\\\", \\\"{x:1333,y:820,t:1527272402674};\\\", \\\"{x:1331,y:815,t:1527272402691};\\\", \\\"{x:1331,y:814,t:1527272402714};\\\", \\\"{x:1331,y:813,t:1527272402725};\\\", \\\"{x:1330,y:812,t:1527272402742};\\\", \\\"{x:1330,y:809,t:1527272402759};\\\", \\\"{x:1330,y:808,t:1527272402774};\\\", \\\"{x:1330,y:806,t:1527272402792};\\\", \\\"{x:1330,y:805,t:1527272402826};\\\", \\\"{x:1330,y:804,t:1527272403130};\\\", \\\"{x:1332,y:802,t:1527272403142};\\\", \\\"{x:1334,y:799,t:1527272403159};\\\", \\\"{x:1335,y:798,t:1527272403174};\\\", \\\"{x:1335,y:797,t:1527272403192};\\\", \\\"{x:1335,y:795,t:1527272403208};\\\", \\\"{x:1335,y:792,t:1527272403225};\\\", \\\"{x:1334,y:790,t:1527272403241};\\\", \\\"{x:1333,y:789,t:1527272403266};\\\", \\\"{x:1333,y:788,t:1527272403275};\\\", \\\"{x:1333,y:786,t:1527272403292};\\\", \\\"{x:1333,y:785,t:1527272403308};\\\", \\\"{x:1333,y:783,t:1527272403326};\\\", \\\"{x:1332,y:782,t:1527272403341};\\\", \\\"{x:1332,y:780,t:1527272403358};\\\", \\\"{x:1332,y:778,t:1527272403376};\\\", \\\"{x:1332,y:776,t:1527272403392};\\\", \\\"{x:1333,y:773,t:1527272403409};\\\", \\\"{x:1335,y:767,t:1527272403426};\\\", \\\"{x:1335,y:765,t:1527272403442};\\\", \\\"{x:1335,y:764,t:1527272403466};\\\", \\\"{x:1335,y:763,t:1527272404194};\\\", \\\"{x:1333,y:763,t:1527272404208};\\\", \\\"{x:1330,y:764,t:1527272404226};\\\", \\\"{x:1327,y:765,t:1527272404283};\\\", \\\"{x:1319,y:765,t:1527272404298};\\\", \\\"{x:1306,y:765,t:1527272404309};\\\", \\\"{x:1278,y:765,t:1527272404326};\\\", \\\"{x:1241,y:765,t:1527272404342};\\\", \\\"{x:1189,y:760,t:1527272404358};\\\", \\\"{x:1121,y:751,t:1527272404375};\\\", \\\"{x:1070,y:741,t:1527272404393};\\\", \\\"{x:955,y:726,t:1527272404410};\\\", \\\"{x:895,y:717,t:1527272404426};\\\", \\\"{x:868,y:706,t:1527272404442};\\\", \\\"{x:800,y:694,t:1527272404459};\\\", \\\"{x:755,y:683,t:1527272404476};\\\", \\\"{x:746,y:673,t:1527272404492};\\\", \\\"{x:733,y:668,t:1527272404509};\\\", \\\"{x:724,y:662,t:1527272404525};\\\", \\\"{x:711,y:660,t:1527272404542};\\\", \\\"{x:706,y:659,t:1527272404559};\\\", \\\"{x:702,y:659,t:1527272404575};\\\", \\\"{x:699,y:658,t:1527272404592};\\\", \\\"{x:695,y:657,t:1527272404610};\\\", \\\"{x:689,y:656,t:1527272404626};\\\", \\\"{x:684,y:655,t:1527272404642};\\\", \\\"{x:676,y:654,t:1527272404660};\\\", \\\"{x:668,y:653,t:1527272404676};\\\", \\\"{x:659,y:652,t:1527272404692};\\\", \\\"{x:655,y:648,t:1527272404709};\\\", \\\"{x:650,y:647,t:1527272404726};\\\", \\\"{x:647,y:647,t:1527272404743};\\\", \\\"{x:646,y:647,t:1527272405386};\\\", \\\"{x:643,y:647,t:1527272405394};\\\", \\\"{x:633,y:646,t:1527272405410};\\\", \\\"{x:629,y:645,t:1527272405428};\\\", \\\"{x:619,y:642,t:1527272405443};\\\", \\\"{x:603,y:641,t:1527272405459};\\\", \\\"{x:593,y:639,t:1527272405481};\\\", \\\"{x:591,y:638,t:1527272405497};\\\", \\\"{x:588,y:637,t:1527272405514};\\\", \\\"{x:585,y:637,t:1527272405531};\\\", \\\"{x:583,y:637,t:1527272405658};\\\", \\\"{x:583,y:640,t:1527272405674};\\\", \\\"{x:583,y:643,t:1527272405689};\\\", \\\"{x:583,y:644,t:1527272405698};\\\", \\\"{x:585,y:647,t:1527272405715};\\\", \\\"{x:589,y:647,t:1527272410275};\\\", \\\"{x:601,y:647,t:1527272410285};\\\", \\\"{x:624,y:643,t:1527272410303};\\\", \\\"{x:638,y:639,t:1527272410318};\\\", \\\"{x:645,y:638,t:1527272410334};\\\", \\\"{x:646,y:638,t:1527272410546};\\\", \\\"{x:656,y:640,t:1527272410553};\\\", \\\"{x:681,y:641,t:1527272410569};\\\", \\\"{x:815,y:670,t:1527272410587};\\\", \\\"{x:874,y:688,t:1527272410601};\\\", \\\"{x:975,y:717,t:1527272410618};\\\", \\\"{x:1068,y:739,t:1527272410635};\\\", \\\"{x:1165,y:767,t:1527272410652};\\\", \\\"{x:1238,y:783,t:1527272410668};\\\", \\\"{x:1270,y:792,t:1527272410685};\\\", \\\"{x:1280,y:795,t:1527272410702};\\\", \\\"{x:1282,y:795,t:1527272411226};\\\", \\\"{x:1284,y:795,t:1527272411237};\\\", \\\"{x:1290,y:793,t:1527272411254};\\\", \\\"{x:1296,y:791,t:1527272411271};\\\", \\\"{x:1307,y:784,t:1527272411288};\\\", \\\"{x:1338,y:781,t:1527272411304};\\\", \\\"{x:1416,y:783,t:1527272411321};\\\", \\\"{x:1591,y:814,t:1527272411338};\\\", \\\"{x:1707,y:833,t:1527272411354};\\\", \\\"{x:1795,y:852,t:1527272411370};\\\", \\\"{x:1847,y:863,t:1527272411388};\\\", \\\"{x:1868,y:868,t:1527272411405};\\\", \\\"{x:1869,y:872,t:1527272411421};\\\", \\\"{x:1869,y:874,t:1527272411466};\\\", \\\"{x:1867,y:875,t:1527272411474};\\\", \\\"{x:1865,y:877,t:1527272411490};\\\", \\\"{x:1862,y:879,t:1527272411505};\\\", \\\"{x:1855,y:882,t:1527272411522};\\\", \\\"{x:1848,y:884,t:1527272411538};\\\", \\\"{x:1826,y:887,t:1527272411554};\\\", \\\"{x:1772,y:884,t:1527272411572};\\\", \\\"{x:1667,y:870,t:1527272411588};\\\", \\\"{x:1580,y:857,t:1527272411605};\\\", \\\"{x:1548,y:851,t:1527272411622};\\\", \\\"{x:1533,y:846,t:1527272411637};\\\", \\\"{x:1525,y:846,t:1527272411655};\\\", \\\"{x:1516,y:846,t:1527272411671};\\\", \\\"{x:1511,y:846,t:1527272411688};\\\", \\\"{x:1508,y:847,t:1527272411704};\\\", \\\"{x:1507,y:849,t:1527272411746};\\\", \\\"{x:1505,y:851,t:1527272411756};\\\", \\\"{x:1502,y:851,t:1527272411772};\\\", \\\"{x:1500,y:851,t:1527272411789};\\\", \\\"{x:1498,y:853,t:1527272411806};\\\", \\\"{x:1497,y:855,t:1527272411954};\\\", \\\"{x:1494,y:857,t:1527272412066};\\\", \\\"{x:1493,y:857,t:1527272412081};\\\", \\\"{x:1493,y:858,t:1527272412090};\\\", \\\"{x:1490,y:859,t:1527272412106};\\\", \\\"{x:1489,y:860,t:1527272412123};\\\", \\\"{x:1485,y:861,t:1527272412139};\\\", \\\"{x:1483,y:862,t:1527272412157};\\\", \\\"{x:1478,y:863,t:1527272412173};\\\", \\\"{x:1476,y:864,t:1527272412190};\\\", \\\"{x:1470,y:866,t:1527272412207};\\\", \\\"{x:1466,y:867,t:1527272412223};\\\", \\\"{x:1466,y:868,t:1527272412240};\\\", \\\"{x:1462,y:869,t:1527272412858};\\\", \\\"{x:1460,y:872,t:1527272412875};\\\", \\\"{x:1456,y:876,t:1527272412892};\\\", \\\"{x:1453,y:879,t:1527272412908};\\\", \\\"{x:1451,y:880,t:1527272412925};\\\", \\\"{x:1448,y:882,t:1527272412941};\\\", \\\"{x:1444,y:884,t:1527272412959};\\\", \\\"{x:1440,y:884,t:1527272412974};\\\", \\\"{x:1436,y:884,t:1527272412992};\\\", \\\"{x:1434,y:884,t:1527272413009};\\\", \\\"{x:1432,y:885,t:1527272413025};\\\", \\\"{x:1430,y:886,t:1527272413090};\\\", \\\"{x:1429,y:887,t:1527272413106};\\\", \\\"{x:1427,y:887,t:1527272413146};\\\", \\\"{x:1426,y:889,t:1527272413162};\\\", \\\"{x:1424,y:890,t:1527272413175};\\\", \\\"{x:1421,y:892,t:1527272413193};\\\", \\\"{x:1419,y:894,t:1527272413209};\\\", \\\"{x:1414,y:897,t:1527272413226};\\\", \\\"{x:1413,y:898,t:1527272413243};\\\", \\\"{x:1412,y:899,t:1527272413259};\\\", \\\"{x:1412,y:900,t:1527272413276};\\\", \\\"{x:1412,y:901,t:1527272413330};\\\", \\\"{x:1413,y:902,t:1527272413346};\\\", \\\"{x:1416,y:902,t:1527272413360};\\\", \\\"{x:1417,y:901,t:1527272413375};\\\", \\\"{x:1422,y:900,t:1527272413393};\\\", \\\"{x:1430,y:900,t:1527272413410};\\\", \\\"{x:1431,y:899,t:1527272413426};\\\", \\\"{x:1433,y:898,t:1527272413443};\\\", \\\"{x:1433,y:897,t:1527272413481};\\\", \\\"{x:1434,y:896,t:1527272413494};\\\", \\\"{x:1435,y:895,t:1527272413510};\\\", \\\"{x:1437,y:894,t:1527272413527};\\\", \\\"{x:1439,y:893,t:1527272413544};\\\", \\\"{x:1440,y:892,t:1527272413560};\\\", \\\"{x:1443,y:891,t:1527272413576};\\\", \\\"{x:1445,y:889,t:1527272413594};\\\", \\\"{x:1448,y:887,t:1527272413609};\\\", \\\"{x:1448,y:886,t:1527272413627};\\\", \\\"{x:1449,y:886,t:1527272413644};\\\", \\\"{x:1450,y:886,t:1527272413850};\\\", \\\"{x:1451,y:889,t:1527272413861};\\\", \\\"{x:1471,y:917,t:1527272413878};\\\", \\\"{x:1478,y:933,t:1527272413894};\\\", \\\"{x:1482,y:935,t:1527272413911};\\\", \\\"{x:1483,y:936,t:1527272413927};\\\", \\\"{x:1486,y:942,t:1527272413944};\\\", \\\"{x:1489,y:948,t:1527272413962};\\\", \\\"{x:1489,y:949,t:1527272413980};\\\", \\\"{x:1489,y:950,t:1527272414002};\\\", \\\"{x:1489,y:951,t:1527272414011};\\\", \\\"{x:1489,y:952,t:1527272414114};\\\", \\\"{x:1488,y:952,t:1527272414146};\\\", \\\"{x:1488,y:950,t:1527272414179};\\\", \\\"{x:1488,y:949,t:1527272414195};\\\", \\\"{x:1486,y:948,t:1527272414212};\\\", \\\"{x:1485,y:945,t:1527272414229};\\\", \\\"{x:1484,y:944,t:1527272414245};\\\", \\\"{x:1482,y:939,t:1527272414261};\\\", \\\"{x:1481,y:936,t:1527272414279};\\\", \\\"{x:1481,y:930,t:1527272414295};\\\", \\\"{x:1481,y:926,t:1527272414312};\\\", \\\"{x:1483,y:919,t:1527272414329};\\\", \\\"{x:1485,y:910,t:1527272414346};\\\", \\\"{x:1487,y:904,t:1527272414362};\\\", \\\"{x:1487,y:901,t:1527272414379};\\\", \\\"{x:1488,y:898,t:1527272414396};\\\", \\\"{x:1490,y:892,t:1527272414412};\\\", \\\"{x:1490,y:888,t:1527272414429};\\\", \\\"{x:1490,y:883,t:1527272414446};\\\", \\\"{x:1487,y:873,t:1527272414463};\\\", \\\"{x:1485,y:866,t:1527272414479};\\\", \\\"{x:1485,y:858,t:1527272414496};\\\", \\\"{x:1485,y:851,t:1527272414513};\\\", \\\"{x:1485,y:848,t:1527272414529};\\\", \\\"{x:1485,y:847,t:1527272414546};\\\", \\\"{x:1482,y:843,t:1527272414563};\\\", \\\"{x:1482,y:839,t:1527272414580};\\\", \\\"{x:1482,y:837,t:1527272414596};\\\", \\\"{x:1482,y:836,t:1527272414612};\\\", \\\"{x:1482,y:833,t:1527272414630};\\\", \\\"{x:1482,y:832,t:1527272415634};\\\", \\\"{x:1482,y:828,t:1527272415649};\\\", \\\"{x:1479,y:817,t:1527272415667};\\\", \\\"{x:1479,y:816,t:1527272415697};\\\", \\\"{x:1477,y:814,t:1527272415705};\\\", \\\"{x:1476,y:812,t:1527272415722};\\\", \\\"{x:1474,y:810,t:1527272415734};\\\", \\\"{x:1467,y:802,t:1527272415749};\\\", \\\"{x:1465,y:798,t:1527272415765};\\\", \\\"{x:1457,y:790,t:1527272415783};\\\", \\\"{x:1439,y:781,t:1527272415799};\\\", \\\"{x:1412,y:772,t:1527272415816};\\\", \\\"{x:1406,y:765,t:1527272415834};\\\", \\\"{x:1402,y:763,t:1527272415849};\\\", \\\"{x:1398,y:760,t:1527272415866};\\\", \\\"{x:1397,y:758,t:1527272415936};\\\", \\\"{x:1397,y:757,t:1527272415993};\\\", \\\"{x:1397,y:755,t:1527272416017};\\\", \\\"{x:1398,y:755,t:1527272416033};\\\", \\\"{x:1399,y:754,t:1527272416057};\\\", \\\"{x:1399,y:753,t:1527272416066};\\\", \\\"{x:1402,y:753,t:1527272416083};\\\", \\\"{x:1404,y:752,t:1527272416099};\\\", \\\"{x:1405,y:751,t:1527272416116};\\\", \\\"{x:1406,y:750,t:1527272416133};\\\", \\\"{x:1406,y:751,t:1527272416354};\\\", \\\"{x:1405,y:751,t:1527272416368};\\\", \\\"{x:1405,y:753,t:1527272416418};\\\", \\\"{x:1405,y:754,t:1527272416442};\\\", \\\"{x:1406,y:755,t:1527272416546};\\\", \\\"{x:1406,y:756,t:1527272416569};\\\", \\\"{x:1406,y:757,t:1527272416593};\\\", \\\"{x:1407,y:757,t:1527272416602};\\\", \\\"{x:1410,y:759,t:1527272416617};\\\", \\\"{x:1412,y:761,t:1527272416635};\\\", \\\"{x:1412,y:763,t:1527272416653};\\\", \\\"{x:1414,y:765,t:1527272416668};\\\", \\\"{x:1415,y:765,t:1527272416685};\\\", \\\"{x:1417,y:765,t:1527272416702};\\\", \\\"{x:1418,y:766,t:1527272416762};\\\", \\\"{x:1416,y:766,t:1527272416890};\\\", \\\"{x:1414,y:766,t:1527272416902};\\\", \\\"{x:1415,y:766,t:1527272417225};\\\", \\\"{x:1417,y:766,t:1527272417237};\\\", \\\"{x:1426,y:766,t:1527272417252};\\\", \\\"{x:1439,y:766,t:1527272417270};\\\", \\\"{x:1446,y:771,t:1527272417287};\\\", \\\"{x:1452,y:772,t:1527272417302};\\\", \\\"{x:1468,y:772,t:1527272417320};\\\", \\\"{x:1476,y:772,t:1527272417337};\\\", \\\"{x:1483,y:772,t:1527272417353};\\\", \\\"{x:1487,y:771,t:1527272417370};\\\", \\\"{x:1487,y:769,t:1527272417442};\\\", \\\"{x:1488,y:767,t:1527272417454};\\\", \\\"{x:1492,y:766,t:1527272417470};\\\", \\\"{x:1493,y:765,t:1527272417489};\\\", \\\"{x:1493,y:763,t:1527272417580};\\\", \\\"{x:1492,y:761,t:1527272417588};\\\", \\\"{x:1490,y:760,t:1527272417603};\\\", \\\"{x:1487,y:760,t:1527272417620};\\\", \\\"{x:1486,y:760,t:1527272417638};\\\", \\\"{x:1485,y:760,t:1527272417769};\\\", \\\"{x:1484,y:760,t:1527272417801};\\\", \\\"{x:1484,y:761,t:1527272417866};\\\", \\\"{x:1484,y:764,t:1527272417873};\\\", \\\"{x:1484,y:765,t:1527272417898};\\\", \\\"{x:1485,y:766,t:1527272417922};\\\", \\\"{x:1488,y:768,t:1527272417937};\\\", \\\"{x:1489,y:769,t:1527272417977};\\\", \\\"{x:1491,y:769,t:1527272417987};\\\", \\\"{x:1497,y:771,t:1527272418005};\\\", \\\"{x:1505,y:772,t:1527272418021};\\\", \\\"{x:1510,y:773,t:1527272418038};\\\", \\\"{x:1512,y:773,t:1527272418054};\\\", \\\"{x:1514,y:773,t:1527272418071};\\\", \\\"{x:1517,y:773,t:1527272418114};\\\", \\\"{x:1518,y:773,t:1527272418121};\\\", \\\"{x:1521,y:773,t:1527272418138};\\\", \\\"{x:1525,y:773,t:1527272418156};\\\", \\\"{x:1528,y:773,t:1527272418172};\\\", \\\"{x:1530,y:773,t:1527272418188};\\\", \\\"{x:1531,y:773,t:1527272418206};\\\", \\\"{x:1534,y:771,t:1527272418222};\\\", \\\"{x:1535,y:771,t:1527272418239};\\\", \\\"{x:1535,y:770,t:1527272418322};\\\", \\\"{x:1536,y:769,t:1527272418339};\\\", \\\"{x:1537,y:768,t:1527272418362};\\\", \\\"{x:1538,y:766,t:1527272418400};\\\", \\\"{x:1538,y:765,t:1527272418457};\\\", \\\"{x:1539,y:764,t:1527272418488};\\\", \\\"{x:1540,y:763,t:1527272418562};\\\", \\\"{x:1541,y:762,t:1527272418618};\\\", \\\"{x:1541,y:761,t:1527272418641};\\\", \\\"{x:1542,y:761,t:1527272418657};\\\", \\\"{x:1543,y:760,t:1527272418681};\\\", \\\"{x:1544,y:759,t:1527272418690};\\\", \\\"{x:1544,y:758,t:1527272418712};\\\", \\\"{x:1546,y:757,t:1527272418737};\\\", \\\"{x:1548,y:756,t:1527272418769};\\\", \\\"{x:1549,y:756,t:1527272418858};\\\", \\\"{x:1550,y:756,t:1527272418874};\\\", \\\"{x:1551,y:756,t:1527272418891};\\\", \\\"{x:1553,y:756,t:1527272418938};\\\", \\\"{x:1554,y:756,t:1527272418986};\\\", \\\"{x:1555,y:757,t:1527272418994};\\\", \\\"{x:1556,y:757,t:1527272419009};\\\", \\\"{x:1556,y:758,t:1527272419026};\\\", \\\"{x:1557,y:761,t:1527272419066};\\\", \\\"{x:1557,y:762,t:1527272419089};\\\", \\\"{x:1557,y:764,t:1527272419122};\\\", \\\"{x:1557,y:765,t:1527272419130};\\\", \\\"{x:1557,y:766,t:1527272419142};\\\", \\\"{x:1557,y:767,t:1527272419159};\\\", \\\"{x:1557,y:769,t:1527272419175};\\\", \\\"{x:1556,y:770,t:1527272419192};\\\", \\\"{x:1554,y:771,t:1527272419625};\\\", \\\"{x:1550,y:771,t:1527272419643};\\\", \\\"{x:1546,y:771,t:1527272419659};\\\", \\\"{x:1539,y:772,t:1527272419676};\\\", \\\"{x:1531,y:772,t:1527272419692};\\\", \\\"{x:1519,y:772,t:1527272419710};\\\", \\\"{x:1497,y:772,t:1527272419726};\\\", \\\"{x:1482,y:772,t:1527272419743};\\\", \\\"{x:1474,y:771,t:1527272419760};\\\", \\\"{x:1443,y:762,t:1527272419776};\\\", \\\"{x:1414,y:755,t:1527272419793};\\\", \\\"{x:1378,y:748,t:1527272419810};\\\", \\\"{x:1370,y:747,t:1527272419827};\\\", \\\"{x:1369,y:745,t:1527272419842};\\\", \\\"{x:1366,y:745,t:1527272419914};\\\", \\\"{x:1365,y:745,t:1527272419927};\\\", \\\"{x:1361,y:743,t:1527272419944};\\\", \\\"{x:1358,y:743,t:1527272419960};\\\", \\\"{x:1357,y:742,t:1527272419977};\\\", \\\"{x:1356,y:742,t:1527272419994};\\\", \\\"{x:1356,y:741,t:1527272420042};\\\", \\\"{x:1356,y:739,t:1527272420049};\\\", \\\"{x:1357,y:737,t:1527272420062};\\\", \\\"{x:1364,y:732,t:1527272420077};\\\", \\\"{x:1369,y:728,t:1527272420094};\\\", \\\"{x:1377,y:725,t:1527272420111};\\\", \\\"{x:1384,y:721,t:1527272420128};\\\", \\\"{x:1388,y:717,t:1527272420144};\\\", \\\"{x:1399,y:713,t:1527272420162};\\\", \\\"{x:1401,y:713,t:1527272420179};\\\", \\\"{x:1406,y:713,t:1527272420194};\\\", \\\"{x:1413,y:710,t:1527272420211};\\\", \\\"{x:1418,y:709,t:1527272420228};\\\", \\\"{x:1420,y:709,t:1527272420244};\\\", \\\"{x:1421,y:709,t:1527272420261};\\\", \\\"{x:1422,y:708,t:1527272420347};\\\", \\\"{x:1423,y:706,t:1527272420498};\\\", \\\"{x:1415,y:704,t:1527272420594};\\\", \\\"{x:1399,y:699,t:1527272420612};\\\", \\\"{x:1398,y:697,t:1527272420629};\\\", \\\"{x:1398,y:695,t:1527272420690};\\\", \\\"{x:1398,y:694,t:1527272420730};\\\", \\\"{x:1401,y:693,t:1527272420818};\\\", \\\"{x:1404,y:694,t:1527272420829};\\\", \\\"{x:1408,y:700,t:1527272420847};\\\", \\\"{x:1409,y:700,t:1527272420864};\\\", \\\"{x:1412,y:705,t:1527272420879};\\\", \\\"{x:1415,y:708,t:1527272420896};\\\", \\\"{x:1419,y:713,t:1527272420913};\\\", \\\"{x:1423,y:717,t:1527272420930};\\\", \\\"{x:1425,y:718,t:1527272420946};\\\", \\\"{x:1432,y:721,t:1527272420963};\\\", \\\"{x:1436,y:723,t:1527272420980};\\\", \\\"{x:1442,y:724,t:1527272420996};\\\", \\\"{x:1444,y:724,t:1527272421013};\\\", \\\"{x:1445,y:724,t:1527272421030};\\\", \\\"{x:1446,y:724,t:1527272421046};\\\", \\\"{x:1448,y:723,t:1527272421063};\\\", \\\"{x:1451,y:721,t:1527272421081};\\\", \\\"{x:1454,y:719,t:1527272421098};\\\", \\\"{x:1456,y:717,t:1527272421113};\\\", \\\"{x:1458,y:714,t:1527272421130};\\\", \\\"{x:1461,y:711,t:1527272421147};\\\", \\\"{x:1462,y:710,t:1527272421163};\\\", \\\"{x:1465,y:709,t:1527272421226};\\\", \\\"{x:1465,y:708,t:1527272421234};\\\", \\\"{x:1466,y:707,t:1527272421634};\\\", \\\"{x:1466,y:706,t:1527272421650};\\\", \\\"{x:1469,y:703,t:1527272421665};\\\", \\\"{x:1470,y:702,t:1527272421681};\\\", \\\"{x:1471,y:701,t:1527272421698};\\\", \\\"{x:1472,y:700,t:1527272421715};\\\", \\\"{x:1473,y:698,t:1527272421732};\\\", \\\"{x:1474,y:698,t:1527272421748};\\\", \\\"{x:1474,y:697,t:1527272421765};\\\", \\\"{x:1475,y:695,t:1527272421782};\\\", \\\"{x:1476,y:695,t:1527272421798};\\\", \\\"{x:1477,y:694,t:1527272421818};\\\", \\\"{x:1475,y:694,t:1527272422605};\\\", \\\"{x:1474,y:694,t:1527272422621};\\\", \\\"{x:1472,y:694,t:1527272422789};\\\", \\\"{x:1469,y:692,t:1527272422805};\\\", \\\"{x:1467,y:692,t:1527272422822};\\\", \\\"{x:1463,y:692,t:1527272422838};\\\", \\\"{x:1458,y:692,t:1527272422855};\\\", \\\"{x:1451,y:692,t:1527272422872};\\\", \\\"{x:1440,y:692,t:1527272422890};\\\", \\\"{x:1438,y:692,t:1527272422905};\\\", \\\"{x:1433,y:692,t:1527272422922};\\\", \\\"{x:1429,y:692,t:1527272422939};\\\", \\\"{x:1426,y:692,t:1527272422955};\\\", \\\"{x:1425,y:692,t:1527272422972};\\\", \\\"{x:1422,y:693,t:1527272423070};\\\", \\\"{x:1420,y:693,t:1527272423085};\\\", \\\"{x:1418,y:694,t:1527272423094};\\\", \\\"{x:1415,y:695,t:1527272423106};\\\", \\\"{x:1413,y:695,t:1527272423124};\\\", \\\"{x:1403,y:695,t:1527272423139};\\\", \\\"{x:1395,y:695,t:1527272423156};\\\", \\\"{x:1375,y:695,t:1527272423173};\\\", \\\"{x:1366,y:695,t:1527272423190};\\\", \\\"{x:1349,y:695,t:1527272423206};\\\", \\\"{x:1328,y:694,t:1527272423224};\\\", \\\"{x:1301,y:693,t:1527272423240};\\\", \\\"{x:1258,y:693,t:1527272423256};\\\", \\\"{x:1201,y:682,t:1527272423273};\\\", \\\"{x:1184,y:680,t:1527272423290};\\\", \\\"{x:1143,y:679,t:1527272423306};\\\", \\\"{x:1094,y:671,t:1527272423323};\\\", \\\"{x:1083,y:666,t:1527272423340};\\\", \\\"{x:1071,y:661,t:1527272423357};\\\", \\\"{x:1067,y:654,t:1527272423373};\\\", \\\"{x:1055,y:653,t:1527272423389};\\\", \\\"{x:1046,y:651,t:1527272423407};\\\", \\\"{x:1045,y:651,t:1527272423423};\\\", \\\"{x:1042,y:651,t:1527272423440};\\\", \\\"{x:1041,y:650,t:1527272423457};\\\", \\\"{x:1035,y:650,t:1527272423473};\\\", \\\"{x:1028,y:650,t:1527272423490};\\\", \\\"{x:1022,y:647,t:1527272423507};\\\", \\\"{x:1019,y:646,t:1527272423524};\\\", \\\"{x:1017,y:646,t:1527272423540};\\\", \\\"{x:1012,y:646,t:1527272423557};\\\", \\\"{x:1004,y:646,t:1527272423574};\\\", \\\"{x:996,y:646,t:1527272423590};\\\", \\\"{x:978,y:646,t:1527272423607};\\\", \\\"{x:964,y:638,t:1527272423623};\\\", \\\"{x:957,y:637,t:1527272423645};\\\", \\\"{x:943,y:636,t:1527272423658};\\\", \\\"{x:924,y:633,t:1527272423674};\\\", \\\"{x:910,y:631,t:1527272423691};\\\", \\\"{x:909,y:631,t:1527272423698};\\\", \\\"{x:902,y:631,t:1527272423715};\\\", \\\"{x:893,y:631,t:1527272423731};\\\", \\\"{x:890,y:632,t:1527272423748};\\\", \\\"{x:887,y:632,t:1527272423765};\\\", \\\"{x:885,y:632,t:1527272423829};\\\", \\\"{x:884,y:632,t:1527272423845};\\\", \\\"{x:883,y:632,t:1527272423861};\\\", \\\"{x:881,y:632,t:1527272423877};\\\", \\\"{x:880,y:632,t:1527272423902};\\\", \\\"{x:873,y:633,t:1527272424262};\\\", \\\"{x:847,y:630,t:1527272424270};\\\", \\\"{x:809,y:621,t:1527272424283};\\\", \\\"{x:787,y:610,t:1527272424300};\\\", \\\"{x:752,y:593,t:1527272424317};\\\", \\\"{x:751,y:592,t:1527272424333};\\\", \\\"{x:750,y:592,t:1527272424461};\\\", \\\"{x:749,y:592,t:1527272424469};\\\", \\\"{x:745,y:592,t:1527272424517};\\\", \\\"{x:724,y:591,t:1527272424533};\\\", \\\"{x:665,y:584,t:1527272424552};\\\", \\\"{x:595,y:584,t:1527272424566};\\\", \\\"{x:557,y:581,t:1527272424584};\\\", \\\"{x:541,y:579,t:1527272424600};\\\", \\\"{x:529,y:579,t:1527272424616};\\\", \\\"{x:511,y:577,t:1527272424634};\\\", \\\"{x:503,y:576,t:1527272424651};\\\", \\\"{x:496,y:576,t:1527272424666};\\\", \\\"{x:490,y:576,t:1527272424684};\\\", \\\"{x:487,y:576,t:1527272424699};\\\", \\\"{x:485,y:574,t:1527272424716};\\\", \\\"{x:485,y:573,t:1527272424733};\\\", \\\"{x:485,y:571,t:1527272424750};\\\", \\\"{x:483,y:571,t:1527272424878};\\\", \\\"{x:480,y:571,t:1527272424885};\\\", \\\"{x:476,y:571,t:1527272424901};\\\", \\\"{x:469,y:575,t:1527272424917};\\\", \\\"{x:444,y:577,t:1527272424934};\\\", \\\"{x:429,y:578,t:1527272424951};\\\", \\\"{x:401,y:582,t:1527272424967};\\\", \\\"{x:368,y:583,t:1527272424984};\\\", \\\"{x:349,y:583,t:1527272425001};\\\", \\\"{x:345,y:585,t:1527272425029};\\\", \\\"{x:344,y:585,t:1527272425036};\\\", \\\"{x:343,y:585,t:1527272425077};\\\", \\\"{x:341,y:585,t:1527272425084};\\\", \\\"{x:339,y:587,t:1527272425101};\\\", \\\"{x:336,y:588,t:1527272425116};\\\", \\\"{x:327,y:592,t:1527272425133};\\\", \\\"{x:300,y:604,t:1527272425150};\\\", \\\"{x:289,y:610,t:1527272425167};\\\", \\\"{x:281,y:616,t:1527272425184};\\\", \\\"{x:277,y:619,t:1527272425201};\\\", \\\"{x:273,y:620,t:1527272425218};\\\", \\\"{x:269,y:623,t:1527272425235};\\\", \\\"{x:268,y:625,t:1527272425250};\\\", \\\"{x:267,y:626,t:1527272425267};\\\", \\\"{x:266,y:627,t:1527272425283};\\\", \\\"{x:265,y:627,t:1527272425301};\\\", \\\"{x:265,y:628,t:1527272425383};\\\", \\\"{x:278,y:628,t:1527272425431};\\\", \\\"{x:299,y:622,t:1527272425450};\\\", \\\"{x:328,y:614,t:1527272425467};\\\", \\\"{x:350,y:606,t:1527272425484};\\\", \\\"{x:357,y:601,t:1527272425500};\\\", \\\"{x:363,y:596,t:1527272425517};\\\", \\\"{x:372,y:593,t:1527272425533};\\\", \\\"{x:377,y:590,t:1527272425550};\\\", \\\"{x:381,y:588,t:1527272425567};\\\", \\\"{x:388,y:583,t:1527272425584};\\\", \\\"{x:398,y:579,t:1527272425600};\\\", \\\"{x:413,y:571,t:1527272425618};\\\", \\\"{x:426,y:562,t:1527272425635};\\\", \\\"{x:440,y:553,t:1527272425650};\\\", \\\"{x:458,y:547,t:1527272425668};\\\", \\\"{x:485,y:538,t:1527272425685};\\\", \\\"{x:496,y:531,t:1527272425701};\\\", \\\"{x:504,y:528,t:1527272425719};\\\", \\\"{x:507,y:526,t:1527272425734};\\\", \\\"{x:508,y:526,t:1527272425750};\\\", \\\"{x:508,y:525,t:1527272425767};\\\", \\\"{x:510,y:524,t:1527272425813};\\\", \\\"{x:511,y:523,t:1527272425828};\\\", \\\"{x:511,y:522,t:1527272425836};\\\", \\\"{x:512,y:517,t:1527272425868};\\\", \\\"{x:520,y:517,t:1527272425884};\\\", \\\"{x:555,y:520,t:1527272425901};\\\", \\\"{x:641,y:532,t:1527272425919};\\\", \\\"{x:682,y:537,t:1527272425934};\\\", \\\"{x:725,y:544,t:1527272425951};\\\", \\\"{x:761,y:541,t:1527272425967};\\\", \\\"{x:804,y:542,t:1527272425985};\\\", \\\"{x:823,y:542,t:1527272426000};\\\", \\\"{x:827,y:541,t:1527272426017};\\\", \\\"{x:833,y:539,t:1527272426034};\\\", \\\"{x:835,y:538,t:1527272426052};\\\", \\\"{x:836,y:537,t:1527272426067};\\\", \\\"{x:838,y:537,t:1527272426084};\\\", \\\"{x:843,y:534,t:1527272426101};\\\", \\\"{x:848,y:530,t:1527272426118};\\\", \\\"{x:853,y:529,t:1527272426134};\\\", \\\"{x:858,y:526,t:1527272426151};\\\", \\\"{x:861,y:523,t:1527272426167};\\\", \\\"{x:863,y:522,t:1527272426184};\\\", \\\"{x:865,y:521,t:1527272426201};\\\", \\\"{x:866,y:520,t:1527272426229};\\\", \\\"{x:866,y:518,t:1527272426285};\\\", \\\"{x:866,y:516,t:1527272426301};\\\", \\\"{x:864,y:512,t:1527272426318};\\\", \\\"{x:863,y:512,t:1527272426334};\\\", \\\"{x:862,y:512,t:1527272426351};\\\", \\\"{x:861,y:512,t:1527272426548};\\\", \\\"{x:857,y:513,t:1527272426556};\\\", \\\"{x:854,y:516,t:1527272426568};\\\", \\\"{x:841,y:528,t:1527272426585};\\\", \\\"{x:836,y:533,t:1527272426602};\\\", \\\"{x:821,y:545,t:1527272426619};\\\", \\\"{x:804,y:557,t:1527272426634};\\\", \\\"{x:782,y:571,t:1527272426652};\\\", \\\"{x:737,y:590,t:1527272426669};\\\", \\\"{x:715,y:600,t:1527272426685};\\\", \\\"{x:684,y:611,t:1527272426702};\\\", \\\"{x:667,y:619,t:1527272426719};\\\", \\\"{x:659,y:624,t:1527272426734};\\\", \\\"{x:658,y:625,t:1527272426751};\\\", \\\"{x:655,y:628,t:1527272426797};\\\", \\\"{x:647,y:635,t:1527272426804};\\\", \\\"{x:641,y:640,t:1527272426819};\\\", \\\"{x:627,y:652,t:1527272426836};\\\", \\\"{x:613,y:663,t:1527272426851};\\\", \\\"{x:597,y:678,t:1527272426868};\\\", \\\"{x:590,y:685,t:1527272426885};\\\", \\\"{x:585,y:689,t:1527272426901};\\\", \\\"{x:580,y:693,t:1527272426919};\\\", \\\"{x:577,y:694,t:1527272426936};\\\", \\\"{x:572,y:700,t:1527272426952};\\\", \\\"{x:565,y:706,t:1527272426969};\\\", \\\"{x:557,y:714,t:1527272426986};\\\", \\\"{x:543,y:721,t:1527272427002};\\\", \\\"{x:533,y:727,t:1527272427019};\\\", \\\"{x:522,y:735,t:1527272427036};\\\", \\\"{x:513,y:741,t:1527272427051};\\\", \\\"{x:504,y:749,t:1527272427068};\\\", \\\"{x:500,y:750,t:1527272427085};\\\", \\\"{x:499,y:751,t:1527272427102};\\\", \\\"{x:498,y:751,t:1527272427118};\\\" ] }, { \\\"rt\\\": 51142, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 896998, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Find the 12PM mark on the x axis and then move directly up to find the dots that are right above this point.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6369, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 904374, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 14316, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Math or Computer Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 919712, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 19199, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 940237, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"YFWR3\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"YFWR3\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 225, dom: 780, initialDom: 846",
  "javascriptErrors": []
}