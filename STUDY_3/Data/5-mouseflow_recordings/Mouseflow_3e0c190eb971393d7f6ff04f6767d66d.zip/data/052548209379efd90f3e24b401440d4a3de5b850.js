var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052548209379efd90f3e24b401440d4a3de5b850"] = {
  "startTime": "2018-05-25T17:16:48.3316302Z",
  "websitePageUrl": "/16",
  "visitTime": 67102,
  "engagementTime": 62628,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "3e0c190eb971393d7f6ff04f6767d66d",
    "created": "2018-05-25T17:16:48.3316302+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=CE2FW",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "bbb7b1eec5e6c0a59fee42d6e4179570",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/3e0c190eb971393d7f6ff04f6767d66d/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 199,
      "e": 199,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 601,
      "e": 601,
      "ty": 2,
      "x": 532,
      "y": 740
    },
    {
      "t": 789,
      "e": 789,
      "ty": 41,
      "x": 48887,
      "y": 40550,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 531,
      "y": 739
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 469,
      "y": 654
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 41805,
      "y": 35786,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1044,
      "e": 1044,
      "ty": 6,
      "x": 383,
      "y": 587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 382,
      "y": 585
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 381,
      "y": 561
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 31913,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 3,
      "x": 381,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1302,
      "e": 1302,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1356,
      "e": 1356,
      "ty": 4,
      "x": 31913,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1356,
      "e": 1356,
      "ty": 5,
      "x": 381,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10002,
      "e": 6356,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10817,
      "e": 6356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 10992,
      "e": 6531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 11112,
      "e": 6651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11113,
      "e": 6652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11215,
      "e": 6754,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "a"
    },
    {
      "t": 11449,
      "e": 6988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11536,
      "e": 7075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 11705,
      "e": 7244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 11706,
      "e": 7245,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11815,
      "e": 7354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 11831,
      "e": 7370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i"
    },
    {
      "t": 11920,
      "e": 7459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11920,
      "e": 7459,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11962,
      "e": 7501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i "
    },
    {
      "t": 12007,
      "e": 7546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i "
    },
    {
      "t": 12143,
      "e": 7682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 12144,
      "e": 7683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12239,
      "e": 7778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i L"
    },
    {
      "t": 12352,
      "e": 7891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12352,
      "e": 7891,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12464,
      "e": 8003,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i LO"
    },
    {
      "t": 12552,
      "e": 8091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12553,
      "e": 8092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12623,
      "e": 8162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 12689,
      "e": 8228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 12689,
      "e": 8228,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12792,
      "e": 8331,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||K"
    },
    {
      "t": 12872,
      "e": 8411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12873,
      "e": 8412,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12959,
      "e": 8498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13263,
      "e": 8802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13404,
      "e": 8943,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i LOOK"
    },
    {
      "t": 13763,
      "e": 9302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13796,
      "e": 9335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13828,
      "e": 9367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13862,
      "e": 9401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13895,
      "e": 9434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13928,
      "e": 9467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13961,
      "e": 9500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13994,
      "e": 9533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14027,
      "e": 9566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14061,
      "e": 9600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14093,
      "e": 9632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14126,
      "e": 9665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14159,
      "e": 9698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14192,
      "e": 9731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14225,
      "e": 9764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14248,
      "e": 9787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 14720,
      "e": 10259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 14824,
      "e": 10363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 15272,
      "e": 10811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 15368,
      "e": 10907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 15874,
      "e": 11413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15875,
      "e": 11414,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15953,
      "e": 11492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 16186,
      "e": 11725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 16298,
      "e": 11837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 16410,
      "e": 11949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16411,
      "e": 11950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16506,
      "e": 12045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I "
    },
    {
      "t": 17002,
      "e": 12541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 17003,
      "e": 12542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17065,
      "e": 12604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I l"
    },
    {
      "t": 17179,
      "e": 12718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17179,
      "e": 12718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17225,
      "e": 12764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I lo"
    },
    {
      "t": 17345,
      "e": 12884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17347,
      "e": 12886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17386,
      "e": 12925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 17467,
      "e": 13006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 17467,
      "e": 13006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17570,
      "e": 13109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 17617,
      "e": 13156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17618,
      "e": 13157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17714,
      "e": 13253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17770,
      "e": 13309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17770,
      "e": 13309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17882,
      "e": 13421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 18338,
      "e": 13877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18339,
      "e": 13878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18361,
      "e": 13900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 18586,
      "e": 14125,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18587,
      "e": 14126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18681,
      "e": 14220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18730,
      "e": 14269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18730,
      "e": 14269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18809,
      "e": 14348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 18841,
      "e": 14380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 18841,
      "e": 14380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18922,
      "e": 14461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 19043,
      "e": 14582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19043,
      "e": 14582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19113,
      "e": 14652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 19250,
      "e": 14789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19251,
      "e": 14790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19337,
      "e": 14876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20003,
      "e": 15542,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 22923,
      "e": 18462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 22924,
      "e": 18463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22986,
      "e": 18525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 23082,
      "e": 18621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23082,
      "e": 18621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23178,
      "e": 18717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24058,
      "e": 19597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 24059,
      "e": 19598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24131,
      "e": 19670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 25130,
      "e": 20669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 25130,
      "e": 20669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25201,
      "e": 20740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 25323,
      "e": 20862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25323,
      "e": 20862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25385,
      "e": 20924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25490,
      "e": 21029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25490,
      "e": 21029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25570,
      "e": 21109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26386,
      "e": 21925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26387,
      "e": 21926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26433,
      "e": 21972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26506,
      "e": 22045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26506,
      "e": 22045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26577,
      "e": 22116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 26690,
      "e": 22229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 26691,
      "e": 22230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26777,
      "e": 22316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 26857,
      "e": 22396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26858,
      "e": 22397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26898,
      "e": 22437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26938,
      "e": 22477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26938,
      "e": 22477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27018,
      "e": 22557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27074,
      "e": 22613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27075,
      "e": 22614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27122,
      "e": 22661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 27122,
      "e": 22661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27185,
      "e": 22724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||of"
    },
    {
      "t": 27209,
      "e": 22748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27217,
      "e": 22756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27217,
      "e": 22756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27314,
      "e": 22853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27362,
      "e": 22901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27363,
      "e": 22902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27434,
      "e": 22973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 27442,
      "e": 22981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 27442,
      "e": 22981,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27529,
      "e": 23068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 27610,
      "e": 23149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27611,
      "e": 23150,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27690,
      "e": 23229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 27698,
      "e": 23237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27698,
      "e": 23237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27770,
      "e": 23309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27914,
      "e": 23453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 27915,
      "e": 23454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28010,
      "e": 23549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28010,
      "e": 23549,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28074,
      "e": 23613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||da"
    },
    {
      "t": 28138,
      "e": 23677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 28139,
      "e": 23678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28179,
      "e": 23718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 28203,
      "e": 23742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28266,
      "e": 23805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28267,
      "e": 23806,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28337,
      "e": 23876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29336,
      "e": 24875,
      "ty": 7,
      "x": 381,
      "y": 628,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29352,
      "e": 24891,
      "ty": 6,
      "x": 377,
      "y": 667,
      "ta": "#strategyButton"
    },
    {
      "t": 29368,
      "e": 24907,
      "ty": 7,
      "x": 376,
      "y": 689,
      "ta": "#strategyButton"
    },
    {
      "t": 29403,
      "e": 24942,
      "ty": 2,
      "x": 375,
      "y": 700
    },
    {
      "t": 29504,
      "e": 25043,
      "ty": 41,
      "x": 26404,
      "y": 51291,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 29604,
      "e": 25143,
      "ty": 6,
      "x": 372,
      "y": 683,
      "ta": "#strategyButton"
    },
    {
      "t": 29606,
      "e": 25145,
      "ty": 2,
      "x": 372,
      "y": 683
    },
    {
      "t": 29703,
      "e": 25242,
      "ty": 2,
      "x": 373,
      "y": 663
    },
    {
      "t": 29753,
      "e": 25292,
      "ty": 41,
      "x": 18790,
      "y": 15931,
      "ta": "#strategyButton"
    },
    {
      "t": 29903,
      "e": 25442,
      "ty": 2,
      "x": 373,
      "y": 670
    },
    {
      "t": 29911,
      "e": 25450,
      "ty": 3,
      "x": 373,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 29912,
      "e": 25451,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I look at the start time of the day "
    },
    {
      "t": 29913,
      "e": 25452,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29914,
      "e": 25453,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 29998,
      "e": 25537,
      "ty": 4,
      "x": 18790,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 30008,
      "e": 25547,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 30011,
      "e": 25550,
      "ty": 5,
      "x": 373,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 30020,
      "e": 25559,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 30022,
      "e": 25561,
      "ty": 41,
      "x": 12569,
      "y": 36673,
      "ta": "html > body"
    },
    {
      "t": 30022,
      "e": 25561,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30254,
      "e": 25793,
      "ty": 41,
      "x": 12535,
      "y": 36673,
      "ta": "html > body"
    },
    {
      "t": 30304,
      "e": 25843,
      "ty": 2,
      "x": 372,
      "y": 670
    },
    {
      "t": 30603,
      "e": 26142,
      "ty": 2,
      "x": 402,
      "y": 695
    },
    {
      "t": 30704,
      "e": 26243,
      "ty": 2,
      "x": 895,
      "y": 578
    },
    {
      "t": 30754,
      "e": 26293,
      "ty": 41,
      "x": 32578,
      "y": 27809,
      "ta": "html > body"
    },
    {
      "t": 30803,
      "e": 26342,
      "ty": 2,
      "x": 954,
      "y": 510
    },
    {
      "t": 30903,
      "e": 26442,
      "ty": 2,
      "x": 954,
      "y": 509
    },
    {
      "t": 31003,
      "e": 26542,
      "ty": 2,
      "x": 952,
      "y": 506
    },
    {
      "t": 31004,
      "e": 26543,
      "ty": 41,
      "x": 32509,
      "y": 27587,
      "ta": "html > body"
    },
    {
      "t": 31017,
      "e": 26556,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 31603,
      "e": 27142,
      "ty": 2,
      "x": 954,
      "y": 523
    },
    {
      "t": 31704,
      "e": 27243,
      "ty": 2,
      "x": 954,
      "y": 529
    },
    {
      "t": 31753,
      "e": 27292,
      "ty": 41,
      "x": 31577,
      "y": 49151,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 31804,
      "e": 27343,
      "ty": 2,
      "x": 952,
      "y": 539
    },
    {
      "t": 31854,
      "e": 27393,
      "ty": 6,
      "x": 947,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 31904,
      "e": 27443,
      "ty": 2,
      "x": 943,
      "y": 566
    },
    {
      "t": 31983,
      "e": 27522,
      "ty": 3,
      "x": 943,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 31984,
      "e": 27523,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32003,
      "e": 27542,
      "ty": 41,
      "x": 29198,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32053,
      "e": 27592,
      "ty": 4,
      "x": 29198,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32053,
      "e": 27592,
      "ty": 5,
      "x": 943,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32874,
      "e": 28413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 32874,
      "e": 28413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32937,
      "e": 28476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 32994,
      "e": 28533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 32994,
      "e": 28533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33073,
      "e": 28612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 33346,
      "e": 28885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 33347,
      "e": 28886,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 33347,
      "e": 28886,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33349,
      "e": 28888,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 33409,
      "e": 28948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 35042,
      "e": 30581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 35097,
      "e": 30636,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 35554,
      "e": 31093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 35555,
      "e": 31094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35657,
      "e": 31196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 36105,
      "e": 31644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "190"
    },
    {
      "t": 36106,
      "e": 31645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36162,
      "e": 31701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U."
    },
    {
      "t": 36322,
      "e": 31861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 36323,
      "e": 31862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36401,
      "e": 31940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U.S"
    },
    {
      "t": 37618,
      "e": 33157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "190"
    },
    {
      "t": 37619,
      "e": 33158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37729,
      "e": 33268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U.S."
    },
    {
      "t": 37762,
      "e": 33301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 37762,
      "e": 33301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37866,
      "e": 33405,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 38202,
      "e": 33741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 38266,
      "e": 33805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U.S."
    },
    {
      "t": 38354,
      "e": 33893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 38434,
      "e": 33973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U.S"
    },
    {
      "t": 38522,
      "e": 34061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 38561,
      "e": 34100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U."
    },
    {
      "t": 38690,
      "e": 34229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 38714,
      "e": 34253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 39459,
      "e": 34998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 39459,
      "e": 34998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39537,
      "e": 35076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 39691,
      "e": 35230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 39691,
      "e": 35230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39745,
      "e": 35284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 39865,
      "e": 35404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 39938,
      "e": 35477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 40003,
      "e": 35542,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40428,
      "e": 35967,
      "ty": 7,
      "x": 887,
      "y": 548,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40503,
      "e": 36042,
      "ty": 2,
      "x": 734,
      "y": 514
    },
    {
      "t": 40503,
      "e": 36042,
      "ty": 41,
      "x": 25001,
      "y": 28031,
      "ta": "html > body"
    },
    {
      "t": 40603,
      "e": 36142,
      "ty": 2,
      "x": 837,
      "y": 634
    },
    {
      "t": 40612,
      "e": 36151,
      "ty": 6,
      "x": 844,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40678,
      "e": 36217,
      "ty": 7,
      "x": 865,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40703,
      "e": 36242,
      "ty": 2,
      "x": 893,
      "y": 719
    },
    {
      "t": 40753,
      "e": 36292,
      "ty": 41,
      "x": 32474,
      "y": 41547,
      "ta": "html > body"
    },
    {
      "t": 40803,
      "e": 36342,
      "ty": 2,
      "x": 960,
      "y": 758
    },
    {
      "t": 40903,
      "e": 36442,
      "ty": 2,
      "x": 961,
      "y": 758
    },
    {
      "t": 41003,
      "e": 36542,
      "ty": 2,
      "x": 961,
      "y": 717
    },
    {
      "t": 41004,
      "e": 36543,
      "ty": 41,
      "x": 32819,
      "y": 39276,
      "ta": "html > body"
    },
    {
      "t": 41047,
      "e": 36586,
      "ty": 6,
      "x": 961,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41103,
      "e": 36642,
      "ty": 2,
      "x": 961,
      "y": 699
    },
    {
      "t": 41253,
      "e": 36792,
      "ty": 41,
      "x": 33540,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41254,
      "e": 36793,
      "ty": 3,
      "x": 961,
      "y": 699,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41255,
      "e": 36794,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 41256,
      "e": 36795,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41257,
      "e": 36796,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41326,
      "e": 36865,
      "ty": 4,
      "x": 33540,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41326,
      "e": 36865,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41327,
      "e": 36866,
      "ty": 5,
      "x": 961,
      "y": 699,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41327,
      "e": 36866,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 42339,
      "e": 37878,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 42903,
      "e": 38442,
      "ty": 2,
      "x": 960,
      "y": 646
    },
    {
      "t": 42979,
      "e": 38518,
      "ty": 6,
      "x": 834,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 42996,
      "e": 38535,
      "ty": 7,
      "x": 828,
      "y": 206,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43003,
      "e": 38542,
      "ty": 2,
      "x": 828,
      "y": 206
    },
    {
      "t": 43003,
      "e": 38542,
      "ty": 41,
      "x": 1561,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 43103,
      "e": 38642,
      "ty": 2,
      "x": 827,
      "y": 161
    },
    {
      "t": 43254,
      "e": 38793,
      "ty": 41,
      "x": 1323,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 43304,
      "e": 38843,
      "ty": 2,
      "x": 829,
      "y": 160
    },
    {
      "t": 43403,
      "e": 38942,
      "ty": 2,
      "x": 841,
      "y": 224
    },
    {
      "t": 43503,
      "e": 39042,
      "ty": 2,
      "x": 841,
      "y": 257
    },
    {
      "t": 43503,
      "e": 39042,
      "ty": 41,
      "x": 14911,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 43648,
      "e": 39187,
      "ty": 6,
      "x": 830,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 43703,
      "e": 39242,
      "ty": 2,
      "x": 830,
      "y": 241
    },
    {
      "t": 43753,
      "e": 39292,
      "ty": 41,
      "x": 18037,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 44469,
      "e": 40008,
      "ty": 7,
      "x": 825,
      "y": 246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 44503,
      "e": 40042,
      "ty": 2,
      "x": 817,
      "y": 267
    },
    {
      "t": 44503,
      "e": 40042,
      "ty": 41,
      "x": 27860,
      "y": 14347,
      "ta": "html > body"
    },
    {
      "t": 44604,
      "e": 40143,
      "ty": 2,
      "x": 808,
      "y": 288
    },
    {
      "t": 44703,
      "e": 40242,
      "ty": 2,
      "x": 806,
      "y": 295
    },
    {
      "t": 44753,
      "e": 40292,
      "ty": 41,
      "x": 27550,
      "y": 16176,
      "ta": "html > body"
    },
    {
      "t": 44803,
      "e": 40342,
      "ty": 2,
      "x": 808,
      "y": 300
    },
    {
      "t": 44899,
      "e": 40438,
      "ty": 6,
      "x": 826,
      "y": 293,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 44903,
      "e": 40442,
      "ty": 2,
      "x": 826,
      "y": 293
    },
    {
      "t": 45003,
      "e": 40542,
      "ty": 2,
      "x": 830,
      "y": 290
    },
    {
      "t": 45003,
      "e": 40542,
      "ty": 41,
      "x": 18037,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 45203,
      "e": 40742,
      "ty": 2,
      "x": 830,
      "y": 291
    },
    {
      "t": 45254,
      "e": 40793,
      "ty": 41,
      "x": 23079,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 45304,
      "e": 40843,
      "ty": 2,
      "x": 831,
      "y": 292
    },
    {
      "t": 45880,
      "e": 41419,
      "ty": 3,
      "x": 831,
      "y": 292,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 45881,
      "e": 41420,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 45973,
      "e": 41512,
      "ty": 4,
      "x": 23079,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 45974,
      "e": 41513,
      "ty": 5,
      "x": 831,
      "y": 292,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 45974,
      "e": 41513,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 46295,
      "e": 41834,
      "ty": 7,
      "x": 834,
      "y": 303,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 46304,
      "e": 41843,
      "ty": 2,
      "x": 839,
      "y": 331
    },
    {
      "t": 46403,
      "e": 41942,
      "ty": 2,
      "x": 855,
      "y": 418
    },
    {
      "t": 46503,
      "e": 42042,
      "ty": 2,
      "x": 855,
      "y": 419
    },
    {
      "t": 46503,
      "e": 42042,
      "ty": 41,
      "x": 39306,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 46703,
      "e": 42242,
      "ty": 2,
      "x": 824,
      "y": 396
    },
    {
      "t": 46754,
      "e": 42293,
      "ty": 41,
      "x": 611,
      "y": 9207,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 46803,
      "e": 42342,
      "ty": 2,
      "x": 824,
      "y": 381
    },
    {
      "t": 46904,
      "e": 42443,
      "ty": 2,
      "x": 825,
      "y": 380
    },
    {
      "t": 47004,
      "e": 42543,
      "ty": 2,
      "x": 826,
      "y": 385
    },
    {
      "t": 47004,
      "e": 42543,
      "ty": 41,
      "x": 1086,
      "y": 8124,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 47103,
      "e": 42642,
      "ty": 2,
      "x": 822,
      "y": 404
    },
    {
      "t": 47203,
      "e": 42742,
      "ty": 2,
      "x": 822,
      "y": 419
    },
    {
      "t": 47253,
      "e": 42792,
      "ty": 41,
      "x": 676,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 47303,
      "e": 42842,
      "ty": 2,
      "x": 822,
      "y": 422
    },
    {
      "t": 47503,
      "e": 43042,
      "ty": 2,
      "x": 825,
      "y": 418
    },
    {
      "t": 47504,
      "e": 43043,
      "ty": 41,
      "x": 4188,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 47519,
      "e": 43045,
      "ty": 6,
      "x": 826,
      "y": 414,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 47534,
      "e": 43060,
      "ty": 7,
      "x": 830,
      "y": 405,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 47603,
      "e": 43129,
      "ty": 2,
      "x": 835,
      "y": 387
    },
    {
      "t": 47703,
      "e": 43229,
      "ty": 2,
      "x": 838,
      "y": 379
    },
    {
      "t": 47754,
      "e": 43280,
      "ty": 41,
      "x": 4883,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 47803,
      "e": 43329,
      "ty": 2,
      "x": 845,
      "y": 375
    },
    {
      "t": 47903,
      "e": 43429,
      "ty": 2,
      "x": 847,
      "y": 374
    },
    {
      "t": 48003,
      "e": 43529,
      "ty": 41,
      "x": 6070,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 48104,
      "e": 43630,
      "ty": 2,
      "x": 848,
      "y": 373
    },
    {
      "t": 48203,
      "e": 43729,
      "ty": 2,
      "x": 860,
      "y": 370
    },
    {
      "t": 48254,
      "e": 43780,
      "ty": 41,
      "x": 11054,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 48303,
      "e": 43829,
      "ty": 2,
      "x": 874,
      "y": 368
    },
    {
      "t": 48404,
      "e": 43930,
      "ty": 2,
      "x": 888,
      "y": 367
    },
    {
      "t": 48504,
      "e": 44030,
      "ty": 2,
      "x": 917,
      "y": 367
    },
    {
      "t": 48504,
      "e": 44030,
      "ty": 41,
      "x": 22683,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 48603,
      "e": 44129,
      "ty": 2,
      "x": 917,
      "y": 368
    },
    {
      "t": 48704,
      "e": 44230,
      "ty": 2,
      "x": 917,
      "y": 371
    },
    {
      "t": 48753,
      "e": 44279,
      "ty": 41,
      "x": 22445,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 48803,
      "e": 44329,
      "ty": 2,
      "x": 916,
      "y": 372
    },
    {
      "t": 48904,
      "e": 44430,
      "ty": 2,
      "x": 912,
      "y": 375
    },
    {
      "t": 49003,
      "e": 44529,
      "ty": 2,
      "x": 905,
      "y": 381
    },
    {
      "t": 49003,
      "e": 44529,
      "ty": 41,
      "x": 19835,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 49254,
      "e": 44780,
      "ty": 41,
      "x": 17699,
      "y": 8394,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 49304,
      "e": 44830,
      "ty": 2,
      "x": 858,
      "y": 414
    },
    {
      "t": 49403,
      "e": 44929,
      "ty": 2,
      "x": 846,
      "y": 426
    },
    {
      "t": 49504,
      "e": 45030,
      "ty": 2,
      "x": 843,
      "y": 428
    },
    {
      "t": 49504,
      "e": 45030,
      "ty": 41,
      "x": 5121,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 49704,
      "e": 45230,
      "ty": 2,
      "x": 834,
      "y": 422
    },
    {
      "t": 49720,
      "e": 45246,
      "ty": 6,
      "x": 833,
      "y": 420,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 49753,
      "e": 45279,
      "ty": 41,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 49803,
      "e": 45329,
      "ty": 2,
      "x": 830,
      "y": 415
    },
    {
      "t": 49878,
      "e": 45404,
      "ty": 3,
      "x": 830,
      "y": 415,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 49880,
      "e": 45406,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 49880,
      "e": 45406,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 49941,
      "e": 45467,
      "ty": 4,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 49941,
      "e": 45467,
      "ty": 5,
      "x": 830,
      "y": 415,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 49942,
      "e": 45468,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 50153,
      "e": 45679,
      "ty": 7,
      "x": 840,
      "y": 421,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 50203,
      "e": 45729,
      "ty": 2,
      "x": 932,
      "y": 521
    },
    {
      "t": 50253,
      "e": 45779,
      "ty": 41,
      "x": 27429,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 50303,
      "e": 45829,
      "ty": 2,
      "x": 921,
      "y": 601
    },
    {
      "t": 50404,
      "e": 45930,
      "ty": 2,
      "x": 902,
      "y": 666
    },
    {
      "t": 50503,
      "e": 46029,
      "ty": 2,
      "x": 901,
      "y": 721
    },
    {
      "t": 50503,
      "e": 46029,
      "ty": 41,
      "x": 19973,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 50603,
      "e": 46129,
      "ty": 2,
      "x": 905,
      "y": 772
    },
    {
      "t": 50704,
      "e": 46230,
      "ty": 2,
      "x": 854,
      "y": 775
    },
    {
      "t": 50754,
      "e": 46280,
      "ty": 41,
      "x": 8169,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 50770,
      "e": 46296,
      "ty": 6,
      "x": 834,
      "y": 756,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 50786,
      "e": 46312,
      "ty": 7,
      "x": 825,
      "y": 746,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 50803,
      "e": 46329,
      "ty": 2,
      "x": 816,
      "y": 740
    },
    {
      "t": 50903,
      "e": 46429,
      "ty": 2,
      "x": 807,
      "y": 715
    },
    {
      "t": 51004,
      "e": 46530,
      "ty": 2,
      "x": 807,
      "y": 700
    },
    {
      "t": 51004,
      "e": 46530,
      "ty": 41,
      "x": 27515,
      "y": 38334,
      "ta": "html > body"
    },
    {
      "t": 51104,
      "e": 46630,
      "ty": 2,
      "x": 819,
      "y": 685
    },
    {
      "t": 51153,
      "e": 46679,
      "ty": 6,
      "x": 831,
      "y": 679,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 51203,
      "e": 46729,
      "ty": 2,
      "x": 837,
      "y": 676
    },
    {
      "t": 51253,
      "e": 46779,
      "ty": 7,
      "x": 842,
      "y": 674,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 51255,
      "e": 46781,
      "ty": 41,
      "x": 5525,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 51303,
      "e": 46829,
      "ty": 2,
      "x": 859,
      "y": 674
    },
    {
      "t": 51404,
      "e": 46930,
      "ty": 2,
      "x": 859,
      "y": 676
    },
    {
      "t": 51504,
      "e": 47030,
      "ty": 2,
      "x": 855,
      "y": 678
    },
    {
      "t": 51504,
      "e": 47030,
      "ty": 41,
      "x": 9015,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 51604,
      "e": 47130,
      "ty": 2,
      "x": 847,
      "y": 684
    },
    {
      "t": 51704,
      "e": 47230,
      "ty": 2,
      "x": 838,
      "y": 693
    },
    {
      "t": 51720,
      "e": 47246,
      "ty": 6,
      "x": 835,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 51754,
      "e": 47280,
      "ty": 41,
      "x": 43243,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 51804,
      "e": 47330,
      "ty": 2,
      "x": 834,
      "y": 698
    },
    {
      "t": 51903,
      "e": 47429,
      "ty": 2,
      "x": 833,
      "y": 703
    },
    {
      "t": 51987,
      "e": 47513,
      "ty": 7,
      "x": 830,
      "y": 709,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 52004,
      "e": 47530,
      "ty": 2,
      "x": 830,
      "y": 709
    },
    {
      "t": 52004,
      "e": 47530,
      "ty": 41,
      "x": 2161,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 52104,
      "e": 47630,
      "ty": 2,
      "x": 830,
      "y": 712
    },
    {
      "t": 52204,
      "e": 47730,
      "ty": 2,
      "x": 829,
      "y": 718
    },
    {
      "t": 52238,
      "e": 47764,
      "ty": 6,
      "x": 829,
      "y": 724,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 52254,
      "e": 47780,
      "ty": 41,
      "x": 12996,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 52303,
      "e": 47829,
      "ty": 2,
      "x": 831,
      "y": 730
    },
    {
      "t": 52354,
      "e": 47880,
      "ty": 7,
      "x": 833,
      "y": 738,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 52404,
      "e": 47930,
      "ty": 2,
      "x": 834,
      "y": 742
    },
    {
      "t": 52504,
      "e": 48030,
      "ty": 2,
      "x": 846,
      "y": 763
    },
    {
      "t": 52504,
      "e": 48030,
      "ty": 41,
      "x": 10255,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 52704,
      "e": 48230,
      "ty": 2,
      "x": 846,
      "y": 761
    },
    {
      "t": 52754,
      "e": 48280,
      "ty": 41,
      "x": 10255,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 52804,
      "e": 48330,
      "ty": 2,
      "x": 846,
      "y": 760
    },
    {
      "t": 52903,
      "e": 48429,
      "ty": 2,
      "x": 845,
      "y": 753
    },
    {
      "t": 53003,
      "e": 48529,
      "ty": 2,
      "x": 843,
      "y": 749
    },
    {
      "t": 53003,
      "e": 48529,
      "ty": 41,
      "x": 9003,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 53104,
      "e": 48630,
      "ty": 2,
      "x": 841,
      "y": 742
    },
    {
      "t": 53254,
      "e": 48780,
      "ty": 41,
      "x": 4646,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 53404,
      "e": 48930,
      "ty": 2,
      "x": 839,
      "y": 746
    },
    {
      "t": 53455,
      "e": 48981,
      "ty": 6,
      "x": 839,
      "y": 754,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 53504,
      "e": 49030,
      "ty": 2,
      "x": 839,
      "y": 758
    },
    {
      "t": 53504,
      "e": 49030,
      "ty": 41,
      "x": 63408,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 53539,
      "e": 49065,
      "ty": 7,
      "x": 839,
      "y": 765,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 53604,
      "e": 49130,
      "ty": 2,
      "x": 844,
      "y": 776
    },
    {
      "t": 53704,
      "e": 49230,
      "ty": 2,
      "x": 860,
      "y": 798
    },
    {
      "t": 53753,
      "e": 49279,
      "ty": 41,
      "x": 16867,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 53789,
      "e": 49315,
      "ty": 6,
      "x": 837,
      "y": 840,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 53804,
      "e": 49330,
      "ty": 2,
      "x": 837,
      "y": 840
    },
    {
      "t": 53838,
      "e": 49364,
      "ty": 7,
      "x": 835,
      "y": 849,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 53903,
      "e": 49429,
      "ty": 2,
      "x": 830,
      "y": 859
    },
    {
      "t": 54003,
      "e": 49529,
      "ty": 2,
      "x": 827,
      "y": 866
    },
    {
      "t": 54004,
      "e": 49530,
      "ty": 41,
      "x": 1323,
      "y": 52682,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 54103,
      "e": 49629,
      "ty": 2,
      "x": 825,
      "y": 859
    },
    {
      "t": 54204,
      "e": 49730,
      "ty": 2,
      "x": 825,
      "y": 845
    },
    {
      "t": 54205,
      "e": 49731,
      "ty": 6,
      "x": 826,
      "y": 843,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 54254,
      "e": 49780,
      "ty": 41,
      "x": 2914,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 54273,
      "e": 49799,
      "ty": 7,
      "x": 828,
      "y": 832,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 54304,
      "e": 49830,
      "ty": 2,
      "x": 828,
      "y": 827
    },
    {
      "t": 54339,
      "e": 49865,
      "ty": 6,
      "x": 830,
      "y": 819,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 54389,
      "e": 49915,
      "ty": 7,
      "x": 831,
      "y": 805,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 54403,
      "e": 49929,
      "ty": 2,
      "x": 831,
      "y": 805
    },
    {
      "t": 54439,
      "e": 49965,
      "ty": 6,
      "x": 831,
      "y": 785,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 54456,
      "e": 49982,
      "ty": 7,
      "x": 830,
      "y": 776,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 54504,
      "e": 50030,
      "ty": 2,
      "x": 829,
      "y": 769
    },
    {
      "t": 54504,
      "e": 50030,
      "ty": 41,
      "x": 1798,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 54574,
      "e": 50100,
      "ty": 6,
      "x": 829,
      "y": 764,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 54604,
      "e": 50130,
      "ty": 2,
      "x": 829,
      "y": 761
    },
    {
      "t": 54639,
      "e": 50165,
      "ty": 7,
      "x": 829,
      "y": 749,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 54703,
      "e": 50229,
      "ty": 2,
      "x": 829,
      "y": 749
    },
    {
      "t": 54754,
      "e": 50280,
      "ty": 41,
      "x": 3162,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 54804,
      "e": 50330,
      "ty": 2,
      "x": 829,
      "y": 748
    },
    {
      "t": 55004,
      "e": 50530,
      "ty": 41,
      "x": 1798,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 55340,
      "e": 50866,
      "ty": 6,
      "x": 827,
      "y": 754,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 55374,
      "e": 50900,
      "ty": 7,
      "x": 825,
      "y": 757,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 55404,
      "e": 50930,
      "ty": 2,
      "x": 825,
      "y": 757
    },
    {
      "t": 55504,
      "e": 51030,
      "ty": 41,
      "x": 1492,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 55750,
      "e": 51276,
      "ty": 6,
      "x": 826,
      "y": 758,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 55754,
      "e": 51280,
      "ty": 41,
      "x": 0,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 55804,
      "e": 51330,
      "ty": 2,
      "x": 827,
      "y": 759
    },
    {
      "t": 56004,
      "e": 51530,
      "ty": 41,
      "x": 2914,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 56207,
      "e": 51733,
      "ty": 3,
      "x": 827,
      "y": 759,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 56208,
      "e": 51734,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 56208,
      "e": 51734,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 56294,
      "e": 51820,
      "ty": 4,
      "x": 2914,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 56294,
      "e": 51820,
      "ty": 5,
      "x": 827,
      "y": 759,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 56294,
      "e": 51820,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf",
      "v": "Natural Sciences"
    },
    {
      "t": 56974,
      "e": 52500,
      "ty": 7,
      "x": 844,
      "y": 752,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 57003,
      "e": 52529,
      "ty": 2,
      "x": 846,
      "y": 750
    },
    {
      "t": 57003,
      "e": 52529,
      "ty": 41,
      "x": 10255,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 57102,
      "e": 52628,
      "ty": 2,
      "x": 863,
      "y": 732
    },
    {
      "t": 57203,
      "e": 52729,
      "ty": 2,
      "x": 864,
      "y": 730
    },
    {
      "t": 57254,
      "e": 52780,
      "ty": 41,
      "x": 11188,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 57303,
      "e": 52829,
      "ty": 2,
      "x": 873,
      "y": 718
    },
    {
      "t": 57403,
      "e": 52929,
      "ty": 2,
      "x": 879,
      "y": 710
    },
    {
      "t": 57503,
      "e": 53029,
      "ty": 2,
      "x": 885,
      "y": 708
    },
    {
      "t": 57504,
      "e": 53030,
      "ty": 41,
      "x": 16020,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 57603,
      "e": 53129,
      "ty": 2,
      "x": 970,
      "y": 699
    },
    {
      "t": 57703,
      "e": 53229,
      "ty": 2,
      "x": 1129,
      "y": 714
    },
    {
      "t": 57753,
      "e": 53279,
      "ty": 41,
      "x": 38880,
      "y": 39775,
      "ta": "html > body"
    },
    {
      "t": 57803,
      "e": 53329,
      "ty": 2,
      "x": 1123,
      "y": 739
    },
    {
      "t": 57903,
      "e": 53429,
      "ty": 2,
      "x": 1077,
      "y": 754
    },
    {
      "t": 58003,
      "e": 53529,
      "ty": 2,
      "x": 984,
      "y": 754
    },
    {
      "t": 58003,
      "e": 53529,
      "ty": 41,
      "x": 38583,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 58103,
      "e": 53629,
      "ty": 2,
      "x": 876,
      "y": 754
    },
    {
      "t": 58203,
      "e": 53729,
      "ty": 2,
      "x": 872,
      "y": 754
    },
    {
      "t": 58253,
      "e": 53779,
      "ty": 41,
      "x": 18183,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 58303,
      "e": 53829,
      "ty": 2,
      "x": 864,
      "y": 749
    },
    {
      "t": 58403,
      "e": 53929,
      "ty": 2,
      "x": 882,
      "y": 736
    },
    {
      "t": 58503,
      "e": 54029,
      "ty": 2,
      "x": 886,
      "y": 735
    },
    {
      "t": 58503,
      "e": 54029,
      "ty": 41,
      "x": 16208,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 58602,
      "e": 54128,
      "ty": 2,
      "x": 871,
      "y": 790
    },
    {
      "t": 58703,
      "e": 54229,
      "ty": 2,
      "x": 869,
      "y": 822
    },
    {
      "t": 58753,
      "e": 54279,
      "ty": 41,
      "x": 32112,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 58803,
      "e": 54329,
      "ty": 2,
      "x": 862,
      "y": 846
    },
    {
      "t": 58903,
      "e": 54429,
      "ty": 2,
      "x": 861,
      "y": 853
    },
    {
      "t": 59002,
      "e": 54528,
      "ty": 2,
      "x": 857,
      "y": 841
    },
    {
      "t": 59003,
      "e": 54529,
      "ty": 41,
      "x": 25066,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 59102,
      "e": 54628,
      "ty": 2,
      "x": 854,
      "y": 803
    },
    {
      "t": 59202,
      "e": 54728,
      "ty": 2,
      "x": 870,
      "y": 771
    },
    {
      "t": 59253,
      "e": 54779,
      "ty": 41,
      "x": 11528,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 59403,
      "e": 54929,
      "ty": 2,
      "x": 877,
      "y": 784
    },
    {
      "t": 59503,
      "e": 55029,
      "ty": 2,
      "x": 881,
      "y": 816
    },
    {
      "t": 59503,
      "e": 55029,
      "ty": 41,
      "x": 35165,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 59603,
      "e": 55129,
      "ty": 2,
      "x": 885,
      "y": 839
    },
    {
      "t": 59703,
      "e": 55229,
      "ty": 2,
      "x": 882,
      "y": 867
    },
    {
      "t": 59753,
      "e": 55279,
      "ty": 41,
      "x": 13664,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 59803,
      "e": 55329,
      "ty": 2,
      "x": 865,
      "y": 909
    },
    {
      "t": 59903,
      "e": 55429,
      "ty": 2,
      "x": 852,
      "y": 927
    },
    {
      "t": 60003,
      "e": 55529,
      "ty": 2,
      "x": 848,
      "y": 956
    },
    {
      "t": 60003,
      "e": 55529,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60007,
      "e": 55533,
      "ty": 41,
      "x": 21499,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 60027,
      "e": 55553,
      "ty": 6,
      "x": 833,
      "y": 993,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 60043,
      "e": 55569,
      "ty": 7,
      "x": 818,
      "y": 1011,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 60103,
      "e": 55629,
      "ty": 2,
      "x": 788,
      "y": 1023
    },
    {
      "t": 60203,
      "e": 55729,
      "ty": 2,
      "x": 790,
      "y": 1006
    },
    {
      "t": 60253,
      "e": 55779,
      "ty": 41,
      "x": 27171,
      "y": 54012,
      "ta": "html > body"
    },
    {
      "t": 60303,
      "e": 55829,
      "ty": 2,
      "x": 802,
      "y": 977
    },
    {
      "t": 60403,
      "e": 55929,
      "ty": 2,
      "x": 818,
      "y": 964
    },
    {
      "t": 60504,
      "e": 56030,
      "ty": 41,
      "x": 27894,
      "y": 52959,
      "ta": "html > body"
    },
    {
      "t": 60703,
      "e": 56229,
      "ty": 2,
      "x": 822,
      "y": 959
    },
    {
      "t": 60753,
      "e": 56279,
      "ty": 41,
      "x": 467,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 60894,
      "e": 56420,
      "ty": 6,
      "x": 828,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 60903,
      "e": 56429,
      "ty": 2,
      "x": 828,
      "y": 960
    },
    {
      "t": 61003,
      "e": 56529,
      "ty": 2,
      "x": 830,
      "y": 961
    },
    {
      "t": 61004,
      "e": 56530,
      "ty": 41,
      "x": 18037,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 61111,
      "e": 56637,
      "ty": 3,
      "x": 830,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 61112,
      "e": 56638,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 61112,
      "e": 56638,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 61173,
      "e": 56699,
      "ty": 4,
      "x": 18037,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 61173,
      "e": 56699,
      "ty": 5,
      "x": 830,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 61173,
      "e": 56699,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 61294,
      "e": 56820,
      "ty": 7,
      "x": 850,
      "y": 973,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 61303,
      "e": 56829,
      "ty": 2,
      "x": 850,
      "y": 973
    },
    {
      "t": 61362,
      "e": 56888,
      "ty": 6,
      "x": 870,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61403,
      "e": 56929,
      "ty": 2,
      "x": 873,
      "y": 1009
    },
    {
      "t": 61503,
      "e": 57029,
      "ty": 2,
      "x": 874,
      "y": 1011
    },
    {
      "t": 61503,
      "e": 57029,
      "ty": 41,
      "x": 22975,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61603,
      "e": 57129,
      "ty": 2,
      "x": 876,
      "y": 1012
    },
    {
      "t": 61607,
      "e": 57133,
      "ty": 3,
      "x": 876,
      "y": 1012,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61607,
      "e": 57133,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 61607,
      "e": 57133,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61661,
      "e": 57187,
      "ty": 4,
      "x": 24005,
      "y": 13901,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61661,
      "e": 57187,
      "ty": 5,
      "x": 876,
      "y": 1012,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61663,
      "e": 57189,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61664,
      "e": 57190,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 61664,
      "e": 57190,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 61753,
      "e": 57279,
      "ty": 41,
      "x": 29891,
      "y": 55618,
      "ta": "html > body"
    },
    {
      "t": 62503,
      "e": 58029,
      "ty": 2,
      "x": 890,
      "y": 744
    },
    {
      "t": 62504,
      "e": 58030,
      "ty": 41,
      "x": 30374,
      "y": 40772,
      "ta": "html > body"
    },
    {
      "t": 62603,
      "e": 58129,
      "ty": 2,
      "x": 901,
      "y": 688
    },
    {
      "t": 62753,
      "e": 58279,
      "ty": 41,
      "x": 30752,
      "y": 37670,
      "ta": "html > body"
    },
    {
      "t": 63000,
      "e": 58526,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 63504,
      "e": 59030,
      "ty": 2,
      "x": 901,
      "y": 721
    },
    {
      "t": 63504,
      "e": 59030,
      "ty": 41,
      "x": 29889,
      "y": 30728,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 63603,
      "e": 59129,
      "ty": 2,
      "x": 945,
      "y": 1018
    },
    {
      "t": 63703,
      "e": 59229,
      "ty": 2,
      "x": 915,
      "y": 1142
    },
    {
      "t": 63754,
      "e": 59280,
      "ty": 41,
      "x": 11468,
      "y": 38952,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 63803,
      "e": 59329,
      "ty": 2,
      "x": 914,
      "y": 1143
    },
    {
      "t": 63904,
      "e": 59430,
      "ty": 2,
      "x": 958,
      "y": 1107
    },
    {
      "t": 63915,
      "e": 59441,
      "ty": 6,
      "x": 965,
      "y": 1101,
      "ta": "#start"
    },
    {
      "t": 64003,
      "e": 59529,
      "ty": 2,
      "x": 971,
      "y": 1092
    },
    {
      "t": 64004,
      "e": 59530,
      "ty": 41,
      "x": 33586,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 64661,
      "e": 60187,
      "ty": 3,
      "x": 971,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 64662,
      "e": 60188,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 64733,
      "e": 60259,
      "ty": 4,
      "x": 33586,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 64733,
      "e": 60259,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 64734,
      "e": 60260,
      "ty": 5,
      "x": 971,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 64735,
      "e": 60261,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 65770,
      "e": 61296,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 67102,
      "e": 62628,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 92710, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 92713, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 3456, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 97493, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 11151, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"MIKE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 109649, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 8745, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 119480, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 13138, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 133621, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 18609, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 153602, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1003,y:1018,t:1527268109509};\\\", \\\"{x:1006,y:991,t:1527268109524};\\\", \\\"{x:1013,y:966,t:1527268109539};\\\", \\\"{x:1020,y:950,t:1527268109556};\\\", \\\"{x:1021,y:944,t:1527268109574};\\\", \\\"{x:1024,y:938,t:1527268109589};\\\", \\\"{x:1025,y:933,t:1527268109607};\\\", \\\"{x:1028,y:926,t:1527268109624};\\\", \\\"{x:1030,y:919,t:1527268109640};\\\", \\\"{x:1032,y:911,t:1527268109657};\\\", \\\"{x:1033,y:903,t:1527268109673};\\\", \\\"{x:1034,y:892,t:1527268109690};\\\", \\\"{x:1037,y:879,t:1527268109707};\\\", \\\"{x:1038,y:865,t:1527268109724};\\\", \\\"{x:1039,y:849,t:1527268109740};\\\", \\\"{x:1039,y:845,t:1527268109756};\\\", \\\"{x:1039,y:844,t:1527268109773};\\\", \\\"{x:1023,y:854,t:1527268109957};\\\", \\\"{x:1016,y:857,t:1527268109973};\\\", \\\"{x:1017,y:860,t:1527268110341};\\\", \\\"{x:1021,y:862,t:1527268110357};\\\", \\\"{x:1030,y:862,t:1527268110373};\\\", \\\"{x:1046,y:862,t:1527268110390};\\\", \\\"{x:1064,y:862,t:1527268110407};\\\", \\\"{x:1083,y:862,t:1527268110423};\\\", \\\"{x:1101,y:862,t:1527268110440};\\\", \\\"{x:1128,y:859,t:1527268110457};\\\", \\\"{x:1157,y:854,t:1527268110473};\\\", \\\"{x:1189,y:850,t:1527268110490};\\\", \\\"{x:1218,y:845,t:1527268110507};\\\", \\\"{x:1258,y:839,t:1527268110523};\\\", \\\"{x:1292,y:835,t:1527268110540};\\\", \\\"{x:1306,y:832,t:1527268110557};\\\", \\\"{x:1314,y:831,t:1527268110573};\\\", \\\"{x:1316,y:831,t:1527268110591};\\\", \\\"{x:1319,y:829,t:1527268110636};\\\", \\\"{x:1319,y:828,t:1527268110644};\\\", \\\"{x:1320,y:828,t:1527268110657};\\\", \\\"{x:1320,y:827,t:1527268110749};\\\", \\\"{x:1318,y:826,t:1527268110773};\\\", \\\"{x:1317,y:826,t:1527268110788};\\\", \\\"{x:1314,y:825,t:1527268110797};\\\", \\\"{x:1313,y:825,t:1527268110807};\\\", \\\"{x:1310,y:825,t:1527268110825};\\\", \\\"{x:1308,y:825,t:1527268110841};\\\", \\\"{x:1306,y:826,t:1527268110857};\\\", \\\"{x:1305,y:826,t:1527268110875};\\\", \\\"{x:1302,y:829,t:1527268110890};\\\", \\\"{x:1298,y:833,t:1527268110908};\\\", \\\"{x:1283,y:846,t:1527268110924};\\\", \\\"{x:1269,y:855,t:1527268110941};\\\", \\\"{x:1255,y:863,t:1527268110958};\\\", \\\"{x:1243,y:869,t:1527268110974};\\\", \\\"{x:1244,y:870,t:1527268111261};\\\", \\\"{x:1246,y:870,t:1527268111275};\\\", \\\"{x:1248,y:871,t:1527268111292};\\\", \\\"{x:1249,y:871,t:1527268111340};\\\", \\\"{x:1250,y:872,t:1527268111358};\\\", \\\"{x:1251,y:872,t:1527268111413};\\\", \\\"{x:1254,y:872,t:1527268111425};\\\", \\\"{x:1258,y:875,t:1527268111441};\\\", \\\"{x:1260,y:875,t:1527268111458};\\\", \\\"{x:1261,y:878,t:1527268111509};\\\", \\\"{x:1262,y:885,t:1527268111524};\\\", \\\"{x:1262,y:891,t:1527268111542};\\\", \\\"{x:1262,y:895,t:1527268111558};\\\", \\\"{x:1262,y:899,t:1527268111574};\\\", \\\"{x:1262,y:902,t:1527268111592};\\\", \\\"{x:1262,y:908,t:1527268111609};\\\", \\\"{x:1262,y:916,t:1527268111625};\\\", \\\"{x:1260,y:925,t:1527268111642};\\\", \\\"{x:1259,y:931,t:1527268111659};\\\", \\\"{x:1255,y:938,t:1527268111675};\\\", \\\"{x:1255,y:943,t:1527268111692};\\\", \\\"{x:1255,y:948,t:1527268111709};\\\", \\\"{x:1255,y:946,t:1527268111925};\\\", \\\"{x:1257,y:933,t:1527268111942};\\\", \\\"{x:1261,y:916,t:1527268111959};\\\", \\\"{x:1266,y:900,t:1527268111975};\\\", \\\"{x:1266,y:885,t:1527268111992};\\\", \\\"{x:1266,y:878,t:1527268112008};\\\", \\\"{x:1266,y:875,t:1527268112025};\\\", \\\"{x:1266,y:874,t:1527268112041};\\\", \\\"{x:1265,y:868,t:1527268112058};\\\", \\\"{x:1262,y:857,t:1527268112075};\\\", \\\"{x:1258,y:836,t:1527268112091};\\\", \\\"{x:1251,y:819,t:1527268112108};\\\", \\\"{x:1250,y:816,t:1527268112125};\\\", \\\"{x:1250,y:812,t:1527268112141};\\\", \\\"{x:1250,y:796,t:1527268112158};\\\", \\\"{x:1250,y:778,t:1527268112175};\\\", \\\"{x:1252,y:769,t:1527268112192};\\\", \\\"{x:1253,y:766,t:1527268112209};\\\", \\\"{x:1255,y:756,t:1527268112226};\\\", \\\"{x:1260,y:742,t:1527268112241};\\\", \\\"{x:1265,y:732,t:1527268112259};\\\", \\\"{x:1272,y:718,t:1527268112275};\\\", \\\"{x:1283,y:701,t:1527268112292};\\\", \\\"{x:1294,y:688,t:1527268112308};\\\", \\\"{x:1302,y:679,t:1527268112325};\\\", \\\"{x:1307,y:675,t:1527268112342};\\\", \\\"{x:1308,y:675,t:1527268112359};\\\", \\\"{x:1309,y:675,t:1527268112397};\\\", \\\"{x:1312,y:675,t:1527268112413};\\\", \\\"{x:1313,y:675,t:1527268112426};\\\", \\\"{x:1315,y:675,t:1527268112442};\\\", \\\"{x:1316,y:675,t:1527268112459};\\\", \\\"{x:1318,y:677,t:1527268112476};\\\", \\\"{x:1323,y:687,t:1527268112492};\\\", \\\"{x:1336,y:710,t:1527268112509};\\\", \\\"{x:1340,y:720,t:1527268112525};\\\", \\\"{x:1341,y:731,t:1527268112542};\\\", \\\"{x:1342,y:741,t:1527268112559};\\\", \\\"{x:1342,y:755,t:1527268112576};\\\", \\\"{x:1342,y:767,t:1527268112592};\\\", \\\"{x:1342,y:776,t:1527268112609};\\\", \\\"{x:1342,y:785,t:1527268112625};\\\", \\\"{x:1339,y:798,t:1527268112643};\\\", \\\"{x:1338,y:804,t:1527268112659};\\\", \\\"{x:1338,y:812,t:1527268112676};\\\", \\\"{x:1338,y:820,t:1527268112692};\\\", \\\"{x:1336,y:824,t:1527268112709};\\\", \\\"{x:1336,y:831,t:1527268112725};\\\", \\\"{x:1336,y:839,t:1527268112742};\\\", \\\"{x:1336,y:856,t:1527268112758};\\\", \\\"{x:1336,y:871,t:1527268112775};\\\", \\\"{x:1334,y:882,t:1527268112792};\\\", \\\"{x:1333,y:894,t:1527268112808};\\\", \\\"{x:1333,y:909,t:1527268112826};\\\", \\\"{x:1331,y:932,t:1527268112842};\\\", \\\"{x:1326,y:956,t:1527268112859};\\\", \\\"{x:1319,y:979,t:1527268112875};\\\", \\\"{x:1314,y:992,t:1527268112892};\\\", \\\"{x:1311,y:992,t:1527268113013};\\\", \\\"{x:1306,y:992,t:1527268113026};\\\", \\\"{x:1282,y:992,t:1527268113043};\\\", \\\"{x:1181,y:961,t:1527268113059};\\\", \\\"{x:1023,y:917,t:1527268113076};\\\", \\\"{x:699,y:799,t:1527268113093};\\\", \\\"{x:475,y:736,t:1527268113110};\\\", \\\"{x:286,y:669,t:1527268113126};\\\", \\\"{x:247,y:652,t:1527268113144};\\\", \\\"{x:246,y:652,t:1527268113160};\\\", \\\"{x:246,y:651,t:1527268113180};\\\", \\\"{x:249,y:650,t:1527268113194};\\\", \\\"{x:259,y:646,t:1527268113209};\\\", \\\"{x:260,y:646,t:1527268113225};\\\", \\\"{x:263,y:643,t:1527268113251};\\\", \\\"{x:264,y:641,t:1527268113260};\\\", \\\"{x:268,y:634,t:1527268113276};\\\", \\\"{x:271,y:632,t:1527268113293};\\\", \\\"{x:275,y:629,t:1527268113311};\\\", \\\"{x:284,y:619,t:1527268113326};\\\", \\\"{x:285,y:617,t:1527268113343};\\\", \\\"{x:285,y:616,t:1527268113360};\\\", \\\"{x:291,y:612,t:1527268113377};\\\", \\\"{x:303,y:607,t:1527268113393};\\\", \\\"{x:305,y:606,t:1527268113410};\\\", \\\"{x:310,y:606,t:1527268113541};\\\", \\\"{x:309,y:606,t:1527268113588};\\\", \\\"{x:306,y:606,t:1527268113597};\\\", \\\"{x:303,y:605,t:1527268113611};\\\", \\\"{x:298,y:602,t:1527268113628};\\\", \\\"{x:277,y:593,t:1527268113644};\\\", \\\"{x:248,y:582,t:1527268113663};\\\", \\\"{x:230,y:574,t:1527268113678};\\\", \\\"{x:212,y:567,t:1527268113693};\\\", \\\"{x:200,y:562,t:1527268113710};\\\", \\\"{x:200,y:561,t:1527268113727};\\\", \\\"{x:199,y:561,t:1527268113743};\\\", \\\"{x:202,y:560,t:1527268113796};\\\", \\\"{x:208,y:558,t:1527268113811};\\\", \\\"{x:211,y:557,t:1527268113827};\\\", \\\"{x:213,y:557,t:1527268113843};\\\", \\\"{x:215,y:557,t:1527268113861};\\\", \\\"{x:217,y:557,t:1527268113980};\\\", \\\"{x:227,y:557,t:1527268113993};\\\", \\\"{x:288,y:557,t:1527268114014};\\\", \\\"{x:387,y:557,t:1527268114028};\\\", \\\"{x:540,y:557,t:1527268114044};\\\", \\\"{x:620,y:557,t:1527268114060};\\\", \\\"{x:665,y:557,t:1527268114077};\\\", \\\"{x:678,y:557,t:1527268114094};\\\", \\\"{x:679,y:557,t:1527268114110};\\\", \\\"{x:677,y:557,t:1527268114127};\\\", \\\"{x:651,y:551,t:1527268114144};\\\", \\\"{x:635,y:546,t:1527268114161};\\\", \\\"{x:621,y:542,t:1527268114177};\\\", \\\"{x:596,y:540,t:1527268114194};\\\", \\\"{x:559,y:539,t:1527268114210};\\\", \\\"{x:491,y:534,t:1527268114228};\\\", \\\"{x:371,y:532,t:1527268114244};\\\", \\\"{x:293,y:532,t:1527268114260};\\\", \\\"{x:256,y:532,t:1527268114278};\\\", \\\"{x:242,y:532,t:1527268114294};\\\", \\\"{x:245,y:534,t:1527268114380};\\\", \\\"{x:251,y:534,t:1527268114394};\\\", \\\"{x:266,y:535,t:1527268114411};\\\", \\\"{x:280,y:535,t:1527268114428};\\\", \\\"{x:313,y:537,t:1527268114445};\\\", \\\"{x:327,y:537,t:1527268114461};\\\", \\\"{x:330,y:537,t:1527268114477};\\\", \\\"{x:331,y:537,t:1527268114494};\\\", \\\"{x:338,y:537,t:1527268114511};\\\", \\\"{x:349,y:535,t:1527268114527};\\\", \\\"{x:358,y:534,t:1527268114545};\\\", \\\"{x:365,y:533,t:1527268114561};\\\", \\\"{x:369,y:531,t:1527268114684};\\\", \\\"{x:370,y:531,t:1527268114700};\\\", \\\"{x:371,y:530,t:1527268114756};\\\", \\\"{x:373,y:529,t:1527268114764};\\\", \\\"{x:380,y:525,t:1527268114777};\\\", \\\"{x:387,y:520,t:1527268114795};\\\", \\\"{x:388,y:519,t:1527268114811};\\\", \\\"{x:388,y:518,t:1527268114827};\\\", \\\"{x:389,y:518,t:1527268114964};\\\", \\\"{x:390,y:518,t:1527268114975};\\\", \\\"{x:398,y:519,t:1527268114994};\\\", \\\"{x:399,y:523,t:1527268115011};\\\", \\\"{x:403,y:526,t:1527268115028};\\\", \\\"{x:418,y:538,t:1527268115045};\\\", \\\"{x:439,y:554,t:1527268115061};\\\", \\\"{x:452,y:573,t:1527268115079};\\\", \\\"{x:466,y:595,t:1527268115094};\\\", \\\"{x:479,y:618,t:1527268115112};\\\", \\\"{x:493,y:638,t:1527268115129};\\\", \\\"{x:501,y:647,t:1527268115146};\\\", \\\"{x:504,y:655,t:1527268115161};\\\", \\\"{x:509,y:668,t:1527268115178};\\\", \\\"{x:514,y:685,t:1527268115194};\\\", \\\"{x:527,y:722,t:1527268115212};\\\", \\\"{x:532,y:729,t:1527268115227};\\\", \\\"{x:541,y:738,t:1527268115244};\\\", \\\"{x:544,y:742,t:1527268115261};\\\", \\\"{x:546,y:742,t:1527268115278};\\\", \\\"{x:539,y:737,t:1527268115468};\\\", \\\"{x:531,y:729,t:1527268115479};\\\", \\\"{x:522,y:720,t:1527268115496};\\\", \\\"{x:522,y:718,t:1527268115515};\\\", \\\"{x:521,y:718,t:1527268115528};\\\", \\\"{x:521,y:717,t:1527268117205};\\\" ] }, { \\\"rt\\\": 19228, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 174098, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-10 AM-C -U -K -K -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:717,t:1527268121644};\\\", \\\"{x:530,y:720,t:1527268121658};\\\", \\\"{x:547,y:723,t:1527268121671};\\\", \\\"{x:552,y:727,t:1527268121688};\\\", \\\"{x:553,y:727,t:1527268121703};\\\", \\\"{x:555,y:727,t:1527268121720};\\\", \\\"{x:559,y:729,t:1527268121738};\\\", \\\"{x:563,y:731,t:1527268121755};\\\", \\\"{x:571,y:735,t:1527268121771};\\\", \\\"{x:580,y:743,t:1527268121787};\\\", \\\"{x:586,y:746,t:1527268121805};\\\", \\\"{x:589,y:748,t:1527268121816};\\\", \\\"{x:594,y:752,t:1527268121833};\\\", \\\"{x:607,y:757,t:1527268121849};\\\", \\\"{x:623,y:765,t:1527268121866};\\\", \\\"{x:656,y:778,t:1527268121883};\\\", \\\"{x:675,y:783,t:1527268121899};\\\", \\\"{x:710,y:795,t:1527268121916};\\\", \\\"{x:763,y:813,t:1527268121933};\\\", \\\"{x:817,y:829,t:1527268121949};\\\", \\\"{x:867,y:845,t:1527268121967};\\\", \\\"{x:937,y:866,t:1527268121985};\\\", \\\"{x:1004,y:895,t:1527268122000};\\\", \\\"{x:1062,y:922,t:1527268122016};\\\", \\\"{x:1103,y:948,t:1527268122034};\\\", \\\"{x:1135,y:966,t:1527268122049};\\\", \\\"{x:1157,y:978,t:1527268122067};\\\", \\\"{x:1189,y:985,t:1527268122084};\\\", \\\"{x:1204,y:988,t:1527268122100};\\\", \\\"{x:1214,y:988,t:1527268122117};\\\", \\\"{x:1220,y:988,t:1527268122134};\\\", \\\"{x:1224,y:988,t:1527268122151};\\\", \\\"{x:1225,y:989,t:1527268122167};\\\", \\\"{x:1226,y:988,t:1527268122269};\\\", \\\"{x:1226,y:979,t:1527268122285};\\\", \\\"{x:1226,y:973,t:1527268122300};\\\", \\\"{x:1226,y:969,t:1527268122317};\\\", \\\"{x:1226,y:966,t:1527268122429};\\\", \\\"{x:1226,y:961,t:1527268122436};\\\", \\\"{x:1226,y:958,t:1527268122452};\\\", \\\"{x:1226,y:951,t:1527268122467};\\\", \\\"{x:1226,y:939,t:1527268122484};\\\", \\\"{x:1226,y:924,t:1527268122501};\\\", \\\"{x:1226,y:909,t:1527268122518};\\\", \\\"{x:1226,y:903,t:1527268122534};\\\", \\\"{x:1226,y:902,t:1527268122552};\\\", \\\"{x:1226,y:900,t:1527268122781};\\\", \\\"{x:1226,y:899,t:1527268122788};\\\", \\\"{x:1226,y:897,t:1527268122812};\\\", \\\"{x:1226,y:896,t:1527268122860};\\\", \\\"{x:1226,y:892,t:1527268122867};\\\", \\\"{x:1225,y:884,t:1527268122883};\\\", \\\"{x:1215,y:873,t:1527268122901};\\\", \\\"{x:1209,y:871,t:1527268122917};\\\", \\\"{x:1210,y:871,t:1527268123693};\\\", \\\"{x:1210,y:870,t:1527268123703};\\\", \\\"{x:1213,y:870,t:1527268123718};\\\", \\\"{x:1217,y:869,t:1527268123735};\\\", \\\"{x:1223,y:869,t:1527268123752};\\\", \\\"{x:1230,y:868,t:1527268123768};\\\", \\\"{x:1235,y:866,t:1527268123785};\\\", \\\"{x:1236,y:866,t:1527268123801};\\\", \\\"{x:1238,y:865,t:1527268123818};\\\", \\\"{x:1241,y:865,t:1527268123834};\\\", \\\"{x:1238,y:863,t:1527268123983};\\\", \\\"{x:1231,y:860,t:1527268123987};\\\", \\\"{x:1223,y:857,t:1527268124002};\\\", \\\"{x:1205,y:850,t:1527268124019};\\\", \\\"{x:1187,y:845,t:1527268124034};\\\", \\\"{x:1170,y:838,t:1527268124051};\\\", \\\"{x:1169,y:837,t:1527268124069};\\\", \\\"{x:1169,y:835,t:1527268124180};\\\", \\\"{x:1170,y:834,t:1527268124187};\\\", \\\"{x:1173,y:834,t:1527268124201};\\\", \\\"{x:1189,y:832,t:1527268124219};\\\", \\\"{x:1212,y:832,t:1527268124235};\\\", \\\"{x:1273,y:832,t:1527268124252};\\\", \\\"{x:1324,y:832,t:1527268124269};\\\", \\\"{x:1371,y:832,t:1527268124284};\\\", \\\"{x:1410,y:832,t:1527268124301};\\\", \\\"{x:1444,y:832,t:1527268124318};\\\", \\\"{x:1463,y:832,t:1527268124334};\\\", \\\"{x:1478,y:832,t:1527268124351};\\\", \\\"{x:1492,y:832,t:1527268124369};\\\", \\\"{x:1503,y:832,t:1527268124384};\\\", \\\"{x:1518,y:832,t:1527268124401};\\\", \\\"{x:1532,y:832,t:1527268124418};\\\", \\\"{x:1556,y:832,t:1527268124435};\\\", \\\"{x:1579,y:832,t:1527268124452};\\\", \\\"{x:1609,y:832,t:1527268124468};\\\", \\\"{x:1649,y:832,t:1527268124485};\\\", \\\"{x:1688,y:832,t:1527268124501};\\\", \\\"{x:1724,y:832,t:1527268124518};\\\", \\\"{x:1748,y:832,t:1527268124535};\\\", \\\"{x:1762,y:832,t:1527268124551};\\\", \\\"{x:1763,y:832,t:1527268124569};\\\", \\\"{x:1762,y:832,t:1527268124660};\\\", \\\"{x:1762,y:831,t:1527268124668};\\\", \\\"{x:1760,y:831,t:1527268124685};\\\", \\\"{x:1754,y:829,t:1527268124702};\\\", \\\"{x:1752,y:828,t:1527268124719};\\\", \\\"{x:1751,y:827,t:1527268124736};\\\", \\\"{x:1748,y:827,t:1527268124752};\\\", \\\"{x:1746,y:826,t:1527268124769};\\\", \\\"{x:1740,y:825,t:1527268124786};\\\", \\\"{x:1729,y:824,t:1527268124802};\\\", \\\"{x:1717,y:824,t:1527268124819};\\\", \\\"{x:1703,y:824,t:1527268124835};\\\", \\\"{x:1695,y:824,t:1527268124852};\\\", \\\"{x:1691,y:824,t:1527268124869};\\\", \\\"{x:1687,y:824,t:1527268124886};\\\", \\\"{x:1672,y:824,t:1527268124902};\\\", \\\"{x:1660,y:824,t:1527268124919};\\\", \\\"{x:1651,y:824,t:1527268124936};\\\", \\\"{x:1648,y:824,t:1527268124952};\\\", \\\"{x:1647,y:824,t:1527268124969};\\\", \\\"{x:1645,y:824,t:1527268125029};\\\", \\\"{x:1644,y:824,t:1527268125036};\\\", \\\"{x:1637,y:824,t:1527268125053};\\\", \\\"{x:1629,y:824,t:1527268125069};\\\", \\\"{x:1611,y:826,t:1527268125086};\\\", \\\"{x:1587,y:830,t:1527268125103};\\\", \\\"{x:1561,y:833,t:1527268125119};\\\", \\\"{x:1535,y:833,t:1527268125136};\\\", \\\"{x:1523,y:835,t:1527268125153};\\\", \\\"{x:1515,y:835,t:1527268125169};\\\", \\\"{x:1512,y:835,t:1527268125187};\\\", \\\"{x:1511,y:835,t:1527268125203};\\\", \\\"{x:1510,y:835,t:1527268125220};\\\", \\\"{x:1509,y:835,t:1527268125403};\\\", \\\"{x:1509,y:829,t:1527268125418};\\\", \\\"{x:1509,y:799,t:1527268125435};\\\", \\\"{x:1506,y:778,t:1527268125453};\\\", \\\"{x:1504,y:763,t:1527268125470};\\\", \\\"{x:1504,y:753,t:1527268125486};\\\", \\\"{x:1504,y:751,t:1527268125503};\\\", \\\"{x:1504,y:750,t:1527268125520};\\\", \\\"{x:1504,y:744,t:1527268125536};\\\", \\\"{x:1503,y:726,t:1527268125553};\\\", \\\"{x:1501,y:718,t:1527268125570};\\\", \\\"{x:1501,y:717,t:1527268125586};\\\", \\\"{x:1501,y:714,t:1527268125603};\\\", \\\"{x:1501,y:710,t:1527268125619};\\\", \\\"{x:1501,y:707,t:1527268125636};\\\", \\\"{x:1501,y:705,t:1527268125653};\\\", \\\"{x:1501,y:701,t:1527268125670};\\\", \\\"{x:1501,y:697,t:1527268125686};\\\", \\\"{x:1502,y:693,t:1527268125703};\\\", \\\"{x:1502,y:689,t:1527268125720};\\\", \\\"{x:1503,y:683,t:1527268125736};\\\", \\\"{x:1503,y:678,t:1527268125753};\\\", \\\"{x:1504,y:667,t:1527268125770};\\\", \\\"{x:1505,y:665,t:1527268125786};\\\", \\\"{x:1507,y:661,t:1527268125803};\\\", \\\"{x:1509,y:652,t:1527268125820};\\\", \\\"{x:1511,y:646,t:1527268125836};\\\", \\\"{x:1512,y:640,t:1527268125853};\\\", \\\"{x:1514,y:633,t:1527268125871};\\\", \\\"{x:1515,y:628,t:1527268125886};\\\", \\\"{x:1517,y:623,t:1527268125904};\\\", \\\"{x:1519,y:616,t:1527268125921};\\\", \\\"{x:1519,y:605,t:1527268125936};\\\", \\\"{x:1515,y:595,t:1527268125953};\\\", \\\"{x:1505,y:581,t:1527268125970};\\\", \\\"{x:1498,y:574,t:1527268125987};\\\", \\\"{x:1495,y:571,t:1527268126003};\\\", \\\"{x:1490,y:565,t:1527268126020};\\\", \\\"{x:1481,y:556,t:1527268126036};\\\", \\\"{x:1469,y:551,t:1527268126053};\\\", \\\"{x:1464,y:548,t:1527268126070};\\\", \\\"{x:1463,y:541,t:1527268126087};\\\", \\\"{x:1463,y:532,t:1527268126103};\\\", \\\"{x:1463,y:527,t:1527268126120};\\\", \\\"{x:1463,y:523,t:1527268126138};\\\", \\\"{x:1463,y:520,t:1527268126154};\\\", \\\"{x:1463,y:519,t:1527268126188};\\\", \\\"{x:1463,y:517,t:1527268126204};\\\", \\\"{x:1474,y:512,t:1527268126220};\\\", \\\"{x:1489,y:499,t:1527268126237};\\\", \\\"{x:1505,y:487,t:1527268126254};\\\", \\\"{x:1519,y:477,t:1527268126270};\\\", \\\"{x:1537,y:466,t:1527268126288};\\\", \\\"{x:1560,y:452,t:1527268126304};\\\", \\\"{x:1582,y:435,t:1527268126320};\\\", \\\"{x:1596,y:426,t:1527268126338};\\\", \\\"{x:1612,y:413,t:1527268126354};\\\", \\\"{x:1622,y:406,t:1527268126370};\\\", \\\"{x:1632,y:401,t:1527268126387};\\\", \\\"{x:1633,y:409,t:1527268126597};\\\", \\\"{x:1632,y:423,t:1527268126604};\\\", \\\"{x:1625,y:437,t:1527268126621};\\\", \\\"{x:1618,y:451,t:1527268126637};\\\", \\\"{x:1612,y:458,t:1527268126655};\\\", \\\"{x:1610,y:461,t:1527268126670};\\\", \\\"{x:1609,y:462,t:1527268126688};\\\", \\\"{x:1608,y:463,t:1527268126996};\\\", \\\"{x:1607,y:463,t:1527268127005};\\\", \\\"{x:1607,y:462,t:1527268127021};\\\", \\\"{x:1606,y:460,t:1527268127037};\\\", \\\"{x:1606,y:458,t:1527268127060};\\\", \\\"{x:1606,y:457,t:1527268127071};\\\", \\\"{x:1606,y:456,t:1527268127509};\\\", \\\"{x:1606,y:452,t:1527268127522};\\\", \\\"{x:1606,y:441,t:1527268127539};\\\", \\\"{x:1606,y:437,t:1527268127555};\\\", \\\"{x:1606,y:435,t:1527268127571};\\\", \\\"{x:1606,y:432,t:1527268127589};\\\", \\\"{x:1606,y:434,t:1527268128085};\\\", \\\"{x:1606,y:446,t:1527268128093};\\\", \\\"{x:1608,y:458,t:1527268128106};\\\", \\\"{x:1610,y:484,t:1527268128122};\\\", \\\"{x:1611,y:510,t:1527268128138};\\\", \\\"{x:1615,y:524,t:1527268128155};\\\", \\\"{x:1618,y:529,t:1527268128172};\\\", \\\"{x:1619,y:531,t:1527268128188};\\\", \\\"{x:1622,y:535,t:1527268128205};\\\", \\\"{x:1626,y:543,t:1527268128221};\\\", \\\"{x:1628,y:549,t:1527268128239};\\\", \\\"{x:1631,y:558,t:1527268128255};\\\", \\\"{x:1633,y:563,t:1527268128272};\\\", \\\"{x:1634,y:565,t:1527268128289};\\\", \\\"{x:1634,y:566,t:1527268128581};\\\", \\\"{x:1634,y:568,t:1527268128589};\\\", \\\"{x:1634,y:573,t:1527268128605};\\\", \\\"{x:1630,y:580,t:1527268128622};\\\", \\\"{x:1627,y:584,t:1527268128638};\\\", \\\"{x:1625,y:586,t:1527268128655};\\\", \\\"{x:1625,y:589,t:1527268129444};\\\", \\\"{x:1625,y:598,t:1527268129456};\\\", \\\"{x:1621,y:620,t:1527268129471};\\\", \\\"{x:1617,y:642,t:1527268129489};\\\", \\\"{x:1615,y:661,t:1527268129506};\\\", \\\"{x:1612,y:672,t:1527268129522};\\\", \\\"{x:1612,y:675,t:1527268129539};\\\", \\\"{x:1612,y:676,t:1527268129580};\\\", \\\"{x:1612,y:678,t:1527268129589};\\\", \\\"{x:1612,y:685,t:1527268129606};\\\", \\\"{x:1611,y:692,t:1527268129622};\\\", \\\"{x:1611,y:695,t:1527268129639};\\\", \\\"{x:1611,y:696,t:1527268129717};\\\", \\\"{x:1611,y:697,t:1527268129725};\\\", \\\"{x:1610,y:701,t:1527268129739};\\\", \\\"{x:1605,y:722,t:1527268129756};\\\", \\\"{x:1601,y:730,t:1527268129772};\\\", \\\"{x:1600,y:732,t:1527268129790};\\\", \\\"{x:1599,y:733,t:1527268129805};\\\", \\\"{x:1599,y:734,t:1527268129827};\\\", \\\"{x:1599,y:735,t:1527268129844};\\\", \\\"{x:1599,y:736,t:1527268129856};\\\", \\\"{x:1599,y:740,t:1527268129873};\\\", \\\"{x:1599,y:742,t:1527268129889};\\\", \\\"{x:1599,y:743,t:1527268129906};\\\", \\\"{x:1599,y:745,t:1527268129939};\\\", \\\"{x:1603,y:754,t:1527268129956};\\\", \\\"{x:1610,y:762,t:1527268129973};\\\", \\\"{x:1612,y:765,t:1527268129989};\\\", \\\"{x:1614,y:767,t:1527268130006};\\\", \\\"{x:1615,y:770,t:1527268130023};\\\", \\\"{x:1616,y:772,t:1527268130039};\\\", \\\"{x:1616,y:775,t:1527268130056};\\\", \\\"{x:1616,y:781,t:1527268130074};\\\", \\\"{x:1617,y:789,t:1527268130090};\\\", \\\"{x:1617,y:795,t:1527268130106};\\\", \\\"{x:1617,y:800,t:1527268130123};\\\", \\\"{x:1620,y:807,t:1527268130139};\\\", \\\"{x:1620,y:809,t:1527268130156};\\\", \\\"{x:1620,y:810,t:1527268130173};\\\", \\\"{x:1620,y:811,t:1527268130189};\\\", \\\"{x:1620,y:812,t:1527268130206};\\\", \\\"{x:1620,y:814,t:1527268130224};\\\", \\\"{x:1621,y:819,t:1527268130239};\\\", \\\"{x:1622,y:824,t:1527268130257};\\\", \\\"{x:1622,y:829,t:1527268130273};\\\", \\\"{x:1622,y:831,t:1527268130289};\\\", \\\"{x:1623,y:834,t:1527268130307};\\\", \\\"{x:1623,y:835,t:1527268130323};\\\", \\\"{x:1624,y:838,t:1527268130339};\\\", \\\"{x:1624,y:840,t:1527268130357};\\\", \\\"{x:1624,y:843,t:1527268130373};\\\", \\\"{x:1624,y:848,t:1527268130390};\\\", \\\"{x:1624,y:850,t:1527268130406};\\\", \\\"{x:1624,y:851,t:1527268130423};\\\", \\\"{x:1624,y:852,t:1527268130440};\\\", \\\"{x:1624,y:853,t:1527268130456};\\\", \\\"{x:1624,y:854,t:1527268130473};\\\", \\\"{x:1624,y:859,t:1527268130490};\\\", \\\"{x:1624,y:866,t:1527268130506};\\\", \\\"{x:1625,y:873,t:1527268130523};\\\", \\\"{x:1625,y:883,t:1527268130539};\\\", \\\"{x:1624,y:890,t:1527268130556};\\\", \\\"{x:1621,y:899,t:1527268130573};\\\", \\\"{x:1618,y:910,t:1527268130590};\\\", \\\"{x:1616,y:919,t:1527268130606};\\\", \\\"{x:1616,y:933,t:1527268130623};\\\", \\\"{x:1616,y:937,t:1527268130640};\\\", \\\"{x:1616,y:938,t:1527268130656};\\\", \\\"{x:1616,y:941,t:1527268130673};\\\", \\\"{x:1616,y:947,t:1527268130690};\\\", \\\"{x:1615,y:952,t:1527268130706};\\\", \\\"{x:1615,y:954,t:1527268130723};\\\", \\\"{x:1615,y:955,t:1527268130741};\\\", \\\"{x:1615,y:950,t:1527268130964};\\\", \\\"{x:1615,y:943,t:1527268130973};\\\", \\\"{x:1615,y:932,t:1527268130990};\\\", \\\"{x:1614,y:923,t:1527268131007};\\\", \\\"{x:1612,y:914,t:1527268131023};\\\", \\\"{x:1608,y:905,t:1527268131040};\\\", \\\"{x:1602,y:894,t:1527268131057};\\\", \\\"{x:1598,y:887,t:1527268131073};\\\", \\\"{x:1598,y:886,t:1527268131090};\\\", \\\"{x:1598,y:885,t:1527268131107};\\\", \\\"{x:1596,y:883,t:1527268131123};\\\", \\\"{x:1595,y:875,t:1527268131140};\\\", \\\"{x:1595,y:865,t:1527268131158};\\\", \\\"{x:1592,y:849,t:1527268131173};\\\", \\\"{x:1591,y:835,t:1527268131190};\\\", \\\"{x:1590,y:822,t:1527268131207};\\\", \\\"{x:1589,y:798,t:1527268131223};\\\", \\\"{x:1589,y:770,t:1527268131241};\\\", \\\"{x:1589,y:751,t:1527268131257};\\\", \\\"{x:1589,y:732,t:1527268131274};\\\", \\\"{x:1589,y:711,t:1527268131291};\\\", \\\"{x:1589,y:687,t:1527268131307};\\\", \\\"{x:1589,y:673,t:1527268131323};\\\", \\\"{x:1589,y:665,t:1527268131340};\\\", \\\"{x:1589,y:659,t:1527268131358};\\\", \\\"{x:1589,y:651,t:1527268131374};\\\", \\\"{x:1587,y:636,t:1527268131390};\\\", \\\"{x:1585,y:614,t:1527268131408};\\\", \\\"{x:1585,y:590,t:1527268131424};\\\", \\\"{x:1585,y:576,t:1527268131440};\\\", \\\"{x:1586,y:564,t:1527268131458};\\\", \\\"{x:1586,y:551,t:1527268131474};\\\", \\\"{x:1586,y:536,t:1527268131491};\\\", \\\"{x:1586,y:508,t:1527268131507};\\\", \\\"{x:1586,y:483,t:1527268131524};\\\", \\\"{x:1586,y:478,t:1527268131540};\\\", \\\"{x:1586,y:469,t:1527268131558};\\\", \\\"{x:1586,y:462,t:1527268131574};\\\", \\\"{x:1583,y:455,t:1527268131590};\\\", \\\"{x:1582,y:447,t:1527268131607};\\\", \\\"{x:1579,y:435,t:1527268131624};\\\", \\\"{x:1578,y:435,t:1527268131640};\\\", \\\"{x:1578,y:434,t:1527268131708};\\\", \\\"{x:1578,y:451,t:1527268131724};\\\", \\\"{x:1582,y:486,t:1527268131740};\\\", \\\"{x:1588,y:516,t:1527268131757};\\\", \\\"{x:1591,y:549,t:1527268131774};\\\", \\\"{x:1591,y:579,t:1527268131790};\\\", \\\"{x:1589,y:608,t:1527268131807};\\\", \\\"{x:1582,y:630,t:1527268131824};\\\", \\\"{x:1577,y:639,t:1527268131841};\\\", \\\"{x:1575,y:641,t:1527268131857};\\\", \\\"{x:1571,y:643,t:1527268131874};\\\", \\\"{x:1559,y:644,t:1527268131891};\\\", \\\"{x:1525,y:651,t:1527268131907};\\\", \\\"{x:1399,y:667,t:1527268131924};\\\", \\\"{x:1294,y:681,t:1527268131941};\\\", \\\"{x:1174,y:700,t:1527268131957};\\\", \\\"{x:1050,y:700,t:1527268131974};\\\", \\\"{x:925,y:700,t:1527268131991};\\\", \\\"{x:831,y:700,t:1527268132007};\\\", \\\"{x:811,y:700,t:1527268132024};\\\", \\\"{x:810,y:700,t:1527268132041};\\\", \\\"{x:809,y:700,t:1527268132075};\\\", \\\"{x:804,y:699,t:1527268132269};\\\", \\\"{x:798,y:697,t:1527268132275};\\\", \\\"{x:788,y:694,t:1527268132291};\\\", \\\"{x:745,y:678,t:1527268132307};\\\", \\\"{x:707,y:662,t:1527268132324};\\\", \\\"{x:681,y:651,t:1527268132341};\\\", \\\"{x:668,y:640,t:1527268132358};\\\", \\\"{x:662,y:628,t:1527268132374};\\\", \\\"{x:661,y:618,t:1527268132391};\\\", \\\"{x:660,y:608,t:1527268132409};\\\", \\\"{x:657,y:601,t:1527268132425};\\\", \\\"{x:647,y:588,t:1527268132442};\\\", \\\"{x:618,y:573,t:1527268132459};\\\", \\\"{x:568,y:557,t:1527268132474};\\\", \\\"{x:480,y:544,t:1527268132493};\\\", \\\"{x:427,y:537,t:1527268132508};\\\", \\\"{x:382,y:537,t:1527268132525};\\\", \\\"{x:343,y:537,t:1527268132542};\\\", \\\"{x:313,y:537,t:1527268132558};\\\", \\\"{x:287,y:537,t:1527268132575};\\\", \\\"{x:278,y:537,t:1527268132592};\\\", \\\"{x:277,y:537,t:1527268132788};\\\", \\\"{x:274,y:537,t:1527268132796};\\\", \\\"{x:269,y:537,t:1527268132809};\\\", \\\"{x:259,y:541,t:1527268132825};\\\", \\\"{x:245,y:546,t:1527268132843};\\\", \\\"{x:229,y:551,t:1527268132858};\\\", \\\"{x:199,y:557,t:1527268132875};\\\", \\\"{x:189,y:559,t:1527268132893};\\\", \\\"{x:185,y:559,t:1527268132909};\\\", \\\"{x:184,y:559,t:1527268132925};\\\", \\\"{x:183,y:559,t:1527268133020};\\\", \\\"{x:182,y:559,t:1527268133028};\\\", \\\"{x:181,y:559,t:1527268133042};\\\", \\\"{x:177,y:559,t:1527268133059};\\\", \\\"{x:167,y:559,t:1527268133076};\\\", \\\"{x:164,y:559,t:1527268133093};\\\", \\\"{x:164,y:558,t:1527268133110};\\\", \\\"{x:163,y:558,t:1527268133126};\\\", \\\"{x:162,y:557,t:1527268133142};\\\", \\\"{x:162,y:556,t:1527268133159};\\\", \\\"{x:162,y:555,t:1527268133284};\\\", \\\"{x:162,y:554,t:1527268133348};\\\", \\\"{x:165,y:554,t:1527268133444};\\\", \\\"{x:168,y:554,t:1527268133459};\\\", \\\"{x:172,y:557,t:1527268133477};\\\", \\\"{x:174,y:558,t:1527268133540};\\\", \\\"{x:180,y:561,t:1527268133549};\\\", \\\"{x:185,y:563,t:1527268133559};\\\", \\\"{x:191,y:566,t:1527268133577};\\\", \\\"{x:194,y:568,t:1527268133593};\\\", \\\"{x:197,y:570,t:1527268133609};\\\", \\\"{x:198,y:575,t:1527268133626};\\\", \\\"{x:198,y:580,t:1527268133643};\\\", \\\"{x:198,y:585,t:1527268133659};\\\", \\\"{x:195,y:594,t:1527268133676};\\\", \\\"{x:189,y:606,t:1527268133693};\\\", \\\"{x:180,y:618,t:1527268133710};\\\", \\\"{x:176,y:623,t:1527268133728};\\\", \\\"{x:174,y:625,t:1527268133742};\\\", \\\"{x:172,y:625,t:1527268133759};\\\", \\\"{x:170,y:626,t:1527268133776};\\\", \\\"{x:170,y:627,t:1527268133793};\\\", \\\"{x:169,y:627,t:1527268133812};\\\", \\\"{x:168,y:629,t:1527268133827};\\\", \\\"{x:168,y:630,t:1527268133844};\\\", \\\"{x:167,y:631,t:1527268133859};\\\", \\\"{x:162,y:642,t:1527268133876};\\\", \\\"{x:158,y:648,t:1527268133893};\\\", \\\"{x:158,y:649,t:1527268133910};\\\", \\\"{x:158,y:646,t:1527268134045};\\\", \\\"{x:157,y:638,t:1527268134060};\\\", \\\"{x:156,y:633,t:1527268134076};\\\", \\\"{x:156,y:631,t:1527268134093};\\\", \\\"{x:155,y:629,t:1527268134110};\\\", \\\"{x:166,y:629,t:1527268134315};\\\", \\\"{x:184,y:629,t:1527268134326};\\\", \\\"{x:256,y:634,t:1527268134344};\\\", \\\"{x:343,y:638,t:1527268134361};\\\", \\\"{x:445,y:638,t:1527268134377};\\\", \\\"{x:545,y:638,t:1527268134394};\\\", \\\"{x:637,y:638,t:1527268134411};\\\", \\\"{x:708,y:645,t:1527268134427};\\\", \\\"{x:759,y:652,t:1527268134444};\\\", \\\"{x:760,y:653,t:1527268134461};\\\", \\\"{x:760,y:655,t:1527268134531};\\\", \\\"{x:756,y:656,t:1527268134543};\\\", \\\"{x:738,y:665,t:1527268134560};\\\", \\\"{x:715,y:673,t:1527268134577};\\\", \\\"{x:695,y:682,t:1527268134594};\\\", \\\"{x:681,y:689,t:1527268134611};\\\", \\\"{x:673,y:692,t:1527268134628};\\\", \\\"{x:672,y:692,t:1527268134652};\\\", \\\"{x:670,y:693,t:1527268134660};\\\", \\\"{x:660,y:697,t:1527268134677};\\\", \\\"{x:646,y:703,t:1527268134694};\\\", \\\"{x:635,y:705,t:1527268134710};\\\", \\\"{x:620,y:705,t:1527268134727};\\\", \\\"{x:601,y:705,t:1527268134743};\\\", \\\"{x:579,y:705,t:1527268134761};\\\", \\\"{x:556,y:705,t:1527268134778};\\\", \\\"{x:537,y:705,t:1527268134793};\\\", \\\"{x:519,y:704,t:1527268134810};\\\", \\\"{x:501,y:703,t:1527268134827};\\\", \\\"{x:497,y:703,t:1527268134844};\\\", \\\"{x:496,y:703,t:1527268134861};\\\", \\\"{x:494,y:703,t:1527268134878};\\\", \\\"{x:493,y:704,t:1527268134940};\\\", \\\"{x:493,y:707,t:1527268134948};\\\", \\\"{x:493,y:708,t:1527268134962};\\\", \\\"{x:493,y:710,t:1527268134978};\\\" ] }, { \\\"rt\\\": 28609, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 203950, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -K -C -C -C -C -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:493,y:708,t:1527268143636};\\\", \\\"{x:493,y:706,t:1527268143660};\\\", \\\"{x:493,y:705,t:1527268143676};\\\", \\\"{x:494,y:703,t:1527268143740};\\\", \\\"{x:496,y:703,t:1527268143758};\\\", \\\"{x:498,y:701,t:1527268143775};\\\", \\\"{x:499,y:701,t:1527268143791};\\\", \\\"{x:500,y:701,t:1527268143808};\\\", \\\"{x:501,y:700,t:1527268143830};\\\", \\\"{x:504,y:699,t:1527268143844};\\\", \\\"{x:508,y:698,t:1527268143860};\\\", \\\"{x:512,y:697,t:1527268143870};\\\", \\\"{x:518,y:697,t:1527268143886};\\\", \\\"{x:523,y:696,t:1527268143903};\\\", \\\"{x:529,y:696,t:1527268143920};\\\", \\\"{x:533,y:696,t:1527268143937};\\\", \\\"{x:539,y:694,t:1527268143953};\\\", \\\"{x:541,y:694,t:1527268143970};\\\", \\\"{x:544,y:694,t:1527268143987};\\\", \\\"{x:544,y:693,t:1527268145239};\\\", \\\"{x:544,y:691,t:1527268145255};\\\", \\\"{x:540,y:685,t:1527268145272};\\\", \\\"{x:533,y:679,t:1527268145288};\\\", \\\"{x:526,y:672,t:1527268145304};\\\", \\\"{x:520,y:666,t:1527268145322};\\\", \\\"{x:516,y:660,t:1527268145337};\\\", \\\"{x:514,y:658,t:1527268145355};\\\", \\\"{x:513,y:657,t:1527268145371};\\\", \\\"{x:513,y:656,t:1527268145502};\\\", \\\"{x:512,y:654,t:1527268145511};\\\", \\\"{x:510,y:653,t:1527268145522};\\\", \\\"{x:501,y:649,t:1527268145540};\\\", \\\"{x:479,y:643,t:1527268145554};\\\", \\\"{x:435,y:633,t:1527268145571};\\\", \\\"{x:391,y:621,t:1527268145588};\\\", \\\"{x:357,y:611,t:1527268145604};\\\", \\\"{x:331,y:607,t:1527268145621};\\\", \\\"{x:319,y:603,t:1527268145638};\\\", \\\"{x:318,y:603,t:1527268145654};\\\", \\\"{x:331,y:603,t:1527268145799};\\\", \\\"{x:364,y:603,t:1527268145806};\\\", \\\"{x:414,y:603,t:1527268145823};\\\", \\\"{x:524,y:592,t:1527268145840};\\\", \\\"{x:714,y:578,t:1527268145856};\\\", \\\"{x:764,y:578,t:1527268145872};\\\", \\\"{x:766,y:578,t:1527268145888};\\\", \\\"{x:758,y:578,t:1527268145905};\\\", \\\"{x:771,y:574,t:1527268146304};\\\", \\\"{x:791,y:570,t:1527268146322};\\\", \\\"{x:813,y:568,t:1527268146338};\\\", \\\"{x:846,y:563,t:1527268146355};\\\", \\\"{x:900,y:560,t:1527268146372};\\\", \\\"{x:968,y:548,t:1527268146390};\\\", \\\"{x:1034,y:539,t:1527268146405};\\\", \\\"{x:1109,y:527,t:1527268146422};\\\", \\\"{x:1136,y:518,t:1527268146439};\\\", \\\"{x:1155,y:512,t:1527268146456};\\\", \\\"{x:1174,y:507,t:1527268146472};\\\", \\\"{x:1197,y:499,t:1527268146490};\\\", \\\"{x:1226,y:491,t:1527268146506};\\\", \\\"{x:1264,y:481,t:1527268146523};\\\", \\\"{x:1291,y:469,t:1527268146539};\\\", \\\"{x:1352,y:454,t:1527268146556};\\\", \\\"{x:1426,y:435,t:1527268146572};\\\", \\\"{x:1495,y:420,t:1527268146589};\\\", \\\"{x:1531,y:410,t:1527268146606};\\\", \\\"{x:1562,y:404,t:1527268146622};\\\", \\\"{x:1571,y:401,t:1527268146640};\\\", \\\"{x:1573,y:400,t:1527268146655};\\\", \\\"{x:1572,y:400,t:1527268146726};\\\", \\\"{x:1570,y:401,t:1527268146739};\\\", \\\"{x:1567,y:405,t:1527268146755};\\\", \\\"{x:1566,y:413,t:1527268146773};\\\", \\\"{x:1568,y:420,t:1527268146790};\\\", \\\"{x:1571,y:431,t:1527268146806};\\\", \\\"{x:1572,y:445,t:1527268146823};\\\", \\\"{x:1572,y:464,t:1527268146840};\\\", \\\"{x:1572,y:483,t:1527268146856};\\\", \\\"{x:1573,y:500,t:1527268146873};\\\", \\\"{x:1575,y:512,t:1527268146890};\\\", \\\"{x:1575,y:522,t:1527268146906};\\\", \\\"{x:1575,y:529,t:1527268146923};\\\", \\\"{x:1574,y:536,t:1527268146939};\\\", \\\"{x:1568,y:547,t:1527268146956};\\\", \\\"{x:1565,y:556,t:1527268146973};\\\", \\\"{x:1564,y:558,t:1527268146990};\\\", \\\"{x:1562,y:563,t:1527268147006};\\\", \\\"{x:1557,y:571,t:1527268147023};\\\", \\\"{x:1553,y:576,t:1527268147040};\\\", \\\"{x:1547,y:590,t:1527268147055};\\\", \\\"{x:1537,y:601,t:1527268147073};\\\", \\\"{x:1530,y:611,t:1527268147090};\\\", \\\"{x:1526,y:615,t:1527268147106};\\\", \\\"{x:1524,y:618,t:1527268147123};\\\", \\\"{x:1522,y:619,t:1527268147140};\\\", \\\"{x:1522,y:621,t:1527268147158};\\\", \\\"{x:1522,y:622,t:1527268147173};\\\", \\\"{x:1522,y:631,t:1527268147190};\\\", \\\"{x:1522,y:633,t:1527268147207};\\\", \\\"{x:1522,y:636,t:1527268147222};\\\", \\\"{x:1522,y:641,t:1527268147240};\\\", \\\"{x:1522,y:649,t:1527268147257};\\\", \\\"{x:1523,y:669,t:1527268147273};\\\", \\\"{x:1526,y:687,t:1527268147290};\\\", \\\"{x:1528,y:705,t:1527268147307};\\\", \\\"{x:1532,y:726,t:1527268147323};\\\", \\\"{x:1534,y:746,t:1527268147340};\\\", \\\"{x:1538,y:761,t:1527268147357};\\\", \\\"{x:1539,y:769,t:1527268147373};\\\", \\\"{x:1543,y:790,t:1527268147390};\\\", \\\"{x:1547,y:813,t:1527268147406};\\\", \\\"{x:1547,y:828,t:1527268147423};\\\", \\\"{x:1547,y:837,t:1527268147441};\\\", \\\"{x:1547,y:840,t:1527268147457};\\\", \\\"{x:1545,y:844,t:1527268147735};\\\", \\\"{x:1535,y:849,t:1527268147742};\\\", \\\"{x:1523,y:853,t:1527268147757};\\\", \\\"{x:1497,y:869,t:1527268147774};\\\", \\\"{x:1490,y:869,t:1527268147790};\\\", \\\"{x:1491,y:869,t:1527268148191};\\\", \\\"{x:1492,y:868,t:1527268148247};\\\", \\\"{x:1492,y:859,t:1527268148257};\\\", \\\"{x:1492,y:829,t:1527268148274};\\\", \\\"{x:1492,y:815,t:1527268148291};\\\", \\\"{x:1492,y:802,t:1527268148307};\\\", \\\"{x:1492,y:769,t:1527268148323};\\\", \\\"{x:1484,y:741,t:1527268148340};\\\", \\\"{x:1483,y:733,t:1527268148356};\\\", \\\"{x:1483,y:732,t:1527268148374};\\\", \\\"{x:1483,y:726,t:1527268148406};\\\", \\\"{x:1483,y:698,t:1527268148423};\\\", \\\"{x:1483,y:685,t:1527268148440};\\\", \\\"{x:1483,y:677,t:1527268148456};\\\", \\\"{x:1483,y:670,t:1527268148473};\\\", \\\"{x:1484,y:662,t:1527268148491};\\\", \\\"{x:1484,y:660,t:1527268148507};\\\", \\\"{x:1491,y:642,t:1527268148524};\\\", \\\"{x:1501,y:613,t:1527268148541};\\\", \\\"{x:1509,y:593,t:1527268148557};\\\", \\\"{x:1523,y:570,t:1527268148574};\\\", \\\"{x:1555,y:533,t:1527268148590};\\\", \\\"{x:1570,y:516,t:1527268148606};\\\", \\\"{x:1585,y:498,t:1527268148624};\\\", \\\"{x:1596,y:484,t:1527268148641};\\\", \\\"{x:1604,y:477,t:1527268148657};\\\", \\\"{x:1611,y:469,t:1527268148673};\\\", \\\"{x:1615,y:466,t:1527268148691};\\\", \\\"{x:1616,y:465,t:1527268148706};\\\", \\\"{x:1617,y:465,t:1527268148723};\\\", \\\"{x:1617,y:463,t:1527268148759};\\\", \\\"{x:1617,y:461,t:1527268148774};\\\", \\\"{x:1611,y:458,t:1527268148791};\\\", \\\"{x:1606,y:450,t:1527268148808};\\\", \\\"{x:1603,y:444,t:1527268148825};\\\", \\\"{x:1600,y:437,t:1527268148841};\\\", \\\"{x:1599,y:429,t:1527268148858};\\\", \\\"{x:1595,y:424,t:1527268148874};\\\", \\\"{x:1589,y:417,t:1527268148890};\\\", \\\"{x:1581,y:405,t:1527268148908};\\\", \\\"{x:1572,y:388,t:1527268148924};\\\", \\\"{x:1554,y:364,t:1527268148941};\\\", \\\"{x:1540,y:344,t:1527268148958};\\\", \\\"{x:1529,y:327,t:1527268148974};\\\", \\\"{x:1526,y:318,t:1527268148991};\\\", \\\"{x:1526,y:319,t:1527268149127};\\\", \\\"{x:1525,y:331,t:1527268149141};\\\", \\\"{x:1525,y:354,t:1527268149158};\\\", \\\"{x:1525,y:375,t:1527268149174};\\\", \\\"{x:1525,y:395,t:1527268149191};\\\", \\\"{x:1528,y:410,t:1527268149208};\\\", \\\"{x:1529,y:414,t:1527268149223};\\\", \\\"{x:1531,y:422,t:1527268149241};\\\", \\\"{x:1532,y:433,t:1527268149258};\\\", \\\"{x:1533,y:450,t:1527268149274};\\\", \\\"{x:1533,y:469,t:1527268149291};\\\", \\\"{x:1533,y:487,t:1527268149308};\\\", \\\"{x:1533,y:500,t:1527268149324};\\\", \\\"{x:1533,y:516,t:1527268149341};\\\", \\\"{x:1532,y:531,t:1527268149358};\\\", \\\"{x:1530,y:540,t:1527268149374};\\\", \\\"{x:1524,y:568,t:1527268149391};\\\", \\\"{x:1521,y:583,t:1527268149407};\\\", \\\"{x:1516,y:601,t:1527268149425};\\\", \\\"{x:1514,y:614,t:1527268149441};\\\", \\\"{x:1514,y:622,t:1527268149458};\\\", \\\"{x:1514,y:635,t:1527268149477};\\\", \\\"{x:1514,y:652,t:1527268149492};\\\", \\\"{x:1517,y:670,t:1527268149507};\\\", \\\"{x:1530,y:682,t:1527268149525};\\\", \\\"{x:1554,y:693,t:1527268149541};\\\", \\\"{x:1592,y:704,t:1527268149558};\\\", \\\"{x:1692,y:731,t:1527268149575};\\\", \\\"{x:1740,y:748,t:1527268149591};\\\", \\\"{x:1756,y:755,t:1527268149608};\\\", \\\"{x:1767,y:762,t:1527268149625};\\\", \\\"{x:1774,y:776,t:1527268149641};\\\", \\\"{x:1779,y:797,t:1527268149658};\\\", \\\"{x:1780,y:804,t:1527268149675};\\\", \\\"{x:1780,y:810,t:1527268149691};\\\", \\\"{x:1777,y:820,t:1527268149708};\\\", \\\"{x:1771,y:831,t:1527268149725};\\\", \\\"{x:1763,y:839,t:1527268149741};\\\", \\\"{x:1758,y:844,t:1527268149758};\\\", \\\"{x:1742,y:859,t:1527268149774};\\\", \\\"{x:1723,y:868,t:1527268149791};\\\", \\\"{x:1697,y:877,t:1527268149809};\\\", \\\"{x:1660,y:888,t:1527268149825};\\\", \\\"{x:1625,y:896,t:1527268149841};\\\", \\\"{x:1583,y:896,t:1527268149858};\\\", \\\"{x:1505,y:896,t:1527268149875};\\\", \\\"{x:1449,y:896,t:1527268149891};\\\", \\\"{x:1421,y:897,t:1527268149907};\\\", \\\"{x:1400,y:899,t:1527268149924};\\\", \\\"{x:1375,y:899,t:1527268149941};\\\", \\\"{x:1364,y:898,t:1527268149958};\\\", \\\"{x:1331,y:895,t:1527268149973};\\\", \\\"{x:1324,y:895,t:1527268149992};\\\", \\\"{x:1319,y:895,t:1527268150008};\\\", \\\"{x:1318,y:895,t:1527268150025};\\\", \\\"{x:1312,y:895,t:1527268150471};\\\", \\\"{x:1309,y:895,t:1527268150479};\\\", \\\"{x:1302,y:895,t:1527268150492};\\\", \\\"{x:1293,y:895,t:1527268150508};\\\", \\\"{x:1285,y:894,t:1527268150526};\\\", \\\"{x:1276,y:893,t:1527268150543};\\\", \\\"{x:1264,y:892,t:1527268150559};\\\", \\\"{x:1262,y:890,t:1527268150575};\\\", \\\"{x:1260,y:890,t:1527268150671};\\\", \\\"{x:1258,y:888,t:1527268150679};\\\", \\\"{x:1254,y:886,t:1527268150693};\\\", \\\"{x:1248,y:879,t:1527268150709};\\\", \\\"{x:1240,y:873,t:1527268150725};\\\", \\\"{x:1228,y:861,t:1527268150742};\\\", \\\"{x:1224,y:856,t:1527268150759};\\\", \\\"{x:1223,y:852,t:1527268150775};\\\", \\\"{x:1222,y:851,t:1527268150793};\\\", \\\"{x:1222,y:850,t:1527268150911};\\\", \\\"{x:1222,y:848,t:1527268150925};\\\", \\\"{x:1222,y:844,t:1527268150942};\\\", \\\"{x:1221,y:842,t:1527268150959};\\\", \\\"{x:1221,y:841,t:1527268150976};\\\", \\\"{x:1221,y:840,t:1527268150999};\\\", \\\"{x:1220,y:840,t:1527268151023};\\\", \\\"{x:1220,y:838,t:1527268151504};\\\", \\\"{x:1215,y:833,t:1527268151511};\\\", \\\"{x:1212,y:829,t:1527268151526};\\\", \\\"{x:1209,y:825,t:1527268151543};\\\", \\\"{x:1208,y:824,t:1527268151559};\\\", \\\"{x:1208,y:823,t:1527268151606};\\\", \\\"{x:1208,y:822,t:1527268151623};\\\", \\\"{x:1209,y:822,t:1527268152767};\\\", \\\"{x:1212,y:822,t:1527268152777};\\\", \\\"{x:1213,y:822,t:1527268152886};\\\", \\\"{x:1212,y:824,t:1527268153111};\\\", \\\"{x:1211,y:825,t:1527268153126};\\\", \\\"{x:1208,y:829,t:1527268153144};\\\", \\\"{x:1207,y:830,t:1527268153167};\\\", \\\"{x:1208,y:831,t:1527268153735};\\\", \\\"{x:1211,y:832,t:1527268153745};\\\", \\\"{x:1227,y:833,t:1527268153762};\\\", \\\"{x:1244,y:833,t:1527268153778};\\\", \\\"{x:1260,y:833,t:1527268153794};\\\", \\\"{x:1279,y:834,t:1527268153811};\\\", \\\"{x:1293,y:836,t:1527268153828};\\\", \\\"{x:1295,y:836,t:1527268153845};\\\", \\\"{x:1295,y:837,t:1527268153863};\\\", \\\"{x:1294,y:836,t:1527268154191};\\\", \\\"{x:1292,y:836,t:1527268154199};\\\", \\\"{x:1291,y:836,t:1527268154231};\\\", \\\"{x:1290,y:835,t:1527268154431};\\\", \\\"{x:1286,y:833,t:1527268154445};\\\", \\\"{x:1284,y:833,t:1527268154462};\\\", \\\"{x:1281,y:833,t:1527268154477};\\\", \\\"{x:1278,y:833,t:1527268154495};\\\", \\\"{x:1277,y:833,t:1527268154511};\\\", \\\"{x:1276,y:833,t:1527268154656};\\\", \\\"{x:1274,y:833,t:1527268154663};\\\", \\\"{x:1268,y:835,t:1527268154679};\\\", \\\"{x:1258,y:837,t:1527268154695};\\\", \\\"{x:1250,y:837,t:1527268154711};\\\", \\\"{x:1240,y:838,t:1527268154728};\\\", \\\"{x:1231,y:838,t:1527268154744};\\\", \\\"{x:1227,y:838,t:1527268154760};\\\", \\\"{x:1226,y:838,t:1527268154778};\\\", \\\"{x:1225,y:839,t:1527268154798};\\\", \\\"{x:1230,y:836,t:1527268164239};\\\", \\\"{x:1237,y:833,t:1527268164251};\\\", \\\"{x:1240,y:831,t:1527268164267};\\\", \\\"{x:1241,y:831,t:1527268164295};\\\", \\\"{x:1243,y:831,t:1527268164335};\\\", \\\"{x:1247,y:831,t:1527268164351};\\\", \\\"{x:1255,y:832,t:1527268164367};\\\", \\\"{x:1259,y:834,t:1527268164384};\\\", \\\"{x:1261,y:834,t:1527268164401};\\\", \\\"{x:1263,y:835,t:1527268164417};\\\", \\\"{x:1265,y:836,t:1527268164434};\\\", \\\"{x:1266,y:837,t:1527268164451};\\\", \\\"{x:1267,y:837,t:1527268164478};\\\", \\\"{x:1268,y:837,t:1527268164494};\\\", \\\"{x:1269,y:837,t:1527268164502};\\\", \\\"{x:1270,y:838,t:1527268164535};\\\", \\\"{x:1270,y:839,t:1527268164567};\\\", \\\"{x:1271,y:839,t:1527268164584};\\\", \\\"{x:1272,y:839,t:1527268164630};\\\", \\\"{x:1273,y:839,t:1527268164679};\\\", \\\"{x:1274,y:839,t:1527268164686};\\\", \\\"{x:1275,y:839,t:1527268164701};\\\", \\\"{x:1280,y:838,t:1527268164718};\\\", \\\"{x:1282,y:838,t:1527268164733};\\\", \\\"{x:1282,y:837,t:1527268164750};\\\", \\\"{x:1283,y:837,t:1527268165015};\\\", \\\"{x:1263,y:832,t:1527268165431};\\\", \\\"{x:1192,y:814,t:1527268165439};\\\", \\\"{x:1055,y:793,t:1527268165451};\\\", \\\"{x:765,y:744,t:1527268165468};\\\", \\\"{x:472,y:703,t:1527268165486};\\\", \\\"{x:212,y:653,t:1527268165501};\\\", \\\"{x:26,y:621,t:1527268165518};\\\", \\\"{x:0,y:605,t:1527268165538};\\\", \\\"{x:0,y:603,t:1527268165554};\\\", \\\"{x:2,y:603,t:1527268165582};\\\", \\\"{x:7,y:599,t:1527268165590};\\\", \\\"{x:19,y:592,t:1527268165605};\\\", \\\"{x:43,y:578,t:1527268165621};\\\", \\\"{x:62,y:568,t:1527268165638};\\\", \\\"{x:94,y:548,t:1527268165655};\\\", \\\"{x:135,y:524,t:1527268165672};\\\", \\\"{x:164,y:509,t:1527268165688};\\\", \\\"{x:180,y:500,t:1527268165705};\\\", \\\"{x:193,y:489,t:1527268165721};\\\", \\\"{x:196,y:485,t:1527268165737};\\\", \\\"{x:204,y:477,t:1527268165755};\\\", \\\"{x:230,y:465,t:1527268165771};\\\", \\\"{x:258,y:455,t:1527268165788};\\\", \\\"{x:274,y:453,t:1527268165804};\\\", \\\"{x:295,y:450,t:1527268165821};\\\", \\\"{x:331,y:448,t:1527268165838};\\\", \\\"{x:348,y:448,t:1527268165854};\\\", \\\"{x:355,y:448,t:1527268165872};\\\", \\\"{x:363,y:453,t:1527268165889};\\\", \\\"{x:371,y:462,t:1527268165905};\\\", \\\"{x:376,y:474,t:1527268165922};\\\", \\\"{x:378,y:482,t:1527268165939};\\\", \\\"{x:381,y:487,t:1527268165955};\\\", \\\"{x:381,y:490,t:1527268165971};\\\", \\\"{x:381,y:497,t:1527268165989};\\\", \\\"{x:380,y:506,t:1527268166005};\\\", \\\"{x:380,y:512,t:1527268166022};\\\", \\\"{x:380,y:519,t:1527268166037};\\\", \\\"{x:380,y:521,t:1527268166054};\\\", \\\"{x:380,y:523,t:1527268166072};\\\", \\\"{x:380,y:524,t:1527268166089};\\\", \\\"{x:379,y:525,t:1527268166118};\\\", \\\"{x:379,y:527,t:1527268166159};\\\", \\\"{x:379,y:529,t:1527268166171};\\\", \\\"{x:379,y:530,t:1527268166188};\\\", \\\"{x:379,y:531,t:1527268166204};\\\", \\\"{x:379,y:533,t:1527268166695};\\\", \\\"{x:385,y:540,t:1527268166707};\\\", \\\"{x:399,y:551,t:1527268166722};\\\", \\\"{x:413,y:564,t:1527268166738};\\\", \\\"{x:427,y:580,t:1527268166756};\\\", \\\"{x:440,y:600,t:1527268166772};\\\", \\\"{x:447,y:617,t:1527268166788};\\\", \\\"{x:452,y:636,t:1527268166806};\\\", \\\"{x:457,y:654,t:1527268166821};\\\", \\\"{x:457,y:657,t:1527268166838};\\\", \\\"{x:459,y:663,t:1527268166855};\\\", \\\"{x:461,y:674,t:1527268166872};\\\", \\\"{x:463,y:684,t:1527268166888};\\\", \\\"{x:467,y:699,t:1527268166905};\\\", \\\"{x:467,y:705,t:1527268166923};\\\", \\\"{x:467,y:706,t:1527268166938};\\\", \\\"{x:467,y:708,t:1527268166957};\\\", \\\"{x:468,y:708,t:1527268166971};\\\", \\\"{x:470,y:716,t:1527268166988};\\\", \\\"{x:472,y:727,t:1527268167006};\\\", \\\"{x:473,y:739,t:1527268167023};\\\", \\\"{x:475,y:740,t:1527268168231};\\\", \\\"{x:484,y:740,t:1527268168240};\\\", \\\"{x:496,y:740,t:1527268168256};\\\", \\\"{x:497,y:740,t:1527268168367};\\\", \\\"{x:497,y:737,t:1527268168374};\\\", \\\"{x:497,y:733,t:1527268168391};\\\", \\\"{x:493,y:719,t:1527268168407};\\\", \\\"{x:493,y:716,t:1527268168424};\\\", \\\"{x:493,y:715,t:1527268168440};\\\", \\\"{x:492,y:715,t:1527268168457};\\\" ] }, { \\\"rt\\\": 55371, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 260552, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-04 PM-E -E -02 PM-Z -12 PM-Z -F -F -O -U -U -02 PM-02 PM-U -U -U -04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:492,y:713,t:1527268170454};\\\", \\\"{x:488,y:699,t:1527268170463};\\\", \\\"{x:483,y:684,t:1527268170476};\\\", \\\"{x:480,y:669,t:1527268170492};\\\", \\\"{x:478,y:658,t:1527268170509};\\\", \\\"{x:477,y:656,t:1527268170525};\\\", \\\"{x:476,y:655,t:1527268170598};\\\", \\\"{x:474,y:653,t:1527268170608};\\\", \\\"{x:468,y:641,t:1527268170625};\\\", \\\"{x:463,y:630,t:1527268170641};\\\", \\\"{x:457,y:616,t:1527268170659};\\\", \\\"{x:445,y:604,t:1527268170675};\\\", \\\"{x:419,y:592,t:1527268170692};\\\", \\\"{x:401,y:584,t:1527268170708};\\\", \\\"{x:400,y:583,t:1527268170724};\\\", \\\"{x:398,y:580,t:1527268170758};\\\", \\\"{x:395,y:579,t:1527268170776};\\\", \\\"{x:396,y:579,t:1527268171542};\\\", \\\"{x:401,y:579,t:1527268171559};\\\", \\\"{x:407,y:579,t:1527268171576};\\\", \\\"{x:422,y:579,t:1527268171593};\\\", \\\"{x:446,y:581,t:1527268171609};\\\", \\\"{x:478,y:585,t:1527268171627};\\\", \\\"{x:520,y:590,t:1527268171643};\\\", \\\"{x:573,y:597,t:1527268171659};\\\", \\\"{x:637,y:606,t:1527268171676};\\\", \\\"{x:708,y:611,t:1527268171693};\\\", \\\"{x:773,y:615,t:1527268171709};\\\", \\\"{x:849,y:622,t:1527268171725};\\\", \\\"{x:878,y:626,t:1527268171743};\\\", \\\"{x:907,y:630,t:1527268171759};\\\", \\\"{x:945,y:634,t:1527268171775};\\\", \\\"{x:998,y:642,t:1527268171793};\\\", \\\"{x:1044,y:645,t:1527268171810};\\\", \\\"{x:1070,y:647,t:1527268171825};\\\", \\\"{x:1100,y:647,t:1527268171843};\\\", \\\"{x:1123,y:647,t:1527268171860};\\\", \\\"{x:1161,y:651,t:1527268171876};\\\", \\\"{x:1203,y:658,t:1527268171893};\\\", \\\"{x:1263,y:665,t:1527268171910};\\\", \\\"{x:1296,y:666,t:1527268171926};\\\", \\\"{x:1317,y:667,t:1527268171943};\\\", \\\"{x:1331,y:667,t:1527268171960};\\\", \\\"{x:1334,y:667,t:1527268171976};\\\", \\\"{x:1338,y:667,t:1527268172343};\\\", \\\"{x:1345,y:667,t:1527268172360};\\\", \\\"{x:1364,y:664,t:1527268172377};\\\", \\\"{x:1386,y:660,t:1527268172393};\\\", \\\"{x:1408,y:658,t:1527268172410};\\\", \\\"{x:1426,y:655,t:1527268172427};\\\", \\\"{x:1440,y:653,t:1527268172443};\\\", \\\"{x:1451,y:652,t:1527268172460};\\\", \\\"{x:1461,y:650,t:1527268172477};\\\", \\\"{x:1470,y:649,t:1527268172493};\\\", \\\"{x:1478,y:648,t:1527268172509};\\\", \\\"{x:1480,y:648,t:1527268172541};\\\", \\\"{x:1481,y:646,t:1527268172565};\\\", \\\"{x:1482,y:645,t:1527268172589};\\\", \\\"{x:1484,y:644,t:1527268172598};\\\", \\\"{x:1485,y:644,t:1527268172609};\\\", \\\"{x:1493,y:642,t:1527268172627};\\\", \\\"{x:1501,y:640,t:1527268172643};\\\", \\\"{x:1508,y:637,t:1527268172660};\\\", \\\"{x:1518,y:635,t:1527268172676};\\\", \\\"{x:1529,y:632,t:1527268172693};\\\", \\\"{x:1542,y:631,t:1527268172710};\\\", \\\"{x:1549,y:629,t:1527268172727};\\\", \\\"{x:1550,y:628,t:1527268172743};\\\", \\\"{x:1552,y:628,t:1527268172806};\\\", \\\"{x:1553,y:628,t:1527268172822};\\\", \\\"{x:1554,y:628,t:1527268172975};\\\", \\\"{x:1554,y:633,t:1527268172982};\\\", \\\"{x:1557,y:636,t:1527268172994};\\\", \\\"{x:1565,y:650,t:1527268173011};\\\", \\\"{x:1577,y:667,t:1527268173027};\\\", \\\"{x:1585,y:690,t:1527268173044};\\\", \\\"{x:1587,y:722,t:1527268173060};\\\", \\\"{x:1587,y:762,t:1527268173077};\\\", \\\"{x:1575,y:824,t:1527268173094};\\\", \\\"{x:1566,y:862,t:1527268173110};\\\", \\\"{x:1560,y:892,t:1527268173127};\\\", \\\"{x:1557,y:907,t:1527268173144};\\\", \\\"{x:1555,y:921,t:1527268173160};\\\", \\\"{x:1555,y:925,t:1527268173177};\\\", \\\"{x:1554,y:928,t:1527268173214};\\\", \\\"{x:1551,y:933,t:1527268173227};\\\", \\\"{x:1544,y:948,t:1527268173244};\\\", \\\"{x:1536,y:957,t:1527268173260};\\\", \\\"{x:1532,y:963,t:1527268173277};\\\", \\\"{x:1530,y:966,t:1527268173294};\\\", \\\"{x:1529,y:967,t:1527268173311};\\\", \\\"{x:1528,y:968,t:1527268173367};\\\", \\\"{x:1527,y:969,t:1527268173382};\\\", \\\"{x:1527,y:970,t:1527268173394};\\\", \\\"{x:1522,y:973,t:1527268173411};\\\", \\\"{x:1519,y:974,t:1527268173427};\\\", \\\"{x:1514,y:978,t:1527268173444};\\\", \\\"{x:1510,y:981,t:1527268173461};\\\", \\\"{x:1509,y:982,t:1527268173478};\\\", \\\"{x:1508,y:982,t:1527268173495};\\\", \\\"{x:1510,y:982,t:1527268173783};\\\", \\\"{x:1514,y:982,t:1527268173794};\\\", \\\"{x:1524,y:982,t:1527268173811};\\\", \\\"{x:1534,y:980,t:1527268173828};\\\", \\\"{x:1544,y:978,t:1527268173844};\\\", \\\"{x:1548,y:978,t:1527268173861};\\\", \\\"{x:1553,y:977,t:1527268173878};\\\", \\\"{x:1555,y:977,t:1527268173911};\\\", \\\"{x:1557,y:976,t:1527268173928};\\\", \\\"{x:1563,y:975,t:1527268173944};\\\", \\\"{x:1571,y:975,t:1527268173963};\\\", \\\"{x:1580,y:974,t:1527268173978};\\\", \\\"{x:1588,y:972,t:1527268173994};\\\", \\\"{x:1601,y:971,t:1527268174011};\\\", \\\"{x:1615,y:969,t:1527268174028};\\\", \\\"{x:1624,y:967,t:1527268174044};\\\", \\\"{x:1631,y:966,t:1527268174061};\\\", \\\"{x:1632,y:966,t:1527268174079};\\\", \\\"{x:1633,y:966,t:1527268175565};\\\", \\\"{x:1633,y:964,t:1527268175735};\\\", \\\"{x:1633,y:963,t:1527268175745};\\\", \\\"{x:1633,y:960,t:1527268175763};\\\", \\\"{x:1632,y:957,t:1527268175779};\\\", \\\"{x:1632,y:956,t:1527268175796};\\\", \\\"{x:1630,y:956,t:1527268176047};\\\", \\\"{x:1628,y:955,t:1527268176063};\\\", \\\"{x:1625,y:954,t:1527268176079};\\\", \\\"{x:1624,y:954,t:1527268176096};\\\", \\\"{x:1622,y:953,t:1527268176112};\\\", \\\"{x:1618,y:952,t:1527268176129};\\\", \\\"{x:1611,y:948,t:1527268176146};\\\", \\\"{x:1605,y:946,t:1527268176162};\\\", \\\"{x:1598,y:944,t:1527268176180};\\\", \\\"{x:1587,y:942,t:1527268176196};\\\", \\\"{x:1573,y:940,t:1527268176212};\\\", \\\"{x:1559,y:939,t:1527268176229};\\\", \\\"{x:1520,y:933,t:1527268176246};\\\", \\\"{x:1483,y:928,t:1527268176263};\\\", \\\"{x:1438,y:928,t:1527268176279};\\\", \\\"{x:1396,y:928,t:1527268176296};\\\", \\\"{x:1360,y:928,t:1527268176311};\\\", \\\"{x:1338,y:928,t:1527268176329};\\\", \\\"{x:1327,y:928,t:1527268176346};\\\", \\\"{x:1321,y:928,t:1527268176361};\\\", \\\"{x:1320,y:927,t:1527268176382};\\\", \\\"{x:1319,y:927,t:1527268176413};\\\", \\\"{x:1318,y:927,t:1527268176428};\\\", \\\"{x:1316,y:926,t:1527268176446};\\\", \\\"{x:1316,y:925,t:1527268176478};\\\", \\\"{x:1315,y:925,t:1527268176502};\\\", \\\"{x:1314,y:925,t:1527268176534};\\\", \\\"{x:1313,y:925,t:1527268176550};\\\", \\\"{x:1312,y:925,t:1527268176567};\\\", \\\"{x:1312,y:924,t:1527268176580};\\\", \\\"{x:1311,y:924,t:1527268176623};\\\", \\\"{x:1310,y:924,t:1527268176646};\\\", \\\"{x:1309,y:923,t:1527268176695};\\\", \\\"{x:1308,y:922,t:1527268176823};\\\", \\\"{x:1307,y:922,t:1527268176887};\\\", \\\"{x:1306,y:922,t:1527268176935};\\\", \\\"{x:1305,y:921,t:1527268176951};\\\", \\\"{x:1304,y:920,t:1527268176967};\\\", \\\"{x:1303,y:919,t:1527268176979};\\\", \\\"{x:1298,y:915,t:1527268176997};\\\", \\\"{x:1296,y:913,t:1527268177013};\\\", \\\"{x:1294,y:911,t:1527268177030};\\\", \\\"{x:1290,y:910,t:1527268177046};\\\", \\\"{x:1288,y:908,t:1527268177064};\\\", \\\"{x:1287,y:907,t:1527268177081};\\\", \\\"{x:1286,y:905,t:1527268177096};\\\", \\\"{x:1285,y:904,t:1527268177118};\\\", \\\"{x:1284,y:904,t:1527268177134};\\\", \\\"{x:1284,y:902,t:1527268177150};\\\", \\\"{x:1283,y:902,t:1527268177182};\\\", \\\"{x:1283,y:901,t:1527268177197};\\\", \\\"{x:1282,y:901,t:1527268177213};\\\", \\\"{x:1280,y:899,t:1527268177230};\\\", \\\"{x:1278,y:897,t:1527268177246};\\\", \\\"{x:1278,y:896,t:1527268177263};\\\", \\\"{x:1276,y:895,t:1527268177280};\\\", \\\"{x:1273,y:893,t:1527268177296};\\\", \\\"{x:1271,y:891,t:1527268177313};\\\", \\\"{x:1268,y:889,t:1527268177330};\\\", \\\"{x:1265,y:887,t:1527268177346};\\\", \\\"{x:1263,y:885,t:1527268177363};\\\", \\\"{x:1258,y:882,t:1527268177380};\\\", \\\"{x:1252,y:877,t:1527268177396};\\\", \\\"{x:1243,y:872,t:1527268177413};\\\", \\\"{x:1227,y:860,t:1527268177430};\\\", \\\"{x:1222,y:858,t:1527268177446};\\\", \\\"{x:1217,y:853,t:1527268177463};\\\", \\\"{x:1207,y:847,t:1527268177480};\\\", \\\"{x:1204,y:845,t:1527268177497};\\\", \\\"{x:1202,y:844,t:1527268177514};\\\", \\\"{x:1202,y:843,t:1527268177531};\\\", \\\"{x:1201,y:842,t:1527268177546};\\\", \\\"{x:1208,y:842,t:1527268179775};\\\", \\\"{x:1233,y:842,t:1527268179782};\\\", \\\"{x:1288,y:853,t:1527268179799};\\\", \\\"{x:1339,y:863,t:1527268179815};\\\", \\\"{x:1383,y:868,t:1527268179832};\\\", \\\"{x:1417,y:875,t:1527268179848};\\\", \\\"{x:1440,y:878,t:1527268179865};\\\", \\\"{x:1461,y:882,t:1527268179882};\\\", \\\"{x:1472,y:886,t:1527268179898};\\\", \\\"{x:1481,y:889,t:1527268179916};\\\", \\\"{x:1491,y:896,t:1527268179932};\\\", \\\"{x:1513,y:907,t:1527268179948};\\\", \\\"{x:1534,y:914,t:1527268179965};\\\", \\\"{x:1547,y:918,t:1527268179982};\\\", \\\"{x:1551,y:918,t:1527268179998};\\\", \\\"{x:1552,y:918,t:1527268180023};\\\", \\\"{x:1556,y:918,t:1527268180032};\\\", \\\"{x:1572,y:921,t:1527268180048};\\\", \\\"{x:1601,y:924,t:1527268180065};\\\", \\\"{x:1635,y:929,t:1527268180082};\\\", \\\"{x:1657,y:929,t:1527268180099};\\\", \\\"{x:1672,y:929,t:1527268180116};\\\", \\\"{x:1681,y:929,t:1527268180131};\\\", \\\"{x:1681,y:928,t:1527268180279};\\\", \\\"{x:1675,y:924,t:1527268180287};\\\", \\\"{x:1665,y:918,t:1527268180299};\\\", \\\"{x:1655,y:909,t:1527268180315};\\\", \\\"{x:1651,y:906,t:1527268180331};\\\", \\\"{x:1647,y:903,t:1527268180348};\\\", \\\"{x:1643,y:900,t:1527268180365};\\\", \\\"{x:1634,y:894,t:1527268180382};\\\", \\\"{x:1629,y:890,t:1527268180398};\\\", \\\"{x:1627,y:889,t:1527268180415};\\\", \\\"{x:1625,y:888,t:1527268180432};\\\", \\\"{x:1625,y:887,t:1527268180549};\\\", \\\"{x:1624,y:887,t:1527268180574};\\\", \\\"{x:1624,y:886,t:1527268180581};\\\", \\\"{x:1622,y:884,t:1527268180598};\\\", \\\"{x:1622,y:883,t:1527268180615};\\\", \\\"{x:1621,y:882,t:1527268180632};\\\", \\\"{x:1620,y:883,t:1527268180791};\\\", \\\"{x:1619,y:891,t:1527268180799};\\\", \\\"{x:1617,y:910,t:1527268180816};\\\", \\\"{x:1616,y:925,t:1527268180833};\\\", \\\"{x:1615,y:937,t:1527268180850};\\\", \\\"{x:1615,y:939,t:1527268180866};\\\", \\\"{x:1614,y:939,t:1527268180919};\\\", \\\"{x:1614,y:941,t:1527268180933};\\\", \\\"{x:1614,y:944,t:1527268180950};\\\", \\\"{x:1615,y:946,t:1527268180966};\\\", \\\"{x:1615,y:944,t:1527268181063};\\\", \\\"{x:1615,y:939,t:1527268181070};\\\", \\\"{x:1615,y:931,t:1527268181082};\\\", \\\"{x:1615,y:921,t:1527268181101};\\\", \\\"{x:1617,y:915,t:1527268181115};\\\", \\\"{x:1620,y:908,t:1527268181132};\\\", \\\"{x:1624,y:900,t:1527268181150};\\\", \\\"{x:1626,y:896,t:1527268181166};\\\", \\\"{x:1627,y:891,t:1527268181182};\\\", \\\"{x:1627,y:889,t:1527268181199};\\\", \\\"{x:1627,y:888,t:1527268181223};\\\", \\\"{x:1627,y:887,t:1527268181233};\\\", \\\"{x:1627,y:884,t:1527268181250};\\\", \\\"{x:1627,y:879,t:1527268181266};\\\", \\\"{x:1627,y:873,t:1527268181283};\\\", \\\"{x:1627,y:870,t:1527268181301};\\\", \\\"{x:1626,y:865,t:1527268181316};\\\", \\\"{x:1625,y:860,t:1527268181332};\\\", \\\"{x:1622,y:853,t:1527268181350};\\\", \\\"{x:1621,y:849,t:1527268181366};\\\", \\\"{x:1621,y:845,t:1527268181383};\\\", \\\"{x:1621,y:842,t:1527268181400};\\\", \\\"{x:1621,y:840,t:1527268181417};\\\", \\\"{x:1620,y:839,t:1527268181446};\\\", \\\"{x:1620,y:837,t:1527268181462};\\\", \\\"{x:1620,y:833,t:1527268181471};\\\", \\\"{x:1620,y:828,t:1527268181483};\\\", \\\"{x:1619,y:823,t:1527268181501};\\\", \\\"{x:1618,y:820,t:1527268181516};\\\", \\\"{x:1618,y:819,t:1527268181532};\\\", \\\"{x:1618,y:817,t:1527268181550};\\\", \\\"{x:1618,y:816,t:1527268181590};\\\", \\\"{x:1618,y:815,t:1527268181600};\\\", \\\"{x:1617,y:810,t:1527268181617};\\\", \\\"{x:1614,y:806,t:1527268181633};\\\", \\\"{x:1614,y:805,t:1527268181662};\\\", \\\"{x:1613,y:803,t:1527268181670};\\\", \\\"{x:1612,y:801,t:1527268181682};\\\", \\\"{x:1610,y:798,t:1527268181701};\\\", \\\"{x:1609,y:796,t:1527268181717};\\\", \\\"{x:1608,y:795,t:1527268181733};\\\", \\\"{x:1608,y:793,t:1527268181750};\\\", \\\"{x:1606,y:786,t:1527268181767};\\\", \\\"{x:1606,y:785,t:1527268181783};\\\", \\\"{x:1605,y:784,t:1527268181800};\\\", \\\"{x:1603,y:776,t:1527268181816};\\\", \\\"{x:1600,y:767,t:1527268181834};\\\", \\\"{x:1599,y:762,t:1527268181850};\\\", \\\"{x:1599,y:761,t:1527268181879};\\\", \\\"{x:1599,y:759,t:1527268181895};\\\", \\\"{x:1599,y:756,t:1527268181902};\\\", \\\"{x:1599,y:749,t:1527268181916};\\\", \\\"{x:1597,y:727,t:1527268181933};\\\", \\\"{x:1595,y:722,t:1527268181949};\\\", \\\"{x:1595,y:717,t:1527268181966};\\\", \\\"{x:1595,y:715,t:1527268181983};\\\", \\\"{x:1595,y:707,t:1527268181999};\\\", \\\"{x:1595,y:698,t:1527268182016};\\\", \\\"{x:1595,y:695,t:1527268182033};\\\", \\\"{x:1595,y:691,t:1527268182049};\\\", \\\"{x:1595,y:687,t:1527268182066};\\\", \\\"{x:1595,y:681,t:1527268182083};\\\", \\\"{x:1595,y:677,t:1527268182100};\\\", \\\"{x:1595,y:673,t:1527268182116};\\\", \\\"{x:1595,y:669,t:1527268182133};\\\", \\\"{x:1595,y:663,t:1527268182149};\\\", \\\"{x:1595,y:659,t:1527268182167};\\\", \\\"{x:1595,y:655,t:1527268182184};\\\", \\\"{x:1595,y:651,t:1527268182199};\\\", \\\"{x:1596,y:646,t:1527268182216};\\\", \\\"{x:1596,y:641,t:1527268182233};\\\", \\\"{x:1596,y:631,t:1527268182250};\\\", \\\"{x:1596,y:623,t:1527268182266};\\\", \\\"{x:1598,y:610,t:1527268182283};\\\", \\\"{x:1598,y:604,t:1527268182299};\\\", \\\"{x:1600,y:598,t:1527268182316};\\\", \\\"{x:1600,y:594,t:1527268182333};\\\", \\\"{x:1602,y:591,t:1527268182349};\\\", \\\"{x:1603,y:589,t:1527268182367};\\\", \\\"{x:1603,y:587,t:1527268182383};\\\", \\\"{x:1604,y:585,t:1527268182400};\\\", \\\"{x:1604,y:583,t:1527268182416};\\\", \\\"{x:1604,y:581,t:1527268182433};\\\", \\\"{x:1605,y:580,t:1527268182450};\\\", \\\"{x:1605,y:579,t:1527268182470};\\\", \\\"{x:1605,y:578,t:1527268182494};\\\", \\\"{x:1605,y:577,t:1527268182510};\\\", \\\"{x:1606,y:576,t:1527268182518};\\\", \\\"{x:1607,y:575,t:1527268182534};\\\", \\\"{x:1607,y:574,t:1527268182567};\\\", \\\"{x:1607,y:573,t:1527268182591};\\\", \\\"{x:1607,y:572,t:1527268182607};\\\", \\\"{x:1608,y:571,t:1527268182617};\\\", \\\"{x:1609,y:570,t:1527268182633};\\\", \\\"{x:1610,y:569,t:1527268182651};\\\", \\\"{x:1610,y:568,t:1527268182687};\\\", \\\"{x:1611,y:565,t:1527268182705};\\\", \\\"{x:1613,y:563,t:1527268182716};\\\", \\\"{x:1614,y:562,t:1527268182733};\\\", \\\"{x:1614,y:561,t:1527268182750};\\\", \\\"{x:1613,y:555,t:1527268183200};\\\", \\\"{x:1611,y:536,t:1527268183218};\\\", \\\"{x:1611,y:517,t:1527268183234};\\\", \\\"{x:1611,y:502,t:1527268183251};\\\", \\\"{x:1614,y:490,t:1527268183268};\\\", \\\"{x:1615,y:483,t:1527268183283};\\\", \\\"{x:1615,y:480,t:1527268183302};\\\", \\\"{x:1615,y:477,t:1527268183535};\\\", \\\"{x:1607,y:468,t:1527268183551};\\\", \\\"{x:1600,y:460,t:1527268183568};\\\", \\\"{x:1594,y:453,t:1527268183584};\\\", \\\"{x:1591,y:450,t:1527268183600};\\\", \\\"{x:1587,y:446,t:1527268183618};\\\", \\\"{x:1586,y:445,t:1527268183654};\\\", \\\"{x:1587,y:444,t:1527268183879};\\\", \\\"{x:1588,y:444,t:1527268183943};\\\", \\\"{x:1589,y:444,t:1527268183951};\\\", \\\"{x:1590,y:444,t:1527268183968};\\\", \\\"{x:1591,y:444,t:1527268183985};\\\", \\\"{x:1593,y:444,t:1527268184002};\\\", \\\"{x:1593,y:443,t:1527268184039};\\\", \\\"{x:1594,y:443,t:1527268184051};\\\", \\\"{x:1595,y:443,t:1527268184067};\\\", \\\"{x:1596,y:443,t:1527268184127};\\\", \\\"{x:1597,y:443,t:1527268184183};\\\", \\\"{x:1599,y:441,t:1527268184223};\\\", \\\"{x:1601,y:441,t:1527268184254};\\\", \\\"{x:1603,y:440,t:1527268184279};\\\", \\\"{x:1604,y:440,t:1527268184295};\\\", \\\"{x:1604,y:439,t:1527268184302};\\\", \\\"{x:1605,y:439,t:1527268184325};\\\", \\\"{x:1606,y:438,t:1527268184358};\\\", \\\"{x:1607,y:438,t:1527268184373};\\\", \\\"{x:1608,y:438,t:1527268184479};\\\", \\\"{x:1609,y:438,t:1527268186343};\\\", \\\"{x:1609,y:441,t:1527268186353};\\\", \\\"{x:1606,y:455,t:1527268186370};\\\", \\\"{x:1602,y:475,t:1527268186386};\\\", \\\"{x:1597,y:494,t:1527268186403};\\\", \\\"{x:1594,y:510,t:1527268186420};\\\", \\\"{x:1590,y:522,t:1527268186436};\\\", \\\"{x:1587,y:533,t:1527268186453};\\\", \\\"{x:1585,y:547,t:1527268186469};\\\", \\\"{x:1582,y:568,t:1527268186486};\\\", \\\"{x:1580,y:586,t:1527268186503};\\\", \\\"{x:1576,y:599,t:1527268186519};\\\", \\\"{x:1574,y:616,t:1527268186536};\\\", \\\"{x:1573,y:633,t:1527268186552};\\\", \\\"{x:1568,y:655,t:1527268186569};\\\", \\\"{x:1560,y:679,t:1527268186586};\\\", \\\"{x:1551,y:705,t:1527268186602};\\\", \\\"{x:1541,y:729,t:1527268186619};\\\", \\\"{x:1531,y:752,t:1527268186637};\\\", \\\"{x:1522,y:777,t:1527268186652};\\\", \\\"{x:1509,y:819,t:1527268186670};\\\", \\\"{x:1493,y:883,t:1527268186686};\\\", \\\"{x:1477,y:931,t:1527268186702};\\\", \\\"{x:1457,y:985,t:1527268186720};\\\", \\\"{x:1442,y:1021,t:1527268186736};\\\", \\\"{x:1436,y:1037,t:1527268186753};\\\", \\\"{x:1432,y:1047,t:1527268186769};\\\", \\\"{x:1431,y:1050,t:1527268186787};\\\", \\\"{x:1431,y:1051,t:1527268186814};\\\", \\\"{x:1431,y:1048,t:1527268188095};\\\", \\\"{x:1431,y:1046,t:1527268188104};\\\", \\\"{x:1431,y:1044,t:1527268188121};\\\", \\\"{x:1431,y:1043,t:1527268188158};\\\", \\\"{x:1431,y:1039,t:1527268189854};\\\", \\\"{x:1436,y:1029,t:1527268189861};\\\", \\\"{x:1442,y:1022,t:1527268189872};\\\", \\\"{x:1458,y:1008,t:1527268189889};\\\", \\\"{x:1471,y:996,t:1527268189904};\\\", \\\"{x:1476,y:992,t:1527268189922};\\\", \\\"{x:1478,y:990,t:1527268189939};\\\", \\\"{x:1479,y:990,t:1527268189999};\\\", \\\"{x:1480,y:989,t:1527268190015};\\\", \\\"{x:1480,y:988,t:1527268190022};\\\", \\\"{x:1483,y:986,t:1527268190039};\\\", \\\"{x:1486,y:983,t:1527268190055};\\\", \\\"{x:1489,y:980,t:1527268190072};\\\", \\\"{x:1490,y:978,t:1527268190089};\\\", \\\"{x:1491,y:977,t:1527268190105};\\\", \\\"{x:1492,y:976,t:1527268190121};\\\", \\\"{x:1493,y:975,t:1527268190189};\\\", \\\"{x:1494,y:975,t:1527268190214};\\\", \\\"{x:1495,y:975,t:1527268190222};\\\", \\\"{x:1495,y:974,t:1527268190655};\\\", \\\"{x:1492,y:972,t:1527268190672};\\\", \\\"{x:1488,y:970,t:1527268190689};\\\", \\\"{x:1487,y:969,t:1527268190775};\\\", \\\"{x:1486,y:969,t:1527268190789};\\\", \\\"{x:1481,y:968,t:1527268190807};\\\", \\\"{x:1479,y:966,t:1527268190823};\\\", \\\"{x:1476,y:966,t:1527268190839};\\\", \\\"{x:1475,y:966,t:1527268190856};\\\", \\\"{x:1474,y:965,t:1527268190872};\\\", \\\"{x:1472,y:965,t:1527268190889};\\\", \\\"{x:1471,y:964,t:1527268190907};\\\", \\\"{x:1468,y:963,t:1527268190926};\\\", \\\"{x:1466,y:963,t:1527268190942};\\\", \\\"{x:1464,y:962,t:1527268190958};\\\", \\\"{x:1463,y:962,t:1527268190973};\\\", \\\"{x:1462,y:962,t:1527268190989};\\\", \\\"{x:1458,y:960,t:1527268191006};\\\", \\\"{x:1457,y:960,t:1527268191022};\\\", \\\"{x:1455,y:960,t:1527268191039};\\\", \\\"{x:1452,y:959,t:1527268191056};\\\", \\\"{x:1446,y:959,t:1527268191073};\\\", \\\"{x:1441,y:958,t:1527268191089};\\\", \\\"{x:1436,y:958,t:1527268191106};\\\", \\\"{x:1430,y:958,t:1527268191123};\\\", \\\"{x:1423,y:958,t:1527268191139};\\\", \\\"{x:1416,y:958,t:1527268191156};\\\", \\\"{x:1409,y:957,t:1527268191173};\\\", \\\"{x:1405,y:957,t:1527268191189};\\\", \\\"{x:1401,y:957,t:1527268191206};\\\", \\\"{x:1397,y:957,t:1527268191222};\\\", \\\"{x:1394,y:957,t:1527268191239};\\\", \\\"{x:1389,y:956,t:1527268191256};\\\", \\\"{x:1379,y:955,t:1527268191273};\\\", \\\"{x:1373,y:954,t:1527268191289};\\\", \\\"{x:1366,y:954,t:1527268191306};\\\", \\\"{x:1360,y:954,t:1527268191323};\\\", \\\"{x:1352,y:953,t:1527268191340};\\\", \\\"{x:1346,y:953,t:1527268191356};\\\", \\\"{x:1339,y:953,t:1527268191373};\\\", \\\"{x:1335,y:952,t:1527268191389};\\\", \\\"{x:1334,y:952,t:1527268191407};\\\", \\\"{x:1334,y:950,t:1527268191703};\\\", \\\"{x:1334,y:948,t:1527268191710};\\\", \\\"{x:1334,y:944,t:1527268191723};\\\", \\\"{x:1334,y:937,t:1527268191740};\\\", \\\"{x:1334,y:930,t:1527268191756};\\\", \\\"{x:1334,y:928,t:1527268191773};\\\", \\\"{x:1334,y:927,t:1527268191790};\\\", \\\"{x:1334,y:926,t:1527268191870};\\\", \\\"{x:1334,y:924,t:1527268191878};\\\", \\\"{x:1334,y:922,t:1527268191890};\\\", \\\"{x:1334,y:920,t:1527268191906};\\\", \\\"{x:1334,y:919,t:1527268191923};\\\", \\\"{x:1336,y:915,t:1527268191940};\\\", \\\"{x:1336,y:912,t:1527268191956};\\\", \\\"{x:1336,y:909,t:1527268191972};\\\", \\\"{x:1340,y:903,t:1527268191990};\\\", \\\"{x:1344,y:899,t:1527268192007};\\\", \\\"{x:1345,y:897,t:1527268192040};\\\", \\\"{x:1346,y:897,t:1527268192334};\\\", \\\"{x:1346,y:901,t:1527268192342};\\\", \\\"{x:1347,y:908,t:1527268192357};\\\", \\\"{x:1349,y:923,t:1527268192374};\\\", \\\"{x:1349,y:941,t:1527268192390};\\\", \\\"{x:1349,y:954,t:1527268192407};\\\", \\\"{x:1352,y:964,t:1527268192424};\\\", \\\"{x:1352,y:966,t:1527268192440};\\\", \\\"{x:1352,y:967,t:1527268192583};\\\", \\\"{x:1352,y:968,t:1527268192727};\\\", \\\"{x:1354,y:969,t:1527268192740};\\\", \\\"{x:1355,y:969,t:1527268192758};\\\", \\\"{x:1357,y:969,t:1527268192775};\\\", \\\"{x:1362,y:969,t:1527268192790};\\\", \\\"{x:1365,y:968,t:1527268192808};\\\", \\\"{x:1366,y:968,t:1527268192895};\\\", \\\"{x:1367,y:968,t:1527268192919};\\\", \\\"{x:1368,y:968,t:1527268192927};\\\", \\\"{x:1369,y:968,t:1527268193015};\\\", \\\"{x:1370,y:968,t:1527268193031};\\\", \\\"{x:1371,y:968,t:1527268193055};\\\", \\\"{x:1372,y:968,t:1527268193111};\\\", \\\"{x:1373,y:968,t:1527268193134};\\\", \\\"{x:1374,y:968,t:1527268193166};\\\", \\\"{x:1375,y:968,t:1527268193182};\\\", \\\"{x:1376,y:968,t:1527268193206};\\\", \\\"{x:1378,y:968,t:1527268193237};\\\", \\\"{x:1379,y:968,t:1527268193246};\\\", \\\"{x:1381,y:968,t:1527268193257};\\\", \\\"{x:1384,y:968,t:1527268193273};\\\", \\\"{x:1389,y:968,t:1527268193291};\\\", \\\"{x:1392,y:968,t:1527268193306};\\\", \\\"{x:1393,y:968,t:1527268193324};\\\", \\\"{x:1394,y:968,t:1527268193358};\\\", \\\"{x:1398,y:968,t:1527268193374};\\\", \\\"{x:1400,y:968,t:1527268193391};\\\", \\\"{x:1401,y:968,t:1527268193414};\\\", \\\"{x:1402,y:968,t:1527268193430};\\\", \\\"{x:1403,y:968,t:1527268193441};\\\", \\\"{x:1405,y:968,t:1527268193458};\\\", \\\"{x:1407,y:968,t:1527268193474};\\\", \\\"{x:1409,y:967,t:1527268193490};\\\", \\\"{x:1411,y:967,t:1527268193508};\\\", \\\"{x:1413,y:967,t:1527268193523};\\\", \\\"{x:1415,y:965,t:1527268193541};\\\", \\\"{x:1416,y:965,t:1527268193558};\\\", \\\"{x:1417,y:965,t:1527268193574};\\\", \\\"{x:1418,y:964,t:1527268193591};\\\", \\\"{x:1420,y:964,t:1527268193608};\\\", \\\"{x:1421,y:964,t:1527268193624};\\\", \\\"{x:1423,y:962,t:1527268193641};\\\", \\\"{x:1426,y:962,t:1527268193658};\\\", \\\"{x:1427,y:962,t:1527268193759};\\\", \\\"{x:1429,y:962,t:1527268193775};\\\", \\\"{x:1427,y:962,t:1527268194166};\\\", \\\"{x:1425,y:962,t:1527268194183};\\\", \\\"{x:1424,y:962,t:1527268194191};\\\", \\\"{x:1421,y:965,t:1527268194209};\\\", \\\"{x:1416,y:966,t:1527268194226};\\\", \\\"{x:1410,y:966,t:1527268194241};\\\", \\\"{x:1403,y:966,t:1527268194258};\\\", \\\"{x:1393,y:964,t:1527268194275};\\\", \\\"{x:1387,y:963,t:1527268194291};\\\", \\\"{x:1385,y:963,t:1527268194308};\\\", \\\"{x:1384,y:963,t:1527268194455};\\\", \\\"{x:1383,y:963,t:1527268194463};\\\", \\\"{x:1382,y:963,t:1527268194478};\\\", \\\"{x:1380,y:963,t:1527268194492};\\\", \\\"{x:1377,y:963,t:1527268194508};\\\", \\\"{x:1376,y:963,t:1527268194526};\\\", \\\"{x:1373,y:963,t:1527268194541};\\\", \\\"{x:1370,y:963,t:1527268194557};\\\", \\\"{x:1369,y:963,t:1527268194630};\\\", \\\"{x:1368,y:963,t:1527268194653};\\\", \\\"{x:1367,y:963,t:1527268194662};\\\", \\\"{x:1365,y:963,t:1527268194686};\\\", \\\"{x:1364,y:963,t:1527268194702};\\\", \\\"{x:1363,y:963,t:1527268194726};\\\", \\\"{x:1362,y:963,t:1527268194758};\\\", \\\"{x:1361,y:963,t:1527268194775};\\\", \\\"{x:1360,y:963,t:1527268194797};\\\", \\\"{x:1358,y:963,t:1527268194808};\\\", \\\"{x:1357,y:963,t:1527268194824};\\\", \\\"{x:1356,y:963,t:1527268194983};\\\", \\\"{x:1355,y:963,t:1527268194999};\\\", \\\"{x:1354,y:963,t:1527268195014};\\\", \\\"{x:1352,y:963,t:1527268195025};\\\", \\\"{x:1351,y:963,t:1527268195054};\\\", \\\"{x:1350,y:963,t:1527268195070};\\\", \\\"{x:1348,y:963,t:1527268195079};\\\", \\\"{x:1346,y:963,t:1527268195092};\\\", \\\"{x:1341,y:963,t:1527268195109};\\\", \\\"{x:1336,y:963,t:1527268195126};\\\", \\\"{x:1331,y:965,t:1527268195142};\\\", \\\"{x:1330,y:965,t:1527268195159};\\\", \\\"{x:1329,y:964,t:1527268195527};\\\", \\\"{x:1330,y:957,t:1527268195542};\\\", \\\"{x:1331,y:952,t:1527268195560};\\\", \\\"{x:1332,y:949,t:1527268195576};\\\", \\\"{x:1332,y:947,t:1527268195593};\\\", \\\"{x:1332,y:946,t:1527268195610};\\\", \\\"{x:1335,y:941,t:1527268195626};\\\", \\\"{x:1337,y:933,t:1527268195643};\\\", \\\"{x:1339,y:927,t:1527268195660};\\\", \\\"{x:1342,y:921,t:1527268195677};\\\", \\\"{x:1344,y:916,t:1527268195692};\\\", \\\"{x:1345,y:913,t:1527268195708};\\\", \\\"{x:1346,y:912,t:1527268195726};\\\", \\\"{x:1347,y:910,t:1527268195742};\\\", \\\"{x:1347,y:908,t:1527268195759};\\\", \\\"{x:1349,y:906,t:1527268195776};\\\", \\\"{x:1349,y:905,t:1527268195792};\\\", \\\"{x:1349,y:904,t:1527268195809};\\\", \\\"{x:1349,y:903,t:1527268195826};\\\", \\\"{x:1349,y:902,t:1527268195846};\\\", \\\"{x:1350,y:901,t:1527268195876};\\\", \\\"{x:1352,y:901,t:1527268196512};\\\", \\\"{x:1353,y:900,t:1527268196526};\\\", \\\"{x:1355,y:900,t:1527268196544};\\\", \\\"{x:1356,y:899,t:1527268196662};\\\", \\\"{x:1357,y:898,t:1527268196702};\\\", \\\"{x:1358,y:898,t:1527268196710};\\\", \\\"{x:1360,y:898,t:1527268196726};\\\", \\\"{x:1364,y:895,t:1527268196743};\\\", \\\"{x:1366,y:894,t:1527268196761};\\\", \\\"{x:1373,y:890,t:1527268196776};\\\", \\\"{x:1378,y:886,t:1527268196793};\\\", \\\"{x:1380,y:885,t:1527268196810};\\\", \\\"{x:1382,y:884,t:1527268196826};\\\", \\\"{x:1386,y:882,t:1527268196843};\\\", \\\"{x:1390,y:879,t:1527268196860};\\\", \\\"{x:1390,y:877,t:1527268196912};\\\", \\\"{x:1390,y:875,t:1527268196926};\\\", \\\"{x:1392,y:873,t:1527268196944};\\\", \\\"{x:1393,y:866,t:1527268196960};\\\", \\\"{x:1397,y:839,t:1527268196976};\\\", \\\"{x:1398,y:830,t:1527268196993};\\\", \\\"{x:1395,y:829,t:1527268197351};\\\", \\\"{x:1388,y:829,t:1527268197361};\\\", \\\"{x:1372,y:834,t:1527268197378};\\\", \\\"{x:1364,y:838,t:1527268197394};\\\", \\\"{x:1358,y:841,t:1527268197410};\\\", \\\"{x:1356,y:841,t:1527268197427};\\\", \\\"{x:1356,y:842,t:1527268197444};\\\", \\\"{x:1355,y:842,t:1527268197495};\\\", \\\"{x:1353,y:842,t:1527268197510};\\\", \\\"{x:1352,y:842,t:1527268197527};\\\", \\\"{x:1351,y:843,t:1527268197550};\\\", \\\"{x:1351,y:844,t:1527268197559};\\\", \\\"{x:1351,y:843,t:1527268197806};\\\", \\\"{x:1351,y:837,t:1527268197815};\\\", \\\"{x:1354,y:830,t:1527268197828};\\\", \\\"{x:1355,y:823,t:1527268197845};\\\", \\\"{x:1359,y:817,t:1527268197861};\\\", \\\"{x:1360,y:814,t:1527268197878};\\\", \\\"{x:1360,y:813,t:1527268197934};\\\", \\\"{x:1360,y:814,t:1527268198071};\\\", \\\"{x:1358,y:820,t:1527268198079};\\\", \\\"{x:1347,y:827,t:1527268198094};\\\", \\\"{x:1337,y:832,t:1527268198110};\\\", \\\"{x:1332,y:835,t:1527268198127};\\\", \\\"{x:1330,y:836,t:1527268198143};\\\", \\\"{x:1330,y:833,t:1527268198351};\\\", \\\"{x:1335,y:828,t:1527268198362};\\\", \\\"{x:1345,y:819,t:1527268198377};\\\", \\\"{x:1355,y:811,t:1527268198395};\\\", \\\"{x:1363,y:806,t:1527268198412};\\\", \\\"{x:1368,y:802,t:1527268198427};\\\", \\\"{x:1372,y:799,t:1527268198445};\\\", \\\"{x:1373,y:798,t:1527268198487};\\\", \\\"{x:1374,y:798,t:1527268198502};\\\", \\\"{x:1375,y:796,t:1527268198510};\\\", \\\"{x:1378,y:795,t:1527268198527};\\\", \\\"{x:1378,y:794,t:1527268198544};\\\", \\\"{x:1379,y:793,t:1527268198561};\\\", \\\"{x:1381,y:792,t:1527268198606};\\\", \\\"{x:1382,y:792,t:1527268198622};\\\", \\\"{x:1383,y:791,t:1527268198629};\\\", \\\"{x:1383,y:789,t:1527268198644};\\\", \\\"{x:1386,y:787,t:1527268198662};\\\", \\\"{x:1387,y:785,t:1527268198677};\\\", \\\"{x:1388,y:784,t:1527268198694};\\\", \\\"{x:1388,y:782,t:1527268198712};\\\", \\\"{x:1389,y:778,t:1527268198728};\\\", \\\"{x:1390,y:772,t:1527268198744};\\\", \\\"{x:1391,y:764,t:1527268198762};\\\", \\\"{x:1392,y:762,t:1527268198779};\\\", \\\"{x:1393,y:761,t:1527268198794};\\\", \\\"{x:1393,y:760,t:1527268199263};\\\", \\\"{x:1391,y:761,t:1527268199279};\\\", \\\"{x:1390,y:761,t:1527268199319};\\\", \\\"{x:1389,y:761,t:1527268200823};\\\", \\\"{x:1385,y:759,t:1527268200831};\\\", \\\"{x:1379,y:745,t:1527268200846};\\\", \\\"{x:1376,y:724,t:1527268200862};\\\", \\\"{x:1373,y:702,t:1527268200879};\\\", \\\"{x:1369,y:685,t:1527268200896};\\\", \\\"{x:1369,y:674,t:1527268200912};\\\", \\\"{x:1369,y:665,t:1527268200929};\\\", \\\"{x:1368,y:657,t:1527268200946};\\\", \\\"{x:1368,y:648,t:1527268200962};\\\", \\\"{x:1368,y:643,t:1527268200979};\\\", \\\"{x:1368,y:637,t:1527268200996};\\\", \\\"{x:1367,y:633,t:1527268201012};\\\", \\\"{x:1366,y:631,t:1527268201029};\\\", \\\"{x:1365,y:631,t:1527268201062};\\\", \\\"{x:1362,y:629,t:1527268201080};\\\", \\\"{x:1357,y:629,t:1527268201096};\\\", \\\"{x:1351,y:629,t:1527268201113};\\\", \\\"{x:1346,y:628,t:1527268201130};\\\", \\\"{x:1344,y:628,t:1527268201150};\\\", \\\"{x:1343,y:627,t:1527268201183};\\\", \\\"{x:1341,y:627,t:1527268201199};\\\", \\\"{x:1340,y:626,t:1527268201213};\\\", \\\"{x:1339,y:626,t:1527268201230};\\\", \\\"{x:1338,y:626,t:1527268201247};\\\", \\\"{x:1337,y:626,t:1527268201263};\\\", \\\"{x:1336,y:626,t:1527268201310};\\\", \\\"{x:1335,y:626,t:1527268201318};\\\", \\\"{x:1334,y:626,t:1527268201329};\\\", \\\"{x:1330,y:626,t:1527268201347};\\\", \\\"{x:1327,y:626,t:1527268201363};\\\", \\\"{x:1325,y:626,t:1527268201380};\\\", \\\"{x:1320,y:628,t:1527268201397};\\\", \\\"{x:1315,y:630,t:1527268201413};\\\", \\\"{x:1312,y:631,t:1527268201429};\\\", \\\"{x:1311,y:632,t:1527268201446};\\\", \\\"{x:1310,y:632,t:1527268201823};\\\", \\\"{x:1310,y:633,t:1527268201830};\\\", \\\"{x:1308,y:633,t:1527268201847};\\\", \\\"{x:1308,y:635,t:1527268202343};\\\", \\\"{x:1309,y:636,t:1527268202351};\\\", \\\"{x:1312,y:637,t:1527268202364};\\\", \\\"{x:1316,y:639,t:1527268202381};\\\", \\\"{x:1323,y:643,t:1527268202397};\\\", \\\"{x:1330,y:649,t:1527268202414};\\\", \\\"{x:1342,y:657,t:1527268202430};\\\", \\\"{x:1349,y:663,t:1527268202448};\\\", \\\"{x:1354,y:667,t:1527268202463};\\\", \\\"{x:1361,y:671,t:1527268202480};\\\", \\\"{x:1372,y:677,t:1527268202496};\\\", \\\"{x:1380,y:681,t:1527268202514};\\\", \\\"{x:1394,y:688,t:1527268202531};\\\", \\\"{x:1407,y:694,t:1527268202548};\\\", \\\"{x:1422,y:700,t:1527268202564};\\\", \\\"{x:1429,y:703,t:1527268202580};\\\", \\\"{x:1439,y:707,t:1527268202597};\\\", \\\"{x:1456,y:715,t:1527268202614};\\\", \\\"{x:1482,y:728,t:1527268202631};\\\", \\\"{x:1507,y:740,t:1527268202648};\\\", \\\"{x:1528,y:746,t:1527268202663};\\\", \\\"{x:1551,y:752,t:1527268202681};\\\", \\\"{x:1567,y:755,t:1527268202698};\\\", \\\"{x:1575,y:756,t:1527268202713};\\\", \\\"{x:1578,y:756,t:1527268202730};\\\", \\\"{x:1580,y:756,t:1527268202747};\\\", \\\"{x:1581,y:756,t:1527268202774};\\\", \\\"{x:1582,y:756,t:1527268202797};\\\", \\\"{x:1584,y:756,t:1527268202822};\\\", \\\"{x:1585,y:757,t:1527268202837};\\\", \\\"{x:1587,y:759,t:1527268202847};\\\", \\\"{x:1591,y:760,t:1527268202864};\\\", \\\"{x:1597,y:763,t:1527268202880};\\\", \\\"{x:1599,y:764,t:1527268202897};\\\", \\\"{x:1601,y:766,t:1527268202913};\\\", \\\"{x:1604,y:766,t:1527268202930};\\\", \\\"{x:1605,y:766,t:1527268202948};\\\", \\\"{x:1606,y:766,t:1527268202964};\\\", \\\"{x:1607,y:766,t:1527268202981};\\\", \\\"{x:1609,y:766,t:1527268203037};\\\", \\\"{x:1611,y:766,t:1527268203047};\\\", \\\"{x:1615,y:767,t:1527268203064};\\\", \\\"{x:1618,y:767,t:1527268203080};\\\", \\\"{x:1620,y:767,t:1527268203098};\\\", \\\"{x:1622,y:767,t:1527268203114};\\\", \\\"{x:1627,y:768,t:1527268203130};\\\", \\\"{x:1632,y:769,t:1527268203147};\\\", \\\"{x:1637,y:769,t:1527268203165};\\\", \\\"{x:1639,y:770,t:1527268203180};\\\", \\\"{x:1640,y:771,t:1527268203254};\\\", \\\"{x:1640,y:773,t:1527268203271};\\\", \\\"{x:1642,y:774,t:1527268203281};\\\", \\\"{x:1642,y:776,t:1527268203297};\\\", \\\"{x:1642,y:779,t:1527268203314};\\\", \\\"{x:1643,y:784,t:1527268203330};\\\", \\\"{x:1643,y:791,t:1527268203347};\\\", \\\"{x:1645,y:797,t:1527268203365};\\\", \\\"{x:1645,y:798,t:1527268203495};\\\", \\\"{x:1645,y:799,t:1527268203518};\\\", \\\"{x:1645,y:801,t:1527268203535};\\\", \\\"{x:1645,y:802,t:1527268203548};\\\", \\\"{x:1645,y:806,t:1527268203565};\\\", \\\"{x:1643,y:815,t:1527268203582};\\\", \\\"{x:1636,y:827,t:1527268203597};\\\", \\\"{x:1620,y:845,t:1527268203614};\\\", \\\"{x:1602,y:859,t:1527268203632};\\\", \\\"{x:1578,y:877,t:1527268203648};\\\", \\\"{x:1555,y:891,t:1527268203664};\\\", \\\"{x:1542,y:897,t:1527268203682};\\\", \\\"{x:1538,y:898,t:1527268203698};\\\", \\\"{x:1537,y:898,t:1527268203718};\\\", \\\"{x:1536,y:898,t:1527268203759};\\\", \\\"{x:1535,y:898,t:1527268203767};\\\", \\\"{x:1534,y:898,t:1527268203782};\\\", \\\"{x:1528,y:898,t:1527268203798};\\\", \\\"{x:1511,y:896,t:1527268203815};\\\", \\\"{x:1499,y:894,t:1527268203835};\\\", \\\"{x:1494,y:891,t:1527268203851};\\\", \\\"{x:1490,y:889,t:1527268203868};\\\", \\\"{x:1486,y:884,t:1527268203885};\\\", \\\"{x:1484,y:879,t:1527268203901};\\\", \\\"{x:1482,y:877,t:1527268203918};\\\", \\\"{x:1482,y:876,t:1527268203935};\\\", \\\"{x:1480,y:872,t:1527268203951};\\\", \\\"{x:1480,y:871,t:1527268203968};\\\", \\\"{x:1479,y:869,t:1527268203985};\\\", \\\"{x:1478,y:864,t:1527268204002};\\\", \\\"{x:1476,y:860,t:1527268204018};\\\", \\\"{x:1475,y:857,t:1527268204035};\\\", \\\"{x:1475,y:856,t:1527268204058};\\\", \\\"{x:1475,y:855,t:1527268204068};\\\", \\\"{x:1475,y:853,t:1527268204085};\\\", \\\"{x:1475,y:849,t:1527268204102};\\\", \\\"{x:1475,y:844,t:1527268204118};\\\", \\\"{x:1475,y:838,t:1527268204135};\\\", \\\"{x:1475,y:837,t:1527268204152};\\\", \\\"{x:1474,y:835,t:1527268204168};\\\", \\\"{x:1474,y:834,t:1527268204570};\\\", \\\"{x:1474,y:832,t:1527268204585};\\\", \\\"{x:1474,y:830,t:1527268204602};\\\", \\\"{x:1475,y:828,t:1527268204619};\\\", \\\"{x:1476,y:827,t:1527268204642};\\\", \\\"{x:1476,y:826,t:1527268205130};\\\", \\\"{x:1476,y:825,t:1527268205138};\\\", \\\"{x:1476,y:824,t:1527268205176};\\\", \\\"{x:1476,y:823,t:1527268205184};\\\", \\\"{x:1476,y:819,t:1527268205202};\\\", \\\"{x:1476,y:817,t:1527268205218};\\\", \\\"{x:1476,y:816,t:1527268205236};\\\", \\\"{x:1476,y:812,t:1527268205251};\\\", \\\"{x:1476,y:810,t:1527268205274};\\\", \\\"{x:1476,y:809,t:1527268205286};\\\", \\\"{x:1476,y:808,t:1527268205301};\\\", \\\"{x:1476,y:806,t:1527268205319};\\\", \\\"{x:1476,y:805,t:1527268205336};\\\", \\\"{x:1476,y:802,t:1527268205352};\\\", \\\"{x:1476,y:795,t:1527268205369};\\\", \\\"{x:1476,y:794,t:1527268205409};\\\", \\\"{x:1476,y:793,t:1527268205434};\\\", \\\"{x:1476,y:791,t:1527268205449};\\\", \\\"{x:1476,y:789,t:1527268205457};\\\", \\\"{x:1476,y:788,t:1527268205469};\\\", \\\"{x:1476,y:781,t:1527268205486};\\\", \\\"{x:1476,y:779,t:1527268205501};\\\", \\\"{x:1476,y:778,t:1527268205519};\\\", \\\"{x:1476,y:777,t:1527268205617};\\\", \\\"{x:1476,y:776,t:1527268205722};\\\", \\\"{x:1476,y:775,t:1527268205736};\\\", \\\"{x:1476,y:773,t:1527268205753};\\\", \\\"{x:1476,y:771,t:1527268205769};\\\", \\\"{x:1476,y:770,t:1527268205786};\\\", \\\"{x:1476,y:769,t:1527268205808};\\\", \\\"{x:1476,y:768,t:1527268205819};\\\", \\\"{x:1476,y:766,t:1527268205865};\\\", \\\"{x:1476,y:765,t:1527268205881};\\\", \\\"{x:1476,y:762,t:1527268205897};\\\", \\\"{x:1475,y:759,t:1527268205905};\\\", \\\"{x:1475,y:758,t:1527268206195};\\\", \\\"{x:1475,y:756,t:1527268206203};\\\", \\\"{x:1475,y:752,t:1527268206219};\\\", \\\"{x:1475,y:751,t:1527268206236};\\\", \\\"{x:1475,y:754,t:1527268206458};\\\", \\\"{x:1476,y:761,t:1527268206470};\\\", \\\"{x:1477,y:770,t:1527268206487};\\\", \\\"{x:1478,y:782,t:1527268206506};\\\", \\\"{x:1478,y:783,t:1527268206521};\\\", \\\"{x:1479,y:789,t:1527268206536};\\\", \\\"{x:1480,y:792,t:1527268206554};\\\", \\\"{x:1480,y:795,t:1527268206570};\\\", \\\"{x:1481,y:800,t:1527268206586};\\\", \\\"{x:1482,y:809,t:1527268206604};\\\", \\\"{x:1485,y:817,t:1527268206621};\\\", \\\"{x:1487,y:822,t:1527268206636};\\\", \\\"{x:1487,y:823,t:1527268206653};\\\", \\\"{x:1488,y:823,t:1527268206671};\\\", \\\"{x:1488,y:824,t:1527268206686};\\\", \\\"{x:1489,y:826,t:1527268206720};\\\", \\\"{x:1489,y:828,t:1527268206737};\\\", \\\"{x:1489,y:832,t:1527268206753};\\\", \\\"{x:1489,y:834,t:1527268206769};\\\", \\\"{x:1490,y:836,t:1527268206787};\\\", \\\"{x:1490,y:837,t:1527268206802};\\\", \\\"{x:1490,y:838,t:1527268206857};\\\", \\\"{x:1490,y:840,t:1527268206870};\\\", \\\"{x:1490,y:842,t:1527268206887};\\\", \\\"{x:1490,y:848,t:1527268206903};\\\", \\\"{x:1490,y:852,t:1527268206920};\\\", \\\"{x:1490,y:859,t:1527268206936};\\\", \\\"{x:1490,y:867,t:1527268206953};\\\", \\\"{x:1490,y:873,t:1527268206970};\\\", \\\"{x:1490,y:880,t:1527268206987};\\\", \\\"{x:1491,y:892,t:1527268207003};\\\", \\\"{x:1494,y:909,t:1527268207020};\\\", \\\"{x:1495,y:926,t:1527268207037};\\\", \\\"{x:1495,y:940,t:1527268207053};\\\", \\\"{x:1495,y:949,t:1527268207070};\\\", \\\"{x:1495,y:958,t:1527268207087};\\\", \\\"{x:1495,y:962,t:1527268207103};\\\", \\\"{x:1495,y:963,t:1527268207442};\\\", \\\"{x:1495,y:959,t:1527268207786};\\\", \\\"{x:1493,y:945,t:1527268207804};\\\", \\\"{x:1491,y:930,t:1527268207821};\\\", \\\"{x:1487,y:916,t:1527268207837};\\\", \\\"{x:1484,y:910,t:1527268207855};\\\", \\\"{x:1483,y:902,t:1527268207872};\\\", \\\"{x:1480,y:893,t:1527268207887};\\\", \\\"{x:1479,y:887,t:1527268207904};\\\", \\\"{x:1478,y:882,t:1527268207921};\\\", \\\"{x:1478,y:878,t:1527268207937};\\\", \\\"{x:1475,y:871,t:1527268207954};\\\", \\\"{x:1475,y:869,t:1527268207971};\\\", \\\"{x:1474,y:860,t:1527268207987};\\\", \\\"{x:1474,y:854,t:1527268208004};\\\", \\\"{x:1474,y:852,t:1527268208021};\\\", \\\"{x:1474,y:849,t:1527268208037};\\\", \\\"{x:1474,y:848,t:1527268208055};\\\", \\\"{x:1474,y:842,t:1527268208071};\\\", \\\"{x:1474,y:837,t:1527268208087};\\\", \\\"{x:1474,y:836,t:1527268208104};\\\", \\\"{x:1473,y:833,t:1527268208122};\\\", \\\"{x:1472,y:831,t:1527268208138};\\\", \\\"{x:1472,y:830,t:1527268208154};\\\", \\\"{x:1472,y:828,t:1527268208172};\\\", \\\"{x:1473,y:841,t:1527268208634};\\\", \\\"{x:1478,y:863,t:1527268208642};\\\", \\\"{x:1479,y:881,t:1527268208654};\\\", \\\"{x:1484,y:910,t:1527268208671};\\\", \\\"{x:1486,y:929,t:1527268208688};\\\", \\\"{x:1489,y:945,t:1527268208704};\\\", \\\"{x:1492,y:961,t:1527268208721};\\\", \\\"{x:1492,y:963,t:1527268208739};\\\", \\\"{x:1492,y:967,t:1527268208754};\\\", \\\"{x:1494,y:974,t:1527268208772};\\\", \\\"{x:1496,y:988,t:1527268208789};\\\", \\\"{x:1498,y:995,t:1527268208805};\\\", \\\"{x:1498,y:996,t:1527268208821};\\\", \\\"{x:1498,y:994,t:1527268208954};\\\", \\\"{x:1498,y:990,t:1527268208961};\\\", \\\"{x:1496,y:984,t:1527268208972};\\\", \\\"{x:1492,y:969,t:1527268208988};\\\", \\\"{x:1485,y:953,t:1527268209006};\\\", \\\"{x:1481,y:939,t:1527268209022};\\\", \\\"{x:1477,y:928,t:1527268209038};\\\", \\\"{x:1475,y:917,t:1527268209055};\\\", \\\"{x:1475,y:909,t:1527268209071};\\\", \\\"{x:1473,y:897,t:1527268209088};\\\", \\\"{x:1473,y:879,t:1527268209106};\\\", \\\"{x:1473,y:869,t:1527268209122};\\\", \\\"{x:1474,y:861,t:1527268209138};\\\", \\\"{x:1476,y:851,t:1527268209155};\\\", \\\"{x:1476,y:849,t:1527268209171};\\\", \\\"{x:1476,y:845,t:1527268209188};\\\", \\\"{x:1476,y:832,t:1527268209205};\\\", \\\"{x:1476,y:829,t:1527268209221};\\\", \\\"{x:1477,y:825,t:1527268209239};\\\", \\\"{x:1477,y:824,t:1527268209256};\\\", \\\"{x:1478,y:823,t:1527268211418};\\\", \\\"{x:1478,y:824,t:1527268211425};\\\", \\\"{x:1478,y:828,t:1527268211439};\\\", \\\"{x:1479,y:834,t:1527268211456};\\\", \\\"{x:1480,y:835,t:1527268211473};\\\", \\\"{x:1480,y:836,t:1527268215459};\\\", \\\"{x:1480,y:838,t:1527268215522};\\\", \\\"{x:1482,y:852,t:1527268215530};\\\", \\\"{x:1489,y:867,t:1527268215543};\\\", \\\"{x:1504,y:890,t:1527268215560};\\\", \\\"{x:1512,y:910,t:1527268215576};\\\", \\\"{x:1522,y:925,t:1527268215593};\\\", \\\"{x:1530,y:938,t:1527268215610};\\\", \\\"{x:1532,y:945,t:1527268215626};\\\", \\\"{x:1540,y:962,t:1527268215643};\\\", \\\"{x:1548,y:993,t:1527268215659};\\\", \\\"{x:1562,y:1058,t:1527268215677};\\\", \\\"{x:1568,y:1111,t:1527268215693};\\\", \\\"{x:1573,y:1166,t:1527268215709};\\\", \\\"{x:1577,y:1181,t:1527268215727};\\\", \\\"{x:1577,y:1179,t:1527268215801};\\\", \\\"{x:1576,y:1178,t:1527268215809};\\\", \\\"{x:1573,y:1174,t:1527268215826};\\\", \\\"{x:1566,y:1168,t:1527268215842};\\\", \\\"{x:1551,y:1157,t:1527268215859};\\\", \\\"{x:1528,y:1143,t:1527268215876};\\\", \\\"{x:1491,y:1126,t:1527268215892};\\\", \\\"{x:1459,y:1113,t:1527268215909};\\\", \\\"{x:1436,y:1104,t:1527268215926};\\\", \\\"{x:1418,y:1099,t:1527268215942};\\\", \\\"{x:1409,y:1096,t:1527268215959};\\\", \\\"{x:1409,y:1094,t:1527268216066};\\\", \\\"{x:1409,y:1093,t:1527268216077};\\\", \\\"{x:1408,y:1088,t:1527268216093};\\\", \\\"{x:1408,y:1084,t:1527268216110};\\\", \\\"{x:1408,y:1081,t:1527268216127};\\\", \\\"{x:1408,y:1078,t:1527268216142};\\\", \\\"{x:1408,y:1076,t:1527268216160};\\\", \\\"{x:1408,y:1073,t:1527268216176};\\\", \\\"{x:1408,y:1072,t:1527268216192};\\\", \\\"{x:1408,y:1070,t:1527268216225};\\\", \\\"{x:1408,y:1067,t:1527268216244};\\\", \\\"{x:1408,y:1065,t:1527268216260};\\\", \\\"{x:1408,y:1063,t:1527268216276};\\\", \\\"{x:1409,y:1062,t:1527268216293};\\\", \\\"{x:1410,y:1058,t:1527268216309};\\\", \\\"{x:1410,y:1056,t:1527268216326};\\\", \\\"{x:1412,y:1054,t:1527268216343};\\\", \\\"{x:1414,y:1050,t:1527268216359};\\\", \\\"{x:1418,y:1045,t:1527268216376};\\\", \\\"{x:1419,y:1044,t:1527268216409};\\\", \\\"{x:1420,y:1044,t:1527268216434};\\\", \\\"{x:1420,y:1043,t:1527268216444};\\\", \\\"{x:1421,y:1041,t:1527268216460};\\\", \\\"{x:1426,y:1038,t:1527268216476};\\\", \\\"{x:1437,y:1032,t:1527268216494};\\\", \\\"{x:1449,y:1025,t:1527268216510};\\\", \\\"{x:1462,y:1019,t:1527268216526};\\\", \\\"{x:1472,y:1015,t:1527268216542};\\\", \\\"{x:1482,y:1008,t:1527268216559};\\\", \\\"{x:1491,y:1005,t:1527268216576};\\\", \\\"{x:1509,y:999,t:1527268216593};\\\", \\\"{x:1518,y:996,t:1527268216609};\\\", \\\"{x:1521,y:996,t:1527268216626};\\\", \\\"{x:1523,y:995,t:1527268216643};\\\", \\\"{x:1524,y:995,t:1527268216659};\\\", \\\"{x:1526,y:995,t:1527268216705};\\\", \\\"{x:1527,y:995,t:1527268216713};\\\", \\\"{x:1529,y:995,t:1527268216726};\\\", \\\"{x:1539,y:994,t:1527268216743};\\\", \\\"{x:1553,y:992,t:1527268216759};\\\", \\\"{x:1571,y:990,t:1527268216777};\\\", \\\"{x:1597,y:989,t:1527268216793};\\\", \\\"{x:1614,y:988,t:1527268216811};\\\", \\\"{x:1628,y:985,t:1527268216827};\\\", \\\"{x:1635,y:984,t:1527268216844};\\\", \\\"{x:1636,y:984,t:1527268216861};\\\", \\\"{x:1637,y:978,t:1527268217066};\\\", \\\"{x:1636,y:967,t:1527268217077};\\\", \\\"{x:1635,y:938,t:1527268217094};\\\", \\\"{x:1635,y:905,t:1527268217110};\\\", \\\"{x:1635,y:883,t:1527268217126};\\\", \\\"{x:1633,y:874,t:1527268217143};\\\", \\\"{x:1633,y:871,t:1527268217160};\\\", \\\"{x:1633,y:869,t:1527268217176};\\\", \\\"{x:1633,y:867,t:1527268217193};\\\", \\\"{x:1633,y:862,t:1527268217210};\\\", \\\"{x:1633,y:857,t:1527268217226};\\\", \\\"{x:1632,y:851,t:1527268217243};\\\", \\\"{x:1632,y:845,t:1527268217260};\\\", \\\"{x:1630,y:825,t:1527268217276};\\\", \\\"{x:1627,y:813,t:1527268217293};\\\", \\\"{x:1622,y:806,t:1527268217310};\\\", \\\"{x:1619,y:796,t:1527268217328};\\\", \\\"{x:1618,y:783,t:1527268217343};\\\", \\\"{x:1618,y:759,t:1527268217361};\\\", \\\"{x:1618,y:705,t:1527268217377};\\\", \\\"{x:1620,y:631,t:1527268217393};\\\", \\\"{x:1626,y:587,t:1527268217411};\\\", \\\"{x:1629,y:561,t:1527268217428};\\\", \\\"{x:1632,y:540,t:1527268217443};\\\", \\\"{x:1632,y:523,t:1527268217460};\\\", \\\"{x:1630,y:510,t:1527268217477};\\\", \\\"{x:1630,y:504,t:1527268217493};\\\", \\\"{x:1630,y:496,t:1527268217510};\\\", \\\"{x:1630,y:493,t:1527268217528};\\\", \\\"{x:1630,y:487,t:1527268217543};\\\", \\\"{x:1630,y:486,t:1527268217560};\\\", \\\"{x:1630,y:485,t:1527268217578};\\\", \\\"{x:1629,y:485,t:1527268217642};\\\", \\\"{x:1627,y:485,t:1527268217650};\\\", \\\"{x:1625,y:485,t:1527268217665};\\\", \\\"{x:1624,y:485,t:1527268217737};\\\", \\\"{x:1620,y:482,t:1527268217794};\\\", \\\"{x:1615,y:478,t:1527268217811};\\\", \\\"{x:1611,y:478,t:1527268218138};\\\", \\\"{x:1600,y:478,t:1527268218146};\\\", \\\"{x:1589,y:479,t:1527268218161};\\\", \\\"{x:1508,y:507,t:1527268218177};\\\", \\\"{x:1422,y:534,t:1527268218195};\\\", \\\"{x:1293,y:579,t:1527268218211};\\\", \\\"{x:1130,y:628,t:1527268218228};\\\", \\\"{x:951,y:680,t:1527268218245};\\\", \\\"{x:791,y:718,t:1527268218261};\\\", \\\"{x:658,y:739,t:1527268218277};\\\", \\\"{x:558,y:751,t:1527268218294};\\\", \\\"{x:512,y:752,t:1527268218310};\\\", \\\"{x:503,y:752,t:1527268218327};\\\", \\\"{x:502,y:751,t:1527268218362};\\\", \\\"{x:500,y:750,t:1527268218377};\\\", \\\"{x:498,y:744,t:1527268218395};\\\", \\\"{x:493,y:740,t:1527268218412};\\\", \\\"{x:483,y:733,t:1527268218429};\\\", \\\"{x:472,y:726,t:1527268218444};\\\", \\\"{x:459,y:719,t:1527268218461};\\\", \\\"{x:428,y:702,t:1527268218483};\\\", \\\"{x:396,y:683,t:1527268218500};\\\", \\\"{x:374,y:665,t:1527268218516};\\\", \\\"{x:361,y:653,t:1527268218533};\\\", \\\"{x:351,y:638,t:1527268218550};\\\", \\\"{x:343,y:628,t:1527268218566};\\\", \\\"{x:336,y:618,t:1527268218584};\\\", \\\"{x:332,y:611,t:1527268218600};\\\", \\\"{x:325,y:605,t:1527268218616};\\\", \\\"{x:263,y:570,t:1527268218634};\\\", \\\"{x:177,y:533,t:1527268218651};\\\", \\\"{x:111,y:504,t:1527268218667};\\\", \\\"{x:84,y:492,t:1527268218683};\\\", \\\"{x:73,y:489,t:1527268218700};\\\", \\\"{x:71,y:489,t:1527268218717};\\\", \\\"{x:69,y:489,t:1527268218745};\\\", \\\"{x:67,y:491,t:1527268218752};\\\", \\\"{x:65,y:491,t:1527268218767};\\\", \\\"{x:64,y:492,t:1527268218783};\\\", \\\"{x:60,y:494,t:1527268218801};\\\", \\\"{x:54,y:496,t:1527268218816};\\\", \\\"{x:53,y:498,t:1527268218834};\\\", \\\"{x:53,y:506,t:1527268218852};\\\", \\\"{x:55,y:510,t:1527268218867};\\\", \\\"{x:59,y:513,t:1527268218883};\\\", \\\"{x:64,y:515,t:1527268218900};\\\", \\\"{x:76,y:521,t:1527268218918};\\\", \\\"{x:92,y:528,t:1527268218933};\\\", \\\"{x:98,y:533,t:1527268218950};\\\", \\\"{x:100,y:537,t:1527268218968};\\\", \\\"{x:100,y:541,t:1527268218983};\\\", \\\"{x:100,y:547,t:1527268219001};\\\", \\\"{x:100,y:556,t:1527268219016};\\\", \\\"{x:98,y:561,t:1527268219033};\\\", \\\"{x:96,y:566,t:1527268219050};\\\", \\\"{x:95,y:568,t:1527268219067};\\\", \\\"{x:95,y:569,t:1527268219083};\\\", \\\"{x:95,y:570,t:1527268219113};\\\", \\\"{x:95,y:571,t:1527268219137};\\\", \\\"{x:96,y:572,t:1527268219150};\\\", \\\"{x:101,y:575,t:1527268219168};\\\", \\\"{x:108,y:576,t:1527268219184};\\\", \\\"{x:112,y:578,t:1527268219200};\\\", \\\"{x:116,y:580,t:1527268219217};\\\", \\\"{x:116,y:581,t:1527268219234};\\\", \\\"{x:118,y:583,t:1527268219252};\\\", \\\"{x:125,y:590,t:1527268219267};\\\", \\\"{x:136,y:601,t:1527268219284};\\\", \\\"{x:144,y:610,t:1527268219300};\\\", \\\"{x:152,y:616,t:1527268219317};\\\", \\\"{x:158,y:619,t:1527268219334};\\\", \\\"{x:160,y:620,t:1527268219351};\\\", \\\"{x:161,y:621,t:1527268219546};\\\", \\\"{x:161,y:622,t:1527268219553};\\\", \\\"{x:161,y:623,t:1527268219568};\\\", \\\"{x:161,y:627,t:1527268219585};\\\", \\\"{x:161,y:628,t:1527268219600};\\\", \\\"{x:161,y:630,t:1527268219617};\\\", \\\"{x:161,y:629,t:1527268219761};\\\", \\\"{x:161,y:625,t:1527268219769};\\\", \\\"{x:162,y:622,t:1527268219784};\\\", \\\"{x:165,y:606,t:1527268219801};\\\", \\\"{x:169,y:595,t:1527268219817};\\\", \\\"{x:170,y:591,t:1527268219834};\\\", \\\"{x:170,y:590,t:1527268219851};\\\", \\\"{x:171,y:589,t:1527268219880};\\\", \\\"{x:171,y:585,t:1527268219896};\\\", \\\"{x:173,y:583,t:1527268219905};\\\", \\\"{x:174,y:580,t:1527268219917};\\\", \\\"{x:180,y:572,t:1527268219935};\\\", \\\"{x:198,y:562,t:1527268219951};\\\", \\\"{x:221,y:553,t:1527268219967};\\\", \\\"{x:244,y:548,t:1527268219984};\\\", \\\"{x:284,y:537,t:1527268220001};\\\", \\\"{x:311,y:529,t:1527268220018};\\\", \\\"{x:347,y:525,t:1527268220034};\\\", \\\"{x:375,y:521,t:1527268220051};\\\", \\\"{x:404,y:520,t:1527268220069};\\\", \\\"{x:426,y:520,t:1527268220084};\\\", \\\"{x:441,y:520,t:1527268220101};\\\", \\\"{x:448,y:520,t:1527268220118};\\\", \\\"{x:449,y:520,t:1527268220134};\\\", \\\"{x:450,y:520,t:1527268220151};\\\", \\\"{x:451,y:520,t:1527268220185};\\\", \\\"{x:461,y:520,t:1527268220201};\\\", \\\"{x:475,y:520,t:1527268220218};\\\", \\\"{x:483,y:520,t:1527268220234};\\\", \\\"{x:489,y:520,t:1527268220251};\\\", \\\"{x:493,y:520,t:1527268220268};\\\", \\\"{x:495,y:520,t:1527268220284};\\\", \\\"{x:496,y:520,t:1527268220302};\\\", \\\"{x:497,y:520,t:1527268220354};\\\", \\\"{x:499,y:520,t:1527268220370};\\\", \\\"{x:502,y:520,t:1527268220385};\\\", \\\"{x:517,y:520,t:1527268220401};\\\", \\\"{x:533,y:523,t:1527268220417};\\\", \\\"{x:555,y:525,t:1527268220434};\\\", \\\"{x:575,y:527,t:1527268220452};\\\", \\\"{x:590,y:527,t:1527268220468};\\\", \\\"{x:603,y:527,t:1527268220484};\\\", \\\"{x:616,y:527,t:1527268220501};\\\", \\\"{x:630,y:527,t:1527268220517};\\\", \\\"{x:644,y:527,t:1527268220536};\\\", \\\"{x:658,y:527,t:1527268220551};\\\", \\\"{x:669,y:527,t:1527268220568};\\\", \\\"{x:684,y:528,t:1527268220585};\\\", \\\"{x:691,y:528,t:1527268220601};\\\", \\\"{x:693,y:528,t:1527268220619};\\\", \\\"{x:694,y:528,t:1527268220706};\\\", \\\"{x:697,y:528,t:1527268220719};\\\", \\\"{x:707,y:528,t:1527268220736};\\\", \\\"{x:732,y:528,t:1527268220753};\\\", \\\"{x:762,y:528,t:1527268220768};\\\", \\\"{x:810,y:528,t:1527268220785};\\\", \\\"{x:827,y:528,t:1527268220803};\\\", \\\"{x:831,y:528,t:1527268220818};\\\", \\\"{x:831,y:529,t:1527268220937};\\\", \\\"{x:830,y:530,t:1527268220952};\\\", \\\"{x:821,y:533,t:1527268220969};\\\", \\\"{x:795,y:541,t:1527268220985};\\\", \\\"{x:774,y:548,t:1527268221003};\\\", \\\"{x:757,y:555,t:1527268221018};\\\", \\\"{x:732,y:561,t:1527268221035};\\\", \\\"{x:705,y:569,t:1527268221053};\\\", \\\"{x:684,y:575,t:1527268221069};\\\", \\\"{x:674,y:579,t:1527268221085};\\\", \\\"{x:672,y:579,t:1527268221138};\\\", \\\"{x:669,y:580,t:1527268221153};\\\", \\\"{x:660,y:585,t:1527268221170};\\\", \\\"{x:642,y:595,t:1527268221185};\\\", \\\"{x:626,y:605,t:1527268221201};\\\", \\\"{x:601,y:618,t:1527268221218};\\\", \\\"{x:577,y:628,t:1527268221236};\\\", \\\"{x:548,y:638,t:1527268221252};\\\", \\\"{x:523,y:646,t:1527268221269};\\\", \\\"{x:499,y:652,t:1527268221285};\\\", \\\"{x:484,y:653,t:1527268221303};\\\", \\\"{x:474,y:655,t:1527268221319};\\\", \\\"{x:471,y:655,t:1527268221335};\\\", \\\"{x:464,y:655,t:1527268221352};\\\", \\\"{x:447,y:657,t:1527268221368};\\\", \\\"{x:434,y:658,t:1527268221385};\\\", \\\"{x:428,y:658,t:1527268221402};\\\", \\\"{x:425,y:658,t:1527268221419};\\\", \\\"{x:424,y:658,t:1527268221457};\\\", \\\"{x:423,y:658,t:1527268221497};\\\", \\\"{x:422,y:658,t:1527268221601};\\\", \\\"{x:421,y:657,t:1527268221634};\\\", \\\"{x:420,y:657,t:1527268221641};\\\", \\\"{x:420,y:656,t:1527268221653};\\\", \\\"{x:415,y:654,t:1527268221670};\\\", \\\"{x:407,y:651,t:1527268221687};\\\", \\\"{x:405,y:650,t:1527268221703};\\\", \\\"{x:404,y:649,t:1527268221719};\\\", \\\"{x:402,y:648,t:1527268221735};\\\", \\\"{x:401,y:647,t:1527268221777};\\\", \\\"{x:401,y:646,t:1527268221793};\\\", \\\"{x:400,y:644,t:1527268221810};\\\", \\\"{x:400,y:643,t:1527268221820};\\\", \\\"{x:399,y:641,t:1527268221835};\\\", \\\"{x:399,y:640,t:1527268221852};\\\", \\\"{x:398,y:639,t:1527268221869};\\\", \\\"{x:398,y:638,t:1527268221886};\\\", \\\"{x:398,y:637,t:1527268221905};\\\", \\\"{x:398,y:634,t:1527268221920};\\\", \\\"{x:398,y:632,t:1527268221937};\\\", \\\"{x:404,y:627,t:1527268221952};\\\", \\\"{x:414,y:624,t:1527268221969};\\\", \\\"{x:426,y:618,t:1527268221987};\\\", \\\"{x:441,y:611,t:1527268222003};\\\", \\\"{x:457,y:605,t:1527268222019};\\\", \\\"{x:478,y:601,t:1527268222036};\\\", \\\"{x:497,y:599,t:1527268222052};\\\", \\\"{x:528,y:594,t:1527268222070};\\\", \\\"{x:599,y:591,t:1527268222087};\\\", \\\"{x:688,y:587,t:1527268222104};\\\", \\\"{x:780,y:587,t:1527268222120};\\\", \\\"{x:865,y:583,t:1527268222137};\\\", \\\"{x:881,y:580,t:1527268222153};\\\", \\\"{x:898,y:579,t:1527268222169};\\\", \\\"{x:897,y:579,t:1527268222313};\\\", \\\"{x:896,y:579,t:1527268222321};\\\", \\\"{x:893,y:579,t:1527268222335};\\\", \\\"{x:884,y:574,t:1527268222354};\\\", \\\"{x:871,y:565,t:1527268222369};\\\", \\\"{x:865,y:559,t:1527268222387};\\\", \\\"{x:862,y:557,t:1527268222404};\\\", \\\"{x:859,y:556,t:1527268222419};\\\", \\\"{x:856,y:558,t:1527268222554};\\\", \\\"{x:849,y:561,t:1527268222570};\\\", \\\"{x:845,y:562,t:1527268222587};\\\", \\\"{x:842,y:565,t:1527268222604};\\\", \\\"{x:839,y:567,t:1527268222620};\\\", \\\"{x:839,y:569,t:1527268222636};\\\", \\\"{x:839,y:577,t:1527268222655};\\\", \\\"{x:841,y:582,t:1527268222670};\\\", \\\"{x:842,y:585,t:1527268222687};\\\", \\\"{x:843,y:585,t:1527268222721};\\\", \\\"{x:842,y:587,t:1527268222760};\\\", \\\"{x:840,y:587,t:1527268222770};\\\", \\\"{x:837,y:589,t:1527268222786};\\\", \\\"{x:835,y:591,t:1527268222803};\\\", \\\"{x:834,y:591,t:1527268222820};\\\", \\\"{x:833,y:591,t:1527268222841};\\\", \\\"{x:833,y:592,t:1527268222854};\\\", \\\"{x:829,y:594,t:1527268223136};\\\", \\\"{x:795,y:613,t:1527268223155};\\\", \\\"{x:745,y:636,t:1527268223170};\\\", \\\"{x:674,y:661,t:1527268223186};\\\", \\\"{x:592,y:680,t:1527268223204};\\\", \\\"{x:505,y:695,t:1527268223221};\\\", \\\"{x:443,y:698,t:1527268223237};\\\", \\\"{x:395,y:698,t:1527268223254};\\\", \\\"{x:350,y:698,t:1527268223270};\\\", \\\"{x:308,y:698,t:1527268223288};\\\", \\\"{x:263,y:698,t:1527268223304};\\\", \\\"{x:198,y:699,t:1527268223321};\\\", \\\"{x:167,y:699,t:1527268223337};\\\", \\\"{x:142,y:699,t:1527268223353};\\\", \\\"{x:123,y:697,t:1527268223370};\\\", \\\"{x:107,y:696,t:1527268223387};\\\", \\\"{x:85,y:691,t:1527268223403};\\\", \\\"{x:59,y:685,t:1527268223420};\\\", \\\"{x:31,y:680,t:1527268223438};\\\", \\\"{x:12,y:678,t:1527268223453};\\\", \\\"{x:0,y:675,t:1527268223471};\\\", \\\"{x:0,y:672,t:1527268223497};\\\", \\\"{x:6,y:667,t:1527268223505};\\\", \\\"{x:22,y:659,t:1527268223521};\\\", \\\"{x:38,y:653,t:1527268223536};\\\", \\\"{x:43,y:648,t:1527268223554};\\\", \\\"{x:50,y:644,t:1527268223571};\\\", \\\"{x:56,y:641,t:1527268223587};\\\", \\\"{x:59,y:639,t:1527268223603};\\\", \\\"{x:61,y:638,t:1527268223641};\\\", \\\"{x:62,y:637,t:1527268223653};\\\", \\\"{x:65,y:637,t:1527268223670};\\\", \\\"{x:70,y:634,t:1527268223687};\\\", \\\"{x:75,y:634,t:1527268223704};\\\", \\\"{x:88,y:634,t:1527268223720};\\\", \\\"{x:99,y:634,t:1527268223737};\\\", \\\"{x:105,y:634,t:1527268223753};\\\", \\\"{x:109,y:634,t:1527268223770};\\\", \\\"{x:110,y:634,t:1527268223788};\\\", \\\"{x:112,y:634,t:1527268223803};\\\", \\\"{x:116,y:633,t:1527268223820};\\\", \\\"{x:119,y:633,t:1527268223837};\\\", \\\"{x:120,y:633,t:1527268223855};\\\", \\\"{x:122,y:632,t:1527268223870};\\\", \\\"{x:130,y:632,t:1527268223887};\\\", \\\"{x:147,y:632,t:1527268223905};\\\", \\\"{x:153,y:632,t:1527268223921};\\\", \\\"{x:154,y:632,t:1527268223976};\\\", \\\"{x:156,y:632,t:1527268224441};\\\", \\\"{x:160,y:632,t:1527268224454};\\\", \\\"{x:187,y:637,t:1527268224471};\\\", \\\"{x:240,y:651,t:1527268224488};\\\", \\\"{x:353,y:680,t:1527268224504};\\\", \\\"{x:422,y:698,t:1527268224522};\\\", \\\"{x:484,y:717,t:1527268224539};\\\", \\\"{x:516,y:725,t:1527268224555};\\\", \\\"{x:528,y:728,t:1527268224572};\\\", \\\"{x:531,y:730,t:1527268224588};\\\", \\\"{x:532,y:730,t:1527268224625};\\\", \\\"{x:533,y:730,t:1527268224639};\\\", \\\"{x:536,y:732,t:1527268224655};\\\", \\\"{x:537,y:733,t:1527268224672};\\\", \\\"{x:538,y:733,t:1527268224689};\\\", \\\"{x:541,y:733,t:1527268224704};\\\", \\\"{x:553,y:738,t:1527268224722};\\\", \\\"{x:565,y:741,t:1527268224739};\\\", \\\"{x:568,y:743,t:1527268224755};\\\", \\\"{x:566,y:743,t:1527268224833};\\\", \\\"{x:560,y:741,t:1527268224840};\\\", \\\"{x:557,y:739,t:1527268224856};\\\", \\\"{x:556,y:738,t:1527268224871};\\\", \\\"{x:555,y:737,t:1527268224889};\\\", \\\"{x:553,y:736,t:1527268224905};\\\", \\\"{x:550,y:733,t:1527268224922};\\\", \\\"{x:548,y:732,t:1527268224938};\\\" ] }, { \\\"rt\\\": 15680, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 277445, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:547,y:731,t:1527268228361};\\\", \\\"{x:538,y:726,t:1527268228377};\\\", \\\"{x:539,y:726,t:1527268228794};\\\", \\\"{x:540,y:726,t:1527268228801};\\\", \\\"{x:542,y:726,t:1527268228811};\\\", \\\"{x:546,y:724,t:1527268228828};\\\", \\\"{x:551,y:718,t:1527268228845};\\\", \\\"{x:565,y:712,t:1527268228862};\\\", \\\"{x:573,y:706,t:1527268228877};\\\", \\\"{x:580,y:700,t:1527268228894};\\\", \\\"{x:592,y:690,t:1527268228908};\\\", \\\"{x:609,y:671,t:1527268228925};\\\", \\\"{x:622,y:654,t:1527268228942};\\\", \\\"{x:636,y:641,t:1527268228958};\\\", \\\"{x:653,y:621,t:1527268228975};\\\", \\\"{x:671,y:603,t:1527268228992};\\\", \\\"{x:685,y:580,t:1527268229009};\\\", \\\"{x:687,y:574,t:1527268229024};\\\", \\\"{x:688,y:571,t:1527268229041};\\\", \\\"{x:689,y:569,t:1527268229059};\\\", \\\"{x:689,y:567,t:1527268229075};\\\", \\\"{x:689,y:564,t:1527268229091};\\\", \\\"{x:689,y:561,t:1527268229109};\\\", \\\"{x:689,y:559,t:1527268229125};\\\", \\\"{x:684,y:555,t:1527268229142};\\\", \\\"{x:679,y:552,t:1527268229158};\\\", \\\"{x:654,y:525,t:1527268229175};\\\", \\\"{x:631,y:515,t:1527268229192};\\\", \\\"{x:607,y:509,t:1527268229208};\\\", \\\"{x:594,y:505,t:1527268229224};\\\", \\\"{x:587,y:503,t:1527268229242};\\\", \\\"{x:583,y:502,t:1527268229259};\\\", \\\"{x:582,y:502,t:1527268229275};\\\", \\\"{x:581,y:502,t:1527268229338};\\\", \\\"{x:580,y:502,t:1527268229361};\\\", \\\"{x:579,y:502,t:1527268229375};\\\", \\\"{x:577,y:502,t:1527268229391};\\\", \\\"{x:576,y:502,t:1527268229409};\\\", \\\"{x:575,y:502,t:1527268229432};\\\", \\\"{x:574,y:502,t:1527268229490};\\\", \\\"{x:573,y:502,t:1527268229497};\\\", \\\"{x:570,y:502,t:1527268229509};\\\", \\\"{x:566,y:502,t:1527268229526};\\\", \\\"{x:558,y:503,t:1527268229543};\\\", \\\"{x:541,y:507,t:1527268229559};\\\", \\\"{x:521,y:511,t:1527268229576};\\\", \\\"{x:500,y:514,t:1527268229592};\\\", \\\"{x:465,y:521,t:1527268229611};\\\", \\\"{x:453,y:523,t:1527268229626};\\\", \\\"{x:447,y:523,t:1527268229641};\\\", \\\"{x:446,y:523,t:1527268229658};\\\", \\\"{x:446,y:524,t:1527268230169};\\\", \\\"{x:448,y:523,t:1527268230784};\\\", \\\"{x:450,y:522,t:1527268230792};\\\", \\\"{x:451,y:521,t:1527268230805};\\\", \\\"{x:454,y:521,t:1527268230823};\\\", \\\"{x:461,y:521,t:1527268230838};\\\", \\\"{x:469,y:521,t:1527268230855};\\\", \\\"{x:475,y:521,t:1527268230872};\\\", \\\"{x:485,y:521,t:1527268230888};\\\", \\\"{x:494,y:522,t:1527268230905};\\\", \\\"{x:495,y:522,t:1527268230922};\\\", \\\"{x:496,y:522,t:1527268231273};\\\", \\\"{x:496,y:521,t:1527268231474};\\\", \\\"{x:505,y:519,t:1527268231489};\\\", \\\"{x:617,y:524,t:1527268231504};\\\", \\\"{x:682,y:528,t:1527268231527};\\\", \\\"{x:755,y:529,t:1527268231544};\\\", \\\"{x:814,y:531,t:1527268231560};\\\", \\\"{x:868,y:531,t:1527268231577};\\\", \\\"{x:887,y:531,t:1527268231594};\\\", \\\"{x:901,y:531,t:1527268231610};\\\", \\\"{x:907,y:531,t:1527268231627};\\\", \\\"{x:908,y:531,t:1527268231656};\\\", \\\"{x:910,y:531,t:1527268231665};\\\", \\\"{x:916,y:531,t:1527268231676};\\\", \\\"{x:967,y:526,t:1527268231694};\\\", \\\"{x:1074,y:518,t:1527268231710};\\\", \\\"{x:1164,y:514,t:1527268231727};\\\", \\\"{x:1232,y:511,t:1527268231744};\\\", \\\"{x:1284,y:510,t:1527268231761};\\\", \\\"{x:1306,y:510,t:1527268231778};\\\", \\\"{x:1334,y:509,t:1527268231794};\\\", \\\"{x:1363,y:509,t:1527268231812};\\\", \\\"{x:1387,y:509,t:1527268231828};\\\", \\\"{x:1406,y:508,t:1527268231844};\\\", \\\"{x:1418,y:506,t:1527268231860};\\\", \\\"{x:1422,y:506,t:1527268231878};\\\", \\\"{x:1423,y:506,t:1527268231897};\\\", \\\"{x:1421,y:506,t:1527268232026};\\\", \\\"{x:1420,y:506,t:1527268232034};\\\", \\\"{x:1418,y:506,t:1527268232045};\\\", \\\"{x:1413,y:506,t:1527268232063};\\\", \\\"{x:1412,y:506,t:1527268232079};\\\", \\\"{x:1408,y:504,t:1527268232095};\\\", \\\"{x:1404,y:504,t:1527268232112};\\\", \\\"{x:1400,y:503,t:1527268232129};\\\", \\\"{x:1399,y:503,t:1527268232153};\\\", \\\"{x:1398,y:503,t:1527268232162};\\\", \\\"{x:1397,y:503,t:1527268232180};\\\", \\\"{x:1394,y:503,t:1527268232195};\\\", \\\"{x:1390,y:502,t:1527268232213};\\\", \\\"{x:1386,y:501,t:1527268232229};\\\", \\\"{x:1379,y:500,t:1527268232247};\\\", \\\"{x:1372,y:500,t:1527268232262};\\\", \\\"{x:1371,y:500,t:1527268232279};\\\", \\\"{x:1370,y:500,t:1527268232362};\\\", \\\"{x:1369,y:500,t:1527268232377};\\\", \\\"{x:1368,y:500,t:1527268232385};\\\", \\\"{x:1367,y:500,t:1527268232402};\\\", \\\"{x:1366,y:500,t:1527268232414};\\\", \\\"{x:1365,y:500,t:1527268232442};\\\", \\\"{x:1363,y:499,t:1527268232457};\\\", \\\"{x:1362,y:499,t:1527268232473};\\\", \\\"{x:1361,y:499,t:1527268232481};\\\", \\\"{x:1359,y:499,t:1527268232602};\\\", \\\"{x:1358,y:499,t:1527268232614};\\\", \\\"{x:1356,y:499,t:1527268232630};\\\", \\\"{x:1354,y:499,t:1527268232647};\\\", \\\"{x:1350,y:499,t:1527268232665};\\\", \\\"{x:1349,y:499,t:1527268232680};\\\", \\\"{x:1348,y:499,t:1527268232697};\\\", \\\"{x:1346,y:499,t:1527268232874};\\\", \\\"{x:1345,y:499,t:1527268232882};\\\", \\\"{x:1343,y:499,t:1527268232900};\\\", \\\"{x:1342,y:499,t:1527268232922};\\\", \\\"{x:1340,y:499,t:1527268232937};\\\", \\\"{x:1339,y:499,t:1527268232961};\\\", \\\"{x:1338,y:499,t:1527268232970};\\\", \\\"{x:1337,y:499,t:1527268232981};\\\", \\\"{x:1336,y:499,t:1527268233001};\\\", \\\"{x:1335,y:499,t:1527268233210};\\\", \\\"{x:1333,y:499,t:1527268233225};\\\", \\\"{x:1331,y:499,t:1527268233233};\\\", \\\"{x:1327,y:498,t:1527268233250};\\\", \\\"{x:1322,y:497,t:1527268233266};\\\", \\\"{x:1321,y:497,t:1527268233338};\\\", \\\"{x:1320,y:496,t:1527268233396};\\\", \\\"{x:1322,y:496,t:1527268237763};\\\", \\\"{x:1323,y:496,t:1527268237780};\\\", \\\"{x:1324,y:496,t:1527268237796};\\\", \\\"{x:1327,y:498,t:1527268237813};\\\", \\\"{x:1328,y:498,t:1527268237830};\\\", \\\"{x:1329,y:498,t:1527268237846};\\\", \\\"{x:1330,y:498,t:1527268237882};\\\", \\\"{x:1331,y:499,t:1527268237897};\\\", \\\"{x:1332,y:499,t:1527268237913};\\\", \\\"{x:1334,y:500,t:1527268237929};\\\", \\\"{x:1335,y:500,t:1527268237947};\\\", \\\"{x:1336,y:501,t:1527268237969};\\\", \\\"{x:1337,y:501,t:1527268237994};\\\", \\\"{x:1339,y:502,t:1527268238009};\\\", \\\"{x:1340,y:502,t:1527268238017};\\\", \\\"{x:1341,y:502,t:1527268238034};\\\", \\\"{x:1342,y:502,t:1527268238050};\\\", \\\"{x:1344,y:503,t:1527268238073};\\\", \\\"{x:1345,y:504,t:1527268238106};\\\", \\\"{x:1346,y:504,t:1527268238130};\\\", \\\"{x:1347,y:504,t:1527268238147};\\\", \\\"{x:1347,y:505,t:1527268238164};\\\", \\\"{x:1347,y:506,t:1527268239065};\\\", \\\"{x:1338,y:524,t:1527268239084};\\\", \\\"{x:1328,y:539,t:1527268239100};\\\", \\\"{x:1318,y:552,t:1527268239117};\\\", \\\"{x:1311,y:559,t:1527268239134};\\\", \\\"{x:1308,y:563,t:1527268239150};\\\", \\\"{x:1306,y:566,t:1527268239168};\\\", \\\"{x:1306,y:567,t:1527268239183};\\\", \\\"{x:1305,y:567,t:1527268239201};\\\", \\\"{x:1305,y:569,t:1527268239216};\\\", \\\"{x:1301,y:582,t:1527268239234};\\\", \\\"{x:1296,y:594,t:1527268239251};\\\", \\\"{x:1292,y:602,t:1527268239267};\\\", \\\"{x:1292,y:605,t:1527268239283};\\\", \\\"{x:1292,y:606,t:1527268239394};\\\", \\\"{x:1291,y:607,t:1527268239401};\\\", \\\"{x:1290,y:609,t:1527268239425};\\\", \\\"{x:1289,y:609,t:1527268239482};\\\", \\\"{x:1288,y:610,t:1527268239490};\\\", \\\"{x:1287,y:610,t:1527268239500};\\\", \\\"{x:1286,y:610,t:1527268239520};\\\", \\\"{x:1284,y:610,t:1527268239534};\\\", \\\"{x:1280,y:612,t:1527268239551};\\\", \\\"{x:1271,y:613,t:1527268239568};\\\", \\\"{x:1257,y:615,t:1527268239584};\\\", \\\"{x:1229,y:618,t:1527268239600};\\\", \\\"{x:1209,y:619,t:1527268239617};\\\", \\\"{x:1189,y:620,t:1527268239634};\\\", \\\"{x:1170,y:623,t:1527268239652};\\\", \\\"{x:1152,y:625,t:1527268239669};\\\", \\\"{x:1130,y:629,t:1527268239684};\\\", \\\"{x:1105,y:634,t:1527268239701};\\\", \\\"{x:1085,y:640,t:1527268239718};\\\", \\\"{x:1067,y:642,t:1527268239734};\\\", \\\"{x:1050,y:645,t:1527268239752};\\\", \\\"{x:1032,y:648,t:1527268239769};\\\", \\\"{x:1000,y:656,t:1527268239785};\\\", \\\"{x:977,y:658,t:1527268239802};\\\", \\\"{x:955,y:663,t:1527268239819};\\\", \\\"{x:937,y:664,t:1527268239835};\\\", \\\"{x:924,y:667,t:1527268239852};\\\", \\\"{x:914,y:668,t:1527268239868};\\\", \\\"{x:904,y:669,t:1527268239886};\\\", \\\"{x:893,y:671,t:1527268239902};\\\", \\\"{x:885,y:672,t:1527268239918};\\\", \\\"{x:877,y:673,t:1527268239936};\\\", \\\"{x:871,y:674,t:1527268239953};\\\", \\\"{x:865,y:675,t:1527268239969};\\\", \\\"{x:864,y:675,t:1527268239986};\\\", \\\"{x:863,y:675,t:1527268240002};\\\", \\\"{x:862,y:675,t:1527268240020};\\\", \\\"{x:861,y:675,t:1527268240074};\\\", \\\"{x:860,y:675,t:1527268240085};\\\", \\\"{x:858,y:675,t:1527268240103};\\\", \\\"{x:855,y:675,t:1527268240119};\\\", \\\"{x:851,y:675,t:1527268240136};\\\", \\\"{x:844,y:676,t:1527268240153};\\\", \\\"{x:834,y:679,t:1527268240170};\\\", \\\"{x:813,y:686,t:1527268240186};\\\", \\\"{x:792,y:690,t:1527268240203};\\\", \\\"{x:763,y:694,t:1527268240219};\\\", \\\"{x:735,y:697,t:1527268240236};\\\", \\\"{x:706,y:702,t:1527268240254};\\\", \\\"{x:683,y:703,t:1527268240269};\\\", \\\"{x:664,y:704,t:1527268240286};\\\", \\\"{x:651,y:705,t:1527268240303};\\\", \\\"{x:637,y:705,t:1527268240320};\\\", \\\"{x:629,y:705,t:1527268240336};\\\", \\\"{x:622,y:705,t:1527268240353};\\\", \\\"{x:614,y:703,t:1527268240370};\\\", \\\"{x:604,y:697,t:1527268240386};\\\", \\\"{x:595,y:689,t:1527268240404};\\\", \\\"{x:587,y:684,t:1527268240420};\\\", \\\"{x:580,y:677,t:1527268240438};\\\", \\\"{x:576,y:671,t:1527268240453};\\\", \\\"{x:575,y:668,t:1527268240470};\\\", \\\"{x:573,y:667,t:1527268240487};\\\", \\\"{x:573,y:665,t:1527268240504};\\\", \\\"{x:573,y:664,t:1527268240521};\\\", \\\"{x:573,y:658,t:1527268240537};\\\", \\\"{x:578,y:650,t:1527268240554};\\\", \\\"{x:584,y:646,t:1527268240567};\\\", \\\"{x:604,y:637,t:1527268240584};\\\", \\\"{x:618,y:630,t:1527268240601};\\\", \\\"{x:635,y:617,t:1527268240618};\\\", \\\"{x:654,y:605,t:1527268240634};\\\", \\\"{x:666,y:597,t:1527268240651};\\\", \\\"{x:670,y:593,t:1527268240667};\\\", \\\"{x:673,y:590,t:1527268240684};\\\", \\\"{x:675,y:588,t:1527268240702};\\\", \\\"{x:678,y:584,t:1527268240717};\\\", \\\"{x:686,y:579,t:1527268240734};\\\", \\\"{x:712,y:560,t:1527268240752};\\\", \\\"{x:738,y:543,t:1527268240767};\\\", \\\"{x:755,y:532,t:1527268240784};\\\", \\\"{x:757,y:532,t:1527268240848};\\\", \\\"{x:765,y:527,t:1527268240856};\\\", \\\"{x:771,y:525,t:1527268240867};\\\", \\\"{x:778,y:522,t:1527268240884};\\\", \\\"{x:778,y:521,t:1527268240953};\\\", \\\"{x:788,y:518,t:1527268240969};\\\", \\\"{x:793,y:515,t:1527268240984};\\\", \\\"{x:794,y:514,t:1527268241001};\\\", \\\"{x:797,y:513,t:1527268241105};\\\", \\\"{x:801,y:513,t:1527268241118};\\\", \\\"{x:809,y:513,t:1527268241134};\\\", \\\"{x:810,y:513,t:1527268241151};\\\", \\\"{x:811,y:514,t:1527268241201};\\\", \\\"{x:813,y:520,t:1527268241220};\\\", \\\"{x:814,y:525,t:1527268241234};\\\", \\\"{x:814,y:526,t:1527268241251};\\\", \\\"{x:816,y:527,t:1527268241361};\\\", \\\"{x:821,y:530,t:1527268241369};\\\", \\\"{x:828,y:532,t:1527268241385};\\\", \\\"{x:829,y:532,t:1527268241502};\\\", \\\"{x:830,y:533,t:1527268241518};\\\", \\\"{x:830,y:533,t:1527268241557};\\\", \\\"{x:830,y:535,t:1527268241585};\\\", \\\"{x:826,y:538,t:1527268241601};\\\", \\\"{x:819,y:546,t:1527268241619};\\\", \\\"{x:807,y:562,t:1527268241636};\\\", \\\"{x:780,y:590,t:1527268241651};\\\", \\\"{x:735,y:634,t:1527268241668};\\\", \\\"{x:692,y:676,t:1527268241685};\\\", \\\"{x:653,y:714,t:1527268241701};\\\", \\\"{x:631,y:730,t:1527268241718};\\\", \\\"{x:620,y:736,t:1527268241735};\\\", \\\"{x:614,y:739,t:1527268241752};\\\", \\\"{x:613,y:739,t:1527268241809};\\\", \\\"{x:609,y:740,t:1527268241824};\\\", \\\"{x:607,y:741,t:1527268241836};\\\", \\\"{x:603,y:743,t:1527268241852};\\\", \\\"{x:600,y:744,t:1527268241869};\\\", \\\"{x:598,y:744,t:1527268241885};\\\", \\\"{x:597,y:744,t:1527268241902};\\\", \\\"{x:594,y:744,t:1527268241919};\\\", \\\"{x:579,y:744,t:1527268241936};\\\", \\\"{x:545,y:746,t:1527268241954};\\\", \\\"{x:512,y:751,t:1527268241968};\\\", \\\"{x:493,y:751,t:1527268241985};\\\", \\\"{x:478,y:751,t:1527268242002};\\\", \\\"{x:468,y:749,t:1527268242018};\\\", \\\"{x:467,y:749,t:1527268242035};\\\", \\\"{x:467,y:748,t:1527268242225};\\\", \\\"{x:472,y:744,t:1527268242235};\\\", \\\"{x:480,y:740,t:1527268242252};\\\", \\\"{x:483,y:739,t:1527268242268};\\\", \\\"{x:485,y:737,t:1527268242285};\\\", \\\"{x:488,y:735,t:1527268242302};\\\", \\\"{x:491,y:734,t:1527268242319};\\\", \\\"{x:492,y:733,t:1527268242336};\\\" ] }, { \\\"rt\\\": 10422, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 289133, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:733,t:1527268244513};\\\", \\\"{x:496,y:732,t:1527268244523};\\\", \\\"{x:498,y:731,t:1527268244539};\\\", \\\"{x:499,y:730,t:1527268244594};\\\", \\\"{x:500,y:729,t:1527268244606};\\\", \\\"{x:504,y:729,t:1527268244623};\\\", \\\"{x:507,y:727,t:1527268244639};\\\", \\\"{x:510,y:726,t:1527268244655};\\\", \\\"{x:517,y:726,t:1527268244673};\\\", \\\"{x:523,y:726,t:1527268244689};\\\", \\\"{x:538,y:726,t:1527268244706};\\\", \\\"{x:560,y:726,t:1527268244723};\\\", \\\"{x:586,y:726,t:1527268244741};\\\", \\\"{x:613,y:726,t:1527268244755};\\\", \\\"{x:638,y:726,t:1527268244770};\\\", \\\"{x:665,y:726,t:1527268244787};\\\", \\\"{x:689,y:726,t:1527268244804};\\\", \\\"{x:710,y:726,t:1527268244820};\\\", \\\"{x:743,y:729,t:1527268244838};\\\", \\\"{x:776,y:731,t:1527268244854};\\\", \\\"{x:807,y:736,t:1527268244871};\\\", \\\"{x:831,y:739,t:1527268244888};\\\", \\\"{x:875,y:743,t:1527268244905};\\\", \\\"{x:902,y:748,t:1527268244921};\\\", \\\"{x:932,y:752,t:1527268244938};\\\", \\\"{x:959,y:755,t:1527268244954};\\\", \\\"{x:981,y:759,t:1527268244972};\\\", \\\"{x:1002,y:762,t:1527268244988};\\\", \\\"{x:1033,y:769,t:1527268245004};\\\", \\\"{x:1064,y:772,t:1527268245022};\\\", \\\"{x:1088,y:780,t:1527268245038};\\\", \\\"{x:1106,y:787,t:1527268245055};\\\", \\\"{x:1124,y:794,t:1527268245072};\\\", \\\"{x:1143,y:803,t:1527268245088};\\\", \\\"{x:1174,y:816,t:1527268245105};\\\", \\\"{x:1192,y:825,t:1527268245121};\\\", \\\"{x:1204,y:832,t:1527268245137};\\\", \\\"{x:1218,y:839,t:1527268245155};\\\", \\\"{x:1228,y:844,t:1527268245172};\\\", \\\"{x:1236,y:850,t:1527268245187};\\\", \\\"{x:1246,y:855,t:1527268245205};\\\", \\\"{x:1257,y:862,t:1527268245222};\\\", \\\"{x:1268,y:873,t:1527268245237};\\\", \\\"{x:1277,y:883,t:1527268245255};\\\", \\\"{x:1284,y:895,t:1527268245272};\\\", \\\"{x:1287,y:909,t:1527268245288};\\\", \\\"{x:1284,y:928,t:1527268245305};\\\", \\\"{x:1276,y:938,t:1527268245321};\\\", \\\"{x:1266,y:949,t:1527268245338};\\\", \\\"{x:1264,y:953,t:1527268245354};\\\", \\\"{x:1262,y:951,t:1527268245498};\\\", \\\"{x:1262,y:947,t:1527268245505};\\\", \\\"{x:1262,y:942,t:1527268245522};\\\", \\\"{x:1262,y:937,t:1527268245539};\\\", \\\"{x:1262,y:931,t:1527268245556};\\\", \\\"{x:1262,y:927,t:1527268245572};\\\", \\\"{x:1262,y:926,t:1527268245589};\\\", \\\"{x:1262,y:923,t:1527268245605};\\\", \\\"{x:1262,y:918,t:1527268245622};\\\", \\\"{x:1262,y:912,t:1527268245639};\\\", \\\"{x:1262,y:908,t:1527268245655};\\\", \\\"{x:1262,y:903,t:1527268245673};\\\", \\\"{x:1262,y:894,t:1527268245689};\\\", \\\"{x:1262,y:889,t:1527268245705};\\\", \\\"{x:1262,y:874,t:1527268245722};\\\", \\\"{x:1262,y:866,t:1527268245738};\\\", \\\"{x:1262,y:863,t:1527268245754};\\\", \\\"{x:1262,y:857,t:1527268245771};\\\", \\\"{x:1261,y:846,t:1527268245789};\\\", \\\"{x:1259,y:839,t:1527268245805};\\\", \\\"{x:1256,y:830,t:1527268245822};\\\", \\\"{x:1246,y:816,t:1527268245838};\\\", \\\"{x:1238,y:805,t:1527268245855};\\\", \\\"{x:1232,y:796,t:1527268245872};\\\", \\\"{x:1227,y:779,t:1527268245889};\\\", \\\"{x:1217,y:763,t:1527268245905};\\\", \\\"{x:1209,y:748,t:1527268245922};\\\", \\\"{x:1201,y:736,t:1527268245938};\\\", \\\"{x:1194,y:720,t:1527268245956};\\\", \\\"{x:1187,y:704,t:1527268245972};\\\", \\\"{x:1182,y:693,t:1527268245989};\\\", \\\"{x:1180,y:684,t:1527268246005};\\\", \\\"{x:1177,y:677,t:1527268246022};\\\", \\\"{x:1176,y:664,t:1527268246039};\\\", \\\"{x:1175,y:655,t:1527268246056};\\\", \\\"{x:1173,y:644,t:1527268246071};\\\", \\\"{x:1171,y:631,t:1527268246089};\\\", \\\"{x:1171,y:621,t:1527268246106};\\\", \\\"{x:1171,y:612,t:1527268246121};\\\", \\\"{x:1171,y:605,t:1527268246139};\\\", \\\"{x:1171,y:593,t:1527268246156};\\\", \\\"{x:1171,y:591,t:1527268246172};\\\", \\\"{x:1171,y:588,t:1527268246189};\\\", \\\"{x:1171,y:582,t:1527268246205};\\\", \\\"{x:1174,y:576,t:1527268246222};\\\", \\\"{x:1176,y:572,t:1527268246239};\\\", \\\"{x:1178,y:571,t:1527268246255};\\\", \\\"{x:1180,y:569,t:1527268246272};\\\", \\\"{x:1183,y:566,t:1527268246289};\\\", \\\"{x:1187,y:565,t:1527268246306};\\\", \\\"{x:1193,y:561,t:1527268246322};\\\", \\\"{x:1199,y:557,t:1527268246339};\\\", \\\"{x:1208,y:553,t:1527268246356};\\\", \\\"{x:1216,y:552,t:1527268246372};\\\", \\\"{x:1225,y:549,t:1527268246389};\\\", \\\"{x:1232,y:548,t:1527268246406};\\\", \\\"{x:1235,y:548,t:1527268246423};\\\", \\\"{x:1239,y:548,t:1527268246438};\\\", \\\"{x:1243,y:548,t:1527268246455};\\\", \\\"{x:1253,y:548,t:1527268246472};\\\", \\\"{x:1259,y:548,t:1527268246489};\\\", \\\"{x:1263,y:548,t:1527268246506};\\\", \\\"{x:1265,y:548,t:1527268246523};\\\", \\\"{x:1266,y:548,t:1527268246560};\\\", \\\"{x:1267,y:548,t:1527268246572};\\\", \\\"{x:1268,y:548,t:1527268246593};\\\", \\\"{x:1268,y:549,t:1527268246606};\\\", \\\"{x:1270,y:550,t:1527268246623};\\\", \\\"{x:1272,y:551,t:1527268246638};\\\", \\\"{x:1273,y:552,t:1527268246656};\\\", \\\"{x:1276,y:552,t:1527268246673};\\\", \\\"{x:1278,y:552,t:1527268246689};\\\", \\\"{x:1279,y:553,t:1527268246706};\\\", \\\"{x:1282,y:554,t:1527268246723};\\\", \\\"{x:1286,y:555,t:1527268246740};\\\", \\\"{x:1294,y:556,t:1527268246756};\\\", \\\"{x:1301,y:556,t:1527268246773};\\\", \\\"{x:1310,y:558,t:1527268246789};\\\", \\\"{x:1315,y:559,t:1527268246806};\\\", \\\"{x:1321,y:559,t:1527268246823};\\\", \\\"{x:1324,y:560,t:1527268246839};\\\", \\\"{x:1325,y:560,t:1527268246856};\\\", \\\"{x:1325,y:561,t:1527268246881};\\\", \\\"{x:1322,y:563,t:1527268247090};\\\", \\\"{x:1311,y:567,t:1527268247106};\\\", \\\"{x:1288,y:570,t:1527268247123};\\\", \\\"{x:1254,y:579,t:1527268247140};\\\", \\\"{x:1210,y:583,t:1527268247156};\\\", \\\"{x:1171,y:589,t:1527268247173};\\\", \\\"{x:1152,y:591,t:1527268247190};\\\", \\\"{x:1148,y:592,t:1527268247206};\\\", \\\"{x:1148,y:593,t:1527268247410};\\\", \\\"{x:1154,y:593,t:1527268247423};\\\", \\\"{x:1175,y:591,t:1527268247441};\\\", \\\"{x:1219,y:585,t:1527268247457};\\\", \\\"{x:1253,y:584,t:1527268247473};\\\", \\\"{x:1277,y:580,t:1527268247490};\\\", \\\"{x:1295,y:580,t:1527268247507};\\\", \\\"{x:1301,y:580,t:1527268247523};\\\", \\\"{x:1303,y:580,t:1527268247540};\\\", \\\"{x:1301,y:579,t:1527268247730};\\\", \\\"{x:1300,y:579,t:1527268247802};\\\", \\\"{x:1300,y:578,t:1527268247809};\\\", \\\"{x:1298,y:578,t:1527268247827};\\\", \\\"{x:1297,y:578,t:1527268247840};\\\", \\\"{x:1296,y:577,t:1527268247857};\\\", \\\"{x:1294,y:577,t:1527268247881};\\\", \\\"{x:1292,y:577,t:1527268248090};\\\", \\\"{x:1291,y:576,t:1527268248107};\\\", \\\"{x:1289,y:575,t:1527268248706};\\\", \\\"{x:1285,y:575,t:1527268248713};\\\", \\\"{x:1282,y:574,t:1527268248725};\\\", \\\"{x:1276,y:572,t:1527268248742};\\\", \\\"{x:1264,y:572,t:1527268248758};\\\", \\\"{x:1248,y:572,t:1527268248774};\\\", \\\"{x:1225,y:572,t:1527268248791};\\\", \\\"{x:1200,y:572,t:1527268248808};\\\", \\\"{x:1158,y:572,t:1527268248825};\\\", \\\"{x:1066,y:572,t:1527268248841};\\\", \\\"{x:996,y:572,t:1527268248857};\\\", \\\"{x:921,y:572,t:1527268248876};\\\", \\\"{x:863,y:572,t:1527268248891};\\\", \\\"{x:815,y:572,t:1527268248908};\\\", \\\"{x:731,y:572,t:1527268248941};\\\", \\\"{x:701,y:572,t:1527268248958};\\\", \\\"{x:674,y:572,t:1527268248973};\\\", \\\"{x:653,y:572,t:1527268248991};\\\", \\\"{x:635,y:572,t:1527268249008};\\\", \\\"{x:625,y:572,t:1527268249024};\\\", \\\"{x:622,y:572,t:1527268249040};\\\", \\\"{x:621,y:572,t:1527268249058};\\\", \\\"{x:619,y:572,t:1527268249075};\\\", \\\"{x:616,y:572,t:1527268249092};\\\", \\\"{x:607,y:572,t:1527268249107};\\\", \\\"{x:589,y:572,t:1527268249125};\\\", \\\"{x:563,y:572,t:1527268249142};\\\", \\\"{x:542,y:572,t:1527268249158};\\\", \\\"{x:521,y:572,t:1527268249175};\\\", \\\"{x:503,y:572,t:1527268249191};\\\", \\\"{x:478,y:572,t:1527268249209};\\\", \\\"{x:449,y:572,t:1527268249224};\\\", \\\"{x:435,y:572,t:1527268249241};\\\", \\\"{x:421,y:572,t:1527268249258};\\\", \\\"{x:408,y:572,t:1527268249275};\\\", \\\"{x:390,y:572,t:1527268249292};\\\", \\\"{x:368,y:572,t:1527268249308};\\\", \\\"{x:350,y:572,t:1527268249324};\\\", \\\"{x:345,y:571,t:1527268249341};\\\", \\\"{x:344,y:571,t:1527268249393};\\\", \\\"{x:349,y:566,t:1527268249408};\\\", \\\"{x:384,y:551,t:1527268249427};\\\", \\\"{x:406,y:541,t:1527268249441};\\\", \\\"{x:427,y:532,t:1527268249457};\\\", \\\"{x:450,y:526,t:1527268249475};\\\", \\\"{x:489,y:518,t:1527268249492};\\\", \\\"{x:552,y:515,t:1527268249508};\\\", \\\"{x:639,y:511,t:1527268249525};\\\", \\\"{x:690,y:509,t:1527268249542};\\\", \\\"{x:702,y:507,t:1527268249558};\\\", \\\"{x:701,y:507,t:1527268249584};\\\", \\\"{x:700,y:507,t:1527268249592};\\\", \\\"{x:698,y:509,t:1527268249608};\\\", \\\"{x:696,y:510,t:1527268249632};\\\", \\\"{x:695,y:510,t:1527268249642};\\\", \\\"{x:694,y:510,t:1527268249665};\\\", \\\"{x:693,y:512,t:1527268249738};\\\", \\\"{x:690,y:513,t:1527268249745};\\\", \\\"{x:688,y:513,t:1527268249758};\\\", \\\"{x:682,y:513,t:1527268249775};\\\", \\\"{x:680,y:513,t:1527268249792};\\\", \\\"{x:668,y:511,t:1527268249808};\\\", \\\"{x:660,y:510,t:1527268249826};\\\", \\\"{x:657,y:509,t:1527268249842};\\\", \\\"{x:655,y:508,t:1527268249946};\\\", \\\"{x:652,y:507,t:1527268249960};\\\", \\\"{x:639,y:504,t:1527268249976};\\\", \\\"{x:628,y:504,t:1527268249992};\\\", \\\"{x:615,y:504,t:1527268250008};\\\", \\\"{x:613,y:504,t:1527268250025};\\\", \\\"{x:610,y:504,t:1527268250417};\\\", \\\"{x:596,y:505,t:1527268250426};\\\", \\\"{x:541,y:531,t:1527268250442};\\\", \\\"{x:478,y:553,t:1527268250460};\\\", \\\"{x:424,y:566,t:1527268250477};\\\", \\\"{x:375,y:577,t:1527268250492};\\\", \\\"{x:325,y:581,t:1527268250509};\\\", \\\"{x:296,y:586,t:1527268250526};\\\", \\\"{x:281,y:589,t:1527268250542};\\\", \\\"{x:273,y:590,t:1527268250559};\\\", \\\"{x:267,y:591,t:1527268250577};\\\", \\\"{x:259,y:593,t:1527268250591};\\\", \\\"{x:240,y:596,t:1527268250610};\\\", \\\"{x:227,y:599,t:1527268250625};\\\", \\\"{x:220,y:599,t:1527268250641};\\\", \\\"{x:214,y:600,t:1527268250659};\\\", \\\"{x:203,y:601,t:1527268250677};\\\", \\\"{x:190,y:601,t:1527268250692};\\\", \\\"{x:175,y:604,t:1527268250709};\\\", \\\"{x:164,y:604,t:1527268250726};\\\", \\\"{x:157,y:604,t:1527268250743};\\\", \\\"{x:154,y:604,t:1527268250758};\\\", \\\"{x:153,y:607,t:1527268250890};\\\", \\\"{x:153,y:610,t:1527268250897};\\\", \\\"{x:152,y:612,t:1527268250908};\\\", \\\"{x:152,y:618,t:1527268250926};\\\", \\\"{x:150,y:621,t:1527268250943};\\\", \\\"{x:150,y:622,t:1527268250959};\\\", \\\"{x:150,y:625,t:1527268250975};\\\", \\\"{x:151,y:627,t:1527268251041};\\\", \\\"{x:162,y:632,t:1527268251050};\\\", \\\"{x:175,y:635,t:1527268251058};\\\", \\\"{x:196,y:638,t:1527268251076};\\\", \\\"{x:215,y:641,t:1527268251093};\\\", \\\"{x:233,y:643,t:1527268251109};\\\", \\\"{x:257,y:644,t:1527268251125};\\\", \\\"{x:279,y:644,t:1527268251143};\\\", \\\"{x:297,y:644,t:1527268251160};\\\", \\\"{x:307,y:644,t:1527268251175};\\\", \\\"{x:323,y:642,t:1527268251192};\\\", \\\"{x:334,y:639,t:1527268251210};\\\", \\\"{x:342,y:636,t:1527268251227};\\\", \\\"{x:345,y:636,t:1527268251243};\\\", \\\"{x:346,y:636,t:1527268251260};\\\", \\\"{x:346,y:635,t:1527268251361};\\\", \\\"{x:347,y:634,t:1527268251377};\\\", \\\"{x:350,y:629,t:1527268251395};\\\", \\\"{x:358,y:625,t:1527268251410};\\\", \\\"{x:364,y:621,t:1527268251426};\\\", \\\"{x:374,y:615,t:1527268251442};\\\", \\\"{x:378,y:612,t:1527268251459};\\\", \\\"{x:378,y:611,t:1527268251476};\\\", \\\"{x:380,y:610,t:1527268251512};\\\", \\\"{x:385,y:607,t:1527268251525};\\\", \\\"{x:403,y:599,t:1527268251544};\\\", \\\"{x:425,y:592,t:1527268251560};\\\", \\\"{x:454,y:584,t:1527268251576};\\\", \\\"{x:472,y:580,t:1527268251593};\\\", \\\"{x:494,y:576,t:1527268251610};\\\", \\\"{x:524,y:576,t:1527268251628};\\\", \\\"{x:553,y:576,t:1527268251642};\\\", \\\"{x:575,y:575,t:1527268251659};\\\", \\\"{x:590,y:574,t:1527268251677};\\\", \\\"{x:602,y:573,t:1527268251693};\\\", \\\"{x:604,y:572,t:1527268251709};\\\", \\\"{x:604,y:571,t:1527268251737};\\\", \\\"{x:605,y:571,t:1527268251745};\\\", \\\"{x:607,y:571,t:1527268251760};\\\", \\\"{x:613,y:570,t:1527268251777};\\\", \\\"{x:622,y:568,t:1527268251793};\\\", \\\"{x:633,y:567,t:1527268251810};\\\", \\\"{x:648,y:567,t:1527268251828};\\\", \\\"{x:663,y:567,t:1527268251844};\\\", \\\"{x:674,y:567,t:1527268251859};\\\", \\\"{x:678,y:567,t:1527268251877};\\\", \\\"{x:681,y:567,t:1527268251893};\\\", \\\"{x:694,y:567,t:1527268251909};\\\", \\\"{x:718,y:567,t:1527268251927};\\\", \\\"{x:741,y:567,t:1527268251943};\\\", \\\"{x:763,y:567,t:1527268251960};\\\", \\\"{x:797,y:567,t:1527268251977};\\\", \\\"{x:814,y:565,t:1527268251993};\\\", \\\"{x:828,y:565,t:1527268252010};\\\", \\\"{x:840,y:565,t:1527268252027};\\\", \\\"{x:847,y:563,t:1527268252043};\\\", \\\"{x:852,y:562,t:1527268252060};\\\", \\\"{x:853,y:562,t:1527268252088};\\\", \\\"{x:853,y:560,t:1527268252192};\\\", \\\"{x:853,y:558,t:1527268252201};\\\", \\\"{x:853,y:556,t:1527268252216};\\\", \\\"{x:852,y:555,t:1527268252227};\\\", \\\"{x:848,y:554,t:1527268252244};\\\", \\\"{x:844,y:552,t:1527268252260};\\\", \\\"{x:842,y:551,t:1527268252277};\\\", \\\"{x:840,y:551,t:1527268252293};\\\", \\\"{x:840,y:550,t:1527268252310};\\\", \\\"{x:839,y:550,t:1527268252327};\\\", \\\"{x:838,y:549,t:1527268252344};\\\", \\\"{x:830,y:554,t:1527268253065};\\\", \\\"{x:818,y:564,t:1527268253079};\\\", \\\"{x:799,y:578,t:1527268253094};\\\", \\\"{x:778,y:593,t:1527268253111};\\\", \\\"{x:766,y:601,t:1527268253129};\\\", \\\"{x:760,y:605,t:1527268253144};\\\", \\\"{x:760,y:606,t:1527268253160};\\\", \\\"{x:759,y:606,t:1527268253179};\\\", \\\"{x:755,y:608,t:1527268253194};\\\", \\\"{x:745,y:617,t:1527268253212};\\\", \\\"{x:727,y:629,t:1527268253228};\\\", \\\"{x:702,y:643,t:1527268253245};\\\", \\\"{x:683,y:654,t:1527268253261};\\\", \\\"{x:671,y:661,t:1527268253277};\\\", \\\"{x:658,y:670,t:1527268253294};\\\", \\\"{x:647,y:677,t:1527268253311};\\\", \\\"{x:636,y:683,t:1527268253328};\\\", \\\"{x:618,y:692,t:1527268253345};\\\", \\\"{x:600,y:702,t:1527268253360};\\\", \\\"{x:580,y:716,t:1527268253378};\\\", \\\"{x:568,y:725,t:1527268253395};\\\", \\\"{x:566,y:726,t:1527268253411};\\\", \\\"{x:565,y:726,t:1527268253428};\\\", \\\"{x:564,y:727,t:1527268253445};\\\", \\\"{x:563,y:727,t:1527268253489};\\\", \\\"{x:562,y:727,t:1527268253497};\\\", \\\"{x:561,y:727,t:1527268253511};\\\", \\\"{x:559,y:728,t:1527268253528};\\\", \\\"{x:558,y:728,t:1527268253634};\\\", \\\"{x:556,y:730,t:1527268253646};\\\", \\\"{x:554,y:731,t:1527268253661};\\\", \\\"{x:552,y:732,t:1527268253678};\\\" ] }, { \\\"rt\\\": 20553, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 311014, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:552,y:727,t:1527268257858};\\\", \\\"{x:547,y:707,t:1527268257867};\\\", \\\"{x:540,y:680,t:1527268257881};\\\", \\\"{x:534,y:653,t:1527268257898};\\\", \\\"{x:529,y:624,t:1527268257916};\\\", \\\"{x:526,y:595,t:1527268257932};\\\", \\\"{x:523,y:573,t:1527268257948};\\\", \\\"{x:519,y:560,t:1527268257966};\\\", \\\"{x:516,y:552,t:1527268257981};\\\", \\\"{x:515,y:547,t:1527268257997};\\\", \\\"{x:514,y:542,t:1527268258015};\\\", \\\"{x:512,y:536,t:1527268258031};\\\", \\\"{x:505,y:525,t:1527268258048};\\\", \\\"{x:499,y:518,t:1527268258065};\\\", \\\"{x:493,y:514,t:1527268258082};\\\", \\\"{x:484,y:509,t:1527268258098};\\\", \\\"{x:477,y:506,t:1527268258115};\\\", \\\"{x:473,y:504,t:1527268258131};\\\", \\\"{x:470,y:503,t:1527268258148};\\\", \\\"{x:470,y:502,t:1527268258522};\\\", \\\"{x:472,y:501,t:1527268258545};\\\", \\\"{x:473,y:500,t:1527268258553};\\\", \\\"{x:475,y:499,t:1527268258565};\\\", \\\"{x:477,y:498,t:1527268258582};\\\", \\\"{x:479,y:497,t:1527268258599};\\\", \\\"{x:480,y:497,t:1527268258657};\\\", \\\"{x:481,y:497,t:1527268258753};\\\", \\\"{x:482,y:497,t:1527268258764};\\\", \\\"{x:483,y:496,t:1527268258782};\\\", \\\"{x:485,y:495,t:1527268259490};\\\", \\\"{x:487,y:494,t:1527268259505};\\\", \\\"{x:488,y:494,t:1527268259545};\\\", \\\"{x:489,y:494,t:1527268259553};\\\", \\\"{x:490,y:494,t:1527268259569};\\\", \\\"{x:492,y:493,t:1527268259585};\\\", \\\"{x:493,y:493,t:1527268259597};\\\", \\\"{x:495,y:493,t:1527268259613};\\\", \\\"{x:497,y:491,t:1527268259631};\\\", \\\"{x:498,y:491,t:1527268259647};\\\", \\\"{x:500,y:490,t:1527268259666};\\\", \\\"{x:503,y:489,t:1527268259680};\\\", \\\"{x:505,y:489,t:1527268259699};\\\", \\\"{x:506,y:489,t:1527268259716};\\\", \\\"{x:513,y:489,t:1527268259734};\\\", \\\"{x:521,y:489,t:1527268259749};\\\", \\\"{x:528,y:489,t:1527268259766};\\\", \\\"{x:531,y:489,t:1527268259783};\\\", \\\"{x:536,y:489,t:1527268259800};\\\", \\\"{x:538,y:489,t:1527268259816};\\\", \\\"{x:542,y:489,t:1527268259833};\\\", \\\"{x:548,y:489,t:1527268259851};\\\", \\\"{x:553,y:489,t:1527268259866};\\\", \\\"{x:555,y:489,t:1527268259883};\\\", \\\"{x:556,y:489,t:1527268259900};\\\", \\\"{x:557,y:489,t:1527268260097};\\\", \\\"{x:558,y:488,t:1527268260105};\\\", \\\"{x:558,y:487,t:1527268260121};\\\", \\\"{x:559,y:487,t:1527268260153};\\\", \\\"{x:560,y:487,t:1527268260177};\\\", \\\"{x:563,y:486,t:1527268260186};\\\", \\\"{x:564,y:486,t:1527268260200};\\\", \\\"{x:565,y:486,t:1527268260216};\\\", \\\"{x:566,y:486,t:1527268260233};\\\", \\\"{x:568,y:486,t:1527268260305};\\\", \\\"{x:569,y:486,t:1527268260316};\\\", \\\"{x:571,y:486,t:1527268260333};\\\", \\\"{x:575,y:486,t:1527268260350};\\\", \\\"{x:580,y:486,t:1527268260366};\\\", \\\"{x:592,y:486,t:1527268260384};\\\", \\\"{x:616,y:487,t:1527268260401};\\\", \\\"{x:629,y:489,t:1527268260416};\\\", \\\"{x:637,y:490,t:1527268260434};\\\", \\\"{x:644,y:492,t:1527268260451};\\\", \\\"{x:645,y:492,t:1527268260468};\\\", \\\"{x:646,y:492,t:1527268260483};\\\", \\\"{x:647,y:492,t:1527268260529};\\\", \\\"{x:648,y:492,t:1527268260537};\\\", \\\"{x:651,y:492,t:1527268260550};\\\", \\\"{x:657,y:492,t:1527268260567};\\\", \\\"{x:664,y:496,t:1527268260583};\\\", \\\"{x:674,y:498,t:1527268260601};\\\", \\\"{x:680,y:502,t:1527268260617};\\\", \\\"{x:687,y:503,t:1527268260633};\\\", \\\"{x:692,y:505,t:1527268260650};\\\", \\\"{x:697,y:506,t:1527268260667};\\\", \\\"{x:701,y:507,t:1527268260684};\\\", \\\"{x:705,y:509,t:1527268260700};\\\", \\\"{x:707,y:509,t:1527268260717};\\\", \\\"{x:708,y:509,t:1527268260737};\\\", \\\"{x:709,y:509,t:1527268260769};\\\", \\\"{x:710,y:509,t:1527268260783};\\\", \\\"{x:716,y:510,t:1527268260800};\\\", \\\"{x:722,y:512,t:1527268260817};\\\", \\\"{x:725,y:512,t:1527268260834};\\\", \\\"{x:730,y:514,t:1527268260850};\\\", \\\"{x:739,y:517,t:1527268260868};\\\", \\\"{x:753,y:521,t:1527268260885};\\\", \\\"{x:769,y:524,t:1527268260901};\\\", \\\"{x:787,y:529,t:1527268260918};\\\", \\\"{x:799,y:533,t:1527268260934};\\\", \\\"{x:810,y:535,t:1527268260950};\\\", \\\"{x:831,y:540,t:1527268260968};\\\", \\\"{x:877,y:563,t:1527268260985};\\\", \\\"{x:925,y:594,t:1527268261000};\\\", \\\"{x:967,y:623,t:1527268261017};\\\", \\\"{x:1022,y:653,t:1527268261035};\\\", \\\"{x:1093,y:683,t:1527268261051};\\\", \\\"{x:1174,y:711,t:1527268261067};\\\", \\\"{x:1242,y:732,t:1527268261085};\\\", \\\"{x:1295,y:748,t:1527268261101};\\\", \\\"{x:1309,y:751,t:1527268261117};\\\", \\\"{x:1310,y:751,t:1527268261134};\\\", \\\"{x:1313,y:754,t:1527268261602};\\\", \\\"{x:1317,y:759,t:1527268261618};\\\", \\\"{x:1319,y:763,t:1527268261634};\\\", \\\"{x:1326,y:772,t:1527268261652};\\\", \\\"{x:1332,y:781,t:1527268261668};\\\", \\\"{x:1336,y:793,t:1527268261684};\\\", \\\"{x:1340,y:800,t:1527268261701};\\\", \\\"{x:1344,y:808,t:1527268261718};\\\", \\\"{x:1346,y:818,t:1527268261734};\\\", \\\"{x:1346,y:824,t:1527268261751};\\\", \\\"{x:1346,y:828,t:1527268261768};\\\", \\\"{x:1347,y:828,t:1527268261784};\\\", \\\"{x:1348,y:835,t:1527268261802};\\\", \\\"{x:1348,y:841,t:1527268261818};\\\", \\\"{x:1348,y:846,t:1527268261834};\\\", \\\"{x:1348,y:849,t:1527268261851};\\\", \\\"{x:1348,y:850,t:1527268261868};\\\", \\\"{x:1348,y:853,t:1527268261884};\\\", \\\"{x:1348,y:857,t:1527268261901};\\\", \\\"{x:1348,y:865,t:1527268261917};\\\", \\\"{x:1347,y:876,t:1527268261934};\\\", \\\"{x:1345,y:886,t:1527268261950};\\\", \\\"{x:1343,y:890,t:1527268261967};\\\", \\\"{x:1343,y:891,t:1527268261983};\\\", \\\"{x:1341,y:897,t:1527268262000};\\\", \\\"{x:1339,y:901,t:1527268262016};\\\", \\\"{x:1337,y:909,t:1527268262033};\\\", \\\"{x:1329,y:919,t:1527268262050};\\\", \\\"{x:1326,y:922,t:1527268262066};\\\", \\\"{x:1321,y:929,t:1527268262084};\\\", \\\"{x:1318,y:932,t:1527268262101};\\\", \\\"{x:1316,y:935,t:1527268262116};\\\", \\\"{x:1314,y:938,t:1527268262133};\\\", \\\"{x:1313,y:941,t:1527268262150};\\\", \\\"{x:1311,y:943,t:1527268262167};\\\", \\\"{x:1310,y:943,t:1527268262961};\\\", \\\"{x:1303,y:940,t:1527268262969};\\\", \\\"{x:1297,y:937,t:1527268262984};\\\", \\\"{x:1280,y:926,t:1527268263000};\\\", \\\"{x:1262,y:908,t:1527268263017};\\\", \\\"{x:1253,y:894,t:1527268263034};\\\", \\\"{x:1249,y:885,t:1527268263051};\\\", \\\"{x:1247,y:877,t:1527268263067};\\\", \\\"{x:1247,y:871,t:1527268263084};\\\", \\\"{x:1245,y:864,t:1527268263100};\\\", \\\"{x:1244,y:859,t:1527268263117};\\\", \\\"{x:1244,y:851,t:1527268263134};\\\", \\\"{x:1244,y:842,t:1527268263150};\\\", \\\"{x:1244,y:834,t:1527268263167};\\\", \\\"{x:1244,y:820,t:1527268263184};\\\", \\\"{x:1245,y:810,t:1527268263200};\\\", \\\"{x:1252,y:783,t:1527268263217};\\\", \\\"{x:1257,y:771,t:1527268263233};\\\", \\\"{x:1273,y:742,t:1527268263250};\\\", \\\"{x:1294,y:707,t:1527268263267};\\\", \\\"{x:1325,y:669,t:1527268263284};\\\", \\\"{x:1355,y:635,t:1527268263300};\\\", \\\"{x:1373,y:618,t:1527268263317};\\\", \\\"{x:1383,y:610,t:1527268263334};\\\", \\\"{x:1387,y:608,t:1527268263350};\\\", \\\"{x:1388,y:607,t:1527268263442};\\\", \\\"{x:1390,y:607,t:1527268263450};\\\", \\\"{x:1395,y:607,t:1527268263467};\\\", \\\"{x:1398,y:605,t:1527268263483};\\\", \\\"{x:1399,y:605,t:1527268263544};\\\", \\\"{x:1401,y:605,t:1527268263552};\\\", \\\"{x:1403,y:605,t:1527268263566};\\\", \\\"{x:1405,y:605,t:1527268263583};\\\", \\\"{x:1408,y:608,t:1527268263599};\\\", \\\"{x:1411,y:616,t:1527268263617};\\\", \\\"{x:1413,y:621,t:1527268263633};\\\", \\\"{x:1418,y:632,t:1527268263650};\\\", \\\"{x:1421,y:643,t:1527268263666};\\\", \\\"{x:1422,y:657,t:1527268263684};\\\", \\\"{x:1422,y:673,t:1527268263700};\\\", \\\"{x:1422,y:691,t:1527268263717};\\\", \\\"{x:1419,y:712,t:1527268263733};\\\", \\\"{x:1411,y:732,t:1527268263750};\\\", \\\"{x:1404,y:745,t:1527268263766};\\\", \\\"{x:1403,y:747,t:1527268263783};\\\", \\\"{x:1402,y:748,t:1527268263909};\\\", \\\"{x:1403,y:748,t:1527268264109};\\\", \\\"{x:1408,y:747,t:1527268264120};\\\", \\\"{x:1428,y:746,t:1527268264136};\\\", \\\"{x:1451,y:746,t:1527268264153};\\\", \\\"{x:1481,y:746,t:1527268264170};\\\", \\\"{x:1520,y:746,t:1527268264186};\\\", \\\"{x:1562,y:746,t:1527268264203};\\\", \\\"{x:1604,y:746,t:1527268264220};\\\", \\\"{x:1621,y:746,t:1527268264236};\\\", \\\"{x:1634,y:746,t:1527268264253};\\\", \\\"{x:1639,y:746,t:1527268264270};\\\", \\\"{x:1635,y:748,t:1527268264614};\\\", \\\"{x:1630,y:751,t:1527268264620};\\\", \\\"{x:1624,y:757,t:1527268264637};\\\", \\\"{x:1618,y:762,t:1527268264653};\\\", \\\"{x:1612,y:766,t:1527268264669};\\\", \\\"{x:1608,y:768,t:1527268264686};\\\", \\\"{x:1608,y:769,t:1527268264703};\\\", \\\"{x:1607,y:769,t:1527268264720};\\\", \\\"{x:1605,y:771,t:1527268264736};\\\", \\\"{x:1603,y:772,t:1527268264753};\\\", \\\"{x:1600,y:773,t:1527268264770};\\\", \\\"{x:1600,y:774,t:1527268264786};\\\", \\\"{x:1599,y:775,t:1527268264803};\\\", \\\"{x:1595,y:780,t:1527268264820};\\\", \\\"{x:1583,y:793,t:1527268264836};\\\", \\\"{x:1573,y:803,t:1527268264852};\\\", \\\"{x:1559,y:814,t:1527268264870};\\\", \\\"{x:1551,y:821,t:1527268264886};\\\", \\\"{x:1545,y:829,t:1527268264903};\\\", \\\"{x:1543,y:831,t:1527268264919};\\\", \\\"{x:1543,y:832,t:1527268264940};\\\", \\\"{x:1542,y:834,t:1527268264957};\\\", \\\"{x:1541,y:838,t:1527268264973};\\\", \\\"{x:1540,y:840,t:1527268264987};\\\", \\\"{x:1533,y:852,t:1527268265003};\\\", \\\"{x:1519,y:867,t:1527268265019};\\\", \\\"{x:1491,y:898,t:1527268265036};\\\", \\\"{x:1449,y:929,t:1527268265053};\\\", \\\"{x:1369,y:999,t:1527268265069};\\\", \\\"{x:1283,y:1063,t:1527268265087};\\\", \\\"{x:1213,y:1112,t:1527268265103};\\\", \\\"{x:1168,y:1145,t:1527268265119};\\\", \\\"{x:1137,y:1157,t:1527268265136};\\\", \\\"{x:1130,y:1158,t:1527268265153};\\\", \\\"{x:1135,y:1149,t:1527268265261};\\\", \\\"{x:1147,y:1133,t:1527268265269};\\\", \\\"{x:1181,y:1094,t:1527268265286};\\\", \\\"{x:1213,y:1056,t:1527268265304};\\\", \\\"{x:1260,y:1016,t:1527268265320};\\\", \\\"{x:1312,y:986,t:1527268265337};\\\", \\\"{x:1332,y:978,t:1527268265354};\\\", \\\"{x:1336,y:976,t:1527268265369};\\\", \\\"{x:1337,y:976,t:1527268265386};\\\", \\\"{x:1338,y:974,t:1527268265500};\\\", \\\"{x:1340,y:970,t:1527268265508};\\\", \\\"{x:1342,y:964,t:1527268265521};\\\", \\\"{x:1344,y:960,t:1527268265536};\\\", \\\"{x:1349,y:953,t:1527268265552};\\\", \\\"{x:1352,y:947,t:1527268265568};\\\", \\\"{x:1354,y:943,t:1527268265586};\\\", \\\"{x:1358,y:936,t:1527268265602};\\\", \\\"{x:1362,y:925,t:1527268265618};\\\", \\\"{x:1365,y:917,t:1527268265636};\\\", \\\"{x:1367,y:908,t:1527268265652};\\\", \\\"{x:1368,y:900,t:1527268265669};\\\", \\\"{x:1368,y:892,t:1527268265686};\\\", \\\"{x:1368,y:888,t:1527268265702};\\\", \\\"{x:1368,y:882,t:1527268265719};\\\", \\\"{x:1369,y:872,t:1527268265736};\\\", \\\"{x:1369,y:865,t:1527268265752};\\\", \\\"{x:1369,y:860,t:1527268265769};\\\", \\\"{x:1369,y:859,t:1527268265786};\\\", \\\"{x:1369,y:858,t:1527268265802};\\\", \\\"{x:1369,y:853,t:1527268265819};\\\", \\\"{x:1369,y:842,t:1527268265836};\\\", \\\"{x:1369,y:832,t:1527268265852};\\\", \\\"{x:1369,y:821,t:1527268265869};\\\", \\\"{x:1369,y:811,t:1527268265886};\\\", \\\"{x:1369,y:802,t:1527268265901};\\\", \\\"{x:1369,y:793,t:1527268265918};\\\", \\\"{x:1369,y:786,t:1527268265936};\\\", \\\"{x:1366,y:777,t:1527268265952};\\\", \\\"{x:1361,y:767,t:1527268265969};\\\", \\\"{x:1355,y:758,t:1527268265986};\\\", \\\"{x:1353,y:752,t:1527268266002};\\\", \\\"{x:1351,y:750,t:1527268266019};\\\", \\\"{x:1349,y:747,t:1527268266036};\\\", \\\"{x:1348,y:746,t:1527268266052};\\\", \\\"{x:1346,y:743,t:1527268266070};\\\", \\\"{x:1345,y:741,t:1527268266086};\\\", \\\"{x:1344,y:741,t:1527268266102};\\\", \\\"{x:1344,y:740,t:1527268266120};\\\", \\\"{x:1339,y:739,t:1527268266135};\\\", \\\"{x:1327,y:734,t:1527268266153};\\\", \\\"{x:1309,y:726,t:1527268266170};\\\", \\\"{x:1295,y:720,t:1527268266187};\\\", \\\"{x:1291,y:718,t:1527268266203};\\\", \\\"{x:1288,y:718,t:1527268266219};\\\", \\\"{x:1286,y:718,t:1527268266269};\\\", \\\"{x:1279,y:718,t:1527268266285};\\\", \\\"{x:1269,y:718,t:1527268266302};\\\", \\\"{x:1262,y:719,t:1527268266319};\\\", \\\"{x:1256,y:720,t:1527268266335};\\\", \\\"{x:1248,y:720,t:1527268266351};\\\", \\\"{x:1231,y:724,t:1527268266368};\\\", \\\"{x:1216,y:726,t:1527268266385};\\\", \\\"{x:1194,y:728,t:1527268266402};\\\", \\\"{x:1164,y:734,t:1527268266419};\\\", \\\"{x:1124,y:739,t:1527268266435};\\\", \\\"{x:1088,y:742,t:1527268266452};\\\", \\\"{x:1084,y:742,t:1527268266469};\\\", \\\"{x:1085,y:742,t:1527268266565};\\\", \\\"{x:1090,y:741,t:1527268266572};\\\", \\\"{x:1100,y:738,t:1527268266585};\\\", \\\"{x:1125,y:736,t:1527268266602};\\\", \\\"{x:1153,y:735,t:1527268266619};\\\", \\\"{x:1175,y:731,t:1527268266635};\\\", \\\"{x:1204,y:725,t:1527268266652};\\\", \\\"{x:1226,y:717,t:1527268266669};\\\", \\\"{x:1227,y:716,t:1527268266685};\\\", \\\"{x:1228,y:716,t:1527268266732};\\\", \\\"{x:1231,y:714,t:1527268266764};\\\", \\\"{x:1236,y:711,t:1527268266771};\\\", \\\"{x:1246,y:706,t:1527268266784};\\\", \\\"{x:1264,y:698,t:1527268266802};\\\", \\\"{x:1288,y:690,t:1527268266819};\\\", \\\"{x:1316,y:683,t:1527268266835};\\\", \\\"{x:1344,y:680,t:1527268266852};\\\", \\\"{x:1347,y:680,t:1527268267180};\\\", \\\"{x:1354,y:680,t:1527268267187};\\\", \\\"{x:1366,y:676,t:1527268267202};\\\", \\\"{x:1392,y:673,t:1527268267218};\\\", \\\"{x:1416,y:670,t:1527268267235};\\\", \\\"{x:1443,y:666,t:1527268267251};\\\", \\\"{x:1457,y:663,t:1527268267268};\\\", \\\"{x:1462,y:662,t:1527268267285};\\\", \\\"{x:1465,y:662,t:1527268267605};\\\", \\\"{x:1471,y:660,t:1527268267618};\\\", \\\"{x:1489,y:651,t:1527268267635};\\\", \\\"{x:1513,y:641,t:1527268267653};\\\", \\\"{x:1525,y:635,t:1527268267668};\\\", \\\"{x:1532,y:633,t:1527268267685};\\\", \\\"{x:1535,y:631,t:1527268267702};\\\", \\\"{x:1537,y:630,t:1527268267718};\\\", \\\"{x:1540,y:629,t:1527268267736};\\\", \\\"{x:1544,y:626,t:1527268267752};\\\", \\\"{x:1552,y:623,t:1527268267768};\\\", \\\"{x:1559,y:620,t:1527268267786};\\\", \\\"{x:1564,y:619,t:1527268267803};\\\", \\\"{x:1568,y:617,t:1527268267819};\\\", \\\"{x:1570,y:616,t:1527268267836};\\\", \\\"{x:1571,y:616,t:1527268267853};\\\", \\\"{x:1571,y:617,t:1527268267989};\\\", \\\"{x:1569,y:620,t:1527268268002};\\\", \\\"{x:1564,y:626,t:1527268268019};\\\", \\\"{x:1558,y:629,t:1527268268036};\\\", \\\"{x:1551,y:633,t:1527268268051};\\\", \\\"{x:1543,y:637,t:1527268268068};\\\", \\\"{x:1537,y:640,t:1527268268086};\\\", \\\"{x:1533,y:641,t:1527268268101};\\\", \\\"{x:1525,y:645,t:1527268268118};\\\", \\\"{x:1512,y:652,t:1527268268135};\\\", \\\"{x:1497,y:662,t:1527268268151};\\\", \\\"{x:1475,y:676,t:1527268268168};\\\", \\\"{x:1453,y:690,t:1527268268185};\\\", \\\"{x:1436,y:700,t:1527268268201};\\\", \\\"{x:1417,y:709,t:1527268268217};\\\", \\\"{x:1397,y:719,t:1527268268234};\\\", \\\"{x:1376,y:728,t:1527268268251};\\\", \\\"{x:1368,y:730,t:1527268268268};\\\", \\\"{x:1367,y:730,t:1527268269933};\\\", \\\"{x:1365,y:737,t:1527268269940};\\\", \\\"{x:1365,y:742,t:1527268269951};\\\", \\\"{x:1365,y:753,t:1527268269968};\\\", \\\"{x:1362,y:764,t:1527268269984};\\\", \\\"{x:1362,y:769,t:1527268270001};\\\", \\\"{x:1362,y:771,t:1527268270017};\\\", \\\"{x:1362,y:772,t:1527268270037};\\\", \\\"{x:1362,y:773,t:1527268270052};\\\", \\\"{x:1361,y:776,t:1527268270068};\\\", \\\"{x:1361,y:789,t:1527268270084};\\\", \\\"{x:1361,y:801,t:1527268270101};\\\", \\\"{x:1361,y:814,t:1527268270117};\\\", \\\"{x:1361,y:821,t:1527268270134};\\\", \\\"{x:1363,y:825,t:1527268270151};\\\", \\\"{x:1363,y:828,t:1527268270168};\\\", \\\"{x:1363,y:833,t:1527268270185};\\\", \\\"{x:1363,y:836,t:1527268270202};\\\", \\\"{x:1363,y:843,t:1527268270218};\\\", \\\"{x:1363,y:852,t:1527268270235};\\\", \\\"{x:1362,y:858,t:1527268270252};\\\", \\\"{x:1362,y:859,t:1527268270317};\\\", \\\"{x:1362,y:860,t:1527268270335};\\\", \\\"{x:1362,y:862,t:1527268270352};\\\", \\\"{x:1362,y:865,t:1527268270367};\\\", \\\"{x:1362,y:870,t:1527268270385};\\\", \\\"{x:1362,y:876,t:1527268270402};\\\", \\\"{x:1361,y:885,t:1527268270418};\\\", \\\"{x:1361,y:890,t:1527268270435};\\\", \\\"{x:1361,y:897,t:1527268270452};\\\", \\\"{x:1364,y:913,t:1527268270467};\\\", \\\"{x:1364,y:916,t:1527268270484};\\\", \\\"{x:1364,y:919,t:1527268270502};\\\", \\\"{x:1361,y:919,t:1527268270518};\\\", \\\"{x:1357,y:919,t:1527268270535};\\\", \\\"{x:1356,y:918,t:1527268270551};\\\", \\\"{x:1354,y:918,t:1527268270568};\\\", \\\"{x:1352,y:916,t:1527268270585};\\\", \\\"{x:1352,y:908,t:1527268270600};\\\", \\\"{x:1352,y:884,t:1527268270618};\\\", \\\"{x:1353,y:852,t:1527268270634};\\\", \\\"{x:1360,y:799,t:1527268270650};\\\", \\\"{x:1364,y:742,t:1527268270667};\\\", \\\"{x:1367,y:698,t:1527268270685};\\\", \\\"{x:1370,y:688,t:1527268270700};\\\", \\\"{x:1371,y:683,t:1527268270718};\\\", \\\"{x:1372,y:681,t:1527268270735};\\\", \\\"{x:1372,y:679,t:1527268270751};\\\", \\\"{x:1372,y:677,t:1527268270768};\\\", \\\"{x:1372,y:675,t:1527268270784};\\\", \\\"{x:1372,y:677,t:1527268271012};\\\", \\\"{x:1372,y:679,t:1527268271020};\\\", \\\"{x:1372,y:681,t:1527268271035};\\\", \\\"{x:1372,y:683,t:1527268271051};\\\", \\\"{x:1372,y:685,t:1527268271068};\\\", \\\"{x:1369,y:693,t:1527268271084};\\\", \\\"{x:1359,y:704,t:1527268271100};\\\", \\\"{x:1336,y:719,t:1527268271117};\\\", \\\"{x:1292,y:738,t:1527268271134};\\\", \\\"{x:1234,y:762,t:1527268271150};\\\", \\\"{x:1153,y:776,t:1527268271167};\\\", \\\"{x:1099,y:780,t:1527268271184};\\\", \\\"{x:1039,y:777,t:1527268271200};\\\", \\\"{x:988,y:762,t:1527268271217};\\\", \\\"{x:951,y:748,t:1527268271234};\\\", \\\"{x:928,y:737,t:1527268271250};\\\", \\\"{x:916,y:732,t:1527268271267};\\\", \\\"{x:905,y:721,t:1527268271283};\\\", \\\"{x:903,y:720,t:1527268271300};\\\", \\\"{x:902,y:719,t:1527268271636};\\\", \\\"{x:900,y:716,t:1527268271650};\\\", \\\"{x:885,y:708,t:1527268271668};\\\", \\\"{x:866,y:697,t:1527268271683};\\\", \\\"{x:830,y:677,t:1527268271700};\\\", \\\"{x:794,y:655,t:1527268271717};\\\", \\\"{x:761,y:642,t:1527268271733};\\\", \\\"{x:724,y:626,t:1527268271752};\\\", \\\"{x:701,y:614,t:1527268271767};\\\", \\\"{x:683,y:604,t:1527268271783};\\\", \\\"{x:662,y:591,t:1527268271796};\\\", \\\"{x:643,y:579,t:1527268271812};\\\", \\\"{x:627,y:567,t:1527268271829};\\\", \\\"{x:617,y:559,t:1527268271847};\\\", \\\"{x:614,y:554,t:1527268271863};\\\", \\\"{x:613,y:551,t:1527268271879};\\\", \\\"{x:612,y:548,t:1527268271896};\\\", \\\"{x:612,y:545,t:1527268271912};\\\", \\\"{x:615,y:540,t:1527268271929};\\\", \\\"{x:624,y:535,t:1527268271946};\\\", \\\"{x:642,y:527,t:1527268271962};\\\", \\\"{x:655,y:521,t:1527268271979};\\\", \\\"{x:659,y:520,t:1527268271996};\\\", \\\"{x:663,y:520,t:1527268272013};\\\", \\\"{x:673,y:520,t:1527268272029};\\\", \\\"{x:682,y:520,t:1527268272046};\\\", \\\"{x:687,y:520,t:1527268272063};\\\", \\\"{x:690,y:520,t:1527268272080};\\\", \\\"{x:695,y:520,t:1527268272096};\\\", \\\"{x:702,y:521,t:1527268272113};\\\", \\\"{x:706,y:521,t:1527268272129};\\\", \\\"{x:709,y:521,t:1527268272180};\\\", \\\"{x:730,y:521,t:1527268272196};\\\", \\\"{x:761,y:521,t:1527268272213};\\\", \\\"{x:782,y:521,t:1527268272231};\\\", \\\"{x:789,y:521,t:1527268272246};\\\", \\\"{x:792,y:521,t:1527268272264};\\\", \\\"{x:796,y:521,t:1527268272372};\\\", \\\"{x:798,y:519,t:1527268272380};\\\", \\\"{x:802,y:516,t:1527268272397};\\\", \\\"{x:802,y:514,t:1527268272413};\\\", \\\"{x:802,y:513,t:1527268272429};\\\", \\\"{x:803,y:510,t:1527268272446};\\\", \\\"{x:805,y:508,t:1527268272463};\\\", \\\"{x:814,y:502,t:1527268272479};\\\", \\\"{x:818,y:500,t:1527268272496};\\\", \\\"{x:819,y:500,t:1527268272513};\\\", \\\"{x:820,y:500,t:1527268272611};\\\", \\\"{x:815,y:501,t:1527268272964};\\\", \\\"{x:764,y:528,t:1527268272982};\\\", \\\"{x:706,y:563,t:1527268272996};\\\", \\\"{x:627,y:597,t:1527268273013};\\\", \\\"{x:539,y:628,t:1527268273030};\\\", \\\"{x:481,y:645,t:1527268273048};\\\", \\\"{x:433,y:659,t:1527268273063};\\\", \\\"{x:407,y:666,t:1527268273080};\\\", \\\"{x:401,y:667,t:1527268273097};\\\", \\\"{x:397,y:668,t:1527268273112};\\\", \\\"{x:392,y:670,t:1527268273130};\\\", \\\"{x:387,y:672,t:1527268273147};\\\", \\\"{x:375,y:675,t:1527268273163};\\\", \\\"{x:338,y:679,t:1527268273180};\\\", \\\"{x:308,y:679,t:1527268273196};\\\", \\\"{x:283,y:678,t:1527268273213};\\\", \\\"{x:261,y:671,t:1527268273230};\\\", \\\"{x:248,y:666,t:1527268273248};\\\", \\\"{x:241,y:660,t:1527268273263};\\\", \\\"{x:228,y:654,t:1527268273280};\\\", \\\"{x:216,y:647,t:1527268273297};\\\", \\\"{x:197,y:637,t:1527268273315};\\\", \\\"{x:174,y:626,t:1527268273331};\\\", \\\"{x:145,y:620,t:1527268273347};\\\", \\\"{x:123,y:615,t:1527268273363};\\\", \\\"{x:115,y:613,t:1527268273380};\\\", \\\"{x:114,y:613,t:1527268273445};\\\", \\\"{x:114,y:609,t:1527268273452};\\\", \\\"{x:114,y:602,t:1527268273465};\\\", \\\"{x:113,y:594,t:1527268273482};\\\", \\\"{x:112,y:584,t:1527268273498};\\\", \\\"{x:112,y:577,t:1527268273513};\\\", \\\"{x:113,y:572,t:1527268273530};\\\", \\\"{x:116,y:568,t:1527268273546};\\\", \\\"{x:118,y:567,t:1527268273563};\\\", \\\"{x:122,y:564,t:1527268273579};\\\", \\\"{x:126,y:562,t:1527268273597};\\\", \\\"{x:132,y:558,t:1527268273613};\\\", \\\"{x:133,y:557,t:1527268273631};\\\", \\\"{x:134,y:557,t:1527268273692};\\\", \\\"{x:138,y:554,t:1527268273701};\\\", \\\"{x:141,y:552,t:1527268273714};\\\", \\\"{x:149,y:548,t:1527268273732};\\\", \\\"{x:151,y:546,t:1527268273747};\\\", \\\"{x:152,y:546,t:1527268273851};\\\", \\\"{x:154,y:544,t:1527268273864};\\\", \\\"{x:161,y:540,t:1527268273881};\\\", \\\"{x:161,y:539,t:1527268273897};\\\", \\\"{x:163,y:538,t:1527268274051};\\\", \\\"{x:167,y:537,t:1527268274064};\\\", \\\"{x:173,y:534,t:1527268274081};\\\", \\\"{x:174,y:534,t:1527268274107};\\\", \\\"{x:176,y:533,t:1527268274115};\\\", \\\"{x:179,y:532,t:1527268274131};\\\", \\\"{x:198,y:532,t:1527268274148};\\\", \\\"{x:228,y:532,t:1527268274164};\\\", \\\"{x:266,y:530,t:1527268274181};\\\", \\\"{x:329,y:526,t:1527268274199};\\\", \\\"{x:415,y:515,t:1527268274215};\\\", \\\"{x:515,y:499,t:1527268274232};\\\", \\\"{x:611,y:492,t:1527268274248};\\\", \\\"{x:697,y:480,t:1527268274264};\\\", \\\"{x:761,y:472,t:1527268274281};\\\", \\\"{x:804,y:465,t:1527268274299};\\\", \\\"{x:824,y:463,t:1527268274314};\\\", \\\"{x:831,y:461,t:1527268274332};\\\", \\\"{x:833,y:461,t:1527268274348};\\\", \\\"{x:831,y:461,t:1527268274499};\\\", \\\"{x:830,y:462,t:1527268274515};\\\", \\\"{x:829,y:462,t:1527268274531};\\\", \\\"{x:827,y:464,t:1527268274548};\\\", \\\"{x:827,y:471,t:1527268274565};\\\", \\\"{x:827,y:481,t:1527268274581};\\\", \\\"{x:827,y:492,t:1527268274599};\\\", \\\"{x:827,y:499,t:1527268274614};\\\", \\\"{x:828,y:502,t:1527268274632};\\\", \\\"{x:831,y:503,t:1527268274925};\\\", \\\"{x:832,y:503,t:1527268274932};\\\", \\\"{x:833,y:503,t:1527268274964};\\\", \\\"{x:834,y:503,t:1527268274989};\\\", \\\"{x:831,y:506,t:1527268275236};\\\", \\\"{x:810,y:514,t:1527268275249};\\\", \\\"{x:758,y:548,t:1527268275266};\\\", \\\"{x:697,y:599,t:1527268275283};\\\", \\\"{x:614,y:657,t:1527268275298};\\\", \\\"{x:513,y:704,t:1527268275315};\\\", \\\"{x:484,y:713,t:1527268275332};\\\", \\\"{x:474,y:717,t:1527268275348};\\\", \\\"{x:474,y:718,t:1527268275420};\\\", \\\"{x:474,y:720,t:1527268275434};\\\", \\\"{x:474,y:722,t:1527268275448};\\\", \\\"{x:474,y:724,t:1527268275465};\\\", \\\"{x:475,y:724,t:1527268275499};\\\", \\\"{x:478,y:726,t:1527268275515};\\\", \\\"{x:487,y:731,t:1527268275532};\\\", \\\"{x:491,y:732,t:1527268275549};\\\", \\\"{x:491,y:733,t:1527268275565};\\\", \\\"{x:495,y:740,t:1527268275583};\\\", \\\"{x:497,y:743,t:1527268275599};\\\", \\\"{x:498,y:744,t:1527268275651};\\\", \\\"{x:499,y:746,t:1527268275676};\\\", \\\"{x:500,y:746,t:1527268275684};\\\", \\\"{x:500,y:746,t:1527268275746};\\\", \\\"{x:501,y:749,t:1527268276005};\\\", \\\"{x:523,y:765,t:1527268276016};\\\", \\\"{x:579,y:791,t:1527268276033};\\\", \\\"{x:621,y:797,t:1527268276049};\\\", \\\"{x:659,y:797,t:1527268276066};\\\", \\\"{x:721,y:785,t:1527268276082};\\\", \\\"{x:823,y:761,t:1527268276099};\\\", \\\"{x:878,y:744,t:1527268276115};\\\", \\\"{x:916,y:730,t:1527268276132};\\\", \\\"{x:940,y:725,t:1527268276149};\\\", \\\"{x:953,y:721,t:1527268276165};\\\", \\\"{x:958,y:719,t:1527268276182};\\\", \\\"{x:957,y:719,t:1527268276220};\\\", \\\"{x:950,y:719,t:1527268276232};\\\", \\\"{x:944,y:719,t:1527268276249};\\\", \\\"{x:943,y:719,t:1527268276266};\\\" ] }, { \\\"rt\\\": 68097, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 380331, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"N\\\", \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -X -X -M -B -M -J -J -J -X -N -N \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:943,y:718,t:1527268282180};\\\", \\\"{x:972,y:709,t:1527268282197};\\\", \\\"{x:991,y:699,t:1527268282204};\\\", \\\"{x:1022,y:685,t:1527268282220};\\\", \\\"{x:1049,y:673,t:1527268282237};\\\", \\\"{x:1068,y:666,t:1527268282254};\\\", \\\"{x:1081,y:661,t:1527268282271};\\\", \\\"{x:1089,y:657,t:1527268282288};\\\", \\\"{x:1098,y:653,t:1527268282304};\\\", \\\"{x:1103,y:651,t:1527268282321};\\\", \\\"{x:1108,y:647,t:1527268282337};\\\", \\\"{x:1112,y:643,t:1527268282354};\\\", \\\"{x:1118,y:634,t:1527268282371};\\\", \\\"{x:1136,y:607,t:1527268282388};\\\", \\\"{x:1152,y:580,t:1527268282403};\\\", \\\"{x:1175,y:548,t:1527268282420};\\\", \\\"{x:1188,y:524,t:1527268282438};\\\", \\\"{x:1196,y:507,t:1527268282454};\\\", \\\"{x:1200,y:495,t:1527268282471};\\\", \\\"{x:1201,y:491,t:1527268282488};\\\", \\\"{x:1201,y:488,t:1527268282504};\\\", \\\"{x:1201,y:487,t:1527268282557};\\\", \\\"{x:1199,y:485,t:1527268282571};\\\", \\\"{x:1188,y:478,t:1527268282588};\\\", \\\"{x:1175,y:472,t:1527268282604};\\\", \\\"{x:1166,y:468,t:1527268282621};\\\", \\\"{x:1159,y:465,t:1527268282638};\\\", \\\"{x:1155,y:467,t:1527268282692};\\\", \\\"{x:1150,y:471,t:1527268282705};\\\", \\\"{x:1144,y:480,t:1527268282721};\\\", \\\"{x:1143,y:483,t:1527268282738};\\\", \\\"{x:1143,y:484,t:1527268282755};\\\", \\\"{x:1142,y:485,t:1527268282876};\\\", \\\"{x:1142,y:488,t:1527268282917};\\\", \\\"{x:1142,y:492,t:1527268282924};\\\", \\\"{x:1142,y:495,t:1527268282939};\\\", \\\"{x:1140,y:501,t:1527268282956};\\\", \\\"{x:1139,y:506,t:1527268282971};\\\", \\\"{x:1138,y:507,t:1527268282988};\\\", \\\"{x:1137,y:508,t:1527268283006};\\\", \\\"{x:1137,y:510,t:1527268291349};\\\", \\\"{x:1138,y:512,t:1527268291362};\\\", \\\"{x:1139,y:513,t:1527268291378};\\\", \\\"{x:1141,y:514,t:1527268291395};\\\", \\\"{x:1144,y:514,t:1527268291412};\\\", \\\"{x:1146,y:516,t:1527268291427};\\\", \\\"{x:1147,y:516,t:1527268291444};\\\", \\\"{x:1149,y:516,t:1527268291477};\\\", \\\"{x:1151,y:517,t:1527268291494};\\\", \\\"{x:1153,y:518,t:1527268291512};\\\", \\\"{x:1154,y:518,t:1527268291527};\\\", \\\"{x:1155,y:519,t:1527268291544};\\\", \\\"{x:1157,y:519,t:1527268291561};\\\", \\\"{x:1159,y:520,t:1527268291577};\\\", \\\"{x:1161,y:521,t:1527268291594};\\\", \\\"{x:1163,y:522,t:1527268291611};\\\", \\\"{x:1164,y:522,t:1527268291636};\\\", \\\"{x:1165,y:522,t:1527268291644};\\\", \\\"{x:1166,y:523,t:1527268291662};\\\", \\\"{x:1167,y:523,t:1527268291684};\\\", \\\"{x:1169,y:524,t:1527268291694};\\\", \\\"{x:1170,y:526,t:1527268291712};\\\", \\\"{x:1172,y:526,t:1527268291732};\\\", \\\"{x:1173,y:527,t:1527268291745};\\\", \\\"{x:1175,y:528,t:1527268291762};\\\", \\\"{x:1176,y:529,t:1527268291777};\\\", \\\"{x:1177,y:530,t:1527268291820};\\\", \\\"{x:1179,y:530,t:1527268291828};\\\", \\\"{x:1188,y:537,t:1527268291845};\\\", \\\"{x:1195,y:543,t:1527268291861};\\\", \\\"{x:1200,y:547,t:1527268291879};\\\", \\\"{x:1202,y:551,t:1527268291894};\\\", \\\"{x:1203,y:554,t:1527268291911};\\\", \\\"{x:1203,y:555,t:1527268291928};\\\", \\\"{x:1205,y:557,t:1527268291945};\\\", \\\"{x:1205,y:561,t:1527268291962};\\\", \\\"{x:1205,y:564,t:1527268291979};\\\", \\\"{x:1205,y:566,t:1527268291995};\\\", \\\"{x:1205,y:571,t:1527268292011};\\\", \\\"{x:1199,y:579,t:1527268292028};\\\", \\\"{x:1193,y:588,t:1527268292045};\\\", \\\"{x:1188,y:598,t:1527268292062};\\\", \\\"{x:1183,y:607,t:1527268292079};\\\", \\\"{x:1180,y:616,t:1527268292095};\\\", \\\"{x:1180,y:619,t:1527268292111};\\\", \\\"{x:1181,y:621,t:1527268292165};\\\", \\\"{x:1182,y:622,t:1527268292179};\\\", \\\"{x:1189,y:626,t:1527268292194};\\\", \\\"{x:1200,y:632,t:1527268292212};\\\", \\\"{x:1223,y:640,t:1527268292229};\\\", \\\"{x:1242,y:648,t:1527268292245};\\\", \\\"{x:1261,y:653,t:1527268292261};\\\", \\\"{x:1286,y:659,t:1527268292279};\\\", \\\"{x:1309,y:665,t:1527268292294};\\\", \\\"{x:1327,y:673,t:1527268292312};\\\", \\\"{x:1343,y:689,t:1527268292329};\\\", \\\"{x:1356,y:706,t:1527268292346};\\\", \\\"{x:1361,y:723,t:1527268292363};\\\", \\\"{x:1362,y:733,t:1527268292379};\\\", \\\"{x:1362,y:742,t:1527268292395};\\\", \\\"{x:1364,y:749,t:1527268292412};\\\", \\\"{x:1364,y:753,t:1527268292428};\\\", \\\"{x:1364,y:755,t:1527268292516};\\\", \\\"{x:1364,y:759,t:1527268292529};\\\", \\\"{x:1363,y:766,t:1527268292545};\\\", \\\"{x:1363,y:769,t:1527268292562};\\\", \\\"{x:1361,y:774,t:1527268292578};\\\", \\\"{x:1361,y:778,t:1527268292596};\\\", \\\"{x:1360,y:781,t:1527268292612};\\\", \\\"{x:1360,y:784,t:1527268292628};\\\", \\\"{x:1360,y:785,t:1527268292828};\\\", \\\"{x:1360,y:786,t:1527268292846};\\\", \\\"{x:1360,y:795,t:1527268292863};\\\", \\\"{x:1360,y:810,t:1527268292879};\\\", \\\"{x:1360,y:837,t:1527268292896};\\\", \\\"{x:1360,y:870,t:1527268292913};\\\", \\\"{x:1360,y:926,t:1527268292929};\\\", \\\"{x:1360,y:947,t:1527268292946};\\\", \\\"{x:1360,y:949,t:1527268292963};\\\", \\\"{x:1360,y:945,t:1527268293149};\\\", \\\"{x:1362,y:935,t:1527268293164};\\\", \\\"{x:1364,y:910,t:1527268293178};\\\", \\\"{x:1373,y:873,t:1527268293195};\\\", \\\"{x:1380,y:859,t:1527268293212};\\\", \\\"{x:1382,y:855,t:1527268293228};\\\", \\\"{x:1382,y:854,t:1527268293245};\\\", \\\"{x:1382,y:853,t:1527268295124};\\\", \\\"{x:1383,y:855,t:1527268295132};\\\", \\\"{x:1384,y:861,t:1527268295147};\\\", \\\"{x:1387,y:868,t:1527268295164};\\\", \\\"{x:1388,y:870,t:1527268295180};\\\", \\\"{x:1389,y:870,t:1527268295197};\\\", \\\"{x:1390,y:870,t:1527268295429};\\\", \\\"{x:1394,y:872,t:1527268295436};\\\", \\\"{x:1398,y:872,t:1527268295448};\\\", \\\"{x:1416,y:872,t:1527268295464};\\\", \\\"{x:1435,y:867,t:1527268295481};\\\", \\\"{x:1458,y:861,t:1527268295498};\\\", \\\"{x:1477,y:854,t:1527268295514};\\\", \\\"{x:1493,y:848,t:1527268295531};\\\", \\\"{x:1502,y:843,t:1527268295548};\\\", \\\"{x:1503,y:842,t:1527268295636};\\\", \\\"{x:1505,y:840,t:1527268295648};\\\", \\\"{x:1510,y:834,t:1527268295664};\\\", \\\"{x:1513,y:829,t:1527268295681};\\\", \\\"{x:1513,y:828,t:1527268295698};\\\", \\\"{x:1513,y:826,t:1527268295748};\\\", \\\"{x:1510,y:824,t:1527268295764};\\\", \\\"{x:1502,y:822,t:1527268295780};\\\", \\\"{x:1498,y:820,t:1527268295797};\\\", \\\"{x:1491,y:817,t:1527268295814};\\\", \\\"{x:1489,y:817,t:1527268295830};\\\", \\\"{x:1488,y:817,t:1527268295847};\\\", \\\"{x:1487,y:817,t:1527268295868};\\\", \\\"{x:1485,y:817,t:1527268295916};\\\", \\\"{x:1484,y:817,t:1527268295932};\\\", \\\"{x:1482,y:817,t:1527268295956};\\\", \\\"{x:1481,y:818,t:1527268295980};\\\", \\\"{x:1481,y:819,t:1527268296077};\\\", \\\"{x:1481,y:820,t:1527268296084};\\\", \\\"{x:1481,y:821,t:1527268296098};\\\", \\\"{x:1481,y:823,t:1527268296115};\\\", \\\"{x:1481,y:824,t:1527268296131};\\\", \\\"{x:1481,y:827,t:1527268296151};\\\", \\\"{x:1482,y:830,t:1527268296164};\\\", \\\"{x:1478,y:830,t:1527268296764};\\\", \\\"{x:1469,y:829,t:1527268296782};\\\", \\\"{x:1465,y:827,t:1527268296798};\\\", \\\"{x:1460,y:825,t:1527268296814};\\\", \\\"{x:1449,y:822,t:1527268296832};\\\", \\\"{x:1438,y:817,t:1527268296849};\\\", \\\"{x:1421,y:810,t:1527268296864};\\\", \\\"{x:1401,y:803,t:1527268296882};\\\", \\\"{x:1383,y:798,t:1527268296899};\\\", \\\"{x:1370,y:796,t:1527268296915};\\\", \\\"{x:1356,y:794,t:1527268296931};\\\", \\\"{x:1350,y:792,t:1527268296948};\\\", \\\"{x:1345,y:792,t:1527268296965};\\\", \\\"{x:1343,y:791,t:1527268296982};\\\", \\\"{x:1342,y:791,t:1527268296999};\\\", \\\"{x:1341,y:791,t:1527268297014};\\\", \\\"{x:1340,y:790,t:1527268297052};\\\", \\\"{x:1336,y:793,t:1527268298965};\\\", \\\"{x:1322,y:801,t:1527268298971};\\\", \\\"{x:1303,y:809,t:1527268298983};\\\", \\\"{x:1275,y:823,t:1527268299000};\\\", \\\"{x:1249,y:834,t:1527268299017};\\\", \\\"{x:1230,y:837,t:1527268299032};\\\", \\\"{x:1224,y:839,t:1527268299049};\\\", \\\"{x:1240,y:831,t:1527268300700};\\\", \\\"{x:1258,y:823,t:1527268300718};\\\", \\\"{x:1266,y:819,t:1527268300735};\\\", \\\"{x:1274,y:814,t:1527268300750};\\\", \\\"{x:1275,y:813,t:1527268300767};\\\", \\\"{x:1276,y:813,t:1527268300785};\\\", \\\"{x:1278,y:812,t:1527268300800};\\\", \\\"{x:1280,y:812,t:1527268300817};\\\", \\\"{x:1282,y:810,t:1527268300835};\\\", \\\"{x:1287,y:807,t:1527268300850};\\\", \\\"{x:1300,y:800,t:1527268300868};\\\", \\\"{x:1303,y:799,t:1527268300884};\\\", \\\"{x:1305,y:797,t:1527268300900};\\\", \\\"{x:1306,y:796,t:1527268300917};\\\", \\\"{x:1308,y:794,t:1527268300935};\\\", \\\"{x:1314,y:792,t:1527268300951};\\\", \\\"{x:1321,y:788,t:1527268300967};\\\", \\\"{x:1324,y:786,t:1527268300985};\\\", \\\"{x:1324,y:785,t:1527268301001};\\\", \\\"{x:1326,y:785,t:1527268301059};\\\", \\\"{x:1327,y:785,t:1527268301067};\\\", \\\"{x:1336,y:779,t:1527268301084};\\\", \\\"{x:1340,y:777,t:1527268301102};\\\", \\\"{x:1340,y:782,t:1527268301315};\\\", \\\"{x:1341,y:791,t:1527268301324};\\\", \\\"{x:1342,y:800,t:1527268301334};\\\", \\\"{x:1346,y:813,t:1527268301351};\\\", \\\"{x:1349,y:822,t:1527268301367};\\\", \\\"{x:1350,y:825,t:1527268301384};\\\", \\\"{x:1351,y:831,t:1527268301402};\\\", \\\"{x:1354,y:840,t:1527268301417};\\\", \\\"{x:1359,y:850,t:1527268301435};\\\", \\\"{x:1362,y:858,t:1527268301452};\\\", \\\"{x:1362,y:859,t:1527268301468};\\\", \\\"{x:1363,y:859,t:1527268301485};\\\", \\\"{x:1365,y:863,t:1527268301501};\\\", \\\"{x:1367,y:865,t:1527268301518};\\\", \\\"{x:1369,y:868,t:1527268301535};\\\", \\\"{x:1372,y:869,t:1527268301552};\\\", \\\"{x:1374,y:871,t:1527268301568};\\\", \\\"{x:1377,y:874,t:1527268301584};\\\", \\\"{x:1380,y:878,t:1527268301602};\\\", \\\"{x:1381,y:880,t:1527268301619};\\\", \\\"{x:1383,y:883,t:1527268301635};\\\", \\\"{x:1383,y:884,t:1527268301676};\\\", \\\"{x:1384,y:886,t:1527268301700};\\\", \\\"{x:1384,y:887,t:1527268301716};\\\", \\\"{x:1384,y:888,t:1527268301724};\\\", \\\"{x:1384,y:889,t:1527268301756};\\\", \\\"{x:1384,y:890,t:1527268301780};\\\", \\\"{x:1384,y:891,t:1527268301788};\\\", \\\"{x:1386,y:893,t:1527268301803};\\\", \\\"{x:1387,y:896,t:1527268301819};\\\", \\\"{x:1387,y:898,t:1527268301835};\\\", \\\"{x:1387,y:899,t:1527268301860};\\\", \\\"{x:1382,y:871,t:1527268308333};\\\", \\\"{x:1366,y:845,t:1527268308340};\\\", \\\"{x:1330,y:785,t:1527268308357};\\\", \\\"{x:1290,y:722,t:1527268308373};\\\", \\\"{x:1264,y:685,t:1527268308390};\\\", \\\"{x:1253,y:670,t:1527268308407};\\\", \\\"{x:1251,y:666,t:1527268308423};\\\", \\\"{x:1251,y:665,t:1527268308507};\\\", \\\"{x:1258,y:661,t:1527268308523};\\\", \\\"{x:1267,y:661,t:1527268308540};\\\", \\\"{x:1275,y:663,t:1527268308558};\\\", \\\"{x:1290,y:674,t:1527268308573};\\\", \\\"{x:1303,y:690,t:1527268308590};\\\", \\\"{x:1311,y:706,t:1527268308608};\\\", \\\"{x:1316,y:720,t:1527268308623};\\\", \\\"{x:1319,y:726,t:1527268308640};\\\", \\\"{x:1320,y:731,t:1527268308657};\\\", \\\"{x:1320,y:733,t:1527268308673};\\\", \\\"{x:1320,y:735,t:1527268308691};\\\", \\\"{x:1320,y:738,t:1527268308707};\\\", \\\"{x:1321,y:740,t:1527268308788};\\\", \\\"{x:1321,y:742,t:1527268308796};\\\", \\\"{x:1322,y:745,t:1527268308807};\\\", \\\"{x:1322,y:746,t:1527268308824};\\\", \\\"{x:1324,y:749,t:1527268308840};\\\", \\\"{x:1326,y:750,t:1527268308858};\\\", \\\"{x:1332,y:753,t:1527268308874};\\\", \\\"{x:1333,y:753,t:1527268308891};\\\", \\\"{x:1334,y:753,t:1527268308924};\\\", \\\"{x:1336,y:753,t:1527268308940};\\\", \\\"{x:1337,y:753,t:1527268308958};\\\", \\\"{x:1338,y:753,t:1527268308974};\\\", \\\"{x:1339,y:753,t:1527268308996};\\\", \\\"{x:1340,y:753,t:1527268309007};\\\", \\\"{x:1341,y:752,t:1527268309025};\\\", \\\"{x:1343,y:752,t:1527268309041};\\\", \\\"{x:1342,y:753,t:1527268314992};\\\", \\\"{x:1336,y:755,t:1527268314996};\\\", \\\"{x:1333,y:759,t:1527268315011};\\\", \\\"{x:1331,y:764,t:1527268315028};\\\", \\\"{x:1330,y:764,t:1527268315044};\\\", \\\"{x:1330,y:765,t:1527268315061};\\\", \\\"{x:1330,y:767,t:1527268315309};\\\", \\\"{x:1333,y:768,t:1527268315316};\\\", \\\"{x:1335,y:768,t:1527268315328};\\\", \\\"{x:1337,y:769,t:1527268315346};\\\", \\\"{x:1340,y:769,t:1527268315361};\\\", \\\"{x:1351,y:772,t:1527268315378};\\\", \\\"{x:1391,y:772,t:1527268315395};\\\", \\\"{x:1428,y:772,t:1527268315411};\\\", \\\"{x:1481,y:772,t:1527268315428};\\\", \\\"{x:1538,y:770,t:1527268315446};\\\", \\\"{x:1568,y:765,t:1527268315462};\\\", \\\"{x:1579,y:764,t:1527268315479};\\\", \\\"{x:1580,y:764,t:1527268315580};\\\", \\\"{x:1582,y:764,t:1527268315603};\\\", \\\"{x:1583,y:766,t:1527268315620};\\\", \\\"{x:1584,y:768,t:1527268315628};\\\", \\\"{x:1588,y:773,t:1527268315646};\\\", \\\"{x:1591,y:777,t:1527268315663};\\\", \\\"{x:1593,y:781,t:1527268315679};\\\", \\\"{x:1598,y:788,t:1527268315695};\\\", \\\"{x:1606,y:793,t:1527268315713};\\\", \\\"{x:1612,y:795,t:1527268315728};\\\", \\\"{x:1617,y:798,t:1527268315745};\\\", \\\"{x:1618,y:799,t:1527268315762};\\\", \\\"{x:1620,y:800,t:1527268315779};\\\", \\\"{x:1623,y:801,t:1527268315795};\\\", \\\"{x:1625,y:804,t:1527268315813};\\\", \\\"{x:1625,y:805,t:1527268315924};\\\", \\\"{x:1622,y:808,t:1527268315932};\\\", \\\"{x:1617,y:810,t:1527268315946};\\\", \\\"{x:1581,y:818,t:1527268315964};\\\", \\\"{x:1565,y:820,t:1527268315979};\\\", \\\"{x:1512,y:832,t:1527268315996};\\\", \\\"{x:1484,y:837,t:1527268316013};\\\", \\\"{x:1464,y:839,t:1527268316030};\\\", \\\"{x:1450,y:840,t:1527268316046};\\\", \\\"{x:1444,y:840,t:1527268316063};\\\", \\\"{x:1442,y:840,t:1527268316132};\\\", \\\"{x:1442,y:839,t:1527268316372};\\\", \\\"{x:1441,y:838,t:1527268316413};\\\", \\\"{x:1437,y:835,t:1527268316621};\\\", \\\"{x:1434,y:834,t:1527268316637};\\\", \\\"{x:1433,y:834,t:1527268316647};\\\", \\\"{x:1432,y:834,t:1527268316662};\\\", \\\"{x:1431,y:834,t:1527268319469};\\\", \\\"{x:1431,y:836,t:1527268319482};\\\", \\\"{x:1430,y:841,t:1527268319499};\\\", \\\"{x:1430,y:843,t:1527268319515};\\\", \\\"{x:1430,y:844,t:1527268319532};\\\", \\\"{x:1430,y:846,t:1527268319549};\\\", \\\"{x:1430,y:847,t:1527268319573};\\\", \\\"{x:1428,y:849,t:1527268319582};\\\", \\\"{x:1428,y:851,t:1527268319599};\\\", \\\"{x:1427,y:853,t:1527268319615};\\\", \\\"{x:1425,y:855,t:1527268319632};\\\", \\\"{x:1424,y:856,t:1527268319649};\\\", \\\"{x:1423,y:859,t:1527268319665};\\\", \\\"{x:1420,y:863,t:1527268319683};\\\", \\\"{x:1417,y:865,t:1527268319699};\\\", \\\"{x:1416,y:867,t:1527268319715};\\\", \\\"{x:1414,y:870,t:1527268319733};\\\", \\\"{x:1411,y:873,t:1527268319749};\\\", \\\"{x:1407,y:876,t:1527268319764};\\\", \\\"{x:1404,y:878,t:1527268319782};\\\", \\\"{x:1403,y:879,t:1527268319798};\\\", \\\"{x:1400,y:880,t:1527268319814};\\\", \\\"{x:1400,y:881,t:1527268319972};\\\", \\\"{x:1399,y:882,t:1527268319982};\\\", \\\"{x:1398,y:883,t:1527268319999};\\\", \\\"{x:1396,y:884,t:1527268320015};\\\", \\\"{x:1393,y:887,t:1527268320032};\\\", \\\"{x:1392,y:888,t:1527268320048};\\\", \\\"{x:1391,y:889,t:1527268320066};\\\", \\\"{x:1390,y:890,t:1527268320125};\\\", \\\"{x:1390,y:892,t:1527268320228};\\\", \\\"{x:1389,y:892,t:1527268320261};\\\", \\\"{x:1389,y:893,t:1527268320388};\\\", \\\"{x:1387,y:893,t:1527268322324};\\\", \\\"{x:1377,y:890,t:1527268322335};\\\", \\\"{x:1325,y:873,t:1527268322352};\\\", \\\"{x:1242,y:860,t:1527268322367};\\\", \\\"{x:1142,y:846,t:1527268322383};\\\", \\\"{x:1033,y:840,t:1527268322400};\\\", \\\"{x:970,y:836,t:1527268322417};\\\", \\\"{x:962,y:836,t:1527268322433};\\\", \\\"{x:962,y:835,t:1527268322507};\\\", \\\"{x:963,y:834,t:1527268322516};\\\", \\\"{x:991,y:834,t:1527268322533};\\\", \\\"{x:1021,y:833,t:1527268322551};\\\", \\\"{x:1044,y:828,t:1527268322567};\\\", \\\"{x:1069,y:827,t:1527268322584};\\\", \\\"{x:1079,y:826,t:1527268322601};\\\", \\\"{x:1081,y:826,t:1527268322617};\\\", \\\"{x:1085,y:826,t:1527268322634};\\\", \\\"{x:1093,y:826,t:1527268322651};\\\", \\\"{x:1110,y:826,t:1527268322666};\\\", \\\"{x:1127,y:826,t:1527268322684};\\\", \\\"{x:1132,y:826,t:1527268322701};\\\", \\\"{x:1133,y:826,t:1527268322724};\\\", \\\"{x:1135,y:826,t:1527268322734};\\\", \\\"{x:1146,y:828,t:1527268322751};\\\", \\\"{x:1160,y:828,t:1527268322766};\\\", \\\"{x:1169,y:828,t:1527268322784};\\\", \\\"{x:1172,y:828,t:1527268322801};\\\", \\\"{x:1175,y:828,t:1527268323077};\\\", \\\"{x:1181,y:828,t:1527268323085};\\\", \\\"{x:1192,y:828,t:1527268323101};\\\", \\\"{x:1199,y:828,t:1527268323118};\\\", \\\"{x:1202,y:828,t:1527268323135};\\\", \\\"{x:1204,y:828,t:1527268323151};\\\", \\\"{x:1203,y:828,t:1527268327312};\\\", \\\"{x:1211,y:825,t:1527268327325};\\\", \\\"{x:1252,y:818,t:1527268327342};\\\", \\\"{x:1298,y:809,t:1527268327358};\\\", \\\"{x:1336,y:801,t:1527268327374};\\\", \\\"{x:1354,y:797,t:1527268327391};\\\", \\\"{x:1355,y:797,t:1527268327407};\\\", \\\"{x:1354,y:797,t:1527268327527};\\\", \\\"{x:1350,y:797,t:1527268327540};\\\", \\\"{x:1337,y:797,t:1527268327557};\\\", \\\"{x:1331,y:798,t:1527268327574};\\\", \\\"{x:1328,y:798,t:1527268327591};\\\", \\\"{x:1327,y:798,t:1527268327607};\\\", \\\"{x:1321,y:798,t:1527268327624};\\\", \\\"{x:1316,y:801,t:1527268327640};\\\", \\\"{x:1312,y:801,t:1527268327657};\\\", \\\"{x:1308,y:803,t:1527268327674};\\\", \\\"{x:1304,y:804,t:1527268327691};\\\", \\\"{x:1302,y:804,t:1527268327707};\\\", \\\"{x:1300,y:805,t:1527268327724};\\\", \\\"{x:1299,y:805,t:1527268327741};\\\", \\\"{x:1295,y:806,t:1527268327757};\\\", \\\"{x:1289,y:806,t:1527268327774};\\\", \\\"{x:1275,y:809,t:1527268327790};\\\", \\\"{x:1270,y:809,t:1527268327808};\\\", \\\"{x:1267,y:810,t:1527268327824};\\\", \\\"{x:1266,y:810,t:1527268327855};\\\", \\\"{x:1264,y:810,t:1527268327871};\\\", \\\"{x:1263,y:810,t:1527268327879};\\\", \\\"{x:1259,y:810,t:1527268327892};\\\", \\\"{x:1252,y:811,t:1527268327907};\\\", \\\"{x:1243,y:813,t:1527268327925};\\\", \\\"{x:1233,y:814,t:1527268327942};\\\", \\\"{x:1226,y:815,t:1527268327957};\\\", \\\"{x:1220,y:818,t:1527268327974};\\\", \\\"{x:1217,y:818,t:1527268327991};\\\", \\\"{x:1215,y:818,t:1527268328136};\\\", \\\"{x:1213,y:818,t:1527268328151};\\\", \\\"{x:1210,y:820,t:1527268328158};\\\", \\\"{x:1208,y:821,t:1527268328174};\\\", \\\"{x:1203,y:825,t:1527268328191};\\\", \\\"{x:1203,y:826,t:1527268328208};\\\", \\\"{x:1219,y:826,t:1527268329990};\\\", \\\"{x:1283,y:826,t:1527268330009};\\\", \\\"{x:1356,y:826,t:1527268330025};\\\", \\\"{x:1415,y:823,t:1527268330041};\\\", \\\"{x:1477,y:813,t:1527268330059};\\\", \\\"{x:1510,y:808,t:1527268330076};\\\", \\\"{x:1527,y:806,t:1527268330092};\\\", \\\"{x:1532,y:806,t:1527268330109};\\\", \\\"{x:1534,y:806,t:1527268330125};\\\", \\\"{x:1535,y:806,t:1527268330150};\\\", \\\"{x:1539,y:806,t:1527268330159};\\\", \\\"{x:1552,y:806,t:1527268330175};\\\", \\\"{x:1564,y:808,t:1527268330191};\\\", \\\"{x:1571,y:808,t:1527268330209};\\\", \\\"{x:1581,y:808,t:1527268330226};\\\", \\\"{x:1599,y:808,t:1527268330242};\\\", \\\"{x:1619,y:808,t:1527268330259};\\\", \\\"{x:1633,y:808,t:1527268330275};\\\", \\\"{x:1649,y:806,t:1527268330292};\\\", \\\"{x:1659,y:804,t:1527268330309};\\\", \\\"{x:1663,y:803,t:1527268330326};\\\", \\\"{x:1665,y:803,t:1527268330350};\\\", \\\"{x:1666,y:803,t:1527268330390};\\\", \\\"{x:1667,y:803,t:1527268330398};\\\", \\\"{x:1669,y:803,t:1527268330408};\\\", \\\"{x:1677,y:805,t:1527268330426};\\\", \\\"{x:1680,y:807,t:1527268330442};\\\", \\\"{x:1681,y:808,t:1527268330459};\\\", \\\"{x:1684,y:810,t:1527268330476};\\\", \\\"{x:1691,y:812,t:1527268330492};\\\", \\\"{x:1697,y:815,t:1527268330509};\\\", \\\"{x:1697,y:816,t:1527268330527};\\\", \\\"{x:1698,y:817,t:1527268330623};\\\", \\\"{x:1698,y:818,t:1527268330638};\\\", \\\"{x:1695,y:819,t:1527268330646};\\\", \\\"{x:1692,y:820,t:1527268330659};\\\", \\\"{x:1690,y:822,t:1527268330676};\\\", \\\"{x:1687,y:822,t:1527268330693};\\\", \\\"{x:1684,y:824,t:1527268330710};\\\", \\\"{x:1679,y:829,t:1527268330727};\\\", \\\"{x:1677,y:830,t:1527268330742};\\\", \\\"{x:1674,y:832,t:1527268330760};\\\", \\\"{x:1672,y:833,t:1527268330776};\\\", \\\"{x:1670,y:833,t:1527268330792};\\\", \\\"{x:1669,y:833,t:1527268330809};\\\", \\\"{x:1668,y:834,t:1527268330830};\\\", \\\"{x:1667,y:834,t:1527268331158};\\\", \\\"{x:1667,y:833,t:1527268331246};\\\", \\\"{x:1668,y:833,t:1527268331260};\\\", \\\"{x:1669,y:832,t:1527268331278};\\\", \\\"{x:1671,y:832,t:1527268331326};\\\", \\\"{x:1672,y:831,t:1527268331343};\\\", \\\"{x:1674,y:830,t:1527268331360};\\\", \\\"{x:1675,y:830,t:1527268331439};\\\", \\\"{x:1675,y:829,t:1527268336463};\\\", \\\"{x:1674,y:828,t:1527268338654};\\\", \\\"{x:1672,y:828,t:1527268338664};\\\", \\\"{x:1670,y:826,t:1527268338798};\\\", \\\"{x:1664,y:825,t:1527268338815};\\\", \\\"{x:1660,y:822,t:1527268338833};\\\", \\\"{x:1657,y:821,t:1527268338849};\\\", \\\"{x:1653,y:820,t:1527268338865};\\\", \\\"{x:1648,y:818,t:1527268338882};\\\", \\\"{x:1629,y:818,t:1527268338898};\\\", \\\"{x:1593,y:818,t:1527268338915};\\\", \\\"{x:1515,y:818,t:1527268338932};\\\", \\\"{x:1399,y:818,t:1527268338949};\\\", \\\"{x:1270,y:828,t:1527268338965};\\\", \\\"{x:1063,y:843,t:1527268338981};\\\", \\\"{x:922,y:845,t:1527268338998};\\\", \\\"{x:779,y:853,t:1527268339015};\\\", \\\"{x:651,y:862,t:1527268339032};\\\", \\\"{x:539,y:866,t:1527268339048};\\\", \\\"{x:451,y:873,t:1527268339065};\\\", \\\"{x:393,y:880,t:1527268339082};\\\", \\\"{x:354,y:880,t:1527268339098};\\\", \\\"{x:315,y:880,t:1527268339115};\\\", \\\"{x:275,y:880,t:1527268339132};\\\", \\\"{x:236,y:880,t:1527268339149};\\\", \\\"{x:195,y:878,t:1527268339165};\\\", \\\"{x:141,y:870,t:1527268339182};\\\", \\\"{x:103,y:863,t:1527268339198};\\\", \\\"{x:102,y:863,t:1527268339215};\\\", \\\"{x:100,y:861,t:1527268339727};\\\", \\\"{x:99,y:861,t:1527268339925};\\\", \\\"{x:95,y:861,t:1527268339934};\\\", \\\"{x:88,y:858,t:1527268339949};\\\", \\\"{x:64,y:853,t:1527268339966};\\\", \\\"{x:61,y:853,t:1527268339982};\\\", \\\"{x:61,y:852,t:1527268340279};\\\", \\\"{x:62,y:852,t:1527268340295};\\\", \\\"{x:62,y:851,t:1527268340462};\\\", \\\"{x:62,y:848,t:1527268340639};\\\", \\\"{x:61,y:847,t:1527268340650};\\\", \\\"{x:59,y:845,t:1527268340667};\\\", \\\"{x:57,y:843,t:1527268340684};\\\", \\\"{x:55,y:841,t:1527268340701};\\\", \\\"{x:52,y:838,t:1527268340716};\\\", \\\"{x:51,y:838,t:1527268340911};\\\", \\\"{x:57,y:833,t:1527268340919};\\\", \\\"{x:72,y:826,t:1527268340934};\\\", \\\"{x:115,y:802,t:1527268340951};\\\", \\\"{x:164,y:783,t:1527268340966};\\\", \\\"{x:226,y:762,t:1527268340983};\\\", \\\"{x:295,y:745,t:1527268341000};\\\", \\\"{x:369,y:727,t:1527268341016};\\\", \\\"{x:447,y:706,t:1527268341034};\\\", \\\"{x:529,y:688,t:1527268341051};\\\", \\\"{x:598,y:670,t:1527268341066};\\\", \\\"{x:646,y:654,t:1527268341084};\\\", \\\"{x:673,y:649,t:1527268341101};\\\", \\\"{x:683,y:648,t:1527268341116};\\\", \\\"{x:685,y:648,t:1527268341134};\\\", \\\"{x:685,y:647,t:1527268341247};\\\", \\\"{x:682,y:646,t:1527268341254};\\\", \\\"{x:679,y:644,t:1527268341267};\\\", \\\"{x:670,y:639,t:1527268341284};\\\", \\\"{x:656,y:625,t:1527268341302};\\\", \\\"{x:638,y:604,t:1527268341318};\\\", \\\"{x:612,y:574,t:1527268341334};\\\", \\\"{x:574,y:537,t:1527268341355};\\\", \\\"{x:558,y:520,t:1527268341371};\\\", \\\"{x:553,y:514,t:1527268341388};\\\", \\\"{x:552,y:512,t:1527268341404};\\\", \\\"{x:551,y:512,t:1527268341454};\\\", \\\"{x:543,y:512,t:1527268341471};\\\", \\\"{x:527,y:515,t:1527268341488};\\\", \\\"{x:516,y:516,t:1527268341504};\\\", \\\"{x:502,y:521,t:1527268341522};\\\", \\\"{x:485,y:526,t:1527268341538};\\\", \\\"{x:468,y:530,t:1527268341555};\\\", \\\"{x:448,y:537,t:1527268341571};\\\", \\\"{x:425,y:543,t:1527268341588};\\\", \\\"{x:404,y:549,t:1527268341605};\\\", \\\"{x:389,y:554,t:1527268341621};\\\", \\\"{x:375,y:557,t:1527268341638};\\\", \\\"{x:374,y:558,t:1527268341654};\\\", \\\"{x:372,y:559,t:1527268341718};\\\", \\\"{x:368,y:560,t:1527268341725};\\\", \\\"{x:367,y:562,t:1527268341738};\\\", \\\"{x:361,y:563,t:1527268341755};\\\", \\\"{x:357,y:566,t:1527268341772};\\\", \\\"{x:354,y:566,t:1527268341788};\\\", \\\"{x:354,y:567,t:1527268341838};\\\", \\\"{x:346,y:570,t:1527268341854};\\\", \\\"{x:331,y:572,t:1527268341871};\\\", \\\"{x:308,y:575,t:1527268341888};\\\", \\\"{x:269,y:576,t:1527268341906};\\\", \\\"{x:216,y:576,t:1527268341921};\\\", \\\"{x:163,y:576,t:1527268341939};\\\", \\\"{x:131,y:576,t:1527268341956};\\\", \\\"{x:116,y:576,t:1527268341971};\\\", \\\"{x:115,y:576,t:1527268341988};\\\", \\\"{x:116,y:576,t:1527268342102};\\\", \\\"{x:122,y:576,t:1527268342110};\\\", \\\"{x:128,y:576,t:1527268342121};\\\", \\\"{x:139,y:576,t:1527268342138};\\\", \\\"{x:157,y:576,t:1527268342156};\\\", \\\"{x:173,y:576,t:1527268342172};\\\", \\\"{x:177,y:576,t:1527268342188};\\\", \\\"{x:178,y:576,t:1527268342206};\\\", \\\"{x:178,y:577,t:1527268342253};\\\", \\\"{x:178,y:579,t:1527268342366};\\\", \\\"{x:177,y:582,t:1527268342373};\\\", \\\"{x:177,y:584,t:1527268342388};\\\", \\\"{x:175,y:591,t:1527268342405};\\\", \\\"{x:171,y:596,t:1527268342421};\\\", \\\"{x:167,y:605,t:1527268342439};\\\", \\\"{x:166,y:611,t:1527268342455};\\\", \\\"{x:165,y:614,t:1527268342472};\\\", \\\"{x:165,y:617,t:1527268342488};\\\", \\\"{x:165,y:619,t:1527268342505};\\\", \\\"{x:164,y:621,t:1527268342523};\\\", \\\"{x:163,y:627,t:1527268342863};\\\", \\\"{x:163,y:632,t:1527268342874};\\\", \\\"{x:160,y:638,t:1527268342888};\\\", \\\"{x:160,y:641,t:1527268342905};\\\", \\\"{x:159,y:641,t:1527268342921};\\\", \\\"{x:159,y:642,t:1527268343096};\\\", \\\"{x:157,y:644,t:1527268343111};\\\", \\\"{x:167,y:641,t:1527268343424};\\\", \\\"{x:204,y:625,t:1527268343440};\\\", \\\"{x:232,y:618,t:1527268343457};\\\", \\\"{x:278,y:609,t:1527268343473};\\\", \\\"{x:327,y:604,t:1527268343489};\\\", \\\"{x:386,y:596,t:1527268343507};\\\", \\\"{x:449,y:591,t:1527268343523};\\\", \\\"{x:497,y:583,t:1527268343539};\\\", \\\"{x:550,y:567,t:1527268343557};\\\", \\\"{x:588,y:558,t:1527268343573};\\\", \\\"{x:617,y:549,t:1527268343590};\\\", \\\"{x:643,y:543,t:1527268343606};\\\", \\\"{x:647,y:541,t:1527268343622};\\\", \\\"{x:649,y:540,t:1527268343639};\\\", \\\"{x:657,y:536,t:1527268343656};\\\", \\\"{x:663,y:535,t:1527268343672};\\\", \\\"{x:670,y:531,t:1527268343689};\\\", \\\"{x:674,y:530,t:1527268343706};\\\", \\\"{x:676,y:528,t:1527268343723};\\\", \\\"{x:682,y:525,t:1527268343740};\\\", \\\"{x:683,y:524,t:1527268343756};\\\", \\\"{x:682,y:524,t:1527268343814};\\\", \\\"{x:673,y:524,t:1527268343823};\\\", \\\"{x:655,y:525,t:1527268343840};\\\", \\\"{x:634,y:531,t:1527268343857};\\\", \\\"{x:592,y:542,t:1527268343874};\\\", \\\"{x:553,y:555,t:1527268343890};\\\", \\\"{x:521,y:566,t:1527268343907};\\\", \\\"{x:502,y:573,t:1527268343924};\\\", \\\"{x:490,y:577,t:1527268343940};\\\", \\\"{x:477,y:579,t:1527268343956};\\\", \\\"{x:472,y:581,t:1527268343973};\\\", \\\"{x:467,y:582,t:1527268343989};\\\", \\\"{x:461,y:584,t:1527268344007};\\\", \\\"{x:458,y:585,t:1527268344024};\\\", \\\"{x:443,y:586,t:1527268344039};\\\", \\\"{x:426,y:593,t:1527268344057};\\\", \\\"{x:410,y:599,t:1527268344074};\\\", \\\"{x:403,y:603,t:1527268344090};\\\", \\\"{x:398,y:607,t:1527268344107};\\\", \\\"{x:395,y:612,t:1527268344124};\\\", \\\"{x:394,y:614,t:1527268344140};\\\", \\\"{x:391,y:619,t:1527268344156};\\\", \\\"{x:391,y:620,t:1527268344173};\\\", \\\"{x:389,y:625,t:1527268344190};\\\", \\\"{x:388,y:630,t:1527268344207};\\\", \\\"{x:386,y:637,t:1527268344225};\\\", \\\"{x:385,y:647,t:1527268344242};\\\", \\\"{x:385,y:651,t:1527268344256};\\\", \\\"{x:385,y:652,t:1527268344581};\\\", \\\"{x:391,y:656,t:1527268344589};\\\", \\\"{x:407,y:664,t:1527268344606};\\\", \\\"{x:431,y:673,t:1527268344624};\\\", \\\"{x:464,y:688,t:1527268344641};\\\", \\\"{x:485,y:697,t:1527268344657};\\\", \\\"{x:492,y:700,t:1527268344674};\\\", \\\"{x:495,y:701,t:1527268344691};\\\", \\\"{x:498,y:703,t:1527268344707};\\\", \\\"{x:500,y:705,t:1527268344724};\\\", \\\"{x:503,y:708,t:1527268344740};\\\", \\\"{x:510,y:713,t:1527268344757};\\\", \\\"{x:517,y:720,t:1527268344774};\\\", \\\"{x:524,y:724,t:1527268344791};\\\", \\\"{x:527,y:727,t:1527268344807};\\\", \\\"{x:528,y:728,t:1527268344824};\\\", \\\"{x:530,y:730,t:1527268344841};\\\", \\\"{x:531,y:731,t:1527268344857};\\\", \\\"{x:532,y:732,t:1527268344873};\\\", \\\"{x:533,y:733,t:1527268344975};\\\", \\\"{x:535,y:733,t:1527268344991};\\\", \\\"{x:536,y:733,t:1527268345695};\\\" ] }, { \\\"rt\\\": 33921, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 415837, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -L -L -O -L -X -M -M -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:535,y:729,t:1527268347183};\\\", \\\"{x:526,y:710,t:1527268347194};\\\", \\\"{x:498,y:675,t:1527268347209};\\\", \\\"{x:474,y:652,t:1527268347226};\\\", \\\"{x:449,y:631,t:1527268347243};\\\", \\\"{x:434,y:623,t:1527268347260};\\\", \\\"{x:429,y:621,t:1527268347276};\\\", \\\"{x:428,y:621,t:1527268347293};\\\", \\\"{x:428,y:619,t:1527268347333};\\\", \\\"{x:420,y:611,t:1527268347343};\\\", \\\"{x:398,y:588,t:1527268347360};\\\", \\\"{x:375,y:568,t:1527268347376};\\\", \\\"{x:356,y:552,t:1527268347393};\\\", \\\"{x:334,y:536,t:1527268347409};\\\", \\\"{x:316,y:524,t:1527268347426};\\\", \\\"{x:305,y:516,t:1527268347443};\\\", \\\"{x:301,y:510,t:1527268347460};\\\", \\\"{x:299,y:506,t:1527268347475};\\\", \\\"{x:299,y:505,t:1527268347493};\\\", \\\"{x:305,y:495,t:1527268347510};\\\", \\\"{x:317,y:489,t:1527268347526};\\\", \\\"{x:334,y:482,t:1527268347543};\\\", \\\"{x:354,y:472,t:1527268347560};\\\", \\\"{x:380,y:461,t:1527268347577};\\\", \\\"{x:393,y:455,t:1527268347593};\\\", \\\"{x:398,y:453,t:1527268347609};\\\", \\\"{x:400,y:453,t:1527268347627};\\\", \\\"{x:400,y:452,t:1527268347646};\\\", \\\"{x:402,y:452,t:1527268347660};\\\", \\\"{x:404,y:452,t:1527268347677};\\\", \\\"{x:411,y:452,t:1527268347693};\\\", \\\"{x:421,y:452,t:1527268347710};\\\", \\\"{x:430,y:452,t:1527268347726};\\\", \\\"{x:436,y:452,t:1527268347743};\\\", \\\"{x:445,y:452,t:1527268347760};\\\", \\\"{x:458,y:453,t:1527268347777};\\\", \\\"{x:475,y:458,t:1527268347794};\\\", \\\"{x:489,y:461,t:1527268347810};\\\", \\\"{x:498,y:463,t:1527268347827};\\\", \\\"{x:502,y:463,t:1527268347844};\\\", \\\"{x:504,y:463,t:1527268347860};\\\", \\\"{x:505,y:463,t:1527268347894};\\\", \\\"{x:508,y:463,t:1527268347934};\\\", \\\"{x:511,y:464,t:1527268347944};\\\", \\\"{x:523,y:466,t:1527268347962};\\\", \\\"{x:541,y:469,t:1527268347977};\\\", \\\"{x:559,y:470,t:1527268347995};\\\", \\\"{x:579,y:471,t:1527268348011};\\\", \\\"{x:596,y:471,t:1527268348028};\\\", \\\"{x:606,y:471,t:1527268348044};\\\", \\\"{x:612,y:471,t:1527268348061};\\\", \\\"{x:613,y:471,t:1527268348080};\\\", \\\"{x:615,y:471,t:1527268349487};\\\", \\\"{x:621,y:476,t:1527268349497};\\\", \\\"{x:648,y:480,t:1527268349514};\\\", \\\"{x:696,y:488,t:1527268349532};\\\", \\\"{x:752,y:496,t:1527268349548};\\\", \\\"{x:816,y:504,t:1527268349563};\\\", \\\"{x:906,y:519,t:1527268349578};\\\", \\\"{x:1016,y:534,t:1527268349595};\\\", \\\"{x:1121,y:543,t:1527268349611};\\\", \\\"{x:1236,y:553,t:1527268349628};\\\", \\\"{x:1347,y:553,t:1527268349644};\\\", \\\"{x:1469,y:553,t:1527268349661};\\\", \\\"{x:1640,y:564,t:1527268349678};\\\", \\\"{x:1720,y:564,t:1527268349694};\\\", \\\"{x:1787,y:565,t:1527268349710};\\\", \\\"{x:1834,y:568,t:1527268349728};\\\", \\\"{x:1868,y:572,t:1527268349744};\\\", \\\"{x:1889,y:577,t:1527268349761};\\\", \\\"{x:1899,y:582,t:1527268349778};\\\", \\\"{x:1902,y:584,t:1527268349795};\\\", \\\"{x:1905,y:587,t:1527268349811};\\\", \\\"{x:1906,y:588,t:1527268349827};\\\", \\\"{x:1908,y:591,t:1527268349845};\\\", \\\"{x:1910,y:595,t:1527268349862};\\\", \\\"{x:1914,y:609,t:1527268349878};\\\", \\\"{x:1919,y:626,t:1527268349895};\\\", \\\"{x:1919,y:631,t:1527268349911};\\\", \\\"{x:1919,y:633,t:1527268349929};\\\", \\\"{x:1919,y:637,t:1527268349945};\\\", \\\"{x:1919,y:638,t:1527268349962};\\\", \\\"{x:1919,y:639,t:1527268349979};\\\", \\\"{x:1919,y:642,t:1527268349996};\\\", \\\"{x:1919,y:644,t:1527268350012};\\\", \\\"{x:1912,y:646,t:1527268350028};\\\", \\\"{x:1892,y:646,t:1527268350046};\\\", \\\"{x:1877,y:640,t:1527268350062};\\\", \\\"{x:1850,y:634,t:1527268350078};\\\", \\\"{x:1799,y:626,t:1527268350095};\\\", \\\"{x:1704,y:606,t:1527268350112};\\\", \\\"{x:1583,y:577,t:1527268350127};\\\", \\\"{x:1470,y:551,t:1527268350145};\\\", \\\"{x:1397,y:538,t:1527268350162};\\\", \\\"{x:1381,y:537,t:1527268350178};\\\", \\\"{x:1373,y:536,t:1527268350195};\\\", \\\"{x:1371,y:536,t:1527268350212};\\\", \\\"{x:1369,y:535,t:1527268350228};\\\", \\\"{x:1367,y:534,t:1527268350245};\\\", \\\"{x:1366,y:533,t:1527268350270};\\\", \\\"{x:1367,y:533,t:1527268350367};\\\", \\\"{x:1375,y:532,t:1527268350379};\\\", \\\"{x:1387,y:532,t:1527268350394};\\\", \\\"{x:1392,y:532,t:1527268350411};\\\", \\\"{x:1396,y:534,t:1527268350429};\\\", \\\"{x:1399,y:535,t:1527268350445};\\\", \\\"{x:1400,y:537,t:1527268350462};\\\", \\\"{x:1400,y:540,t:1527268350502};\\\", \\\"{x:1401,y:544,t:1527268350512};\\\", \\\"{x:1401,y:549,t:1527268350529};\\\", \\\"{x:1401,y:557,t:1527268350545};\\\", \\\"{x:1401,y:560,t:1527268350562};\\\", \\\"{x:1401,y:561,t:1527268350579};\\\", \\\"{x:1405,y:560,t:1527268350639};\\\", \\\"{x:1415,y:557,t:1527268350647};\\\", \\\"{x:1442,y:540,t:1527268350664};\\\", \\\"{x:1470,y:516,t:1527268350679};\\\", \\\"{x:1494,y:494,t:1527268350695};\\\", \\\"{x:1512,y:476,t:1527268350712};\\\", \\\"{x:1523,y:462,t:1527268350729};\\\", \\\"{x:1523,y:459,t:1527268350745};\\\", \\\"{x:1525,y:458,t:1527268350896};\\\", \\\"{x:1543,y:466,t:1527268350912};\\\", \\\"{x:1559,y:477,t:1527268350930};\\\", \\\"{x:1569,y:482,t:1527268350946};\\\", \\\"{x:1576,y:488,t:1527268350962};\\\", \\\"{x:1578,y:490,t:1527268350979};\\\", \\\"{x:1578,y:492,t:1527268351098};\\\", \\\"{x:1578,y:499,t:1527268351111};\\\", \\\"{x:1576,y:502,t:1527268351129};\\\", \\\"{x:1572,y:510,t:1527268351146};\\\", \\\"{x:1572,y:514,t:1527268351162};\\\", \\\"{x:1570,y:521,t:1527268351179};\\\", \\\"{x:1570,y:530,t:1527268351196};\\\", \\\"{x:1570,y:538,t:1527268351212};\\\", \\\"{x:1570,y:545,t:1527268351228};\\\", \\\"{x:1570,y:561,t:1527268351246};\\\", \\\"{x:1570,y:570,t:1527268351261};\\\", \\\"{x:1570,y:579,t:1527268351279};\\\", \\\"{x:1570,y:587,t:1527268351296};\\\", \\\"{x:1572,y:595,t:1527268351312};\\\", \\\"{x:1572,y:604,t:1527268351329};\\\", \\\"{x:1572,y:612,t:1527268351345};\\\", \\\"{x:1572,y:620,t:1527268351363};\\\", \\\"{x:1572,y:630,t:1527268351379};\\\", \\\"{x:1572,y:643,t:1527268351396};\\\", \\\"{x:1573,y:653,t:1527268351413};\\\", \\\"{x:1574,y:665,t:1527268351429};\\\", \\\"{x:1574,y:685,t:1527268351446};\\\", \\\"{x:1574,y:689,t:1527268351463};\\\", \\\"{x:1574,y:695,t:1527268351479};\\\", \\\"{x:1574,y:697,t:1527268351496};\\\", \\\"{x:1574,y:698,t:1527268351518};\\\", \\\"{x:1574,y:699,t:1527268351529};\\\", \\\"{x:1572,y:704,t:1527268351546};\\\", \\\"{x:1569,y:711,t:1527268351562};\\\", \\\"{x:1568,y:712,t:1527268351694};\\\", \\\"{x:1567,y:714,t:1527268351702};\\\", \\\"{x:1564,y:721,t:1527268351713};\\\", \\\"{x:1554,y:733,t:1527268351729};\\\", \\\"{x:1544,y:743,t:1527268351746};\\\", \\\"{x:1536,y:752,t:1527268351763};\\\", \\\"{x:1515,y:765,t:1527268351781};\\\", \\\"{x:1496,y:776,t:1527268351797};\\\", \\\"{x:1476,y:785,t:1527268351813};\\\", \\\"{x:1451,y:793,t:1527268351830};\\\", \\\"{x:1440,y:796,t:1527268351846};\\\", \\\"{x:1432,y:797,t:1527268351863};\\\", \\\"{x:1425,y:797,t:1527268351880};\\\", \\\"{x:1415,y:797,t:1527268351896};\\\", \\\"{x:1397,y:795,t:1527268351913};\\\", \\\"{x:1379,y:793,t:1527268351930};\\\", \\\"{x:1358,y:793,t:1527268351946};\\\", \\\"{x:1337,y:793,t:1527268351963};\\\", \\\"{x:1310,y:793,t:1527268351980};\\\", \\\"{x:1286,y:793,t:1527268351996};\\\", \\\"{x:1271,y:792,t:1527268352013};\\\", \\\"{x:1254,y:791,t:1527268352030};\\\", \\\"{x:1249,y:790,t:1527268352046};\\\", \\\"{x:1248,y:789,t:1527268352063};\\\", \\\"{x:1246,y:789,t:1527268352302};\\\", \\\"{x:1241,y:791,t:1527268352313};\\\", \\\"{x:1232,y:796,t:1527268352329};\\\", \\\"{x:1216,y:803,t:1527268352347};\\\", \\\"{x:1200,y:807,t:1527268352363};\\\", \\\"{x:1189,y:811,t:1527268352379};\\\", \\\"{x:1185,y:811,t:1527268352397};\\\", \\\"{x:1185,y:812,t:1527268352454};\\\", \\\"{x:1185,y:813,t:1527268352471};\\\", \\\"{x:1185,y:818,t:1527268352480};\\\", \\\"{x:1185,y:825,t:1527268352497};\\\", \\\"{x:1183,y:829,t:1527268352513};\\\", \\\"{x:1183,y:830,t:1527268352530};\\\", \\\"{x:1183,y:832,t:1527268352575};\\\", \\\"{x:1184,y:833,t:1527268352582};\\\", \\\"{x:1186,y:833,t:1527268352597};\\\", \\\"{x:1189,y:834,t:1527268352614};\\\", \\\"{x:1190,y:834,t:1527268352630};\\\", \\\"{x:1190,y:835,t:1527268352647};\\\", \\\"{x:1191,y:835,t:1527268352670};\\\", \\\"{x:1195,y:835,t:1527268352693};\\\", \\\"{x:1199,y:836,t:1527268352701};\\\", \\\"{x:1205,y:837,t:1527268352714};\\\", \\\"{x:1210,y:837,t:1527268352730};\\\", \\\"{x:1213,y:838,t:1527268352747};\\\", \\\"{x:1208,y:835,t:1527268367135};\\\", \\\"{x:1198,y:831,t:1527268367142};\\\", \\\"{x:1186,y:824,t:1527268367159};\\\", \\\"{x:1181,y:821,t:1527268367175};\\\", \\\"{x:1181,y:820,t:1527268367239};\\\", \\\"{x:1180,y:820,t:1527268367247};\\\", \\\"{x:1186,y:815,t:1527268367270};\\\", \\\"{x:1199,y:809,t:1527268367278};\\\", \\\"{x:1217,y:804,t:1527268367291};\\\", \\\"{x:1277,y:790,t:1527268367308};\\\", \\\"{x:1352,y:769,t:1527268367325};\\\", \\\"{x:1510,y:739,t:1527268367342};\\\", \\\"{x:1635,y:722,t:1527268367359};\\\", \\\"{x:1741,y:706,t:1527268367376};\\\", \\\"{x:1825,y:691,t:1527268367391};\\\", \\\"{x:1887,y:688,t:1527268367409};\\\", \\\"{x:1919,y:688,t:1527268367426};\\\", \\\"{x:1919,y:690,t:1527268367446};\\\", \\\"{x:1917,y:691,t:1527268367623};\\\", \\\"{x:1899,y:691,t:1527268367638};\\\", \\\"{x:1763,y:678,t:1527268367654};\\\", \\\"{x:1642,y:670,t:1527268367676};\\\", \\\"{x:1548,y:670,t:1527268367692};\\\", \\\"{x:1502,y:673,t:1527268367708};\\\", \\\"{x:1474,y:683,t:1527268367726};\\\", \\\"{x:1470,y:684,t:1527268367742};\\\", \\\"{x:1469,y:684,t:1527268367765};\\\", \\\"{x:1468,y:684,t:1527268367781};\\\", \\\"{x:1466,y:684,t:1527268367793};\\\", \\\"{x:1457,y:682,t:1527268367808};\\\", \\\"{x:1447,y:680,t:1527268367826};\\\", \\\"{x:1439,y:679,t:1527268367842};\\\", \\\"{x:1437,y:678,t:1527268367859};\\\", \\\"{x:1437,y:677,t:1527268367879};\\\", \\\"{x:1436,y:673,t:1527268367893};\\\", \\\"{x:1431,y:658,t:1527268367909};\\\", \\\"{x:1436,y:624,t:1527268367926};\\\", \\\"{x:1476,y:580,t:1527268367943};\\\", \\\"{x:1539,y:528,t:1527268367959};\\\", \\\"{x:1593,y:488,t:1527268367976};\\\", \\\"{x:1612,y:467,t:1527268367993};\\\", \\\"{x:1632,y:455,t:1527268368009};\\\", \\\"{x:1640,y:449,t:1527268368026};\\\", \\\"{x:1642,y:448,t:1527268368043};\\\", \\\"{x:1642,y:447,t:1527268368127};\\\", \\\"{x:1643,y:446,t:1527268368142};\\\", \\\"{x:1644,y:445,t:1527268368159};\\\", \\\"{x:1643,y:444,t:1527268368223};\\\", \\\"{x:1635,y:446,t:1527268368231};\\\", \\\"{x:1617,y:453,t:1527268368243};\\\", \\\"{x:1589,y:469,t:1527268368259};\\\", \\\"{x:1575,y:487,t:1527268368276};\\\", \\\"{x:1569,y:495,t:1527268368293};\\\", \\\"{x:1567,y:501,t:1527268368311};\\\", \\\"{x:1567,y:502,t:1527268368367};\\\", \\\"{x:1566,y:502,t:1527268368376};\\\", \\\"{x:1563,y:503,t:1527268368393};\\\", \\\"{x:1561,y:503,t:1527268368410};\\\", \\\"{x:1559,y:503,t:1527268368426};\\\", \\\"{x:1554,y:503,t:1527268368443};\\\", \\\"{x:1545,y:501,t:1527268368460};\\\", \\\"{x:1522,y:485,t:1527268368476};\\\", \\\"{x:1502,y:474,t:1527268368493};\\\", \\\"{x:1476,y:458,t:1527268368510};\\\", \\\"{x:1470,y:453,t:1527268368526};\\\", \\\"{x:1469,y:452,t:1527268368551};\\\", \\\"{x:1468,y:452,t:1527268368647};\\\", \\\"{x:1467,y:452,t:1527268368660};\\\", \\\"{x:1461,y:451,t:1527268368676};\\\", \\\"{x:1455,y:449,t:1527268368692};\\\", \\\"{x:1448,y:446,t:1527268368710};\\\", \\\"{x:1447,y:445,t:1527268368727};\\\", \\\"{x:1449,y:437,t:1527268368829};\\\", \\\"{x:1456,y:430,t:1527268368843};\\\", \\\"{x:1471,y:420,t:1527268368860};\\\", \\\"{x:1486,y:409,t:1527268368876};\\\", \\\"{x:1496,y:401,t:1527268368892};\\\", \\\"{x:1500,y:398,t:1527268368909};\\\", \\\"{x:1500,y:397,t:1527268368927};\\\", \\\"{x:1502,y:389,t:1527268368943};\\\", \\\"{x:1506,y:380,t:1527268368960};\\\", \\\"{x:1507,y:373,t:1527268368976};\\\", \\\"{x:1508,y:372,t:1527268368992};\\\", \\\"{x:1509,y:371,t:1527268369014};\\\", \\\"{x:1509,y:370,t:1527268369027};\\\", \\\"{x:1512,y:369,t:1527268369042};\\\", \\\"{x:1517,y:367,t:1527268369059};\\\", \\\"{x:1522,y:367,t:1527268369077};\\\", \\\"{x:1531,y:370,t:1527268369093};\\\", \\\"{x:1540,y:389,t:1527268369110};\\\", \\\"{x:1546,y:405,t:1527268369127};\\\", \\\"{x:1554,y:426,t:1527268369143};\\\", \\\"{x:1563,y:445,t:1527268369160};\\\", \\\"{x:1570,y:465,t:1527268369176};\\\", \\\"{x:1573,y:476,t:1527268369193};\\\", \\\"{x:1573,y:483,t:1527268369210};\\\", \\\"{x:1574,y:487,t:1527268369227};\\\", \\\"{x:1577,y:496,t:1527268369244};\\\", \\\"{x:1580,y:511,t:1527268369260};\\\", \\\"{x:1588,y:531,t:1527268369277};\\\", \\\"{x:1589,y:556,t:1527268369293};\\\", \\\"{x:1591,y:574,t:1527268369309};\\\", \\\"{x:1594,y:592,t:1527268369327};\\\", \\\"{x:1594,y:611,t:1527268369344};\\\", \\\"{x:1594,y:629,t:1527268369359};\\\", \\\"{x:1593,y:646,t:1527268369377};\\\", \\\"{x:1586,y:658,t:1527268369394};\\\", \\\"{x:1584,y:660,t:1527268369410};\\\", \\\"{x:1584,y:662,t:1527268369511};\\\", \\\"{x:1584,y:669,t:1527268369528};\\\", \\\"{x:1585,y:678,t:1527268369544};\\\", \\\"{x:1585,y:683,t:1527268369560};\\\", \\\"{x:1585,y:692,t:1527268369578};\\\", \\\"{x:1585,y:704,t:1527268369595};\\\", \\\"{x:1585,y:715,t:1527268369610};\\\", \\\"{x:1581,y:732,t:1527268369628};\\\", \\\"{x:1573,y:748,t:1527268369644};\\\", \\\"{x:1567,y:763,t:1527268369661};\\\", \\\"{x:1559,y:778,t:1527268369678};\\\", \\\"{x:1550,y:811,t:1527268369694};\\\", \\\"{x:1541,y:837,t:1527268369711};\\\", \\\"{x:1531,y:851,t:1527268369727};\\\", \\\"{x:1525,y:860,t:1527268369744};\\\", \\\"{x:1523,y:862,t:1527268369762};\\\", \\\"{x:1521,y:863,t:1527268369777};\\\", \\\"{x:1520,y:864,t:1527268369794};\\\", \\\"{x:1518,y:864,t:1527268369811};\\\", \\\"{x:1516,y:864,t:1527268369827};\\\", \\\"{x:1515,y:864,t:1527268369871};\\\", \\\"{x:1513,y:863,t:1527268369880};\\\", \\\"{x:1506,y:860,t:1527268369895};\\\", \\\"{x:1497,y:854,t:1527268369911};\\\", \\\"{x:1491,y:850,t:1527268369927};\\\", \\\"{x:1489,y:846,t:1527268369944};\\\", \\\"{x:1484,y:837,t:1527268369961};\\\", \\\"{x:1478,y:827,t:1527268369977};\\\", \\\"{x:1474,y:818,t:1527268369995};\\\", \\\"{x:1474,y:815,t:1527268370011};\\\", \\\"{x:1473,y:812,t:1527268370028};\\\", \\\"{x:1471,y:808,t:1527268370044};\\\", \\\"{x:1469,y:805,t:1527268370062};\\\", \\\"{x:1462,y:798,t:1527268370079};\\\", \\\"{x:1451,y:791,t:1527268370093};\\\", \\\"{x:1432,y:780,t:1527268370110};\\\", \\\"{x:1408,y:767,t:1527268370126};\\\", \\\"{x:1397,y:761,t:1527268370144};\\\", \\\"{x:1392,y:759,t:1527268370160};\\\", \\\"{x:1391,y:758,t:1527268370238};\\\", \\\"{x:1390,y:758,t:1527268370246};\\\", \\\"{x:1388,y:758,t:1527268370261};\\\", \\\"{x:1382,y:753,t:1527268370279};\\\", \\\"{x:1373,y:745,t:1527268370294};\\\", \\\"{x:1366,y:740,t:1527268370311};\\\", \\\"{x:1356,y:734,t:1527268370328};\\\", \\\"{x:1345,y:730,t:1527268370343};\\\", \\\"{x:1336,y:726,t:1527268370361};\\\", \\\"{x:1329,y:723,t:1527268370378};\\\", \\\"{x:1326,y:722,t:1527268370394};\\\", \\\"{x:1321,y:723,t:1527268370607};\\\", \\\"{x:1314,y:731,t:1527268370614};\\\", \\\"{x:1303,y:744,t:1527268370628};\\\", \\\"{x:1268,y:773,t:1527268370645};\\\", \\\"{x:1219,y:803,t:1527268370661};\\\", \\\"{x:1104,y:840,t:1527268370679};\\\", \\\"{x:1046,y:854,t:1527268370695};\\\", \\\"{x:1012,y:856,t:1527268370711};\\\", \\\"{x:1009,y:856,t:1527268370729};\\\", \\\"{x:1008,y:856,t:1527268370745};\\\", \\\"{x:1022,y:854,t:1527268370846};\\\", \\\"{x:1055,y:849,t:1527268370861};\\\", \\\"{x:1161,y:848,t:1527268370880};\\\", \\\"{x:1206,y:840,t:1527268370894};\\\", \\\"{x:1236,y:836,t:1527268370912};\\\", \\\"{x:1250,y:834,t:1527268370928};\\\", \\\"{x:1252,y:834,t:1527268370951};\\\", \\\"{x:1261,y:834,t:1527268371175};\\\", \\\"{x:1280,y:839,t:1527268371182};\\\", \\\"{x:1296,y:850,t:1527268371195};\\\", \\\"{x:1331,y:862,t:1527268371212};\\\", \\\"{x:1352,y:868,t:1527268371228};\\\", \\\"{x:1370,y:871,t:1527268371244};\\\", \\\"{x:1373,y:872,t:1527268371262};\\\", \\\"{x:1373,y:873,t:1527268371375};\\\", \\\"{x:1373,y:874,t:1527268371382};\\\", \\\"{x:1372,y:876,t:1527268371396};\\\", \\\"{x:1372,y:877,t:1527268371412};\\\", \\\"{x:1372,y:879,t:1527268371428};\\\", \\\"{x:1372,y:881,t:1527268371471};\\\", \\\"{x:1374,y:885,t:1527268371480};\\\", \\\"{x:1384,y:894,t:1527268371496};\\\", \\\"{x:1387,y:899,t:1527268371514};\\\", \\\"{x:1388,y:900,t:1527268371528};\\\", \\\"{x:1388,y:901,t:1527268371545};\\\", \\\"{x:1379,y:886,t:1527268375935};\\\", \\\"{x:1362,y:861,t:1527268375950};\\\", \\\"{x:1341,y:839,t:1527268375966};\\\", \\\"{x:1331,y:826,t:1527268375982};\\\", \\\"{x:1330,y:825,t:1527268375999};\\\", \\\"{x:1330,y:823,t:1527268376118};\\\", \\\"{x:1328,y:822,t:1527268376214};\\\", \\\"{x:1327,y:821,t:1527268376270};\\\", \\\"{x:1326,y:821,t:1527268376302};\\\", \\\"{x:1325,y:820,t:1527268376326};\\\", \\\"{x:1324,y:820,t:1527268376358};\\\", \\\"{x:1323,y:819,t:1527268376366};\\\", \\\"{x:1322,y:819,t:1527268376382};\\\", \\\"{x:1320,y:817,t:1527268376398};\\\", \\\"{x:1320,y:816,t:1527268376439};\\\", \\\"{x:1319,y:815,t:1527268376471};\\\", \\\"{x:1319,y:814,t:1527268376511};\\\", \\\"{x:1318,y:813,t:1527268376543};\\\", \\\"{x:1318,y:812,t:1527268376591};\\\", \\\"{x:1317,y:811,t:1527268376599};\\\", \\\"{x:1317,y:810,t:1527268376615};\\\", \\\"{x:1317,y:808,t:1527268376633};\\\", \\\"{x:1315,y:806,t:1527268376649};\\\", \\\"{x:1315,y:805,t:1527268376666};\\\", \\\"{x:1315,y:803,t:1527268376682};\\\", \\\"{x:1315,y:802,t:1527268376700};\\\", \\\"{x:1315,y:801,t:1527268376716};\\\", \\\"{x:1314,y:800,t:1527268376735};\\\", \\\"{x:1313,y:800,t:1527268376847};\\\", \\\"{x:1312,y:800,t:1527268376863};\\\", \\\"{x:1312,y:799,t:1527268376870};\\\", \\\"{x:1310,y:799,t:1527268376887};\\\", \\\"{x:1309,y:798,t:1527268376903};\\\", \\\"{x:1308,y:797,t:1527268376935};\\\", \\\"{x:1307,y:797,t:1527268376950};\\\", \\\"{x:1306,y:797,t:1527268377055};\\\", \\\"{x:1304,y:796,t:1527268377087};\\\", \\\"{x:1302,y:795,t:1527268377102};\\\", \\\"{x:1300,y:794,t:1527268377126};\\\", \\\"{x:1299,y:794,t:1527268377133};\\\", \\\"{x:1297,y:793,t:1527268377150};\\\", \\\"{x:1296,y:792,t:1527268377166};\\\", \\\"{x:1295,y:792,t:1527268377189};\\\", \\\"{x:1294,y:791,t:1527268377200};\\\", \\\"{x:1293,y:791,t:1527268377216};\\\", \\\"{x:1291,y:790,t:1527268377232};\\\", \\\"{x:1289,y:790,t:1527268377249};\\\", \\\"{x:1284,y:788,t:1527268377267};\\\", \\\"{x:1277,y:785,t:1527268377282};\\\", \\\"{x:1267,y:781,t:1527268377300};\\\", \\\"{x:1258,y:778,t:1527268377316};\\\", \\\"{x:1253,y:776,t:1527268377332};\\\", \\\"{x:1247,y:774,t:1527268377349};\\\", \\\"{x:1244,y:774,t:1527268377365};\\\", \\\"{x:1242,y:773,t:1527268377383};\\\", \\\"{x:1240,y:773,t:1527268377399};\\\", \\\"{x:1237,y:771,t:1527268377416};\\\", \\\"{x:1231,y:770,t:1527268377433};\\\", \\\"{x:1225,y:769,t:1527268377449};\\\", \\\"{x:1216,y:767,t:1527268377467};\\\", \\\"{x:1203,y:767,t:1527268377483};\\\", \\\"{x:1182,y:767,t:1527268377500};\\\", \\\"{x:1159,y:767,t:1527268377516};\\\", \\\"{x:1144,y:767,t:1527268377534};\\\", \\\"{x:1130,y:767,t:1527268377549};\\\", \\\"{x:1118,y:767,t:1527268377566};\\\", \\\"{x:1115,y:767,t:1527268377584};\\\", \\\"{x:1111,y:767,t:1527268377600};\\\", \\\"{x:1113,y:767,t:1527268377711};\\\", \\\"{x:1119,y:768,t:1527268377718};\\\", \\\"{x:1125,y:769,t:1527268377733};\\\", \\\"{x:1137,y:773,t:1527268377749};\\\", \\\"{x:1142,y:774,t:1527268377766};\\\", \\\"{x:1144,y:774,t:1527268377783};\\\", \\\"{x:1145,y:774,t:1527268377799};\\\", \\\"{x:1148,y:774,t:1527268377862};\\\", \\\"{x:1152,y:774,t:1527268377869};\\\", \\\"{x:1155,y:774,t:1527268377883};\\\", \\\"{x:1158,y:774,t:1527268377901};\\\", \\\"{x:1161,y:772,t:1527268377916};\\\", \\\"{x:1168,y:772,t:1527268377933};\\\", \\\"{x:1192,y:772,t:1527268377951};\\\", \\\"{x:1193,y:772,t:1527268377966};\\\", \\\"{x:1194,y:772,t:1527268378006};\\\", \\\"{x:1193,y:773,t:1527268378214};\\\", \\\"{x:1192,y:773,t:1527268378230};\\\", \\\"{x:1190,y:773,t:1527268378247};\\\", \\\"{x:1189,y:775,t:1527268378254};\\\", \\\"{x:1187,y:775,t:1527268378280};\\\", \\\"{x:1186,y:775,t:1527268378303};\\\", \\\"{x:1185,y:775,t:1527268378518};\\\", \\\"{x:1183,y:775,t:1527268378551};\\\", \\\"{x:1165,y:770,t:1527268378568};\\\", \\\"{x:1127,y:760,t:1527268378583};\\\", \\\"{x:1083,y:750,t:1527268378600};\\\", \\\"{x:1036,y:738,t:1527268378617};\\\", \\\"{x:1016,y:732,t:1527268378633};\\\", \\\"{x:1014,y:730,t:1527268378651};\\\", \\\"{x:1014,y:729,t:1527268378668};\\\", \\\"{x:1014,y:728,t:1527268378951};\\\", \\\"{x:1012,y:721,t:1527268378968};\\\", \\\"{x:989,y:703,t:1527268378984};\\\", \\\"{x:946,y:669,t:1527268379001};\\\", \\\"{x:914,y:635,t:1527268379017};\\\", \\\"{x:877,y:601,t:1527268379035};\\\", \\\"{x:813,y:562,t:1527268379050};\\\", \\\"{x:723,y:528,t:1527268379067};\\\", \\\"{x:621,y:502,t:1527268379084};\\\", \\\"{x:527,y:493,t:1527268379100};\\\", \\\"{x:416,y:493,t:1527268379118};\\\", \\\"{x:374,y:493,t:1527268379134};\\\", \\\"{x:335,y:493,t:1527268379151};\\\", \\\"{x:308,y:495,t:1527268379168};\\\", \\\"{x:290,y:501,t:1527268379184};\\\", \\\"{x:282,y:504,t:1527268379201};\\\", \\\"{x:279,y:508,t:1527268379219};\\\", \\\"{x:275,y:513,t:1527268379234};\\\", \\\"{x:269,y:520,t:1527268379252};\\\", \\\"{x:263,y:530,t:1527268379269};\\\", \\\"{x:256,y:538,t:1527268379285};\\\", \\\"{x:253,y:545,t:1527268379301};\\\", \\\"{x:251,y:555,t:1527268379318};\\\", \\\"{x:248,y:562,t:1527268379336};\\\", \\\"{x:245,y:565,t:1527268379352};\\\", \\\"{x:240,y:568,t:1527268379368};\\\", \\\"{x:236,y:570,t:1527268379385};\\\", \\\"{x:232,y:571,t:1527268379403};\\\", \\\"{x:224,y:572,t:1527268379418};\\\", \\\"{x:208,y:572,t:1527268379435};\\\", \\\"{x:194,y:572,t:1527268379452};\\\", \\\"{x:178,y:569,t:1527268379469};\\\", \\\"{x:166,y:562,t:1527268379486};\\\", \\\"{x:164,y:559,t:1527268379502};\\\", \\\"{x:162,y:554,t:1527268379519};\\\", \\\"{x:158,y:549,t:1527268379536};\\\", \\\"{x:154,y:543,t:1527268379551};\\\", \\\"{x:152,y:539,t:1527268379569};\\\", \\\"{x:152,y:533,t:1527268379586};\\\", \\\"{x:153,y:527,t:1527268379602};\\\", \\\"{x:153,y:524,t:1527268379619};\\\", \\\"{x:153,y:519,t:1527268379635};\\\", \\\"{x:155,y:516,t:1527268379652};\\\", \\\"{x:155,y:515,t:1527268379669};\\\", \\\"{x:155,y:512,t:1527268379685};\\\", \\\"{x:155,y:510,t:1527268379702};\\\", \\\"{x:155,y:507,t:1527268379718};\\\", \\\"{x:156,y:503,t:1527268379735};\\\", \\\"{x:156,y:502,t:1527268379757};\\\", \\\"{x:168,y:503,t:1527268379918};\\\", \\\"{x:192,y:512,t:1527268379935};\\\", \\\"{x:222,y:538,t:1527268379953};\\\", \\\"{x:275,y:572,t:1527268379969};\\\", \\\"{x:345,y:609,t:1527268379986};\\\", \\\"{x:419,y:653,t:1527268380002};\\\", \\\"{x:489,y:690,t:1527268380018};\\\", \\\"{x:522,y:711,t:1527268380035};\\\", \\\"{x:537,y:723,t:1527268380052};\\\", \\\"{x:544,y:727,t:1527268380069};\\\", \\\"{x:544,y:729,t:1527268380085};\\\", \\\"{x:544,y:738,t:1527268380101};\\\", \\\"{x:544,y:745,t:1527268380118};\\\", \\\"{x:543,y:755,t:1527268380136};\\\", \\\"{x:543,y:768,t:1527268380152};\\\", \\\"{x:543,y:772,t:1527268380168};\\\", \\\"{x:543,y:773,t:1527268380185};\\\", \\\"{x:540,y:773,t:1527268380270};\\\", \\\"{x:537,y:770,t:1527268380286};\\\", \\\"{x:535,y:765,t:1527268380302};\\\", \\\"{x:534,y:764,t:1527268380320};\\\", \\\"{x:532,y:760,t:1527268380336};\\\", \\\"{x:528,y:752,t:1527268380354};\\\", \\\"{x:522,y:742,t:1527268380370};\\\", \\\"{x:521,y:736,t:1527268380385};\\\", \\\"{x:520,y:734,t:1527268380402};\\\", \\\"{x:520,y:733,t:1527268380430};\\\", \\\"{x:519,y:732,t:1527268380439};\\\" ] }, { \\\"rt\\\": 55543, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 472631, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:731,t:1527268382390};\\\", \\\"{x:523,y:731,t:1527268385978};\\\", \\\"{x:536,y:731,t:1527268385990};\\\", \\\"{x:572,y:731,t:1527268386006};\\\", \\\"{x:607,y:731,t:1527268386022};\\\", \\\"{x:635,y:731,t:1527268386039};\\\", \\\"{x:670,y:731,t:1527268386060};\\\", \\\"{x:683,y:731,t:1527268386076};\\\", \\\"{x:698,y:731,t:1527268386094};\\\", \\\"{x:716,y:731,t:1527268386109};\\\", \\\"{x:736,y:731,t:1527268386126};\\\", \\\"{x:762,y:726,t:1527268386143};\\\", \\\"{x:792,y:720,t:1527268386160};\\\", \\\"{x:819,y:713,t:1527268386177};\\\", \\\"{x:822,y:712,t:1527268386193};\\\", \\\"{x:823,y:712,t:1527268386209};\\\", \\\"{x:824,y:711,t:1527268386226};\\\", \\\"{x:833,y:707,t:1527268386244};\\\", \\\"{x:849,y:701,t:1527268386260};\\\", \\\"{x:870,y:691,t:1527268386276};\\\", \\\"{x:887,y:685,t:1527268386294};\\\", \\\"{x:913,y:678,t:1527268386310};\\\", \\\"{x:962,y:661,t:1527268386326};\\\", \\\"{x:1015,y:645,t:1527268386344};\\\", \\\"{x:1088,y:626,t:1527268386360};\\\", \\\"{x:1154,y:617,t:1527268386377};\\\", \\\"{x:1229,y:606,t:1527268386393};\\\", \\\"{x:1307,y:595,t:1527268386409};\\\", \\\"{x:1371,y:587,t:1527268386427};\\\", \\\"{x:1422,y:579,t:1527268386444};\\\", \\\"{x:1452,y:575,t:1527268386461};\\\", \\\"{x:1465,y:573,t:1527268386477};\\\", \\\"{x:1467,y:572,t:1527268386494};\\\", \\\"{x:1468,y:571,t:1527268386778};\\\", \\\"{x:1475,y:571,t:1527268386793};\\\", \\\"{x:1484,y:569,t:1527268386810};\\\", \\\"{x:1497,y:565,t:1527268386828};\\\", \\\"{x:1509,y:562,t:1527268386843};\\\", \\\"{x:1523,y:557,t:1527268386860};\\\", \\\"{x:1531,y:555,t:1527268386878};\\\", \\\"{x:1537,y:554,t:1527268386894};\\\", \\\"{x:1540,y:552,t:1527268386910};\\\", \\\"{x:1542,y:551,t:1527268386928};\\\", \\\"{x:1544,y:550,t:1527268386944};\\\", \\\"{x:1545,y:549,t:1527268387002};\\\", \\\"{x:1547,y:553,t:1527268387041};\\\", \\\"{x:1549,y:555,t:1527268387050};\\\", \\\"{x:1550,y:557,t:1527268387061};\\\", \\\"{x:1552,y:561,t:1527268387078};\\\", \\\"{x:1552,y:564,t:1527268387095};\\\", \\\"{x:1551,y:564,t:1527268387266};\\\", \\\"{x:1549,y:564,t:1527268387278};\\\", \\\"{x:1547,y:564,t:1527268387295};\\\", \\\"{x:1546,y:564,t:1527268387312};\\\", \\\"{x:1544,y:564,t:1527268387328};\\\", \\\"{x:1543,y:563,t:1527268387370};\\\", \\\"{x:1542,y:563,t:1527268387378};\\\", \\\"{x:1531,y:553,t:1527268387396};\\\", \\\"{x:1517,y:533,t:1527268387411};\\\", \\\"{x:1512,y:514,t:1527268387428};\\\", \\\"{x:1509,y:499,t:1527268387445};\\\", \\\"{x:1499,y:476,t:1527268387461};\\\", \\\"{x:1477,y:446,t:1527268387478};\\\", \\\"{x:1429,y:397,t:1527268387495};\\\", \\\"{x:1349,y:349,t:1527268387511};\\\", \\\"{x:1248,y:295,t:1527268387528};\\\", \\\"{x:1084,y:244,t:1527268387545};\\\", \\\"{x:998,y:229,t:1527268387561};\\\", \\\"{x:935,y:231,t:1527268387578};\\\", \\\"{x:899,y:240,t:1527268387595};\\\", \\\"{x:878,y:246,t:1527268387612};\\\", \\\"{x:875,y:247,t:1527268387628};\\\", \\\"{x:879,y:247,t:1527268387665};\\\", \\\"{x:880,y:246,t:1527268387678};\\\", \\\"{x:882,y:245,t:1527268387695};\\\", \\\"{x:906,y:258,t:1527268387712};\\\", \\\"{x:921,y:273,t:1527268387728};\\\", \\\"{x:951,y:303,t:1527268387745};\\\", \\\"{x:990,y:339,t:1527268387761};\\\", \\\"{x:1031,y:371,t:1527268387778};\\\", \\\"{x:1057,y:397,t:1527268387795};\\\", \\\"{x:1067,y:409,t:1527268387812};\\\", \\\"{x:1072,y:416,t:1527268387828};\\\", \\\"{x:1082,y:423,t:1527268387845};\\\", \\\"{x:1092,y:431,t:1527268387862};\\\", \\\"{x:1101,y:440,t:1527268387878};\\\", \\\"{x:1112,y:451,t:1527268387895};\\\", \\\"{x:1122,y:462,t:1527268387912};\\\", \\\"{x:1132,y:476,t:1527268387928};\\\", \\\"{x:1150,y:504,t:1527268387945};\\\", \\\"{x:1168,y:523,t:1527268387961};\\\", \\\"{x:1188,y:542,t:1527268387979};\\\", \\\"{x:1200,y:554,t:1527268387995};\\\", \\\"{x:1204,y:559,t:1527268388012};\\\", \\\"{x:1208,y:572,t:1527268388028};\\\", \\\"{x:1211,y:583,t:1527268388045};\\\", \\\"{x:1212,y:593,t:1527268388062};\\\", \\\"{x:1214,y:603,t:1527268388079};\\\", \\\"{x:1214,y:606,t:1527268388095};\\\", \\\"{x:1206,y:604,t:1527268388161};\\\", \\\"{x:1164,y:591,t:1527268388180};\\\", \\\"{x:1175,y:593,t:1527268388921};\\\", \\\"{x:1197,y:600,t:1527268388929};\\\", \\\"{x:1222,y:608,t:1527268388945};\\\", \\\"{x:1240,y:617,t:1527268388963};\\\", \\\"{x:1258,y:628,t:1527268388979};\\\", \\\"{x:1276,y:643,t:1527268388996};\\\", \\\"{x:1284,y:653,t:1527268389013};\\\", \\\"{x:1290,y:662,t:1527268389029};\\\", \\\"{x:1295,y:670,t:1527268389046};\\\", \\\"{x:1304,y:680,t:1527268389063};\\\", \\\"{x:1307,y:682,t:1527268389079};\\\", \\\"{x:1309,y:685,t:1527268389096};\\\", \\\"{x:1314,y:686,t:1527268389113};\\\", \\\"{x:1320,y:689,t:1527268389129};\\\", \\\"{x:1337,y:696,t:1527268389146};\\\", \\\"{x:1362,y:700,t:1527268389163};\\\", \\\"{x:1401,y:706,t:1527268389179};\\\", \\\"{x:1461,y:712,t:1527268389196};\\\", \\\"{x:1487,y:712,t:1527268389213};\\\", \\\"{x:1496,y:713,t:1527268389230};\\\", \\\"{x:1498,y:714,t:1527268389246};\\\", \\\"{x:1499,y:714,t:1527268389314};\\\", \\\"{x:1504,y:717,t:1527268389330};\\\", \\\"{x:1507,y:717,t:1527268389346};\\\", \\\"{x:1503,y:717,t:1527268389449};\\\", \\\"{x:1492,y:713,t:1527268389463};\\\", \\\"{x:1465,y:705,t:1527268389480};\\\", \\\"{x:1440,y:700,t:1527268389496};\\\", \\\"{x:1405,y:696,t:1527268389513};\\\", \\\"{x:1392,y:696,t:1527268389530};\\\", \\\"{x:1389,y:696,t:1527268389546};\\\", \\\"{x:1388,y:696,t:1527268389587};\\\", \\\"{x:1389,y:696,t:1527268389784};\\\", \\\"{x:1412,y:700,t:1527268389796};\\\", \\\"{x:1452,y:707,t:1527268389813};\\\", \\\"{x:1518,y:712,t:1527268389830};\\\", \\\"{x:1577,y:715,t:1527268389847};\\\", \\\"{x:1628,y:715,t:1527268389862};\\\", \\\"{x:1662,y:715,t:1527268389879};\\\", \\\"{x:1671,y:714,t:1527268389896};\\\", \\\"{x:1670,y:714,t:1527268390201};\\\", \\\"{x:1663,y:714,t:1527268390214};\\\", \\\"{x:1645,y:716,t:1527268390230};\\\", \\\"{x:1620,y:719,t:1527268390247};\\\", \\\"{x:1598,y:724,t:1527268390264};\\\", \\\"{x:1592,y:727,t:1527268390279};\\\", \\\"{x:1590,y:727,t:1527268390297};\\\", \\\"{x:1583,y:727,t:1527268391681};\\\", \\\"{x:1485,y:727,t:1527268391698};\\\", \\\"{x:1363,y:727,t:1527268391715};\\\", \\\"{x:1244,y:744,t:1527268391732};\\\", \\\"{x:1132,y:767,t:1527268391748};\\\", \\\"{x:1036,y:790,t:1527268391765};\\\", \\\"{x:991,y:801,t:1527268391782};\\\", \\\"{x:986,y:801,t:1527268391798};\\\", \\\"{x:990,y:801,t:1527268391866};\\\", \\\"{x:1014,y:793,t:1527268391882};\\\", \\\"{x:1058,y:785,t:1527268391898};\\\", \\\"{x:1123,y:773,t:1527268391915};\\\", \\\"{x:1170,y:767,t:1527268391932};\\\", \\\"{x:1230,y:755,t:1527268391948};\\\", \\\"{x:1291,y:749,t:1527268391965};\\\", \\\"{x:1323,y:743,t:1527268391982};\\\", \\\"{x:1353,y:740,t:1527268391998};\\\", \\\"{x:1368,y:736,t:1527268392015};\\\", \\\"{x:1375,y:735,t:1527268392033};\\\", \\\"{x:1376,y:735,t:1527268392090};\\\", \\\"{x:1381,y:733,t:1527268392099};\\\", \\\"{x:1393,y:727,t:1527268392116};\\\", \\\"{x:1399,y:725,t:1527268392132};\\\", \\\"{x:1400,y:725,t:1527268392150};\\\", \\\"{x:1400,y:724,t:1527268392165};\\\", \\\"{x:1399,y:724,t:1527268392209};\\\", \\\"{x:1394,y:724,t:1527268392217};\\\", \\\"{x:1387,y:724,t:1527268392232};\\\", \\\"{x:1363,y:724,t:1527268392250};\\\", \\\"{x:1349,y:724,t:1527268392265};\\\", \\\"{x:1337,y:726,t:1527268392283};\\\", \\\"{x:1335,y:726,t:1527268392299};\\\", \\\"{x:1336,y:726,t:1527268394074};\\\", \\\"{x:1339,y:724,t:1527268394084};\\\", \\\"{x:1342,y:722,t:1527268394101};\\\", \\\"{x:1343,y:721,t:1527268394117};\\\", \\\"{x:1343,y:720,t:1527268394514};\\\", \\\"{x:1343,y:717,t:1527268394521};\\\", \\\"{x:1343,y:715,t:1527268394537};\\\", \\\"{x:1343,y:714,t:1527268394550};\\\", \\\"{x:1343,y:713,t:1527268394578};\\\", \\\"{x:1343,y:712,t:1527268394690};\\\", \\\"{x:1343,y:711,t:1527268394702};\\\", \\\"{x:1344,y:708,t:1527268394718};\\\", \\\"{x:1345,y:706,t:1527268394734};\\\", \\\"{x:1345,y:705,t:1527268394769};\\\", \\\"{x:1346,y:704,t:1527268394793};\\\", \\\"{x:1346,y:703,t:1527268394833};\\\", \\\"{x:1346,y:702,t:1527268397156};\\\", \\\"{x:1346,y:697,t:1527268397168};\\\", \\\"{x:1341,y:696,t:1527268399729};\\\", \\\"{x:1329,y:696,t:1527268399738};\\\", \\\"{x:1302,y:696,t:1527268399755};\\\", \\\"{x:1287,y:702,t:1527268399771};\\\", \\\"{x:1282,y:704,t:1527268399788};\\\", \\\"{x:1282,y:705,t:1527268399976};\\\", \\\"{x:1285,y:708,t:1527268399988};\\\", \\\"{x:1303,y:715,t:1527268400005};\\\", \\\"{x:1310,y:718,t:1527268400022};\\\", \\\"{x:1314,y:720,t:1527268400038};\\\", \\\"{x:1315,y:720,t:1527268400280};\\\", \\\"{x:1315,y:717,t:1527268400554};\\\", \\\"{x:1315,y:714,t:1527268400561};\\\", \\\"{x:1316,y:712,t:1527268400573};\\\", \\\"{x:1323,y:704,t:1527268400589};\\\", \\\"{x:1324,y:701,t:1527268400605};\\\", \\\"{x:1325,y:701,t:1527268400622};\\\", \\\"{x:1327,y:700,t:1527268400857};\\\", \\\"{x:1336,y:696,t:1527268400874};\\\", \\\"{x:1355,y:690,t:1527268400889};\\\", \\\"{x:1375,y:684,t:1527268400906};\\\", \\\"{x:1388,y:679,t:1527268400922};\\\", \\\"{x:1400,y:678,t:1527268400939};\\\", \\\"{x:1407,y:678,t:1527268400956};\\\", \\\"{x:1413,y:678,t:1527268401001};\\\", \\\"{x:1420,y:681,t:1527268401008};\\\", \\\"{x:1429,y:683,t:1527268401023};\\\", \\\"{x:1439,y:687,t:1527268401039};\\\", \\\"{x:1442,y:688,t:1527268401056};\\\", \\\"{x:1443,y:688,t:1527268401169};\\\", \\\"{x:1444,y:688,t:1527268401200};\\\", \\\"{x:1444,y:689,t:1527268401208};\\\", \\\"{x:1445,y:689,t:1527268401225};\\\", \\\"{x:1449,y:689,t:1527268401239};\\\", \\\"{x:1482,y:678,t:1527268401257};\\\", \\\"{x:1511,y:671,t:1527268401273};\\\", \\\"{x:1572,y:670,t:1527268401289};\\\", \\\"{x:1650,y:670,t:1527268401307};\\\", \\\"{x:1709,y:670,t:1527268401324};\\\", \\\"{x:1743,y:675,t:1527268401340};\\\", \\\"{x:1751,y:678,t:1527268401356};\\\", \\\"{x:1753,y:678,t:1527268401373};\\\", \\\"{x:1753,y:680,t:1527268401514};\\\", \\\"{x:1753,y:682,t:1527268401524};\\\", \\\"{x:1743,y:688,t:1527268401540};\\\", \\\"{x:1726,y:699,t:1527268401557};\\\", \\\"{x:1698,y:705,t:1527268401573};\\\", \\\"{x:1679,y:708,t:1527268401591};\\\", \\\"{x:1670,y:708,t:1527268401606};\\\", \\\"{x:1665,y:707,t:1527268401623};\\\", \\\"{x:1658,y:706,t:1527268401640};\\\", \\\"{x:1657,y:706,t:1527268401656};\\\", \\\"{x:1654,y:704,t:1527268401681};\\\", \\\"{x:1653,y:704,t:1527268401728};\\\", \\\"{x:1652,y:704,t:1527268401777};\\\", \\\"{x:1651,y:703,t:1527268401790};\\\", \\\"{x:1645,y:702,t:1527268401807};\\\", \\\"{x:1640,y:701,t:1527268401823};\\\", \\\"{x:1637,y:700,t:1527268401841};\\\", \\\"{x:1634,y:699,t:1527268403754};\\\", \\\"{x:1620,y:696,t:1527268403761};\\\", \\\"{x:1591,y:693,t:1527268403776};\\\", \\\"{x:1486,y:684,t:1527268403791};\\\", \\\"{x:1214,y:675,t:1527268403808};\\\", \\\"{x:1029,y:671,t:1527268403825};\\\", \\\"{x:893,y:668,t:1527268403842};\\\", \\\"{x:793,y:668,t:1527268403858};\\\", \\\"{x:750,y:668,t:1527268403875};\\\", \\\"{x:737,y:667,t:1527268403891};\\\", \\\"{x:736,y:667,t:1527268403977};\\\", \\\"{x:732,y:667,t:1527268403992};\\\", \\\"{x:695,y:668,t:1527268404009};\\\", \\\"{x:667,y:668,t:1527268404026};\\\", \\\"{x:629,y:658,t:1527268404041};\\\", \\\"{x:533,y:637,t:1527268404059};\\\", \\\"{x:402,y:618,t:1527268404077};\\\", \\\"{x:277,y:599,t:1527268404093};\\\", \\\"{x:175,y:585,t:1527268404109};\\\", \\\"{x:89,y:572,t:1527268404124};\\\", \\\"{x:8,y:559,t:1527268404141};\\\", \\\"{x:0,y:552,t:1527268404157};\\\", \\\"{x:0,y:548,t:1527268404174};\\\", \\\"{x:0,y:547,t:1527268404191};\\\", \\\"{x:6,y:546,t:1527268404240};\\\", \\\"{x:20,y:540,t:1527268404257};\\\", \\\"{x:37,y:537,t:1527268404274};\\\", \\\"{x:59,y:536,t:1527268404292};\\\", \\\"{x:81,y:536,t:1527268404307};\\\", \\\"{x:117,y:544,t:1527268404325};\\\", \\\"{x:175,y:561,t:1527268404340};\\\", \\\"{x:218,y:576,t:1527268404357};\\\", \\\"{x:252,y:590,t:1527268404374};\\\", \\\"{x:280,y:605,t:1527268404392};\\\", \\\"{x:333,y:633,t:1527268404408};\\\", \\\"{x:355,y:642,t:1527268404425};\\\", \\\"{x:372,y:646,t:1527268404442};\\\", \\\"{x:394,y:647,t:1527268404458};\\\", \\\"{x:433,y:652,t:1527268404475};\\\", \\\"{x:530,y:664,t:1527268404491};\\\", \\\"{x:636,y:668,t:1527268404508};\\\", \\\"{x:722,y:668,t:1527268404524};\\\", \\\"{x:778,y:668,t:1527268404541};\\\", \\\"{x:823,y:668,t:1527268404558};\\\", \\\"{x:851,y:668,t:1527268404574};\\\", \\\"{x:855,y:668,t:1527268404591};\\\", \\\"{x:856,y:668,t:1527268404689};\\\", \\\"{x:856,y:666,t:1527268404696};\\\", \\\"{x:856,y:663,t:1527268404708};\\\", \\\"{x:856,y:656,t:1527268404724};\\\", \\\"{x:856,y:648,t:1527268404741};\\\", \\\"{x:856,y:644,t:1527268404758};\\\", \\\"{x:856,y:640,t:1527268404774};\\\", \\\"{x:856,y:639,t:1527268404833};\\\", \\\"{x:856,y:637,t:1527268404849};\\\", \\\"{x:856,y:636,t:1527268404859};\\\", \\\"{x:856,y:635,t:1527268404875};\\\", \\\"{x:855,y:633,t:1527268404892};\\\", \\\"{x:854,y:631,t:1527268404910};\\\", \\\"{x:851,y:627,t:1527268404924};\\\", \\\"{x:849,y:625,t:1527268404941};\\\", \\\"{x:847,y:622,t:1527268404958};\\\", \\\"{x:845,y:619,t:1527268404974};\\\", \\\"{x:843,y:618,t:1527268404991};\\\", \\\"{x:838,y:618,t:1527268405240};\\\", \\\"{x:818,y:633,t:1527268405248};\\\", \\\"{x:802,y:644,t:1527268405259};\\\", \\\"{x:766,y:665,t:1527268405275};\\\", \\\"{x:715,y:691,t:1527268405291};\\\", \\\"{x:619,y:727,t:1527268405308};\\\", \\\"{x:538,y:756,t:1527268405325};\\\", \\\"{x:499,y:767,t:1527268405342};\\\", \\\"{x:482,y:771,t:1527268405358};\\\", \\\"{x:479,y:772,t:1527268405376};\\\", \\\"{x:478,y:772,t:1527268405553};\\\", \\\"{x:479,y:771,t:1527268405561};\\\", \\\"{x:480,y:769,t:1527268405576};\\\", \\\"{x:483,y:762,t:1527268405593};\\\", \\\"{x:486,y:758,t:1527268405609};\\\", \\\"{x:489,y:753,t:1527268405626};\\\", \\\"{x:491,y:748,t:1527268405643};\\\", \\\"{x:493,y:743,t:1527268405659};\\\", \\\"{x:495,y:741,t:1527268405676};\\\", \\\"{x:495,y:738,t:1527268405692};\\\", \\\"{x:495,y:737,t:1527268405713};\\\" ] }, { \\\"rt\\\": 13082, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 486969, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-12 PM-B -B -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:738,t:1527268439385};\\\", \\\"{x:479,y:737,t:1527268439407};\\\", \\\"{x:472,y:736,t:1527268439419};\\\", \\\"{x:470,y:735,t:1527268439436};\\\", \\\"{x:469,y:735,t:1527268439472};\\\", \\\"{x:468,y:735,t:1527268439486};\\\", \\\"{x:468,y:734,t:1527268439502};\\\", \\\"{x:467,y:734,t:1527268439519};\\\", \\\"{x:461,y:731,t:1527268439536};\\\", \\\"{x:452,y:728,t:1527268439552};\\\", \\\"{x:442,y:724,t:1527268439570};\\\", \\\"{x:440,y:723,t:1527268439586};\\\", \\\"{x:439,y:722,t:1527268439656};\\\", \\\"{x:439,y:715,t:1527268439669};\\\", \\\"{x:439,y:677,t:1527268439687};\\\", \\\"{x:444,y:622,t:1527268439704};\\\", \\\"{x:444,y:591,t:1527268439719};\\\", \\\"{x:444,y:572,t:1527268439736};\\\", \\\"{x:445,y:570,t:1527268439752};\\\", \\\"{x:446,y:570,t:1527268439897};\\\", \\\"{x:447,y:566,t:1527268439904};\\\", \\\"{x:453,y:553,t:1527268439922};\\\", \\\"{x:474,y:514,t:1527268439937};\\\", \\\"{x:488,y:493,t:1527268439952};\\\", \\\"{x:511,y:467,t:1527268439969};\\\", \\\"{x:521,y:456,t:1527268439984};\\\", \\\"{x:530,y:449,t:1527268440003};\\\", \\\"{x:542,y:440,t:1527268440020};\\\", \\\"{x:558,y:432,t:1527268440036};\\\", \\\"{x:573,y:427,t:1527268440053};\\\", \\\"{x:583,y:423,t:1527268440070};\\\", \\\"{x:586,y:423,t:1527268440087};\\\", \\\"{x:587,y:422,t:1527268440103};\\\", \\\"{x:588,y:422,t:1527268440136};\\\", \\\"{x:589,y:422,t:1527268440145};\\\", \\\"{x:593,y:422,t:1527268440154};\\\", \\\"{x:607,y:422,t:1527268440170};\\\", \\\"{x:635,y:427,t:1527268440187};\\\", \\\"{x:688,y:433,t:1527268440204};\\\", \\\"{x:752,y:442,t:1527268440220};\\\", \\\"{x:814,y:452,t:1527268440237};\\\", \\\"{x:892,y:464,t:1527268440254};\\\", \\\"{x:950,y:469,t:1527268440271};\\\", \\\"{x:1005,y:474,t:1527268440288};\\\", \\\"{x:1079,y:486,t:1527268440304};\\\", \\\"{x:1101,y:496,t:1527268440322};\\\", \\\"{x:1104,y:499,t:1527268440339};\\\", \\\"{x:1105,y:499,t:1527268440865};\\\", \\\"{x:1106,y:500,t:1527268440881};\\\", \\\"{x:1106,y:501,t:1527268440913};\\\", \\\"{x:1106,y:502,t:1527268440961};\\\", \\\"{x:1106,y:504,t:1527268440974};\\\", \\\"{x:1111,y:508,t:1527268440991};\\\", \\\"{x:1118,y:515,t:1527268441008};\\\", \\\"{x:1136,y:526,t:1527268441024};\\\", \\\"{x:1221,y:577,t:1527268441041};\\\", \\\"{x:1354,y:638,t:1527268441058};\\\", \\\"{x:1522,y:710,t:1527268441075};\\\", \\\"{x:1695,y:776,t:1527268441090};\\\", \\\"{x:1827,y:833,t:1527268441108};\\\", \\\"{x:1919,y:891,t:1527268441124};\\\", \\\"{x:1919,y:955,t:1527268441142};\\\", \\\"{x:1919,y:1024,t:1527268441153};\\\", \\\"{x:1919,y:1082,t:1527268441170};\\\", \\\"{x:1919,y:1116,t:1527268441187};\\\", \\\"{x:1919,y:1148,t:1527268441203};\\\", \\\"{x:1912,y:1190,t:1527268441221};\\\", \\\"{x:1905,y:1199,t:1527268441236};\\\", \\\"{x:1900,y:1199,t:1527268441253};\\\", \\\"{x:1895,y:1199,t:1527268441270};\\\", \\\"{x:1891,y:1199,t:1527268441288};\\\", \\\"{x:1890,y:1199,t:1527268441305};\\\", \\\"{x:1889,y:1199,t:1527268441321};\\\", \\\"{x:1887,y:1199,t:1527268441385};\\\", \\\"{x:1880,y:1199,t:1527268441393};\\\", \\\"{x:1876,y:1199,t:1527268441405};\\\", \\\"{x:1870,y:1199,t:1527268441421};\\\", \\\"{x:1854,y:1199,t:1527268441438};\\\", \\\"{x:1834,y:1199,t:1527268441454};\\\", \\\"{x:1819,y:1199,t:1527268441471};\\\", \\\"{x:1801,y:1199,t:1527268441488};\\\", \\\"{x:1797,y:1199,t:1527268441504};\\\", \\\"{x:1792,y:1199,t:1527268441521};\\\", \\\"{x:1789,y:1199,t:1527268441538};\\\", \\\"{x:1788,y:1199,t:1527268441569};\\\", \\\"{x:1787,y:1199,t:1527268441609};\\\", \\\"{x:1786,y:1199,t:1527268441621};\\\", \\\"{x:1765,y:1199,t:1527268441638};\\\", \\\"{x:1730,y:1199,t:1527268441656};\\\", \\\"{x:1675,y:1195,t:1527268441671};\\\", \\\"{x:1623,y:1186,t:1527268441688};\\\", \\\"{x:1611,y:1184,t:1527268441706};\\\", \\\"{x:1606,y:1180,t:1527268441722};\\\", \\\"{x:1603,y:1177,t:1527268441738};\\\", \\\"{x:1599,y:1173,t:1527268441754};\\\", \\\"{x:1594,y:1163,t:1527268441771};\\\", \\\"{x:1588,y:1156,t:1527268441788};\\\", \\\"{x:1585,y:1151,t:1527268441804};\\\", \\\"{x:1584,y:1149,t:1527268441821};\\\", \\\"{x:1582,y:1145,t:1527268441838};\\\", \\\"{x:1581,y:1136,t:1527268441854};\\\", \\\"{x:1579,y:1135,t:1527268441871};\\\", \\\"{x:1579,y:1134,t:1527268441888};\\\", \\\"{x:1579,y:1133,t:1527268441961};\\\", \\\"{x:1579,y:1132,t:1527268442025};\\\", \\\"{x:1579,y:1131,t:1527268442038};\\\", \\\"{x:1579,y:1129,t:1527268442056};\\\", \\\"{x:1579,y:1126,t:1527268442072};\\\", \\\"{x:1579,y:1125,t:1527268442345};\\\", \\\"{x:1579,y:1122,t:1527268442355};\\\", \\\"{x:1578,y:1115,t:1527268442372};\\\", \\\"{x:1577,y:1107,t:1527268442388};\\\", \\\"{x:1575,y:1101,t:1527268442405};\\\", \\\"{x:1573,y:1094,t:1527268442422};\\\", \\\"{x:1571,y:1087,t:1527268442438};\\\", \\\"{x:1569,y:1081,t:1527268442455};\\\", \\\"{x:1565,y:1075,t:1527268442472};\\\", \\\"{x:1563,y:1071,t:1527268442488};\\\", \\\"{x:1557,y:1065,t:1527268442505};\\\", \\\"{x:1546,y:1060,t:1527268442522};\\\", \\\"{x:1530,y:1052,t:1527268442538};\\\", \\\"{x:1509,y:1042,t:1527268442555};\\\", \\\"{x:1479,y:1034,t:1527268442572};\\\", \\\"{x:1443,y:1029,t:1527268442589};\\\", \\\"{x:1396,y:1016,t:1527268442605};\\\", \\\"{x:1334,y:1005,t:1527268442622};\\\", \\\"{x:1278,y:995,t:1527268442639};\\\", \\\"{x:1242,y:986,t:1527268442656};\\\", \\\"{x:1219,y:983,t:1527268442672};\\\", \\\"{x:1216,y:982,t:1527268442690};\\\", \\\"{x:1216,y:981,t:1527268442786};\\\", \\\"{x:1218,y:980,t:1527268442792};\\\", \\\"{x:1225,y:976,t:1527268442806};\\\", \\\"{x:1238,y:970,t:1527268442824};\\\", \\\"{x:1250,y:965,t:1527268442839};\\\", \\\"{x:1253,y:964,t:1527268442855};\\\", \\\"{x:1256,y:962,t:1527268442872};\\\", \\\"{x:1257,y:962,t:1527268442890};\\\", \\\"{x:1259,y:961,t:1527268442928};\\\", \\\"{x:1265,y:958,t:1527268442940};\\\", \\\"{x:1272,y:957,t:1527268442957};\\\", \\\"{x:1277,y:954,t:1527268442972};\\\", \\\"{x:1279,y:954,t:1527268442990};\\\", \\\"{x:1282,y:953,t:1527268443041};\\\", \\\"{x:1291,y:951,t:1527268443056};\\\", \\\"{x:1306,y:951,t:1527268443073};\\\", \\\"{x:1317,y:951,t:1527268443089};\\\", \\\"{x:1324,y:951,t:1527268443106};\\\", \\\"{x:1322,y:951,t:1527268443201};\\\", \\\"{x:1320,y:951,t:1527268443209};\\\", \\\"{x:1317,y:952,t:1527268443223};\\\", \\\"{x:1317,y:953,t:1527268443239};\\\", \\\"{x:1317,y:954,t:1527268443360};\\\", \\\"{x:1321,y:956,t:1527268443373};\\\", \\\"{x:1326,y:957,t:1527268443389};\\\", \\\"{x:1330,y:957,t:1527268443406};\\\", \\\"{x:1332,y:958,t:1527268443424};\\\", \\\"{x:1333,y:958,t:1527268443440};\\\", \\\"{x:1335,y:958,t:1527268443713};\\\", \\\"{x:1336,y:960,t:1527268443724};\\\", \\\"{x:1340,y:967,t:1527268443741};\\\", \\\"{x:1343,y:970,t:1527268443757};\\\", \\\"{x:1344,y:972,t:1527268443774};\\\", \\\"{x:1344,y:973,t:1527268444036};\\\", \\\"{x:1346,y:973,t:1527268444043};\\\", \\\"{x:1346,y:969,t:1527268444828};\\\", \\\"{x:1346,y:947,t:1527268444846};\\\", \\\"{x:1346,y:935,t:1527268444862};\\\", \\\"{x:1346,y:928,t:1527268444878};\\\", \\\"{x:1346,y:925,t:1527268444895};\\\", \\\"{x:1346,y:922,t:1527268444912};\\\", \\\"{x:1346,y:918,t:1527268444928};\\\", \\\"{x:1346,y:908,t:1527268444944};\\\", \\\"{x:1351,y:895,t:1527268444962};\\\", \\\"{x:1355,y:879,t:1527268444978};\\\", \\\"{x:1355,y:857,t:1527268444995};\\\", \\\"{x:1355,y:837,t:1527268445012};\\\", \\\"{x:1350,y:827,t:1527268445028};\\\", \\\"{x:1344,y:816,t:1527268445045};\\\", \\\"{x:1342,y:814,t:1527268445062};\\\", \\\"{x:1342,y:813,t:1527268445100};\\\", \\\"{x:1340,y:812,t:1527268445112};\\\", \\\"{x:1340,y:810,t:1527268445129};\\\", \\\"{x:1339,y:808,t:1527268445144};\\\", \\\"{x:1339,y:807,t:1527268445162};\\\", \\\"{x:1339,y:805,t:1527268445212};\\\", \\\"{x:1339,y:804,t:1527268445276};\\\", \\\"{x:1339,y:802,t:1527268445283};\\\", \\\"{x:1339,y:800,t:1527268445295};\\\", \\\"{x:1339,y:793,t:1527268445311};\\\", \\\"{x:1339,y:789,t:1527268445328};\\\", \\\"{x:1340,y:783,t:1527268445346};\\\", \\\"{x:1340,y:781,t:1527268445362};\\\", \\\"{x:1342,y:777,t:1527268445378};\\\", \\\"{x:1342,y:774,t:1527268445395};\\\", \\\"{x:1343,y:771,t:1527268445412};\\\", \\\"{x:1344,y:768,t:1527268445428};\\\", \\\"{x:1344,y:767,t:1527268445447};\\\", \\\"{x:1346,y:763,t:1527268445462};\\\", \\\"{x:1347,y:763,t:1527268445479};\\\", \\\"{x:1348,y:761,t:1527268445495};\\\", \\\"{x:1350,y:760,t:1527268445511};\\\", \\\"{x:1350,y:759,t:1527268445588};\\\", \\\"{x:1350,y:752,t:1527268446405};\\\", \\\"{x:1350,y:738,t:1527268446414};\\\", \\\"{x:1350,y:721,t:1527268446429};\\\", \\\"{x:1350,y:709,t:1527268446446};\\\", \\\"{x:1350,y:700,t:1527268446463};\\\", \\\"{x:1350,y:696,t:1527268446479};\\\", \\\"{x:1349,y:695,t:1527268446496};\\\", \\\"{x:1349,y:694,t:1527268446515};\\\", \\\"{x:1349,y:693,t:1527268446529};\\\", \\\"{x:1349,y:689,t:1527268446547};\\\", \\\"{x:1347,y:681,t:1527268446563};\\\", \\\"{x:1346,y:679,t:1527268446579};\\\", \\\"{x:1346,y:678,t:1527268447108};\\\", \\\"{x:1345,y:676,t:1527268447373};\\\", \\\"{x:1334,y:676,t:1527268447381};\\\", \\\"{x:1300,y:671,t:1527268447398};\\\", \\\"{x:1247,y:662,t:1527268447415};\\\", \\\"{x:1184,y:650,t:1527268447431};\\\", \\\"{x:1116,y:636,t:1527268447448};\\\", \\\"{x:1033,y:611,t:1527268447464};\\\", \\\"{x:940,y:594,t:1527268447480};\\\", \\\"{x:855,y:571,t:1527268447498};\\\", \\\"{x:775,y:553,t:1527268447515};\\\", \\\"{x:728,y:539,t:1527268447530};\\\", \\\"{x:683,y:533,t:1527268447546};\\\", \\\"{x:623,y:528,t:1527268447562};\\\", \\\"{x:536,y:515,t:1527268447578};\\\", \\\"{x:409,y:504,t:1527268447595};\\\", \\\"{x:361,y:497,t:1527268447613};\\\", \\\"{x:339,y:495,t:1527268447628};\\\", \\\"{x:330,y:495,t:1527268447645};\\\", \\\"{x:327,y:495,t:1527268447663};\\\", \\\"{x:324,y:495,t:1527268447678};\\\", \\\"{x:321,y:495,t:1527268447695};\\\", \\\"{x:317,y:496,t:1527268447712};\\\", \\\"{x:307,y:501,t:1527268447728};\\\", \\\"{x:294,y:506,t:1527268447746};\\\", \\\"{x:283,y:513,t:1527268447762};\\\", \\\"{x:281,y:515,t:1527268447778};\\\", \\\"{x:281,y:516,t:1527268447868};\\\", \\\"{x:281,y:519,t:1527268447880};\\\", \\\"{x:277,y:534,t:1527268447896};\\\", \\\"{x:266,y:549,t:1527268447913};\\\", \\\"{x:251,y:563,t:1527268447929};\\\", \\\"{x:229,y:573,t:1527268447946};\\\", \\\"{x:206,y:581,t:1527268447962};\\\", \\\"{x:205,y:581,t:1527268447979};\\\", \\\"{x:204,y:581,t:1527268448148};\\\", \\\"{x:203,y:577,t:1527268448163};\\\", \\\"{x:201,y:558,t:1527268448181};\\\", \\\"{x:201,y:549,t:1527268448196};\\\", \\\"{x:200,y:540,t:1527268448212};\\\", \\\"{x:200,y:535,t:1527268448229};\\\", \\\"{x:200,y:534,t:1527268448307};\\\", \\\"{x:199,y:534,t:1527268448651};\\\", \\\"{x:198,y:534,t:1527268448662};\\\", \\\"{x:196,y:534,t:1527268448679};\\\", \\\"{x:194,y:534,t:1527268448696};\\\", \\\"{x:192,y:535,t:1527268448712};\\\", \\\"{x:191,y:535,t:1527268448756};\\\", \\\"{x:188,y:535,t:1527268448763};\\\", \\\"{x:182,y:535,t:1527268448780};\\\", \\\"{x:180,y:535,t:1527268448796};\\\", \\\"{x:178,y:535,t:1527268448915};\\\", \\\"{x:177,y:535,t:1527268448929};\\\", \\\"{x:175,y:535,t:1527268449004};\\\", \\\"{x:174,y:536,t:1527268449019};\\\", \\\"{x:172,y:537,t:1527268449029};\\\", \\\"{x:170,y:537,t:1527268449047};\\\", \\\"{x:167,y:538,t:1527268449065};\\\", \\\"{x:166,y:538,t:1527268449079};\\\", \\\"{x:165,y:538,t:1527268449097};\\\", \\\"{x:169,y:538,t:1527268449891};\\\", \\\"{x:206,y:538,t:1527268449900};\\\", \\\"{x:256,y:538,t:1527268449914};\\\", \\\"{x:350,y:538,t:1527268449932};\\\", \\\"{x:442,y:538,t:1527268449947};\\\", \\\"{x:567,y:538,t:1527268449964};\\\", \\\"{x:614,y:538,t:1527268449981};\\\", \\\"{x:642,y:538,t:1527268449998};\\\", \\\"{x:653,y:538,t:1527268450014};\\\", \\\"{x:655,y:538,t:1527268450031};\\\", \\\"{x:661,y:538,t:1527268450084};\\\", \\\"{x:669,y:538,t:1527268450098};\\\", \\\"{x:704,y:538,t:1527268450114};\\\", \\\"{x:744,y:538,t:1527268450132};\\\", \\\"{x:816,y:538,t:1527268450148};\\\", \\\"{x:867,y:538,t:1527268450165};\\\", \\\"{x:895,y:538,t:1527268450181};\\\", \\\"{x:920,y:538,t:1527268450198};\\\", \\\"{x:940,y:538,t:1527268450215};\\\", \\\"{x:950,y:538,t:1527268450230};\\\", \\\"{x:953,y:538,t:1527268450248};\\\", \\\"{x:954,y:538,t:1527268450264};\\\", \\\"{x:949,y:536,t:1527268450348};\\\", \\\"{x:929,y:527,t:1527268450363};\\\", \\\"{x:922,y:524,t:1527268450382};\\\", \\\"{x:915,y:522,t:1527268450397};\\\", \\\"{x:910,y:520,t:1527268450415};\\\", \\\"{x:909,y:520,t:1527268450431};\\\", \\\"{x:903,y:516,t:1527268450574};\\\", \\\"{x:893,y:513,t:1527268450582};\\\", \\\"{x:877,y:509,t:1527268450598};\\\", \\\"{x:863,y:507,t:1527268450616};\\\", \\\"{x:845,y:504,t:1527268450631};\\\", \\\"{x:834,y:502,t:1527268450647};\\\", \\\"{x:830,y:503,t:1527268450963};\\\", \\\"{x:814,y:529,t:1527268450971};\\\", \\\"{x:789,y:563,t:1527268450982};\\\", \\\"{x:726,y:642,t:1527268450999};\\\", \\\"{x:632,y:725,t:1527268451015};\\\", \\\"{x:537,y:795,t:1527268451031};\\\", \\\"{x:461,y:835,t:1527268451048};\\\", \\\"{x:414,y:857,t:1527268451065};\\\", \\\"{x:395,y:865,t:1527268451081};\\\", \\\"{x:394,y:866,t:1527268451098};\\\", \\\"{x:394,y:863,t:1527268451227};\\\", \\\"{x:396,y:854,t:1527268451235};\\\", \\\"{x:404,y:843,t:1527268451249};\\\", \\\"{x:415,y:830,t:1527268451265};\\\", \\\"{x:429,y:814,t:1527268451281};\\\", \\\"{x:440,y:800,t:1527268451298};\\\", \\\"{x:448,y:793,t:1527268451315};\\\", \\\"{x:465,y:779,t:1527268451332};\\\", \\\"{x:479,y:769,t:1527268451349};\\\", \\\"{x:485,y:763,t:1527268451365};\\\", \\\"{x:493,y:755,t:1527268451382};\\\", \\\"{x:495,y:752,t:1527268451399};\\\", \\\"{x:497,y:750,t:1527268451500};\\\", \\\"{x:499,y:741,t:1527268451515};\\\", \\\"{x:500,y:739,t:1527268451532};\\\" ] }, { \\\"rt\\\": 28464, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 516659, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-O -F -Z -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:471,y:739,t:1527268454301};\\\", \\\"{x:403,y:726,t:1527268454319};\\\", \\\"{x:405,y:726,t:1527268455028};\\\", \\\"{x:409,y:726,t:1527268455035};\\\", \\\"{x:423,y:729,t:1527268455051};\\\", \\\"{x:449,y:731,t:1527268455069};\\\", \\\"{x:482,y:736,t:1527268455085};\\\", \\\"{x:527,y:742,t:1527268455101};\\\", \\\"{x:587,y:745,t:1527268455118};\\\", \\\"{x:646,y:748,t:1527268455135};\\\", \\\"{x:701,y:751,t:1527268455151};\\\", \\\"{x:767,y:758,t:1527268455167};\\\", \\\"{x:820,y:758,t:1527268455184};\\\", \\\"{x:882,y:760,t:1527268455202};\\\", \\\"{x:937,y:760,t:1527268455218};\\\", \\\"{x:1012,y:765,t:1527268455234};\\\", \\\"{x:1062,y:765,t:1527268455251};\\\", \\\"{x:1123,y:765,t:1527268455268};\\\", \\\"{x:1187,y:765,t:1527268455285};\\\", \\\"{x:1243,y:765,t:1527268455302};\\\", \\\"{x:1294,y:765,t:1527268455319};\\\", \\\"{x:1338,y:765,t:1527268455335};\\\", \\\"{x:1383,y:765,t:1527268455352};\\\", \\\"{x:1425,y:765,t:1527268455367};\\\", \\\"{x:1454,y:765,t:1527268455385};\\\", \\\"{x:1472,y:765,t:1527268455402};\\\", \\\"{x:1484,y:763,t:1527268455418};\\\", \\\"{x:1492,y:759,t:1527268455436};\\\", \\\"{x:1505,y:754,t:1527268455451};\\\", \\\"{x:1510,y:751,t:1527268455468};\\\", \\\"{x:1509,y:747,t:1527268455573};\\\", \\\"{x:1502,y:743,t:1527268455585};\\\", \\\"{x:1488,y:737,t:1527268455602};\\\", \\\"{x:1476,y:731,t:1527268455618};\\\", \\\"{x:1474,y:730,t:1527268455635};\\\", \\\"{x:1472,y:729,t:1527268455724};\\\", \\\"{x:1469,y:728,t:1527268455735};\\\", \\\"{x:1457,y:722,t:1527268455752};\\\", \\\"{x:1444,y:716,t:1527268455769};\\\", \\\"{x:1430,y:710,t:1527268455785};\\\", \\\"{x:1420,y:708,t:1527268455802};\\\", \\\"{x:1410,y:705,t:1527268455819};\\\", \\\"{x:1408,y:704,t:1527268455835};\\\", \\\"{x:1406,y:704,t:1527268455892};\\\", \\\"{x:1404,y:703,t:1527268455902};\\\", \\\"{x:1402,y:702,t:1527268455919};\\\", \\\"{x:1398,y:701,t:1527268455935};\\\", \\\"{x:1396,y:700,t:1527268455952};\\\", \\\"{x:1394,y:700,t:1527268455971};\\\", \\\"{x:1393,y:700,t:1527268455985};\\\", \\\"{x:1391,y:700,t:1527268456002};\\\", \\\"{x:1386,y:700,t:1527268456019};\\\", \\\"{x:1385,y:699,t:1527268456035};\\\", \\\"{x:1382,y:699,t:1527268456052};\\\", \\\"{x:1379,y:699,t:1527268456069};\\\", \\\"{x:1378,y:699,t:1527268456086};\\\", \\\"{x:1377,y:699,t:1527268456102};\\\", \\\"{x:1376,y:699,t:1527268456164};\\\", \\\"{x:1375,y:699,t:1527268456180};\\\", \\\"{x:1373,y:699,t:1527268456188};\\\", \\\"{x:1370,y:699,t:1527268456203};\\\", \\\"{x:1359,y:699,t:1527268456219};\\\", \\\"{x:1349,y:702,t:1527268456238};\\\", \\\"{x:1339,y:703,t:1527268456254};\\\", \\\"{x:1332,y:703,t:1527268456270};\\\", \\\"{x:1331,y:703,t:1527268456286};\\\", \\\"{x:1332,y:703,t:1527268456508};\\\", \\\"{x:1334,y:703,t:1527268456635};\\\", \\\"{x:1340,y:706,t:1527268456652};\\\", \\\"{x:1341,y:706,t:1527268456669};\\\", \\\"{x:1342,y:706,t:1527268456772};\\\", \\\"{x:1344,y:706,t:1527268456786};\\\", \\\"{x:1350,y:707,t:1527268456804};\\\", \\\"{x:1364,y:703,t:1527268460956};\\\", \\\"{x:1414,y:696,t:1527268460973};\\\", \\\"{x:1461,y:690,t:1527268460990};\\\", \\\"{x:1493,y:687,t:1527268461006};\\\", \\\"{x:1517,y:687,t:1527268461023};\\\", \\\"{x:1527,y:687,t:1527268461040};\\\", \\\"{x:1530,y:687,t:1527268461056};\\\", \\\"{x:1533,y:687,t:1527268461157};\\\", \\\"{x:1538,y:687,t:1527268461173};\\\", \\\"{x:1545,y:687,t:1527268461190};\\\", \\\"{x:1548,y:687,t:1527268461206};\\\", \\\"{x:1549,y:687,t:1527268461228};\\\", \\\"{x:1551,y:687,t:1527268461268};\\\", \\\"{x:1554,y:687,t:1527268461276};\\\", \\\"{x:1558,y:687,t:1527268461289};\\\", \\\"{x:1565,y:689,t:1527268461305};\\\", \\\"{x:1569,y:689,t:1527268461322};\\\", \\\"{x:1570,y:689,t:1527268461379};\\\", \\\"{x:1571,y:689,t:1527268461390};\\\", \\\"{x:1575,y:690,t:1527268461405};\\\", \\\"{x:1584,y:691,t:1527268461422};\\\", \\\"{x:1592,y:693,t:1527268461439};\\\", \\\"{x:1595,y:693,t:1527268461456};\\\", \\\"{x:1598,y:693,t:1527268461472};\\\", \\\"{x:1599,y:693,t:1527268461547};\\\", \\\"{x:1601,y:693,t:1527268461563};\\\", \\\"{x:1602,y:693,t:1527268461572};\\\", \\\"{x:1603,y:693,t:1527268461590};\\\", \\\"{x:1604,y:693,t:1527268461644};\\\", \\\"{x:1605,y:693,t:1527268461657};\\\", \\\"{x:1610,y:694,t:1527268461674};\\\", \\\"{x:1614,y:695,t:1527268461690};\\\", \\\"{x:1620,y:695,t:1527268461706};\\\", \\\"{x:1625,y:697,t:1527268461724};\\\", \\\"{x:1632,y:699,t:1527268461739};\\\", \\\"{x:1627,y:699,t:1527268470173};\\\", \\\"{x:1610,y:708,t:1527268470180};\\\", \\\"{x:1596,y:712,t:1527268470195};\\\", \\\"{x:1525,y:723,t:1527268470212};\\\", \\\"{x:1463,y:731,t:1527268470230};\\\", \\\"{x:1402,y:738,t:1527268470245};\\\", \\\"{x:1361,y:742,t:1527268470262};\\\", \\\"{x:1343,y:745,t:1527268470279};\\\", \\\"{x:1335,y:746,t:1527268470295};\\\", \\\"{x:1334,y:746,t:1527268470312};\\\", \\\"{x:1331,y:746,t:1527268470692};\\\", \\\"{x:1323,y:746,t:1527268470700};\\\", \\\"{x:1317,y:746,t:1527268470712};\\\", \\\"{x:1308,y:745,t:1527268470730};\\\", \\\"{x:1303,y:744,t:1527268470746};\\\", \\\"{x:1302,y:744,t:1527268470762};\\\", \\\"{x:1292,y:744,t:1527268478747};\\\", \\\"{x:1259,y:744,t:1527268478755};\\\", \\\"{x:1198,y:744,t:1527268478767};\\\", \\\"{x:1104,y:744,t:1527268478784};\\\", \\\"{x:1015,y:744,t:1527268478801};\\\", \\\"{x:931,y:747,t:1527268478817};\\\", \\\"{x:863,y:749,t:1527268478834};\\\", \\\"{x:829,y:749,t:1527268478851};\\\", \\\"{x:826,y:746,t:1527268478867};\\\", \\\"{x:806,y:746,t:1527268478884};\\\", \\\"{x:801,y:746,t:1527268478901};\\\", \\\"{x:798,y:746,t:1527268478917};\\\", \\\"{x:794,y:746,t:1527268478934};\\\", \\\"{x:781,y:746,t:1527268478951};\\\", \\\"{x:744,y:746,t:1527268478968};\\\", \\\"{x:656,y:746,t:1527268478985};\\\", \\\"{x:523,y:746,t:1527268479002};\\\", \\\"{x:356,y:739,t:1527268479018};\\\", \\\"{x:186,y:726,t:1527268479034};\\\", \\\"{x:170,y:723,t:1527268479046};\\\", \\\"{x:169,y:723,t:1527268479062};\\\", \\\"{x:169,y:718,t:1527268479146};\\\", \\\"{x:169,y:711,t:1527268479162};\\\", \\\"{x:169,y:699,t:1527268479179};\\\", \\\"{x:169,y:693,t:1527268479196};\\\", \\\"{x:169,y:681,t:1527268479212};\\\", \\\"{x:172,y:668,t:1527268479230};\\\", \\\"{x:172,y:667,t:1527268479246};\\\", \\\"{x:172,y:666,t:1527268479476};\\\", \\\"{x:172,y:665,t:1527268479499};\\\", \\\"{x:172,y:661,t:1527268479508};\\\", \\\"{x:172,y:652,t:1527268479520};\\\", \\\"{x:162,y:630,t:1527268479538};\\\", \\\"{x:153,y:603,t:1527268479554};\\\", \\\"{x:146,y:568,t:1527268479572};\\\", \\\"{x:144,y:551,t:1527268479588};\\\", \\\"{x:144,y:541,t:1527268479604};\\\", \\\"{x:144,y:538,t:1527268479621};\\\", \\\"{x:144,y:536,t:1527268479637};\\\", \\\"{x:144,y:535,t:1527268479690};\\\", \\\"{x:146,y:534,t:1527268479704};\\\", \\\"{x:150,y:532,t:1527268479721};\\\", \\\"{x:151,y:531,t:1527268479738};\\\", \\\"{x:153,y:531,t:1527268480211};\\\", \\\"{x:159,y:531,t:1527268480221};\\\", \\\"{x:172,y:539,t:1527268480238};\\\", \\\"{x:190,y:551,t:1527268480256};\\\", \\\"{x:215,y:569,t:1527268480272};\\\", \\\"{x:265,y:598,t:1527268480288};\\\", \\\"{x:297,y:617,t:1527268480305};\\\", \\\"{x:330,y:636,t:1527268480322};\\\", \\\"{x:353,y:651,t:1527268480339};\\\", \\\"{x:377,y:669,t:1527268480355};\\\", \\\"{x:391,y:681,t:1527268480372};\\\", \\\"{x:398,y:687,t:1527268480388};\\\", \\\"{x:404,y:694,t:1527268480405};\\\", \\\"{x:408,y:698,t:1527268480421};\\\", \\\"{x:409,y:699,t:1527268480439};\\\", \\\"{x:409,y:701,t:1527268480456};\\\", \\\"{x:411,y:704,t:1527268480471};\\\", \\\"{x:414,y:708,t:1527268480488};\\\", \\\"{x:416,y:711,t:1527268480505};\\\", \\\"{x:416,y:712,t:1527268480523};\\\", \\\"{x:417,y:712,t:1527268480547};\\\", \\\"{x:417,y:713,t:1527268480556};\\\", \\\"{x:425,y:718,t:1527268480572};\\\", \\\"{x:437,y:724,t:1527268480588};\\\", \\\"{x:446,y:731,t:1527268480606};\\\", \\\"{x:454,y:736,t:1527268480621};\\\", \\\"{x:460,y:740,t:1527268480639};\\\", \\\"{x:462,y:740,t:1527268480655};\\\", \\\"{x:463,y:740,t:1527268480707};\\\", \\\"{x:463,y:741,t:1527268480722};\\\", \\\"{x:470,y:743,t:1527268480738};\\\", \\\"{x:471,y:743,t:1527268480756};\\\", \\\"{x:468,y:743,t:1527268482406};\\\", \\\"{x:467,y:743,t:1527268482423};\\\", \\\"{x:466,y:743,t:1527268482440};\\\" ] }, { \\\"rt\\\": 48815, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 566682, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -O -Z -Z -N -Z -Z -Z -Z -Z -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:466,y:742,t:1527268482826};\\\", \\\"{x:466,y:736,t:1527268482840};\\\", \\\"{x:460,y:717,t:1527268482856};\\\", \\\"{x:455,y:697,t:1527268482873};\\\", \\\"{x:452,y:679,t:1527268482890};\\\", \\\"{x:440,y:638,t:1527268482907};\\\", \\\"{x:433,y:598,t:1527268482924};\\\", \\\"{x:433,y:554,t:1527268482941};\\\", \\\"{x:433,y:522,t:1527268482957};\\\", \\\"{x:434,y:509,t:1527268482975};\\\", \\\"{x:434,y:495,t:1527268482990};\\\", \\\"{x:434,y:481,t:1527268483008};\\\", \\\"{x:436,y:471,t:1527268483024};\\\", \\\"{x:439,y:467,t:1527268483041};\\\", \\\"{x:439,y:461,t:1527268483057};\\\", \\\"{x:439,y:459,t:1527268483075};\\\", \\\"{x:446,y:450,t:1527268483165};\\\", \\\"{x:447,y:450,t:1527268483186};\\\", \\\"{x:448,y:449,t:1527268483194};\\\", \\\"{x:449,y:449,t:1527268483218};\\\", \\\"{x:451,y:449,t:1527268483234};\\\", \\\"{x:455,y:449,t:1527268483242};\\\", \\\"{x:458,y:449,t:1527268483257};\\\", \\\"{x:470,y:449,t:1527268483274};\\\", \\\"{x:489,y:453,t:1527268483290};\\\", \\\"{x:521,y:458,t:1527268483307};\\\", \\\"{x:545,y:463,t:1527268483324};\\\", \\\"{x:568,y:468,t:1527268483340};\\\", \\\"{x:590,y:470,t:1527268483358};\\\", \\\"{x:607,y:471,t:1527268483374};\\\", \\\"{x:626,y:475,t:1527268483390};\\\", \\\"{x:648,y:479,t:1527268483408};\\\", \\\"{x:668,y:479,t:1527268483425};\\\", \\\"{x:685,y:479,t:1527268483441};\\\", \\\"{x:699,y:479,t:1527268483458};\\\", \\\"{x:710,y:479,t:1527268483475};\\\", \\\"{x:732,y:480,t:1527268483491};\\\", \\\"{x:740,y:480,t:1527268483508};\\\", \\\"{x:742,y:481,t:1527268483524};\\\", \\\"{x:743,y:481,t:1527268484044};\\\", \\\"{x:746,y:481,t:1527268484058};\\\", \\\"{x:755,y:481,t:1527268484075};\\\", \\\"{x:762,y:480,t:1527268484091};\\\", \\\"{x:769,y:479,t:1527268484109};\\\", \\\"{x:777,y:479,t:1527268484124};\\\", \\\"{x:795,y:479,t:1527268484141};\\\", \\\"{x:817,y:479,t:1527268484158};\\\", \\\"{x:844,y:479,t:1527268484175};\\\", \\\"{x:874,y:479,t:1527268484192};\\\", \\\"{x:902,y:479,t:1527268484209};\\\", \\\"{x:944,y:479,t:1527268484225};\\\", \\\"{x:1011,y:479,t:1527268484242};\\\", \\\"{x:1086,y:479,t:1527268484259};\\\", \\\"{x:1170,y:479,t:1527268484275};\\\", \\\"{x:1297,y:479,t:1527268484292};\\\", \\\"{x:1381,y:479,t:1527268484309};\\\", \\\"{x:1456,y:479,t:1527268484325};\\\", \\\"{x:1514,y:479,t:1527268484342};\\\", \\\"{x:1562,y:479,t:1527268484359};\\\", \\\"{x:1592,y:479,t:1527268484375};\\\", \\\"{x:1615,y:479,t:1527268484391};\\\", \\\"{x:1629,y:479,t:1527268484408};\\\", \\\"{x:1647,y:479,t:1527268484424};\\\", \\\"{x:1657,y:479,t:1527268484441};\\\", \\\"{x:1661,y:480,t:1527268484459};\\\", \\\"{x:1666,y:481,t:1527268484476};\\\", \\\"{x:1665,y:481,t:1527268484724};\\\", \\\"{x:1660,y:481,t:1527268484732};\\\", \\\"{x:1650,y:479,t:1527268484741};\\\", \\\"{x:1636,y:477,t:1527268484758};\\\", \\\"{x:1630,y:477,t:1527268484775};\\\", \\\"{x:1629,y:477,t:1527268484791};\\\", \\\"{x:1628,y:477,t:1527268485028};\\\", \\\"{x:1626,y:477,t:1527268485188};\\\", \\\"{x:1626,y:480,t:1527268485195};\\\", \\\"{x:1626,y:483,t:1527268485209};\\\", \\\"{x:1624,y:494,t:1527268485225};\\\", \\\"{x:1623,y:501,t:1527268485243};\\\", \\\"{x:1620,y:508,t:1527268485258};\\\", \\\"{x:1619,y:516,t:1527268485276};\\\", \\\"{x:1619,y:520,t:1527268485293};\\\", \\\"{x:1619,y:524,t:1527268485309};\\\", \\\"{x:1618,y:527,t:1527268485326};\\\", \\\"{x:1618,y:531,t:1527268485342};\\\", \\\"{x:1616,y:535,t:1527268485358};\\\", \\\"{x:1616,y:541,t:1527268485376};\\\", \\\"{x:1615,y:551,t:1527268485393};\\\", \\\"{x:1610,y:568,t:1527268485408};\\\", \\\"{x:1604,y:582,t:1527268485425};\\\", \\\"{x:1595,y:601,t:1527268485443};\\\", \\\"{x:1582,y:632,t:1527268485462};\\\", \\\"{x:1573,y:654,t:1527268485475};\\\", \\\"{x:1564,y:677,t:1527268485493};\\\", \\\"{x:1554,y:700,t:1527268485509};\\\", \\\"{x:1545,y:719,t:1527268485525};\\\", \\\"{x:1533,y:741,t:1527268485543};\\\", \\\"{x:1525,y:756,t:1527268485559};\\\", \\\"{x:1518,y:767,t:1527268485576};\\\", \\\"{x:1510,y:780,t:1527268485593};\\\", \\\"{x:1501,y:795,t:1527268485610};\\\", \\\"{x:1491,y:818,t:1527268485625};\\\", \\\"{x:1483,y:838,t:1527268485643};\\\", \\\"{x:1471,y:870,t:1527268485659};\\\", \\\"{x:1455,y:895,t:1527268485676};\\\", \\\"{x:1442,y:913,t:1527268485693};\\\", \\\"{x:1432,y:926,t:1527268485710};\\\", \\\"{x:1425,y:934,t:1527268485726};\\\", \\\"{x:1425,y:935,t:1527268485803};\\\", \\\"{x:1424,y:936,t:1527268485843};\\\", \\\"{x:1423,y:939,t:1527268485859};\\\", \\\"{x:1421,y:942,t:1527268485876};\\\", \\\"{x:1420,y:943,t:1527268485893};\\\", \\\"{x:1420,y:945,t:1527268485909};\\\", \\\"{x:1419,y:946,t:1527268485931};\\\", \\\"{x:1418,y:946,t:1527268485988};\\\", \\\"{x:1418,y:945,t:1527268487332};\\\", \\\"{x:1418,y:941,t:1527268487345};\\\", \\\"{x:1418,y:934,t:1527268487361};\\\", \\\"{x:1418,y:931,t:1527268487378};\\\", \\\"{x:1418,y:930,t:1527268487393};\\\", \\\"{x:1418,y:928,t:1527268487410};\\\", \\\"{x:1417,y:927,t:1527268488412};\\\", \\\"{x:1417,y:924,t:1527268488428};\\\", \\\"{x:1417,y:907,t:1527268488445};\\\", \\\"{x:1418,y:897,t:1527268488462};\\\", \\\"{x:1423,y:885,t:1527268488478};\\\", \\\"{x:1426,y:880,t:1527268488495};\\\", \\\"{x:1426,y:879,t:1527268488512};\\\", \\\"{x:1427,y:878,t:1527268488532};\\\", \\\"{x:1429,y:877,t:1527268488588};\\\", \\\"{x:1430,y:877,t:1527268488596};\\\", \\\"{x:1434,y:872,t:1527268488612};\\\", \\\"{x:1440,y:864,t:1527268488629};\\\", \\\"{x:1444,y:861,t:1527268488645};\\\", \\\"{x:1447,y:857,t:1527268488662};\\\", \\\"{x:1448,y:856,t:1527268488722};\\\", \\\"{x:1448,y:854,t:1527268488730};\\\", \\\"{x:1449,y:853,t:1527268488746};\\\", \\\"{x:1450,y:852,t:1527268488761};\\\", \\\"{x:1450,y:851,t:1527268488787};\\\", \\\"{x:1450,y:850,t:1527268488843};\\\", \\\"{x:1450,y:849,t:1527268488859};\\\", \\\"{x:1451,y:848,t:1527268488866};\\\", \\\"{x:1450,y:847,t:1527268489779};\\\", \\\"{x:1446,y:846,t:1527268489796};\\\", \\\"{x:1445,y:846,t:1527268489819};\\\", \\\"{x:1445,y:845,t:1527268489829};\\\", \\\"{x:1443,y:845,t:1527268489867};\\\", \\\"{x:1442,y:845,t:1527268489879};\\\", \\\"{x:1437,y:843,t:1527268489896};\\\", \\\"{x:1426,y:839,t:1527268489913};\\\", \\\"{x:1409,y:835,t:1527268489928};\\\", \\\"{x:1384,y:833,t:1527268489945};\\\", \\\"{x:1351,y:830,t:1527268489962};\\\", \\\"{x:1335,y:830,t:1527268489979};\\\", \\\"{x:1327,y:830,t:1527268489996};\\\", \\\"{x:1326,y:830,t:1527268490012};\\\", \\\"{x:1320,y:830,t:1527268490092};\\\", \\\"{x:1313,y:830,t:1527268490099};\\\", \\\"{x:1303,y:829,t:1527268490113};\\\", \\\"{x:1280,y:829,t:1527268490129};\\\", \\\"{x:1260,y:827,t:1527268490146};\\\", \\\"{x:1243,y:827,t:1527268490164};\\\", \\\"{x:1242,y:827,t:1527268490179};\\\", \\\"{x:1241,y:827,t:1527268490356};\\\", \\\"{x:1245,y:824,t:1527268490363};\\\", \\\"{x:1256,y:819,t:1527268490379};\\\", \\\"{x:1263,y:816,t:1527268490396};\\\", \\\"{x:1264,y:816,t:1527268490452};\\\", \\\"{x:1268,y:816,t:1527268490463};\\\", \\\"{x:1276,y:816,t:1527268490480};\\\", \\\"{x:1280,y:818,t:1527268490496};\\\", \\\"{x:1282,y:818,t:1527268490513};\\\", \\\"{x:1283,y:818,t:1527268490530};\\\", \\\"{x:1285,y:820,t:1527268490546};\\\", \\\"{x:1290,y:820,t:1527268490564};\\\", \\\"{x:1297,y:823,t:1527268490580};\\\", \\\"{x:1305,y:826,t:1527268490596};\\\", \\\"{x:1312,y:827,t:1527268490613};\\\", \\\"{x:1318,y:829,t:1527268490630};\\\", \\\"{x:1327,y:830,t:1527268490646};\\\", \\\"{x:1332,y:832,t:1527268490664};\\\", \\\"{x:1335,y:832,t:1527268490680};\\\", \\\"{x:1339,y:833,t:1527268490697};\\\", \\\"{x:1346,y:833,t:1527268490713};\\\", \\\"{x:1352,y:836,t:1527268490731};\\\", \\\"{x:1357,y:838,t:1527268490747};\\\", \\\"{x:1361,y:838,t:1527268490763};\\\", \\\"{x:1369,y:841,t:1527268490780};\\\", \\\"{x:1379,y:843,t:1527268490797};\\\", \\\"{x:1388,y:845,t:1527268490813};\\\", \\\"{x:1393,y:845,t:1527268490830};\\\", \\\"{x:1396,y:845,t:1527268490847};\\\", \\\"{x:1398,y:845,t:1527268490863};\\\", \\\"{x:1399,y:845,t:1527268490881};\\\", \\\"{x:1401,y:845,t:1527268490897};\\\", \\\"{x:1402,y:845,t:1527268490914};\\\", \\\"{x:1404,y:845,t:1527268490930};\\\", \\\"{x:1405,y:845,t:1527268490948};\\\", \\\"{x:1406,y:845,t:1527268490963};\\\", \\\"{x:1407,y:845,t:1527268490980};\\\", \\\"{x:1409,y:842,t:1527268491148};\\\", \\\"{x:1412,y:834,t:1527268491163};\\\", \\\"{x:1418,y:823,t:1527268491180};\\\", \\\"{x:1422,y:818,t:1527268491197};\\\", \\\"{x:1423,y:814,t:1527268491213};\\\", \\\"{x:1425,y:812,t:1527268491230};\\\", \\\"{x:1425,y:808,t:1527268491248};\\\", \\\"{x:1426,y:805,t:1527268491265};\\\", \\\"{x:1428,y:802,t:1527268491280};\\\", \\\"{x:1430,y:798,t:1527268491297};\\\", \\\"{x:1432,y:794,t:1527268491314};\\\", \\\"{x:1434,y:789,t:1527268491330};\\\", \\\"{x:1455,y:755,t:1527268491347};\\\", \\\"{x:1476,y:690,t:1527268491364};\\\", \\\"{x:1488,y:657,t:1527268491380};\\\", \\\"{x:1498,y:646,t:1527268491397};\\\", \\\"{x:1505,y:635,t:1527268491414};\\\", \\\"{x:1509,y:624,t:1527268491430};\\\", \\\"{x:1513,y:620,t:1527268491446};\\\", \\\"{x:1513,y:618,t:1527268491463};\\\", \\\"{x:1514,y:617,t:1527268491480};\\\", \\\"{x:1514,y:616,t:1527268491498};\\\", \\\"{x:1514,y:615,t:1527268491514};\\\", \\\"{x:1515,y:612,t:1527268491530};\\\", \\\"{x:1517,y:608,t:1527268491546};\\\", \\\"{x:1518,y:605,t:1527268491563};\\\", \\\"{x:1519,y:605,t:1527268491804};\\\", \\\"{x:1520,y:608,t:1527268491814};\\\", \\\"{x:1525,y:619,t:1527268491831};\\\", \\\"{x:1528,y:628,t:1527268491846};\\\", \\\"{x:1529,y:635,t:1527268491864};\\\", \\\"{x:1530,y:641,t:1527268491881};\\\", \\\"{x:1536,y:649,t:1527268491897};\\\", \\\"{x:1548,y:654,t:1527268491914};\\\", \\\"{x:1572,y:660,t:1527268491932};\\\", \\\"{x:1580,y:660,t:1527268491947};\\\", \\\"{x:1581,y:661,t:1527268491964};\\\", \\\"{x:1581,y:662,t:1527268492003};\\\", \\\"{x:1581,y:664,t:1527268492019};\\\", \\\"{x:1581,y:665,t:1527268492036};\\\", \\\"{x:1582,y:666,t:1527268492047};\\\", \\\"{x:1586,y:670,t:1527268492065};\\\", \\\"{x:1592,y:674,t:1527268492081};\\\", \\\"{x:1595,y:677,t:1527268492097};\\\", \\\"{x:1597,y:678,t:1527268492114};\\\", \\\"{x:1598,y:678,t:1527268492148};\\\", \\\"{x:1600,y:680,t:1527268492188};\\\", \\\"{x:1601,y:681,t:1527268492197};\\\", \\\"{x:1606,y:685,t:1527268492215};\\\", \\\"{x:1612,y:690,t:1527268492231};\\\", \\\"{x:1617,y:695,t:1527268492249};\\\", \\\"{x:1618,y:696,t:1527268492265};\\\", \\\"{x:1619,y:697,t:1527268492281};\\\", \\\"{x:1619,y:706,t:1527268500724};\\\", \\\"{x:1620,y:721,t:1527268500738};\\\", \\\"{x:1622,y:746,t:1527268500753};\\\", \\\"{x:1628,y:767,t:1527268500770};\\\", \\\"{x:1628,y:787,t:1527268500787};\\\", \\\"{x:1629,y:795,t:1527268500803};\\\", \\\"{x:1629,y:797,t:1527268500820};\\\", \\\"{x:1630,y:798,t:1527268500837};\\\", \\\"{x:1631,y:803,t:1527268500853};\\\", \\\"{x:1631,y:809,t:1527268500870};\\\", \\\"{x:1633,y:823,t:1527268500887};\\\", \\\"{x:1634,y:835,t:1527268500904};\\\", \\\"{x:1634,y:854,t:1527268500920};\\\", \\\"{x:1634,y:864,t:1527268500937};\\\", \\\"{x:1634,y:867,t:1527268500954};\\\", \\\"{x:1634,y:868,t:1527268500971};\\\", \\\"{x:1634,y:869,t:1527268500987};\\\", \\\"{x:1634,y:870,t:1527268501179};\\\", \\\"{x:1636,y:870,t:1527268501188};\\\", \\\"{x:1637,y:870,t:1527268501205};\\\", \\\"{x:1639,y:870,t:1527268501260};\\\", \\\"{x:1640,y:870,t:1527268501275};\\\", \\\"{x:1642,y:870,t:1527268501316};\\\", \\\"{x:1643,y:870,t:1527268501323};\\\", \\\"{x:1644,y:870,t:1527268501338};\\\", \\\"{x:1646,y:870,t:1527268501354};\\\", \\\"{x:1647,y:870,t:1527268501397};\\\", \\\"{x:1649,y:870,t:1527268501468};\\\", \\\"{x:1654,y:869,t:1527268501475};\\\", \\\"{x:1655,y:867,t:1527268501500};\\\", \\\"{x:1658,y:865,t:1527268501507};\\\", \\\"{x:1659,y:863,t:1527268501521};\\\", \\\"{x:1663,y:860,t:1527268501538};\\\", \\\"{x:1664,y:858,t:1527268501554};\\\", \\\"{x:1666,y:856,t:1527268501572};\\\", \\\"{x:1666,y:855,t:1527268501588};\\\", \\\"{x:1671,y:848,t:1527268501605};\\\", \\\"{x:1674,y:842,t:1527268501622};\\\", \\\"{x:1678,y:837,t:1527268501637};\\\", \\\"{x:1680,y:834,t:1527268501655};\\\", \\\"{x:1682,y:826,t:1527268501672};\\\", \\\"{x:1685,y:817,t:1527268501689};\\\", \\\"{x:1686,y:810,t:1527268501705};\\\", \\\"{x:1686,y:805,t:1527268501722};\\\", \\\"{x:1686,y:797,t:1527268501738};\\\", \\\"{x:1683,y:785,t:1527268501754};\\\", \\\"{x:1681,y:779,t:1527268501772};\\\", \\\"{x:1680,y:776,t:1527268501788};\\\", \\\"{x:1677,y:774,t:1527268501805};\\\", \\\"{x:1670,y:768,t:1527268501821};\\\", \\\"{x:1653,y:756,t:1527268501838};\\\", \\\"{x:1615,y:733,t:1527268501854};\\\", \\\"{x:1580,y:713,t:1527268501871};\\\", \\\"{x:1569,y:708,t:1527268501888};\\\", \\\"{x:1567,y:707,t:1527268501904};\\\", \\\"{x:1570,y:704,t:1527268502027};\\\", \\\"{x:1578,y:701,t:1527268502039};\\\", \\\"{x:1583,y:699,t:1527268502055};\\\", \\\"{x:1586,y:697,t:1527268502071};\\\", \\\"{x:1587,y:697,t:1527268502088};\\\", \\\"{x:1588,y:697,t:1527268503100};\\\", \\\"{x:1589,y:704,t:1527268503107};\\\", \\\"{x:1591,y:709,t:1527268503123};\\\", \\\"{x:1591,y:719,t:1527268503138};\\\", \\\"{x:1591,y:723,t:1527268503155};\\\", \\\"{x:1591,y:724,t:1527268503459};\\\", \\\"{x:1591,y:727,t:1527268503472};\\\", \\\"{x:1602,y:729,t:1527268503490};\\\", \\\"{x:1609,y:729,t:1527268503505};\\\", \\\"{x:1617,y:729,t:1527268503522};\\\", \\\"{x:1621,y:729,t:1527268503539};\\\", \\\"{x:1621,y:728,t:1527268503764};\\\", \\\"{x:1621,y:724,t:1527268503780};\\\", \\\"{x:1621,y:722,t:1527268503790};\\\", \\\"{x:1621,y:717,t:1527268503806};\\\", \\\"{x:1621,y:716,t:1527268503822};\\\", \\\"{x:1621,y:713,t:1527268503839};\\\", \\\"{x:1621,y:712,t:1527268503857};\\\", \\\"{x:1621,y:711,t:1527268503873};\\\", \\\"{x:1621,y:709,t:1527268504112};\\\", \\\"{x:1620,y:708,t:1527268504126};\\\", \\\"{x:1619,y:707,t:1527268504143};\\\", \\\"{x:1618,y:705,t:1527268504160};\\\", \\\"{x:1617,y:704,t:1527268504495};\\\", \\\"{x:1616,y:699,t:1527268504527};\\\", \\\"{x:1616,y:696,t:1527268504543};\\\", \\\"{x:1615,y:692,t:1527268504560};\\\", \\\"{x:1614,y:690,t:1527268504577};\\\", \\\"{x:1614,y:689,t:1527268504593};\\\", \\\"{x:1614,y:694,t:1527268506448};\\\", \\\"{x:1614,y:705,t:1527268506462};\\\", \\\"{x:1614,y:721,t:1527268506478};\\\", \\\"{x:1608,y:737,t:1527268506495};\\\", \\\"{x:1607,y:741,t:1527268506512};\\\", \\\"{x:1607,y:742,t:1527268506567};\\\", \\\"{x:1607,y:744,t:1527268506583};\\\", \\\"{x:1607,y:749,t:1527268506596};\\\", \\\"{x:1607,y:758,t:1527268506611};\\\", \\\"{x:1607,y:768,t:1527268506629};\\\", \\\"{x:1609,y:777,t:1527268506645};\\\", \\\"{x:1609,y:785,t:1527268506662};\\\", \\\"{x:1609,y:793,t:1527268506678};\\\", \\\"{x:1610,y:810,t:1527268506695};\\\", \\\"{x:1612,y:823,t:1527268506711};\\\", \\\"{x:1615,y:840,t:1527268506728};\\\", \\\"{x:1617,y:857,t:1527268506745};\\\", \\\"{x:1619,y:869,t:1527268506761};\\\", \\\"{x:1620,y:878,t:1527268506778};\\\", \\\"{x:1622,y:890,t:1527268506795};\\\", \\\"{x:1626,y:905,t:1527268506812};\\\", \\\"{x:1637,y:931,t:1527268506828};\\\", \\\"{x:1658,y:973,t:1527268506845};\\\", \\\"{x:1666,y:998,t:1527268506862};\\\", \\\"{x:1666,y:1007,t:1527268506878};\\\", \\\"{x:1666,y:1019,t:1527268506895};\\\", \\\"{x:1666,y:1029,t:1527268506912};\\\", \\\"{x:1666,y:1034,t:1527268506928};\\\", \\\"{x:1665,y:1036,t:1527268506945};\\\", \\\"{x:1664,y:1038,t:1527268506962};\\\", \\\"{x:1664,y:1039,t:1527268507047};\\\", \\\"{x:1657,y:1034,t:1527268507063};\\\", \\\"{x:1645,y:1009,t:1527268507078};\\\", \\\"{x:1636,y:990,t:1527268507095};\\\", \\\"{x:1629,y:966,t:1527268507112};\\\", \\\"{x:1620,y:936,t:1527268507129};\\\", \\\"{x:1617,y:921,t:1527268507145};\\\", \\\"{x:1617,y:917,t:1527268507162};\\\", \\\"{x:1617,y:913,t:1527268507179};\\\", \\\"{x:1617,y:907,t:1527268507195};\\\", \\\"{x:1616,y:899,t:1527268507213};\\\", \\\"{x:1616,y:895,t:1527268507229};\\\", \\\"{x:1615,y:891,t:1527268507246};\\\", \\\"{x:1614,y:880,t:1527268507262};\\\", \\\"{x:1613,y:875,t:1527268507278};\\\", \\\"{x:1611,y:866,t:1527268507295};\\\", \\\"{x:1609,y:857,t:1527268507313};\\\", \\\"{x:1608,y:847,t:1527268507329};\\\", \\\"{x:1608,y:840,t:1527268507345};\\\", \\\"{x:1608,y:834,t:1527268507363};\\\", \\\"{x:1608,y:829,t:1527268507379};\\\", \\\"{x:1608,y:817,t:1527268507395};\\\", \\\"{x:1610,y:799,t:1527268507412};\\\", \\\"{x:1618,y:769,t:1527268507428};\\\", \\\"{x:1626,y:739,t:1527268507445};\\\", \\\"{x:1630,y:706,t:1527268507461};\\\", \\\"{x:1633,y:693,t:1527268507479};\\\", \\\"{x:1634,y:688,t:1527268507495};\\\", \\\"{x:1634,y:686,t:1527268507512};\\\", \\\"{x:1634,y:685,t:1527268507529};\\\", \\\"{x:1634,y:684,t:1527268507545};\\\", \\\"{x:1634,y:681,t:1527268507562};\\\", \\\"{x:1634,y:677,t:1527268507579};\\\", \\\"{x:1634,y:673,t:1527268507594};\\\", \\\"{x:1634,y:670,t:1527268507611};\\\", \\\"{x:1633,y:670,t:1527268507710};\\\", \\\"{x:1629,y:670,t:1527268507718};\\\", \\\"{x:1624,y:674,t:1527268507729};\\\", \\\"{x:1621,y:687,t:1527268507746};\\\", \\\"{x:1616,y:701,t:1527268507762};\\\", \\\"{x:1612,y:710,t:1527268507779};\\\", \\\"{x:1612,y:712,t:1527268507795};\\\", \\\"{x:1612,y:713,t:1527268507812};\\\", \\\"{x:1610,y:709,t:1527268508200};\\\", \\\"{x:1610,y:707,t:1527268508213};\\\", \\\"{x:1610,y:702,t:1527268508229};\\\", \\\"{x:1610,y:700,t:1527268508247};\\\", \\\"{x:1610,y:699,t:1527268508263};\\\", \\\"{x:1608,y:699,t:1527268523358};\\\", \\\"{x:1601,y:708,t:1527268523374};\\\", \\\"{x:1590,y:730,t:1527268523389};\\\", \\\"{x:1588,y:738,t:1527268523407};\\\", \\\"{x:1584,y:744,t:1527268523424};\\\", \\\"{x:1581,y:747,t:1527268523440};\\\", \\\"{x:1578,y:751,t:1527268523457};\\\", \\\"{x:1575,y:755,t:1527268523473};\\\", \\\"{x:1569,y:761,t:1527268523491};\\\", \\\"{x:1561,y:769,t:1527268523507};\\\", \\\"{x:1553,y:777,t:1527268523523};\\\", \\\"{x:1550,y:779,t:1527268523540};\\\", \\\"{x:1548,y:781,t:1527268523557};\\\", \\\"{x:1547,y:781,t:1527268523573};\\\", \\\"{x:1546,y:782,t:1527268523599};\\\", \\\"{x:1544,y:782,t:1527268523608};\\\", \\\"{x:1538,y:785,t:1527268523623};\\\", \\\"{x:1531,y:788,t:1527268523641};\\\", \\\"{x:1529,y:789,t:1527268523657};\\\", \\\"{x:1528,y:789,t:1527268523743};\\\", \\\"{x:1527,y:789,t:1527268523775};\\\", \\\"{x:1526,y:789,t:1527268523863};\\\", \\\"{x:1526,y:788,t:1527268524047};\\\", \\\"{x:1526,y:785,t:1527268524058};\\\", \\\"{x:1526,y:779,t:1527268524074};\\\", \\\"{x:1530,y:771,t:1527268524091};\\\", \\\"{x:1538,y:760,t:1527268524108};\\\", \\\"{x:1544,y:755,t:1527268524126};\\\", \\\"{x:1552,y:750,t:1527268524141};\\\", \\\"{x:1560,y:745,t:1527268524158};\\\", \\\"{x:1571,y:739,t:1527268524175};\\\", \\\"{x:1575,y:736,t:1527268524191};\\\", \\\"{x:1577,y:736,t:1527268524208};\\\", \\\"{x:1579,y:734,t:1527268524225};\\\", \\\"{x:1581,y:733,t:1527268524241};\\\", \\\"{x:1585,y:730,t:1527268524259};\\\", \\\"{x:1589,y:727,t:1527268524275};\\\", \\\"{x:1592,y:725,t:1527268524291};\\\", \\\"{x:1595,y:723,t:1527268524308};\\\", \\\"{x:1596,y:722,t:1527268524350};\\\", \\\"{x:1597,y:721,t:1527268524367};\\\", \\\"{x:1599,y:720,t:1527268524375};\\\", \\\"{x:1602,y:717,t:1527268524391};\\\", \\\"{x:1604,y:715,t:1527268524408};\\\", \\\"{x:1604,y:711,t:1527268524600};\\\", \\\"{x:1607,y:704,t:1527268524608};\\\", \\\"{x:1607,y:697,t:1527268524626};\\\", \\\"{x:1607,y:691,t:1527268524642};\\\", \\\"{x:1607,y:688,t:1527268524658};\\\", \\\"{x:1607,y:687,t:1527268524676};\\\", \\\"{x:1602,y:687,t:1527268524798};\\\", \\\"{x:1600,y:687,t:1527268524808};\\\", \\\"{x:1590,y:692,t:1527268524824};\\\", \\\"{x:1586,y:693,t:1527268524841};\\\", \\\"{x:1581,y:695,t:1527268524858};\\\", \\\"{x:1578,y:697,t:1527268524874};\\\", \\\"{x:1576,y:697,t:1527268524892};\\\", \\\"{x:1573,y:699,t:1527268524908};\\\", \\\"{x:1571,y:700,t:1527268524924};\\\", \\\"{x:1565,y:704,t:1527268524942};\\\", \\\"{x:1558,y:709,t:1527268524957};\\\", \\\"{x:1547,y:717,t:1527268524974};\\\", \\\"{x:1534,y:726,t:1527268524992};\\\", \\\"{x:1521,y:736,t:1527268525008};\\\", \\\"{x:1513,y:742,t:1527268525024};\\\", \\\"{x:1510,y:746,t:1527268525042};\\\", \\\"{x:1509,y:748,t:1527268525062};\\\", \\\"{x:1509,y:750,t:1527268525075};\\\", \\\"{x:1508,y:757,t:1527268525092};\\\", \\\"{x:1508,y:763,t:1527268525109};\\\", \\\"{x:1507,y:768,t:1527268525125};\\\", \\\"{x:1507,y:771,t:1527268525142};\\\", \\\"{x:1507,y:772,t:1527268525158};\\\", \\\"{x:1507,y:773,t:1527268525175};\\\", \\\"{x:1505,y:775,t:1527268525192};\\\", \\\"{x:1505,y:778,t:1527268525209};\\\", \\\"{x:1505,y:780,t:1527268525225};\\\", \\\"{x:1504,y:780,t:1527268527992};\\\", \\\"{x:1504,y:779,t:1527268528005};\\\", \\\"{x:1504,y:778,t:1527268528021};\\\", \\\"{x:1504,y:777,t:1527268528134};\\\", \\\"{x:1504,y:776,t:1527268528157};\\\", \\\"{x:1504,y:775,t:1527268528174};\\\", \\\"{x:1505,y:775,t:1527268528231};\\\", \\\"{x:1506,y:774,t:1527268528246};\\\", \\\"{x:1507,y:774,t:1527268528262};\\\", \\\"{x:1508,y:773,t:1527268528277};\\\", \\\"{x:1509,y:772,t:1527268528294};\\\", \\\"{x:1506,y:772,t:1527268528679};\\\", \\\"{x:1480,y:783,t:1527268528695};\\\", \\\"{x:1460,y:790,t:1527268528712};\\\", \\\"{x:1459,y:790,t:1527268528729};\\\", \\\"{x:1458,y:789,t:1527268528775};\\\", \\\"{x:1455,y:791,t:1527268528991};\\\", \\\"{x:1447,y:792,t:1527268529000};\\\", \\\"{x:1438,y:792,t:1527268529011};\\\", \\\"{x:1410,y:789,t:1527268529028};\\\", \\\"{x:1370,y:774,t:1527268529046};\\\", \\\"{x:1329,y:749,t:1527268529062};\\\", \\\"{x:1217,y:685,t:1527268529078};\\\", \\\"{x:1114,y:650,t:1527268529094};\\\", \\\"{x:1006,y:620,t:1527268529111};\\\", \\\"{x:897,y:583,t:1527268529130};\\\", \\\"{x:818,y:553,t:1527268529145};\\\", \\\"{x:739,y:519,t:1527268529178};\\\", \\\"{x:714,y:499,t:1527268529198};\\\", \\\"{x:697,y:491,t:1527268529213};\\\", \\\"{x:691,y:489,t:1527268529231};\\\", \\\"{x:680,y:485,t:1527268529248};\\\", \\\"{x:666,y:481,t:1527268529263};\\\", \\\"{x:659,y:480,t:1527268529280};\\\", \\\"{x:658,y:480,t:1527268529297};\\\", \\\"{x:660,y:480,t:1527268529326};\\\", \\\"{x:669,y:483,t:1527268529333};\\\", \\\"{x:676,y:488,t:1527268529347};\\\", \\\"{x:725,y:497,t:1527268529364};\\\", \\\"{x:754,y:505,t:1527268529381};\\\", \\\"{x:770,y:513,t:1527268529398};\\\", \\\"{x:774,y:520,t:1527268529415};\\\", \\\"{x:775,y:524,t:1527268529431};\\\", \\\"{x:778,y:531,t:1527268529448};\\\", \\\"{x:779,y:538,t:1527268529464};\\\", \\\"{x:785,y:550,t:1527268529480};\\\", \\\"{x:793,y:561,t:1527268529498};\\\", \\\"{x:803,y:573,t:1527268529515};\\\", \\\"{x:805,y:575,t:1527268529531};\\\", \\\"{x:806,y:575,t:1527268529622};\\\", \\\"{x:808,y:576,t:1527268529630};\\\", \\\"{x:812,y:578,t:1527268529648};\\\", \\\"{x:814,y:578,t:1527268529664};\\\", \\\"{x:815,y:578,t:1527268529680};\\\", \\\"{x:816,y:578,t:1527268529698};\\\", \\\"{x:817,y:578,t:1527268529718};\\\", \\\"{x:818,y:578,t:1527268529731};\\\", \\\"{x:821,y:575,t:1527268529748};\\\", \\\"{x:823,y:574,t:1527268529765};\\\", \\\"{x:826,y:573,t:1527268529782};\\\", \\\"{x:823,y:575,t:1527268530158};\\\", \\\"{x:813,y:578,t:1527268530166};\\\", \\\"{x:795,y:582,t:1527268530181};\\\", \\\"{x:781,y:587,t:1527268530198};\\\", \\\"{x:763,y:588,t:1527268530215};\\\", \\\"{x:741,y:588,t:1527268530231};\\\", \\\"{x:715,y:588,t:1527268530248};\\\", \\\"{x:694,y:588,t:1527268530265};\\\", \\\"{x:678,y:587,t:1527268530282};\\\", \\\"{x:673,y:585,t:1527268530298};\\\", \\\"{x:670,y:584,t:1527268530315};\\\", \\\"{x:669,y:583,t:1527268530423};\\\", \\\"{x:665,y:580,t:1527268530432};\\\", \\\"{x:652,y:578,t:1527268530448};\\\", \\\"{x:632,y:576,t:1527268530466};\\\", \\\"{x:612,y:574,t:1527268530482};\\\", \\\"{x:605,y:573,t:1527268530499};\\\", \\\"{x:604,y:573,t:1527268530515};\\\", \\\"{x:603,y:579,t:1527268530790};\\\", \\\"{x:601,y:589,t:1527268530799};\\\", \\\"{x:598,y:616,t:1527268530816};\\\", \\\"{x:587,y:656,t:1527268530832};\\\", \\\"{x:571,y:697,t:1527268530849};\\\", \\\"{x:557,y:717,t:1527268530865};\\\", \\\"{x:543,y:728,t:1527268530882};\\\", \\\"{x:526,y:740,t:1527268530899};\\\", \\\"{x:513,y:755,t:1527268530915};\\\", \\\"{x:511,y:762,t:1527268530932};\\\", \\\"{x:511,y:763,t:1527268530965};\\\", \\\"{x:511,y:758,t:1527268531157};\\\", \\\"{x:510,y:752,t:1527268531166};\\\", \\\"{x:508,y:744,t:1527268531183};\\\", \\\"{x:506,y:739,t:1527268531199};\\\", \\\"{x:505,y:734,t:1527268531216};\\\", \\\"{x:503,y:731,t:1527268531232};\\\", \\\"{x:502,y:730,t:1527268531248};\\\", \\\"{x:498,y:711,t:1527268531991};\\\", \\\"{x:475,y:660,t:1527268532000};\\\", \\\"{x:442,y:590,t:1527268532016};\\\", \\\"{x:416,y:539,t:1527268532033};\\\", \\\"{x:391,y:503,t:1527268532050};\\\", \\\"{x:372,y:478,t:1527268532067};\\\", \\\"{x:363,y:463,t:1527268532083};\\\", \\\"{x:359,y:457,t:1527268532100};\\\", \\\"{x:359,y:455,t:1527268532117};\\\", \\\"{x:359,y:450,t:1527268532133};\\\", \\\"{x:358,y:440,t:1527268532150};\\\", \\\"{x:356,y:436,t:1527268532166};\\\", \\\"{x:356,y:433,t:1527268532183};\\\", \\\"{x:356,y:431,t:1527268532200};\\\", \\\"{x:359,y:427,t:1527268532217};\\\", \\\"{x:366,y:424,t:1527268532233};\\\", \\\"{x:368,y:423,t:1527268532250};\\\", \\\"{x:370,y:422,t:1527268532267};\\\", \\\"{x:371,y:423,t:1527268532319};\\\", \\\"{x:373,y:432,t:1527268532333};\\\", \\\"{x:387,y:462,t:1527268532350};\\\", \\\"{x:397,y:487,t:1527268532367};\\\", \\\"{x:405,y:506,t:1527268532383};\\\", \\\"{x:407,y:516,t:1527268532400};\\\", \\\"{x:408,y:520,t:1527268532418};\\\" ] }, { \\\"rt\\\": 34793, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 602685, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -02 PM-03 PM-04 PM-03 PM-03 PM-X -12 PM-M -M -12 PM-B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:445,y:489,t:1527268532603};\\\", \\\"{x:456,y:484,t:1527268532617};\\\", \\\"{x:458,y:482,t:1527268532633};\\\", \\\"{x:459,y:481,t:1527268533095};\\\", \\\"{x:462,y:481,t:1527268533102};\\\", \\\"{x:472,y:481,t:1527268533187};\\\", \\\"{x:473,y:481,t:1527268533200};\\\", \\\"{x:474,y:481,t:1527268533229};\\\", \\\"{x:475,y:481,t:1527268533238};\\\", \\\"{x:476,y:481,t:1527268533250};\\\", \\\"{x:480,y:481,t:1527268533265};\\\", \\\"{x:484,y:481,t:1527268533283};\\\", \\\"{x:491,y:481,t:1527268533300};\\\", \\\"{x:500,y:482,t:1527268533316};\\\", \\\"{x:509,y:484,t:1527268533333};\\\", \\\"{x:526,y:486,t:1527268533350};\\\", \\\"{x:543,y:488,t:1527268533367};\\\", \\\"{x:564,y:489,t:1527268533383};\\\", \\\"{x:581,y:489,t:1527268533400};\\\", \\\"{x:603,y:489,t:1527268533417};\\\", \\\"{x:604,y:489,t:1527268533433};\\\", \\\"{x:603,y:489,t:1527268534885};\\\", \\\"{x:602,y:490,t:1527268534934};\\\", \\\"{x:601,y:491,t:1527268534951};\\\", \\\"{x:600,y:491,t:1527268534981};\\\", \\\"{x:599,y:492,t:1527268535039};\\\", \\\"{x:598,y:492,t:1527268535052};\\\", \\\"{x:593,y:496,t:1527268535068};\\\", \\\"{x:588,y:500,t:1527268535085};\\\", \\\"{x:584,y:503,t:1527268535102};\\\", \\\"{x:583,y:503,t:1527268535119};\\\", \\\"{x:582,y:503,t:1527268535150};\\\", \\\"{x:585,y:504,t:1527268535295};\\\", \\\"{x:587,y:505,t:1527268535310};\\\", \\\"{x:589,y:506,t:1527268535319};\\\", \\\"{x:593,y:510,t:1527268535335};\\\", \\\"{x:598,y:516,t:1527268535353};\\\", \\\"{x:604,y:520,t:1527268535371};\\\", \\\"{x:608,y:524,t:1527268535385};\\\", \\\"{x:614,y:527,t:1527268535402};\\\", \\\"{x:623,y:532,t:1527268535419};\\\", \\\"{x:634,y:539,t:1527268535436};\\\", \\\"{x:645,y:547,t:1527268535452};\\\", \\\"{x:656,y:555,t:1527268535469};\\\", \\\"{x:681,y:573,t:1527268535486};\\\", \\\"{x:710,y:589,t:1527268535502};\\\", \\\"{x:735,y:608,t:1527268535520};\\\", \\\"{x:768,y:631,t:1527268535536};\\\", \\\"{x:806,y:653,t:1527268535552};\\\", \\\"{x:833,y:669,t:1527268535569};\\\", \\\"{x:862,y:684,t:1527268535585};\\\", \\\"{x:895,y:701,t:1527268535602};\\\", \\\"{x:931,y:716,t:1527268535619};\\\", \\\"{x:960,y:730,t:1527268535636};\\\", \\\"{x:984,y:740,t:1527268535652};\\\", \\\"{x:1007,y:749,t:1527268535669};\\\", \\\"{x:1042,y:766,t:1527268535686};\\\", \\\"{x:1069,y:777,t:1527268535702};\\\", \\\"{x:1088,y:789,t:1527268535720};\\\", \\\"{x:1097,y:794,t:1527268535736};\\\", \\\"{x:1099,y:796,t:1527268535753};\\\", \\\"{x:1100,y:796,t:1527268536095};\\\", \\\"{x:1102,y:796,t:1527268536351};\\\", \\\"{x:1103,y:796,t:1527268536455};\\\", \\\"{x:1105,y:796,t:1527268536470};\\\", \\\"{x:1108,y:796,t:1527268536487};\\\", \\\"{x:1110,y:796,t:1527268536504};\\\", \\\"{x:1111,y:796,t:1527268536527};\\\", \\\"{x:1112,y:796,t:1527268536538};\\\", \\\"{x:1114,y:796,t:1527268536558};\\\", \\\"{x:1115,y:796,t:1527268536570};\\\", \\\"{x:1116,y:796,t:1527268536587};\\\", \\\"{x:1119,y:795,t:1527268536604};\\\", \\\"{x:1122,y:794,t:1527268536621};\\\", \\\"{x:1126,y:794,t:1527268536637};\\\", \\\"{x:1129,y:794,t:1527268536653};\\\", \\\"{x:1134,y:792,t:1527268536671};\\\", \\\"{x:1137,y:792,t:1527268536686};\\\", \\\"{x:1144,y:792,t:1527268536703};\\\", \\\"{x:1150,y:791,t:1527268536720};\\\", \\\"{x:1156,y:790,t:1527268536738};\\\", \\\"{x:1160,y:789,t:1527268536753};\\\", \\\"{x:1166,y:789,t:1527268536770};\\\", \\\"{x:1171,y:788,t:1527268536787};\\\", \\\"{x:1180,y:787,t:1527268536803};\\\", \\\"{x:1188,y:787,t:1527268536821};\\\", \\\"{x:1202,y:786,t:1527268536838};\\\", \\\"{x:1210,y:786,t:1527268536853};\\\", \\\"{x:1228,y:786,t:1527268536871};\\\", \\\"{x:1241,y:784,t:1527268536888};\\\", \\\"{x:1256,y:782,t:1527268536904};\\\", \\\"{x:1274,y:781,t:1527268536921};\\\", \\\"{x:1290,y:779,t:1527268536938};\\\", \\\"{x:1302,y:778,t:1527268536954};\\\", \\\"{x:1315,y:777,t:1527268536970};\\\", \\\"{x:1324,y:774,t:1527268536988};\\\", \\\"{x:1335,y:773,t:1527268537003};\\\", \\\"{x:1350,y:768,t:1527268537022};\\\", \\\"{x:1368,y:763,t:1527268537037};\\\", \\\"{x:1389,y:761,t:1527268537053};\\\", \\\"{x:1407,y:757,t:1527268537070};\\\", \\\"{x:1428,y:753,t:1527268537087};\\\", \\\"{x:1444,y:751,t:1527268537104};\\\", \\\"{x:1455,y:747,t:1527268537120};\\\", \\\"{x:1461,y:747,t:1527268537137};\\\", \\\"{x:1464,y:747,t:1527268537154};\\\", \\\"{x:1469,y:746,t:1527268537170};\\\", \\\"{x:1472,y:746,t:1527268537187};\\\", \\\"{x:1480,y:744,t:1527268537204};\\\", \\\"{x:1490,y:743,t:1527268537220};\\\", \\\"{x:1504,y:741,t:1527268537237};\\\", \\\"{x:1531,y:741,t:1527268537253};\\\", \\\"{x:1549,y:741,t:1527268537270};\\\", \\\"{x:1560,y:738,t:1527268537287};\\\", \\\"{x:1566,y:738,t:1527268537304};\\\", \\\"{x:1569,y:738,t:1527268537320};\\\", \\\"{x:1570,y:737,t:1527268537338};\\\", \\\"{x:1566,y:737,t:1527268538824};\\\", \\\"{x:1556,y:750,t:1527268538838};\\\", \\\"{x:1550,y:762,t:1527268538856};\\\", \\\"{x:1547,y:777,t:1527268538872};\\\", \\\"{x:1544,y:793,t:1527268538888};\\\", \\\"{x:1543,y:799,t:1527268538906};\\\", \\\"{x:1543,y:804,t:1527268538922};\\\", \\\"{x:1542,y:811,t:1527268538938};\\\", \\\"{x:1539,y:821,t:1527268538955};\\\", \\\"{x:1536,y:833,t:1527268538972};\\\", \\\"{x:1532,y:846,t:1527268538988};\\\", \\\"{x:1528,y:859,t:1527268539005};\\\", \\\"{x:1523,y:874,t:1527268539022};\\\", \\\"{x:1518,y:881,t:1527268539039};\\\", \\\"{x:1511,y:888,t:1527268539056};\\\", \\\"{x:1505,y:893,t:1527268539073};\\\", \\\"{x:1504,y:894,t:1527268539090};\\\", \\\"{x:1503,y:895,t:1527268539106};\\\", \\\"{x:1503,y:896,t:1527268539183};\\\", \\\"{x:1503,y:898,t:1527268539191};\\\", \\\"{x:1502,y:899,t:1527268539206};\\\", \\\"{x:1498,y:905,t:1527268539222};\\\", \\\"{x:1495,y:911,t:1527268539239};\\\", \\\"{x:1492,y:917,t:1527268539255};\\\", \\\"{x:1489,y:925,t:1527268539272};\\\", \\\"{x:1485,y:934,t:1527268539289};\\\", \\\"{x:1482,y:940,t:1527268539306};\\\", \\\"{x:1479,y:946,t:1527268539323};\\\", \\\"{x:1478,y:948,t:1527268539339};\\\", \\\"{x:1477,y:952,t:1527268539355};\\\", \\\"{x:1474,y:957,t:1527268539372};\\\", \\\"{x:1470,y:959,t:1527268539390};\\\", \\\"{x:1462,y:963,t:1527268539406};\\\", \\\"{x:1451,y:974,t:1527268539423};\\\", \\\"{x:1449,y:977,t:1527268539439};\\\", \\\"{x:1448,y:979,t:1527268539456};\\\", \\\"{x:1448,y:980,t:1527268539535};\\\", \\\"{x:1449,y:980,t:1527268539543};\\\", \\\"{x:1459,y:980,t:1527268539557};\\\", \\\"{x:1485,y:980,t:1527268539574};\\\", \\\"{x:1507,y:978,t:1527268539590};\\\", \\\"{x:1541,y:974,t:1527268539607};\\\", \\\"{x:1556,y:974,t:1527268539623};\\\", \\\"{x:1559,y:974,t:1527268539640};\\\", \\\"{x:1560,y:974,t:1527268539656};\\\", \\\"{x:1561,y:973,t:1527268539695};\\\", \\\"{x:1564,y:972,t:1527268539707};\\\", \\\"{x:1582,y:971,t:1527268539723};\\\", \\\"{x:1601,y:971,t:1527268539740};\\\", \\\"{x:1618,y:970,t:1527268539756};\\\", \\\"{x:1625,y:968,t:1527268539773};\\\", \\\"{x:1627,y:968,t:1527268539790};\\\", \\\"{x:1630,y:968,t:1527268539847};\\\", \\\"{x:1633,y:967,t:1527268539857};\\\", \\\"{x:1644,y:966,t:1527268539873};\\\", \\\"{x:1663,y:964,t:1527268539890};\\\", \\\"{x:1681,y:964,t:1527268539907};\\\", \\\"{x:1697,y:962,t:1527268539924};\\\", \\\"{x:1701,y:961,t:1527268539940};\\\", \\\"{x:1704,y:961,t:1527268539957};\\\", \\\"{x:1705,y:961,t:1527268539973};\\\", \\\"{x:1708,y:960,t:1527268539990};\\\", \\\"{x:1712,y:960,t:1527268540007};\\\", \\\"{x:1718,y:960,t:1527268540024};\\\", \\\"{x:1724,y:960,t:1527268540039};\\\", \\\"{x:1729,y:960,t:1527268540056};\\\", \\\"{x:1730,y:960,t:1527268540073};\\\", \\\"{x:1731,y:960,t:1527268540090};\\\", \\\"{x:1733,y:960,t:1527268540110};\\\", \\\"{x:1735,y:960,t:1527268540123};\\\", \\\"{x:1741,y:960,t:1527268540139};\\\", \\\"{x:1750,y:961,t:1527268540157};\\\", \\\"{x:1754,y:962,t:1527268540174};\\\", \\\"{x:1755,y:962,t:1527268540190};\\\", \\\"{x:1754,y:964,t:1527268540239};\\\", \\\"{x:1750,y:966,t:1527268540247};\\\", \\\"{x:1744,y:967,t:1527268540257};\\\", \\\"{x:1720,y:967,t:1527268540273};\\\", \\\"{x:1674,y:967,t:1527268540291};\\\", \\\"{x:1624,y:967,t:1527268540307};\\\", \\\"{x:1585,y:971,t:1527268540324};\\\", \\\"{x:1566,y:973,t:1527268540341};\\\", \\\"{x:1557,y:973,t:1527268540357};\\\", \\\"{x:1551,y:973,t:1527268540373};\\\", \\\"{x:1544,y:973,t:1527268540390};\\\", \\\"{x:1540,y:973,t:1527268540407};\\\", \\\"{x:1539,y:973,t:1527268540424};\\\", \\\"{x:1535,y:973,t:1527268540441};\\\", \\\"{x:1528,y:973,t:1527268540457};\\\", \\\"{x:1521,y:973,t:1527268540474};\\\", \\\"{x:1511,y:973,t:1527268540491};\\\", \\\"{x:1506,y:972,t:1527268540506};\\\", \\\"{x:1505,y:972,t:1527268540524};\\\", \\\"{x:1503,y:971,t:1527268540575};\\\", \\\"{x:1505,y:971,t:1527268540719};\\\", \\\"{x:1512,y:967,t:1527268540726};\\\", \\\"{x:1514,y:966,t:1527268540741};\\\", \\\"{x:1516,y:966,t:1527268540758};\\\", \\\"{x:1518,y:965,t:1527268540879};\\\", \\\"{x:1522,y:962,t:1527268540891};\\\", \\\"{x:1526,y:959,t:1527268540908};\\\", \\\"{x:1527,y:959,t:1527268541119};\\\", \\\"{x:1528,y:958,t:1527268541135};\\\", \\\"{x:1529,y:951,t:1527268541143};\\\", \\\"{x:1533,y:944,t:1527268541158};\\\", \\\"{x:1536,y:932,t:1527268541175};\\\", \\\"{x:1541,y:919,t:1527268541190};\\\", \\\"{x:1544,y:910,t:1527268541207};\\\", \\\"{x:1550,y:902,t:1527268541224};\\\", \\\"{x:1553,y:890,t:1527268541241};\\\", \\\"{x:1555,y:876,t:1527268541258};\\\", \\\"{x:1559,y:860,t:1527268541275};\\\", \\\"{x:1563,y:843,t:1527268541291};\\\", \\\"{x:1565,y:825,t:1527268541308};\\\", \\\"{x:1565,y:806,t:1527268541325};\\\", \\\"{x:1565,y:786,t:1527268541341};\\\", \\\"{x:1565,y:764,t:1527268541357};\\\", \\\"{x:1565,y:734,t:1527268541374};\\\", \\\"{x:1565,y:715,t:1527268541390};\\\", \\\"{x:1563,y:698,t:1527268541408};\\\", \\\"{x:1560,y:681,t:1527268541425};\\\", \\\"{x:1554,y:661,t:1527268541441};\\\", \\\"{x:1551,y:646,t:1527268541458};\\\", \\\"{x:1548,y:630,t:1527268541475};\\\", \\\"{x:1539,y:597,t:1527268541491};\\\", \\\"{x:1535,y:582,t:1527268541507};\\\", \\\"{x:1535,y:580,t:1527268541525};\\\", \\\"{x:1535,y:578,t:1527268541542};\\\", \\\"{x:1535,y:576,t:1527268541557};\\\", \\\"{x:1535,y:575,t:1527268541581};\\\", \\\"{x:1535,y:573,t:1527268541591};\\\", \\\"{x:1535,y:569,t:1527268541607};\\\", \\\"{x:1535,y:563,t:1527268541625};\\\", \\\"{x:1535,y:559,t:1527268541642};\\\", \\\"{x:1535,y:554,t:1527268541657};\\\", \\\"{x:1535,y:548,t:1527268541675};\\\", \\\"{x:1535,y:540,t:1527268541691};\\\", \\\"{x:1535,y:528,t:1527268541708};\\\", \\\"{x:1535,y:516,t:1527268541724};\\\", \\\"{x:1535,y:513,t:1527268541741};\\\", \\\"{x:1535,y:512,t:1527268541757};\\\", \\\"{x:1535,y:510,t:1527268541774};\\\", \\\"{x:1535,y:508,t:1527268541792};\\\", \\\"{x:1535,y:505,t:1527268541807};\\\", \\\"{x:1535,y:499,t:1527268541824};\\\", \\\"{x:1535,y:493,t:1527268541841};\\\", \\\"{x:1536,y:485,t:1527268541857};\\\", \\\"{x:1537,y:479,t:1527268541875};\\\", \\\"{x:1537,y:476,t:1527268541892};\\\", \\\"{x:1538,y:470,t:1527268541907};\\\", \\\"{x:1539,y:463,t:1527268541925};\\\", \\\"{x:1540,y:450,t:1527268541942};\\\", \\\"{x:1541,y:438,t:1527268541958};\\\", \\\"{x:1541,y:432,t:1527268541975};\\\", \\\"{x:1541,y:431,t:1527268541991};\\\", \\\"{x:1541,y:430,t:1527268542021};\\\", \\\"{x:1539,y:429,t:1527268542037};\\\", \\\"{x:1536,y:429,t:1527268542053};\\\", \\\"{x:1532,y:429,t:1527268542062};\\\", \\\"{x:1528,y:429,t:1527268542074};\\\", \\\"{x:1499,y:435,t:1527268542091};\\\", \\\"{x:1434,y:454,t:1527268542108};\\\", \\\"{x:1285,y:498,t:1527268542125};\\\", \\\"{x:1023,y:568,t:1527268542142};\\\", \\\"{x:885,y:605,t:1527268542159};\\\", \\\"{x:787,y:624,t:1527268542174};\\\", \\\"{x:748,y:629,t:1527268542191};\\\", \\\"{x:743,y:629,t:1527268542207};\\\", \\\"{x:742,y:630,t:1527268542415};\\\", \\\"{x:741,y:630,t:1527268542424};\\\", \\\"{x:737,y:625,t:1527268542441};\\\", \\\"{x:738,y:627,t:1527268542646};\\\", \\\"{x:740,y:630,t:1527268542658};\\\", \\\"{x:740,y:632,t:1527268542800};\\\", \\\"{x:740,y:633,t:1527268542808};\\\", \\\"{x:736,y:635,t:1527268542824};\\\", \\\"{x:725,y:638,t:1527268542841};\\\", \\\"{x:709,y:638,t:1527268542859};\\\", \\\"{x:672,y:638,t:1527268542874};\\\", \\\"{x:592,y:638,t:1527268542891};\\\", \\\"{x:506,y:638,t:1527268542908};\\\", \\\"{x:400,y:638,t:1527268542925};\\\", \\\"{x:367,y:636,t:1527268542942};\\\", \\\"{x:353,y:631,t:1527268542959};\\\", \\\"{x:351,y:629,t:1527268542975};\\\", \\\"{x:351,y:627,t:1527268543022};\\\", \\\"{x:351,y:623,t:1527268543030};\\\", \\\"{x:351,y:621,t:1527268543041};\\\", \\\"{x:351,y:618,t:1527268543058};\\\", \\\"{x:353,y:616,t:1527268543075};\\\", \\\"{x:353,y:615,t:1527268543094};\\\", \\\"{x:354,y:614,t:1527268543117};\\\", \\\"{x:354,y:613,t:1527268543126};\\\", \\\"{x:356,y:611,t:1527268543141};\\\", \\\"{x:357,y:610,t:1527268543158};\\\", \\\"{x:358,y:610,t:1527268543206};\\\", \\\"{x:359,y:610,t:1527268543214};\\\", \\\"{x:360,y:609,t:1527268543231};\\\", \\\"{x:361,y:609,t:1527268543242};\\\", \\\"{x:363,y:608,t:1527268543259};\\\", \\\"{x:366,y:606,t:1527268543275};\\\", \\\"{x:369,y:606,t:1527268543292};\\\", \\\"{x:376,y:604,t:1527268543309};\\\", \\\"{x:399,y:602,t:1527268543325};\\\", \\\"{x:426,y:602,t:1527268543342};\\\", \\\"{x:465,y:602,t:1527268543358};\\\", \\\"{x:513,y:608,t:1527268543376};\\\", \\\"{x:566,y:616,t:1527268543392};\\\", \\\"{x:608,y:622,t:1527268543409};\\\", \\\"{x:640,y:626,t:1527268543425};\\\", \\\"{x:657,y:628,t:1527268543442};\\\", \\\"{x:659,y:628,t:1527268543458};\\\", \\\"{x:660,y:628,t:1527268543517};\\\", \\\"{x:661,y:628,t:1527268543526};\\\", \\\"{x:666,y:628,t:1527268543541};\\\", \\\"{x:674,y:628,t:1527268543559};\\\", \\\"{x:677,y:629,t:1527268543576};\\\", \\\"{x:680,y:629,t:1527268543592};\\\", \\\"{x:681,y:630,t:1527268543608};\\\", \\\"{x:682,y:630,t:1527268543687};\\\", \\\"{x:689,y:631,t:1527268545254};\\\", \\\"{x:723,y:655,t:1527268545264};\\\", \\\"{x:785,y:681,t:1527268545275};\\\", \\\"{x:945,y:730,t:1527268545292};\\\", \\\"{x:1201,y:791,t:1527268545311};\\\", \\\"{x:1339,y:812,t:1527268545327};\\\", \\\"{x:1416,y:828,t:1527268545343};\\\", \\\"{x:1441,y:834,t:1527268545360};\\\", \\\"{x:1443,y:835,t:1527268545377};\\\", \\\"{x:1443,y:841,t:1527268545393};\\\", \\\"{x:1434,y:851,t:1527268545410};\\\", \\\"{x:1420,y:858,t:1527268545427};\\\", \\\"{x:1415,y:861,t:1527268545443};\\\", \\\"{x:1413,y:861,t:1527268545461};\\\", \\\"{x:1412,y:862,t:1527268545485};\\\", \\\"{x:1412,y:864,t:1527268545501};\\\", \\\"{x:1412,y:868,t:1527268545510};\\\", \\\"{x:1413,y:876,t:1527268545527};\\\", \\\"{x:1418,y:885,t:1527268545544};\\\", \\\"{x:1430,y:908,t:1527268545561};\\\", \\\"{x:1484,y:958,t:1527268545578};\\\", \\\"{x:1575,y:1019,t:1527268545594};\\\", \\\"{x:1665,y:1067,t:1527268545611};\\\", \\\"{x:1731,y:1095,t:1527268545628};\\\", \\\"{x:1745,y:1103,t:1527268545645};\\\", \\\"{x:1743,y:1103,t:1527268545766};\\\", \\\"{x:1743,y:1102,t:1527268545778};\\\", \\\"{x:1740,y:1098,t:1527268545795};\\\", \\\"{x:1731,y:1079,t:1527268545812};\\\", \\\"{x:1719,y:1059,t:1527268545827};\\\", \\\"{x:1714,y:1052,t:1527268545845};\\\", \\\"{x:1712,y:1049,t:1527268545861};\\\", \\\"{x:1706,y:1044,t:1527268545877};\\\", \\\"{x:1691,y:1033,t:1527268545894};\\\", \\\"{x:1673,y:1027,t:1527268545911};\\\", \\\"{x:1665,y:1024,t:1527268545928};\\\", \\\"{x:1664,y:1023,t:1527268545982};\\\", \\\"{x:1658,y:1020,t:1527268545995};\\\", \\\"{x:1614,y:1009,t:1527268546012};\\\", \\\"{x:1537,y:989,t:1527268546029};\\\", \\\"{x:1445,y:974,t:1527268546045};\\\", \\\"{x:1337,y:958,t:1527268546062};\\\", \\\"{x:1320,y:955,t:1527268546078};\\\", \\\"{x:1322,y:955,t:1527268546151};\\\", \\\"{x:1332,y:955,t:1527268546162};\\\", \\\"{x:1370,y:956,t:1527268546179};\\\", \\\"{x:1428,y:956,t:1527268546195};\\\", \\\"{x:1503,y:956,t:1527268546212};\\\", \\\"{x:1559,y:956,t:1527268546229};\\\", \\\"{x:1580,y:956,t:1527268546245};\\\", \\\"{x:1580,y:958,t:1527268546479};\\\", \\\"{x:1572,y:962,t:1527268546496};\\\", \\\"{x:1567,y:964,t:1527268546513};\\\", \\\"{x:1561,y:965,t:1527268546529};\\\", \\\"{x:1557,y:967,t:1527268546545};\\\", \\\"{x:1556,y:967,t:1527268546563};\\\", \\\"{x:1556,y:962,t:1527268546887};\\\", \\\"{x:1558,y:953,t:1527268546897};\\\", \\\"{x:1560,y:932,t:1527268546913};\\\", \\\"{x:1562,y:917,t:1527268546930};\\\", \\\"{x:1563,y:905,t:1527268546947};\\\", \\\"{x:1563,y:891,t:1527268546964};\\\", \\\"{x:1563,y:879,t:1527268546980};\\\", \\\"{x:1559,y:863,t:1527268546997};\\\", \\\"{x:1555,y:850,t:1527268547013};\\\", \\\"{x:1549,y:837,t:1527268547030};\\\", \\\"{x:1549,y:831,t:1527268547047};\\\", \\\"{x:1549,y:826,t:1527268547064};\\\", \\\"{x:1549,y:822,t:1527268547080};\\\", \\\"{x:1549,y:819,t:1527268547097};\\\", \\\"{x:1547,y:817,t:1527268547114};\\\", \\\"{x:1547,y:815,t:1527268547375};\\\", \\\"{x:1547,y:807,t:1527268547382};\\\", \\\"{x:1547,y:801,t:1527268547397};\\\", \\\"{x:1547,y:786,t:1527268547414};\\\", \\\"{x:1554,y:767,t:1527268547431};\\\", \\\"{x:1558,y:753,t:1527268547448};\\\", \\\"{x:1559,y:750,t:1527268547464};\\\", \\\"{x:1559,y:749,t:1527268547481};\\\", \\\"{x:1559,y:748,t:1527268547527};\\\", \\\"{x:1559,y:746,t:1527268547534};\\\", \\\"{x:1559,y:745,t:1527268547548};\\\", \\\"{x:1559,y:743,t:1527268547564};\\\", \\\"{x:1559,y:741,t:1527268547581};\\\", \\\"{x:1559,y:740,t:1527268547599};\\\", \\\"{x:1559,y:739,t:1527268547614};\\\", \\\"{x:1559,y:737,t:1527268547631};\\\", \\\"{x:1559,y:733,t:1527268547648};\\\", \\\"{x:1559,y:730,t:1527268547664};\\\", \\\"{x:1559,y:724,t:1527268547681};\\\", \\\"{x:1559,y:721,t:1527268547699};\\\", \\\"{x:1559,y:719,t:1527268547715};\\\", \\\"{x:1559,y:715,t:1527268547731};\\\", \\\"{x:1559,y:706,t:1527268547748};\\\", \\\"{x:1559,y:696,t:1527268547766};\\\", \\\"{x:1559,y:684,t:1527268547781};\\\", \\\"{x:1559,y:672,t:1527268547798};\\\", \\\"{x:1559,y:669,t:1527268547815};\\\", \\\"{x:1559,y:668,t:1527268547951};\\\", \\\"{x:1559,y:667,t:1527268547991};\\\", \\\"{x:1559,y:663,t:1527268547998};\\\", \\\"{x:1559,y:659,t:1527268548015};\\\", \\\"{x:1559,y:654,t:1527268548031};\\\", \\\"{x:1559,y:651,t:1527268548048};\\\", \\\"{x:1559,y:646,t:1527268548064};\\\", \\\"{x:1559,y:642,t:1527268548081};\\\", \\\"{x:1559,y:638,t:1527268548098};\\\", \\\"{x:1559,y:636,t:1527268548114};\\\", \\\"{x:1559,y:635,t:1527268548215};\\\", \\\"{x:1559,y:633,t:1527268548232};\\\", \\\"{x:1559,y:632,t:1527268548294};\\\", \\\"{x:1559,y:625,t:1527268548302};\\\", \\\"{x:1559,y:619,t:1527268548316};\\\", \\\"{x:1559,y:618,t:1527268548332};\\\", \\\"{x:1559,y:617,t:1527268548349};\\\", \\\"{x:1559,y:612,t:1527268548455};\\\", \\\"{x:1559,y:606,t:1527268548466};\\\", \\\"{x:1557,y:595,t:1527268548482};\\\", \\\"{x:1553,y:584,t:1527268548499};\\\", \\\"{x:1551,y:578,t:1527268548516};\\\", \\\"{x:1550,y:571,t:1527268548533};\\\", \\\"{x:1547,y:563,t:1527268548549};\\\", \\\"{x:1547,y:556,t:1527268548566};\\\", \\\"{x:1547,y:554,t:1527268548582};\\\", \\\"{x:1546,y:553,t:1527268548599};\\\", \\\"{x:1546,y:555,t:1527268549310};\\\", \\\"{x:1553,y:578,t:1527268549318};\\\", \\\"{x:1570,y:641,t:1527268549334};\\\", \\\"{x:1592,y:701,t:1527268549350};\\\", \\\"{x:1610,y:752,t:1527268549367};\\\", \\\"{x:1624,y:788,t:1527268549384};\\\", \\\"{x:1639,y:811,t:1527268549401};\\\", \\\"{x:1643,y:817,t:1527268549417};\\\", \\\"{x:1644,y:817,t:1527268549434};\\\", \\\"{x:1644,y:819,t:1527268549487};\\\", \\\"{x:1645,y:823,t:1527268549501};\\\", \\\"{x:1645,y:835,t:1527268549517};\\\", \\\"{x:1645,y:848,t:1527268549535};\\\", \\\"{x:1642,y:851,t:1527268549552};\\\", \\\"{x:1629,y:859,t:1527268549569};\\\", \\\"{x:1616,y:870,t:1527268549585};\\\", \\\"{x:1597,y:881,t:1527268549601};\\\", \\\"{x:1580,y:888,t:1527268549619};\\\", \\\"{x:1557,y:898,t:1527268549635};\\\", \\\"{x:1526,y:905,t:1527268549652};\\\", \\\"{x:1508,y:911,t:1527268549669};\\\", \\\"{x:1506,y:911,t:1527268549684};\\\", \\\"{x:1505,y:914,t:1527268549999};\\\", \\\"{x:1507,y:922,t:1527268550007};\\\", \\\"{x:1509,y:927,t:1527268550019};\\\", \\\"{x:1515,y:936,t:1527268550036};\\\", \\\"{x:1522,y:943,t:1527268550052};\\\", \\\"{x:1531,y:952,t:1527268550069};\\\", \\\"{x:1540,y:958,t:1527268550086};\\\", \\\"{x:1543,y:960,t:1527268550102};\\\", \\\"{x:1544,y:961,t:1527268550150};\\\", \\\"{x:1546,y:964,t:1527268550158};\\\", \\\"{x:1547,y:966,t:1527268550170};\\\", \\\"{x:1549,y:971,t:1527268550184};\\\", \\\"{x:1551,y:973,t:1527268550201};\\\", \\\"{x:1551,y:974,t:1527268550220};\\\", \\\"{x:1552,y:975,t:1527268550286};\\\", \\\"{x:1553,y:975,t:1527268550302};\\\", \\\"{x:1552,y:969,t:1527268550591};\\\", \\\"{x:1546,y:961,t:1527268550603};\\\", \\\"{x:1537,y:949,t:1527268550620};\\\", \\\"{x:1533,y:943,t:1527268550637};\\\", \\\"{x:1529,y:939,t:1527268550653};\\\", \\\"{x:1528,y:939,t:1527268550669};\\\", \\\"{x:1527,y:937,t:1527268550686};\\\", \\\"{x:1526,y:937,t:1527268550903};\\\", \\\"{x:1524,y:936,t:1527268550920};\\\", \\\"{x:1522,y:935,t:1527268552327};\\\", \\\"{x:1520,y:934,t:1527268552351};\\\", \\\"{x:1518,y:934,t:1527268552446};\\\", \\\"{x:1512,y:936,t:1527268552454};\\\", \\\"{x:1495,y:943,t:1527268552472};\\\", \\\"{x:1480,y:947,t:1527268552488};\\\", \\\"{x:1464,y:950,t:1527268552506};\\\", \\\"{x:1453,y:951,t:1527268552522};\\\", \\\"{x:1449,y:951,t:1527268552539};\\\", \\\"{x:1448,y:951,t:1527268553031};\\\", \\\"{x:1447,y:951,t:1527268553041};\\\", \\\"{x:1446,y:951,t:1527268553071};\\\", \\\"{x:1445,y:951,t:1527268553079};\\\", \\\"{x:1444,y:951,t:1527268553094};\\\", \\\"{x:1443,y:951,t:1527268553111};\\\", \\\"{x:1440,y:951,t:1527268553494};\\\", \\\"{x:1436,y:951,t:1527268553508};\\\", \\\"{x:1428,y:954,t:1527268553524};\\\", \\\"{x:1421,y:956,t:1527268553542};\\\", \\\"{x:1418,y:956,t:1527268553557};\\\", \\\"{x:1417,y:956,t:1527268553679};\\\", \\\"{x:1416,y:956,t:1527268553691};\\\", \\\"{x:1413,y:956,t:1527268553708};\\\", \\\"{x:1409,y:952,t:1527268553725};\\\", \\\"{x:1405,y:945,t:1527268553741};\\\", \\\"{x:1401,y:936,t:1527268553758};\\\", \\\"{x:1396,y:923,t:1527268553774};\\\", \\\"{x:1394,y:916,t:1527268553792};\\\", \\\"{x:1391,y:907,t:1527268553808};\\\", \\\"{x:1390,y:893,t:1527268553824};\\\", \\\"{x:1390,y:878,t:1527268553841};\\\", \\\"{x:1390,y:863,t:1527268553858};\\\", \\\"{x:1390,y:843,t:1527268553874};\\\", \\\"{x:1390,y:822,t:1527268553891};\\\", \\\"{x:1390,y:804,t:1527268553908};\\\", \\\"{x:1390,y:791,t:1527268553924};\\\", \\\"{x:1390,y:779,t:1527268553941};\\\", \\\"{x:1390,y:769,t:1527268553958};\\\", \\\"{x:1390,y:767,t:1527268553981};\\\", \\\"{x:1390,y:766,t:1527268553998};\\\", \\\"{x:1388,y:760,t:1527268554008};\\\", \\\"{x:1387,y:752,t:1527268554026};\\\", \\\"{x:1386,y:746,t:1527268554041};\\\", \\\"{x:1384,y:744,t:1527268554058};\\\", \\\"{x:1384,y:743,t:1527268554075};\\\", \\\"{x:1384,y:742,t:1527268554143};\\\", \\\"{x:1384,y:739,t:1527268554158};\\\", \\\"{x:1384,y:730,t:1527268554176};\\\", \\\"{x:1384,y:728,t:1527268554193};\\\", \\\"{x:1384,y:727,t:1527268554222};\\\", \\\"{x:1384,y:725,t:1527268554231};\\\", \\\"{x:1384,y:721,t:1527268554247};\\\", \\\"{x:1384,y:711,t:1527268554259};\\\", \\\"{x:1387,y:697,t:1527268554276};\\\", \\\"{x:1388,y:696,t:1527268554293};\\\", \\\"{x:1389,y:695,t:1527268554309};\\\", \\\"{x:1389,y:699,t:1527268554503};\\\", \\\"{x:1391,y:720,t:1527268554511};\\\", \\\"{x:1391,y:745,t:1527268554526};\\\", \\\"{x:1391,y:778,t:1527268554543};\\\", \\\"{x:1391,y:786,t:1527268554559};\\\", \\\"{x:1391,y:794,t:1527268554575};\\\", \\\"{x:1393,y:806,t:1527268554593};\\\", \\\"{x:1398,y:823,t:1527268554610};\\\", \\\"{x:1399,y:840,t:1527268554627};\\\", \\\"{x:1399,y:856,t:1527268554643};\\\", \\\"{x:1399,y:869,t:1527268554659};\\\", \\\"{x:1399,y:879,t:1527268554676};\\\", \\\"{x:1399,y:889,t:1527268554692};\\\", \\\"{x:1399,y:896,t:1527268554710};\\\", \\\"{x:1398,y:899,t:1527268554727};\\\", \\\"{x:1398,y:901,t:1527268554743};\\\", \\\"{x:1398,y:903,t:1527268554760};\\\", \\\"{x:1398,y:908,t:1527268554777};\\\", \\\"{x:1398,y:910,t:1527268554793};\\\", \\\"{x:1398,y:912,t:1527268554809};\\\", \\\"{x:1398,y:914,t:1527268554830};\\\", \\\"{x:1398,y:915,t:1527268554846};\\\", \\\"{x:1398,y:917,t:1527268554860};\\\", \\\"{x:1398,y:919,t:1527268554877};\\\", \\\"{x:1397,y:922,t:1527268554894};\\\", \\\"{x:1397,y:925,t:1527268554910};\\\", \\\"{x:1397,y:928,t:1527268554927};\\\", \\\"{x:1397,y:925,t:1527268555086};\\\", \\\"{x:1397,y:918,t:1527268555095};\\\", \\\"{x:1401,y:901,t:1527268555111};\\\", \\\"{x:1406,y:885,t:1527268555126};\\\", \\\"{x:1409,y:879,t:1527268555143};\\\", \\\"{x:1411,y:877,t:1527268555160};\\\", \\\"{x:1411,y:876,t:1527268555176};\\\", \\\"{x:1412,y:875,t:1527268555194};\\\", \\\"{x:1412,y:873,t:1527268555230};\\\", \\\"{x:1413,y:871,t:1527268555254};\\\", \\\"{x:1413,y:870,t:1527268555271};\\\", \\\"{x:1413,y:869,t:1527268555287};\\\", \\\"{x:1413,y:868,t:1527268555303};\\\", \\\"{x:1413,y:867,t:1527268555311};\\\", \\\"{x:1414,y:866,t:1527268555328};\\\", \\\"{x:1417,y:860,t:1527268555344};\\\", \\\"{x:1422,y:849,t:1527268555361};\\\", \\\"{x:1426,y:842,t:1527268555378};\\\", \\\"{x:1430,y:836,t:1527268555394};\\\", \\\"{x:1433,y:833,t:1527268555410};\\\", \\\"{x:1435,y:831,t:1527268555427};\\\", \\\"{x:1436,y:831,t:1527268555444};\\\", \\\"{x:1437,y:830,t:1527268555469};\\\", \\\"{x:1439,y:828,t:1527268555477};\\\", \\\"{x:1445,y:824,t:1527268555493};\\\", \\\"{x:1450,y:821,t:1527268555510};\\\", \\\"{x:1456,y:817,t:1527268555527};\\\", \\\"{x:1458,y:816,t:1527268555544};\\\", \\\"{x:1460,y:815,t:1527268555561};\\\", \\\"{x:1461,y:815,t:1527268555622};\\\", \\\"{x:1461,y:814,t:1527268555630};\\\", \\\"{x:1463,y:813,t:1527268555644};\\\", \\\"{x:1465,y:813,t:1527268555734};\\\", \\\"{x:1468,y:816,t:1527268555744};\\\", \\\"{x:1476,y:826,t:1527268555761};\\\", \\\"{x:1480,y:832,t:1527268555778};\\\", \\\"{x:1480,y:833,t:1527268555794};\\\", \\\"{x:1481,y:834,t:1527268555812};\\\", \\\"{x:1481,y:840,t:1527268556800};\\\", \\\"{x:1481,y:865,t:1527268556813};\\\", \\\"{x:1481,y:905,t:1527268556830};\\\", \\\"{x:1481,y:931,t:1527268556846};\\\", \\\"{x:1481,y:937,t:1527268556863};\\\", \\\"{x:1481,y:940,t:1527268556880};\\\", \\\"{x:1481,y:941,t:1527268556919};\\\", \\\"{x:1481,y:943,t:1527268556930};\\\", \\\"{x:1482,y:948,t:1527268556947};\\\", \\\"{x:1482,y:951,t:1527268556963};\\\", \\\"{x:1482,y:954,t:1527268556979};\\\", \\\"{x:1483,y:956,t:1527268556997};\\\", \\\"{x:1483,y:958,t:1527268557013};\\\", \\\"{x:1482,y:958,t:1527268557150};\\\", \\\"{x:1479,y:956,t:1527268557164};\\\", \\\"{x:1476,y:942,t:1527268557181};\\\", \\\"{x:1475,y:929,t:1527268557196};\\\", \\\"{x:1475,y:915,t:1527268557214};\\\", \\\"{x:1475,y:894,t:1527268557230};\\\", \\\"{x:1475,y:883,t:1527268557247};\\\", \\\"{x:1475,y:876,t:1527268557264};\\\", \\\"{x:1475,y:873,t:1527268557281};\\\", \\\"{x:1474,y:868,t:1527268557297};\\\", \\\"{x:1474,y:862,t:1527268557313};\\\", \\\"{x:1472,y:857,t:1527268557331};\\\", \\\"{x:1472,y:853,t:1527268557348};\\\", \\\"{x:1471,y:850,t:1527268557364};\\\", \\\"{x:1470,y:847,t:1527268557380};\\\", \\\"{x:1470,y:846,t:1527268557397};\\\", \\\"{x:1469,y:844,t:1527268557414};\\\", \\\"{x:1468,y:841,t:1527268557430};\\\", \\\"{x:1468,y:839,t:1527268557470};\\\", \\\"{x:1468,y:837,t:1527268557480};\\\", \\\"{x:1468,y:831,t:1527268557498};\\\", \\\"{x:1468,y:827,t:1527268557513};\\\", \\\"{x:1468,y:826,t:1527268557530};\\\", \\\"{x:1466,y:836,t:1527268558111};\\\", \\\"{x:1456,y:855,t:1527268558119};\\\", \\\"{x:1451,y:866,t:1527268558131};\\\", \\\"{x:1440,y:885,t:1527268558148};\\\", \\\"{x:1429,y:897,t:1527268558165};\\\", \\\"{x:1423,y:902,t:1527268558181};\\\", \\\"{x:1423,y:903,t:1527268558198};\\\", \\\"{x:1421,y:905,t:1527268558230};\\\", \\\"{x:1421,y:906,t:1527268558238};\\\", \\\"{x:1420,y:909,t:1527268558248};\\\", \\\"{x:1416,y:914,t:1527268558266};\\\", \\\"{x:1407,y:921,t:1527268558282};\\\", \\\"{x:1404,y:924,t:1527268558298};\\\", \\\"{x:1403,y:925,t:1527268558315};\\\", \\\"{x:1402,y:927,t:1527268558671};\\\", \\\"{x:1399,y:930,t:1527268558683};\\\", \\\"{x:1390,y:940,t:1527268558700};\\\", \\\"{x:1380,y:948,t:1527268558716};\\\", \\\"{x:1369,y:956,t:1527268558733};\\\", \\\"{x:1360,y:965,t:1527268558750};\\\", \\\"{x:1357,y:969,t:1527268558767};\\\", \\\"{x:1357,y:967,t:1527268559000};\\\", \\\"{x:1357,y:962,t:1527268559017};\\\", \\\"{x:1357,y:960,t:1527268559034};\\\", \\\"{x:1358,y:959,t:1527268559049};\\\", \\\"{x:1358,y:956,t:1527268559067};\\\", \\\"{x:1358,y:954,t:1527268559084};\\\", \\\"{x:1358,y:952,t:1527268559100};\\\", \\\"{x:1358,y:950,t:1527268559127};\\\", \\\"{x:1358,y:949,t:1527268559142};\\\", \\\"{x:1358,y:947,t:1527268559151};\\\", \\\"{x:1358,y:942,t:1527268559167};\\\", \\\"{x:1358,y:938,t:1527268559184};\\\", \\\"{x:1358,y:937,t:1527268559214};\\\", \\\"{x:1358,y:936,t:1527268559255};\\\", \\\"{x:1358,y:935,t:1527268559267};\\\", \\\"{x:1358,y:932,t:1527268559284};\\\", \\\"{x:1358,y:927,t:1527268559300};\\\", \\\"{x:1360,y:925,t:1527268559317};\\\", \\\"{x:1360,y:924,t:1527268559342};\\\", \\\"{x:1360,y:922,t:1527268559350};\\\", \\\"{x:1361,y:921,t:1527268559374};\\\", \\\"{x:1362,y:920,t:1527268559390};\\\", \\\"{x:1363,y:918,t:1527268559401};\\\", \\\"{x:1364,y:914,t:1527268559418};\\\", \\\"{x:1368,y:908,t:1527268559434};\\\", \\\"{x:1372,y:902,t:1527268559450};\\\", \\\"{x:1378,y:896,t:1527268559468};\\\", \\\"{x:1378,y:895,t:1527268559483};\\\", \\\"{x:1379,y:894,t:1527268559501};\\\", \\\"{x:1379,y:893,t:1527268559517};\\\", \\\"{x:1381,y:890,t:1527268559534};\\\", \\\"{x:1384,y:883,t:1527268559551};\\\", \\\"{x:1385,y:879,t:1527268559567};\\\", \\\"{x:1387,y:876,t:1527268559584};\\\", \\\"{x:1387,y:873,t:1527268559735};\\\", \\\"{x:1387,y:861,t:1527268559751};\\\", \\\"{x:1387,y:850,t:1527268559767};\\\", \\\"{x:1387,y:841,t:1527268559785};\\\", \\\"{x:1386,y:832,t:1527268559801};\\\", \\\"{x:1384,y:824,t:1527268559818};\\\", \\\"{x:1382,y:819,t:1527268559835};\\\", \\\"{x:1380,y:812,t:1527268559852};\\\", \\\"{x:1377,y:802,t:1527268559868};\\\", \\\"{x:1373,y:793,t:1527268559885};\\\", \\\"{x:1371,y:790,t:1527268559902};\\\", \\\"{x:1370,y:787,t:1527268559918};\\\", \\\"{x:1368,y:786,t:1527268559935};\\\", \\\"{x:1368,y:785,t:1527268560103};\\\", \\\"{x:1367,y:783,t:1527268560119};\\\", \\\"{x:1366,y:783,t:1527268560135};\\\", \\\"{x:1364,y:780,t:1527268560151};\\\", \\\"{x:1363,y:779,t:1527268560169};\\\", \\\"{x:1359,y:775,t:1527268560185};\\\", \\\"{x:1358,y:775,t:1527268560202};\\\", \\\"{x:1357,y:774,t:1527268560222};\\\", \\\"{x:1356,y:773,t:1527268560238};\\\", \\\"{x:1356,y:797,t:1527268561103};\\\", \\\"{x:1357,y:853,t:1527268561120};\\\", \\\"{x:1360,y:892,t:1527268561137};\\\", \\\"{x:1360,y:912,t:1527268561154};\\\", \\\"{x:1360,y:916,t:1527268561170};\\\", \\\"{x:1360,y:918,t:1527268561187};\\\", \\\"{x:1360,y:920,t:1527268561207};\\\", \\\"{x:1360,y:923,t:1527268561221};\\\", \\\"{x:1361,y:933,t:1527268561236};\\\", \\\"{x:1362,y:947,t:1527268561253};\\\", \\\"{x:1362,y:952,t:1527268561269};\\\", \\\"{x:1362,y:956,t:1527268561286};\\\", \\\"{x:1363,y:957,t:1527268561599};\\\", \\\"{x:1363,y:958,t:1527268561606};\\\", \\\"{x:1364,y:958,t:1527268561621};\\\", \\\"{x:1366,y:960,t:1527268561638};\\\", \\\"{x:1368,y:961,t:1527268561654};\\\", \\\"{x:1368,y:968,t:1527268561671};\\\", \\\"{x:1368,y:971,t:1527268561687};\\\", \\\"{x:1368,y:972,t:1527268561704};\\\", \\\"{x:1367,y:972,t:1527268561720};\\\", \\\"{x:1367,y:973,t:1527268561750};\\\", \\\"{x:1366,y:973,t:1527268561879};\\\", \\\"{x:1364,y:973,t:1527268561888};\\\", \\\"{x:1358,y:965,t:1527268561905};\\\", \\\"{x:1350,y:955,t:1527268561921};\\\", \\\"{x:1345,y:945,t:1527268561938};\\\", \\\"{x:1343,y:941,t:1527268561955};\\\", \\\"{x:1341,y:937,t:1527268561972};\\\", \\\"{x:1340,y:932,t:1527268561988};\\\", \\\"{x:1337,y:927,t:1527268562005};\\\", \\\"{x:1334,y:919,t:1527268562022};\\\", \\\"{x:1333,y:915,t:1527268562038};\\\", \\\"{x:1333,y:914,t:1527268562055};\\\", \\\"{x:1333,y:912,t:1527268562072};\\\", \\\"{x:1333,y:910,t:1527268562094};\\\", \\\"{x:1333,y:909,t:1527268562126};\\\", \\\"{x:1333,y:907,t:1527268562150};\\\", \\\"{x:1333,y:906,t:1527268562166};\\\", \\\"{x:1333,y:903,t:1527268562174};\\\", \\\"{x:1333,y:902,t:1527268562188};\\\", \\\"{x:1333,y:900,t:1527268562205};\\\", \\\"{x:1333,y:898,t:1527268562238};\\\", \\\"{x:1333,y:896,t:1527268562255};\\\", \\\"{x:1333,y:895,t:1527268562272};\\\", \\\"{x:1333,y:894,t:1527268562391};\\\", \\\"{x:1334,y:891,t:1527268562406};\\\", \\\"{x:1334,y:890,t:1527268562424};\\\", \\\"{x:1334,y:887,t:1527268562438};\\\", \\\"{x:1335,y:886,t:1527268562478};\\\", \\\"{x:1335,y:885,t:1527268562678};\\\", \\\"{x:1335,y:883,t:1527268562689};\\\", \\\"{x:1335,y:875,t:1527268562706};\\\", \\\"{x:1335,y:868,t:1527268562723};\\\", \\\"{x:1335,y:867,t:1527268562739};\\\", \\\"{x:1335,y:864,t:1527268562756};\\\", \\\"{x:1336,y:860,t:1527268562773};\\\", \\\"{x:1336,y:855,t:1527268562790};\\\", \\\"{x:1336,y:851,t:1527268562806};\\\", \\\"{x:1336,y:848,t:1527268562822};\\\", \\\"{x:1336,y:844,t:1527268562840};\\\", \\\"{x:1336,y:843,t:1527268562856};\\\", \\\"{x:1336,y:840,t:1527268562873};\\\", \\\"{x:1336,y:837,t:1527268562890};\\\", \\\"{x:1336,y:834,t:1527268562906};\\\", \\\"{x:1336,y:831,t:1527268562923};\\\", \\\"{x:1336,y:828,t:1527268562940};\\\", \\\"{x:1336,y:827,t:1527268562991};\\\", \\\"{x:1336,y:825,t:1527268563031};\\\", \\\"{x:1336,y:824,t:1527268563071};\\\", \\\"{x:1336,y:822,t:1527268563103};\\\", \\\"{x:1336,y:821,t:1527268563127};\\\", \\\"{x:1336,y:820,t:1527268563142};\\\", \\\"{x:1336,y:818,t:1527268563158};\\\", \\\"{x:1336,y:816,t:1527268563173};\\\", \\\"{x:1336,y:815,t:1527268563206};\\\", \\\"{x:1336,y:813,t:1527268563230};\\\", \\\"{x:1336,y:812,t:1527268563246};\\\", \\\"{x:1336,y:810,t:1527268563257};\\\", \\\"{x:1336,y:809,t:1527268563274};\\\", \\\"{x:1336,y:807,t:1527268563290};\\\", \\\"{x:1336,y:804,t:1527268563307};\\\", \\\"{x:1336,y:800,t:1527268563324};\\\", \\\"{x:1336,y:794,t:1527268563340};\\\", \\\"{x:1336,y:789,t:1527268563357};\\\", \\\"{x:1336,y:787,t:1527268563374};\\\", \\\"{x:1336,y:786,t:1527268563390};\\\", \\\"{x:1336,y:785,t:1527268563471};\\\", \\\"{x:1336,y:783,t:1527268563486};\\\", \\\"{x:1336,y:781,t:1527268563495};\\\", \\\"{x:1336,y:779,t:1527268563507};\\\", \\\"{x:1336,y:775,t:1527268563524};\\\", \\\"{x:1338,y:770,t:1527268563540};\\\", \\\"{x:1339,y:764,t:1527268563556};\\\", \\\"{x:1342,y:759,t:1527268563573};\\\", \\\"{x:1342,y:758,t:1527268563591};\\\", \\\"{x:1342,y:753,t:1527268563607};\\\", \\\"{x:1345,y:747,t:1527268563624};\\\", \\\"{x:1346,y:745,t:1527268563641};\\\", \\\"{x:1346,y:743,t:1527268563879};\\\", \\\"{x:1346,y:744,t:1527268564194};\\\", \\\"{x:1346,y:751,t:1527268564211};\\\", \\\"{x:1346,y:757,t:1527268564228};\\\", \\\"{x:1346,y:762,t:1527268564245};\\\", \\\"{x:1346,y:763,t:1527268564261};\\\", \\\"{x:1346,y:764,t:1527268565138};\\\", \\\"{x:1336,y:764,t:1527268565147};\\\", \\\"{x:1267,y:757,t:1527268565163};\\\", \\\"{x:1186,y:742,t:1527268565180};\\\", \\\"{x:1109,y:725,t:1527268565197};\\\", \\\"{x:1072,y:719,t:1527268565214};\\\", \\\"{x:1044,y:705,t:1527268565231};\\\", \\\"{x:1035,y:700,t:1527268565246};\\\", \\\"{x:1023,y:700,t:1527268565506};\\\", \\\"{x:1003,y:697,t:1527268565514};\\\", \\\"{x:957,y:692,t:1527268565531};\\\", \\\"{x:906,y:685,t:1527268565547};\\\", \\\"{x:831,y:685,t:1527268565564};\\\", \\\"{x:737,y:685,t:1527268565581};\\\", \\\"{x:620,y:685,t:1527268565597};\\\", \\\"{x:504,y:685,t:1527268565615};\\\", \\\"{x:396,y:685,t:1527268565630};\\\", \\\"{x:313,y:676,t:1527268565648};\\\", \\\"{x:282,y:671,t:1527268565665};\\\", \\\"{x:266,y:668,t:1527268565682};\\\", \\\"{x:260,y:664,t:1527268565697};\\\", \\\"{x:256,y:657,t:1527268565713};\\\", \\\"{x:242,y:648,t:1527268565729};\\\", \\\"{x:209,y:634,t:1527268565746};\\\", \\\"{x:143,y:617,t:1527268565763};\\\", \\\"{x:84,y:608,t:1527268565779};\\\", \\\"{x:55,y:602,t:1527268565796};\\\", \\\"{x:40,y:600,t:1527268565813};\\\", \\\"{x:39,y:599,t:1527268565830};\\\", \\\"{x:39,y:598,t:1527268565857};\\\", \\\"{x:39,y:597,t:1527268565865};\\\", \\\"{x:41,y:597,t:1527268565880};\\\", \\\"{x:44,y:594,t:1527268565897};\\\", \\\"{x:58,y:589,t:1527268565914};\\\", \\\"{x:81,y:579,t:1527268565930};\\\", \\\"{x:91,y:574,t:1527268565947};\\\", \\\"{x:95,y:573,t:1527268565963};\\\", \\\"{x:96,y:572,t:1527268565980};\\\", \\\"{x:97,y:571,t:1527268566010};\\\", \\\"{x:99,y:570,t:1527268566050};\\\", \\\"{x:103,y:569,t:1527268566064};\\\", \\\"{x:111,y:561,t:1527268566083};\\\", \\\"{x:128,y:550,t:1527268566097};\\\", \\\"{x:132,y:546,t:1527268566114};\\\", \\\"{x:133,y:546,t:1527268566161};\\\", \\\"{x:135,y:545,t:1527268566177};\\\", \\\"{x:140,y:542,t:1527268566185};\\\", \\\"{x:150,y:538,t:1527268566197};\\\", \\\"{x:154,y:537,t:1527268566214};\\\", \\\"{x:158,y:537,t:1527268566497};\\\", \\\"{x:188,y:564,t:1527268566515};\\\", \\\"{x:252,y:615,t:1527268566532};\\\", \\\"{x:352,y:691,t:1527268566548};\\\", \\\"{x:483,y:786,t:1527268566565};\\\", \\\"{x:600,y:852,t:1527268566581};\\\", \\\"{x:680,y:899,t:1527268566597};\\\", \\\"{x:713,y:913,t:1527268566614};\\\", \\\"{x:723,y:914,t:1527268566631};\\\", \\\"{x:724,y:914,t:1527268566646};\\\", \\\"{x:723,y:914,t:1527268566698};\\\", \\\"{x:715,y:908,t:1527268566714};\\\", \\\"{x:707,y:897,t:1527268566731};\\\", \\\"{x:700,y:890,t:1527268566748};\\\", \\\"{x:698,y:885,t:1527268566764};\\\", \\\"{x:693,y:879,t:1527268566781};\\\", \\\"{x:686,y:868,t:1527268566798};\\\", \\\"{x:680,y:862,t:1527268566814};\\\", \\\"{x:672,y:852,t:1527268566831};\\\", \\\"{x:662,y:840,t:1527268566849};\\\", \\\"{x:652,y:827,t:1527268566864};\\\", \\\"{x:624,y:802,t:1527268566881};\\\", \\\"{x:603,y:791,t:1527268566898};\\\", \\\"{x:593,y:784,t:1527268566914};\\\", \\\"{x:583,y:781,t:1527268566931};\\\", \\\"{x:574,y:777,t:1527268566948};\\\", \\\"{x:566,y:774,t:1527268566964};\\\", \\\"{x:565,y:773,t:1527268566994};\\\", \\\"{x:564,y:773,t:1527268567017};\\\", \\\"{x:563,y:773,t:1527268567031};\\\", \\\"{x:556,y:768,t:1527268567048};\\\", \\\"{x:549,y:764,t:1527268567064};\\\", \\\"{x:545,y:761,t:1527268567081};\\\", \\\"{x:544,y:761,t:1527268567130};\\\", \\\"{x:543,y:760,t:1527268567137};\\\", \\\"{x:535,y:756,t:1527268567149};\\\", \\\"{x:523,y:751,t:1527268567166};\\\", \\\"{x:518,y:746,t:1527268567181};\\\", \\\"{x:517,y:745,t:1527268567197};\\\", \\\"{x:516,y:745,t:1527268567625};\\\", \\\"{x:515,y:745,t:1527268568106};\\\", \\\"{x:514,y:745,t:1527268568129};\\\", \\\"{x:513,y:745,t:1527268568137};\\\", \\\"{x:512,y:745,t:1527268568149};\\\", \\\"{x:511,y:745,t:1527268568166};\\\", \\\"{x:510,y:745,t:1527268568217};\\\", \\\"{x:509,y:745,t:1527268568473};\\\", \\\"{x:509,y:741,t:1527268568483};\\\", \\\"{x:510,y:727,t:1527268568499};\\\" ] }, { \\\"rt\\\": 38734, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 642678, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -12 PM-01 PM-02 PM-X -X -X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:557,y:546,t:1527268568660};\\\", \\\"{x:561,y:538,t:1527268568669};\\\", \\\"{x:577,y:520,t:1527268568690};\\\", \\\"{x:583,y:516,t:1527268568699};\\\", \\\"{x:594,y:512,t:1527268568716};\\\", \\\"{x:600,y:510,t:1527268568732};\\\", \\\"{x:603,y:508,t:1527268568760};\\\", \\\"{x:604,y:507,t:1527268568766};\\\", \\\"{x:603,y:507,t:1527268569106};\\\", \\\"{x:593,y:505,t:1527268569117};\\\", \\\"{x:555,y:500,t:1527268569133};\\\", \\\"{x:524,y:497,t:1527268569149};\\\", \\\"{x:425,y:489,t:1527268569242};\\\", \\\"{x:425,y:488,t:1527268569474};\\\", \\\"{x:425,y:486,t:1527268569489};\\\", \\\"{x:425,y:482,t:1527268569500};\\\", \\\"{x:425,y:474,t:1527268569517};\\\", \\\"{x:425,y:471,t:1527268569533};\\\", \\\"{x:430,y:465,t:1527268569786};\\\", \\\"{x:436,y:463,t:1527268569801};\\\", \\\"{x:453,y:460,t:1527268569817};\\\", \\\"{x:457,y:460,t:1527268569835};\\\", \\\"{x:457,y:459,t:1527268569954};\\\", \\\"{x:459,y:459,t:1527268569968};\\\", \\\"{x:465,y:457,t:1527268569985};\\\", \\\"{x:472,y:456,t:1527268570001};\\\", \\\"{x:475,y:456,t:1527268570018};\\\", \\\"{x:477,y:456,t:1527268570035};\\\", \\\"{x:479,y:456,t:1527268570052};\\\", \\\"{x:484,y:455,t:1527268570068};\\\", \\\"{x:497,y:455,t:1527268570084};\\\", \\\"{x:517,y:454,t:1527268570102};\\\", \\\"{x:549,y:450,t:1527268570119};\\\", \\\"{x:580,y:448,t:1527268570134};\\\", \\\"{x:598,y:448,t:1527268570152};\\\", \\\"{x:607,y:447,t:1527268570169};\\\", \\\"{x:610,y:447,t:1527268570186};\\\", \\\"{x:611,y:447,t:1527268570201};\\\", \\\"{x:613,y:447,t:1527268570219};\\\", \\\"{x:615,y:446,t:1527268570236};\\\", \\\"{x:620,y:446,t:1527268570252};\\\", \\\"{x:629,y:445,t:1527268570268};\\\", \\\"{x:643,y:444,t:1527268570286};\\\", \\\"{x:660,y:442,t:1527268570302};\\\", \\\"{x:674,y:442,t:1527268570319};\\\", \\\"{x:689,y:442,t:1527268570336};\\\", \\\"{x:704,y:441,t:1527268570352};\\\", \\\"{x:718,y:439,t:1527268570368};\\\", \\\"{x:727,y:439,t:1527268570385};\\\", \\\"{x:728,y:438,t:1527268570402};\\\", \\\"{x:729,y:438,t:1527268570450};\\\", \\\"{x:731,y:437,t:1527268570457};\\\", \\\"{x:735,y:436,t:1527268570469};\\\", \\\"{x:748,y:435,t:1527268570486};\\\", \\\"{x:756,y:433,t:1527268570502};\\\", \\\"{x:759,y:432,t:1527268570520};\\\", \\\"{x:760,y:432,t:1527268570536};\\\", \\\"{x:771,y:439,t:1527268570970};\\\", \\\"{x:824,y:464,t:1527268570986};\\\", \\\"{x:903,y:480,t:1527268571004};\\\", \\\"{x:989,y:492,t:1527268571020};\\\", \\\"{x:1086,y:507,t:1527268571037};\\\", \\\"{x:1196,y:529,t:1527268571054};\\\", \\\"{x:1285,y:559,t:1527268571074};\\\", \\\"{x:1336,y:574,t:1527268571087};\\\", \\\"{x:1362,y:587,t:1527268571104};\\\", \\\"{x:1376,y:598,t:1527268571120};\\\", \\\"{x:1410,y:624,t:1527268571136};\\\", \\\"{x:1469,y:673,t:1527268571153};\\\", \\\"{x:1497,y:700,t:1527268571170};\\\", \\\"{x:1516,y:717,t:1527268571186};\\\", \\\"{x:1534,y:727,t:1527268571203};\\\", \\\"{x:1551,y:737,t:1527268571220};\\\", \\\"{x:1577,y:747,t:1527268571237};\\\", \\\"{x:1600,y:756,t:1527268571254};\\\", \\\"{x:1618,y:766,t:1527268571271};\\\", \\\"{x:1622,y:768,t:1527268571288};\\\", \\\"{x:1618,y:768,t:1527268571314};\\\", \\\"{x:1593,y:768,t:1527268571321};\\\", \\\"{x:1538,y:770,t:1527268571337};\\\", \\\"{x:1537,y:770,t:1527268571354};\\\", \\\"{x:1537,y:771,t:1527268571770};\\\", \\\"{x:1537,y:777,t:1527268571778};\\\", \\\"{x:1534,y:779,t:1527268571788};\\\", \\\"{x:1519,y:783,t:1527268571805};\\\", \\\"{x:1504,y:785,t:1527268571822};\\\", \\\"{x:1492,y:788,t:1527268571839};\\\", \\\"{x:1488,y:788,t:1527268571854};\\\", \\\"{x:1486,y:789,t:1527268571871};\\\", \\\"{x:1484,y:789,t:1527268571888};\\\", \\\"{x:1483,y:790,t:1527268571904};\\\", \\\"{x:1475,y:795,t:1527268571921};\\\", \\\"{x:1465,y:799,t:1527268571939};\\\", \\\"{x:1454,y:804,t:1527268571954};\\\", \\\"{x:1435,y:808,t:1527268571971};\\\", \\\"{x:1427,y:812,t:1527268571989};\\\", \\\"{x:1425,y:812,t:1527268572005};\\\", \\\"{x:1424,y:812,t:1527268572021};\\\", \\\"{x:1423,y:812,t:1527268572074};\\\", \\\"{x:1422,y:813,t:1527268572089};\\\", \\\"{x:1413,y:816,t:1527268572106};\\\", \\\"{x:1402,y:817,t:1527268572121};\\\", \\\"{x:1385,y:821,t:1527268572139};\\\", \\\"{x:1375,y:822,t:1527268572156};\\\", \\\"{x:1366,y:823,t:1527268572173};\\\", \\\"{x:1357,y:825,t:1527268572189};\\\", \\\"{x:1355,y:825,t:1527268572206};\\\", \\\"{x:1354,y:825,t:1527268572223};\\\", \\\"{x:1353,y:825,t:1527268572314};\\\", \\\"{x:1352,y:825,t:1527268572362};\\\", \\\"{x:1350,y:825,t:1527268572373};\\\", \\\"{x:1347,y:825,t:1527268572390};\\\", \\\"{x:1340,y:824,t:1527268572406};\\\", \\\"{x:1338,y:824,t:1527268572423};\\\", \\\"{x:1337,y:824,t:1527268572440};\\\", \\\"{x:1337,y:823,t:1527268572521};\\\", \\\"{x:1337,y:821,t:1527268572625};\\\", \\\"{x:1337,y:820,t:1527268572640};\\\", \\\"{x:1337,y:822,t:1527268572690};\\\", \\\"{x:1334,y:832,t:1527268572707};\\\", \\\"{x:1331,y:849,t:1527268572723};\\\", \\\"{x:1324,y:875,t:1527268572740};\\\", \\\"{x:1310,y:915,t:1527268572757};\\\", \\\"{x:1308,y:933,t:1527268572773};\\\", \\\"{x:1308,y:938,t:1527268572789};\\\", \\\"{x:1306,y:941,t:1527268572806};\\\", \\\"{x:1306,y:944,t:1527268572823};\\\", \\\"{x:1306,y:949,t:1527268572840};\\\", \\\"{x:1306,y:959,t:1527268572856};\\\", \\\"{x:1306,y:982,t:1527268572873};\\\", \\\"{x:1306,y:985,t:1527268572891};\\\", \\\"{x:1306,y:986,t:1527268572913};\\\", \\\"{x:1307,y:987,t:1527268572945};\\\", \\\"{x:1309,y:987,t:1527268573002};\\\", \\\"{x:1309,y:988,t:1527268573009};\\\", \\\"{x:1310,y:988,t:1527268573114};\\\", \\\"{x:1311,y:988,t:1527268573129};\\\", \\\"{x:1312,y:988,t:1527268573141};\\\", \\\"{x:1319,y:988,t:1527268573158};\\\", \\\"{x:1332,y:987,t:1527268573174};\\\", \\\"{x:1346,y:984,t:1527268573190};\\\", \\\"{x:1360,y:983,t:1527268573207};\\\", \\\"{x:1386,y:981,t:1527268573225};\\\", \\\"{x:1395,y:979,t:1527268573240};\\\", \\\"{x:1410,y:977,t:1527268573257};\\\", \\\"{x:1415,y:976,t:1527268573274};\\\", \\\"{x:1419,y:975,t:1527268573290};\\\", \\\"{x:1424,y:975,t:1527268573307};\\\", \\\"{x:1429,y:975,t:1527268573324};\\\", \\\"{x:1435,y:975,t:1527268573340};\\\", \\\"{x:1437,y:975,t:1527268573357};\\\", \\\"{x:1439,y:975,t:1527268573374};\\\", \\\"{x:1440,y:975,t:1527268573561};\\\", \\\"{x:1444,y:975,t:1527268573574};\\\", \\\"{x:1458,y:974,t:1527268573592};\\\", \\\"{x:1472,y:974,t:1527268573608};\\\", \\\"{x:1489,y:974,t:1527268573624};\\\", \\\"{x:1514,y:974,t:1527268573641};\\\", \\\"{x:1521,y:974,t:1527268573659};\\\", \\\"{x:1522,y:974,t:1527268573675};\\\", \\\"{x:1522,y:973,t:1527268573858};\\\", \\\"{x:1522,y:971,t:1527268573922};\\\", \\\"{x:1520,y:969,t:1527268573938};\\\", \\\"{x:1519,y:967,t:1527268573946};\\\", \\\"{x:1518,y:967,t:1527268573959};\\\", \\\"{x:1517,y:965,t:1527268573976};\\\", \\\"{x:1515,y:963,t:1527268573993};\\\", \\\"{x:1514,y:960,t:1527268574009};\\\", \\\"{x:1511,y:954,t:1527268574025};\\\", \\\"{x:1510,y:950,t:1527268574043};\\\", \\\"{x:1508,y:942,t:1527268574059};\\\", \\\"{x:1508,y:939,t:1527268574076};\\\", \\\"{x:1508,y:937,t:1527268574093};\\\", \\\"{x:1508,y:931,t:1527268574109};\\\", \\\"{x:1508,y:914,t:1527268574125};\\\", \\\"{x:1508,y:896,t:1527268574143};\\\", \\\"{x:1508,y:890,t:1527268574159};\\\", \\\"{x:1508,y:882,t:1527268574176};\\\", \\\"{x:1508,y:868,t:1527268574192};\\\", \\\"{x:1508,y:864,t:1527268574210};\\\", \\\"{x:1507,y:862,t:1527268574225};\\\", \\\"{x:1507,y:861,t:1527268574243};\\\", \\\"{x:1507,y:854,t:1527268574259};\\\", \\\"{x:1502,y:845,t:1527268574276};\\\", \\\"{x:1497,y:831,t:1527268574293};\\\", \\\"{x:1492,y:823,t:1527268574311};\\\", \\\"{x:1492,y:822,t:1527268574326};\\\", \\\"{x:1490,y:821,t:1527268574370};\\\", \\\"{x:1489,y:821,t:1527268576210};\\\", \\\"{x:1488,y:823,t:1527268577186};\\\", \\\"{x:1484,y:826,t:1527268577198};\\\", \\\"{x:1475,y:832,t:1527268577216};\\\", \\\"{x:1474,y:832,t:1527268577232};\\\", \\\"{x:1473,y:832,t:1527268577249};\\\", \\\"{x:1471,y:832,t:1527268581882};\\\", \\\"{x:1462,y:838,t:1527268581890};\\\", \\\"{x:1451,y:847,t:1527268581908};\\\", \\\"{x:1439,y:856,t:1527268581924};\\\", \\\"{x:1427,y:863,t:1527268581940};\\\", \\\"{x:1425,y:864,t:1527268581957};\\\", \\\"{x:1425,y:865,t:1527268582018};\\\", \\\"{x:1424,y:867,t:1527268582025};\\\", \\\"{x:1421,y:871,t:1527268582042};\\\", \\\"{x:1419,y:874,t:1527268582058};\\\", \\\"{x:1419,y:876,t:1527268582074};\\\", \\\"{x:1418,y:877,t:1527268582092};\\\", \\\"{x:1418,y:879,t:1527268582107};\\\", \\\"{x:1417,y:880,t:1527268582130};\\\", \\\"{x:1417,y:881,t:1527268582146};\\\", \\\"{x:1416,y:882,t:1527268582158};\\\", \\\"{x:1416,y:884,t:1527268582174};\\\", \\\"{x:1414,y:887,t:1527268582191};\\\", \\\"{x:1413,y:888,t:1527268582218};\\\", \\\"{x:1412,y:889,t:1527268582235};\\\", \\\"{x:1412,y:890,t:1527268582265};\\\", \\\"{x:1412,y:892,t:1527268582275};\\\", \\\"{x:1412,y:894,t:1527268582291};\\\", \\\"{x:1407,y:902,t:1527268582308};\\\", \\\"{x:1404,y:908,t:1527268582325};\\\", \\\"{x:1401,y:913,t:1527268582341};\\\", \\\"{x:1400,y:916,t:1527268582359};\\\", \\\"{x:1400,y:918,t:1527268582374};\\\", \\\"{x:1399,y:920,t:1527268582391};\\\", \\\"{x:1399,y:921,t:1527268582417};\\\", \\\"{x:1399,y:922,t:1527268582425};\\\", \\\"{x:1398,y:922,t:1527268583170};\\\", \\\"{x:1398,y:920,t:1527268583178};\\\", \\\"{x:1396,y:917,t:1527268583193};\\\", \\\"{x:1395,y:915,t:1527268583210};\\\", \\\"{x:1395,y:913,t:1527268583227};\\\", \\\"{x:1395,y:911,t:1527268583243};\\\", \\\"{x:1395,y:908,t:1527268583259};\\\", \\\"{x:1395,y:906,t:1527268583276};\\\", \\\"{x:1394,y:905,t:1527268583293};\\\", \\\"{x:1393,y:904,t:1527268583314};\\\", \\\"{x:1393,y:903,t:1527268583326};\\\", \\\"{x:1393,y:902,t:1527268583344};\\\", \\\"{x:1391,y:904,t:1527268584195};\\\", \\\"{x:1390,y:905,t:1527268584211};\\\", \\\"{x:1389,y:906,t:1527268584330};\\\", \\\"{x:1387,y:908,t:1527268584626};\\\", \\\"{x:1385,y:909,t:1527268584642};\\\", \\\"{x:1383,y:909,t:1527268584650};\\\", \\\"{x:1382,y:910,t:1527268584663};\\\", \\\"{x:1381,y:910,t:1527268584679};\\\", \\\"{x:1380,y:910,t:1527268584696};\\\", \\\"{x:1379,y:910,t:1527268584737};\\\", \\\"{x:1378,y:910,t:1527268584850};\\\", \\\"{x:1377,y:912,t:1527268584866};\\\", \\\"{x:1376,y:912,t:1527268584889};\\\", \\\"{x:1374,y:912,t:1527268585218};\\\", \\\"{x:1372,y:912,t:1527268585290};\\\", \\\"{x:1372,y:911,t:1527268585769};\\\", \\\"{x:1372,y:909,t:1527268585801};\\\", \\\"{x:1372,y:905,t:1527268585814};\\\", \\\"{x:1371,y:901,t:1527268585831};\\\", \\\"{x:1371,y:898,t:1527268585847};\\\", \\\"{x:1370,y:895,t:1527268585864};\\\", \\\"{x:1370,y:891,t:1527268585881};\\\", \\\"{x:1368,y:887,t:1527268585898};\\\", \\\"{x:1367,y:885,t:1527268585914};\\\", \\\"{x:1366,y:884,t:1527268585932};\\\", \\\"{x:1366,y:882,t:1527268585961};\\\", \\\"{x:1365,y:881,t:1527268585969};\\\", \\\"{x:1365,y:880,t:1527268585985};\\\", \\\"{x:1364,y:880,t:1527268586042};\\\", \\\"{x:1360,y:880,t:1527268586049};\\\", \\\"{x:1357,y:885,t:1527268586065};\\\", \\\"{x:1352,y:894,t:1527268586082};\\\", \\\"{x:1345,y:905,t:1527268586098};\\\", \\\"{x:1342,y:911,t:1527268586116};\\\", \\\"{x:1342,y:914,t:1527268586132};\\\", \\\"{x:1341,y:914,t:1527268586154};\\\", \\\"{x:1341,y:915,t:1527268586166};\\\", \\\"{x:1341,y:917,t:1527268586202};\\\", \\\"{x:1341,y:918,t:1527268586215};\\\", \\\"{x:1341,y:919,t:1527268586258};\\\", \\\"{x:1341,y:920,t:1527268586265};\\\", \\\"{x:1341,y:921,t:1527268586282};\\\", \\\"{x:1341,y:922,t:1527268586306};\\\", \\\"{x:1341,y:923,t:1527268587418};\\\", \\\"{x:1341,y:924,t:1527268587802};\\\", \\\"{x:1341,y:925,t:1527268587819};\\\", \\\"{x:1341,y:926,t:1527268587835};\\\", \\\"{x:1340,y:928,t:1527268587852};\\\", \\\"{x:1337,y:928,t:1527268588946};\\\", \\\"{x:1333,y:928,t:1527268588954};\\\", \\\"{x:1325,y:928,t:1527268588970};\\\", \\\"{x:1304,y:929,t:1527268588988};\\\", \\\"{x:1285,y:929,t:1527268589003};\\\", \\\"{x:1270,y:929,t:1527268589021};\\\", \\\"{x:1261,y:929,t:1527268589038};\\\", \\\"{x:1255,y:929,t:1527268589054};\\\", \\\"{x:1251,y:929,t:1527268589071};\\\", \\\"{x:1250,y:930,t:1527268589138};\\\", \\\"{x:1249,y:931,t:1527268589162};\\\", \\\"{x:1248,y:932,t:1527268589177};\\\", \\\"{x:1246,y:932,t:1527268589193};\\\", \\\"{x:1245,y:932,t:1527268589209};\\\", \\\"{x:1244,y:932,t:1527268589220};\\\", \\\"{x:1243,y:932,t:1527268589238};\\\", \\\"{x:1242,y:932,t:1527268589254};\\\", \\\"{x:1241,y:932,t:1527268589271};\\\", \\\"{x:1237,y:934,t:1527268589288};\\\", \\\"{x:1235,y:934,t:1527268589304};\\\", \\\"{x:1230,y:936,t:1527268589321};\\\", \\\"{x:1216,y:937,t:1527268589338};\\\", \\\"{x:1207,y:940,t:1527268589355};\\\", \\\"{x:1201,y:940,t:1527268589372};\\\", \\\"{x:1196,y:940,t:1527268589388};\\\", \\\"{x:1193,y:941,t:1527268589405};\\\", \\\"{x:1192,y:941,t:1527268589802};\\\", \\\"{x:1191,y:941,t:1527268590570};\\\", \\\"{x:1193,y:939,t:1527268590586};\\\", \\\"{x:1196,y:936,t:1527268590593};\\\", \\\"{x:1201,y:934,t:1527268590607};\\\", \\\"{x:1209,y:930,t:1527268590624};\\\", \\\"{x:1214,y:927,t:1527268590641};\\\", \\\"{x:1216,y:927,t:1527268590657};\\\", \\\"{x:1217,y:926,t:1527268590674};\\\", \\\"{x:1223,y:926,t:1527268590691};\\\", \\\"{x:1233,y:926,t:1527268590707};\\\", \\\"{x:1245,y:926,t:1527268590724};\\\", \\\"{x:1261,y:926,t:1527268590741};\\\", \\\"{x:1274,y:926,t:1527268590757};\\\", \\\"{x:1285,y:926,t:1527268590774};\\\", \\\"{x:1294,y:926,t:1527268590790};\\\", \\\"{x:1299,y:926,t:1527268590807};\\\", \\\"{x:1303,y:926,t:1527268590824};\\\", \\\"{x:1307,y:926,t:1527268590841};\\\", \\\"{x:1319,y:926,t:1527268590856};\\\", \\\"{x:1334,y:926,t:1527268590873};\\\", \\\"{x:1350,y:926,t:1527268590890};\\\", \\\"{x:1358,y:926,t:1527268590908};\\\", \\\"{x:1360,y:926,t:1527268590923};\\\", \\\"{x:1361,y:926,t:1527268591001};\\\", \\\"{x:1363,y:925,t:1527268591009};\\\", \\\"{x:1365,y:925,t:1527268591024};\\\", \\\"{x:1375,y:924,t:1527268591040};\\\", \\\"{x:1385,y:924,t:1527268591057};\\\", \\\"{x:1391,y:924,t:1527268591075};\\\", \\\"{x:1400,y:924,t:1527268591091};\\\", \\\"{x:1405,y:924,t:1527268591108};\\\", \\\"{x:1408,y:924,t:1527268591125};\\\", \\\"{x:1409,y:924,t:1527268591141};\\\", \\\"{x:1411,y:924,t:1527268591158};\\\", \\\"{x:1415,y:924,t:1527268591175};\\\", \\\"{x:1418,y:924,t:1527268591192};\\\", \\\"{x:1419,y:924,t:1527268591208};\\\", \\\"{x:1420,y:924,t:1527268591225};\\\", \\\"{x:1421,y:924,t:1527268591242};\\\", \\\"{x:1422,y:924,t:1527268591257};\\\", \\\"{x:1424,y:924,t:1527268591275};\\\", \\\"{x:1427,y:924,t:1527268591292};\\\", \\\"{x:1432,y:924,t:1527268591308};\\\", \\\"{x:1438,y:924,t:1527268591325};\\\", \\\"{x:1441,y:924,t:1527268591342};\\\", \\\"{x:1445,y:924,t:1527268591359};\\\", \\\"{x:1447,y:924,t:1527268591375};\\\", \\\"{x:1448,y:924,t:1527268591391};\\\", \\\"{x:1449,y:924,t:1527268591457};\\\", \\\"{x:1452,y:924,t:1527268591464};\\\", \\\"{x:1456,y:924,t:1527268591474};\\\", \\\"{x:1467,y:925,t:1527268591491};\\\", \\\"{x:1481,y:925,t:1527268591508};\\\", \\\"{x:1487,y:925,t:1527268591525};\\\", \\\"{x:1489,y:925,t:1527268591542};\\\", \\\"{x:1489,y:924,t:1527268592130};\\\", \\\"{x:1488,y:920,t:1527268592143};\\\", \\\"{x:1488,y:913,t:1527268592160};\\\", \\\"{x:1488,y:907,t:1527268592177};\\\", \\\"{x:1488,y:894,t:1527268592193};\\\", \\\"{x:1488,y:866,t:1527268592210};\\\", \\\"{x:1488,y:839,t:1527268592227};\\\", \\\"{x:1494,y:818,t:1527268592244};\\\", \\\"{x:1496,y:809,t:1527268592260};\\\", \\\"{x:1496,y:807,t:1527268592277};\\\", \\\"{x:1496,y:813,t:1527268592474};\\\", \\\"{x:1491,y:821,t:1527268592481};\\\", \\\"{x:1488,y:827,t:1527268592493};\\\", \\\"{x:1482,y:838,t:1527268592511};\\\", \\\"{x:1479,y:842,t:1527268592527};\\\", \\\"{x:1478,y:845,t:1527268592543};\\\", \\\"{x:1478,y:846,t:1527268592561};\\\", \\\"{x:1478,y:848,t:1527268592577};\\\", \\\"{x:1478,y:858,t:1527268592593};\\\", \\\"{x:1475,y:873,t:1527268592610};\\\", \\\"{x:1474,y:881,t:1527268592627};\\\", \\\"{x:1474,y:884,t:1527268592644};\\\", \\\"{x:1474,y:888,t:1527268592661};\\\", \\\"{x:1476,y:897,t:1527268592678};\\\", \\\"{x:1482,y:914,t:1527268592694};\\\", \\\"{x:1488,y:930,t:1527268592711};\\\", \\\"{x:1493,y:946,t:1527268592727};\\\", \\\"{x:1493,y:955,t:1527268592744};\\\", \\\"{x:1493,y:959,t:1527268592760};\\\", \\\"{x:1493,y:960,t:1527268592777};\\\", \\\"{x:1494,y:957,t:1527268594035};\\\", \\\"{x:1494,y:955,t:1527268594050};\\\", \\\"{x:1494,y:954,t:1527268594074};\\\", \\\"{x:1495,y:952,t:1527268594082};\\\", \\\"{x:1496,y:952,t:1527268594097};\\\", \\\"{x:1496,y:950,t:1527268594114};\\\", \\\"{x:1496,y:947,t:1527268594130};\\\", \\\"{x:1499,y:939,t:1527268594147};\\\", \\\"{x:1500,y:936,t:1527268594164};\\\", \\\"{x:1500,y:931,t:1527268594180};\\\", \\\"{x:1501,y:929,t:1527268594197};\\\", \\\"{x:1501,y:928,t:1527268594214};\\\", \\\"{x:1501,y:927,t:1527268594230};\\\", \\\"{x:1502,y:925,t:1527268594247};\\\", \\\"{x:1503,y:923,t:1527268594264};\\\", \\\"{x:1503,y:920,t:1527268594281};\\\", \\\"{x:1504,y:918,t:1527268594297};\\\", \\\"{x:1504,y:914,t:1527268594315};\\\", \\\"{x:1504,y:910,t:1527268594331};\\\", \\\"{x:1504,y:908,t:1527268594347};\\\", \\\"{x:1504,y:899,t:1527268594364};\\\", \\\"{x:1504,y:891,t:1527268594381};\\\", \\\"{x:1504,y:887,t:1527268594397};\\\", \\\"{x:1504,y:886,t:1527268594414};\\\", \\\"{x:1504,y:885,t:1527268594442};\\\", \\\"{x:1504,y:882,t:1527268594562};\\\", \\\"{x:1504,y:881,t:1527268594569};\\\", \\\"{x:1503,y:879,t:1527268594581};\\\", \\\"{x:1503,y:877,t:1527268594597};\\\", \\\"{x:1503,y:876,t:1527268594615};\\\", \\\"{x:1502,y:876,t:1527268594689};\\\", \\\"{x:1501,y:875,t:1527268594737};\\\", \\\"{x:1501,y:874,t:1527268594761};\\\", \\\"{x:1500,y:874,t:1527268594785};\\\", \\\"{x:1498,y:872,t:1527268594825};\\\", \\\"{x:1497,y:871,t:1527268594849};\\\", \\\"{x:1496,y:870,t:1527268594898};\\\", \\\"{x:1495,y:868,t:1527268594915};\\\", \\\"{x:1493,y:866,t:1527268594932};\\\", \\\"{x:1493,y:865,t:1527268594954};\\\", \\\"{x:1492,y:865,t:1527268594970};\\\", \\\"{x:1492,y:863,t:1527268595163};\\\", \\\"{x:1490,y:862,t:1527268595170};\\\", \\\"{x:1490,y:861,t:1527268595183};\\\", \\\"{x:1488,y:855,t:1527268595199};\\\", \\\"{x:1487,y:853,t:1527268595216};\\\", \\\"{x:1486,y:852,t:1527268595232};\\\", \\\"{x:1486,y:851,t:1527268595249};\\\", \\\"{x:1486,y:849,t:1527268595290};\\\", \\\"{x:1486,y:848,t:1527268595299};\\\", \\\"{x:1485,y:842,t:1527268595316};\\\", \\\"{x:1483,y:836,t:1527268595332};\\\", \\\"{x:1483,y:828,t:1527268595349};\\\", \\\"{x:1483,y:827,t:1527268595435};\\\", \\\"{x:1483,y:826,t:1527268597706};\\\", \\\"{x:1483,y:823,t:1527268597721};\\\", \\\"{x:1483,y:819,t:1527268597737};\\\", \\\"{x:1482,y:814,t:1527268597753};\\\", \\\"{x:1482,y:813,t:1527268597770};\\\", \\\"{x:1482,y:812,t:1527268597787};\\\", \\\"{x:1481,y:812,t:1527268597804};\\\", \\\"{x:1479,y:810,t:1527268601637};\\\", \\\"{x:1475,y:810,t:1527268601644};\\\", \\\"{x:1474,y:810,t:1527268601662};\\\", \\\"{x:1474,y:812,t:1527268601986};\\\", \\\"{x:1474,y:814,t:1527268601995};\\\", \\\"{x:1472,y:819,t:1527268602011};\\\", \\\"{x:1471,y:824,t:1527268602028};\\\", \\\"{x:1471,y:827,t:1527268602045};\\\", \\\"{x:1470,y:832,t:1527268602062};\\\", \\\"{x:1469,y:836,t:1527268602078};\\\", \\\"{x:1469,y:837,t:1527268602210};\\\", \\\"{x:1468,y:837,t:1527268602226};\\\", \\\"{x:1468,y:833,t:1527268602466};\\\", \\\"{x:1469,y:831,t:1527268602480};\\\", \\\"{x:1473,y:828,t:1527268602496};\\\", \\\"{x:1476,y:826,t:1527268602512};\\\", \\\"{x:1478,y:825,t:1527268602585};\\\", \\\"{x:1480,y:825,t:1527268602596};\\\", \\\"{x:1484,y:825,t:1527268602612};\\\", \\\"{x:1486,y:825,t:1527268602875};\\\", \\\"{x:1483,y:825,t:1527268602914};\\\", \\\"{x:1474,y:825,t:1527268602931};\\\", \\\"{x:1465,y:825,t:1527268602947};\\\", \\\"{x:1446,y:825,t:1527268602963};\\\", \\\"{x:1418,y:824,t:1527268602980};\\\", \\\"{x:1349,y:812,t:1527268602997};\\\", \\\"{x:1249,y:798,t:1527268603013};\\\", \\\"{x:1119,y:779,t:1527268603031};\\\", \\\"{x:980,y:760,t:1527268603048};\\\", \\\"{x:836,y:738,t:1527268603063};\\\", \\\"{x:708,y:717,t:1527268603080};\\\", \\\"{x:559,y:692,t:1527268603097};\\\", \\\"{x:501,y:678,t:1527268603113};\\\", \\\"{x:474,y:665,t:1527268603132};\\\", \\\"{x:461,y:659,t:1527268603147};\\\", \\\"{x:450,y:652,t:1527268603163};\\\", \\\"{x:430,y:639,t:1527268603177};\\\", \\\"{x:405,y:622,t:1527268603194};\\\", \\\"{x:374,y:609,t:1527268603210};\\\", \\\"{x:343,y:595,t:1527268603227};\\\", \\\"{x:325,y:589,t:1527268603244};\\\", \\\"{x:318,y:582,t:1527268603259};\\\", \\\"{x:315,y:579,t:1527268603277};\\\", \\\"{x:315,y:578,t:1527268603294};\\\", \\\"{x:314,y:574,t:1527268603311};\\\", \\\"{x:314,y:566,t:1527268603327};\\\", \\\"{x:319,y:556,t:1527268603343};\\\", \\\"{x:323,y:544,t:1527268603360};\\\", \\\"{x:329,y:538,t:1527268603377};\\\", \\\"{x:334,y:537,t:1527268603394};\\\", \\\"{x:339,y:534,t:1527268603410};\\\", \\\"{x:343,y:533,t:1527268603426};\\\", \\\"{x:347,y:530,t:1527268603445};\\\", \\\"{x:349,y:530,t:1527268603461};\\\", \\\"{x:354,y:530,t:1527268603477};\\\", \\\"{x:355,y:530,t:1527268603497};\\\", \\\"{x:360,y:530,t:1527268603641};\\\", \\\"{x:373,y:535,t:1527268603649};\\\", \\\"{x:389,y:540,t:1527268603661};\\\", \\\"{x:429,y:554,t:1527268603677};\\\", \\\"{x:474,y:560,t:1527268603694};\\\", \\\"{x:510,y:564,t:1527268603712};\\\", \\\"{x:536,y:567,t:1527268603727};\\\", \\\"{x:546,y:567,t:1527268603744};\\\", \\\"{x:542,y:570,t:1527268603899};\\\", \\\"{x:528,y:574,t:1527268603911};\\\", \\\"{x:481,y:587,t:1527268603927};\\\", \\\"{x:417,y:604,t:1527268603944};\\\", \\\"{x:312,y:621,t:1527268603961};\\\", \\\"{x:272,y:627,t:1527268603978};\\\", \\\"{x:258,y:628,t:1527268603994};\\\", \\\"{x:256,y:629,t:1527268604010};\\\", \\\"{x:246,y:629,t:1527268604298};\\\", \\\"{x:229,y:629,t:1527268604311};\\\", \\\"{x:196,y:629,t:1527268604329};\\\", \\\"{x:142,y:629,t:1527268604344};\\\", \\\"{x:100,y:629,t:1527268604361};\\\", \\\"{x:99,y:629,t:1527268604378};\\\", \\\"{x:99,y:630,t:1527268604562};\\\", \\\"{x:127,y:641,t:1527268604578};\\\", \\\"{x:159,y:648,t:1527268604597};\\\", \\\"{x:204,y:649,t:1527268604611};\\\", \\\"{x:243,y:649,t:1527268604628};\\\", \\\"{x:268,y:649,t:1527268604645};\\\", \\\"{x:283,y:649,t:1527268604661};\\\", \\\"{x:294,y:647,t:1527268604678};\\\", \\\"{x:300,y:646,t:1527268604694};\\\", \\\"{x:304,y:644,t:1527268604711};\\\", \\\"{x:311,y:641,t:1527268604728};\\\", \\\"{x:339,y:632,t:1527268604745};\\\", \\\"{x:369,y:626,t:1527268604761};\\\", \\\"{x:390,y:622,t:1527268604779};\\\", \\\"{x:403,y:621,t:1527268604795};\\\", \\\"{x:412,y:619,t:1527268604810};\\\", \\\"{x:427,y:619,t:1527268604829};\\\", \\\"{x:451,y:617,t:1527268604844};\\\", \\\"{x:492,y:617,t:1527268604861};\\\", \\\"{x:545,y:617,t:1527268604879};\\\", \\\"{x:603,y:617,t:1527268604895};\\\", \\\"{x:639,y:617,t:1527268604911};\\\", \\\"{x:662,y:617,t:1527268604928};\\\", \\\"{x:681,y:617,t:1527268604945};\\\", \\\"{x:682,y:617,t:1527268604962};\\\", \\\"{x:683,y:617,t:1527268604994};\\\", \\\"{x:682,y:616,t:1527268605106};\\\", \\\"{x:679,y:613,t:1527268605115};\\\", \\\"{x:674,y:610,t:1527268605128};\\\", \\\"{x:664,y:603,t:1527268605145};\\\", \\\"{x:661,y:602,t:1527268605161};\\\", \\\"{x:660,y:600,t:1527268605178};\\\", \\\"{x:657,y:599,t:1527268605195};\\\", \\\"{x:655,y:599,t:1527268605212};\\\", \\\"{x:654,y:598,t:1527268605233};\\\", \\\"{x:653,y:598,t:1527268605244};\\\", \\\"{x:646,y:597,t:1527268605262};\\\", \\\"{x:634,y:596,t:1527268605279};\\\", \\\"{x:632,y:596,t:1527268605295};\\\", \\\"{x:631,y:596,t:1527268605312};\\\", \\\"{x:630,y:595,t:1527268605434};\\\", \\\"{x:629,y:594,t:1527268605456};\\\", \\\"{x:628,y:593,t:1527268605514};\\\", \\\"{x:614,y:593,t:1527268605938};\\\", \\\"{x:586,y:593,t:1527268605947};\\\", \\\"{x:519,y:593,t:1527268605962};\\\", \\\"{x:450,y:593,t:1527268605979};\\\", \\\"{x:391,y:593,t:1527268605996};\\\", \\\"{x:366,y:593,t:1527268606012};\\\", \\\"{x:354,y:593,t:1527268606028};\\\", \\\"{x:353,y:594,t:1527268606080};\\\", \\\"{x:350,y:595,t:1527268606096};\\\", \\\"{x:335,y:602,t:1527268606112};\\\", \\\"{x:307,y:609,t:1527268606129};\\\", \\\"{x:285,y:610,t:1527268606146};\\\", \\\"{x:269,y:613,t:1527268606162};\\\", \\\"{x:258,y:614,t:1527268606179};\\\", \\\"{x:256,y:614,t:1527268606196};\\\", \\\"{x:255,y:614,t:1527268606212};\\\", \\\"{x:261,y:614,t:1527268606298};\\\", \\\"{x:265,y:612,t:1527268606313};\\\", \\\"{x:279,y:608,t:1527268606329};\\\", \\\"{x:300,y:606,t:1527268606345};\\\", \\\"{x:316,y:603,t:1527268606362};\\\", \\\"{x:336,y:598,t:1527268606379};\\\", \\\"{x:354,y:596,t:1527268606396};\\\", \\\"{x:372,y:593,t:1527268606413};\\\", \\\"{x:377,y:591,t:1527268606429};\\\", \\\"{x:380,y:591,t:1527268607000};\\\", \\\"{x:399,y:617,t:1527268607013};\\\", \\\"{x:448,y:674,t:1527268607030};\\\", \\\"{x:488,y:712,t:1527268607046};\\\", \\\"{x:514,y:734,t:1527268607063};\\\", \\\"{x:532,y:747,t:1527268607080};\\\", \\\"{x:537,y:748,t:1527268607096};\\\" ] }, { \\\"rt\\\": 29801, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 673706, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"I look at the start time of the day \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 10311, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 685023, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 19325, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Natural Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 705360, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 1737, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 708430, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"CE2FW\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"CE2FW\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 149, dom: 728, initialDom: 772",
  "javascriptErrors": []
}