var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["051848916cc28b882a6c67f2fe320548aa3bb0ba"] = {
  "startTime": "2018-05-18T18:22:48.726175Z",
  "websitePageUrl": "/",
  "visitTime": 48235,
  "engagementTime": 45385,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "bf1026547d1c96b113820f9e6b14a5a9",
    "created": "2018-05-18T18:22:48.726175+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "91b1c36b4ecb2e27b315ec27142a8aa2",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/bf1026547d1c96b113820f9e6b14a5a9/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 234,
      "e": 234,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 2029,
      "e": 2029,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 906,
      "y": 55
    },
    {
      "t": 2252,
      "e": 2252,
      "ty": 41,
      "x": 30925,
      "y": 2603,
      "ta": "html > body"
    },
    {
      "t": 3101,
      "e": 3101,
      "ty": 2,
      "x": 944,
      "y": 0
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 1011,
      "y": 0
    },
    {
      "t": 3236,
      "e": 3236,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 35160,
      "y": 5816,
      "ta": "html > body"
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 2,
      "x": 1053,
      "y": 319
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 2,
      "x": 1133,
      "y": 639
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 41,
      "x": 42242,
      "y": 36003,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 1132,
      "y": 655
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 1131,
      "y": 662
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 42024,
      "y": 38051,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 1129,
      "y": 665
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 1128,
      "y": 666
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 2,
      "x": 1128,
      "y": 668
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 41,
      "x": 41969,
      "y": 38378,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1123,
      "y": 667
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 704,
      "y": 505
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 18814,
      "y": 25026,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 878,
      "y": 500
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 1115,
      "y": 584
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 51035,
      "y": 35757,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 1414,
      "y": 671
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 1432,
      "y": 680
    },
    {
      "t": 6502,
      "e": 6502,
      "ty": 41,
      "x": 58571,
      "y": 39361,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6534,
      "e": 6534,
      "ty": 3,
      "x": 1432,
      "y": 680,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6693,
      "e": 6693,
      "ty": 4,
      "x": 58571,
      "y": 39361,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6694,
      "e": 6694,
      "ty": 5,
      "x": 1432,
      "y": 680,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7789,
      "e": 7789,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 8874,
      "e": 8874,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10502,
      "e": 10502,
      "ty": 2,
      "x": 1417,
      "y": 689
    },
    {
      "t": 10502,
      "e": 10502,
      "ty": 41,
      "x": 55275,
      "y": 7497,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 10602,
      "e": 10602,
      "ty": 2,
      "x": 1369,
      "y": 739
    },
    {
      "t": 10702,
      "e": 10702,
      "ty": 2,
      "x": 1317,
      "y": 1199
    },
    {
      "t": 10802,
      "e": 10802,
      "ty": 2,
      "x": 1234,
      "y": 1199
    },
    {
      "t": 10901,
      "e": 10901,
      "ty": 2,
      "x": 1147,
      "y": 1107
    },
    {
      "t": 11001,
      "e": 11001,
      "ty": 2,
      "x": 1133,
      "y": 1073
    },
    {
      "t": 11002,
      "e": 11002,
      "ty": 41,
      "x": 38742,
      "y": 58998,
      "ta": "> div.masterdiv"
    },
    {
      "t": 11101,
      "e": 11101,
      "ty": 2,
      "x": 1081,
      "y": 1032
    },
    {
      "t": 11202,
      "e": 11202,
      "ty": 2,
      "x": 1041,
      "y": 974
    },
    {
      "t": 11251,
      "e": 11251,
      "ty": 41,
      "x": 36777,
      "y": 58285,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 11301,
      "e": 11301,
      "ty": 2,
      "x": 1045,
      "y": 954
    },
    {
      "t": 11401,
      "e": 11401,
      "ty": 2,
      "x": 1061,
      "y": 929
    },
    {
      "t": 11484,
      "e": 11484,
      "ty": 3,
      "x": 1063,
      "y": 926,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 11501,
      "e": 11501,
      "ty": 2,
      "x": 1063,
      "y": 926
    },
    {
      "t": 11501,
      "e": 11501,
      "ty": 41,
      "x": 54501,
      "y": 53666,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 11564,
      "e": 11564,
      "ty": 4,
      "x": 54501,
      "y": 53666,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 11564,
      "e": 11564,
      "ty": 5,
      "x": 1063,
      "y": 926,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 11566,
      "e": 11566,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 11570,
      "e": 11570,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 11702,
      "e": 11702,
      "ty": 2,
      "x": 1057,
      "y": 948
    },
    {
      "t": 11751,
      "e": 11751,
      "ty": 41,
      "x": 36039,
      "y": 62786,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 11802,
      "e": 11802,
      "ty": 2,
      "x": 1012,
      "y": 1068
    },
    {
      "t": 11830,
      "e": 11830,
      "ty": 6,
      "x": 1011,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 11901,
      "e": 11901,
      "ty": 2,
      "x": 1011,
      "y": 1073
    },
    {
      "t": 12001,
      "e": 12001,
      "ty": 2,
      "x": 1000,
      "y": 1089
    },
    {
      "t": 12002,
      "e": 12002,
      "ty": 41,
      "x": 49424,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 12093,
      "e": 12093,
      "ty": 3,
      "x": 1000,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 12094,
      "e": 12094,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 12095,
      "e": 12095,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 12101,
      "e": 12101,
      "ty": 2,
      "x": 1000,
      "y": 1090
    },
    {
      "t": 12180,
      "e": 12180,
      "ty": 4,
      "x": 49424,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 12181,
      "e": 12181,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 12182,
      "e": 12182,
      "ty": 5,
      "x": 1000,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 12182,
      "e": 12182,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 12251,
      "e": 12251,
      "ty": 41,
      "x": 34162,
      "y": 59939,
      "ta": "html > body"
    },
    {
      "t": 12301,
      "e": 12301,
      "ty": 2,
      "x": 1013,
      "y": 1076
    },
    {
      "t": 12401,
      "e": 12401,
      "ty": 2,
      "x": 1919,
      "y": 746
    },
    {
      "t": 12501,
      "e": 12501,
      "ty": 2,
      "x": 1919,
      "y": 712
    },
    {
      "t": 13188,
      "e": 13188,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 13401,
      "e": 13401,
      "ty": 2,
      "x": 1919,
      "y": 721
    },
    {
      "t": 13501,
      "e": 13501,
      "ty": 2,
      "x": 1919,
      "y": 731
    },
    {
      "t": 13601,
      "e": 13601,
      "ty": 2,
      "x": 1919,
      "y": 739
    },
    {
      "t": 13701,
      "e": 13701,
      "ty": 2,
      "x": 1919,
      "y": 741
    },
    {
      "t": 13801,
      "e": 13801,
      "ty": 2,
      "x": 1919,
      "y": 743
    },
    {
      "t": 14400,
      "e": 14400,
      "ty": 2,
      "x": 1919,
      "y": 744
    },
    {
      "t": 18400,
      "e": 18400,
      "ty": 2,
      "x": 1717,
      "y": 693
    },
    {
      "t": 18501,
      "e": 18501,
      "ty": 2,
      "x": 1408,
      "y": 760
    },
    {
      "t": 18501,
      "e": 18501,
      "ty": 41,
      "x": 48212,
      "y": 41658,
      "ta": "html > body"
    },
    {
      "t": 18600,
      "e": 18600,
      "ty": 2,
      "x": 1406,
      "y": 760
    },
    {
      "t": 18700,
      "e": 18700,
      "ty": 2,
      "x": 1515,
      "y": 641
    },
    {
      "t": 18751,
      "e": 18751,
      "ty": 41,
      "x": 51863,
      "y": 33681,
      "ta": "html > body"
    },
    {
      "t": 18800,
      "e": 18800,
      "ty": 2,
      "x": 1348,
      "y": 615
    },
    {
      "t": 18901,
      "e": 18901,
      "ty": 2,
      "x": 1071,
      "y": 610
    },
    {
      "t": 19000,
      "e": 19000,
      "ty": 2,
      "x": 1045,
      "y": 612
    },
    {
      "t": 19001,
      "e": 19001,
      "ty": 41,
      "x": 51260,
      "y": 63420,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 19101,
      "e": 19101,
      "ty": 2,
      "x": 1044,
      "y": 613
    },
    {
      "t": 19201,
      "e": 19201,
      "ty": 2,
      "x": 1045,
      "y": 611
    },
    {
      "t": 19221,
      "e": 19221,
      "ty": 6,
      "x": 1053,
      "y": 601,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19250,
      "e": 19250,
      "ty": 41,
      "x": 54504,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19301,
      "e": 19301,
      "ty": 2,
      "x": 1066,
      "y": 593
    },
    {
      "t": 19339,
      "e": 19339,
      "ty": 3,
      "x": 1066,
      "y": 593,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19340,
      "e": 19340,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19501,
      "e": 19501,
      "ty": 41,
      "x": 55802,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19516,
      "e": 19516,
      "ty": 4,
      "x": 55802,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 19517,
      "e": 19517,
      "ty": 5,
      "x": 1066,
      "y": 593,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 24100,
      "e": 24100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 24226,
      "e": 24226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 24227,
      "e": 24227,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 24393,
      "e": 24393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "M"
    },
    {
      "t": 24401,
      "e": 24401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 24402,
      "e": 24402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 24554,
      "e": 24554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ME"
    },
    {
      "t": 24754,
      "e": 24754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 24755,
      "e": 24755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 24905,
      "e": 24905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MEN"
    },
    {
      "t": 25170,
      "e": 25170,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MEN"
    },
    {
      "t": 26131,
      "e": 26131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 26131,
      "e": 26131,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "MEN"
    },
    {
      "t": 26131,
      "e": 26131,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26133,
      "e": 26133,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 26323,
      "e": 26323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 27106,
      "e": 27106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 27107,
      "e": 27107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27146,
      "e": 27146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 27274,
      "e": 27274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 27275,
      "e": 27275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 27370,
      "e": 27370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 28355,
      "e": 28355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "51"
    },
    {
      "t": 28356,
      "e": 28356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28530,
      "e": 28530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 28995,
      "e": 28995,
      "ty": 7,
      "x": 1060,
      "y": 621,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29001,
      "e": 29001,
      "ty": 2,
      "x": 1060,
      "y": 621
    },
    {
      "t": 29001,
      "e": 29001,
      "ty": 41,
      "x": 54504,
      "y": 4228,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 29101,
      "e": 29101,
      "ty": 2,
      "x": 1035,
      "y": 752
    },
    {
      "t": 29201,
      "e": 29201,
      "ty": 2,
      "x": 1026,
      "y": 742
    },
    {
      "t": 29228,
      "e": 29228,
      "ty": 6,
      "x": 1021,
      "y": 740,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29251,
      "e": 29251,
      "ty": 41,
      "x": 63433,
      "y": 61563,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29301,
      "e": 29301,
      "ty": 2,
      "x": 1016,
      "y": 732
    },
    {
      "t": 29401,
      "e": 29401,
      "ty": 2,
      "x": 1014,
      "y": 731
    },
    {
      "t": 29445,
      "e": 29445,
      "ty": 3,
      "x": 1014,
      "y": 731,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29446,
      "e": 29446,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 29446,
      "e": 29446,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29447,
      "e": 29447,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29501,
      "e": 29501,
      "ty": 41,
      "x": 60856,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29572,
      "e": 29572,
      "ty": 4,
      "x": 60856,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29573,
      "e": 29573,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29574,
      "e": 29574,
      "ty": 5,
      "x": 1014,
      "y": 731,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 29574,
      "e": 29574,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 29901,
      "e": 29901,
      "ty": 2,
      "x": 1102,
      "y": 704
    },
    {
      "t": 30001,
      "e": 30001,
      "ty": 2,
      "x": 1207,
      "y": 687
    },
    {
      "t": 30002,
      "e": 30002,
      "ty": 41,
      "x": 41290,
      "y": 37614,
      "ta": "html > body"
    },
    {
      "t": 30002,
      "e": 30002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30659,
      "e": 30659,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 30688,
      "e": 30688,
      "ty": 6,
      "x": 1207,
      "y": 687,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 31001,
      "e": 31001,
      "ty": 2,
      "x": 1219,
      "y": 674
    },
    {
      "t": 31002,
      "e": 31002,
      "ty": 41,
      "x": 44937,
      "y": 7058,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 31012,
      "e": 31012,
      "ty": 7,
      "x": 1215,
      "y": 667,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 31101,
      "e": 31101,
      "ty": 2,
      "x": 1189,
      "y": 626
    },
    {
      "t": 31201,
      "e": 31201,
      "ty": 2,
      "x": 1131,
      "y": 567
    },
    {
      "t": 31251,
      "e": 31251,
      "ty": 41,
      "x": 40958,
      "y": 43354,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 31301,
      "e": 31301,
      "ty": 2,
      "x": 1121,
      "y": 560
    },
    {
      "t": 31364,
      "e": 31364,
      "ty": 6,
      "x": 897,
      "y": 529,
      "ta": "#da1"
    },
    {
      "t": 31402,
      "e": 31402,
      "ty": 2,
      "x": 805,
      "y": 529
    },
    {
      "t": 31430,
      "e": 31430,
      "ty": 7,
      "x": 587,
      "y": 507,
      "ta": "#da1"
    },
    {
      "t": 31501,
      "e": 31501,
      "ty": 2,
      "x": 389,
      "y": 461
    },
    {
      "t": 31501,
      "e": 31501,
      "ty": 41,
      "x": 4700,
      "y": 64383,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 31701,
      "e": 31701,
      "ty": 2,
      "x": 389,
      "y": 443
    },
    {
      "t": 31751,
      "e": 31751,
      "ty": 41,
      "x": 4700,
      "y": 43318,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 31802,
      "e": 31802,
      "ty": 2,
      "x": 388,
      "y": 443
    },
    {
      "t": 31901,
      "e": 31901,
      "ty": 2,
      "x": 383,
      "y": 443
    },
    {
      "t": 32002,
      "e": 32002,
      "ty": 2,
      "x": 379,
      "y": 444
    },
    {
      "t": 32002,
      "e": 32002,
      "ty": 41,
      "x": 4208,
      "y": 44488,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 32101,
      "e": 32101,
      "ty": 2,
      "x": 377,
      "y": 444
    },
    {
      "t": 32202,
      "e": 32202,
      "ty": 2,
      "x": 375,
      "y": 445
    },
    {
      "t": 32252,
      "e": 32252,
      "ty": 41,
      "x": 3864,
      "y": 46828,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 32301,
      "e": 32301,
      "ty": 2,
      "x": 371,
      "y": 446
    },
    {
      "t": 32501,
      "e": 32501,
      "ty": 2,
      "x": 425,
      "y": 472
    },
    {
      "t": 32502,
      "e": 32502,
      "ty": 41,
      "x": 6471,
      "y": 10227,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 32565,
      "e": 32565,
      "ty": 6,
      "x": 823,
      "y": 737,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 32580,
      "e": 32580,
      "ty": 7,
      "x": 973,
      "y": 851,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 32601,
      "e": 32601,
      "ty": 2,
      "x": 1108,
      "y": 958
    },
    {
      "t": 32701,
      "e": 32701,
      "ty": 2,
      "x": 1531,
      "y": 1199
    },
    {
      "t": 32801,
      "e": 32801,
      "ty": 2,
      "x": 1511,
      "y": 1199
    },
    {
      "t": 32901,
      "e": 32901,
      "ty": 2,
      "x": 1406,
      "y": 1199
    },
    {
      "t": 33001,
      "e": 33001,
      "ty": 2,
      "x": 1224,
      "y": 1149
    },
    {
      "t": 33002,
      "e": 33002,
      "ty": 41,
      "x": 41876,
      "y": 63208,
      "ta": "> div.masterdiv"
    },
    {
      "t": 33101,
      "e": 33101,
      "ty": 2,
      "x": 1195,
      "y": 1136
    },
    {
      "t": 33201,
      "e": 33201,
      "ty": 2,
      "x": 1171,
      "y": 1119
    },
    {
      "t": 33251,
      "e": 33251,
      "ty": 41,
      "x": 38225,
      "y": 60937,
      "ta": "> div.masterdiv"
    },
    {
      "t": 33301,
      "e": 33301,
      "ty": 2,
      "x": 1043,
      "y": 1103
    },
    {
      "t": 33315,
      "e": 33315,
      "ty": 6,
      "x": 1017,
      "y": 1103,
      "ta": "#start"
    },
    {
      "t": 33401,
      "e": 33401,
      "ty": 2,
      "x": 977,
      "y": 1103
    },
    {
      "t": 33502,
      "e": 33502,
      "ty": 2,
      "x": 974,
      "y": 1103
    },
    {
      "t": 33502,
      "e": 33502,
      "ty": 41,
      "x": 35225,
      "y": 58427,
      "ta": "#start"
    },
    {
      "t": 33548,
      "e": 33548,
      "ty": 7,
      "x": 954,
      "y": 1110,
      "ta": "#start"
    },
    {
      "t": 33601,
      "e": 33601,
      "ty": 2,
      "x": 934,
      "y": 1112
    },
    {
      "t": 33700,
      "e": 33700,
      "ty": 3,
      "x": 933,
      "y": 1112,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 33701,
      "e": 33701,
      "ty": 2,
      "x": 933,
      "y": 1112
    },
    {
      "t": 33751,
      "e": 33751,
      "ty": 41,
      "x": 20362,
      "y": 21778,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 33843,
      "e": 33843,
      "ty": 4,
      "x": 20362,
      "y": 21778,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 33844,
      "e": 33844,
      "ty": 5,
      "x": 933,
      "y": 1112,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 33999,
      "e": 33999,
      "ty": 6,
      "x": 945,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 34001,
      "e": 34001,
      "ty": 2,
      "x": 945,
      "y": 1105
    },
    {
      "t": 34002,
      "e": 34002,
      "ty": 41,
      "x": 19387,
      "y": 62282,
      "ta": "#start"
    },
    {
      "t": 34101,
      "e": 34101,
      "ty": 2,
      "x": 955,
      "y": 1099
    },
    {
      "t": 34149,
      "e": 34149,
      "ty": 3,
      "x": 955,
      "y": 1099,
      "ta": "#start"
    },
    {
      "t": 34150,
      "e": 34150,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 34251,
      "e": 34251,
      "ty": 41,
      "x": 24848,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 34284,
      "e": 34284,
      "ty": 4,
      "x": 24848,
      "y": 50717,
      "ta": "#start"
    },
    {
      "t": 34285,
      "e": 34285,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 34286,
      "e": 34286,
      "ty": 5,
      "x": 955,
      "y": 1099,
      "ta": "#start"
    },
    {
      "t": 34286,
      "e": 34286,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 35289,
      "e": 35289,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 35401,
      "e": 35401,
      "ty": 2,
      "x": 950,
      "y": 1096
    },
    {
      "t": 35502,
      "e": 35502,
      "ty": 41,
      "x": 32440,
      "y": 60272,
      "ta": "html > body"
    },
    {
      "t": 35601,
      "e": 35601,
      "ty": 2,
      "x": 948,
      "y": 1096
    },
    {
      "t": 35702,
      "e": 35702,
      "ty": 2,
      "x": 947,
      "y": 1095
    },
    {
      "t": 35751,
      "e": 35751,
      "ty": 41,
      "x": 32337,
      "y": 60216,
      "ta": "html > body"
    },
    {
      "t": 36000,
      "e": 36000,
      "ty": 2,
      "x": 944,
      "y": 1094
    },
    {
      "t": 36001,
      "e": 36001,
      "ty": 41,
      "x": 32233,
      "y": 60161,
      "ta": "html > body"
    },
    {
      "t": 36100,
      "e": 36100,
      "ty": 2,
      "x": 936,
      "y": 1086
    },
    {
      "t": 36200,
      "e": 36200,
      "ty": 2,
      "x": 928,
      "y": 1075
    },
    {
      "t": 36250,
      "e": 36250,
      "ty": 41,
      "x": 31441,
      "y": 58388,
      "ta": "html > body"
    },
    {
      "t": 36300,
      "e": 36300,
      "ty": 2,
      "x": 910,
      "y": 1041
    },
    {
      "t": 36400,
      "e": 36400,
      "ty": 2,
      "x": 895,
      "y": 1014
    },
    {
      "t": 36500,
      "e": 36500,
      "ty": 2,
      "x": 882,
      "y": 983
    },
    {
      "t": 36501,
      "e": 36501,
      "ty": 41,
      "x": 29005,
      "y": 65030,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 36600,
      "e": 36600,
      "ty": 2,
      "x": 876,
      "y": 968
    },
    {
      "t": 36701,
      "e": 36701,
      "ty": 2,
      "x": 876,
      "y": 964
    },
    {
      "t": 36751,
      "e": 36751,
      "ty": 41,
      "x": 28714,
      "y": 63554,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 40001,
      "e": 40001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 44601,
      "e": 41751,
      "ty": 2,
      "x": 889,
      "y": 960
    },
    {
      "t": 44751,
      "e": 41901,
      "ty": 41,
      "x": 29345,
      "y": 63244,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 47228,
      "e": 44378,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 47300,
      "e": 44450,
      "ty": 2,
      "x": 890,
      "y": 959
    },
    {
      "t": 47501,
      "e": 44651,
      "ty": 41,
      "x": 30374,
      "y": 52682,
      "ta": "html > body"
    },
    {
      "t": 48235,
      "e": 45385,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 688, dom: 1496, initialDom: 1502",
  "javascriptErrors": []
}