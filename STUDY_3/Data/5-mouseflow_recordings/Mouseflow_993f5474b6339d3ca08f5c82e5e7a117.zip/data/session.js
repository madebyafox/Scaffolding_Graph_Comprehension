var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "993f5474b6339d3ca08f5c82e5e7a117",
  "created": "2018-05-22T10:19:20.4237015-07:00",
  "lastActivity": "2018-05-22T10:19:32.9557015-07:00",
  "pageViews": [
    {
      "id": "052220329667c0eb289a0f3b1e4fa8c003c0121b",
      "startTime": "2018-05-22T10:19:20.4237015-07:00",
      "endTime": "2018-05-22T10:19:32.9557015-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 12532,
      "engagementTime": 12384,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 12532,
  "engagementTime": 12384,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=808YR",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d15e735ee195b9de4d18975be14fa561",
  "gdpr": false
}