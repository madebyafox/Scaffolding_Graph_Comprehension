var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f2e98b5ab8453b8bea65746e871dcf28",
  "created": "2018-05-18T11:16:22.7935228-07:00",
  "lastActivity": "2018-05-18T11:18:22.4942128-07:00",
  "pageViews": [
    {
      "id": "051822350a1767c156d84b4e4a7e56d9239d492e",
      "startTime": "2018-05-18T11:16:22.8922128-07:00",
      "endTime": "2018-05-18T11:18:22.4942128-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 119602,
      "engagementTime": 119602,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 119602,
  "engagementTime": 119602,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8U980",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b0e1a4376f95b5b68447d148edd440ec",
  "gdpr": false
}