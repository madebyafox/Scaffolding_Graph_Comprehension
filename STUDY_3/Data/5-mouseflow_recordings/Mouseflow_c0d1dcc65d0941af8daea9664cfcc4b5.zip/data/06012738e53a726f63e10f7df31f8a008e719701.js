var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06012738e53a726f63e10f7df31f8a008e719701"] = {
  "startTime": "2018-06-01T16:08:27.5924077Z",
  "websitePageUrl": "/",
  "visitTime": 105908,
  "engagementTime": 52803,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 929,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "c0d1dcc65d0941af8daea9664cfcc4b5",
    "created": "2018-06-01T16:08:27.5924077+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "87bc5ffb2bc8410b1e39fc19dc288961",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/c0d1dcc65d0941af8daea9664cfcc4b5/play"
  },
  "events": [
    {
      "t": 7,
      "e": 7,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 929,
      "y": 1047
    },
    {
      "t": 10000,
      "e": 5101,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 15701,
      "e": 5101,
      "ty": 2,
      "x": 241,
      "y": 99
    },
    {
      "t": 15751,
      "e": 5151,
      "ty": 41,
      "x": 23264,
      "y": 6389,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 15801,
      "e": 5201,
      "ty": 2,
      "x": 321,
      "y": 273
    },
    {
      "t": 15901,
      "e": 5301,
      "ty": 2,
      "x": 323,
      "y": 275
    },
    {
      "t": 15975,
      "e": 5375,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 16001,
      "e": 5401,
      "ty": 2,
      "x": 397,
      "y": 39
    },
    {
      "t": 16002,
      "e": 5402,
      "ty": 41,
      "x": 27952,
      "y": 1972,
      "ta": "html > body"
    },
    {
      "t": 16601,
      "e": 6001,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 19901,
      "e": 9301,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 19901,
      "e": 9301,
      "ty": 2,
      "x": 553,
      "y": 34
    },
    {
      "t": 20001,
      "e": 9401,
      "ty": 41,
      "x": 18768,
      "y": 1440,
      "ta": "html > body"
    },
    {
      "t": 30001,
      "e": 14401,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 61205,
      "e": 14401,
      "ty": 2,
      "x": 711,
      "y": 0
    },
    {
      "t": 61255,
      "e": 14451,
      "ty": 41,
      "x": 26654,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 61305,
      "e": 14501,
      "ty": 2,
      "x": 775,
      "y": 0
    },
    {
      "t": 61364,
      "e": 14560,
      "ty": 3,
      "x": 775,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 61405,
      "e": 14601,
      "ty": 2,
      "x": 791,
      "y": 37
    },
    {
      "t": 61504,
      "e": 14700,
      "ty": 2,
      "x": 807,
      "y": 132
    },
    {
      "t": 61506,
      "e": 14702,
      "ty": 41,
      "x": 27515,
      "y": 6869,
      "ta": "html > body"
    },
    {
      "t": 61506,
      "e": 14702,
      "ty": 4,
      "x": 27515,
      "y": 6869,
      "ta": "html > body"
    },
    {
      "t": 61508,
      "e": 14704,
      "ty": 5,
      "x": 807,
      "y": 132,
      "ta": "html"
    },
    {
      "t": 61704,
      "e": 14900,
      "ty": 2,
      "x": 823,
      "y": 211
    },
    {
      "t": 61755,
      "e": 14951,
      "ty": 41,
      "x": 25312,
      "y": 17899,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 61804,
      "e": 15000,
      "ty": 2,
      "x": 825,
      "y": 554
    },
    {
      "t": 61904,
      "e": 15100,
      "ty": 2,
      "x": 827,
      "y": 619
    },
    {
      "t": 62004,
      "e": 15200,
      "ty": 2,
      "x": 769,
      "y": 568
    },
    {
      "t": 62005,
      "e": 15201,
      "ty": 41,
      "x": 22363,
      "y": 30187,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 62104,
      "e": 15300,
      "ty": 2,
      "x": 679,
      "y": 586
    },
    {
      "t": 62204,
      "e": 15400,
      "ty": 2,
      "x": 976,
      "y": 764
    },
    {
      "t": 62255,
      "e": 15451,
      "ty": 41,
      "x": 33723,
      "y": 42638,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 62305,
      "e": 15501,
      "ty": 2,
      "x": 931,
      "y": 687
    },
    {
      "t": 62404,
      "e": 15600,
      "ty": 2,
      "x": 944,
      "y": 711
    },
    {
      "t": 62504,
      "e": 15700,
      "ty": 2,
      "x": 931,
      "y": 661
    },
    {
      "t": 62505,
      "e": 15701,
      "ty": 41,
      "x": 31211,
      "y": 37805,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 62605,
      "e": 15801,
      "ty": 2,
      "x": 822,
      "y": 855
    },
    {
      "t": 62705,
      "e": 15901,
      "ty": 2,
      "x": 811,
      "y": 907
    },
    {
      "t": 62754,
      "e": 15950,
      "ty": 41,
      "x": 24657,
      "y": 58285,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 62805,
      "e": 16001,
      "ty": 2,
      "x": 810,
      "y": 912
    },
    {
      "t": 62905,
      "e": 16101,
      "ty": 2,
      "x": 810,
      "y": 910
    },
    {
      "t": 63005,
      "e": 16201,
      "ty": 2,
      "x": 810,
      "y": 896
    },
    {
      "t": 63005,
      "e": 16201,
      "ty": 41,
      "x": 24602,
      "y": 57056,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 63105,
      "e": 16301,
      "ty": 2,
      "x": 810,
      "y": 894
    },
    {
      "t": 63205,
      "e": 16401,
      "ty": 2,
      "x": 810,
      "y": 891
    },
    {
      "t": 63255,
      "e": 16451,
      "ty": 41,
      "x": 24602,
      "y": 56482,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 63305,
      "e": 16501,
      "ty": 2,
      "x": 810,
      "y": 883
    },
    {
      "t": 63404,
      "e": 16600,
      "ty": 2,
      "x": 809,
      "y": 882
    },
    {
      "t": 63505,
      "e": 16701,
      "ty": 41,
      "x": 24548,
      "y": 55909,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 70005,
      "e": 21701,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 73800,
      "e": 21701,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 73905,
      "e": 21701,
      "ty": 1,
      "x": 0,
      "y": 11
    },
    {
      "t": 74005,
      "e": 21801,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 75176,
      "e": 22972,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 76905,
      "e": 24701,
      "ty": 2,
      "x": 809,
      "y": 903
    },
    {
      "t": 77005,
      "e": 24801,
      "ty": 2,
      "x": 809,
      "y": 922
    },
    {
      "t": 77006,
      "e": 24802,
      "ty": 41,
      "x": 18226,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 77105,
      "e": 24901,
      "ty": 2,
      "x": 809,
      "y": 923
    },
    {
      "t": 77256,
      "e": 25052,
      "ty": 41,
      "x": 18226,
      "y": 39372,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 77330,
      "e": 25126,
      "ty": 3,
      "x": 809,
      "y": 923,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 77394,
      "e": 25190,
      "ty": 4,
      "x": 18226,
      "y": 39372,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 77395,
      "e": 25191,
      "ty": 5,
      "x": 809,
      "y": 923,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 77397,
      "e": 25193,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 77407,
      "e": 25203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 77606,
      "e": 25402,
      "ty": 2,
      "x": 936,
      "y": 1068
    },
    {
      "t": 77612,
      "e": 25408,
      "ty": 6,
      "x": 956,
      "y": 1086,
      "ta": "#start"
    },
    {
      "t": 77645,
      "e": 25441,
      "ty": 7,
      "x": 982,
      "y": 1108,
      "ta": "#start"
    },
    {
      "t": 77705,
      "e": 25501,
      "ty": 2,
      "x": 991,
      "y": 1119
    },
    {
      "t": 77756,
      "e": 25552,
      "ty": 41,
      "x": 47512,
      "y": 25656,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 77805,
      "e": 25601,
      "ty": 2,
      "x": 991,
      "y": 1120
    },
    {
      "t": 77905,
      "e": 25701,
      "ty": 2,
      "x": 988,
      "y": 1120
    },
    {
      "t": 78005,
      "e": 25801,
      "ty": 2,
      "x": 981,
      "y": 1109
    },
    {
      "t": 78006,
      "e": 25802,
      "ty": 41,
      "x": 42831,
      "y": 20116,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 78145,
      "e": 25941,
      "ty": 6,
      "x": 981,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 78205,
      "e": 26001,
      "ty": 2,
      "x": 981,
      "y": 1099
    },
    {
      "t": 78255,
      "e": 26051,
      "ty": 41,
      "x": 39594,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 78299,
      "e": 26095,
      "ty": 3,
      "x": 982,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 78300,
      "e": 26096,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 78301,
      "e": 26097,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 78305,
      "e": 26101,
      "ty": 2,
      "x": 982,
      "y": 1095
    },
    {
      "t": 78377,
      "e": 26173,
      "ty": 4,
      "x": 39594,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 78378,
      "e": 26174,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 78378,
      "e": 26174,
      "ty": 5,
      "x": 982,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 78379,
      "e": 26175,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 79386,
      "e": 27182,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 80005,
      "e": 27801,
      "ty": 2,
      "x": 797,
      "y": 619
    },
    {
      "t": 80005,
      "e": 27801,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80006,
      "e": 27802,
      "ty": 41,
      "x": 27171,
      "y": 33847,
      "ta": "html > body"
    },
    {
      "t": 80105,
      "e": 27901,
      "ty": 2,
      "x": 789,
      "y": 472
    },
    {
      "t": 80205,
      "e": 28001,
      "ty": 2,
      "x": 823,
      "y": 506
    },
    {
      "t": 80255,
      "e": 28051,
      "ty": 41,
      "x": 12112,
      "y": 7021,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 80305,
      "e": 28101,
      "ty": 2,
      "x": 887,
      "y": 575
    },
    {
      "t": 80365,
      "e": 28161,
      "ty": 6,
      "x": 890,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 80405,
      "e": 28201,
      "ty": 2,
      "x": 890,
      "y": 600
    },
    {
      "t": 80505,
      "e": 28301,
      "ty": 2,
      "x": 890,
      "y": 602
    },
    {
      "t": 80505,
      "e": 28301,
      "ty": 41,
      "x": 17735,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 80530,
      "e": 28326,
      "ty": 3,
      "x": 890,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 80531,
      "e": 28327,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 80610,
      "e": 28406,
      "ty": 4,
      "x": 17735,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 80610,
      "e": 28406,
      "ty": 5,
      "x": 890,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 82133,
      "e": 29929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "16"
    },
    {
      "t": 82237,
      "e": 30033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 82238,
      "e": 30034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 82357,
      "e": 30153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "V"
    },
    {
      "t": 82445,
      "e": 30241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 82446,
      "e": 30242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 82542,
      "e": 30338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "VI"
    },
    {
      "t": 83630,
      "e": 31426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 83631,
      "e": 31427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 83717,
      "e": 31513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "VIC"
    },
    {
      "t": 83871,
      "e": 31667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "84"
    },
    {
      "t": 83871,
      "e": 31667,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 83982,
      "e": 31778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "VICT"
    },
    {
      "t": 84053,
      "e": 31849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 84054,
      "e": 31850,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 84141,
      "e": 31937,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||O"
    },
    {
      "t": 84262,
      "e": 32058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 84262,
      "e": 32058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 84332,
      "e": 32128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||R"
    },
    {
      "t": 84461,
      "e": 32257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 84685,
      "e": 32481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 84687,
      "e": 32483,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "VICTOR"
    },
    {
      "t": 84688,
      "e": 32484,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 84689,
      "e": 32485,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84773,
      "e": 32569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 85549,
      "e": 33345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 85550,
      "e": 33346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 85662,
      "e": 33458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 85756,
      "e": 33552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 85756,
      "e": 33552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 85837,
      "e": 33633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 85988,
      "e": 33784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "52"
    },
    {
      "t": 85989,
      "e": 33785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86052,
      "e": 33848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 86613,
      "e": 34409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 86614,
      "e": 34410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 86676,
      "e": 34472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*\n"
    },
    {
      "t": 86810,
      "e": 34606,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*\n"
    },
    {
      "t": 87797,
      "e": 35593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 87925,
      "e": 35721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 88804,
      "e": 36600,
      "ty": 7,
      "x": 905,
      "y": 623,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88806,
      "e": 36602,
      "ty": 2,
      "x": 905,
      "y": 623
    },
    {
      "t": 88904,
      "e": 36700,
      "ty": 2,
      "x": 919,
      "y": 811
    },
    {
      "t": 89005,
      "e": 36801,
      "ty": 2,
      "x": 919,
      "y": 831
    },
    {
      "t": 89005,
      "e": 36801,
      "ty": 41,
      "x": 31372,
      "y": 45591,
      "ta": "html > body"
    },
    {
      "t": 89105,
      "e": 36901,
      "ty": 6,
      "x": 920,
      "y": 738,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 89106,
      "e": 36902,
      "ty": 2,
      "x": 920,
      "y": 738
    },
    {
      "t": 89204,
      "e": 37000,
      "ty": 2,
      "x": 922,
      "y": 726
    },
    {
      "t": 89255,
      "e": 37051,
      "ty": 41,
      "x": 13440,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 89441,
      "e": 37237,
      "ty": 3,
      "x": 922,
      "y": 726,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 89442,
      "e": 37238,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 89442,
      "e": 37238,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 89442,
      "e": 37238,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 89545,
      "e": 37341,
      "ty": 4,
      "x": 13440,
      "y": 35746,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 89546,
      "e": 37342,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 89547,
      "e": 37343,
      "ty": 5,
      "x": 922,
      "y": 726,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 89547,
      "e": 37343,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 90005,
      "e": 37801,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90642,
      "e": 38438,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 90677,
      "e": 38473,
      "ty": 6,
      "x": 922,
      "y": 726,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 91802,
      "e": 39598,
      "ty": 7,
      "x": 922,
      "y": 727,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 91803,
      "e": 39599,
      "ty": 6,
      "x": 922,
      "y": 727,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 91804,
      "e": 39600,
      "ty": 2,
      "x": 922,
      "y": 727
    },
    {
      "t": 92005,
      "e": 39801,
      "ty": 41,
      "x": 29890,
      "y": 36,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 92205,
      "e": 40001,
      "ty": 2,
      "x": 923,
      "y": 728
    },
    {
      "t": 92254,
      "e": 40050,
      "ty": 41,
      "x": 29941,
      "y": 2377,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 93755,
      "e": 41551,
      "ty": 41,
      "x": 29890,
      "y": 11739,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 93804,
      "e": 41600,
      "ty": 2,
      "x": 921,
      "y": 735
    },
    {
      "t": 93905,
      "e": 41701,
      "ty": 2,
      "x": 920,
      "y": 742
    },
    {
      "t": 93940,
      "e": 41736,
      "ty": 7,
      "x": 920,
      "y": 759,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 93940,
      "e": 41736,
      "ty": 6,
      "x": 920,
      "y": 759,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 94004,
      "e": 41800,
      "ty": 2,
      "x": 920,
      "y": 776
    },
    {
      "t": 94005,
      "e": 41801,
      "ty": 41,
      "x": 29789,
      "y": 49187,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 94022,
      "e": 41818,
      "ty": 7,
      "x": 920,
      "y": 784,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 94105,
      "e": 41901,
      "ty": 2,
      "x": 918,
      "y": 812
    },
    {
      "t": 94205,
      "e": 42001,
      "ty": 2,
      "x": 918,
      "y": 892
    },
    {
      "t": 94255,
      "e": 42051,
      "ty": 41,
      "x": 31119,
      "y": 56069,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94305,
      "e": 42101,
      "ty": 2,
      "x": 939,
      "y": 974
    },
    {
      "t": 94405,
      "e": 42201,
      "ty": 2,
      "x": 956,
      "y": 1021
    },
    {
      "t": 94505,
      "e": 42301,
      "ty": 2,
      "x": 956,
      "y": 1024
    },
    {
      "t": 94505,
      "e": 42301,
      "ty": 41,
      "x": 32595,
      "y": 62163,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94605,
      "e": 42401,
      "ty": 2,
      "x": 958,
      "y": 1042
    },
    {
      "t": 94705,
      "e": 42501,
      "ty": 2,
      "x": 958,
      "y": 1045
    },
    {
      "t": 94755,
      "e": 42551,
      "ty": 41,
      "x": 32693,
      "y": 65002,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94757,
      "e": 42553,
      "ty": 6,
      "x": 958,
      "y": 1079,
      "ta": "#start"
    },
    {
      "t": 94804,
      "e": 42600,
      "ty": 2,
      "x": 960,
      "y": 1097
    },
    {
      "t": 94905,
      "e": 42701,
      "ty": 2,
      "x": 960,
      "y": 1098
    },
    {
      "t": 95005,
      "e": 42801,
      "ty": 2,
      "x": 960,
      "y": 1100
    },
    {
      "t": 95005,
      "e": 42801,
      "ty": 41,
      "x": 27579,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 95105,
      "e": 42901,
      "ty": 2,
      "x": 960,
      "y": 1102
    },
    {
      "t": 95254,
      "e": 43050,
      "ty": 41,
      "x": 27579,
      "y": 56499,
      "ta": "#start"
    },
    {
      "t": 95304,
      "e": 43100,
      "ty": 2,
      "x": 962,
      "y": 1100
    },
    {
      "t": 95405,
      "e": 43201,
      "ty": 2,
      "x": 962,
      "y": 1097
    },
    {
      "t": 95505,
      "e": 43301,
      "ty": 2,
      "x": 963,
      "y": 1093
    },
    {
      "t": 95505,
      "e": 43301,
      "ty": 41,
      "x": 29217,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 96770,
      "e": 44566,
      "ty": 3,
      "x": 963,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 96771,
      "e": 44567,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 96897,
      "e": 44693,
      "ty": 4,
      "x": 29217,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 96897,
      "e": 44693,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 96898,
      "e": 44694,
      "ty": 5,
      "x": 963,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 96898,
      "e": 44694,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 97901,
      "e": 45697,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 99105,
      "e": 46901,
      "ty": 2,
      "x": 962,
      "y": 1087
    },
    {
      "t": 99205,
      "e": 47001,
      "ty": 2,
      "x": 960,
      "y": 1078
    },
    {
      "t": 99255,
      "e": 47051,
      "ty": 41,
      "x": 32784,
      "y": 59275,
      "ta": "html > body"
    },
    {
      "t": 99305,
      "e": 47101,
      "ty": 2,
      "x": 960,
      "y": 1074
    },
    {
      "t": 99405,
      "e": 47201,
      "ty": 2,
      "x": 959,
      "y": 1067
    },
    {
      "t": 99505,
      "e": 47301,
      "ty": 2,
      "x": 958,
      "y": 1059
    },
    {
      "t": 99505,
      "e": 47301,
      "ty": 41,
      "x": 32715,
      "y": 58222,
      "ta": "html > body"
    },
    {
      "t": 99605,
      "e": 47401,
      "ty": 2,
      "x": 957,
      "y": 1053
    },
    {
      "t": 99705,
      "e": 47501,
      "ty": 2,
      "x": 956,
      "y": 1052
    },
    {
      "t": 99755,
      "e": 47551,
      "ty": 41,
      "x": 32646,
      "y": 57613,
      "ta": "html > body"
    },
    {
      "t": 99805,
      "e": 47601,
      "ty": 2,
      "x": 955,
      "y": 1045
    },
    {
      "t": 99905,
      "e": 47701,
      "ty": 2,
      "x": 955,
      "y": 1042
    },
    {
      "t": 100005,
      "e": 47801,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100007,
      "e": 47803,
      "ty": 41,
      "x": 32612,
      "y": 57280,
      "ta": "html > body"
    },
    {
      "t": 104902,
      "e": 52698,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 105908,
      "e": 52803,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 113, dom: 788, initialDom: 799",
  "javascriptErrors": []
}