var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0522290487b1b08c83e7da5ef5d5d10d94165de6"] = {
  "startTime": "2018-05-22T22:11:29.4933904Z",
  "websitePageUrl": "/16",
  "visitTime": 99081,
  "engagementTime": 61073,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "d234b36f02140911f7bbb8b1d2de53d2",
    "created": "2018-05-22T22:11:29.4933904+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=2S99A",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "4d19edf39216b479ec6d79987ea205f1",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/d234b36f02140911f7bbb8b1d2de53d2/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 228,
      "e": 228,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 521,
      "y": 713
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 530,
      "y": 677
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 48662,
      "y": 36728,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 531,
      "y": 669
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 48775,
      "y": 36617,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3800,
      "e": 3800,
      "ty": 2,
      "x": 531,
      "y": 661
    },
    {
      "t": 3900,
      "e": 3900,
      "ty": 2,
      "x": 540,
      "y": 643
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 2,
      "x": 542,
      "y": 642
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 50011,
      "y": 35121,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 560,
      "y": 605
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 41,
      "x": 52035,
      "y": 61762,
      "ta": "#.strategy"
    },
    {
      "t": 5006,
      "e": 5006,
      "ty": 6,
      "x": 564,
      "y": 599,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5100,
      "e": 5100,
      "ty": 2,
      "x": 577,
      "y": 568
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 578,
      "y": 568
    },
    {
      "t": 5250,
      "e": 5250,
      "ty": 41,
      "x": 54058,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5448,
      "e": 5448,
      "ty": 3,
      "x": 578,
      "y": 568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5449,
      "e": 5449,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5599,
      "e": 5599,
      "ty": 4,
      "x": 54058,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5599,
      "e": 5599,
      "ty": 5,
      "x": 578,
      "y": 568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30029,
      "e": 10599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30029,
      "e": 10599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30098,
      "e": 10668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i"
    },
    {
      "t": 30115,
      "e": 10685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30115,
      "e": 10685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30170,
      "e": 10740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 30170,
      "e": 10740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30218,
      "e": 10788,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i w"
    },
    {
      "t": 30258,
      "e": 10828,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30259,
      "e": 10829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30282,
      "e": 10852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i wa"
    },
    {
      "t": 30362,
      "e": 10932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 30363,
      "e": 10933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30402,
      "e": 10972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 30435,
      "e": 11005,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30435,
      "e": 11005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30466,
      "e": 11036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30491,
      "e": 11061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 30491,
      "e": 11061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30498,
      "e": 11068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 30594,
      "e": 11164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30707,
      "e": 11277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 30708,
      "e": 11278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30763,
      "e": 11333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 30859,
      "e": 11429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 30860,
      "e": 11430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30922,
      "e": 11492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 30923,
      "e": 11493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30946,
      "e": 11516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ok"
    },
    {
      "t": 31019,
      "e": 11589,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31106,
      "e": 11676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31107,
      "e": 11677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31114,
      "e": 11684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 31114,
      "e": 11684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31178,
      "e": 11748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 31178,
      "e": 11748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31187,
      "e": 11757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ing"
    },
    {
      "t": 31250,
      "e": 11820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31258,
      "e": 11828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31306,
      "e": 11876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31307,
      "e": 11877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31395,
      "e": 11965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31515,
      "e": 12085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 31516,
      "e": 12086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31594,
      "e": 12164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 31650,
      "e": 12220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31650,
      "e": 12220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31714,
      "e": 12284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 31715,
      "e": 12285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31754,
      "e": 12324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 31771,
      "e": 12341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31884,
      "e": 12454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31884,
      "e": 12454,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31939,
      "e": 12509,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 31954,
      "e": 12524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31955,
      "e": 12525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32027,
      "e": 12597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 32067,
      "e": 12637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 32067,
      "e": 12637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32114,
      "e": 12684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32114,
      "e": 12684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32162,
      "e": 12732,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 32186,
      "e": 12756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 32187,
      "e": 12757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32226,
      "e": 12796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 32267,
      "e": 12837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32330,
      "e": 12900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 32331,
      "e": 12901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32395,
      "e": 12965,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 32507,
      "e": 13077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 32507,
      "e": 13077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32562,
      "e": 13132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 32586,
      "e": 13156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32587,
      "e": 13157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32674,
      "e": 13244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32682,
      "e": 13252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 32683,
      "e": 13253,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32730,
      "e": 13300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 32731,
      "e": 13301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32778,
      "e": 13348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||up"
    },
    {
      "t": 32842,
      "e": 13412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32874,
      "e": 13444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32875,
      "e": 13445,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32947,
      "e": 13517,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32979,
      "e": 13549,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 32980,
      "e": 13550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33058,
      "e": 13628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 33138,
      "e": 13708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 33138,
      "e": 13708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33203,
      "e": 13773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 33211,
      "e": 13781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 33212,
      "e": 13782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33274,
      "e": 13844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 33274,
      "e": 13844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33307,
      "e": 13877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||om"
    },
    {
      "t": 33331,
      "e": 13901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33331,
      "e": 13901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33354,
      "e": 13924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33459,
      "e": 14029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33723,
      "e": 14293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 33724,
      "e": 14294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33826,
      "e": 14396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 33827,
      "e": 14397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33850,
      "e": 14420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 33922,
      "e": 14492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33931,
      "e": 14501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33931,
      "e": 14501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34042,
      "e": 14612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34051,
      "e": 14621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 34051,
      "e": 14621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34131,
      "e": 14701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 34131,
      "e": 14701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34154,
      "e": 14724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 34275,
      "e": 14845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34443,
      "e": 15013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34443,
      "e": 15013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34555,
      "e": 15125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34603,
      "e": 15173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 34605,
      "e": 15175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34674,
      "e": 15244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 34682,
      "e": 15252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 34682,
      "e": 15252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34779,
      "e": 15349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 34795,
      "e": 15365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34795,
      "e": 15365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34883,
      "e": 15453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34891,
      "e": 15461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34892,
      "e": 15462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34962,
      "e": 15532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34962,
      "e": 15532,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34987,
      "e": 15557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| i"
    },
    {
      "t": 35082,
      "e": 15652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35091,
      "e": 15661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 35091,
      "e": 15661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35173,
      "e": 15663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 35179,
      "e": 15669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 35180,
      "e": 15670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35274,
      "e": 15764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 35282,
      "e": 15772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35282,
      "e": 15772,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35362,
      "e": 15852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35362,
      "e": 15852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 35362,
      "e": 15852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35450,
      "e": 15940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 35450,
      "e": 15940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35466,
      "e": 15956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wh"
    },
    {
      "t": 35490,
      "e": 15980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 35491,
      "e": 15981,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35555,
      "e": 16045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 35555,
      "e": 16045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35555,
      "e": 16045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35586,
      "e": 16076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 35618,
      "e": 16108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35651,
      "e": 16141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35652,
      "e": 16142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35706,
      "e": 16196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35707,
      "e": 16197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35722,
      "e": 16212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 35778,
      "e": 16268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35786,
      "e": 16276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 35786,
      "e": 16276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35882,
      "e": 16372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35884,
      "e": 16374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35891,
      "e": 16381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 35971,
      "e": 16461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36011,
      "e": 16501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36012,
      "e": 16502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36098,
      "e": 16588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36178,
      "e": 16668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36179,
      "e": 16669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36274,
      "e": 16764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 36283,
      "e": 16773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36283,
      "e": 16773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36346,
      "e": 16836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 36394,
      "e": 16884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36394,
      "e": 16884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36458,
      "e": 16948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 36540,
      "e": 17030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36541,
      "e": 17031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36602,
      "e": 17092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 36602,
      "e": 17092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36602,
      "e": 17092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36714,
      "e": 17204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36714,
      "e": 17204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36722,
      "e": 17212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| i"
    },
    {
      "t": 36795,
      "e": 17285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 36795,
      "e": 17285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36810,
      "e": 17300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 36906,
      "e": 17396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36906,
      "e": 17396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36906,
      "e": 17396,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36962,
      "e": 17452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 36963,
      "e": 17453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36970,
      "e": 17460,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| d"
    },
    {
      "t": 37026,
      "e": 17516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 37026,
      "e": 17516,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37050,
      "e": 17540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 37066,
      "e": 17556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 37066,
      "e": 17556,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37106,
      "e": 17596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 37146,
      "e": 17636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37146,
      "e": 17636,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37178,
      "e": 17668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 37202,
      "e": 17692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 37203,
      "e": 17693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37259,
      "e": 17749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 37282,
      "e": 17772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37403,
      "e": 17893,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i was looking vertically up from 12 pm but idk what the hell im doing"
    },
    {
      "t": 37411,
      "e": 17901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37412,
      "e": 17902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37538,
      "e": 18028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40204,
      "e": 20694,
      "ty": 2,
      "x": 210,
      "y": 570
    },
    {
      "t": 40237,
      "e": 20727,
      "ty": 7,
      "x": 217,
      "y": 614,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40254,
      "e": 20744,
      "ty": 41,
      "x": 13478,
      "y": 62026,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 40304,
      "e": 20794,
      "ty": 2,
      "x": 224,
      "y": 629
    },
    {
      "t": 40404,
      "e": 20894,
      "ty": 2,
      "x": 288,
      "y": 665
    },
    {
      "t": 40421,
      "e": 20911,
      "ty": 6,
      "x": 342,
      "y": 674,
      "ta": "#strategyButton"
    },
    {
      "t": 40504,
      "e": 20994,
      "ty": 2,
      "x": 354,
      "y": 675
    },
    {
      "t": 40504,
      "e": 20994,
      "ty": 41,
      "x": 8413,
      "y": 39061,
      "ta": "#strategyButton"
    },
    {
      "t": 40604,
      "e": 21094,
      "ty": 2,
      "x": 356,
      "y": 675
    },
    {
      "t": 40684,
      "e": 21174,
      "ty": 3,
      "x": 356,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 40685,
      "e": 21175,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i was looking vertically up from 12 pm but idk what the hell im doing "
    },
    {
      "t": 40687,
      "e": 21177,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40688,
      "e": 21178,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 40754,
      "e": 21244,
      "ty": 4,
      "x": 9505,
      "y": 39061,
      "ta": "#strategyButton"
    },
    {
      "t": 40763,
      "e": 21253,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 40765,
      "e": 21255,
      "ty": 5,
      "x": 356,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 40774,
      "e": 21264,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 40775,
      "e": 21265,
      "ty": 41,
      "x": 11984,
      "y": 36949,
      "ta": "html > body"
    },
    {
      "t": 41604,
      "e": 22094,
      "ty": 2,
      "x": 355,
      "y": 675
    },
    {
      "t": 41754,
      "e": 22244,
      "ty": 41,
      "x": 11949,
      "y": 36949,
      "ta": "html > body"
    },
    {
      "t": 41773,
      "e": 22263,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 42504,
      "e": 22994,
      "ty": 2,
      "x": 383,
      "y": 667
    },
    {
      "t": 42504,
      "e": 22994,
      "ty": 41,
      "x": 12914,
      "y": 36506,
      "ta": "html > body"
    },
    {
      "t": 42604,
      "e": 23094,
      "ty": 2,
      "x": 652,
      "y": 617
    },
    {
      "t": 42704,
      "e": 23194,
      "ty": 2,
      "x": 726,
      "y": 601
    },
    {
      "t": 42755,
      "e": 23245,
      "ty": 41,
      "x": 25380,
      "y": 32739,
      "ta": "html > body"
    },
    {
      "t": 42804,
      "e": 23294,
      "ty": 2,
      "x": 780,
      "y": 594
    },
    {
      "t": 42857,
      "e": 23347,
      "ty": 6,
      "x": 922,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42905,
      "e": 23395,
      "ty": 2,
      "x": 934,
      "y": 567
    },
    {
      "t": 43004,
      "e": 23494,
      "ty": 2,
      "x": 935,
      "y": 567
    },
    {
      "t": 43005,
      "e": 23495,
      "ty": 41,
      "x": 27468,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43083,
      "e": 23573,
      "ty": 3,
      "x": 935,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43084,
      "e": 23574,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43104,
      "e": 23594,
      "ty": 2,
      "x": 935,
      "y": 558
    },
    {
      "t": 43201,
      "e": 23691,
      "ty": 4,
      "x": 27468,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43201,
      "e": 23691,
      "ty": 5,
      "x": 935,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43255,
      "e": 23745,
      "ty": 41,
      "x": 27468,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44079,
      "e": 24569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 44079,
      "e": 24569,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44191,
      "e": 24681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 44431,
      "e": 24921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 44431,
      "e": 24921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44517,
      "e": 25007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 44658,
      "e": 25148,
      "ty": 7,
      "x": 952,
      "y": 579,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44704,
      "e": 25194,
      "ty": 2,
      "x": 962,
      "y": 604
    },
    {
      "t": 44754,
      "e": 25244,
      "ty": 41,
      "x": 33308,
      "y": 36643,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 44804,
      "e": 25294,
      "ty": 2,
      "x": 958,
      "y": 642
    },
    {
      "t": 44875,
      "e": 25365,
      "ty": 6,
      "x": 944,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44904,
      "e": 25394,
      "ty": 2,
      "x": 933,
      "y": 664
    },
    {
      "t": 44908,
      "e": 25398,
      "ty": 7,
      "x": 926,
      "y": 675,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44925,
      "e": 25415,
      "ty": 6,
      "x": 925,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44987,
      "e": 25477,
      "ty": 3,
      "x": 925,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44988,
      "e": 25478,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 44989,
      "e": 25479,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44989,
      "e": 25479,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45004,
      "e": 25494,
      "ty": 2,
      "x": 925,
      "y": 676
    },
    {
      "t": 45004,
      "e": 25494,
      "ty": 41,
      "x": 14986,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45074,
      "e": 25564,
      "ty": 4,
      "x": 14986,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45074,
      "e": 25564,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45075,
      "e": 25565,
      "ty": 5,
      "x": 925,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 45075,
      "e": 25565,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 45255,
      "e": 25745,
      "ty": 41,
      "x": 31648,
      "y": 36894,
      "ta": "html > body"
    },
    {
      "t": 45304,
      "e": 25794,
      "ty": 2,
      "x": 928,
      "y": 674
    },
    {
      "t": 45504,
      "e": 25994,
      "ty": 41,
      "x": 31682,
      "y": 36894,
      "ta": "html > body"
    },
    {
      "t": 45704,
      "e": 26194,
      "ty": 2,
      "x": 906,
      "y": 667
    },
    {
      "t": 45755,
      "e": 26245,
      "ty": 41,
      "x": 30925,
      "y": 36506,
      "ta": "html > body"
    },
    {
      "t": 46099,
      "e": 26589,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 46605,
      "e": 27095,
      "ty": 2,
      "x": 895,
      "y": 631
    },
    {
      "t": 46704,
      "e": 27194,
      "ty": 2,
      "x": 895,
      "y": 620
    },
    {
      "t": 46754,
      "e": 27244,
      "ty": 41,
      "x": 17461,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 47005,
      "e": 27495,
      "ty": 2,
      "x": 895,
      "y": 617
    },
    {
      "t": 47005,
      "e": 27495,
      "ty": 41,
      "x": 17461,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 47104,
      "e": 27594,
      "ty": 2,
      "x": 896,
      "y": 606
    },
    {
      "t": 47204,
      "e": 27694,
      "ty": 2,
      "x": 824,
      "y": 420
    },
    {
      "t": 47254,
      "e": 27744,
      "ty": 41,
      "x": 27377,
      "y": 12630,
      "ta": "html > body"
    },
    {
      "t": 47304,
      "e": 27794,
      "ty": 2,
      "x": 804,
      "y": 183
    },
    {
      "t": 47405,
      "e": 27895,
      "ty": 2,
      "x": 808,
      "y": 178
    },
    {
      "t": 47504,
      "e": 27994,
      "ty": 2,
      "x": 799,
      "y": 181
    },
    {
      "t": 47504,
      "e": 27994,
      "ty": 41,
      "x": 27240,
      "y": 9583,
      "ta": "html > body"
    },
    {
      "t": 47605,
      "e": 28095,
      "ty": 2,
      "x": 781,
      "y": 151
    },
    {
      "t": 47704,
      "e": 28194,
      "ty": 2,
      "x": 809,
      "y": 178
    },
    {
      "t": 47755,
      "e": 28245,
      "ty": 41,
      "x": 5595,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 47804,
      "e": 28294,
      "ty": 2,
      "x": 855,
      "y": 212
    },
    {
      "t": 47905,
      "e": 28395,
      "ty": 2,
      "x": 856,
      "y": 221
    },
    {
      "t": 48005,
      "e": 28495,
      "ty": 2,
      "x": 847,
      "y": 227
    },
    {
      "t": 48005,
      "e": 28495,
      "ty": 41,
      "x": 6070,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 48104,
      "e": 28594,
      "ty": 2,
      "x": 839,
      "y": 230
    },
    {
      "t": 48255,
      "e": 28745,
      "ty": 41,
      "x": 14394,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 48363,
      "e": 28853,
      "ty": 3,
      "x": 839,
      "y": 230,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 48489,
      "e": 28979,
      "ty": 4,
      "x": 14394,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 48490,
      "e": 28980,
      "ty": 5,
      "x": 839,
      "y": 230,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 48490,
      "e": 28980,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 48491,
      "e": 28981,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 49004,
      "e": 29494,
      "ty": 2,
      "x": 839,
      "y": 231
    },
    {
      "t": 49004,
      "e": 29494,
      "ty": 41,
      "x": 14394,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 49013,
      "e": 29503,
      "ty": 6,
      "x": 839,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49063,
      "e": 29553,
      "ty": 7,
      "x": 840,
      "y": 248,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49104,
      "e": 29594,
      "ty": 2,
      "x": 841,
      "y": 250
    },
    {
      "t": 49254,
      "e": 29744,
      "ty": 41,
      "x": 4409,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 49304,
      "e": 29794,
      "ty": 2,
      "x": 840,
      "y": 251
    },
    {
      "t": 50004,
      "e": 30494,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 52003,
      "e": 32493,
      "ty": 2,
      "x": 839,
      "y": 251
    },
    {
      "t": 52004,
      "e": 32494,
      "ty": 41,
      "x": 4171,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 52032,
      "e": 32522,
      "ty": 6,
      "x": 839,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 52064,
      "e": 32554,
      "ty": 7,
      "x": 841,
      "y": 272,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 52104,
      "e": 32594,
      "ty": 2,
      "x": 841,
      "y": 282
    },
    {
      "t": 52203,
      "e": 32693,
      "ty": 2,
      "x": 841,
      "y": 303
    },
    {
      "t": 52253,
      "e": 32743,
      "ty": 41,
      "x": 6135,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 52668,
      "e": 33158,
      "ty": 3,
      "x": 841,
      "y": 303,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 52669,
      "e": 33159,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 52785,
      "e": 33275,
      "ty": 4,
      "x": 6135,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 52785,
      "e": 33275,
      "ty": 5,
      "x": 841,
      "y": 303,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 52786,
      "e": 33276,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 52786,
      "e": 33276,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 54903,
      "e": 35393,
      "ty": 2,
      "x": 841,
      "y": 313
    },
    {
      "t": 55004,
      "e": 35494,
      "ty": 2,
      "x": 836,
      "y": 357
    },
    {
      "t": 55004,
      "e": 35494,
      "ty": 41,
      "x": 3459,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 55083,
      "e": 35573,
      "ty": 6,
      "x": 833,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 55099,
      "e": 35589,
      "ty": 7,
      "x": 833,
      "y": 424,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 55103,
      "e": 35593,
      "ty": 2,
      "x": 833,
      "y": 424
    },
    {
      "t": 55150,
      "e": 35640,
      "ty": 6,
      "x": 831,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 55200,
      "e": 35690,
      "ty": 7,
      "x": 831,
      "y": 453,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 55203,
      "e": 35693,
      "ty": 2,
      "x": 831,
      "y": 453
    },
    {
      "t": 55253,
      "e": 35743,
      "ty": 41,
      "x": 12238,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 55290,
      "e": 35780,
      "ty": 6,
      "x": 833,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 55304,
      "e": 35794,
      "ty": 2,
      "x": 834,
      "y": 465
    },
    {
      "t": 55350,
      "e": 35840,
      "ty": 7,
      "x": 840,
      "y": 479,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 55404,
      "e": 35894,
      "ty": 2,
      "x": 841,
      "y": 480
    },
    {
      "t": 55504,
      "e": 35994,
      "ty": 41,
      "x": 20694,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 55604,
      "e": 36094,
      "ty": 2,
      "x": 841,
      "y": 477
    },
    {
      "t": 55704,
      "e": 36194,
      "ty": 2,
      "x": 840,
      "y": 475
    },
    {
      "t": 55714,
      "e": 36204,
      "ty": 3,
      "x": 840,
      "y": 475,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 55715,
      "e": 36205,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 55754,
      "e": 36244,
      "ty": 41,
      "x": 19637,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 55810,
      "e": 36300,
      "ty": 4,
      "x": 19637,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 55810,
      "e": 36300,
      "ty": 5,
      "x": 840,
      "y": 475,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 55810,
      "e": 36300,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 55810,
      "e": 36300,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 56810,
      "e": 37300,
      "ty": 6,
      "x": 839,
      "y": 474,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 56904,
      "e": 37394,
      "ty": 2,
      "x": 839,
      "y": 474
    },
    {
      "t": 57005,
      "e": 37495,
      "ty": 41,
      "x": 63408,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 58318,
      "e": 38808,
      "ty": 7,
      "x": 843,
      "y": 485,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 58403,
      "e": 38893,
      "ty": 2,
      "x": 881,
      "y": 599
    },
    {
      "t": 58504,
      "e": 38994,
      "ty": 2,
      "x": 897,
      "y": 669
    },
    {
      "t": 58504,
      "e": 38994,
      "ty": 41,
      "x": 20292,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 58603,
      "e": 39093,
      "ty": 2,
      "x": 888,
      "y": 695
    },
    {
      "t": 58704,
      "e": 39194,
      "ty": 2,
      "x": 887,
      "y": 701
    },
    {
      "t": 58754,
      "e": 39244,
      "ty": 41,
      "x": 16524,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 59204,
      "e": 39694,
      "ty": 2,
      "x": 865,
      "y": 724
    },
    {
      "t": 59254,
      "e": 39744,
      "ty": 41,
      "x": 2035,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 59304,
      "e": 39794,
      "ty": 2,
      "x": 826,
      "y": 747
    },
    {
      "t": 59504,
      "e": 39994,
      "ty": 41,
      "x": 1086,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 59604,
      "e": 40094,
      "ty": 2,
      "x": 828,
      "y": 747
    },
    {
      "t": 59754,
      "e": 40244,
      "ty": 41,
      "x": 1561,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 61474,
      "e": 41964,
      "ty": 6,
      "x": 837,
      "y": 736,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 61490,
      "e": 41980,
      "ty": 7,
      "x": 840,
      "y": 731,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 61504,
      "e": 41994,
      "ty": 2,
      "x": 841,
      "y": 730
    },
    {
      "t": 61504,
      "e": 41994,
      "ty": 41,
      "x": 4913,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 62003,
      "e": 42493,
      "ty": 6,
      "x": 839,
      "y": 729,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 62005,
      "e": 42495,
      "ty": 2,
      "x": 839,
      "y": 729
    },
    {
      "t": 62005,
      "e": 42495,
      "ty": 41,
      "x": 63408,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 62304,
      "e": 42794,
      "ty": 2,
      "x": 834,
      "y": 736
    },
    {
      "t": 62317,
      "e": 42807,
      "ty": 7,
      "x": 833,
      "y": 741,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 62404,
      "e": 42894,
      "ty": 2,
      "x": 832,
      "y": 747
    },
    {
      "t": 62504,
      "e": 42994,
      "ty": 41,
      "x": 2510,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 62555,
      "e": 43045,
      "ty": 6,
      "x": 832,
      "y": 754,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 62604,
      "e": 43094,
      "ty": 2,
      "x": 832,
      "y": 760
    },
    {
      "t": 62641,
      "e": 43131,
      "ty": 3,
      "x": 832,
      "y": 761,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 62642,
      "e": 43132,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 62642,
      "e": 43132,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 62704,
      "e": 43194,
      "ty": 2,
      "x": 832,
      "y": 761
    },
    {
      "t": 62729,
      "e": 43219,
      "ty": 4,
      "x": 28120,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 62729,
      "e": 43219,
      "ty": 5,
      "x": 832,
      "y": 761,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 62729,
      "e": 43219,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf",
      "v": "Natural Sciences"
    },
    {
      "t": 62754,
      "e": 43244,
      "ty": 41,
      "x": 28120,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 62857,
      "e": 43347,
      "ty": 7,
      "x": 848,
      "y": 759,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 62904,
      "e": 43394,
      "ty": 2,
      "x": 894,
      "y": 746
    },
    {
      "t": 63004,
      "e": 43494,
      "ty": 2,
      "x": 1026,
      "y": 732
    },
    {
      "t": 63005,
      "e": 43495,
      "ty": 41,
      "x": 51346,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 63104,
      "e": 43594,
      "ty": 2,
      "x": 1033,
      "y": 731
    },
    {
      "t": 63254,
      "e": 43744,
      "ty": 41,
      "x": 53103,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 63304,
      "e": 43794,
      "ty": 1,
      "x": 0,
      "y": 12
    },
    {
      "t": 63404,
      "e": 43894,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 63604,
      "e": 44094,
      "ty": 2,
      "x": 1024,
      "y": 787
    },
    {
      "t": 63704,
      "e": 44194,
      "ty": 2,
      "x": 952,
      "y": 904
    },
    {
      "t": 63754,
      "e": 44244,
      "ty": 41,
      "x": 23632,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 63804,
      "e": 44294,
      "ty": 2,
      "x": 908,
      "y": 938
    },
    {
      "t": 63904,
      "e": 44394,
      "ty": 2,
      "x": 890,
      "y": 933
    },
    {
      "t": 64004,
      "e": 44494,
      "ty": 2,
      "x": 872,
      "y": 956
    },
    {
      "t": 64004,
      "e": 44494,
      "ty": 41,
      "x": 40913,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 64103,
      "e": 44593,
      "ty": 2,
      "x": 869,
      "y": 960
    },
    {
      "t": 64129,
      "e": 44619,
      "ty": 3,
      "x": 869,
      "y": 960,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 64130,
      "e": 44620,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 64226,
      "e": 44716,
      "ty": 4,
      "x": 38486,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 64227,
      "e": 44717,
      "ty": 5,
      "x": 869,
      "y": 960,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 64228,
      "e": 44718,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64232,
      "e": 44722,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 64254,
      "e": 44744,
      "ty": 41,
      "x": 38486,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 64374,
      "e": 44864,
      "ty": 6,
      "x": 879,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64404,
      "e": 44894,
      "ty": 2,
      "x": 885,
      "y": 1025
    },
    {
      "t": 64423,
      "e": 44913,
      "ty": 7,
      "x": 885,
      "y": 1039,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64504,
      "e": 44994,
      "ty": 2,
      "x": 897,
      "y": 1059
    },
    {
      "t": 64504,
      "e": 44994,
      "ty": 41,
      "x": 30615,
      "y": 58222,
      "ta": "html > body"
    },
    {
      "t": 64605,
      "e": 45095,
      "ty": 2,
      "x": 898,
      "y": 1057
    },
    {
      "t": 64659,
      "e": 45149,
      "ty": 6,
      "x": 899,
      "y": 1036,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64704,
      "e": 45194,
      "ty": 2,
      "x": 899,
      "y": 1033
    },
    {
      "t": 64755,
      "e": 45245,
      "ty": 41,
      "x": 36375,
      "y": 47661,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64804,
      "e": 45294,
      "ty": 2,
      "x": 900,
      "y": 1029
    },
    {
      "t": 64810,
      "e": 45300,
      "ty": 3,
      "x": 900,
      "y": 1029,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64812,
      "e": 45302,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 64813,
      "e": 45303,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64931,
      "e": 45421,
      "ty": 4,
      "x": 36375,
      "y": 47661,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64931,
      "e": 45421,
      "ty": 5,
      "x": 900,
      "y": 1029,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64937,
      "e": 45427,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 64938,
      "e": 45428,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 64941,
      "e": 45431,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 65204,
      "e": 45694,
      "ty": 2,
      "x": 800,
      "y": 963
    },
    {
      "t": 65254,
      "e": 45744,
      "ty": 41,
      "x": 25724,
      "y": 50023,
      "ta": "html > body"
    },
    {
      "t": 65304,
      "e": 45794,
      "ty": 2,
      "x": 714,
      "y": 834
    },
    {
      "t": 65405,
      "e": 45895,
      "ty": 2,
      "x": 676,
      "y": 729
    },
    {
      "t": 65504,
      "e": 45994,
      "ty": 2,
      "x": 665,
      "y": 701
    },
    {
      "t": 65505,
      "e": 45995,
      "ty": 41,
      "x": 22625,
      "y": 38390,
      "ta": "html > body"
    },
    {
      "t": 66288,
      "e": 46778,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 70004,
      "e": 50494,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 71604,
      "e": 50995,
      "ty": 2,
      "x": 683,
      "y": 662
    },
    {
      "t": 71704,
      "e": 51095,
      "ty": 2,
      "x": 700,
      "y": 636
    },
    {
      "t": 71755,
      "e": 51146,
      "ty": 41,
      "x": 20000,
      "y": 59884,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 72005,
      "e": 51396,
      "ty": 2,
      "x": 700,
      "y": 635
    },
    {
      "t": 72005,
      "e": 51396,
      "ty": 41,
      "x": 20000,
      "y": 59494,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 80004,
      "e": 56396,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 94404,
      "e": 56396,
      "ty": 2,
      "x": 735,
      "y": 660
    },
    {
      "t": 94505,
      "e": 56497,
      "ty": 2,
      "x": 972,
      "y": 843
    },
    {
      "t": 94505,
      "e": 56497,
      "ty": 41,
      "x": 33382,
      "y": 52095,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 94604,
      "e": 56596,
      "ty": 2,
      "x": 1027,
      "y": 997
    },
    {
      "t": 94704,
      "e": 56696,
      "ty": 2,
      "x": 1025,
      "y": 1056
    },
    {
      "t": 94709,
      "e": 56701,
      "ty": 6,
      "x": 1025,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 94754,
      "e": 56746,
      "ty": 41,
      "x": 61439,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 94804,
      "e": 56796,
      "ty": 2,
      "x": 1021,
      "y": 1106
    },
    {
      "t": 94815,
      "e": 56807,
      "ty": 7,
      "x": 1021,
      "y": 1112,
      "ta": "#start"
    },
    {
      "t": 94904,
      "e": 56896,
      "ty": 2,
      "x": 1021,
      "y": 1115
    },
    {
      "t": 95005,
      "e": 56997,
      "ty": 2,
      "x": 1010,
      "y": 1108
    },
    {
      "t": 95005,
      "e": 56997,
      "ty": 41,
      "x": 56406,
      "y": 19562,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 95017,
      "e": 57009,
      "ty": 6,
      "x": 1008,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 95104,
      "e": 57096,
      "ty": 2,
      "x": 1005,
      "y": 1101
    },
    {
      "t": 95204,
      "e": 57196,
      "ty": 2,
      "x": 1005,
      "y": 1100
    },
    {
      "t": 95254,
      "e": 57246,
      "ty": 41,
      "x": 52154,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 96004,
      "e": 57996,
      "ty": 2,
      "x": 1002,
      "y": 1094
    },
    {
      "t": 96005,
      "e": 57997,
      "ty": 41,
      "x": 50516,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 96104,
      "e": 58096,
      "ty": 2,
      "x": 1000,
      "y": 1091
    },
    {
      "t": 96255,
      "e": 58247,
      "ty": 41,
      "x": 49424,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 97035,
      "e": 59027,
      "ty": 3,
      "x": 1000,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 97036,
      "e": 59028,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 97137,
      "e": 59129,
      "ty": 4,
      "x": 49424,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 97137,
      "e": 59129,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 97138,
      "e": 59130,
      "ty": 5,
      "x": 1000,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 97138,
      "e": 59130,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 98173,
      "e": 60165,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 99081,
      "e": 61073,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 61519, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 61525, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 17285, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 80161, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 6717, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"india\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 87886, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 14259, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 103233, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 7666, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 111902, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 12562, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 125896, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:565,y:320,t:1527026784539};\\\", \\\"{x:592,y:320,t:1527026784549};\\\", \\\"{x:659,y:331,t:1527026784566};\\\", \\\"{x:730,y:345,t:1527026784582};\\\", \\\"{x:803,y:372,t:1527026784599};\\\", \\\"{x:871,y:409,t:1527026784615};\\\", \\\"{x:936,y:455,t:1527026784632};\\\", \\\"{x:981,y:499,t:1527026784649};\\\", \\\"{x:1017,y:531,t:1527026784666};\\\", \\\"{x:1018,y:533,t:1527026784682};\\\", \\\"{x:1021,y:533,t:1527026786243};\\\", \\\"{x:1029,y:538,t:1527026786250};\\\", \\\"{x:1047,y:546,t:1527026786267};\\\", \\\"{x:1061,y:554,t:1527026786284};\\\", \\\"{x:1074,y:560,t:1527026786300};\\\", \\\"{x:1089,y:566,t:1527026786317};\\\", \\\"{x:1106,y:574,t:1527026786333};\\\", \\\"{x:1122,y:582,t:1527026786349};\\\", \\\"{x:1136,y:588,t:1527026786367};\\\", \\\"{x:1149,y:594,t:1527026786383};\\\", \\\"{x:1161,y:601,t:1527026786400};\\\", \\\"{x:1173,y:606,t:1527026786417};\\\", \\\"{x:1187,y:612,t:1527026786434};\\\", \\\"{x:1193,y:615,t:1527026786450};\\\", \\\"{x:1200,y:620,t:1527026786467};\\\", \\\"{x:1209,y:633,t:1527026786484};\\\", \\\"{x:1220,y:666,t:1527026786500};\\\", \\\"{x:1238,y:705,t:1527026786517};\\\", \\\"{x:1266,y:729,t:1527026786534};\\\", \\\"{x:1302,y:739,t:1527026786550};\\\", \\\"{x:1330,y:739,t:1527026786567};\\\", \\\"{x:1365,y:730,t:1527026786584};\\\", \\\"{x:1383,y:714,t:1527026786601};\\\", \\\"{x:1393,y:705,t:1527026786616};\\\", \\\"{x:1392,y:709,t:1527026786897};\\\", \\\"{x:1388,y:718,t:1527026786905};\\\", \\\"{x:1386,y:721,t:1527026786916};\\\", \\\"{x:1377,y:732,t:1527026786933};\\\", \\\"{x:1365,y:749,t:1527026786949};\\\", \\\"{x:1353,y:761,t:1527026786966};\\\", \\\"{x:1338,y:774,t:1527026786983};\\\", \\\"{x:1323,y:786,t:1527026787000};\\\", \\\"{x:1309,y:799,t:1527026787017};\\\", \\\"{x:1303,y:814,t:1527026787032};\\\", \\\"{x:1299,y:828,t:1527026787050};\\\", \\\"{x:1295,y:840,t:1527026787067};\\\", \\\"{x:1292,y:849,t:1527026787083};\\\", \\\"{x:1285,y:861,t:1527026787100};\\\", \\\"{x:1280,y:874,t:1527026787117};\\\", \\\"{x:1277,y:886,t:1527026787133};\\\", \\\"{x:1274,y:899,t:1527026787150};\\\", \\\"{x:1273,y:901,t:1527026787167};\\\", \\\"{x:1273,y:902,t:1527026787184};\\\", \\\"{x:1273,y:906,t:1527026787225};\\\", \\\"{x:1273,y:910,t:1527026787233};\\\", \\\"{x:1273,y:917,t:1527026787250};\\\", \\\"{x:1273,y:918,t:1527026787268};\\\", \\\"{x:1273,y:919,t:1527026787284};\\\", \\\"{x:1273,y:922,t:1527026787301};\\\", \\\"{x:1273,y:929,t:1527026787318};\\\", \\\"{x:1273,y:934,t:1527026787334};\\\", \\\"{x:1274,y:939,t:1527026787351};\\\", \\\"{x:1274,y:940,t:1527026787368};\\\", \\\"{x:1274,y:942,t:1527026787384};\\\", \\\"{x:1274,y:938,t:1527026790202};\\\", \\\"{x:1281,y:913,t:1527026790220};\\\", \\\"{x:1287,y:893,t:1527026790236};\\\", \\\"{x:1288,y:878,t:1527026790253};\\\", \\\"{x:1290,y:869,t:1527026790270};\\\", \\\"{x:1291,y:863,t:1527026790286};\\\", \\\"{x:1292,y:859,t:1527026790304};\\\", \\\"{x:1292,y:856,t:1527026790320};\\\", \\\"{x:1292,y:854,t:1527026790338};\\\", \\\"{x:1292,y:853,t:1527026790356};\\\", \\\"{x:1292,y:851,t:1527026790369};\\\", \\\"{x:1292,y:850,t:1527026790385};\\\", \\\"{x:1292,y:848,t:1527026790538};\\\", \\\"{x:1292,y:845,t:1527026790553};\\\", \\\"{x:1292,y:840,t:1527026790570};\\\", \\\"{x:1292,y:839,t:1527026790586};\\\", \\\"{x:1292,y:837,t:1527026790602};\\\", \\\"{x:1291,y:836,t:1527026790779};\\\", \\\"{x:1290,y:835,t:1527026790787};\\\", \\\"{x:1286,y:834,t:1527026790803};\\\", \\\"{x:1285,y:833,t:1527026790826};\\\", \\\"{x:1284,y:833,t:1527026790853};\\\", \\\"{x:1283,y:833,t:1527026790937};\\\", \\\"{x:1276,y:833,t:1527026790954};\\\", \\\"{x:1257,y:833,t:1527026790971};\\\", \\\"{x:1223,y:833,t:1527026790986};\\\", \\\"{x:1134,y:833,t:1527026791003};\\\", \\\"{x:1053,y:831,t:1527026791019};\\\", \\\"{x:1051,y:831,t:1527026791036};\\\", \\\"{x:1044,y:827,t:1527026791283};\\\", \\\"{x:1011,y:811,t:1527026791290};\\\", \\\"{x:975,y:786,t:1527026791305};\\\", \\\"{x:896,y:744,t:1527026791320};\\\", \\\"{x:855,y:711,t:1527026791337};\\\", \\\"{x:849,y:699,t:1527026791354};\\\", \\\"{x:851,y:693,t:1527026791370};\\\", \\\"{x:856,y:689,t:1527026791387};\\\", \\\"{x:861,y:686,t:1527026791404};\\\", \\\"{x:867,y:682,t:1527026791421};\\\", \\\"{x:877,y:678,t:1527026791437};\\\", \\\"{x:882,y:675,t:1527026791454};\\\", \\\"{x:882,y:674,t:1527026791471};\\\", \\\"{x:878,y:667,t:1527026791487};\\\", \\\"{x:854,y:652,t:1527026791504};\\\", \\\"{x:814,y:634,t:1527026791520};\\\", \\\"{x:725,y:607,t:1527026791539};\\\", \\\"{x:528,y:530,t:1527026791554};\\\", \\\"{x:416,y:486,t:1527026791570};\\\", \\\"{x:315,y:455,t:1527026791604};\\\", \\\"{x:296,y:448,t:1527026791622};\\\", \\\"{x:294,y:447,t:1527026791637};\\\", \\\"{x:296,y:447,t:1527026791729};\\\", \\\"{x:298,y:451,t:1527026791737};\\\", \\\"{x:304,y:459,t:1527026791754};\\\", \\\"{x:310,y:467,t:1527026791771};\\\", \\\"{x:317,y:475,t:1527026791787};\\\", \\\"{x:327,y:483,t:1527026791804};\\\", \\\"{x:339,y:491,t:1527026791821};\\\", \\\"{x:347,y:495,t:1527026791837};\\\", \\\"{x:351,y:497,t:1527026791855};\\\", \\\"{x:353,y:498,t:1527026791871};\\\", \\\"{x:355,y:499,t:1527026791888};\\\", \\\"{x:356,y:499,t:1527026791905};\\\", \\\"{x:358,y:500,t:1527026791922};\\\", \\\"{x:361,y:501,t:1527026791939};\\\", \\\"{x:365,y:505,t:1527026791955};\\\", \\\"{x:371,y:507,t:1527026791976};\\\", \\\"{x:372,y:508,t:1527026791992};\\\", \\\"{x:372,y:509,t:1527026792008};\\\", \\\"{x:373,y:510,t:1527026792022};\\\", \\\"{x:375,y:513,t:1527026792038};\\\", \\\"{x:375,y:514,t:1527026792169};\\\", \\\"{x:375,y:515,t:1527026792209};\\\", \\\"{x:378,y:521,t:1527026792689};\\\", \\\"{x:383,y:538,t:1527026792705};\\\", \\\"{x:386,y:554,t:1527026792722};\\\", \\\"{x:395,y:575,t:1527026792739};\\\", \\\"{x:405,y:593,t:1527026792756};\\\", \\\"{x:417,y:609,t:1527026792772};\\\", \\\"{x:431,y:632,t:1527026792790};\\\", \\\"{x:448,y:655,t:1527026792806};\\\", \\\"{x:460,y:676,t:1527026792822};\\\", \\\"{x:468,y:688,t:1527026792838};\\\", \\\"{x:470,y:692,t:1527026792855};\\\", \\\"{x:471,y:692,t:1527026792871};\\\", \\\"{x:472,y:693,t:1527026793058};\\\", \\\"{x:476,y:695,t:1527026793072};\\\", \\\"{x:481,y:704,t:1527026793091};\\\", \\\"{x:485,y:710,t:1527026793104};\\\", \\\"{x:488,y:716,t:1527026793122};\\\", \\\"{x:489,y:717,t:1527026793138};\\\", \\\"{x:490,y:719,t:1527026793155};\\\" ] }, { \\\"rt\\\": 11298, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 138571, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -D -D -E -04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:719,t:1527026797210};\\\", \\\"{x:556,y:716,t:1527026797226};\\\", \\\"{x:574,y:715,t:1527026797243};\\\", \\\"{x:575,y:715,t:1527026797634};\\\", \\\"{x:580,y:714,t:1527026797643};\\\", \\\"{x:591,y:705,t:1527026797658};\\\", \\\"{x:602,y:692,t:1527026797675};\\\", \\\"{x:613,y:676,t:1527026797692};\\\", \\\"{x:622,y:658,t:1527026797709};\\\", \\\"{x:628,y:632,t:1527026797726};\\\", \\\"{x:630,y:599,t:1527026797743};\\\", \\\"{x:630,y:570,t:1527026797760};\\\", \\\"{x:626,y:555,t:1527026797776};\\\", \\\"{x:600,y:505,t:1527026797793};\\\", \\\"{x:577,y:479,t:1527026797808};\\\", \\\"{x:560,y:469,t:1527026797825};\\\", \\\"{x:546,y:463,t:1527026797842};\\\", \\\"{x:537,y:459,t:1527026797860};\\\", \\\"{x:536,y:458,t:1527026797875};\\\", \\\"{x:535,y:458,t:1527026797897};\\\", \\\"{x:534,y:458,t:1527026798018};\\\", \\\"{x:532,y:458,t:1527026798025};\\\", \\\"{x:525,y:462,t:1527026798044};\\\", \\\"{x:519,y:465,t:1527026798060};\\\", \\\"{x:510,y:468,t:1527026798076};\\\", \\\"{x:498,y:469,t:1527026798093};\\\", \\\"{x:482,y:471,t:1527026798110};\\\", \\\"{x:473,y:472,t:1527026798126};\\\", \\\"{x:467,y:473,t:1527026798143};\\\", \\\"{x:465,y:473,t:1527026798160};\\\", \\\"{x:464,y:474,t:1527026798176};\\\", \\\"{x:462,y:475,t:1527026798193};\\\", \\\"{x:459,y:476,t:1527026798209};\\\", \\\"{x:458,y:476,t:1527026798226};\\\", \\\"{x:456,y:477,t:1527026798242};\\\", \\\"{x:455,y:478,t:1527026798260};\\\", \\\"{x:453,y:478,t:1527026798276};\\\", \\\"{x:452,y:478,t:1527026798293};\\\", \\\"{x:452,y:479,t:1527026798489};\\\", \\\"{x:453,y:479,t:1527026798498};\\\", \\\"{x:458,y:479,t:1527026798510};\\\", \\\"{x:479,y:478,t:1527026798527};\\\", \\\"{x:508,y:478,t:1527026798543};\\\", \\\"{x:542,y:478,t:1527026798559};\\\", \\\"{x:578,y:471,t:1527026798577};\\\", \\\"{x:592,y:468,t:1527026798592};\\\", \\\"{x:605,y:464,t:1527026798609};\\\", \\\"{x:616,y:463,t:1527026798626};\\\", \\\"{x:626,y:462,t:1527026798643};\\\", \\\"{x:635,y:461,t:1527026798660};\\\", \\\"{x:640,y:461,t:1527026798676};\\\", \\\"{x:642,y:461,t:1527026798693};\\\", \\\"{x:653,y:461,t:1527026798709};\\\", \\\"{x:665,y:461,t:1527026798727};\\\", \\\"{x:678,y:461,t:1527026798744};\\\", \\\"{x:688,y:461,t:1527026798760};\\\", \\\"{x:696,y:461,t:1527026798777};\\\", \\\"{x:699,y:461,t:1527026798792};\\\", \\\"{x:701,y:461,t:1527026798810};\\\", \\\"{x:702,y:461,t:1527026798827};\\\", \\\"{x:702,y:461,t:1527026798907};\\\", \\\"{x:703,y:462,t:1527026799330};\\\", \\\"{x:711,y:471,t:1527026799344};\\\", \\\"{x:770,y:523,t:1527026799363};\\\", \\\"{x:819,y:566,t:1527026799378};\\\", \\\"{x:901,y:612,t:1527026799393};\\\", \\\"{x:964,y:648,t:1527026799410};\\\", \\\"{x:1010,y:674,t:1527026799427};\\\", \\\"{x:1028,y:685,t:1527026799444};\\\", \\\"{x:1041,y:693,t:1527026799460};\\\", \\\"{x:1052,y:702,t:1527026799477};\\\", \\\"{x:1060,y:712,t:1527026799494};\\\", \\\"{x:1072,y:731,t:1527026799510};\\\", \\\"{x:1083,y:751,t:1527026799528};\\\", \\\"{x:1093,y:768,t:1527026799543};\\\", \\\"{x:1110,y:798,t:1527026799561};\\\", \\\"{x:1124,y:820,t:1527026799577};\\\", \\\"{x:1138,y:840,t:1527026799594};\\\", \\\"{x:1150,y:858,t:1527026799611};\\\", \\\"{x:1165,y:874,t:1527026799628};\\\", \\\"{x:1177,y:891,t:1527026799645};\\\", \\\"{x:1195,y:909,t:1527026799661};\\\", \\\"{x:1209,y:922,t:1527026799678};\\\", \\\"{x:1219,y:929,t:1527026799695};\\\", \\\"{x:1222,y:930,t:1527026799711};\\\", \\\"{x:1225,y:932,t:1527026799729};\\\", \\\"{x:1231,y:937,t:1527026799745};\\\", \\\"{x:1238,y:943,t:1527026799762};\\\", \\\"{x:1242,y:946,t:1527026799778};\\\", \\\"{x:1244,y:947,t:1527026799795};\\\", \\\"{x:1245,y:947,t:1527026799826};\\\", \\\"{x:1247,y:948,t:1527026799858};\\\", \\\"{x:1248,y:950,t:1527026799970};\\\", \\\"{x:1249,y:950,t:1527026799979};\\\", \\\"{x:1249,y:951,t:1527026799995};\\\", \\\"{x:1250,y:953,t:1527026800013};\\\", \\\"{x:1251,y:953,t:1527026800058};\\\", \\\"{x:1253,y:955,t:1527026800066};\\\", \\\"{x:1254,y:955,t:1527026800080};\\\", \\\"{x:1264,y:955,t:1527026800096};\\\", \\\"{x:1280,y:955,t:1527026800112};\\\", \\\"{x:1314,y:955,t:1527026800129};\\\", \\\"{x:1340,y:955,t:1527026800146};\\\", \\\"{x:1362,y:955,t:1527026800162};\\\", \\\"{x:1379,y:955,t:1527026800179};\\\", \\\"{x:1394,y:955,t:1527026800197};\\\", \\\"{x:1410,y:956,t:1527026800214};\\\", \\\"{x:1415,y:956,t:1527026800229};\\\", \\\"{x:1418,y:956,t:1527026800246};\\\", \\\"{x:1420,y:957,t:1527026800264};\\\", \\\"{x:1422,y:957,t:1527026800298};\\\", \\\"{x:1425,y:957,t:1527026800314};\\\", \\\"{x:1430,y:957,t:1527026800330};\\\", \\\"{x:1433,y:957,t:1527026800346};\\\", \\\"{x:1436,y:954,t:1527026800363};\\\", \\\"{x:1437,y:952,t:1527026800381};\\\", \\\"{x:1438,y:949,t:1527026800396};\\\", \\\"{x:1438,y:941,t:1527026800413};\\\", \\\"{x:1438,y:926,t:1527026800431};\\\", \\\"{x:1438,y:909,t:1527026800446};\\\", \\\"{x:1441,y:883,t:1527026800463};\\\", \\\"{x:1441,y:854,t:1527026800480};\\\", \\\"{x:1429,y:814,t:1527026800498};\\\", \\\"{x:1422,y:798,t:1527026800513};\\\", \\\"{x:1414,y:784,t:1527026800530};\\\", \\\"{x:1407,y:771,t:1527026800548};\\\", \\\"{x:1400,y:763,t:1527026800564};\\\", \\\"{x:1394,y:759,t:1527026800580};\\\", \\\"{x:1387,y:754,t:1527026800597};\\\", \\\"{x:1376,y:745,t:1527026800613};\\\", \\\"{x:1365,y:738,t:1527026800631};\\\", \\\"{x:1362,y:735,t:1527026800647};\\\", \\\"{x:1360,y:733,t:1527026800663};\\\", \\\"{x:1359,y:731,t:1527026800680};\\\", \\\"{x:1357,y:724,t:1527026800697};\\\", \\\"{x:1357,y:718,t:1527026800714};\\\", \\\"{x:1357,y:705,t:1527026800730};\\\", \\\"{x:1357,y:684,t:1527026800746};\\\", \\\"{x:1359,y:667,t:1527026800763};\\\", \\\"{x:1361,y:659,t:1527026800780};\\\", \\\"{x:1365,y:651,t:1527026800797};\\\", \\\"{x:1366,y:646,t:1527026800814};\\\", \\\"{x:1369,y:641,t:1527026800830};\\\", \\\"{x:1373,y:621,t:1527026800847};\\\", \\\"{x:1374,y:607,t:1527026800864};\\\", \\\"{x:1378,y:595,t:1527026800882};\\\", \\\"{x:1383,y:582,t:1527026800897};\\\", \\\"{x:1393,y:563,t:1527026800915};\\\", \\\"{x:1407,y:535,t:1527026800931};\\\", \\\"{x:1421,y:504,t:1527026800948};\\\", \\\"{x:1430,y:484,t:1527026800964};\\\", \\\"{x:1431,y:481,t:1527026800981};\\\", \\\"{x:1431,y:480,t:1527026801114};\\\", \\\"{x:1432,y:475,t:1527026801355};\\\", \\\"{x:1436,y:465,t:1527026801365};\\\", \\\"{x:1438,y:439,t:1527026801383};\\\", \\\"{x:1442,y:406,t:1527026801400};\\\", \\\"{x:1451,y:350,t:1527026801415};\\\", \\\"{x:1479,y:255,t:1527026801434};\\\", \\\"{x:1483,y:242,t:1527026801449};\\\", \\\"{x:1484,y:237,t:1527026801465};\\\", \\\"{x:1485,y:236,t:1527026801483};\\\", \\\"{x:1485,y:243,t:1527026801602};\\\", \\\"{x:1485,y:255,t:1527026801616};\\\", \\\"{x:1478,y:289,t:1527026801634};\\\", \\\"{x:1474,y:316,t:1527026801649};\\\", \\\"{x:1474,y:343,t:1527026801665};\\\", \\\"{x:1474,y:360,t:1527026801683};\\\", \\\"{x:1475,y:369,t:1527026801700};\\\", \\\"{x:1477,y:378,t:1527026801716};\\\", \\\"{x:1479,y:387,t:1527026801733};\\\", \\\"{x:1486,y:405,t:1527026801748};\\\", \\\"{x:1496,y:428,t:1527026801766};\\\", \\\"{x:1509,y:448,t:1527026801783};\\\", \\\"{x:1521,y:465,t:1527026801800};\\\", \\\"{x:1532,y:476,t:1527026801815};\\\", \\\"{x:1551,y:483,t:1527026801833};\\\", \\\"{x:1562,y:483,t:1527026801849};\\\", \\\"{x:1575,y:483,t:1527026801866};\\\", \\\"{x:1589,y:481,t:1527026801883};\\\", \\\"{x:1601,y:474,t:1527026801900};\\\", \\\"{x:1609,y:464,t:1527026801916};\\\", \\\"{x:1615,y:451,t:1527026801933};\\\", \\\"{x:1618,y:444,t:1527026801950};\\\", \\\"{x:1619,y:441,t:1527026801967};\\\", \\\"{x:1620,y:438,t:1527026801983};\\\", \\\"{x:1620,y:436,t:1527026802000};\\\", \\\"{x:1620,y:435,t:1527026802017};\\\", \\\"{x:1620,y:433,t:1527026802034};\\\", \\\"{x:1620,y:429,t:1527026802052};\\\", \\\"{x:1620,y:426,t:1527026802067};\\\", \\\"{x:1620,y:425,t:1527026802084};\\\", \\\"{x:1620,y:429,t:1527026802258};\\\", \\\"{x:1620,y:435,t:1527026802268};\\\", \\\"{x:1620,y:442,t:1527026802284};\\\", \\\"{x:1618,y:452,t:1527026802302};\\\", \\\"{x:1615,y:463,t:1527026802317};\\\", \\\"{x:1613,y:474,t:1527026802335};\\\", \\\"{x:1613,y:481,t:1527026802352};\\\", \\\"{x:1612,y:485,t:1527026802367};\\\", \\\"{x:1612,y:489,t:1527026802385};\\\", \\\"{x:1612,y:497,t:1527026802401};\\\", \\\"{x:1611,y:502,t:1527026802417};\\\", \\\"{x:1609,y:510,t:1527026802434};\\\", \\\"{x:1609,y:518,t:1527026802451};\\\", \\\"{x:1609,y:531,t:1527026802468};\\\", \\\"{x:1609,y:543,t:1527026802485};\\\", \\\"{x:1609,y:553,t:1527026802502};\\\", \\\"{x:1610,y:559,t:1527026802518};\\\", \\\"{x:1610,y:563,t:1527026802535};\\\", \\\"{x:1610,y:566,t:1527026802551};\\\", \\\"{x:1614,y:574,t:1527026802569};\\\", \\\"{x:1620,y:591,t:1527026802586};\\\", \\\"{x:1624,y:600,t:1527026802601};\\\", \\\"{x:1624,y:604,t:1527026802618};\\\", \\\"{x:1624,y:606,t:1527026802635};\\\", \\\"{x:1624,y:612,t:1527026802652};\\\", \\\"{x:1627,y:625,t:1527026802669};\\\", \\\"{x:1629,y:640,t:1527026802686};\\\", \\\"{x:1629,y:655,t:1527026802702};\\\", \\\"{x:1629,y:665,t:1527026802719};\\\", \\\"{x:1629,y:672,t:1527026802735};\\\", \\\"{x:1629,y:682,t:1527026802752};\\\", \\\"{x:1629,y:696,t:1527026802769};\\\", \\\"{x:1629,y:712,t:1527026802786};\\\", \\\"{x:1629,y:715,t:1527026802802};\\\", \\\"{x:1629,y:718,t:1527026802819};\\\", \\\"{x:1629,y:724,t:1527026802836};\\\", \\\"{x:1629,y:734,t:1527026802852};\\\", \\\"{x:1629,y:749,t:1527026802870};\\\", \\\"{x:1627,y:763,t:1527026802886};\\\", \\\"{x:1625,y:771,t:1527026802903};\\\", \\\"{x:1622,y:779,t:1527026802919};\\\", \\\"{x:1620,y:786,t:1527026802935};\\\", \\\"{x:1618,y:795,t:1527026802952};\\\", \\\"{x:1618,y:803,t:1527026802970};\\\", \\\"{x:1618,y:805,t:1527026802985};\\\", \\\"{x:1618,y:806,t:1527026803002};\\\", \\\"{x:1618,y:810,t:1527026803019};\\\", \\\"{x:1617,y:817,t:1527026803036};\\\", \\\"{x:1614,y:829,t:1527026803052};\\\", \\\"{x:1613,y:842,t:1527026803069};\\\", \\\"{x:1612,y:852,t:1527026803085};\\\", \\\"{x:1612,y:865,t:1527026803103};\\\", \\\"{x:1612,y:888,t:1527026803118};\\\", \\\"{x:1612,y:910,t:1527026803136};\\\", \\\"{x:1611,y:927,t:1527026803153};\\\", \\\"{x:1609,y:932,t:1527026803168};\\\", \\\"{x:1609,y:936,t:1527026803186};\\\", \\\"{x:1609,y:941,t:1527026803203};\\\", \\\"{x:1609,y:946,t:1527026803219};\\\", \\\"{x:1609,y:947,t:1527026803236};\\\", \\\"{x:1609,y:949,t:1527026803253};\\\", \\\"{x:1609,y:950,t:1527026803270};\\\", \\\"{x:1609,y:953,t:1527026803286};\\\", \\\"{x:1609,y:954,t:1527026803304};\\\", \\\"{x:1609,y:956,t:1527026803320};\\\", \\\"{x:1609,y:958,t:1527026803336};\\\", \\\"{x:1610,y:966,t:1527026803353};\\\", \\\"{x:1610,y:972,t:1527026803371};\\\", \\\"{x:1610,y:977,t:1527026803387};\\\", \\\"{x:1610,y:981,t:1527026803403};\\\", \\\"{x:1610,y:984,t:1527026803421};\\\", \\\"{x:1610,y:990,t:1527026803438};\\\", \\\"{x:1610,y:1005,t:1527026803454};\\\", \\\"{x:1593,y:1032,t:1527026803471};\\\", \\\"{x:1558,y:1058,t:1527026803488};\\\", \\\"{x:1488,y:1082,t:1527026803503};\\\", \\\"{x:1402,y:1103,t:1527026803520};\\\", \\\"{x:1240,y:1119,t:1527026803537};\\\", \\\"{x:1132,y:1117,t:1527026803554};\\\", \\\"{x:1047,y:1112,t:1527026803571};\\\", \\\"{x:1043,y:1111,t:1527026803587};\\\", \\\"{x:1041,y:1107,t:1527026803898};\\\", \\\"{x:1034,y:1095,t:1527026803905};\\\", \\\"{x:991,y:1037,t:1527026803922};\\\", \\\"{x:938,y:939,t:1527026803938};\\\", \\\"{x:898,y:814,t:1527026803954};\\\", \\\"{x:867,y:700,t:1527026803972};\\\", \\\"{x:862,y:680,t:1527026803988};\\\", \\\"{x:861,y:665,t:1527026804006};\\\", \\\"{x:855,y:649,t:1527026804021};\\\", \\\"{x:849,y:635,t:1527026804038};\\\", \\\"{x:843,y:626,t:1527026804055};\\\", \\\"{x:842,y:624,t:1527026804072};\\\", \\\"{x:841,y:623,t:1527026804106};\\\", \\\"{x:833,y:620,t:1527026804121};\\\", \\\"{x:818,y:620,t:1527026804139};\\\", \\\"{x:799,y:620,t:1527026804155};\\\", \\\"{x:782,y:620,t:1527026804172};\\\", \\\"{x:766,y:620,t:1527026804188};\\\", \\\"{x:757,y:616,t:1527026804205};\\\", \\\"{x:755,y:614,t:1527026804223};\\\", \\\"{x:755,y:608,t:1527026804239};\\\", \\\"{x:760,y:598,t:1527026804254};\\\", \\\"{x:772,y:582,t:1527026804265};\\\", \\\"{x:790,y:573,t:1527026804282};\\\", \\\"{x:815,y:570,t:1527026804297};\\\", \\\"{x:836,y:570,t:1527026804313};\\\", \\\"{x:849,y:568,t:1527026804331};\\\", \\\"{x:850,y:567,t:1527026804347};\\\", \\\"{x:850,y:566,t:1527026804384};\\\", \\\"{x:847,y:564,t:1527026804401};\\\", \\\"{x:841,y:562,t:1527026804415};\\\", \\\"{x:812,y:561,t:1527026804431};\\\", \\\"{x:730,y:558,t:1527026804448};\\\", \\\"{x:549,y:547,t:1527026804465};\\\", \\\"{x:437,y:548,t:1527026804481};\\\", \\\"{x:351,y:562,t:1527026804498};\\\", \\\"{x:305,y:568,t:1527026804514};\\\", \\\"{x:302,y:568,t:1527026804531};\\\", \\\"{x:297,y:567,t:1527026804547};\\\", \\\"{x:293,y:567,t:1527026804564};\\\", \\\"{x:292,y:567,t:1527026804593};\\\", \\\"{x:293,y:567,t:1527026804601};\\\", \\\"{x:295,y:568,t:1527026804614};\\\", \\\"{x:304,y:571,t:1527026804631};\\\", \\\"{x:307,y:572,t:1527026804648};\\\", \\\"{x:315,y:575,t:1527026804666};\\\", \\\"{x:325,y:580,t:1527026804680};\\\", \\\"{x:338,y:581,t:1527026804698};\\\", \\\"{x:355,y:583,t:1527026804715};\\\", \\\"{x:365,y:584,t:1527026804730};\\\", \\\"{x:366,y:585,t:1527026804748};\\\", \\\"{x:368,y:586,t:1527026804765};\\\", \\\"{x:368,y:587,t:1527026804930};\\\", \\\"{x:368,y:588,t:1527026804937};\\\", \\\"{x:366,y:591,t:1527026804948};\\\", \\\"{x:359,y:593,t:1527026804966};\\\", \\\"{x:341,y:593,t:1527026804982};\\\", \\\"{x:326,y:593,t:1527026804998};\\\", \\\"{x:312,y:592,t:1527026805015};\\\", \\\"{x:294,y:586,t:1527026805032};\\\", \\\"{x:276,y:581,t:1527026805050};\\\", \\\"{x:255,y:577,t:1527026805065};\\\", \\\"{x:240,y:575,t:1527026805082};\\\", \\\"{x:236,y:574,t:1527026805099};\\\", \\\"{x:235,y:574,t:1527026805115};\\\", \\\"{x:233,y:574,t:1527026805185};\\\", \\\"{x:231,y:574,t:1527026805197};\\\", \\\"{x:226,y:574,t:1527026805214};\\\", \\\"{x:216,y:578,t:1527026805233};\\\", \\\"{x:213,y:580,t:1527026805248};\\\", \\\"{x:201,y:581,t:1527026805264};\\\", \\\"{x:187,y:581,t:1527026805281};\\\", \\\"{x:172,y:584,t:1527026805299};\\\", \\\"{x:162,y:591,t:1527026805314};\\\", \\\"{x:154,y:604,t:1527026805332};\\\", \\\"{x:149,y:628,t:1527026805350};\\\", \\\"{x:148,y:637,t:1527026805364};\\\", \\\"{x:148,y:639,t:1527026805382};\\\", \\\"{x:149,y:639,t:1527026805817};\\\", \\\"{x:156,y:643,t:1527026805833};\\\", \\\"{x:176,y:649,t:1527026805849};\\\", \\\"{x:229,y:661,t:1527026805866};\\\", \\\"{x:277,y:677,t:1527026805882};\\\", \\\"{x:302,y:682,t:1527026805898};\\\", \\\"{x:325,y:688,t:1527026805915};\\\", \\\"{x:354,y:694,t:1527026805932};\\\", \\\"{x:374,y:698,t:1527026805948};\\\", \\\"{x:380,y:699,t:1527026805966};\\\", \\\"{x:373,y:699,t:1527026806002};\\\", \\\"{x:362,y:694,t:1527026806016};\\\", \\\"{x:330,y:679,t:1527026806032};\\\", \\\"{x:272,y:652,t:1527026806050};\\\", \\\"{x:254,y:647,t:1527026806067};\\\", \\\"{x:246,y:645,t:1527026806081};\\\", \\\"{x:238,y:644,t:1527026806098};\\\", \\\"{x:233,y:644,t:1527026806116};\\\", \\\"{x:227,y:643,t:1527026806132};\\\", \\\"{x:226,y:643,t:1527026806148};\\\", \\\"{x:224,y:643,t:1527026806185};\\\", \\\"{x:222,y:643,t:1527026806201};\\\", \\\"{x:220,y:643,t:1527026806215};\\\", \\\"{x:206,y:643,t:1527026806233};\\\", \\\"{x:199,y:643,t:1527026806249};\\\", \\\"{x:198,y:643,t:1527026806266};\\\", \\\"{x:196,y:643,t:1527026806283};\\\", \\\"{x:189,y:642,t:1527026806300};\\\", \\\"{x:173,y:640,t:1527026806316};\\\", \\\"{x:161,y:640,t:1527026806333};\\\", \\\"{x:158,y:640,t:1527026806348};\\\", \\\"{x:159,y:640,t:1527026806555};\\\", \\\"{x:163,y:640,t:1527026806566};\\\", \\\"{x:168,y:641,t:1527026806583};\\\", \\\"{x:170,y:641,t:1527026806600};\\\", \\\"{x:171,y:642,t:1527026806616};\\\", \\\"{x:173,y:643,t:1527026806672};\\\", \\\"{x:179,y:644,t:1527026806683};\\\", \\\"{x:199,y:651,t:1527026806700};\\\", \\\"{x:215,y:655,t:1527026806716};\\\", \\\"{x:223,y:656,t:1527026806733};\\\", \\\"{x:233,y:658,t:1527026806749};\\\", \\\"{x:263,y:666,t:1527026806766};\\\", \\\"{x:317,y:684,t:1527026806783};\\\", \\\"{x:411,y:711,t:1527026806800};\\\", \\\"{x:496,y:732,t:1527026806816};\\\", \\\"{x:540,y:737,t:1527026806833};\\\", \\\"{x:543,y:737,t:1527026806850};\\\", \\\"{x:541,y:737,t:1527026806914};\\\", \\\"{x:538,y:737,t:1527026807018};\\\", \\\"{x:533,y:735,t:1527026807034};\\\", \\\"{x:532,y:735,t:1527026807050};\\\", \\\"{x:530,y:734,t:1527026807067};\\\", \\\"{x:529,y:733,t:1527026807138};\\\", \\\"{x:529,y:730,t:1527026807267};\\\", \\\"{x:531,y:720,t:1527026807283};\\\", \\\"{x:537,y:707,t:1527026807299};\\\", \\\"{x:544,y:698,t:1527026807317};\\\", \\\"{x:545,y:696,t:1527026807334};\\\", \\\"{x:545,y:697,t:1527026807633};\\\", \\\"{x:544,y:698,t:1527026807657};\\\", \\\"{x:544,y:699,t:1527026807761};\\\", \\\"{x:544,y:700,t:1527026807777};\\\", \\\"{x:542,y:701,t:1527026807785};\\\", \\\"{x:541,y:701,t:1527026807801};\\\", \\\"{x:540,y:702,t:1527026807817};\\\", \\\"{x:539,y:703,t:1527026807835};\\\", \\\"{x:538,y:703,t:1527026807852};\\\", \\\"{x:536,y:704,t:1527026807867};\\\", \\\"{x:535,y:705,t:1527026807884};\\\", \\\"{x:535,y:706,t:1527026807902};\\\", \\\"{x:533,y:706,t:1527026807929};\\\", \\\"{x:535,y:706,t:1527026808098};\\\", \\\"{x:539,y:704,t:1527026808105};\\\", \\\"{x:542,y:702,t:1527026808118};\\\", \\\"{x:549,y:699,t:1527026808134};\\\", \\\"{x:558,y:692,t:1527026808151};\\\", \\\"{x:566,y:686,t:1527026808168};\\\", \\\"{x:567,y:686,t:1527026808184};\\\" ] }, { \\\"rt\\\": 10614, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 150562, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:567,y:685,t:1527026809338};\\\", \\\"{x:567,y:684,t:1527026809353};\\\", \\\"{x:544,y:644,t:1527026809371};\\\", \\\"{x:507,y:592,t:1527026809387};\\\", \\\"{x:493,y:567,t:1527026809404};\\\", \\\"{x:486,y:546,t:1527026809418};\\\", \\\"{x:485,y:529,t:1527026809437};\\\", \\\"{x:485,y:511,t:1527026809452};\\\", \\\"{x:489,y:495,t:1527026809469};\\\", \\\"{x:498,y:481,t:1527026809485};\\\", \\\"{x:509,y:471,t:1527026809502};\\\", \\\"{x:521,y:465,t:1527026809518};\\\", \\\"{x:526,y:462,t:1527026809535};\\\", \\\"{x:535,y:462,t:1527026809551};\\\", \\\"{x:544,y:462,t:1527026809568};\\\", \\\"{x:562,y:462,t:1527026809585};\\\", \\\"{x:571,y:462,t:1527026809602};\\\", \\\"{x:574,y:462,t:1527026809618};\\\", \\\"{x:575,y:462,t:1527026809635};\\\", \\\"{x:576,y:462,t:1527026809653};\\\", \\\"{x:582,y:462,t:1527026810137};\\\", \\\"{x:602,y:462,t:1527026810153};\\\", \\\"{x:639,y:462,t:1527026810169};\\\", \\\"{x:721,y:465,t:1527026810186};\\\", \\\"{x:778,y:467,t:1527026810202};\\\", \\\"{x:826,y:468,t:1527026810219};\\\", \\\"{x:873,y:474,t:1527026810235};\\\", \\\"{x:901,y:479,t:1527026810252};\\\", \\\"{x:922,y:482,t:1527026810269};\\\", \\\"{x:940,y:486,t:1527026810285};\\\", \\\"{x:953,y:489,t:1527026810303};\\\", \\\"{x:953,y:490,t:1527026810318};\\\", \\\"{x:953,y:492,t:1527026810610};\\\", \\\"{x:957,y:495,t:1527026810619};\\\", \\\"{x:963,y:495,t:1527026810635};\\\", \\\"{x:978,y:498,t:1527026810651};\\\", \\\"{x:1013,y:505,t:1527026810668};\\\", \\\"{x:1077,y:523,t:1527026810684};\\\", \\\"{x:1159,y:543,t:1527026810701};\\\", \\\"{x:1265,y:574,t:1527026810718};\\\", \\\"{x:1370,y:604,t:1527026810735};\\\", \\\"{x:1478,y:635,t:1527026810751};\\\", \\\"{x:1550,y:654,t:1527026810769};\\\", \\\"{x:1598,y:671,t:1527026810785};\\\", \\\"{x:1615,y:675,t:1527026810801};\\\", \\\"{x:1620,y:677,t:1527026810818};\\\", \\\"{x:1621,y:678,t:1527026810835};\\\", \\\"{x:1623,y:680,t:1527026810851};\\\", \\\"{x:1624,y:680,t:1527026810868};\\\", \\\"{x:1625,y:681,t:1527026810884};\\\", \\\"{x:1625,y:683,t:1527026810900};\\\", \\\"{x:1623,y:687,t:1527026810917};\\\", \\\"{x:1619,y:695,t:1527026810934};\\\", \\\"{x:1613,y:709,t:1527026810951};\\\", \\\"{x:1601,y:723,t:1527026810968};\\\", \\\"{x:1567,y:753,t:1527026810984};\\\", \\\"{x:1519,y:769,t:1527026811000};\\\", \\\"{x:1477,y:770,t:1527026811018};\\\", \\\"{x:1471,y:767,t:1527026811035};\\\", \\\"{x:1469,y:768,t:1527026811560};\\\", \\\"{x:1468,y:770,t:1527026811568};\\\", \\\"{x:1463,y:777,t:1527026811584};\\\", \\\"{x:1455,y:788,t:1527026811601};\\\", \\\"{x:1444,y:798,t:1527026811617};\\\", \\\"{x:1433,y:806,t:1527026811635};\\\", \\\"{x:1413,y:814,t:1527026811651};\\\", \\\"{x:1356,y:838,t:1527026811668};\\\", \\\"{x:1320,y:845,t:1527026811685};\\\", \\\"{x:1291,y:849,t:1527026811701};\\\", \\\"{x:1269,y:853,t:1527026811718};\\\", \\\"{x:1257,y:854,t:1527026811735};\\\", \\\"{x:1254,y:854,t:1527026811751};\\\", \\\"{x:1253,y:854,t:1527026811768};\\\", \\\"{x:1253,y:853,t:1527026811784};\\\", \\\"{x:1253,y:851,t:1527026811801};\\\", \\\"{x:1253,y:849,t:1527026811818};\\\", \\\"{x:1253,y:848,t:1527026811834};\\\", \\\"{x:1253,y:847,t:1527026811850};\\\", \\\"{x:1253,y:845,t:1527026811868};\\\", \\\"{x:1254,y:844,t:1527026811884};\\\", \\\"{x:1254,y:843,t:1527026811900};\\\", \\\"{x:1253,y:841,t:1527026811918};\\\", \\\"{x:1248,y:841,t:1527026811934};\\\", \\\"{x:1242,y:841,t:1527026811951};\\\", \\\"{x:1237,y:841,t:1527026811968};\\\", \\\"{x:1235,y:841,t:1527026811984};\\\", \\\"{x:1234,y:841,t:1527026812001};\\\", \\\"{x:1232,y:841,t:1527026812018};\\\", \\\"{x:1231,y:841,t:1527026812033};\\\", \\\"{x:1230,y:841,t:1527026812080};\\\", \\\"{x:1229,y:840,t:1527026812161};\\\", \\\"{x:1228,y:839,t:1527026812184};\\\", \\\"{x:1228,y:838,t:1527026812201};\\\", \\\"{x:1227,y:838,t:1527026812233};\\\", \\\"{x:1225,y:837,t:1527026812249};\\\", \\\"{x:1222,y:837,t:1527026812265};\\\", \\\"{x:1221,y:836,t:1527026812273};\\\", \\\"{x:1221,y:835,t:1527026812305};\\\", \\\"{x:1220,y:835,t:1527026812578};\\\", \\\"{x:1218,y:835,t:1527026812617};\\\", \\\"{x:1218,y:833,t:1527026813876};\\\", \\\"{x:1219,y:832,t:1527026813885};\\\", \\\"{x:1227,y:831,t:1527026813902};\\\", \\\"{x:1236,y:830,t:1527026813917};\\\", \\\"{x:1243,y:830,t:1527026813934};\\\", \\\"{x:1250,y:830,t:1527026813951};\\\", \\\"{x:1256,y:830,t:1527026813967};\\\", \\\"{x:1265,y:830,t:1527026813984};\\\", \\\"{x:1273,y:831,t:1527026814001};\\\", \\\"{x:1273,y:832,t:1527026814017};\\\", \\\"{x:1276,y:837,t:1527026814035};\\\", \\\"{x:1282,y:846,t:1527026814051};\\\", \\\"{x:1285,y:852,t:1527026814068};\\\", \\\"{x:1287,y:855,t:1527026814084};\\\", \\\"{x:1288,y:856,t:1527026814101};\\\", \\\"{x:1291,y:856,t:1527026814162};\\\", \\\"{x:1296,y:856,t:1527026814169};\\\", \\\"{x:1302,y:856,t:1527026814185};\\\", \\\"{x:1329,y:853,t:1527026814201};\\\", \\\"{x:1345,y:851,t:1527026814218};\\\", \\\"{x:1357,y:851,t:1527026814235};\\\", \\\"{x:1362,y:851,t:1527026814251};\\\", \\\"{x:1367,y:854,t:1527026814268};\\\", \\\"{x:1373,y:860,t:1527026814285};\\\", \\\"{x:1380,y:869,t:1527026814302};\\\", \\\"{x:1385,y:881,t:1527026814317};\\\", \\\"{x:1389,y:888,t:1527026814334};\\\", \\\"{x:1392,y:896,t:1527026814351};\\\", \\\"{x:1392,y:899,t:1527026814367};\\\", \\\"{x:1392,y:900,t:1527026814384};\\\", \\\"{x:1392,y:902,t:1527026814400};\\\", \\\"{x:1392,y:905,t:1527026814418};\\\", \\\"{x:1387,y:907,t:1527026814434};\\\", \\\"{x:1382,y:909,t:1527026814450};\\\", \\\"{x:1378,y:909,t:1527026814467};\\\", \\\"{x:1377,y:909,t:1527026814484};\\\", \\\"{x:1375,y:909,t:1527026814501};\\\", \\\"{x:1373,y:909,t:1527026814517};\\\", \\\"{x:1370,y:909,t:1527026814535};\\\", \\\"{x:1369,y:905,t:1527026814550};\\\", \\\"{x:1367,y:902,t:1527026814567};\\\", \\\"{x:1366,y:898,t:1527026814584};\\\", \\\"{x:1365,y:894,t:1527026814601};\\\", \\\"{x:1365,y:892,t:1527026814618};\\\", \\\"{x:1364,y:890,t:1527026814635};\\\", \\\"{x:1363,y:890,t:1527026814681};\\\", \\\"{x:1362,y:890,t:1527026814706};\\\", \\\"{x:1361,y:888,t:1527026814721};\\\", \\\"{x:1358,y:888,t:1527026814745};\\\", \\\"{x:1357,y:888,t:1527026814762};\\\", \\\"{x:1356,y:888,t:1527026815290};\\\", \\\"{x:1350,y:887,t:1527026815302};\\\", \\\"{x:1326,y:883,t:1527026815318};\\\", \\\"{x:1267,y:873,t:1527026815335};\\\", \\\"{x:1178,y:856,t:1527026815351};\\\", \\\"{x:1071,y:834,t:1527026815368};\\\", \\\"{x:980,y:813,t:1527026815385};\\\", \\\"{x:915,y:788,t:1527026815400};\\\", \\\"{x:854,y:750,t:1527026815417};\\\", \\\"{x:830,y:729,t:1527026815434};\\\", \\\"{x:811,y:707,t:1527026815451};\\\", \\\"{x:794,y:677,t:1527026815468};\\\", \\\"{x:781,y:665,t:1527026815484};\\\", \\\"{x:767,y:659,t:1527026815502};\\\", \\\"{x:755,y:649,t:1527026815518};\\\", \\\"{x:741,y:643,t:1527026815534};\\\", \\\"{x:731,y:637,t:1527026815550};\\\", \\\"{x:725,y:632,t:1527026815568};\\\", \\\"{x:724,y:631,t:1527026815585};\\\", \\\"{x:723,y:631,t:1527026815616};\\\", \\\"{x:722,y:631,t:1527026815624};\\\", \\\"{x:718,y:631,t:1527026815635};\\\", \\\"{x:706,y:632,t:1527026815652};\\\", \\\"{x:692,y:639,t:1527026815668};\\\", \\\"{x:679,y:647,t:1527026815685};\\\", \\\"{x:670,y:653,t:1527026815703};\\\", \\\"{x:664,y:656,t:1527026815718};\\\", \\\"{x:647,y:656,t:1527026815740};\\\", \\\"{x:627,y:656,t:1527026815757};\\\", \\\"{x:603,y:656,t:1527026815773};\\\", \\\"{x:582,y:656,t:1527026815790};\\\", \\\"{x:572,y:654,t:1527026815807};\\\", \\\"{x:567,y:651,t:1527026815823};\\\", \\\"{x:563,y:648,t:1527026815841};\\\", \\\"{x:544,y:642,t:1527026815857};\\\", \\\"{x:524,y:640,t:1527026815873};\\\", \\\"{x:506,y:637,t:1527026815890};\\\", \\\"{x:488,y:637,t:1527026815908};\\\", \\\"{x:472,y:636,t:1527026815923};\\\", \\\"{x:450,y:636,t:1527026815940};\\\", \\\"{x:424,y:636,t:1527026815957};\\\", \\\"{x:398,y:636,t:1527026815973};\\\", \\\"{x:375,y:636,t:1527026815990};\\\", \\\"{x:363,y:635,t:1527026816008};\\\", \\\"{x:361,y:635,t:1527026816023};\\\", \\\"{x:361,y:634,t:1527026816040};\\\", \\\"{x:361,y:633,t:1527026816057};\\\", \\\"{x:361,y:629,t:1527026816075};\\\", \\\"{x:361,y:626,t:1527026816090};\\\", \\\"{x:363,y:620,t:1527026816107};\\\", \\\"{x:366,y:613,t:1527026816125};\\\", \\\"{x:372,y:611,t:1527026816141};\\\", \\\"{x:372,y:608,t:1527026816158};\\\", \\\"{x:372,y:607,t:1527026816177};\\\", \\\"{x:372,y:606,t:1527026816190};\\\", \\\"{x:366,y:604,t:1527026816208};\\\", \\\"{x:355,y:604,t:1527026816224};\\\", \\\"{x:331,y:611,t:1527026816240};\\\", \\\"{x:294,y:621,t:1527026816259};\\\", \\\"{x:262,y:624,t:1527026816276};\\\", \\\"{x:233,y:624,t:1527026816290};\\\", \\\"{x:214,y:624,t:1527026816307};\\\", \\\"{x:206,y:628,t:1527026816323};\\\", \\\"{x:205,y:629,t:1527026816340};\\\", \\\"{x:204,y:630,t:1527026816357};\\\", \\\"{x:203,y:630,t:1527026816373};\\\", \\\"{x:203,y:631,t:1527026816390};\\\", \\\"{x:203,y:632,t:1527026816481};\\\", \\\"{x:205,y:632,t:1527026816498};\\\", \\\"{x:209,y:632,t:1527026816508};\\\", \\\"{x:232,y:627,t:1527026816523};\\\", \\\"{x:273,y:622,t:1527026816543};\\\", \\\"{x:351,y:611,t:1527026816558};\\\", \\\"{x:442,y:599,t:1527026816574};\\\", \\\"{x:533,y:589,t:1527026816591};\\\", \\\"{x:605,y:589,t:1527026816607};\\\", \\\"{x:642,y:589,t:1527026816624};\\\", \\\"{x:646,y:589,t:1527026816641};\\\", \\\"{x:648,y:589,t:1527026816689};\\\", \\\"{x:652,y:589,t:1527026816696};\\\", \\\"{x:656,y:589,t:1527026816707};\\\", \\\"{x:670,y:586,t:1527026816724};\\\", \\\"{x:688,y:585,t:1527026816741};\\\", \\\"{x:705,y:584,t:1527026816757};\\\", \\\"{x:719,y:584,t:1527026816774};\\\", \\\"{x:731,y:584,t:1527026816792};\\\", \\\"{x:743,y:586,t:1527026816808};\\\", \\\"{x:761,y:587,t:1527026816824};\\\", \\\"{x:769,y:588,t:1527026816841};\\\", \\\"{x:782,y:589,t:1527026816859};\\\", \\\"{x:785,y:591,t:1527026816874};\\\", \\\"{x:783,y:591,t:1527026816912};\\\", \\\"{x:775,y:591,t:1527026816925};\\\", \\\"{x:756,y:590,t:1527026816941};\\\", \\\"{x:733,y:590,t:1527026816958};\\\", \\\"{x:700,y:590,t:1527026816975};\\\", \\\"{x:635,y:580,t:1527026816992};\\\", \\\"{x:593,y:573,t:1527026817009};\\\", \\\"{x:585,y:568,t:1527026817024};\\\", \\\"{x:584,y:567,t:1527026817041};\\\", \\\"{x:584,y:566,t:1527026817059};\\\", \\\"{x:584,y:564,t:1527026817137};\\\", \\\"{x:583,y:564,t:1527026817144};\\\", \\\"{x:581,y:563,t:1527026817158};\\\", \\\"{x:574,y:563,t:1527026817174};\\\", \\\"{x:555,y:562,t:1527026817191};\\\", \\\"{x:503,y:561,t:1527026817208};\\\", \\\"{x:483,y:561,t:1527026817225};\\\", \\\"{x:421,y:561,t:1527026817241};\\\", \\\"{x:393,y:561,t:1527026817258};\\\", \\\"{x:374,y:561,t:1527026817274};\\\", \\\"{x:369,y:561,t:1527026817292};\\\", \\\"{x:366,y:561,t:1527026817361};\\\", \\\"{x:357,y:561,t:1527026817374};\\\", \\\"{x:337,y:561,t:1527026817391};\\\", \\\"{x:307,y:561,t:1527026817409};\\\", \\\"{x:295,y:561,t:1527026817424};\\\", \\\"{x:293,y:561,t:1527026817442};\\\", \\\"{x:292,y:561,t:1527026817473};\\\", \\\"{x:291,y:561,t:1527026817480};\\\", \\\"{x:291,y:562,t:1527026817491};\\\", \\\"{x:286,y:566,t:1527026817508};\\\", \\\"{x:279,y:571,t:1527026817524};\\\", \\\"{x:264,y:581,t:1527026817542};\\\", \\\"{x:249,y:588,t:1527026817558};\\\", \\\"{x:236,y:594,t:1527026817576};\\\", \\\"{x:224,y:598,t:1527026817591};\\\", \\\"{x:206,y:599,t:1527026817608};\\\", \\\"{x:192,y:599,t:1527026817625};\\\", \\\"{x:180,y:599,t:1527026817642};\\\", \\\"{x:172,y:599,t:1527026817659};\\\", \\\"{x:167,y:597,t:1527026817676};\\\", \\\"{x:163,y:596,t:1527026817693};\\\", \\\"{x:159,y:592,t:1527026817708};\\\", \\\"{x:158,y:590,t:1527026817725};\\\", \\\"{x:158,y:586,t:1527026817743};\\\", \\\"{x:158,y:578,t:1527026817760};\\\", \\\"{x:158,y:574,t:1527026817776};\\\", \\\"{x:158,y:572,t:1527026817791};\\\", \\\"{x:158,y:570,t:1527026817817};\\\", \\\"{x:159,y:570,t:1527026817849};\\\", \\\"{x:160,y:569,t:1527026817859};\\\", \\\"{x:161,y:569,t:1527026818312};\\\", \\\"{x:163,y:569,t:1527026818325};\\\", \\\"{x:171,y:569,t:1527026818342};\\\", \\\"{x:192,y:571,t:1527026818359};\\\", \\\"{x:216,y:579,t:1527026818376};\\\", \\\"{x:233,y:586,t:1527026818393};\\\", \\\"{x:240,y:589,t:1527026818408};\\\", \\\"{x:257,y:597,t:1527026818426};\\\", \\\"{x:278,y:609,t:1527026818443};\\\", \\\"{x:325,y:636,t:1527026818460};\\\", \\\"{x:366,y:660,t:1527026818476};\\\", \\\"{x:394,y:681,t:1527026818492};\\\", \\\"{x:417,y:699,t:1527026818509};\\\", \\\"{x:441,y:721,t:1527026818525};\\\", \\\"{x:468,y:741,t:1527026818542};\\\", \\\"{x:494,y:758,t:1527026818560};\\\", \\\"{x:515,y:765,t:1527026818575};\\\", \\\"{x:527,y:768,t:1527026818593};\\\", \\\"{x:529,y:769,t:1527026818609};\\\", \\\"{x:528,y:768,t:1527026818804};\\\", \\\"{x:526,y:764,t:1527026818809};\\\", \\\"{x:522,y:755,t:1527026818826};\\\", \\\"{x:519,y:747,t:1527026818842};\\\", \\\"{x:519,y:743,t:1527026818859};\\\", \\\"{x:518,y:739,t:1527026818876};\\\", \\\"{x:518,y:737,t:1527026818892};\\\", \\\"{x:517,y:736,t:1527026818910};\\\", \\\"{x:517,y:735,t:1527026818927};\\\", \\\"{x:517,y:734,t:1527026818943};\\\", \\\"{x:517,y:732,t:1527026818958};\\\", \\\"{x:517,y:730,t:1527026818975};\\\", \\\"{x:517,y:726,t:1527026818992};\\\", \\\"{x:517,y:723,t:1527026819009};\\\", \\\"{x:517,y:721,t:1527026819025};\\\", \\\"{x:518,y:719,t:1527026819545};\\\", \\\"{x:520,y:717,t:1527026819560};\\\", \\\"{x:521,y:716,t:1527026819576};\\\", \\\"{x:522,y:716,t:1527026820129};\\\" ] }, { \\\"rt\\\": 25092, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 176976, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -U -F -H -H -H -I -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:716,t:1527026820546};\\\", \\\"{x:527,y:713,t:1527026820561};\\\", \\\"{x:528,y:712,t:1527026820577};\\\", \\\"{x:532,y:708,t:1527026820593};\\\", \\\"{x:532,y:705,t:1527026820610};\\\", \\\"{x:534,y:706,t:1527026821250};\\\", \\\"{x:535,y:706,t:1527026821261};\\\", \\\"{x:537,y:703,t:1527026821278};\\\", \\\"{x:544,y:696,t:1527026821296};\\\", \\\"{x:553,y:687,t:1527026821312};\\\", \\\"{x:572,y:672,t:1527026821327};\\\", \\\"{x:620,y:643,t:1527026821345};\\\", \\\"{x:668,y:620,t:1527026821362};\\\", \\\"{x:677,y:616,t:1527026821379};\\\", \\\"{x:679,y:615,t:1527026821825};\\\", \\\"{x:684,y:612,t:1527026821841};\\\", \\\"{x:690,y:612,t:1527026821849};\\\", \\\"{x:695,y:611,t:1527026821861};\\\", \\\"{x:719,y:607,t:1527026821879};\\\", \\\"{x:746,y:606,t:1527026821896};\\\", \\\"{x:787,y:599,t:1527026821911};\\\", \\\"{x:858,y:590,t:1527026821929};\\\", \\\"{x:903,y:590,t:1527026821946};\\\", \\\"{x:959,y:590,t:1527026821962};\\\", \\\"{x:1023,y:590,t:1527026821979};\\\", \\\"{x:1092,y:590,t:1527026821996};\\\", \\\"{x:1159,y:590,t:1527026822011};\\\", \\\"{x:1223,y:590,t:1527026822028};\\\", \\\"{x:1276,y:590,t:1527026822046};\\\", \\\"{x:1315,y:590,t:1527026822061};\\\", \\\"{x:1352,y:590,t:1527026822078};\\\", \\\"{x:1382,y:591,t:1527026822095};\\\", \\\"{x:1411,y:595,t:1527026822111};\\\", \\\"{x:1451,y:600,t:1527026822129};\\\", \\\"{x:1474,y:605,t:1527026822146};\\\", \\\"{x:1496,y:612,t:1527026822162};\\\", \\\"{x:1512,y:620,t:1527026822179};\\\", \\\"{x:1525,y:627,t:1527026822197};\\\", \\\"{x:1536,y:637,t:1527026822211};\\\", \\\"{x:1545,y:649,t:1527026822229};\\\", \\\"{x:1553,y:666,t:1527026822246};\\\", \\\"{x:1560,y:687,t:1527026822262};\\\", \\\"{x:1563,y:715,t:1527026822279};\\\", \\\"{x:1567,y:748,t:1527026822296};\\\", \\\"{x:1575,y:790,t:1527026822313};\\\", \\\"{x:1583,y:813,t:1527026822329};\\\", \\\"{x:1593,y:830,t:1527026822346};\\\", \\\"{x:1603,y:844,t:1527026822363};\\\", \\\"{x:1614,y:857,t:1527026822379};\\\", \\\"{x:1621,y:866,t:1527026822396};\\\", \\\"{x:1625,y:873,t:1527026822413};\\\", \\\"{x:1628,y:877,t:1527026822429};\\\", \\\"{x:1630,y:882,t:1527026822446};\\\", \\\"{x:1635,y:886,t:1527026822463};\\\", \\\"{x:1639,y:888,t:1527026822479};\\\", \\\"{x:1641,y:890,t:1527026822496};\\\", \\\"{x:1643,y:891,t:1527026822562};\\\", \\\"{x:1643,y:892,t:1527026822586};\\\", \\\"{x:1643,y:893,t:1527026822597};\\\", \\\"{x:1643,y:896,t:1527026822613};\\\", \\\"{x:1643,y:903,t:1527026822630};\\\", \\\"{x:1641,y:908,t:1527026822646};\\\", \\\"{x:1639,y:912,t:1527026822663};\\\", \\\"{x:1637,y:916,t:1527026822680};\\\", \\\"{x:1635,y:922,t:1527026822696};\\\", \\\"{x:1631,y:930,t:1527026822713};\\\", \\\"{x:1626,y:933,t:1527026822730};\\\", \\\"{x:1624,y:935,t:1527026822747};\\\", \\\"{x:1623,y:936,t:1527026822763};\\\", \\\"{x:1622,y:937,t:1527026822780};\\\", \\\"{x:1622,y:938,t:1527026822796};\\\", \\\"{x:1621,y:939,t:1527026822813};\\\", \\\"{x:1621,y:940,t:1527026822849};\\\", \\\"{x:1621,y:941,t:1527026822865};\\\", \\\"{x:1620,y:943,t:1527026822880};\\\", \\\"{x:1619,y:944,t:1527026822896};\\\", \\\"{x:1617,y:946,t:1527026822913};\\\", \\\"{x:1615,y:947,t:1527026822929};\\\", \\\"{x:1613,y:949,t:1527026822946};\\\", \\\"{x:1612,y:950,t:1527026823091};\\\", \\\"{x:1612,y:948,t:1527026823121};\\\", \\\"{x:1612,y:947,t:1527026823137};\\\", \\\"{x:1612,y:946,t:1527026823146};\\\", \\\"{x:1612,y:943,t:1527026823163};\\\", \\\"{x:1612,y:938,t:1527026823180};\\\", \\\"{x:1610,y:932,t:1527026823196};\\\", \\\"{x:1610,y:926,t:1527026823213};\\\", \\\"{x:1610,y:922,t:1527026823230};\\\", \\\"{x:1610,y:919,t:1527026823246};\\\", \\\"{x:1610,y:915,t:1527026823263};\\\", \\\"{x:1609,y:911,t:1527026823280};\\\", \\\"{x:1609,y:906,t:1527026823297};\\\", \\\"{x:1609,y:904,t:1527026823313};\\\", \\\"{x:1609,y:901,t:1527026823331};\\\", \\\"{x:1609,y:900,t:1527026823347};\\\", \\\"{x:1608,y:897,t:1527026823364};\\\", \\\"{x:1607,y:894,t:1527026823380};\\\", \\\"{x:1607,y:892,t:1527026823397};\\\", \\\"{x:1607,y:890,t:1527026823413};\\\", \\\"{x:1607,y:887,t:1527026823430};\\\", \\\"{x:1607,y:884,t:1527026823447};\\\", \\\"{x:1607,y:882,t:1527026823463};\\\", \\\"{x:1607,y:880,t:1527026823480};\\\", \\\"{x:1608,y:878,t:1527026823497};\\\", \\\"{x:1608,y:874,t:1527026823513};\\\", \\\"{x:1610,y:871,t:1527026823530};\\\", \\\"{x:1610,y:867,t:1527026823547};\\\", \\\"{x:1610,y:864,t:1527026823563};\\\", \\\"{x:1610,y:863,t:1527026823580};\\\", \\\"{x:1610,y:861,t:1527026823596};\\\", \\\"{x:1610,y:860,t:1527026823613};\\\", \\\"{x:1610,y:859,t:1527026823629};\\\", \\\"{x:1610,y:858,t:1527026823647};\\\", \\\"{x:1610,y:857,t:1527026823663};\\\", \\\"{x:1610,y:856,t:1527026823680};\\\", \\\"{x:1610,y:854,t:1527026823696};\\\", \\\"{x:1610,y:851,t:1527026823714};\\\", \\\"{x:1611,y:849,t:1527026823729};\\\", \\\"{x:1611,y:848,t:1527026823747};\\\", \\\"{x:1611,y:847,t:1527026823763};\\\", \\\"{x:1611,y:846,t:1527026823784};\\\", \\\"{x:1611,y:845,t:1527026823801};\\\", \\\"{x:1613,y:844,t:1527026823814};\\\", \\\"{x:1613,y:843,t:1527026823830};\\\", \\\"{x:1613,y:840,t:1527026823847};\\\", \\\"{x:1614,y:839,t:1527026823864};\\\", \\\"{x:1614,y:838,t:1527026823881};\\\", \\\"{x:1614,y:836,t:1527026823897};\\\", \\\"{x:1614,y:834,t:1527026823914};\\\", \\\"{x:1614,y:833,t:1527026823930};\\\", \\\"{x:1614,y:831,t:1527026823947};\\\", \\\"{x:1614,y:826,t:1527026823965};\\\", \\\"{x:1614,y:822,t:1527026823980};\\\", \\\"{x:1614,y:820,t:1527026823997};\\\", \\\"{x:1614,y:816,t:1527026824014};\\\", \\\"{x:1614,y:815,t:1527026824030};\\\", \\\"{x:1614,y:813,t:1527026824047};\\\", \\\"{x:1614,y:809,t:1527026824064};\\\", \\\"{x:1614,y:808,t:1527026824081};\\\", \\\"{x:1614,y:803,t:1527026824096};\\\", \\\"{x:1614,y:800,t:1527026824114};\\\", \\\"{x:1614,y:799,t:1527026824130};\\\", \\\"{x:1614,y:795,t:1527026824147};\\\", \\\"{x:1614,y:787,t:1527026824164};\\\", \\\"{x:1614,y:781,t:1527026824180};\\\", \\\"{x:1614,y:775,t:1527026824197};\\\", \\\"{x:1616,y:762,t:1527026824214};\\\", \\\"{x:1616,y:757,t:1527026824231};\\\", \\\"{x:1616,y:751,t:1527026824247};\\\", \\\"{x:1616,y:743,t:1527026824264};\\\", \\\"{x:1618,y:732,t:1527026824281};\\\", \\\"{x:1619,y:724,t:1527026824298};\\\", \\\"{x:1620,y:717,t:1527026824314};\\\", \\\"{x:1620,y:713,t:1527026824330};\\\", \\\"{x:1620,y:709,t:1527026824346};\\\", \\\"{x:1620,y:708,t:1527026824364};\\\", \\\"{x:1620,y:706,t:1527026824522};\\\", \\\"{x:1618,y:706,t:1527026824531};\\\", \\\"{x:1610,y:703,t:1527026824547};\\\", \\\"{x:1601,y:701,t:1527026824564};\\\", \\\"{x:1594,y:698,t:1527026824581};\\\", \\\"{x:1588,y:697,t:1527026824597};\\\", \\\"{x:1584,y:694,t:1527026824615};\\\", \\\"{x:1582,y:692,t:1527026824631};\\\", \\\"{x:1580,y:691,t:1527026824647};\\\", \\\"{x:1580,y:690,t:1527026824664};\\\", \\\"{x:1577,y:687,t:1527026824681};\\\", \\\"{x:1575,y:685,t:1527026824698};\\\", \\\"{x:1570,y:682,t:1527026824714};\\\", \\\"{x:1567,y:679,t:1527026824730};\\\", \\\"{x:1564,y:677,t:1527026824748};\\\", \\\"{x:1560,y:673,t:1527026824764};\\\", \\\"{x:1555,y:668,t:1527026824781};\\\", \\\"{x:1549,y:664,t:1527026824798};\\\", \\\"{x:1543,y:660,t:1527026824814};\\\", \\\"{x:1540,y:657,t:1527026824832};\\\", \\\"{x:1538,y:657,t:1527026824848};\\\", \\\"{x:1538,y:656,t:1527026824865};\\\", \\\"{x:1532,y:653,t:1527026824881};\\\", \\\"{x:1528,y:650,t:1527026824897};\\\", \\\"{x:1521,y:645,t:1527026824915};\\\", \\\"{x:1519,y:645,t:1527026824931};\\\", \\\"{x:1518,y:644,t:1527026824948};\\\", \\\"{x:1517,y:643,t:1527026825025};\\\", \\\"{x:1517,y:642,t:1527026825033};\\\", \\\"{x:1516,y:642,t:1527026825049};\\\", \\\"{x:1516,y:640,t:1527026825065};\\\", \\\"{x:1516,y:639,t:1527026825097};\\\", \\\"{x:1515,y:638,t:1527026825129};\\\", \\\"{x:1513,y:642,t:1527026825873};\\\", \\\"{x:1512,y:647,t:1527026825882};\\\", \\\"{x:1507,y:659,t:1527026825898};\\\", \\\"{x:1505,y:673,t:1527026825915};\\\", \\\"{x:1502,y:685,t:1527026825933};\\\", \\\"{x:1498,y:703,t:1527026825948};\\\", \\\"{x:1497,y:720,t:1527026825965};\\\", \\\"{x:1495,y:737,t:1527026825982};\\\", \\\"{x:1493,y:751,t:1527026825998};\\\", \\\"{x:1492,y:758,t:1527026826015};\\\", \\\"{x:1492,y:768,t:1527026826032};\\\", \\\"{x:1492,y:779,t:1527026826048};\\\", \\\"{x:1492,y:794,t:1527026826065};\\\", \\\"{x:1492,y:803,t:1527026826082};\\\", \\\"{x:1492,y:808,t:1527026826098};\\\", \\\"{x:1492,y:816,t:1527026826115};\\\", \\\"{x:1491,y:825,t:1527026826132};\\\", \\\"{x:1491,y:832,t:1527026826148};\\\", \\\"{x:1491,y:837,t:1527026826165};\\\", \\\"{x:1490,y:838,t:1527026826401};\\\", \\\"{x:1488,y:838,t:1527026826417};\\\", \\\"{x:1487,y:838,t:1527026826432};\\\", \\\"{x:1486,y:838,t:1527026826449};\\\", \\\"{x:1485,y:837,t:1527026826465};\\\", \\\"{x:1485,y:836,t:1527026826482};\\\", \\\"{x:1484,y:836,t:1527026826499};\\\", \\\"{x:1483,y:835,t:1527026826516};\\\", \\\"{x:1482,y:834,t:1527026826549};\\\", \\\"{x:1482,y:833,t:1527026826565};\\\", \\\"{x:1480,y:832,t:1527026826581};\\\", \\\"{x:1476,y:832,t:1527026829934};\\\", \\\"{x:1443,y:832,t:1527026829950};\\\", \\\"{x:1365,y:832,t:1527026829966};\\\", \\\"{x:1160,y:826,t:1527026829982};\\\", \\\"{x:972,y:799,t:1527026829999};\\\", \\\"{x:797,y:772,t:1527026830016};\\\", \\\"{x:658,y:746,t:1527026830032};\\\", \\\"{x:547,y:713,t:1527026830050};\\\", \\\"{x:476,y:686,t:1527026830065};\\\", \\\"{x:446,y:671,t:1527026830082};\\\", \\\"{x:437,y:664,t:1527026830099};\\\", \\\"{x:437,y:662,t:1527026830115};\\\", \\\"{x:437,y:658,t:1527026830131};\\\", \\\"{x:440,y:653,t:1527026830149};\\\", \\\"{x:444,y:645,t:1527026830165};\\\", \\\"{x:448,y:637,t:1527026830181};\\\", \\\"{x:453,y:633,t:1527026830199};\\\", \\\"{x:459,y:627,t:1527026830216};\\\", \\\"{x:472,y:618,t:1527026830233};\\\", \\\"{x:492,y:612,t:1527026830250};\\\", \\\"{x:518,y:608,t:1527026830267};\\\", \\\"{x:545,y:608,t:1527026830282};\\\", \\\"{x:564,y:608,t:1527026830299};\\\", \\\"{x:578,y:607,t:1527026830316};\\\", \\\"{x:586,y:607,t:1527026830332};\\\", \\\"{x:593,y:607,t:1527026830349};\\\", \\\"{x:598,y:607,t:1527026830365};\\\", \\\"{x:600,y:607,t:1527026830382};\\\", \\\"{x:597,y:607,t:1527026830421};\\\", \\\"{x:591,y:604,t:1527026830432};\\\", \\\"{x:586,y:601,t:1527026830448};\\\", \\\"{x:585,y:601,t:1527026830466};\\\", \\\"{x:587,y:601,t:1527026830558};\\\", \\\"{x:590,y:601,t:1527026830565};\\\", \\\"{x:596,y:602,t:1527026830582};\\\", \\\"{x:597,y:603,t:1527026830599};\\\", \\\"{x:598,y:603,t:1527026830616};\\\", \\\"{x:599,y:603,t:1527026830646};\\\", \\\"{x:599,y:604,t:1527026830666};\\\", \\\"{x:601,y:604,t:1527026831006};\\\", \\\"{x:602,y:604,t:1527026831079};\\\", \\\"{x:605,y:604,t:1527026831089};\\\", \\\"{x:606,y:604,t:1527026831100};\\\", \\\"{x:610,y:604,t:1527026831116};\\\", \\\"{x:612,y:603,t:1527026831133};\\\", \\\"{x:609,y:605,t:1527026831270};\\\", \\\"{x:607,y:607,t:1527026831283};\\\", \\\"{x:605,y:617,t:1527026831301};\\\", \\\"{x:601,y:632,t:1527026831317};\\\", \\\"{x:600,y:642,t:1527026831333};\\\", \\\"{x:597,y:652,t:1527026831351};\\\", \\\"{x:596,y:656,t:1527026831367};\\\", \\\"{x:595,y:660,t:1527026831384};\\\", \\\"{x:594,y:664,t:1527026831401};\\\", \\\"{x:593,y:666,t:1527026831416};\\\", \\\"{x:592,y:669,t:1527026831433};\\\", \\\"{x:591,y:672,t:1527026831450};\\\", \\\"{x:591,y:673,t:1527026831466};\\\", \\\"{x:589,y:675,t:1527026831483};\\\", \\\"{x:588,y:676,t:1527026831500};\\\", \\\"{x:587,y:677,t:1527026831517};\\\", \\\"{x:585,y:678,t:1527026831533};\\\", \\\"{x:579,y:680,t:1527026831549};\\\", \\\"{x:567,y:683,t:1527026831566};\\\", \\\"{x:559,y:686,t:1527026831583};\\\", \\\"{x:552,y:690,t:1527026831599};\\\", \\\"{x:546,y:695,t:1527026831616};\\\", \\\"{x:542,y:699,t:1527026831632};\\\", \\\"{x:539,y:702,t:1527026831649};\\\", \\\"{x:536,y:704,t:1527026831666};\\\", \\\"{x:535,y:705,t:1527026831684};\\\", \\\"{x:533,y:707,t:1527026831700};\\\", \\\"{x:532,y:710,t:1527026831717};\\\", \\\"{x:530,y:713,t:1527026831733};\\\", \\\"{x:528,y:716,t:1527026831751};\\\", \\\"{x:528,y:718,t:1527026831768};\\\", \\\"{x:528,y:720,t:1527026831784};\\\", \\\"{x:527,y:721,t:1527026831800};\\\", \\\"{x:529,y:721,t:1527026832143};\\\", \\\"{x:535,y:721,t:1527026832151};\\\", \\\"{x:569,y:719,t:1527026832170};\\\", \\\"{x:651,y:713,t:1527026832186};\\\", \\\"{x:752,y:709,t:1527026832201};\\\", \\\"{x:877,y:709,t:1527026832218};\\\", \\\"{x:1012,y:709,t:1527026832235};\\\", \\\"{x:1131,y:709,t:1527026832251};\\\", \\\"{x:1236,y:709,t:1527026832268};\\\", \\\"{x:1319,y:716,t:1527026832285};\\\", \\\"{x:1362,y:723,t:1527026832302};\\\", \\\"{x:1381,y:726,t:1527026832318};\\\", \\\"{x:1390,y:728,t:1527026832334};\\\", \\\"{x:1391,y:728,t:1527026832351};\\\", \\\"{x:1391,y:729,t:1527026832431};\\\", \\\"{x:1391,y:731,t:1527026832438};\\\", \\\"{x:1392,y:734,t:1527026832452};\\\", \\\"{x:1397,y:746,t:1527026832468};\\\", \\\"{x:1400,y:754,t:1527026832485};\\\", \\\"{x:1405,y:763,t:1527026832502};\\\", \\\"{x:1408,y:770,t:1527026832518};\\\", \\\"{x:1418,y:793,t:1527026832535};\\\", \\\"{x:1425,y:806,t:1527026832552};\\\", \\\"{x:1431,y:816,t:1527026832568};\\\", \\\"{x:1436,y:822,t:1527026832584};\\\", \\\"{x:1440,y:824,t:1527026832602};\\\", \\\"{x:1445,y:825,t:1527026832618};\\\", \\\"{x:1449,y:825,t:1527026832634};\\\", \\\"{x:1451,y:825,t:1527026832651};\\\", \\\"{x:1452,y:825,t:1527026832668};\\\", \\\"{x:1455,y:825,t:1527026832684};\\\", \\\"{x:1457,y:824,t:1527026832702};\\\", \\\"{x:1463,y:822,t:1527026832718};\\\", \\\"{x:1466,y:821,t:1527026832734};\\\", \\\"{x:1468,y:820,t:1527026832766};\\\", \\\"{x:1470,y:820,t:1527026832807};\\\", \\\"{x:1471,y:820,t:1527026832818};\\\", \\\"{x:1472,y:821,t:1527026832834};\\\", \\\"{x:1473,y:821,t:1527026832902};\\\", \\\"{x:1473,y:822,t:1527026832933};\\\", \\\"{x:1473,y:825,t:1527026832942};\\\", \\\"{x:1474,y:827,t:1527026832951};\\\", \\\"{x:1474,y:829,t:1527026832969};\\\", \\\"{x:1474,y:831,t:1527026832984};\\\", \\\"{x:1475,y:833,t:1527026833002};\\\", \\\"{x:1473,y:836,t:1527026834910};\\\", \\\"{x:1466,y:839,t:1527026834920};\\\", \\\"{x:1444,y:846,t:1527026834937};\\\", \\\"{x:1422,y:850,t:1527026834953};\\\", \\\"{x:1411,y:852,t:1527026834969};\\\", \\\"{x:1405,y:854,t:1527026834987};\\\", \\\"{x:1403,y:855,t:1527026835004};\\\", \\\"{x:1403,y:856,t:1527026835020};\\\", \\\"{x:1402,y:858,t:1527026835036};\\\", \\\"{x:1400,y:861,t:1527026835054};\\\", \\\"{x:1398,y:863,t:1527026835070};\\\", \\\"{x:1392,y:874,t:1527026835089};\\\", \\\"{x:1388,y:880,t:1527026835104};\\\", \\\"{x:1384,y:885,t:1527026835120};\\\", \\\"{x:1382,y:887,t:1527026835137};\\\", \\\"{x:1381,y:889,t:1527026835154};\\\", \\\"{x:1381,y:890,t:1527026835169};\\\", \\\"{x:1380,y:891,t:1527026835187};\\\", \\\"{x:1379,y:892,t:1527026835204};\\\", \\\"{x:1377,y:895,t:1527026835221};\\\", \\\"{x:1375,y:896,t:1527026835237};\\\", \\\"{x:1372,y:898,t:1527026835254};\\\", \\\"{x:1371,y:898,t:1527026835743};\\\", \\\"{x:1371,y:895,t:1527026835754};\\\", \\\"{x:1370,y:880,t:1527026835771};\\\", \\\"{x:1370,y:857,t:1527026835788};\\\", \\\"{x:1370,y:831,t:1527026835804};\\\", \\\"{x:1370,y:809,t:1527026835821};\\\", \\\"{x:1372,y:802,t:1527026835838};\\\", \\\"{x:1373,y:801,t:1527026835854};\\\", \\\"{x:1373,y:799,t:1527026835871};\\\", \\\"{x:1373,y:798,t:1527026835888};\\\", \\\"{x:1373,y:795,t:1527026835904};\\\", \\\"{x:1373,y:790,t:1527026835920};\\\", \\\"{x:1373,y:787,t:1527026835938};\\\", \\\"{x:1373,y:785,t:1527026835954};\\\", \\\"{x:1373,y:783,t:1527026835991};\\\", \\\"{x:1373,y:782,t:1527026836003};\\\", \\\"{x:1375,y:777,t:1527026836021};\\\", \\\"{x:1377,y:772,t:1527026836039};\\\", \\\"{x:1377,y:771,t:1527026836054};\\\", \\\"{x:1379,y:767,t:1527026836071};\\\", \\\"{x:1380,y:766,t:1527026836103};\\\", \\\"{x:1380,y:765,t:1527026836141};\\\", \\\"{x:1381,y:765,t:1527026836153};\\\", \\\"{x:1386,y:758,t:1527026838289};\\\", \\\"{x:1401,y:731,t:1527026838306};\\\", \\\"{x:1414,y:707,t:1527026838322};\\\", \\\"{x:1427,y:674,t:1527026838339};\\\", \\\"{x:1451,y:619,t:1527026838356};\\\", \\\"{x:1464,y:578,t:1527026838372};\\\", \\\"{x:1466,y:569,t:1527026838388};\\\", \\\"{x:1466,y:542,t:1527026838405};\\\", \\\"{x:1466,y:529,t:1527026838422};\\\", \\\"{x:1466,y:521,t:1527026838440};\\\", \\\"{x:1466,y:515,t:1527026838455};\\\", \\\"{x:1466,y:514,t:1527026838472};\\\", \\\"{x:1464,y:511,t:1527026838489};\\\", \\\"{x:1461,y:510,t:1527026838505};\\\", \\\"{x:1458,y:510,t:1527026838523};\\\", \\\"{x:1450,y:511,t:1527026838539};\\\", \\\"{x:1443,y:514,t:1527026838556};\\\", \\\"{x:1434,y:517,t:1527026838572};\\\", \\\"{x:1425,y:525,t:1527026838590};\\\", \\\"{x:1420,y:530,t:1527026838605};\\\", \\\"{x:1418,y:533,t:1527026838622};\\\", \\\"{x:1417,y:536,t:1527026838639};\\\", \\\"{x:1417,y:538,t:1527026838662};\\\", \\\"{x:1417,y:540,t:1527026838673};\\\", \\\"{x:1417,y:543,t:1527026838689};\\\", \\\"{x:1417,y:545,t:1527026838706};\\\", \\\"{x:1415,y:547,t:1527026838722};\\\", \\\"{x:1415,y:548,t:1527026838813};\\\", \\\"{x:1415,y:551,t:1527026838822};\\\", \\\"{x:1415,y:557,t:1527026838840};\\\", \\\"{x:1415,y:562,t:1527026838855};\\\", \\\"{x:1415,y:564,t:1527026838872};\\\", \\\"{x:1414,y:559,t:1527026839839};\\\", \\\"{x:1414,y:547,t:1527026839847};\\\", \\\"{x:1414,y:535,t:1527026839857};\\\", \\\"{x:1414,y:513,t:1527026839874};\\\", \\\"{x:1414,y:495,t:1527026839891};\\\", \\\"{x:1414,y:481,t:1527026839907};\\\", \\\"{x:1414,y:471,t:1527026839924};\\\", \\\"{x:1415,y:464,t:1527026839941};\\\", \\\"{x:1415,y:458,t:1527026839957};\\\", \\\"{x:1415,y:453,t:1527026839974};\\\", \\\"{x:1415,y:450,t:1527026839991};\\\", \\\"{x:1415,y:449,t:1527026840013};\\\", \\\"{x:1415,y:448,t:1527026840246};\\\", \\\"{x:1415,y:446,t:1527026840258};\\\", \\\"{x:1409,y:441,t:1527026840275};\\\", \\\"{x:1397,y:436,t:1527026840291};\\\", \\\"{x:1388,y:435,t:1527026840308};\\\", \\\"{x:1385,y:434,t:1527026840323};\\\", \\\"{x:1384,y:433,t:1527026840340};\\\", \\\"{x:1381,y:433,t:1527026840357};\\\", \\\"{x:1371,y:435,t:1527026840373};\\\", \\\"{x:1359,y:440,t:1527026840391};\\\", \\\"{x:1344,y:446,t:1527026840407};\\\", \\\"{x:1333,y:452,t:1527026840424};\\\", \\\"{x:1325,y:458,t:1527026840441};\\\", \\\"{x:1322,y:462,t:1527026840458};\\\", \\\"{x:1316,y:475,t:1527026840474};\\\", \\\"{x:1313,y:486,t:1527026840491};\\\", \\\"{x:1311,y:495,t:1527026840508};\\\", \\\"{x:1309,y:497,t:1527026840523};\\\", \\\"{x:1309,y:498,t:1527026840540};\\\", \\\"{x:1309,y:499,t:1527026840557};\\\", \\\"{x:1309,y:502,t:1527026841016};\\\", \\\"{x:1309,y:512,t:1527026841025};\\\", \\\"{x:1311,y:528,t:1527026841042};\\\", \\\"{x:1314,y:538,t:1527026841059};\\\", \\\"{x:1316,y:545,t:1527026841075};\\\", \\\"{x:1318,y:552,t:1527026841092};\\\", \\\"{x:1319,y:557,t:1527026841108};\\\", \\\"{x:1321,y:565,t:1527026841125};\\\", \\\"{x:1324,y:586,t:1527026841142};\\\", \\\"{x:1326,y:601,t:1527026841158};\\\", \\\"{x:1326,y:615,t:1527026841175};\\\", \\\"{x:1326,y:629,t:1527026841192};\\\", \\\"{x:1326,y:641,t:1527026841208};\\\", \\\"{x:1326,y:655,t:1527026841225};\\\", \\\"{x:1326,y:666,t:1527026841241};\\\", \\\"{x:1325,y:675,t:1527026841258};\\\", \\\"{x:1322,y:685,t:1527026841276};\\\", \\\"{x:1318,y:696,t:1527026841292};\\\", \\\"{x:1314,y:710,t:1527026841309};\\\", \\\"{x:1310,y:723,t:1527026841325};\\\", \\\"{x:1301,y:751,t:1527026841342};\\\", \\\"{x:1294,y:766,t:1527026841359};\\\", \\\"{x:1288,y:776,t:1527026841375};\\\", \\\"{x:1287,y:778,t:1527026841392};\\\", \\\"{x:1286,y:780,t:1527026841408};\\\", \\\"{x:1286,y:781,t:1527026841425};\\\", \\\"{x:1286,y:785,t:1527026841442};\\\", \\\"{x:1286,y:791,t:1527026841458};\\\", \\\"{x:1286,y:795,t:1527026841476};\\\", \\\"{x:1288,y:799,t:1527026841492};\\\", \\\"{x:1289,y:799,t:1527026841573};\\\", \\\"{x:1291,y:801,t:1527026841589};\\\", \\\"{x:1292,y:804,t:1527026841597};\\\", \\\"{x:1293,y:806,t:1527026841609};\\\", \\\"{x:1293,y:809,t:1527026841625};\\\", \\\"{x:1293,y:812,t:1527026841642};\\\", \\\"{x:1293,y:817,t:1527026841659};\\\", \\\"{x:1291,y:820,t:1527026841674};\\\", \\\"{x:1290,y:823,t:1527026841691};\\\", \\\"{x:1289,y:825,t:1527026841709};\\\", \\\"{x:1287,y:826,t:1527026841725};\\\", \\\"{x:1284,y:828,t:1527026841742};\\\", \\\"{x:1282,y:829,t:1527026843037};\\\", \\\"{x:1277,y:831,t:1527026843045};\\\", \\\"{x:1272,y:832,t:1527026843060};\\\", \\\"{x:1255,y:834,t:1527026843075};\\\", \\\"{x:1235,y:834,t:1527026843093};\\\", \\\"{x:1207,y:836,t:1527026843109};\\\", \\\"{x:1199,y:836,t:1527026843126};\\\", \\\"{x:1195,y:836,t:1527026843143};\\\", \\\"{x:1194,y:836,t:1527026843159};\\\", \\\"{x:1193,y:836,t:1527026843213};\\\", \\\"{x:1192,y:836,t:1527026843613};\\\", \\\"{x:1189,y:836,t:1527026843627};\\\", \\\"{x:1184,y:836,t:1527026843642};\\\", \\\"{x:1158,y:835,t:1527026843660};\\\", \\\"{x:1138,y:835,t:1527026843676};\\\", \\\"{x:1123,y:835,t:1527026843693};\\\", \\\"{x:1098,y:838,t:1527026843710};\\\", \\\"{x:1066,y:840,t:1527026843726};\\\", \\\"{x:1038,y:840,t:1527026843744};\\\", \\\"{x:1012,y:840,t:1527026843760};\\\", \\\"{x:982,y:840,t:1527026843777};\\\", \\\"{x:954,y:840,t:1527026843794};\\\", \\\"{x:915,y:835,t:1527026843810};\\\", \\\"{x:893,y:830,t:1527026843826};\\\", \\\"{x:868,y:823,t:1527026843844};\\\", \\\"{x:848,y:816,t:1527026843860};\\\", \\\"{x:832,y:809,t:1527026843877};\\\", \\\"{x:806,y:799,t:1527026843894};\\\", \\\"{x:793,y:796,t:1527026843910};\\\", \\\"{x:783,y:793,t:1527026843926};\\\", \\\"{x:772,y:787,t:1527026843944};\\\", \\\"{x:762,y:782,t:1527026843960};\\\", \\\"{x:742,y:772,t:1527026843976};\\\", \\\"{x:712,y:761,t:1527026843993};\\\", \\\"{x:659,y:745,t:1527026844010};\\\", \\\"{x:617,y:733,t:1527026844027};\\\", \\\"{x:587,y:725,t:1527026844043};\\\", \\\"{x:567,y:722,t:1527026844059};\\\", \\\"{x:555,y:718,t:1527026844077};\\\", \\\"{x:554,y:717,t:1527026844094};\\\", \\\"{x:552,y:717,t:1527026844157};\\\", \\\"{x:552,y:718,t:1527026844165};\\\", \\\"{x:551,y:719,t:1527026844177};\\\", \\\"{x:549,y:721,t:1527026844193};\\\", \\\"{x:548,y:722,t:1527026844211};\\\", \\\"{x:548,y:724,t:1527026844227};\\\", \\\"{x:547,y:725,t:1527026844243};\\\", \\\"{x:547,y:726,t:1527026844260};\\\", \\\"{x:546,y:726,t:1527026844285};\\\", \\\"{x:545,y:725,t:1527026844390};\\\", \\\"{x:545,y:724,t:1527026844397};\\\", \\\"{x:545,y:723,t:1527026844411};\\\", \\\"{x:544,y:720,t:1527026844427};\\\", \\\"{x:543,y:719,t:1527026844443};\\\", \\\"{x:543,y:716,t:1527026846102};\\\", \\\"{x:549,y:709,t:1527026846112};\\\", \\\"{x:574,y:687,t:1527026846129};\\\", \\\"{x:607,y:658,t:1527026846145};\\\", \\\"{x:653,y:611,t:1527026846162};\\\", \\\"{x:697,y:565,t:1527026846179};\\\", \\\"{x:726,y:542,t:1527026846195};\\\", \\\"{x:756,y:520,t:1527026846212};\\\", \\\"{x:775,y:506,t:1527026846230};\\\", \\\"{x:785,y:497,t:1527026846245};\\\", \\\"{x:787,y:496,t:1527026846262};\\\", \\\"{x:788,y:495,t:1527026846279};\\\", \\\"{x:790,y:493,t:1527026846295};\\\", \\\"{x:792,y:490,t:1527026846312};\\\", \\\"{x:793,y:489,t:1527026846334};\\\", \\\"{x:794,y:487,t:1527026846382};\\\" ] }, { \\\"rt\\\": 32324, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 210515, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -H -K -K -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:797,y:488,t:1527026850326};\\\", \\\"{x:816,y:495,t:1527026850341};\\\", \\\"{x:826,y:499,t:1527026850349};\\\", \\\"{x:854,y:506,t:1527026850365};\\\", \\\"{x:898,y:513,t:1527026850381};\\\", \\\"{x:951,y:519,t:1527026850399};\\\", \\\"{x:999,y:521,t:1527026850415};\\\", \\\"{x:1057,y:521,t:1527026850432};\\\", \\\"{x:1143,y:521,t:1527026850449};\\\", \\\"{x:1146,y:521,t:1527026850465};\\\", \\\"{x:1149,y:521,t:1527026851014};\\\", \\\"{x:1156,y:519,t:1527026851022};\\\", \\\"{x:1166,y:518,t:1527026851032};\\\", \\\"{x:1181,y:520,t:1527026851050};\\\", \\\"{x:1202,y:520,t:1527026851069};\\\", \\\"{x:1217,y:520,t:1527026851083};\\\", \\\"{x:1228,y:520,t:1527026851099};\\\", \\\"{x:1234,y:520,t:1527026851117};\\\", \\\"{x:1235,y:520,t:1527026851133};\\\", \\\"{x:1237,y:520,t:1527026851223};\\\", \\\"{x:1239,y:519,t:1527026851234};\\\", \\\"{x:1244,y:517,t:1527026851249};\\\", \\\"{x:1249,y:515,t:1527026851268};\\\", \\\"{x:1258,y:512,t:1527026851284};\\\", \\\"{x:1267,y:510,t:1527026851299};\\\", \\\"{x:1273,y:508,t:1527026851317};\\\", \\\"{x:1276,y:507,t:1527026851334};\\\", \\\"{x:1277,y:506,t:1527026851374};\\\", \\\"{x:1278,y:506,t:1527026851384};\\\", \\\"{x:1283,y:503,t:1527026851400};\\\", \\\"{x:1288,y:500,t:1527026851417};\\\", \\\"{x:1291,y:499,t:1527026851433};\\\", \\\"{x:1292,y:498,t:1527026851478};\\\", \\\"{x:1293,y:498,t:1527026851502};\\\", \\\"{x:1295,y:497,t:1527026851517};\\\", \\\"{x:1296,y:496,t:1527026851534};\\\", \\\"{x:1297,y:496,t:1527026851774};\\\", \\\"{x:1299,y:496,t:1527026851798};\\\", \\\"{x:1301,y:496,t:1527026851814};\\\", \\\"{x:1303,y:496,t:1527026851830};\\\", \\\"{x:1305,y:497,t:1527026851839};\\\", \\\"{x:1307,y:498,t:1527026851851};\\\", \\\"{x:1309,y:499,t:1527026851870};\\\", \\\"{x:1309,y:500,t:1527026864360};\\\", \\\"{x:1309,y:513,t:1527026864377};\\\", \\\"{x:1309,y:526,t:1527026864394};\\\", \\\"{x:1310,y:544,t:1527026864410};\\\", \\\"{x:1311,y:553,t:1527026864427};\\\", \\\"{x:1312,y:558,t:1527026864444};\\\", \\\"{x:1312,y:559,t:1527026864460};\\\", \\\"{x:1314,y:557,t:1527026864558};\\\", \\\"{x:1317,y:550,t:1527026864566};\\\", \\\"{x:1320,y:542,t:1527026864577};\\\", \\\"{x:1326,y:529,t:1527026864594};\\\", \\\"{x:1333,y:519,t:1527026864611};\\\", \\\"{x:1338,y:513,t:1527026864627};\\\", \\\"{x:1340,y:511,t:1527026864644};\\\", \\\"{x:1340,y:516,t:1527026864734};\\\", \\\"{x:1341,y:527,t:1527026864744};\\\", \\\"{x:1345,y:549,t:1527026864761};\\\", \\\"{x:1346,y:569,t:1527026864777};\\\", \\\"{x:1346,y:577,t:1527026864794};\\\", \\\"{x:1346,y:581,t:1527026864811};\\\", \\\"{x:1347,y:582,t:1527026864827};\\\", \\\"{x:1348,y:581,t:1527026864886};\\\", \\\"{x:1350,y:577,t:1527026864894};\\\", \\\"{x:1355,y:568,t:1527026864911};\\\", \\\"{x:1365,y:557,t:1527026864927};\\\", \\\"{x:1376,y:550,t:1527026864944};\\\", \\\"{x:1382,y:546,t:1527026864961};\\\", \\\"{x:1385,y:545,t:1527026864976};\\\", \\\"{x:1389,y:544,t:1527026864993};\\\", \\\"{x:1396,y:544,t:1527026865011};\\\", \\\"{x:1404,y:544,t:1527026865027};\\\", \\\"{x:1407,y:544,t:1527026865043};\\\", \\\"{x:1407,y:543,t:1527026865134};\\\", \\\"{x:1407,y:542,t:1527026865144};\\\", \\\"{x:1406,y:539,t:1527026865161};\\\", \\\"{x:1405,y:537,t:1527026865177};\\\", \\\"{x:1404,y:539,t:1527026865222};\\\", \\\"{x:1404,y:547,t:1527026865230};\\\", \\\"{x:1404,y:557,t:1527026865244};\\\", \\\"{x:1404,y:568,t:1527026865261};\\\", \\\"{x:1404,y:575,t:1527026865277};\\\", \\\"{x:1404,y:576,t:1527026865294};\\\", \\\"{x:1405,y:574,t:1527026865358};\\\", \\\"{x:1408,y:567,t:1527026865366};\\\", \\\"{x:1416,y:558,t:1527026865378};\\\", \\\"{x:1432,y:541,t:1527026865394};\\\", \\\"{x:1446,y:529,t:1527026865411};\\\", \\\"{x:1454,y:525,t:1527026865428};\\\", \\\"{x:1456,y:524,t:1527026865444};\\\", \\\"{x:1457,y:525,t:1527026865477};\\\", \\\"{x:1463,y:543,t:1527026865493};\\\", \\\"{x:1467,y:561,t:1527026865510};\\\", \\\"{x:1468,y:565,t:1527026865527};\\\", \\\"{x:1469,y:567,t:1527026865544};\\\", \\\"{x:1470,y:567,t:1527026865589};\\\", \\\"{x:1471,y:567,t:1527026865597};\\\", \\\"{x:1472,y:566,t:1527026865614};\\\", \\\"{x:1473,y:565,t:1527026865628};\\\", \\\"{x:1477,y:563,t:1527026865645};\\\", \\\"{x:1480,y:561,t:1527026865661};\\\", \\\"{x:1485,y:561,t:1527026865678};\\\", \\\"{x:1489,y:564,t:1527026865695};\\\", \\\"{x:1491,y:573,t:1527026865710};\\\", \\\"{x:1492,y:584,t:1527026865727};\\\", \\\"{x:1488,y:593,t:1527026865745};\\\", \\\"{x:1486,y:599,t:1527026865760};\\\", \\\"{x:1483,y:602,t:1527026865777};\\\", \\\"{x:1482,y:602,t:1527026865794};\\\", \\\"{x:1484,y:598,t:1527026865893};\\\", \\\"{x:1490,y:592,t:1527026865901};\\\", \\\"{x:1496,y:584,t:1527026865911};\\\", \\\"{x:1508,y:566,t:1527026865927};\\\", \\\"{x:1519,y:550,t:1527026865945};\\\", \\\"{x:1524,y:545,t:1527026865961};\\\", \\\"{x:1526,y:544,t:1527026865978};\\\", \\\"{x:1526,y:545,t:1527026866022};\\\", \\\"{x:1526,y:549,t:1527026866030};\\\", \\\"{x:1526,y:553,t:1527026866045};\\\", \\\"{x:1526,y:567,t:1527026866061};\\\", \\\"{x:1537,y:589,t:1527026866077};\\\", \\\"{x:1540,y:593,t:1527026866095};\\\", \\\"{x:1541,y:593,t:1527026866141};\\\", \\\"{x:1543,y:589,t:1527026866150};\\\", \\\"{x:1544,y:586,t:1527026866163};\\\", \\\"{x:1551,y:573,t:1527026866178};\\\", \\\"{x:1560,y:558,t:1527026866195};\\\", \\\"{x:1569,y:544,t:1527026866212};\\\", \\\"{x:1574,y:535,t:1527026866228};\\\", \\\"{x:1576,y:532,t:1527026866245};\\\", \\\"{x:1576,y:531,t:1527026866262};\\\", \\\"{x:1578,y:532,t:1527026866366};\\\", \\\"{x:1578,y:535,t:1527026866378};\\\", \\\"{x:1588,y:549,t:1527026866395};\\\", \\\"{x:1616,y:575,t:1527026866412};\\\", \\\"{x:1639,y:592,t:1527026866428};\\\", \\\"{x:1644,y:597,t:1527026866446};\\\", \\\"{x:1644,y:599,t:1527026866462};\\\", \\\"{x:1642,y:601,t:1527026866480};\\\", \\\"{x:1632,y:606,t:1527026866495};\\\", \\\"{x:1629,y:607,t:1527026866512};\\\", \\\"{x:1627,y:607,t:1527026866529};\\\", \\\"{x:1617,y:602,t:1527026866544};\\\", \\\"{x:1599,y:575,t:1527026866562};\\\", \\\"{x:1591,y:556,t:1527026866579};\\\", \\\"{x:1591,y:545,t:1527026866595};\\\", \\\"{x:1598,y:536,t:1527026866612};\\\", \\\"{x:1606,y:530,t:1527026866629};\\\", \\\"{x:1619,y:524,t:1527026866645};\\\", \\\"{x:1645,y:519,t:1527026866661};\\\", \\\"{x:1652,y:518,t:1527026866678};\\\", \\\"{x:1653,y:518,t:1527026866694};\\\", \\\"{x:1653,y:519,t:1527026866733};\\\", \\\"{x:1648,y:525,t:1527026866745};\\\", \\\"{x:1636,y:541,t:1527026866761};\\\", \\\"{x:1623,y:560,t:1527026866779};\\\", \\\"{x:1593,y:586,t:1527026866795};\\\", \\\"{x:1561,y:603,t:1527026866812};\\\", \\\"{x:1526,y:615,t:1527026866829};\\\", \\\"{x:1497,y:617,t:1527026866845};\\\", \\\"{x:1462,y:624,t:1527026866862};\\\", \\\"{x:1449,y:628,t:1527026866879};\\\", \\\"{x:1438,y:634,t:1527026866895};\\\", \\\"{x:1434,y:640,t:1527026866912};\\\", \\\"{x:1430,y:645,t:1527026866929};\\\", \\\"{x:1417,y:655,t:1527026866946};\\\", \\\"{x:1416,y:656,t:1527026866990};\\\", \\\"{x:1417,y:657,t:1527026866998};\\\", \\\"{x:1419,y:658,t:1527026867012};\\\", \\\"{x:1425,y:660,t:1527026867029};\\\", \\\"{x:1430,y:666,t:1527026867046};\\\", \\\"{x:1430,y:668,t:1527026867062};\\\", \\\"{x:1431,y:669,t:1527026867079};\\\", \\\"{x:1431,y:675,t:1527026867097};\\\", \\\"{x:1431,y:680,t:1527026867113};\\\", \\\"{x:1431,y:684,t:1527026867129};\\\", \\\"{x:1431,y:687,t:1527026867146};\\\", \\\"{x:1431,y:688,t:1527026867162};\\\", \\\"{x:1431,y:689,t:1527026867182};\\\", \\\"{x:1434,y:690,t:1527026867198};\\\", \\\"{x:1439,y:691,t:1527026867212};\\\", \\\"{x:1454,y:691,t:1527026867229};\\\", \\\"{x:1485,y:691,t:1527026867246};\\\", \\\"{x:1502,y:690,t:1527026867263};\\\", \\\"{x:1509,y:689,t:1527026867279};\\\", \\\"{x:1510,y:689,t:1527026867296};\\\", \\\"{x:1511,y:689,t:1527026867312};\\\", \\\"{x:1511,y:686,t:1527026867486};\\\", \\\"{x:1511,y:680,t:1527026867497};\\\", \\\"{x:1511,y:664,t:1527026867513};\\\", \\\"{x:1511,y:643,t:1527026867529};\\\", \\\"{x:1511,y:631,t:1527026867546};\\\", \\\"{x:1511,y:629,t:1527026867563};\\\", \\\"{x:1512,y:626,t:1527026867579};\\\", \\\"{x:1513,y:626,t:1527026867596};\\\", \\\"{x:1513,y:624,t:1527026867614};\\\", \\\"{x:1513,y:623,t:1527026867629};\\\", \\\"{x:1514,y:622,t:1527026867646};\\\", \\\"{x:1514,y:624,t:1527026867902};\\\", \\\"{x:1514,y:629,t:1527026867913};\\\", \\\"{x:1512,y:641,t:1527026867931};\\\", \\\"{x:1511,y:651,t:1527026867945};\\\", \\\"{x:1510,y:661,t:1527026867963};\\\", \\\"{x:1509,y:669,t:1527026867979};\\\", \\\"{x:1508,y:678,t:1527026867995};\\\", \\\"{x:1508,y:688,t:1527026868013};\\\", \\\"{x:1508,y:706,t:1527026868029};\\\", \\\"{x:1507,y:716,t:1527026868045};\\\", \\\"{x:1507,y:723,t:1527026868062};\\\", \\\"{x:1507,y:733,t:1527026868080};\\\", \\\"{x:1507,y:745,t:1527026868096};\\\", \\\"{x:1507,y:755,t:1527026868113};\\\", \\\"{x:1507,y:762,t:1527026868130};\\\", \\\"{x:1507,y:771,t:1527026868146};\\\", \\\"{x:1509,y:781,t:1527026868163};\\\", \\\"{x:1512,y:793,t:1527026868179};\\\", \\\"{x:1513,y:804,t:1527026868196};\\\", \\\"{x:1514,y:809,t:1527026868213};\\\", \\\"{x:1514,y:820,t:1527026868229};\\\", \\\"{x:1514,y:824,t:1527026868247};\\\", \\\"{x:1516,y:831,t:1527026868263};\\\", \\\"{x:1516,y:835,t:1527026868280};\\\", \\\"{x:1517,y:840,t:1527026868298};\\\", \\\"{x:1517,y:846,t:1527026868313};\\\", \\\"{x:1517,y:850,t:1527026868330};\\\", \\\"{x:1517,y:853,t:1527026868347};\\\", \\\"{x:1517,y:858,t:1527026868363};\\\", \\\"{x:1517,y:862,t:1527026868380};\\\", \\\"{x:1517,y:866,t:1527026868398};\\\", \\\"{x:1517,y:868,t:1527026868413};\\\", \\\"{x:1517,y:877,t:1527026868430};\\\", \\\"{x:1517,y:883,t:1527026868447};\\\", \\\"{x:1517,y:890,t:1527026868463};\\\", \\\"{x:1517,y:893,t:1527026868481};\\\", \\\"{x:1517,y:895,t:1527026868497};\\\", \\\"{x:1517,y:897,t:1527026868514};\\\", \\\"{x:1517,y:898,t:1527026868530};\\\", \\\"{x:1517,y:900,t:1527026868547};\\\", \\\"{x:1516,y:900,t:1527026868563};\\\", \\\"{x:1516,y:901,t:1527026868580};\\\", \\\"{x:1515,y:903,t:1527026868597};\\\", \\\"{x:1515,y:907,t:1527026868613};\\\", \\\"{x:1514,y:908,t:1527026868630};\\\", \\\"{x:1513,y:908,t:1527026868647};\\\", \\\"{x:1513,y:910,t:1527026868664};\\\", \\\"{x:1513,y:911,t:1527026868680};\\\", \\\"{x:1512,y:913,t:1527026868710};\\\", \\\"{x:1512,y:914,t:1527026868734};\\\", \\\"{x:1511,y:916,t:1527026868750};\\\", \\\"{x:1510,y:917,t:1527026868764};\\\", \\\"{x:1510,y:919,t:1527026868780};\\\", \\\"{x:1509,y:921,t:1527026868798};\\\", \\\"{x:1507,y:924,t:1527026868814};\\\", \\\"{x:1507,y:926,t:1527026868830};\\\", \\\"{x:1507,y:928,t:1527026868848};\\\", \\\"{x:1506,y:930,t:1527026868865};\\\", \\\"{x:1504,y:932,t:1527026868880};\\\", \\\"{x:1503,y:933,t:1527026868898};\\\", \\\"{x:1502,y:937,t:1527026868914};\\\", \\\"{x:1501,y:940,t:1527026868930};\\\", \\\"{x:1500,y:942,t:1527026868947};\\\", \\\"{x:1497,y:945,t:1527026868964};\\\", \\\"{x:1495,y:947,t:1527026868981};\\\", \\\"{x:1493,y:949,t:1527026868998};\\\", \\\"{x:1492,y:951,t:1527026869014};\\\", \\\"{x:1490,y:953,t:1527026869031};\\\", \\\"{x:1488,y:955,t:1527026869047};\\\", \\\"{x:1486,y:957,t:1527026869064};\\\", \\\"{x:1485,y:958,t:1527026869081};\\\", \\\"{x:1482,y:960,t:1527026869097};\\\", \\\"{x:1480,y:961,t:1527026869114};\\\", \\\"{x:1476,y:963,t:1527026869132};\\\", \\\"{x:1474,y:964,t:1527026869147};\\\", \\\"{x:1473,y:964,t:1527026869164};\\\", \\\"{x:1472,y:966,t:1527026869181};\\\", \\\"{x:1472,y:965,t:1527026869391};\\\", \\\"{x:1472,y:964,t:1527026869406};\\\", \\\"{x:1474,y:962,t:1527026869422};\\\", \\\"{x:1475,y:959,t:1527026869432};\\\", \\\"{x:1478,y:957,t:1527026869447};\\\", \\\"{x:1479,y:957,t:1527026869465};\\\", \\\"{x:1480,y:955,t:1527026869482};\\\", \\\"{x:1480,y:954,t:1527026869497};\\\", \\\"{x:1480,y:953,t:1527026869574};\\\", \\\"{x:1481,y:953,t:1527026869582};\\\", \\\"{x:1480,y:953,t:1527026877622};\\\", \\\"{x:1441,y:945,t:1527026877638};\\\", \\\"{x:1359,y:928,t:1527026877654};\\\", \\\"{x:1259,y:915,t:1527026877670};\\\", \\\"{x:1156,y:909,t:1527026877687};\\\", \\\"{x:1070,y:909,t:1527026877704};\\\", \\\"{x:992,y:909,t:1527026877720};\\\", \\\"{x:938,y:907,t:1527026877737};\\\", \\\"{x:909,y:903,t:1527026877754};\\\", \\\"{x:888,y:897,t:1527026877770};\\\", \\\"{x:875,y:892,t:1527026877787};\\\", \\\"{x:867,y:889,t:1527026877804};\\\", \\\"{x:864,y:888,t:1527026877820};\\\", \\\"{x:863,y:885,t:1527026877837};\\\", \\\"{x:859,y:881,t:1527026877855};\\\", \\\"{x:853,y:872,t:1527026877870};\\\", \\\"{x:841,y:853,t:1527026877888};\\\", \\\"{x:828,y:837,t:1527026877905};\\\", \\\"{x:816,y:818,t:1527026877922};\\\", \\\"{x:804,y:805,t:1527026877937};\\\", \\\"{x:793,y:792,t:1527026877954};\\\", \\\"{x:776,y:777,t:1527026877971};\\\", \\\"{x:747,y:757,t:1527026877987};\\\", \\\"{x:719,y:738,t:1527026878005};\\\", \\\"{x:666,y:720,t:1527026878022};\\\", \\\"{x:641,y:715,t:1527026878037};\\\", \\\"{x:624,y:707,t:1527026878054};\\\", \\\"{x:602,y:698,t:1527026878072};\\\", \\\"{x:591,y:693,t:1527026878088};\\\", \\\"{x:583,y:691,t:1527026878104};\\\", \\\"{x:583,y:689,t:1527026878182};\\\", \\\"{x:586,y:689,t:1527026878190};\\\", \\\"{x:591,y:687,t:1527026878204};\\\", \\\"{x:611,y:682,t:1527026878221};\\\", \\\"{x:622,y:679,t:1527026878237};\\\", \\\"{x:625,y:677,t:1527026878255};\\\", \\\"{x:627,y:676,t:1527026878272};\\\", \\\"{x:627,y:675,t:1527026878301};\\\", \\\"{x:626,y:675,t:1527026878326};\\\", \\\"{x:625,y:674,t:1527026878337};\\\", \\\"{x:624,y:674,t:1527026878354};\\\", \\\"{x:621,y:672,t:1527026878372};\\\", \\\"{x:617,y:669,t:1527026878389};\\\", \\\"{x:610,y:664,t:1527026878406};\\\", \\\"{x:606,y:661,t:1527026878421};\\\", \\\"{x:606,y:659,t:1527026878469};\\\", \\\"{x:606,y:658,t:1527026878484};\\\", \\\"{x:606,y:657,t:1527026878565};\\\", \\\"{x:606,y:657,t:1527026878637};\\\", \\\"{x:605,y:656,t:1527026878717};\\\", \\\"{x:603,y:656,t:1527026878732};\\\", \\\"{x:602,y:658,t:1527026878741};\\\", \\\"{x:601,y:660,t:1527026878754};\\\", \\\"{x:598,y:667,t:1527026878772};\\\", \\\"{x:594,y:680,t:1527026878788};\\\", \\\"{x:588,y:698,t:1527026878804};\\\", \\\"{x:584,y:704,t:1527026878822};\\\", \\\"{x:582,y:708,t:1527026878838};\\\", \\\"{x:579,y:712,t:1527026878855};\\\", \\\"{x:574,y:717,t:1527026878871};\\\", \\\"{x:567,y:720,t:1527026878889};\\\", \\\"{x:559,y:723,t:1527026878909};\\\", \\\"{x:556,y:725,t:1527026878922};\\\", \\\"{x:551,y:726,t:1527026878938};\\\", \\\"{x:548,y:727,t:1527026878955};\\\", \\\"{x:546,y:728,t:1527026878972};\\\", \\\"{x:545,y:728,t:1527026878988};\\\", \\\"{x:544,y:729,t:1527026879013};\\\", \\\"{x:545,y:729,t:1527026879333};\\\", \\\"{x:547,y:729,t:1527026879341};\\\", \\\"{x:549,y:729,t:1527026879355};\\\", \\\"{x:556,y:725,t:1527026879372};\\\", \\\"{x:572,y:716,t:1527026879389};\\\", \\\"{x:585,y:704,t:1527026879405};\\\", \\\"{x:589,y:700,t:1527026879422};\\\", \\\"{x:587,y:698,t:1527026879806};\\\", \\\"{x:584,y:698,t:1527026879822};\\\", \\\"{x:582,y:698,t:1527026879839};\\\", \\\"{x:581,y:698,t:1527026879857};\\\", \\\"{x:579,y:698,t:1527026879873};\\\", \\\"{x:576,y:696,t:1527026879889};\\\", \\\"{x:569,y:691,t:1527026879906};\\\", \\\"{x:562,y:687,t:1527026879922};\\\", \\\"{x:557,y:684,t:1527026879939};\\\", \\\"{x:550,y:680,t:1527026879957};\\\", \\\"{x:544,y:675,t:1527026879972};\\\", \\\"{x:534,y:668,t:1527026879989};\\\", \\\"{x:530,y:664,t:1527026880006};\\\", \\\"{x:527,y:660,t:1527026880023};\\\", \\\"{x:524,y:652,t:1527026880039};\\\", \\\"{x:520,y:646,t:1527026880056};\\\", \\\"{x:520,y:644,t:1527026880073};\\\", \\\"{x:519,y:642,t:1527026880089};\\\", \\\"{x:519,y:641,t:1527026880106};\\\" ] }, { \\\"rt\\\": 7052, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 218798, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:640,t:1527026881077};\\\", \\\"{x:525,y:637,t:1527026881091};\\\", \\\"{x:539,y:631,t:1527026881107};\\\", \\\"{x:554,y:627,t:1527026881123};\\\", \\\"{x:566,y:626,t:1527026881140};\\\", \\\"{x:586,y:625,t:1527026881156};\\\", \\\"{x:634,y:622,t:1527026881173};\\\", \\\"{x:695,y:621,t:1527026881190};\\\", \\\"{x:771,y:621,t:1527026881208};\\\", \\\"{x:775,y:620,t:1527026881222};\\\", \\\"{x:776,y:619,t:1527026881726};\\\", \\\"{x:776,y:618,t:1527026881740};\\\", \\\"{x:778,y:617,t:1527026881765};\\\", \\\"{x:783,y:616,t:1527026881782};\\\", \\\"{x:791,y:613,t:1527026881790};\\\", \\\"{x:814,y:610,t:1527026881807};\\\", \\\"{x:838,y:605,t:1527026881824};\\\", \\\"{x:867,y:601,t:1527026881840};\\\", \\\"{x:911,y:595,t:1527026881857};\\\", \\\"{x:967,y:587,t:1527026881874};\\\", \\\"{x:1050,y:575,t:1527026881890};\\\", \\\"{x:1142,y:564,t:1527026881907};\\\", \\\"{x:1217,y:562,t:1527026881924};\\\", \\\"{x:1312,y:562,t:1527026881940};\\\", \\\"{x:1335,y:562,t:1527026881957};\\\", \\\"{x:1341,y:562,t:1527026881974};\\\", \\\"{x:1343,y:562,t:1527026881992};\\\", \\\"{x:1342,y:562,t:1527026882029};\\\", \\\"{x:1341,y:562,t:1527026882042};\\\", \\\"{x:1337,y:560,t:1527026882057};\\\", \\\"{x:1330,y:556,t:1527026882074};\\\", \\\"{x:1320,y:550,t:1527026882092};\\\", \\\"{x:1306,y:546,t:1527026882107};\\\", \\\"{x:1285,y:541,t:1527026882124};\\\", \\\"{x:1255,y:539,t:1527026882141};\\\", \\\"{x:1241,y:539,t:1527026882157};\\\", \\\"{x:1224,y:542,t:1527026882174};\\\", \\\"{x:1216,y:546,t:1527026882191};\\\", \\\"{x:1213,y:548,t:1527026882207};\\\", \\\"{x:1212,y:549,t:1527026882224};\\\", \\\"{x:1212,y:550,t:1527026882241};\\\", \\\"{x:1214,y:552,t:1527026882257};\\\", \\\"{x:1216,y:553,t:1527026882275};\\\", \\\"{x:1220,y:553,t:1527026882292};\\\", \\\"{x:1227,y:553,t:1527026882308};\\\", \\\"{x:1239,y:553,t:1527026882325};\\\", \\\"{x:1256,y:553,t:1527026882341};\\\", \\\"{x:1267,y:553,t:1527026882358};\\\", \\\"{x:1273,y:553,t:1527026882374};\\\", \\\"{x:1279,y:553,t:1527026882392};\\\", \\\"{x:1280,y:553,t:1527026882407};\\\", \\\"{x:1279,y:553,t:1527026882446};\\\", \\\"{x:1275,y:554,t:1527026882460};\\\", \\\"{x:1259,y:558,t:1527026882475};\\\", \\\"{x:1238,y:564,t:1527026882492};\\\", \\\"{x:1216,y:569,t:1527026882509};\\\", \\\"{x:1191,y:581,t:1527026882525};\\\", \\\"{x:1113,y:614,t:1527026882541};\\\", \\\"{x:1066,y:636,t:1527026882559};\\\", \\\"{x:1030,y:649,t:1527026882575};\\\", \\\"{x:1007,y:656,t:1527026882592};\\\", \\\"{x:987,y:663,t:1527026882609};\\\", \\\"{x:963,y:672,t:1527026882625};\\\", \\\"{x:941,y:672,t:1527026882642};\\\", \\\"{x:908,y:669,t:1527026882658};\\\", \\\"{x:875,y:669,t:1527026882675};\\\", \\\"{x:844,y:669,t:1527026882691};\\\", \\\"{x:816,y:669,t:1527026882709};\\\", \\\"{x:791,y:665,t:1527026882724};\\\", \\\"{x:757,y:655,t:1527026882741};\\\", \\\"{x:735,y:647,t:1527026882759};\\\", \\\"{x:719,y:637,t:1527026882775};\\\", \\\"{x:711,y:632,t:1527026882792};\\\", \\\"{x:707,y:628,t:1527026882809};\\\", \\\"{x:703,y:624,t:1527026882825};\\\", \\\"{x:700,y:616,t:1527026882841};\\\", \\\"{x:695,y:607,t:1527026882858};\\\", \\\"{x:690,y:596,t:1527026882875};\\\", \\\"{x:684,y:589,t:1527026882892};\\\", \\\"{x:670,y:579,t:1527026882908};\\\", \\\"{x:652,y:565,t:1527026882925};\\\", \\\"{x:643,y:558,t:1527026882942};\\\", \\\"{x:639,y:556,t:1527026882958};\\\", \\\"{x:636,y:551,t:1527026882975};\\\", \\\"{x:631,y:545,t:1527026882992};\\\", \\\"{x:629,y:541,t:1527026883008};\\\", \\\"{x:628,y:539,t:1527026883025};\\\", \\\"{x:627,y:535,t:1527026883041};\\\", \\\"{x:626,y:534,t:1527026883058};\\\", \\\"{x:624,y:531,t:1527026883075};\\\", \\\"{x:623,y:528,t:1527026883091};\\\", \\\"{x:623,y:523,t:1527026883109};\\\", \\\"{x:622,y:521,t:1527026883125};\\\", \\\"{x:622,y:519,t:1527026883141};\\\", \\\"{x:621,y:518,t:1527026883158};\\\", \\\"{x:620,y:517,t:1527026883197};\\\", \\\"{x:619,y:517,t:1527026883237};\\\", \\\"{x:617,y:515,t:1527026883253};\\\", \\\"{x:616,y:515,t:1527026883261};\\\", \\\"{x:615,y:514,t:1527026883285};\\\", \\\"{x:615,y:512,t:1527026883510};\\\", \\\"{x:616,y:512,t:1527026883525};\\\", \\\"{x:623,y:513,t:1527026883543};\\\", \\\"{x:646,y:519,t:1527026883558};\\\", \\\"{x:681,y:530,t:1527026883576};\\\", \\\"{x:704,y:537,t:1527026883592};\\\", \\\"{x:718,y:538,t:1527026883608};\\\", \\\"{x:728,y:540,t:1527026883626};\\\", \\\"{x:731,y:540,t:1527026883642};\\\", \\\"{x:733,y:540,t:1527026883659};\\\", \\\"{x:739,y:541,t:1527026883675};\\\", \\\"{x:756,y:544,t:1527026883692};\\\", \\\"{x:771,y:546,t:1527026883708};\\\", \\\"{x:775,y:546,t:1527026883725};\\\", \\\"{x:781,y:547,t:1527026883742};\\\", \\\"{x:787,y:548,t:1527026883759};\\\", \\\"{x:798,y:548,t:1527026883776};\\\", \\\"{x:809,y:548,t:1527026883792};\\\", \\\"{x:813,y:548,t:1527026883810};\\\", \\\"{x:815,y:548,t:1527026883825};\\\", \\\"{x:816,y:548,t:1527026883870};\\\", \\\"{x:817,y:548,t:1527026883878};\\\", \\\"{x:818,y:546,t:1527026883892};\\\", \\\"{x:820,y:544,t:1527026883910};\\\", \\\"{x:822,y:543,t:1527026883926};\\\", \\\"{x:822,y:542,t:1527026883966};\\\", \\\"{x:822,y:540,t:1527026883976};\\\", \\\"{x:811,y:533,t:1527026883992};\\\", \\\"{x:791,y:524,t:1527026884011};\\\", \\\"{x:770,y:517,t:1527026884028};\\\", \\\"{x:755,y:510,t:1527026884042};\\\", \\\"{x:746,y:508,t:1527026884059};\\\", \\\"{x:738,y:507,t:1527026884075};\\\", \\\"{x:735,y:507,t:1527026884093};\\\", \\\"{x:730,y:506,t:1527026884109};\\\", \\\"{x:727,y:504,t:1527026884125};\\\", \\\"{x:724,y:504,t:1527026884142};\\\", \\\"{x:721,y:504,t:1527026884160};\\\", \\\"{x:720,y:504,t:1527026884176};\\\", \\\"{x:719,y:504,t:1527026884193};\\\", \\\"{x:713,y:504,t:1527026884210};\\\", \\\"{x:705,y:504,t:1527026884226};\\\", \\\"{x:700,y:503,t:1527026884242};\\\", \\\"{x:694,y:502,t:1527026884259};\\\", \\\"{x:694,y:501,t:1527026884285};\\\", \\\"{x:693,y:501,t:1527026884292};\\\", \\\"{x:680,y:500,t:1527026884309};\\\", \\\"{x:675,y:500,t:1527026884326};\\\", \\\"{x:670,y:500,t:1527026884343};\\\", \\\"{x:669,y:500,t:1527026884365};\\\", \\\"{x:667,y:500,t:1527026884389};\\\", \\\"{x:662,y:500,t:1527026884397};\\\", \\\"{x:655,y:500,t:1527026884410};\\\", \\\"{x:645,y:500,t:1527026884426};\\\", \\\"{x:640,y:500,t:1527026884443};\\\", \\\"{x:637,y:500,t:1527026884459};\\\", \\\"{x:636,y:500,t:1527026884476};\\\", \\\"{x:637,y:501,t:1527026884644};\\\", \\\"{x:638,y:502,t:1527026884669};\\\", \\\"{x:639,y:502,t:1527026884677};\\\", \\\"{x:643,y:504,t:1527026884692};\\\", \\\"{x:652,y:505,t:1527026884710};\\\", \\\"{x:672,y:509,t:1527026884726};\\\", \\\"{x:692,y:511,t:1527026884743};\\\", \\\"{x:703,y:513,t:1527026884759};\\\", \\\"{x:704,y:514,t:1527026884797};\\\", \\\"{x:706,y:514,t:1527026884809};\\\", \\\"{x:716,y:515,t:1527026884827};\\\", \\\"{x:730,y:518,t:1527026884844};\\\", \\\"{x:739,y:518,t:1527026884859};\\\", \\\"{x:744,y:518,t:1527026884876};\\\", \\\"{x:752,y:519,t:1527026884893};\\\", \\\"{x:759,y:522,t:1527026884909};\\\", \\\"{x:773,y:523,t:1527026884926};\\\", \\\"{x:790,y:525,t:1527026884944};\\\", \\\"{x:799,y:527,t:1527026884959};\\\", \\\"{x:800,y:527,t:1527026884976};\\\", \\\"{x:803,y:529,t:1527026885094};\\\", \\\"{x:806,y:530,t:1527026885111};\\\", \\\"{x:811,y:532,t:1527026885127};\\\", \\\"{x:820,y:536,t:1527026885144};\\\", \\\"{x:829,y:539,t:1527026885161};\\\", \\\"{x:834,y:540,t:1527026885176};\\\", \\\"{x:836,y:540,t:1527026885193};\\\", \\\"{x:836,y:541,t:1527026885429};\\\", \\\"{x:836,y:544,t:1527026885443};\\\", \\\"{x:836,y:555,t:1527026885461};\\\", \\\"{x:828,y:582,t:1527026885478};\\\", \\\"{x:817,y:604,t:1527026885494};\\\", \\\"{x:806,y:624,t:1527026885510};\\\", \\\"{x:797,y:636,t:1527026885528};\\\", \\\"{x:787,y:645,t:1527026885543};\\\", \\\"{x:773,y:657,t:1527026885560};\\\", \\\"{x:754,y:672,t:1527026885577};\\\", \\\"{x:717,y:696,t:1527026885594};\\\", \\\"{x:697,y:713,t:1527026885610};\\\", \\\"{x:688,y:722,t:1527026885627};\\\", \\\"{x:684,y:722,t:1527026885644};\\\", \\\"{x:672,y:726,t:1527026885661};\\\", \\\"{x:665,y:730,t:1527026885677};\\\", \\\"{x:665,y:728,t:1527026885726};\\\", \\\"{x:665,y:727,t:1527026885741};\\\", \\\"{x:665,y:725,t:1527026885749};\\\", \\\"{x:665,y:724,t:1527026885797};\\\", \\\"{x:665,y:723,t:1527026885813};\\\", \\\"{x:665,y:722,t:1527026885827};\\\", \\\"{x:664,y:721,t:1527026885854};\\\", \\\"{x:663,y:721,t:1527026885878};\\\", \\\"{x:662,y:722,t:1527026885893};\\\", \\\"{x:660,y:723,t:1527026885909};\\\", \\\"{x:659,y:723,t:1527026885927};\\\", \\\"{x:654,y:725,t:1527026885943};\\\", \\\"{x:642,y:729,t:1527026885960};\\\", \\\"{x:626,y:734,t:1527026885977};\\\", \\\"{x:610,y:738,t:1527026885994};\\\", \\\"{x:591,y:742,t:1527026886009};\\\", \\\"{x:569,y:744,t:1527026886026};\\\", \\\"{x:544,y:745,t:1527026886044};\\\", \\\"{x:514,y:747,t:1527026886060};\\\", \\\"{x:483,y:747,t:1527026886077};\\\", \\\"{x:470,y:747,t:1527026886095};\\\", \\\"{x:468,y:747,t:1527026886112};\\\", \\\"{x:467,y:747,t:1527026886141};\\\", \\\"{x:467,y:746,t:1527026887691};\\\", \\\"{x:467,y:745,t:1527026888201};\\\" ] }, { \\\"rt\\\": 13664, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 233661, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:467,y:744,t:1527026889411};\\\", \\\"{x:468,y:743,t:1527026889466};\\\", \\\"{x:468,y:742,t:1527026889546};\\\", \\\"{x:468,y:741,t:1527026889570};\\\", \\\"{x:468,y:740,t:1527026889627};\\\", \\\"{x:469,y:739,t:1527026889634};\\\", \\\"{x:469,y:737,t:1527026889650};\\\", \\\"{x:470,y:736,t:1527026889661};\\\", \\\"{x:472,y:731,t:1527026889678};\\\", \\\"{x:478,y:724,t:1527026889695};\\\", \\\"{x:490,y:714,t:1527026889712};\\\", \\\"{x:512,y:695,t:1527026889728};\\\", \\\"{x:536,y:670,t:1527026889744};\\\", \\\"{x:551,y:659,t:1527026889761};\\\", \\\"{x:579,y:649,t:1527026889778};\\\", \\\"{x:604,y:644,t:1527026889794};\\\", \\\"{x:644,y:636,t:1527026889811};\\\", \\\"{x:645,y:635,t:1527026889828};\\\", \\\"{x:645,y:633,t:1527026889845};\\\", \\\"{x:644,y:633,t:1527026890332};\\\", \\\"{x:643,y:633,t:1527026890345};\\\", \\\"{x:641,y:633,t:1527026890362};\\\", \\\"{x:645,y:632,t:1527026892779};\\\", \\\"{x:666,y:630,t:1527026892799};\\\", \\\"{x:704,y:630,t:1527026892813};\\\", \\\"{x:765,y:630,t:1527026892830};\\\", \\\"{x:848,y:639,t:1527026892847};\\\", \\\"{x:942,y:648,t:1527026892864};\\\", \\\"{x:1047,y:660,t:1527026892880};\\\", \\\"{x:1150,y:678,t:1527026892897};\\\", \\\"{x:1296,y:697,t:1527026892914};\\\", \\\"{x:1360,y:707,t:1527026892930};\\\", \\\"{x:1386,y:709,t:1527026892947};\\\", \\\"{x:1386,y:710,t:1527026892964};\\\", \\\"{x:1387,y:710,t:1527026892981};\\\", \\\"{x:1386,y:710,t:1527026893555};\\\", \\\"{x:1385,y:710,t:1527026893571};\\\", \\\"{x:1383,y:709,t:1527026893587};\\\", \\\"{x:1381,y:708,t:1527026893603};\\\", \\\"{x:1380,y:708,t:1527026893635};\\\", \\\"{x:1379,y:708,t:1527026893651};\\\", \\\"{x:1378,y:707,t:1527026893665};\\\", \\\"{x:1377,y:706,t:1527026893682};\\\", \\\"{x:1374,y:706,t:1527026893698};\\\", \\\"{x:1368,y:704,t:1527026893715};\\\", \\\"{x:1366,y:703,t:1527026893731};\\\", \\\"{x:1365,y:703,t:1527026893763};\\\", \\\"{x:1364,y:702,t:1527026893779};\\\", \\\"{x:1363,y:702,t:1527026893787};\\\", \\\"{x:1362,y:702,t:1527026893811};\\\", \\\"{x:1361,y:702,t:1527026896667};\\\", \\\"{x:1357,y:712,t:1527026896683};\\\", \\\"{x:1356,y:721,t:1527026896700};\\\", \\\"{x:1356,y:727,t:1527026896717};\\\", \\\"{x:1355,y:732,t:1527026896734};\\\", \\\"{x:1354,y:735,t:1527026896751};\\\", \\\"{x:1354,y:740,t:1527026896767};\\\", \\\"{x:1354,y:745,t:1527026896784};\\\", \\\"{x:1354,y:750,t:1527026896800};\\\", \\\"{x:1354,y:754,t:1527026896818};\\\", \\\"{x:1354,y:759,t:1527026896833};\\\", \\\"{x:1354,y:764,t:1527026896849};\\\", \\\"{x:1354,y:766,t:1527026896867};\\\", \\\"{x:1354,y:767,t:1527026896883};\\\", \\\"{x:1354,y:768,t:1527026896900};\\\", \\\"{x:1350,y:773,t:1527026898619};\\\", \\\"{x:1336,y:778,t:1527026898635};\\\", \\\"{x:1334,y:778,t:1527026898652};\\\", \\\"{x:1332,y:777,t:1527026899282};\\\", \\\"{x:1328,y:775,t:1527026899290};\\\", \\\"{x:1324,y:773,t:1527026899303};\\\", \\\"{x:1313,y:768,t:1527026899318};\\\", \\\"{x:1298,y:763,t:1527026899335};\\\", \\\"{x:1285,y:760,t:1527026899353};\\\", \\\"{x:1270,y:757,t:1527026899368};\\\", \\\"{x:1252,y:754,t:1527026899385};\\\", \\\"{x:1207,y:746,t:1527026899402};\\\", \\\"{x:1136,y:734,t:1527026899419};\\\", \\\"{x:1041,y:715,t:1527026899435};\\\", \\\"{x:924,y:694,t:1527026899453};\\\", \\\"{x:795,y:686,t:1527026899469};\\\", \\\"{x:671,y:675,t:1527026899486};\\\", \\\"{x:549,y:673,t:1527026899503};\\\", \\\"{x:412,y:663,t:1527026899521};\\\", \\\"{x:308,y:655,t:1527026899536};\\\", \\\"{x:260,y:647,t:1527026899553};\\\", \\\"{x:245,y:641,t:1527026899561};\\\", \\\"{x:233,y:635,t:1527026899577};\\\", \\\"{x:231,y:630,t:1527026899594};\\\", \\\"{x:241,y:619,t:1527026899620};\\\", \\\"{x:259,y:609,t:1527026899635};\\\", \\\"{x:281,y:601,t:1527026899653};\\\", \\\"{x:321,y:590,t:1527026899670};\\\", \\\"{x:356,y:583,t:1527026899685};\\\", \\\"{x:381,y:578,t:1527026899703};\\\", \\\"{x:397,y:573,t:1527026899719};\\\", \\\"{x:401,y:570,t:1527026899735};\\\", \\\"{x:402,y:568,t:1527026899753};\\\", \\\"{x:401,y:566,t:1527026899810};\\\", \\\"{x:400,y:565,t:1527026899924};\\\", \\\"{x:399,y:565,t:1527026899936};\\\", \\\"{x:396,y:565,t:1527026899952};\\\", \\\"{x:393,y:565,t:1527026899969};\\\", \\\"{x:382,y:564,t:1527026899986};\\\", \\\"{x:376,y:562,t:1527026900003};\\\", \\\"{x:373,y:561,t:1527026900019};\\\", \\\"{x:372,y:561,t:1527026900049};\\\", \\\"{x:372,y:560,t:1527026900058};\\\", \\\"{x:372,y:559,t:1527026900069};\\\", \\\"{x:374,y:557,t:1527026900086};\\\", \\\"{x:382,y:554,t:1527026900103};\\\", \\\"{x:391,y:550,t:1527026900120};\\\", \\\"{x:397,y:549,t:1527026900137};\\\", \\\"{x:412,y:549,t:1527026900152};\\\", \\\"{x:441,y:549,t:1527026900170};\\\", \\\"{x:522,y:549,t:1527026900187};\\\", \\\"{x:600,y:549,t:1527026900204};\\\", \\\"{x:667,y:549,t:1527026900220};\\\", \\\"{x:728,y:549,t:1527026900237};\\\", \\\"{x:770,y:544,t:1527026900254};\\\", \\\"{x:795,y:539,t:1527026900270};\\\", \\\"{x:809,y:538,t:1527026900286};\\\", \\\"{x:812,y:538,t:1527026900303};\\\", \\\"{x:813,y:537,t:1527026900319};\\\", \\\"{x:813,y:536,t:1527026900337};\\\", \\\"{x:813,y:533,t:1527026900353};\\\", \\\"{x:822,y:511,t:1527026900372};\\\", \\\"{x:827,y:502,t:1527026900387};\\\", \\\"{x:828,y:499,t:1527026900403};\\\", \\\"{x:828,y:497,t:1527026900420};\\\", \\\"{x:829,y:496,t:1527026900436};\\\", \\\"{x:833,y:496,t:1527026900651};\\\", \\\"{x:835,y:497,t:1527026900658};\\\", \\\"{x:837,y:498,t:1527026900670};\\\", \\\"{x:839,y:498,t:1527026900688};\\\", \\\"{x:838,y:498,t:1527026900858};\\\", \\\"{x:831,y:498,t:1527026900871};\\\", \\\"{x:802,y:495,t:1527026900887};\\\", \\\"{x:761,y:492,t:1527026900904};\\\", \\\"{x:702,y:492,t:1527026900921};\\\", \\\"{x:633,y:492,t:1527026900936};\\\", \\\"{x:566,y:493,t:1527026900954};\\\", \\\"{x:466,y:509,t:1527026900971};\\\", \\\"{x:408,y:525,t:1527026900987};\\\", \\\"{x:359,y:542,t:1527026901003};\\\", \\\"{x:317,y:562,t:1527026901021};\\\", \\\"{x:300,y:570,t:1527026901038};\\\", \\\"{x:296,y:572,t:1527026901053};\\\", \\\"{x:294,y:572,t:1527026901098};\\\", \\\"{x:292,y:574,t:1527026901106};\\\", \\\"{x:291,y:575,t:1527026901121};\\\", \\\"{x:285,y:577,t:1527026901137};\\\", \\\"{x:272,y:580,t:1527026901157};\\\", \\\"{x:246,y:580,t:1527026901170};\\\", \\\"{x:234,y:580,t:1527026901187};\\\", \\\"{x:227,y:580,t:1527026901203};\\\", \\\"{x:218,y:579,t:1527026901220};\\\", \\\"{x:212,y:578,t:1527026901238};\\\", \\\"{x:207,y:578,t:1527026901254};\\\", \\\"{x:203,y:575,t:1527026901270};\\\", \\\"{x:196,y:572,t:1527026901287};\\\", \\\"{x:193,y:570,t:1527026901303};\\\", \\\"{x:192,y:568,t:1527026901320};\\\", \\\"{x:192,y:566,t:1527026901338};\\\", \\\"{x:192,y:565,t:1527026901354};\\\", \\\"{x:192,y:561,t:1527026901371};\\\", \\\"{x:192,y:559,t:1527026901387};\\\", \\\"{x:192,y:558,t:1527026901404};\\\", \\\"{x:192,y:556,t:1527026901420};\\\", \\\"{x:192,y:555,t:1527026901439};\\\", \\\"{x:190,y:553,t:1527026901454};\\\", \\\"{x:189,y:553,t:1527026901470};\\\", \\\"{x:184,y:552,t:1527026901487};\\\", \\\"{x:177,y:552,t:1527026901504};\\\", \\\"{x:169,y:551,t:1527026901521};\\\", \\\"{x:164,y:551,t:1527026901538};\\\", \\\"{x:164,y:550,t:1527026901562};\\\", \\\"{x:170,y:552,t:1527026901771};\\\", \\\"{x:232,y:586,t:1527026901788};\\\", \\\"{x:327,y:632,t:1527026901805};\\\", \\\"{x:391,y:678,t:1527026901820};\\\", \\\"{x:432,y:711,t:1527026901837};\\\", \\\"{x:459,y:731,t:1527026901855};\\\", \\\"{x:488,y:748,t:1527026901871};\\\", \\\"{x:514,y:766,t:1527026901888};\\\", \\\"{x:529,y:775,t:1527026901904};\\\", \\\"{x:530,y:777,t:1527026901920};\\\", \\\"{x:531,y:779,t:1527026901937};\\\", \\\"{x:531,y:782,t:1527026901955};\\\", \\\"{x:531,y:783,t:1527026902011};\\\", \\\"{x:530,y:783,t:1527026902021};\\\", \\\"{x:529,y:783,t:1527026902038};\\\", \\\"{x:527,y:783,t:1527026902055};\\\", \\\"{x:527,y:782,t:1527026902075};\\\", \\\"{x:527,y:780,t:1527026902088};\\\", \\\"{x:526,y:773,t:1527026902105};\\\", \\\"{x:524,y:764,t:1527026902122};\\\", \\\"{x:522,y:754,t:1527026902139};\\\", \\\"{x:521,y:749,t:1527026902155};\\\", \\\"{x:521,y:748,t:1527026902172};\\\" ] }, { \\\"rt\\\": 32842, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 267747, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:521,y:744,t:1527026904531};\\\", \\\"{x:517,y:735,t:1527026904540};\\\", \\\"{x:513,y:726,t:1527026904557};\\\", \\\"{x:512,y:717,t:1527026904574};\\\", \\\"{x:511,y:710,t:1527026904590};\\\", \\\"{x:511,y:707,t:1527026904607};\\\", \\\"{x:511,y:704,t:1527026904624};\\\", \\\"{x:512,y:692,t:1527026904640};\\\", \\\"{x:512,y:685,t:1527026904656};\\\", \\\"{x:512,y:679,t:1527026904674};\\\", \\\"{x:513,y:678,t:1527026905355};\\\", \\\"{x:515,y:677,t:1527026905362};\\\", \\\"{x:516,y:676,t:1527026905374};\\\", \\\"{x:521,y:673,t:1527026905391};\\\", \\\"{x:529,y:665,t:1527026905407};\\\", \\\"{x:543,y:653,t:1527026905424};\\\", \\\"{x:561,y:641,t:1527026905441};\\\", \\\"{x:583,y:626,t:1527026905459};\\\", \\\"{x:618,y:598,t:1527026905474};\\\", \\\"{x:641,y:585,t:1527026905491};\\\", \\\"{x:661,y:574,t:1527026905508};\\\", \\\"{x:678,y:569,t:1527026905524};\\\", \\\"{x:693,y:564,t:1527026905541};\\\", \\\"{x:700,y:563,t:1527026905558};\\\", \\\"{x:708,y:561,t:1527026905574};\\\", \\\"{x:711,y:560,t:1527026905590};\\\", \\\"{x:711,y:559,t:1527026905666};\\\", \\\"{x:710,y:557,t:1527026905747};\\\", \\\"{x:709,y:557,t:1527026905762};\\\", \\\"{x:708,y:557,t:1527026905774};\\\", \\\"{x:707,y:557,t:1527026905791};\\\", \\\"{x:705,y:556,t:1527026905807};\\\", \\\"{x:703,y:555,t:1527026905825};\\\", \\\"{x:698,y:553,t:1527026905841};\\\", \\\"{x:685,y:550,t:1527026905857};\\\", \\\"{x:670,y:544,t:1527026905874};\\\", \\\"{x:653,y:540,t:1527026905890};\\\", \\\"{x:627,y:532,t:1527026905908};\\\", \\\"{x:595,y:523,t:1527026905924};\\\", \\\"{x:564,y:518,t:1527026905941};\\\", \\\"{x:532,y:508,t:1527026905958};\\\", \\\"{x:504,y:500,t:1527026905974};\\\", \\\"{x:490,y:496,t:1527026905991};\\\", \\\"{x:474,y:488,t:1527026906007};\\\", \\\"{x:458,y:483,t:1527026906025};\\\", \\\"{x:452,y:480,t:1527026906041};\\\", \\\"{x:447,y:478,t:1527026906058};\\\", \\\"{x:447,y:477,t:1527026906074};\\\", \\\"{x:447,y:476,t:1527026906130};\\\", \\\"{x:448,y:473,t:1527026906141};\\\", \\\"{x:450,y:471,t:1527026906158};\\\", \\\"{x:450,y:470,t:1527026906175};\\\", \\\"{x:450,y:469,t:1527026906191};\\\", \\\"{x:451,y:469,t:1527026906208};\\\", \\\"{x:453,y:468,t:1527026906225};\\\", \\\"{x:455,y:467,t:1527026906241};\\\", \\\"{x:461,y:466,t:1527026906259};\\\", \\\"{x:464,y:466,t:1527026906274};\\\", \\\"{x:467,y:463,t:1527026906292};\\\", \\\"{x:469,y:463,t:1527026906308};\\\", \\\"{x:470,y:463,t:1527026906330};\\\", \\\"{x:471,y:463,t:1527026906419};\\\", \\\"{x:473,y:462,t:1527026906809};\\\", \\\"{x:475,y:461,t:1527026906824};\\\", \\\"{x:476,y:461,t:1527026906840};\\\", \\\"{x:481,y:461,t:1527026906858};\\\", \\\"{x:482,y:461,t:1527026906874};\\\", \\\"{x:484,y:461,t:1527026906890};\\\", \\\"{x:488,y:461,t:1527026906908};\\\", \\\"{x:497,y:461,t:1527026906924};\\\", \\\"{x:506,y:461,t:1527026906941};\\\", \\\"{x:523,y:461,t:1527026906958};\\\", \\\"{x:537,y:462,t:1527026906974};\\\", \\\"{x:552,y:467,t:1527026906991};\\\", \\\"{x:556,y:467,t:1527026907008};\\\", \\\"{x:557,y:467,t:1527026907024};\\\", \\\"{x:557,y:468,t:1527026907482};\\\", \\\"{x:558,y:468,t:1527026907490};\\\", \\\"{x:559,y:469,t:1527026907508};\\\", \\\"{x:560,y:469,t:1527026907610};\\\", \\\"{x:561,y:469,t:1527026908427};\\\", \\\"{x:566,y:469,t:1527026908441};\\\", \\\"{x:598,y:469,t:1527026908459};\\\", \\\"{x:634,y:469,t:1527026908474};\\\", \\\"{x:692,y:469,t:1527026908491};\\\", \\\"{x:767,y:469,t:1527026908508};\\\", \\\"{x:844,y:474,t:1527026908525};\\\", \\\"{x:925,y:487,t:1527026908542};\\\", \\\"{x:1016,y:499,t:1527026908559};\\\", \\\"{x:1091,y:521,t:1527026908573};\\\", \\\"{x:1141,y:541,t:1527026908593};\\\", \\\"{x:1179,y:564,t:1527026908610};\\\", \\\"{x:1193,y:576,t:1527026908627};\\\", \\\"{x:1202,y:583,t:1527026908642};\\\", \\\"{x:1206,y:586,t:1527026908660};\\\", \\\"{x:1209,y:589,t:1527026908677};\\\", \\\"{x:1216,y:594,t:1527026908694};\\\", \\\"{x:1218,y:596,t:1527026908709};\\\", \\\"{x:1219,y:598,t:1527026908727};\\\", \\\"{x:1220,y:600,t:1527026908743};\\\", \\\"{x:1221,y:601,t:1527026908760};\\\", \\\"{x:1221,y:602,t:1527026908777};\\\", \\\"{x:1221,y:603,t:1527026908794};\\\", \\\"{x:1222,y:603,t:1527026908810};\\\", \\\"{x:1222,y:605,t:1527026908867};\\\", \\\"{x:1222,y:606,t:1527026908891};\\\", \\\"{x:1222,y:608,t:1527026908923};\\\", \\\"{x:1222,y:609,t:1527026908954};\\\", \\\"{x:1222,y:611,t:1527026908971};\\\", \\\"{x:1222,y:612,t:1527026908979};\\\", \\\"{x:1222,y:614,t:1527026909003};\\\", \\\"{x:1222,y:615,t:1527026909011};\\\", \\\"{x:1222,y:618,t:1527026909027};\\\", \\\"{x:1222,y:621,t:1527026909045};\\\", \\\"{x:1222,y:625,t:1527026909062};\\\", \\\"{x:1222,y:629,t:1527026909078};\\\", \\\"{x:1222,y:635,t:1527026909094};\\\", \\\"{x:1226,y:646,t:1527026909112};\\\", \\\"{x:1232,y:654,t:1527026909128};\\\", \\\"{x:1237,y:661,t:1527026909145};\\\", \\\"{x:1240,y:666,t:1527026909162};\\\", \\\"{x:1248,y:678,t:1527026909179};\\\", \\\"{x:1251,y:688,t:1527026909194};\\\", \\\"{x:1258,y:700,t:1527026909211};\\\", \\\"{x:1266,y:715,t:1527026909229};\\\", \\\"{x:1277,y:731,t:1527026909245};\\\", \\\"{x:1300,y:752,t:1527026909261};\\\", \\\"{x:1324,y:770,t:1527026909278};\\\", \\\"{x:1344,y:783,t:1527026909294};\\\", \\\"{x:1360,y:796,t:1527026909310};\\\", \\\"{x:1370,y:804,t:1527026909328};\\\", \\\"{x:1381,y:813,t:1527026909345};\\\", \\\"{x:1391,y:820,t:1527026909361};\\\", \\\"{x:1398,y:826,t:1527026909378};\\\", \\\"{x:1400,y:826,t:1527026909394};\\\", \\\"{x:1400,y:827,t:1527026909426};\\\", \\\"{x:1397,y:830,t:1527026910332};\\\", \\\"{x:1393,y:835,t:1527026910346};\\\", \\\"{x:1389,y:841,t:1527026910363};\\\", \\\"{x:1386,y:845,t:1527026910380};\\\", \\\"{x:1385,y:846,t:1527026910396};\\\", \\\"{x:1384,y:849,t:1527026910413};\\\", \\\"{x:1383,y:850,t:1527026910430};\\\", \\\"{x:1382,y:851,t:1527026910446};\\\", \\\"{x:1379,y:852,t:1527026910463};\\\", \\\"{x:1376,y:852,t:1527026910480};\\\", \\\"{x:1369,y:852,t:1527026910497};\\\", \\\"{x:1361,y:852,t:1527026910513};\\\", \\\"{x:1347,y:851,t:1527026910530};\\\", \\\"{x:1330,y:845,t:1527026910547};\\\", \\\"{x:1303,y:839,t:1527026910563};\\\", \\\"{x:1280,y:834,t:1527026910580};\\\", \\\"{x:1259,y:832,t:1527026910597};\\\", \\\"{x:1242,y:828,t:1527026910613};\\\", \\\"{x:1229,y:826,t:1527026910630};\\\", \\\"{x:1223,y:824,t:1527026910647};\\\", \\\"{x:1222,y:823,t:1527026910663};\\\", \\\"{x:1222,y:820,t:1527026910680};\\\", \\\"{x:1231,y:812,t:1527026910698};\\\", \\\"{x:1242,y:805,t:1527026910713};\\\", \\\"{x:1263,y:790,t:1527026910730};\\\", \\\"{x:1287,y:784,t:1527026910747};\\\", \\\"{x:1299,y:779,t:1527026910764};\\\", \\\"{x:1310,y:773,t:1527026910781};\\\", \\\"{x:1315,y:771,t:1527026910797};\\\", \\\"{x:1320,y:770,t:1527026910814};\\\", \\\"{x:1322,y:770,t:1527026911043};\\\", \\\"{x:1324,y:771,t:1527026911051};\\\", \\\"{x:1327,y:771,t:1527026911065};\\\", \\\"{x:1331,y:771,t:1527026911081};\\\", \\\"{x:1334,y:771,t:1527026911097};\\\", \\\"{x:1335,y:771,t:1527026911123};\\\", \\\"{x:1336,y:771,t:1527026911139};\\\", \\\"{x:1337,y:771,t:1527026911148};\\\", \\\"{x:1339,y:771,t:1527026911170};\\\", \\\"{x:1341,y:770,t:1527026911267};\\\", \\\"{x:1342,y:770,t:1527026911282};\\\", \\\"{x:1346,y:767,t:1527026911301};\\\", \\\"{x:1348,y:766,t:1527026917019};\\\", \\\"{x:1347,y:766,t:1527026917027};\\\", \\\"{x:1343,y:767,t:1527026917043};\\\", \\\"{x:1340,y:768,t:1527026917058};\\\", \\\"{x:1338,y:768,t:1527026917075};\\\", \\\"{x:1337,y:768,t:1527026917098};\\\", \\\"{x:1334,y:768,t:1527026917108};\\\", \\\"{x:1331,y:768,t:1527026917125};\\\", \\\"{x:1326,y:768,t:1527026917142};\\\", \\\"{x:1319,y:768,t:1527026917158};\\\", \\\"{x:1313,y:768,t:1527026917174};\\\", \\\"{x:1307,y:768,t:1527026917192};\\\", \\\"{x:1303,y:768,t:1527026917209};\\\", \\\"{x:1300,y:768,t:1527026917225};\\\", \\\"{x:1299,y:768,t:1527026917243};\\\", \\\"{x:1298,y:768,t:1527026917258};\\\", \\\"{x:1297,y:768,t:1527026917274};\\\", \\\"{x:1295,y:768,t:1527026917292};\\\", \\\"{x:1293,y:768,t:1527026917309};\\\", \\\"{x:1289,y:768,t:1527026917324};\\\", \\\"{x:1286,y:768,t:1527026917342};\\\", \\\"{x:1285,y:768,t:1527026917359};\\\", \\\"{x:1283,y:768,t:1527026917375};\\\", \\\"{x:1280,y:768,t:1527026917392};\\\", \\\"{x:1278,y:768,t:1527026917409};\\\", \\\"{x:1273,y:768,t:1527026917426};\\\", \\\"{x:1266,y:768,t:1527026917442};\\\", \\\"{x:1258,y:768,t:1527026917459};\\\", \\\"{x:1254,y:768,t:1527026917475};\\\", \\\"{x:1251,y:768,t:1527026917492};\\\", \\\"{x:1250,y:768,t:1527026917509};\\\", \\\"{x:1248,y:768,t:1527026917526};\\\", \\\"{x:1247,y:768,t:1527026917554};\\\", \\\"{x:1246,y:768,t:1527026917563};\\\", \\\"{x:1245,y:768,t:1527026917576};\\\", \\\"{x:1244,y:768,t:1527026917593};\\\", \\\"{x:1243,y:768,t:1527026917609};\\\", \\\"{x:1242,y:768,t:1527026917626};\\\", \\\"{x:1240,y:768,t:1527026919323};\\\", \\\"{x:1239,y:770,t:1527026919331};\\\", \\\"{x:1239,y:772,t:1527026919346};\\\", \\\"{x:1239,y:773,t:1527026919362};\\\", \\\"{x:1238,y:777,t:1527026919379};\\\", \\\"{x:1238,y:780,t:1527026919396};\\\", \\\"{x:1238,y:785,t:1527026919412};\\\", \\\"{x:1238,y:791,t:1527026919429};\\\", \\\"{x:1237,y:797,t:1527026919446};\\\", \\\"{x:1237,y:800,t:1527026919462};\\\", \\\"{x:1237,y:804,t:1527026919479};\\\", \\\"{x:1237,y:806,t:1527026919498};\\\", \\\"{x:1236,y:807,t:1527026919514};\\\", \\\"{x:1235,y:807,t:1527026919529};\\\", \\\"{x:1234,y:807,t:1527026919963};\\\", \\\"{x:1232,y:807,t:1527026919980};\\\", \\\"{x:1231,y:807,t:1527026920003};\\\", \\\"{x:1230,y:807,t:1527026920043};\\\", \\\"{x:1228,y:804,t:1527026922883};\\\", \\\"{x:1224,y:801,t:1527026922890};\\\", \\\"{x:1221,y:797,t:1527026922901};\\\", \\\"{x:1217,y:794,t:1527026922919};\\\", \\\"{x:1216,y:793,t:1527026922935};\\\", \\\"{x:1215,y:792,t:1527026922951};\\\", \\\"{x:1213,y:791,t:1527026922968};\\\", \\\"{x:1213,y:790,t:1527026923259};\\\", \\\"{x:1210,y:788,t:1527026923269};\\\", \\\"{x:1206,y:784,t:1527026923285};\\\", \\\"{x:1205,y:783,t:1527026923302};\\\", \\\"{x:1204,y:782,t:1527026923319};\\\", \\\"{x:1203,y:782,t:1527026923335};\\\", \\\"{x:1203,y:781,t:1527026923395};\\\", \\\"{x:1203,y:779,t:1527026927403};\\\", \\\"{x:1206,y:775,t:1527026927410};\\\", \\\"{x:1219,y:765,t:1527026927426};\\\", \\\"{x:1233,y:751,t:1527026927442};\\\", \\\"{x:1252,y:730,t:1527026927459};\\\", \\\"{x:1267,y:707,t:1527026927477};\\\", \\\"{x:1281,y:684,t:1527026927492};\\\", \\\"{x:1289,y:664,t:1527026927509};\\\", \\\"{x:1299,y:646,t:1527026927526};\\\", \\\"{x:1303,y:633,t:1527026927542};\\\", \\\"{x:1305,y:621,t:1527026927559};\\\", \\\"{x:1309,y:610,t:1527026927576};\\\", \\\"{x:1309,y:600,t:1527026927592};\\\", \\\"{x:1309,y:593,t:1527026927609};\\\", \\\"{x:1308,y:588,t:1527026927627};\\\", \\\"{x:1304,y:587,t:1527026927643};\\\", \\\"{x:1300,y:585,t:1527026927659};\\\", \\\"{x:1298,y:584,t:1527026927675};\\\", \\\"{x:1297,y:584,t:1527026927737};\\\", \\\"{x:1294,y:583,t:1527026927745};\\\", \\\"{x:1293,y:582,t:1527026927758};\\\", \\\"{x:1289,y:579,t:1527026927776};\\\", \\\"{x:1287,y:577,t:1527026927793};\\\", \\\"{x:1286,y:576,t:1527026927809};\\\", \\\"{x:1284,y:573,t:1527026927826};\\\", \\\"{x:1284,y:572,t:1527026927843};\\\", \\\"{x:1284,y:570,t:1527026927860};\\\", \\\"{x:1284,y:569,t:1527026927875};\\\", \\\"{x:1284,y:568,t:1527026927899};\\\", \\\"{x:1277,y:572,t:1527026934691};\\\", \\\"{x:1261,y:583,t:1527026934705};\\\", \\\"{x:1213,y:616,t:1527026934722};\\\", \\\"{x:1126,y:665,t:1527026934738};\\\", \\\"{x:1064,y:687,t:1527026934754};\\\", \\\"{x:981,y:710,t:1527026934771};\\\", \\\"{x:895,y:723,t:1527026934789};\\\", \\\"{x:817,y:723,t:1527026934804};\\\", \\\"{x:815,y:723,t:1527026934821};\\\", \\\"{x:814,y:723,t:1527026935099};\\\", \\\"{x:811,y:723,t:1527026935106};\\\", \\\"{x:809,y:723,t:1527026935122};\\\", \\\"{x:806,y:723,t:1527026935138};\\\", \\\"{x:802,y:721,t:1527026935156};\\\", \\\"{x:792,y:713,t:1527026935172};\\\", \\\"{x:780,y:695,t:1527026935188};\\\", \\\"{x:762,y:671,t:1527026935206};\\\", \\\"{x:740,y:638,t:1527026935223};\\\", \\\"{x:711,y:598,t:1527026935239};\\\", \\\"{x:682,y:558,t:1527026935255};\\\", \\\"{x:669,y:535,t:1527026935274};\\\", \\\"{x:656,y:523,t:1527026935291};\\\", \\\"{x:650,y:516,t:1527026935305};\\\", \\\"{x:641,y:510,t:1527026935331};\\\", \\\"{x:640,y:510,t:1527026935434};\\\", \\\"{x:638,y:510,t:1527026935466};\\\", \\\"{x:636,y:511,t:1527026935482};\\\", \\\"{x:634,y:512,t:1527026935498};\\\", \\\"{x:632,y:513,t:1527026935516};\\\", \\\"{x:631,y:513,t:1527026935532};\\\", \\\"{x:628,y:513,t:1527026935548};\\\", \\\"{x:623,y:513,t:1527026935565};\\\", \\\"{x:618,y:511,t:1527026935583};\\\", \\\"{x:617,y:511,t:1527026935597};\\\", \\\"{x:616,y:510,t:1527026935615};\\\", \\\"{x:614,y:521,t:1527026935874};\\\", \\\"{x:611,y:536,t:1527026935882};\\\", \\\"{x:605,y:584,t:1527026935899};\\\", \\\"{x:601,y:619,t:1527026935915};\\\", \\\"{x:598,y:641,t:1527026935933};\\\", \\\"{x:594,y:652,t:1527026935949};\\\", \\\"{x:592,y:659,t:1527026935965};\\\", \\\"{x:590,y:663,t:1527026935982};\\\", \\\"{x:583,y:675,t:1527026935998};\\\", \\\"{x:574,y:686,t:1527026936015};\\\", \\\"{x:567,y:695,t:1527026936032};\\\", \\\"{x:562,y:698,t:1527026936049};\\\", \\\"{x:557,y:699,t:1527026936065};\\\", \\\"{x:552,y:701,t:1527026936082};\\\", \\\"{x:546,y:703,t:1527026936099};\\\", \\\"{x:541,y:706,t:1527026936115};\\\", \\\"{x:535,y:710,t:1527026936132};\\\", \\\"{x:531,y:712,t:1527026936149};\\\", \\\"{x:529,y:713,t:1527026936165};\\\", \\\"{x:527,y:714,t:1527026936182};\\\", \\\"{x:525,y:715,t:1527026936199};\\\", \\\"{x:524,y:718,t:1527026936215};\\\", \\\"{x:523,y:722,t:1527026936234};\\\", \\\"{x:521,y:727,t:1527026936249};\\\", \\\"{x:516,y:734,t:1527026936266};\\\", \\\"{x:515,y:737,t:1527026936282};\\\", \\\"{x:514,y:738,t:1527026936299};\\\", \\\"{x:513,y:738,t:1527026936316};\\\", \\\"{x:513,y:736,t:1527026936707};\\\", \\\"{x:512,y:734,t:1527026936722};\\\", \\\"{x:512,y:733,t:1527026936732};\\\", \\\"{x:511,y:729,t:1527026936749};\\\", \\\"{x:511,y:728,t:1527026936766};\\\", \\\"{x:511,y:725,t:1527026936782};\\\", \\\"{x:510,y:722,t:1527026936799};\\\", \\\"{x:510,y:718,t:1527026936816};\\\", \\\"{x:509,y:714,t:1527026936832};\\\", \\\"{x:509,y:711,t:1527026936849};\\\", \\\"{x:509,y:705,t:1527026936866};\\\", \\\"{x:507,y:702,t:1527026936882};\\\", \\\"{x:507,y:699,t:1527026936898};\\\", \\\"{x:506,y:697,t:1527026936916};\\\", \\\"{x:506,y:695,t:1527026936933};\\\", \\\"{x:506,y:694,t:1527026936948};\\\", \\\"{x:506,y:691,t:1527026936966};\\\", \\\"{x:506,y:690,t:1527026937009};\\\", \\\"{x:506,y:689,t:1527026937026};\\\", \\\"{x:506,y:688,t:1527026937042};\\\", \\\"{x:505,y:687,t:1527026937074};\\\", \\\"{x:505,y:686,t:1527026937098};\\\", \\\"{x:505,y:685,t:1527026937113};\\\", \\\"{x:505,y:684,t:1527026937163};\\\", \\\"{x:505,y:683,t:1527026937170};\\\", \\\"{x:505,y:682,t:1527026937194};\\\", \\\"{x:504,y:682,t:1527026937201};\\\", \\\"{x:504,y:681,t:1527026937226};\\\", \\\"{x:504,y:680,t:1527026937258};\\\", \\\"{x:504,y:679,t:1527026937274};\\\", \\\"{x:504,y:678,t:1527026937346};\\\", \\\"{x:504,y:677,t:1527026937362};\\\", \\\"{x:504,y:676,t:1527026937386};\\\", \\\"{x:503,y:676,t:1527026937506};\\\" ] }, { \\\"rt\\\": 15096, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 284053, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:675,t:1527026941146};\\\", \\\"{x:506,y:672,t:1527026941167};\\\", \\\"{x:509,y:669,t:1527026941169};\\\", \\\"{x:515,y:663,t:1527026941186};\\\", \\\"{x:522,y:654,t:1527026941202};\\\", \\\"{x:532,y:637,t:1527026941219};\\\", \\\"{x:540,y:621,t:1527026941237};\\\", \\\"{x:548,y:601,t:1527026941253};\\\", \\\"{x:554,y:585,t:1527026941270};\\\", \\\"{x:560,y:568,t:1527026941285};\\\", \\\"{x:565,y:553,t:1527026941303};\\\", \\\"{x:569,y:541,t:1527026941318};\\\", \\\"{x:575,y:526,t:1527026941336};\\\", \\\"{x:585,y:504,t:1527026941354};\\\", \\\"{x:590,y:491,t:1527026941370};\\\", \\\"{x:591,y:490,t:1527026941386};\\\", \\\"{x:591,y:488,t:1527026942074};\\\", \\\"{x:591,y:487,t:1527026942098};\\\", \\\"{x:591,y:485,t:1527026942107};\\\", \\\"{x:604,y:484,t:1527026942121};\\\", \\\"{x:638,y:484,t:1527026942137};\\\", \\\"{x:664,y:484,t:1527026942153};\\\", \\\"{x:691,y:484,t:1527026942170};\\\", \\\"{x:734,y:484,t:1527026942187};\\\", \\\"{x:792,y:484,t:1527026942203};\\\", \\\"{x:851,y:484,t:1527026942220};\\\", \\\"{x:904,y:484,t:1527026942237};\\\", \\\"{x:962,y:484,t:1527026942253};\\\", \\\"{x:1016,y:484,t:1527026942271};\\\", \\\"{x:1029,y:493,t:1527026942287};\\\", \\\"{x:1036,y:497,t:1527026942304};\\\", \\\"{x:1036,y:498,t:1527026942683};\\\", \\\"{x:1036,y:499,t:1527026942859};\\\", \\\"{x:1036,y:503,t:1527026942872};\\\", \\\"{x:1040,y:518,t:1527026942887};\\\", \\\"{x:1051,y:540,t:1527026942904};\\\", \\\"{x:1077,y:586,t:1527026942921};\\\", \\\"{x:1104,y:619,t:1527026942937};\\\", \\\"{x:1142,y:651,t:1527026942954};\\\", \\\"{x:1185,y:682,t:1527026942971};\\\", \\\"{x:1227,y:710,t:1527026942987};\\\", \\\"{x:1265,y:734,t:1527026943004};\\\", \\\"{x:1292,y:754,t:1527026943021};\\\", \\\"{x:1313,y:767,t:1527026943038};\\\", \\\"{x:1325,y:783,t:1527026943054};\\\", \\\"{x:1331,y:800,t:1527026943071};\\\", \\\"{x:1332,y:802,t:1527026943089};\\\", \\\"{x:1330,y:802,t:1527026943403};\\\", \\\"{x:1319,y:802,t:1527026943411};\\\", \\\"{x:1307,y:799,t:1527026943422};\\\", \\\"{x:1285,y:796,t:1527026943438};\\\", \\\"{x:1279,y:796,t:1527026943456};\\\", \\\"{x:1278,y:796,t:1527026943472};\\\", \\\"{x:1276,y:796,t:1527026943489};\\\", \\\"{x:1273,y:796,t:1527026943505};\\\", \\\"{x:1270,y:797,t:1527026943521};\\\", \\\"{x:1261,y:800,t:1527026943538};\\\", \\\"{x:1251,y:805,t:1527026943555};\\\", \\\"{x:1239,y:809,t:1527026943572};\\\", \\\"{x:1231,y:812,t:1527026943588};\\\", \\\"{x:1224,y:816,t:1527026943605};\\\", \\\"{x:1221,y:818,t:1527026943621};\\\", \\\"{x:1219,y:819,t:1527026943638};\\\", \\\"{x:1218,y:819,t:1527026943803};\\\", \\\"{x:1218,y:821,t:1527026943810};\\\", \\\"{x:1218,y:824,t:1527026943823};\\\", \\\"{x:1218,y:829,t:1527026943841};\\\", \\\"{x:1218,y:832,t:1527026943855};\\\", \\\"{x:1217,y:836,t:1527026943874};\\\", \\\"{x:1217,y:837,t:1527026943889};\\\", \\\"{x:1217,y:840,t:1527026943905};\\\", \\\"{x:1218,y:842,t:1527026943923};\\\", \\\"{x:1219,y:843,t:1527026943938};\\\", \\\"{x:1220,y:844,t:1527026943986};\\\", \\\"{x:1221,y:845,t:1527026943994};\\\", \\\"{x:1223,y:845,t:1527026944011};\\\", \\\"{x:1225,y:845,t:1527026944023};\\\", \\\"{x:1228,y:845,t:1527026944039};\\\", \\\"{x:1232,y:845,t:1527026944056};\\\", \\\"{x:1235,y:845,t:1527026944073};\\\", \\\"{x:1238,y:845,t:1527026944089};\\\", \\\"{x:1241,y:845,t:1527026944106};\\\", \\\"{x:1242,y:845,t:1527026944123};\\\", \\\"{x:1243,y:844,t:1527026944979};\\\", \\\"{x:1242,y:837,t:1527026944990};\\\", \\\"{x:1228,y:825,t:1527026945007};\\\", \\\"{x:1215,y:809,t:1527026945024};\\\", \\\"{x:1203,y:797,t:1527026945040};\\\", \\\"{x:1198,y:792,t:1527026945057};\\\", \\\"{x:1198,y:791,t:1527026945074};\\\", \\\"{x:1198,y:789,t:1527026945139};\\\", \\\"{x:1198,y:788,t:1527026945157};\\\", \\\"{x:1198,y:787,t:1527026945174};\\\", \\\"{x:1196,y:784,t:1527026945190};\\\", \\\"{x:1196,y:782,t:1527026945207};\\\", \\\"{x:1194,y:779,t:1527026945224};\\\", \\\"{x:1192,y:775,t:1527026945240};\\\", \\\"{x:1188,y:770,t:1527026945257};\\\", \\\"{x:1185,y:766,t:1527026945275};\\\", \\\"{x:1185,y:765,t:1527026945290};\\\", \\\"{x:1184,y:765,t:1527026945314};\\\", \\\"{x:1183,y:765,t:1527026945330};\\\", \\\"{x:1182,y:764,t:1527026945354};\\\", \\\"{x:1178,y:762,t:1527026949017};\\\", \\\"{x:1165,y:756,t:1527026949026};\\\", \\\"{x:1129,y:743,t:1527026949042};\\\", \\\"{x:1087,y:724,t:1527026949058};\\\", \\\"{x:1035,y:701,t:1527026949075};\\\", \\\"{x:960,y:669,t:1527026949092};\\\", \\\"{x:907,y:642,t:1527026949107};\\\", \\\"{x:871,y:621,t:1527026949126};\\\", \\\"{x:854,y:610,t:1527026949141};\\\", \\\"{x:834,y:599,t:1527026949158};\\\", \\\"{x:816,y:589,t:1527026949174};\\\", \\\"{x:799,y:579,t:1527026949190};\\\", \\\"{x:785,y:572,t:1527026949207};\\\", \\\"{x:761,y:558,t:1527026949224};\\\", \\\"{x:742,y:551,t:1527026949241};\\\", \\\"{x:721,y:547,t:1527026949258};\\\", \\\"{x:708,y:545,t:1527026949273};\\\", \\\"{x:689,y:545,t:1527026949290};\\\", \\\"{x:672,y:544,t:1527026949307};\\\", \\\"{x:652,y:544,t:1527026949324};\\\", \\\"{x:633,y:544,t:1527026949340};\\\", \\\"{x:616,y:544,t:1527026949358};\\\", \\\"{x:610,y:544,t:1527026949374};\\\", \\\"{x:606,y:544,t:1527026949390};\\\", \\\"{x:604,y:544,t:1527026949407};\\\", \\\"{x:604,y:545,t:1527026949512};\\\", \\\"{x:604,y:546,t:1527026949524};\\\", \\\"{x:604,y:547,t:1527026949552};\\\", \\\"{x:606,y:547,t:1527026949560};\\\", \\\"{x:607,y:547,t:1527026949575};\\\", \\\"{x:610,y:549,t:1527026949591};\\\", \\\"{x:621,y:552,t:1527026949607};\\\", \\\"{x:632,y:554,t:1527026949625};\\\", \\\"{x:641,y:558,t:1527026949641};\\\", \\\"{x:645,y:559,t:1527026949657};\\\", \\\"{x:647,y:560,t:1527026949674};\\\", \\\"{x:647,y:561,t:1527026949690};\\\", \\\"{x:647,y:563,t:1527026949708};\\\", \\\"{x:647,y:567,t:1527026949725};\\\", \\\"{x:647,y:572,t:1527026949741};\\\", \\\"{x:634,y:578,t:1527026949758};\\\", \\\"{x:616,y:585,t:1527026949775};\\\", \\\"{x:577,y:590,t:1527026949792};\\\", \\\"{x:547,y:593,t:1527026949807};\\\", \\\"{x:518,y:593,t:1527026949824};\\\", \\\"{x:491,y:593,t:1527026949842};\\\", \\\"{x:471,y:593,t:1527026949857};\\\", \\\"{x:461,y:593,t:1527026949874};\\\", \\\"{x:457,y:593,t:1527026949892};\\\", \\\"{x:455,y:594,t:1527026949936};\\\", \\\"{x:449,y:595,t:1527026949943};\\\", \\\"{x:447,y:595,t:1527026949957};\\\", \\\"{x:446,y:595,t:1527026949975};\\\", \\\"{x:443,y:597,t:1527026949991};\\\", \\\"{x:440,y:598,t:1527026950007};\\\", \\\"{x:437,y:598,t:1527026950024};\\\", \\\"{x:434,y:598,t:1527026950042};\\\", \\\"{x:430,y:598,t:1527026950057};\\\", \\\"{x:426,y:597,t:1527026950075};\\\", \\\"{x:418,y:592,t:1527026950092};\\\", \\\"{x:413,y:588,t:1527026950108};\\\", \\\"{x:408,y:583,t:1527026950124};\\\", \\\"{x:404,y:578,t:1527026950142};\\\", \\\"{x:400,y:573,t:1527026950157};\\\", \\\"{x:395,y:567,t:1527026950175};\\\", \\\"{x:390,y:561,t:1527026950193};\\\", \\\"{x:389,y:560,t:1527026950209};\\\", \\\"{x:388,y:560,t:1527026950263};\\\", \\\"{x:385,y:562,t:1527026950279};\\\", \\\"{x:384,y:566,t:1527026950292};\\\", \\\"{x:379,y:575,t:1527026950309};\\\", \\\"{x:375,y:585,t:1527026950324};\\\", \\\"{x:370,y:594,t:1527026950342};\\\", \\\"{x:368,y:598,t:1527026950358};\\\", \\\"{x:363,y:603,t:1527026950375};\\\", \\\"{x:351,y:609,t:1527026950392};\\\", \\\"{x:343,y:611,t:1527026950408};\\\", \\\"{x:336,y:614,t:1527026950424};\\\", \\\"{x:327,y:614,t:1527026950441};\\\", \\\"{x:310,y:614,t:1527026950459};\\\", \\\"{x:284,y:614,t:1527026950475};\\\", \\\"{x:254,y:614,t:1527026950493};\\\", \\\"{x:223,y:614,t:1527026950509};\\\", \\\"{x:195,y:614,t:1527026950524};\\\", \\\"{x:182,y:614,t:1527026950542};\\\", \\\"{x:169,y:614,t:1527026950558};\\\", \\\"{x:165,y:614,t:1527026950574};\\\", \\\"{x:163,y:614,t:1527026950592};\\\", \\\"{x:162,y:614,t:1527026950776};\\\", \\\"{x:164,y:611,t:1527026950792};\\\", \\\"{x:179,y:604,t:1527026950809};\\\", \\\"{x:198,y:594,t:1527026950827};\\\", \\\"{x:213,y:583,t:1527026950843};\\\", \\\"{x:221,y:573,t:1527026950859};\\\", \\\"{x:222,y:566,t:1527026950876};\\\", \\\"{x:222,y:561,t:1527026950893};\\\", \\\"{x:217,y:555,t:1527026950909};\\\", \\\"{x:206,y:547,t:1527026950926};\\\", \\\"{x:191,y:536,t:1527026950942};\\\", \\\"{x:182,y:528,t:1527026950959};\\\", \\\"{x:177,y:519,t:1527026950977};\\\", \\\"{x:176,y:518,t:1527026950991};\\\", \\\"{x:176,y:517,t:1527026951011};\\\", \\\"{x:176,y:516,t:1527026951079};\\\", \\\"{x:177,y:516,t:1527026951392};\\\", \\\"{x:195,y:521,t:1527026951409};\\\", \\\"{x:213,y:532,t:1527026951426};\\\", \\\"{x:234,y:546,t:1527026951443};\\\", \\\"{x:262,y:566,t:1527026951461};\\\", \\\"{x:298,y:588,t:1527026951476};\\\", \\\"{x:323,y:600,t:1527026951494};\\\", \\\"{x:337,y:605,t:1527026951509};\\\", \\\"{x:338,y:605,t:1527026951526};\\\", \\\"{x:330,y:603,t:1527026951543};\\\", \\\"{x:251,y:565,t:1527026951560};\\\", \\\"{x:197,y:533,t:1527026951578};\\\", \\\"{x:164,y:512,t:1527026951593};\\\", \\\"{x:150,y:502,t:1527026951609};\\\", \\\"{x:146,y:499,t:1527026951626};\\\", \\\"{x:146,y:498,t:1527026951647};\\\", \\\"{x:148,y:496,t:1527026951659};\\\", \\\"{x:152,y:495,t:1527026951675};\\\", \\\"{x:153,y:495,t:1527026951693};\\\", \\\"{x:154,y:495,t:1527026951711};\\\", \\\"{x:155,y:495,t:1527026951725};\\\", \\\"{x:156,y:495,t:1527026951742};\\\", \\\"{x:160,y:495,t:1527026951824};\\\", \\\"{x:162,y:495,t:1527026951832};\\\", \\\"{x:163,y:495,t:1527026951843};\\\", \\\"{x:163,y:496,t:1527026952039};\\\", \\\"{x:166,y:497,t:1527026952047};\\\", \\\"{x:172,y:500,t:1527026952060};\\\", \\\"{x:197,y:515,t:1527026952077};\\\", \\\"{x:244,y:546,t:1527026952093};\\\", \\\"{x:294,y:581,t:1527026952111};\\\", \\\"{x:332,y:612,t:1527026952127};\\\", \\\"{x:378,y:646,t:1527026952143};\\\", \\\"{x:438,y:691,t:1527026952159};\\\", \\\"{x:466,y:709,t:1527026952177};\\\", \\\"{x:480,y:718,t:1527026952193};\\\", \\\"{x:484,y:722,t:1527026952211};\\\", \\\"{x:485,y:724,t:1527026952226};\\\", \\\"{x:485,y:725,t:1527026952242};\\\", \\\"{x:485,y:726,t:1527026952271};\\\", \\\"{x:485,y:727,t:1527026952279};\\\", \\\"{x:485,y:728,t:1527026952293};\\\", \\\"{x:486,y:731,t:1527026952310};\\\", \\\"{x:488,y:733,t:1527026952327};\\\", \\\"{x:499,y:740,t:1527026952343};\\\", \\\"{x:508,y:746,t:1527026952360};\\\", \\\"{x:518,y:751,t:1527026952377};\\\", \\\"{x:526,y:756,t:1527026952395};\\\", \\\"{x:531,y:757,t:1527026952411};\\\", \\\"{x:532,y:758,t:1527026952426};\\\", \\\"{x:532,y:756,t:1527026952496};\\\", \\\"{x:532,y:754,t:1527026952513};\\\", \\\"{x:532,y:752,t:1527026952526};\\\", \\\"{x:528,y:744,t:1527026952543};\\\", \\\"{x:525,y:742,t:1527026952559};\\\", \\\"{x:524,y:741,t:1527026952576};\\\", \\\"{x:523,y:740,t:1527026953408};\\\", \\\"{x:523,y:738,t:1527026953560};\\\", \\\"{x:523,y:737,t:1527026953592};\\\", \\\"{x:523,y:736,t:1527026953624};\\\", \\\"{x:523,y:735,t:1527026953639};\\\", \\\"{x:523,y:734,t:1527026953696};\\\", \\\"{x:523,y:732,t:1527026953745};\\\", \\\"{x:523,y:731,t:1527026953761};\\\", \\\"{x:522,y:730,t:1527026953791};\\\", \\\"{x:522,y:729,t:1527026953815};\\\" ] }, { \\\"rt\\\": 18499, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 303852, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:726,t:1527026954016};\\\", \\\"{x:521,y:725,t:1527026954824};\\\", \\\"{x:521,y:723,t:1527026955135};\\\", \\\"{x:521,y:722,t:1527026955145};\\\", \\\"{x:521,y:719,t:1527026955163};\\\", \\\"{x:521,y:718,t:1527026955178};\\\", \\\"{x:521,y:717,t:1527026955194};\\\", \\\"{x:521,y:716,t:1527026955212};\\\", \\\"{x:521,y:715,t:1527026955229};\\\", \\\"{x:521,y:714,t:1527026959168};\\\", \\\"{x:523,y:712,t:1527026959182};\\\", \\\"{x:543,y:706,t:1527026959199};\\\", \\\"{x:554,y:706,t:1527026959216};\\\", \\\"{x:593,y:706,t:1527026959232};\\\", \\\"{x:625,y:706,t:1527026959249};\\\", \\\"{x:664,y:710,t:1527026959265};\\\", \\\"{x:733,y:719,t:1527026959283};\\\", \\\"{x:814,y:730,t:1527026959300};\\\", \\\"{x:889,y:740,t:1527026959316};\\\", \\\"{x:952,y:747,t:1527026959332};\\\", \\\"{x:997,y:753,t:1527026959350};\\\", \\\"{x:1026,y:755,t:1527026959366};\\\", \\\"{x:1045,y:759,t:1527026959382};\\\", \\\"{x:1063,y:763,t:1527026959400};\\\", \\\"{x:1070,y:765,t:1527026959417};\\\", \\\"{x:1090,y:770,t:1527026959432};\\\", \\\"{x:1106,y:774,t:1527026959449};\\\", \\\"{x:1124,y:778,t:1527026959466};\\\", \\\"{x:1146,y:781,t:1527026959482};\\\", \\\"{x:1174,y:786,t:1527026959499};\\\", \\\"{x:1204,y:789,t:1527026959517};\\\", \\\"{x:1230,y:789,t:1527026959533};\\\", \\\"{x:1253,y:789,t:1527026959550};\\\", \\\"{x:1270,y:787,t:1527026959567};\\\", \\\"{x:1278,y:785,t:1527026959582};\\\", \\\"{x:1285,y:781,t:1527026959600};\\\", \\\"{x:1291,y:776,t:1527026959616};\\\", \\\"{x:1301,y:766,t:1527026959633};\\\", \\\"{x:1310,y:756,t:1527026959650};\\\", \\\"{x:1322,y:748,t:1527026959667};\\\", \\\"{x:1336,y:741,t:1527026959682};\\\", \\\"{x:1356,y:734,t:1527026959699};\\\", \\\"{x:1375,y:728,t:1527026959716};\\\", \\\"{x:1390,y:724,t:1527026959732};\\\", \\\"{x:1408,y:719,t:1527026959749};\\\", \\\"{x:1421,y:718,t:1527026959767};\\\", \\\"{x:1437,y:714,t:1527026959783};\\\", \\\"{x:1465,y:712,t:1527026959800};\\\", \\\"{x:1484,y:712,t:1527026959816};\\\", \\\"{x:1497,y:712,t:1527026959833};\\\", \\\"{x:1509,y:712,t:1527026959850};\\\", \\\"{x:1522,y:712,t:1527026959866};\\\", \\\"{x:1533,y:712,t:1527026959882};\\\", \\\"{x:1547,y:712,t:1527026959900};\\\", \\\"{x:1564,y:712,t:1527026959917};\\\", \\\"{x:1577,y:712,t:1527026959934};\\\", \\\"{x:1587,y:712,t:1527026959949};\\\", \\\"{x:1594,y:712,t:1527026959967};\\\", \\\"{x:1599,y:711,t:1527026959983};\\\", \\\"{x:1600,y:711,t:1527026960000};\\\", \\\"{x:1601,y:711,t:1527026960104};\\\", \\\"{x:1603,y:710,t:1527026960116};\\\", \\\"{x:1604,y:710,t:1527026960192};\\\", \\\"{x:1606,y:711,t:1527026960200};\\\", \\\"{x:1608,y:711,t:1527026960216};\\\", \\\"{x:1609,y:713,t:1527026960234};\\\", \\\"{x:1610,y:718,t:1527026960250};\\\", \\\"{x:1610,y:726,t:1527026960266};\\\", \\\"{x:1615,y:738,t:1527026960283};\\\", \\\"{x:1619,y:749,t:1527026960300};\\\", \\\"{x:1622,y:759,t:1527026960316};\\\", \\\"{x:1624,y:765,t:1527026960334};\\\", \\\"{x:1624,y:772,t:1527026960350};\\\", \\\"{x:1624,y:776,t:1527026960366};\\\", \\\"{x:1624,y:783,t:1527026960383};\\\", \\\"{x:1624,y:788,t:1527026960400};\\\", \\\"{x:1624,y:791,t:1527026960416};\\\", \\\"{x:1624,y:794,t:1527026960433};\\\", \\\"{x:1624,y:796,t:1527026960451};\\\", \\\"{x:1624,y:800,t:1527026960466};\\\", \\\"{x:1622,y:805,t:1527026960483};\\\", \\\"{x:1622,y:813,t:1527026960501};\\\", \\\"{x:1621,y:822,t:1527026960516};\\\", \\\"{x:1619,y:832,t:1527026960533};\\\", \\\"{x:1618,y:838,t:1527026960550};\\\", \\\"{x:1617,y:843,t:1527026960566};\\\", \\\"{x:1617,y:851,t:1527026960583};\\\", \\\"{x:1616,y:854,t:1527026960600};\\\", \\\"{x:1616,y:860,t:1527026960616};\\\", \\\"{x:1616,y:861,t:1527026960633};\\\", \\\"{x:1615,y:863,t:1527026960649};\\\", \\\"{x:1615,y:864,t:1527026960666};\\\", \\\"{x:1615,y:865,t:1527026960683};\\\", \\\"{x:1614,y:865,t:1527026960712};\\\", \\\"{x:1614,y:863,t:1527026960759};\\\", \\\"{x:1614,y:857,t:1527026960768};\\\", \\\"{x:1617,y:838,t:1527026960783};\\\", \\\"{x:1620,y:813,t:1527026960800};\\\", \\\"{x:1623,y:788,t:1527026960818};\\\", \\\"{x:1627,y:770,t:1527026960833};\\\", \\\"{x:1630,y:749,t:1527026960850};\\\", \\\"{x:1633,y:735,t:1527026960867};\\\", \\\"{x:1634,y:728,t:1527026960883};\\\", \\\"{x:1634,y:725,t:1527026960901};\\\", \\\"{x:1635,y:723,t:1527026960918};\\\", \\\"{x:1636,y:722,t:1527026960934};\\\", \\\"{x:1636,y:721,t:1527026960951};\\\", \\\"{x:1635,y:720,t:1527026960968};\\\", \\\"{x:1633,y:719,t:1527026961000};\\\", \\\"{x:1630,y:718,t:1527026961017};\\\", \\\"{x:1628,y:716,t:1527026961033};\\\", \\\"{x:1626,y:716,t:1527026961050};\\\", \\\"{x:1625,y:715,t:1527026961067};\\\", \\\"{x:1623,y:714,t:1527026961084};\\\", \\\"{x:1622,y:713,t:1527026961112};\\\", \\\"{x:1620,y:713,t:1527026961120};\\\", \\\"{x:1619,y:713,t:1527026961133};\\\", \\\"{x:1619,y:712,t:1527026961152};\\\", \\\"{x:1618,y:712,t:1527026968520};\\\", \\\"{x:1617,y:709,t:1527026968528};\\\", \\\"{x:1602,y:703,t:1527026968540};\\\", \\\"{x:1549,y:695,t:1527026968557};\\\", \\\"{x:1507,y:689,t:1527026968572};\\\", \\\"{x:1477,y:684,t:1527026968589};\\\", \\\"{x:1427,y:678,t:1527026968607};\\\", \\\"{x:1333,y:667,t:1527026968623};\\\", \\\"{x:1141,y:642,t:1527026968640};\\\", \\\"{x:1009,y:631,t:1527026968657};\\\", \\\"{x:902,y:623,t:1527026968675};\\\", \\\"{x:833,y:623,t:1527026968689};\\\", \\\"{x:742,y:614,t:1527026968706};\\\", \\\"{x:661,y:612,t:1527026968724};\\\", \\\"{x:615,y:607,t:1527026968739};\\\", \\\"{x:611,y:607,t:1527026968757};\\\", \\\"{x:611,y:606,t:1527026968888};\\\", \\\"{x:610,y:605,t:1527026968894};\\\", \\\"{x:609,y:603,t:1527026968906};\\\", \\\"{x:609,y:600,t:1527026968924};\\\", \\\"{x:609,y:599,t:1527026968943};\\\", \\\"{x:609,y:598,t:1527026968956};\\\", \\\"{x:609,y:597,t:1527026968974};\\\", \\\"{x:610,y:596,t:1527026968991};\\\", \\\"{x:611,y:595,t:1527026969006};\\\", \\\"{x:614,y:593,t:1527026969025};\\\", \\\"{x:614,y:591,t:1527026969040};\\\", \\\"{x:614,y:588,t:1527026969057};\\\", \\\"{x:614,y:586,t:1527026969073};\\\", \\\"{x:613,y:588,t:1527026971128};\\\", \\\"{x:613,y:591,t:1527026971142};\\\", \\\"{x:609,y:596,t:1527026971159};\\\", \\\"{x:609,y:599,t:1527026971175};\\\", \\\"{x:607,y:600,t:1527026971191};\\\", \\\"{x:607,y:602,t:1527026971881};\\\", \\\"{x:605,y:609,t:1527026971892};\\\", \\\"{x:596,y:624,t:1527026971908};\\\", \\\"{x:590,y:636,t:1527026971926};\\\", \\\"{x:584,y:645,t:1527026971942};\\\", \\\"{x:581,y:652,t:1527026971958};\\\", \\\"{x:576,y:658,t:1527026971975};\\\", \\\"{x:572,y:662,t:1527026971992};\\\", \\\"{x:559,y:670,t:1527026972009};\\\", \\\"{x:543,y:680,t:1527026972025};\\\", \\\"{x:527,y:689,t:1527026972043};\\\", \\\"{x:508,y:698,t:1527026972058};\\\", \\\"{x:494,y:704,t:1527026972075};\\\", \\\"{x:486,y:709,t:1527026972092};\\\", \\\"{x:483,y:709,t:1527026972110};\\\", \\\"{x:483,y:710,t:1527026972125};\\\", \\\"{x:487,y:715,t:1527026972288};\\\", \\\"{x:492,y:721,t:1527026972297};\\\", \\\"{x:496,y:726,t:1527026972309};\\\", \\\"{x:504,y:733,t:1527026972325};\\\", \\\"{x:509,y:735,t:1527026972342};\\\", \\\"{x:510,y:735,t:1527026972360};\\\", \\\"{x:510,y:733,t:1527026972912};\\\", \\\"{x:510,y:731,t:1527026972928};\\\", \\\"{x:510,y:730,t:1527026972943};\\\", \\\"{x:510,y:729,t:1527026972960};\\\", \\\"{x:510,y:727,t:1527026972977};\\\", \\\"{x:510,y:726,t:1527026973008};\\\", \\\"{x:510,y:725,t:1527026973040};\\\", \\\"{x:510,y:724,t:1527026973056};\\\" ] }, { \\\"rt\\\": 13847, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 318904, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:511,y:723,t:1527026977216};\\\", \\\"{x:534,y:714,t:1527026977234};\\\", \\\"{x:585,y:699,t:1527026977250};\\\", \\\"{x:656,y:684,t:1527026977266};\\\", \\\"{x:725,y:674,t:1527026977279};\\\", \\\"{x:820,y:662,t:1527026977297};\\\", \\\"{x:930,y:652,t:1527026977312};\\\", \\\"{x:1060,y:652,t:1527026977330};\\\", \\\"{x:1179,y:652,t:1527026977347};\\\", \\\"{x:1284,y:652,t:1527026977363};\\\", \\\"{x:1345,y:652,t:1527026977380};\\\", \\\"{x:1374,y:652,t:1527026977396};\\\", \\\"{x:1381,y:652,t:1527026977413};\\\", \\\"{x:1384,y:652,t:1527026977430};\\\", \\\"{x:1385,y:652,t:1527026977446};\\\", \\\"{x:1385,y:653,t:1527026977896};\\\", \\\"{x:1385,y:658,t:1527026978720};\\\", \\\"{x:1392,y:671,t:1527026978731};\\\", \\\"{x:1428,y:708,t:1527026978747};\\\", \\\"{x:1480,y:751,t:1527026978765};\\\", \\\"{x:1531,y:788,t:1527026978781};\\\", \\\"{x:1564,y:808,t:1527026978798};\\\", \\\"{x:1598,y:826,t:1527026978815};\\\", \\\"{x:1620,y:833,t:1527026978831};\\\", \\\"{x:1629,y:838,t:1527026978848};\\\", \\\"{x:1633,y:844,t:1527026978864};\\\", \\\"{x:1633,y:854,t:1527026978882};\\\", \\\"{x:1631,y:868,t:1527026978899};\\\", \\\"{x:1627,y:876,t:1527026978915};\\\", \\\"{x:1623,y:882,t:1527026978931};\\\", \\\"{x:1618,y:887,t:1527026978948};\\\", \\\"{x:1605,y:897,t:1527026978964};\\\", \\\"{x:1589,y:907,t:1527026978981};\\\", \\\"{x:1571,y:921,t:1527026978999};\\\", \\\"{x:1552,y:933,t:1527026979015};\\\", \\\"{x:1528,y:947,t:1527026979031};\\\", \\\"{x:1515,y:951,t:1527026979048};\\\", \\\"{x:1513,y:952,t:1527026979064};\\\", \\\"{x:1511,y:954,t:1527026979081};\\\", \\\"{x:1510,y:956,t:1527026979280};\\\", \\\"{x:1507,y:958,t:1527026979298};\\\", \\\"{x:1505,y:961,t:1527026979314};\\\", \\\"{x:1503,y:962,t:1527026979331};\\\", \\\"{x:1499,y:964,t:1527026979349};\\\", \\\"{x:1496,y:964,t:1527026979440};\\\", \\\"{x:1494,y:964,t:1527026979448};\\\", \\\"{x:1489,y:964,t:1527026979465};\\\", \\\"{x:1486,y:964,t:1527026979481};\\\", \\\"{x:1481,y:963,t:1527026979499};\\\", \\\"{x:1475,y:963,t:1527026979516};\\\", \\\"{x:1471,y:963,t:1527026979531};\\\", \\\"{x:1466,y:963,t:1527026979548};\\\", \\\"{x:1459,y:963,t:1527026979565};\\\", \\\"{x:1455,y:964,t:1527026979581};\\\", \\\"{x:1451,y:964,t:1527026979598};\\\", \\\"{x:1448,y:965,t:1527026979615};\\\", \\\"{x:1445,y:966,t:1527026979632};\\\", \\\"{x:1443,y:966,t:1527026979649};\\\", \\\"{x:1442,y:966,t:1527026979665};\\\", \\\"{x:1441,y:966,t:1527026979682};\\\", \\\"{x:1438,y:966,t:1527026979698};\\\", \\\"{x:1436,y:966,t:1527026979716};\\\", \\\"{x:1435,y:966,t:1527026979731};\\\", \\\"{x:1433,y:966,t:1527026979760};\\\", \\\"{x:1432,y:966,t:1527026979808};\\\", \\\"{x:1429,y:966,t:1527026979815};\\\", \\\"{x:1427,y:965,t:1527026979832};\\\", \\\"{x:1425,y:963,t:1527026979849};\\\", \\\"{x:1423,y:961,t:1527026979865};\\\", \\\"{x:1421,y:960,t:1527026979883};\\\", \\\"{x:1419,y:959,t:1527026979898};\\\", \\\"{x:1418,y:958,t:1527026979919};\\\", \\\"{x:1417,y:958,t:1527026979944};\\\", \\\"{x:1416,y:958,t:1527026979952};\\\", \\\"{x:1415,y:958,t:1527026979965};\\\", \\\"{x:1412,y:957,t:1527026979982};\\\", \\\"{x:1411,y:957,t:1527026979999};\\\", \\\"{x:1407,y:957,t:1527026980016};\\\", \\\"{x:1406,y:957,t:1527026980032};\\\", \\\"{x:1403,y:957,t:1527026980048};\\\", \\\"{x:1401,y:957,t:1527026980065};\\\", \\\"{x:1398,y:957,t:1527026980082};\\\", \\\"{x:1396,y:958,t:1527026980098};\\\", \\\"{x:1394,y:959,t:1527026980115};\\\", \\\"{x:1393,y:959,t:1527026980143};\\\", \\\"{x:1392,y:960,t:1527026980185};\\\", \\\"{x:1391,y:960,t:1527026980198};\\\", \\\"{x:1385,y:962,t:1527026980216};\\\", \\\"{x:1381,y:963,t:1527026980232};\\\", \\\"{x:1379,y:965,t:1527026980249};\\\", \\\"{x:1376,y:965,t:1527026980266};\\\", \\\"{x:1375,y:965,t:1527026980282};\\\", \\\"{x:1374,y:965,t:1527026980336};\\\", \\\"{x:1372,y:965,t:1527026980348};\\\", \\\"{x:1369,y:965,t:1527026980365};\\\", \\\"{x:1365,y:965,t:1527026980382};\\\", \\\"{x:1362,y:965,t:1527026980398};\\\", \\\"{x:1359,y:965,t:1527026980415};\\\", \\\"{x:1358,y:965,t:1527026980495};\\\", \\\"{x:1356,y:965,t:1527026980504};\\\", \\\"{x:1355,y:965,t:1527026980520};\\\", \\\"{x:1353,y:965,t:1527026980536};\\\", \\\"{x:1352,y:965,t:1527026980551};\\\", \\\"{x:1351,y:964,t:1527026980565};\\\", \\\"{x:1350,y:964,t:1527026980582};\\\", \\\"{x:1350,y:963,t:1527026980599};\\\", \\\"{x:1349,y:963,t:1527026980881};\\\", \\\"{x:1349,y:962,t:1527026981425};\\\", \\\"{x:1348,y:960,t:1527026981447};\\\", \\\"{x:1348,y:959,t:1527026981480};\\\", \\\"{x:1348,y:958,t:1527026981512};\\\", \\\"{x:1348,y:957,t:1527026981546};\\\", \\\"{x:1348,y:956,t:1527026982896};\\\", \\\"{x:1348,y:954,t:1527026982904};\\\", \\\"{x:1348,y:952,t:1527026982919};\\\", \\\"{x:1348,y:950,t:1527026982935};\\\", \\\"{x:1348,y:949,t:1527026982950};\\\", \\\"{x:1347,y:945,t:1527026982983};\\\", \\\"{x:1347,y:943,t:1527026983000};\\\", \\\"{x:1346,y:939,t:1527026983016};\\\", \\\"{x:1345,y:930,t:1527026983033};\\\", \\\"{x:1345,y:917,t:1527026983050};\\\", \\\"{x:1344,y:900,t:1527026983067};\\\", \\\"{x:1344,y:885,t:1527026983084};\\\", \\\"{x:1344,y:866,t:1527026983100};\\\", \\\"{x:1344,y:845,t:1527026983117};\\\", \\\"{x:1344,y:825,t:1527026983134};\\\", \\\"{x:1344,y:805,t:1527026983150};\\\", \\\"{x:1339,y:772,t:1527026983167};\\\", \\\"{x:1333,y:732,t:1527026983184};\\\", \\\"{x:1329,y:716,t:1527026983200};\\\", \\\"{x:1325,y:705,t:1527026983217};\\\", \\\"{x:1320,y:699,t:1527026983234};\\\", \\\"{x:1311,y:694,t:1527026983250};\\\", \\\"{x:1294,y:689,t:1527026983267};\\\", \\\"{x:1279,y:686,t:1527026983285};\\\", \\\"{x:1258,y:684,t:1527026983300};\\\", \\\"{x:1229,y:684,t:1527026983317};\\\", \\\"{x:1183,y:694,t:1527026983335};\\\", \\\"{x:1120,y:709,t:1527026983351};\\\", \\\"{x:954,y:738,t:1527026983368};\\\", \\\"{x:843,y:754,t:1527026983384};\\\", \\\"{x:782,y:771,t:1527026983401};\\\", \\\"{x:717,y:777,t:1527026983418};\\\", \\\"{x:709,y:781,t:1527026983434};\\\", \\\"{x:708,y:781,t:1527026983450};\\\", \\\"{x:702,y:780,t:1527026983839};\\\", \\\"{x:698,y:780,t:1527026983852};\\\", \\\"{x:689,y:776,t:1527026983867};\\\", \\\"{x:680,y:772,t:1527026983885};\\\", \\\"{x:670,y:769,t:1527026983901};\\\", \\\"{x:661,y:762,t:1527026983917};\\\", \\\"{x:644,y:752,t:1527026983934};\\\", \\\"{x:605,y:721,t:1527026983951};\\\", \\\"{x:573,y:697,t:1527026983967};\\\", \\\"{x:539,y:673,t:1527026983985};\\\", \\\"{x:516,y:656,t:1527026984001};\\\", \\\"{x:499,y:647,t:1527026984020};\\\", \\\"{x:496,y:642,t:1527026984034};\\\", \\\"{x:493,y:638,t:1527026984051};\\\", \\\"{x:491,y:636,t:1527026984069};\\\", \\\"{x:489,y:633,t:1527026984085};\\\", \\\"{x:480,y:626,t:1527026984102};\\\", \\\"{x:469,y:614,t:1527026984119};\\\", \\\"{x:462,y:608,t:1527026984135};\\\", \\\"{x:454,y:601,t:1527026984152};\\\", \\\"{x:445,y:595,t:1527026984169};\\\", \\\"{x:435,y:589,t:1527026984187};\\\", \\\"{x:429,y:583,t:1527026984202};\\\", \\\"{x:427,y:574,t:1527026984219};\\\", \\\"{x:434,y:559,t:1527026984235};\\\", \\\"{x:443,y:545,t:1527026984253};\\\", \\\"{x:454,y:528,t:1527026984269};\\\", \\\"{x:464,y:519,t:1527026984285};\\\", \\\"{x:477,y:511,t:1527026984303};\\\", \\\"{x:488,y:505,t:1527026984318};\\\", \\\"{x:488,y:504,t:1527026984336};\\\", \\\"{x:475,y:504,t:1527026984352};\\\", \\\"{x:445,y:506,t:1527026984369};\\\", \\\"{x:383,y:514,t:1527026984385};\\\", \\\"{x:297,y:525,t:1527026984402};\\\", \\\"{x:222,y:536,t:1527026984419};\\\", \\\"{x:177,y:538,t:1527026984435};\\\", \\\"{x:150,y:538,t:1527026984452};\\\", \\\"{x:133,y:538,t:1527026984469};\\\", \\\"{x:128,y:540,t:1527026984485};\\\", \\\"{x:126,y:540,t:1527026984502};\\\", \\\"{x:125,y:541,t:1527026984518};\\\", \\\"{x:123,y:544,t:1527026984536};\\\", \\\"{x:123,y:546,t:1527026984552};\\\", \\\"{x:123,y:547,t:1527026984575};\\\", \\\"{x:123,y:548,t:1527026984655};\\\", \\\"{x:126,y:548,t:1527026984672};\\\", \\\"{x:128,y:547,t:1527026984687};\\\", \\\"{x:130,y:546,t:1527026984702};\\\", \\\"{x:132,y:545,t:1527026984719};\\\", \\\"{x:133,y:545,t:1527026984736};\\\", \\\"{x:135,y:543,t:1527026984759};\\\", \\\"{x:137,y:543,t:1527026984769};\\\", \\\"{x:139,y:543,t:1527026984786};\\\", \\\"{x:140,y:543,t:1527026984803};\\\", \\\"{x:142,y:543,t:1527026985128};\\\", \\\"{x:143,y:542,t:1527026985136};\\\", \\\"{x:152,y:541,t:1527026985154};\\\", \\\"{x:159,y:541,t:1527026985170};\\\", \\\"{x:160,y:540,t:1527026985185};\\\", \\\"{x:161,y:540,t:1527026985203};\\\", \\\"{x:162,y:540,t:1527026985270};\\\", \\\"{x:162,y:539,t:1527026985286};\\\", \\\"{x:163,y:539,t:1527026985303};\\\", \\\"{x:161,y:539,t:1527026985367};\\\", \\\"{x:160,y:539,t:1527026985375};\\\", \\\"{x:160,y:540,t:1527026985386};\\\", \\\"{x:156,y:540,t:1527026985403};\\\", \\\"{x:156,y:541,t:1527026985420};\\\", \\\"{x:155,y:541,t:1527026985436};\\\", \\\"{x:155,y:542,t:1527026985472};\\\", \\\"{x:154,y:542,t:1527026985511};\\\", \\\"{x:153,y:542,t:1527026985520};\\\", \\\"{x:157,y:542,t:1527026985592};\\\", \\\"{x:162,y:542,t:1527026985603};\\\", \\\"{x:175,y:542,t:1527026985620};\\\", \\\"{x:180,y:542,t:1527026985637};\\\", \\\"{x:179,y:542,t:1527026985776};\\\", \\\"{x:177,y:543,t:1527026985791};\\\", \\\"{x:175,y:544,t:1527026985803};\\\", \\\"{x:173,y:544,t:1527026985821};\\\", \\\"{x:172,y:546,t:1527026985837};\\\", \\\"{x:170,y:546,t:1527026985854};\\\", \\\"{x:168,y:546,t:1527026985871};\\\", \\\"{x:166,y:547,t:1527026985887};\\\", \\\"{x:165,y:548,t:1527026985903};\\\", \\\"{x:164,y:548,t:1527026985920};\\\", \\\"{x:171,y:547,t:1527026986215};\\\", \\\"{x:180,y:547,t:1527026986223};\\\", \\\"{x:195,y:547,t:1527026986237};\\\", \\\"{x:220,y:547,t:1527026986254};\\\", \\\"{x:247,y:547,t:1527026986270};\\\", \\\"{x:306,y:547,t:1527026986288};\\\", \\\"{x:362,y:547,t:1527026986304};\\\", \\\"{x:432,y:545,t:1527026986320};\\\", \\\"{x:521,y:532,t:1527026986340};\\\", \\\"{x:610,y:521,t:1527026986354};\\\", \\\"{x:677,y:508,t:1527026986372};\\\", \\\"{x:714,y:503,t:1527026986387};\\\", \\\"{x:732,y:499,t:1527026986404};\\\", \\\"{x:747,y:497,t:1527026986420};\\\", \\\"{x:766,y:494,t:1527026986437};\\\", \\\"{x:782,y:491,t:1527026986454};\\\", \\\"{x:810,y:487,t:1527026986471};\\\", \\\"{x:822,y:482,t:1527026986488};\\\", \\\"{x:829,y:481,t:1527026986504};\\\", \\\"{x:831,y:480,t:1527026986521};\\\", \\\"{x:832,y:480,t:1527026986537};\\\", \\\"{x:834,y:480,t:1527026986583};\\\", \\\"{x:835,y:480,t:1527026986591};\\\", \\\"{x:836,y:480,t:1527026986604};\\\", \\\"{x:839,y:481,t:1527026986621};\\\", \\\"{x:840,y:486,t:1527026986637};\\\", \\\"{x:844,y:493,t:1527026986656};\\\", \\\"{x:847,y:499,t:1527026986671};\\\", \\\"{x:847,y:501,t:1527026986687};\\\", \\\"{x:846,y:502,t:1527026986705};\\\", \\\"{x:840,y:506,t:1527026986721};\\\", \\\"{x:838,y:506,t:1527026986737};\\\", \\\"{x:838,y:507,t:1527026986754};\\\", \\\"{x:837,y:507,t:1527026986772};\\\", \\\"{x:833,y:510,t:1527026987046};\\\", \\\"{x:828,y:513,t:1527026987055};\\\", \\\"{x:813,y:522,t:1527026987071};\\\", \\\"{x:799,y:536,t:1527026987088};\\\", \\\"{x:780,y:560,t:1527026987105};\\\", \\\"{x:758,y:587,t:1527026987121};\\\", \\\"{x:728,y:622,t:1527026987139};\\\", \\\"{x:703,y:657,t:1527026987154};\\\", \\\"{x:678,y:687,t:1527026987171};\\\", \\\"{x:661,y:703,t:1527026987188};\\\", \\\"{x:646,y:715,t:1527026987204};\\\", \\\"{x:633,y:724,t:1527026987221};\\\", \\\"{x:625,y:727,t:1527026987238};\\\", \\\"{x:614,y:730,t:1527026987255};\\\", \\\"{x:605,y:732,t:1527026987271};\\\", \\\"{x:594,y:733,t:1527026987288};\\\", \\\"{x:580,y:733,t:1527026987305};\\\", \\\"{x:572,y:733,t:1527026987322};\\\", \\\"{x:564,y:733,t:1527026987339};\\\", \\\"{x:561,y:733,t:1527026987355};\\\", \\\"{x:558,y:733,t:1527026987371};\\\", \\\"{x:556,y:733,t:1527026987399};\\\", \\\"{x:554,y:733,t:1527026987424};\\\", \\\"{x:553,y:733,t:1527026987438};\\\", \\\"{x:551,y:731,t:1527026988039};\\\", \\\"{x:550,y:730,t:1527026988054};\\\", \\\"{x:550,y:729,t:1527026988072};\\\", \\\"{x:550,y:727,t:1527026988088};\\\", \\\"{x:549,y:727,t:1527026988105};\\\", \\\"{x:548,y:725,t:1527026988122};\\\", \\\"{x:548,y:724,t:1527026988138};\\\", \\\"{x:547,y:724,t:1527026988155};\\\", \\\"{x:547,y:723,t:1527026988199};\\\", \\\"{x:546,y:722,t:1527026988223};\\\", \\\"{x:546,y:721,t:1527026988264};\\\", \\\"{x:546,y:720,t:1527026988327};\\\", \\\"{x:546,y:719,t:1527026988344};\\\", \\\"{x:545,y:717,t:1527026988367};\\\", \\\"{x:544,y:716,t:1527026988504};\\\" ] }, { \\\"rt\\\": 4357, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 324550, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:544,y:715,t:1527026989576};\\\", \\\"{x:544,y:714,t:1527026989591};\\\", \\\"{x:544,y:713,t:1527026989637};\\\", \\\"{x:544,y:712,t:1527026989663};\\\", \\\"{x:544,y:711,t:1527026989711};\\\", \\\"{x:544,y:710,t:1527026989743};\\\", \\\"{x:545,y:710,t:1527026989775};\\\", \\\"{x:545,y:709,t:1527026989790};\\\", \\\"{x:547,y:708,t:1527026989806};\\\", \\\"{x:566,y:701,t:1527026989824};\\\", \\\"{x:600,y:695,t:1527026989840};\\\", \\\"{x:675,y:695,t:1527026989856};\\\", \\\"{x:761,y:695,t:1527026989873};\\\", \\\"{x:856,y:695,t:1527026989890};\\\", \\\"{x:969,y:695,t:1527026989906};\\\", \\\"{x:1099,y:711,t:1527026989924};\\\", \\\"{x:1218,y:727,t:1527026989940};\\\", \\\"{x:1343,y:746,t:1527026989957};\\\", \\\"{x:1437,y:755,t:1527026989974};\\\", \\\"{x:1480,y:757,t:1527026989991};\\\", \\\"{x:1479,y:757,t:1527026990496};\\\", \\\"{x:1475,y:757,t:1527026990508};\\\", \\\"{x:1471,y:757,t:1527026990525};\\\", \\\"{x:1466,y:757,t:1527026990541};\\\", \\\"{x:1460,y:757,t:1527026990558};\\\", \\\"{x:1452,y:757,t:1527026990575};\\\", \\\"{x:1443,y:757,t:1527026990591};\\\", \\\"{x:1428,y:757,t:1527026990608};\\\", \\\"{x:1420,y:757,t:1527026990626};\\\", \\\"{x:1411,y:757,t:1527026990641};\\\", \\\"{x:1404,y:757,t:1527026990657};\\\", \\\"{x:1396,y:757,t:1527026990675};\\\", \\\"{x:1388,y:757,t:1527026990691};\\\", \\\"{x:1380,y:757,t:1527026990708};\\\", \\\"{x:1370,y:757,t:1527026990725};\\\", \\\"{x:1362,y:754,t:1527026990740};\\\", \\\"{x:1358,y:752,t:1527026990758};\\\", \\\"{x:1358,y:750,t:1527026990775};\\\", \\\"{x:1358,y:748,t:1527026990791};\\\", \\\"{x:1358,y:742,t:1527026990808};\\\", \\\"{x:1357,y:737,t:1527026990826};\\\", \\\"{x:1353,y:729,t:1527026990842};\\\", \\\"{x:1353,y:724,t:1527026990858};\\\", \\\"{x:1353,y:720,t:1527026990876};\\\", \\\"{x:1353,y:718,t:1527026990892};\\\", \\\"{x:1353,y:716,t:1527026990908};\\\", \\\"{x:1353,y:715,t:1527026990925};\\\", \\\"{x:1353,y:713,t:1527026990942};\\\", \\\"{x:1352,y:711,t:1527026990958};\\\", \\\"{x:1351,y:711,t:1527026990975};\\\", \\\"{x:1349,y:711,t:1527026991064};\\\", \\\"{x:1349,y:715,t:1527026991075};\\\", \\\"{x:1345,y:732,t:1527026991092};\\\", \\\"{x:1343,y:749,t:1527026991108};\\\", \\\"{x:1341,y:762,t:1527026991126};\\\", \\\"{x:1340,y:769,t:1527026991142};\\\", \\\"{x:1340,y:771,t:1527026991158};\\\", \\\"{x:1340,y:772,t:1527026991175};\\\", \\\"{x:1340,y:773,t:1527026991232};\\\", \\\"{x:1337,y:772,t:1527026991344};\\\", \\\"{x:1330,y:771,t:1527026991358};\\\", \\\"{x:1268,y:760,t:1527026991375};\\\", \\\"{x:1171,y:732,t:1527026991391};\\\", \\\"{x:1020,y:697,t:1527026991409};\\\", \\\"{x:850,y:666,t:1527026991427};\\\", \\\"{x:721,y:632,t:1527026991441};\\\", \\\"{x:635,y:609,t:1527026991460};\\\", \\\"{x:572,y:587,t:1527026991475};\\\", \\\"{x:511,y:559,t:1527026991491};\\\", \\\"{x:449,y:524,t:1527026991524};\\\", \\\"{x:449,y:523,t:1527026991541};\\\", \\\"{x:449,y:521,t:1527026991559};\\\", \\\"{x:450,y:520,t:1527026991574};\\\", \\\"{x:455,y:516,t:1527026991591};\\\", \\\"{x:459,y:514,t:1527026991607};\\\", \\\"{x:468,y:508,t:1527026991624};\\\", \\\"{x:479,y:505,t:1527026991641};\\\", \\\"{x:493,y:504,t:1527026991658};\\\", \\\"{x:510,y:504,t:1527026991675};\\\", \\\"{x:518,y:504,t:1527026991691};\\\", \\\"{x:520,y:505,t:1527026991708};\\\", \\\"{x:520,y:510,t:1527026991726};\\\", \\\"{x:514,y:517,t:1527026991741};\\\", \\\"{x:497,y:526,t:1527026991759};\\\", \\\"{x:445,y:548,t:1527026991775};\\\", \\\"{x:415,y:559,t:1527026991791};\\\", \\\"{x:396,y:564,t:1527026991808};\\\", \\\"{x:378,y:565,t:1527026991825};\\\", \\\"{x:367,y:565,t:1527026991842};\\\", \\\"{x:359,y:565,t:1527026991858};\\\", \\\"{x:358,y:563,t:1527026991875};\\\", \\\"{x:357,y:563,t:1527026991959};\\\", \\\"{x:356,y:559,t:1527026991976};\\\", \\\"{x:353,y:555,t:1527026991991};\\\", \\\"{x:348,y:551,t:1527026992008};\\\", \\\"{x:337,y:544,t:1527026992025};\\\", \\\"{x:300,y:535,t:1527026992042};\\\", \\\"{x:266,y:530,t:1527026992059};\\\", \\\"{x:229,y:530,t:1527026992076};\\\", \\\"{x:202,y:530,t:1527026992091};\\\", \\\"{x:180,y:533,t:1527026992108};\\\", \\\"{x:169,y:537,t:1527026992126};\\\", \\\"{x:164,y:540,t:1527026992142};\\\", \\\"{x:163,y:541,t:1527026992158};\\\", \\\"{x:163,y:542,t:1527026992183};\\\", \\\"{x:164,y:542,t:1527026992503};\\\", \\\"{x:166,y:543,t:1527026992511};\\\", \\\"{x:170,y:546,t:1527026992525};\\\", \\\"{x:188,y:554,t:1527026992542};\\\", \\\"{x:241,y:584,t:1527026992560};\\\", \\\"{x:295,y:613,t:1527026992576};\\\", \\\"{x:348,y:651,t:1527026992594};\\\", \\\"{x:392,y:676,t:1527026992610};\\\", \\\"{x:428,y:698,t:1527026992625};\\\", \\\"{x:455,y:718,t:1527026992642};\\\", \\\"{x:471,y:731,t:1527026992659};\\\", \\\"{x:472,y:737,t:1527026992675};\\\", \\\"{x:473,y:739,t:1527026992692};\\\", \\\"{x:473,y:740,t:1527026992710};\\\", \\\"{x:473,y:741,t:1527026992726};\\\", \\\"{x:475,y:746,t:1527026992743};\\\", \\\"{x:480,y:748,t:1527026992759};\\\", \\\"{x:487,y:752,t:1527026992776};\\\", \\\"{x:493,y:756,t:1527026992793};\\\", \\\"{x:501,y:756,t:1527026992809};\\\", \\\"{x:505,y:756,t:1527026992825};\\\", \\\"{x:509,y:756,t:1527026992842};\\\", \\\"{x:510,y:756,t:1527026992859};\\\", \\\"{x:511,y:756,t:1527026992879};\\\", \\\"{x:511,y:755,t:1527026992911};\\\", \\\"{x:511,y:752,t:1527026992926};\\\", \\\"{x:511,y:747,t:1527026992943};\\\", \\\"{x:509,y:744,t:1527026992959};\\\", \\\"{x:508,y:743,t:1527026992976};\\\", \\\"{x:507,y:742,t:1527026993903};\\\", \\\"{x:507,y:741,t:1527026993984};\\\", \\\"{x:506,y:741,t:1527026993994};\\\", \\\"{x:506,y:739,t:1527026994010};\\\", \\\"{x:506,y:738,t:1527026994063};\\\" ] }, { \\\"rt\\\": 21298, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 347106, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -M -M -C -C -C -C -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:736,t:1527026994927};\\\", \\\"{x:506,y:735,t:1527026994975};\\\", \\\"{x:505,y:734,t:1527026995030};\\\", \\\"{x:505,y:733,t:1527026995062};\\\", \\\"{x:505,y:732,t:1527026995167};\\\", \\\"{x:505,y:730,t:1527026995287};\\\", \\\"{x:505,y:729,t:1527026995343};\\\", \\\"{x:505,y:727,t:1527026995472};\\\", \\\"{x:505,y:726,t:1527026995544};\\\", \\\"{x:505,y:725,t:1527026995639};\\\", \\\"{x:506,y:724,t:1527026995648};\\\", \\\"{x:508,y:723,t:1527026995662};\\\", \\\"{x:511,y:722,t:1527026995679};\\\", \\\"{x:518,y:718,t:1527026995696};\\\", \\\"{x:529,y:715,t:1527026995712};\\\", \\\"{x:550,y:708,t:1527026995728};\\\", \\\"{x:581,y:698,t:1527026995745};\\\", \\\"{x:637,y:690,t:1527026995761};\\\", \\\"{x:715,y:687,t:1527026995778};\\\", \\\"{x:818,y:687,t:1527026995795};\\\", \\\"{x:940,y:687,t:1527026995812};\\\", \\\"{x:1065,y:685,t:1527026995828};\\\", \\\"{x:1188,y:692,t:1527026995844};\\\", \\\"{x:1286,y:696,t:1527026995862};\\\", \\\"{x:1368,y:701,t:1527026995879};\\\", \\\"{x:1392,y:702,t:1527026995895};\\\", \\\"{x:1395,y:703,t:1527026995912};\\\", \\\"{x:1397,y:703,t:1527026995976};\\\", \\\"{x:1398,y:703,t:1527026995999};\\\", \\\"{x:1399,y:703,t:1527026996424};\\\", \\\"{x:1399,y:704,t:1527026996711};\\\", \\\"{x:1402,y:709,t:1527026996729};\\\", \\\"{x:1403,y:711,t:1527026996746};\\\", \\\"{x:1406,y:715,t:1527026996763};\\\", \\\"{x:1410,y:719,t:1527026996779};\\\", \\\"{x:1414,y:723,t:1527026996796};\\\", \\\"{x:1420,y:729,t:1527026996813};\\\", \\\"{x:1427,y:734,t:1527026996830};\\\", \\\"{x:1435,y:742,t:1527026996846};\\\", \\\"{x:1443,y:747,t:1527026996864};\\\", \\\"{x:1449,y:753,t:1527026996879};\\\", \\\"{x:1456,y:758,t:1527026996895};\\\", \\\"{x:1463,y:764,t:1527026996912};\\\", \\\"{x:1473,y:772,t:1527026996930};\\\", \\\"{x:1483,y:781,t:1527026996945};\\\", \\\"{x:1492,y:786,t:1527026996963};\\\", \\\"{x:1503,y:791,t:1527026996980};\\\", \\\"{x:1515,y:796,t:1527026996995};\\\", \\\"{x:1526,y:802,t:1527026997012};\\\", \\\"{x:1538,y:806,t:1527026997029};\\\", \\\"{x:1553,y:811,t:1527026997045};\\\", \\\"{x:1580,y:817,t:1527026997063};\\\", \\\"{x:1594,y:819,t:1527026997078};\\\", \\\"{x:1610,y:822,t:1527026997096};\\\", \\\"{x:1621,y:823,t:1527026997113};\\\", \\\"{x:1632,y:824,t:1527026997130};\\\", \\\"{x:1643,y:824,t:1527026997146};\\\", \\\"{x:1653,y:824,t:1527026997163};\\\", \\\"{x:1662,y:824,t:1527026997180};\\\", \\\"{x:1668,y:824,t:1527026997196};\\\", \\\"{x:1670,y:824,t:1527026997213};\\\", \\\"{x:1672,y:824,t:1527026997230};\\\", \\\"{x:1673,y:824,t:1527026997280};\\\", \\\"{x:1674,y:824,t:1527026997297};\\\", \\\"{x:1674,y:822,t:1527026997314};\\\", \\\"{x:1674,y:818,t:1527026997330};\\\", \\\"{x:1674,y:816,t:1527026997346};\\\", \\\"{x:1674,y:814,t:1527026997363};\\\", \\\"{x:1674,y:810,t:1527026997380};\\\", \\\"{x:1671,y:807,t:1527026997397};\\\", \\\"{x:1667,y:802,t:1527026997413};\\\", \\\"{x:1662,y:797,t:1527026997430};\\\", \\\"{x:1649,y:783,t:1527026997447};\\\", \\\"{x:1643,y:778,t:1527026997463};\\\", \\\"{x:1637,y:774,t:1527026997479};\\\", \\\"{x:1633,y:772,t:1527026997497};\\\", \\\"{x:1631,y:770,t:1527026997513};\\\", \\\"{x:1626,y:768,t:1527026997530};\\\", \\\"{x:1621,y:766,t:1527026997548};\\\", \\\"{x:1618,y:765,t:1527026997563};\\\", \\\"{x:1615,y:764,t:1527026997580};\\\", \\\"{x:1613,y:763,t:1527026997597};\\\", \\\"{x:1611,y:762,t:1527026997616};\\\", \\\"{x:1611,y:761,t:1527026997640};\\\", \\\"{x:1611,y:760,t:1527026997647};\\\", \\\"{x:1609,y:757,t:1527026997663};\\\", \\\"{x:1609,y:755,t:1527026997687};\\\", \\\"{x:1609,y:754,t:1527026997697};\\\", \\\"{x:1609,y:751,t:1527026997713};\\\", \\\"{x:1609,y:748,t:1527026997730};\\\", \\\"{x:1609,y:745,t:1527026997747};\\\", \\\"{x:1609,y:742,t:1527026997763};\\\", \\\"{x:1608,y:740,t:1527026997780};\\\", \\\"{x:1608,y:738,t:1527026997797};\\\", \\\"{x:1608,y:735,t:1527026997814};\\\", \\\"{x:1608,y:731,t:1527026997830};\\\", \\\"{x:1608,y:725,t:1527026997848};\\\", \\\"{x:1608,y:723,t:1527026997864};\\\", \\\"{x:1608,y:721,t:1527026997880};\\\", \\\"{x:1608,y:717,t:1527026997897};\\\", \\\"{x:1608,y:714,t:1527026997914};\\\", \\\"{x:1608,y:712,t:1527026997930};\\\", \\\"{x:1608,y:711,t:1527026997947};\\\", \\\"{x:1608,y:709,t:1527026997964};\\\", \\\"{x:1608,y:708,t:1527026997980};\\\", \\\"{x:1608,y:706,t:1527026997998};\\\", \\\"{x:1608,y:705,t:1527026998014};\\\", \\\"{x:1608,y:704,t:1527026998030};\\\", \\\"{x:1608,y:699,t:1527026998048};\\\", \\\"{x:1608,y:698,t:1527026998064};\\\", \\\"{x:1608,y:696,t:1527026998081};\\\", \\\"{x:1608,y:695,t:1527026998097};\\\", \\\"{x:1608,y:693,t:1527026998114};\\\", \\\"{x:1598,y:692,t:1527027004704};\\\", \\\"{x:1549,y:708,t:1527027004720};\\\", \\\"{x:1470,y:724,t:1527027004736};\\\", \\\"{x:1365,y:736,t:1527027004752};\\\", \\\"{x:1235,y:736,t:1527027004769};\\\", \\\"{x:1116,y:736,t:1527027004785};\\\", \\\"{x:994,y:723,t:1527027004803};\\\", \\\"{x:890,y:701,t:1527027004820};\\\", \\\"{x:825,y:685,t:1527027004836};\\\", \\\"{x:804,y:679,t:1527027004852};\\\", \\\"{x:798,y:678,t:1527027004869};\\\", \\\"{x:797,y:676,t:1527027004895};\\\", \\\"{x:795,y:676,t:1527027004903};\\\", \\\"{x:792,y:674,t:1527027004919};\\\", \\\"{x:781,y:671,t:1527027004936};\\\", \\\"{x:770,y:667,t:1527027004952};\\\", \\\"{x:755,y:662,t:1527027004970};\\\", \\\"{x:743,y:656,t:1527027004986};\\\", \\\"{x:732,y:650,t:1527027005002};\\\", \\\"{x:717,y:641,t:1527027005019};\\\", \\\"{x:700,y:630,t:1527027005037};\\\", \\\"{x:683,y:617,t:1527027005052};\\\", \\\"{x:670,y:608,t:1527027005068};\\\", \\\"{x:655,y:598,t:1527027005086};\\\", \\\"{x:641,y:590,t:1527027005103};\\\", \\\"{x:635,y:586,t:1527027005118};\\\", \\\"{x:634,y:585,t:1527027005136};\\\", \\\"{x:632,y:584,t:1527027005182};\\\", \\\"{x:631,y:583,t:1527027005190};\\\", \\\"{x:630,y:583,t:1527027005295};\\\", \\\"{x:631,y:583,t:1527027005622};\\\", \\\"{x:639,y:583,t:1527027005635};\\\", \\\"{x:665,y:586,t:1527027005654};\\\", \\\"{x:703,y:590,t:1527027005670};\\\", \\\"{x:759,y:598,t:1527027005687};\\\", \\\"{x:856,y:613,t:1527027005704};\\\", \\\"{x:951,y:629,t:1527027005720};\\\", \\\"{x:1051,y:642,t:1527027005736};\\\", \\\"{x:1154,y:658,t:1527027005753};\\\", \\\"{x:1256,y:672,t:1527027005770};\\\", \\\"{x:1334,y:683,t:1527027005786};\\\", \\\"{x:1390,y:691,t:1527027005803};\\\", \\\"{x:1427,y:702,t:1527027005820};\\\", \\\"{x:1454,y:709,t:1527027005836};\\\", \\\"{x:1476,y:718,t:1527027005853};\\\", \\\"{x:1493,y:725,t:1527027005870};\\\", \\\"{x:1508,y:733,t:1527027005886};\\\", \\\"{x:1520,y:742,t:1527027005902};\\\", \\\"{x:1524,y:745,t:1527027005920};\\\", \\\"{x:1526,y:748,t:1527027005937};\\\", \\\"{x:1528,y:752,t:1527027005953};\\\", \\\"{x:1531,y:760,t:1527027005970};\\\", \\\"{x:1535,y:767,t:1527027005986};\\\", \\\"{x:1536,y:771,t:1527027006002};\\\", \\\"{x:1537,y:772,t:1527027006020};\\\", \\\"{x:1538,y:772,t:1527027006062};\\\", \\\"{x:1541,y:772,t:1527027006070};\\\", \\\"{x:1548,y:772,t:1527027006086};\\\", \\\"{x:1557,y:772,t:1527027006103};\\\", \\\"{x:1566,y:769,t:1527027006120};\\\", \\\"{x:1577,y:765,t:1527027006137};\\\", \\\"{x:1583,y:761,t:1527027006153};\\\", \\\"{x:1589,y:758,t:1527027006170};\\\", \\\"{x:1590,y:757,t:1527027006187};\\\", \\\"{x:1591,y:757,t:1527027006203};\\\", \\\"{x:1590,y:756,t:1527027006254};\\\", \\\"{x:1589,y:756,t:1527027006270};\\\", \\\"{x:1577,y:759,t:1527027006286};\\\", \\\"{x:1560,y:774,t:1527027006303};\\\", \\\"{x:1526,y:804,t:1527027006320};\\\", \\\"{x:1484,y:832,t:1527027006338};\\\", \\\"{x:1455,y:853,t:1527027006354};\\\", \\\"{x:1435,y:862,t:1527027006370};\\\", \\\"{x:1420,y:868,t:1527027006387};\\\", \\\"{x:1411,y:874,t:1527027006403};\\\", \\\"{x:1407,y:877,t:1527027006420};\\\", \\\"{x:1403,y:881,t:1527027006437};\\\", \\\"{x:1402,y:885,t:1527027006453};\\\", \\\"{x:1399,y:889,t:1527027006470};\\\", \\\"{x:1387,y:895,t:1527027006487};\\\", \\\"{x:1386,y:896,t:1527027006504};\\\", \\\"{x:1383,y:897,t:1527027006520};\\\", \\\"{x:1382,y:897,t:1527027006824};\\\", \\\"{x:1382,y:896,t:1527027006837};\\\", \\\"{x:1378,y:890,t:1527027006855};\\\", \\\"{x:1374,y:880,t:1527027006872};\\\", \\\"{x:1373,y:875,t:1527027006887};\\\", \\\"{x:1372,y:868,t:1527027006904};\\\", \\\"{x:1372,y:862,t:1527027006921};\\\", \\\"{x:1372,y:852,t:1527027006936};\\\", \\\"{x:1372,y:844,t:1527027006953};\\\", \\\"{x:1372,y:829,t:1527027006971};\\\", \\\"{x:1372,y:811,t:1527027006986};\\\", \\\"{x:1379,y:787,t:1527027007004};\\\", \\\"{x:1390,y:752,t:1527027007021};\\\", \\\"{x:1398,y:722,t:1527027007037};\\\", \\\"{x:1402,y:706,t:1527027007054};\\\", \\\"{x:1413,y:683,t:1527027007070};\\\", \\\"{x:1419,y:669,t:1527027007087};\\\", \\\"{x:1428,y:656,t:1527027007104};\\\", \\\"{x:1433,y:646,t:1527027007121};\\\", \\\"{x:1438,y:639,t:1527027007137};\\\", \\\"{x:1442,y:634,t:1527027007154};\\\", \\\"{x:1442,y:632,t:1527027007171};\\\", \\\"{x:1443,y:629,t:1527027007188};\\\", \\\"{x:1444,y:628,t:1527027007204};\\\", \\\"{x:1444,y:626,t:1527027007221};\\\", \\\"{x:1445,y:624,t:1527027007238};\\\", \\\"{x:1445,y:621,t:1527027007254};\\\", \\\"{x:1445,y:617,t:1527027007270};\\\", \\\"{x:1444,y:615,t:1527027007288};\\\", \\\"{x:1441,y:612,t:1527027007305};\\\", \\\"{x:1438,y:609,t:1527027007321};\\\", \\\"{x:1437,y:607,t:1527027007338};\\\", \\\"{x:1436,y:605,t:1527027007354};\\\", \\\"{x:1434,y:604,t:1527027007371};\\\", \\\"{x:1432,y:604,t:1527027007424};\\\", \\\"{x:1430,y:604,t:1527027007439};\\\", \\\"{x:1426,y:613,t:1527027007454};\\\", \\\"{x:1425,y:624,t:1527027007471};\\\", \\\"{x:1425,y:626,t:1527027007489};\\\", \\\"{x:1425,y:628,t:1527027007505};\\\", \\\"{x:1426,y:630,t:1527027007521};\\\", \\\"{x:1428,y:631,t:1527027007538};\\\", \\\"{x:1429,y:631,t:1527027007553};\\\", \\\"{x:1433,y:632,t:1527027007570};\\\", \\\"{x:1437,y:633,t:1527027007590};\\\", \\\"{x:1439,y:635,t:1527027007606};\\\", \\\"{x:1440,y:635,t:1527027007621};\\\", \\\"{x:1441,y:635,t:1527027007638};\\\", \\\"{x:1442,y:635,t:1527027007654};\\\", \\\"{x:1443,y:635,t:1527027007671};\\\", \\\"{x:1447,y:635,t:1527027007688};\\\", \\\"{x:1451,y:635,t:1527027007706};\\\", \\\"{x:1454,y:635,t:1527027007720};\\\", \\\"{x:1455,y:635,t:1527027007738};\\\", \\\"{x:1454,y:635,t:1527027008199};\\\", \\\"{x:1453,y:635,t:1527027008207};\\\", \\\"{x:1451,y:634,t:1527027009119};\\\", \\\"{x:1444,y:632,t:1527027009139};\\\", \\\"{x:1438,y:632,t:1527027009157};\\\", \\\"{x:1431,y:632,t:1527027009172};\\\", \\\"{x:1425,y:632,t:1527027009189};\\\", \\\"{x:1418,y:636,t:1527027009206};\\\", \\\"{x:1408,y:644,t:1527027009223};\\\", \\\"{x:1399,y:650,t:1527027009239};\\\", \\\"{x:1391,y:656,t:1527027009256};\\\", \\\"{x:1382,y:664,t:1527027009273};\\\", \\\"{x:1370,y:674,t:1527027009290};\\\", \\\"{x:1362,y:682,t:1527027009306};\\\", \\\"{x:1357,y:689,t:1527027009323};\\\", \\\"{x:1354,y:693,t:1527027009340};\\\", \\\"{x:1352,y:695,t:1527027009357};\\\", \\\"{x:1352,y:696,t:1527027009373};\\\", \\\"{x:1350,y:697,t:1527027009389};\\\", \\\"{x:1349,y:699,t:1527027009407};\\\", \\\"{x:1347,y:700,t:1527027009423};\\\", \\\"{x:1345,y:700,t:1527027009447};\\\", \\\"{x:1336,y:698,t:1527027013776};\\\", \\\"{x:1291,y:686,t:1527027013793};\\\", \\\"{x:1228,y:671,t:1527027013810};\\\", \\\"{x:1115,y:644,t:1527027013826};\\\", \\\"{x:1009,y:624,t:1527027013846};\\\", \\\"{x:928,y:611,t:1527027013861};\\\", \\\"{x:857,y:597,t:1527027013877};\\\", \\\"{x:812,y:590,t:1527027013893};\\\", \\\"{x:747,y:582,t:1527027013926};\\\", \\\"{x:728,y:578,t:1527027013943};\\\", \\\"{x:711,y:576,t:1527027013959};\\\", \\\"{x:696,y:574,t:1527027013976};\\\", \\\"{x:684,y:572,t:1527027013993};\\\", \\\"{x:679,y:571,t:1527027014009};\\\", \\\"{x:678,y:571,t:1527027014026};\\\", \\\"{x:679,y:570,t:1527027014046};\\\", \\\"{x:683,y:569,t:1527027014060};\\\", \\\"{x:697,y:567,t:1527027014076};\\\", \\\"{x:722,y:563,t:1527027014093};\\\", \\\"{x:770,y:553,t:1527027014112};\\\", \\\"{x:802,y:549,t:1527027014126};\\\", \\\"{x:822,y:545,t:1527027014142};\\\", \\\"{x:832,y:544,t:1527027014159};\\\", \\\"{x:836,y:541,t:1527027014176};\\\", \\\"{x:838,y:540,t:1527027014193};\\\", \\\"{x:838,y:539,t:1527027014209};\\\", \\\"{x:838,y:535,t:1527027014226};\\\", \\\"{x:838,y:533,t:1527027014246};\\\", \\\"{x:838,y:531,t:1527027014258};\\\", \\\"{x:839,y:528,t:1527027014276};\\\", \\\"{x:839,y:526,t:1527027014293};\\\", \\\"{x:839,y:525,t:1527027014309};\\\", \\\"{x:839,y:523,t:1527027014440};\\\", \\\"{x:839,y:521,t:1527027014446};\\\", \\\"{x:839,y:518,t:1527027014460};\\\", \\\"{x:840,y:510,t:1527027014477};\\\", \\\"{x:840,y:509,t:1527027014492};\\\", \\\"{x:840,y:507,t:1527027014510};\\\", \\\"{x:839,y:507,t:1527027015062};\\\", \\\"{x:835,y:507,t:1527027015077};\\\", \\\"{x:823,y:513,t:1527027015093};\\\", \\\"{x:768,y:553,t:1527027015111};\\\", \\\"{x:712,y:601,t:1527027015128};\\\", \\\"{x:662,y:638,t:1527027015144};\\\", \\\"{x:635,y:658,t:1527027015159};\\\", \\\"{x:620,y:669,t:1527027015177};\\\", \\\"{x:610,y:678,t:1527027015194};\\\", \\\"{x:599,y:687,t:1527027015210};\\\", \\\"{x:586,y:700,t:1527027015227};\\\", \\\"{x:572,y:715,t:1527027015244};\\\", \\\"{x:555,y:731,t:1527027015261};\\\", \\\"{x:545,y:742,t:1527027015277};\\\", \\\"{x:538,y:746,t:1527027015294};\\\", \\\"{x:537,y:747,t:1527027015310};\\\", \\\"{x:536,y:747,t:1527027015383};\\\", \\\"{x:535,y:747,t:1527027015394};\\\", \\\"{x:534,y:747,t:1527027015423};\\\", \\\"{x:531,y:747,t:1527027015431};\\\", \\\"{x:529,y:747,t:1527027015445};\\\", \\\"{x:527,y:747,t:1527027015460};\\\", \\\"{x:526,y:747,t:1527027015478};\\\", \\\"{x:525,y:747,t:1527027015494};\\\" ] }, { \\\"rt\\\": 41205, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 389586, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:744,t:1527027018903};\\\", \\\"{x:532,y:743,t:1527027018911};\\\", \\\"{x:538,y:741,t:1527027018927};\\\", \\\"{x:549,y:737,t:1527027018943};\\\", \\\"{x:561,y:736,t:1527027018960};\\\", \\\"{x:580,y:736,t:1527027018977};\\\", \\\"{x:603,y:736,t:1527027018993};\\\", \\\"{x:632,y:736,t:1527027019013};\\\", \\\"{x:702,y:736,t:1527027019030};\\\", \\\"{x:780,y:739,t:1527027019047};\\\", \\\"{x:884,y:756,t:1527027019064};\\\", \\\"{x:984,y:770,t:1527027019080};\\\", \\\"{x:1072,y:781,t:1527027019097};\\\", \\\"{x:1153,y:794,t:1527027019113};\\\", \\\"{x:1234,y:805,t:1527027019130};\\\", \\\"{x:1296,y:817,t:1527027019148};\\\", \\\"{x:1361,y:838,t:1527027019164};\\\", \\\"{x:1404,y:848,t:1527027019181};\\\", \\\"{x:1441,y:859,t:1527027019198};\\\", \\\"{x:1465,y:864,t:1527027019213};\\\", \\\"{x:1482,y:868,t:1527027019231};\\\", \\\"{x:1484,y:869,t:1527027019247};\\\", \\\"{x:1485,y:870,t:1527027019264};\\\", \\\"{x:1489,y:876,t:1527027019280};\\\", \\\"{x:1494,y:884,t:1527027019298};\\\", \\\"{x:1500,y:897,t:1527027019314};\\\", \\\"{x:1510,y:914,t:1527027019330};\\\", \\\"{x:1517,y:927,t:1527027019347};\\\", \\\"{x:1525,y:939,t:1527027019364};\\\", \\\"{x:1537,y:955,t:1527027019380};\\\", \\\"{x:1552,y:976,t:1527027019398};\\\", \\\"{x:1560,y:989,t:1527027019415};\\\", \\\"{x:1570,y:1003,t:1527027019431};\\\", \\\"{x:1571,y:1003,t:1527027019448};\\\", \\\"{x:1573,y:1004,t:1527027019510};\\\", \\\"{x:1574,y:1004,t:1527027019533};\\\", \\\"{x:1574,y:998,t:1527027019573};\\\", \\\"{x:1573,y:994,t:1527027019581};\\\", \\\"{x:1569,y:989,t:1527027019597};\\\", \\\"{x:1568,y:985,t:1527027019614};\\\", \\\"{x:1568,y:984,t:1527027019630};\\\", \\\"{x:1566,y:982,t:1527027019647};\\\", \\\"{x:1566,y:979,t:1527027019664};\\\", \\\"{x:1565,y:977,t:1527027019681};\\\", \\\"{x:1565,y:974,t:1527027019697};\\\", \\\"{x:1565,y:971,t:1527027019714};\\\", \\\"{x:1564,y:964,t:1527027019730};\\\", \\\"{x:1563,y:960,t:1527027019747};\\\", \\\"{x:1562,y:951,t:1527027019765};\\\", \\\"{x:1562,y:941,t:1527027019780};\\\", \\\"{x:1562,y:926,t:1527027019798};\\\", \\\"{x:1562,y:906,t:1527027019814};\\\", \\\"{x:1562,y:893,t:1527027019830};\\\", \\\"{x:1562,y:877,t:1527027019847};\\\", \\\"{x:1561,y:855,t:1527027019864};\\\", \\\"{x:1557,y:824,t:1527027019882};\\\", \\\"{x:1553,y:786,t:1527027019898};\\\", \\\"{x:1550,y:773,t:1527027019914};\\\", \\\"{x:1550,y:769,t:1527027019931};\\\", \\\"{x:1549,y:768,t:1527027019948};\\\", \\\"{x:1549,y:766,t:1527027019964};\\\", \\\"{x:1549,y:764,t:1527027019982};\\\", \\\"{x:1549,y:763,t:1527027019998};\\\", \\\"{x:1549,y:759,t:1527027020014};\\\", \\\"{x:1549,y:756,t:1527027020031};\\\", \\\"{x:1549,y:751,t:1527027020047};\\\", \\\"{x:1549,y:748,t:1527027020064};\\\", \\\"{x:1549,y:744,t:1527027020081};\\\", \\\"{x:1549,y:741,t:1527027020098};\\\", \\\"{x:1550,y:735,t:1527027020115};\\\", \\\"{x:1551,y:729,t:1527027020131};\\\", \\\"{x:1551,y:721,t:1527027020148};\\\", \\\"{x:1552,y:712,t:1527027020165};\\\", \\\"{x:1552,y:703,t:1527027020182};\\\", \\\"{x:1552,y:691,t:1527027020198};\\\", \\\"{x:1552,y:679,t:1527027020215};\\\", \\\"{x:1552,y:667,t:1527027020231};\\\", \\\"{x:1552,y:655,t:1527027020248};\\\", \\\"{x:1552,y:645,t:1527027020265};\\\", \\\"{x:1552,y:637,t:1527027020281};\\\", \\\"{x:1552,y:630,t:1527027020299};\\\", \\\"{x:1552,y:621,t:1527027020315};\\\", \\\"{x:1554,y:611,t:1527027020332};\\\", \\\"{x:1555,y:601,t:1527027020349};\\\", \\\"{x:1556,y:592,t:1527027020365};\\\", \\\"{x:1557,y:584,t:1527027020382};\\\", \\\"{x:1557,y:567,t:1527027020399};\\\", \\\"{x:1559,y:562,t:1527027020415};\\\", \\\"{x:1560,y:555,t:1527027020432};\\\", \\\"{x:1560,y:550,t:1527027020449};\\\", \\\"{x:1560,y:546,t:1527027020465};\\\", \\\"{x:1560,y:543,t:1527027020482};\\\", \\\"{x:1560,y:537,t:1527027020499};\\\", \\\"{x:1559,y:526,t:1527027020514};\\\", \\\"{x:1557,y:508,t:1527027020532};\\\", \\\"{x:1554,y:497,t:1527027020549};\\\", \\\"{x:1552,y:493,t:1527027020565};\\\", \\\"{x:1549,y:486,t:1527027020582};\\\", \\\"{x:1548,y:482,t:1527027020599};\\\", \\\"{x:1548,y:481,t:1527027020615};\\\", \\\"{x:1548,y:479,t:1527027020632};\\\", \\\"{x:1547,y:478,t:1527027020648};\\\", \\\"{x:1547,y:476,t:1527027020665};\\\", \\\"{x:1547,y:475,t:1527027020682};\\\", \\\"{x:1547,y:472,t:1527027020699};\\\", \\\"{x:1547,y:465,t:1527027020715};\\\", \\\"{x:1547,y:458,t:1527027020732};\\\", \\\"{x:1547,y:453,t:1527027020749};\\\", \\\"{x:1547,y:449,t:1527027020766};\\\", \\\"{x:1547,y:445,t:1527027020782};\\\", \\\"{x:1547,y:441,t:1527027020799};\\\", \\\"{x:1547,y:438,t:1527027020815};\\\", \\\"{x:1547,y:434,t:1527027020832};\\\", \\\"{x:1547,y:432,t:1527027020849};\\\", \\\"{x:1547,y:430,t:1527027020866};\\\", \\\"{x:1547,y:429,t:1527027020882};\\\", \\\"{x:1547,y:428,t:1527027020899};\\\", \\\"{x:1547,y:426,t:1527027020917};\\\", \\\"{x:1540,y:439,t:1527027054630};\\\", \\\"{x:1529,y:470,t:1527027054643};\\\", \\\"{x:1500,y:520,t:1527027054660};\\\", \\\"{x:1442,y:574,t:1527027054678};\\\", \\\"{x:1394,y:605,t:1527027054694};\\\", \\\"{x:1321,y:633,t:1527027054711};\\\", \\\"{x:1220,y:649,t:1527027054728};\\\", \\\"{x:1174,y:654,t:1527027054743};\\\", \\\"{x:1173,y:654,t:1527027055078};\\\", \\\"{x:1155,y:648,t:1527027055094};\\\", \\\"{x:1109,y:632,t:1527027055111};\\\", \\\"{x:1041,y:609,t:1527027055128};\\\", \\\"{x:946,y:579,t:1527027055147};\\\", \\\"{x:857,y:552,t:1527027055161};\\\", \\\"{x:813,y:534,t:1527027055177};\\\", \\\"{x:792,y:523,t:1527027055193};\\\", \\\"{x:778,y:514,t:1527027055209};\\\", \\\"{x:772,y:509,t:1527027055226};\\\", \\\"{x:764,y:504,t:1527027055242};\\\", \\\"{x:757,y:500,t:1527027055259};\\\", \\\"{x:747,y:495,t:1527027055275};\\\", \\\"{x:726,y:489,t:1527027055292};\\\", \\\"{x:647,y:476,t:1527027055309};\\\", \\\"{x:592,y:476,t:1527027055326};\\\", \\\"{x:558,y:476,t:1527027055343};\\\", \\\"{x:534,y:477,t:1527027055360};\\\", \\\"{x:517,y:483,t:1527027055376};\\\", \\\"{x:511,y:484,t:1527027055393};\\\", \\\"{x:508,y:487,t:1527027055411};\\\", \\\"{x:505,y:491,t:1527027055425};\\\", \\\"{x:504,y:495,t:1527027055442};\\\", \\\"{x:504,y:500,t:1527027055460};\\\", \\\"{x:503,y:503,t:1527027055475};\\\", \\\"{x:501,y:505,t:1527027055493};\\\", \\\"{x:501,y:507,t:1527027055509};\\\", \\\"{x:501,y:510,t:1527027055525};\\\", \\\"{x:505,y:517,t:1527027055542};\\\", \\\"{x:523,y:524,t:1527027055560};\\\", \\\"{x:552,y:533,t:1527027055576};\\\", \\\"{x:584,y:540,t:1527027055592};\\\", \\\"{x:612,y:541,t:1527027055611};\\\", \\\"{x:648,y:541,t:1527027055626};\\\", \\\"{x:682,y:541,t:1527027055643};\\\", \\\"{x:706,y:536,t:1527027055660};\\\", \\\"{x:724,y:531,t:1527027055677};\\\", \\\"{x:734,y:525,t:1527027055692};\\\", \\\"{x:740,y:521,t:1527027055710};\\\", \\\"{x:742,y:520,t:1527027055726};\\\", \\\"{x:743,y:519,t:1527027055743};\\\", \\\"{x:744,y:519,t:1527027055822};\\\", \\\"{x:747,y:517,t:1527027055831};\\\", \\\"{x:749,y:518,t:1527027055886};\\\", \\\"{x:754,y:523,t:1527027055894};\\\", \\\"{x:768,y:536,t:1527027055910};\\\", \\\"{x:781,y:544,t:1527027055927};\\\", \\\"{x:783,y:546,t:1527027055943};\\\", \\\"{x:781,y:549,t:1527027055960};\\\", \\\"{x:763,y:558,t:1527027055977};\\\", \\\"{x:728,y:564,t:1527027055993};\\\", \\\"{x:646,y:568,t:1527027056011};\\\", \\\"{x:544,y:568,t:1527027056026};\\\", \\\"{x:467,y:563,t:1527027056045};\\\", \\\"{x:435,y:558,t:1527027056061};\\\", \\\"{x:419,y:557,t:1527027056076};\\\", \\\"{x:415,y:555,t:1527027056094};\\\", \\\"{x:414,y:555,t:1527027056109};\\\", \\\"{x:412,y:555,t:1527027056127};\\\", \\\"{x:405,y:554,t:1527027056144};\\\", \\\"{x:400,y:554,t:1527027056160};\\\", \\\"{x:393,y:554,t:1527027056177};\\\", \\\"{x:384,y:554,t:1527027056194};\\\", \\\"{x:375,y:554,t:1527027056210};\\\", \\\"{x:368,y:554,t:1527027056226};\\\", \\\"{x:364,y:554,t:1527027056262};\\\", \\\"{x:359,y:554,t:1527027056278};\\\", \\\"{x:332,y:557,t:1527027056295};\\\", \\\"{x:318,y:561,t:1527027056310};\\\", \\\"{x:313,y:564,t:1527027056327};\\\", \\\"{x:310,y:565,t:1527027056344};\\\", \\\"{x:308,y:565,t:1527027056360};\\\", \\\"{x:305,y:566,t:1527027056377};\\\", \\\"{x:295,y:566,t:1527027056394};\\\", \\\"{x:284,y:566,t:1527027056410};\\\", \\\"{x:281,y:566,t:1527027056426};\\\", \\\"{x:279,y:566,t:1527027056494};\\\", \\\"{x:264,y:569,t:1527027056511};\\\", \\\"{x:254,y:570,t:1527027056527};\\\", \\\"{x:249,y:573,t:1527027056544};\\\", \\\"{x:246,y:574,t:1527027056560};\\\", \\\"{x:244,y:576,t:1527027056577};\\\", \\\"{x:243,y:577,t:1527027056594};\\\", \\\"{x:242,y:577,t:1527027056611};\\\", \\\"{x:235,y:577,t:1527027056627};\\\", \\\"{x:231,y:577,t:1527027056644};\\\", \\\"{x:230,y:577,t:1527027056660};\\\", \\\"{x:230,y:576,t:1527027056702};\\\", \\\"{x:230,y:574,t:1527027056710};\\\", \\\"{x:230,y:571,t:1527027056727};\\\", \\\"{x:229,y:567,t:1527027056744};\\\", \\\"{x:224,y:562,t:1527027056762};\\\", \\\"{x:219,y:559,t:1527027056776};\\\", \\\"{x:217,y:558,t:1527027056794};\\\", \\\"{x:207,y:554,t:1527027056811};\\\", \\\"{x:159,y:539,t:1527027056828};\\\", \\\"{x:103,y:525,t:1527027056844};\\\", \\\"{x:42,y:508,t:1527027056861};\\\", \\\"{x:19,y:505,t:1527027056876};\\\", \\\"{x:15,y:505,t:1527027056894};\\\", \\\"{x:16,y:505,t:1527027056966};\\\", \\\"{x:20,y:507,t:1527027056977};\\\", \\\"{x:22,y:508,t:1527027056994};\\\", \\\"{x:29,y:511,t:1527027057010};\\\", \\\"{x:41,y:514,t:1527027057027};\\\", \\\"{x:49,y:518,t:1527027057043};\\\", \\\"{x:54,y:520,t:1527027057061};\\\", \\\"{x:56,y:521,t:1527027057118};\\\", \\\"{x:61,y:523,t:1527027057128};\\\", \\\"{x:65,y:525,t:1527027057145};\\\", \\\"{x:67,y:526,t:1527027057161};\\\", \\\"{x:68,y:526,t:1527027057177};\\\", \\\"{x:69,y:527,t:1527027057194};\\\", \\\"{x:75,y:528,t:1527027057211};\\\", \\\"{x:96,y:533,t:1527027057228};\\\", \\\"{x:118,y:535,t:1527027057244};\\\", \\\"{x:125,y:537,t:1527027057261};\\\", \\\"{x:126,y:537,t:1527027057278};\\\", \\\"{x:127,y:537,t:1527027057382};\\\", \\\"{x:133,y:537,t:1527027057394};\\\", \\\"{x:146,y:538,t:1527027057411};\\\", \\\"{x:157,y:539,t:1527027057429};\\\", \\\"{x:161,y:540,t:1527027057445};\\\", \\\"{x:162,y:540,t:1527027057460};\\\", \\\"{x:167,y:540,t:1527027057765};\\\", \\\"{x:184,y:551,t:1527027057778};\\\", \\\"{x:217,y:587,t:1527027057795};\\\", \\\"{x:232,y:608,t:1527027057811};\\\", \\\"{x:256,y:637,t:1527027057829};\\\", \\\"{x:290,y:666,t:1527027057845};\\\", \\\"{x:341,y:689,t:1527027057861};\\\", \\\"{x:373,y:700,t:1527027057878};\\\", \\\"{x:392,y:707,t:1527027057895};\\\", \\\"{x:402,y:710,t:1527027057911};\\\", \\\"{x:409,y:711,t:1527027057928};\\\", \\\"{x:414,y:713,t:1527027057945};\\\", \\\"{x:416,y:714,t:1527027057961};\\\", \\\"{x:420,y:714,t:1527027057977};\\\", \\\"{x:424,y:715,t:1527027057995};\\\", \\\"{x:439,y:719,t:1527027058011};\\\", \\\"{x:457,y:724,t:1527027058028};\\\", \\\"{x:475,y:728,t:1527027058043};\\\", \\\"{x:503,y:731,t:1527027058061};\\\", \\\"{x:519,y:735,t:1527027058079};\\\", \\\"{x:524,y:736,t:1527027058095};\\\", \\\"{x:527,y:736,t:1527027058112};\\\" ] }, { \\\"rt\\\": 29208, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 420018, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:734,t:1527027059774};\\\", \\\"{x:527,y:732,t:1527027059782};\\\", \\\"{x:527,y:730,t:1527027059798};\\\", \\\"{x:527,y:729,t:1527027059814};\\\", \\\"{x:527,y:728,t:1527027070289};\\\", \\\"{x:510,y:722,t:1527027070307};\\\", \\\"{x:478,y:711,t:1527027070323};\\\", \\\"{x:422,y:694,t:1527027070341};\\\", \\\"{x:359,y:677,t:1527027070359};\\\", \\\"{x:304,y:657,t:1527027070374};\\\", \\\"{x:274,y:638,t:1527027070390};\\\", \\\"{x:261,y:618,t:1527027070408};\\\", \\\"{x:258,y:610,t:1527027070425};\\\", \\\"{x:260,y:602,t:1527027070442};\\\", \\\"{x:262,y:596,t:1527027070457};\\\", \\\"{x:263,y:593,t:1527027070474};\\\", \\\"{x:265,y:588,t:1527027070491};\\\", \\\"{x:269,y:585,t:1527027070508};\\\", \\\"{x:274,y:581,t:1527027070525};\\\", \\\"{x:281,y:576,t:1527027070541};\\\", \\\"{x:286,y:573,t:1527027070558};\\\", \\\"{x:290,y:571,t:1527027070575};\\\", \\\"{x:298,y:569,t:1527027070592};\\\", \\\"{x:320,y:565,t:1527027070608};\\\", \\\"{x:338,y:563,t:1527027070624};\\\", \\\"{x:351,y:560,t:1527027070641};\\\", \\\"{x:362,y:558,t:1527027070659};\\\", \\\"{x:372,y:555,t:1527027070675};\\\", \\\"{x:384,y:551,t:1527027070692};\\\", \\\"{x:393,y:549,t:1527027070708};\\\", \\\"{x:406,y:546,t:1527027070725};\\\", \\\"{x:418,y:544,t:1527027070741};\\\", \\\"{x:425,y:544,t:1527027070759};\\\", \\\"{x:428,y:542,t:1527027070774};\\\", \\\"{x:431,y:542,t:1527027070791};\\\", \\\"{x:437,y:541,t:1527027070808};\\\", \\\"{x:442,y:541,t:1527027070825};\\\", \\\"{x:444,y:541,t:1527027070841};\\\", \\\"{x:445,y:541,t:1527027070858};\\\", \\\"{x:446,y:541,t:1527027071154};\\\", \\\"{x:448,y:541,t:1527027071160};\\\", \\\"{x:451,y:542,t:1527027071176};\\\", \\\"{x:466,y:546,t:1527027071192};\\\", \\\"{x:475,y:547,t:1527027071209};\\\", \\\"{x:484,y:547,t:1527027071225};\\\", \\\"{x:494,y:548,t:1527027071243};\\\", \\\"{x:508,y:550,t:1527027071261};\\\", \\\"{x:523,y:550,t:1527027071275};\\\", \\\"{x:541,y:550,t:1527027071291};\\\", \\\"{x:563,y:550,t:1527027071309};\\\", \\\"{x:585,y:550,t:1527027071326};\\\", \\\"{x:605,y:550,t:1527027071341};\\\", \\\"{x:626,y:549,t:1527027071358};\\\", \\\"{x:645,y:545,t:1527027071376};\\\", \\\"{x:664,y:540,t:1527027071392};\\\", \\\"{x:679,y:538,t:1527027071409};\\\", \\\"{x:695,y:536,t:1527027071425};\\\", \\\"{x:712,y:533,t:1527027071442};\\\", \\\"{x:726,y:530,t:1527027071459};\\\", \\\"{x:738,y:530,t:1527027071476};\\\", \\\"{x:747,y:529,t:1527027071491};\\\", \\\"{x:754,y:527,t:1527027071509};\\\", \\\"{x:757,y:525,t:1527027071526};\\\", \\\"{x:760,y:525,t:1527027071542};\\\", \\\"{x:767,y:524,t:1527027071559};\\\", \\\"{x:773,y:522,t:1527027071575};\\\", \\\"{x:774,y:522,t:1527027071626};\\\", \\\"{x:777,y:522,t:1527027071643};\\\", \\\"{x:779,y:522,t:1527027071658};\\\", \\\"{x:782,y:522,t:1527027071721};\\\", \\\"{x:782,y:523,t:1527027071729};\\\", \\\"{x:785,y:523,t:1527027071743};\\\", \\\"{x:789,y:525,t:1527027071759};\\\", \\\"{x:792,y:526,t:1527027071776};\\\", \\\"{x:793,y:526,t:1527027071825};\\\", \\\"{x:797,y:526,t:1527027071842};\\\", \\\"{x:802,y:526,t:1527027071858};\\\", \\\"{x:807,y:524,t:1527027071876};\\\", \\\"{x:808,y:524,t:1527027071892};\\\", \\\"{x:809,y:524,t:1527027071909};\\\", \\\"{x:810,y:524,t:1527027071929};\\\", \\\"{x:811,y:524,t:1527027071943};\\\", \\\"{x:812,y:524,t:1527027071958};\\\", \\\"{x:814,y:523,t:1527027071975};\\\", \\\"{x:821,y:522,t:1527027071992};\\\", \\\"{x:825,y:522,t:1527027072009};\\\", \\\"{x:828,y:522,t:1527027072026};\\\", \\\"{x:829,y:522,t:1527027072042};\\\", \\\"{x:829,y:521,t:1527027086905};\\\", \\\"{x:823,y:523,t:1527027086914};\\\", \\\"{x:814,y:526,t:1527027086924};\\\", \\\"{x:795,y:531,t:1527027086941};\\\", \\\"{x:777,y:537,t:1527027086958};\\\", \\\"{x:752,y:540,t:1527027086972};\\\", \\\"{x:727,y:545,t:1527027086987};\\\", \\\"{x:697,y:548,t:1527027087004};\\\", \\\"{x:672,y:548,t:1527027087021};\\\", \\\"{x:648,y:549,t:1527027087038};\\\", \\\"{x:629,y:552,t:1527027087055};\\\", \\\"{x:614,y:554,t:1527027087071};\\\", \\\"{x:587,y:557,t:1527027087088};\\\", \\\"{x:541,y:567,t:1527027087105};\\\", \\\"{x:492,y:580,t:1527027087122};\\\", \\\"{x:460,y:588,t:1527027087138};\\\", \\\"{x:442,y:596,t:1527027087155};\\\", \\\"{x:438,y:597,t:1527027087171};\\\", \\\"{x:440,y:597,t:1527027087233};\\\", \\\"{x:447,y:595,t:1527027087241};\\\", \\\"{x:457,y:592,t:1527027087255};\\\", \\\"{x:486,y:578,t:1527027087271};\\\", \\\"{x:532,y:553,t:1527027087290};\\\", \\\"{x:553,y:539,t:1527027087305};\\\", \\\"{x:571,y:530,t:1527027087321};\\\", \\\"{x:579,y:525,t:1527027087338};\\\", \\\"{x:581,y:523,t:1527027087355};\\\", \\\"{x:581,y:522,t:1527027087376};\\\", \\\"{x:583,y:520,t:1527027087400};\\\", \\\"{x:584,y:519,t:1527027087408};\\\", \\\"{x:585,y:518,t:1527027087422};\\\", \\\"{x:587,y:516,t:1527027087438};\\\", \\\"{x:588,y:516,t:1527027087455};\\\", \\\"{x:589,y:516,t:1527027087488};\\\", \\\"{x:593,y:514,t:1527027087505};\\\", \\\"{x:598,y:514,t:1527027087523};\\\", \\\"{x:602,y:514,t:1527027087539};\\\", \\\"{x:605,y:514,t:1527027087555};\\\", \\\"{x:606,y:514,t:1527027087632};\\\", \\\"{x:606,y:517,t:1527027087808};\\\", \\\"{x:606,y:524,t:1527027087822};\\\", \\\"{x:603,y:545,t:1527027087838};\\\", \\\"{x:594,y:577,t:1527027087856};\\\", \\\"{x:582,y:629,t:1527027087872};\\\", \\\"{x:579,y:645,t:1527027087888};\\\", \\\"{x:577,y:653,t:1527027087905};\\\", \\\"{x:576,y:656,t:1527027087922};\\\", \\\"{x:574,y:658,t:1527027087939};\\\", \\\"{x:572,y:662,t:1527027087955};\\\", \\\"{x:566,y:668,t:1527027087972};\\\", \\\"{x:563,y:671,t:1527027087989};\\\", \\\"{x:561,y:673,t:1527027088005};\\\", \\\"{x:559,y:675,t:1527027088023};\\\", \\\"{x:557,y:675,t:1527027088039};\\\", \\\"{x:555,y:676,t:1527027088055};\\\", \\\"{x:552,y:678,t:1527027088073};\\\", \\\"{x:549,y:679,t:1527027088089};\\\", \\\"{x:547,y:682,t:1527027088106};\\\", \\\"{x:542,y:684,t:1527027088122};\\\", \\\"{x:538,y:690,t:1527027088139};\\\", \\\"{x:532,y:699,t:1527027088156};\\\", \\\"{x:526,y:709,t:1527027088173};\\\", \\\"{x:522,y:719,t:1527027088189};\\\", \\\"{x:520,y:725,t:1527027088206};\\\", \\\"{x:519,y:727,t:1527027088222};\\\", \\\"{x:519,y:728,t:1527027088240};\\\", \\\"{x:518,y:731,t:1527027088257};\\\", \\\"{x:518,y:732,t:1527027088273};\\\", \\\"{x:518,y:734,t:1527027088291};\\\", \\\"{x:518,y:736,t:1527027088307};\\\", \\\"{x:518,y:737,t:1527027088353};\\\" ] }, { \\\"rt\\\": 40528, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 461797, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"i was looking vertically up from 12 pm but idk what the hell im doing \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 3303, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 466106, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 18837, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Natural Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 485970, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 30855, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 518170, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"2S99A\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"india\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"2S99A\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 79, dom: 885, initialDom: 993",
  "javascriptErrors": []
}