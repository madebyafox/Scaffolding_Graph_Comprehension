var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4cf39b359647c9c05f3dd49245373a1b",
  "created": "2018-05-21T13:22:09.7345092-07:00",
  "lastActivity": "2018-05-21T13:22:40.5271906-07:00",
  "pageViews": [
    {
      "id": "0521101035372b7d7d38630cad5992f5c413e3cc",
      "startTime": "2018-05-21T13:22:10.0699908-07:00",
      "endTime": "2018-05-21T13:22:40.5271906-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 30691,
      "engagementTime": 30690,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 30691,
  "engagementTime": 30690,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ELUPZ",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "90ab40e3f5c1d89b3137f344a94da9a1",
  "gdpr": false
}