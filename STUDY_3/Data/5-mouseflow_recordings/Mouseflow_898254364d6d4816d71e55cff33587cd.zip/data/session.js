var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "898254364d6d4816d71e55cff33587cd",
  "created": "2018-05-21T12:13:32.4342292-07:00",
  "lastActivity": "2018-05-21T12:14:29.13665-07:00",
  "pageViews": [
    {
      "id": "05213241e82e50d5e7f984c76d48c7a8156e9096",
      "startTime": "2018-05-21T12:13:32.43965-07:00",
      "endTime": "2018-05-21T12:14:29.13665-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 56697,
      "engagementTime": 50848,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 56697,
  "engagementTime": 50848,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=UX4QZ",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "3cc57783be4fc5e2660a2d2db6e69a7d",
  "gdpr": false
}