var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "06b37afdf227b132be9df9b9d929df55",
  "created": "2018-05-22T10:19:42.1863491-07:00",
  "lastActivity": "2018-05-22T10:20:14.2413491-07:00",
  "pageViews": [
    {
      "id": "0522429055c6057545d1f73593c173fd85ae0706",
      "startTime": "2018-05-22T10:19:42.1863491-07:00",
      "endTime": "2018-05-22T10:20:14.2413491-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 32055,
      "engagementTime": 30955,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 32055,
  "engagementTime": 30955,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=808YR",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "4e8a41a3ad60c9f5e32b25ec769470d1",
  "gdpr": false
}