var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060448171e36e7a2326c962621b5ca1532dcd779"] = {
  "startTime": "2018-06-04T20:23:48.0563443Z",
  "websitePageUrl": "/16",
  "visitTime": 101267,
  "engagementTime": 100398,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "454a4a084e890276ec15efc54af8cd25",
    "created": "2018-06-04T20:23:48.0563443+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=MUULG",
      "CONDITION=211"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "ab0bc8dd59b91ead77036e76ff2125a4",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/454a4a084e890276ec15efc54af8cd25/play"
  },
  "events": [
    {
      "t": 3,
      "e": 3,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 449,
      "y": 644
    },
    {
      "t": 1196,
      "e": 1196,
      "ty": 6,
      "x": 432,
      "y": 599,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 432,
      "y": 599
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 36859,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 423,
      "y": 562
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 423,
      "y": 561
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 36635,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5383,
      "e": 5383,
      "ty": 3,
      "x": 423,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5385,
      "e": 5385,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5758,
      "e": 5758,
      "ty": 4,
      "x": 36635,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5758,
      "e": 5758,
      "ty": 5,
      "x": 423,
      "y": 561,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 427,
      "y": 568
    },
    {
      "t": 6351,
      "e": 6351,
      "ty": 7,
      "x": 503,
      "y": 614,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 692,
      "y": 689
    },
    {
      "t": 6502,
      "e": 6502,
      "ty": 2,
      "x": 900,
      "y": 769
    },
    {
      "t": 6502,
      "e": 6502,
      "ty": 41,
      "x": 8034,
      "y": 45194,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 904,
      "y": 771
    },
    {
      "t": 6701,
      "e": 6701,
      "ty": 2,
      "x": 1013,
      "y": 830
    },
    {
      "t": 6752,
      "e": 6752,
      "ty": 41,
      "x": 25228,
      "y": 52714,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6802,
      "e": 6802,
      "ty": 2,
      "x": 1157,
      "y": 877
    },
    {
      "t": 6901,
      "e": 6901,
      "ty": 2,
      "x": 1156,
      "y": 880
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 2,
      "x": 1146,
      "y": 915
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 41,
      "x": 25369,
      "y": 55651,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7101,
      "e": 7101,
      "ty": 2,
      "x": 1144,
      "y": 931
    },
    {
      "t": 7202,
      "e": 7202,
      "ty": 2,
      "x": 1144,
      "y": 945
    },
    {
      "t": 7252,
      "e": 7252,
      "ty": 41,
      "x": 25228,
      "y": 58014,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7302,
      "e": 7302,
      "ty": 2,
      "x": 1143,
      "y": 952
    },
    {
      "t": 7402,
      "e": 7402,
      "ty": 2,
      "x": 1143,
      "y": 957
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 1143,
      "y": 958
    },
    {
      "t": 7502,
      "e": 7502,
      "ty": 41,
      "x": 25158,
      "y": 58730,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7602,
      "e": 7602,
      "ty": 2,
      "x": 1152,
      "y": 948
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 1165,
      "y": 926
    },
    {
      "t": 7752,
      "e": 7752,
      "ty": 41,
      "x": 26778,
      "y": 56080,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 2,
      "x": 1169,
      "y": 914
    },
    {
      "t": 7902,
      "e": 7902,
      "ty": 2,
      "x": 1172,
      "y": 900
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 2,
      "x": 1172,
      "y": 899
    },
    {
      "t": 8002,
      "e": 8002,
      "ty": 41,
      "x": 27201,
      "y": 54505,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8101,
      "e": 8101,
      "ty": 2,
      "x": 1172,
      "y": 898
    },
    {
      "t": 8201,
      "e": 8201,
      "ty": 2,
      "x": 1173,
      "y": 896
    },
    {
      "t": 8401,
      "e": 8401,
      "ty": 2,
      "x": 1174,
      "y": 895
    },
    {
      "t": 8502,
      "e": 8502,
      "ty": 41,
      "x": 27342,
      "y": 54218,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9502,
      "e": 9502,
      "ty": 2,
      "x": 1179,
      "y": 893
    },
    {
      "t": 9502,
      "e": 9502,
      "ty": 41,
      "x": 27694,
      "y": 54075,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 2,
      "x": 1181,
      "y": 893
    },
    {
      "t": 10003,
      "e": 10003,
      "ty": 41,
      "x": 27835,
      "y": 54075,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10003,
      "e": 10003,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10101,
      "e": 10101,
      "ty": 2,
      "x": 1184,
      "y": 893
    },
    {
      "t": 10202,
      "e": 10202,
      "ty": 2,
      "x": 1186,
      "y": 893
    },
    {
      "t": 10251,
      "e": 10251,
      "ty": 41,
      "x": 32852,
      "y": 14563,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[13] > circle"
    },
    {
      "t": 15401,
      "e": 15251,
      "ty": 2,
      "x": 1186,
      "y": 892
    },
    {
      "t": 15501,
      "e": 15351,
      "ty": 2,
      "x": 860,
      "y": 754
    },
    {
      "t": 15502,
      "e": 15352,
      "ty": 41,
      "x": 5215,
      "y": 44119,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 15601,
      "e": 15451,
      "ty": 2,
      "x": 677,
      "y": 693
    },
    {
      "t": 15751,
      "e": 15601,
      "ty": 41,
      "x": 65187,
      "y": 37947,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 16201,
      "e": 16051,
      "ty": 2,
      "x": 992,
      "y": 658
    },
    {
      "t": 16251,
      "e": 16101,
      "ty": 41,
      "x": 25158,
      "y": 38246,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 16301,
      "e": 16151,
      "ty": 2,
      "x": 1257,
      "y": 677
    },
    {
      "t": 16400,
      "e": 16250,
      "ty": 2,
      "x": 1353,
      "y": 612
    },
    {
      "t": 16501,
      "e": 16351,
      "ty": 2,
      "x": 1393,
      "y": 554
    },
    {
      "t": 16501,
      "e": 16351,
      "ty": 41,
      "x": 42775,
      "y": 29795,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 16600,
      "e": 16450,
      "ty": 2,
      "x": 1399,
      "y": 504
    },
    {
      "t": 16701,
      "e": 16551,
      "ty": 2,
      "x": 1399,
      "y": 482
    },
    {
      "t": 16752,
      "e": 16602,
      "ty": 41,
      "x": 43902,
      "y": 23134,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 16801,
      "e": 16651,
      "ty": 2,
      "x": 1418,
      "y": 434
    },
    {
      "t": 16901,
      "e": 16751,
      "ty": 2,
      "x": 1423,
      "y": 421
    },
    {
      "t": 17001,
      "e": 16851,
      "ty": 41,
      "x": 44889,
      "y": 20269,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 17101,
      "e": 16951,
      "ty": 2,
      "x": 1413,
      "y": 444
    },
    {
      "t": 17201,
      "e": 17051,
      "ty": 2,
      "x": 1360,
      "y": 532
    },
    {
      "t": 17251,
      "e": 17101,
      "ty": 41,
      "x": 39956,
      "y": 29222,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 17301,
      "e": 17151,
      "ty": 2,
      "x": 1323,
      "y": 591
    },
    {
      "t": 17401,
      "e": 17251,
      "ty": 2,
      "x": 1249,
      "y": 683
    },
    {
      "t": 17501,
      "e": 17351,
      "ty": 2,
      "x": 1218,
      "y": 737
    },
    {
      "t": 17502,
      "e": 17352,
      "ty": 41,
      "x": 30443,
      "y": 42902,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 17601,
      "e": 17451,
      "ty": 2,
      "x": 1160,
      "y": 861
    },
    {
      "t": 17701,
      "e": 17551,
      "ty": 2,
      "x": 1153,
      "y": 895
    },
    {
      "t": 17751,
      "e": 17601,
      "ty": 41,
      "x": 25721,
      "y": 55221,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 17801,
      "e": 17651,
      "ty": 2,
      "x": 1148,
      "y": 923
    },
    {
      "t": 17901,
      "e": 17751,
      "ty": 2,
      "x": 1148,
      "y": 927
    },
    {
      "t": 18001,
      "e": 17851,
      "ty": 2,
      "x": 939,
      "y": 869
    },
    {
      "t": 18001,
      "e": 17851,
      "ty": 41,
      "x": 10782,
      "y": 52356,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 18101,
      "e": 17951,
      "ty": 2,
      "x": 423,
      "y": 614
    },
    {
      "t": 18110,
      "e": 17960,
      "ty": 6,
      "x": 324,
      "y": 551,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18143,
      "e": 17993,
      "ty": 7,
      "x": 258,
      "y": 509,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18201,
      "e": 18051,
      "ty": 2,
      "x": 234,
      "y": 489
    },
    {
      "t": 18251,
      "e": 18101,
      "ty": 41,
      "x": 15389,
      "y": 5329,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 18401,
      "e": 18251,
      "ty": 2,
      "x": 278,
      "y": 503
    },
    {
      "t": 18443,
      "e": 18293,
      "ty": 6,
      "x": 287,
      "y": 530,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18502,
      "e": 18352,
      "ty": 2,
      "x": 288,
      "y": 545
    },
    {
      "t": 18502,
      "e": 18352,
      "ty": 41,
      "x": 21459,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18601,
      "e": 18451,
      "ty": 2,
      "x": 288,
      "y": 553
    },
    {
      "t": 18751,
      "e": 18601,
      "ty": 41,
      "x": 21459,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19715,
      "e": 19565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 19874,
      "e": 19724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 19875,
      "e": 19725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19913,
      "e": 19763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "m"
    },
    {
      "t": 19977,
      "e": 19827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "m"
    },
    {
      "t": 20001,
      "e": 19851,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20201,
      "e": 20051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 20306,
      "e": 20156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20307,
      "e": 20157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20321,
      "e": 20171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "m "
    },
    {
      "t": 20442,
      "e": 20292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "m "
    },
    {
      "t": 21002,
      "e": 20852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21042,
      "e": 20892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "m"
    },
    {
      "t": 21130,
      "e": 20980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21177,
      "e": 21027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 21435,
      "e": 21285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 21435,
      "e": 21285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21562,
      "e": 21412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 21579,
      "e": 21429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 21579,
      "e": 21429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21689,
      "e": 21539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21690,
      "e": 21540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21714,
      "e": 21564,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "BY "
    },
    {
      "t": 21818,
      "e": 21668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "BY "
    },
    {
      "t": 22298,
      "e": 22148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22345,
      "e": 22195,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "BY"
    },
    {
      "t": 22418,
      "e": 22268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22475,
      "e": 22325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 22521,
      "e": 22371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 22673,
      "e": 22523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 22722,
      "e": 22572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 22722,
      "e": 22572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22818,
      "e": 22668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22819,
      "e": 22669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22850,
      "e": 22700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By "
    },
    {
      "t": 22938,
      "e": 22788,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By "
    },
    {
      "t": 23234,
      "e": 23084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 23235,
      "e": 23085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23386,
      "e": 23236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By d"
    },
    {
      "t": 23794,
      "e": 23644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23858,
      "e": 23708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By "
    },
    {
      "t": 24009,
      "e": 23859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 24010,
      "e": 23860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24081,
      "e": 23931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By l"
    },
    {
      "t": 24205,
      "e": 24055,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By l"
    },
    {
      "t": 24210,
      "e": 24060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24211,
      "e": 24061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24273,
      "e": 24123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 24379,
      "e": 24229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24379,
      "e": 24229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24449,
      "e": 24299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 24794,
      "e": 24644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 24795,
      "e": 24645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24897,
      "e": 24747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 24994,
      "e": 24844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24994,
      "e": 24844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25098,
      "e": 24948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 25098,
      "e": 24948,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25146,
      "e": 24996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 25146,
      "e": 24996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25202,
      "e": 25052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ing"
    },
    {
      "t": 25202,
      "e": 25052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25203,
      "e": 25053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25257,
      "e": 25107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25258,
      "e": 25108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25282,
      "e": 25132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25282,
      "e": 25132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25345,
      "e": 25195,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 25409,
      "e": 25259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25410,
      "e": 25260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25449,
      "e": 25299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25506,
      "e": 25356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25507,
      "e": 25357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25514,
      "e": 25364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25602,
      "e": 25452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25602,
      "e": 25452,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25609,
      "e": 25459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25698,
      "e": 25548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25698,
      "e": 25548,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25754,
      "e": 25604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 25770,
      "e": 25620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25770,
      "e": 25620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25826,
      "e": 25676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25827,
      "e": 25677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25849,
      "e": 25699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 25922,
      "e": 25772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25986,
      "e": 25836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26091,
      "e": 25941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 26091,
      "e": 25941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26177,
      "e": 26027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26178,
      "e": 26028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26234,
      "e": 26084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||di"
    },
    {
      "t": 26329,
      "e": 26179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26353,
      "e": 26203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26353,
      "e": 26203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26474,
      "e": 26324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26635,
      "e": 26485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 26636,
      "e": 26486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26770,
      "e": 26620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 27107,
      "e": 26957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27107,
      "e": 26957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27249,
      "e": 27099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 27353,
      "e": 27203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27354,
      "e": 27204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27466,
      "e": 27316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 27730,
      "e": 27580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27777,
      "e": 27627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the diagn"
    },
    {
      "t": 27954,
      "e": 27804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27955,
      "e": 27805,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28026,
      "e": 27876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28234,
      "e": 28084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 28235,
      "e": 28085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28321,
      "e": 28171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 28899,
      "e": 28749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 28900,
      "e": 28750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28961,
      "e": 28811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 29050,
      "e": 28900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29050,
      "e": 28900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29138,
      "e": 28988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29146,
      "e": 28996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 29274,
      "e": 29124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29843,
      "e": 29693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 29843,
      "e": 29693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29953,
      "e": 29803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 30002,
      "e": 29852,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30018,
      "e": 29868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 30138,
      "e": 29988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30145,
      "e": 29995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30145,
      "e": 29995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30274,
      "e": 30124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30274,
      "e": 30124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30282,
      "e": 30132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 30321,
      "e": 30171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 30321,
      "e": 30171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30426,
      "e": 30276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 30450,
      "e": 30300,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 30450,
      "e": 30300,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30506,
      "e": 30356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 30529,
      "e": 30379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30530,
      "e": 30380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30577,
      "e": 30427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30666,
      "e": 30516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 30674,
      "e": 30524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30770,
      "e": 30620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30771,
      "e": 30621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 30772,
      "e": 30622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30898,
      "e": 30748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 30970,
      "e": 30820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 31114,
      "e": 30964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31154,
      "e": 31004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31155,
      "e": 31005,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31249,
      "e": 31099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31602,
      "e": 31452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 31603,
      "e": 31453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31779,
      "e": 31629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 31907,
      "e": 31757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31907,
      "e": 31757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32010,
      "e": 31860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32163,
      "e": 32013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32163,
      "e": 32013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32305,
      "e": 32155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 32306,
      "e": 32156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32362,
      "e": 32212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 32419,
      "e": 32269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32506,
      "e": 32356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32507,
      "e": 32357,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32618,
      "e": 32468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32619,
      "e": 32469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 32619,
      "e": 32469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32737,
      "e": 32587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32738,
      "e": 32588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32746,
      "e": 32596,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 32874,
      "e": 32724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32875,
      "e": 32725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32882,
      "e": 32732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32883,
      "e": 32733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32889,
      "e": 32739,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||na"
    },
    {
      "t": 33001,
      "e": 32851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33001,
      "e": 32851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 33002,
      "e": 32852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33050,
      "e": 32900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33050,
      "e": 32900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33081,
      "e": 32931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 33169,
      "e": 33019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33210,
      "e": 33060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35171,
      "e": 35021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 35330,
      "e": 35180,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36002,
      "e": 35852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36041,
      "e": 35891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the diagnol, M and L starts nad"
    },
    {
      "t": 36121,
      "e": 35971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36154,
      "e": 36004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the diagnol, M and L starts na"
    },
    {
      "t": 36233,
      "e": 36083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36281,
      "e": 36131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the diagnol, M and L starts n"
    },
    {
      "t": 36346,
      "e": 36196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 36395,
      "e": 36245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36449,
      "e": 36299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the diagnol, M and L starts "
    },
    {
      "t": 36457,
      "e": 36307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36602,
      "e": 36452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36602,
      "e": 36452,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36673,
      "e": 36523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36674,
      "e": 36524,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36745,
      "e": 36595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 36786,
      "e": 36636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 36787,
      "e": 36637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36818,
      "e": 36668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 36930,
      "e": 36780,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36945,
      "e": 36795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36946,
      "e": 36796,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37074,
      "e": 36924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37458,
      "e": 37308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 37459,
      "e": 37309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37586,
      "e": 37436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 37586,
      "e": 37436,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37593,
      "e": 37443,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||by"
    },
    {
      "t": 37690,
      "e": 37540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37691,
      "e": 37541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37713,
      "e": 37563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37834,
      "e": 37684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37898,
      "e": 37748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 37900,
      "e": 37750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37953,
      "e": 37803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 38066,
      "e": 37916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38066,
      "e": 37916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38122,
      "e": 37972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 38241,
      "e": 38091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 38243,
      "e": 38093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38297,
      "e": 38147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 38404,
      "e": 38254,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the diagnol, M and L starts and by lok"
    },
    {
      "t": 38731,
      "e": 38255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38778,
      "e": 38302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the diagnol, M and L starts and by lo"
    },
    {
      "t": 38954,
      "e": 38478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 38954,
      "e": 38478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39034,
      "e": 38558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 39162,
      "e": 38686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 39162,
      "e": 38686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39202,
      "e": 38726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 39307,
      "e": 38831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 39307,
      "e": 38831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39401,
      "e": 38925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 39401,
      "e": 38925,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39473,
      "e": 38997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 39505,
      "e": 39029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 39506,
      "e": 39030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39602,
      "e": 39126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39602,
      "e": 39126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39625,
      "e": 39149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g "
    },
    {
      "t": 39625,
      "e": 39149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39746,
      "e": 39270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40226,
      "e": 39750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 40226,
      "e": 39750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40313,
      "e": 39837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 40362,
      "e": 39886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40362,
      "e": 39886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40466,
      "e": 39990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 40467,
      "e": 39991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40522,
      "e": 40046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 40553,
      "e": 40077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40642,
      "e": 40166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40643,
      "e": 40167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40746,
      "e": 40270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40747,
      "e": 40271,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40761,
      "e": 40285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 40873,
      "e": 40397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40913,
      "e": 40437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 40914,
      "e": 40438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41042,
      "e": 40566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 41074,
      "e": 40598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 41074,
      "e": 40598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41161,
      "e": 40685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 41161,
      "e": 40685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41185,
      "e": 40709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 41210,
      "e": 40734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41290,
      "e": 40814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 41292,
      "e": 40816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41369,
      "e": 40893,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 41498,
      "e": 41022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 41498,
      "e": 41022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41601,
      "e": 41125,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41603,
      "e": 41127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41625,
      "e": 41149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y "
    },
    {
      "t": 41737,
      "e": 41261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44691,
      "e": 44215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 44826,
      "e": 44350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44979,
      "e": 44503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 44979,
      "e": 44503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45106,
      "e": 44630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 45170,
      "e": 44694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 45274,
      "e": 44798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45275,
      "e": 44799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45275,
      "e": 44799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45401,
      "e": 44925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45402,
      "e": 44926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45433,
      "e": 44957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 45498,
      "e": 45022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 45498,
      "e": 45022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45569,
      "e": 45093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 45601,
      "e": 45125,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 45602,
      "e": 45126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45689,
      "e": 45213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 45706,
      "e": 45230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45706,
      "e": 45230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45729,
      "e": 45253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45825,
      "e": 45349,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 45834,
      "e": 45358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45962,
      "e": 45486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46042,
      "e": 45566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 46043,
      "e": 45567,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46145,
      "e": 45669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||B"
    },
    {
      "t": 46313,
      "e": 45837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 46458,
      "e": 45982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46458,
      "e": 45982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46465,
      "e": 45989,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46594,
      "e": 46118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46739,
      "e": 46263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 46739,
      "e": 46263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46873,
      "e": 46397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 46897,
      "e": 46421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46898,
      "e": 46422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46962,
      "e": 46486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 47002,
      "e": 46526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 47002,
      "e": 46526,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47090,
      "e": 46614,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 47090,
      "e": 46614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47162,
      "e": 46686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 47226,
      "e": 46750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47258,
      "e": 46782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47259,
      "e": 46783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47353,
      "e": 46877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 47377,
      "e": 46901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 47377,
      "e": 46901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47498,
      "e": 47022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 47649,
      "e": 47173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47649,
      "e": 47173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47762,
      "e": 47286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48650,
      "e": 48174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 48651,
      "e": 48175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48761,
      "e": 48285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 49178,
      "e": 48702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 49179,
      "e": 48703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49265,
      "e": 48789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 49394,
      "e": 48918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 49395,
      "e": 48919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49482,
      "e": 49006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 49570,
      "e": 49094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 49571,
      "e": 49095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49657,
      "e": 49181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 49690,
      "e": 49214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 49690,
      "e": 49214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49807,
      "e": 49217,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the diagnol, M and L starts and by looking vertically F and B starts coffe"
    },
    {
      "t": 49825,
      "e": 49235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 49842,
      "e": 49252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49842,
      "e": 49252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49969,
      "e": 49379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50025,
      "e": 49435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 50026,
      "e": 49436,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50090,
      "e": 49500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 50205,
      "e": 49615,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the diagnol, M and L starts and by looking vertically F and B starts coffe b"
    },
    {
      "t": 50251,
      "e": 49661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 50251,
      "e": 49661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50337,
      "e": 49747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 50554,
      "e": 49964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50585,
      "e": 49995,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the diagnol, M and L starts and by looking vertically F and B starts coffe b"
    },
    {
      "t": 50633,
      "e": 50043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50689,
      "e": 50099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the diagnol, M and L starts and by looking vertically F and B starts coffe "
    },
    {
      "t": 50777,
      "e": 50187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50818,
      "e": 50228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the diagnol, M and L starts and by looking vertically F and B starts coffe"
    },
    {
      "t": 50905,
      "e": 50315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50938,
      "e": 50348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the diagnol, M and L starts and by looking vertically F and B starts coff"
    },
    {
      "t": 51097,
      "e": 50507,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 51097,
      "e": 50507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51203,
      "e": 50613,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the diagnol, M and L starts and by looking vertically F and B starts coffe"
    },
    {
      "t": 51212,
      "e": 50622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 51517,
      "e": 50927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 51518,
      "e": 50928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51604,
      "e": 51014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 51700,
      "e": 51110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51701,
      "e": 51111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51806,
      "e": 51216,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the diagnol, M and L starts and by looking vertically F and B starts coffee "
    },
    {
      "t": 51836,
      "e": 51246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51853,
      "e": 51263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 51853,
      "e": 51263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51941,
      "e": 51351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 52085,
      "e": 51495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 52086,
      "e": 51496,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52180,
      "e": 51590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 52180,
      "e": 51590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52220,
      "e": 51630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 52327,
      "e": 51632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 52328,
      "e": 51633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52340,
      "e": 51645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 52444,
      "e": 51749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52444,
      "e": 51749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 52444,
      "e": 51749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52548,
      "e": 51853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 52548,
      "e": 51853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 52549,
      "e": 51854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52653,
      "e": 51958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 53404,
      "e": 52709,
      "ty": 2,
      "x": 285,
      "y": 577
    },
    {
      "t": 53409,
      "e": 52714,
      "ty": 7,
      "x": 292,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53504,
      "e": 52809,
      "ty": 2,
      "x": 330,
      "y": 647
    },
    {
      "t": 53505,
      "e": 52810,
      "ty": 41,
      "x": 5339,
      "y": 16557,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 53560,
      "e": 52865,
      "ty": 6,
      "x": 353,
      "y": 655,
      "ta": "#strategyButton"
    },
    {
      "t": 53604,
      "e": 52909,
      "ty": 2,
      "x": 365,
      "y": 661
    },
    {
      "t": 53705,
      "e": 53010,
      "ty": 2,
      "x": 377,
      "y": 667
    },
    {
      "t": 53755,
      "e": 53060,
      "ty": 41,
      "x": 24251,
      "y": 27496,
      "ta": "#strategyButton"
    },
    {
      "t": 53805,
      "e": 53110,
      "ty": 2,
      "x": 383,
      "y": 670
    },
    {
      "t": 53817,
      "e": 53122,
      "ty": 3,
      "x": 383,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 53819,
      "e": 53124,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the diagnol, M and L starts and by looking vertically F and B starts coffee breaks"
    },
    {
      "t": 53820,
      "e": 53125,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53821,
      "e": 53126,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 53896,
      "e": 53201,
      "ty": 4,
      "x": 24251,
      "y": 29424,
      "ta": "#strategyButton"
    },
    {
      "t": 53904,
      "e": 53209,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 53905,
      "e": 53210,
      "ty": 5,
      "x": 383,
      "y": 670,
      "ta": "#strategyButton"
    },
    {
      "t": 53911,
      "e": 53216,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 54005,
      "e": 53310,
      "ty": 41,
      "x": 12914,
      "y": 36673,
      "ta": "html > body"
    },
    {
      "t": 54304,
      "e": 53609,
      "ty": 2,
      "x": 423,
      "y": 661
    },
    {
      "t": 54403,
      "e": 53708,
      "ty": 2,
      "x": 1069,
      "y": 1088
    },
    {
      "t": 54503,
      "e": 53808,
      "ty": 2,
      "x": 820,
      "y": 1199
    },
    {
      "t": 54603,
      "e": 53908,
      "ty": 2,
      "x": 7,
      "y": 1039
    },
    {
      "t": 54704,
      "e": 54009,
      "ty": 2,
      "x": 663,
      "y": 506
    },
    {
      "t": 54754,
      "e": 54059,
      "ty": 41,
      "x": 34334,
      "y": 24097,
      "ta": "html > body"
    },
    {
      "t": 54804,
      "e": 54109,
      "ty": 2,
      "x": 1163,
      "y": 460
    },
    {
      "t": 54903,
      "e": 54208,
      "ty": 2,
      "x": 1193,
      "y": 552
    },
    {
      "t": 54913,
      "e": 54218,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 55003,
      "e": 54308,
      "ty": 2,
      "x": 1167,
      "y": 595
    },
    {
      "t": 55004,
      "e": 54309,
      "ty": 41,
      "x": 39913,
      "y": 32518,
      "ta": "html > body"
    },
    {
      "t": 55504,
      "e": 54809,
      "ty": 2,
      "x": 1151,
      "y": 594
    },
    {
      "t": 55504,
      "e": 54809,
      "ty": 41,
      "x": 39362,
      "y": 32462,
      "ta": "html > body"
    },
    {
      "t": 55603,
      "e": 54908,
      "ty": 2,
      "x": 1112,
      "y": 577
    },
    {
      "t": 55678,
      "e": 54983,
      "ty": 6,
      "x": 1103,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55704,
      "e": 55009,
      "ty": 2,
      "x": 1097,
      "y": 568
    },
    {
      "t": 55754,
      "e": 55059,
      "ty": 41,
      "x": 56667,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55760,
      "e": 55065,
      "ty": 7,
      "x": 1062,
      "y": 550,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 55804,
      "e": 55109,
      "ty": 2,
      "x": 1052,
      "y": 548
    },
    {
      "t": 55903,
      "e": 55208,
      "ty": 2,
      "x": 1049,
      "y": 547
    },
    {
      "t": 56004,
      "e": 55309,
      "ty": 41,
      "x": 52125,
      "y": 40166,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 56061,
      "e": 55366,
      "ty": 6,
      "x": 1049,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56104,
      "e": 55409,
      "ty": 2,
      "x": 1051,
      "y": 557
    },
    {
      "t": 56204,
      "e": 55509,
      "ty": 2,
      "x": 1057,
      "y": 559
    },
    {
      "t": 56254,
      "e": 55559,
      "ty": 41,
      "x": 54071,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56304,
      "e": 55609,
      "ty": 2,
      "x": 1058,
      "y": 560
    },
    {
      "t": 56404,
      "e": 55709,
      "ty": 2,
      "x": 1061,
      "y": 560
    },
    {
      "t": 56504,
      "e": 55809,
      "ty": 2,
      "x": 1074,
      "y": 558
    },
    {
      "t": 56504,
      "e": 55809,
      "ty": 41,
      "x": 57532,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56552,
      "e": 55857,
      "ty": 3,
      "x": 1074,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56553,
      "e": 55858,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56672,
      "e": 55977,
      "ty": 4,
      "x": 57532,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56673,
      "e": 55978,
      "ty": 5,
      "x": 1074,
      "y": 558,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57813,
      "e": 57118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 57814,
      "e": 57119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57925,
      "e": 57230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 58253,
      "e": 57558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 58253,
      "e": 57558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58332,
      "e": 57637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 58403,
      "e": 57708,
      "ty": 2,
      "x": 1074,
      "y": 566
    },
    {
      "t": 58414,
      "e": 57719,
      "ty": 7,
      "x": 1073,
      "y": 577,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58504,
      "e": 57809,
      "ty": 2,
      "x": 1070,
      "y": 619
    },
    {
      "t": 58504,
      "e": 57809,
      "ty": 41,
      "x": 56667,
      "y": 42129,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 58604,
      "e": 57909,
      "ty": 2,
      "x": 1069,
      "y": 636
    },
    {
      "t": 58704,
      "e": 58009,
      "ty": 2,
      "x": 1060,
      "y": 646
    },
    {
      "t": 58746,
      "e": 58051,
      "ty": 6,
      "x": 1060,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58754,
      "e": 58059,
      "ty": 41,
      "x": 54504,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58803,
      "e": 58108,
      "ty": 2,
      "x": 1060,
      "y": 650
    },
    {
      "t": 58904,
      "e": 58209,
      "ty": 2,
      "x": 1059,
      "y": 652
    },
    {
      "t": 58969,
      "e": 58274,
      "ty": 3,
      "x": 1059,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 58970,
      "e": 58275,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 58970,
      "e": 58275,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58971,
      "e": 58276,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59004,
      "e": 58309,
      "ty": 2,
      "x": 1059,
      "y": 653
    },
    {
      "t": 59004,
      "e": 58309,
      "ty": 41,
      "x": 54288,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59072,
      "e": 58377,
      "ty": 4,
      "x": 54288,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 59073,
      "e": 58378,
      "ty": 5,
      "x": 1059,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60004,
      "e": 59309,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60108,
      "e": 59413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 60261,
      "e": 59566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 60398,
      "e": 59703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 60398,
      "e": 59703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60516,
      "e": 59821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 60637,
      "e": 59942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 60748,
      "e": 60053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 60749,
      "e": 60054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60772,
      "e": 60077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ch"
    },
    {
      "t": 60827,
      "e": 60132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 60828,
      "e": 60133,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60852,
      "e": 60157,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chi"
    },
    {
      "t": 60956,
      "e": 60261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 60957,
      "e": 60262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61004,
      "e": 60309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chin"
    },
    {
      "t": 61036,
      "e": 60341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 61037,
      "e": 60342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61060,
      "e": 60365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 61148,
      "e": 60453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 61804,
      "e": 61109,
      "ty": 2,
      "x": 1040,
      "y": 663
    },
    {
      "t": 61834,
      "e": 61139,
      "ty": 7,
      "x": 1014,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61849,
      "e": 61154,
      "ty": 6,
      "x": 1002,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 61904,
      "e": 61209,
      "ty": 2,
      "x": 991,
      "y": 680
    },
    {
      "t": 62004,
      "e": 61309,
      "ty": 2,
      "x": 985,
      "y": 692
    },
    {
      "t": 62004,
      "e": 61309,
      "ty": 41,
      "x": 45909,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 62082,
      "e": 61387,
      "ty": 3,
      "x": 985,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 62082,
      "e": 61387,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "China"
    },
    {
      "t": 62082,
      "e": 61387,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62083,
      "e": 61388,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 62144,
      "e": 61449,
      "ty": 4,
      "x": 45909,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 62145,
      "e": 61450,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 62145,
      "e": 61450,
      "ty": 5,
      "x": 985,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 62145,
      "e": 61450,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 63163,
      "e": 62468,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 63904,
      "e": 63209,
      "ty": 2,
      "x": 985,
      "y": 682
    },
    {
      "t": 64004,
      "e": 63309,
      "ty": 2,
      "x": 974,
      "y": 604
    },
    {
      "t": 64004,
      "e": 63309,
      "ty": 41,
      "x": 36210,
      "y": 33103,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 64104,
      "e": 63409,
      "ty": 2,
      "x": 962,
      "y": 484
    },
    {
      "t": 64203,
      "e": 63508,
      "ty": 2,
      "x": 929,
      "y": 281
    },
    {
      "t": 64254,
      "e": 63559,
      "ty": 41,
      "x": 22683,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 64304,
      "e": 63609,
      "ty": 2,
      "x": 912,
      "y": 223
    },
    {
      "t": 64404,
      "e": 63709,
      "ty": 2,
      "x": 905,
      "y": 216
    },
    {
      "t": 64504,
      "e": 63809,
      "ty": 2,
      "x": 836,
      "y": 246
    },
    {
      "t": 64504,
      "e": 63809,
      "ty": 41,
      "x": 11937,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 64604,
      "e": 63909,
      "ty": 2,
      "x": 826,
      "y": 248
    },
    {
      "t": 64704,
      "e": 64009,
      "ty": 2,
      "x": 811,
      "y": 250
    },
    {
      "t": 64754,
      "e": 64059,
      "ty": 41,
      "x": 27653,
      "y": 13461,
      "ta": "html > body"
    },
    {
      "t": 64805,
      "e": 64110,
      "ty": 2,
      "x": 820,
      "y": 240
    },
    {
      "t": 64904,
      "e": 64209,
      "ty": 2,
      "x": 824,
      "y": 234
    },
    {
      "t": 65005,
      "e": 64310,
      "ty": 41,
      "x": 2111,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 65104,
      "e": 64409,
      "ty": 2,
      "x": 825,
      "y": 273
    },
    {
      "t": 65204,
      "e": 64509,
      "ty": 2,
      "x": 825,
      "y": 295
    },
    {
      "t": 65254,
      "e": 64559,
      "ty": 41,
      "x": 1121,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 65593,
      "e": 64898,
      "ty": 3,
      "x": 825,
      "y": 295,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 65744,
      "e": 65049,
      "ty": 4,
      "x": 1121,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 65744,
      "e": 65049,
      "ty": 5,
      "x": 825,
      "y": 295,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 65745,
      "e": 65050,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 65746,
      "e": 65051,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 66405,
      "e": 65710,
      "ty": 2,
      "x": 826,
      "y": 305
    },
    {
      "t": 66504,
      "e": 65809,
      "ty": 2,
      "x": 826,
      "y": 312
    },
    {
      "t": 66504,
      "e": 65809,
      "ty": 41,
      "x": 1086,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 66553,
      "e": 65858,
      "ty": 6,
      "x": 827,
      "y": 318,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 66603,
      "e": 65908,
      "ty": 7,
      "x": 829,
      "y": 329,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 66604,
      "e": 65909,
      "ty": 2,
      "x": 829,
      "y": 329
    },
    {
      "t": 66704,
      "e": 66009,
      "ty": 2,
      "x": 831,
      "y": 339
    },
    {
      "t": 66754,
      "e": 66059,
      "ty": 41,
      "x": 2273,
      "y": 13301,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 66804,
      "e": 66109,
      "ty": 2,
      "x": 832,
      "y": 351
    },
    {
      "t": 66904,
      "e": 66209,
      "ty": 2,
      "x": 834,
      "y": 380
    },
    {
      "t": 67003,
      "e": 66308,
      "ty": 2,
      "x": 843,
      "y": 404
    },
    {
      "t": 67003,
      "e": 66308,
      "ty": 41,
      "x": 5121,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 67103,
      "e": 66408,
      "ty": 2,
      "x": 843,
      "y": 448
    },
    {
      "t": 67205,
      "e": 66409,
      "ty": 6,
      "x": 835,
      "y": 444,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 67205,
      "e": 66409,
      "ty": 2,
      "x": 835,
      "y": 444
    },
    {
      "t": 67254,
      "e": 66458,
      "ty": 41,
      "x": 12996,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 67304,
      "e": 66508,
      "ty": 2,
      "x": 829,
      "y": 436
    },
    {
      "t": 67320,
      "e": 66524,
      "ty": 7,
      "x": 828,
      "y": 435,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 67404,
      "e": 66608,
      "ty": 6,
      "x": 828,
      "y": 419,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67404,
      "e": 66608,
      "ty": 2,
      "x": 828,
      "y": 419
    },
    {
      "t": 67504,
      "e": 66708,
      "ty": 2,
      "x": 827,
      "y": 412
    },
    {
      "t": 67505,
      "e": 66709,
      "ty": 41,
      "x": 2914,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67585,
      "e": 66789,
      "ty": 3,
      "x": 827,
      "y": 412,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67587,
      "e": 66791,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 67587,
      "e": 66791,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67704,
      "e": 66908,
      "ty": 4,
      "x": 2914,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67704,
      "e": 66908,
      "ty": 5,
      "x": 827,
      "y": 412,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 67705,
      "e": 66909,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 68071,
      "e": 67275,
      "ty": 7,
      "x": 827,
      "y": 422,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 68104,
      "e": 67308,
      "ty": 2,
      "x": 828,
      "y": 426
    },
    {
      "t": 68171,
      "e": 67375,
      "ty": 6,
      "x": 829,
      "y": 438,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 68205,
      "e": 67409,
      "ty": 2,
      "x": 830,
      "y": 440
    },
    {
      "t": 68238,
      "e": 67442,
      "ty": 7,
      "x": 832,
      "y": 450,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 68254,
      "e": 67458,
      "ty": 41,
      "x": 8449,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 68304,
      "e": 67508,
      "ty": 2,
      "x": 833,
      "y": 457
    },
    {
      "t": 68371,
      "e": 67575,
      "ty": 6,
      "x": 833,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 68404,
      "e": 67608,
      "ty": 2,
      "x": 833,
      "y": 466
    },
    {
      "t": 68454,
      "e": 67658,
      "ty": 7,
      "x": 836,
      "y": 482,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 68488,
      "e": 67692,
      "ty": 6,
      "x": 837,
      "y": 494,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 68504,
      "e": 67708,
      "ty": 2,
      "x": 839,
      "y": 501
    },
    {
      "t": 68504,
      "e": 67708,
      "ty": 41,
      "x": 63408,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 68521,
      "e": 67725,
      "ty": 7,
      "x": 839,
      "y": 507,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 68605,
      "e": 67809,
      "ty": 2,
      "x": 842,
      "y": 521
    },
    {
      "t": 68705,
      "e": 67909,
      "ty": 2,
      "x": 848,
      "y": 556
    },
    {
      "t": 68754,
      "e": 67958,
      "ty": 41,
      "x": 30355,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 68804,
      "e": 68008,
      "ty": 2,
      "x": 855,
      "y": 597
    },
    {
      "t": 68904,
      "e": 68108,
      "ty": 2,
      "x": 857,
      "y": 611
    },
    {
      "t": 69004,
      "e": 68208,
      "ty": 2,
      "x": 857,
      "y": 629
    },
    {
      "t": 69004,
      "e": 68208,
      "ty": 41,
      "x": 8443,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 69105,
      "e": 68309,
      "ty": 2,
      "x": 859,
      "y": 643
    },
    {
      "t": 69204,
      "e": 68408,
      "ty": 2,
      "x": 856,
      "y": 665
    },
    {
      "t": 69254,
      "e": 68458,
      "ty": 41,
      "x": 8747,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 69304,
      "e": 68508,
      "ty": 2,
      "x": 853,
      "y": 679
    },
    {
      "t": 69504,
      "e": 68708,
      "ty": 41,
      "x": 8478,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 70005,
      "e": 69209,
      "ty": 2,
      "x": 851,
      "y": 679
    },
    {
      "t": 70005,
      "e": 69209,
      "ty": 41,
      "x": 7941,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 70105,
      "e": 69309,
      "ty": 2,
      "x": 849,
      "y": 678
    },
    {
      "t": 70254,
      "e": 69458,
      "ty": 41,
      "x": 7136,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 70305,
      "e": 69509,
      "ty": 2,
      "x": 845,
      "y": 675
    },
    {
      "t": 70404,
      "e": 69608,
      "ty": 2,
      "x": 844,
      "y": 675
    },
    {
      "t": 70472,
      "e": 69608,
      "ty": 6,
      "x": 838,
      "y": 674,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 70504,
      "e": 69640,
      "ty": 2,
      "x": 836,
      "y": 672
    },
    {
      "t": 70504,
      "e": 69640,
      "ty": 41,
      "x": 48284,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 70604,
      "e": 69740,
      "ty": 2,
      "x": 829,
      "y": 669
    },
    {
      "t": 70754,
      "e": 69890,
      "ty": 41,
      "x": 2914,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 70804,
      "e": 69940,
      "ty": 2,
      "x": 826,
      "y": 668
    },
    {
      "t": 70969,
      "e": 70105,
      "ty": 3,
      "x": 826,
      "y": 668,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 70970,
      "e": 70106,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 70971,
      "e": 70107,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 71005,
      "e": 70141,
      "ty": 41,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 71193,
      "e": 70329,
      "ty": 4,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 71194,
      "e": 70330,
      "ty": 5,
      "x": 826,
      "y": 668,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 71194,
      "e": 70330,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 71504,
      "e": 70640,
      "ty": 2,
      "x": 828,
      "y": 668
    },
    {
      "t": 71505,
      "e": 70641,
      "ty": 41,
      "x": 7955,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 71604,
      "e": 70740,
      "ty": 2,
      "x": 832,
      "y": 674
    },
    {
      "t": 71754,
      "e": 70890,
      "ty": 41,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 71805,
      "e": 70941,
      "ty": 2,
      "x": 832,
      "y": 675
    },
    {
      "t": 72005,
      "e": 71141,
      "ty": 2,
      "x": 830,
      "y": 675
    },
    {
      "t": 72005,
      "e": 71141,
      "ty": 41,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 72024,
      "e": 71160,
      "ty": 7,
      "x": 829,
      "y": 683,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 72041,
      "e": 71177,
      "ty": 6,
      "x": 832,
      "y": 699,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 72058,
      "e": 71194,
      "ty": 7,
      "x": 836,
      "y": 711,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 72105,
      "e": 71241,
      "ty": 2,
      "x": 843,
      "y": 721
    },
    {
      "t": 72204,
      "e": 71340,
      "ty": 2,
      "x": 858,
      "y": 738
    },
    {
      "t": 72255,
      "e": 71391,
      "ty": 41,
      "x": 37832,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 72305,
      "e": 71441,
      "ty": 2,
      "x": 916,
      "y": 850
    },
    {
      "t": 72404,
      "e": 71540,
      "ty": 2,
      "x": 927,
      "y": 893
    },
    {
      "t": 72505,
      "e": 71641,
      "ty": 2,
      "x": 923,
      "y": 930
    },
    {
      "t": 72505,
      "e": 71641,
      "ty": 41,
      "x": 24107,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 72605,
      "e": 71741,
      "ty": 2,
      "x": 915,
      "y": 945
    },
    {
      "t": 72705,
      "e": 71841,
      "ty": 2,
      "x": 897,
      "y": 986
    },
    {
      "t": 72755,
      "e": 71891,
      "ty": 41,
      "x": 17699,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 72805,
      "e": 71941,
      "ty": 2,
      "x": 896,
      "y": 989
    },
    {
      "t": 72904,
      "e": 72040,
      "ty": 2,
      "x": 895,
      "y": 989
    },
    {
      "t": 73005,
      "e": 72141,
      "ty": 2,
      "x": 895,
      "y": 875
    },
    {
      "t": 73005,
      "e": 72141,
      "ty": 41,
      "x": 17461,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 73105,
      "e": 72241,
      "ty": 2,
      "x": 873,
      "y": 772
    },
    {
      "t": 73204,
      "e": 72340,
      "ty": 2,
      "x": 861,
      "y": 753
    },
    {
      "t": 73254,
      "e": 72390,
      "ty": 41,
      "x": 8427,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 73305,
      "e": 72441,
      "ty": 2,
      "x": 851,
      "y": 722
    },
    {
      "t": 73405,
      "e": 72541,
      "ty": 2,
      "x": 843,
      "y": 710
    },
    {
      "t": 73443,
      "e": 72579,
      "ty": 6,
      "x": 839,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 73476,
      "e": 72612,
      "ty": 7,
      "x": 837,
      "y": 692,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 73504,
      "e": 72640,
      "ty": 2,
      "x": 835,
      "y": 688
    },
    {
      "t": 73504,
      "e": 72640,
      "ty": 41,
      "x": 3222,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 73605,
      "e": 72741,
      "ty": 2,
      "x": 834,
      "y": 682
    },
    {
      "t": 73704,
      "e": 72840,
      "ty": 2,
      "x": 838,
      "y": 687
    },
    {
      "t": 73755,
      "e": 72891,
      "ty": 41,
      "x": 4883,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 73805,
      "e": 72941,
      "ty": 2,
      "x": 844,
      "y": 690
    },
    {
      "t": 73905,
      "e": 73041,
      "ty": 2,
      "x": 843,
      "y": 702
    },
    {
      "t": 73959,
      "e": 73095,
      "ty": 6,
      "x": 839,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 74004,
      "e": 73140,
      "ty": 2,
      "x": 832,
      "y": 703
    },
    {
      "t": 74004,
      "e": 73140,
      "ty": 41,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 74105,
      "e": 73241,
      "ty": 2,
      "x": 829,
      "y": 702
    },
    {
      "t": 74255,
      "e": 73391,
      "ty": 41,
      "x": 12996,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 74425,
      "e": 73561,
      "ty": 3,
      "x": 829,
      "y": 702,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 74426,
      "e": 73562,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 74427,
      "e": 73563,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 74544,
      "e": 73680,
      "ty": 4,
      "x": 12996,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 74545,
      "e": 73681,
      "ty": 5,
      "x": 829,
      "y": 702,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 74545,
      "e": 73681,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 74794,
      "e": 73930,
      "ty": 7,
      "x": 833,
      "y": 718,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 74805,
      "e": 73941,
      "ty": 2,
      "x": 833,
      "y": 718
    },
    {
      "t": 74811,
      "e": 73942,
      "ty": 6,
      "x": 837,
      "y": 730,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 74826,
      "e": 73957,
      "ty": 7,
      "x": 843,
      "y": 743,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 74905,
      "e": 74036,
      "ty": 2,
      "x": 862,
      "y": 793
    },
    {
      "t": 75004,
      "e": 74135,
      "ty": 2,
      "x": 873,
      "y": 877
    },
    {
      "t": 75004,
      "e": 74135,
      "ty": 41,
      "x": 12240,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 75104,
      "e": 74235,
      "ty": 2,
      "x": 880,
      "y": 926
    },
    {
      "t": 75204,
      "e": 74335,
      "ty": 2,
      "x": 881,
      "y": 943
    },
    {
      "t": 75255,
      "e": 74386,
      "ty": 41,
      "x": 14376,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 75305,
      "e": 74436,
      "ty": 2,
      "x": 881,
      "y": 956
    },
    {
      "t": 75404,
      "e": 74535,
      "ty": 2,
      "x": 868,
      "y": 960
    },
    {
      "t": 75505,
      "e": 74636,
      "ty": 2,
      "x": 851,
      "y": 957
    },
    {
      "t": 75505,
      "e": 74636,
      "ty": 41,
      "x": 23926,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 75603,
      "e": 74734,
      "ty": 2,
      "x": 837,
      "y": 946
    },
    {
      "t": 75611,
      "e": 74742,
      "ty": 6,
      "x": 835,
      "y": 940,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 75660,
      "e": 74791,
      "ty": 7,
      "x": 832,
      "y": 925,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 75703,
      "e": 74834,
      "ty": 2,
      "x": 832,
      "y": 922
    },
    {
      "t": 75754,
      "e": 74885,
      "ty": 41,
      "x": 2510,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 75793,
      "e": 74924,
      "ty": 6,
      "x": 834,
      "y": 929,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 75804,
      "e": 74935,
      "ty": 2,
      "x": 834,
      "y": 929
    },
    {
      "t": 75861,
      "e": 74992,
      "ty": 7,
      "x": 832,
      "y": 942,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 75903,
      "e": 75034,
      "ty": 2,
      "x": 830,
      "y": 947
    },
    {
      "t": 76004,
      "e": 75135,
      "ty": 2,
      "x": 828,
      "y": 953
    },
    {
      "t": 76004,
      "e": 75135,
      "ty": 41,
      "x": 5321,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 76145,
      "e": 75276,
      "ty": 6,
      "x": 828,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 76203,
      "e": 75334,
      "ty": 2,
      "x": 826,
      "y": 960
    },
    {
      "t": 76254,
      "e": 75385,
      "ty": 41,
      "x": 0,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 76256,
      "e": 75387,
      "ty": 3,
      "x": 826,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 76256,
      "e": 75387,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 76256,
      "e": 75387,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 76344,
      "e": 75475,
      "ty": 4,
      "x": 0,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 76345,
      "e": 75476,
      "ty": 5,
      "x": 826,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 76345,
      "e": 75476,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 76493,
      "e": 75624,
      "ty": 7,
      "x": 835,
      "y": 972,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 76504,
      "e": 75635,
      "ty": 2,
      "x": 835,
      "y": 972
    },
    {
      "t": 76504,
      "e": 75635,
      "ty": 41,
      "x": 10983,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 76604,
      "e": 75735,
      "ty": 2,
      "x": 861,
      "y": 998
    },
    {
      "t": 76628,
      "e": 75759,
      "ty": 6,
      "x": 867,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76704,
      "e": 75835,
      "ty": 2,
      "x": 867,
      "y": 1007
    },
    {
      "t": 76754,
      "e": 75885,
      "ty": 41,
      "x": 19367,
      "y": 3971,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76803,
      "e": 75934,
      "ty": 2,
      "x": 869,
      "y": 1007
    },
    {
      "t": 76857,
      "e": 75988,
      "ty": 3,
      "x": 870,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76858,
      "e": 75989,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 76859,
      "e": 75990,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76903,
      "e": 76034,
      "ty": 2,
      "x": 870,
      "y": 1008
    },
    {
      "t": 76952,
      "e": 76083,
      "ty": 4,
      "x": 20913,
      "y": 5957,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76952,
      "e": 76083,
      "ty": 5,
      "x": 870,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76954,
      "e": 76085,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 76956,
      "e": 76087,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 76957,
      "e": 76088,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 77004,
      "e": 76135,
      "ty": 41,
      "x": 29685,
      "y": 55397,
      "ta": "html > body"
    },
    {
      "t": 77404,
      "e": 76535,
      "ty": 2,
      "x": 883,
      "y": 958
    },
    {
      "t": 77504,
      "e": 76635,
      "ty": 2,
      "x": 978,
      "y": 532
    },
    {
      "t": 77504,
      "e": 76635,
      "ty": 41,
      "x": 33404,
      "y": 29028,
      "ta": "html > body"
    },
    {
      "t": 77603,
      "e": 76734,
      "ty": 2,
      "x": 968,
      "y": 378
    },
    {
      "t": 77703,
      "e": 76834,
      "ty": 2,
      "x": 965,
      "y": 360
    },
    {
      "t": 77754,
      "e": 76885,
      "ty": 41,
      "x": 32956,
      "y": 18613,
      "ta": "html > body"
    },
    {
      "t": 77804,
      "e": 76935,
      "ty": 2,
      "x": 964,
      "y": 340
    },
    {
      "t": 78004,
      "e": 77135,
      "ty": 41,
      "x": 32922,
      "y": 18391,
      "ta": "html > body"
    },
    {
      "t": 78332,
      "e": 77463,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 80004,
      "e": 79135,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 82754,
      "e": 81885,
      "ty": 41,
      "x": 32890,
      "y": 10568,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 82804,
      "e": 81935,
      "ty": 2,
      "x": 957,
      "y": 341
    },
    {
      "t": 82904,
      "e": 82035,
      "ty": 2,
      "x": 954,
      "y": 342
    },
    {
      "t": 83003,
      "e": 82134,
      "ty": 2,
      "x": 951,
      "y": 344
    },
    {
      "t": 83004,
      "e": 82135,
      "ty": 41,
      "x": 32349,
      "y": 22271,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 83104,
      "e": 82235,
      "ty": 2,
      "x": 950,
      "y": 344
    },
    {
      "t": 83254,
      "e": 82385,
      "ty": 41,
      "x": 32300,
      "y": 22271,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 85204,
      "e": 84335,
      "ty": 2,
      "x": 949,
      "y": 344
    },
    {
      "t": 85255,
      "e": 84386,
      "ty": 41,
      "x": 32250,
      "y": 22271,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 88104,
      "e": 87235,
      "ty": 2,
      "x": 947,
      "y": 344
    },
    {
      "t": 88204,
      "e": 87335,
      "ty": 2,
      "x": 900,
      "y": 383
    },
    {
      "t": 88255,
      "e": 87386,
      "ty": 41,
      "x": 29594,
      "y": 5083,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 88304,
      "e": 87435,
      "ty": 2,
      "x": 895,
      "y": 387
    },
    {
      "t": 88404,
      "e": 87535,
      "ty": 2,
      "x": 884,
      "y": 403
    },
    {
      "t": 88504,
      "e": 87635,
      "ty": 2,
      "x": 865,
      "y": 449
    },
    {
      "t": 88504,
      "e": 87635,
      "ty": 41,
      "x": 28118,
      "y": 53454,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 88605,
      "e": 87736,
      "ty": 2,
      "x": 861,
      "y": 490
    },
    {
      "t": 88704,
      "e": 87835,
      "ty": 2,
      "x": 878,
      "y": 586
    },
    {
      "t": 88755,
      "e": 87886,
      "ty": 41,
      "x": 29594,
      "y": 52863,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 88804,
      "e": 87935,
      "ty": 2,
      "x": 901,
      "y": 629
    },
    {
      "t": 88904,
      "e": 88035,
      "ty": 2,
      "x": 931,
      "y": 702
    },
    {
      "t": 89004,
      "e": 88135,
      "ty": 2,
      "x": 967,
      "y": 787
    },
    {
      "t": 89004,
      "e": 88135,
      "ty": 41,
      "x": 33136,
      "y": 52395,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 89104,
      "e": 88235,
      "ty": 2,
      "x": 977,
      "y": 841
    },
    {
      "t": 89204,
      "e": 88335,
      "ty": 2,
      "x": 981,
      "y": 896
    },
    {
      "t": 89255,
      "e": 88386,
      "ty": 41,
      "x": 33825,
      "y": 64401,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 89305,
      "e": 88436,
      "ty": 2,
      "x": 981,
      "y": 911
    },
    {
      "t": 89404,
      "e": 88535,
      "ty": 2,
      "x": 976,
      "y": 973
    },
    {
      "t": 89504,
      "e": 88635,
      "ty": 2,
      "x": 975,
      "y": 990
    },
    {
      "t": 89504,
      "e": 88635,
      "ty": 41,
      "x": 33530,
      "y": 59809,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 89604,
      "e": 88735,
      "ty": 2,
      "x": 965,
      "y": 1014
    },
    {
      "t": 89704,
      "e": 88835,
      "ty": 2,
      "x": 954,
      "y": 1044
    },
    {
      "t": 89754,
      "e": 88885,
      "ty": 41,
      "x": 32496,
      "y": 63548,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 89904,
      "e": 89035,
      "ty": 2,
      "x": 950,
      "y": 1056
    },
    {
      "t": 90004,
      "e": 89135,
      "ty": 2,
      "x": 947,
      "y": 1063
    },
    {
      "t": 90004,
      "e": 89135,
      "ty": 41,
      "x": 32152,
      "y": 64864,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 90004,
      "e": 89135,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90073,
      "e": 89204,
      "ty": 6,
      "x": 938,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 90104,
      "e": 89235,
      "ty": 2,
      "x": 935,
      "y": 1079
    },
    {
      "t": 90204,
      "e": 89335,
      "ty": 2,
      "x": 931,
      "y": 1084
    },
    {
      "t": 90254,
      "e": 89385,
      "ty": 41,
      "x": 11741,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 93404,
      "e": 92535,
      "ty": 2,
      "x": 925,
      "y": 1074
    },
    {
      "t": 93505,
      "e": 92636,
      "ty": 2,
      "x": 925,
      "y": 1072
    },
    {
      "t": 93505,
      "e": 92636,
      "ty": 41,
      "x": 8464,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 93553,
      "e": 92684,
      "ty": 7,
      "x": 923,
      "y": 1071,
      "ta": "#start"
    },
    {
      "t": 93604,
      "e": 92735,
      "ty": 2,
      "x": 922,
      "y": 1068
    },
    {
      "t": 93704,
      "e": 92835,
      "ty": 2,
      "x": 922,
      "y": 1067
    },
    {
      "t": 93754,
      "e": 92885,
      "ty": 41,
      "x": 30922,
      "y": 65141,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94255,
      "e": 93386,
      "ty": 41,
      "x": 30922,
      "y": 64933,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94305,
      "e": 93436,
      "ty": 2,
      "x": 921,
      "y": 1050
    },
    {
      "t": 94405,
      "e": 93536,
      "ty": 2,
      "x": 921,
      "y": 1028
    },
    {
      "t": 94504,
      "e": 93635,
      "ty": 2,
      "x": 930,
      "y": 975
    },
    {
      "t": 94505,
      "e": 93636,
      "ty": 41,
      "x": 31316,
      "y": 58770,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94605,
      "e": 93736,
      "ty": 2,
      "x": 935,
      "y": 956
    },
    {
      "t": 94704,
      "e": 93835,
      "ty": 2,
      "x": 945,
      "y": 927
    },
    {
      "t": 94754,
      "e": 93885,
      "ty": 41,
      "x": 32201,
      "y": 54892,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 94805,
      "e": 93936,
      "ty": 2,
      "x": 951,
      "y": 913
    },
    {
      "t": 94905,
      "e": 94036,
      "ty": 2,
      "x": 956,
      "y": 902
    },
    {
      "t": 95004,
      "e": 94135,
      "ty": 2,
      "x": 961,
      "y": 893
    },
    {
      "t": 95005,
      "e": 94136,
      "ty": 41,
      "x": 32841,
      "y": 48017,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 95204,
      "e": 94335,
      "ty": 2,
      "x": 979,
      "y": 897
    },
    {
      "t": 95254,
      "e": 94385,
      "ty": 41,
      "x": 34218,
      "y": 53715,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 95304,
      "e": 94435,
      "ty": 2,
      "x": 996,
      "y": 905
    },
    {
      "t": 95404,
      "e": 94535,
      "ty": 2,
      "x": 1009,
      "y": 912
    },
    {
      "t": 95504,
      "e": 94635,
      "ty": 2,
      "x": 1016,
      "y": 950
    },
    {
      "t": 95505,
      "e": 94636,
      "ty": 41,
      "x": 35547,
      "y": 57039,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 95604,
      "e": 94735,
      "ty": 2,
      "x": 1017,
      "y": 974
    },
    {
      "t": 95704,
      "e": 94835,
      "ty": 2,
      "x": 999,
      "y": 1018
    },
    {
      "t": 95754,
      "e": 94885,
      "ty": 41,
      "x": 34120,
      "y": 63063,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 95805,
      "e": 94936,
      "ty": 2,
      "x": 983,
      "y": 1045
    },
    {
      "t": 95905,
      "e": 95036,
      "ty": 2,
      "x": 975,
      "y": 1052
    },
    {
      "t": 96003,
      "e": 95134,
      "ty": 2,
      "x": 965,
      "y": 1059
    },
    {
      "t": 96004,
      "e": 95135,
      "ty": 41,
      "x": 33038,
      "y": 64587,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 96104,
      "e": 95235,
      "ty": 2,
      "x": 962,
      "y": 1061
    },
    {
      "t": 96205,
      "e": 95336,
      "ty": 2,
      "x": 956,
      "y": 1068
    },
    {
      "t": 96227,
      "e": 95358,
      "ty": 6,
      "x": 949,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 96254,
      "e": 95385,
      "ty": 41,
      "x": 19387,
      "y": 4457,
      "ta": "#start"
    },
    {
      "t": 96304,
      "e": 95435,
      "ty": 2,
      "x": 941,
      "y": 1078
    },
    {
      "t": 96404,
      "e": 95535,
      "ty": 2,
      "x": 940,
      "y": 1078
    },
    {
      "t": 96504,
      "e": 95635,
      "ty": 2,
      "x": 933,
      "y": 1090
    },
    {
      "t": 96504,
      "e": 95635,
      "ty": 41,
      "x": 12833,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 97254,
      "e": 96385,
      "ty": 41,
      "x": 12833,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 97304,
      "e": 96435,
      "ty": 2,
      "x": 935,
      "y": 1091
    },
    {
      "t": 97404,
      "e": 96535,
      "ty": 2,
      "x": 938,
      "y": 1088
    },
    {
      "t": 97504,
      "e": 96635,
      "ty": 41,
      "x": 15564,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 97603,
      "e": 96734,
      "ty": 2,
      "x": 942,
      "y": 1088
    },
    {
      "t": 97704,
      "e": 96835,
      "ty": 2,
      "x": 947,
      "y": 1088
    },
    {
      "t": 97754,
      "e": 96885,
      "ty": 41,
      "x": 21571,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 97804,
      "e": 96935,
      "ty": 2,
      "x": 951,
      "y": 1089
    },
    {
      "t": 97903,
      "e": 97034,
      "ty": 2,
      "x": 954,
      "y": 1091
    },
    {
      "t": 98003,
      "e": 97134,
      "ty": 2,
      "x": 955,
      "y": 1091
    },
    {
      "t": 98004,
      "e": 97135,
      "ty": 41,
      "x": 24848,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 98303,
      "e": 97434,
      "ty": 2,
      "x": 957,
      "y": 1091
    },
    {
      "t": 98403,
      "e": 97534,
      "ty": 2,
      "x": 968,
      "y": 1091
    },
    {
      "t": 98503,
      "e": 97634,
      "ty": 2,
      "x": 969,
      "y": 1091
    },
    {
      "t": 98504,
      "e": 97635,
      "ty": 41,
      "x": 32494,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 98603,
      "e": 97734,
      "ty": 2,
      "x": 973,
      "y": 1093
    },
    {
      "t": 98753,
      "e": 97884,
      "ty": 41,
      "x": 34678,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 98858,
      "e": 97989,
      "ty": 3,
      "x": 973,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 98859,
      "e": 97990,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 98992,
      "e": 98123,
      "ty": 4,
      "x": 34678,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 98992,
      "e": 98123,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 98993,
      "e": 98124,
      "ty": 5,
      "x": 973,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 98993,
      "e": 98124,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 99403,
      "e": 98534,
      "ty": 2,
      "x": 981,
      "y": 1056
    },
    {
      "t": 99504,
      "e": 98635,
      "ty": 2,
      "x": 1046,
      "y": 607
    },
    {
      "t": 99504,
      "e": 98635,
      "ty": 41,
      "x": 35746,
      "y": 33182,
      "ta": "html > body"
    },
    {
      "t": 99604,
      "e": 98735,
      "ty": 2,
      "x": 1041,
      "y": 438
    },
    {
      "t": 99703,
      "e": 98834,
      "ty": 2,
      "x": 1039,
      "y": 420
    },
    {
      "t": 99754,
      "e": 98885,
      "ty": 41,
      "x": 35505,
      "y": 22823,
      "ta": "html > body"
    },
    {
      "t": 100030,
      "e": 99161,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 100669,
      "e": 99800,
      "ty": 2,
      "x": 920,
      "y": 434
    },
    {
      "t": 100669,
      "e": 99800,
      "ty": 41,
      "x": 30739,
      "y": 32722,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 100669,
      "e": 99800,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 101267,
      "e": 100398,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 222558, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 222563, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 3170, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 227069, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 11281, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"ZULU\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"211\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 239356, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 24019, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 264474, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 30224, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 295699, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 20998, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 318077, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-U -11 AM-F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:946,y:1007,t:1528143458925};\\\", \\\"{x:949,y:1006,t:1528143458941};\\\", \\\"{x:955,y:1000,t:1528143458956};\\\", \\\"{x:961,y:989,t:1528143458974};\\\", \\\"{x:965,y:985,t:1528143458990};\\\", \\\"{x:968,y:981,t:1528143459006};\\\", \\\"{x:974,y:974,t:1528143459024};\\\", \\\"{x:983,y:967,t:1528143459041};\\\", \\\"{x:987,y:963,t:1528143459056};\\\", \\\"{x:992,y:958,t:1528143459073};\\\", \\\"{x:1001,y:948,t:1528143459091};\\\", \\\"{x:1005,y:941,t:1528143459107};\\\", \\\"{x:1014,y:932,t:1528143459124};\\\", \\\"{x:1022,y:920,t:1528143459140};\\\", \\\"{x:1042,y:903,t:1528143459157};\\\", \\\"{x:1068,y:885,t:1528143459174};\\\", \\\"{x:1094,y:866,t:1528143459191};\\\", \\\"{x:1117,y:850,t:1528143459207};\\\", \\\"{x:1138,y:831,t:1528143459224};\\\", \\\"{x:1163,y:810,t:1528143459241};\\\", \\\"{x:1180,y:793,t:1528143459258};\\\", \\\"{x:1194,y:781,t:1528143459274};\\\", \\\"{x:1206,y:770,t:1528143459291};\\\", \\\"{x:1216,y:761,t:1528143459308};\\\", \\\"{x:1221,y:756,t:1528143459324};\\\", \\\"{x:1229,y:749,t:1528143459341};\\\", \\\"{x:1233,y:744,t:1528143459359};\\\", \\\"{x:1237,y:740,t:1528143459375};\\\", \\\"{x:1241,y:735,t:1528143459392};\\\", \\\"{x:1246,y:730,t:1528143459409};\\\", \\\"{x:1253,y:723,t:1528143459424};\\\", \\\"{x:1262,y:717,t:1528143459441};\\\", \\\"{x:1271,y:712,t:1528143459458};\\\", \\\"{x:1279,y:708,t:1528143459474};\\\", \\\"{x:1286,y:704,t:1528143459492};\\\", \\\"{x:1293,y:700,t:1528143459508};\\\", \\\"{x:1300,y:699,t:1528143459525};\\\", \\\"{x:1305,y:696,t:1528143459541};\\\", \\\"{x:1308,y:696,t:1528143459559};\\\", \\\"{x:1313,y:693,t:1528143459575};\\\", \\\"{x:1315,y:692,t:1528143459591};\\\", \\\"{x:1321,y:690,t:1528143459609};\\\", \\\"{x:1325,y:689,t:1528143459625};\\\", \\\"{x:1331,y:687,t:1528143459641};\\\", \\\"{x:1336,y:684,t:1528143459659};\\\", \\\"{x:1344,y:681,t:1528143459675};\\\", \\\"{x:1353,y:679,t:1528143459691};\\\", \\\"{x:1359,y:678,t:1528143459708};\\\", \\\"{x:1368,y:678,t:1528143459725};\\\", \\\"{x:1372,y:678,t:1528143459741};\\\", \\\"{x:1379,y:678,t:1528143459758};\\\", \\\"{x:1384,y:678,t:1528143459775};\\\", \\\"{x:1390,y:681,t:1528143459792};\\\", \\\"{x:1393,y:684,t:1528143459808};\\\", \\\"{x:1399,y:686,t:1528143459826};\\\", \\\"{x:1405,y:688,t:1528143459841};\\\", \\\"{x:1412,y:689,t:1528143459858};\\\", \\\"{x:1423,y:693,t:1528143459876};\\\", \\\"{x:1428,y:694,t:1528143459892};\\\", \\\"{x:1433,y:696,t:1528143459909};\\\", \\\"{x:1444,y:699,t:1528143459925};\\\", \\\"{x:1449,y:701,t:1528143459941};\\\", \\\"{x:1453,y:703,t:1528143459959};\\\", \\\"{x:1456,y:706,t:1528143459976};\\\", \\\"{x:1461,y:711,t:1528143459991};\\\", \\\"{x:1468,y:721,t:1528143460008};\\\", \\\"{x:1474,y:733,t:1528143460026};\\\", \\\"{x:1479,y:743,t:1528143460042};\\\", \\\"{x:1484,y:755,t:1528143460058};\\\", \\\"{x:1486,y:767,t:1528143460075};\\\", \\\"{x:1488,y:777,t:1528143460091};\\\", \\\"{x:1489,y:786,t:1528143460108};\\\", \\\"{x:1489,y:802,t:1528143460125};\\\", \\\"{x:1488,y:813,t:1528143460141};\\\", \\\"{x:1488,y:817,t:1528143460159};\\\", \\\"{x:1487,y:820,t:1528143460175};\\\", \\\"{x:1487,y:822,t:1528143460192};\\\", \\\"{x:1487,y:823,t:1528143460208};\\\", \\\"{x:1487,y:825,t:1528143460226};\\\", \\\"{x:1487,y:827,t:1528143460242};\\\", \\\"{x:1485,y:832,t:1528143460262};\\\", \\\"{x:1483,y:838,t:1528143460277};\\\", \\\"{x:1481,y:846,t:1528143460292};\\\", \\\"{x:1476,y:858,t:1528143460309};\\\", \\\"{x:1475,y:863,t:1528143460325};\\\", \\\"{x:1474,y:868,t:1528143460343};\\\", \\\"{x:1473,y:870,t:1528143460359};\\\", \\\"{x:1473,y:871,t:1528143460376};\\\", \\\"{x:1472,y:872,t:1528143460393};\\\", \\\"{x:1472,y:873,t:1528143460429};\\\", \\\"{x:1471,y:874,t:1528143460443};\\\", \\\"{x:1469,y:877,t:1528143460458};\\\", \\\"{x:1464,y:882,t:1528143460476};\\\", \\\"{x:1454,y:889,t:1528143460493};\\\", \\\"{x:1442,y:896,t:1528143460508};\\\", \\\"{x:1434,y:900,t:1528143460526};\\\", \\\"{x:1423,y:904,t:1528143460542};\\\", \\\"{x:1411,y:908,t:1528143460558};\\\", \\\"{x:1404,y:910,t:1528143460575};\\\", \\\"{x:1399,y:912,t:1528143460593};\\\", \\\"{x:1397,y:913,t:1528143460609};\\\", \\\"{x:1395,y:914,t:1528143460626};\\\", \\\"{x:1393,y:915,t:1528143460643};\\\", \\\"{x:1393,y:916,t:1528143460658};\\\", \\\"{x:1391,y:917,t:1528143460674};\\\", \\\"{x:1384,y:920,t:1528143460692};\\\", \\\"{x:1374,y:928,t:1528143460708};\\\", \\\"{x:1362,y:934,t:1528143460725};\\\", \\\"{x:1345,y:941,t:1528143460742};\\\", \\\"{x:1326,y:946,t:1528143460759};\\\", \\\"{x:1315,y:950,t:1528143460775};\\\", \\\"{x:1308,y:951,t:1528143460792};\\\", \\\"{x:1305,y:953,t:1528143460809};\\\", \\\"{x:1304,y:954,t:1528143461101};\\\", \\\"{x:1306,y:954,t:1528143461124};\\\", \\\"{x:1307,y:955,t:1528143461143};\\\", \\\"{x:1310,y:956,t:1528143461160};\\\", \\\"{x:1313,y:957,t:1528143461176};\\\", \\\"{x:1314,y:957,t:1528143461192};\\\", \\\"{x:1316,y:957,t:1528143461210};\\\", \\\"{x:1319,y:960,t:1528143461226};\\\", \\\"{x:1322,y:960,t:1528143461242};\\\", \\\"{x:1324,y:961,t:1528143461259};\\\", \\\"{x:1327,y:962,t:1528143461276};\\\", \\\"{x:1328,y:963,t:1528143461292};\\\", \\\"{x:1331,y:964,t:1528143461309};\\\", \\\"{x:1333,y:964,t:1528143461326};\\\", \\\"{x:1336,y:965,t:1528143461342};\\\", \\\"{x:1337,y:965,t:1528143461359};\\\", \\\"{x:1339,y:965,t:1528143461381};\\\", \\\"{x:1340,y:965,t:1528143461392};\\\", \\\"{x:1341,y:965,t:1528143461410};\\\", \\\"{x:1343,y:965,t:1528143461426};\\\", \\\"{x:1345,y:965,t:1528143461442};\\\", \\\"{x:1346,y:963,t:1528143461459};\\\", \\\"{x:1347,y:963,t:1528143461476};\\\", \\\"{x:1348,y:963,t:1528143461517};\\\", \\\"{x:1349,y:963,t:1528143461710};\\\", \\\"{x:1349,y:962,t:1528143461958};\\\", \\\"{x:1350,y:962,t:1528143461965};\\\", \\\"{x:1351,y:961,t:1528143461977};\\\", \\\"{x:1352,y:961,t:1528143462005};\\\", \\\"{x:1346,y:963,t:1528143462246};\\\", \\\"{x:1339,y:965,t:1528143462262};\\\", \\\"{x:1327,y:969,t:1528143462278};\\\", \\\"{x:1315,y:972,t:1528143462294};\\\", \\\"{x:1309,y:975,t:1528143462311};\\\", \\\"{x:1305,y:975,t:1528143462327};\\\", \\\"{x:1304,y:975,t:1528143462349};\\\", \\\"{x:1303,y:975,t:1528143462373};\\\", \\\"{x:1301,y:975,t:1528143462381};\\\", \\\"{x:1299,y:975,t:1528143462396};\\\", \\\"{x:1297,y:975,t:1528143462410};\\\", \\\"{x:1294,y:974,t:1528143462427};\\\", \\\"{x:1289,y:973,t:1528143462444};\\\", \\\"{x:1283,y:970,t:1528143462460};\\\", \\\"{x:1278,y:969,t:1528143462477};\\\", \\\"{x:1277,y:968,t:1528143462502};\\\", \\\"{x:1277,y:966,t:1528143465630};\\\", \\\"{x:1277,y:963,t:1528143465647};\\\", \\\"{x:1277,y:960,t:1528143465663};\\\", \\\"{x:1277,y:958,t:1528143465679};\\\", \\\"{x:1277,y:957,t:1528143465696};\\\", \\\"{x:1277,y:955,t:1528143465869};\\\", \\\"{x:1277,y:953,t:1528143465879};\\\", \\\"{x:1277,y:950,t:1528143465895};\\\", \\\"{x:1279,y:945,t:1528143465912};\\\", \\\"{x:1280,y:942,t:1528143465929};\\\", \\\"{x:1280,y:940,t:1528143465945};\\\", \\\"{x:1281,y:939,t:1528143465972};\\\", \\\"{x:1281,y:938,t:1528143466045};\\\", \\\"{x:1281,y:937,t:1528143466052};\\\", \\\"{x:1282,y:936,t:1528143466069};\\\", \\\"{x:1282,y:935,t:1528143466085};\\\", \\\"{x:1283,y:933,t:1528143466096};\\\", \\\"{x:1283,y:932,t:1528143466113};\\\", \\\"{x:1284,y:929,t:1528143466130};\\\", \\\"{x:1284,y:927,t:1528143466147};\\\", \\\"{x:1285,y:924,t:1528143466163};\\\", \\\"{x:1285,y:923,t:1528143466189};\\\", \\\"{x:1286,y:923,t:1528143466342};\\\", \\\"{x:1286,y:922,t:1528143466349};\\\", \\\"{x:1286,y:921,t:1528143466363};\\\", \\\"{x:1286,y:919,t:1528143466380};\\\", \\\"{x:1288,y:914,t:1528143466397};\\\", \\\"{x:1288,y:912,t:1528143466437};\\\", \\\"{x:1289,y:912,t:1528143466461};\\\", \\\"{x:1289,y:911,t:1528143466637};\\\", \\\"{x:1289,y:909,t:1528143466669};\\\", \\\"{x:1289,y:908,t:1528143468125};\\\", \\\"{x:1289,y:906,t:1528143468133};\\\", \\\"{x:1289,y:905,t:1528143468149};\\\", \\\"{x:1290,y:904,t:1528143468165};\\\", \\\"{x:1292,y:902,t:1528143468341};\\\", \\\"{x:1292,y:901,t:1528143468349};\\\", \\\"{x:1293,y:898,t:1528143468365};\\\", \\\"{x:1295,y:894,t:1528143468382};\\\", \\\"{x:1296,y:893,t:1528143468405};\\\", \\\"{x:1296,y:892,t:1528143468622};\\\", \\\"{x:1297,y:891,t:1528143468632};\\\", \\\"{x:1297,y:890,t:1528143468648};\\\", \\\"{x:1299,y:889,t:1528143468665};\\\", \\\"{x:1299,y:888,t:1528143468685};\\\", \\\"{x:1300,y:887,t:1528143468701};\\\", \\\"{x:1301,y:885,t:1528143468717};\\\", \\\"{x:1302,y:885,t:1528143468732};\\\", \\\"{x:1303,y:883,t:1528143468748};\\\", \\\"{x:1306,y:878,t:1528143468765};\\\", \\\"{x:1309,y:875,t:1528143468782};\\\", \\\"{x:1312,y:870,t:1528143468798};\\\", \\\"{x:1314,y:867,t:1528143468815};\\\", \\\"{x:1318,y:859,t:1528143468833};\\\", \\\"{x:1323,y:852,t:1528143468848};\\\", \\\"{x:1326,y:847,t:1528143468865};\\\", \\\"{x:1330,y:839,t:1528143468883};\\\", \\\"{x:1336,y:829,t:1528143468899};\\\", \\\"{x:1341,y:822,t:1528143468915};\\\", \\\"{x:1343,y:820,t:1528143468933};\\\", \\\"{x:1345,y:816,t:1528143468949};\\\", \\\"{x:1346,y:815,t:1528143468965};\\\", \\\"{x:1347,y:815,t:1528143468989};\\\", \\\"{x:1347,y:814,t:1528143468999};\\\", \\\"{x:1349,y:811,t:1528143469015};\\\", \\\"{x:1350,y:809,t:1528143469032};\\\", \\\"{x:1351,y:807,t:1528143469049};\\\", \\\"{x:1353,y:804,t:1528143469065};\\\", \\\"{x:1355,y:800,t:1528143469083};\\\", \\\"{x:1357,y:796,t:1528143469099};\\\", \\\"{x:1359,y:791,t:1528143469115};\\\", \\\"{x:1361,y:786,t:1528143469132};\\\", \\\"{x:1362,y:783,t:1528143469149};\\\", \\\"{x:1362,y:782,t:1528143469165};\\\", \\\"{x:1362,y:781,t:1528143469317};\\\", \\\"{x:1364,y:778,t:1528143469333};\\\", \\\"{x:1364,y:776,t:1528143469349};\\\", \\\"{x:1366,y:774,t:1528143469365};\\\", \\\"{x:1366,y:772,t:1528143469382};\\\", \\\"{x:1367,y:771,t:1528143469399};\\\", \\\"{x:1368,y:771,t:1528143469662};\\\", \\\"{x:1368,y:770,t:1528143469669};\\\", \\\"{x:1368,y:769,t:1528143469766};\\\", \\\"{x:1369,y:769,t:1528143469854};\\\", \\\"{x:1369,y:768,t:1528143469877};\\\", \\\"{x:1370,y:768,t:1528143469902};\\\", \\\"{x:1370,y:767,t:1528143470102};\\\", \\\"{x:1371,y:765,t:1528143470125};\\\", \\\"{x:1372,y:765,t:1528143470133};\\\", \\\"{x:1373,y:764,t:1528143470357};\\\", \\\"{x:1374,y:763,t:1528143470373};\\\", \\\"{x:1375,y:762,t:1528143470384};\\\", \\\"{x:1376,y:762,t:1528143472302};\\\", \\\"{x:1380,y:760,t:1528143472318};\\\", \\\"{x:1381,y:760,t:1528143472334};\\\", \\\"{x:1382,y:759,t:1528143472351};\\\", \\\"{x:1383,y:758,t:1528143472381};\\\", \\\"{x:1383,y:757,t:1528143475094};\\\", \\\"{x:1375,y:755,t:1528143475104};\\\", \\\"{x:1353,y:752,t:1528143475119};\\\", \\\"{x:1324,y:746,t:1528143475137};\\\", \\\"{x:1278,y:739,t:1528143475153};\\\", \\\"{x:1230,y:732,t:1528143475171};\\\", \\\"{x:1190,y:725,t:1528143475186};\\\", \\\"{x:1167,y:719,t:1528143475204};\\\", \\\"{x:1151,y:716,t:1528143475221};\\\", \\\"{x:1143,y:711,t:1528143475237};\\\", \\\"{x:1141,y:710,t:1528143475254};\\\", \\\"{x:1141,y:709,t:1528143475270};\\\", \\\"{x:1138,y:706,t:1528143475286};\\\", \\\"{x:1133,y:700,t:1528143475303};\\\", \\\"{x:1116,y:690,t:1528143475319};\\\", \\\"{x:1081,y:676,t:1528143475336};\\\", \\\"{x:1029,y:655,t:1528143475352};\\\", \\\"{x:985,y:644,t:1528143475370};\\\", \\\"{x:930,y:632,t:1528143475386};\\\", \\\"{x:885,y:626,t:1528143475403};\\\", \\\"{x:847,y:622,t:1528143475420};\\\", \\\"{x:806,y:616,t:1528143475436};\\\", \\\"{x:790,y:613,t:1528143475452};\\\", \\\"{x:781,y:612,t:1528143475470};\\\", \\\"{x:778,y:611,t:1528143475485};\\\", \\\"{x:776,y:611,t:1528143475540};\\\", \\\"{x:774,y:611,t:1528143475553};\\\", \\\"{x:767,y:611,t:1528143475569};\\\", \\\"{x:746,y:606,t:1528143475587};\\\", \\\"{x:710,y:599,t:1528143475604};\\\", \\\"{x:665,y:592,t:1528143475620};\\\", \\\"{x:596,y:582,t:1528143475637};\\\", \\\"{x:566,y:578,t:1528143475655};\\\", \\\"{x:541,y:575,t:1528143475672};\\\", \\\"{x:516,y:570,t:1528143475688};\\\", \\\"{x:501,y:568,t:1528143475704};\\\", \\\"{x:492,y:567,t:1528143475721};\\\", \\\"{x:486,y:566,t:1528143475738};\\\", \\\"{x:472,y:565,t:1528143475755};\\\", \\\"{x:462,y:563,t:1528143475770};\\\", \\\"{x:455,y:561,t:1528143475788};\\\", \\\"{x:447,y:559,t:1528143475804};\\\", \\\"{x:446,y:558,t:1528143475821};\\\", \\\"{x:445,y:558,t:1528143475837};\\\", \\\"{x:444,y:558,t:1528143475860};\\\", \\\"{x:442,y:558,t:1528143475870};\\\", \\\"{x:438,y:558,t:1528143475888};\\\", \\\"{x:431,y:558,t:1528143475904};\\\", \\\"{x:424,y:559,t:1528143475921};\\\", \\\"{x:419,y:561,t:1528143475938};\\\", \\\"{x:415,y:562,t:1528143475954};\\\", \\\"{x:412,y:562,t:1528143475970};\\\", \\\"{x:406,y:563,t:1528143475988};\\\", \\\"{x:400,y:565,t:1528143476005};\\\", \\\"{x:398,y:565,t:1528143476021};\\\", \\\"{x:396,y:564,t:1528143476038};\\\", \\\"{x:393,y:564,t:1528143476054};\\\", \\\"{x:391,y:562,t:1528143476083};\\\", \\\"{x:390,y:562,t:1528143476116};\\\", \\\"{x:390,y:564,t:1528143476517};\\\", \\\"{x:392,y:567,t:1528143476524};\\\", \\\"{x:393,y:571,t:1528143476539};\\\", \\\"{x:401,y:581,t:1528143476556};\\\", \\\"{x:417,y:600,t:1528143476572};\\\", \\\"{x:429,y:610,t:1528143476589};\\\", \\\"{x:442,y:620,t:1528143476606};\\\", \\\"{x:447,y:626,t:1528143476621};\\\", \\\"{x:455,y:635,t:1528143476638};\\\", \\\"{x:461,y:643,t:1528143476654};\\\", \\\"{x:465,y:651,t:1528143476672};\\\", \\\"{x:470,y:659,t:1528143476689};\\\", \\\"{x:475,y:668,t:1528143476705};\\\", \\\"{x:479,y:676,t:1528143476721};\\\", \\\"{x:483,y:681,t:1528143476739};\\\", \\\"{x:486,y:687,t:1528143476755};\\\", \\\"{x:488,y:689,t:1528143476772};\\\", \\\"{x:491,y:694,t:1528143476788};\\\", \\\"{x:494,y:697,t:1528143476806};\\\", \\\"{x:496,y:698,t:1528143476837};\\\", \\\"{x:496,y:699,t:1528143476852};\\\", \\\"{x:497,y:701,t:1528143476870};\\\", \\\"{x:498,y:705,t:1528143476888};\\\", \\\"{x:499,y:710,t:1528143476905};\\\", \\\"{x:500,y:714,t:1528143476922};\\\", \\\"{x:500,y:716,t:1528143476938};\\\" ] }, { \\\"rt\\\": 20900, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 340224, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:717,t:1528143480653};\\\", \\\"{x:499,y:717,t:1528143480716};\\\", \\\"{x:498,y:717,t:1528143480724};\\\", \\\"{x:497,y:717,t:1528143480738};\\\", \\\"{x:492,y:717,t:1528143480755};\\\", \\\"{x:484,y:716,t:1528143480770};\\\", \\\"{x:464,y:714,t:1528143480788};\\\", \\\"{x:449,y:713,t:1528143480805};\\\", \\\"{x:432,y:709,t:1528143480822};\\\", \\\"{x:411,y:707,t:1528143480838};\\\", \\\"{x:398,y:704,t:1528143480854};\\\", \\\"{x:369,y:700,t:1528143480876};\\\", \\\"{x:351,y:697,t:1528143480892};\\\", \\\"{x:330,y:694,t:1528143480908};\\\", \\\"{x:304,y:689,t:1528143480926};\\\", \\\"{x:276,y:683,t:1528143480942};\\\", \\\"{x:244,y:676,t:1528143480959};\\\", \\\"{x:200,y:670,t:1528143480976};\\\", \\\"{x:143,y:660,t:1528143480992};\\\", \\\"{x:80,y:645,t:1528143481009};\\\", \\\"{x:9,y:627,t:1528143481026};\\\", \\\"{x:0,y:615,t:1528143481041};\\\", \\\"{x:0,y:602,t:1528143481059};\\\", \\\"{x:0,y:590,t:1528143481075};\\\", \\\"{x:0,y:584,t:1528143481092};\\\", \\\"{x:0,y:574,t:1528143481109};\\\", \\\"{x:0,y:567,t:1528143481125};\\\", \\\"{x:0,y:561,t:1528143481142};\\\", \\\"{x:0,y:555,t:1528143481159};\\\", \\\"{x:0,y:553,t:1528143481176};\\\", \\\"{x:0,y:552,t:1528143481204};\\\", \\\"{x:0,y:551,t:1528143481220};\\\", \\\"{x:0,y:550,t:1528143481236};\\\", \\\"{x:0,y:549,t:1528143481245};\\\", \\\"{x:0,y:548,t:1528143481258};\\\", \\\"{x:0,y:544,t:1528143481276};\\\", \\\"{x:2,y:542,t:1528143481292};\\\", \\\"{x:7,y:540,t:1528143481309};\\\", \\\"{x:13,y:536,t:1528143481326};\\\", \\\"{x:24,y:532,t:1528143481342};\\\", \\\"{x:35,y:527,t:1528143481359};\\\", \\\"{x:50,y:523,t:1528143481377};\\\", \\\"{x:67,y:519,t:1528143481393};\\\", \\\"{x:85,y:513,t:1528143481409};\\\", \\\"{x:108,y:508,t:1528143481426};\\\", \\\"{x:130,y:504,t:1528143481444};\\\", \\\"{x:149,y:502,t:1528143481458};\\\", \\\"{x:173,y:499,t:1528143481476};\\\", \\\"{x:187,y:498,t:1528143481493};\\\", \\\"{x:195,y:498,t:1528143481509};\\\", \\\"{x:201,y:498,t:1528143481526};\\\", \\\"{x:206,y:498,t:1528143481542};\\\", \\\"{x:210,y:498,t:1528143481559};\\\", \\\"{x:213,y:498,t:1528143481576};\\\", \\\"{x:214,y:498,t:1528143481593};\\\", \\\"{x:215,y:498,t:1528143481609};\\\", \\\"{x:217,y:498,t:1528143481626};\\\", \\\"{x:223,y:498,t:1528143481643};\\\", \\\"{x:230,y:498,t:1528143481660};\\\", \\\"{x:245,y:498,t:1528143481676};\\\", \\\"{x:264,y:498,t:1528143481693};\\\", \\\"{x:280,y:498,t:1528143481709};\\\", \\\"{x:295,y:498,t:1528143481726};\\\", \\\"{x:309,y:498,t:1528143481743};\\\", \\\"{x:324,y:498,t:1528143481759};\\\", \\\"{x:339,y:498,t:1528143481775};\\\", \\\"{x:359,y:498,t:1528143481793};\\\", \\\"{x:379,y:498,t:1528143481809};\\\", \\\"{x:395,y:498,t:1528143481825};\\\", \\\"{x:414,y:498,t:1528143481842};\\\", \\\"{x:440,y:498,t:1528143481860};\\\", \\\"{x:453,y:498,t:1528143481876};\\\", \\\"{x:465,y:498,t:1528143481893};\\\", \\\"{x:475,y:498,t:1528143481911};\\\", \\\"{x:482,y:498,t:1528143481926};\\\", \\\"{x:489,y:498,t:1528143481943};\\\", \\\"{x:493,y:497,t:1528143481961};\\\", \\\"{x:496,y:496,t:1528143481976};\\\", \\\"{x:498,y:496,t:1528143481994};\\\", \\\"{x:500,y:496,t:1528143482010};\\\", \\\"{x:501,y:496,t:1528143482026};\\\", \\\"{x:503,y:496,t:1528143482043};\\\", \\\"{x:509,y:496,t:1528143482060};\\\", \\\"{x:513,y:496,t:1528143482077};\\\", \\\"{x:520,y:496,t:1528143482093};\\\", \\\"{x:531,y:496,t:1528143482110};\\\", \\\"{x:543,y:496,t:1528143482126};\\\", \\\"{x:555,y:496,t:1528143482143};\\\", \\\"{x:572,y:497,t:1528143482160};\\\", \\\"{x:584,y:498,t:1528143482177};\\\", \\\"{x:592,y:499,t:1528143482193};\\\", \\\"{x:595,y:499,t:1528143482210};\\\", \\\"{x:596,y:500,t:1528143482227};\\\", \\\"{x:596,y:501,t:1528143482285};\\\", \\\"{x:596,y:503,t:1528143482293};\\\", \\\"{x:594,y:510,t:1528143482312};\\\", \\\"{x:588,y:517,t:1528143482327};\\\", \\\"{x:578,y:520,t:1528143482343};\\\", \\\"{x:576,y:520,t:1528143482360};\\\", \\\"{x:578,y:520,t:1528143482860};\\\", \\\"{x:592,y:521,t:1528143482877};\\\", \\\"{x:614,y:523,t:1528143482895};\\\", \\\"{x:647,y:528,t:1528143482911};\\\", \\\"{x:680,y:533,t:1528143482927};\\\", \\\"{x:716,y:540,t:1528143482945};\\\", \\\"{x:767,y:548,t:1528143482961};\\\", \\\"{x:831,y:558,t:1528143482977};\\\", \\\"{x:912,y:569,t:1528143482994};\\\", \\\"{x:999,y:584,t:1528143483011};\\\", \\\"{x:1083,y:601,t:1528143483027};\\\", \\\"{x:1198,y:615,t:1528143483043};\\\", \\\"{x:1274,y:628,t:1528143483060};\\\", \\\"{x:1338,y:636,t:1528143483077};\\\", \\\"{x:1394,y:644,t:1528143483094};\\\", \\\"{x:1426,y:646,t:1528143483110};\\\", \\\"{x:1448,y:646,t:1528143483127};\\\", \\\"{x:1460,y:646,t:1528143483144};\\\", \\\"{x:1464,y:646,t:1528143483161};\\\", \\\"{x:1464,y:645,t:1528143483269};\\\", \\\"{x:1459,y:645,t:1528143483278};\\\", \\\"{x:1446,y:638,t:1528143483294};\\\", \\\"{x:1437,y:634,t:1528143483311};\\\", \\\"{x:1433,y:633,t:1528143483327};\\\", \\\"{x:1432,y:632,t:1528143483344};\\\", \\\"{x:1430,y:632,t:1528143483362};\\\", \\\"{x:1431,y:632,t:1528143483509};\\\", \\\"{x:1434,y:633,t:1528143483516};\\\", \\\"{x:1436,y:633,t:1528143483532};\\\", \\\"{x:1439,y:633,t:1528143483544};\\\", \\\"{x:1447,y:633,t:1528143483561};\\\", \\\"{x:1455,y:634,t:1528143483577};\\\", \\\"{x:1462,y:634,t:1528143483594};\\\", \\\"{x:1470,y:635,t:1528143483611};\\\", \\\"{x:1479,y:636,t:1528143483627};\\\", \\\"{x:1502,y:637,t:1528143483644};\\\", \\\"{x:1517,y:638,t:1528143483661};\\\", \\\"{x:1530,y:640,t:1528143483677};\\\", \\\"{x:1545,y:640,t:1528143483694};\\\", \\\"{x:1553,y:640,t:1528143483711};\\\", \\\"{x:1560,y:640,t:1528143483727};\\\", \\\"{x:1563,y:641,t:1528143483744};\\\", \\\"{x:1564,y:641,t:1528143483761};\\\", \\\"{x:1565,y:641,t:1528143483777};\\\", \\\"{x:1566,y:641,t:1528143483861};\\\", \\\"{x:1567,y:641,t:1528143483878};\\\", \\\"{x:1570,y:637,t:1528143483894};\\\", \\\"{x:1570,y:633,t:1528143483911};\\\", \\\"{x:1570,y:626,t:1528143483927};\\\", \\\"{x:1569,y:618,t:1528143483944};\\\", \\\"{x:1566,y:610,t:1528143483961};\\\", \\\"{x:1561,y:602,t:1528143483977};\\\", \\\"{x:1555,y:596,t:1528143483995};\\\", \\\"{x:1553,y:594,t:1528143484011};\\\", \\\"{x:1552,y:594,t:1528143484027};\\\", \\\"{x:1551,y:593,t:1528143484045};\\\", \\\"{x:1550,y:593,t:1528143484061};\\\", \\\"{x:1549,y:593,t:1528143484077};\\\", \\\"{x:1549,y:592,t:1528143484117};\\\", \\\"{x:1548,y:590,t:1528143484133};\\\", \\\"{x:1545,y:590,t:1528143484145};\\\", \\\"{x:1535,y:585,t:1528143484161};\\\", \\\"{x:1526,y:579,t:1528143484178};\\\", \\\"{x:1518,y:576,t:1528143484195};\\\", \\\"{x:1508,y:571,t:1528143484211};\\\", \\\"{x:1502,y:569,t:1528143484227};\\\", \\\"{x:1497,y:569,t:1528143484245};\\\", \\\"{x:1496,y:569,t:1528143486517};\\\", \\\"{x:1495,y:569,t:1528143486529};\\\", \\\"{x:1494,y:571,t:1528143486546};\\\", \\\"{x:1494,y:572,t:1528143486562};\\\", \\\"{x:1494,y:574,t:1528143486797};\\\", \\\"{x:1494,y:575,t:1528143486853};\\\", \\\"{x:1493,y:575,t:1528143487093};\\\", \\\"{x:1492,y:575,t:1528143487269};\\\", \\\"{x:1491,y:575,t:1528143487279};\\\", \\\"{x:1490,y:576,t:1528143487301};\\\", \\\"{x:1489,y:577,t:1528143487421};\\\", \\\"{x:1488,y:577,t:1528143487445};\\\", \\\"{x:1489,y:577,t:1528143487885};\\\", \\\"{x:1493,y:573,t:1528143487896};\\\", \\\"{x:1507,y:562,t:1528143487913};\\\", \\\"{x:1520,y:550,t:1528143487928};\\\", \\\"{x:1532,y:542,t:1528143487946};\\\", \\\"{x:1544,y:536,t:1528143487962};\\\", \\\"{x:1554,y:530,t:1528143487979};\\\", \\\"{x:1561,y:526,t:1528143487995};\\\", \\\"{x:1565,y:523,t:1528143488013};\\\", \\\"{x:1567,y:521,t:1528143488028};\\\", \\\"{x:1569,y:519,t:1528143488047};\\\", \\\"{x:1573,y:516,t:1528143488063};\\\", \\\"{x:1578,y:511,t:1528143488079};\\\", \\\"{x:1583,y:505,t:1528143488096};\\\", \\\"{x:1587,y:498,t:1528143488112};\\\", \\\"{x:1594,y:488,t:1528143488129};\\\", \\\"{x:1596,y:482,t:1528143488146};\\\", \\\"{x:1599,y:474,t:1528143488163};\\\", \\\"{x:1605,y:465,t:1528143488179};\\\", \\\"{x:1608,y:460,t:1528143488196};\\\", \\\"{x:1609,y:455,t:1528143488213};\\\", \\\"{x:1610,y:455,t:1528143488229};\\\", \\\"{x:1610,y:454,t:1528143488247};\\\", \\\"{x:1610,y:453,t:1528143488268};\\\", \\\"{x:1611,y:453,t:1528143488278};\\\", \\\"{x:1611,y:451,t:1528143488300};\\\", \\\"{x:1611,y:450,t:1528143488429};\\\", \\\"{x:1611,y:448,t:1528143488452};\\\", \\\"{x:1611,y:447,t:1528143488492};\\\", \\\"{x:1611,y:446,t:1528143488532};\\\", \\\"{x:1611,y:445,t:1528143488545};\\\", \\\"{x:1611,y:444,t:1528143488562};\\\", \\\"{x:1611,y:442,t:1528143488578};\\\", \\\"{x:1611,y:439,t:1528143488595};\\\", \\\"{x:1611,y:433,t:1528143488612};\\\", \\\"{x:1612,y:431,t:1528143488628};\\\", \\\"{x:1612,y:427,t:1528143488645};\\\", \\\"{x:1612,y:425,t:1528143488667};\\\", \\\"{x:1612,y:428,t:1528143493317};\\\", \\\"{x:1595,y:438,t:1528143493331};\\\", \\\"{x:1564,y:453,t:1528143493347};\\\", \\\"{x:1524,y:472,t:1528143493363};\\\", \\\"{x:1479,y:487,t:1528143493380};\\\", \\\"{x:1429,y:498,t:1528143493396};\\\", \\\"{x:1410,y:500,t:1528143493414};\\\", \\\"{x:1398,y:502,t:1528143493430};\\\", \\\"{x:1393,y:504,t:1528143493448};\\\", \\\"{x:1392,y:504,t:1528143493464};\\\", \\\"{x:1391,y:504,t:1528143493480};\\\", \\\"{x:1389,y:504,t:1528143493508};\\\", \\\"{x:1387,y:505,t:1528143493515};\\\", \\\"{x:1386,y:506,t:1528143493530};\\\", \\\"{x:1379,y:507,t:1528143493546};\\\", \\\"{x:1366,y:508,t:1528143493564};\\\", \\\"{x:1344,y:511,t:1528143493579};\\\", \\\"{x:1290,y:514,t:1528143493597};\\\", \\\"{x:1221,y:523,t:1528143493613};\\\", \\\"{x:1149,y:531,t:1528143493629};\\\", \\\"{x:1098,y:535,t:1528143493647};\\\", \\\"{x:1047,y:535,t:1528143493663};\\\", \\\"{x:1020,y:535,t:1528143493679};\\\", \\\"{x:996,y:535,t:1528143493697};\\\", \\\"{x:979,y:535,t:1528143493713};\\\", \\\"{x:963,y:535,t:1528143493729};\\\", \\\"{x:956,y:535,t:1528143493747};\\\", \\\"{x:951,y:535,t:1528143493763};\\\", \\\"{x:948,y:534,t:1528143493780};\\\", \\\"{x:940,y:534,t:1528143493796};\\\", \\\"{x:929,y:534,t:1528143493813};\\\", \\\"{x:903,y:534,t:1528143493835};\\\", \\\"{x:881,y:534,t:1528143493852};\\\", \\\"{x:853,y:537,t:1528143493870};\\\", \\\"{x:810,y:538,t:1528143493886};\\\", \\\"{x:751,y:540,t:1528143493902};\\\", \\\"{x:698,y:540,t:1528143493919};\\\", \\\"{x:660,y:543,t:1528143493936};\\\", \\\"{x:631,y:543,t:1528143493952};\\\", \\\"{x:605,y:543,t:1528143493969};\\\", \\\"{x:588,y:543,t:1528143493986};\\\", \\\"{x:578,y:543,t:1528143494003};\\\", \\\"{x:573,y:543,t:1528143494019};\\\", \\\"{x:566,y:543,t:1528143494036};\\\", \\\"{x:564,y:544,t:1528143494054};\\\", \\\"{x:561,y:544,t:1528143494069};\\\", \\\"{x:553,y:547,t:1528143494086};\\\", \\\"{x:542,y:552,t:1528143494104};\\\", \\\"{x:529,y:556,t:1528143494120};\\\", \\\"{x:511,y:561,t:1528143494137};\\\", \\\"{x:490,y:568,t:1528143494155};\\\", \\\"{x:478,y:571,t:1528143494169};\\\", \\\"{x:466,y:574,t:1528143494186};\\\", \\\"{x:452,y:578,t:1528143494204};\\\", \\\"{x:428,y:580,t:1528143494219};\\\", \\\"{x:409,y:583,t:1528143494237};\\\", \\\"{x:387,y:583,t:1528143494253};\\\", \\\"{x:363,y:583,t:1528143494269};\\\", \\\"{x:342,y:583,t:1528143494286};\\\", \\\"{x:320,y:581,t:1528143494303};\\\", \\\"{x:297,y:578,t:1528143494319};\\\", \\\"{x:275,y:572,t:1528143494337};\\\", \\\"{x:259,y:571,t:1528143494354};\\\", \\\"{x:243,y:571,t:1528143494369};\\\", \\\"{x:229,y:571,t:1528143494386};\\\", \\\"{x:218,y:571,t:1528143494403};\\\", \\\"{x:212,y:571,t:1528143494419};\\\", \\\"{x:200,y:571,t:1528143494436};\\\", \\\"{x:197,y:571,t:1528143494453};\\\", \\\"{x:193,y:571,t:1528143494470};\\\", \\\"{x:192,y:571,t:1528143494492};\\\", \\\"{x:191,y:571,t:1528143494503};\\\", \\\"{x:190,y:571,t:1528143494519};\\\", \\\"{x:189,y:570,t:1528143494537};\\\", \\\"{x:188,y:570,t:1528143494553};\\\", \\\"{x:187,y:570,t:1528143494570};\\\", \\\"{x:182,y:572,t:1528143494586};\\\", \\\"{x:171,y:574,t:1528143494604};\\\", \\\"{x:158,y:578,t:1528143494622};\\\", \\\"{x:153,y:578,t:1528143494637};\\\", \\\"{x:150,y:578,t:1528143494654};\\\", \\\"{x:149,y:578,t:1528143494684};\\\", \\\"{x:149,y:579,t:1528143494748};\\\", \\\"{x:154,y:578,t:1528143494828};\\\", \\\"{x:159,y:575,t:1528143494836};\\\", \\\"{x:171,y:570,t:1528143494855};\\\", \\\"{x:180,y:566,t:1528143494870};\\\", \\\"{x:194,y:564,t:1528143494887};\\\", \\\"{x:211,y:560,t:1528143494904};\\\", \\\"{x:229,y:558,t:1528143494920};\\\", \\\"{x:253,y:556,t:1528143494936};\\\", \\\"{x:271,y:555,t:1528143494953};\\\", \\\"{x:284,y:554,t:1528143494971};\\\", \\\"{x:297,y:553,t:1528143494986};\\\", \\\"{x:317,y:551,t:1528143495004};\\\", \\\"{x:329,y:550,t:1528143495020};\\\", \\\"{x:338,y:549,t:1528143495037};\\\", \\\"{x:355,y:546,t:1528143495053};\\\", \\\"{x:373,y:546,t:1528143495070};\\\", \\\"{x:393,y:546,t:1528143495086};\\\", \\\"{x:415,y:546,t:1528143495103};\\\", \\\"{x:435,y:546,t:1528143495120};\\\", \\\"{x:456,y:546,t:1528143495137};\\\", \\\"{x:476,y:546,t:1528143495154};\\\", \\\"{x:498,y:546,t:1528143495170};\\\", \\\"{x:514,y:546,t:1528143495187};\\\", \\\"{x:536,y:546,t:1528143495203};\\\", \\\"{x:567,y:546,t:1528143495220};\\\", \\\"{x:582,y:546,t:1528143495237};\\\", \\\"{x:596,y:546,t:1528143495254};\\\", \\\"{x:607,y:546,t:1528143495271};\\\", \\\"{x:618,y:546,t:1528143495287};\\\", \\\"{x:625,y:544,t:1528143495303};\\\", \\\"{x:632,y:544,t:1528143495321};\\\", \\\"{x:636,y:544,t:1528143495337};\\\", \\\"{x:643,y:543,t:1528143495354};\\\", \\\"{x:648,y:543,t:1528143495370};\\\", \\\"{x:655,y:543,t:1528143495387};\\\", \\\"{x:664,y:543,t:1528143495404};\\\", \\\"{x:683,y:541,t:1528143495420};\\\", \\\"{x:697,y:539,t:1528143495438};\\\", \\\"{x:713,y:535,t:1528143495455};\\\", \\\"{x:730,y:534,t:1528143495472};\\\", \\\"{x:750,y:531,t:1528143495487};\\\", \\\"{x:764,y:529,t:1528143495504};\\\", \\\"{x:776,y:529,t:1528143495520};\\\", \\\"{x:786,y:529,t:1528143495537};\\\", \\\"{x:792,y:529,t:1528143495554};\\\", \\\"{x:797,y:529,t:1528143495570};\\\", \\\"{x:800,y:529,t:1528143495587};\\\", \\\"{x:804,y:529,t:1528143495603};\\\", \\\"{x:807,y:529,t:1528143495620};\\\", \\\"{x:809,y:529,t:1528143495637};\\\", \\\"{x:811,y:529,t:1528143495654};\\\", \\\"{x:816,y:529,t:1528143495671};\\\", \\\"{x:819,y:529,t:1528143495687};\\\", \\\"{x:822,y:529,t:1528143495705};\\\", \\\"{x:827,y:529,t:1528143495722};\\\", \\\"{x:831,y:529,t:1528143495737};\\\", \\\"{x:836,y:529,t:1528143495753};\\\", \\\"{x:842,y:529,t:1528143495770};\\\", \\\"{x:846,y:529,t:1528143495787};\\\", \\\"{x:852,y:529,t:1528143495803};\\\", \\\"{x:857,y:530,t:1528143495821};\\\", \\\"{x:858,y:532,t:1528143495837};\\\", \\\"{x:858,y:538,t:1528143495855};\\\", \\\"{x:858,y:551,t:1528143495872};\\\", \\\"{x:858,y:566,t:1528143495887};\\\", \\\"{x:858,y:578,t:1528143495905};\\\", \\\"{x:858,y:585,t:1528143495922};\\\", \\\"{x:858,y:589,t:1528143495938};\\\", \\\"{x:858,y:593,t:1528143495954};\\\", \\\"{x:857,y:596,t:1528143495971};\\\", \\\"{x:856,y:596,t:1528143496004};\\\", \\\"{x:856,y:597,t:1528143496036};\\\", \\\"{x:855,y:597,t:1528143496051};\\\", \\\"{x:854,y:597,t:1528143496067};\\\", \\\"{x:853,y:598,t:1528143496076};\\\", \\\"{x:851,y:599,t:1528143496091};\\\", \\\"{x:849,y:600,t:1528143496116};\\\", \\\"{x:848,y:601,t:1528143496140};\\\", \\\"{x:847,y:602,t:1528143496164};\\\", \\\"{x:846,y:602,t:1528143496180};\\\", \\\"{x:845,y:603,t:1528143496189};\\\", \\\"{x:844,y:603,t:1528143496204};\\\", \\\"{x:842,y:603,t:1528143496221};\\\", \\\"{x:840,y:603,t:1528143496238};\\\", \\\"{x:838,y:603,t:1528143496255};\\\", \\\"{x:835,y:603,t:1528143496272};\\\", \\\"{x:834,y:603,t:1528143496288};\\\", \\\"{x:833,y:603,t:1528143496307};\\\", \\\"{x:832,y:603,t:1528143496372};\\\", \\\"{x:831,y:603,t:1528143496533};\\\", \\\"{x:830,y:603,t:1528143496557};\\\", \\\"{x:825,y:605,t:1528143496572};\\\", \\\"{x:817,y:606,t:1528143496589};\\\", \\\"{x:800,y:606,t:1528143496604};\\\", \\\"{x:778,y:606,t:1528143496622};\\\", \\\"{x:754,y:606,t:1528143496638};\\\", \\\"{x:720,y:606,t:1528143496657};\\\", \\\"{x:682,y:603,t:1528143496671};\\\", \\\"{x:655,y:594,t:1528143496688};\\\", \\\"{x:640,y:590,t:1528143496705};\\\", \\\"{x:632,y:587,t:1528143496721};\\\", \\\"{x:632,y:586,t:1528143496739};\\\", \\\"{x:631,y:586,t:1528143496755};\\\", \\\"{x:630,y:585,t:1528143496772};\\\", \\\"{x:627,y:585,t:1528143496788};\\\", \\\"{x:626,y:585,t:1528143496804};\\\", \\\"{x:619,y:585,t:1528143496821};\\\", \\\"{x:608,y:587,t:1528143496839};\\\", \\\"{x:590,y:590,t:1528143496856};\\\", \\\"{x:573,y:590,t:1528143496872};\\\", \\\"{x:557,y:590,t:1528143496888};\\\", \\\"{x:542,y:590,t:1528143496906};\\\", \\\"{x:529,y:590,t:1528143496921};\\\", \\\"{x:521,y:590,t:1528143496939};\\\", \\\"{x:507,y:590,t:1528143496956};\\\", \\\"{x:497,y:590,t:1528143496974};\\\", \\\"{x:474,y:590,t:1528143496988};\\\", \\\"{x:456,y:590,t:1528143497006};\\\", \\\"{x:444,y:590,t:1528143497021};\\\", \\\"{x:433,y:590,t:1528143497039};\\\", \\\"{x:427,y:590,t:1528143497056};\\\", \\\"{x:424,y:590,t:1528143497072};\\\", \\\"{x:422,y:591,t:1528143497088};\\\", \\\"{x:421,y:591,t:1528143497106};\\\", \\\"{x:420,y:593,t:1528143497123};\\\", \\\"{x:419,y:593,t:1528143497138};\\\", \\\"{x:414,y:594,t:1528143497156};\\\", \\\"{x:409,y:596,t:1528143497171};\\\", \\\"{x:404,y:596,t:1528143497188};\\\", \\\"{x:400,y:598,t:1528143497205};\\\", \\\"{x:392,y:598,t:1528143497222};\\\", \\\"{x:384,y:598,t:1528143497238};\\\", \\\"{x:380,y:598,t:1528143497255};\\\", \\\"{x:376,y:598,t:1528143497271};\\\", \\\"{x:375,y:598,t:1528143497300};\\\", \\\"{x:376,y:600,t:1528143498308};\\\", \\\"{x:377,y:602,t:1528143498322};\\\", \\\"{x:385,y:612,t:1528143498339};\\\", \\\"{x:392,y:622,t:1528143498357};\\\", \\\"{x:398,y:629,t:1528143498374};\\\", \\\"{x:405,y:637,t:1528143498390};\\\", \\\"{x:412,y:641,t:1528143498406};\\\", \\\"{x:420,y:647,t:1528143498423};\\\", \\\"{x:431,y:654,t:1528143498439};\\\", \\\"{x:443,y:659,t:1528143498456};\\\", \\\"{x:451,y:662,t:1528143498473};\\\", \\\"{x:457,y:666,t:1528143498489};\\\", \\\"{x:461,y:668,t:1528143498506};\\\", \\\"{x:463,y:670,t:1528143498522};\\\", \\\"{x:464,y:670,t:1528143498540};\\\", \\\"{x:466,y:672,t:1528143498557};\\\", \\\"{x:468,y:675,t:1528143498573};\\\", \\\"{x:469,y:678,t:1528143498590};\\\", \\\"{x:470,y:681,t:1528143498607};\\\", \\\"{x:472,y:686,t:1528143498623};\\\", \\\"{x:473,y:688,t:1528143498640};\\\", \\\"{x:475,y:692,t:1528143498657};\\\", \\\"{x:476,y:696,t:1528143498674};\\\", \\\"{x:479,y:701,t:1528143498690};\\\", \\\"{x:484,y:710,t:1528143498707};\\\", \\\"{x:490,y:724,t:1528143498724};\\\", \\\"{x:496,y:739,t:1528143498741};\\\", \\\"{x:498,y:744,t:1528143498757};\\\", \\\"{x:499,y:746,t:1528143498774};\\\", \\\"{x:503,y:745,t:1528143499052};\\\", \\\"{x:505,y:743,t:1528143499060};\\\", \\\"{x:507,y:742,t:1528143499073};\\\", \\\"{x:510,y:739,t:1528143499089};\\\", \\\"{x:512,y:736,t:1528143499106};\\\", \\\"{x:513,y:735,t:1528143499124};\\\", \\\"{x:513,y:734,t:1528143499188};\\\", \\\"{x:513,y:733,t:1528143499212};\\\", \\\"{x:513,y:732,t:1528143499223};\\\", \\\"{x:514,y:729,t:1528143499660};\\\", \\\"{x:518,y:727,t:1528143499674};\\\", \\\"{x:527,y:719,t:1528143499691};\\\", \\\"{x:549,y:698,t:1528143499708};\\\", \\\"{x:568,y:681,t:1528143499724};\\\", \\\"{x:587,y:667,t:1528143499741};\\\", \\\"{x:613,y:651,t:1528143499758};\\\", \\\"{x:633,y:638,t:1528143499773};\\\", \\\"{x:648,y:627,t:1528143499791};\\\", \\\"{x:669,y:616,t:1528143499808};\\\", \\\"{x:689,y:602,t:1528143499824};\\\", \\\"{x:699,y:598,t:1528143499841};\\\", \\\"{x:708,y:592,t:1528143499858};\\\", \\\"{x:714,y:589,t:1528143499875};\\\", \\\"{x:716,y:587,t:1528143499891};\\\", \\\"{x:718,y:586,t:1528143499908};\\\", \\\"{x:719,y:586,t:1528143499933};\\\", \\\"{x:719,y:584,t:1528143499956};\\\" ] }, { \\\"rt\\\": 39002, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 380469, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 3, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\", \\\"U\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -C -F -F -U -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:716,y:584,t:1528143501404};\\\", \\\"{x:707,y:585,t:1528143501412};\\\", \\\"{x:698,y:585,t:1528143501424};\\\", \\\"{x:675,y:590,t:1528143501441};\\\", \\\"{x:649,y:590,t:1528143501458};\\\", \\\"{x:610,y:590,t:1528143501474};\\\", \\\"{x:572,y:581,t:1528143501492};\\\", \\\"{x:568,y:578,t:1528143501509};\\\", \\\"{x:567,y:578,t:1528143501941};\\\", \\\"{x:568,y:577,t:1528143502069};\\\", \\\"{x:569,y:576,t:1528143502085};\\\", \\\"{x:570,y:576,t:1528143502101};\\\", \\\"{x:571,y:575,t:1528143502110};\\\", \\\"{x:573,y:575,t:1528143502126};\\\", \\\"{x:580,y:574,t:1528143502144};\\\", \\\"{x:596,y:571,t:1528143502160};\\\", \\\"{x:608,y:568,t:1528143502177};\\\", \\\"{x:621,y:565,t:1528143502193};\\\", \\\"{x:637,y:563,t:1528143502209};\\\", \\\"{x:649,y:561,t:1528143502226};\\\", \\\"{x:660,y:557,t:1528143502243};\\\", \\\"{x:672,y:553,t:1528143502259};\\\", \\\"{x:681,y:551,t:1528143502275};\\\", \\\"{x:690,y:548,t:1528143502292};\\\", \\\"{x:696,y:546,t:1528143502309};\\\", \\\"{x:703,y:544,t:1528143502326};\\\", \\\"{x:711,y:540,t:1528143502343};\\\", \\\"{x:721,y:537,t:1528143502360};\\\", \\\"{x:727,y:535,t:1528143502377};\\\", \\\"{x:734,y:530,t:1528143502393};\\\", \\\"{x:745,y:523,t:1528143502410};\\\", \\\"{x:760,y:514,t:1528143502426};\\\", \\\"{x:768,y:509,t:1528143502443};\\\", \\\"{x:778,y:505,t:1528143502461};\\\", \\\"{x:780,y:505,t:1528143502477};\\\", \\\"{x:781,y:505,t:1528143502493};\\\", \\\"{x:784,y:503,t:1528143502733};\\\", \\\"{x:788,y:501,t:1528143502744};\\\", \\\"{x:794,y:499,t:1528143502761};\\\", \\\"{x:806,y:496,t:1528143502777};\\\", \\\"{x:816,y:495,t:1528143502794};\\\", \\\"{x:827,y:491,t:1528143502811};\\\", \\\"{x:835,y:490,t:1528143502827};\\\", \\\"{x:861,y:481,t:1528143502844};\\\", \\\"{x:878,y:476,t:1528143502861};\\\", \\\"{x:898,y:470,t:1528143502877};\\\", \\\"{x:917,y:468,t:1528143502894};\\\", \\\"{x:943,y:462,t:1528143502911};\\\", \\\"{x:967,y:457,t:1528143502928};\\\", \\\"{x:988,y:452,t:1528143502945};\\\", \\\"{x:1004,y:448,t:1528143502962};\\\", \\\"{x:1018,y:447,t:1528143502977};\\\", \\\"{x:1029,y:446,t:1528143502994};\\\", \\\"{x:1040,y:444,t:1528143503011};\\\", \\\"{x:1050,y:444,t:1528143503028};\\\", \\\"{x:1058,y:444,t:1528143503044};\\\", \\\"{x:1066,y:444,t:1528143503061};\\\", \\\"{x:1082,y:445,t:1528143503079};\\\", \\\"{x:1094,y:446,t:1528143503094};\\\", \\\"{x:1112,y:446,t:1528143503111};\\\", \\\"{x:1130,y:448,t:1528143503129};\\\", \\\"{x:1157,y:449,t:1528143503145};\\\", \\\"{x:1189,y:454,t:1528143503161};\\\", \\\"{x:1212,y:455,t:1528143503179};\\\", \\\"{x:1240,y:460,t:1528143503195};\\\", \\\"{x:1267,y:467,t:1528143503211};\\\", \\\"{x:1308,y:479,t:1528143503228};\\\", \\\"{x:1325,y:484,t:1528143503245};\\\", \\\"{x:1341,y:488,t:1528143503261};\\\", \\\"{x:1355,y:491,t:1528143503279};\\\", \\\"{x:1370,y:499,t:1528143503296};\\\", \\\"{x:1384,y:506,t:1528143503311};\\\", \\\"{x:1404,y:514,t:1528143503328};\\\", \\\"{x:1426,y:527,t:1528143503345};\\\", \\\"{x:1450,y:539,t:1528143503362};\\\", \\\"{x:1473,y:547,t:1528143503379};\\\", \\\"{x:1496,y:551,t:1528143503395};\\\", \\\"{x:1536,y:558,t:1528143503411};\\\", \\\"{x:1560,y:563,t:1528143503428};\\\", \\\"{x:1583,y:569,t:1528143503445};\\\", \\\"{x:1604,y:573,t:1528143503462};\\\", \\\"{x:1617,y:577,t:1528143503477};\\\", \\\"{x:1620,y:578,t:1528143503495};\\\", \\\"{x:1621,y:578,t:1528143503511};\\\", \\\"{x:1621,y:581,t:1528143503781};\\\", \\\"{x:1610,y:588,t:1528143503796};\\\", \\\"{x:1602,y:597,t:1528143503812};\\\", \\\"{x:1592,y:606,t:1528143503829};\\\", \\\"{x:1581,y:613,t:1528143503847};\\\", \\\"{x:1572,y:619,t:1528143503862};\\\", \\\"{x:1567,y:622,t:1528143503879};\\\", \\\"{x:1557,y:626,t:1528143503896};\\\", \\\"{x:1548,y:630,t:1528143503913};\\\", \\\"{x:1536,y:635,t:1528143503930};\\\", \\\"{x:1529,y:638,t:1528143503946};\\\", \\\"{x:1520,y:643,t:1528143503962};\\\", \\\"{x:1510,y:647,t:1528143503979};\\\", \\\"{x:1500,y:653,t:1528143503996};\\\", \\\"{x:1495,y:656,t:1528143504013};\\\", \\\"{x:1486,y:661,t:1528143504030};\\\", \\\"{x:1481,y:665,t:1528143504047};\\\", \\\"{x:1473,y:669,t:1528143504064};\\\", \\\"{x:1469,y:671,t:1528143504079};\\\", \\\"{x:1467,y:673,t:1528143504097};\\\", \\\"{x:1464,y:676,t:1528143504113};\\\", \\\"{x:1461,y:678,t:1528143504130};\\\", \\\"{x:1454,y:682,t:1528143504146};\\\", \\\"{x:1442,y:691,t:1528143504163};\\\", \\\"{x:1427,y:701,t:1528143504179};\\\", \\\"{x:1406,y:712,t:1528143504197};\\\", \\\"{x:1384,y:724,t:1528143504214};\\\", \\\"{x:1368,y:734,t:1528143504231};\\\", \\\"{x:1355,y:741,t:1528143504247};\\\", \\\"{x:1344,y:748,t:1528143504263};\\\", \\\"{x:1337,y:752,t:1528143504281};\\\", \\\"{x:1329,y:758,t:1528143504297};\\\", \\\"{x:1324,y:763,t:1528143504313};\\\", \\\"{x:1320,y:766,t:1528143504331};\\\", \\\"{x:1317,y:767,t:1528143504347};\\\", \\\"{x:1316,y:767,t:1528143504364};\\\", \\\"{x:1315,y:767,t:1528143504381};\\\", \\\"{x:1313,y:767,t:1528143504396};\\\", \\\"{x:1312,y:767,t:1528143504413};\\\", \\\"{x:1309,y:768,t:1528143504430};\\\", \\\"{x:1306,y:769,t:1528143504447};\\\", \\\"{x:1303,y:770,t:1528143504463};\\\", \\\"{x:1296,y:772,t:1528143504481};\\\", \\\"{x:1293,y:774,t:1528143504497};\\\", \\\"{x:1284,y:777,t:1528143504514};\\\", \\\"{x:1278,y:781,t:1528143504530};\\\", \\\"{x:1276,y:781,t:1528143504547};\\\", \\\"{x:1275,y:782,t:1528143504565};\\\", \\\"{x:1273,y:785,t:1528143504645};\\\", \\\"{x:1272,y:785,t:1528143504653};\\\", \\\"{x:1272,y:787,t:1528143504665};\\\", \\\"{x:1266,y:792,t:1528143504681};\\\", \\\"{x:1260,y:796,t:1528143504697};\\\", \\\"{x:1255,y:801,t:1528143504715};\\\", \\\"{x:1247,y:809,t:1528143504732};\\\", \\\"{x:1242,y:813,t:1528143504748};\\\", \\\"{x:1238,y:817,t:1528143504764};\\\", \\\"{x:1237,y:818,t:1528143504782};\\\", \\\"{x:1235,y:820,t:1528143504798};\\\", \\\"{x:1234,y:822,t:1528143504814};\\\", \\\"{x:1232,y:823,t:1528143504831};\\\", \\\"{x:1232,y:824,t:1528143504847};\\\", \\\"{x:1230,y:827,t:1528143504865};\\\", \\\"{x:1229,y:827,t:1528143504881};\\\", \\\"{x:1229,y:829,t:1528143504898};\\\", \\\"{x:1227,y:830,t:1528143504915};\\\", \\\"{x:1226,y:831,t:1528143504932};\\\", \\\"{x:1225,y:834,t:1528143504949};\\\", \\\"{x:1225,y:835,t:1528143504972};\\\", \\\"{x:1224,y:835,t:1528143504990};\\\", \\\"{x:1223,y:835,t:1528143504998};\\\", \\\"{x:1223,y:836,t:1528143505020};\\\", \\\"{x:1222,y:836,t:1528143505031};\\\", \\\"{x:1220,y:836,t:1528143505048};\\\", \\\"{x:1218,y:836,t:1528143505064};\\\", \\\"{x:1217,y:836,t:1528143505081};\\\", \\\"{x:1215,y:836,t:1528143505099};\\\", \\\"{x:1213,y:836,t:1528143505114};\\\", \\\"{x:1211,y:835,t:1528143505132};\\\", \\\"{x:1210,y:835,t:1528143505157};\\\", \\\"{x:1210,y:834,t:1528143505325};\\\", \\\"{x:1210,y:832,t:1528143505359};\\\", \\\"{x:1210,y:831,t:1528143505382};\\\", \\\"{x:1210,y:830,t:1528143505403};\\\", \\\"{x:1210,y:829,t:1528143505668};\\\", \\\"{x:1211,y:829,t:1528143506747};\\\", \\\"{x:1212,y:829,t:1528143506772};\\\", \\\"{x:1212,y:830,t:1528143506788};\\\", \\\"{x:1213,y:830,t:1528143506844};\\\", \\\"{x:1214,y:830,t:1528143506916};\\\", \\\"{x:1215,y:830,t:1528143506956};\\\", \\\"{x:1214,y:830,t:1528143508405};\\\", \\\"{x:1209,y:830,t:1528143508420};\\\", \\\"{x:1204,y:830,t:1528143508439};\\\", \\\"{x:1198,y:830,t:1528143508454};\\\", \\\"{x:1192,y:830,t:1528143508470};\\\", \\\"{x:1187,y:830,t:1528143508487};\\\", \\\"{x:1183,y:830,t:1528143508504};\\\", \\\"{x:1178,y:830,t:1528143508521};\\\", \\\"{x:1174,y:830,t:1528143508537};\\\", \\\"{x:1173,y:830,t:1528143508554};\\\", \\\"{x:1171,y:830,t:1528143508570};\\\", \\\"{x:1170,y:830,t:1528143508629};\\\", \\\"{x:1169,y:830,t:1528143508644};\\\", \\\"{x:1168,y:830,t:1528143508655};\\\", \\\"{x:1167,y:830,t:1528143508671};\\\", \\\"{x:1166,y:830,t:1528143508741};\\\", \\\"{x:1167,y:830,t:1528143508916};\\\", \\\"{x:1168,y:830,t:1528143508931};\\\", \\\"{x:1169,y:830,t:1528143508940};\\\", \\\"{x:1170,y:830,t:1528143508954};\\\", \\\"{x:1172,y:830,t:1528143508971};\\\", \\\"{x:1176,y:830,t:1528143508989};\\\", \\\"{x:1180,y:830,t:1528143509005};\\\", \\\"{x:1184,y:830,t:1528143509022};\\\", \\\"{x:1191,y:830,t:1528143509038};\\\", \\\"{x:1195,y:829,t:1528143509055};\\\", \\\"{x:1199,y:828,t:1528143509071};\\\", \\\"{x:1201,y:828,t:1528143509089};\\\", \\\"{x:1203,y:828,t:1528143509106};\\\", \\\"{x:1205,y:828,t:1528143509122};\\\", \\\"{x:1206,y:827,t:1528143509139};\\\", \\\"{x:1207,y:826,t:1528143509156};\\\", \\\"{x:1208,y:825,t:1528143509171};\\\", \\\"{x:1209,y:825,t:1528143509190};\\\", \\\"{x:1211,y:825,t:1528143509206};\\\", \\\"{x:1211,y:824,t:1528143509253};\\\", \\\"{x:1212,y:824,t:1528143509260};\\\", \\\"{x:1214,y:824,t:1528143510093};\\\", \\\"{x:1215,y:824,t:1528143510109};\\\", \\\"{x:1216,y:824,t:1528143510483};\\\", \\\"{x:1217,y:824,t:1528143510499};\\\", \\\"{x:1216,y:824,t:1528143512932};\\\", \\\"{x:1215,y:824,t:1528143512945};\\\", \\\"{x:1214,y:824,t:1528143512961};\\\", \\\"{x:1213,y:824,t:1528143512980};\\\", \\\"{x:1213,y:826,t:1528143516245};\\\", \\\"{x:1218,y:828,t:1528143516268};\\\", \\\"{x:1221,y:831,t:1528143516285};\\\", \\\"{x:1225,y:834,t:1528143516301};\\\", \\\"{x:1228,y:837,t:1528143516318};\\\", \\\"{x:1231,y:841,t:1528143516335};\\\", \\\"{x:1236,y:847,t:1528143516351};\\\", \\\"{x:1246,y:856,t:1528143516367};\\\", \\\"{x:1253,y:866,t:1528143516384};\\\", \\\"{x:1260,y:874,t:1528143516401};\\\", \\\"{x:1270,y:886,t:1528143516418};\\\", \\\"{x:1279,y:893,t:1528143516435};\\\", \\\"{x:1293,y:914,t:1528143516451};\\\", \\\"{x:1301,y:927,t:1528143516467};\\\", \\\"{x:1307,y:935,t:1528143516484};\\\", \\\"{x:1312,y:941,t:1528143516502};\\\", \\\"{x:1315,y:945,t:1528143516517};\\\", \\\"{x:1316,y:946,t:1528143516534};\\\", \\\"{x:1316,y:947,t:1528143516724};\\\", \\\"{x:1314,y:947,t:1528143516764};\\\", \\\"{x:1314,y:948,t:1528143516781};\\\", \\\"{x:1313,y:948,t:1528143516790};\\\", \\\"{x:1311,y:950,t:1528143516804};\\\", \\\"{x:1310,y:951,t:1528143516819};\\\", \\\"{x:1307,y:952,t:1528143516836};\\\", \\\"{x:1305,y:953,t:1528143516853};\\\", \\\"{x:1302,y:954,t:1528143516869};\\\", \\\"{x:1296,y:957,t:1528143516886};\\\", \\\"{x:1293,y:957,t:1528143516902};\\\", \\\"{x:1291,y:958,t:1528143516919};\\\", \\\"{x:1289,y:958,t:1528143516936};\\\", \\\"{x:1288,y:958,t:1528143516997};\\\", \\\"{x:1286,y:958,t:1528143517037};\\\", \\\"{x:1285,y:958,t:1528143517133};\\\", \\\"{x:1283,y:958,t:1528143517164};\\\", \\\"{x:1283,y:959,t:1528143517172};\\\", \\\"{x:1282,y:959,t:1528143517186};\\\", \\\"{x:1282,y:960,t:1528143517253};\\\", \\\"{x:1280,y:960,t:1528143517300};\\\", \\\"{x:1279,y:960,t:1528143521375};\\\", \\\"{x:1278,y:960,t:1528143521407};\\\", \\\"{x:1277,y:960,t:1528143523000};\\\", \\\"{x:1277,y:959,t:1528143524032};\\\", \\\"{x:1277,y:958,t:1528143524039};\\\", \\\"{x:1278,y:957,t:1528143524052};\\\", \\\"{x:1279,y:954,t:1528143524068};\\\", \\\"{x:1281,y:951,t:1528143524085};\\\", \\\"{x:1282,y:949,t:1528143524102};\\\", \\\"{x:1283,y:947,t:1528143524119};\\\", \\\"{x:1283,y:946,t:1528143524135};\\\", \\\"{x:1284,y:943,t:1528143524151};\\\", \\\"{x:1286,y:940,t:1528143524168};\\\", \\\"{x:1287,y:939,t:1528143524185};\\\", \\\"{x:1288,y:937,t:1528143524201};\\\", \\\"{x:1290,y:933,t:1528143524218};\\\", \\\"{x:1293,y:928,t:1528143524236};\\\", \\\"{x:1296,y:923,t:1528143524252};\\\", \\\"{x:1300,y:916,t:1528143524268};\\\", \\\"{x:1305,y:909,t:1528143524285};\\\", \\\"{x:1309,y:901,t:1528143524302};\\\", \\\"{x:1313,y:895,t:1528143524319};\\\", \\\"{x:1316,y:887,t:1528143524335};\\\", \\\"{x:1318,y:884,t:1528143524351};\\\", \\\"{x:1321,y:880,t:1528143524368};\\\", \\\"{x:1323,y:876,t:1528143524385};\\\", \\\"{x:1326,y:872,t:1528143524401};\\\", \\\"{x:1331,y:865,t:1528143524418};\\\", \\\"{x:1339,y:851,t:1528143524435};\\\", \\\"{x:1345,y:843,t:1528143524452};\\\", \\\"{x:1352,y:834,t:1528143524468};\\\", \\\"{x:1361,y:823,t:1528143524485};\\\", \\\"{x:1368,y:814,t:1528143524502};\\\", \\\"{x:1372,y:808,t:1528143524518};\\\", \\\"{x:1375,y:802,t:1528143524534};\\\", \\\"{x:1375,y:799,t:1528143524552};\\\", \\\"{x:1378,y:796,t:1528143524568};\\\", \\\"{x:1379,y:795,t:1528143524585};\\\", \\\"{x:1379,y:793,t:1528143524602};\\\", \\\"{x:1380,y:789,t:1528143524618};\\\", \\\"{x:1380,y:788,t:1528143524648};\\\", \\\"{x:1381,y:787,t:1528143524656};\\\", \\\"{x:1381,y:786,t:1528143524671};\\\", \\\"{x:1381,y:785,t:1528143524685};\\\", \\\"{x:1382,y:783,t:1528143524702};\\\", \\\"{x:1384,y:777,t:1528143524720};\\\", \\\"{x:1384,y:776,t:1528143524736};\\\", \\\"{x:1385,y:774,t:1528143524753};\\\", \\\"{x:1385,y:773,t:1528143524783};\\\", \\\"{x:1385,y:771,t:1528143524816};\\\", \\\"{x:1385,y:770,t:1528143524839};\\\", \\\"{x:1385,y:768,t:1528143524878};\\\", \\\"{x:1385,y:767,t:1528143524887};\\\", \\\"{x:1385,y:766,t:1528143524902};\\\", \\\"{x:1385,y:764,t:1528143524919};\\\", \\\"{x:1385,y:763,t:1528143524936};\\\", \\\"{x:1385,y:762,t:1528143524951};\\\", \\\"{x:1385,y:761,t:1528143525352};\\\", \\\"{x:1384,y:761,t:1528143525992};\\\", \\\"{x:1383,y:760,t:1528143526007};\\\", \\\"{x:1381,y:761,t:1528143528296};\\\", \\\"{x:1370,y:762,t:1528143528309};\\\", \\\"{x:1341,y:767,t:1528143528326};\\\", \\\"{x:1310,y:767,t:1528143528343};\\\", \\\"{x:1275,y:767,t:1528143528358};\\\", \\\"{x:1200,y:757,t:1528143528375};\\\", \\\"{x:1151,y:744,t:1528143528393};\\\", \\\"{x:1107,y:732,t:1528143528408};\\\", \\\"{x:1070,y:721,t:1528143528426};\\\", \\\"{x:1043,y:713,t:1528143528442};\\\", \\\"{x:1015,y:705,t:1528143528459};\\\", \\\"{x:991,y:697,t:1528143528475};\\\", \\\"{x:964,y:690,t:1528143528493};\\\", \\\"{x:932,y:680,t:1528143528509};\\\", \\\"{x:904,y:672,t:1528143528525};\\\", \\\"{x:879,y:664,t:1528143528543};\\\", \\\"{x:838,y:647,t:1528143528558};\\\", \\\"{x:816,y:637,t:1528143528575};\\\", \\\"{x:789,y:625,t:1528143528592};\\\", \\\"{x:762,y:617,t:1528143528609};\\\", \\\"{x:734,y:610,t:1528143528625};\\\", \\\"{x:704,y:602,t:1528143528642};\\\", \\\"{x:655,y:593,t:1528143528659};\\\", \\\"{x:634,y:589,t:1528143528669};\\\", \\\"{x:577,y:577,t:1528143528684};\\\", \\\"{x:535,y:568,t:1528143528702};\\\", \\\"{x:509,y:560,t:1528143528718};\\\", \\\"{x:476,y:550,t:1528143528735};\\\", \\\"{x:466,y:544,t:1528143528751};\\\", \\\"{x:462,y:541,t:1528143528769};\\\", \\\"{x:461,y:541,t:1528143528784};\\\", \\\"{x:459,y:541,t:1528143528801};\\\", \\\"{x:457,y:542,t:1528143528818};\\\", \\\"{x:456,y:542,t:1528143528834};\\\", \\\"{x:454,y:544,t:1528143528852};\\\", \\\"{x:452,y:544,t:1528143528868};\\\", \\\"{x:448,y:546,t:1528143528885};\\\", \\\"{x:445,y:546,t:1528143528901};\\\", \\\"{x:444,y:547,t:1528143528918};\\\", \\\"{x:441,y:548,t:1528143529008};\\\", \\\"{x:438,y:549,t:1528143529018};\\\", \\\"{x:435,y:549,t:1528143529035};\\\", \\\"{x:431,y:550,t:1528143529052};\\\", \\\"{x:428,y:551,t:1528143529069};\\\", \\\"{x:423,y:551,t:1528143529085};\\\", \\\"{x:419,y:551,t:1528143529102};\\\", \\\"{x:414,y:551,t:1528143529120};\\\", \\\"{x:409,y:552,t:1528143529135};\\\", \\\"{x:408,y:553,t:1528143529166};\\\", \\\"{x:407,y:554,t:1528143529182};\\\", \\\"{x:406,y:554,t:1528143529190};\\\", \\\"{x:405,y:554,t:1528143529246};\\\", \\\"{x:404,y:554,t:1528143529262};\\\", \\\"{x:403,y:555,t:1528143529311};\\\", \\\"{x:403,y:553,t:1528143529928};\\\", \\\"{x:406,y:552,t:1528143529936};\\\", \\\"{x:414,y:548,t:1528143529953};\\\", \\\"{x:421,y:545,t:1528143529969};\\\", \\\"{x:430,y:540,t:1528143529985};\\\", \\\"{x:437,y:539,t:1528143530002};\\\", \\\"{x:445,y:535,t:1528143530019};\\\", \\\"{x:458,y:531,t:1528143530035};\\\", \\\"{x:478,y:531,t:1528143530052};\\\", \\\"{x:508,y:531,t:1528143530069};\\\", \\\"{x:559,y:542,t:1528143530086};\\\", \\\"{x:639,y:563,t:1528143530102};\\\", \\\"{x:790,y:601,t:1528143530119};\\\", \\\"{x:903,y:623,t:1528143530136};\\\", \\\"{x:1022,y:640,t:1528143530152};\\\", \\\"{x:1139,y:660,t:1528143530169};\\\", \\\"{x:1244,y:674,t:1528143530187};\\\", \\\"{x:1317,y:688,t:1528143530203};\\\", \\\"{x:1357,y:695,t:1528143530219};\\\", \\\"{x:1383,y:700,t:1528143530236};\\\", \\\"{x:1400,y:703,t:1528143530253};\\\", \\\"{x:1411,y:707,t:1528143530269};\\\", \\\"{x:1413,y:708,t:1528143530287};\\\", \\\"{x:1413,y:709,t:1528143530407};\\\", \\\"{x:1413,y:712,t:1528143530438};\\\", \\\"{x:1413,y:715,t:1528143530453};\\\", \\\"{x:1408,y:727,t:1528143530470};\\\", \\\"{x:1399,y:742,t:1528143530486};\\\", \\\"{x:1397,y:751,t:1528143530504};\\\", \\\"{x:1395,y:755,t:1528143530521};\\\", \\\"{x:1394,y:758,t:1528143530537};\\\", \\\"{x:1393,y:761,t:1528143530553};\\\", \\\"{x:1391,y:763,t:1528143530570};\\\", \\\"{x:1390,y:764,t:1528143530587};\\\", \\\"{x:1390,y:765,t:1528143530622};\\\", \\\"{x:1390,y:767,t:1528143530702};\\\", \\\"{x:1390,y:768,t:1528143530719};\\\", \\\"{x:1389,y:769,t:1528143530727};\\\", \\\"{x:1389,y:770,t:1528143530737};\\\", \\\"{x:1388,y:770,t:1528143530754};\\\", \\\"{x:1387,y:771,t:1528143530771};\\\", \\\"{x:1387,y:774,t:1528143530789};\\\", \\\"{x:1386,y:775,t:1528143530920};\\\", \\\"{x:1385,y:775,t:1528143530935};\\\", \\\"{x:1383,y:775,t:1528143530943};\\\", \\\"{x:1381,y:775,t:1528143530959};\\\", \\\"{x:1381,y:774,t:1528143530975};\\\", \\\"{x:1380,y:774,t:1528143530988};\\\", \\\"{x:1380,y:773,t:1528143531005};\\\", \\\"{x:1380,y:772,t:1528143531039};\\\", \\\"{x:1380,y:771,t:1528143531063};\\\", \\\"{x:1380,y:770,t:1528143531087};\\\", \\\"{x:1380,y:769,t:1528143531208};\\\", \\\"{x:1380,y:768,t:1528143531224};\\\", \\\"{x:1380,y:766,t:1528143531239};\\\", \\\"{x:1380,y:765,t:1528143531257};\\\", \\\"{x:1382,y:764,t:1528143531274};\\\", \\\"{x:1382,y:762,t:1528143531376};\\\", \\\"{x:1384,y:764,t:1528143532032};\\\", \\\"{x:1387,y:770,t:1528143532044};\\\", \\\"{x:1391,y:779,t:1528143532060};\\\", \\\"{x:1396,y:791,t:1528143532076};\\\", \\\"{x:1398,y:798,t:1528143532092};\\\", \\\"{x:1400,y:806,t:1528143532109};\\\", \\\"{x:1402,y:815,t:1528143532126};\\\", \\\"{x:1404,y:827,t:1528143532143};\\\", \\\"{x:1405,y:829,t:1528143532159};\\\", \\\"{x:1405,y:832,t:1528143532176};\\\", \\\"{x:1406,y:833,t:1528143532193};\\\", \\\"{x:1406,y:835,t:1528143532210};\\\", \\\"{x:1406,y:836,t:1528143532226};\\\", \\\"{x:1406,y:837,t:1528143532242};\\\", \\\"{x:1407,y:841,t:1528143532260};\\\", \\\"{x:1408,y:844,t:1528143532276};\\\", \\\"{x:1408,y:848,t:1528143532294};\\\", \\\"{x:1410,y:853,t:1528143532310};\\\", \\\"{x:1413,y:864,t:1528143532327};\\\", \\\"{x:1415,y:875,t:1528143532343};\\\", \\\"{x:1416,y:879,t:1528143532361};\\\", \\\"{x:1417,y:886,t:1528143532377};\\\", \\\"{x:1418,y:891,t:1528143532394};\\\", \\\"{x:1418,y:896,t:1528143532411};\\\", \\\"{x:1418,y:900,t:1528143532428};\\\", \\\"{x:1418,y:901,t:1528143532444};\\\", \\\"{x:1418,y:903,t:1528143532461};\\\", \\\"{x:1418,y:904,t:1528143532568};\\\", \\\"{x:1418,y:905,t:1528143532583};\\\", \\\"{x:1418,y:906,t:1528143532595};\\\", \\\"{x:1418,y:907,t:1528143532611};\\\", \\\"{x:1417,y:910,t:1528143532628};\\\", \\\"{x:1417,y:911,t:1528143532645};\\\", \\\"{x:1416,y:913,t:1528143532661};\\\", \\\"{x:1415,y:916,t:1528143532678};\\\", \\\"{x:1413,y:917,t:1528143532695};\\\", \\\"{x:1413,y:918,t:1528143532711};\\\", \\\"{x:1413,y:919,t:1528143532728};\\\", \\\"{x:1413,y:920,t:1528143532745};\\\", \\\"{x:1412,y:922,t:1528143532762};\\\", \\\"{x:1411,y:924,t:1528143532779};\\\", \\\"{x:1411,y:927,t:1528143532795};\\\", \\\"{x:1409,y:929,t:1528143532812};\\\", \\\"{x:1409,y:933,t:1528143532829};\\\", \\\"{x:1407,y:934,t:1528143532845};\\\", \\\"{x:1407,y:936,t:1528143532862};\\\", \\\"{x:1406,y:938,t:1528143532879};\\\", \\\"{x:1406,y:939,t:1528143532895};\\\", \\\"{x:1406,y:940,t:1528143533224};\\\", \\\"{x:1406,y:941,t:1528143533232};\\\", \\\"{x:1406,y:942,t:1528143533247};\\\", \\\"{x:1406,y:943,t:1528143533264};\\\", \\\"{x:1406,y:944,t:1528143533287};\\\", \\\"{x:1406,y:945,t:1528143533336};\\\", \\\"{x:1406,y:946,t:1528143533367};\\\", \\\"{x:1406,y:948,t:1528143533382};\\\", \\\"{x:1406,y:949,t:1528143533399};\\\", \\\"{x:1406,y:950,t:1528143533414};\\\", \\\"{x:1407,y:951,t:1528143533431};\\\", \\\"{x:1407,y:952,t:1528143533447};\\\", \\\"{x:1408,y:953,t:1528143533464};\\\", \\\"{x:1408,y:954,t:1528143533481};\\\", \\\"{x:1409,y:954,t:1528143533498};\\\", \\\"{x:1409,y:955,t:1528143533514};\\\", \\\"{x:1411,y:956,t:1528143533531};\\\", \\\"{x:1411,y:957,t:1528143533548};\\\", \\\"{x:1412,y:958,t:1528143533564};\\\", \\\"{x:1413,y:958,t:1528143533580};\\\", \\\"{x:1414,y:958,t:1528143533597};\\\", \\\"{x:1416,y:956,t:1528143533904};\\\", \\\"{x:1416,y:954,t:1528143533916};\\\", \\\"{x:1418,y:950,t:1528143533933};\\\", \\\"{x:1421,y:946,t:1528143533949};\\\", \\\"{x:1422,y:944,t:1528143533966};\\\", \\\"{x:1425,y:939,t:1528143533984};\\\", \\\"{x:1427,y:936,t:1528143534000};\\\", \\\"{x:1429,y:933,t:1528143534016};\\\", \\\"{x:1431,y:927,t:1528143534034};\\\", \\\"{x:1434,y:919,t:1528143534050};\\\", \\\"{x:1437,y:913,t:1528143534066};\\\", \\\"{x:1439,y:910,t:1528143534083};\\\", \\\"{x:1440,y:907,t:1528143534100};\\\", \\\"{x:1440,y:905,t:1528143534116};\\\", \\\"{x:1441,y:904,t:1528143534133};\\\", \\\"{x:1441,y:902,t:1528143534150};\\\", \\\"{x:1442,y:900,t:1528143534167};\\\", \\\"{x:1443,y:896,t:1528143534184};\\\", \\\"{x:1446,y:892,t:1528143534200};\\\", \\\"{x:1448,y:887,t:1528143534218};\\\", \\\"{x:1451,y:881,t:1528143534234};\\\", \\\"{x:1456,y:875,t:1528143534250};\\\", \\\"{x:1459,y:869,t:1528143534267};\\\", \\\"{x:1460,y:866,t:1528143534284};\\\", \\\"{x:1465,y:859,t:1528143534300};\\\", \\\"{x:1468,y:853,t:1528143534317};\\\", \\\"{x:1472,y:845,t:1528143534334};\\\", \\\"{x:1475,y:839,t:1528143534351};\\\", \\\"{x:1477,y:834,t:1528143534367};\\\", \\\"{x:1477,y:832,t:1528143534384};\\\", \\\"{x:1480,y:829,t:1528143534400};\\\", \\\"{x:1480,y:827,t:1528143534417};\\\", \\\"{x:1481,y:825,t:1528143534433};\\\", \\\"{x:1481,y:824,t:1528143534454};\\\", \\\"{x:1483,y:824,t:1528143535472};\\\", \\\"{x:1502,y:814,t:1528143535488};\\\", \\\"{x:1546,y:800,t:1528143535505};\\\", \\\"{x:1648,y:776,t:1528143535521};\\\", \\\"{x:1808,y:758,t:1528143535538};\\\", \\\"{x:1919,y:762,t:1528143535555};\\\", \\\"{x:1919,y:795,t:1528143535570};\\\", \\\"{x:1919,y:856,t:1528143535590};\\\", \\\"{x:1919,y:893,t:1528143535606};\\\", \\\"{x:1919,y:930,t:1528143535623};\\\", \\\"{x:1919,y:969,t:1528143535640};\\\", \\\"{x:1919,y:990,t:1528143535657};\\\", \\\"{x:1919,y:994,t:1528143535673};\\\", \\\"{x:1918,y:995,t:1528143535695};\\\", \\\"{x:1910,y:996,t:1528143535707};\\\", \\\"{x:1870,y:996,t:1528143535723};\\\", \\\"{x:1752,y:968,t:1528143535740};\\\", \\\"{x:1603,y:928,t:1528143535757};\\\", \\\"{x:1458,y:900,t:1528143535773};\\\", \\\"{x:1277,y:863,t:1528143535791};\\\", \\\"{x:1161,y:829,t:1528143535807};\\\", \\\"{x:1050,y:799,t:1528143535823};\\\", \\\"{x:945,y:766,t:1528143535840};\\\", \\\"{x:844,y:728,t:1528143535857};\\\", \\\"{x:766,y:694,t:1528143535874};\\\", \\\"{x:722,y:676,t:1528143535893};\\\", \\\"{x:689,y:661,t:1528143535907};\\\", \\\"{x:669,y:653,t:1528143535923};\\\", \\\"{x:662,y:651,t:1528143535941};\\\", \\\"{x:659,y:649,t:1528143535958};\\\", \\\"{x:659,y:646,t:1528143536094};\\\", \\\"{x:659,y:642,t:1528143536107};\\\", \\\"{x:658,y:635,t:1528143536123};\\\", \\\"{x:654,y:629,t:1528143536140};\\\", \\\"{x:650,y:621,t:1528143536157};\\\", \\\"{x:645,y:610,t:1528143536174};\\\", \\\"{x:636,y:599,t:1528143536191};\\\", \\\"{x:630,y:595,t:1528143536208};\\\", \\\"{x:628,y:594,t:1528143536223};\\\", \\\"{x:624,y:593,t:1528143536241};\\\", \\\"{x:623,y:592,t:1528143536258};\\\", \\\"{x:621,y:591,t:1528143536273};\\\", \\\"{x:619,y:591,t:1528143536291};\\\", \\\"{x:617,y:591,t:1528143536311};\\\", \\\"{x:617,y:590,t:1528143536324};\\\", \\\"{x:614,y:589,t:1528143536341};\\\", \\\"{x:609,y:587,t:1528143536358};\\\", \\\"{x:605,y:585,t:1528143536374};\\\", \\\"{x:601,y:584,t:1528143536393};\\\", \\\"{x:601,y:583,t:1528143536414};\\\", \\\"{x:601,y:586,t:1528143536591};\\\", \\\"{x:606,y:591,t:1528143536608};\\\", \\\"{x:608,y:596,t:1528143536624};\\\", \\\"{x:612,y:602,t:1528143536641};\\\", \\\"{x:615,y:605,t:1528143536657};\\\", \\\"{x:615,y:606,t:1528143536674};\\\", \\\"{x:616,y:607,t:1528143536690};\\\", \\\"{x:616,y:606,t:1528143536800};\\\", \\\"{x:615,y:605,t:1528143536815};\\\", \\\"{x:614,y:605,t:1528143536825};\\\", \\\"{x:613,y:604,t:1528143536840};\\\", \\\"{x:612,y:604,t:1528143536858};\\\", \\\"{x:611,y:604,t:1528143536874};\\\", \\\"{x:610,y:603,t:1528143536903};\\\", \\\"{x:609,y:602,t:1528143536919};\\\", \\\"{x:612,y:601,t:1528143537376};\\\", \\\"{x:625,y:592,t:1528143537395};\\\", \\\"{x:637,y:587,t:1528143537409};\\\", \\\"{x:648,y:583,t:1528143537426};\\\", \\\"{x:665,y:577,t:1528143537442};\\\", \\\"{x:674,y:574,t:1528143537459};\\\", \\\"{x:682,y:571,t:1528143537475};\\\", \\\"{x:695,y:567,t:1528143537492};\\\", \\\"{x:703,y:565,t:1528143537508};\\\", \\\"{x:712,y:563,t:1528143537524};\\\", \\\"{x:722,y:561,t:1528143537542};\\\", \\\"{x:738,y:557,t:1528143537559};\\\", \\\"{x:749,y:554,t:1528143537575};\\\", \\\"{x:754,y:553,t:1528143537592};\\\", \\\"{x:757,y:553,t:1528143537608};\\\", \\\"{x:758,y:553,t:1528143537624};\\\", \\\"{x:756,y:553,t:1528143537727};\\\", \\\"{x:747,y:557,t:1528143537742};\\\", \\\"{x:704,y:575,t:1528143537760};\\\", \\\"{x:671,y:584,t:1528143537776};\\\", \\\"{x:645,y:587,t:1528143537792};\\\", \\\"{x:620,y:593,t:1528143537809};\\\", \\\"{x:601,y:596,t:1528143537825};\\\", \\\"{x:595,y:598,t:1528143537842};\\\", \\\"{x:592,y:599,t:1528143537858};\\\", \\\"{x:590,y:600,t:1528143537886};\\\", \\\"{x:587,y:602,t:1528143537895};\\\", \\\"{x:579,y:605,t:1528143537909};\\\", \\\"{x:556,y:611,t:1528143537925};\\\", \\\"{x:514,y:618,t:1528143537942};\\\", \\\"{x:439,y:624,t:1528143537959};\\\", \\\"{x:391,y:624,t:1528143537975};\\\", \\\"{x:358,y:624,t:1528143537992};\\\", \\\"{x:338,y:624,t:1528143538008};\\\", \\\"{x:328,y:624,t:1528143538025};\\\", \\\"{x:322,y:624,t:1528143538042};\\\", \\\"{x:320,y:624,t:1528143538058};\\\", \\\"{x:319,y:624,t:1528143538136};\\\", \\\"{x:317,y:624,t:1528143538142};\\\", \\\"{x:313,y:624,t:1528143538158};\\\", \\\"{x:305,y:625,t:1528143538175};\\\", \\\"{x:292,y:626,t:1528143538193};\\\", \\\"{x:272,y:631,t:1528143538212};\\\", \\\"{x:248,y:633,t:1528143538225};\\\", \\\"{x:231,y:636,t:1528143538243};\\\", \\\"{x:217,y:639,t:1528143538259};\\\", \\\"{x:206,y:639,t:1528143538276};\\\", \\\"{x:200,y:639,t:1528143538293};\\\", \\\"{x:199,y:639,t:1528143538308};\\\", \\\"{x:197,y:639,t:1528143538351};\\\", \\\"{x:196,y:639,t:1528143538375};\\\", \\\"{x:194,y:639,t:1528143538399};\\\", \\\"{x:192,y:638,t:1528143538430};\\\", \\\"{x:191,y:638,t:1528143538444};\\\", \\\"{x:187,y:637,t:1528143538460};\\\", \\\"{x:182,y:637,t:1528143538476};\\\", \\\"{x:175,y:636,t:1528143538492};\\\", \\\"{x:172,y:635,t:1528143538508};\\\", \\\"{x:169,y:635,t:1528143538526};\\\", \\\"{x:168,y:635,t:1528143538584};\\\", \\\"{x:172,y:635,t:1528143538886};\\\", \\\"{x:176,y:637,t:1528143538894};\\\", \\\"{x:181,y:639,t:1528143538909};\\\", \\\"{x:192,y:643,t:1528143538926};\\\", \\\"{x:219,y:647,t:1528143538943};\\\", \\\"{x:236,y:649,t:1528143538960};\\\", \\\"{x:250,y:652,t:1528143538977};\\\", \\\"{x:268,y:655,t:1528143538992};\\\", \\\"{x:288,y:661,t:1528143539010};\\\", \\\"{x:313,y:665,t:1528143539026};\\\", \\\"{x:336,y:673,t:1528143539043};\\\", \\\"{x:352,y:679,t:1528143539059};\\\", \\\"{x:369,y:683,t:1528143539077};\\\", \\\"{x:382,y:687,t:1528143539092};\\\", \\\"{x:390,y:690,t:1528143539109};\\\", \\\"{x:402,y:692,t:1528143539126};\\\", \\\"{x:408,y:694,t:1528143539142};\\\", \\\"{x:409,y:694,t:1528143539160};\\\", \\\"{x:412,y:694,t:1528143539176};\\\", \\\"{x:413,y:694,t:1528143539193};\\\", \\\"{x:415,y:694,t:1528143539210};\\\", \\\"{x:420,y:694,t:1528143539227};\\\", \\\"{x:424,y:694,t:1528143539242};\\\", \\\"{x:429,y:694,t:1528143539260};\\\", \\\"{x:434,y:694,t:1528143539276};\\\", \\\"{x:438,y:695,t:1528143539293};\\\", \\\"{x:445,y:699,t:1528143539310};\\\", \\\"{x:456,y:703,t:1528143539327};\\\", \\\"{x:465,y:705,t:1528143539344};\\\", \\\"{x:474,y:709,t:1528143539359};\\\", \\\"{x:479,y:709,t:1528143539377};\\\", \\\"{x:481,y:709,t:1528143539393};\\\", \\\"{x:483,y:709,t:1528143539410};\\\", \\\"{x:484,y:709,t:1528143539427};\\\", \\\"{x:486,y:709,t:1528143539526};\\\", \\\"{x:486,y:709,t:1528143539593};\\\", \\\"{x:488,y:709,t:1528143539943};\\\", \\\"{x:530,y:690,t:1528143539959};\\\", \\\"{x:613,y:658,t:1528143539977};\\\", \\\"{x:714,y:617,t:1528143539994};\\\", \\\"{x:831,y:578,t:1528143540010};\\\", \\\"{x:957,y:535,t:1528143540027};\\\", \\\"{x:1046,y:506,t:1528143540044};\\\", \\\"{x:1102,y:490,t:1528143540060};\\\", \\\"{x:1130,y:485,t:1528143540077};\\\", \\\"{x:1137,y:484,t:1528143540094};\\\", \\\"{x:1138,y:483,t:1528143540110};\\\" ] }, { \\\"rt\\\": 77832, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 459582, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 3.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -D -K -K -H -B \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1138,y:484,t:1528143541760};\\\", \\\"{x:1133,y:488,t:1528143541775};\\\", \\\"{x:1132,y:489,t:1528143541782};\\\", \\\"{x:1128,y:491,t:1528143541794};\\\", \\\"{x:1123,y:494,t:1528143541811};\\\", \\\"{x:1121,y:496,t:1528143541829};\\\", \\\"{x:1118,y:497,t:1528143541845};\\\", \\\"{x:1117,y:497,t:1528143541862};\\\", \\\"{x:1112,y:500,t:1528143541878};\\\", \\\"{x:1111,y:500,t:1528143541895};\\\", \\\"{x:1106,y:502,t:1528143541912};\\\", \\\"{x:1102,y:504,t:1528143541929};\\\", \\\"{x:1090,y:509,t:1528143541944};\\\", \\\"{x:1074,y:517,t:1528143541962};\\\", \\\"{x:1049,y:527,t:1528143541979};\\\", \\\"{x:1020,y:537,t:1528143541995};\\\", \\\"{x:992,y:544,t:1528143542012};\\\", \\\"{x:966,y:550,t:1528143542029};\\\", \\\"{x:944,y:556,t:1528143542046};\\\", \\\"{x:924,y:565,t:1528143542061};\\\", \\\"{x:858,y:567,t:1528143542078};\\\", \\\"{x:806,y:555,t:1528143542096};\\\", \\\"{x:792,y:553,t:1528143542112};\\\", \\\"{x:793,y:550,t:1528143542808};\\\", \\\"{x:799,y:549,t:1528143542815};\\\", \\\"{x:805,y:549,t:1528143542830};\\\", \\\"{x:815,y:549,t:1528143542847};\\\", \\\"{x:817,y:549,t:1528143542863};\\\", \\\"{x:818,y:549,t:1528143542880};\\\", \\\"{x:819,y:549,t:1528143542897};\\\", \\\"{x:820,y:549,t:1528143542919};\\\", \\\"{x:821,y:549,t:1528143542934};\\\", \\\"{x:822,y:549,t:1528143542947};\\\", \\\"{x:828,y:549,t:1528143542965};\\\", \\\"{x:836,y:551,t:1528143542980};\\\", \\\"{x:852,y:556,t:1528143542995};\\\", \\\"{x:872,y:559,t:1528143543012};\\\", \\\"{x:896,y:563,t:1528143543027};\\\", \\\"{x:920,y:568,t:1528143543045};\\\", \\\"{x:957,y:574,t:1528143543063};\\\", \\\"{x:980,y:576,t:1528143543080};\\\", \\\"{x:1004,y:579,t:1528143543096};\\\", \\\"{x:1028,y:582,t:1528143543113};\\\", \\\"{x:1047,y:587,t:1528143543130};\\\", \\\"{x:1064,y:591,t:1528143543146};\\\", \\\"{x:1082,y:596,t:1528143543163};\\\", \\\"{x:1099,y:603,t:1528143543180};\\\", \\\"{x:1113,y:608,t:1528143543196};\\\", \\\"{x:1130,y:617,t:1528143543213};\\\", \\\"{x:1144,y:622,t:1528143543231};\\\", \\\"{x:1171,y:629,t:1528143543247};\\\", \\\"{x:1192,y:634,t:1528143543263};\\\", \\\"{x:1212,y:637,t:1528143543280};\\\", \\\"{x:1230,y:639,t:1528143543297};\\\", \\\"{x:1245,y:642,t:1528143543313};\\\", \\\"{x:1255,y:643,t:1528143543330};\\\", \\\"{x:1264,y:644,t:1528143543347};\\\", \\\"{x:1270,y:647,t:1528143543363};\\\", \\\"{x:1276,y:648,t:1528143543380};\\\", \\\"{x:1282,y:652,t:1528143543397};\\\", \\\"{x:1288,y:656,t:1528143543415};\\\", \\\"{x:1291,y:659,t:1528143543430};\\\", \\\"{x:1293,y:665,t:1528143543447};\\\", \\\"{x:1295,y:670,t:1528143543465};\\\", \\\"{x:1295,y:672,t:1528143543480};\\\", \\\"{x:1295,y:674,t:1528143543497};\\\", \\\"{x:1295,y:676,t:1528143543514};\\\", \\\"{x:1295,y:677,t:1528143543530};\\\", \\\"{x:1294,y:680,t:1528143543547};\\\", \\\"{x:1292,y:680,t:1528143543565};\\\", \\\"{x:1290,y:681,t:1528143543580};\\\", \\\"{x:1288,y:682,t:1528143543597};\\\", \\\"{x:1288,y:683,t:1528143543613};\\\", \\\"{x:1284,y:684,t:1528143543629};\\\", \\\"{x:1277,y:687,t:1528143543647};\\\", \\\"{x:1264,y:692,t:1528143543664};\\\", \\\"{x:1252,y:695,t:1528143543681};\\\", \\\"{x:1239,y:697,t:1528143543697};\\\", \\\"{x:1231,y:697,t:1528143543714};\\\", \\\"{x:1223,y:698,t:1528143543731};\\\", \\\"{x:1217,y:698,t:1528143543747};\\\", \\\"{x:1206,y:698,t:1528143543764};\\\", \\\"{x:1198,y:700,t:1528143543781};\\\", \\\"{x:1191,y:700,t:1528143543798};\\\", \\\"{x:1179,y:700,t:1528143543814};\\\", \\\"{x:1161,y:700,t:1528143543831};\\\", \\\"{x:1148,y:700,t:1528143543847};\\\", \\\"{x:1134,y:701,t:1528143543864};\\\", \\\"{x:1119,y:701,t:1528143543881};\\\", \\\"{x:1103,y:701,t:1528143543898};\\\", \\\"{x:1090,y:701,t:1528143543914};\\\", \\\"{x:1082,y:701,t:1528143543932};\\\", \\\"{x:1077,y:701,t:1528143543949};\\\", \\\"{x:1073,y:701,t:1528143543964};\\\", \\\"{x:1072,y:701,t:1528143543981};\\\", \\\"{x:1071,y:701,t:1528143543999};\\\", \\\"{x:1071,y:702,t:1528143544816};\\\", \\\"{x:1072,y:702,t:1528143544911};\\\", \\\"{x:1073,y:702,t:1528143544919};\\\", \\\"{x:1074,y:702,t:1528143544935};\\\", \\\"{x:1075,y:702,t:1528143544968};\\\", \\\"{x:1076,y:702,t:1528143545080};\\\", \\\"{x:1077,y:702,t:1528143545095};\\\", \\\"{x:1078,y:702,t:1528143545111};\\\", \\\"{x:1079,y:702,t:1528143545119};\\\", \\\"{x:1080,y:702,t:1528143545133};\\\", \\\"{x:1081,y:702,t:1528143545152};\\\", \\\"{x:1082,y:702,t:1528143545166};\\\", \\\"{x:1083,y:702,t:1528143545183};\\\", \\\"{x:1084,y:702,t:1528143545200};\\\", \\\"{x:1085,y:702,t:1528143545216};\\\", \\\"{x:1088,y:702,t:1528143545234};\\\", \\\"{x:1089,y:702,t:1528143545249};\\\", \\\"{x:1092,y:702,t:1528143545266};\\\", \\\"{x:1095,y:702,t:1528143545284};\\\", \\\"{x:1096,y:702,t:1528143545300};\\\", \\\"{x:1097,y:702,t:1528143545317};\\\", \\\"{x:1098,y:702,t:1528143545334};\\\", \\\"{x:1099,y:702,t:1528143545349};\\\", \\\"{x:1100,y:702,t:1528143545366};\\\", \\\"{x:1101,y:702,t:1528143545384};\\\", \\\"{x:1102,y:702,t:1528143545400};\\\", \\\"{x:1104,y:702,t:1528143545417};\\\", \\\"{x:1105,y:702,t:1528143545434};\\\", \\\"{x:1106,y:702,t:1528143545449};\\\", \\\"{x:1107,y:702,t:1528143545466};\\\", \\\"{x:1108,y:702,t:1528143545483};\\\", \\\"{x:1109,y:702,t:1528143545543};\\\", \\\"{x:1110,y:702,t:1528143545639};\\\", \\\"{x:1112,y:701,t:1528143545650};\\\", \\\"{x:1113,y:701,t:1528143545667};\\\", \\\"{x:1114,y:700,t:1528143545683};\\\", \\\"{x:1117,y:700,t:1528143545700};\\\", \\\"{x:1118,y:700,t:1528143545717};\\\", \\\"{x:1119,y:700,t:1528143545751};\\\", \\\"{x:1120,y:700,t:1528143546744};\\\", \\\"{x:1121,y:699,t:1528143546751};\\\", \\\"{x:1123,y:699,t:1528143546769};\\\", \\\"{x:1128,y:698,t:1528143546785};\\\", \\\"{x:1130,y:698,t:1528143546802};\\\", \\\"{x:1133,y:697,t:1528143546818};\\\", \\\"{x:1138,y:697,t:1528143546837};\\\", \\\"{x:1142,y:696,t:1528143546851};\\\", \\\"{x:1145,y:696,t:1528143546869};\\\", \\\"{x:1152,y:696,t:1528143546885};\\\", \\\"{x:1157,y:696,t:1528143546901};\\\", \\\"{x:1164,y:696,t:1528143546918};\\\", \\\"{x:1182,y:702,t:1528143546935};\\\", \\\"{x:1191,y:705,t:1528143546951};\\\", \\\"{x:1203,y:710,t:1528143546969};\\\", \\\"{x:1216,y:714,t:1528143546985};\\\", \\\"{x:1229,y:717,t:1528143547001};\\\", \\\"{x:1244,y:720,t:1528143547019};\\\", \\\"{x:1259,y:723,t:1528143547036};\\\", \\\"{x:1274,y:725,t:1528143547053};\\\", \\\"{x:1289,y:728,t:1528143547068};\\\", \\\"{x:1305,y:730,t:1528143547086};\\\", \\\"{x:1324,y:734,t:1528143547103};\\\", \\\"{x:1343,y:739,t:1528143547118};\\\", \\\"{x:1367,y:746,t:1528143547136};\\\", \\\"{x:1384,y:752,t:1528143547153};\\\", \\\"{x:1396,y:757,t:1528143547169};\\\", \\\"{x:1413,y:766,t:1528143547186};\\\", \\\"{x:1427,y:771,t:1528143547203};\\\", \\\"{x:1441,y:775,t:1528143547219};\\\", \\\"{x:1458,y:778,t:1528143547237};\\\", \\\"{x:1471,y:783,t:1528143547252};\\\", \\\"{x:1488,y:788,t:1528143547268};\\\", \\\"{x:1504,y:791,t:1528143547286};\\\", \\\"{x:1521,y:793,t:1528143547303};\\\", \\\"{x:1546,y:797,t:1528143547319};\\\", \\\"{x:1562,y:799,t:1528143547335};\\\", \\\"{x:1582,y:802,t:1528143547353};\\\", \\\"{x:1595,y:804,t:1528143547370};\\\", \\\"{x:1608,y:808,t:1528143547386};\\\", \\\"{x:1618,y:813,t:1528143547403};\\\", \\\"{x:1626,y:817,t:1528143547420};\\\", \\\"{x:1633,y:820,t:1528143547437};\\\", \\\"{x:1638,y:822,t:1528143547452};\\\", \\\"{x:1641,y:822,t:1528143547470};\\\", \\\"{x:1642,y:822,t:1528143547485};\\\", \\\"{x:1643,y:822,t:1528143547503};\\\", \\\"{x:1644,y:822,t:1528143547527};\\\", \\\"{x:1645,y:822,t:1528143547543};\\\", \\\"{x:1646,y:822,t:1528143547568};\\\", \\\"{x:1647,y:824,t:1528143547640};\\\", \\\"{x:1648,y:824,t:1528143547653};\\\", \\\"{x:1650,y:827,t:1528143547670};\\\", \\\"{x:1653,y:829,t:1528143547686};\\\", \\\"{x:1653,y:831,t:1528143547702};\\\", \\\"{x:1656,y:836,t:1528143547720};\\\", \\\"{x:1658,y:842,t:1528143547737};\\\", \\\"{x:1659,y:846,t:1528143547752};\\\", \\\"{x:1660,y:849,t:1528143547769};\\\", \\\"{x:1660,y:853,t:1528143547786};\\\", \\\"{x:1660,y:859,t:1528143547802};\\\", \\\"{x:1660,y:864,t:1528143547820};\\\", \\\"{x:1661,y:868,t:1528143547837};\\\", \\\"{x:1662,y:874,t:1528143547854};\\\", \\\"{x:1663,y:879,t:1528143547870};\\\", \\\"{x:1663,y:886,t:1528143547886};\\\", \\\"{x:1663,y:899,t:1528143547903};\\\", \\\"{x:1663,y:907,t:1528143547919};\\\", \\\"{x:1661,y:916,t:1528143547937};\\\", \\\"{x:1658,y:923,t:1528143547954};\\\", \\\"{x:1656,y:929,t:1528143547970};\\\", \\\"{x:1655,y:930,t:1528143547987};\\\", \\\"{x:1654,y:932,t:1528143548004};\\\", \\\"{x:1651,y:933,t:1528143548020};\\\", \\\"{x:1645,y:934,t:1528143548037};\\\", \\\"{x:1638,y:938,t:1528143548054};\\\", \\\"{x:1631,y:938,t:1528143548070};\\\", \\\"{x:1630,y:940,t:1528143548086};\\\", \\\"{x:1625,y:941,t:1528143548103};\\\", \\\"{x:1623,y:943,t:1528143548121};\\\", \\\"{x:1622,y:944,t:1528143548137};\\\", \\\"{x:1621,y:945,t:1528143548176};\\\", \\\"{x:1620,y:946,t:1528143548187};\\\", \\\"{x:1619,y:948,t:1528143548204};\\\", \\\"{x:1618,y:949,t:1528143548220};\\\", \\\"{x:1617,y:949,t:1528143548237};\\\", \\\"{x:1617,y:950,t:1528143548344};\\\", \\\"{x:1617,y:951,t:1528143548353};\\\", \\\"{x:1616,y:953,t:1528143548371};\\\", \\\"{x:1614,y:956,t:1528143548388};\\\", \\\"{x:1614,y:957,t:1528143548403};\\\", \\\"{x:1614,y:960,t:1528143548421};\\\", \\\"{x:1613,y:960,t:1528143548437};\\\", \\\"{x:1613,y:959,t:1528143548808};\\\", \\\"{x:1613,y:958,t:1528143548823};\\\", \\\"{x:1614,y:956,t:1528143549487};\\\", \\\"{x:1614,y:955,t:1528143549505};\\\", \\\"{x:1615,y:954,t:1528143550759};\\\", \\\"{x:1615,y:953,t:1528143554728};\\\", \\\"{x:1616,y:953,t:1528143554745};\\\", \\\"{x:1617,y:953,t:1528143554767};\\\", \\\"{x:1618,y:953,t:1528143554792};\\\", \\\"{x:1619,y:953,t:1528143554823};\\\", \\\"{x:1620,y:953,t:1528143554864};\\\", \\\"{x:1621,y:953,t:1528143554944};\\\", \\\"{x:1623,y:953,t:1528143554959};\\\", \\\"{x:1624,y:953,t:1528143555127};\\\", \\\"{x:1625,y:953,t:1528143555143};\\\", \\\"{x:1626,y:953,t:1528143555176};\\\", \\\"{x:1626,y:954,t:1528143556599};\\\", \\\"{x:1621,y:955,t:1528143556615};\\\", \\\"{x:1618,y:956,t:1528143556632};\\\", \\\"{x:1613,y:956,t:1528143556648};\\\", \\\"{x:1606,y:956,t:1528143556665};\\\", \\\"{x:1604,y:954,t:1528143556681};\\\", \\\"{x:1599,y:953,t:1528143556698};\\\", \\\"{x:1595,y:953,t:1528143556714};\\\", \\\"{x:1592,y:953,t:1528143556732};\\\", \\\"{x:1590,y:952,t:1528143556747};\\\", \\\"{x:1591,y:952,t:1528143557119};\\\", \\\"{x:1592,y:952,t:1528143557132};\\\", \\\"{x:1593,y:952,t:1528143557149};\\\", \\\"{x:1595,y:952,t:1528143557166};\\\", \\\"{x:1598,y:952,t:1528143557182};\\\", \\\"{x:1599,y:952,t:1528143557216};\\\", \\\"{x:1601,y:952,t:1528143557256};\\\", \\\"{x:1602,y:952,t:1528143557279};\\\", \\\"{x:1604,y:952,t:1528143557320};\\\", \\\"{x:1605,y:952,t:1528143557367};\\\", \\\"{x:1606,y:952,t:1528143557384};\\\", \\\"{x:1607,y:952,t:1528143557415};\\\", \\\"{x:1604,y:948,t:1528143557880};\\\", \\\"{x:1596,y:943,t:1528143557887};\\\", \\\"{x:1579,y:934,t:1528143557900};\\\", \\\"{x:1551,y:922,t:1528143557917};\\\", \\\"{x:1519,y:913,t:1528143557933};\\\", \\\"{x:1496,y:907,t:1528143557950};\\\", \\\"{x:1468,y:897,t:1528143557967};\\\", \\\"{x:1455,y:893,t:1528143557983};\\\", \\\"{x:1448,y:891,t:1528143558001};\\\", \\\"{x:1444,y:888,t:1528143558017};\\\", \\\"{x:1439,y:885,t:1528143558033};\\\", \\\"{x:1435,y:881,t:1528143558050};\\\", \\\"{x:1429,y:876,t:1528143558067};\\\", \\\"{x:1419,y:868,t:1528143558083};\\\", \\\"{x:1409,y:861,t:1528143558100};\\\", \\\"{x:1398,y:855,t:1528143558118};\\\", \\\"{x:1389,y:852,t:1528143558135};\\\", \\\"{x:1383,y:849,t:1528143558150};\\\", \\\"{x:1379,y:847,t:1528143558167};\\\", \\\"{x:1378,y:847,t:1528143558199};\\\", \\\"{x:1376,y:847,t:1528143558217};\\\", \\\"{x:1374,y:847,t:1528143558234};\\\", \\\"{x:1369,y:847,t:1528143558250};\\\", \\\"{x:1364,y:847,t:1528143558267};\\\", \\\"{x:1356,y:845,t:1528143558284};\\\", \\\"{x:1352,y:844,t:1528143558301};\\\", \\\"{x:1347,y:842,t:1528143558317};\\\", \\\"{x:1341,y:841,t:1528143558334};\\\", \\\"{x:1336,y:839,t:1528143558350};\\\", \\\"{x:1329,y:836,t:1528143558367};\\\", \\\"{x:1322,y:835,t:1528143558384};\\\", \\\"{x:1312,y:833,t:1528143558401};\\\", \\\"{x:1305,y:831,t:1528143558417};\\\", \\\"{x:1298,y:829,t:1528143558434};\\\", \\\"{x:1294,y:827,t:1528143558451};\\\", \\\"{x:1292,y:827,t:1528143558467};\\\", \\\"{x:1290,y:826,t:1528143558484};\\\", \\\"{x:1288,y:826,t:1528143558501};\\\", \\\"{x:1286,y:825,t:1528143558517};\\\", \\\"{x:1285,y:825,t:1528143558559};\\\", \\\"{x:1286,y:824,t:1528143561920};\\\", \\\"{x:1288,y:822,t:1528143561927};\\\", \\\"{x:1290,y:820,t:1528143561938};\\\", \\\"{x:1293,y:815,t:1528143561956};\\\", \\\"{x:1296,y:813,t:1528143561972};\\\", \\\"{x:1298,y:812,t:1528143561989};\\\", \\\"{x:1301,y:809,t:1528143562055};\\\", \\\"{x:1307,y:805,t:1528143562072};\\\", \\\"{x:1314,y:797,t:1528143562089};\\\", \\\"{x:1326,y:783,t:1528143562106};\\\", \\\"{x:1351,y:756,t:1528143562123};\\\", \\\"{x:1382,y:720,t:1528143562139};\\\", \\\"{x:1425,y:673,t:1528143562155};\\\", \\\"{x:1465,y:616,t:1528143562171};\\\", \\\"{x:1492,y:573,t:1528143562188};\\\", \\\"{x:1511,y:538,t:1528143562204};\\\", \\\"{x:1523,y:510,t:1528143562222};\\\", \\\"{x:1535,y:475,t:1528143562238};\\\", \\\"{x:1539,y:457,t:1528143562255};\\\", \\\"{x:1542,y:435,t:1528143562272};\\\", \\\"{x:1550,y:413,t:1528143562289};\\\", \\\"{x:1555,y:394,t:1528143562306};\\\", \\\"{x:1560,y:376,t:1528143562322};\\\", \\\"{x:1564,y:360,t:1528143562339};\\\", \\\"{x:1568,y:345,t:1528143562356};\\\", \\\"{x:1569,y:332,t:1528143562372};\\\", \\\"{x:1571,y:319,t:1528143562389};\\\", \\\"{x:1571,y:307,t:1528143562406};\\\", \\\"{x:1571,y:290,t:1528143562423};\\\", \\\"{x:1571,y:263,t:1528143562439};\\\", \\\"{x:1569,y:243,t:1528143562457};\\\", \\\"{x:1561,y:225,t:1528143562473};\\\", \\\"{x:1554,y:205,t:1528143562489};\\\", \\\"{x:1545,y:191,t:1528143562506};\\\", \\\"{x:1542,y:185,t:1528143562522};\\\", \\\"{x:1541,y:184,t:1528143562539};\\\", \\\"{x:1541,y:183,t:1528143562567};\\\", \\\"{x:1541,y:182,t:1528143562591};\\\", \\\"{x:1540,y:182,t:1528143562696};\\\", \\\"{x:1537,y:182,t:1528143562706};\\\", \\\"{x:1531,y:182,t:1528143562723};\\\", \\\"{x:1528,y:182,t:1528143562739};\\\", \\\"{x:1526,y:183,t:1528143562756};\\\", \\\"{x:1524,y:184,t:1528143562773};\\\", \\\"{x:1520,y:184,t:1528143562951};\\\", \\\"{x:1517,y:184,t:1528143562959};\\\", \\\"{x:1513,y:184,t:1528143562974};\\\", \\\"{x:1504,y:184,t:1528143562990};\\\", \\\"{x:1495,y:185,t:1528143563006};\\\", \\\"{x:1482,y:185,t:1528143563023};\\\", \\\"{x:1480,y:185,t:1528143563040};\\\", \\\"{x:1479,y:185,t:1528143563057};\\\", \\\"{x:1478,y:185,t:1528143563073};\\\", \\\"{x:1476,y:185,t:1528143563119};\\\", \\\"{x:1475,y:185,t:1528143563127};\\\", \\\"{x:1474,y:184,t:1528143563140};\\\", \\\"{x:1471,y:181,t:1528143563157};\\\", \\\"{x:1468,y:179,t:1528143563173};\\\", \\\"{x:1466,y:178,t:1528143563191};\\\", \\\"{x:1463,y:177,t:1528143563207};\\\", \\\"{x:1462,y:177,t:1528143563223};\\\", \\\"{x:1462,y:176,t:1528143563303};\\\", \\\"{x:1462,y:175,t:1528143563319};\\\", \\\"{x:1462,y:174,t:1528143563327};\\\", \\\"{x:1462,y:173,t:1528143563341};\\\", \\\"{x:1463,y:172,t:1528143563357};\\\", \\\"{x:1463,y:171,t:1528143563374};\\\", \\\"{x:1463,y:170,t:1528143563390};\\\", \\\"{x:1464,y:169,t:1528143563415};\\\", \\\"{x:1465,y:167,t:1528143563640};\\\", \\\"{x:1466,y:167,t:1528143563655};\\\", \\\"{x:1467,y:167,t:1528143563671};\\\", \\\"{x:1468,y:167,t:1528143563687};\\\", \\\"{x:1469,y:167,t:1528143563727};\\\", \\\"{x:1470,y:167,t:1528143563743};\\\", \\\"{x:1471,y:167,t:1528143563783};\\\", \\\"{x:1472,y:167,t:1528143563887};\\\", \\\"{x:1473,y:167,t:1528143563911};\\\", \\\"{x:1474,y:167,t:1528143564040};\\\", \\\"{x:1475,y:167,t:1528143564087};\\\", \\\"{x:1476,y:167,t:1528143564095};\\\", \\\"{x:1477,y:166,t:1528143564114};\\\", \\\"{x:1479,y:167,t:1528143572543};\\\", \\\"{x:1482,y:175,t:1528143572554};\\\", \\\"{x:1486,y:182,t:1528143572570};\\\", \\\"{x:1490,y:191,t:1528143572585};\\\", \\\"{x:1496,y:204,t:1528143572603};\\\", \\\"{x:1502,y:215,t:1528143572620};\\\", \\\"{x:1506,y:223,t:1528143572637};\\\", \\\"{x:1509,y:229,t:1528143572653};\\\", \\\"{x:1510,y:233,t:1528143572669};\\\", \\\"{x:1513,y:240,t:1528143572686};\\\", \\\"{x:1518,y:248,t:1528143572702};\\\", \\\"{x:1518,y:250,t:1528143572719};\\\", \\\"{x:1522,y:256,t:1528143572736};\\\", \\\"{x:1526,y:264,t:1528143572753};\\\", \\\"{x:1533,y:275,t:1528143572769};\\\", \\\"{x:1544,y:294,t:1528143572786};\\\", \\\"{x:1558,y:309,t:1528143572802};\\\", \\\"{x:1570,y:326,t:1528143572819};\\\", \\\"{x:1585,y:342,t:1528143572836};\\\", \\\"{x:1595,y:356,t:1528143572852};\\\", \\\"{x:1602,y:366,t:1528143572869};\\\", \\\"{x:1613,y:380,t:1528143572886};\\\", \\\"{x:1617,y:386,t:1528143572903};\\\", \\\"{x:1620,y:391,t:1528143572919};\\\", \\\"{x:1621,y:392,t:1528143572936};\\\", \\\"{x:1622,y:395,t:1528143572953};\\\", \\\"{x:1622,y:396,t:1528143572999};\\\", \\\"{x:1622,y:397,t:1528143573007};\\\", \\\"{x:1622,y:399,t:1528143573020};\\\", \\\"{x:1622,y:407,t:1528143573037};\\\", \\\"{x:1622,y:413,t:1528143573054};\\\", \\\"{x:1622,y:417,t:1528143573070};\\\", \\\"{x:1622,y:418,t:1528143573087};\\\", \\\"{x:1622,y:420,t:1528143573104};\\\", \\\"{x:1622,y:421,t:1528143573143};\\\", \\\"{x:1622,y:423,t:1528143573154};\\\", \\\"{x:1622,y:427,t:1528143573171};\\\", \\\"{x:1621,y:431,t:1528143573187};\\\", \\\"{x:1620,y:433,t:1528143573204};\\\", \\\"{x:1619,y:434,t:1528143573221};\\\", \\\"{x:1618,y:434,t:1528143573448};\\\", \\\"{x:1616,y:434,t:1528143573471};\\\", \\\"{x:1613,y:434,t:1528143579626};\\\", \\\"{x:1609,y:440,t:1528143579634};\\\", \\\"{x:1604,y:448,t:1528143579649};\\\", \\\"{x:1590,y:465,t:1528143579665};\\\", \\\"{x:1572,y:491,t:1528143579681};\\\", \\\"{x:1562,y:507,t:1528143579698};\\\", \\\"{x:1545,y:521,t:1528143579714};\\\", \\\"{x:1539,y:528,t:1528143579731};\\\", \\\"{x:1535,y:532,t:1528143579749};\\\", \\\"{x:1533,y:534,t:1528143579765};\\\", \\\"{x:1533,y:535,t:1528143579781};\\\", \\\"{x:1530,y:538,t:1528143579799};\\\", \\\"{x:1529,y:541,t:1528143579815};\\\", \\\"{x:1528,y:544,t:1528143579832};\\\", \\\"{x:1527,y:548,t:1528143579849};\\\", \\\"{x:1524,y:555,t:1528143579865};\\\", \\\"{x:1522,y:562,t:1528143579882};\\\", \\\"{x:1518,y:575,t:1528143579899};\\\", \\\"{x:1516,y:584,t:1528143579916};\\\", \\\"{x:1514,y:589,t:1528143579932};\\\", \\\"{x:1514,y:592,t:1528143579949};\\\", \\\"{x:1514,y:596,t:1528143579966};\\\", \\\"{x:1514,y:599,t:1528143579982};\\\", \\\"{x:1513,y:604,t:1528143579998};\\\", \\\"{x:1513,y:608,t:1528143580015};\\\", \\\"{x:1511,y:612,t:1528143580031};\\\", \\\"{x:1511,y:614,t:1528143580048};\\\", \\\"{x:1510,y:618,t:1528143580065};\\\", \\\"{x:1510,y:619,t:1528143580081};\\\", \\\"{x:1510,y:620,t:1528143580105};\\\", \\\"{x:1510,y:621,t:1528143580121};\\\", \\\"{x:1510,y:622,t:1528143581378};\\\", \\\"{x:1511,y:623,t:1528143581393};\\\", \\\"{x:1514,y:623,t:1528143581410};\\\", \\\"{x:1515,y:624,t:1528143581434};\\\", \\\"{x:1516,y:624,t:1528143581451};\\\", \\\"{x:1517,y:624,t:1528143581468};\\\", \\\"{x:1518,y:624,t:1528143581484};\\\", \\\"{x:1518,y:625,t:1528143581501};\\\", \\\"{x:1519,y:625,t:1528143581518};\\\", \\\"{x:1520,y:626,t:1528143581534};\\\", \\\"{x:1521,y:626,t:1528143581577};\\\", \\\"{x:1522,y:626,t:1528143581609};\\\", \\\"{x:1523,y:627,t:1528143581617};\\\", \\\"{x:1525,y:628,t:1528143581635};\\\", \\\"{x:1526,y:629,t:1528143581674};\\\", \\\"{x:1528,y:629,t:1528143581697};\\\", \\\"{x:1529,y:629,t:1528143581706};\\\", \\\"{x:1531,y:631,t:1528143581722};\\\", \\\"{x:1533,y:632,t:1528143581735};\\\", \\\"{x:1536,y:632,t:1528143581751};\\\", \\\"{x:1537,y:633,t:1528143581768};\\\", \\\"{x:1540,y:634,t:1528143581785};\\\", \\\"{x:1542,y:634,t:1528143581801};\\\", \\\"{x:1546,y:635,t:1528143581818};\\\", \\\"{x:1547,y:636,t:1528143581835};\\\", \\\"{x:1548,y:636,t:1528143581852};\\\", \\\"{x:1551,y:636,t:1528143581868};\\\", \\\"{x:1553,y:636,t:1528143581884};\\\", \\\"{x:1554,y:636,t:1528143581902};\\\", \\\"{x:1556,y:636,t:1528143581918};\\\", \\\"{x:1557,y:636,t:1528143581935};\\\", \\\"{x:1559,y:637,t:1528143581952};\\\", \\\"{x:1562,y:637,t:1528143581967};\\\", \\\"{x:1566,y:637,t:1528143581984};\\\", \\\"{x:1577,y:637,t:1528143582001};\\\", \\\"{x:1589,y:639,t:1528143582017};\\\", \\\"{x:1604,y:641,t:1528143582035};\\\", \\\"{x:1614,y:642,t:1528143582052};\\\", \\\"{x:1627,y:645,t:1528143582067};\\\", \\\"{x:1632,y:645,t:1528143582084};\\\", \\\"{x:1639,y:645,t:1528143582102};\\\", \\\"{x:1640,y:646,t:1528143582118};\\\", \\\"{x:1641,y:646,t:1528143582135};\\\", \\\"{x:1642,y:646,t:1528143582153};\\\", \\\"{x:1643,y:646,t:1528143582178};\\\", \\\"{x:1644,y:646,t:1528143582193};\\\", \\\"{x:1645,y:646,t:1528143582202};\\\", \\\"{x:1647,y:646,t:1528143582219};\\\", \\\"{x:1651,y:646,t:1528143582235};\\\", \\\"{x:1654,y:646,t:1528143582252};\\\", \\\"{x:1658,y:646,t:1528143582269};\\\", \\\"{x:1659,y:646,t:1528143582285};\\\", \\\"{x:1662,y:646,t:1528143582302};\\\", \\\"{x:1663,y:646,t:1528143582320};\\\", \\\"{x:1666,y:648,t:1528143582335};\\\", \\\"{x:1667,y:648,t:1528143582351};\\\", \\\"{x:1669,y:648,t:1528143582369};\\\", \\\"{x:1670,y:649,t:1528143582385};\\\", \\\"{x:1674,y:649,t:1528143582402};\\\", \\\"{x:1677,y:649,t:1528143582419};\\\", \\\"{x:1681,y:650,t:1528143582436};\\\", \\\"{x:1685,y:650,t:1528143582452};\\\", \\\"{x:1688,y:652,t:1528143582469};\\\", \\\"{x:1692,y:652,t:1528143582486};\\\", \\\"{x:1694,y:653,t:1528143582502};\\\", \\\"{x:1697,y:654,t:1528143582519};\\\", \\\"{x:1700,y:655,t:1528143582536};\\\", \\\"{x:1703,y:656,t:1528143582552};\\\", \\\"{x:1706,y:656,t:1528143582570};\\\", \\\"{x:1709,y:657,t:1528143582586};\\\", \\\"{x:1710,y:657,t:1528143582602};\\\", \\\"{x:1712,y:657,t:1528143582620};\\\", \\\"{x:1715,y:658,t:1528143582636};\\\", \\\"{x:1717,y:659,t:1528143582652};\\\", \\\"{x:1720,y:659,t:1528143582669};\\\", \\\"{x:1723,y:659,t:1528143582687};\\\", \\\"{x:1726,y:660,t:1528143582703};\\\", \\\"{x:1730,y:660,t:1528143582720};\\\", \\\"{x:1732,y:661,t:1528143582736};\\\", \\\"{x:1733,y:661,t:1528143582754};\\\", \\\"{x:1734,y:661,t:1528143582770};\\\", \\\"{x:1735,y:662,t:1528143582786};\\\", \\\"{x:1736,y:662,t:1528143582803};\\\", \\\"{x:1737,y:663,t:1528143582819};\\\", \\\"{x:1739,y:664,t:1528143582837};\\\", \\\"{x:1738,y:666,t:1528143583794};\\\", \\\"{x:1735,y:666,t:1528143583804};\\\", \\\"{x:1727,y:670,t:1528143583822};\\\", \\\"{x:1721,y:673,t:1528143583838};\\\", \\\"{x:1718,y:675,t:1528143583855};\\\", \\\"{x:1715,y:677,t:1528143583871};\\\", \\\"{x:1714,y:677,t:1528143583905};\\\", \\\"{x:1713,y:678,t:1528143583930};\\\", \\\"{x:1711,y:679,t:1528143583946};\\\", \\\"{x:1708,y:680,t:1528143583961};\\\", \\\"{x:1705,y:682,t:1528143583971};\\\", \\\"{x:1701,y:684,t:1528143583988};\\\", \\\"{x:1696,y:686,t:1528143584005};\\\", \\\"{x:1693,y:688,t:1528143584022};\\\", \\\"{x:1691,y:689,t:1528143584040};\\\", \\\"{x:1686,y:691,t:1528143584054};\\\", \\\"{x:1682,y:693,t:1528143584072};\\\", \\\"{x:1679,y:694,t:1528143584089};\\\", \\\"{x:1673,y:696,t:1528143584104};\\\", \\\"{x:1665,y:699,t:1528143584122};\\\", \\\"{x:1653,y:702,t:1528143584138};\\\", \\\"{x:1642,y:704,t:1528143584154};\\\", \\\"{x:1626,y:705,t:1528143584172};\\\", \\\"{x:1607,y:707,t:1528143584189};\\\", \\\"{x:1589,y:711,t:1528143584204};\\\", \\\"{x:1573,y:713,t:1528143584222};\\\", \\\"{x:1558,y:716,t:1528143584240};\\\", \\\"{x:1544,y:717,t:1528143584256};\\\", \\\"{x:1535,y:720,t:1528143584271};\\\", \\\"{x:1528,y:721,t:1528143584288};\\\", \\\"{x:1522,y:723,t:1528143584306};\\\", \\\"{x:1521,y:724,t:1528143584330};\\\", \\\"{x:1520,y:724,t:1528143584346};\\\", \\\"{x:1519,y:724,t:1528143584355};\\\", \\\"{x:1516,y:726,t:1528143584372};\\\", \\\"{x:1514,y:727,t:1528143584389};\\\", \\\"{x:1510,y:728,t:1528143584405};\\\", \\\"{x:1502,y:732,t:1528143584422};\\\", \\\"{x:1494,y:734,t:1528143584440};\\\", \\\"{x:1485,y:737,t:1528143584455};\\\", \\\"{x:1479,y:739,t:1528143584472};\\\", \\\"{x:1475,y:740,t:1528143584488};\\\", \\\"{x:1472,y:741,t:1528143584505};\\\", \\\"{x:1470,y:742,t:1528143584523};\\\", \\\"{x:1469,y:743,t:1528143584539};\\\", \\\"{x:1468,y:743,t:1528143584834};\\\", \\\"{x:1467,y:743,t:1528143584930};\\\", \\\"{x:1466,y:744,t:1528143584939};\\\", \\\"{x:1464,y:744,t:1528143584955};\\\", \\\"{x:1462,y:744,t:1528143584972};\\\", \\\"{x:1461,y:744,t:1528143584989};\\\", \\\"{x:1460,y:744,t:1528143585005};\\\", \\\"{x:1458,y:744,t:1528143591794};\\\", \\\"{x:1456,y:744,t:1528143591802};\\\", \\\"{x:1454,y:746,t:1528143591815};\\\", \\\"{x:1450,y:747,t:1528143591832};\\\", \\\"{x:1449,y:748,t:1528143591849};\\\", \\\"{x:1449,y:750,t:1528143591865};\\\", \\\"{x:1449,y:751,t:1528143591881};\\\", \\\"{x:1449,y:752,t:1528143591898};\\\", \\\"{x:1451,y:753,t:1528143591915};\\\", \\\"{x:1452,y:754,t:1528143591932};\\\", \\\"{x:1456,y:756,t:1528143591949};\\\", \\\"{x:1460,y:757,t:1528143591965};\\\", \\\"{x:1464,y:759,t:1528143591982};\\\", \\\"{x:1465,y:761,t:1528143591999};\\\", \\\"{x:1468,y:763,t:1528143592015};\\\", \\\"{x:1470,y:767,t:1528143592032};\\\", \\\"{x:1474,y:772,t:1528143592049};\\\", \\\"{x:1484,y:785,t:1528143592066};\\\", \\\"{x:1489,y:792,t:1528143592081};\\\", \\\"{x:1494,y:801,t:1528143592099};\\\", \\\"{x:1501,y:812,t:1528143592116};\\\", \\\"{x:1507,y:821,t:1528143592132};\\\", \\\"{x:1513,y:830,t:1528143592149};\\\", \\\"{x:1519,y:838,t:1528143592166};\\\", \\\"{x:1525,y:844,t:1528143592181};\\\", \\\"{x:1529,y:849,t:1528143592199};\\\", \\\"{x:1532,y:852,t:1528143592216};\\\", \\\"{x:1538,y:856,t:1528143592233};\\\", \\\"{x:1543,y:858,t:1528143592249};\\\", \\\"{x:1554,y:864,t:1528143592265};\\\", \\\"{x:1573,y:873,t:1528143592283};\\\", \\\"{x:1592,y:883,t:1528143592299};\\\", \\\"{x:1616,y:895,t:1528143592316};\\\", \\\"{x:1652,y:910,t:1528143592333};\\\", \\\"{x:1686,y:926,t:1528143592349};\\\", \\\"{x:1712,y:935,t:1528143592366};\\\", \\\"{x:1733,y:944,t:1528143592383};\\\", \\\"{x:1750,y:951,t:1528143592398};\\\", \\\"{x:1757,y:953,t:1528143592416};\\\", \\\"{x:1756,y:953,t:1528143592514};\\\", \\\"{x:1754,y:953,t:1528143592521};\\\", \\\"{x:1752,y:953,t:1528143592533};\\\", \\\"{x:1747,y:953,t:1528143592550};\\\", \\\"{x:1741,y:953,t:1528143592566};\\\", \\\"{x:1737,y:953,t:1528143592582};\\\", \\\"{x:1731,y:953,t:1528143592600};\\\", \\\"{x:1725,y:953,t:1528143592615};\\\", \\\"{x:1717,y:953,t:1528143592633};\\\", \\\"{x:1706,y:953,t:1528143592649};\\\", \\\"{x:1700,y:953,t:1528143592666};\\\", \\\"{x:1694,y:953,t:1528143592683};\\\", \\\"{x:1690,y:953,t:1528143592700};\\\", \\\"{x:1689,y:953,t:1528143592716};\\\", \\\"{x:1686,y:953,t:1528143592733};\\\", \\\"{x:1684,y:953,t:1528143592750};\\\", \\\"{x:1683,y:954,t:1528143592766};\\\", \\\"{x:1682,y:954,t:1528143592794};\\\", \\\"{x:1681,y:955,t:1528143592802};\\\", \\\"{x:1679,y:955,t:1528143592898};\\\", \\\"{x:1666,y:956,t:1528143592917};\\\", \\\"{x:1658,y:958,t:1528143592933};\\\", \\\"{x:1648,y:959,t:1528143592950};\\\", \\\"{x:1643,y:960,t:1528143592967};\\\", \\\"{x:1637,y:960,t:1528143592983};\\\", \\\"{x:1633,y:960,t:1528143593000};\\\", \\\"{x:1632,y:960,t:1528143593017};\\\", \\\"{x:1629,y:960,t:1528143593034};\\\", \\\"{x:1628,y:960,t:1528143593122};\\\", \\\"{x:1626,y:960,t:1528143593154};\\\", \\\"{x:1625,y:960,t:1528143593370};\\\", \\\"{x:1624,y:960,t:1528143593386};\\\", \\\"{x:1623,y:960,t:1528143593401};\\\", \\\"{x:1621,y:960,t:1528143593418};\\\", \\\"{x:1620,y:959,t:1528143593434};\\\", \\\"{x:1620,y:958,t:1528143593458};\\\", \\\"{x:1618,y:958,t:1528143593474};\\\", \\\"{x:1617,y:958,t:1528143593586};\\\", \\\"{x:1616,y:957,t:1528143593651};\\\", \\\"{x:1615,y:957,t:1528143593674};\\\", \\\"{x:1614,y:957,t:1528143593684};\\\", \\\"{x:1614,y:956,t:1528143593700};\\\", \\\"{x:1613,y:956,t:1528143593841};\\\", \\\"{x:1611,y:955,t:1528143593857};\\\", \\\"{x:1609,y:954,t:1528143593914};\\\", \\\"{x:1607,y:954,t:1528143599546};\\\", \\\"{x:1604,y:952,t:1528143599559};\\\", \\\"{x:1601,y:947,t:1528143599575};\\\", \\\"{x:1596,y:942,t:1528143599592};\\\", \\\"{x:1591,y:938,t:1528143599610};\\\", \\\"{x:1589,y:937,t:1528143599625};\\\", \\\"{x:1587,y:936,t:1528143599642};\\\", \\\"{x:1587,y:935,t:1528143599659};\\\", \\\"{x:1585,y:933,t:1528143599682};\\\", \\\"{x:1584,y:932,t:1528143599698};\\\", \\\"{x:1584,y:931,t:1528143599708};\\\", \\\"{x:1581,y:927,t:1528143599726};\\\", \\\"{x:1578,y:922,t:1528143599741};\\\", \\\"{x:1576,y:917,t:1528143599758};\\\", \\\"{x:1573,y:911,t:1528143599776};\\\", \\\"{x:1569,y:904,t:1528143599792};\\\", \\\"{x:1561,y:895,t:1528143599808};\\\", \\\"{x:1552,y:883,t:1528143599825};\\\", \\\"{x:1550,y:880,t:1528143599841};\\\", \\\"{x:1547,y:875,t:1528143599858};\\\", \\\"{x:1542,y:869,t:1528143599875};\\\", \\\"{x:1536,y:862,t:1528143599892};\\\", \\\"{x:1534,y:858,t:1528143599909};\\\", \\\"{x:1530,y:850,t:1528143599926};\\\", \\\"{x:1524,y:838,t:1528143599942};\\\", \\\"{x:1516,y:815,t:1528143599959};\\\", \\\"{x:1504,y:794,t:1528143599976};\\\", \\\"{x:1491,y:775,t:1528143599994};\\\", \\\"{x:1476,y:754,t:1528143600009};\\\", \\\"{x:1444,y:722,t:1528143600026};\\\", \\\"{x:1416,y:702,t:1528143600043};\\\", \\\"{x:1386,y:685,t:1528143600059};\\\", \\\"{x:1354,y:672,t:1528143600076};\\\", \\\"{x:1324,y:663,t:1528143600093};\\\", \\\"{x:1294,y:656,t:1528143600109};\\\", \\\"{x:1266,y:650,t:1528143600126};\\\", \\\"{x:1246,y:648,t:1528143600143};\\\", \\\"{x:1230,y:646,t:1528143600159};\\\", \\\"{x:1216,y:645,t:1528143600176};\\\", \\\"{x:1201,y:645,t:1528143600193};\\\", \\\"{x:1183,y:645,t:1528143600209};\\\", \\\"{x:1142,y:648,t:1528143600226};\\\", \\\"{x:1105,y:652,t:1528143600243};\\\", \\\"{x:1078,y:653,t:1528143600260};\\\", \\\"{x:1056,y:653,t:1528143600276};\\\", \\\"{x:1028,y:653,t:1528143600293};\\\", \\\"{x:1005,y:653,t:1528143600310};\\\", \\\"{x:982,y:653,t:1528143600326};\\\", \\\"{x:960,y:653,t:1528143600343};\\\", \\\"{x:930,y:653,t:1528143600360};\\\", \\\"{x:899,y:651,t:1528143600375};\\\", \\\"{x:854,y:643,t:1528143600392};\\\", \\\"{x:764,y:625,t:1528143600410};\\\", \\\"{x:705,y:606,t:1528143600427};\\\", \\\"{x:668,y:596,t:1528143600442};\\\", \\\"{x:646,y:585,t:1528143600459};\\\", \\\"{x:630,y:573,t:1528143600480};\\\", \\\"{x:611,y:560,t:1528143600497};\\\", \\\"{x:590,y:545,t:1528143600513};\\\", \\\"{x:585,y:541,t:1528143600530};\\\", \\\"{x:583,y:539,t:1528143600547};\\\", \\\"{x:581,y:539,t:1528143600563};\\\", \\\"{x:579,y:539,t:1528143600698};\\\", \\\"{x:577,y:540,t:1528143600713};\\\", \\\"{x:576,y:540,t:1528143600731};\\\", \\\"{x:576,y:541,t:1528143600747};\\\", \\\"{x:576,y:545,t:1528143600763};\\\", \\\"{x:579,y:546,t:1528143600781};\\\", \\\"{x:584,y:548,t:1528143600797};\\\", \\\"{x:589,y:550,t:1528143600812};\\\", \\\"{x:594,y:552,t:1528143600830};\\\", \\\"{x:598,y:554,t:1528143600846};\\\", \\\"{x:602,y:554,t:1528143600862};\\\", \\\"{x:606,y:557,t:1528143600879};\\\", \\\"{x:611,y:558,t:1528143600896};\\\", \\\"{x:619,y:560,t:1528143600913};\\\", \\\"{x:627,y:560,t:1528143600929};\\\", \\\"{x:636,y:560,t:1528143600946};\\\", \\\"{x:637,y:560,t:1528143600964};\\\", \\\"{x:636,y:560,t:1528143601082};\\\", \\\"{x:634,y:560,t:1528143601097};\\\", \\\"{x:627,y:557,t:1528143601113};\\\", \\\"{x:618,y:553,t:1528143601131};\\\", \\\"{x:613,y:551,t:1528143601147};\\\", \\\"{x:609,y:549,t:1528143601164};\\\", \\\"{x:607,y:548,t:1528143601181};\\\", \\\"{x:605,y:547,t:1528143601197};\\\", \\\"{x:604,y:547,t:1528143601241};\\\", \\\"{x:605,y:547,t:1528143601610};\\\", \\\"{x:608,y:547,t:1528143601618};\\\", \\\"{x:611,y:548,t:1528143601631};\\\", \\\"{x:619,y:551,t:1528143601648};\\\", \\\"{x:624,y:553,t:1528143601664};\\\", \\\"{x:631,y:553,t:1528143601681};\\\", \\\"{x:665,y:553,t:1528143601697};\\\", \\\"{x:706,y:553,t:1528143601714};\\\", \\\"{x:759,y:553,t:1528143601731};\\\", \\\"{x:812,y:553,t:1528143601747};\\\", \\\"{x:863,y:555,t:1528143601765};\\\", \\\"{x:911,y:561,t:1528143601781};\\\", \\\"{x:940,y:562,t:1528143601798};\\\", \\\"{x:962,y:565,t:1528143601814};\\\", \\\"{x:976,y:567,t:1528143601831};\\\", \\\"{x:991,y:568,t:1528143601848};\\\", \\\"{x:1001,y:568,t:1528143601864};\\\", \\\"{x:1007,y:568,t:1528143601881};\\\", \\\"{x:1018,y:567,t:1528143601897};\\\", \\\"{x:1025,y:565,t:1528143601914};\\\", \\\"{x:1031,y:564,t:1528143601931};\\\", \\\"{x:1033,y:562,t:1528143601948};\\\", \\\"{x:1035,y:562,t:1528143601964};\\\", \\\"{x:1032,y:562,t:1528143602066};\\\", \\\"{x:1028,y:562,t:1528143602081};\\\", \\\"{x:1003,y:568,t:1528143602097};\\\", \\\"{x:953,y:575,t:1528143602114};\\\", \\\"{x:921,y:575,t:1528143602131};\\\", \\\"{x:887,y:575,t:1528143602146};\\\", \\\"{x:862,y:575,t:1528143602164};\\\", \\\"{x:848,y:574,t:1528143602182};\\\", \\\"{x:839,y:570,t:1528143602196};\\\", \\\"{x:838,y:570,t:1528143602214};\\\", \\\"{x:836,y:570,t:1528143602296};\\\", \\\"{x:835,y:570,t:1528143602305};\\\", \\\"{x:834,y:569,t:1528143602315};\\\", \\\"{x:831,y:568,t:1528143602332};\\\", \\\"{x:829,y:566,t:1528143602349};\\\", \\\"{x:830,y:566,t:1528143602513};\\\", \\\"{x:830,y:566,t:1528143602564};\\\", \\\"{x:820,y:567,t:1528143602851};\\\", \\\"{x:800,y:567,t:1528143602864};\\\", \\\"{x:753,y:565,t:1528143602881};\\\", \\\"{x:727,y:560,t:1528143602899};\\\", \\\"{x:711,y:554,t:1528143602917};\\\", \\\"{x:701,y:551,t:1528143602931};\\\", \\\"{x:700,y:550,t:1528143602949};\\\", \\\"{x:700,y:549,t:1528143602977};\\\", \\\"{x:702,y:548,t:1528143602985};\\\", \\\"{x:706,y:546,t:1528143602999};\\\", \\\"{x:708,y:546,t:1528143603015};\\\", \\\"{x:717,y:546,t:1528143603032};\\\", \\\"{x:732,y:546,t:1528143603051};\\\", \\\"{x:748,y:546,t:1528143603065};\\\", \\\"{x:770,y:546,t:1528143603082};\\\", \\\"{x:792,y:546,t:1528143603099};\\\", \\\"{x:812,y:546,t:1528143603116};\\\", \\\"{x:829,y:546,t:1528143603132};\\\", \\\"{x:844,y:546,t:1528143603149};\\\", \\\"{x:858,y:545,t:1528143603166};\\\", \\\"{x:862,y:545,t:1528143603182};\\\", \\\"{x:864,y:545,t:1528143603201};\\\", \\\"{x:865,y:545,t:1528143603217};\\\", \\\"{x:867,y:545,t:1528143603234};\\\", \\\"{x:869,y:545,t:1528143603249};\\\", \\\"{x:870,y:545,t:1528143603266};\\\", \\\"{x:871,y:545,t:1528143603283};\\\", \\\"{x:869,y:547,t:1528143603354};\\\", \\\"{x:862,y:551,t:1528143603367};\\\", \\\"{x:848,y:559,t:1528143603382};\\\", \\\"{x:840,y:562,t:1528143603398};\\\", \\\"{x:835,y:562,t:1528143603416};\\\", \\\"{x:833,y:562,t:1528143603432};\\\", \\\"{x:830,y:562,t:1528143603448};\\\", \\\"{x:829,y:562,t:1528143603465};\\\", \\\"{x:828,y:562,t:1528143603481};\\\", \\\"{x:827,y:562,t:1528143603499};\\\", \\\"{x:825,y:562,t:1528143603517};\\\", \\\"{x:824,y:562,t:1528143603532};\\\", \\\"{x:826,y:562,t:1528143603913};\\\", \\\"{x:828,y:562,t:1528143604378};\\\", \\\"{x:835,y:560,t:1528143604385};\\\", \\\"{x:838,y:559,t:1528143604399};\\\", \\\"{x:847,y:555,t:1528143604416};\\\", \\\"{x:849,y:553,t:1528143604432};\\\", \\\"{x:850,y:552,t:1528143604450};\\\", \\\"{x:849,y:552,t:1528143604650};\\\", \\\"{x:848,y:552,t:1528143604681};\\\", \\\"{x:846,y:552,t:1528143604690};\\\", \\\"{x:845,y:552,t:1528143604705};\\\", \\\"{x:843,y:552,t:1528143604721};\\\", \\\"{x:840,y:552,t:1528143604953};\\\", \\\"{x:838,y:552,t:1528143604967};\\\", \\\"{x:835,y:554,t:1528143604984};\\\", \\\"{x:832,y:555,t:1528143605000};\\\", \\\"{x:831,y:556,t:1528143605041};\\\", \\\"{x:839,y:556,t:1528143605290};\\\", \\\"{x:852,y:555,t:1528143605301};\\\", \\\"{x:877,y:555,t:1528143605318};\\\", \\\"{x:905,y:555,t:1528143605333};\\\", \\\"{x:947,y:555,t:1528143605349};\\\", \\\"{x:997,y:555,t:1528143605367};\\\", \\\"{x:1053,y:555,t:1528143605384};\\\", \\\"{x:1163,y:551,t:1528143605401};\\\", \\\"{x:1220,y:547,t:1528143605417};\\\", \\\"{x:1259,y:547,t:1528143605434};\\\", \\\"{x:1281,y:547,t:1528143605449};\\\", \\\"{x:1299,y:547,t:1528143605467};\\\", \\\"{x:1308,y:547,t:1528143605484};\\\", \\\"{x:1315,y:547,t:1528143605501};\\\", \\\"{x:1319,y:547,t:1528143605517};\\\", \\\"{x:1320,y:547,t:1528143605658};\\\", \\\"{x:1323,y:547,t:1528143605668};\\\", \\\"{x:1329,y:547,t:1528143605684};\\\", \\\"{x:1347,y:546,t:1528143605701};\\\", \\\"{x:1366,y:546,t:1528143605717};\\\", \\\"{x:1381,y:547,t:1528143605735};\\\", \\\"{x:1397,y:553,t:1528143605751};\\\", \\\"{x:1417,y:559,t:1528143605767};\\\", \\\"{x:1430,y:565,t:1528143605785};\\\", \\\"{x:1450,y:577,t:1528143605801};\\\", \\\"{x:1457,y:580,t:1528143605817};\\\", \\\"{x:1459,y:582,t:1528143605835};\\\", \\\"{x:1461,y:583,t:1528143605906};\\\", \\\"{x:1462,y:585,t:1528143605918};\\\", \\\"{x:1467,y:594,t:1528143605934};\\\", \\\"{x:1474,y:608,t:1528143605951};\\\", \\\"{x:1480,y:624,t:1528143605968};\\\", \\\"{x:1490,y:639,t:1528143605985};\\\", \\\"{x:1500,y:654,t:1528143606002};\\\", \\\"{x:1506,y:663,t:1528143606018};\\\", \\\"{x:1518,y:676,t:1528143606034};\\\", \\\"{x:1528,y:683,t:1528143606051};\\\", \\\"{x:1535,y:687,t:1528143606068};\\\", \\\"{x:1540,y:689,t:1528143606084};\\\", \\\"{x:1543,y:689,t:1528143606102};\\\", \\\"{x:1545,y:689,t:1528143606118};\\\", \\\"{x:1546,y:689,t:1528143606135};\\\", \\\"{x:1549,y:687,t:1528143606152};\\\", \\\"{x:1550,y:685,t:1528143606168};\\\", \\\"{x:1552,y:681,t:1528143606185};\\\", \\\"{x:1554,y:677,t:1528143606201};\\\", \\\"{x:1555,y:674,t:1528143606218};\\\", \\\"{x:1555,y:670,t:1528143606235};\\\", \\\"{x:1555,y:669,t:1528143606257};\\\", \\\"{x:1555,y:668,t:1528143606269};\\\", \\\"{x:1555,y:666,t:1528143606285};\\\", \\\"{x:1555,y:663,t:1528143606301};\\\", \\\"{x:1555,y:659,t:1528143606318};\\\", \\\"{x:1555,y:654,t:1528143606334};\\\", \\\"{x:1556,y:649,t:1528143606352};\\\", \\\"{x:1556,y:645,t:1528143606369};\\\", \\\"{x:1556,y:641,t:1528143606384};\\\", \\\"{x:1557,y:636,t:1528143606402};\\\", \\\"{x:1557,y:635,t:1528143606418};\\\", \\\"{x:1557,y:639,t:1528143606544};\\\", \\\"{x:1557,y:643,t:1528143606553};\\\", \\\"{x:1557,y:647,t:1528143606568};\\\", \\\"{x:1557,y:657,t:1528143606584};\\\", \\\"{x:1557,y:679,t:1528143606600};\\\", \\\"{x:1558,y:695,t:1528143606618};\\\", \\\"{x:1562,y:706,t:1528143606634};\\\", \\\"{x:1566,y:719,t:1528143606651};\\\", \\\"{x:1572,y:732,t:1528143606669};\\\", \\\"{x:1575,y:746,t:1528143606684};\\\", \\\"{x:1578,y:758,t:1528143606701};\\\", \\\"{x:1581,y:769,t:1528143606718};\\\", \\\"{x:1583,y:787,t:1528143606734};\\\", \\\"{x:1588,y:807,t:1528143606752};\\\", \\\"{x:1596,y:828,t:1528143606768};\\\", \\\"{x:1604,y:842,t:1528143606784};\\\", \\\"{x:1612,y:860,t:1528143606801};\\\", \\\"{x:1618,y:874,t:1528143606818};\\\", \\\"{x:1620,y:882,t:1528143606834};\\\", \\\"{x:1623,y:888,t:1528143606851};\\\", \\\"{x:1624,y:896,t:1528143606869};\\\", \\\"{x:1625,y:903,t:1528143606885};\\\", \\\"{x:1626,y:909,t:1528143606901};\\\", \\\"{x:1626,y:916,t:1528143606918};\\\", \\\"{x:1624,y:926,t:1528143606936};\\\", \\\"{x:1620,y:937,t:1528143606952};\\\", \\\"{x:1620,y:942,t:1528143606968};\\\", \\\"{x:1617,y:947,t:1528143606985};\\\", \\\"{x:1615,y:951,t:1528143607002};\\\", \\\"{x:1614,y:954,t:1528143607018};\\\", \\\"{x:1613,y:955,t:1528143607035};\\\", \\\"{x:1612,y:957,t:1528143607051};\\\", \\\"{x:1612,y:958,t:1528143607074};\\\", \\\"{x:1612,y:959,t:1528143607202};\\\", \\\"{x:1613,y:960,t:1528143607219};\\\", \\\"{x:1614,y:960,t:1528143607235};\\\", \\\"{x:1613,y:960,t:1528143607450};\\\", \\\"{x:1612,y:960,t:1528143608626};\\\", \\\"{x:1612,y:958,t:1528143608874};\\\", \\\"{x:1612,y:957,t:1528143608906};\\\", \\\"{x:1612,y:956,t:1528143609130};\\\", \\\"{x:1612,y:955,t:1528143609466};\\\", \\\"{x:1614,y:953,t:1528143609474};\\\", \\\"{x:1614,y:951,t:1528143609487};\\\", \\\"{x:1617,y:945,t:1528143609503};\\\", \\\"{x:1619,y:937,t:1528143609520};\\\", \\\"{x:1623,y:929,t:1528143609536};\\\", \\\"{x:1626,y:923,t:1528143609552};\\\", \\\"{x:1629,y:914,t:1528143609569};\\\", \\\"{x:1631,y:908,t:1528143609586};\\\", \\\"{x:1634,y:902,t:1528143609602};\\\", \\\"{x:1636,y:894,t:1528143609620};\\\", \\\"{x:1637,y:888,t:1528143609637};\\\", \\\"{x:1640,y:883,t:1528143609652};\\\", \\\"{x:1641,y:878,t:1528143609670};\\\", \\\"{x:1643,y:873,t:1528143609687};\\\", \\\"{x:1644,y:871,t:1528143609703};\\\", \\\"{x:1645,y:865,t:1528143609719};\\\", \\\"{x:1646,y:862,t:1528143609737};\\\", \\\"{x:1648,y:859,t:1528143609753};\\\", \\\"{x:1649,y:854,t:1528143609769};\\\", \\\"{x:1650,y:852,t:1528143609787};\\\", \\\"{x:1651,y:850,t:1528143609803};\\\", \\\"{x:1653,y:847,t:1528143609820};\\\", \\\"{x:1655,y:843,t:1528143609837};\\\", \\\"{x:1656,y:841,t:1528143609853};\\\", \\\"{x:1657,y:840,t:1528143609870};\\\", \\\"{x:1658,y:839,t:1528143609886};\\\", \\\"{x:1658,y:837,t:1528143609904};\\\", \\\"{x:1659,y:837,t:1528143609920};\\\", \\\"{x:1659,y:836,t:1528143609936};\\\", \\\"{x:1660,y:836,t:1528143609986};\\\", \\\"{x:1663,y:834,t:1528143610004};\\\", \\\"{x:1663,y:833,t:1528143610019};\\\", \\\"{x:1664,y:832,t:1528143610036};\\\", \\\"{x:1666,y:832,t:1528143610054};\\\", \\\"{x:1667,y:831,t:1528143610070};\\\", \\\"{x:1668,y:830,t:1528143610090};\\\", \\\"{x:1669,y:830,t:1528143610105};\\\", \\\"{x:1670,y:830,t:1528143610119};\\\", \\\"{x:1671,y:829,t:1528143610137};\\\", \\\"{x:1673,y:828,t:1528143610154};\\\", \\\"{x:1675,y:828,t:1528143610170};\\\", \\\"{x:1676,y:827,t:1528143610187};\\\", \\\"{x:1677,y:827,t:1528143610203};\\\", \\\"{x:1679,y:826,t:1528143610219};\\\", \\\"{x:1680,y:826,t:1528143610240};\\\", \\\"{x:1681,y:825,t:1528143610256};\\\", \\\"{x:1684,y:825,t:1528143610714};\\\", \\\"{x:1691,y:831,t:1528143610722};\\\", \\\"{x:1698,y:836,t:1528143610736};\\\", \\\"{x:1708,y:853,t:1528143610754};\\\", \\\"{x:1712,y:860,t:1528143610770};\\\", \\\"{x:1717,y:870,t:1528143610786};\\\", \\\"{x:1721,y:877,t:1528143610804};\\\", \\\"{x:1722,y:881,t:1528143610821};\\\", \\\"{x:1724,y:888,t:1528143610837};\\\", \\\"{x:1724,y:890,t:1528143610854};\\\", \\\"{x:1725,y:893,t:1528143610870};\\\", \\\"{x:1726,y:894,t:1528143610886};\\\", \\\"{x:1726,y:896,t:1528143610904};\\\", \\\"{x:1727,y:899,t:1528143610921};\\\", \\\"{x:1729,y:903,t:1528143610937};\\\", \\\"{x:1734,y:914,t:1528143610954};\\\", \\\"{x:1741,y:926,t:1528143610971};\\\", \\\"{x:1744,y:934,t:1528143610987};\\\", \\\"{x:1748,y:943,t:1528143611004};\\\", \\\"{x:1753,y:949,t:1528143611020};\\\", \\\"{x:1755,y:953,t:1528143611036};\\\", \\\"{x:1755,y:954,t:1528143611054};\\\", \\\"{x:1756,y:956,t:1528143611071};\\\", \\\"{x:1754,y:956,t:1528143611248};\\\", \\\"{x:1753,y:951,t:1528143611256};\\\", \\\"{x:1753,y:947,t:1528143611270};\\\", \\\"{x:1742,y:927,t:1528143611286};\\\", \\\"{x:1731,y:901,t:1528143611303};\\\", \\\"{x:1719,y:875,t:1528143611320};\\\", \\\"{x:1707,y:850,t:1528143611336};\\\", \\\"{x:1703,y:844,t:1528143611352};\\\", \\\"{x:1700,y:837,t:1528143611370};\\\", \\\"{x:1699,y:833,t:1528143611387};\\\", \\\"{x:1697,y:830,t:1528143611403};\\\", \\\"{x:1697,y:827,t:1528143611420};\\\", \\\"{x:1696,y:827,t:1528143611437};\\\", \\\"{x:1695,y:826,t:1528143611453};\\\", \\\"{x:1695,y:825,t:1528143611489};\\\", \\\"{x:1694,y:823,t:1528143611505};\\\", \\\"{x:1693,y:823,t:1528143611520};\\\", \\\"{x:1690,y:820,t:1528143611537};\\\", \\\"{x:1690,y:819,t:1528143611553};\\\", \\\"{x:1688,y:816,t:1528143611570};\\\", \\\"{x:1686,y:814,t:1528143611587};\\\", \\\"{x:1684,y:812,t:1528143611609};\\\", \\\"{x:1682,y:810,t:1528143611625};\\\", \\\"{x:1681,y:810,t:1528143611649};\\\", \\\"{x:1680,y:809,t:1528143611665};\\\", \\\"{x:1678,y:809,t:1528143611817};\\\", \\\"{x:1677,y:809,t:1528143611824};\\\", \\\"{x:1673,y:812,t:1528143611837};\\\", \\\"{x:1663,y:823,t:1528143611853};\\\", \\\"{x:1655,y:831,t:1528143611870};\\\", \\\"{x:1648,y:840,t:1528143611887};\\\", \\\"{x:1642,y:847,t:1528143611903};\\\", \\\"{x:1635,y:856,t:1528143611920};\\\", \\\"{x:1618,y:872,t:1528143611937};\\\", \\\"{x:1610,y:880,t:1528143611954};\\\", \\\"{x:1603,y:886,t:1528143611970};\\\", \\\"{x:1600,y:892,t:1528143611988};\\\", \\\"{x:1596,y:899,t:1528143612004};\\\", \\\"{x:1595,y:903,t:1528143612020};\\\", \\\"{x:1594,y:906,t:1528143612038};\\\", \\\"{x:1593,y:908,t:1528143612053};\\\", \\\"{x:1592,y:911,t:1528143612070};\\\", \\\"{x:1592,y:912,t:1528143612087};\\\", \\\"{x:1592,y:914,t:1528143612104};\\\", \\\"{x:1592,y:917,t:1528143612120};\\\", \\\"{x:1590,y:923,t:1528143612137};\\\", \\\"{x:1590,y:926,t:1528143612154};\\\", \\\"{x:1589,y:930,t:1528143612170};\\\", \\\"{x:1589,y:931,t:1528143612187};\\\", \\\"{x:1589,y:933,t:1528143612204};\\\", \\\"{x:1589,y:934,t:1528143612257};\\\", \\\"{x:1589,y:935,t:1528143612369};\\\", \\\"{x:1590,y:935,t:1528143612376};\\\", \\\"{x:1590,y:936,t:1528143612387};\\\", \\\"{x:1593,y:939,t:1528143612404};\\\", \\\"{x:1597,y:942,t:1528143612420};\\\", \\\"{x:1599,y:942,t:1528143612437};\\\", \\\"{x:1600,y:943,t:1528143612454};\\\", \\\"{x:1601,y:944,t:1528143612470};\\\", \\\"{x:1603,y:944,t:1528143612488};\\\", \\\"{x:1604,y:945,t:1528143612505};\\\", \\\"{x:1605,y:945,t:1528143612545};\\\", \\\"{x:1606,y:945,t:1528143612555};\\\", \\\"{x:1607,y:945,t:1528143612578};\\\", \\\"{x:1608,y:947,t:1528143612588};\\\", \\\"{x:1610,y:948,t:1528143612617};\\\", \\\"{x:1611,y:948,t:1528143612658};\\\", \\\"{x:1612,y:948,t:1528143612670};\\\", \\\"{x:1614,y:949,t:1528143612688};\\\", \\\"{x:1616,y:950,t:1528143612705};\\\", \\\"{x:1617,y:950,t:1528143612729};\\\", \\\"{x:1618,y:951,t:1528143612738};\\\", \\\"{x:1619,y:951,t:1528143612850};\\\", \\\"{x:1620,y:951,t:1528143612866};\\\", \\\"{x:1622,y:952,t:1528143612881};\\\", \\\"{x:1623,y:953,t:1528143612906};\\\", \\\"{x:1624,y:953,t:1528143612921};\\\", \\\"{x:1625,y:954,t:1528143612937};\\\", \\\"{x:1627,y:953,t:1528143614898};\\\", \\\"{x:1628,y:948,t:1528143614906};\\\", \\\"{x:1629,y:943,t:1528143614923};\\\", \\\"{x:1630,y:939,t:1528143614938};\\\", \\\"{x:1631,y:938,t:1528143614984};\\\", \\\"{x:1631,y:937,t:1528143615442};\\\", \\\"{x:1631,y:936,t:1528143615456};\\\", \\\"{x:1631,y:934,t:1528143615473};\\\", \\\"{x:1631,y:932,t:1528143615489};\\\", \\\"{x:1631,y:930,t:1528143615505};\\\", \\\"{x:1632,y:928,t:1528143615523};\\\", \\\"{x:1633,y:925,t:1528143615539};\\\", \\\"{x:1633,y:921,t:1528143615556};\\\", \\\"{x:1634,y:918,t:1528143615572};\\\", \\\"{x:1636,y:914,t:1528143615589};\\\", \\\"{x:1637,y:910,t:1528143615606};\\\", \\\"{x:1638,y:904,t:1528143615622};\\\", \\\"{x:1639,y:901,t:1528143615639};\\\", \\\"{x:1640,y:897,t:1528143615656};\\\", \\\"{x:1640,y:896,t:1528143615673};\\\", \\\"{x:1647,y:896,t:1528143616954};\\\", \\\"{x:1648,y:897,t:1528143616962};\\\", \\\"{x:1651,y:898,t:1528143616973};\\\", \\\"{x:1659,y:901,t:1528143616990};\\\", \\\"{x:1667,y:904,t:1528143617007};\\\", \\\"{x:1675,y:908,t:1528143617023};\\\", \\\"{x:1691,y:915,t:1528143617040};\\\", \\\"{x:1700,y:917,t:1528143617057};\\\", \\\"{x:1705,y:919,t:1528143617073};\\\", \\\"{x:1709,y:919,t:1528143617090};\\\", \\\"{x:1710,y:919,t:1528143617107};\\\", \\\"{x:1709,y:921,t:1528143617193};\\\", \\\"{x:1706,y:923,t:1528143617206};\\\", \\\"{x:1703,y:923,t:1528143617223};\\\", \\\"{x:1700,y:924,t:1528143617240};\\\", \\\"{x:1698,y:924,t:1528143617257};\\\", \\\"{x:1694,y:924,t:1528143617273};\\\", \\\"{x:1692,y:923,t:1528143617290};\\\", \\\"{x:1686,y:921,t:1528143617307};\\\", \\\"{x:1682,y:919,t:1528143617323};\\\", \\\"{x:1678,y:918,t:1528143617339};\\\", \\\"{x:1674,y:916,t:1528143617356};\\\", \\\"{x:1670,y:915,t:1528143617373};\\\", \\\"{x:1667,y:914,t:1528143617390};\\\", \\\"{x:1663,y:912,t:1528143617406};\\\", \\\"{x:1662,y:911,t:1528143617424};\\\", \\\"{x:1659,y:910,t:1528143617439};\\\", \\\"{x:1654,y:909,t:1528143617457};\\\", \\\"{x:1639,y:909,t:1528143617474};\\\", \\\"{x:1634,y:909,t:1528143617490};\\\", \\\"{x:1631,y:909,t:1528143617506};\\\", \\\"{x:1626,y:912,t:1528143617524};\\\", \\\"{x:1622,y:916,t:1528143617540};\\\", \\\"{x:1619,y:919,t:1528143617557};\\\", \\\"{x:1616,y:922,t:1528143617574};\\\", \\\"{x:1614,y:924,t:1528143617590};\\\", \\\"{x:1613,y:925,t:1528143617607};\\\", \\\"{x:1611,y:930,t:1528143617624};\\\", \\\"{x:1609,y:932,t:1528143617640};\\\", \\\"{x:1608,y:934,t:1528143617656};\\\", \\\"{x:1608,y:935,t:1528143617673};\\\", \\\"{x:1608,y:936,t:1528143617720};\\\", \\\"{x:1608,y:937,t:1528143617728};\\\", \\\"{x:1608,y:938,t:1528143617739};\\\", \\\"{x:1610,y:940,t:1528143617757};\\\", \\\"{x:1610,y:941,t:1528143617774};\\\", \\\"{x:1611,y:942,t:1528143617789};\\\", \\\"{x:1611,y:943,t:1528143617807};\\\", \\\"{x:1611,y:945,t:1528143617824};\\\", \\\"{x:1609,y:945,t:1528143617914};\\\", \\\"{x:1601,y:945,t:1528143617924};\\\", \\\"{x:1570,y:937,t:1528143617940};\\\", \\\"{x:1494,y:912,t:1528143617957};\\\", \\\"{x:1394,y:880,t:1528143617974};\\\", \\\"{x:1267,y:846,t:1528143617990};\\\", \\\"{x:1138,y:796,t:1528143618007};\\\", \\\"{x:1011,y:743,t:1528143618024};\\\", \\\"{x:877,y:688,t:1528143618041};\\\", \\\"{x:779,y:659,t:1528143618057};\\\", \\\"{x:737,y:650,t:1528143618073};\\\", \\\"{x:733,y:650,t:1528143618090};\\\", \\\"{x:732,y:650,t:1528143618106};\\\", \\\"{x:726,y:650,t:1528143618249};\\\", \\\"{x:710,y:658,t:1528143618257};\\\", \\\"{x:667,y:683,t:1528143618274};\\\", \\\"{x:624,y:707,t:1528143618291};\\\", \\\"{x:591,y:726,t:1528143618306};\\\", \\\"{x:565,y:738,t:1528143618324};\\\", \\\"{x:547,y:742,t:1528143618341};\\\", \\\"{x:539,y:742,t:1528143618357};\\\", \\\"{x:534,y:742,t:1528143618374};\\\", \\\"{x:526,y:738,t:1528143618391};\\\", \\\"{x:522,y:737,t:1528143618407};\\\", \\\"{x:514,y:734,t:1528143618425};\\\", \\\"{x:512,y:733,t:1528143618440};\\\", \\\"{x:511,y:733,t:1528143618456};\\\", \\\"{x:510,y:732,t:1528143618496};\\\", \\\"{x:510,y:731,t:1528143618552};\\\", \\\"{x:509,y:730,t:1528143618568};\\\", \\\"{x:508,y:730,t:1528143618584};\\\", \\\"{x:507,y:729,t:1528143618593};\\\", \\\"{x:507,y:728,t:1528143618689};\\\", \\\"{x:507,y:728,t:1528143618705};\\\" ] }, { \\\"rt\\\": 18745, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 479907, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -K -K -K -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:727,t:1528143622306};\\\", \\\"{x:506,y:726,t:1528143628537};\\\", \\\"{x:508,y:725,t:1528143628552};\\\", \\\"{x:514,y:725,t:1528143628561};\\\", \\\"{x:528,y:726,t:1528143628578};\\\", \\\"{x:545,y:732,t:1528143628594};\\\", \\\"{x:581,y:740,t:1528143628611};\\\", \\\"{x:624,y:747,t:1528143628628};\\\", \\\"{x:666,y:752,t:1528143628645};\\\", \\\"{x:710,y:758,t:1528143628669};\\\", \\\"{x:730,y:763,t:1528143628686};\\\", \\\"{x:751,y:764,t:1528143628703};\\\", \\\"{x:768,y:768,t:1528143628720};\\\", \\\"{x:787,y:772,t:1528143628736};\\\", \\\"{x:815,y:780,t:1528143628753};\\\", \\\"{x:832,y:785,t:1528143628769};\\\", \\\"{x:849,y:786,t:1528143628785};\\\", \\\"{x:870,y:792,t:1528143628803};\\\", \\\"{x:889,y:794,t:1528143628820};\\\", \\\"{x:910,y:797,t:1528143628837};\\\", \\\"{x:935,y:800,t:1528143628853};\\\", \\\"{x:960,y:803,t:1528143628870};\\\", \\\"{x:988,y:803,t:1528143628886};\\\", \\\"{x:1012,y:803,t:1528143628902};\\\", \\\"{x:1035,y:803,t:1528143628920};\\\", \\\"{x:1064,y:803,t:1528143628937};\\\", \\\"{x:1082,y:806,t:1528143628953};\\\", \\\"{x:1096,y:807,t:1528143628970};\\\", \\\"{x:1110,y:808,t:1528143628987};\\\", \\\"{x:1127,y:809,t:1528143629004};\\\", \\\"{x:1141,y:810,t:1528143629020};\\\", \\\"{x:1163,y:813,t:1528143629037};\\\", \\\"{x:1185,y:813,t:1528143629053};\\\", \\\"{x:1212,y:813,t:1528143629071};\\\", \\\"{x:1235,y:813,t:1528143629089};\\\", \\\"{x:1254,y:813,t:1528143629104};\\\", \\\"{x:1272,y:813,t:1528143629120};\\\", \\\"{x:1298,y:813,t:1528143629137};\\\", \\\"{x:1322,y:813,t:1528143629163};\\\", \\\"{x:1330,y:813,t:1528143629169};\\\", \\\"{x:1342,y:813,t:1528143629186};\\\", \\\"{x:1357,y:813,t:1528143629203};\\\", \\\"{x:1369,y:813,t:1528143629220};\\\", \\\"{x:1376,y:813,t:1528143629237};\\\", \\\"{x:1382,y:813,t:1528143629254};\\\", \\\"{x:1384,y:813,t:1528143629270};\\\", \\\"{x:1385,y:813,t:1528143629287};\\\", \\\"{x:1387,y:813,t:1528143629458};\\\", \\\"{x:1387,y:812,t:1528143629470};\\\", \\\"{x:1387,y:808,t:1528143629488};\\\", \\\"{x:1387,y:804,t:1528143629504};\\\", \\\"{x:1387,y:801,t:1528143629521};\\\", \\\"{x:1387,y:798,t:1528143629537};\\\", \\\"{x:1387,y:796,t:1528143629554};\\\", \\\"{x:1387,y:794,t:1528143629571};\\\", \\\"{x:1387,y:792,t:1528143629588};\\\", \\\"{x:1387,y:790,t:1528143629604};\\\", \\\"{x:1387,y:786,t:1528143629620};\\\", \\\"{x:1389,y:783,t:1528143629638};\\\", \\\"{x:1391,y:775,t:1528143629654};\\\", \\\"{x:1394,y:767,t:1528143629670};\\\", \\\"{x:1400,y:759,t:1528143629687};\\\", \\\"{x:1407,y:750,t:1528143629704};\\\", \\\"{x:1416,y:742,t:1528143629726};\\\", \\\"{x:1423,y:736,t:1528143629736};\\\", \\\"{x:1428,y:732,t:1528143629754};\\\", \\\"{x:1432,y:731,t:1528143629771};\\\", \\\"{x:1435,y:729,t:1528143629786};\\\", \\\"{x:1442,y:724,t:1528143629804};\\\", \\\"{x:1448,y:718,t:1528143629821};\\\", \\\"{x:1453,y:712,t:1528143629837};\\\", \\\"{x:1457,y:707,t:1528143629854};\\\", \\\"{x:1462,y:700,t:1528143629871};\\\", \\\"{x:1467,y:694,t:1528143629887};\\\", \\\"{x:1470,y:687,t:1528143629904};\\\", \\\"{x:1473,y:679,t:1528143629921};\\\", \\\"{x:1474,y:675,t:1528143629937};\\\", \\\"{x:1474,y:673,t:1528143629954};\\\", \\\"{x:1475,y:672,t:1528143630034};\\\", \\\"{x:1476,y:670,t:1528143630041};\\\", \\\"{x:1476,y:669,t:1528143630054};\\\", \\\"{x:1479,y:666,t:1528143630071};\\\", \\\"{x:1484,y:659,t:1528143630089};\\\", \\\"{x:1490,y:650,t:1528143630104};\\\", \\\"{x:1502,y:636,t:1528143630121};\\\", \\\"{x:1510,y:627,t:1528143630140};\\\", \\\"{x:1513,y:622,t:1528143630154};\\\", \\\"{x:1517,y:619,t:1528143630171};\\\", \\\"{x:1518,y:617,t:1528143630188};\\\", \\\"{x:1519,y:616,t:1528143630204};\\\", \\\"{x:1520,y:615,t:1528143630386};\\\", \\\"{x:1521,y:614,t:1528143630394};\\\", \\\"{x:1523,y:614,t:1528143630405};\\\", \\\"{x:1526,y:612,t:1528143630422};\\\", \\\"{x:1526,y:611,t:1528143630439};\\\", \\\"{x:1528,y:610,t:1528143630455};\\\", \\\"{x:1529,y:610,t:1528143630666};\\\", \\\"{x:1527,y:611,t:1528143631153};\\\", \\\"{x:1521,y:614,t:1528143631162};\\\", \\\"{x:1516,y:618,t:1528143631172};\\\", \\\"{x:1507,y:624,t:1528143631189};\\\", \\\"{x:1501,y:628,t:1528143631205};\\\", \\\"{x:1494,y:634,t:1528143631223};\\\", \\\"{x:1489,y:638,t:1528143631239};\\\", \\\"{x:1485,y:642,t:1528143631256};\\\", \\\"{x:1482,y:645,t:1528143631272};\\\", \\\"{x:1478,y:649,t:1528143631289};\\\", \\\"{x:1476,y:651,t:1528143631305};\\\", \\\"{x:1476,y:652,t:1528143631323};\\\", \\\"{x:1475,y:652,t:1528143631339};\\\", \\\"{x:1475,y:654,t:1528143631356};\\\", \\\"{x:1472,y:656,t:1528143631372};\\\", \\\"{x:1471,y:658,t:1528143631390};\\\", \\\"{x:1468,y:660,t:1528143631406};\\\", \\\"{x:1465,y:663,t:1528143631423};\\\", \\\"{x:1461,y:666,t:1528143631440};\\\", \\\"{x:1459,y:668,t:1528143631456};\\\", \\\"{x:1458,y:669,t:1528143631473};\\\", \\\"{x:1455,y:673,t:1528143631490};\\\", \\\"{x:1454,y:675,t:1528143631506};\\\", \\\"{x:1454,y:676,t:1528143631522};\\\", \\\"{x:1454,y:677,t:1528143631540};\\\", \\\"{x:1454,y:679,t:1528143631555};\\\", \\\"{x:1464,y:683,t:1528143631572};\\\", \\\"{x:1484,y:687,t:1528143631589};\\\", \\\"{x:1509,y:689,t:1528143631605};\\\", \\\"{x:1529,y:691,t:1528143631622};\\\", \\\"{x:1550,y:694,t:1528143631639};\\\", \\\"{x:1569,y:698,t:1528143631655};\\\", \\\"{x:1592,y:702,t:1528143631672};\\\", \\\"{x:1613,y:709,t:1528143631689};\\\", \\\"{x:1627,y:717,t:1528143631706};\\\", \\\"{x:1636,y:723,t:1528143631722};\\\", \\\"{x:1641,y:728,t:1528143631739};\\\", \\\"{x:1643,y:730,t:1528143631756};\\\", \\\"{x:1645,y:728,t:1528143631882};\\\", \\\"{x:1645,y:722,t:1528143631889};\\\", \\\"{x:1646,y:711,t:1528143631907};\\\", \\\"{x:1646,y:695,t:1528143631923};\\\", \\\"{x:1645,y:683,t:1528143631940};\\\", \\\"{x:1642,y:678,t:1528143631957};\\\", \\\"{x:1640,y:675,t:1528143631972};\\\", \\\"{x:1639,y:671,t:1528143631990};\\\", \\\"{x:1637,y:668,t:1528143632006};\\\", \\\"{x:1636,y:665,t:1528143632023};\\\", \\\"{x:1634,y:661,t:1528143632040};\\\", \\\"{x:1634,y:660,t:1528143632057};\\\", \\\"{x:1632,y:655,t:1528143632073};\\\", \\\"{x:1627,y:643,t:1528143632090};\\\", \\\"{x:1622,y:631,t:1528143632107};\\\", \\\"{x:1616,y:619,t:1528143632124};\\\", \\\"{x:1609,y:610,t:1528143632140};\\\", \\\"{x:1596,y:593,t:1528143632156};\\\", \\\"{x:1579,y:579,t:1528143632173};\\\", \\\"{x:1561,y:568,t:1528143632189};\\\", \\\"{x:1544,y:557,t:1528143632206};\\\", \\\"{x:1533,y:549,t:1528143632224};\\\", \\\"{x:1517,y:540,t:1528143632239};\\\", \\\"{x:1507,y:532,t:1528143632257};\\\", \\\"{x:1501,y:525,t:1528143632274};\\\", \\\"{x:1495,y:518,t:1528143632289};\\\", \\\"{x:1495,y:516,t:1528143632307};\\\", \\\"{x:1494,y:513,t:1528143632323};\\\", \\\"{x:1494,y:511,t:1528143632339};\\\", \\\"{x:1491,y:505,t:1528143632356};\\\", \\\"{x:1489,y:498,t:1528143632374};\\\", \\\"{x:1484,y:486,t:1528143632389};\\\", \\\"{x:1478,y:475,t:1528143632406};\\\", \\\"{x:1473,y:469,t:1528143632424};\\\", \\\"{x:1469,y:464,t:1528143632439};\\\", \\\"{x:1468,y:463,t:1528143632457};\\\", \\\"{x:1466,y:463,t:1528143632490};\\\", \\\"{x:1466,y:462,t:1528143632514};\\\", \\\"{x:1465,y:462,t:1528143632523};\\\", \\\"{x:1463,y:461,t:1528143632541};\\\", \\\"{x:1462,y:461,t:1528143632556};\\\", \\\"{x:1458,y:460,t:1528143632574};\\\", \\\"{x:1451,y:457,t:1528143632590};\\\", \\\"{x:1442,y:453,t:1528143632606};\\\", \\\"{x:1436,y:452,t:1528143632624};\\\", \\\"{x:1427,y:449,t:1528143632641};\\\", \\\"{x:1414,y:447,t:1528143632657};\\\", \\\"{x:1396,y:445,t:1528143632674};\\\", \\\"{x:1380,y:445,t:1528143632691};\\\", \\\"{x:1359,y:451,t:1528143632707};\\\", \\\"{x:1339,y:457,t:1528143632724};\\\", \\\"{x:1324,y:462,t:1528143632741};\\\", \\\"{x:1314,y:466,t:1528143632757};\\\", \\\"{x:1310,y:468,t:1528143632773};\\\", \\\"{x:1309,y:468,t:1528143632794};\\\", \\\"{x:1307,y:469,t:1528143632890};\\\", \\\"{x:1306,y:474,t:1528143632908};\\\", \\\"{x:1304,y:478,t:1528143632923};\\\", \\\"{x:1304,y:482,t:1528143632940};\\\", \\\"{x:1304,y:484,t:1528143632957};\\\", \\\"{x:1304,y:486,t:1528143632973};\\\", \\\"{x:1304,y:488,t:1528143632990};\\\", \\\"{x:1304,y:490,t:1528143633009};\\\", \\\"{x:1305,y:491,t:1528143633138};\\\", \\\"{x:1306,y:491,t:1528143633146};\\\", \\\"{x:1307,y:491,t:1528143633169};\\\", \\\"{x:1308,y:492,t:1528143633177};\\\", \\\"{x:1308,y:493,t:1528143633193};\\\", \\\"{x:1309,y:494,t:1528143633210};\\\", \\\"{x:1310,y:496,t:1528143633505};\\\", \\\"{x:1311,y:497,t:1528143633521};\\\", \\\"{x:1312,y:497,t:1528143633537};\\\", \\\"{x:1313,y:497,t:1528143633602};\\\", \\\"{x:1314,y:499,t:1528143633977};\\\", \\\"{x:1314,y:501,t:1528143633992};\\\", \\\"{x:1314,y:506,t:1528143634009};\\\", \\\"{x:1314,y:510,t:1528143634024};\\\", \\\"{x:1314,y:514,t:1528143634041};\\\", \\\"{x:1314,y:515,t:1528143634066};\\\", \\\"{x:1314,y:516,t:1528143634075};\\\", \\\"{x:1314,y:517,t:1528143634170};\\\", \\\"{x:1314,y:518,t:1528143634177};\\\", \\\"{x:1314,y:521,t:1528143634192};\\\", \\\"{x:1314,y:526,t:1528143634209};\\\", \\\"{x:1314,y:532,t:1528143634224};\\\", \\\"{x:1313,y:534,t:1528143634242};\\\", \\\"{x:1312,y:536,t:1528143634259};\\\", \\\"{x:1312,y:538,t:1528143634360};\\\", \\\"{x:1312,y:539,t:1528143634374};\\\", \\\"{x:1312,y:545,t:1528143634392};\\\", \\\"{x:1311,y:551,t:1528143634408};\\\", \\\"{x:1309,y:557,t:1528143634425};\\\", \\\"{x:1308,y:566,t:1528143634442};\\\", \\\"{x:1308,y:573,t:1528143634458};\\\", \\\"{x:1308,y:576,t:1528143634474};\\\", \\\"{x:1308,y:578,t:1528143634491};\\\", \\\"{x:1308,y:579,t:1528143634509};\\\", \\\"{x:1308,y:580,t:1528143634524};\\\", \\\"{x:1308,y:581,t:1528143634593};\\\", \\\"{x:1308,y:582,t:1528143634608};\\\", \\\"{x:1308,y:585,t:1528143634625};\\\", \\\"{x:1306,y:589,t:1528143634641};\\\", \\\"{x:1306,y:591,t:1528143634658};\\\", \\\"{x:1306,y:596,t:1528143634675};\\\", \\\"{x:1306,y:600,t:1528143634691};\\\", \\\"{x:1306,y:604,t:1528143634708};\\\", \\\"{x:1306,y:605,t:1528143634725};\\\", \\\"{x:1306,y:608,t:1528143634742};\\\", \\\"{x:1306,y:609,t:1528143634758};\\\", \\\"{x:1306,y:610,t:1528143634800};\\\", \\\"{x:1306,y:611,t:1528143634841};\\\", \\\"{x:1306,y:614,t:1528143634858};\\\", \\\"{x:1307,y:617,t:1528143634876};\\\", \\\"{x:1307,y:619,t:1528143634892};\\\", \\\"{x:1308,y:623,t:1528143634908};\\\", \\\"{x:1308,y:626,t:1528143634926};\\\", \\\"{x:1308,y:628,t:1528143634943};\\\", \\\"{x:1308,y:631,t:1528143634959};\\\", \\\"{x:1308,y:632,t:1528143634975};\\\", \\\"{x:1309,y:633,t:1528143634993};\\\", \\\"{x:1309,y:634,t:1528143635114};\\\", \\\"{x:1309,y:635,t:1528143635137};\\\", \\\"{x:1309,y:637,t:1528143635145};\\\", \\\"{x:1310,y:640,t:1528143635159};\\\", \\\"{x:1310,y:641,t:1528143635175};\\\", \\\"{x:1310,y:642,t:1528143635193};\\\", \\\"{x:1310,y:643,t:1528143635208};\\\", \\\"{x:1310,y:644,t:1528143635226};\\\", \\\"{x:1310,y:646,t:1528143635361};\\\", \\\"{x:1311,y:649,t:1528143635376};\\\", \\\"{x:1312,y:653,t:1528143635392};\\\", \\\"{x:1312,y:658,t:1528143635409};\\\", \\\"{x:1312,y:662,t:1528143635426};\\\", \\\"{x:1312,y:663,t:1528143635443};\\\", \\\"{x:1312,y:665,t:1528143635460};\\\", \\\"{x:1312,y:666,t:1528143635586};\\\", \\\"{x:1312,y:668,t:1528143635601};\\\", \\\"{x:1312,y:670,t:1528143635609};\\\", \\\"{x:1313,y:673,t:1528143635626};\\\", \\\"{x:1313,y:677,t:1528143635643};\\\", \\\"{x:1314,y:680,t:1528143635660};\\\", \\\"{x:1314,y:684,t:1528143635676};\\\", \\\"{x:1314,y:686,t:1528143635693};\\\", \\\"{x:1313,y:687,t:1528143636001};\\\", \\\"{x:1303,y:683,t:1528143636009};\\\", \\\"{x:1268,y:670,t:1528143636026};\\\", \\\"{x:1211,y:650,t:1528143636043};\\\", \\\"{x:1140,y:632,t:1528143636059};\\\", \\\"{x:1059,y:620,t:1528143636077};\\\", \\\"{x:1003,y:613,t:1528143636093};\\\", \\\"{x:947,y:605,t:1528143636110};\\\", \\\"{x:892,y:597,t:1528143636126};\\\", \\\"{x:846,y:588,t:1528143636143};\\\", \\\"{x:820,y:583,t:1528143636160};\\\", \\\"{x:800,y:582,t:1528143636175};\\\", \\\"{x:783,y:578,t:1528143636191};\\\", \\\"{x:774,y:577,t:1528143636208};\\\", \\\"{x:773,y:577,t:1528143636225};\\\", \\\"{x:771,y:576,t:1528143636242};\\\", \\\"{x:769,y:575,t:1528143636259};\\\", \\\"{x:764,y:574,t:1528143636275};\\\", \\\"{x:755,y:572,t:1528143636292};\\\", \\\"{x:742,y:570,t:1528143636309};\\\", \\\"{x:724,y:569,t:1528143636326};\\\", \\\"{x:695,y:569,t:1528143636343};\\\", \\\"{x:649,y:573,t:1528143636359};\\\", \\\"{x:578,y:589,t:1528143636376};\\\", \\\"{x:473,y:607,t:1528143636393};\\\", \\\"{x:435,y:613,t:1528143636409};\\\", \\\"{x:417,y:616,t:1528143636427};\\\", \\\"{x:407,y:618,t:1528143636442};\\\", \\\"{x:401,y:620,t:1528143636459};\\\", \\\"{x:393,y:623,t:1528143636476};\\\", \\\"{x:388,y:623,t:1528143636493};\\\", \\\"{x:384,y:626,t:1528143636509};\\\", \\\"{x:378,y:627,t:1528143636527};\\\", \\\"{x:374,y:627,t:1528143636542};\\\", \\\"{x:367,y:628,t:1528143636559};\\\", \\\"{x:353,y:631,t:1528143636576};\\\", \\\"{x:321,y:637,t:1528143636594};\\\", \\\"{x:302,y:637,t:1528143636609};\\\", \\\"{x:293,y:637,t:1528143636626};\\\", \\\"{x:289,y:637,t:1528143636643};\\\", \\\"{x:288,y:637,t:1528143636729};\\\", \\\"{x:288,y:636,t:1528143636743};\\\", \\\"{x:289,y:632,t:1528143636760};\\\", \\\"{x:289,y:630,t:1528143636776};\\\", \\\"{x:288,y:629,t:1528143636825};\\\", \\\"{x:286,y:629,t:1528143636841};\\\", \\\"{x:282,y:627,t:1528143636857};\\\", \\\"{x:279,y:626,t:1528143636875};\\\", \\\"{x:268,y:621,t:1528143636894};\\\", \\\"{x:252,y:615,t:1528143636909};\\\", \\\"{x:234,y:606,t:1528143636926};\\\", \\\"{x:220,y:599,t:1528143636943};\\\", \\\"{x:210,y:594,t:1528143636960};\\\", \\\"{x:197,y:584,t:1528143636977};\\\", \\\"{x:186,y:576,t:1528143636993};\\\", \\\"{x:184,y:571,t:1528143637011};\\\", \\\"{x:183,y:570,t:1528143637026};\\\", \\\"{x:183,y:568,t:1528143637049};\\\", \\\"{x:183,y:567,t:1528143637059};\\\", \\\"{x:183,y:565,t:1528143637089};\\\", \\\"{x:184,y:563,t:1528143637097};\\\", \\\"{x:186,y:562,t:1528143637110};\\\", \\\"{x:199,y:556,t:1528143637127};\\\", \\\"{x:225,y:546,t:1528143637145};\\\", \\\"{x:254,y:538,t:1528143637160};\\\", \\\"{x:332,y:522,t:1528143637177};\\\", \\\"{x:415,y:513,t:1528143637194};\\\", \\\"{x:488,y:509,t:1528143637210};\\\", \\\"{x:536,y:509,t:1528143637226};\\\", \\\"{x:586,y:509,t:1528143637243};\\\", \\\"{x:621,y:512,t:1528143637260};\\\", \\\"{x:647,y:518,t:1528143637278};\\\", \\\"{x:666,y:521,t:1528143637293};\\\", \\\"{x:682,y:527,t:1528143637310};\\\", \\\"{x:688,y:528,t:1528143637327};\\\", \\\"{x:691,y:529,t:1528143637343};\\\", \\\"{x:693,y:530,t:1528143637361};\\\", \\\"{x:696,y:531,t:1528143637376};\\\", \\\"{x:697,y:531,t:1528143637393};\\\", \\\"{x:698,y:531,t:1528143637411};\\\", \\\"{x:699,y:531,t:1528143637427};\\\", \\\"{x:700,y:531,t:1528143637443};\\\", \\\"{x:708,y:533,t:1528143637460};\\\", \\\"{x:719,y:533,t:1528143637478};\\\", \\\"{x:733,y:533,t:1528143637495};\\\", \\\"{x:749,y:533,t:1528143637510};\\\", \\\"{x:762,y:533,t:1528143637527};\\\", \\\"{x:769,y:533,t:1528143637543};\\\", \\\"{x:781,y:533,t:1528143637560};\\\", \\\"{x:787,y:533,t:1528143637576};\\\", \\\"{x:790,y:534,t:1528143637593};\\\", \\\"{x:795,y:534,t:1528143637610};\\\", \\\"{x:803,y:534,t:1528143637627};\\\", \\\"{x:811,y:534,t:1528143637643};\\\", \\\"{x:818,y:534,t:1528143637660};\\\", \\\"{x:822,y:534,t:1528143637677};\\\", \\\"{x:825,y:534,t:1528143637694};\\\", \\\"{x:827,y:534,t:1528143637710};\\\", \\\"{x:829,y:534,t:1528143637727};\\\", \\\"{x:832,y:534,t:1528143637743};\\\", \\\"{x:838,y:534,t:1528143637761};\\\", \\\"{x:834,y:534,t:1528143638008};\\\", \\\"{x:821,y:541,t:1528143638017};\\\", \\\"{x:808,y:547,t:1528143638027};\\\", \\\"{x:792,y:557,t:1528143638044};\\\", \\\"{x:772,y:569,t:1528143638060};\\\", \\\"{x:738,y:587,t:1528143638077};\\\", \\\"{x:717,y:598,t:1528143638095};\\\", \\\"{x:700,y:606,t:1528143638110};\\\", \\\"{x:694,y:610,t:1528143638127};\\\", \\\"{x:686,y:614,t:1528143638144};\\\", \\\"{x:683,y:615,t:1528143638160};\\\", \\\"{x:675,y:620,t:1528143638177};\\\", \\\"{x:666,y:626,t:1528143638194};\\\", \\\"{x:651,y:632,t:1528143638210};\\\", \\\"{x:641,y:637,t:1528143638228};\\\", \\\"{x:631,y:641,t:1528143638244};\\\", \\\"{x:617,y:647,t:1528143638261};\\\", \\\"{x:606,y:653,t:1528143638277};\\\", \\\"{x:598,y:657,t:1528143638295};\\\", \\\"{x:584,y:665,t:1528143638312};\\\", \\\"{x:568,y:676,t:1528143638327};\\\", \\\"{x:551,y:694,t:1528143638344};\\\", \\\"{x:547,y:699,t:1528143638360};\\\", \\\"{x:547,y:701,t:1528143638377};\\\", \\\"{x:543,y:706,t:1528143638395};\\\", \\\"{x:542,y:708,t:1528143638412};\\\", \\\"{x:540,y:709,t:1528143638428};\\\", \\\"{x:539,y:710,t:1528143638473};\\\", \\\"{x:539,y:711,t:1528143638481};\\\", \\\"{x:538,y:711,t:1528143638494};\\\", \\\"{x:534,y:712,t:1528143638511};\\\", \\\"{x:531,y:715,t:1528143638529};\\\", \\\"{x:527,y:717,t:1528143638544};\\\", \\\"{x:522,y:723,t:1528143638561};\\\", \\\"{x:517,y:729,t:1528143638577};\\\", \\\"{x:514,y:732,t:1528143638595};\\\", \\\"{x:514,y:733,t:1528143638612};\\\" ] }, { \\\"rt\\\": 11068, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 492226, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:733,t:1528143640484};\\\", \\\"{x:512,y:732,t:1528143640500};\\\", \\\"{x:511,y:731,t:1528143640516};\\\", \\\"{x:511,y:730,t:1528143640533};\\\", \\\"{x:510,y:730,t:1528143640580};\\\", \\\"{x:510,y:726,t:1528143641317};\\\", \\\"{x:508,y:723,t:1528143641336};\\\", \\\"{x:506,y:718,t:1528143641353};\\\", \\\"{x:497,y:709,t:1528143641368};\\\", \\\"{x:479,y:697,t:1528143641385};\\\", \\\"{x:460,y:676,t:1528143641400};\\\", \\\"{x:458,y:670,t:1528143641417};\\\", \\\"{x:458,y:669,t:1528143641959};\\\", \\\"{x:459,y:671,t:1528143642044};\\\", \\\"{x:460,y:672,t:1528143642052};\\\", \\\"{x:468,y:674,t:1528143642067};\\\", \\\"{x:493,y:679,t:1528143642084};\\\", \\\"{x:510,y:680,t:1528143642101};\\\", \\\"{x:534,y:681,t:1528143642117};\\\", \\\"{x:559,y:683,t:1528143642134};\\\", \\\"{x:579,y:683,t:1528143642152};\\\", \\\"{x:597,y:683,t:1528143642168};\\\", \\\"{x:612,y:683,t:1528143642185};\\\", \\\"{x:622,y:683,t:1528143642202};\\\", \\\"{x:629,y:681,t:1528143642218};\\\", \\\"{x:634,y:681,t:1528143642234};\\\", \\\"{x:642,y:680,t:1528143642252};\\\", \\\"{x:648,y:680,t:1528143642268};\\\", \\\"{x:663,y:680,t:1528143642285};\\\", \\\"{x:677,y:680,t:1528143642302};\\\", \\\"{x:690,y:680,t:1528143642319};\\\", \\\"{x:705,y:680,t:1528143642335};\\\", \\\"{x:720,y:680,t:1528143642351};\\\", \\\"{x:738,y:680,t:1528143642369};\\\", \\\"{x:751,y:680,t:1528143642385};\\\", \\\"{x:763,y:678,t:1528143642401};\\\", \\\"{x:778,y:675,t:1528143642418};\\\", \\\"{x:792,y:674,t:1528143642434};\\\", \\\"{x:807,y:671,t:1528143642451};\\\", \\\"{x:843,y:662,t:1528143642468};\\\", \\\"{x:863,y:659,t:1528143642484};\\\", \\\"{x:877,y:658,t:1528143642501};\\\", \\\"{x:894,y:654,t:1528143642519};\\\", \\\"{x:907,y:652,t:1528143642534};\\\", \\\"{x:921,y:647,t:1528143642551};\\\", \\\"{x:934,y:644,t:1528143642568};\\\", \\\"{x:950,y:639,t:1528143642584};\\\", \\\"{x:969,y:630,t:1528143642602};\\\", \\\"{x:985,y:623,t:1528143642619};\\\", \\\"{x:1000,y:615,t:1528143642635};\\\", \\\"{x:1017,y:604,t:1528143642652};\\\", \\\"{x:1047,y:587,t:1528143642668};\\\", \\\"{x:1074,y:572,t:1528143642685};\\\", \\\"{x:1097,y:557,t:1528143642701};\\\", \\\"{x:1116,y:547,t:1528143642719};\\\", \\\"{x:1130,y:535,t:1528143642735};\\\", \\\"{x:1140,y:527,t:1528143642752};\\\", \\\"{x:1143,y:520,t:1528143642769};\\\", \\\"{x:1147,y:512,t:1528143642786};\\\", \\\"{x:1147,y:506,t:1528143642802};\\\", \\\"{x:1148,y:497,t:1528143642818};\\\", \\\"{x:1148,y:490,t:1528143642836};\\\", \\\"{x:1148,y:480,t:1528143642852};\\\", \\\"{x:1148,y:462,t:1528143642869};\\\", \\\"{x:1148,y:449,t:1528143642885};\\\", \\\"{x:1143,y:435,t:1528143642901};\\\", \\\"{x:1138,y:427,t:1528143642919};\\\", \\\"{x:1134,y:420,t:1528143642936};\\\", \\\"{x:1131,y:416,t:1528143642952};\\\", \\\"{x:1129,y:414,t:1528143642968};\\\", \\\"{x:1126,y:413,t:1528143642986};\\\", \\\"{x:1124,y:412,t:1528143643005};\\\", \\\"{x:1123,y:411,t:1528143643102};\\\", \\\"{x:1120,y:410,t:1528143643119};\\\", \\\"{x:1116,y:408,t:1528143643136};\\\", \\\"{x:1111,y:407,t:1528143643152};\\\", \\\"{x:1108,y:406,t:1528143643169};\\\", \\\"{x:1106,y:404,t:1528143643186};\\\", \\\"{x:1104,y:403,t:1528143643203};\\\", \\\"{x:1103,y:402,t:1528143643219};\\\", \\\"{x:1101,y:402,t:1528143643236};\\\", \\\"{x:1101,y:399,t:1528143643300};\\\", \\\"{x:1101,y:395,t:1528143643309};\\\", \\\"{x:1101,y:390,t:1528143643318};\\\", \\\"{x:1101,y:379,t:1528143643336};\\\", \\\"{x:1105,y:369,t:1528143643352};\\\", \\\"{x:1105,y:358,t:1528143643368};\\\", \\\"{x:1105,y:345,t:1528143643385};\\\", \\\"{x:1105,y:336,t:1528143643402};\\\", \\\"{x:1105,y:330,t:1528143643419};\\\", \\\"{x:1103,y:325,t:1528143643436};\\\", \\\"{x:1102,y:323,t:1528143643452};\\\", \\\"{x:1101,y:322,t:1528143643469};\\\", \\\"{x:1100,y:323,t:1528143643533};\\\", \\\"{x:1098,y:326,t:1528143643541};\\\", \\\"{x:1098,y:328,t:1528143643553};\\\", \\\"{x:1097,y:332,t:1528143643569};\\\", \\\"{x:1097,y:333,t:1528143643586};\\\", \\\"{x:1096,y:335,t:1528143643603};\\\", \\\"{x:1096,y:336,t:1528143643620};\\\", \\\"{x:1095,y:338,t:1528143643635};\\\", \\\"{x:1094,y:342,t:1528143643653};\\\", \\\"{x:1091,y:346,t:1528143643670};\\\", \\\"{x:1090,y:350,t:1528143643685};\\\", \\\"{x:1089,y:356,t:1528143643702};\\\", \\\"{x:1086,y:367,t:1528143643720};\\\", \\\"{x:1084,y:376,t:1528143643735};\\\", \\\"{x:1080,y:389,t:1528143643752};\\\", \\\"{x:1079,y:400,t:1528143643770};\\\", \\\"{x:1077,y:413,t:1528143643786};\\\", \\\"{x:1077,y:424,t:1528143643803};\\\", \\\"{x:1077,y:431,t:1528143643820};\\\", \\\"{x:1077,y:438,t:1528143643837};\\\", \\\"{x:1078,y:441,t:1528143643852};\\\", \\\"{x:1078,y:442,t:1528143643870};\\\", \\\"{x:1079,y:445,t:1528143643886};\\\", \\\"{x:1079,y:448,t:1528143643902};\\\", \\\"{x:1079,y:450,t:1528143643920};\\\", \\\"{x:1080,y:455,t:1528143643937};\\\", \\\"{x:1080,y:461,t:1528143643953};\\\", \\\"{x:1080,y:469,t:1528143643970};\\\", \\\"{x:1080,y:481,t:1528143643986};\\\", \\\"{x:1080,y:490,t:1528143644003};\\\", \\\"{x:1081,y:500,t:1528143644020};\\\", \\\"{x:1083,y:511,t:1528143644038};\\\", \\\"{x:1083,y:515,t:1528143644053};\\\", \\\"{x:1084,y:520,t:1528143644070};\\\", \\\"{x:1085,y:524,t:1528143644087};\\\", \\\"{x:1085,y:528,t:1528143644103};\\\", \\\"{x:1086,y:534,t:1528143644120};\\\", \\\"{x:1086,y:537,t:1528143644137};\\\", \\\"{x:1086,y:540,t:1528143644153};\\\", \\\"{x:1086,y:542,t:1528143644171};\\\", \\\"{x:1086,y:543,t:1528143644187};\\\", \\\"{x:1086,y:544,t:1528143644214};\\\", \\\"{x:1086,y:545,t:1528143644229};\\\", \\\"{x:1086,y:546,t:1528143644237};\\\", \\\"{x:1086,y:548,t:1528143644254};\\\", \\\"{x:1086,y:550,t:1528143644270};\\\", \\\"{x:1085,y:553,t:1528143644287};\\\", \\\"{x:1084,y:555,t:1528143644303};\\\", \\\"{x:1084,y:557,t:1528143644320};\\\", \\\"{x:1081,y:562,t:1528143644337};\\\", \\\"{x:1081,y:564,t:1528143644354};\\\", \\\"{x:1080,y:569,t:1528143644369};\\\", \\\"{x:1079,y:572,t:1528143644387};\\\", \\\"{x:1078,y:575,t:1528143644403};\\\", \\\"{x:1077,y:578,t:1528143644419};\\\", \\\"{x:1075,y:584,t:1528143644437};\\\", \\\"{x:1075,y:586,t:1528143644453};\\\", \\\"{x:1075,y:588,t:1528143644469};\\\", \\\"{x:1074,y:588,t:1528143644493};\\\", \\\"{x:1074,y:585,t:1528143644637};\\\", \\\"{x:1075,y:583,t:1528143644653};\\\", \\\"{x:1076,y:578,t:1528143644670};\\\", \\\"{x:1076,y:577,t:1528143644687};\\\", \\\"{x:1078,y:575,t:1528143644704};\\\", \\\"{x:1078,y:574,t:1528143644854};\\\", \\\"{x:1079,y:572,t:1528143644871};\\\", \\\"{x:1080,y:568,t:1528143644887};\\\", \\\"{x:1081,y:567,t:1528143644904};\\\", \\\"{x:1082,y:566,t:1528143644922};\\\", \\\"{x:1083,y:565,t:1528143644937};\\\", \\\"{x:1084,y:564,t:1528143644954};\\\", \\\"{x:1087,y:564,t:1528143644971};\\\", \\\"{x:1090,y:564,t:1528143644987};\\\", \\\"{x:1097,y:564,t:1528143645004};\\\", \\\"{x:1122,y:564,t:1528143645021};\\\", \\\"{x:1137,y:561,t:1528143645037};\\\", \\\"{x:1158,y:558,t:1528143645054};\\\", \\\"{x:1180,y:555,t:1528143645071};\\\", \\\"{x:1209,y:554,t:1528143645087};\\\", \\\"{x:1234,y:554,t:1528143645104};\\\", \\\"{x:1253,y:554,t:1528143645121};\\\", \\\"{x:1267,y:554,t:1528143645138};\\\", \\\"{x:1272,y:554,t:1528143645154};\\\", \\\"{x:1274,y:554,t:1528143645171};\\\", \\\"{x:1275,y:554,t:1528143645477};\\\", \\\"{x:1275,y:555,t:1528143645510};\\\", \\\"{x:1275,y:556,t:1528143645718};\\\", \\\"{x:1275,y:557,t:1528143645725};\\\", \\\"{x:1275,y:558,t:1528143645749};\\\", \\\"{x:1276,y:558,t:1528143645757};\\\", \\\"{x:1276,y:559,t:1528143645771};\\\", \\\"{x:1276,y:560,t:1528143645791};\\\", \\\"{x:1277,y:561,t:1528143645804};\\\", \\\"{x:1274,y:564,t:1528143647415};\\\", \\\"{x:1267,y:569,t:1528143647423};\\\", \\\"{x:1245,y:575,t:1528143647439};\\\", \\\"{x:1224,y:580,t:1528143647456};\\\", \\\"{x:1170,y:587,t:1528143647473};\\\", \\\"{x:1111,y:591,t:1528143647488};\\\", \\\"{x:1073,y:591,t:1528143647506};\\\", \\\"{x:1057,y:591,t:1528143647523};\\\", \\\"{x:1042,y:591,t:1528143647540};\\\", \\\"{x:1024,y:589,t:1528143647556};\\\", \\\"{x:1004,y:587,t:1528143647573};\\\", \\\"{x:998,y:587,t:1528143647589};\\\", \\\"{x:982,y:587,t:1528143647606};\\\", \\\"{x:965,y:587,t:1528143647623};\\\", \\\"{x:947,y:587,t:1528143647641};\\\", \\\"{x:933,y:587,t:1528143647655};\\\", \\\"{x:914,y:587,t:1528143647673};\\\", \\\"{x:888,y:587,t:1528143647690};\\\", \\\"{x:861,y:586,t:1528143647705};\\\", \\\"{x:836,y:581,t:1528143647722};\\\", \\\"{x:813,y:574,t:1528143647740};\\\", \\\"{x:803,y:569,t:1528143647755};\\\", \\\"{x:786,y:561,t:1528143647773};\\\", \\\"{x:774,y:555,t:1528143647790};\\\", \\\"{x:761,y:549,t:1528143647805};\\\", \\\"{x:745,y:544,t:1528143647823};\\\", \\\"{x:738,y:539,t:1528143647838};\\\", \\\"{x:725,y:536,t:1528143647856};\\\", \\\"{x:709,y:531,t:1528143647873};\\\", \\\"{x:700,y:528,t:1528143647889};\\\", \\\"{x:696,y:526,t:1528143647905};\\\", \\\"{x:693,y:526,t:1528143647923};\\\", \\\"{x:688,y:524,t:1528143647940};\\\", \\\"{x:682,y:522,t:1528143647955};\\\", \\\"{x:672,y:518,t:1528143647973};\\\", \\\"{x:668,y:515,t:1528143647990};\\\", \\\"{x:666,y:515,t:1528143648005};\\\", \\\"{x:665,y:514,t:1528143648022};\\\", \\\"{x:663,y:514,t:1528143648040};\\\", \\\"{x:662,y:513,t:1528143648055};\\\", \\\"{x:659,y:512,t:1528143648072};\\\", \\\"{x:657,y:512,t:1528143648093};\\\", \\\"{x:655,y:512,t:1528143648105};\\\", \\\"{x:647,y:512,t:1528143648123};\\\", \\\"{x:638,y:513,t:1528143648140};\\\", \\\"{x:635,y:514,t:1528143648156};\\\", \\\"{x:633,y:514,t:1528143648172};\\\", \\\"{x:629,y:513,t:1528143648190};\\\", \\\"{x:626,y:513,t:1528143648206};\\\", \\\"{x:621,y:511,t:1528143648224};\\\", \\\"{x:617,y:509,t:1528143648240};\\\", \\\"{x:612,y:507,t:1528143648256};\\\", \\\"{x:606,y:505,t:1528143648273};\\\", \\\"{x:603,y:504,t:1528143648289};\\\", \\\"{x:599,y:502,t:1528143648306};\\\", \\\"{x:598,y:502,t:1528143648324};\\\", \\\"{x:601,y:502,t:1528143649030};\\\", \\\"{x:607,y:502,t:1528143649040};\\\", \\\"{x:623,y:500,t:1528143649057};\\\", \\\"{x:644,y:500,t:1528143649074};\\\", \\\"{x:665,y:500,t:1528143649091};\\\", \\\"{x:680,y:503,t:1528143649106};\\\", \\\"{x:699,y:507,t:1528143649124};\\\", \\\"{x:710,y:510,t:1528143649140};\\\", \\\"{x:724,y:514,t:1528143649157};\\\", \\\"{x:729,y:516,t:1528143649173};\\\", \\\"{x:732,y:517,t:1528143649190};\\\", \\\"{x:735,y:518,t:1528143649207};\\\", \\\"{x:736,y:518,t:1528143649224};\\\", \\\"{x:738,y:518,t:1528143649241};\\\", \\\"{x:740,y:518,t:1528143649257};\\\", \\\"{x:743,y:518,t:1528143649274};\\\", \\\"{x:746,y:518,t:1528143649290};\\\", \\\"{x:748,y:518,t:1528143649306};\\\", \\\"{x:750,y:519,t:1528143649332};\\\", \\\"{x:743,y:519,t:1528143649390};\\\", \\\"{x:732,y:519,t:1528143649397};\\\", \\\"{x:723,y:519,t:1528143649407};\\\", \\\"{x:706,y:514,t:1528143649425};\\\", \\\"{x:690,y:513,t:1528143649441};\\\", \\\"{x:680,y:509,t:1528143649457};\\\", \\\"{x:672,y:507,t:1528143649474};\\\", \\\"{x:666,y:505,t:1528143649491};\\\", \\\"{x:661,y:503,t:1528143649508};\\\", \\\"{x:655,y:501,t:1528143649524};\\\", \\\"{x:646,y:498,t:1528143649541};\\\", \\\"{x:641,y:496,t:1528143649558};\\\", \\\"{x:639,y:496,t:1528143649574};\\\", \\\"{x:637,y:496,t:1528143649591};\\\", \\\"{x:633,y:496,t:1528143649606};\\\", \\\"{x:630,y:496,t:1528143649624};\\\", \\\"{x:625,y:496,t:1528143649641};\\\", \\\"{x:623,y:497,t:1528143649658};\\\", \\\"{x:620,y:497,t:1528143649674};\\\", \\\"{x:618,y:497,t:1528143649691};\\\", \\\"{x:614,y:497,t:1528143649708};\\\", \\\"{x:612,y:497,t:1528143649723};\\\", \\\"{x:609,y:498,t:1528143649740};\\\", \\\"{x:607,y:498,t:1528143649758};\\\", \\\"{x:605,y:498,t:1528143649773};\\\", \\\"{x:605,y:499,t:1528143649948};\\\", \\\"{x:613,y:501,t:1528143649958};\\\", \\\"{x:631,y:506,t:1528143649975};\\\", \\\"{x:650,y:508,t:1528143649991};\\\", \\\"{x:670,y:511,t:1528143650008};\\\", \\\"{x:694,y:512,t:1528143650024};\\\", \\\"{x:724,y:515,t:1528143650041};\\\", \\\"{x:757,y:520,t:1528143650058};\\\", \\\"{x:785,y:520,t:1528143650074};\\\", \\\"{x:806,y:524,t:1528143650090};\\\", \\\"{x:823,y:526,t:1528143650108};\\\", \\\"{x:842,y:530,t:1528143650125};\\\", \\\"{x:845,y:533,t:1528143650140};\\\", \\\"{x:846,y:533,t:1528143650158};\\\", \\\"{x:847,y:533,t:1528143650175};\\\", \\\"{x:847,y:535,t:1528143650348};\\\", \\\"{x:847,y:537,t:1528143650359};\\\", \\\"{x:847,y:540,t:1528143650376};\\\", \\\"{x:846,y:542,t:1528143650392};\\\", \\\"{x:845,y:543,t:1528143650409};\\\", \\\"{x:842,y:545,t:1528143650426};\\\", \\\"{x:840,y:545,t:1528143650442};\\\", \\\"{x:838,y:545,t:1528143650459};\\\", \\\"{x:836,y:545,t:1528143650476};\\\", \\\"{x:835,y:544,t:1528143650493};\\\", \\\"{x:834,y:543,t:1528143650509};\\\", \\\"{x:833,y:543,t:1528143650717};\\\", \\\"{x:826,y:543,t:1528143650725};\\\", \\\"{x:810,y:553,t:1528143650742};\\\", \\\"{x:781,y:570,t:1528143650758};\\\", \\\"{x:743,y:592,t:1528143650775};\\\", \\\"{x:684,y:623,t:1528143650792};\\\", \\\"{x:631,y:648,t:1528143650808};\\\", \\\"{x:578,y:672,t:1528143650825};\\\", \\\"{x:553,y:685,t:1528143650842};\\\", \\\"{x:529,y:693,t:1528143650859};\\\", \\\"{x:515,y:699,t:1528143650875};\\\", \\\"{x:504,y:702,t:1528143650892};\\\", \\\"{x:501,y:703,t:1528143650909};\\\", \\\"{x:503,y:703,t:1528143650964};\\\", \\\"{x:506,y:702,t:1528143650975};\\\", \\\"{x:516,y:690,t:1528143650991};\\\", \\\"{x:522,y:684,t:1528143651009};\\\", \\\"{x:524,y:683,t:1528143651025};\\\", \\\"{x:526,y:683,t:1528143651045};\\\", \\\"{x:527,y:683,t:1528143651077};\\\", \\\"{x:527,y:685,t:1528143651092};\\\", \\\"{x:527,y:700,t:1528143651109};\\\", \\\"{x:527,y:715,t:1528143651125};\\\", \\\"{x:526,y:733,t:1528143651143};\\\", \\\"{x:524,y:746,t:1528143651159};\\\", \\\"{x:523,y:753,t:1528143651175};\\\", \\\"{x:523,y:754,t:1528143651192};\\\", \\\"{x:523,y:752,t:1528143651468};\\\", \\\"{x:523,y:750,t:1528143651476};\\\", \\\"{x:523,y:747,t:1528143651492};\\\", \\\"{x:523,y:741,t:1528143651509};\\\", \\\"{x:523,y:738,t:1528143651525};\\\", \\\"{x:523,y:736,t:1528143651541};\\\" ] }, { \\\"rt\\\": 26628, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 520140, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5-E -F -F -F -F -O -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:735,t:1528143654142};\\\", \\\"{x:523,y:732,t:1528143654164};\\\", \\\"{x:523,y:730,t:1528143654178};\\\", \\\"{x:523,y:729,t:1528143655350};\\\", \\\"{x:523,y:728,t:1528143655362};\\\", \\\"{x:526,y:726,t:1528143655380};\\\", \\\"{x:528,y:726,t:1528143655397};\\\", \\\"{x:529,y:725,t:1528143655412};\\\", \\\"{x:530,y:725,t:1528143655429};\\\", \\\"{x:532,y:723,t:1528143655446};\\\", \\\"{x:534,y:723,t:1528143655462};\\\", \\\"{x:535,y:723,t:1528143655485};\\\", \\\"{x:536,y:723,t:1528143655496};\\\", \\\"{x:538,y:722,t:1528143655514};\\\", \\\"{x:544,y:721,t:1528143655530};\\\", \\\"{x:551,y:720,t:1528143655547};\\\", \\\"{x:559,y:719,t:1528143655564};\\\", \\\"{x:572,y:718,t:1528143655579};\\\", \\\"{x:585,y:715,t:1528143655596};\\\", \\\"{x:592,y:714,t:1528143655612};\\\", \\\"{x:598,y:713,t:1528143655629};\\\", \\\"{x:605,y:713,t:1528143655646};\\\", \\\"{x:611,y:712,t:1528143655662};\\\", \\\"{x:616,y:712,t:1528143655679};\\\", \\\"{x:620,y:712,t:1528143655696};\\\", \\\"{x:625,y:712,t:1528143655711};\\\", \\\"{x:628,y:712,t:1528143655729};\\\", \\\"{x:634,y:712,t:1528143655746};\\\", \\\"{x:644,y:711,t:1528143655762};\\\", \\\"{x:658,y:710,t:1528143655779};\\\", \\\"{x:673,y:708,t:1528143655796};\\\", \\\"{x:687,y:706,t:1528143655812};\\\", \\\"{x:715,y:700,t:1528143655829};\\\", \\\"{x:725,y:699,t:1528143655847};\\\", \\\"{x:733,y:699,t:1528143655863};\\\", \\\"{x:736,y:698,t:1528143655879};\\\", \\\"{x:736,y:697,t:1528143656038};\\\", \\\"{x:736,y:696,t:1528143656047};\\\", \\\"{x:729,y:692,t:1528143656064};\\\", \\\"{x:721,y:687,t:1528143656081};\\\", \\\"{x:718,y:686,t:1528143656097};\\\", \\\"{x:718,y:685,t:1528143656557};\\\", \\\"{x:718,y:684,t:1528143656566};\\\", \\\"{x:719,y:682,t:1528143656580};\\\", \\\"{x:720,y:682,t:1528143656597};\\\", \\\"{x:720,y:681,t:1528143656684};\\\", \\\"{x:719,y:681,t:1528143656697};\\\", \\\"{x:716,y:680,t:1528143656714};\\\", \\\"{x:710,y:677,t:1528143656731};\\\", \\\"{x:700,y:670,t:1528143656747};\\\", \\\"{x:680,y:660,t:1528143656765};\\\", \\\"{x:666,y:650,t:1528143656781};\\\", \\\"{x:650,y:639,t:1528143656797};\\\", \\\"{x:633,y:627,t:1528143656815};\\\", \\\"{x:610,y:611,t:1528143656832};\\\", \\\"{x:587,y:596,t:1528143656849};\\\", \\\"{x:571,y:580,t:1528143656864};\\\", \\\"{x:560,y:567,t:1528143656881};\\\", \\\"{x:558,y:559,t:1528143656897};\\\", \\\"{x:556,y:555,t:1528143656914};\\\", \\\"{x:555,y:548,t:1528143656930};\\\", \\\"{x:552,y:540,t:1528143656947};\\\", \\\"{x:550,y:524,t:1528143656964};\\\", \\\"{x:544,y:507,t:1528143656980};\\\", \\\"{x:544,y:503,t:1528143656997};\\\", \\\"{x:544,y:501,t:1528143657013};\\\", \\\"{x:542,y:500,t:1528143657030};\\\", \\\"{x:542,y:499,t:1528143657052};\\\", \\\"{x:542,y:498,t:1528143657620};\\\", \\\"{x:542,y:497,t:1528143658789};\\\", \\\"{x:543,y:497,t:1528143658800};\\\", \\\"{x:545,y:496,t:1528143658817};\\\", \\\"{x:547,y:496,t:1528143658833};\\\", \\\"{x:556,y:496,t:1528143658849};\\\", \\\"{x:566,y:496,t:1528143658867};\\\", \\\"{x:576,y:496,t:1528143658883};\\\", \\\"{x:594,y:500,t:1528143658899};\\\", \\\"{x:625,y:508,t:1528143658917};\\\", \\\"{x:655,y:517,t:1528143658934};\\\", \\\"{x:703,y:530,t:1528143658949};\\\", \\\"{x:752,y:541,t:1528143658966};\\\", \\\"{x:797,y:556,t:1528143658982};\\\", \\\"{x:839,y:568,t:1528143658998};\\\", \\\"{x:874,y:574,t:1528143659015};\\\", \\\"{x:901,y:577,t:1528143659032};\\\", \\\"{x:924,y:581,t:1528143659048};\\\", \\\"{x:944,y:583,t:1528143659065};\\\", \\\"{x:959,y:587,t:1528143659082};\\\", \\\"{x:971,y:591,t:1528143659098};\\\", \\\"{x:984,y:597,t:1528143659115};\\\", \\\"{x:1000,y:603,t:1528143659132};\\\", \\\"{x:1013,y:611,t:1528143659148};\\\", \\\"{x:1030,y:614,t:1528143659166};\\\", \\\"{x:1043,y:618,t:1528143659182};\\\", \\\"{x:1059,y:622,t:1528143659199};\\\", \\\"{x:1071,y:624,t:1528143659216};\\\", \\\"{x:1080,y:624,t:1528143659232};\\\", \\\"{x:1088,y:626,t:1528143659248};\\\", \\\"{x:1092,y:627,t:1528143659265};\\\", \\\"{x:1096,y:627,t:1528143659283};\\\", \\\"{x:1101,y:628,t:1528143659298};\\\", \\\"{x:1105,y:630,t:1528143659315};\\\", \\\"{x:1111,y:632,t:1528143659333};\\\", \\\"{x:1115,y:635,t:1528143659348};\\\", \\\"{x:1119,y:637,t:1528143659365};\\\", \\\"{x:1123,y:639,t:1528143659382};\\\", \\\"{x:1131,y:643,t:1528143659399};\\\", \\\"{x:1138,y:645,t:1528143659416};\\\", \\\"{x:1142,y:646,t:1528143659433};\\\", \\\"{x:1146,y:646,t:1528143659449};\\\", \\\"{x:1149,y:646,t:1528143659466};\\\", \\\"{x:1150,y:646,t:1528143659482};\\\", \\\"{x:1156,y:644,t:1528143660221};\\\", \\\"{x:1164,y:637,t:1528143660233};\\\", \\\"{x:1171,y:632,t:1528143660249};\\\", \\\"{x:1177,y:627,t:1528143660267};\\\", \\\"{x:1181,y:624,t:1528143660283};\\\", \\\"{x:1185,y:621,t:1528143660300};\\\", \\\"{x:1190,y:618,t:1528143660317};\\\", \\\"{x:1192,y:616,t:1528143660333};\\\", \\\"{x:1195,y:615,t:1528143660349};\\\", \\\"{x:1198,y:612,t:1528143660366};\\\", \\\"{x:1206,y:608,t:1528143660383};\\\", \\\"{x:1215,y:602,t:1528143660400};\\\", \\\"{x:1232,y:596,t:1528143660417};\\\", \\\"{x:1246,y:589,t:1528143660434};\\\", \\\"{x:1257,y:582,t:1528143660449};\\\", \\\"{x:1263,y:579,t:1528143660467};\\\", \\\"{x:1270,y:576,t:1528143660484};\\\", \\\"{x:1275,y:574,t:1528143660500};\\\", \\\"{x:1278,y:571,t:1528143660517};\\\", \\\"{x:1280,y:570,t:1528143660646};\\\", \\\"{x:1282,y:568,t:1528143660656};\\\", \\\"{x:1283,y:566,t:1528143660683};\\\", \\\"{x:1286,y:564,t:1528143660700};\\\", \\\"{x:1285,y:563,t:1528143661101};\\\", \\\"{x:1283,y:565,t:1528143661117};\\\", \\\"{x:1281,y:568,t:1528143661133};\\\", \\\"{x:1280,y:570,t:1528143661152};\\\", \\\"{x:1280,y:571,t:1528143661167};\\\", \\\"{x:1280,y:572,t:1528143661184};\\\", \\\"{x:1280,y:573,t:1528143661213};\\\", \\\"{x:1279,y:574,t:1528143661221};\\\", \\\"{x:1278,y:575,t:1528143661234};\\\", \\\"{x:1278,y:576,t:1528143661261};\\\", \\\"{x:1277,y:578,t:1528143661277};\\\", \\\"{x:1277,y:580,t:1528143661293};\\\", \\\"{x:1277,y:582,t:1528143661301};\\\", \\\"{x:1277,y:587,t:1528143661317};\\\", \\\"{x:1275,y:591,t:1528143661334};\\\", \\\"{x:1275,y:594,t:1528143661351};\\\", \\\"{x:1274,y:598,t:1528143661368};\\\", \\\"{x:1274,y:600,t:1528143661384};\\\", \\\"{x:1273,y:603,t:1528143661401};\\\", \\\"{x:1273,y:604,t:1528143661418};\\\", \\\"{x:1273,y:605,t:1528143661434};\\\", \\\"{x:1273,y:606,t:1528143661525};\\\", \\\"{x:1272,y:607,t:1528143661541};\\\", \\\"{x:1272,y:608,t:1528143661551};\\\", \\\"{x:1271,y:613,t:1528143661568};\\\", \\\"{x:1270,y:615,t:1528143661584};\\\", \\\"{x:1269,y:620,t:1528143661601};\\\", \\\"{x:1269,y:621,t:1528143661618};\\\", \\\"{x:1269,y:623,t:1528143661634};\\\", \\\"{x:1268,y:625,t:1528143661837};\\\", \\\"{x:1268,y:626,t:1528143661853};\\\", \\\"{x:1268,y:628,t:1528143661869};\\\", \\\"{x:1267,y:628,t:1528143661893};\\\", \\\"{x:1267,y:629,t:1528143662085};\\\", \\\"{x:1266,y:629,t:1528143662102};\\\", \\\"{x:1266,y:631,t:1528143662118};\\\", \\\"{x:1266,y:633,t:1528143662572};\\\", \\\"{x:1267,y:633,t:1528143662585};\\\", \\\"{x:1268,y:635,t:1528143662601};\\\", \\\"{x:1271,y:636,t:1528143662619};\\\", \\\"{x:1273,y:638,t:1528143662635};\\\", \\\"{x:1274,y:638,t:1528143662651};\\\", \\\"{x:1275,y:638,t:1528143662781};\\\", \\\"{x:1276,y:638,t:1528143662813};\\\", \\\"{x:1277,y:639,t:1528143662821};\\\", \\\"{x:1278,y:639,t:1528143662853};\\\", \\\"{x:1279,y:639,t:1528143662869};\\\", \\\"{x:1281,y:641,t:1528143662885};\\\", \\\"{x:1283,y:641,t:1528143662902};\\\", \\\"{x:1284,y:641,t:1528143662919};\\\", \\\"{x:1286,y:642,t:1528143662936};\\\", \\\"{x:1287,y:642,t:1528143662952};\\\", \\\"{x:1290,y:643,t:1528143662969};\\\", \\\"{x:1293,y:643,t:1528143662986};\\\", \\\"{x:1296,y:645,t:1528143663002};\\\", \\\"{x:1304,y:647,t:1528143663019};\\\", \\\"{x:1309,y:651,t:1528143663036};\\\", \\\"{x:1314,y:654,t:1528143663052};\\\", \\\"{x:1325,y:660,t:1528143663070};\\\", \\\"{x:1332,y:666,t:1528143663085};\\\", \\\"{x:1334,y:667,t:1528143663102};\\\", \\\"{x:1337,y:669,t:1528143663119};\\\", \\\"{x:1340,y:670,t:1528143663136};\\\", \\\"{x:1343,y:672,t:1528143663153};\\\", \\\"{x:1344,y:672,t:1528143663169};\\\", \\\"{x:1344,y:673,t:1528143663197};\\\", \\\"{x:1345,y:673,t:1528143663293};\\\", \\\"{x:1345,y:675,t:1528143663303};\\\", \\\"{x:1345,y:678,t:1528143663319};\\\", \\\"{x:1346,y:680,t:1528143663336};\\\", \\\"{x:1346,y:683,t:1528143663353};\\\", \\\"{x:1346,y:684,t:1528143663454};\\\", \\\"{x:1346,y:686,t:1528143663469};\\\", \\\"{x:1346,y:688,t:1528143663486};\\\", \\\"{x:1346,y:691,t:1528143663503};\\\", \\\"{x:1346,y:694,t:1528143663521};\\\", \\\"{x:1346,y:698,t:1528143663536};\\\", \\\"{x:1346,y:700,t:1528143663553};\\\", \\\"{x:1346,y:701,t:1528143663570};\\\", \\\"{x:1346,y:702,t:1528143663586};\\\", \\\"{x:1346,y:703,t:1528143663790};\\\", \\\"{x:1346,y:704,t:1528143663803};\\\", \\\"{x:1347,y:705,t:1528143664429};\\\", \\\"{x:1348,y:705,t:1528143664437};\\\", \\\"{x:1349,y:705,t:1528143664568};\\\", \\\"{x:1351,y:704,t:1528143664572};\\\", \\\"{x:1351,y:703,t:1528143664588};\\\", \\\"{x:1352,y:702,t:1528143664603};\\\", \\\"{x:1353,y:700,t:1528143664620};\\\", \\\"{x:1355,y:696,t:1528143664636};\\\", \\\"{x:1355,y:695,t:1528143664654};\\\", \\\"{x:1355,y:693,t:1528143664862};\\\", \\\"{x:1355,y:692,t:1528143664871};\\\", \\\"{x:1356,y:691,t:1528143664886};\\\", \\\"{x:1356,y:689,t:1528143664903};\\\", \\\"{x:1356,y:690,t:1528143665085};\\\", \\\"{x:1356,y:689,t:1528143665117};\\\", \\\"{x:1356,y:688,t:1528143665141};\\\", \\\"{x:1356,y:687,t:1528143665262};\\\", \\\"{x:1356,y:686,t:1528143665277};\\\", \\\"{x:1356,y:685,t:1528143665288};\\\", \\\"{x:1357,y:682,t:1528143665304};\\\", \\\"{x:1358,y:679,t:1528143665321};\\\", \\\"{x:1358,y:677,t:1528143665338};\\\", \\\"{x:1358,y:676,t:1528143665354};\\\", \\\"{x:1358,y:675,t:1528143665371};\\\", \\\"{x:1358,y:674,t:1528143665446};\\\", \\\"{x:1357,y:674,t:1528143665517};\\\", \\\"{x:1354,y:674,t:1528143665525};\\\", \\\"{x:1351,y:674,t:1528143665538};\\\", \\\"{x:1347,y:673,t:1528143665556};\\\", \\\"{x:1343,y:672,t:1528143665572};\\\", \\\"{x:1337,y:670,t:1528143665589};\\\", \\\"{x:1331,y:668,t:1528143665605};\\\", \\\"{x:1325,y:665,t:1528143665621};\\\", \\\"{x:1321,y:664,t:1528143665638};\\\", \\\"{x:1316,y:663,t:1528143665655};\\\", \\\"{x:1311,y:660,t:1528143665671};\\\", \\\"{x:1306,y:659,t:1528143665688};\\\", \\\"{x:1304,y:657,t:1528143665706};\\\", \\\"{x:1299,y:655,t:1528143665721};\\\", \\\"{x:1295,y:653,t:1528143665738};\\\", \\\"{x:1289,y:651,t:1528143665755};\\\", \\\"{x:1283,y:649,t:1528143665772};\\\", \\\"{x:1278,y:647,t:1528143665788};\\\", \\\"{x:1269,y:643,t:1528143665805};\\\", \\\"{x:1263,y:640,t:1528143665821};\\\", \\\"{x:1257,y:638,t:1528143665837};\\\", \\\"{x:1255,y:636,t:1528143665855};\\\", \\\"{x:1253,y:635,t:1528143665870};\\\", \\\"{x:1251,y:634,t:1528143666045};\\\", \\\"{x:1249,y:633,t:1528143666055};\\\", \\\"{x:1248,y:633,t:1528143666071};\\\", \\\"{x:1247,y:633,t:1528143666092};\\\", \\\"{x:1248,y:633,t:1528143666181};\\\", \\\"{x:1251,y:633,t:1528143666189};\\\", \\\"{x:1257,y:633,t:1528143666205};\\\", \\\"{x:1271,y:633,t:1528143666222};\\\", \\\"{x:1283,y:633,t:1528143666238};\\\", \\\"{x:1300,y:633,t:1528143666256};\\\", \\\"{x:1313,y:633,t:1528143666272};\\\", \\\"{x:1326,y:633,t:1528143666289};\\\", \\\"{x:1340,y:633,t:1528143666305};\\\", \\\"{x:1355,y:633,t:1528143666322};\\\", \\\"{x:1370,y:633,t:1528143666338};\\\", \\\"{x:1376,y:633,t:1528143666355};\\\", \\\"{x:1382,y:633,t:1528143666373};\\\", \\\"{x:1386,y:633,t:1528143666389};\\\", \\\"{x:1388,y:633,t:1528143666405};\\\", \\\"{x:1391,y:633,t:1528143666422};\\\", \\\"{x:1398,y:631,t:1528143666440};\\\", \\\"{x:1402,y:631,t:1528143666455};\\\", \\\"{x:1411,y:629,t:1528143666472};\\\", \\\"{x:1416,y:629,t:1528143666489};\\\", \\\"{x:1423,y:628,t:1528143666505};\\\", \\\"{x:1426,y:628,t:1528143666522};\\\", \\\"{x:1427,y:627,t:1528143666540};\\\", \\\"{x:1429,y:627,t:1528143667357};\\\", \\\"{x:1430,y:627,t:1528143667373};\\\", \\\"{x:1430,y:628,t:1528143667413};\\\", \\\"{x:1431,y:628,t:1528143667423};\\\", \\\"{x:1432,y:629,t:1528143667439};\\\", \\\"{x:1433,y:633,t:1528143667456};\\\", \\\"{x:1433,y:637,t:1528143667473};\\\", \\\"{x:1433,y:643,t:1528143667489};\\\", \\\"{x:1433,y:647,t:1528143667506};\\\", \\\"{x:1433,y:650,t:1528143667523};\\\", \\\"{x:1431,y:653,t:1528143667539};\\\", \\\"{x:1424,y:659,t:1528143667556};\\\", \\\"{x:1411,y:673,t:1528143667573};\\\", \\\"{x:1404,y:678,t:1528143667590};\\\", \\\"{x:1395,y:685,t:1528143667606};\\\", \\\"{x:1388,y:689,t:1528143667623};\\\", \\\"{x:1384,y:692,t:1528143667640};\\\", \\\"{x:1381,y:692,t:1528143667656};\\\", \\\"{x:1380,y:692,t:1528143667674};\\\", \\\"{x:1378,y:692,t:1528143667690};\\\", \\\"{x:1376,y:692,t:1528143667706};\\\", \\\"{x:1371,y:692,t:1528143667723};\\\", \\\"{x:1366,y:692,t:1528143667740};\\\", \\\"{x:1359,y:692,t:1528143667756};\\\", \\\"{x:1348,y:692,t:1528143667774};\\\", \\\"{x:1343,y:692,t:1528143667791};\\\", \\\"{x:1337,y:690,t:1528143667806};\\\", \\\"{x:1335,y:690,t:1528143667824};\\\", \\\"{x:1333,y:690,t:1528143667841};\\\", \\\"{x:1334,y:690,t:1528143668510};\\\", \\\"{x:1335,y:690,t:1528143668525};\\\", \\\"{x:1336,y:690,t:1528143668540};\\\", \\\"{x:1337,y:690,t:1528143668573};\\\", \\\"{x:1338,y:690,t:1528143668590};\\\", \\\"{x:1339,y:689,t:1528143668637};\\\", \\\"{x:1339,y:688,t:1528143668756};\\\", \\\"{x:1340,y:688,t:1528143668774};\\\", \\\"{x:1341,y:688,t:1528143668790};\\\", \\\"{x:1342,y:688,t:1528143668807};\\\", \\\"{x:1343,y:688,t:1528143668828};\\\", \\\"{x:1344,y:688,t:1528143668844};\\\", \\\"{x:1345,y:688,t:1528143668877};\\\", \\\"{x:1346,y:688,t:1528143668942};\\\", \\\"{x:1347,y:688,t:1528143668957};\\\", \\\"{x:1348,y:688,t:1528143668974};\\\", \\\"{x:1349,y:688,t:1528143669005};\\\", \\\"{x:1350,y:688,t:1528143669021};\\\", \\\"{x:1351,y:688,t:1528143669037};\\\", \\\"{x:1352,y:688,t:1528143669086};\\\", \\\"{x:1353,y:688,t:1528143669126};\\\", \\\"{x:1354,y:688,t:1528143671461};\\\", \\\"{x:1355,y:692,t:1528143671492};\\\", \\\"{x:1361,y:703,t:1528143671509};\\\", \\\"{x:1364,y:709,t:1528143671526};\\\", \\\"{x:1368,y:713,t:1528143671543};\\\", \\\"{x:1368,y:714,t:1528143671559};\\\", \\\"{x:1369,y:716,t:1528143671576};\\\", \\\"{x:1369,y:717,t:1528143671593};\\\", \\\"{x:1370,y:717,t:1528143671677};\\\", \\\"{x:1370,y:721,t:1528143671693};\\\", \\\"{x:1373,y:726,t:1528143671709};\\\", \\\"{x:1375,y:732,t:1528143671726};\\\", \\\"{x:1380,y:737,t:1528143671743};\\\", \\\"{x:1386,y:745,t:1528143671760};\\\", \\\"{x:1394,y:750,t:1528143671777};\\\", \\\"{x:1402,y:755,t:1528143671794};\\\", \\\"{x:1411,y:759,t:1528143671810};\\\", \\\"{x:1424,y:765,t:1528143671826};\\\", \\\"{x:1440,y:771,t:1528143671843};\\\", \\\"{x:1462,y:776,t:1528143671860};\\\", \\\"{x:1484,y:783,t:1528143671876};\\\", \\\"{x:1511,y:791,t:1528143671893};\\\", \\\"{x:1527,y:795,t:1528143671911};\\\", \\\"{x:1534,y:795,t:1528143671927};\\\", \\\"{x:1536,y:796,t:1528143671944};\\\", \\\"{x:1538,y:796,t:1528143672054};\\\", \\\"{x:1539,y:796,t:1528143672060};\\\", \\\"{x:1539,y:795,t:1528143672076};\\\", \\\"{x:1540,y:790,t:1528143672093};\\\", \\\"{x:1540,y:789,t:1528143672110};\\\", \\\"{x:1540,y:787,t:1528143672127};\\\", \\\"{x:1539,y:785,t:1528143672144};\\\", \\\"{x:1537,y:783,t:1528143672161};\\\", \\\"{x:1535,y:783,t:1528143672177};\\\", \\\"{x:1532,y:781,t:1528143672193};\\\", \\\"{x:1527,y:779,t:1528143672211};\\\", \\\"{x:1526,y:779,t:1528143672228};\\\", \\\"{x:1525,y:778,t:1528143672244};\\\", \\\"{x:1522,y:777,t:1528143672260};\\\", \\\"{x:1519,y:775,t:1528143672277};\\\", \\\"{x:1519,y:774,t:1528143672294};\\\", \\\"{x:1517,y:774,t:1528143672310};\\\", \\\"{x:1516,y:773,t:1528143672327};\\\", \\\"{x:1515,y:772,t:1528143672343};\\\", \\\"{x:1513,y:771,t:1528143672372};\\\", \\\"{x:1512,y:771,t:1528143672428};\\\", \\\"{x:1512,y:770,t:1528143672444};\\\", \\\"{x:1511,y:770,t:1528143672459};\\\", \\\"{x:1510,y:768,t:1528143672477};\\\", \\\"{x:1510,y:767,t:1528143672493};\\\", \\\"{x:1509,y:767,t:1528143672510};\\\", \\\"{x:1509,y:766,t:1528143672527};\\\", \\\"{x:1508,y:765,t:1528143672543};\\\", \\\"{x:1508,y:764,t:1528143672565};\\\", \\\"{x:1508,y:766,t:1528143675669};\\\", \\\"{x:1508,y:767,t:1528143675685};\\\", \\\"{x:1508,y:768,t:1528143675697};\\\", \\\"{x:1508,y:769,t:1528143675714};\\\", \\\"{x:1508,y:771,t:1528143675729};\\\", \\\"{x:1508,y:772,t:1528143675747};\\\", \\\"{x:1508,y:773,t:1528143675853};\\\", \\\"{x:1508,y:774,t:1528143675864};\\\", \\\"{x:1508,y:775,t:1528143675881};\\\", \\\"{x:1508,y:778,t:1528143675896};\\\", \\\"{x:1506,y:781,t:1528143675914};\\\", \\\"{x:1505,y:785,t:1528143675930};\\\", \\\"{x:1503,y:789,t:1528143675946};\\\", \\\"{x:1501,y:792,t:1528143675964};\\\", \\\"{x:1501,y:795,t:1528143675981};\\\", \\\"{x:1499,y:797,t:1528143675997};\\\", \\\"{x:1498,y:799,t:1528143676021};\\\", \\\"{x:1497,y:800,t:1528143676045};\\\", \\\"{x:1496,y:804,t:1528143676069};\\\", \\\"{x:1495,y:804,t:1528143676085};\\\", \\\"{x:1494,y:805,t:1528143676101};\\\", \\\"{x:1494,y:807,t:1528143676114};\\\", \\\"{x:1492,y:808,t:1528143676131};\\\", \\\"{x:1491,y:811,t:1528143676147};\\\", \\\"{x:1489,y:814,t:1528143676164};\\\", \\\"{x:1487,y:817,t:1528143676181};\\\", \\\"{x:1484,y:821,t:1528143676197};\\\", \\\"{x:1482,y:822,t:1528143676213};\\\", \\\"{x:1481,y:825,t:1528143676231};\\\", \\\"{x:1479,y:828,t:1528143676247};\\\", \\\"{x:1478,y:829,t:1528143676264};\\\", \\\"{x:1476,y:831,t:1528143676280};\\\", \\\"{x:1473,y:834,t:1528143676299};\\\", \\\"{x:1472,y:835,t:1528143676313};\\\", \\\"{x:1471,y:835,t:1528143676330};\\\", \\\"{x:1468,y:836,t:1528143676347};\\\", \\\"{x:1467,y:836,t:1528143676382};\\\", \\\"{x:1466,y:837,t:1528143676405};\\\", \\\"{x:1462,y:837,t:1528143676525};\\\", \\\"{x:1458,y:837,t:1528143676533};\\\", \\\"{x:1453,y:837,t:1528143676548};\\\", \\\"{x:1431,y:837,t:1528143676564};\\\", \\\"{x:1369,y:827,t:1528143676581};\\\", \\\"{x:1291,y:807,t:1528143676597};\\\", \\\"{x:1202,y:780,t:1528143676615};\\\", \\\"{x:1122,y:756,t:1528143676631};\\\", \\\"{x:1065,y:738,t:1528143676648};\\\", \\\"{x:1031,y:726,t:1528143676664};\\\", \\\"{x:1009,y:716,t:1528143676680};\\\", \\\"{x:1003,y:713,t:1528143676697};\\\", \\\"{x:1001,y:711,t:1528143676714};\\\", \\\"{x:1000,y:711,t:1528143676788};\\\", \\\"{x:999,y:710,t:1528143676797};\\\", \\\"{x:994,y:703,t:1528143676814};\\\", \\\"{x:990,y:698,t:1528143676830};\\\", \\\"{x:986,y:691,t:1528143676847};\\\", \\\"{x:984,y:684,t:1528143676864};\\\", \\\"{x:982,y:673,t:1528143676880};\\\", \\\"{x:977,y:662,t:1528143676897};\\\", \\\"{x:974,y:653,t:1528143676914};\\\", \\\"{x:972,y:648,t:1528143676931};\\\", \\\"{x:967,y:642,t:1528143676948};\\\", \\\"{x:960,y:635,t:1528143676966};\\\", \\\"{x:957,y:633,t:1528143676981};\\\", \\\"{x:952,y:630,t:1528143676997};\\\", \\\"{x:948,y:627,t:1528143677015};\\\", \\\"{x:942,y:624,t:1528143677031};\\\", \\\"{x:933,y:620,t:1528143677046};\\\", \\\"{x:917,y:613,t:1528143677063};\\\", \\\"{x:903,y:608,t:1528143677080};\\\", \\\"{x:888,y:603,t:1528143677097};\\\", \\\"{x:874,y:596,t:1528143677114};\\\", \\\"{x:861,y:593,t:1528143677130};\\\", \\\"{x:850,y:590,t:1528143677147};\\\", \\\"{x:842,y:586,t:1528143677163};\\\", \\\"{x:836,y:585,t:1528143677179};\\\", \\\"{x:834,y:584,t:1528143677196};\\\", \\\"{x:833,y:584,t:1528143677228};\\\", \\\"{x:832,y:583,t:1528143677244};\\\", \\\"{x:831,y:582,t:1528143677285};\\\", \\\"{x:830,y:582,t:1528143677317};\\\", \\\"{x:830,y:581,t:1528143677372};\\\", \\\"{x:832,y:581,t:1528143677381};\\\", \\\"{x:833,y:581,t:1528143677404};\\\", \\\"{x:835,y:581,t:1528143677453};\\\", \\\"{x:834,y:580,t:1528143677576};\\\", \\\"{x:832,y:578,t:1528143677596};\\\", \\\"{x:827,y:576,t:1528143677614};\\\", \\\"{x:818,y:574,t:1528143677631};\\\", \\\"{x:803,y:573,t:1528143677647};\\\", \\\"{x:787,y:571,t:1528143677664};\\\", \\\"{x:775,y:571,t:1528143677680};\\\", \\\"{x:762,y:571,t:1528143677697};\\\", \\\"{x:745,y:571,t:1528143677713};\\\", \\\"{x:724,y:571,t:1528143677729};\\\", \\\"{x:709,y:571,t:1528143677748};\\\", \\\"{x:679,y:571,t:1528143677764};\\\", \\\"{x:667,y:571,t:1528143677779};\\\", \\\"{x:657,y:571,t:1528143677797};\\\", \\\"{x:651,y:571,t:1528143677814};\\\", \\\"{x:648,y:571,t:1528143677830};\\\", \\\"{x:646,y:571,t:1528143677957};\\\", \\\"{x:643,y:571,t:1528143677966};\\\", \\\"{x:640,y:571,t:1528143677981};\\\", \\\"{x:637,y:571,t:1528143677997};\\\", \\\"{x:635,y:571,t:1528143678014};\\\", \\\"{x:634,y:571,t:1528143678052};\\\", \\\"{x:632,y:571,t:1528143678064};\\\", \\\"{x:628,y:571,t:1528143678081};\\\", \\\"{x:625,y:572,t:1528143678097};\\\", \\\"{x:621,y:572,t:1528143678115};\\\", \\\"{x:620,y:572,t:1528143678131};\\\", \\\"{x:618,y:572,t:1528143678148};\\\", \\\"{x:615,y:572,t:1528143678166};\\\", \\\"{x:613,y:572,t:1528143678181};\\\", \\\"{x:611,y:572,t:1528143678197};\\\", \\\"{x:610,y:572,t:1528143678284};\\\", \\\"{x:610,y:572,t:1528143678324};\\\", \\\"{x:608,y:573,t:1528143678404};\\\", \\\"{x:607,y:577,t:1528143678414};\\\", \\\"{x:605,y:584,t:1528143678431};\\\", \\\"{x:601,y:595,t:1528143678449};\\\", \\\"{x:597,y:605,t:1528143678464};\\\", \\\"{x:594,y:611,t:1528143678481};\\\", \\\"{x:590,y:623,t:1528143678498};\\\", \\\"{x:588,y:635,t:1528143678515};\\\", \\\"{x:583,y:643,t:1528143678531};\\\", \\\"{x:581,y:646,t:1528143678548};\\\", \\\"{x:581,y:647,t:1528143678572};\\\", \\\"{x:580,y:649,t:1528143678589};\\\", \\\"{x:579,y:650,t:1528143678598};\\\", \\\"{x:577,y:654,t:1528143678615};\\\", \\\"{x:576,y:657,t:1528143678631};\\\", \\\"{x:573,y:660,t:1528143678647};\\\", \\\"{x:570,y:663,t:1528143678664};\\\", \\\"{x:570,y:665,t:1528143678682};\\\", \\\"{x:569,y:668,t:1528143678698};\\\", \\\"{x:568,y:671,t:1528143678715};\\\", \\\"{x:567,y:675,t:1528143678731};\\\", \\\"{x:567,y:681,t:1528143678748};\\\", \\\"{x:565,y:686,t:1528143678766};\\\", \\\"{x:565,y:690,t:1528143678782};\\\", \\\"{x:565,y:695,t:1528143678798};\\\", \\\"{x:563,y:699,t:1528143678815};\\\", \\\"{x:563,y:703,t:1528143678831};\\\", \\\"{x:562,y:708,t:1528143678847};\\\", \\\"{x:562,y:711,t:1528143678864};\\\", \\\"{x:562,y:714,t:1528143678882};\\\", \\\"{x:561,y:717,t:1528143678898};\\\", \\\"{x:560,y:719,t:1528143678915};\\\", \\\"{x:560,y:720,t:1528143678940};\\\", \\\"{x:559,y:721,t:1528143678950};\\\", \\\"{x:558,y:724,t:1528143678964};\\\", \\\"{x:558,y:725,t:1528143678981};\\\", \\\"{x:557,y:726,t:1528143678998};\\\", \\\"{x:556,y:728,t:1528143679015};\\\", \\\"{x:554,y:730,t:1528143679031};\\\", \\\"{x:553,y:733,t:1528143679048};\\\", \\\"{x:550,y:736,t:1528143679065};\\\", \\\"{x:549,y:737,t:1528143679082};\\\", \\\"{x:548,y:739,t:1528143679098};\\\", \\\"{x:547,y:739,t:1528143679115};\\\", \\\"{x:547,y:740,t:1528143679132};\\\", \\\"{x:546,y:741,t:1528143679148};\\\", \\\"{x:545,y:741,t:1528143679166};\\\", \\\"{x:544,y:742,t:1528143679183};\\\", \\\"{x:544,y:742,t:1528143679264};\\\", \\\"{x:545,y:742,t:1528143679965};\\\", \\\"{x:547,y:741,t:1528143679982};\\\", \\\"{x:548,y:741,t:1528143679999};\\\", \\\"{x:550,y:740,t:1528143680020};\\\", \\\"{x:550,y:739,t:1528143680044};\\\", \\\"{x:552,y:739,t:1528143680069};\\\", \\\"{x:553,y:737,t:1528143680083};\\\", \\\"{x:554,y:736,t:1528143680099};\\\", \\\"{x:557,y:733,t:1528143680115};\\\", \\\"{x:560,y:729,t:1528143680132};\\\", \\\"{x:565,y:724,t:1528143680150};\\\", \\\"{x:574,y:716,t:1528143680166};\\\", \\\"{x:591,y:704,t:1528143680182};\\\", \\\"{x:622,y:685,t:1528143680199};\\\", \\\"{x:674,y:655,t:1528143680216};\\\", \\\"{x:761,y:624,t:1528143680232};\\\", \\\"{x:894,y:588,t:1528143680250};\\\", \\\"{x:1271,y:554,t:1528143680277};\\\", \\\"{x:1400,y:554,t:1528143680284};\\\", \\\"{x:1525,y:554,t:1528143680299};\\\", \\\"{x:1919,y:577,t:1528143680316};\\\", \\\"{x:1919,y:616,t:1528143680332};\\\", \\\"{x:1919,y:654,t:1528143680349};\\\" ] }, { \\\"rt\\\": 33289, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 554654, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -B -B -X -K -K -K \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1919,y:949,t:1528143680471};\\\", \\\"{x:1919,y:952,t:1528143680483};\\\", \\\"{x:1903,y:961,t:1528143680499};\\\", \\\"{x:1789,y:970,t:1528143680516};\\\", \\\"{x:1673,y:958,t:1528143680532};\\\", \\\"{x:1488,y:908,t:1528143680560};\\\", \\\"{x:1427,y:891,t:1528143680566};\\\", \\\"{x:1319,y:861,t:1528143680583};\\\", \\\"{x:1217,y:830,t:1528143680600};\\\", \\\"{x:1139,y:792,t:1528143680617};\\\", \\\"{x:1090,y:767,t:1528143680633};\\\", \\\"{x:1055,y:744,t:1528143680649};\\\", \\\"{x:1041,y:732,t:1528143680667};\\\", \\\"{x:1038,y:728,t:1528143680682};\\\", \\\"{x:1036,y:724,t:1528143680699};\\\", \\\"{x:1034,y:718,t:1528143680716};\\\", \\\"{x:1034,y:716,t:1528143680733};\\\", \\\"{x:1032,y:713,t:1528143680749};\\\", \\\"{x:1028,y:708,t:1528143680767};\\\", \\\"{x:1023,y:702,t:1528143680783};\\\", \\\"{x:1016,y:695,t:1528143680800};\\\", \\\"{x:1010,y:691,t:1528143680817};\\\", \\\"{x:1002,y:686,t:1528143680833};\\\", \\\"{x:995,y:682,t:1528143680849};\\\", \\\"{x:966,y:668,t:1528143680916};\\\", \\\"{x:955,y:659,t:1528143680933};\\\", \\\"{x:942,y:650,t:1528143680949};\\\", \\\"{x:930,y:640,t:1528143680966};\\\", \\\"{x:916,y:630,t:1528143680983};\\\", \\\"{x:906,y:621,t:1528143680999};\\\", \\\"{x:891,y:612,t:1528143681016};\\\", \\\"{x:876,y:603,t:1528143681033};\\\", \\\"{x:860,y:596,t:1528143681051};\\\", \\\"{x:844,y:589,t:1528143681067};\\\", \\\"{x:827,y:581,t:1528143681083};\\\", \\\"{x:806,y:571,t:1528143681100};\\\", \\\"{x:796,y:568,t:1528143681116};\\\", \\\"{x:785,y:564,t:1528143681133};\\\", \\\"{x:777,y:560,t:1528143681150};\\\", \\\"{x:772,y:558,t:1528143681166};\\\", \\\"{x:767,y:555,t:1528143681184};\\\", \\\"{x:762,y:552,t:1528143681200};\\\", \\\"{x:758,y:548,t:1528143681216};\\\", \\\"{x:749,y:542,t:1528143681233};\\\", \\\"{x:736,y:534,t:1528143681250};\\\", \\\"{x:721,y:524,t:1528143681267};\\\", \\\"{x:704,y:517,t:1528143681284};\\\", \\\"{x:670,y:502,t:1528143681300};\\\", \\\"{x:645,y:494,t:1528143681316};\\\", \\\"{x:621,y:486,t:1528143681334};\\\", \\\"{x:600,y:479,t:1528143681350};\\\", \\\"{x:575,y:473,t:1528143681366};\\\", \\\"{x:560,y:466,t:1528143681384};\\\", \\\"{x:541,y:459,t:1528143681401};\\\", \\\"{x:528,y:452,t:1528143681416};\\\", \\\"{x:518,y:448,t:1528143681433};\\\", \\\"{x:514,y:446,t:1528143681451};\\\", \\\"{x:511,y:444,t:1528143681467};\\\", \\\"{x:508,y:443,t:1528143681483};\\\", \\\"{x:504,y:441,t:1528143681501};\\\", \\\"{x:502,y:440,t:1528143681517};\\\", \\\"{x:499,y:440,t:1528143681534};\\\", \\\"{x:495,y:438,t:1528143681550};\\\", \\\"{x:493,y:438,t:1528143681567};\\\", \\\"{x:489,y:438,t:1528143681583};\\\", \\\"{x:484,y:437,t:1528143681601};\\\", \\\"{x:479,y:437,t:1528143681617};\\\", \\\"{x:474,y:436,t:1528143681634};\\\", \\\"{x:469,y:434,t:1528143681651};\\\", \\\"{x:466,y:433,t:1528143681667};\\\", \\\"{x:464,y:433,t:1528143681683};\\\", \\\"{x:458,y:430,t:1528143681699};\\\", \\\"{x:455,y:428,t:1528143681716};\\\", \\\"{x:451,y:426,t:1528143681733};\\\", \\\"{x:448,y:425,t:1528143681751};\\\", \\\"{x:446,y:423,t:1528143681780};\\\", \\\"{x:445,y:423,t:1528143686309};\\\", \\\"{x:449,y:421,t:1528143686965};\\\", \\\"{x:463,y:415,t:1528143686983};\\\", \\\"{x:473,y:410,t:1528143687000};\\\", \\\"{x:483,y:406,t:1528143687016};\\\", \\\"{x:488,y:403,t:1528143687033};\\\", \\\"{x:493,y:402,t:1528143687050};\\\", \\\"{x:499,y:399,t:1528143687066};\\\", \\\"{x:515,y:398,t:1528143687083};\\\", \\\"{x:530,y:397,t:1528143687100};\\\", \\\"{x:549,y:395,t:1528143687116};\\\", \\\"{x:574,y:393,t:1528143687133};\\\", \\\"{x:592,y:390,t:1528143687150};\\\", \\\"{x:614,y:388,t:1528143687166};\\\", \\\"{x:639,y:384,t:1528143687183};\\\", \\\"{x:665,y:383,t:1528143687200};\\\", \\\"{x:687,y:381,t:1528143687215};\\\", \\\"{x:710,y:378,t:1528143687232};\\\", \\\"{x:732,y:378,t:1528143687250};\\\", \\\"{x:759,y:378,t:1528143687266};\\\", \\\"{x:793,y:378,t:1528143687283};\\\", \\\"{x:837,y:378,t:1528143687300};\\\", \\\"{x:871,y:378,t:1528143687316};\\\", \\\"{x:913,y:378,t:1528143687333};\\\", \\\"{x:954,y:378,t:1528143687350};\\\", \\\"{x:993,y:378,t:1528143687366};\\\", \\\"{x:1044,y:378,t:1528143687383};\\\", \\\"{x:1078,y:378,t:1528143687400};\\\", \\\"{x:1107,y:378,t:1528143687416};\\\", \\\"{x:1136,y:378,t:1528143687433};\\\", \\\"{x:1151,y:378,t:1528143687450};\\\", \\\"{x:1156,y:378,t:1528143687466};\\\", \\\"{x:1157,y:378,t:1528143687483};\\\", \\\"{x:1158,y:378,t:1528143687629};\\\", \\\"{x:1158,y:377,t:1528143687645};\\\", \\\"{x:1158,y:374,t:1528143687661};\\\", \\\"{x:1158,y:371,t:1528143687669};\\\", \\\"{x:1159,y:367,t:1528143687683};\\\", \\\"{x:1164,y:358,t:1528143687699};\\\", \\\"{x:1170,y:347,t:1528143687716};\\\", \\\"{x:1175,y:332,t:1528143687732};\\\", \\\"{x:1175,y:327,t:1528143687749};\\\", \\\"{x:1176,y:325,t:1528143687766};\\\", \\\"{x:1177,y:324,t:1528143687783};\\\", \\\"{x:1178,y:322,t:1528143687884};\\\", \\\"{x:1182,y:320,t:1528143687899};\\\", \\\"{x:1199,y:313,t:1528143687915};\\\", \\\"{x:1214,y:311,t:1528143687932};\\\", \\\"{x:1226,y:309,t:1528143687949};\\\", \\\"{x:1240,y:309,t:1528143687965};\\\", \\\"{x:1249,y:309,t:1528143687983};\\\", \\\"{x:1260,y:314,t:1528143687999};\\\", \\\"{x:1274,y:321,t:1528143688016};\\\", \\\"{x:1289,y:331,t:1528143688033};\\\", \\\"{x:1301,y:340,t:1528143688049};\\\", \\\"{x:1316,y:352,t:1528143688066};\\\", \\\"{x:1334,y:368,t:1528143688082};\\\", \\\"{x:1348,y:379,t:1528143688098};\\\", \\\"{x:1365,y:391,t:1528143688116};\\\", \\\"{x:1385,y:406,t:1528143688132};\\\", \\\"{x:1396,y:414,t:1528143688149};\\\", \\\"{x:1403,y:422,t:1528143688165};\\\", \\\"{x:1408,y:429,t:1528143688182};\\\", \\\"{x:1412,y:439,t:1528143688199};\\\", \\\"{x:1417,y:447,t:1528143688216};\\\", \\\"{x:1418,y:451,t:1528143688233};\\\", \\\"{x:1418,y:453,t:1528143688250};\\\", \\\"{x:1418,y:456,t:1528143688266};\\\", \\\"{x:1418,y:458,t:1528143688283};\\\", \\\"{x:1418,y:461,t:1528143688299};\\\", \\\"{x:1418,y:465,t:1528143688316};\\\", \\\"{x:1416,y:468,t:1528143688333};\\\", \\\"{x:1415,y:471,t:1528143688348};\\\", \\\"{x:1414,y:472,t:1528143688461};\\\", \\\"{x:1412,y:472,t:1528143688469};\\\", \\\"{x:1408,y:473,t:1528143688483};\\\", \\\"{x:1403,y:474,t:1528143688499};\\\", \\\"{x:1391,y:479,t:1528143688516};\\\", \\\"{x:1377,y:482,t:1528143688532};\\\", \\\"{x:1364,y:486,t:1528143688549};\\\", \\\"{x:1356,y:488,t:1528143688566};\\\", \\\"{x:1354,y:489,t:1528143688583};\\\", \\\"{x:1353,y:489,t:1528143688709};\\\", \\\"{x:1353,y:487,t:1528143688717};\\\", \\\"{x:1353,y:483,t:1528143688732};\\\", \\\"{x:1352,y:482,t:1528143688748};\\\", \\\"{x:1352,y:481,t:1528143688940};\\\", \\\"{x:1352,y:480,t:1528143688949};\\\", \\\"{x:1352,y:479,t:1528143688988};\\\", \\\"{x:1352,y:478,t:1528143689085};\\\", \\\"{x:1353,y:478,t:1528143689101};\\\", \\\"{x:1354,y:478,t:1528143689116};\\\", \\\"{x:1355,y:478,t:1528143689132};\\\", \\\"{x:1358,y:476,t:1528143689149};\\\", \\\"{x:1360,y:475,t:1528143689166};\\\", \\\"{x:1362,y:474,t:1528143689183};\\\", \\\"{x:1362,y:472,t:1528143689199};\\\", \\\"{x:1363,y:472,t:1528143689217};\\\", \\\"{x:1364,y:472,t:1528143689233};\\\", \\\"{x:1365,y:471,t:1528143689249};\\\", \\\"{x:1366,y:471,t:1528143689266};\\\", \\\"{x:1367,y:471,t:1528143689284};\\\", \\\"{x:1368,y:471,t:1528143689301};\\\", \\\"{x:1369,y:471,t:1528143689317};\\\", \\\"{x:1370,y:471,t:1528143689332};\\\", \\\"{x:1371,y:471,t:1528143689389};\\\", \\\"{x:1373,y:471,t:1528143689399};\\\", \\\"{x:1374,y:471,t:1528143689417};\\\", \\\"{x:1377,y:470,t:1528143689432};\\\", \\\"{x:1377,y:469,t:1528143689449};\\\", \\\"{x:1379,y:469,t:1528143689581};\\\", \\\"{x:1380,y:469,t:1528143689599};\\\", \\\"{x:1386,y:469,t:1528143689616};\\\", \\\"{x:1393,y:466,t:1528143689632};\\\", \\\"{x:1405,y:463,t:1528143689649};\\\", \\\"{x:1419,y:459,t:1528143689666};\\\", \\\"{x:1431,y:455,t:1528143689683};\\\", \\\"{x:1440,y:454,t:1528143689699};\\\", \\\"{x:1447,y:454,t:1528143689716};\\\", \\\"{x:1451,y:455,t:1528143689733};\\\", \\\"{x:1452,y:455,t:1528143689925};\\\", \\\"{x:1453,y:458,t:1528143692014};\\\", \\\"{x:1453,y:468,t:1528143692021};\\\", \\\"{x:1453,y:479,t:1528143692033};\\\", \\\"{x:1449,y:502,t:1528143692049};\\\", \\\"{x:1444,y:525,t:1528143692065};\\\", \\\"{x:1438,y:543,t:1528143692083};\\\", \\\"{x:1431,y:559,t:1528143692100};\\\", \\\"{x:1427,y:566,t:1528143692115};\\\", \\\"{x:1421,y:581,t:1528143692132};\\\", \\\"{x:1418,y:595,t:1528143692149};\\\", \\\"{x:1412,y:612,t:1528143692166};\\\", \\\"{x:1407,y:628,t:1528143692182};\\\", \\\"{x:1404,y:638,t:1528143692199};\\\", \\\"{x:1401,y:650,t:1528143692215};\\\", \\\"{x:1397,y:662,t:1528143692232};\\\", \\\"{x:1394,y:671,t:1528143692248};\\\", \\\"{x:1392,y:678,t:1528143692266};\\\", \\\"{x:1390,y:685,t:1528143692283};\\\", \\\"{x:1388,y:691,t:1528143692299};\\\", \\\"{x:1384,y:699,t:1528143692315};\\\", \\\"{x:1380,y:708,t:1528143692333};\\\", \\\"{x:1376,y:713,t:1528143692349};\\\", \\\"{x:1373,y:719,t:1528143692366};\\\", \\\"{x:1371,y:724,t:1528143692383};\\\", \\\"{x:1367,y:731,t:1528143692399};\\\", \\\"{x:1362,y:737,t:1528143692415};\\\", \\\"{x:1359,y:743,t:1528143692433};\\\", \\\"{x:1356,y:748,t:1528143692448};\\\", \\\"{x:1355,y:752,t:1528143692466};\\\", \\\"{x:1353,y:754,t:1528143692482};\\\", \\\"{x:1353,y:755,t:1528143692694};\\\", \\\"{x:1351,y:756,t:1528143692701};\\\", \\\"{x:1351,y:758,t:1528143692716};\\\", \\\"{x:1349,y:760,t:1528143692733};\\\", \\\"{x:1349,y:761,t:1528143692749};\\\", \\\"{x:1349,y:762,t:1528143692765};\\\", \\\"{x:1348,y:762,t:1528143701240};\\\", \\\"{x:1349,y:756,t:1528143701251};\\\", \\\"{x:1367,y:749,t:1528143701267};\\\", \\\"{x:1391,y:742,t:1528143701283};\\\", \\\"{x:1417,y:737,t:1528143701301};\\\", \\\"{x:1432,y:735,t:1528143701316};\\\", \\\"{x:1440,y:735,t:1528143701333};\\\", \\\"{x:1444,y:735,t:1528143701351};\\\", \\\"{x:1449,y:735,t:1528143701367};\\\", \\\"{x:1451,y:735,t:1528143701383};\\\", \\\"{x:1454,y:735,t:1528143701400};\\\", \\\"{x:1459,y:735,t:1528143701416};\\\", \\\"{x:1466,y:735,t:1528143701434};\\\", \\\"{x:1482,y:735,t:1528143701450};\\\", \\\"{x:1498,y:735,t:1528143701467};\\\", \\\"{x:1518,y:735,t:1528143701483};\\\", \\\"{x:1536,y:735,t:1528143701500};\\\", \\\"{x:1551,y:735,t:1528143701516};\\\", \\\"{x:1563,y:736,t:1528143701533};\\\", \\\"{x:1567,y:737,t:1528143701550};\\\", \\\"{x:1579,y:741,t:1528143701566};\\\", \\\"{x:1589,y:745,t:1528143701583};\\\", \\\"{x:1594,y:748,t:1528143701600};\\\", \\\"{x:1597,y:749,t:1528143701617};\\\", \\\"{x:1598,y:750,t:1528143701634};\\\", \\\"{x:1598,y:753,t:1528143701840};\\\", \\\"{x:1593,y:757,t:1528143701850};\\\", \\\"{x:1579,y:767,t:1528143701866};\\\", \\\"{x:1559,y:779,t:1528143701884};\\\", \\\"{x:1542,y:787,t:1528143701901};\\\", \\\"{x:1529,y:792,t:1528143701916};\\\", \\\"{x:1520,y:795,t:1528143701934};\\\", \\\"{x:1516,y:795,t:1528143701949};\\\", \\\"{x:1510,y:796,t:1528143701966};\\\", \\\"{x:1492,y:799,t:1528143701983};\\\", \\\"{x:1485,y:799,t:1528143702000};\\\", \\\"{x:1481,y:801,t:1528143702016};\\\", \\\"{x:1476,y:802,t:1528143702033};\\\", \\\"{x:1473,y:804,t:1528143702050};\\\", \\\"{x:1466,y:809,t:1528143702067};\\\", \\\"{x:1464,y:811,t:1528143702083};\\\", \\\"{x:1463,y:812,t:1528143702100};\\\", \\\"{x:1462,y:814,t:1528143702117};\\\", \\\"{x:1462,y:815,t:1528143702133};\\\", \\\"{x:1462,y:816,t:1528143702151};\\\", \\\"{x:1463,y:817,t:1528143702167};\\\", \\\"{x:1465,y:818,t:1528143702184};\\\", \\\"{x:1468,y:819,t:1528143702199};\\\", \\\"{x:1469,y:819,t:1528143702217};\\\", \\\"{x:1471,y:821,t:1528143702233};\\\", \\\"{x:1472,y:821,t:1528143702249};\\\", \\\"{x:1474,y:821,t:1528143702271};\\\", \\\"{x:1474,y:822,t:1528143702288};\\\", \\\"{x:1474,y:823,t:1528143702311};\\\", \\\"{x:1474,y:824,t:1528143702319};\\\", \\\"{x:1475,y:825,t:1528143702335};\\\", \\\"{x:1475,y:826,t:1528143702349};\\\", \\\"{x:1475,y:827,t:1528143702366};\\\", \\\"{x:1476,y:828,t:1528143702390};\\\", \\\"{x:1477,y:828,t:1528143702462};\\\", \\\"{x:1478,y:829,t:1528143702486};\\\", \\\"{x:1479,y:830,t:1528143702498};\\\", \\\"{x:1480,y:830,t:1528143702516};\\\", \\\"{x:1481,y:830,t:1528143702551};\\\", \\\"{x:1482,y:831,t:1528143702607};\\\", \\\"{x:1483,y:831,t:1528143702672};\\\", \\\"{x:1484,y:831,t:1528143702783};\\\", \\\"{x:1485,y:831,t:1528143702823};\\\", \\\"{x:1486,y:831,t:1528143702834};\\\", \\\"{x:1486,y:830,t:1528143709368};\\\", \\\"{x:1486,y:827,t:1528143709382};\\\", \\\"{x:1486,y:814,t:1528143709400};\\\", \\\"{x:1486,y:805,t:1528143709415};\\\", \\\"{x:1486,y:798,t:1528143709432};\\\", \\\"{x:1485,y:790,t:1528143709448};\\\", \\\"{x:1483,y:784,t:1528143709465};\\\", \\\"{x:1482,y:776,t:1528143709482};\\\", \\\"{x:1482,y:764,t:1528143709498};\\\", \\\"{x:1482,y:751,t:1528143709516};\\\", \\\"{x:1480,y:736,t:1528143709532};\\\", \\\"{x:1478,y:722,t:1528143709549};\\\", \\\"{x:1478,y:712,t:1528143709566};\\\", \\\"{x:1477,y:708,t:1528143709582};\\\", \\\"{x:1476,y:705,t:1528143709599};\\\", \\\"{x:1476,y:703,t:1528143709687};\\\", \\\"{x:1476,y:701,t:1528143709698};\\\", \\\"{x:1476,y:698,t:1528143709716};\\\", \\\"{x:1476,y:695,t:1528143709731};\\\", \\\"{x:1476,y:692,t:1528143709748};\\\", \\\"{x:1475,y:686,t:1528143709766};\\\", \\\"{x:1473,y:677,t:1528143709782};\\\", \\\"{x:1472,y:658,t:1528143709799};\\\", \\\"{x:1470,y:641,t:1528143709815};\\\", \\\"{x:1470,y:619,t:1528143709832};\\\", \\\"{x:1470,y:592,t:1528143709849};\\\", \\\"{x:1470,y:556,t:1528143709866};\\\", \\\"{x:1470,y:500,t:1528143709882};\\\", \\\"{x:1470,y:444,t:1528143709898};\\\", \\\"{x:1465,y:384,t:1528143709916};\\\", \\\"{x:1465,y:345,t:1528143709932};\\\", \\\"{x:1461,y:314,t:1528143709949};\\\", \\\"{x:1459,y:293,t:1528143709966};\\\", \\\"{x:1457,y:281,t:1528143709982};\\\", \\\"{x:1455,y:277,t:1528143709999};\\\", \\\"{x:1456,y:278,t:1528143710175};\\\", \\\"{x:1457,y:279,t:1528143710183};\\\", \\\"{x:1461,y:285,t:1528143710199};\\\", \\\"{x:1470,y:289,t:1528143710215};\\\", \\\"{x:1476,y:290,t:1528143710232};\\\", \\\"{x:1482,y:293,t:1528143710249};\\\", \\\"{x:1485,y:294,t:1528143710265};\\\", \\\"{x:1488,y:295,t:1528143710285};\\\", \\\"{x:1489,y:296,t:1528143710298};\\\", \\\"{x:1482,y:300,t:1528143711479};\\\", \\\"{x:1453,y:308,t:1528143711500};\\\", \\\"{x:1395,y:325,t:1528143711515};\\\", \\\"{x:1315,y:345,t:1528143711531};\\\", \\\"{x:1231,y:360,t:1528143711549};\\\", \\\"{x:1139,y:372,t:1528143711564};\\\", \\\"{x:1047,y:389,t:1528143711582};\\\", \\\"{x:966,y:402,t:1528143711598};\\\", \\\"{x:875,y:417,t:1528143711615};\\\", \\\"{x:835,y:430,t:1528143711631};\\\", \\\"{x:808,y:438,t:1528143711648};\\\", \\\"{x:792,y:446,t:1528143711665};\\\", \\\"{x:781,y:452,t:1528143711681};\\\", \\\"{x:776,y:455,t:1528143711698};\\\", \\\"{x:772,y:459,t:1528143711714};\\\", \\\"{x:766,y:462,t:1528143711731};\\\", \\\"{x:762,y:464,t:1528143711747};\\\", \\\"{x:758,y:467,t:1528143711764};\\\", \\\"{x:747,y:472,t:1528143711781};\\\", \\\"{x:730,y:481,t:1528143711797};\\\", \\\"{x:700,y:496,t:1528143711814};\\\", \\\"{x:681,y:506,t:1528143711831};\\\", \\\"{x:663,y:513,t:1528143711847};\\\", \\\"{x:655,y:516,t:1528143711862};\\\", \\\"{x:643,y:520,t:1528143711878};\\\", \\\"{x:634,y:522,t:1528143711894};\\\", \\\"{x:626,y:526,t:1528143711911};\\\", \\\"{x:619,y:529,t:1528143711928};\\\", \\\"{x:613,y:531,t:1528143711944};\\\", \\\"{x:603,y:536,t:1528143711961};\\\", \\\"{x:593,y:539,t:1528143711978};\\\", \\\"{x:577,y:546,t:1528143711994};\\\", \\\"{x:562,y:550,t:1528143712011};\\\", \\\"{x:547,y:554,t:1528143712028};\\\", \\\"{x:529,y:557,t:1528143712045};\\\", \\\"{x:513,y:560,t:1528143712061};\\\", \\\"{x:486,y:560,t:1528143712078};\\\", \\\"{x:468,y:560,t:1528143712094};\\\", \\\"{x:452,y:560,t:1528143712111};\\\", \\\"{x:443,y:560,t:1528143712127};\\\", \\\"{x:438,y:560,t:1528143712144};\\\", \\\"{x:433,y:560,t:1528143712162};\\\", \\\"{x:432,y:560,t:1528143712177};\\\", \\\"{x:427,y:560,t:1528143712194};\\\", \\\"{x:422,y:560,t:1528143712211};\\\", \\\"{x:411,y:560,t:1528143712227};\\\", \\\"{x:400,y:560,t:1528143712244};\\\", \\\"{x:391,y:560,t:1528143712261};\\\", \\\"{x:382,y:560,t:1528143712277};\\\", \\\"{x:363,y:560,t:1528143712294};\\\", \\\"{x:349,y:560,t:1528143712312};\\\", \\\"{x:333,y:560,t:1528143712327};\\\", \\\"{x:319,y:560,t:1528143712345};\\\", \\\"{x:304,y:560,t:1528143712361};\\\", \\\"{x:294,y:560,t:1528143712378};\\\", \\\"{x:281,y:563,t:1528143712395};\\\", \\\"{x:279,y:565,t:1528143712411};\\\", \\\"{x:278,y:565,t:1528143712430};\\\", \\\"{x:278,y:566,t:1528143712503};\\\", \\\"{x:281,y:568,t:1528143712512};\\\", \\\"{x:298,y:568,t:1528143712528};\\\", \\\"{x:315,y:566,t:1528143712546};\\\", \\\"{x:330,y:566,t:1528143712562};\\\", \\\"{x:337,y:566,t:1528143712578};\\\", \\\"{x:343,y:566,t:1528143712595};\\\", \\\"{x:344,y:566,t:1528143712611};\\\", \\\"{x:345,y:566,t:1528143712638};\\\", \\\"{x:346,y:566,t:1528143712654};\\\", \\\"{x:347,y:566,t:1528143712671};\\\", \\\"{x:348,y:566,t:1528143712679};\\\", \\\"{x:349,y:567,t:1528143712695};\\\", \\\"{x:351,y:567,t:1528143712712};\\\", \\\"{x:354,y:569,t:1528143712728};\\\", \\\"{x:356,y:570,t:1528143712746};\\\", \\\"{x:360,y:572,t:1528143712761};\\\", \\\"{x:365,y:573,t:1528143712778};\\\", \\\"{x:369,y:575,t:1528143712795};\\\", \\\"{x:373,y:577,t:1528143712812};\\\", \\\"{x:376,y:578,t:1528143712830};\\\", \\\"{x:377,y:578,t:1528143712845};\\\", \\\"{x:380,y:580,t:1528143712861};\\\", \\\"{x:384,y:580,t:1528143712878};\\\", \\\"{x:385,y:580,t:1528143712896};\\\", \\\"{x:387,y:581,t:1528143712912};\\\", \\\"{x:388,y:582,t:1528143713150};\\\", \\\"{x:388,y:586,t:1528143713166};\\\", \\\"{x:390,y:590,t:1528143713179};\\\", \\\"{x:396,y:601,t:1528143713196};\\\", \\\"{x:416,y:623,t:1528143713213};\\\", \\\"{x:432,y:642,t:1528143713229};\\\", \\\"{x:444,y:654,t:1528143713245};\\\", \\\"{x:454,y:663,t:1528143713263};\\\", \\\"{x:458,y:665,t:1528143713278};\\\", \\\"{x:459,y:666,t:1528143713295};\\\", \\\"{x:460,y:667,t:1528143713319};\\\", \\\"{x:461,y:668,t:1528143713343};\\\", \\\"{x:462,y:669,t:1528143713350};\\\", \\\"{x:462,y:670,t:1528143713363};\\\", \\\"{x:467,y:679,t:1528143713380};\\\", \\\"{x:472,y:694,t:1528143713395};\\\", \\\"{x:477,y:704,t:1528143713413};\\\", \\\"{x:481,y:714,t:1528143713430};\\\", \\\"{x:485,y:723,t:1528143713446};\\\", \\\"{x:488,y:728,t:1528143713462};\\\", \\\"{x:490,y:729,t:1528143713479};\\\", \\\"{x:490,y:731,t:1528143713495};\\\", \\\"{x:490,y:733,t:1528143713559};\\\", \\\"{x:490,y:736,t:1528143713566};\\\", \\\"{x:490,y:739,t:1528143713580};\\\", \\\"{x:495,y:747,t:1528143713596};\\\", \\\"{x:497,y:753,t:1528143713612};\\\", \\\"{x:499,y:754,t:1528143713629};\\\", \\\"{x:499,y:753,t:1528143714023};\\\", \\\"{x:499,y:751,t:1528143714047};\\\", \\\"{x:500,y:749,t:1528143714079};\\\", \\\"{x:500,y:748,t:1528143714111};\\\", \\\"{x:500,y:747,t:1528143714126};\\\", \\\"{x:501,y:746,t:1528143714134};\\\", \\\"{x:501,y:744,t:1528143714147};\\\", \\\"{x:501,y:741,t:1528143714163};\\\", \\\"{x:502,y:735,t:1528143714180};\\\", \\\"{x:504,y:725,t:1528143714197};\\\", \\\"{x:509,y:710,t:1528143714213};\\\", \\\"{x:516,y:692,t:1528143714229};\\\", \\\"{x:553,y:625,t:1528143714246};\\\", \\\"{x:603,y:538,t:1528143714262};\\\", \\\"{x:650,y:475,t:1528143714280};\\\", \\\"{x:682,y:437,t:1528143714296};\\\", \\\"{x:694,y:421,t:1528143714313};\\\", \\\"{x:709,y:403,t:1528143714329};\\\", \\\"{x:721,y:389,t:1528143714346};\\\", \\\"{x:724,y:383,t:1528143714363};\\\", \\\"{x:726,y:379,t:1528143714380};\\\", \\\"{x:727,y:378,t:1528143714396};\\\", \\\"{x:727,y:377,t:1528143714470};\\\" ] }, { \\\"rt\\\": 31894, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 587780, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -B -3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:731,y:377,t:1528143717392};\\\", \\\"{x:742,y:383,t:1528143717399};\\\", \\\"{x:778,y:402,t:1528143717415};\\\", \\\"{x:826,y:428,t:1528143717431};\\\", \\\"{x:865,y:446,t:1528143717448};\\\", \\\"{x:929,y:476,t:1528143717466};\\\", \\\"{x:996,y:504,t:1528143717483};\\\", \\\"{x:1064,y:533,t:1528143717498};\\\", \\\"{x:1120,y:559,t:1528143717515};\\\", \\\"{x:1151,y:573,t:1528143717532};\\\", \\\"{x:1168,y:580,t:1528143717549};\\\", \\\"{x:1172,y:582,t:1528143717566};\\\", \\\"{x:1174,y:583,t:1528143717583};\\\", \\\"{x:1175,y:583,t:1528143717688};\\\", \\\"{x:1176,y:583,t:1528143717700};\\\", \\\"{x:1179,y:583,t:1528143717716};\\\", \\\"{x:1182,y:585,t:1528143717733};\\\", \\\"{x:1187,y:586,t:1528143717749};\\\", \\\"{x:1198,y:591,t:1528143717766};\\\", \\\"{x:1221,y:602,t:1528143717783};\\\", \\\"{x:1239,y:610,t:1528143717799};\\\", \\\"{x:1260,y:617,t:1528143717816};\\\", \\\"{x:1283,y:627,t:1528143717833};\\\", \\\"{x:1305,y:635,t:1528143717850};\\\", \\\"{x:1328,y:645,t:1528143717866};\\\", \\\"{x:1352,y:654,t:1528143717883};\\\", \\\"{x:1373,y:662,t:1528143717900};\\\", \\\"{x:1393,y:671,t:1528143717916};\\\", \\\"{x:1410,y:675,t:1528143717933};\\\", \\\"{x:1421,y:680,t:1528143717950};\\\", \\\"{x:1429,y:684,t:1528143717966};\\\", \\\"{x:1441,y:689,t:1528143717983};\\\", \\\"{x:1445,y:692,t:1528143717999};\\\", \\\"{x:1447,y:693,t:1528143718016};\\\", \\\"{x:1450,y:695,t:1528143718033};\\\", \\\"{x:1453,y:696,t:1528143718050};\\\", \\\"{x:1454,y:698,t:1528143718067};\\\", \\\"{x:1456,y:698,t:1528143718083};\\\", \\\"{x:1456,y:699,t:1528143718100};\\\", \\\"{x:1458,y:699,t:1528143718115};\\\", \\\"{x:1458,y:701,t:1528143718222};\\\", \\\"{x:1458,y:703,t:1528143718238};\\\", \\\"{x:1458,y:704,t:1528143718254};\\\", \\\"{x:1458,y:706,t:1528143718265};\\\", \\\"{x:1458,y:708,t:1528143718283};\\\", \\\"{x:1458,y:709,t:1528143718300};\\\", \\\"{x:1457,y:710,t:1528143718316};\\\", \\\"{x:1457,y:711,t:1528143718333};\\\", \\\"{x:1457,y:713,t:1528143718350};\\\", \\\"{x:1456,y:714,t:1528143718365};\\\", \\\"{x:1455,y:716,t:1528143718382};\\\", \\\"{x:1455,y:717,t:1528143718414};\\\", \\\"{x:1455,y:718,t:1528143718423};\\\", \\\"{x:1455,y:719,t:1528143718433};\\\", \\\"{x:1454,y:720,t:1528143718455};\\\", \\\"{x:1454,y:721,t:1528143718487};\\\", \\\"{x:1454,y:722,t:1528143718500};\\\", \\\"{x:1452,y:724,t:1528143718517};\\\", \\\"{x:1452,y:725,t:1528143718533};\\\", \\\"{x:1452,y:726,t:1528143718550};\\\", \\\"{x:1451,y:727,t:1528143718567};\\\", \\\"{x:1451,y:728,t:1528143718623};\\\", \\\"{x:1451,y:729,t:1528143718663};\\\", \\\"{x:1451,y:730,t:1528143718679};\\\", \\\"{x:1451,y:731,t:1528143718695};\\\", \\\"{x:1451,y:732,t:1528143718703};\\\", \\\"{x:1451,y:733,t:1528143718717};\\\", \\\"{x:1451,y:736,t:1528143718733};\\\", \\\"{x:1451,y:737,t:1528143718750};\\\", \\\"{x:1451,y:738,t:1528143718766};\\\", \\\"{x:1451,y:739,t:1528143718782};\\\", \\\"{x:1451,y:740,t:1528143718799};\\\", \\\"{x:1451,y:741,t:1528143718817};\\\", \\\"{x:1451,y:742,t:1528143718833};\\\", \\\"{x:1451,y:744,t:1528143718850};\\\", \\\"{x:1451,y:745,t:1528143718866};\\\", \\\"{x:1451,y:746,t:1528143718886};\\\", \\\"{x:1451,y:747,t:1528143718903};\\\", \\\"{x:1451,y:748,t:1528143718919};\\\", \\\"{x:1452,y:750,t:1528143718934};\\\", \\\"{x:1452,y:751,t:1528143718950};\\\", \\\"{x:1453,y:752,t:1528143718966};\\\", \\\"{x:1453,y:753,t:1528143718990};\\\", \\\"{x:1453,y:754,t:1528143719000};\\\", \\\"{x:1456,y:756,t:1528143719016};\\\", \\\"{x:1456,y:757,t:1528143719034};\\\", \\\"{x:1458,y:759,t:1528143719050};\\\", \\\"{x:1460,y:763,t:1528143719067};\\\", \\\"{x:1464,y:765,t:1528143719084};\\\", \\\"{x:1471,y:771,t:1528143719100};\\\", \\\"{x:1477,y:775,t:1528143719116};\\\", \\\"{x:1483,y:780,t:1528143719134};\\\", \\\"{x:1485,y:781,t:1528143719150};\\\", \\\"{x:1491,y:784,t:1528143719167};\\\", \\\"{x:1491,y:785,t:1528143719184};\\\", \\\"{x:1490,y:785,t:1528143719320};\\\", \\\"{x:1484,y:787,t:1528143719334};\\\", \\\"{x:1472,y:789,t:1528143719351};\\\", \\\"{x:1454,y:789,t:1528143719367};\\\", \\\"{x:1446,y:789,t:1528143719384};\\\", \\\"{x:1440,y:789,t:1528143719401};\\\", \\\"{x:1432,y:789,t:1528143719417};\\\", \\\"{x:1426,y:789,t:1528143719434};\\\", \\\"{x:1420,y:788,t:1528143719451};\\\", \\\"{x:1411,y:787,t:1528143719467};\\\", \\\"{x:1400,y:784,t:1528143719484};\\\", \\\"{x:1383,y:782,t:1528143719502};\\\", \\\"{x:1368,y:781,t:1528143719517};\\\", \\\"{x:1356,y:777,t:1528143719534};\\\", \\\"{x:1340,y:772,t:1528143719551};\\\", \\\"{x:1331,y:769,t:1528143719567};\\\", \\\"{x:1324,y:768,t:1528143719584};\\\", \\\"{x:1319,y:767,t:1528143719601};\\\", \\\"{x:1316,y:766,t:1528143719618};\\\", \\\"{x:1315,y:766,t:1528143719634};\\\", \\\"{x:1314,y:765,t:1528143719651};\\\", \\\"{x:1315,y:764,t:1528143719760};\\\", \\\"{x:1316,y:764,t:1528143719767};\\\", \\\"{x:1320,y:764,t:1528143719784};\\\", \\\"{x:1321,y:764,t:1528143719801};\\\", \\\"{x:1323,y:764,t:1528143719818};\\\", \\\"{x:1324,y:764,t:1528143719834};\\\", \\\"{x:1326,y:764,t:1528143719851};\\\", \\\"{x:1327,y:764,t:1528143719867};\\\", \\\"{x:1328,y:764,t:1528143719887};\\\", \\\"{x:1329,y:764,t:1528143719901};\\\", \\\"{x:1330,y:764,t:1528143719919};\\\", \\\"{x:1331,y:764,t:1528143719935};\\\", \\\"{x:1332,y:764,t:1528143719951};\\\", \\\"{x:1333,y:764,t:1528143719968};\\\", \\\"{x:1334,y:764,t:1528143719990};\\\", \\\"{x:1335,y:764,t:1528143720001};\\\", \\\"{x:1336,y:764,t:1528143720018};\\\", \\\"{x:1338,y:764,t:1528143720034};\\\", \\\"{x:1339,y:765,t:1528143720055};\\\", \\\"{x:1343,y:766,t:1528143720074};\\\", \\\"{x:1346,y:766,t:1528143720100};\\\", \\\"{x:1347,y:768,t:1528143720117};\\\", \\\"{x:1347,y:764,t:1528143722479};\\\", \\\"{x:1347,y:762,t:1528143722487};\\\", \\\"{x:1347,y:759,t:1528143722503};\\\", \\\"{x:1347,y:757,t:1528143722521};\\\", \\\"{x:1347,y:754,t:1528143722537};\\\", \\\"{x:1347,y:753,t:1528143725215};\\\", \\\"{x:1347,y:754,t:1528143725343};\\\", \\\"{x:1347,y:755,t:1528143725375};\\\", \\\"{x:1347,y:756,t:1528143725388};\\\", \\\"{x:1349,y:758,t:1528143725406};\\\", \\\"{x:1349,y:760,t:1528143725438};\\\", \\\"{x:1349,y:761,t:1528143725455};\\\", \\\"{x:1349,y:764,t:1528143725471};\\\", \\\"{x:1349,y:765,t:1528143725488};\\\", \\\"{x:1349,y:766,t:1528143725505};\\\", \\\"{x:1349,y:767,t:1528143725521};\\\", \\\"{x:1350,y:769,t:1528143725552};\\\", \\\"{x:1350,y:770,t:1528143725583};\\\", \\\"{x:1351,y:770,t:1528143725591};\\\", \\\"{x:1352,y:771,t:1528143725679};\\\", \\\"{x:1352,y:770,t:1528143726104};\\\", \\\"{x:1352,y:769,t:1528143726143};\\\", \\\"{x:1352,y:768,t:1528143726156};\\\", \\\"{x:1352,y:767,t:1528143726175};\\\", \\\"{x:1352,y:765,t:1528143726535};\\\", \\\"{x:1352,y:764,t:1528143727647};\\\", \\\"{x:1350,y:764,t:1528143727720};\\\", \\\"{x:1350,y:763,t:1528143727759};\\\", \\\"{x:1349,y:763,t:1528143741759};\\\", \\\"{x:1344,y:767,t:1528143741766};\\\", \\\"{x:1337,y:776,t:1528143741786};\\\", \\\"{x:1328,y:787,t:1528143741799};\\\", \\\"{x:1322,y:792,t:1528143741816};\\\", \\\"{x:1321,y:792,t:1528143741959};\\\", \\\"{x:1320,y:795,t:1528143741967};\\\", \\\"{x:1316,y:802,t:1528143741984};\\\", \\\"{x:1314,y:811,t:1528143742000};\\\", \\\"{x:1309,y:826,t:1528143742017};\\\", \\\"{x:1304,y:840,t:1528143742035};\\\", \\\"{x:1298,y:855,t:1528143742051};\\\", \\\"{x:1288,y:875,t:1528143742067};\\\", \\\"{x:1280,y:892,t:1528143742085};\\\", \\\"{x:1276,y:901,t:1528143742101};\\\", \\\"{x:1271,y:907,t:1528143742117};\\\", \\\"{x:1269,y:911,t:1528143742134};\\\", \\\"{x:1269,y:913,t:1528143742151};\\\", \\\"{x:1268,y:914,t:1528143742166};\\\", \\\"{x:1268,y:916,t:1528143742183};\\\", \\\"{x:1268,y:917,t:1528143742201};\\\", \\\"{x:1267,y:919,t:1528143742217};\\\", \\\"{x:1267,y:920,t:1528143742234};\\\", \\\"{x:1266,y:923,t:1528143742251};\\\", \\\"{x:1265,y:926,t:1528143742267};\\\", \\\"{x:1265,y:929,t:1528143742284};\\\", \\\"{x:1261,y:935,t:1528143742301};\\\", \\\"{x:1261,y:938,t:1528143742317};\\\", \\\"{x:1260,y:944,t:1528143742334};\\\", \\\"{x:1258,y:948,t:1528143742351};\\\", \\\"{x:1258,y:951,t:1528143742367};\\\", \\\"{x:1257,y:955,t:1528143742384};\\\", \\\"{x:1256,y:956,t:1528143742401};\\\", \\\"{x:1256,y:958,t:1528143742418};\\\", \\\"{x:1255,y:958,t:1528143742434};\\\", \\\"{x:1255,y:961,t:1528143742451};\\\", \\\"{x:1253,y:963,t:1528143742467};\\\", \\\"{x:1251,y:966,t:1528143742484};\\\", \\\"{x:1251,y:968,t:1528143742502};\\\", \\\"{x:1249,y:970,t:1528143742518};\\\", \\\"{x:1248,y:972,t:1528143742534};\\\", \\\"{x:1247,y:972,t:1528143742655};\\\", \\\"{x:1247,y:971,t:1528143742927};\\\", \\\"{x:1246,y:968,t:1528143742935};\\\", \\\"{x:1246,y:965,t:1528143742951};\\\", \\\"{x:1246,y:963,t:1528143742969};\\\", \\\"{x:1245,y:962,t:1528143742985};\\\", \\\"{x:1245,y:960,t:1528143743559};\\\", \\\"{x:1246,y:950,t:1528143743568};\\\", \\\"{x:1258,y:929,t:1528143743586};\\\", \\\"{x:1268,y:909,t:1528143743602};\\\", \\\"{x:1279,y:890,t:1528143743619};\\\", \\\"{x:1285,y:874,t:1528143743636};\\\", \\\"{x:1292,y:858,t:1528143743652};\\\", \\\"{x:1295,y:848,t:1528143743668};\\\", \\\"{x:1295,y:842,t:1528143743685};\\\", \\\"{x:1295,y:837,t:1528143743702};\\\", \\\"{x:1295,y:835,t:1528143743718};\\\", \\\"{x:1296,y:831,t:1528143743735};\\\", \\\"{x:1296,y:828,t:1528143743752};\\\", \\\"{x:1297,y:824,t:1528143743768};\\\", \\\"{x:1298,y:821,t:1528143743785};\\\", \\\"{x:1301,y:816,t:1528143743802};\\\", \\\"{x:1302,y:814,t:1528143743818};\\\", \\\"{x:1306,y:807,t:1528143743834};\\\", \\\"{x:1307,y:804,t:1528143743852};\\\", \\\"{x:1310,y:799,t:1528143743868};\\\", \\\"{x:1314,y:794,t:1528143743884};\\\", \\\"{x:1316,y:790,t:1528143743901};\\\", \\\"{x:1319,y:787,t:1528143743918};\\\", \\\"{x:1322,y:784,t:1528143743934};\\\", \\\"{x:1325,y:781,t:1528143743952};\\\", \\\"{x:1327,y:777,t:1528143743968};\\\", \\\"{x:1332,y:772,t:1528143743985};\\\", \\\"{x:1336,y:768,t:1528143744002};\\\", \\\"{x:1337,y:765,t:1528143744019};\\\", \\\"{x:1339,y:763,t:1528143744035};\\\", \\\"{x:1339,y:762,t:1528143744052};\\\", \\\"{x:1340,y:762,t:1528143744071};\\\", \\\"{x:1340,y:761,t:1528143744224};\\\", \\\"{x:1334,y:761,t:1528143744235};\\\", \\\"{x:1314,y:761,t:1528143744253};\\\", \\\"{x:1275,y:768,t:1528143744269};\\\", \\\"{x:1246,y:770,t:1528143744285};\\\", \\\"{x:1182,y:770,t:1528143744301};\\\", \\\"{x:1145,y:770,t:1528143744318};\\\", \\\"{x:1116,y:770,t:1528143744335};\\\", \\\"{x:1090,y:767,t:1528143744351};\\\", \\\"{x:1063,y:763,t:1528143744368};\\\", \\\"{x:1043,y:760,t:1528143744386};\\\", \\\"{x:1027,y:759,t:1528143744401};\\\", \\\"{x:1006,y:756,t:1528143744418};\\\", \\\"{x:979,y:751,t:1528143744435};\\\", \\\"{x:938,y:748,t:1528143744452};\\\", \\\"{x:867,y:734,t:1528143744469};\\\", \\\"{x:789,y:710,t:1528143744486};\\\", \\\"{x:703,y:687,t:1528143744502};\\\", \\\"{x:595,y:656,t:1528143744519};\\\", \\\"{x:532,y:632,t:1528143744536};\\\", \\\"{x:503,y:621,t:1528143744554};\\\", \\\"{x:485,y:613,t:1528143744569};\\\", \\\"{x:477,y:609,t:1528143744585};\\\", \\\"{x:474,y:608,t:1528143744604};\\\", \\\"{x:473,y:607,t:1528143744694};\\\", \\\"{x:478,y:602,t:1528143744704};\\\", \\\"{x:485,y:598,t:1528143744722};\\\", \\\"{x:492,y:595,t:1528143744738};\\\", \\\"{x:503,y:588,t:1528143744756};\\\", \\\"{x:514,y:582,t:1528143744772};\\\", \\\"{x:522,y:578,t:1528143744788};\\\", \\\"{x:523,y:577,t:1528143744814};\\\", \\\"{x:520,y:577,t:1528143744934};\\\", \\\"{x:511,y:577,t:1528143744943};\\\", \\\"{x:501,y:579,t:1528143744955};\\\", \\\"{x:481,y:580,t:1528143744973};\\\", \\\"{x:453,y:580,t:1528143744989};\\\", \\\"{x:425,y:580,t:1528143745005};\\\", \\\"{x:392,y:574,t:1528143745022};\\\", \\\"{x:372,y:569,t:1528143745038};\\\", \\\"{x:355,y:565,t:1528143745054};\\\", \\\"{x:345,y:561,t:1528143745072};\\\", \\\"{x:337,y:561,t:1528143745089};\\\", \\\"{x:332,y:558,t:1528143745104};\\\", \\\"{x:325,y:557,t:1528143745122};\\\", \\\"{x:313,y:554,t:1528143745140};\\\", \\\"{x:300,y:553,t:1528143745155};\\\", \\\"{x:283,y:551,t:1528143745171};\\\", \\\"{x:263,y:548,t:1528143745189};\\\", \\\"{x:245,y:547,t:1528143745204};\\\", \\\"{x:223,y:546,t:1528143745222};\\\", \\\"{x:213,y:544,t:1528143745238};\\\", \\\"{x:209,y:544,t:1528143745254};\\\", \\\"{x:206,y:544,t:1528143745272};\\\", \\\"{x:203,y:544,t:1528143745289};\\\", \\\"{x:202,y:544,t:1528143745343};\\\", \\\"{x:202,y:545,t:1528143745366};\\\", \\\"{x:203,y:545,t:1528143745375};\\\", \\\"{x:206,y:546,t:1528143745389};\\\", \\\"{x:213,y:546,t:1528143745405};\\\", \\\"{x:231,y:546,t:1528143745422};\\\", \\\"{x:248,y:540,t:1528143745438};\\\", \\\"{x:258,y:535,t:1528143745455};\\\", \\\"{x:268,y:530,t:1528143745472};\\\", \\\"{x:283,y:521,t:1528143745489};\\\", \\\"{x:294,y:514,t:1528143745507};\\\", \\\"{x:299,y:511,t:1528143745522};\\\", \\\"{x:300,y:510,t:1528143745539};\\\", \\\"{x:298,y:510,t:1528143745606};\\\", \\\"{x:288,y:510,t:1528143745622};\\\", \\\"{x:249,y:510,t:1528143745640};\\\", \\\"{x:221,y:510,t:1528143745656};\\\", \\\"{x:194,y:510,t:1528143745672};\\\", \\\"{x:173,y:510,t:1528143745689};\\\", \\\"{x:165,y:510,t:1528143745706};\\\", \\\"{x:160,y:509,t:1528143745722};\\\", \\\"{x:160,y:508,t:1528143745862};\\\", \\\"{x:163,y:507,t:1528143745872};\\\", \\\"{x:164,y:507,t:1528143745889};\\\", \\\"{x:167,y:507,t:1528143745926};\\\", \\\"{x:168,y:507,t:1528143745974};\\\", \\\"{x:168,y:507,t:1528143746021};\\\", \\\"{x:172,y:511,t:1528143746102};\\\", \\\"{x:178,y:515,t:1528143746111};\\\", \\\"{x:185,y:520,t:1528143746124};\\\", \\\"{x:202,y:530,t:1528143746139};\\\", \\\"{x:218,y:540,t:1528143746155};\\\", \\\"{x:240,y:555,t:1528143746173};\\\", \\\"{x:259,y:564,t:1528143746189};\\\", \\\"{x:287,y:578,t:1528143746207};\\\", \\\"{x:304,y:589,t:1528143746223};\\\", \\\"{x:320,y:598,t:1528143746239};\\\", \\\"{x:338,y:610,t:1528143746256};\\\", \\\"{x:345,y:615,t:1528143746273};\\\", \\\"{x:351,y:620,t:1528143746290};\\\", \\\"{x:362,y:628,t:1528143746306};\\\", \\\"{x:373,y:636,t:1528143746323};\\\", \\\"{x:385,y:645,t:1528143746340};\\\", \\\"{x:396,y:657,t:1528143746356};\\\", \\\"{x:406,y:666,t:1528143746373};\\\", \\\"{x:417,y:674,t:1528143746391};\\\", \\\"{x:422,y:678,t:1528143746406};\\\", \\\"{x:426,y:681,t:1528143746422};\\\", \\\"{x:428,y:682,t:1528143746439};\\\", \\\"{x:431,y:685,t:1528143746456};\\\", \\\"{x:433,y:686,t:1528143746473};\\\", \\\"{x:438,y:689,t:1528143746490};\\\", \\\"{x:442,y:690,t:1528143746506};\\\", \\\"{x:446,y:693,t:1528143746523};\\\", \\\"{x:451,y:697,t:1528143746540};\\\", \\\"{x:455,y:699,t:1528143746556};\\\", \\\"{x:457,y:701,t:1528143746573};\\\", \\\"{x:460,y:705,t:1528143746590};\\\", \\\"{x:461,y:706,t:1528143746606};\\\", \\\"{x:465,y:711,t:1528143746623};\\\", \\\"{x:467,y:715,t:1528143746640};\\\", \\\"{x:468,y:718,t:1528143746656};\\\", \\\"{x:470,y:719,t:1528143746673};\\\", \\\"{x:470,y:721,t:1528143746696};\\\", \\\"{x:471,y:723,t:1528143746739};\\\", \\\"{x:472,y:725,t:1528143746756};\\\", \\\"{x:473,y:726,t:1528143746783};\\\", \\\"{x:469,y:726,t:1528143747295};\\\", \\\"{x:462,y:726,t:1528143747307};\\\", \\\"{x:438,y:715,t:1528143747324};\\\", \\\"{x:432,y:710,t:1528143747340};\\\", \\\"{x:432,y:709,t:1528143747798};\\\", \\\"{x:433,y:708,t:1528143747806};\\\", \\\"{x:438,y:707,t:1528143747824};\\\", \\\"{x:451,y:703,t:1528143747841};\\\", \\\"{x:483,y:697,t:1528143747857};\\\", \\\"{x:540,y:692,t:1528143747874};\\\", \\\"{x:629,y:692,t:1528143747891};\\\", \\\"{x:775,y:703,t:1528143747914};\\\", \\\"{x:834,y:721,t:1528143747924};\\\", \\\"{x:977,y:760,t:1528143747941};\\\", \\\"{x:1172,y:822,t:1528143747958};\\\", \\\"{x:1292,y:867,t:1528143747974};\\\", \\\"{x:1395,y:914,t:1528143747991};\\\" ] }, { \\\"rt\\\": 10163, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 599206, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1072,y:1148,t:1528143748141};\\\", \\\"{x:932,y:1137,t:1528143748158};\\\", \\\"{x:801,y:1115,t:1528143748173};\\\", \\\"{x:681,y:1086,t:1528143748191};\\\", \\\"{x:565,y:1038,t:1528143748208};\\\", \\\"{x:478,y:967,t:1528143748231};\\\", \\\"{x:472,y:951,t:1528143748241};\\\", \\\"{x:472,y:918,t:1528143748258};\\\", \\\"{x:500,y:864,t:1528143748273};\\\", \\\"{x:545,y:814,t:1528143748290};\\\", \\\"{x:609,y:768,t:1528143748308};\\\", \\\"{x:688,y:728,t:1528143748324};\\\", \\\"{x:751,y:700,t:1528143748341};\\\", \\\"{x:798,y:677,t:1528143748358};\\\", \\\"{x:808,y:672,t:1528143748373};\\\", \\\"{x:810,y:670,t:1528143748391};\\\", \\\"{x:811,y:669,t:1528143748750};\\\", \\\"{x:820,y:664,t:1528143748758};\\\", \\\"{x:863,y:653,t:1528143748774};\\\", \\\"{x:937,y:646,t:1528143748791};\\\", \\\"{x:1026,y:644,t:1528143748808};\\\", \\\"{x:1110,y:645,t:1528143748825};\\\", \\\"{x:1213,y:675,t:1528143748841};\\\", \\\"{x:1321,y:705,t:1528143748858};\\\", \\\"{x:1401,y:742,t:1528143748875};\\\", \\\"{x:1463,y:776,t:1528143748891};\\\", \\\"{x:1492,y:807,t:1528143748908};\\\", \\\"{x:1503,y:843,t:1528143748925};\\\", \\\"{x:1501,y:887,t:1528143748942};\\\", \\\"{x:1442,y:963,t:1528143748958};\\\", \\\"{x:1359,y:1016,t:1528143748975};\\\", \\\"{x:1240,y:1064,t:1528143748991};\\\", \\\"{x:1083,y:1086,t:1528143749008};\\\", \\\"{x:906,y:1088,t:1528143749025};\\\", \\\"{x:706,y:1080,t:1528143749041};\\\", \\\"{x:474,y:1047,t:1528143749058};\\\", \\\"{x:254,y:996,t:1528143749075};\\\", \\\"{x:84,y:928,t:1528143749091};\\\", \\\"{x:0,y:859,t:1528143749108};\\\", \\\"{x:0,y:802,t:1528143749125};\\\", \\\"{x:6,y:742,t:1528143749141};\\\", \\\"{x:81,y:646,t:1528143749159};\\\", \\\"{x:167,y:584,t:1528143749175};\\\", \\\"{x:273,y:530,t:1528143749193};\\\", \\\"{x:371,y:498,t:1528143749209};\\\", \\\"{x:446,y:476,t:1528143749226};\\\", \\\"{x:517,y:458,t:1528143749242};\\\", \\\"{x:564,y:447,t:1528143749258};\\\", \\\"{x:587,y:441,t:1528143749275};\\\", \\\"{x:598,y:438,t:1528143749292};\\\", \\\"{x:599,y:438,t:1528143749308};\\\", \\\"{x:600,y:437,t:1528143749391};\\\", \\\"{x:601,y:437,t:1528143749414};\\\", \\\"{x:602,y:437,t:1528143749425};\\\", \\\"{x:602,y:436,t:1528143749903};\\\", \\\"{x:602,y:434,t:1528143750239};\\\", \\\"{x:602,y:433,t:1528143750247};\\\", \\\"{x:602,y:432,t:1528143750260};\\\", \\\"{x:602,y:431,t:1528143750276};\\\", \\\"{x:602,y:430,t:1528143750293};\\\", \\\"{x:602,y:429,t:1528143750318};\\\", \\\"{x:602,y:428,t:1528143750342};\\\", \\\"{x:602,y:426,t:1528143750359};\\\", \\\"{x:602,y:425,t:1528143750390};\\\", \\\"{x:602,y:424,t:1528143750511};\\\", \\\"{x:603,y:423,t:1528143750535};\\\", \\\"{x:604,y:422,t:1528143750607};\\\", \\\"{x:604,y:421,t:1528143750614};\\\", \\\"{x:605,y:420,t:1528143750627};\\\", \\\"{x:605,y:419,t:1528143750644};\\\", \\\"{x:606,y:416,t:1528143750660};\\\", \\\"{x:607,y:415,t:1528143750676};\\\", \\\"{x:607,y:414,t:1528143750693};\\\", \\\"{x:607,y:413,t:1528143750710};\\\", \\\"{x:607,y:411,t:1528143750726};\\\", \\\"{x:609,y:409,t:1528143750743};\\\", \\\"{x:610,y:408,t:1528143750782};\\\", \\\"{x:610,y:407,t:1528143750794};\\\", \\\"{x:610,y:406,t:1528143750811};\\\", \\\"{x:611,y:406,t:1528143750826};\\\", \\\"{x:612,y:404,t:1528143750844};\\\", \\\"{x:613,y:404,t:1528143750861};\\\", \\\"{x:614,y:403,t:1528143750876};\\\", \\\"{x:616,y:402,t:1528143750893};\\\", \\\"{x:618,y:401,t:1528143750911};\\\", \\\"{x:619,y:399,t:1528143750927};\\\", \\\"{x:622,y:397,t:1528143750943};\\\", \\\"{x:625,y:396,t:1528143750960};\\\", \\\"{x:627,y:393,t:1528143750976};\\\", \\\"{x:631,y:390,t:1528143750994};\\\", \\\"{x:632,y:389,t:1528143751010};\\\", \\\"{x:636,y:387,t:1528143751027};\\\", \\\"{x:641,y:384,t:1528143751044};\\\", \\\"{x:642,y:383,t:1528143751061};\\\", \\\"{x:644,y:382,t:1528143751077};\\\", \\\"{x:647,y:380,t:1528143751093};\\\", \\\"{x:652,y:379,t:1528143751111};\\\", \\\"{x:654,y:377,t:1528143751127};\\\", \\\"{x:660,y:376,t:1528143751143};\\\", \\\"{x:661,y:375,t:1528143751160};\\\", \\\"{x:669,y:372,t:1528143751177};\\\", \\\"{x:676,y:369,t:1528143751194};\\\", \\\"{x:685,y:367,t:1528143751210};\\\", \\\"{x:691,y:363,t:1528143751227};\\\", \\\"{x:698,y:360,t:1528143751244};\\\", \\\"{x:704,y:358,t:1528143751261};\\\", \\\"{x:707,y:356,t:1528143751277};\\\", \\\"{x:713,y:354,t:1528143751294};\\\", \\\"{x:719,y:351,t:1528143751311};\\\", \\\"{x:722,y:349,t:1528143751327};\\\", \\\"{x:725,y:348,t:1528143751343};\\\", \\\"{x:729,y:346,t:1528143751360};\\\", \\\"{x:732,y:345,t:1528143751377};\\\", \\\"{x:738,y:342,t:1528143751394};\\\", \\\"{x:746,y:339,t:1528143751410};\\\", \\\"{x:759,y:336,t:1528143751427};\\\", \\\"{x:775,y:333,t:1528143751444};\\\", \\\"{x:793,y:328,t:1528143751461};\\\", \\\"{x:810,y:325,t:1528143751477};\\\", \\\"{x:823,y:321,t:1528143751493};\\\", \\\"{x:839,y:318,t:1528143751511};\\\", \\\"{x:846,y:316,t:1528143751527};\\\", \\\"{x:853,y:315,t:1528143751544};\\\", \\\"{x:859,y:314,t:1528143751560};\\\", \\\"{x:867,y:314,t:1528143751578};\\\", \\\"{x:874,y:314,t:1528143751595};\\\", \\\"{x:880,y:314,t:1528143751611};\\\", \\\"{x:887,y:314,t:1528143751627};\\\", \\\"{x:894,y:314,t:1528143751645};\\\", \\\"{x:902,y:314,t:1528143751660};\\\", \\\"{x:915,y:314,t:1528143751678};\\\", \\\"{x:935,y:314,t:1528143751694};\\\", \\\"{x:952,y:314,t:1528143751711};\\\", \\\"{x:967,y:314,t:1528143751728};\\\", \\\"{x:979,y:314,t:1528143751745};\\\", \\\"{x:992,y:314,t:1528143751761};\\\", \\\"{x:1006,y:314,t:1528143751778};\\\", \\\"{x:1020,y:317,t:1528143751795};\\\", \\\"{x:1030,y:318,t:1528143751811};\\\", \\\"{x:1037,y:319,t:1528143751826};\\\", \\\"{x:1043,y:319,t:1528143751844};\\\", \\\"{x:1049,y:320,t:1528143751861};\\\", \\\"{x:1053,y:321,t:1528143751877};\\\", \\\"{x:1060,y:322,t:1528143751893};\\\", \\\"{x:1062,y:322,t:1528143751911};\\\", \\\"{x:1065,y:324,t:1528143751927};\\\", \\\"{x:1071,y:325,t:1528143751944};\\\", \\\"{x:1080,y:328,t:1528143751961};\\\", \\\"{x:1088,y:329,t:1528143751977};\\\", \\\"{x:1097,y:330,t:1528143751994};\\\", \\\"{x:1105,y:331,t:1528143752012};\\\", \\\"{x:1111,y:332,t:1528143752027};\\\", \\\"{x:1118,y:333,t:1528143752044};\\\", \\\"{x:1124,y:334,t:1528143752062};\\\", \\\"{x:1128,y:334,t:1528143752078};\\\", \\\"{x:1131,y:336,t:1528143752095};\\\", \\\"{x:1132,y:336,t:1528143752119};\\\", \\\"{x:1133,y:336,t:1528143752743};\\\", \\\"{x:1137,y:336,t:1528143752759};\\\", \\\"{x:1139,y:334,t:1528143752767};\\\", \\\"{x:1143,y:332,t:1528143752778};\\\", \\\"{x:1154,y:323,t:1528143752795};\\\", \\\"{x:1164,y:316,t:1528143752812};\\\", \\\"{x:1176,y:308,t:1528143752829};\\\", \\\"{x:1186,y:302,t:1528143752846};\\\", \\\"{x:1198,y:296,t:1528143752862};\\\", \\\"{x:1215,y:287,t:1528143752879};\\\", \\\"{x:1224,y:283,t:1528143752895};\\\", \\\"{x:1237,y:281,t:1528143752912};\\\", \\\"{x:1247,y:278,t:1528143752928};\\\", \\\"{x:1257,y:276,t:1528143752945};\\\", \\\"{x:1267,y:276,t:1528143752961};\\\", \\\"{x:1275,y:276,t:1528143752978};\\\", \\\"{x:1281,y:276,t:1528143752995};\\\", \\\"{x:1285,y:276,t:1528143753012};\\\", \\\"{x:1287,y:277,t:1528143753028};\\\", \\\"{x:1293,y:281,t:1528143753045};\\\", \\\"{x:1302,y:287,t:1528143753062};\\\", \\\"{x:1309,y:293,t:1528143753078};\\\", \\\"{x:1316,y:299,t:1528143753095};\\\", \\\"{x:1321,y:307,t:1528143753112};\\\", \\\"{x:1329,y:325,t:1528143753129};\\\", \\\"{x:1335,y:343,t:1528143753146};\\\", \\\"{x:1343,y:364,t:1528143753163};\\\", \\\"{x:1353,y:387,t:1528143753179};\\\", \\\"{x:1364,y:412,t:1528143753196};\\\", \\\"{x:1371,y:437,t:1528143753213};\\\", \\\"{x:1378,y:464,t:1528143753229};\\\", \\\"{x:1385,y:484,t:1528143753246};\\\", \\\"{x:1391,y:514,t:1528143753263};\\\", \\\"{x:1399,y:536,t:1528143753278};\\\", \\\"{x:1404,y:555,t:1528143753296};\\\", \\\"{x:1410,y:575,t:1528143753312};\\\", \\\"{x:1410,y:589,t:1528143753329};\\\", \\\"{x:1410,y:600,t:1528143753346};\\\", \\\"{x:1410,y:610,t:1528143753363};\\\", \\\"{x:1408,y:625,t:1528143753378};\\\", \\\"{x:1402,y:641,t:1528143753396};\\\", \\\"{x:1397,y:654,t:1528143753413};\\\", \\\"{x:1396,y:660,t:1528143753430};\\\", \\\"{x:1395,y:665,t:1528143753447};\\\", \\\"{x:1393,y:667,t:1528143753463};\\\", \\\"{x:1391,y:669,t:1528143753487};\\\", \\\"{x:1390,y:669,t:1528143753496};\\\", \\\"{x:1388,y:670,t:1528143753513};\\\", \\\"{x:1385,y:671,t:1528143753530};\\\", \\\"{x:1380,y:673,t:1528143753546};\\\", \\\"{x:1370,y:679,t:1528143753563};\\\", \\\"{x:1358,y:686,t:1528143753580};\\\", \\\"{x:1345,y:696,t:1528143753598};\\\", \\\"{x:1339,y:702,t:1528143753613};\\\", \\\"{x:1337,y:704,t:1528143753629};\\\", \\\"{x:1337,y:705,t:1528143753645};\\\", \\\"{x:1339,y:705,t:1528143753815};\\\", \\\"{x:1340,y:705,t:1528143753830};\\\", \\\"{x:1341,y:705,t:1528143753846};\\\", \\\"{x:1343,y:705,t:1528143753863};\\\", \\\"{x:1344,y:704,t:1528143753894};\\\", \\\"{x:1346,y:703,t:1528143753911};\\\", \\\"{x:1345,y:703,t:1528143754455};\\\", \\\"{x:1338,y:703,t:1528143754463};\\\", \\\"{x:1321,y:702,t:1528143754480};\\\", \\\"{x:1305,y:702,t:1528143754496};\\\", \\\"{x:1291,y:701,t:1528143754513};\\\", \\\"{x:1272,y:701,t:1528143754530};\\\", \\\"{x:1248,y:701,t:1528143754546};\\\", \\\"{x:1224,y:701,t:1528143754563};\\\", \\\"{x:1196,y:701,t:1528143754579};\\\", \\\"{x:1167,y:697,t:1528143754596};\\\", \\\"{x:1145,y:695,t:1528143754614};\\\", \\\"{x:1118,y:690,t:1528143754629};\\\", \\\"{x:1079,y:683,t:1528143754646};\\\", \\\"{x:1053,y:680,t:1528143754665};\\\", \\\"{x:1026,y:677,t:1528143754680};\\\", \\\"{x:991,y:673,t:1528143754697};\\\", \\\"{x:954,y:668,t:1528143754714};\\\", \\\"{x:923,y:664,t:1528143754731};\\\", \\\"{x:892,y:660,t:1528143754747};\\\", \\\"{x:864,y:655,t:1528143754763};\\\", \\\"{x:840,y:652,t:1528143754780};\\\", \\\"{x:826,y:648,t:1528143754796};\\\", \\\"{x:819,y:645,t:1528143754814};\\\", \\\"{x:810,y:641,t:1528143754831};\\\", \\\"{x:802,y:639,t:1528143754847};\\\", \\\"{x:787,y:632,t:1528143754863};\\\", \\\"{x:771,y:625,t:1528143754882};\\\", \\\"{x:756,y:620,t:1528143754896};\\\", \\\"{x:745,y:614,t:1528143754913};\\\", \\\"{x:731,y:608,t:1528143754929};\\\", \\\"{x:719,y:601,t:1528143754947};\\\", \\\"{x:704,y:590,t:1528143754963};\\\", \\\"{x:695,y:585,t:1528143754980};\\\", \\\"{x:685,y:579,t:1528143754996};\\\", \\\"{x:677,y:575,t:1528143755013};\\\", \\\"{x:664,y:564,t:1528143755029};\\\", \\\"{x:655,y:556,t:1528143755047};\\\", \\\"{x:650,y:550,t:1528143755064};\\\", \\\"{x:645,y:545,t:1528143755080};\\\", \\\"{x:640,y:537,t:1528143755097};\\\", \\\"{x:637,y:533,t:1528143755113};\\\", \\\"{x:634,y:529,t:1528143755130};\\\", \\\"{x:632,y:526,t:1528143755147};\\\", \\\"{x:630,y:524,t:1528143755164};\\\", \\\"{x:628,y:523,t:1528143755180};\\\", \\\"{x:626,y:522,t:1528143755196};\\\", \\\"{x:623,y:520,t:1528143755214};\\\", \\\"{x:618,y:516,t:1528143755231};\\\", \\\"{x:616,y:513,t:1528143755246};\\\", \\\"{x:613,y:508,t:1528143755263};\\\", \\\"{x:610,y:505,t:1528143755280};\\\", \\\"{x:606,y:502,t:1528143755297};\\\", \\\"{x:603,y:500,t:1528143755313};\\\", \\\"{x:599,y:498,t:1528143755330};\\\", \\\"{x:597,y:496,t:1528143755347};\\\", \\\"{x:596,y:492,t:1528143755363};\\\", \\\"{x:596,y:490,t:1528143755380};\\\", \\\"{x:596,y:489,t:1528143755397};\\\", \\\"{x:596,y:491,t:1528143755703};\\\", \\\"{x:596,y:494,t:1528143755713};\\\", \\\"{x:598,y:506,t:1528143755731};\\\", \\\"{x:598,y:520,t:1528143755748};\\\", \\\"{x:598,y:535,t:1528143755765};\\\", \\\"{x:599,y:553,t:1528143755780};\\\", \\\"{x:601,y:572,t:1528143755798};\\\", \\\"{x:601,y:590,t:1528143755813};\\\", \\\"{x:601,y:616,t:1528143755831};\\\", \\\"{x:601,y:628,t:1528143755847};\\\", \\\"{x:601,y:635,t:1528143755864};\\\", \\\"{x:598,y:639,t:1528143755880};\\\", \\\"{x:598,y:642,t:1528143755897};\\\", \\\"{x:597,y:647,t:1528143755913};\\\", \\\"{x:595,y:651,t:1528143755930};\\\", \\\"{x:592,y:660,t:1528143755947};\\\", \\\"{x:589,y:668,t:1528143755963};\\\", \\\"{x:585,y:674,t:1528143755980};\\\", \\\"{x:583,y:678,t:1528143755997};\\\", \\\"{x:579,y:681,t:1528143756014};\\\", \\\"{x:574,y:686,t:1528143756030};\\\", \\\"{x:572,y:688,t:1528143756120};\\\", \\\"{x:570,y:689,t:1528143756130};\\\", \\\"{x:562,y:694,t:1528143756148};\\\", \\\"{x:554,y:697,t:1528143756164};\\\", \\\"{x:547,y:700,t:1528143756181};\\\", \\\"{x:543,y:701,t:1528143756198};\\\", \\\"{x:542,y:701,t:1528143756214};\\\", \\\"{x:541,y:701,t:1528143756230};\\\", \\\"{x:539,y:701,t:1528143756302};\\\", \\\"{x:538,y:702,t:1528143756319};\\\", \\\"{x:534,y:706,t:1528143756331};\\\", \\\"{x:527,y:713,t:1528143756347};\\\", \\\"{x:521,y:717,t:1528143756364};\\\", \\\"{x:520,y:718,t:1528143756381};\\\", \\\"{x:526,y:712,t:1528143756406};\\\", \\\"{x:534,y:703,t:1528143756415};\\\", \\\"{x:543,y:687,t:1528143756430};\\\", \\\"{x:555,y:670,t:1528143756447};\\\", \\\"{x:570,y:650,t:1528143756463};\\\", \\\"{x:588,y:625,t:1528143756481};\\\", \\\"{x:596,y:603,t:1528143756496};\\\", \\\"{x:605,y:587,t:1528143756515};\\\", \\\"{x:607,y:578,t:1528143756531};\\\", \\\"{x:607,y:574,t:1528143756547};\\\", \\\"{x:607,y:573,t:1528143756564};\\\", \\\"{x:607,y:571,t:1528143756581};\\\", \\\"{x:606,y:571,t:1528143756597};\\\", \\\"{x:605,y:570,t:1528143756622};\\\", \\\"{x:605,y:566,t:1528143756655};\\\", \\\"{x:608,y:552,t:1528143756670};\\\", \\\"{x:623,y:518,t:1528143756713};\\\", \\\"{x:626,y:511,t:1528143756731};\\\", \\\"{x:626,y:509,t:1528143756748};\\\", \\\"{x:626,y:508,t:1528143756764};\\\", \\\"{x:626,y:507,t:1528143756781};\\\", \\\"{x:626,y:506,t:1528143756854};\\\", \\\"{x:626,y:505,t:1528143756902};\\\", \\\"{x:625,y:504,t:1528143756915};\\\", \\\"{x:624,y:504,t:1528143756931};\\\", \\\"{x:621,y:504,t:1528143756948};\\\", \\\"{x:620,y:504,t:1528143756965};\\\", \\\"{x:613,y:526,t:1528143757353};\\\", \\\"{x:603,y:545,t:1528143757365};\\\", \\\"{x:594,y:571,t:1528143757382};\\\", \\\"{x:584,y:604,t:1528143757398};\\\", \\\"{x:579,y:622,t:1528143757415};\\\", \\\"{x:575,y:637,t:1528143757431};\\\", \\\"{x:573,y:652,t:1528143757448};\\\", \\\"{x:572,y:663,t:1528143757465};\\\", \\\"{x:570,y:672,t:1528143757481};\\\", \\\"{x:570,y:679,t:1528143757498};\\\", \\\"{x:569,y:683,t:1528143757516};\\\", \\\"{x:568,y:688,t:1528143757532};\\\", \\\"{x:568,y:691,t:1528143757548};\\\", \\\"{x:567,y:694,t:1528143757565};\\\", \\\"{x:564,y:697,t:1528143757582};\\\", \\\"{x:561,y:700,t:1528143757599};\\\", \\\"{x:560,y:702,t:1528143757615};\\\", \\\"{x:559,y:702,t:1528143757631};\\\", \\\"{x:555,y:704,t:1528143757648};\\\", \\\"{x:553,y:705,t:1528143757665};\\\", \\\"{x:551,y:706,t:1528143757683};\\\", \\\"{x:546,y:711,t:1528143757698};\\\", \\\"{x:539,y:719,t:1528143757715};\\\", \\\"{x:533,y:728,t:1528143757733};\\\", \\\"{x:528,y:735,t:1528143757748};\\\", \\\"{x:526,y:737,t:1528143757765};\\\", \\\"{x:525,y:738,t:1528143757854};\\\", \\\"{x:525,y:739,t:1528143757894};\\\", \\\"{x:524,y:739,t:1528143757902};\\\", \\\"{x:523,y:740,t:1528143757916};\\\" ] }, { \\\"rt\\\": 16275, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 616750, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -M -12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:532,y:737,t:1528143761306};\\\", \\\"{x:554,y:730,t:1528143761325};\\\", \\\"{x:578,y:726,t:1528143761343};\\\", \\\"{x:605,y:721,t:1528143761357};\\\", \\\"{x:630,y:721,t:1528143761374};\\\", \\\"{x:659,y:721,t:1528143761388};\\\", \\\"{x:680,y:720,t:1528143761406};\\\", \\\"{x:697,y:718,t:1528143761421};\\\", \\\"{x:711,y:714,t:1528143761439};\\\", \\\"{x:727,y:708,t:1528143761455};\\\", \\\"{x:739,y:704,t:1528143761471};\\\", \\\"{x:754,y:697,t:1528143761489};\\\", \\\"{x:771,y:693,t:1528143761505};\\\", \\\"{x:785,y:689,t:1528143761522};\\\", \\\"{x:800,y:684,t:1528143761539};\\\", \\\"{x:810,y:683,t:1528143761556};\\\", \\\"{x:824,y:680,t:1528143761572};\\\", \\\"{x:843,y:677,t:1528143761589};\\\", \\\"{x:868,y:668,t:1528143761605};\\\", \\\"{x:906,y:652,t:1528143761623};\\\", \\\"{x:932,y:642,t:1528143761639};\\\", \\\"{x:957,y:631,t:1528143761655};\\\", \\\"{x:987,y:619,t:1528143761672};\\\", \\\"{x:1011,y:608,t:1528143761688};\\\", \\\"{x:1029,y:600,t:1528143761706};\\\", \\\"{x:1062,y:588,t:1528143761722};\\\", \\\"{x:1078,y:582,t:1528143761738};\\\", \\\"{x:1095,y:577,t:1528143761756};\\\", \\\"{x:1107,y:571,t:1528143761773};\\\", \\\"{x:1117,y:564,t:1528143761789};\\\", \\\"{x:1125,y:560,t:1528143761806};\\\", \\\"{x:1136,y:552,t:1528143761822};\\\", \\\"{x:1148,y:542,t:1528143761839};\\\", \\\"{x:1165,y:528,t:1528143761856};\\\", \\\"{x:1182,y:511,t:1528143761872};\\\", \\\"{x:1201,y:495,t:1528143761889};\\\", \\\"{x:1225,y:475,t:1528143761906};\\\", \\\"{x:1267,y:442,t:1528143761921};\\\", \\\"{x:1294,y:420,t:1528143761939};\\\", \\\"{x:1314,y:406,t:1528143761956};\\\", \\\"{x:1332,y:390,t:1528143761973};\\\", \\\"{x:1343,y:380,t:1528143761989};\\\", \\\"{x:1351,y:372,t:1528143762006};\\\", \\\"{x:1355,y:363,t:1528143762023};\\\", \\\"{x:1358,y:356,t:1528143762038};\\\", \\\"{x:1359,y:353,t:1528143762056};\\\", \\\"{x:1360,y:352,t:1528143762073};\\\", \\\"{x:1361,y:351,t:1528143762089};\\\", \\\"{x:1361,y:350,t:1528143762106};\\\", \\\"{x:1363,y:346,t:1528143762123};\\\", \\\"{x:1364,y:342,t:1528143762139};\\\", \\\"{x:1369,y:333,t:1528143762156};\\\", \\\"{x:1370,y:327,t:1528143762173};\\\", \\\"{x:1376,y:317,t:1528143762188};\\\", \\\"{x:1383,y:306,t:1528143762206};\\\", \\\"{x:1389,y:296,t:1528143762223};\\\", \\\"{x:1396,y:287,t:1528143762240};\\\", \\\"{x:1402,y:279,t:1528143762256};\\\", \\\"{x:1410,y:271,t:1528143762273};\\\", \\\"{x:1413,y:266,t:1528143762290};\\\", \\\"{x:1419,y:259,t:1528143762306};\\\", \\\"{x:1422,y:255,t:1528143762323};\\\", \\\"{x:1425,y:252,t:1528143762340};\\\", \\\"{x:1427,y:248,t:1528143762356};\\\", \\\"{x:1430,y:245,t:1528143762373};\\\", \\\"{x:1434,y:238,t:1528143762390};\\\", \\\"{x:1439,y:232,t:1528143762406};\\\", \\\"{x:1444,y:225,t:1528143762423};\\\", \\\"{x:1447,y:219,t:1528143762440};\\\", \\\"{x:1449,y:217,t:1528143762456};\\\", \\\"{x:1452,y:212,t:1528143762473};\\\", \\\"{x:1454,y:209,t:1528143762490};\\\", \\\"{x:1457,y:205,t:1528143762506};\\\", \\\"{x:1460,y:202,t:1528143762523};\\\", \\\"{x:1460,y:201,t:1528143762539};\\\", \\\"{x:1461,y:201,t:1528143762556};\\\", \\\"{x:1462,y:199,t:1528143762573};\\\", \\\"{x:1463,y:198,t:1528143762590};\\\", \\\"{x:1463,y:196,t:1528143762606};\\\", \\\"{x:1465,y:195,t:1528143762623};\\\", \\\"{x:1466,y:192,t:1528143762640};\\\", \\\"{x:1468,y:191,t:1528143762656};\\\", \\\"{x:1470,y:188,t:1528143762673};\\\", \\\"{x:1470,y:186,t:1528143762690};\\\", \\\"{x:1472,y:185,t:1528143762706};\\\", \\\"{x:1472,y:184,t:1528143762723};\\\", \\\"{x:1474,y:182,t:1528143762740};\\\", \\\"{x:1474,y:181,t:1528143762756};\\\", \\\"{x:1475,y:180,t:1528143762773};\\\", \\\"{x:1476,y:179,t:1528143762789};\\\", \\\"{x:1476,y:177,t:1528143762819};\\\", \\\"{x:1478,y:176,t:1528143762864};\\\", \\\"{x:1478,y:175,t:1528143762890};\\\", \\\"{x:1478,y:174,t:1528143762986};\\\", \\\"{x:1478,y:173,t:1528143763034};\\\", \\\"{x:1479,y:173,t:1528143763050};\\\", \\\"{x:1479,y:172,t:1528143763066};\\\", \\\"{x:1479,y:171,t:1528143763074};\\\", \\\"{x:1480,y:170,t:1528143763090};\\\", \\\"{x:1481,y:168,t:1528143763107};\\\", \\\"{x:1481,y:167,t:1528143763123};\\\", \\\"{x:1481,y:166,t:1528143763140};\\\", \\\"{x:1481,y:165,t:1528143763186};\\\", \\\"{x:1481,y:171,t:1528143764467};\\\", \\\"{x:1481,y:181,t:1528143764474};\\\", \\\"{x:1475,y:206,t:1528143764490};\\\", \\\"{x:1469,y:237,t:1528143764506};\\\", \\\"{x:1461,y:293,t:1528143764524};\\\", \\\"{x:1451,y:363,t:1528143764541};\\\", \\\"{x:1440,y:444,t:1528143764557};\\\", \\\"{x:1431,y:521,t:1528143764574};\\\", \\\"{x:1426,y:584,t:1528143764591};\\\", \\\"{x:1424,y:643,t:1528143764607};\\\", \\\"{x:1424,y:688,t:1528143764624};\\\", \\\"{x:1424,y:718,t:1528143764641};\\\", \\\"{x:1424,y:740,t:1528143764657};\\\", \\\"{x:1424,y:777,t:1528143764675};\\\", \\\"{x:1423,y:795,t:1528143764690};\\\", \\\"{x:1423,y:802,t:1528143764707};\\\", \\\"{x:1423,y:807,t:1528143764724};\\\", \\\"{x:1422,y:822,t:1528143764741};\\\", \\\"{x:1419,y:837,t:1528143764757};\\\", \\\"{x:1417,y:857,t:1528143764774};\\\", \\\"{x:1413,y:879,t:1528143764791};\\\", \\\"{x:1408,y:900,t:1528143764807};\\\", \\\"{x:1404,y:917,t:1528143764824};\\\", \\\"{x:1402,y:920,t:1528143764841};\\\", \\\"{x:1402,y:921,t:1528143764857};\\\", \\\"{x:1402,y:922,t:1528143764915};\\\", \\\"{x:1400,y:922,t:1528143764924};\\\", \\\"{x:1395,y:922,t:1528143764941};\\\", \\\"{x:1391,y:921,t:1528143764958};\\\", \\\"{x:1384,y:918,t:1528143764974};\\\", \\\"{x:1382,y:916,t:1528143764991};\\\", \\\"{x:1375,y:913,t:1528143765008};\\\", \\\"{x:1370,y:909,t:1528143765024};\\\", \\\"{x:1368,y:907,t:1528143765041};\\\", \\\"{x:1366,y:905,t:1528143765059};\\\", \\\"{x:1366,y:904,t:1528143765283};\\\", \\\"{x:1366,y:903,t:1528143765419};\\\", \\\"{x:1368,y:902,t:1528143765426};\\\", \\\"{x:1369,y:902,t:1528143765441};\\\", \\\"{x:1371,y:900,t:1528143765458};\\\", \\\"{x:1372,y:899,t:1528143765474};\\\", \\\"{x:1375,y:895,t:1528143766931};\\\", \\\"{x:1379,y:885,t:1528143766942};\\\", \\\"{x:1386,y:865,t:1528143766960};\\\", \\\"{x:1393,y:846,t:1528143766976};\\\", \\\"{x:1401,y:820,t:1528143766992};\\\", \\\"{x:1415,y:780,t:1528143767009};\\\", \\\"{x:1422,y:759,t:1528143767026};\\\", \\\"{x:1434,y:718,t:1528143767043};\\\", \\\"{x:1442,y:694,t:1528143767059};\\\", \\\"{x:1448,y:672,t:1528143767075};\\\", \\\"{x:1455,y:650,t:1528143767093};\\\", \\\"{x:1463,y:631,t:1528143767109};\\\", \\\"{x:1469,y:615,t:1528143767125};\\\", \\\"{x:1475,y:600,t:1528143767142};\\\", \\\"{x:1480,y:590,t:1528143767159};\\\", \\\"{x:1483,y:584,t:1528143767175};\\\", \\\"{x:1484,y:580,t:1528143767193};\\\", \\\"{x:1486,y:577,t:1528143767209};\\\", \\\"{x:1490,y:571,t:1528143767226};\\\", \\\"{x:1495,y:565,t:1528143767242};\\\", \\\"{x:1501,y:558,t:1528143767258};\\\", \\\"{x:1509,y:548,t:1528143767275};\\\", \\\"{x:1516,y:538,t:1528143767293};\\\", \\\"{x:1527,y:529,t:1528143767309};\\\", \\\"{x:1538,y:521,t:1528143767325};\\\", \\\"{x:1547,y:514,t:1528143767342};\\\", \\\"{x:1552,y:510,t:1528143767359};\\\", \\\"{x:1557,y:507,t:1528143767375};\\\", \\\"{x:1560,y:505,t:1528143767392};\\\", \\\"{x:1563,y:504,t:1528143767409};\\\", \\\"{x:1564,y:503,t:1528143767425};\\\", \\\"{x:1565,y:502,t:1528143767451};\\\", \\\"{x:1568,y:501,t:1528143767507};\\\", \\\"{x:1568,y:500,t:1528143767514};\\\", \\\"{x:1569,y:500,t:1528143767526};\\\", \\\"{x:1572,y:497,t:1528143767542};\\\", \\\"{x:1573,y:496,t:1528143767559};\\\", \\\"{x:1569,y:496,t:1528143768011};\\\", \\\"{x:1544,y:505,t:1528143768026};\\\", \\\"{x:1487,y:520,t:1528143768042};\\\", \\\"{x:1395,y:532,t:1528143768059};\\\", \\\"{x:1292,y:547,t:1528143768076};\\\", \\\"{x:1190,y:561,t:1528143768093};\\\", \\\"{x:1101,y:573,t:1528143768109};\\\", \\\"{x:1020,y:588,t:1528143768127};\\\", \\\"{x:948,y:596,t:1528143768144};\\\", \\\"{x:884,y:603,t:1528143768160};\\\", \\\"{x:831,y:611,t:1528143768176};\\\", \\\"{x:793,y:619,t:1528143768192};\\\", \\\"{x:725,y:640,t:1528143768210};\\\", \\\"{x:703,y:645,t:1528143768228};\\\", \\\"{x:690,y:647,t:1528143768245};\\\", \\\"{x:672,y:649,t:1528143768261};\\\", \\\"{x:657,y:652,t:1528143768278};\\\", \\\"{x:643,y:652,t:1528143768295};\\\", \\\"{x:628,y:653,t:1528143768311};\\\", \\\"{x:618,y:654,t:1528143768327};\\\", \\\"{x:602,y:657,t:1528143768344};\\\", \\\"{x:593,y:658,t:1528143768361};\\\", \\\"{x:591,y:658,t:1528143768378};\\\", \\\"{x:590,y:658,t:1528143768443};\\\", \\\"{x:587,y:658,t:1528143768450};\\\", \\\"{x:584,y:658,t:1528143768463};\\\", \\\"{x:575,y:656,t:1528143768478};\\\", \\\"{x:559,y:646,t:1528143768495};\\\", \\\"{x:541,y:636,t:1528143768512};\\\", \\\"{x:525,y:626,t:1528143768529};\\\", \\\"{x:508,y:618,t:1528143768545};\\\", \\\"{x:480,y:603,t:1528143768563};\\\", \\\"{x:464,y:597,t:1528143768579};\\\", \\\"{x:454,y:593,t:1528143768595};\\\", \\\"{x:451,y:592,t:1528143768611};\\\", \\\"{x:451,y:591,t:1528143768714};\\\", \\\"{x:448,y:587,t:1528143768728};\\\", \\\"{x:445,y:581,t:1528143768745};\\\", \\\"{x:440,y:569,t:1528143768762};\\\", \\\"{x:437,y:560,t:1528143768780};\\\", \\\"{x:433,y:553,t:1528143768795};\\\", \\\"{x:430,y:549,t:1528143768811};\\\", \\\"{x:428,y:546,t:1528143768829};\\\", \\\"{x:427,y:545,t:1528143768844};\\\", \\\"{x:425,y:544,t:1528143768865};\\\", \\\"{x:423,y:543,t:1528143768881};\\\", \\\"{x:421,y:543,t:1528143768898};\\\", \\\"{x:420,y:543,t:1528143768911};\\\", \\\"{x:418,y:542,t:1528143768929};\\\", \\\"{x:413,y:540,t:1528143768945};\\\", \\\"{x:407,y:538,t:1528143768962};\\\", \\\"{x:404,y:536,t:1528143768979};\\\", \\\"{x:400,y:535,t:1528143768996};\\\", \\\"{x:398,y:534,t:1528143769012};\\\", \\\"{x:396,y:533,t:1528143769029};\\\", \\\"{x:395,y:533,t:1528143769058};\\\", \\\"{x:394,y:533,t:1528143769082};\\\", \\\"{x:393,y:533,t:1528143769553};\\\", \\\"{x:387,y:534,t:1528143769563};\\\", \\\"{x:376,y:541,t:1528143769579};\\\", \\\"{x:362,y:548,t:1528143769596};\\\", \\\"{x:346,y:554,t:1528143769612};\\\", \\\"{x:333,y:557,t:1528143769629};\\\", \\\"{x:324,y:560,t:1528143769646};\\\", \\\"{x:313,y:563,t:1528143769663};\\\", \\\"{x:305,y:564,t:1528143769678};\\\", \\\"{x:292,y:564,t:1528143769696};\\\", \\\"{x:277,y:564,t:1528143769713};\\\", \\\"{x:265,y:564,t:1528143769730};\\\", \\\"{x:241,y:565,t:1528143769746};\\\", \\\"{x:231,y:565,t:1528143769763};\\\", \\\"{x:217,y:568,t:1528143769778};\\\", \\\"{x:208,y:569,t:1528143769796};\\\", \\\"{x:197,y:573,t:1528143769812};\\\", \\\"{x:184,y:578,t:1528143769830};\\\", \\\"{x:174,y:583,t:1528143769846};\\\", \\\"{x:166,y:588,t:1528143769864};\\\", \\\"{x:162,y:591,t:1528143769879};\\\", \\\"{x:158,y:593,t:1528143769895};\\\", \\\"{x:155,y:595,t:1528143769914};\\\", \\\"{x:153,y:596,t:1528143769929};\\\", \\\"{x:154,y:596,t:1528143770074};\\\", \\\"{x:156,y:597,t:1528143770098};\\\", \\\"{x:157,y:597,t:1528143770113};\\\", \\\"{x:161,y:592,t:1528143770130};\\\", \\\"{x:167,y:577,t:1528143770146};\\\", \\\"{x:174,y:561,t:1528143770163};\\\", \\\"{x:182,y:545,t:1528143770180};\\\", \\\"{x:191,y:533,t:1528143770196};\\\", \\\"{x:205,y:526,t:1528143770213};\\\", \\\"{x:217,y:521,t:1528143770229};\\\", \\\"{x:232,y:519,t:1528143770246};\\\", \\\"{x:250,y:517,t:1528143770263};\\\", \\\"{x:273,y:517,t:1528143770281};\\\", \\\"{x:298,y:516,t:1528143770296};\\\", \\\"{x:322,y:516,t:1528143770313};\\\", \\\"{x:355,y:516,t:1528143770329};\\\", \\\"{x:380,y:516,t:1528143770345};\\\", \\\"{x:407,y:516,t:1528143770362};\\\", \\\"{x:435,y:516,t:1528143770379};\\\", \\\"{x:478,y:516,t:1528143770396};\\\", \\\"{x:537,y:516,t:1528143770413};\\\", \\\"{x:584,y:516,t:1528143770429};\\\", \\\"{x:619,y:516,t:1528143770446};\\\", \\\"{x:650,y:516,t:1528143770463};\\\", \\\"{x:668,y:516,t:1528143770480};\\\", \\\"{x:681,y:516,t:1528143770496};\\\", \\\"{x:689,y:518,t:1528143770514};\\\", \\\"{x:691,y:519,t:1528143770530};\\\", \\\"{x:692,y:520,t:1528143770659};\\\", \\\"{x:691,y:524,t:1528143770666};\\\", \\\"{x:684,y:528,t:1528143770682};\\\", \\\"{x:663,y:538,t:1528143770697};\\\", \\\"{x:631,y:552,t:1528143770713};\\\", \\\"{x:587,y:565,t:1528143770732};\\\", \\\"{x:563,y:573,t:1528143770747};\\\", \\\"{x:542,y:579,t:1528143770763};\\\", \\\"{x:521,y:584,t:1528143770779};\\\", \\\"{x:498,y:591,t:1528143770797};\\\", \\\"{x:475,y:597,t:1528143770814};\\\", \\\"{x:452,y:599,t:1528143770829};\\\", \\\"{x:425,y:599,t:1528143770846};\\\", \\\"{x:387,y:599,t:1528143770863};\\\", \\\"{x:331,y:593,t:1528143770880};\\\", \\\"{x:278,y:584,t:1528143770896};\\\", \\\"{x:233,y:570,t:1528143770914};\\\", \\\"{x:176,y:558,t:1528143770930};\\\", \\\"{x:132,y:548,t:1528143770947};\\\", \\\"{x:110,y:542,t:1528143770963};\\\", \\\"{x:98,y:542,t:1528143770979};\\\", \\\"{x:97,y:542,t:1528143771001};\\\", \\\"{x:100,y:542,t:1528143771050};\\\", \\\"{x:105,y:542,t:1528143771064};\\\", \\\"{x:120,y:546,t:1528143771080};\\\", \\\"{x:136,y:548,t:1528143771097};\\\", \\\"{x:176,y:554,t:1528143771114};\\\", \\\"{x:201,y:558,t:1528143771131};\\\", \\\"{x:227,y:561,t:1528143771146};\\\", \\\"{x:250,y:565,t:1528143771164};\\\", \\\"{x:275,y:568,t:1528143771181};\\\", \\\"{x:305,y:576,t:1528143771197};\\\", \\\"{x:342,y:587,t:1528143771213};\\\", \\\"{x:382,y:600,t:1528143771230};\\\", \\\"{x:418,y:609,t:1528143771247};\\\", \\\"{x:443,y:619,t:1528143771263};\\\", \\\"{x:459,y:623,t:1528143771280};\\\", \\\"{x:463,y:624,t:1528143771297};\\\", \\\"{x:463,y:627,t:1528143771346};\\\", \\\"{x:461,y:633,t:1528143771354};\\\", \\\"{x:448,y:643,t:1528143771364};\\\", \\\"{x:430,y:655,t:1528143771381};\\\", \\\"{x:414,y:663,t:1528143771397};\\\", \\\"{x:399,y:666,t:1528143771414};\\\", \\\"{x:386,y:666,t:1528143771430};\\\", \\\"{x:381,y:666,t:1528143771446};\\\", \\\"{x:374,y:665,t:1528143771464};\\\", \\\"{x:371,y:662,t:1528143771482};\\\", \\\"{x:370,y:656,t:1528143771496};\\\", \\\"{x:371,y:636,t:1528143771514};\\\", \\\"{x:375,y:628,t:1528143771532};\\\", \\\"{x:381,y:619,t:1528143771548};\\\", \\\"{x:385,y:612,t:1528143771564};\\\", \\\"{x:385,y:610,t:1528143771581};\\\", \\\"{x:387,y:609,t:1528143771598};\\\", \\\"{x:388,y:608,t:1528143772089};\\\", \\\"{x:391,y:608,t:1528143772098};\\\", \\\"{x:406,y:608,t:1528143772114};\\\", \\\"{x:428,y:613,t:1528143772131};\\\", \\\"{x:452,y:624,t:1528143772148};\\\", \\\"{x:494,y:642,t:1528143772165};\\\", \\\"{x:556,y:661,t:1528143772182};\\\", \\\"{x:625,y:683,t:1528143772197};\\\", \\\"{x:711,y:707,t:1528143772214};\\\", \\\"{x:791,y:726,t:1528143772231};\\\", \\\"{x:877,y:749,t:1528143772247};\\\", \\\"{x:956,y:765,t:1528143772265};\\\", \\\"{x:1028,y:776,t:1528143772281};\\\", \\\"{x:1122,y:800,t:1528143772298};\\\", \\\"{x:1180,y:813,t:1528143772314};\\\", \\\"{x:1207,y:820,t:1528143772331};\\\", \\\"{x:1226,y:828,t:1528143772348};\\\", \\\"{x:1241,y:836,t:1528143772365};\\\", \\\"{x:1252,y:843,t:1528143772381};\\\", \\\"{x:1265,y:853,t:1528143772398};\\\", \\\"{x:1280,y:862,t:1528143772416};\\\", \\\"{x:1293,y:867,t:1528143772431};\\\", \\\"{x:1303,y:871,t:1528143772449};\\\", \\\"{x:1309,y:873,t:1528143772466};\\\", \\\"{x:1310,y:873,t:1528143772481};\\\", \\\"{x:1317,y:873,t:1528143772498};\\\", \\\"{x:1329,y:873,t:1528143772516};\\\", \\\"{x:1337,y:873,t:1528143772532};\\\", \\\"{x:1338,y:873,t:1528143772549};\\\", \\\"{x:1340,y:873,t:1528143772566};\\\", \\\"{x:1341,y:873,t:1528143772582};\\\", \\\"{x:1344,y:876,t:1528143772599};\\\", \\\"{x:1353,y:883,t:1528143772615};\\\", \\\"{x:1365,y:890,t:1528143772632};\\\", \\\"{x:1379,y:899,t:1528143772651};\\\", \\\"{x:1391,y:907,t:1528143772666};\\\", \\\"{x:1408,y:915,t:1528143772682};\\\", \\\"{x:1415,y:918,t:1528143772698};\\\", \\\"{x:1416,y:919,t:1528143772715};\\\", \\\"{x:1416,y:921,t:1528143772818};\\\", \\\"{x:1413,y:925,t:1528143772833};\\\", \\\"{x:1404,y:934,t:1528143772848};\\\", \\\"{x:1397,y:942,t:1528143772865};\\\", \\\"{x:1386,y:952,t:1528143772882};\\\", \\\"{x:1377,y:959,t:1528143772898};\\\", \\\"{x:1370,y:964,t:1528143772916};\\\", \\\"{x:1367,y:966,t:1528143772933};\\\", \\\"{x:1363,y:968,t:1528143772949};\\\", \\\"{x:1362,y:968,t:1528143772966};\\\", \\\"{x:1361,y:968,t:1528143772983};\\\", \\\"{x:1359,y:968,t:1528143772998};\\\", \\\"{x:1357,y:969,t:1528143773015};\\\", \\\"{x:1355,y:969,t:1528143773032};\\\", \\\"{x:1354,y:969,t:1528143773281};\\\", \\\"{x:1354,y:968,t:1528143773299};\\\", \\\"{x:1354,y:966,t:1528143773443};\\\", \\\"{x:1354,y:962,t:1528143773458};\\\", \\\"{x:1357,y:956,t:1528143773466};\\\", \\\"{x:1362,y:947,t:1528143773482};\\\", \\\"{x:1367,y:937,t:1528143773499};\\\", \\\"{x:1369,y:929,t:1528143773516};\\\", \\\"{x:1373,y:920,t:1528143773532};\\\", \\\"{x:1375,y:916,t:1528143773550};\\\", \\\"{x:1377,y:914,t:1528143773567};\\\", \\\"{x:1377,y:912,t:1528143773582};\\\", \\\"{x:1376,y:911,t:1528143774066};\\\", \\\"{x:1352,y:911,t:1528143774084};\\\", \\\"{x:1320,y:913,t:1528143774099};\\\", \\\"{x:1271,y:913,t:1528143774116};\\\", \\\"{x:1210,y:913,t:1528143774134};\\\", \\\"{x:1143,y:905,t:1528143774150};\\\", \\\"{x:1060,y:880,t:1528143774167};\\\", \\\"{x:1011,y:861,t:1528143774183};\\\", \\\"{x:954,y:843,t:1528143774200};\\\", \\\"{x:908,y:825,t:1528143774217};\\\", \\\"{x:880,y:813,t:1528143774234};\\\", \\\"{x:857,y:803,t:1528143774250};\\\", \\\"{x:848,y:799,t:1528143774266};\\\", \\\"{x:842,y:798,t:1528143774283};\\\", \\\"{x:837,y:798,t:1528143774300};\\\", \\\"{x:830,y:798,t:1528143774316};\\\", \\\"{x:825,y:798,t:1528143774333};\\\", \\\"{x:818,y:798,t:1528143774349};\\\", \\\"{x:814,y:798,t:1528143774366};\\\", \\\"{x:811,y:798,t:1528143774383};\\\", \\\"{x:810,y:798,t:1528143774399};\\\", \\\"{x:809,y:799,t:1528143774415};\\\", \\\"{x:808,y:799,t:1528143774433};\\\", \\\"{x:805,y:799,t:1528143774449};\\\", \\\"{x:800,y:799,t:1528143774465};\\\", \\\"{x:792,y:798,t:1528143774483};\\\", \\\"{x:776,y:797,t:1528143774500};\\\", \\\"{x:754,y:797,t:1528143774516};\\\", \\\"{x:725,y:794,t:1528143774532};\\\", \\\"{x:694,y:792,t:1528143774550};\\\", \\\"{x:658,y:789,t:1528143774567};\\\", \\\"{x:625,y:786,t:1528143774582};\\\", \\\"{x:591,y:781,t:1528143774600};\\\", \\\"{x:568,y:777,t:1528143774617};\\\", \\\"{x:550,y:775,t:1528143774633};\\\", \\\"{x:526,y:769,t:1528143774649};\\\", \\\"{x:518,y:766,t:1528143774667};\\\", \\\"{x:512,y:763,t:1528143774682};\\\", \\\"{x:508,y:760,t:1528143774699};\\\", \\\"{x:506,y:760,t:1528143774716};\\\", \\\"{x:504,y:758,t:1528143774733};\\\", \\\"{x:503,y:758,t:1528143774750};\\\", \\\"{x:502,y:756,t:1528143775114};\\\", \\\"{x:502,y:753,t:1528143775121};\\\", \\\"{x:502,y:750,t:1528143775134};\\\", \\\"{x:502,y:743,t:1528143775149};\\\", \\\"{x:502,y:737,t:1528143775161};\\\", \\\"{x:503,y:732,t:1528143775178};\\\", \\\"{x:504,y:728,t:1528143775194};\\\", \\\"{x:504,y:726,t:1528143775211};\\\" ] }, { \\\"rt\\\": 12282, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 630272, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:508,y:724,t:1528143782147};\\\", \\\"{x:511,y:724,t:1528143782157};\\\", \\\"{x:517,y:720,t:1528143782173};\\\", \\\"{x:522,y:718,t:1528143782192};\\\", \\\"{x:526,y:716,t:1528143782206};\\\", \\\"{x:532,y:713,t:1528143782223};\\\", \\\"{x:539,y:710,t:1528143782239};\\\", \\\"{x:547,y:705,t:1528143782256};\\\", \\\"{x:558,y:702,t:1528143782272};\\\", \\\"{x:576,y:695,t:1528143782289};\\\", \\\"{x:585,y:694,t:1528143782305};\\\", \\\"{x:596,y:690,t:1528143782322};\\\", \\\"{x:614,y:684,t:1528143782339};\\\", \\\"{x:641,y:680,t:1528143782356};\\\", \\\"{x:670,y:679,t:1528143782373};\\\", \\\"{x:698,y:677,t:1528143782389};\\\", \\\"{x:738,y:676,t:1528143782406};\\\", \\\"{x:831,y:670,t:1528143782422};\\\", \\\"{x:903,y:670,t:1528143782440};\\\", \\\"{x:988,y:677,t:1528143782456};\\\", \\\"{x:1091,y:693,t:1528143782472};\\\", \\\"{x:1209,y:709,t:1528143782490};\\\", \\\"{x:1251,y:713,t:1528143782506};\\\", \\\"{x:1287,y:713,t:1528143782522};\\\", \\\"{x:1328,y:716,t:1528143782539};\\\", \\\"{x:1358,y:717,t:1528143782557};\\\", \\\"{x:1382,y:717,t:1528143782573};\\\", \\\"{x:1401,y:717,t:1528143782590};\\\", \\\"{x:1412,y:717,t:1528143782607};\\\", \\\"{x:1418,y:717,t:1528143782623};\\\", \\\"{x:1419,y:717,t:1528143782640};\\\", \\\"{x:1420,y:717,t:1528143783035};\\\", \\\"{x:1420,y:716,t:1528143783042};\\\", \\\"{x:1422,y:713,t:1528143783057};\\\", \\\"{x:1423,y:708,t:1528143783074};\\\", \\\"{x:1424,y:706,t:1528143783090};\\\", \\\"{x:1424,y:704,t:1528143783107};\\\", \\\"{x:1425,y:703,t:1528143783124};\\\", \\\"{x:1426,y:702,t:1528143783170};\\\", \\\"{x:1427,y:701,t:1528143783187};\\\", \\\"{x:1428,y:700,t:1528143783202};\\\", \\\"{x:1429,y:699,t:1528143783209};\\\", \\\"{x:1430,y:698,t:1528143783226};\\\", \\\"{x:1430,y:697,t:1528143783241};\\\", \\\"{x:1432,y:694,t:1528143783256};\\\", \\\"{x:1434,y:690,t:1528143783273};\\\", \\\"{x:1436,y:687,t:1528143783290};\\\", \\\"{x:1436,y:686,t:1528143783306};\\\", \\\"{x:1437,y:684,t:1528143783323};\\\", \\\"{x:1438,y:684,t:1528143783427};\\\", \\\"{x:1443,y:683,t:1528143783441};\\\", \\\"{x:1462,y:677,t:1528143783458};\\\", \\\"{x:1475,y:672,t:1528143783474};\\\", \\\"{x:1505,y:660,t:1528143783491};\\\", \\\"{x:1529,y:652,t:1528143783508};\\\", \\\"{x:1550,y:646,t:1528143783524};\\\", \\\"{x:1562,y:644,t:1528143783541};\\\", \\\"{x:1571,y:641,t:1528143783558};\\\", \\\"{x:1573,y:641,t:1528143783574};\\\", \\\"{x:1574,y:641,t:1528143783591};\\\", \\\"{x:1575,y:641,t:1528143784562};\\\", \\\"{x:1575,y:648,t:1528143784576};\\\", \\\"{x:1571,y:666,t:1528143784593};\\\", \\\"{x:1565,y:690,t:1528143784608};\\\", \\\"{x:1560,y:705,t:1528143784625};\\\", \\\"{x:1556,y:721,t:1528143784642};\\\", \\\"{x:1555,y:727,t:1528143784658};\\\", \\\"{x:1554,y:731,t:1528143784675};\\\", \\\"{x:1553,y:731,t:1528143784692};\\\", \\\"{x:1553,y:733,t:1528143784708};\\\", \\\"{x:1552,y:734,t:1528143784731};\\\", \\\"{x:1552,y:735,t:1528143784742};\\\", \\\"{x:1549,y:738,t:1528143784758};\\\", \\\"{x:1544,y:745,t:1528143784775};\\\", \\\"{x:1540,y:751,t:1528143784793};\\\", \\\"{x:1536,y:758,t:1528143784809};\\\", \\\"{x:1534,y:761,t:1528143784825};\\\", \\\"{x:1532,y:764,t:1528143784842};\\\", \\\"{x:1532,y:765,t:1528143784859};\\\", \\\"{x:1532,y:767,t:1528143784876};\\\", \\\"{x:1532,y:768,t:1528143784892};\\\", \\\"{x:1532,y:770,t:1528143784931};\\\", \\\"{x:1532,y:771,t:1528143784942};\\\", \\\"{x:1532,y:776,t:1528143784959};\\\", \\\"{x:1530,y:782,t:1528143784975};\\\", \\\"{x:1527,y:789,t:1528143784992};\\\", \\\"{x:1525,y:795,t:1528143785010};\\\", \\\"{x:1524,y:803,t:1528143785025};\\\", \\\"{x:1522,y:809,t:1528143785042};\\\", \\\"{x:1522,y:813,t:1528143785058};\\\", \\\"{x:1521,y:814,t:1528143785075};\\\", \\\"{x:1521,y:815,t:1528143785092};\\\", \\\"{x:1520,y:816,t:1528143785347};\\\", \\\"{x:1513,y:811,t:1528143785359};\\\", \\\"{x:1486,y:793,t:1528143785376};\\\", \\\"{x:1452,y:771,t:1528143785393};\\\", \\\"{x:1431,y:755,t:1528143785409};\\\", \\\"{x:1384,y:729,t:1528143785426};\\\", \\\"{x:1362,y:717,t:1528143785442};\\\", \\\"{x:1343,y:708,t:1528143785459};\\\", \\\"{x:1338,y:707,t:1528143785476};\\\", \\\"{x:1336,y:706,t:1528143785493};\\\", \\\"{x:1335,y:705,t:1528143786571};\\\", \\\"{x:1324,y:705,t:1528143786578};\\\", \\\"{x:1305,y:704,t:1528143786593};\\\", \\\"{x:1239,y:695,t:1528143786611};\\\", \\\"{x:1178,y:687,t:1528143786626};\\\", \\\"{x:1114,y:677,t:1528143786643};\\\", \\\"{x:1054,y:666,t:1528143786660};\\\", \\\"{x:992,y:656,t:1528143786678};\\\", \\\"{x:933,y:646,t:1528143786694};\\\", \\\"{x:898,y:639,t:1528143786709};\\\", \\\"{x:874,y:636,t:1528143786727};\\\", \\\"{x:855,y:635,t:1528143786743};\\\", \\\"{x:842,y:633,t:1528143786760};\\\", \\\"{x:837,y:631,t:1528143786778};\\\", \\\"{x:834,y:631,t:1528143786792};\\\", \\\"{x:831,y:630,t:1528143786809};\\\", \\\"{x:828,y:630,t:1528143786827};\\\", \\\"{x:822,y:629,t:1528143786842};\\\", \\\"{x:813,y:629,t:1528143786859};\\\", \\\"{x:805,y:626,t:1528143786877};\\\", \\\"{x:796,y:625,t:1528143786893};\\\", \\\"{x:788,y:624,t:1528143786909};\\\", \\\"{x:783,y:623,t:1528143786926};\\\", \\\"{x:776,y:621,t:1528143786943};\\\", \\\"{x:772,y:620,t:1528143786960};\\\", \\\"{x:769,y:618,t:1528143786976};\\\", \\\"{x:764,y:615,t:1528143786994};\\\", \\\"{x:761,y:611,t:1528143787010};\\\", \\\"{x:756,y:603,t:1528143787026};\\\", \\\"{x:749,y:593,t:1528143787045};\\\", \\\"{x:743,y:587,t:1528143787060};\\\", \\\"{x:735,y:583,t:1528143787076};\\\", \\\"{x:729,y:580,t:1528143787094};\\\", \\\"{x:723,y:577,t:1528143787111};\\\", \\\"{x:718,y:575,t:1528143787126};\\\", \\\"{x:713,y:574,t:1528143787144};\\\", \\\"{x:710,y:572,t:1528143787159};\\\", \\\"{x:705,y:570,t:1528143787177};\\\", \\\"{x:696,y:567,t:1528143787194};\\\", \\\"{x:688,y:563,t:1528143787210};\\\", \\\"{x:679,y:560,t:1528143787228};\\\", \\\"{x:674,y:559,t:1528143787244};\\\", \\\"{x:669,y:558,t:1528143787260};\\\", \\\"{x:667,y:558,t:1528143787276};\\\", \\\"{x:666,y:557,t:1528143787354};\\\", \\\"{x:669,y:555,t:1528143787364};\\\", \\\"{x:681,y:549,t:1528143787377};\\\", \\\"{x:695,y:542,t:1528143787393};\\\", \\\"{x:706,y:539,t:1528143787410};\\\", \\\"{x:720,y:535,t:1528143787427};\\\", \\\"{x:727,y:533,t:1528143787446};\\\", \\\"{x:733,y:531,t:1528143787460};\\\", \\\"{x:738,y:530,t:1528143787476};\\\", \\\"{x:744,y:528,t:1528143787494};\\\", \\\"{x:748,y:528,t:1528143787511};\\\", \\\"{x:750,y:528,t:1528143787526};\\\", \\\"{x:752,y:528,t:1528143787543};\\\", \\\"{x:756,y:528,t:1528143787560};\\\", \\\"{x:760,y:529,t:1528143787576};\\\", \\\"{x:765,y:532,t:1528143787593};\\\", \\\"{x:770,y:533,t:1528143787611};\\\", \\\"{x:774,y:533,t:1528143787627};\\\", \\\"{x:780,y:535,t:1528143787644};\\\", \\\"{x:783,y:535,t:1528143787661};\\\", \\\"{x:787,y:535,t:1528143787677};\\\", \\\"{x:790,y:535,t:1528143787694};\\\", \\\"{x:794,y:535,t:1528143787711};\\\", \\\"{x:797,y:535,t:1528143787727};\\\", \\\"{x:798,y:535,t:1528143787743};\\\", \\\"{x:798,y:536,t:1528143787819};\\\", \\\"{x:798,y:538,t:1528143787828};\\\", \\\"{x:793,y:541,t:1528143787843};\\\", \\\"{x:784,y:544,t:1528143787861};\\\", \\\"{x:765,y:550,t:1528143787878};\\\", \\\"{x:746,y:554,t:1528143787894};\\\", \\\"{x:735,y:555,t:1528143787911};\\\", \\\"{x:733,y:555,t:1528143787927};\\\", \\\"{x:731,y:555,t:1528143787943};\\\", \\\"{x:735,y:555,t:1528143788011};\\\", \\\"{x:746,y:553,t:1528143788028};\\\", \\\"{x:754,y:552,t:1528143788045};\\\", \\\"{x:762,y:552,t:1528143788061};\\\", \\\"{x:774,y:552,t:1528143788078};\\\", \\\"{x:788,y:552,t:1528143788094};\\\", \\\"{x:798,y:552,t:1528143788111};\\\", \\\"{x:802,y:552,t:1528143788128};\\\", \\\"{x:807,y:550,t:1528143788144};\\\", \\\"{x:811,y:549,t:1528143788161};\\\", \\\"{x:820,y:547,t:1528143788178};\\\", \\\"{x:826,y:545,t:1528143788195};\\\", \\\"{x:829,y:545,t:1528143788210};\\\", \\\"{x:831,y:544,t:1528143788227};\\\", \\\"{x:832,y:544,t:1528143788273};\\\", \\\"{x:833,y:544,t:1528143788313};\\\", \\\"{x:834,y:544,t:1528143788328};\\\", \\\"{x:829,y:545,t:1528143788634};\\\", \\\"{x:808,y:553,t:1528143788645};\\\", \\\"{x:744,y:574,t:1528143788663};\\\", \\\"{x:690,y:590,t:1528143788678};\\\", \\\"{x:654,y:601,t:1528143788696};\\\", \\\"{x:619,y:613,t:1528143788712};\\\", \\\"{x:589,y:624,t:1528143788728};\\\", \\\"{x:577,y:629,t:1528143788745};\\\", \\\"{x:573,y:630,t:1528143788762};\\\", \\\"{x:573,y:631,t:1528143788777};\\\", \\\"{x:571,y:633,t:1528143788795};\\\", \\\"{x:571,y:634,t:1528143788811};\\\", \\\"{x:571,y:635,t:1528143788914};\\\", \\\"{x:569,y:640,t:1528143788927};\\\", \\\"{x:565,y:651,t:1528143788944};\\\", \\\"{x:554,y:672,t:1528143788962};\\\", \\\"{x:549,y:687,t:1528143788978};\\\", \\\"{x:541,y:702,t:1528143788995};\\\", \\\"{x:536,y:713,t:1528143789011};\\\", \\\"{x:534,y:718,t:1528143789027};\\\", \\\"{x:532,y:721,t:1528143789046};\\\", \\\"{x:531,y:722,t:1528143789061};\\\", \\\"{x:531,y:723,t:1528143789153};\\\", \\\"{x:531,y:725,t:1528143789161};\\\", \\\"{x:525,y:732,t:1528143789178};\\\", \\\"{x:521,y:736,t:1528143789195};\\\", \\\"{x:520,y:737,t:1528143789212};\\\" ] }, { \\\"rt\\\": 11481, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 642998, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:738,t:1528143793627};\\\", \\\"{x:516,y:738,t:1528143793638};\\\", \\\"{x:509,y:738,t:1528143793654};\\\", \\\"{x:500,y:738,t:1528143793672};\\\", \\\"{x:480,y:739,t:1528143793688};\\\", \\\"{x:458,y:743,t:1528143793705};\\\", \\\"{x:436,y:746,t:1528143793723};\\\", \\\"{x:407,y:752,t:1528143793738};\\\", \\\"{x:386,y:754,t:1528143793755};\\\", \\\"{x:369,y:757,t:1528143793771};\\\", \\\"{x:351,y:757,t:1528143793795};\\\", \\\"{x:346,y:757,t:1528143793801};\\\", \\\"{x:340,y:757,t:1528143793814};\\\", \\\"{x:332,y:757,t:1528143793831};\\\", \\\"{x:320,y:756,t:1528143793848};\\\", \\\"{x:308,y:752,t:1528143793864};\\\", \\\"{x:299,y:750,t:1528143793881};\\\", \\\"{x:293,y:748,t:1528143793898};\\\", \\\"{x:292,y:747,t:1528143793914};\\\", \\\"{x:292,y:746,t:1528143793953};\\\", \\\"{x:292,y:743,t:1528143793964};\\\", \\\"{x:302,y:734,t:1528143793981};\\\", \\\"{x:323,y:719,t:1528143793998};\\\", \\\"{x:351,y:703,t:1528143794015};\\\", \\\"{x:392,y:680,t:1528143794031};\\\", \\\"{x:491,y:619,t:1528143794048};\\\", \\\"{x:605,y:559,t:1528143794065};\\\", \\\"{x:774,y:495,t:1528143794083};\\\", \\\"{x:873,y:467,t:1528143794099};\\\", \\\"{x:957,y:440,t:1528143794116};\\\", \\\"{x:1030,y:416,t:1528143794132};\\\", \\\"{x:1105,y:394,t:1528143794149};\\\", \\\"{x:1160,y:382,t:1528143794166};\\\", \\\"{x:1194,y:369,t:1528143794182};\\\", \\\"{x:1210,y:365,t:1528143794199};\\\", \\\"{x:1215,y:364,t:1528143794216};\\\", \\\"{x:1216,y:364,t:1528143794232};\\\", \\\"{x:1219,y:364,t:1528143794306};\\\", \\\"{x:1223,y:362,t:1528143794316};\\\", \\\"{x:1235,y:359,t:1528143794332};\\\", \\\"{x:1250,y:355,t:1528143794349};\\\", \\\"{x:1268,y:352,t:1528143794366};\\\", \\\"{x:1289,y:352,t:1528143794383};\\\", \\\"{x:1307,y:352,t:1528143794399};\\\", \\\"{x:1322,y:352,t:1528143794416};\\\", \\\"{x:1338,y:357,t:1528143794433};\\\", \\\"{x:1358,y:366,t:1528143794449};\\\", \\\"{x:1387,y:384,t:1528143794465};\\\", \\\"{x:1407,y:397,t:1528143794483};\\\", \\\"{x:1429,y:410,t:1528143794499};\\\", \\\"{x:1452,y:425,t:1528143794516};\\\", \\\"{x:1469,y:432,t:1528143794533};\\\", \\\"{x:1485,y:440,t:1528143794550};\\\", \\\"{x:1491,y:442,t:1528143794566};\\\", \\\"{x:1495,y:445,t:1528143794583};\\\", \\\"{x:1496,y:445,t:1528143794600};\\\", \\\"{x:1497,y:445,t:1528143794651};\\\", \\\"{x:1501,y:448,t:1528143794666};\\\", \\\"{x:1510,y:453,t:1528143794684};\\\", \\\"{x:1515,y:457,t:1528143794699};\\\", \\\"{x:1525,y:466,t:1528143794716};\\\", \\\"{x:1535,y:475,t:1528143794733};\\\", \\\"{x:1544,y:483,t:1528143794750};\\\", \\\"{x:1554,y:492,t:1528143794767};\\\", \\\"{x:1564,y:501,t:1528143794784};\\\", \\\"{x:1568,y:506,t:1528143794799};\\\", \\\"{x:1575,y:510,t:1528143794817};\\\", \\\"{x:1580,y:513,t:1528143794834};\\\", \\\"{x:1585,y:516,t:1528143794850};\\\", \\\"{x:1593,y:523,t:1528143794866};\\\", \\\"{x:1600,y:531,t:1528143794883};\\\", \\\"{x:1608,y:538,t:1528143794899};\\\", \\\"{x:1616,y:548,t:1528143794917};\\\", \\\"{x:1622,y:558,t:1528143794933};\\\", \\\"{x:1627,y:567,t:1528143794950};\\\", \\\"{x:1632,y:576,t:1528143794967};\\\", \\\"{x:1635,y:582,t:1528143794984};\\\", \\\"{x:1639,y:589,t:1528143794999};\\\", \\\"{x:1640,y:591,t:1528143795016};\\\", \\\"{x:1642,y:594,t:1528143795034};\\\", \\\"{x:1643,y:595,t:1528143795050};\\\", \\\"{x:1643,y:596,t:1528143795075};\\\", \\\"{x:1644,y:597,t:1528143795084};\\\", \\\"{x:1645,y:601,t:1528143795100};\\\", \\\"{x:1646,y:607,t:1528143795117};\\\", \\\"{x:1650,y:615,t:1528143795134};\\\", \\\"{x:1651,y:624,t:1528143795150};\\\", \\\"{x:1655,y:635,t:1528143795167};\\\", \\\"{x:1657,y:644,t:1528143795184};\\\", \\\"{x:1663,y:658,t:1528143795200};\\\", \\\"{x:1669,y:667,t:1528143795217};\\\", \\\"{x:1679,y:677,t:1528143795234};\\\", \\\"{x:1691,y:687,t:1528143795249};\\\", \\\"{x:1707,y:699,t:1528143795266};\\\", \\\"{x:1719,y:705,t:1528143795283};\\\", \\\"{x:1725,y:711,t:1528143795300};\\\", \\\"{x:1730,y:716,t:1528143795317};\\\", \\\"{x:1731,y:720,t:1528143795333};\\\", \\\"{x:1733,y:724,t:1528143795349};\\\", \\\"{x:1733,y:728,t:1528143795367};\\\", \\\"{x:1733,y:736,t:1528143795383};\\\", \\\"{x:1733,y:743,t:1528143795399};\\\", \\\"{x:1732,y:747,t:1528143795416};\\\", \\\"{x:1729,y:753,t:1528143795434};\\\", \\\"{x:1724,y:758,t:1528143795449};\\\", \\\"{x:1721,y:760,t:1528143795466};\\\", \\\"{x:1720,y:760,t:1528143795522};\\\", \\\"{x:1718,y:760,t:1528143795534};\\\", \\\"{x:1712,y:757,t:1528143795550};\\\", \\\"{x:1704,y:749,t:1528143795566};\\\", \\\"{x:1698,y:744,t:1528143795584};\\\", \\\"{x:1685,y:736,t:1528143795600};\\\", \\\"{x:1674,y:729,t:1528143795616};\\\", \\\"{x:1668,y:726,t:1528143795634};\\\", \\\"{x:1661,y:721,t:1528143795650};\\\", \\\"{x:1647,y:714,t:1528143795666};\\\", \\\"{x:1643,y:712,t:1528143795683};\\\", \\\"{x:1636,y:709,t:1528143795699};\\\", \\\"{x:1626,y:704,t:1528143795715};\\\", \\\"{x:1618,y:701,t:1528143795734};\\\", \\\"{x:1613,y:697,t:1528143795749};\\\", \\\"{x:1607,y:695,t:1528143795766};\\\", \\\"{x:1602,y:692,t:1528143795783};\\\", \\\"{x:1599,y:691,t:1528143795799};\\\", \\\"{x:1598,y:691,t:1528143795816};\\\", \\\"{x:1598,y:690,t:1528143796034};\\\", \\\"{x:1599,y:690,t:1528143796050};\\\", \\\"{x:1601,y:690,t:1528143796082};\\\", \\\"{x:1602,y:690,t:1528143796122};\\\", \\\"{x:1604,y:690,t:1528143796146};\\\", \\\"{x:1605,y:690,t:1528143796162};\\\", \\\"{x:1606,y:690,t:1528143796202};\\\", \\\"{x:1607,y:690,t:1528143796217};\\\", \\\"{x:1608,y:690,t:1528143796243};\\\", \\\"{x:1610,y:690,t:1528143796266};\\\", \\\"{x:1610,y:694,t:1528143796812};\\\", \\\"{x:1604,y:703,t:1528143796835};\\\", \\\"{x:1598,y:713,t:1528143796851};\\\", \\\"{x:1596,y:715,t:1528143796867};\\\", \\\"{x:1596,y:717,t:1528143796884};\\\", \\\"{x:1595,y:719,t:1528143796902};\\\", \\\"{x:1595,y:721,t:1528143797001};\\\", \\\"{x:1593,y:722,t:1528143797016};\\\", \\\"{x:1592,y:725,t:1528143797032};\\\", \\\"{x:1589,y:731,t:1528143797049};\\\", \\\"{x:1587,y:733,t:1528143797066};\\\", \\\"{x:1585,y:735,t:1528143797083};\\\", \\\"{x:1585,y:738,t:1528143797100};\\\", \\\"{x:1584,y:739,t:1528143797117};\\\", \\\"{x:1583,y:739,t:1528143797133};\\\", \\\"{x:1583,y:741,t:1528143797151};\\\", \\\"{x:1583,y:742,t:1528143797178};\\\", \\\"{x:1583,y:743,t:1528143797186};\\\", \\\"{x:1582,y:744,t:1528143797201};\\\", \\\"{x:1580,y:746,t:1528143797216};\\\", \\\"{x:1580,y:747,t:1528143797234};\\\", \\\"{x:1576,y:752,t:1528143797251};\\\", \\\"{x:1574,y:756,t:1528143797267};\\\", \\\"{x:1571,y:761,t:1528143797284};\\\", \\\"{x:1569,y:764,t:1528143797300};\\\", \\\"{x:1568,y:767,t:1528143797317};\\\", \\\"{x:1566,y:771,t:1528143797334};\\\", \\\"{x:1565,y:773,t:1528143797351};\\\", \\\"{x:1563,y:777,t:1528143797367};\\\", \\\"{x:1562,y:779,t:1528143797386};\\\", \\\"{x:1561,y:781,t:1528143797401};\\\", \\\"{x:1561,y:783,t:1528143797417};\\\", \\\"{x:1558,y:786,t:1528143797434};\\\", \\\"{x:1555,y:792,t:1528143797450};\\\", \\\"{x:1551,y:797,t:1528143797467};\\\", \\\"{x:1549,y:802,t:1528143797484};\\\", \\\"{x:1545,y:808,t:1528143797501};\\\", \\\"{x:1541,y:813,t:1528143797517};\\\", \\\"{x:1537,y:821,t:1528143797534};\\\", \\\"{x:1534,y:825,t:1528143797551};\\\", \\\"{x:1530,y:831,t:1528143797567};\\\", \\\"{x:1527,y:838,t:1528143797584};\\\", \\\"{x:1526,y:840,t:1528143797601};\\\", \\\"{x:1523,y:844,t:1528143797617};\\\", \\\"{x:1522,y:847,t:1528143797634};\\\", \\\"{x:1521,y:850,t:1528143797651};\\\", \\\"{x:1520,y:851,t:1528143797666};\\\", \\\"{x:1519,y:854,t:1528143797684};\\\", \\\"{x:1518,y:858,t:1528143797701};\\\", \\\"{x:1516,y:862,t:1528143797717};\\\", \\\"{x:1516,y:865,t:1528143797733};\\\", \\\"{x:1515,y:869,t:1528143797751};\\\", \\\"{x:1513,y:875,t:1528143797767};\\\", \\\"{x:1512,y:879,t:1528143797784};\\\", \\\"{x:1511,y:882,t:1528143797800};\\\", \\\"{x:1511,y:886,t:1528143797817};\\\", \\\"{x:1509,y:889,t:1528143797833};\\\", \\\"{x:1509,y:892,t:1528143797850};\\\", \\\"{x:1508,y:893,t:1528143797866};\\\", \\\"{x:1508,y:896,t:1528143797884};\\\", \\\"{x:1506,y:899,t:1528143797901};\\\", \\\"{x:1505,y:901,t:1528143797917};\\\", \\\"{x:1505,y:903,t:1528143797934};\\\", \\\"{x:1502,y:907,t:1528143797951};\\\", \\\"{x:1501,y:909,t:1528143797966};\\\", \\\"{x:1499,y:911,t:1528143797984};\\\", \\\"{x:1498,y:914,t:1528143798000};\\\", \\\"{x:1497,y:916,t:1528143798016};\\\", \\\"{x:1495,y:919,t:1528143798033};\\\", \\\"{x:1495,y:921,t:1528143798051};\\\", \\\"{x:1493,y:922,t:1528143798067};\\\", \\\"{x:1493,y:923,t:1528143798084};\\\", \\\"{x:1492,y:924,t:1528143798162};\\\", \\\"{x:1492,y:926,t:1528143798186};\\\", \\\"{x:1491,y:927,t:1528143798200};\\\", \\\"{x:1489,y:931,t:1528143798217};\\\", \\\"{x:1487,y:934,t:1528143798233};\\\", \\\"{x:1483,y:941,t:1528143798250};\\\", \\\"{x:1481,y:943,t:1528143798267};\\\", \\\"{x:1479,y:946,t:1528143798284};\\\", \\\"{x:1478,y:947,t:1528143798301};\\\", \\\"{x:1478,y:948,t:1528143798317};\\\", \\\"{x:1477,y:949,t:1528143798334};\\\", \\\"{x:1475,y:951,t:1528143798435};\\\", \\\"{x:1473,y:951,t:1528143798667};\\\", \\\"{x:1467,y:951,t:1528143798684};\\\", \\\"{x:1462,y:947,t:1528143798701};\\\", \\\"{x:1452,y:935,t:1528143798717};\\\", \\\"{x:1444,y:927,t:1528143798734};\\\", \\\"{x:1439,y:919,t:1528143798751};\\\", \\\"{x:1435,y:912,t:1528143798768};\\\", \\\"{x:1433,y:905,t:1528143798784};\\\", \\\"{x:1430,y:895,t:1528143798801};\\\", \\\"{x:1426,y:872,t:1528143798818};\\\", \\\"{x:1421,y:852,t:1528143798834};\\\", \\\"{x:1414,y:834,t:1528143798851};\\\", \\\"{x:1410,y:818,t:1528143798868};\\\", \\\"{x:1402,y:801,t:1528143798884};\\\", \\\"{x:1397,y:786,t:1528143798901};\\\", \\\"{x:1392,y:773,t:1528143798917};\\\", \\\"{x:1388,y:758,t:1528143798934};\\\", \\\"{x:1381,y:736,t:1528143798950};\\\", \\\"{x:1377,y:721,t:1528143798967};\\\", \\\"{x:1375,y:711,t:1528143798983};\\\", \\\"{x:1372,y:705,t:1528143799001};\\\", \\\"{x:1371,y:700,t:1528143799018};\\\", \\\"{x:1370,y:697,t:1528143799034};\\\", \\\"{x:1369,y:694,t:1528143799050};\\\", \\\"{x:1368,y:691,t:1528143799067};\\\", \\\"{x:1367,y:687,t:1528143799084};\\\", \\\"{x:1363,y:682,t:1528143799101};\\\", \\\"{x:1352,y:672,t:1528143799118};\\\", \\\"{x:1333,y:659,t:1528143799133};\\\", \\\"{x:1307,y:643,t:1528143799151};\\\", \\\"{x:1255,y:624,t:1528143799168};\\\", \\\"{x:1185,y:601,t:1528143799184};\\\", \\\"{x:1086,y:577,t:1528143799201};\\\", \\\"{x:932,y:539,t:1528143799220};\\\", \\\"{x:825,y:519,t:1528143799234};\\\", \\\"{x:764,y:509,t:1528143799250};\\\", \\\"{x:736,y:502,t:1528143799270};\\\", \\\"{x:720,y:498,t:1528143799287};\\\", \\\"{x:715,y:496,t:1528143799303};\\\", \\\"{x:714,y:496,t:1528143799319};\\\", \\\"{x:712,y:496,t:1528143799394};\\\", \\\"{x:708,y:496,t:1528143799404};\\\", \\\"{x:698,y:501,t:1528143799420};\\\", \\\"{x:686,y:508,t:1528143799437};\\\", \\\"{x:672,y:517,t:1528143799454};\\\", \\\"{x:654,y:525,t:1528143799470};\\\", \\\"{x:641,y:530,t:1528143799487};\\\", \\\"{x:623,y:536,t:1528143799503};\\\", \\\"{x:607,y:539,t:1528143799520};\\\", \\\"{x:593,y:539,t:1528143799537};\\\", \\\"{x:586,y:539,t:1528143799553};\\\", \\\"{x:579,y:539,t:1528143799570};\\\", \\\"{x:571,y:537,t:1528143799587};\\\", \\\"{x:567,y:536,t:1528143799603};\\\", \\\"{x:566,y:536,t:1528143799620};\\\", \\\"{x:566,y:533,t:1528143799658};\\\", \\\"{x:569,y:531,t:1528143799671};\\\", \\\"{x:577,y:524,t:1528143799688};\\\", \\\"{x:581,y:523,t:1528143799703};\\\", \\\"{x:586,y:520,t:1528143799720};\\\", \\\"{x:592,y:518,t:1528143799737};\\\", \\\"{x:596,y:516,t:1528143799753};\\\", \\\"{x:601,y:514,t:1528143799770};\\\", \\\"{x:606,y:512,t:1528143799787};\\\", \\\"{x:608,y:511,t:1528143799804};\\\", \\\"{x:610,y:509,t:1528143799820};\\\", \\\"{x:612,y:508,t:1528143799837};\\\", \\\"{x:613,y:507,t:1528143799854};\\\", \\\"{x:619,y:505,t:1528143800233};\\\", \\\"{x:626,y:502,t:1528143800241};\\\", \\\"{x:632,y:501,t:1528143800254};\\\", \\\"{x:648,y:499,t:1528143800271};\\\", \\\"{x:665,y:496,t:1528143800287};\\\", \\\"{x:680,y:496,t:1528143800304};\\\", \\\"{x:698,y:496,t:1528143800321};\\\", \\\"{x:713,y:496,t:1528143800337};\\\", \\\"{x:734,y:496,t:1528143800355};\\\", \\\"{x:751,y:497,t:1528143800372};\\\", \\\"{x:771,y:501,t:1528143800387};\\\", \\\"{x:784,y:503,t:1528143800404};\\\", \\\"{x:789,y:504,t:1528143800421};\\\", \\\"{x:791,y:504,t:1528143800437};\\\", \\\"{x:791,y:505,t:1528143800454};\\\", \\\"{x:792,y:505,t:1528143800471};\\\", \\\"{x:793,y:505,t:1528143800594};\\\", \\\"{x:797,y:505,t:1528143800605};\\\", \\\"{x:800,y:505,t:1528143800622};\\\", \\\"{x:806,y:505,t:1528143800638};\\\", \\\"{x:811,y:505,t:1528143800655};\\\", \\\"{x:812,y:505,t:1528143800672};\\\", \\\"{x:813,y:505,t:1528143800688};\\\", \\\"{x:814,y:505,t:1528143800705};\\\", \\\"{x:817,y:504,t:1528143800771};\\\", \\\"{x:818,y:504,t:1528143800778};\\\", \\\"{x:819,y:503,t:1528143800788};\\\", \\\"{x:823,y:502,t:1528143800805};\\\", \\\"{x:825,y:502,t:1528143800821};\\\", \\\"{x:826,y:502,t:1528143800915};\\\", \\\"{x:828,y:502,t:1528143800922};\\\", \\\"{x:829,y:502,t:1528143800938};\\\", \\\"{x:821,y:502,t:1528143801281};\\\", \\\"{x:811,y:509,t:1528143801289};\\\", \\\"{x:784,y:526,t:1528143801305};\\\", \\\"{x:759,y:544,t:1528143801321};\\\", \\\"{x:734,y:564,t:1528143801338};\\\", \\\"{x:714,y:579,t:1528143801356};\\\", \\\"{x:698,y:591,t:1528143801372};\\\", \\\"{x:683,y:600,t:1528143801389};\\\", \\\"{x:666,y:612,t:1528143801406};\\\", \\\"{x:649,y:622,t:1528143801422};\\\", \\\"{x:641,y:628,t:1528143801438};\\\", \\\"{x:628,y:634,t:1528143801456};\\\", \\\"{x:620,y:639,t:1528143801472};\\\", \\\"{x:607,y:644,t:1528143801488};\\\", \\\"{x:590,y:652,t:1528143801505};\\\", \\\"{x:584,y:653,t:1528143801521};\\\", \\\"{x:583,y:654,t:1528143801539};\\\", \\\"{x:582,y:654,t:1528143801555};\\\", \\\"{x:581,y:655,t:1528143801586};\\\", \\\"{x:581,y:656,t:1528143801594};\\\", \\\"{x:579,y:661,t:1528143801606};\\\", \\\"{x:575,y:669,t:1528143801622};\\\", \\\"{x:569,y:677,t:1528143801639};\\\", \\\"{x:563,y:686,t:1528143801656};\\\", \\\"{x:559,y:690,t:1528143801672};\\\", \\\"{x:555,y:694,t:1528143801688};\\\", \\\"{x:552,y:697,t:1528143801705};\\\", \\\"{x:551,y:698,t:1528143801722};\\\", \\\"{x:549,y:699,t:1528143801738};\\\", \\\"{x:547,y:701,t:1528143801755};\\\", \\\"{x:544,y:704,t:1528143801772};\\\", \\\"{x:539,y:710,t:1528143801788};\\\", \\\"{x:532,y:718,t:1528143801805};\\\", \\\"{x:528,y:726,t:1528143801823};\\\", \\\"{x:523,y:737,t:1528143801838};\\\", \\\"{x:518,y:747,t:1528143801855};\\\", \\\"{x:517,y:751,t:1528143801873};\\\", \\\"{x:516,y:753,t:1528143801888};\\\", \\\"{x:516,y:751,t:1528143802305};\\\", \\\"{x:516,y:750,t:1528143802322};\\\", \\\"{x:516,y:747,t:1528143802339};\\\", \\\"{x:516,y:746,t:1528143802355};\\\", \\\"{x:516,y:745,t:1528143802410};\\\", \\\"{x:516,y:744,t:1528143802586};\\\", \\\"{x:516,y:743,t:1528143802602};\\\", \\\"{x:516,y:742,t:1528143802618};\\\", \\\"{x:516,y:741,t:1528143802626};\\\", \\\"{x:516,y:740,t:1528143802690};\\\", \\\"{x:516,y:738,t:1528143802930};\\\", \\\"{x:515,y:736,t:1528143802946};\\\", \\\"{x:515,y:734,t:1528143802956};\\\", \\\"{x:514,y:732,t:1528143802974};\\\", \\\"{x:513,y:729,t:1528143802990};\\\", \\\"{x:512,y:727,t:1528143803007};\\\", \\\"{x:511,y:726,t:1528143803023};\\\", \\\"{x:511,y:724,t:1528143803039};\\\", \\\"{x:510,y:724,t:1528143803056};\\\", \\\"{x:510,y:722,t:1528143803114};\\\", \\\"{x:509,y:721,t:1528143803133};\\\", \\\"{x:509,y:720,t:1528143803156};\\\", \\\"{x:508,y:719,t:1528143803173};\\\" ] }, { \\\"rt\\\": 6351, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 650656, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:718,t:1528143803413};\\\", \\\"{x:506,y:717,t:1528143803634};\\\", \\\"{x:506,y:716,t:1528143804682};\\\", \\\"{x:508,y:713,t:1528143804692};\\\", \\\"{x:513,y:709,t:1528143804708};\\\", \\\"{x:518,y:707,t:1528143804725};\\\", \\\"{x:523,y:704,t:1528143804742};\\\", \\\"{x:529,y:700,t:1528143804758};\\\", \\\"{x:538,y:697,t:1528143804775};\\\", \\\"{x:553,y:690,t:1528143804791};\\\", \\\"{x:570,y:686,t:1528143804809};\\\", \\\"{x:589,y:682,t:1528143804825};\\\", \\\"{x:621,y:676,t:1528143804842};\\\", \\\"{x:646,y:671,t:1528143804858};\\\", \\\"{x:679,y:666,t:1528143804875};\\\", \\\"{x:716,y:661,t:1528143804891};\\\", \\\"{x:784,y:658,t:1528143804909};\\\", \\\"{x:844,y:652,t:1528143804924};\\\", \\\"{x:884,y:652,t:1528143804941};\\\", \\\"{x:942,y:652,t:1528143804958};\\\", \\\"{x:995,y:652,t:1528143804975};\\\", \\\"{x:1057,y:652,t:1528143804992};\\\", \\\"{x:1108,y:654,t:1528143805008};\\\", \\\"{x:1153,y:662,t:1528143805025};\\\", \\\"{x:1188,y:666,t:1528143805042};\\\", \\\"{x:1203,y:668,t:1528143805058};\\\", \\\"{x:1211,y:670,t:1528143805075};\\\", \\\"{x:1218,y:671,t:1528143805092};\\\", \\\"{x:1219,y:671,t:1528143805109};\\\", \\\"{x:1221,y:671,t:1528143805125};\\\", \\\"{x:1222,y:671,t:1528143805611};\\\", \\\"{x:1221,y:674,t:1528143805625};\\\", \\\"{x:1208,y:686,t:1528143805642};\\\", \\\"{x:1199,y:693,t:1528143805658};\\\", \\\"{x:1194,y:698,t:1528143805676};\\\", \\\"{x:1189,y:703,t:1528143805692};\\\", \\\"{x:1183,y:707,t:1528143805709};\\\", \\\"{x:1179,y:710,t:1528143805726};\\\", \\\"{x:1178,y:711,t:1528143805741};\\\", \\\"{x:1177,y:712,t:1528143805759};\\\", \\\"{x:1175,y:713,t:1528143805776};\\\", \\\"{x:1174,y:715,t:1528143805792};\\\", \\\"{x:1172,y:717,t:1528143805808};\\\", \\\"{x:1167,y:723,t:1528143805826};\\\", \\\"{x:1164,y:725,t:1528143805842};\\\", \\\"{x:1160,y:728,t:1528143805859};\\\", \\\"{x:1156,y:732,t:1528143805876};\\\", \\\"{x:1152,y:735,t:1528143805891};\\\", \\\"{x:1144,y:739,t:1528143805909};\\\", \\\"{x:1135,y:743,t:1528143805926};\\\", \\\"{x:1125,y:747,t:1528143805942};\\\", \\\"{x:1120,y:750,t:1528143805959};\\\", \\\"{x:1114,y:752,t:1528143805976};\\\", \\\"{x:1112,y:753,t:1528143805992};\\\", \\\"{x:1111,y:754,t:1528143806186};\\\", \\\"{x:1111,y:755,t:1528143806193};\\\", \\\"{x:1112,y:755,t:1528143806209};\\\", \\\"{x:1114,y:756,t:1528143806226};\\\", \\\"{x:1117,y:756,t:1528143806243};\\\", \\\"{x:1120,y:756,t:1528143806259};\\\", \\\"{x:1123,y:756,t:1528143806276};\\\", \\\"{x:1125,y:756,t:1528143806293};\\\", \\\"{x:1126,y:756,t:1528143806314};\\\", \\\"{x:1127,y:756,t:1528143806326};\\\", \\\"{x:1128,y:756,t:1528143806343};\\\", \\\"{x:1129,y:756,t:1528143806360};\\\", \\\"{x:1130,y:756,t:1528143806376};\\\", \\\"{x:1131,y:756,t:1528143806393};\\\", \\\"{x:1133,y:756,t:1528143806409};\\\", \\\"{x:1134,y:756,t:1528143806450};\\\", \\\"{x:1135,y:756,t:1528143806474};\\\", \\\"{x:1137,y:756,t:1528143806498};\\\", \\\"{x:1137,y:755,t:1528143806530};\\\", \\\"{x:1139,y:754,t:1528143806554};\\\", \\\"{x:1140,y:754,t:1528143806570};\\\", \\\"{x:1142,y:754,t:1528143806578};\\\", \\\"{x:1144,y:754,t:1528143806594};\\\", \\\"{x:1146,y:754,t:1528143806610};\\\", \\\"{x:1148,y:752,t:1528143806634};\\\", \\\"{x:1149,y:752,t:1528143806643};\\\", \\\"{x:1155,y:752,t:1528143806660};\\\", \\\"{x:1164,y:752,t:1528143806676};\\\", \\\"{x:1179,y:752,t:1528143806693};\\\", \\\"{x:1193,y:752,t:1528143806711};\\\", \\\"{x:1208,y:752,t:1528143806726};\\\", \\\"{x:1227,y:752,t:1528143806743};\\\", \\\"{x:1248,y:753,t:1528143806760};\\\", \\\"{x:1267,y:755,t:1528143806776};\\\", \\\"{x:1288,y:758,t:1528143806793};\\\", \\\"{x:1330,y:772,t:1528143806810};\\\", \\\"{x:1355,y:779,t:1528143806826};\\\", \\\"{x:1381,y:787,t:1528143806843};\\\", \\\"{x:1409,y:795,t:1528143806860};\\\", \\\"{x:1443,y:809,t:1528143806876};\\\", \\\"{x:1468,y:821,t:1528143806893};\\\", \\\"{x:1496,y:836,t:1528143806910};\\\", \\\"{x:1521,y:850,t:1528143806926};\\\", \\\"{x:1544,y:861,t:1528143806943};\\\", \\\"{x:1564,y:873,t:1528143806959};\\\", \\\"{x:1573,y:878,t:1528143806975};\\\", \\\"{x:1575,y:880,t:1528143806993};\\\", \\\"{x:1575,y:882,t:1528143807009};\\\", \\\"{x:1577,y:884,t:1528143807027};\\\", \\\"{x:1579,y:888,t:1528143807043};\\\", \\\"{x:1580,y:890,t:1528143807060};\\\", \\\"{x:1581,y:891,t:1528143807076};\\\", \\\"{x:1581,y:893,t:1528143807093};\\\", \\\"{x:1581,y:895,t:1528143807110};\\\", \\\"{x:1581,y:900,t:1528143807126};\\\", \\\"{x:1581,y:904,t:1528143807143};\\\", \\\"{x:1582,y:911,t:1528143807160};\\\", \\\"{x:1582,y:920,t:1528143807177};\\\", \\\"{x:1578,y:929,t:1528143807193};\\\", \\\"{x:1572,y:936,t:1528143807210};\\\", \\\"{x:1570,y:939,t:1528143807227};\\\", \\\"{x:1568,y:939,t:1528143807243};\\\", \\\"{x:1567,y:939,t:1528143807274};\\\", \\\"{x:1564,y:940,t:1528143807282};\\\", \\\"{x:1563,y:941,t:1528143807294};\\\", \\\"{x:1559,y:942,t:1528143807310};\\\", \\\"{x:1555,y:944,t:1528143807327};\\\", \\\"{x:1550,y:946,t:1528143807343};\\\", \\\"{x:1545,y:949,t:1528143807361};\\\", \\\"{x:1540,y:952,t:1528143807377};\\\", \\\"{x:1538,y:954,t:1528143807393};\\\", \\\"{x:1537,y:954,t:1528143808019};\\\", \\\"{x:1537,y:953,t:1528143808058};\\\", \\\"{x:1536,y:951,t:1528143808066};\\\", \\\"{x:1531,y:944,t:1528143808077};\\\", \\\"{x:1517,y:934,t:1528143808094};\\\", \\\"{x:1492,y:918,t:1528143808111};\\\", \\\"{x:1451,y:894,t:1528143808128};\\\", \\\"{x:1376,y:862,t:1528143808143};\\\", \\\"{x:1291,y:825,t:1528143808161};\\\", \\\"{x:1203,y:788,t:1528143808176};\\\", \\\"{x:1066,y:727,t:1528143808193};\\\", \\\"{x:966,y:682,t:1528143808210};\\\", \\\"{x:874,y:636,t:1528143808226};\\\", \\\"{x:804,y:599,t:1528143808243};\\\", \\\"{x:749,y:563,t:1528143808261};\\\", \\\"{x:700,y:537,t:1528143808277};\\\", \\\"{x:677,y:523,t:1528143808294};\\\", \\\"{x:670,y:519,t:1528143808310};\\\", \\\"{x:670,y:518,t:1528143808327};\\\", \\\"{x:668,y:518,t:1528143808433};\\\", \\\"{x:666,y:518,t:1528143808445};\\\", \\\"{x:662,y:528,t:1528143808461};\\\", \\\"{x:658,y:539,t:1528143808477};\\\", \\\"{x:650,y:553,t:1528143808494};\\\", \\\"{x:641,y:565,t:1528143808512};\\\", \\\"{x:632,y:575,t:1528143808528};\\\", \\\"{x:622,y:584,t:1528143808544};\\\", \\\"{x:614,y:589,t:1528143808560};\\\", \\\"{x:603,y:594,t:1528143808577};\\\", \\\"{x:600,y:596,t:1528143808595};\\\", \\\"{x:597,y:596,t:1528143808610};\\\", \\\"{x:596,y:596,t:1528143808628};\\\", \\\"{x:596,y:597,t:1528143808645};\\\", \\\"{x:595,y:597,t:1528143808690};\\\", \\\"{x:594,y:597,t:1528143808697};\\\", \\\"{x:593,y:597,t:1528143808730};\\\", \\\"{x:593,y:596,t:1528143808746};\\\", \\\"{x:593,y:595,t:1528143808761};\\\", \\\"{x:593,y:589,t:1528143808778};\\\", \\\"{x:594,y:588,t:1528143808794};\\\", \\\"{x:594,y:587,t:1528143808812};\\\", \\\"{x:595,y:586,t:1528143808842};\\\", \\\"{x:596,y:585,t:1528143808849};\\\", \\\"{x:597,y:585,t:1528143808913};\\\", \\\"{x:599,y:585,t:1528143808927};\\\", \\\"{x:601,y:583,t:1528143808945};\\\", \\\"{x:604,y:581,t:1528143808961};\\\", \\\"{x:606,y:580,t:1528143808977};\\\", \\\"{x:607,y:579,t:1528143808994};\\\", \\\"{x:608,y:579,t:1528143809011};\\\", \\\"{x:611,y:581,t:1528143809201};\\\", \\\"{x:610,y:590,t:1528143809211};\\\", \\\"{x:597,y:611,t:1528143809229};\\\", \\\"{x:589,y:634,t:1528143809245};\\\", \\\"{x:581,y:650,t:1528143809261};\\\", \\\"{x:577,y:660,t:1528143809279};\\\", \\\"{x:573,y:671,t:1528143809294};\\\", \\\"{x:571,y:677,t:1528143809311};\\\", \\\"{x:571,y:681,t:1528143809329};\\\", \\\"{x:569,y:683,t:1528143809345};\\\", \\\"{x:569,y:684,t:1528143809418};\\\", \\\"{x:567,y:685,t:1528143809429};\\\", \\\"{x:557,y:693,t:1528143809445};\\\", \\\"{x:543,y:703,t:1528143809462};\\\", \\\"{x:530,y:711,t:1528143809479};\\\", \\\"{x:521,y:716,t:1528143809494};\\\", \\\"{x:517,y:718,t:1528143809512};\\\", \\\"{x:516,y:718,t:1528143809529};\\\", \\\"{x:515,y:719,t:1528143809553};\\\", \\\"{x:514,y:721,t:1528143809563};\\\", \\\"{x:509,y:727,t:1528143809578};\\\", \\\"{x:504,y:734,t:1528143809594};\\\", \\\"{x:500,y:738,t:1528143809612};\\\", \\\"{x:499,y:740,t:1528143809627};\\\", \\\"{x:498,y:740,t:1528143809644};\\\", \\\"{x:507,y:727,t:1528143810185};\\\", \\\"{x:526,y:697,t:1528143810196};\\\", \\\"{x:579,y:617,t:1528143810213};\\\", \\\"{x:649,y:504,t:1528143810228};\\\", \\\"{x:696,y:425,t:1528143810245};\\\", \\\"{x:723,y:378,t:1528143810263};\\\", \\\"{x:746,y:342,t:1528143810279};\\\", \\\"{x:763,y:318,t:1528143810295};\\\", \\\"{x:778,y:298,t:1528143810312};\\\", \\\"{x:790,y:284,t:1528143810329};\\\", \\\"{x:796,y:276,t:1528143810345};\\\", \\\"{x:796,y:275,t:1528143810363};\\\", \\\"{x:796,y:274,t:1528143810379};\\\" ] }, { \\\"rt\\\": 16034, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 667986, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:799,y:273,t:1528143817834};\\\", \\\"{x:807,y:277,t:1528143817853};\\\", \\\"{x:822,y:285,t:1528143817869};\\\", \\\"{x:843,y:296,t:1528143817886};\\\", \\\"{x:879,y:317,t:1528143817902};\\\", \\\"{x:914,y:337,t:1528143817919};\\\", \\\"{x:952,y:357,t:1528143817936};\\\", \\\"{x:977,y:372,t:1528143817952};\\\", \\\"{x:998,y:388,t:1528143817968};\\\", \\\"{x:1019,y:402,t:1528143817985};\\\", \\\"{x:1029,y:410,t:1528143818002};\\\", \\\"{x:1037,y:421,t:1528143818018};\\\", \\\"{x:1048,y:437,t:1528143818035};\\\", \\\"{x:1058,y:460,t:1528143818052};\\\", \\\"{x:1071,y:486,t:1528143818069};\\\", \\\"{x:1090,y:528,t:1528143818085};\\\", \\\"{x:1118,y:576,t:1528143818102};\\\", \\\"{x:1164,y:643,t:1528143818119};\\\", \\\"{x:1204,y:711,t:1528143818135};\\\", \\\"{x:1223,y:751,t:1528143818152};\\\", \\\"{x:1238,y:789,t:1528143818170};\\\", \\\"{x:1245,y:808,t:1528143818185};\\\", \\\"{x:1248,y:819,t:1528143818202};\\\", \\\"{x:1249,y:823,t:1528143818219};\\\", \\\"{x:1249,y:824,t:1528143818236};\\\", \\\"{x:1249,y:825,t:1528143818253};\\\", \\\"{x:1249,y:826,t:1528143818289};\\\", \\\"{x:1249,y:828,t:1528143818314};\\\", \\\"{x:1249,y:829,t:1528143818322};\\\", \\\"{x:1249,y:832,t:1528143818336};\\\", \\\"{x:1249,y:837,t:1528143818353};\\\", \\\"{x:1249,y:844,t:1528143818370};\\\", \\\"{x:1249,y:846,t:1528143818387};\\\", \\\"{x:1249,y:847,t:1528143818419};\\\", \\\"{x:1249,y:849,t:1528143818434};\\\", \\\"{x:1249,y:851,t:1528143818442};\\\", \\\"{x:1249,y:853,t:1528143818452};\\\", \\\"{x:1250,y:858,t:1528143818470};\\\", \\\"{x:1251,y:861,t:1528143818485};\\\", \\\"{x:1254,y:865,t:1528143818503};\\\", \\\"{x:1258,y:869,t:1528143818520};\\\", \\\"{x:1271,y:879,t:1528143818536};\\\", \\\"{x:1283,y:886,t:1528143818552};\\\", \\\"{x:1310,y:897,t:1528143818569};\\\", \\\"{x:1329,y:901,t:1528143818587};\\\", \\\"{x:1349,y:904,t:1528143818603};\\\", \\\"{x:1363,y:904,t:1528143818620};\\\", \\\"{x:1379,y:904,t:1528143818636};\\\", \\\"{x:1387,y:904,t:1528143818653};\\\", \\\"{x:1391,y:904,t:1528143818670};\\\", \\\"{x:1393,y:904,t:1528143818687};\\\", \\\"{x:1394,y:904,t:1528143818738};\\\", \\\"{x:1396,y:904,t:1528143818753};\\\", \\\"{x:1401,y:904,t:1528143818770};\\\", \\\"{x:1410,y:904,t:1528143818787};\\\", \\\"{x:1414,y:904,t:1528143818803};\\\", \\\"{x:1415,y:904,t:1528143818820};\\\", \\\"{x:1417,y:905,t:1528143818836};\\\", \\\"{x:1421,y:906,t:1528143818852};\\\", \\\"{x:1425,y:909,t:1528143818869};\\\", \\\"{x:1430,y:912,t:1528143818886};\\\", \\\"{x:1434,y:913,t:1528143818903};\\\", \\\"{x:1434,y:914,t:1528143818919};\\\", \\\"{x:1438,y:916,t:1528143818936};\\\", \\\"{x:1445,y:919,t:1528143818953};\\\", \\\"{x:1449,y:921,t:1528143818969};\\\", \\\"{x:1454,y:923,t:1528143818986};\\\", \\\"{x:1459,y:925,t:1528143819003};\\\", \\\"{x:1464,y:927,t:1528143819019};\\\", \\\"{x:1473,y:930,t:1528143819036};\\\", \\\"{x:1478,y:931,t:1528143819054};\\\", \\\"{x:1479,y:931,t:1528143819069};\\\", \\\"{x:1479,y:932,t:1528143819087};\\\", \\\"{x:1480,y:932,t:1528143819103};\\\", \\\"{x:1481,y:932,t:1528143819120};\\\", \\\"{x:1483,y:933,t:1528143819146};\\\", \\\"{x:1483,y:934,t:1528143819154};\\\", \\\"{x:1483,y:935,t:1528143819170};\\\", \\\"{x:1483,y:937,t:1528143819189};\\\", \\\"{x:1483,y:940,t:1528143819204};\\\", \\\"{x:1484,y:942,t:1528143819219};\\\", \\\"{x:1485,y:946,t:1528143819237};\\\", \\\"{x:1486,y:951,t:1528143819254};\\\", \\\"{x:1487,y:955,t:1528143819270};\\\", \\\"{x:1488,y:959,t:1528143819286};\\\", \\\"{x:1488,y:960,t:1528143819304};\\\", \\\"{x:1488,y:962,t:1528143819323};\\\", \\\"{x:1486,y:959,t:1528143819462};\\\", \\\"{x:1486,y:956,t:1528143819474};\\\", \\\"{x:1486,y:952,t:1528143819490};\\\", \\\"{x:1486,y:948,t:1528143819507};\\\", \\\"{x:1486,y:943,t:1528143819524};\\\", \\\"{x:1486,y:938,t:1528143819539};\\\", \\\"{x:1486,y:935,t:1528143819556};\\\", \\\"{x:1485,y:933,t:1528143819573};\\\", \\\"{x:1485,y:931,t:1528143819590};\\\", \\\"{x:1485,y:930,t:1528143819607};\\\", \\\"{x:1485,y:927,t:1528143819624};\\\", \\\"{x:1485,y:923,t:1528143819640};\\\", \\\"{x:1485,y:920,t:1528143819656};\\\", \\\"{x:1485,y:916,t:1528143819674};\\\", \\\"{x:1485,y:913,t:1528143819690};\\\", \\\"{x:1485,y:910,t:1528143819707};\\\", \\\"{x:1484,y:907,t:1528143819724};\\\", \\\"{x:1484,y:905,t:1528143819741};\\\", \\\"{x:1483,y:903,t:1528143819757};\\\", \\\"{x:1482,y:900,t:1528143819773};\\\", \\\"{x:1481,y:896,t:1528143819791};\\\", \\\"{x:1481,y:894,t:1528143819813};\\\", \\\"{x:1481,y:893,t:1528143819823};\\\", \\\"{x:1481,y:892,t:1528143819845};\\\", \\\"{x:1481,y:890,t:1528143819856};\\\", \\\"{x:1481,y:888,t:1528143819874};\\\", \\\"{x:1481,y:887,t:1528143819890};\\\", \\\"{x:1480,y:885,t:1528143819906};\\\", \\\"{x:1480,y:884,t:1528143819924};\\\", \\\"{x:1479,y:882,t:1528143819940};\\\", \\\"{x:1479,y:881,t:1528143819965};\\\", \\\"{x:1479,y:880,t:1528143819997};\\\", \\\"{x:1479,y:878,t:1528143820134};\\\", \\\"{x:1479,y:876,t:1528143820141};\\\", \\\"{x:1479,y:874,t:1528143820157};\\\", \\\"{x:1479,y:870,t:1528143820174};\\\", \\\"{x:1479,y:868,t:1528143820190};\\\", \\\"{x:1479,y:866,t:1528143820207};\\\", \\\"{x:1479,y:865,t:1528143820224};\\\", \\\"{x:1479,y:863,t:1528143820357};\\\", \\\"{x:1478,y:858,t:1528143820374};\\\", \\\"{x:1478,y:855,t:1528143820391};\\\", \\\"{x:1477,y:851,t:1528143820407};\\\", \\\"{x:1476,y:848,t:1528143820424};\\\", \\\"{x:1476,y:846,t:1528143820441};\\\", \\\"{x:1475,y:844,t:1528143820458};\\\", \\\"{x:1475,y:842,t:1528143820629};\\\", \\\"{x:1475,y:840,t:1528143820641};\\\", \\\"{x:1475,y:838,t:1528143820658};\\\", \\\"{x:1475,y:836,t:1528143820674};\\\", \\\"{x:1475,y:835,t:1528143820691};\\\", \\\"{x:1475,y:834,t:1528143820793};\\\", \\\"{x:1475,y:832,t:1528143823005};\\\", \\\"{x:1475,y:831,t:1528143823012};\\\", \\\"{x:1475,y:830,t:1528143823029};\\\", \\\"{x:1475,y:828,t:1528143823165};\\\", \\\"{x:1475,y:827,t:1528143823176};\\\", \\\"{x:1474,y:824,t:1528143823193};\\\", \\\"{x:1474,y:821,t:1528143823210};\\\", \\\"{x:1474,y:820,t:1528143823226};\\\", \\\"{x:1474,y:819,t:1528143823261};\\\", \\\"{x:1472,y:817,t:1528143823446};\\\", \\\"{x:1465,y:813,t:1528143823460};\\\", \\\"{x:1432,y:806,t:1528143823477};\\\", \\\"{x:1401,y:796,t:1528143823493};\\\", \\\"{x:1361,y:781,t:1528143823509};\\\", \\\"{x:1314,y:769,t:1528143823527};\\\", \\\"{x:1266,y:754,t:1528143823543};\\\", \\\"{x:1222,y:737,t:1528143823560};\\\", \\\"{x:1186,y:726,t:1528143823577};\\\", \\\"{x:1159,y:718,t:1528143823593};\\\", \\\"{x:1139,y:710,t:1528143823610};\\\", \\\"{x:1120,y:705,t:1528143823627};\\\", \\\"{x:1105,y:700,t:1528143823643};\\\", \\\"{x:1087,y:693,t:1528143823660};\\\", \\\"{x:1058,y:683,t:1528143823677};\\\", \\\"{x:1041,y:679,t:1528143823693};\\\", \\\"{x:1029,y:676,t:1528143823710};\\\", \\\"{x:1016,y:672,t:1528143823727};\\\", \\\"{x:1000,y:668,t:1528143823744};\\\", \\\"{x:982,y:666,t:1528143823760};\\\", \\\"{x:967,y:663,t:1528143823777};\\\", \\\"{x:941,y:661,t:1528143823794};\\\", \\\"{x:917,y:656,t:1528143823809};\\\", \\\"{x:896,y:652,t:1528143823826};\\\", \\\"{x:878,y:650,t:1528143823843};\\\", \\\"{x:852,y:646,t:1528143823859};\\\", \\\"{x:818,y:641,t:1528143823876};\\\", \\\"{x:796,y:637,t:1528143823893};\\\", \\\"{x:776,y:634,t:1528143823909};\\\", \\\"{x:757,y:631,t:1528143823926};\\\", \\\"{x:736,y:628,t:1528143823943};\\\", \\\"{x:726,y:623,t:1528143823959};\\\", \\\"{x:714,y:620,t:1528143823976};\\\", \\\"{x:700,y:619,t:1528143823993};\\\", \\\"{x:687,y:618,t:1528143824010};\\\", \\\"{x:677,y:614,t:1528143824026};\\\", \\\"{x:671,y:614,t:1528143824043};\\\", \\\"{x:670,y:613,t:1528143824060};\\\", \\\"{x:667,y:611,t:1528143824076};\\\", \\\"{x:664,y:610,t:1528143824093};\\\", \\\"{x:661,y:608,t:1528143824110};\\\", \\\"{x:658,y:605,t:1528143824126};\\\", \\\"{x:653,y:602,t:1528143824143};\\\", \\\"{x:650,y:602,t:1528143824161};\\\", \\\"{x:649,y:600,t:1528143824176};\\\", \\\"{x:647,y:600,t:1528143824193};\\\", \\\"{x:645,y:599,t:1528143824210};\\\", \\\"{x:644,y:599,t:1528143824227};\\\", \\\"{x:642,y:598,t:1528143824243};\\\", \\\"{x:639,y:597,t:1528143824259};\\\", \\\"{x:638,y:597,t:1528143824276};\\\", \\\"{x:637,y:597,t:1528143824294};\\\", \\\"{x:636,y:596,t:1528143824316};\\\", \\\"{x:635,y:596,t:1528143824340};\\\", \\\"{x:632,y:594,t:1528143824347};\\\", \\\"{x:629,y:593,t:1528143824364};\\\", \\\"{x:627,y:592,t:1528143824376};\\\", \\\"{x:622,y:589,t:1528143824393};\\\", \\\"{x:620,y:589,t:1528143824410};\\\", \\\"{x:618,y:588,t:1528143824427};\\\", \\\"{x:614,y:588,t:1528143824732};\\\", \\\"{x:611,y:588,t:1528143824744};\\\", \\\"{x:607,y:588,t:1528143824760};\\\", \\\"{x:599,y:590,t:1528143824778};\\\", \\\"{x:590,y:592,t:1528143824795};\\\", \\\"{x:583,y:592,t:1528143824810};\\\", \\\"{x:577,y:592,t:1528143824828};\\\", \\\"{x:567,y:592,t:1528143824844};\\\", \\\"{x:557,y:592,t:1528143824860};\\\", \\\"{x:539,y:590,t:1528143824878};\\\", \\\"{x:528,y:590,t:1528143824895};\\\", \\\"{x:522,y:590,t:1528143824911};\\\", \\\"{x:513,y:590,t:1528143824928};\\\", \\\"{x:502,y:590,t:1528143824944};\\\", \\\"{x:487,y:590,t:1528143824962};\\\", \\\"{x:467,y:590,t:1528143824977};\\\", \\\"{x:445,y:588,t:1528143824994};\\\", \\\"{x:426,y:584,t:1528143825011};\\\", \\\"{x:407,y:582,t:1528143825028};\\\", \\\"{x:385,y:579,t:1528143825044};\\\", \\\"{x:379,y:578,t:1528143825061};\\\", \\\"{x:378,y:578,t:1528143825653};\\\", \\\"{x:379,y:582,t:1528143825661};\\\", \\\"{x:386,y:594,t:1528143825678};\\\", \\\"{x:395,y:610,t:1528143825694};\\\", \\\"{x:404,y:628,t:1528143825712};\\\", \\\"{x:411,y:641,t:1528143825728};\\\", \\\"{x:420,y:655,t:1528143825745};\\\", \\\"{x:425,y:666,t:1528143825761};\\\", \\\"{x:429,y:670,t:1528143825778};\\\", \\\"{x:433,y:671,t:1528143825794};\\\", \\\"{x:435,y:672,t:1528143825811};\\\", \\\"{x:436,y:672,t:1528143825828};\\\", \\\"{x:436,y:670,t:1528143825932};\\\", \\\"{x:436,y:664,t:1528143825946};\\\", \\\"{x:436,y:653,t:1528143825961};\\\", \\\"{x:436,y:641,t:1528143825979};\\\", \\\"{x:435,y:628,t:1528143825995};\\\", \\\"{x:429,y:614,t:1528143826012};\\\", \\\"{x:419,y:600,t:1528143826028};\\\", \\\"{x:416,y:596,t:1528143826046};\\\", \\\"{x:413,y:594,t:1528143826061};\\\", \\\"{x:409,y:593,t:1528143826078};\\\", \\\"{x:405,y:591,t:1528143826095};\\\", \\\"{x:404,y:591,t:1528143826116};\\\", \\\"{x:403,y:591,t:1528143826191};\\\", \\\"{x:402,y:590,t:1528143826220};\\\", \\\"{x:402,y:593,t:1528143826460};\\\", \\\"{x:402,y:598,t:1528143826468};\\\", \\\"{x:403,y:602,t:1528143826478};\\\", \\\"{x:404,y:609,t:1528143826496};\\\", \\\"{x:410,y:623,t:1528143826513};\\\", \\\"{x:415,y:639,t:1528143826528};\\\", \\\"{x:421,y:655,t:1528143826546};\\\", \\\"{x:428,y:669,t:1528143826562};\\\", \\\"{x:434,y:679,t:1528143826578};\\\", \\\"{x:440,y:687,t:1528143826596};\\\", \\\"{x:445,y:690,t:1528143826612};\\\", \\\"{x:451,y:692,t:1528143826628};\\\", \\\"{x:455,y:696,t:1528143826645};\\\", \\\"{x:459,y:699,t:1528143826662};\\\", \\\"{x:462,y:703,t:1528143826678};\\\", \\\"{x:464,y:706,t:1528143826695};\\\", \\\"{x:466,y:707,t:1528143826712};\\\", \\\"{x:466,y:708,t:1528143826728};\\\", \\\"{x:467,y:708,t:1528143826748};\\\", \\\"{x:467,y:709,t:1528143826763};\\\", \\\"{x:469,y:713,t:1528143826779};\\\", \\\"{x:473,y:720,t:1528143826795};\\\", \\\"{x:478,y:728,t:1528143826812};\\\", \\\"{x:482,y:736,t:1528143826828};\\\", \\\"{x:485,y:741,t:1528143826845};\\\", \\\"{x:485,y:742,t:1528143826867};\\\" ] }, { \\\"rt\\\": 53617, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 722907, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"By looking at the diagnol, M and L starts and by looking vertically F and B starts coffee breaks\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7233, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"China\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 731147, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 13793, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 745957, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 20667, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 767995, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"MUULG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"MUULG\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 167, dom: 961, initialDom: 1034",
  "javascriptErrors": []
}