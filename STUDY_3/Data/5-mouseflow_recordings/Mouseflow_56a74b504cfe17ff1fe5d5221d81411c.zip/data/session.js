var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "56a74b504cfe17ff1fe5d5221d81411c",
  "created": "2018-05-29T13:05:00.7470772-07:00",
  "lastActivity": "2018-05-29T13:06:04.7830772-07:00",
  "pageViews": [
    {
      "id": "052900488b7f61abf27cc676981eb912ee777785",
      "startTime": "2018-05-29T13:05:00.7470772-07:00",
      "endTime": "2018-05-29T13:06:04.7830772-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 64036,
      "engagementTime": 51385,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 64036,
  "engagementTime": 51385,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=EPDQP",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a0785f2f6d00c7902a25bc5cebce6a43",
  "gdpr": false
}