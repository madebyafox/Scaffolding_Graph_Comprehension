var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8ef8b30e7ad53ed613a3cd7be5203f2f",
  "created": "2018-05-29T10:02:06.8032306-07:00",
  "lastActivity": "2018-05-29T10:05:16.0391108-07:00",
  "pageViews": [
    {
      "id": "05290643bf4e53fa33957e3778cb3b4b1755cdaf",
      "startTime": "2018-05-29T10:02:06.8032306-07:00",
      "endTime": "2018-05-29T10:05:16.0391108-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 189321,
      "engagementTime": 148248,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 189321,
  "engagementTime": 148248,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9434035938191f82669d53d095df3eb5",
  "gdpr": false
}