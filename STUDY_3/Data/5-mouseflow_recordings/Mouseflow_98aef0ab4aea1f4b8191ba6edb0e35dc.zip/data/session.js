var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "98aef0ab4aea1f4b8191ba6edb0e35dc",
  "created": "2018-05-16T11:15:02.5172147-07:00",
  "lastActivity": "2018-05-16T11:16:58.1802147-07:00",
  "pageViews": [
    {
      "id": "05160358c1a9bb6e3eed7e6f4cc60c841d91a6a7",
      "startTime": "2018-05-16T11:15:02.5172147-07:00",
      "endTime": "2018-05-16T11:16:58.1802147-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 115663,
      "engagementTime": 104107,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 115663,
  "engagementTime": 104107,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=BKTUJ",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "902ffb70f0a3e659c1b7a9829c1a3d27",
  "gdpr": false
}