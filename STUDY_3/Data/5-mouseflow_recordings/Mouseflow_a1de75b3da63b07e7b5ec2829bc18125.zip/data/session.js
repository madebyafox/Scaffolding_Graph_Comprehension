var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a1de75b3da63b07e7b5ec2829bc18125",
  "created": "2018-05-22T13:05:15.0456457-07:00",
  "lastActivity": "2018-05-22T13:06:06.1866457-07:00",
  "pageViews": [
    {
      "id": "052215165f4f557de61d0e3b2313382b2590f2b6",
      "startTime": "2018-05-22T13:05:15.0456457-07:00",
      "endTime": "2018-05-22T13:06:06.1866457-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 51141,
      "engagementTime": 32145,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 51141,
  "engagementTime": 32145,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=VT5BG",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a36cd1056290029e17a123bd88648584",
  "gdpr": false
}