var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05294466a061400294936a51ee934273ee86dea7"] = {
  "startTime": "2018-05-29T21:15:43.5217623Z",
  "websitePageUrl": "/16",
  "visitTime": 155363,
  "engagementTime": 117855,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "2c99f7636987e963975dd5de6463aeab",
    "created": "2018-05-29T21:15:43.5217623+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=NN1Z0",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "8e6fec6761a10fc04af4ba510a64c3dd",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/2c99f7636987e963975dd5de6463aeab/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 244,
      "e": 244,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 2901,
      "e": 2901,
      "ty": 2,
      "x": 541,
      "y": 706
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 2,
      "x": 541,
      "y": 705
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 49899,
      "y": 42412,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3300,
      "e": 3300,
      "ty": 2,
      "x": 542,
      "y": 705
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 544,
      "y": 705
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 41,
      "x": 50236,
      "y": 42412,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 571,
      "y": 669
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 611,
      "y": 635
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 61927,
      "y": 37179,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 710,
      "y": 609
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 868,
      "y": 664
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 1021,
      "y": 849
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 16561,
      "y": 54719,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 1087,
      "y": 907
    },
    {
      "t": 4200,
      "e": 4200,
      "ty": 2,
      "x": 1105,
      "y": 919
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 23255,
      "y": 59733,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4301,
      "e": 4301,
      "ty": 2,
      "x": 1134,
      "y": 914
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 1145,
      "y": 909
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 41,
      "x": 25299,
      "y": 59017,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 25369,
      "y": 59017,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 1148,
      "y": 909
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 25510,
      "y": 59017,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 1159,
      "y": 905
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 26285,
      "y": 58730,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1162,
      "y": 903
    },
    {
      "t": 5752,
      "e": 5752,
      "ty": 41,
      "x": 26496,
      "y": 58587,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6900,
      "e": 6900,
      "ty": 2,
      "x": 1158,
      "y": 904
    },
    {
      "t": 7000,
      "e": 7000,
      "ty": 2,
      "x": 1153,
      "y": 908
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 41,
      "x": 25862,
      "y": 58945,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7200,
      "e": 7200,
      "ty": 2,
      "x": 1153,
      "y": 909
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 57,
      "y": 65453,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[9]"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 23404,
      "e": 12251,
      "ty": 2,
      "x": 1078,
      "y": 770
    },
    {
      "t": 23504,
      "e": 12351,
      "ty": 2,
      "x": 780,
      "y": 462
    },
    {
      "t": 23504,
      "e": 12351,
      "ty": 41,
      "x": 5734,
      "y": 26767,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 23604,
      "e": 12451,
      "ty": 2,
      "x": 722,
      "y": 422
    },
    {
      "t": 23690,
      "e": 12537,
      "ty": 6,
      "x": 665,
      "y": 477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23704,
      "e": 12551,
      "ty": 2,
      "x": 665,
      "y": 477
    },
    {
      "t": 23754,
      "e": 12601,
      "ty": 41,
      "x": 63613,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23804,
      "e": 12651,
      "ty": 2,
      "x": 663,
      "y": 484
    },
    {
      "t": 23904,
      "e": 12751,
      "ty": 2,
      "x": 651,
      "y": 490
    },
    {
      "t": 23980,
      "e": 12827,
      "ty": 3,
      "x": 641,
      "y": 495,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23982,
      "e": 12829,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24004,
      "e": 12851,
      "ty": 2,
      "x": 641,
      "y": 495
    },
    {
      "t": 24005,
      "e": 12852,
      "ty": 41,
      "x": 61140,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24067,
      "e": 12914,
      "ty": 4,
      "x": 60803,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24067,
      "e": 12914,
      "ty": 5,
      "x": 638,
      "y": 495,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24104,
      "e": 12951,
      "ty": 2,
      "x": 635,
      "y": 495
    },
    {
      "t": 24204,
      "e": 13051,
      "ty": 2,
      "x": 650,
      "y": 501
    },
    {
      "t": 24242,
      "e": 13089,
      "ty": 7,
      "x": 689,
      "y": 511,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24254,
      "e": 13101,
      "ty": 41,
      "x": 511,
      "y": 30246,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 24304,
      "e": 13151,
      "ty": 2,
      "x": 699,
      "y": 513
    },
    {
      "t": 24505,
      "e": 13352,
      "ty": 41,
      "x": 1085,
      "y": 30388,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 29735,
      "e": 18352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 29822,
      "e": 18439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 29823,
      "e": 18440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29862,
      "e": 18479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 29911,
      "e": 18528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 29999,
      "e": 18616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29999,
      "e": 18616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30005,
      "e": 18622,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30038,
      "e": 18655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 30319,
      "e": 18936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 30320,
      "e": 18937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30414,
      "e": 19031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Loo"
    },
    {
      "t": 30543,
      "e": 19160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 30544,
      "e": 19161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30614,
      "e": 19231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 30678,
      "e": 19295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30678,
      "e": 19295,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30766,
      "e": 19383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30767,
      "e": 19384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30774,
      "e": 19391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 30838,
      "e": 19455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30852,
      "e": 19469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30854,
      "e": 19471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30894,
      "e": 19511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30894,
      "e": 19511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30902,
      "e": 19519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30950,
      "e": 19567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30991,
      "e": 19608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30991,
      "e": 19608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31038,
      "e": 19655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 31038,
      "e": 19655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 31038,
      "e": 19655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31119,
      "e": 19736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 31135,
      "e": 19752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31135,
      "e": 19752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31215,
      "e": 19832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 31222,
      "e": 19839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31223,
      "e": 19840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31310,
      "e": 19927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32463,
      "e": 21080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 32464,
      "e": 21081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32551,
      "e": 21168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 32607,
      "e": 21224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32607,
      "e": 21224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32695,
      "e": 21312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32695,
      "e": 21312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32719,
      "e": 21336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ia"
    },
    {
      "t": 32791,
      "e": 21408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32863,
      "e": 21480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 32864,
      "e": 21481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32951,
      "e": 21568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 33079,
      "e": 21696,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 33080,
      "e": 21697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33118,
      "e": 21735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33119,
      "e": 21736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33158,
      "e": 21775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 33222,
      "e": 21839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36783,
      "e": 25400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36785,
      "e": 25402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36854,
      "e": 25471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 36854,
      "e": 25471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36903,
      "e": 25520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 36950,
      "e": 25567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37591,
      "e": 26208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37592,
      "e": 26209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37678,
      "e": 26295,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37808,
      "e": 26425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 37808,
      "e": 26425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37894,
      "e": 26511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 37895,
      "e": 26512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37926,
      "e": 26543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 37950,
      "e": 26567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37950,
      "e": 26567,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37998,
      "e": 26615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 38063,
      "e": 26680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38103,
      "e": 26720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38103,
      "e": 26720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38174,
      "e": 26791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 38735,
      "e": 27352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38736,
      "e": 27353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38830,
      "e": 27447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38894,
      "e": 27511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 38895,
      "e": 27512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39008,
      "e": 27625,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line s"
    },
    {
      "t": 39008,
      "e": 27625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 39009,
      "e": 27626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39010,
      "e": 27627,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39078,
      "e": 27695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39166,
      "e": 27783,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 39166,
      "e": 27783,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39222,
      "e": 27839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 39222,
      "e": 27839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39270,
      "e": 27887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 39318,
      "e": 27935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39414,
      "e": 28031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39415,
      "e": 28032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39486,
      "e": 28103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 39607,
      "e": 28224,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line start"
    },
    {
      "t": 40005,
      "e": 28622,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40022,
      "e": 28639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40022,
      "e": 28639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40078,
      "e": 28695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 40079,
      "e": 28696,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40110,
      "e": 28727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 40190,
      "e": 28807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40223,
      "e": 28840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 40223,
      "e": 28840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40302,
      "e": 28919,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 40311,
      "e": 28928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40311,
      "e": 28928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40407,
      "e": 29024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40454,
      "e": 29071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 40455,
      "e": 29072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40559,
      "e": 29176,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40559,
      "e": 29176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40582,
      "e": 29199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 40654,
      "e": 29271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40686,
      "e": 29303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40687,
      "e": 29304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40782,
      "e": 29399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 41855,
      "e": 30472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 41856,
      "e": 30473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41934,
      "e": 30551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 41935,
      "e": 30552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41982,
      "e": 30599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "51"
    },
    {
      "t": 41982,
      "e": 30599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41990,
      "e": 30607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||123"
    },
    {
      "t": 42014,
      "e": 30631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42070,
      "e": 30687,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42575,
      "e": 31192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42638,
      "e": 31255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12"
    },
    {
      "t": 43231,
      "e": 31848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 43231,
      "e": 31848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43334,
      "e": 31951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 43342,
      "e": 31959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 43342,
      "e": 31959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43422,
      "e": 32039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 43543,
      "e": 32160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43544,
      "e": 32161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43630,
      "e": 32247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43758,
      "e": 32375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43759,
      "e": 32376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43830,
      "e": 32447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 43838,
      "e": 32455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 43838,
      "e": 32455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43894,
      "e": 32511,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 43942,
      "e": 32559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43942,
      "e": 32559,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44022,
      "e": 32639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44054,
      "e": 32671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44054,
      "e": 32671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44110,
      "e": 32727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44110,
      "e": 32727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44135,
      "e": 32752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 44206,
      "e": 32823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44223,
      "e": 32840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44223,
      "e": 32840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44303,
      "e": 32920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44304,
      "e": 32921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44310,
      "e": 32927,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 44398,
      "e": 33015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44719,
      "e": 33336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 44720,
      "e": 33337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44782,
      "e": 33399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 44798,
      "e": 33415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44798,
      "e": 33415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44854,
      "e": 33471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 44886,
      "e": 33503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 44886,
      "e": 33503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44974,
      "e": 33591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 44975,
      "e": 33592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44976,
      "e": 33593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45078,
      "e": 33695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 45086,
      "e": 33703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45086,
      "e": 33703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45175,
      "e": 33792,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45647,
      "e": 34264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 45647,
      "e": 34264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45694,
      "e": 34311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 45805,
      "e": 34422,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right,"
    },
    {
      "t": 45814,
      "e": 34431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45814,
      "e": 34431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45902,
      "e": 34519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45966,
      "e": 34583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45966,
      "e": 34583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46030,
      "e": 34647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 46030,
      "e": 34647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 46030,
      "e": 34647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46102,
      "e": 34719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 46118,
      "e": 34735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 46118,
      "e": 34735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46222,
      "e": 34839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 46271,
      "e": 34888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46272,
      "e": 34889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46358,
      "e": 34975,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46503,
      "e": 35120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46504,
      "e": 35121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46566,
      "e": 35183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 46582,
      "e": 35199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 46582,
      "e": 35199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46622,
      "e": 35239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 46622,
      "e": 35239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46654,
      "e": 35271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 46686,
      "e": 35303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46686,
      "e": 35303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46726,
      "e": 35343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 46743,
      "e": 35360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46744,
      "e": 35361,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46774,
      "e": 35391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46814,
      "e": 35431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46846,
      "e": 35463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 46846,
      "e": 35463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46926,
      "e": 35543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 46934,
      "e": 35551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 46934,
      "e": 35551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46983,
      "e": 35600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 46983,
      "e": 35600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46998,
      "e": 35615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 47054,
      "e": 35671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47376,
      "e": 35672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 47378,
      "e": 35674,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47438,
      "e": 35734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 47446,
      "e": 35742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 47446,
      "e": 35742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47518,
      "e": 35814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 47574,
      "e": 35870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47574,
      "e": 35870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47647,
      "e": 35943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47687,
      "e": 35983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 47687,
      "e": 35983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47742,
      "e": 36038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 47951,
      "e": 36247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 47952,
      "e": 36248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47959,
      "e": 36255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 47960,
      "e": 36256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47998,
      "e": 36294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ew"
    },
    {
      "t": 48022,
      "e": 36318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48046,
      "e": 36342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48046,
      "e": 36342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48166,
      "e": 36462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48999,
      "e": 37295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49046,
      "e": 37342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and that would bew"
    },
    {
      "t": 49142,
      "e": 37438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49199,
      "e": 37495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and that would be"
    },
    {
      "t": 49278,
      "e": 37574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49326,
      "e": 37622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and that would b"
    },
    {
      "t": 49583,
      "e": 37879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49622,
      "e": 37918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and that would "
    },
    {
      "t": 50007,
      "e": 38303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 50054,
      "e": 38350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and that would"
    },
    {
      "t": 50206,
      "e": 38502,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and that would"
    },
    {
      "t": 50431,
      "e": 38727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50432,
      "e": 38728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50518,
      "e": 38814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50550,
      "e": 38846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 50550,
      "e": 38846,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50646,
      "e": 38942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 50743,
      "e": 39039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 50743,
      "e": 39039,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50822,
      "e": 39118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 50894,
      "e": 39190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50895,
      "e": 39191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51006,
      "e": 39302,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and that would be "
    },
    {
      "t": 51008,
      "e": 39304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53382,
      "e": 41678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 53462,
      "e": 41758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 53463,
      "e": 41759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53534,
      "e": 41830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 53581,
      "e": 41877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54111,
      "e": 42407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54112,
      "e": 42408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54190,
      "e": 42486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 54206,
      "e": 42502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 54206,
      "e": 42502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54269,
      "e": 42565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 54285,
      "e": 42581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 54286,
      "e": 42582,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54358,
      "e": 42654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 54422,
      "e": 42718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 54423,
      "e": 42719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54493,
      "e": 42789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 54502,
      "e": 42798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54503,
      "e": 42799,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54589,
      "e": 42885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55312,
      "e": 42887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 55389,
      "e": 42964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 55390,
      "e": 42965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55445,
      "e": 43020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 55550,
      "e": 43125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 56604,
      "e": 44179,
      "ty": 2,
      "x": 700,
      "y": 515
    },
    {
      "t": 56755,
      "e": 44330,
      "ty": 41,
      "x": 1142,
      "y": 30530,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 57254,
      "e": 44829,
      "ty": 41,
      "x": 1142,
      "y": 32874,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 57305,
      "e": 44880,
      "ty": 2,
      "x": 700,
      "y": 550
    },
    {
      "t": 57504,
      "e": 45079,
      "ty": 2,
      "x": 1058,
      "y": 875
    },
    {
      "t": 57505,
      "e": 45080,
      "ty": 41,
      "x": 19168,
      "y": 56582,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 57554,
      "e": 45129,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 57604,
      "e": 45179,
      "ty": 2,
      "x": 1241,
      "y": 1091
    },
    {
      "t": 57804,
      "e": 45379,
      "ty": 2,
      "x": 1264,
      "y": 984
    },
    {
      "t": 57904,
      "e": 45479,
      "ty": 2,
      "x": 1277,
      "y": 922
    },
    {
      "t": 58005,
      "e": 45580,
      "ty": 41,
      "x": 17389,
      "y": 24831,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[13] > text"
    },
    {
      "t": 58104,
      "e": 45679,
      "ty": 2,
      "x": 1277,
      "y": 920
    },
    {
      "t": 58205,
      "e": 45780,
      "ty": 2,
      "x": 1238,
      "y": 911
    },
    {
      "t": 58255,
      "e": 45830,
      "ty": 41,
      "x": 26092,
      "y": 5957,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 58304,
      "e": 45879,
      "ty": 2,
      "x": 1165,
      "y": 911
    },
    {
      "t": 58404,
      "e": 45979,
      "ty": 2,
      "x": 1140,
      "y": 903
    },
    {
      "t": 58505,
      "e": 46080,
      "ty": 2,
      "x": 1137,
      "y": 899
    },
    {
      "t": 58505,
      "e": 46080,
      "ty": 41,
      "x": 24735,
      "y": 58301,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 58604,
      "e": 46179,
      "ty": 2,
      "x": 1137,
      "y": 898
    },
    {
      "t": 58755,
      "e": 46330,
      "ty": 41,
      "x": 24735,
      "y": 58229,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 59105,
      "e": 46680,
      "ty": 2,
      "x": 1134,
      "y": 895
    },
    {
      "t": 59202,
      "e": 46777,
      "ty": 6,
      "x": 451,
      "y": 632,
      "ta": "#strategyButton"
    },
    {
      "t": 59204,
      "e": 46779,
      "ty": 2,
      "x": 451,
      "y": 632
    },
    {
      "t": 59254,
      "e": 46829,
      "ty": 41,
      "x": 57564,
      "y": 40989,
      "ta": "#strategyButton"
    },
    {
      "t": 59305,
      "e": 46880,
      "ty": 2,
      "x": 440,
      "y": 610
    },
    {
      "t": 59335,
      "e": 46910,
      "ty": 7,
      "x": 431,
      "y": 595,
      "ta": "#strategyButton"
    },
    {
      "t": 59385,
      "e": 46960,
      "ty": 6,
      "x": 364,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59404,
      "e": 46979,
      "ty": 2,
      "x": 295,
      "y": 490
    },
    {
      "t": 59505,
      "e": 47080,
      "ty": 2,
      "x": 272,
      "y": 477
    },
    {
      "t": 59505,
      "e": 47080,
      "ty": 41,
      "x": 19661,
      "y": 5878,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59604,
      "e": 47179,
      "ty": 2,
      "x": 271,
      "y": 476
    },
    {
      "t": 59686,
      "e": 47261,
      "ty": 7,
      "x": 283,
      "y": 468,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59704,
      "e": 47279,
      "ty": 2,
      "x": 285,
      "y": 467
    },
    {
      "t": 59754,
      "e": 47329,
      "ty": 41,
      "x": 21684,
      "y": 52113,
      "ta": "#.strategy > p"
    },
    {
      "t": 59804,
      "e": 47379,
      "ty": 2,
      "x": 302,
      "y": 461
    },
    {
      "t": 59888,
      "e": 47463,
      "ty": 6,
      "x": 312,
      "y": 471,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59905,
      "e": 47480,
      "ty": 2,
      "x": 315,
      "y": 472
    },
    {
      "t": 60004,
      "e": 47579,
      "ty": 2,
      "x": 368,
      "y": 494
    },
    {
      "t": 60004,
      "e": 47579,
      "ty": 41,
      "x": 30452,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60104,
      "e": 47679,
      "ty": 2,
      "x": 403,
      "y": 499
    },
    {
      "t": 60205,
      "e": 47780,
      "ty": 2,
      "x": 458,
      "y": 503
    },
    {
      "t": 60254,
      "e": 47829,
      "ty": 41,
      "x": 40569,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60304,
      "e": 47879,
      "ty": 2,
      "x": 459,
      "y": 503
    },
    {
      "t": 60404,
      "e": 47979,
      "ty": 2,
      "x": 493,
      "y": 507
    },
    {
      "t": 60504,
      "e": 48079,
      "ty": 2,
      "x": 504,
      "y": 507
    },
    {
      "t": 60504,
      "e": 48079,
      "ty": 41,
      "x": 45740,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60605,
      "e": 48180,
      "ty": 2,
      "x": 515,
      "y": 502
    },
    {
      "t": 60705,
      "e": 48280,
      "ty": 2,
      "x": 520,
      "y": 499
    },
    {
      "t": 60755,
      "e": 48330,
      "ty": 41,
      "x": 48550,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60805,
      "e": 48380,
      "ty": 2,
      "x": 539,
      "y": 488
    },
    {
      "t": 60904,
      "e": 48479,
      "ty": 2,
      "x": 546,
      "y": 486
    },
    {
      "t": 61005,
      "e": 48580,
      "ty": 2,
      "x": 546,
      "y": 485
    },
    {
      "t": 61005,
      "e": 48580,
      "ty": 41,
      "x": 50461,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61355,
      "e": 48930,
      "ty": 3,
      "x": 546,
      "y": 485,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61434,
      "e": 49009,
      "ty": 4,
      "x": 50461,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61434,
      "e": 49009,
      "ty": 5,
      "x": 546,
      "y": 485,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61504,
      "e": 49079,
      "ty": 2,
      "x": 582,
      "y": 486
    },
    {
      "t": 61504,
      "e": 49079,
      "ty": 41,
      "x": 54508,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61538,
      "e": 49113,
      "ty": 7,
      "x": 820,
      "y": 553,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61604,
      "e": 49179,
      "ty": 2,
      "x": 892,
      "y": 570
    },
    {
      "t": 61755,
      "e": 49330,
      "ty": 41,
      "x": 7470,
      "y": 34737,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 62534,
      "e": 50109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 62535,
      "e": 50110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62622,
      "e": 50197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and fthat would be M and L"
    },
    {
      "t": 62622,
      "e": 50197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 62622,
      "e": 50197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62669,
      "e": 50244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 62669,
      "e": 50244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62718,
      "e": 50293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and finthat would be M and L"
    },
    {
      "t": 62758,
      "e": 50333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 62758,
      "e": 50333,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62774,
      "e": 50349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and findthat would be M and L"
    },
    {
      "t": 62838,
      "e": 50413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 62863,
      "e": 50438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 62863,
      "e": 50438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62966,
      "e": 50541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find that would be M and L"
    },
    {
      "t": 63119,
      "e": 50694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 63119,
      "e": 50694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63198,
      "e": 50694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find tthat would be M and L"
    },
    {
      "t": 63198,
      "e": 50694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 63198,
      "e": 50694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63278,
      "e": 50774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find ththat would be M and L"
    },
    {
      "t": 63293,
      "e": 50789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 63294,
      "e": 50790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63365,
      "e": 50861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63366,
      "e": 50862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63373,
      "e": 50869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the that would be M and L"
    },
    {
      "t": 63470,
      "e": 50966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65477,
      "e": 52973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 65477,
      "e": 52973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65566,
      "e": 53062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 65566,
      "e": 53062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65573,
      "e": 53069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dothat would be M and L"
    },
    {
      "t": 65646,
      "e": 53142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65663,
      "e": 53159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 65663,
      "e": 53159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65733,
      "e": 53229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dotthat would be M and L"
    },
    {
      "t": 65741,
      "e": 53237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 65742,
      "e": 53238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65838,
      "e": 53334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dotsthat would be M and L"
    },
    {
      "t": 65998,
      "e": 53494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65999,
      "e": 53495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66101,
      "e": 53597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that would be M and L"
    },
    {
      "t": 66166,
      "e": 53662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66167,
      "e": 53663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66213,
      "e": 53709,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 66213,
      "e": 53709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66221,
      "e": 53717,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots ththat would be M and L"
    },
    {
      "t": 66294,
      "e": 53790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66294,
      "e": 53790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 66294,
      "e": 53790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66366,
      "e": 53862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66366,
      "e": 53862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66407,
      "e": 53862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots thatthat would be M and L"
    },
    {
      "t": 66478,
      "e": 53933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66558,
      "e": 54013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66558,
      "e": 54013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66670,
      "e": 54125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that that would be M and L"
    },
    {
      "t": 68158,
      "e": 55613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 68158,
      "e": 55613,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68213,
      "e": 55668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 68213,
      "e": 55668,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68246,
      "e": 55701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that lithat would be M and L"
    },
    {
      "t": 68277,
      "e": 55732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 68278,
      "e": 55733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68317,
      "e": 55772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that linthat would be M and L"
    },
    {
      "t": 68349,
      "e": 55804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 68350,
      "e": 55805,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68366,
      "e": 55821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that linethat would be M and L"
    },
    {
      "t": 68422,
      "e": 55877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68494,
      "e": 55949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68495,
      "e": 55950,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68509,
      "e": 55964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 68509,
      "e": 55964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68518,
      "e": 55973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line uthat would be M and L"
    },
    {
      "t": 68582,
      "e": 56037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 68582,
      "e": 56037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68629,
      "e": 56084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line upthat would be M and L"
    },
    {
      "t": 68718,
      "e": 56173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68886,
      "e": 56341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68887,
      "e": 56342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68990,
      "e": 56343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up that would be M and L"
    },
    {
      "t": 69214,
      "e": 56567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 69215,
      "e": 56568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69253,
      "e": 56606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 69254,
      "e": 56607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69262,
      "e": 56615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up onthat would be M and L"
    },
    {
      "t": 69350,
      "e": 56703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69414,
      "e": 56767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69414,
      "e": 56767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69509,
      "e": 56862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that would be M and L"
    },
    {
      "t": 69687,
      "e": 57040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 69687,
      "e": 57040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69750,
      "e": 57103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 69750,
      "e": 57103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69758,
      "e": 57111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on ththat would be M and L"
    },
    {
      "t": 69805,
      "e": 57158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 69806,
      "e": 57159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69813,
      "e": 57166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on thathat would be M and L"
    },
    {
      "t": 69870,
      "e": 57223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 69870,
      "e": 57223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69917,
      "e": 57270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on thatthat would be M and L"
    },
    {
      "t": 69941,
      "e": 57294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69942,
      "e": 57295,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69958,
      "e": 57311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that that would be M and L"
    },
    {
      "t": 70030,
      "e": 57383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70061,
      "e": 57414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 70063,
      "e": 57416,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70150,
      "e": 57503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 70151,
      "e": 57504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70159,
      "e": 57505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that dithat would be M and L"
    },
    {
      "t": 70222,
      "e": 57568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70262,
      "e": 57608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 70263,
      "e": 57609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70381,
      "e": 57727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that diathat would be M and L"
    },
    {
      "t": 70678,
      "e": 58024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 70679,
      "e": 58025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70757,
      "e": 58103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that diagthat would be M and L"
    },
    {
      "t": 70789,
      "e": 58135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 70789,
      "e": 58135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70845,
      "e": 58191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 70846,
      "e": 58192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70886,
      "e": 58232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that diagonthat would be M and L"
    },
    {
      "t": 70942,
      "e": 58288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71046,
      "e": 58392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 71047,
      "e": 58393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71126,
      "e": 58472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that diagonathat would be M and L"
    },
    {
      "t": 71142,
      "e": 58488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 71142,
      "e": 58488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71214,
      "e": 58560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that diagonalthat would be M and L"
    },
    {
      "t": 71286,
      "e": 58632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71286,
      "e": 58632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71358,
      "e": 58704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that diagonal that would be M and L"
    },
    {
      "t": 71559,
      "e": 58704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 71561,
      "e": 58706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71645,
      "e": 58790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 71646,
      "e": 58791,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71670,
      "e": 58815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that diagonal lithat would be M and L"
    },
    {
      "t": 71677,
      "e": 58822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 71677,
      "e": 58822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71757,
      "e": 58902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that diagonal linthat would be M and L"
    },
    {
      "t": 71773,
      "e": 58918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 71774,
      "e": 58919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71822,
      "e": 58967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that diagonal linethat would be M and L"
    },
    {
      "t": 71878,
      "e": 59023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72374,
      "e": 59519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 72375,
      "e": 59520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72429,
      "e": 59574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that diagonal line,that would be M and L"
    },
    {
      "t": 72590,
      "e": 59735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72591,
      "e": 59736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72670,
      "e": 59815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that diagonal line, that would be M and L"
    },
    {
      "t": 72758,
      "e": 59903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 72758,
      "e": 59903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72805,
      "e": 59950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 72806,
      "e": 59951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72821,
      "e": 59966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that diagonal line, sothat would be M and L"
    },
    {
      "t": 72894,
      "e": 60039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73231,
      "e": 60376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73231,
      "e": 60376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73317,
      "e": 60376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that diagonal line, so that would be M and L"
    },
    {
      "t": 74405,
      "e": 61464,
      "ty": 2,
      "x": 872,
      "y": 597
    },
    {
      "t": 74504,
      "e": 61563,
      "ty": 2,
      "x": 833,
      "y": 675
    },
    {
      "t": 74505,
      "e": 61564,
      "ty": 41,
      "x": 3313,
      "y": 42257,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 75004,
      "e": 62063,
      "ty": 2,
      "x": 756,
      "y": 641
    },
    {
      "t": 75004,
      "e": 62063,
      "ty": 41,
      "x": 4356,
      "y": 39477,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 75105,
      "e": 62164,
      "ty": 2,
      "x": 730,
      "y": 608
    },
    {
      "t": 75204,
      "e": 62263,
      "ty": 2,
      "x": 659,
      "y": 572
    },
    {
      "t": 75232,
      "e": 62291,
      "ty": 6,
      "x": 627,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75255,
      "e": 62314,
      "ty": 41,
      "x": 58779,
      "y": 49568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75305,
      "e": 62364,
      "ty": 2,
      "x": 610,
      "y": 517
    },
    {
      "t": 75393,
      "e": 62452,
      "ty": 3,
      "x": 610,
      "y": 512,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75405,
      "e": 62464,
      "ty": 2,
      "x": 610,
      "y": 512
    },
    {
      "t": 75481,
      "e": 62540,
      "ty": 4,
      "x": 57655,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75481,
      "e": 62540,
      "ty": 5,
      "x": 610,
      "y": 512,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75503,
      "e": 62562,
      "ty": 41,
      "x": 57655,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76230,
      "e": 63289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 76231,
      "e": 63290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76294,
      "e": 63353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 76405,
      "e": 63464,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that diagonal line, so that would be M and L."
    },
    {
      "t": 78004,
      "e": 65063,
      "ty": 2,
      "x": 608,
      "y": 515
    },
    {
      "t": 78004,
      "e": 65063,
      "ty": 41,
      "x": 57430,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78104,
      "e": 65163,
      "ty": 2,
      "x": 606,
      "y": 517
    },
    {
      "t": 78255,
      "e": 65314,
      "ty": 41,
      "x": 57206,
      "y": 38241,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78804,
      "e": 65863,
      "ty": 2,
      "x": 606,
      "y": 521
    },
    {
      "t": 79005,
      "e": 66064,
      "ty": 41,
      "x": 57206,
      "y": 41477,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79103,
      "e": 66162,
      "ty": 2,
      "x": 594,
      "y": 529
    },
    {
      "t": 79204,
      "e": 66263,
      "ty": 2,
      "x": 587,
      "y": 534
    },
    {
      "t": 79254,
      "e": 66313,
      "ty": 41,
      "x": 55070,
      "y": 51995,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79708,
      "e": 66767,
      "ty": 2,
      "x": 543,
      "y": 484
    },
    {
      "t": 79759,
      "e": 66818,
      "ty": 41,
      "x": 45740,
      "y": 2642,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79808,
      "e": 66867,
      "ty": 2,
      "x": 483,
      "y": 473
    },
    {
      "t": 79908,
      "e": 66967,
      "ty": 2,
      "x": 471,
      "y": 478
    },
    {
      "t": 80008,
      "e": 67067,
      "ty": 2,
      "x": 445,
      "y": 485
    },
    {
      "t": 80008,
      "e": 67067,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80010,
      "e": 67069,
      "ty": 41,
      "x": 39108,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80108,
      "e": 67167,
      "ty": 2,
      "x": 444,
      "y": 485
    },
    {
      "t": 80208,
      "e": 67267,
      "ty": 2,
      "x": 446,
      "y": 483
    },
    {
      "t": 80258,
      "e": 67317,
      "ty": 41,
      "x": 39220,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80308,
      "e": 67367,
      "ty": 2,
      "x": 447,
      "y": 482
    },
    {
      "t": 80408,
      "e": 67467,
      "ty": 2,
      "x": 454,
      "y": 482
    },
    {
      "t": 80508,
      "e": 67567,
      "ty": 2,
      "x": 457,
      "y": 482
    },
    {
      "t": 80509,
      "e": 67568,
      "ty": 41,
      "x": 40457,
      "y": 9923,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81309,
      "e": 68368,
      "ty": 2,
      "x": 477,
      "y": 515
    },
    {
      "t": 81374,
      "e": 68433,
      "ty": 7,
      "x": 480,
      "y": 559,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81408,
      "e": 68467,
      "ty": 2,
      "x": 480,
      "y": 565
    },
    {
      "t": 81508,
      "e": 68567,
      "ty": 41,
      "x": 43042,
      "y": 63841,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 85508,
      "e": 72567,
      "ty": 2,
      "x": 576,
      "y": 554
    },
    {
      "t": 85508,
      "e": 72567,
      "ty": 41,
      "x": 53833,
      "y": 62883,
      "ta": "#.strategy"
    },
    {
      "t": 85608,
      "e": 72667,
      "ty": 2,
      "x": 867,
      "y": 643
    },
    {
      "t": 85708,
      "e": 72767,
      "ty": 2,
      "x": 997,
      "y": 624
    },
    {
      "t": 85758,
      "e": 72817,
      "ty": 41,
      "x": 16772,
      "y": 38891,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 85808,
      "e": 72867,
      "ty": 2,
      "x": 1071,
      "y": 649
    },
    {
      "t": 85908,
      "e": 72967,
      "ty": 2,
      "x": 1184,
      "y": 750
    },
    {
      "t": 86008,
      "e": 73067,
      "ty": 2,
      "x": 1183,
      "y": 789
    },
    {
      "t": 86009,
      "e": 73068,
      "ty": 41,
      "x": 27976,
      "y": 50422,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 86108,
      "e": 73167,
      "ty": 2,
      "x": 1174,
      "y": 821
    },
    {
      "t": 86208,
      "e": 73267,
      "ty": 2,
      "x": 1174,
      "y": 822
    },
    {
      "t": 86259,
      "e": 73318,
      "ty": 41,
      "x": 27342,
      "y": 53000,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 86308,
      "e": 73367,
      "ty": 2,
      "x": 1176,
      "y": 855
    },
    {
      "t": 86408,
      "e": 73467,
      "ty": 2,
      "x": 1185,
      "y": 895
    },
    {
      "t": 86508,
      "e": 73567,
      "ty": 2,
      "x": 1167,
      "y": 909
    },
    {
      "t": 86509,
      "e": 73568,
      "ty": 41,
      "x": 26849,
      "y": 59017,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 86608,
      "e": 73667,
      "ty": 2,
      "x": 1117,
      "y": 904
    },
    {
      "t": 86708,
      "e": 73767,
      "ty": 2,
      "x": 1151,
      "y": 889
    },
    {
      "t": 86758,
      "e": 73817,
      "ty": 41,
      "x": 26637,
      "y": 56653,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 86808,
      "e": 73867,
      "ty": 2,
      "x": 1168,
      "y": 864
    },
    {
      "t": 86909,
      "e": 73968,
      "ty": 2,
      "x": 1171,
      "y": 850
    },
    {
      "t": 87009,
      "e": 74068,
      "ty": 2,
      "x": 1172,
      "y": 840
    },
    {
      "t": 87009,
      "e": 74068,
      "ty": 41,
      "x": 27201,
      "y": 54075,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 87109,
      "e": 74168,
      "ty": 2,
      "x": 1175,
      "y": 835
    },
    {
      "t": 87208,
      "e": 74267,
      "ty": 2,
      "x": 1201,
      "y": 804
    },
    {
      "t": 87259,
      "e": 74318,
      "ty": 41,
      "x": 32557,
      "y": 47700,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 87308,
      "e": 74367,
      "ty": 2,
      "x": 1309,
      "y": 678
    },
    {
      "t": 87408,
      "e": 74467,
      "ty": 2,
      "x": 1352,
      "y": 591
    },
    {
      "t": 87508,
      "e": 74567,
      "ty": 2,
      "x": 1380,
      "y": 494
    },
    {
      "t": 87508,
      "e": 74567,
      "ty": 41,
      "x": 41858,
      "y": 29293,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 87608,
      "e": 74667,
      "ty": 2,
      "x": 1401,
      "y": 448
    },
    {
      "t": 87709,
      "e": 74768,
      "ty": 2,
      "x": 1052,
      "y": 528
    },
    {
      "t": 87759,
      "e": 74818,
      "ty": 41,
      "x": 55857,
      "y": 37665,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 87808,
      "e": 74867,
      "ty": 2,
      "x": 571,
      "y": 635
    },
    {
      "t": 87908,
      "e": 74967,
      "ty": 2,
      "x": 566,
      "y": 597
    },
    {
      "t": 88008,
      "e": 75067,
      "ty": 2,
      "x": 345,
      "y": 598
    },
    {
      "t": 88009,
      "e": 75068,
      "ty": 41,
      "x": 12360,
      "y": 19179,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 88108,
      "e": 75167,
      "ty": 2,
      "x": 339,
      "y": 601
    },
    {
      "t": 88197,
      "e": 75256,
      "ty": 6,
      "x": 342,
      "y": 608,
      "ta": "#strategyButton"
    },
    {
      "t": 88208,
      "e": 75267,
      "ty": 2,
      "x": 342,
      "y": 608
    },
    {
      "t": 88259,
      "e": 75318,
      "ty": 41,
      "x": 23159,
      "y": 48699,
      "ta": "#strategyButton"
    },
    {
      "t": 88309,
      "e": 75368,
      "ty": 2,
      "x": 387,
      "y": 629
    },
    {
      "t": 88375,
      "e": 75434,
      "ty": 3,
      "x": 387,
      "y": 629,
      "ta": "#strategyButton"
    },
    {
      "t": 88375,
      "e": 75434,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that diagonal line, so that would be M and L."
    },
    {
      "t": 88377,
      "e": 75436,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88377,
      "e": 75436,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 88438,
      "e": 75497,
      "ty": 4,
      "x": 26435,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 88446,
      "e": 75505,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 88448,
      "e": 75507,
      "ty": 5,
      "x": 387,
      "y": 629,
      "ta": "#strategyButton"
    },
    {
      "t": 88454,
      "e": 75513,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 88509,
      "e": 75568,
      "ty": 2,
      "x": 376,
      "y": 625
    },
    {
      "t": 88509,
      "e": 75568,
      "ty": 41,
      "x": 12673,
      "y": 37544,
      "ta": "html > body"
    },
    {
      "t": 88808,
      "e": 75867,
      "ty": 2,
      "x": 376,
      "y": 624
    },
    {
      "t": 88909,
      "e": 75968,
      "ty": 2,
      "x": 441,
      "y": 624
    },
    {
      "t": 89009,
      "e": 76068,
      "ty": 2,
      "x": 866,
      "y": 663
    },
    {
      "t": 89009,
      "e": 76068,
      "ty": 41,
      "x": 29547,
      "y": 39856,
      "ta": "html > body"
    },
    {
      "t": 89108,
      "e": 76167,
      "ty": 2,
      "x": 868,
      "y": 663
    },
    {
      "t": 89259,
      "e": 76318,
      "ty": 41,
      "x": 29616,
      "y": 39856,
      "ta": "html > body"
    },
    {
      "t": 89455,
      "e": 76514,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 89609,
      "e": 76668,
      "ty": 2,
      "x": 869,
      "y": 664
    },
    {
      "t": 89759,
      "e": 76818,
      "ty": 41,
      "x": 29650,
      "y": 39917,
      "ta": "html > body"
    },
    {
      "t": 90008,
      "e": 77067,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90247,
      "e": 77306,
      "ty": 6,
      "x": 895,
      "y": 614,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90258,
      "e": 77317,
      "ty": 41,
      "x": 18816,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90264,
      "e": 77323,
      "ty": 7,
      "x": 907,
      "y": 588,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90308,
      "e": 77367,
      "ty": 2,
      "x": 927,
      "y": 550
    },
    {
      "t": 90382,
      "e": 77441,
      "ty": 6,
      "x": 935,
      "y": 521,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 90408,
      "e": 77467,
      "ty": 2,
      "x": 936,
      "y": 513
    },
    {
      "t": 90482,
      "e": 77541,
      "ty": 7,
      "x": 943,
      "y": 499,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 90508,
      "e": 77567,
      "ty": 2,
      "x": 944,
      "y": 497
    },
    {
      "t": 90508,
      "e": 77567,
      "ty": 41,
      "x": 29415,
      "y": 42280,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 90558,
      "e": 77617,
      "ty": 3,
      "x": 944,
      "y": 497,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 90638,
      "e": 77697,
      "ty": 4,
      "x": 29415,
      "y": 42280,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 90638,
      "e": 77697,
      "ty": 5,
      "x": 944,
      "y": 497,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 90808,
      "e": 77867,
      "ty": 2,
      "x": 942,
      "y": 498
    },
    {
      "t": 90878,
      "e": 77937,
      "ty": 3,
      "x": 942,
      "y": 498,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 90880,
      "e": 77939,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 90965,
      "e": 78024,
      "ty": 4,
      "x": 28982,
      "y": 42985,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 90965,
      "e": 78024,
      "ty": 5,
      "x": 942,
      "y": 498,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 91008,
      "e": 78067,
      "ty": 41,
      "x": 28982,
      "y": 42985,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 91746,
      "e": 78805,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 91747,
      "e": 78806,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91849,
      "e": 78908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "51"
    },
    {
      "t": 91849,
      "e": 78908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91905,
      "e": 78964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 91933,
      "e": 78992,
      "ty": 6,
      "x": 942,
      "y": 507,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91948,
      "e": 79007,
      "ty": 7,
      "x": 948,
      "y": 522,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91994,
      "e": 79053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 92009,
      "e": 79068,
      "ty": 2,
      "x": 963,
      "y": 567
    },
    {
      "t": 92009,
      "e": 79068,
      "ty": 41,
      "x": 33524,
      "y": 44470,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 92084,
      "e": 79143,
      "ty": 6,
      "x": 968,
      "y": 595,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92108,
      "e": 79167,
      "ty": 2,
      "x": 968,
      "y": 598
    },
    {
      "t": 92208,
      "e": 79267,
      "ty": 2,
      "x": 970,
      "y": 612
    },
    {
      "t": 92259,
      "e": 79318,
      "ty": 41,
      "x": 35038,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92408,
      "e": 79467,
      "ty": 2,
      "x": 971,
      "y": 612
    },
    {
      "t": 92509,
      "e": 79568,
      "ty": 41,
      "x": 35254,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92526,
      "e": 79585,
      "ty": 3,
      "x": 971,
      "y": 612,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92527,
      "e": 79586,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "23"
    },
    {
      "t": 92528,
      "e": 79587,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 92528,
      "e": 79587,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92597,
      "e": 79656,
      "ty": 4,
      "x": 35254,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92597,
      "e": 79656,
      "ty": 5,
      "x": 971,
      "y": 612,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93362,
      "e": 80421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 93426,
      "e": 80485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 93426,
      "e": 80485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93472,
      "e": 80531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 93529,
      "e": 80588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 93570,
      "e": 80629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 93570,
      "e": 80629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93601,
      "e": 80660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ch"
    },
    {
      "t": 93609,
      "e": 80668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 93609,
      "e": 80668,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93754,
      "e": 80813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chi"
    },
    {
      "t": 94410,
      "e": 81469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 94411,
      "e": 81470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94482,
      "e": 81541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chin"
    },
    {
      "t": 94489,
      "e": 81548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 94491,
      "e": 81550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94610,
      "e": 81669,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "China"
    },
    {
      "t": 94625,
      "e": 81684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 95230,
      "e": 82289,
      "ty": 7,
      "x": 971,
      "y": 616,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95252,
      "e": 82311,
      "ty": 6,
      "x": 971,
      "y": 625,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95258,
      "e": 82317,
      "ty": 41,
      "x": 38694,
      "y": 3971,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95308,
      "e": 82367,
      "ty": 2,
      "x": 972,
      "y": 637
    },
    {
      "t": 95408,
      "e": 82467,
      "ty": 2,
      "x": 978,
      "y": 649
    },
    {
      "t": 95517,
      "e": 82576,
      "ty": 2,
      "x": 978,
      "y": 650
    },
    {
      "t": 95517,
      "e": 82576,
      "ty": 41,
      "x": 42302,
      "y": 53619,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95608,
      "e": 82667,
      "ty": 2,
      "x": 985,
      "y": 648
    },
    {
      "t": 95653,
      "e": 82712,
      "ty": 3,
      "x": 987,
      "y": 647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95653,
      "e": 82712,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "China"
    },
    {
      "t": 95654,
      "e": 82713,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95654,
      "e": 82713,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95708,
      "e": 82767,
      "ty": 2,
      "x": 987,
      "y": 647
    },
    {
      "t": 95750,
      "e": 82809,
      "ty": 4,
      "x": 46940,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95752,
      "e": 82811,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95753,
      "e": 82812,
      "ty": 5,
      "x": 987,
      "y": 647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 95754,
      "e": 82813,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 95759,
      "e": 82818,
      "ty": 41,
      "x": 33714,
      "y": 38882,
      "ta": "html > body"
    },
    {
      "t": 96773,
      "e": 83832,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 97708,
      "e": 84767,
      "ty": 2,
      "x": 1003,
      "y": 614
    },
    {
      "t": 97759,
      "e": 84818,
      "ty": 41,
      "x": 63502,
      "y": 7853,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 97809,
      "e": 84868,
      "ty": 2,
      "x": 986,
      "y": 93
    },
    {
      "t": 97845,
      "e": 84904,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 97908,
      "e": 84967,
      "ty": 2,
      "x": 905,
      "y": 1
    },
    {
      "t": 98009,
      "e": 85068,
      "ty": 2,
      "x": 813,
      "y": 23
    },
    {
      "t": 98009,
      "e": 85068,
      "ty": 41,
      "x": 27722,
      "y": 912,
      "ta": "html > body"
    },
    {
      "t": 98109,
      "e": 85168,
      "ty": 2,
      "x": 824,
      "y": 118
    },
    {
      "t": 98209,
      "e": 85268,
      "ty": 2,
      "x": 832,
      "y": 166
    },
    {
      "t": 98237,
      "e": 85296,
      "ty": 6,
      "x": 834,
      "y": 179,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98259,
      "e": 85318,
      "ty": 41,
      "x": 38202,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98270,
      "e": 85329,
      "ty": 7,
      "x": 833,
      "y": 193,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 98309,
      "e": 85368,
      "ty": 2,
      "x": 827,
      "y": 206
    },
    {
      "t": 98409,
      "e": 85468,
      "ty": 2,
      "x": 820,
      "y": 224
    },
    {
      "t": 98509,
      "e": 85568,
      "ty": 41,
      "x": 27963,
      "y": 13143,
      "ta": "html > body"
    },
    {
      "t": 98708,
      "e": 85767,
      "ty": 2,
      "x": 820,
      "y": 225
    },
    {
      "t": 98759,
      "e": 85818,
      "ty": 41,
      "x": 137,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 98808,
      "e": 85867,
      "ty": 2,
      "x": 824,
      "y": 240
    },
    {
      "t": 98909,
      "e": 85968,
      "ty": 2,
      "x": 825,
      "y": 241
    },
    {
      "t": 99011,
      "e": 85970,
      "ty": 41,
      "x": 1121,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 99182,
      "e": 86141,
      "ty": 6,
      "x": 827,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 99209,
      "e": 86168,
      "ty": 2,
      "x": 827,
      "y": 241
    },
    {
      "t": 99259,
      "e": 86218,
      "ty": 41,
      "x": 2914,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 99262,
      "e": 86221,
      "ty": 3,
      "x": 827,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 99264,
      "e": 86223,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 99325,
      "e": 86284,
      "ty": 4,
      "x": 2914,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 99325,
      "e": 86284,
      "ty": 5,
      "x": 827,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 99325,
      "e": 86284,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 99873,
      "e": 86832,
      "ty": 7,
      "x": 827,
      "y": 252,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 99908,
      "e": 86867,
      "ty": 2,
      "x": 825,
      "y": 263
    },
    {
      "t": 100008,
      "e": 86967,
      "ty": 2,
      "x": 825,
      "y": 313
    },
    {
      "t": 100008,
      "e": 86967,
      "ty": 41,
      "x": 849,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 100109,
      "e": 87068,
      "ty": 2,
      "x": 825,
      "y": 338
    },
    {
      "t": 100209,
      "e": 87168,
      "ty": 2,
      "x": 825,
      "y": 340
    },
    {
      "t": 100258,
      "e": 87217,
      "ty": 41,
      "x": 849,
      "y": 10561,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 100309,
      "e": 87268,
      "ty": 2,
      "x": 825,
      "y": 343
    },
    {
      "t": 100409,
      "e": 87368,
      "ty": 2,
      "x": 825,
      "y": 344
    },
    {
      "t": 100506,
      "e": 87465,
      "ty": 6,
      "x": 827,
      "y": 355,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 100509,
      "e": 87468,
      "ty": 2,
      "x": 827,
      "y": 355
    },
    {
      "t": 100509,
      "e": 87468,
      "ty": 41,
      "x": 2914,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 100590,
      "e": 87549,
      "ty": 7,
      "x": 830,
      "y": 369,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 100609,
      "e": 87568,
      "ty": 2,
      "x": 830,
      "y": 371
    },
    {
      "t": 100695,
      "e": 87654,
      "ty": 6,
      "x": 832,
      "y": 383,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 100709,
      "e": 87668,
      "ty": 2,
      "x": 832,
      "y": 383
    },
    {
      "t": 100759,
      "e": 87718,
      "ty": 41,
      "x": 28120,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 100808,
      "e": 87767,
      "ty": 2,
      "x": 832,
      "y": 386
    },
    {
      "t": 100889,
      "e": 87848,
      "ty": 7,
      "x": 832,
      "y": 396,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 100908,
      "e": 87867,
      "ty": 2,
      "x": 831,
      "y": 399
    },
    {
      "t": 101008,
      "e": 87967,
      "ty": 2,
      "x": 829,
      "y": 410
    },
    {
      "t": 101008,
      "e": 87967,
      "ty": 41,
      "x": 8010,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 101023,
      "e": 87982,
      "ty": 6,
      "x": 829,
      "y": 412,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 101109,
      "e": 88068,
      "ty": 2,
      "x": 827,
      "y": 417
    },
    {
      "t": 101207,
      "e": 88166,
      "ty": 7,
      "x": 833,
      "y": 409,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 101208,
      "e": 88167,
      "ty": 2,
      "x": 833,
      "y": 409
    },
    {
      "t": 101259,
      "e": 88218,
      "ty": 41,
      "x": 3697,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 101309,
      "e": 88268,
      "ty": 2,
      "x": 839,
      "y": 398
    },
    {
      "t": 101340,
      "e": 88299,
      "ty": 6,
      "x": 839,
      "y": 395,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 101409,
      "e": 88368,
      "ty": 2,
      "x": 839,
      "y": 389
    },
    {
      "t": 101440,
      "e": 88399,
      "ty": 7,
      "x": 839,
      "y": 381,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 101508,
      "e": 88467,
      "ty": 2,
      "x": 839,
      "y": 376
    },
    {
      "t": 101509,
      "e": 88468,
      "ty": 41,
      "x": 4171,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 101573,
      "e": 88532,
      "ty": 6,
      "x": 839,
      "y": 388,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 101590,
      "e": 88549,
      "ty": 7,
      "x": 840,
      "y": 393,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 101608,
      "e": 88567,
      "ty": 2,
      "x": 841,
      "y": 399
    },
    {
      "t": 101709,
      "e": 88668,
      "ty": 2,
      "x": 841,
      "y": 407
    },
    {
      "t": 101740,
      "e": 88699,
      "ty": 6,
      "x": 839,
      "y": 415,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 101758,
      "e": 88717,
      "ty": 41,
      "x": 63408,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 101774,
      "e": 88733,
      "ty": 7,
      "x": 836,
      "y": 425,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 101808,
      "e": 88767,
      "ty": 2,
      "x": 836,
      "y": 432
    },
    {
      "t": 101874,
      "e": 88768,
      "ty": 6,
      "x": 834,
      "y": 440,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 101909,
      "e": 88803,
      "ty": 2,
      "x": 833,
      "y": 442
    },
    {
      "t": 102009,
      "e": 88903,
      "ty": 2,
      "x": 832,
      "y": 444
    },
    {
      "t": 102009,
      "e": 88903,
      "ty": 41,
      "x": 28120,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 102109,
      "e": 89003,
      "ty": 2,
      "x": 830,
      "y": 445
    },
    {
      "t": 102142,
      "e": 89036,
      "ty": 3,
      "x": 830,
      "y": 445,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 102143,
      "e": 89037,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 102144,
      "e": 89038,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 102205,
      "e": 89099,
      "ty": 4,
      "x": 18037,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 102205,
      "e": 89099,
      "ty": 5,
      "x": 830,
      "y": 445,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 102205,
      "e": 89099,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 102259,
      "e": 89153,
      "ty": 41,
      "x": 18037,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 103008,
      "e": 89902,
      "ty": 1,
      "x": 0,
      "y": 4
    },
    {
      "t": 103108,
      "e": 90002,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 103209,
      "e": 90103,
      "ty": 7,
      "x": 830,
      "y": 461,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 103623,
      "e": 90517,
      "ty": 6,
      "x": 830,
      "y": 471,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 103641,
      "e": 90535,
      "ty": 7,
      "x": 830,
      "y": 509,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 103658,
      "e": 90552,
      "ty": 6,
      "x": 830,
      "y": 535,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 103675,
      "e": 90569,
      "ty": 7,
      "x": 830,
      "y": 555,
      "ta": "jspsych-survey-multi-choice-response-1[6]_mf"
    },
    {
      "t": 103708,
      "e": 90602,
      "ty": 2,
      "x": 830,
      "y": 584
    },
    {
      "t": 103759,
      "e": 90653,
      "ty": 41,
      "x": 1497,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 103775,
      "e": 90669,
      "ty": 6,
      "x": 826,
      "y": 615,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 103792,
      "e": 90686,
      "ty": 7,
      "x": 825,
      "y": 617,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 103809,
      "e": 90703,
      "ty": 2,
      "x": 825,
      "y": 617
    },
    {
      "t": 103910,
      "e": 90804,
      "ty": 2,
      "x": 819,
      "y": 645
    },
    {
      "t": 104009,
      "e": 90903,
      "ty": 2,
      "x": 817,
      "y": 653
    },
    {
      "t": 104009,
      "e": 90903,
      "ty": 41,
      "x": 27860,
      "y": 39247,
      "ta": "html > body"
    },
    {
      "t": 104609,
      "e": 91503,
      "ty": 2,
      "x": 821,
      "y": 682
    },
    {
      "t": 104709,
      "e": 91603,
      "ty": 2,
      "x": 822,
      "y": 688
    },
    {
      "t": 104759,
      "e": 91653,
      "ty": 41,
      "x": 137,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 105409,
      "e": 92303,
      "ty": 2,
      "x": 823,
      "y": 685
    },
    {
      "t": 105509,
      "e": 92403,
      "ty": 2,
      "x": 823,
      "y": 644
    },
    {
      "t": 105509,
      "e": 92403,
      "ty": 41,
      "x": 397,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 105609,
      "e": 92503,
      "ty": 2,
      "x": 824,
      "y": 637
    },
    {
      "t": 105709,
      "e": 92603,
      "ty": 2,
      "x": 826,
      "y": 631
    },
    {
      "t": 105749,
      "e": 92643,
      "ty": 6,
      "x": 828,
      "y": 627,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 105759,
      "e": 92653,
      "ty": 41,
      "x": 7955,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 105809,
      "e": 92703,
      "ty": 2,
      "x": 829,
      "y": 626
    },
    {
      "t": 105908,
      "e": 92802,
      "ty": 2,
      "x": 829,
      "y": 623
    },
    {
      "t": 106009,
      "e": 92903,
      "ty": 2,
      "x": 830,
      "y": 618
    },
    {
      "t": 106010,
      "e": 92904,
      "ty": 41,
      "x": 18037,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 106109,
      "e": 93003,
      "ty": 2,
      "x": 830,
      "y": 620
    },
    {
      "t": 106209,
      "e": 93103,
      "ty": 2,
      "x": 834,
      "y": 625
    },
    {
      "t": 106259,
      "e": 93153,
      "ty": 41,
      "x": 38202,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 106294,
      "e": 93188,
      "ty": 7,
      "x": 834,
      "y": 628,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 106308,
      "e": 93202,
      "ty": 2,
      "x": 834,
      "y": 628
    },
    {
      "t": 106408,
      "e": 93302,
      "ty": 2,
      "x": 834,
      "y": 638
    },
    {
      "t": 106508,
      "e": 93402,
      "ty": 41,
      "x": 2985,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 107178,
      "e": 94072,
      "ty": 6,
      "x": 834,
      "y": 645,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 107208,
      "e": 94102,
      "ty": 2,
      "x": 834,
      "y": 651
    },
    {
      "t": 107212,
      "e": 94106,
      "ty": 7,
      "x": 836,
      "y": 657,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 107258,
      "e": 94152,
      "ty": 41,
      "x": 4646,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 107308,
      "e": 94152,
      "ty": 2,
      "x": 841,
      "y": 663
    },
    {
      "t": 107508,
      "e": 94352,
      "ty": 2,
      "x": 847,
      "y": 666
    },
    {
      "t": 107509,
      "e": 94353,
      "ty": 41,
      "x": 6070,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 107608,
      "e": 94452,
      "ty": 2,
      "x": 860,
      "y": 671
    },
    {
      "t": 107708,
      "e": 94552,
      "ty": 2,
      "x": 861,
      "y": 671
    },
    {
      "t": 107759,
      "e": 94603,
      "ty": 41,
      "x": 9933,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 108108,
      "e": 94952,
      "ty": 2,
      "x": 862,
      "y": 681
    },
    {
      "t": 108208,
      "e": 95052,
      "ty": 2,
      "x": 867,
      "y": 704
    },
    {
      "t": 108259,
      "e": 95103,
      "ty": 41,
      "x": 19017,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 109508,
      "e": 96352,
      "ty": 2,
      "x": 865,
      "y": 727
    },
    {
      "t": 109508,
      "e": 96352,
      "ty": 41,
      "x": 24396,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 109608,
      "e": 96452,
      "ty": 2,
      "x": 864,
      "y": 729
    },
    {
      "t": 109709,
      "e": 96553,
      "ty": 2,
      "x": 844,
      "y": 766
    },
    {
      "t": 109758,
      "e": 96602,
      "ty": 41,
      "x": 5358,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 109808,
      "e": 96652,
      "ty": 2,
      "x": 844,
      "y": 773
    },
    {
      "t": 109908,
      "e": 96752,
      "ty": 2,
      "x": 844,
      "y": 782
    },
    {
      "t": 110009,
      "e": 96853,
      "ty": 41,
      "x": 15907,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 110297,
      "e": 97141,
      "ty": 6,
      "x": 828,
      "y": 785,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 110308,
      "e": 97152,
      "ty": 2,
      "x": 828,
      "y": 785
    },
    {
      "t": 110314,
      "e": 97158,
      "ty": 7,
      "x": 781,
      "y": 779,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 110408,
      "e": 97252,
      "ty": 2,
      "x": 670,
      "y": 744
    },
    {
      "t": 110508,
      "e": 97352,
      "ty": 41,
      "x": 22797,
      "y": 44785,
      "ta": "html > body"
    },
    {
      "t": 111582,
      "e": 98426,
      "ty": 6,
      "x": 837,
      "y": 767,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 111599,
      "e": 98443,
      "ty": 7,
      "x": 846,
      "y": 767,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 111608,
      "e": 98452,
      "ty": 2,
      "x": 846,
      "y": 767
    },
    {
      "t": 111708,
      "e": 98552,
      "ty": 2,
      "x": 856,
      "y": 763
    },
    {
      "t": 111759,
      "e": 98603,
      "ty": 41,
      "x": 20409,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 112208,
      "e": 99052,
      "ty": 2,
      "x": 857,
      "y": 763
    },
    {
      "t": 112259,
      "e": 99103,
      "ty": 41,
      "x": 20999,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 113608,
      "e": 100452,
      "ty": 2,
      "x": 847,
      "y": 693
    },
    {
      "t": 113708,
      "e": 100552,
      "ty": 2,
      "x": 844,
      "y": 687
    },
    {
      "t": 113758,
      "e": 100602,
      "ty": 41,
      "x": 5666,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 113908,
      "e": 100752,
      "ty": 2,
      "x": 834,
      "y": 689
    },
    {
      "t": 114009,
      "e": 100853,
      "ty": 41,
      "x": 2985,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 114108,
      "e": 100952,
      "ty": 2,
      "x": 834,
      "y": 691
    },
    {
      "t": 114258,
      "e": 101102,
      "ty": 41,
      "x": 2985,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 118200,
      "e": 105044,
      "ty": 6,
      "x": 836,
      "y": 681,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 118208,
      "e": 105052,
      "ty": 2,
      "x": 836,
      "y": 681
    },
    {
      "t": 118216,
      "e": 105060,
      "ty": 7,
      "x": 840,
      "y": 669,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 118258,
      "e": 105102,
      "ty": 41,
      "x": 5689,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 118309,
      "e": 105153,
      "ty": 2,
      "x": 845,
      "y": 648
    },
    {
      "t": 118408,
      "e": 105252,
      "ty": 2,
      "x": 845,
      "y": 646
    },
    {
      "t": 118508,
      "e": 105352,
      "ty": 2,
      "x": 845,
      "y": 643
    },
    {
      "t": 118508,
      "e": 105352,
      "ty": 41,
      "x": 5941,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 118607,
      "e": 105353,
      "ty": 6,
      "x": 839,
      "y": 644,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 118608,
      "e": 105354,
      "ty": 2,
      "x": 839,
      "y": 644
    },
    {
      "t": 118708,
      "e": 105454,
      "ty": 2,
      "x": 837,
      "y": 646
    },
    {
      "t": 118758,
      "e": 105504,
      "ty": 41,
      "x": 53325,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 119009,
      "e": 105755,
      "ty": 2,
      "x": 836,
      "y": 646
    },
    {
      "t": 119009,
      "e": 105755,
      "ty": 41,
      "x": 48284,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 119108,
      "e": 105854,
      "ty": 2,
      "x": 836,
      "y": 647
    },
    {
      "t": 119259,
      "e": 106005,
      "ty": 41,
      "x": 48284,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 119308,
      "e": 106054,
      "ty": 2,
      "x": 836,
      "y": 650
    },
    {
      "t": 119318,
      "e": 106064,
      "ty": 3,
      "x": 836,
      "y": 650,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 119320,
      "e": 106066,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 119321,
      "e": 106067,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 119412,
      "e": 106158,
      "ty": 4,
      "x": 48284,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 119412,
      "e": 106158,
      "ty": 5,
      "x": 836,
      "y": 650,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 119412,
      "e": 106158,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 119646,
      "e": 106392,
      "ty": 7,
      "x": 833,
      "y": 658,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 119708,
      "e": 106454,
      "ty": 2,
      "x": 803,
      "y": 703
    },
    {
      "t": 119758,
      "e": 106504,
      "ty": 41,
      "x": 26310,
      "y": 43690,
      "ta": "html > body"
    },
    {
      "t": 119808,
      "e": 106554,
      "ty": 2,
      "x": 770,
      "y": 727
    },
    {
      "t": 119909,
      "e": 106655,
      "ty": 2,
      "x": 769,
      "y": 727
    },
    {
      "t": 120008,
      "e": 106754,
      "ty": 41,
      "x": 26207,
      "y": 43750,
      "ta": "html > body"
    },
    {
      "t": 121258,
      "e": 108004,
      "ty": 41,
      "x": 26172,
      "y": 45941,
      "ta": "html > body"
    },
    {
      "t": 121308,
      "e": 108054,
      "ty": 2,
      "x": 769,
      "y": 814
    },
    {
      "t": 121408,
      "e": 108154,
      "ty": 2,
      "x": 778,
      "y": 832
    },
    {
      "t": 121508,
      "e": 108254,
      "ty": 2,
      "x": 805,
      "y": 874
    },
    {
      "t": 121508,
      "e": 108254,
      "ty": 41,
      "x": 27446,
      "y": 52695,
      "ta": "html > body"
    },
    {
      "t": 121573,
      "e": 108319,
      "ty": 6,
      "x": 826,
      "y": 915,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 121590,
      "e": 108336,
      "ty": 7,
      "x": 826,
      "y": 918,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 121609,
      "e": 108355,
      "ty": 2,
      "x": 826,
      "y": 918
    },
    {
      "t": 121709,
      "e": 108455,
      "ty": 2,
      "x": 828,
      "y": 920
    },
    {
      "t": 121758,
      "e": 108504,
      "ty": 41,
      "x": 1561,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 121808,
      "e": 108554,
      "ty": 2,
      "x": 831,
      "y": 917
    },
    {
      "t": 121823,
      "e": 108569,
      "ty": 6,
      "x": 833,
      "y": 915,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 121908,
      "e": 108654,
      "ty": 2,
      "x": 833,
      "y": 913
    },
    {
      "t": 121957,
      "e": 108703,
      "ty": 3,
      "x": 833,
      "y": 913,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 121960,
      "e": 108706,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 121960,
      "e": 108706,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 122009,
      "e": 108755,
      "ty": 41,
      "x": 33161,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 122037,
      "e": 108783,
      "ty": 4,
      "x": 33161,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 122037,
      "e": 108783,
      "ty": 5,
      "x": 833,
      "y": 913,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 122037,
      "e": 108783,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 122190,
      "e": 108936,
      "ty": 7,
      "x": 834,
      "y": 919,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 122206,
      "e": 108952,
      "ty": 6,
      "x": 838,
      "y": 931,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 122209,
      "e": 108955,
      "ty": 2,
      "x": 838,
      "y": 931
    },
    {
      "t": 122223,
      "e": 108969,
      "ty": 7,
      "x": 844,
      "y": 943,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 122259,
      "e": 109005,
      "ty": 41,
      "x": 6307,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 122308,
      "e": 109054,
      "ty": 2,
      "x": 848,
      "y": 950
    },
    {
      "t": 122478,
      "e": 109224,
      "ty": 6,
      "x": 848,
      "y": 952,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 122508,
      "e": 109254,
      "ty": 2,
      "x": 852,
      "y": 961
    },
    {
      "t": 122509,
      "e": 109255,
      "ty": 41,
      "x": 11636,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 122564,
      "e": 109310,
      "ty": 3,
      "x": 853,
      "y": 962,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 122565,
      "e": 109311,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 122565,
      "e": 109311,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 122608,
      "e": 109354,
      "ty": 2,
      "x": 853,
      "y": 962
    },
    {
      "t": 122652,
      "e": 109398,
      "ty": 4,
      "x": 12151,
      "y": 19859,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 122653,
      "e": 109399,
      "ty": 5,
      "x": 853,
      "y": 962,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 122657,
      "e": 109403,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 122657,
      "e": 109403,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 122659,
      "e": 109405,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 122759,
      "e": 109505,
      "ty": 41,
      "x": 29099,
      "y": 58050,
      "ta": "html > body"
    },
    {
      "t": 124007,
      "e": 110753,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 130009,
      "e": 114505,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 152013,
      "e": 114505,
      "ty": 2,
      "x": 1011,
      "y": 1066
    },
    {
      "t": 152013,
      "e": 114505,
      "ty": 41,
      "x": 56875,
      "y": 53981,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 152113,
      "e": 114605,
      "ty": 2,
      "x": 1043,
      "y": 1075
    },
    {
      "t": 152213,
      "e": 114705,
      "ty": 2,
      "x": 1052,
      "y": 1050
    },
    {
      "t": 152264,
      "e": 114756,
      "ty": 41,
      "x": 35333,
      "y": 61275,
      "ta": "> div.masterdiv"
    },
    {
      "t": 152276,
      "e": 114768,
      "ty": 6,
      "x": 1026,
      "y": 1002,
      "ta": "#start"
    },
    {
      "t": 152313,
      "e": 114805,
      "ty": 2,
      "x": 1009,
      "y": 979
    },
    {
      "t": 152318,
      "e": 114810,
      "ty": 7,
      "x": 1006,
      "y": 975,
      "ta": "#start"
    },
    {
      "t": 152413,
      "e": 114905,
      "ty": 2,
      "x": 998,
      "y": 963
    },
    {
      "t": 152513,
      "e": 115005,
      "ty": 2,
      "x": 989,
      "y": 964
    },
    {
      "t": 152514,
      "e": 115006,
      "ty": 41,
      "x": 34218,
      "y": 64523,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 152614,
      "e": 115106,
      "ty": 2,
      "x": 987,
      "y": 974
    },
    {
      "t": 152636,
      "e": 115128,
      "ty": 6,
      "x": 985,
      "y": 977,
      "ta": "#start"
    },
    {
      "t": 152713,
      "e": 115205,
      "ty": 2,
      "x": 985,
      "y": 985
    },
    {
      "t": 152763,
      "e": 115255,
      "ty": 41,
      "x": 41232,
      "y": 45687,
      "ta": "#start"
    },
    {
      "t": 152813,
      "e": 115305,
      "ty": 2,
      "x": 985,
      "y": 1001
    },
    {
      "t": 152818,
      "e": 115310,
      "ty": 3,
      "x": 985,
      "y": 1001,
      "ta": "#start"
    },
    {
      "t": 152820,
      "e": 115312,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 152905,
      "e": 115397,
      "ty": 4,
      "x": 41232,
      "y": 45687,
      "ta": "#start"
    },
    {
      "t": 152905,
      "e": 115397,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 152905,
      "e": 115397,
      "ty": 5,
      "x": 985,
      "y": 1001,
      "ta": "#start"
    },
    {
      "t": 152905,
      "e": 115397,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 153945,
      "e": 116437,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 155363,
      "e": 117855,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 87936, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 87941, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 22018, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 111299, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 9801, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"romeo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 122107, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 8066, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 131268, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 16102, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 148374, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 39655, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 189394, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:983,y:1003,t:1527627938799};\\\", \\\"{x:985,y:1002,t:1527627938813};\\\", \\\"{x:991,y:998,t:1527627938828};\\\", \\\"{x:993,y:998,t:1527627938845};\\\", \\\"{x:996,y:996,t:1527627938862};\\\", \\\"{x:1001,y:999,t:1527627946064};\\\", \\\"{x:1008,y:1006,t:1527627946070};\\\", \\\"{x:1010,y:1008,t:1527627946085};\\\", \\\"{x:1022,y:1015,t:1527627946101};\\\", \\\"{x:1037,y:1020,t:1527627946118};\\\", \\\"{x:1065,y:1030,t:1527627946134};\\\", \\\"{x:1085,y:1033,t:1527627946151};\\\", \\\"{x:1109,y:1036,t:1527627946168};\\\", \\\"{x:1138,y:1036,t:1527627946185};\\\", \\\"{x:1162,y:1036,t:1527627946201};\\\", \\\"{x:1177,y:1031,t:1527627946218};\\\", \\\"{x:1187,y:1027,t:1527627946234};\\\", \\\"{x:1191,y:1024,t:1527627946251};\\\", \\\"{x:1193,y:1022,t:1527627946268};\\\", \\\"{x:1196,y:1021,t:1527627946285};\\\", \\\"{x:1198,y:1019,t:1527627946301};\\\", \\\"{x:1204,y:1017,t:1527627946317};\\\", \\\"{x:1220,y:1004,t:1527627946334};\\\", \\\"{x:1227,y:999,t:1527627946351};\\\", \\\"{x:1234,y:994,t:1527627946368};\\\", \\\"{x:1238,y:990,t:1527627946385};\\\", \\\"{x:1241,y:988,t:1527627946401};\\\", \\\"{x:1244,y:986,t:1527627946418};\\\", \\\"{x:1247,y:984,t:1527627946435};\\\", \\\"{x:1250,y:983,t:1527627946452};\\\", \\\"{x:1252,y:981,t:1527627946468};\\\", \\\"{x:1255,y:979,t:1527627946485};\\\", \\\"{x:1258,y:978,t:1527627946502};\\\", \\\"{x:1259,y:977,t:1527627946974};\\\", \\\"{x:1260,y:977,t:1527627946984};\\\", \\\"{x:1265,y:974,t:1527627947002};\\\", \\\"{x:1267,y:973,t:1527627947018};\\\", \\\"{x:1270,y:972,t:1527627947034};\\\", \\\"{x:1274,y:970,t:1527627947051};\\\", \\\"{x:1276,y:968,t:1527627947068};\\\", \\\"{x:1279,y:952,t:1527627947084};\\\", \\\"{x:1280,y:952,t:1527627949046};\\\", \\\"{x:1279,y:952,t:1527627949077};\\\", \\\"{x:1277,y:952,t:1527627949093};\\\", \\\"{x:1275,y:952,t:1527627949102};\\\", \\\"{x:1273,y:952,t:1527627949119};\\\", \\\"{x:1270,y:952,t:1527627949136};\\\", \\\"{x:1266,y:951,t:1527627949152};\\\", \\\"{x:1262,y:950,t:1527627949170};\\\", \\\"{x:1259,y:950,t:1527627949186};\\\", \\\"{x:1258,y:950,t:1527627949202};\\\", \\\"{x:1256,y:948,t:1527627949220};\\\", \\\"{x:1255,y:948,t:1527627949301};\\\", \\\"{x:1254,y:947,t:1527627949318};\\\", \\\"{x:1252,y:947,t:1527627949366};\\\", \\\"{x:1251,y:946,t:1527627949373};\\\", \\\"{x:1250,y:946,t:1527627949387};\\\", \\\"{x:1249,y:946,t:1527627949403};\\\", \\\"{x:1247,y:946,t:1527627949419};\\\", \\\"{x:1245,y:945,t:1527627949436};\\\", \\\"{x:1241,y:945,t:1527627949453};\\\", \\\"{x:1237,y:943,t:1527627949470};\\\", \\\"{x:1235,y:943,t:1527627949487};\\\", \\\"{x:1234,y:943,t:1527627949503};\\\", \\\"{x:1234,y:942,t:1527627949550};\\\", \\\"{x:1233,y:941,t:1527627949609};\\\", \\\"{x:1233,y:940,t:1527627949623};\\\", \\\"{x:1232,y:940,t:1527627949671};\\\", \\\"{x:1232,y:939,t:1527627951767};\\\", \\\"{x:1231,y:939,t:1527627951911};\\\", \\\"{x:1232,y:939,t:1527627952935};\\\", \\\"{x:1234,y:939,t:1527627952942};\\\", \\\"{x:1235,y:938,t:1527627952956};\\\", \\\"{x:1238,y:937,t:1527627952973};\\\", \\\"{x:1239,y:936,t:1527627952989};\\\", \\\"{x:1244,y:934,t:1527627953006};\\\", \\\"{x:1248,y:931,t:1527627953022};\\\", \\\"{x:1256,y:930,t:1527627953039};\\\", \\\"{x:1261,y:930,t:1527627953056};\\\", \\\"{x:1266,y:929,t:1527627953073};\\\", \\\"{x:1270,y:928,t:1527627953091};\\\", \\\"{x:1273,y:928,t:1527627953106};\\\", \\\"{x:1277,y:926,t:1527627953124};\\\", \\\"{x:1280,y:925,t:1527627953140};\\\", \\\"{x:1282,y:923,t:1527627953158};\\\", \\\"{x:1283,y:923,t:1527627953173};\\\", \\\"{x:1286,y:920,t:1527627953190};\\\", \\\"{x:1287,y:919,t:1527627953208};\\\", \\\"{x:1288,y:919,t:1527627954983};\\\", \\\"{x:1287,y:919,t:1527627966118};\\\", \\\"{x:1274,y:913,t:1527627966133};\\\", \\\"{x:1221,y:890,t:1527627966149};\\\", \\\"{x:1139,y:859,t:1527627966165};\\\", \\\"{x:984,y:799,t:1527627966182};\\\", \\\"{x:894,y:761,t:1527627966198};\\\", \\\"{x:834,y:728,t:1527627966216};\\\", \\\"{x:795,y:704,t:1527627966232};\\\", \\\"{x:780,y:694,t:1527627966248};\\\", \\\"{x:774,y:688,t:1527627966265};\\\", \\\"{x:772,y:686,t:1527627966282};\\\", \\\"{x:770,y:681,t:1527627966299};\\\", \\\"{x:760,y:674,t:1527627966315};\\\", \\\"{x:741,y:661,t:1527627966332};\\\", \\\"{x:704,y:641,t:1527627966348};\\\", \\\"{x:630,y:613,t:1527627966365};\\\", \\\"{x:523,y:586,t:1527627966384};\\\", \\\"{x:487,y:578,t:1527627966399};\\\", \\\"{x:463,y:568,t:1527627966431};\\\", \\\"{x:459,y:564,t:1527627966449};\\\", \\\"{x:459,y:561,t:1527627966467};\\\", \\\"{x:459,y:557,t:1527627966483};\\\", \\\"{x:459,y:554,t:1527627966499};\\\", \\\"{x:459,y:545,t:1527627966516};\\\", \\\"{x:459,y:543,t:1527627966532};\\\", \\\"{x:457,y:531,t:1527627966549};\\\", \\\"{x:456,y:523,t:1527627966567};\\\", \\\"{x:453,y:516,t:1527627966585};\\\", \\\"{x:446,y:505,t:1527627966599};\\\", \\\"{x:435,y:497,t:1527627966616};\\\", \\\"{x:425,y:489,t:1527627966634};\\\", \\\"{x:408,y:482,t:1527627966650};\\\", \\\"{x:387,y:478,t:1527627966667};\\\", \\\"{x:366,y:473,t:1527627966685};\\\", \\\"{x:345,y:471,t:1527627966700};\\\", \\\"{x:311,y:468,t:1527627966717};\\\", \\\"{x:297,y:467,t:1527627966733};\\\", \\\"{x:290,y:467,t:1527627966750};\\\", \\\"{x:286,y:467,t:1527627966767};\\\", \\\"{x:285,y:467,t:1527627966782};\\\", \\\"{x:282,y:468,t:1527627966800};\\\", \\\"{x:281,y:469,t:1527627966817};\\\", \\\"{x:281,y:471,t:1527627966833};\\\", \\\"{x:281,y:473,t:1527627966850};\\\", \\\"{x:281,y:477,t:1527627966866};\\\", \\\"{x:283,y:481,t:1527627966882};\\\", \\\"{x:290,y:487,t:1527627966900};\\\", \\\"{x:305,y:492,t:1527627966917};\\\", \\\"{x:311,y:496,t:1527627966933};\\\", \\\"{x:312,y:496,t:1527627967037};\\\", \\\"{x:313,y:496,t:1527627967050};\\\", \\\"{x:315,y:496,t:1527627967067};\\\", \\\"{x:316,y:496,t:1527627967084};\\\", \\\"{x:319,y:496,t:1527627967101};\\\", \\\"{x:323,y:496,t:1527627967117};\\\", \\\"{x:325,y:496,t:1527627967133};\\\", \\\"{x:328,y:498,t:1527627967151};\\\", \\\"{x:333,y:500,t:1527627967168};\\\", \\\"{x:340,y:503,t:1527627967184};\\\", \\\"{x:348,y:507,t:1527627967200};\\\", \\\"{x:354,y:508,t:1527627967217};\\\", \\\"{x:357,y:510,t:1527627967234};\\\", \\\"{x:360,y:511,t:1527627967250};\\\", \\\"{x:366,y:512,t:1527627967267};\\\", \\\"{x:372,y:514,t:1527627967284};\\\", \\\"{x:381,y:514,t:1527627967303};\\\", \\\"{x:384,y:514,t:1527627967317};\\\", \\\"{x:391,y:515,t:1527627967334};\\\", \\\"{x:396,y:515,t:1527627967351};\\\", \\\"{x:397,y:515,t:1527627967374};\\\", \\\"{x:398,y:515,t:1527627967870};\\\", \\\"{x:406,y:522,t:1527627967887};\\\", \\\"{x:413,y:539,t:1527627967902};\\\", \\\"{x:423,y:557,t:1527627967917};\\\", \\\"{x:428,y:571,t:1527627967934};\\\", \\\"{x:432,y:582,t:1527627967950};\\\", \\\"{x:434,y:586,t:1527627967968};\\\", \\\"{x:434,y:590,t:1527627967984};\\\", \\\"{x:434,y:592,t:1527627968000};\\\", \\\"{x:434,y:597,t:1527627968017};\\\", \\\"{x:434,y:599,t:1527627968034};\\\", \\\"{x:434,y:603,t:1527627968050};\\\", \\\"{x:434,y:607,t:1527627968067};\\\", \\\"{x:436,y:615,t:1527627968084};\\\", \\\"{x:437,y:622,t:1527627968101};\\\", \\\"{x:440,y:627,t:1527627968118};\\\", \\\"{x:443,y:630,t:1527627968135};\\\", \\\"{x:447,y:632,t:1527627968151};\\\", \\\"{x:450,y:633,t:1527627968168};\\\", \\\"{x:452,y:634,t:1527627968185};\\\", \\\"{x:454,y:634,t:1527627968201};\\\", \\\"{x:459,y:634,t:1527627968218};\\\", \\\"{x:464,y:636,t:1527627968235};\\\", \\\"{x:471,y:638,t:1527627968251};\\\", \\\"{x:482,y:642,t:1527627968268};\\\", \\\"{x:498,y:651,t:1527627968287};\\\", \\\"{x:507,y:656,t:1527627968301};\\\", \\\"{x:512,y:660,t:1527627968318};\\\", \\\"{x:514,y:662,t:1527627968335};\\\", \\\"{x:515,y:663,t:1527627968352};\\\", \\\"{x:516,y:664,t:1527627968855};\\\" ] }, { \\\"rt\\\": 21342, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 211994, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -D -D -K -12 PM-08 PM-08 PM-D -U -D -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:664,t:1527627976974};\\\", \\\"{x:526,y:668,t:1527627976981};\\\", \\\"{x:550,y:681,t:1527627976998};\\\", \\\"{x:603,y:697,t:1527627977017};\\\", \\\"{x:646,y:710,t:1527627977030};\\\", \\\"{x:683,y:724,t:1527627977047};\\\", \\\"{x:695,y:729,t:1527627977058};\\\", \\\"{x:720,y:737,t:1527627977075};\\\", \\\"{x:729,y:741,t:1527627977091};\\\", \\\"{x:733,y:746,t:1527627977108};\\\", \\\"{x:735,y:746,t:1527627977124};\\\", \\\"{x:736,y:747,t:1527627977181};\\\", \\\"{x:739,y:748,t:1527627977197};\\\", \\\"{x:739,y:749,t:1527627977208};\\\", \\\"{x:740,y:749,t:1527627977246};\\\", \\\"{x:747,y:753,t:1527627977259};\\\", \\\"{x:755,y:756,t:1527627977275};\\\", \\\"{x:762,y:759,t:1527627977292};\\\", \\\"{x:770,y:763,t:1527627977308};\\\", \\\"{x:788,y:767,t:1527627977324};\\\", \\\"{x:794,y:770,t:1527627977341};\\\", \\\"{x:797,y:771,t:1527627977359};\\\", \\\"{x:805,y:775,t:1527627977375};\\\", \\\"{x:816,y:778,t:1527627977393};\\\", \\\"{x:825,y:779,t:1527627977408};\\\", \\\"{x:828,y:779,t:1527627977425};\\\", \\\"{x:828,y:780,t:1527627978550};\\\", \\\"{x:830,y:781,t:1527627978565};\\\", \\\"{x:831,y:782,t:1527627978576};\\\", \\\"{x:833,y:786,t:1527627978593};\\\", \\\"{x:835,y:788,t:1527627978610};\\\", \\\"{x:843,y:788,t:1527627978626};\\\", \\\"{x:846,y:792,t:1527627978642};\\\", \\\"{x:858,y:798,t:1527627978660};\\\", \\\"{x:874,y:802,t:1527627978676};\\\", \\\"{x:892,y:807,t:1527627978693};\\\", \\\"{x:910,y:814,t:1527627978709};\\\", \\\"{x:938,y:815,t:1527627978726};\\\", \\\"{x:964,y:815,t:1527627978744};\\\", \\\"{x:994,y:809,t:1527627978760};\\\", \\\"{x:1028,y:799,t:1527627978776};\\\", \\\"{x:1052,y:787,t:1527627978793};\\\", \\\"{x:1080,y:773,t:1527627978809};\\\", \\\"{x:1102,y:761,t:1527627978827};\\\", \\\"{x:1122,y:750,t:1527627978844};\\\", \\\"{x:1142,y:737,t:1527627978859};\\\", \\\"{x:1154,y:724,t:1527627978877};\\\", \\\"{x:1159,y:721,t:1527627978894};\\\", \\\"{x:1173,y:721,t:1527627979462};\\\", \\\"{x:1184,y:720,t:1527627979477};\\\", \\\"{x:1210,y:716,t:1527627979493};\\\", \\\"{x:1223,y:714,t:1527627979510};\\\", \\\"{x:1231,y:710,t:1527627979526};\\\", \\\"{x:1236,y:708,t:1527627979543};\\\", \\\"{x:1238,y:706,t:1527627979560};\\\", \\\"{x:1243,y:704,t:1527627979576};\\\", \\\"{x:1249,y:701,t:1527627979593};\\\", \\\"{x:1255,y:698,t:1527627979610};\\\", \\\"{x:1262,y:694,t:1527627979626};\\\", \\\"{x:1277,y:690,t:1527627979643};\\\", \\\"{x:1291,y:687,t:1527627979660};\\\", \\\"{x:1322,y:683,t:1527627979677};\\\", \\\"{x:1344,y:681,t:1527627979693};\\\", \\\"{x:1367,y:678,t:1527627979710};\\\", \\\"{x:1386,y:677,t:1527627979727};\\\", \\\"{x:1409,y:677,t:1527627979744};\\\", \\\"{x:1435,y:677,t:1527627979760};\\\", \\\"{x:1462,y:679,t:1527627979777};\\\", \\\"{x:1481,y:684,t:1527627979793};\\\", \\\"{x:1505,y:686,t:1527627979811};\\\", \\\"{x:1524,y:692,t:1527627979827};\\\", \\\"{x:1547,y:696,t:1527627979844};\\\", \\\"{x:1569,y:702,t:1527627979861};\\\", \\\"{x:1590,y:704,t:1527627979878};\\\", \\\"{x:1596,y:707,t:1527627979893};\\\", \\\"{x:1600,y:707,t:1527627979911};\\\", \\\"{x:1601,y:707,t:1527627979928};\\\", \\\"{x:1602,y:707,t:1527627979949};\\\", \\\"{x:1604,y:707,t:1527627980998};\\\", \\\"{x:1604,y:701,t:1527627981012};\\\", \\\"{x:1604,y:682,t:1527627981028};\\\", \\\"{x:1604,y:666,t:1527627981045};\\\", \\\"{x:1604,y:647,t:1527627981062};\\\", \\\"{x:1606,y:636,t:1527627981078};\\\", \\\"{x:1606,y:622,t:1527627981094};\\\", \\\"{x:1608,y:603,t:1527627981112};\\\", \\\"{x:1608,y:593,t:1527627981129};\\\", \\\"{x:1608,y:586,t:1527627981144};\\\", \\\"{x:1610,y:576,t:1527627981162};\\\", \\\"{x:1611,y:570,t:1527627981179};\\\", \\\"{x:1613,y:558,t:1527627981195};\\\", \\\"{x:1617,y:545,t:1527627981212};\\\", \\\"{x:1618,y:529,t:1527627981229};\\\", \\\"{x:1618,y:511,t:1527627981247};\\\", \\\"{x:1618,y:481,t:1527627981261};\\\", \\\"{x:1619,y:462,t:1527627981278};\\\", \\\"{x:1621,y:436,t:1527627981294};\\\", \\\"{x:1619,y:411,t:1527627981311};\\\", \\\"{x:1615,y:384,t:1527627981328};\\\", \\\"{x:1613,y:367,t:1527627981345};\\\", \\\"{x:1611,y:358,t:1527627981361};\\\", \\\"{x:1610,y:351,t:1527627981378};\\\", \\\"{x:1610,y:348,t:1527627981394};\\\", \\\"{x:1610,y:347,t:1527627981411};\\\", \\\"{x:1609,y:347,t:1527627981453};\\\", \\\"{x:1608,y:347,t:1527627981469};\\\", \\\"{x:1607,y:347,t:1527627981478};\\\", \\\"{x:1603,y:348,t:1527627981495};\\\", \\\"{x:1597,y:353,t:1527627981511};\\\", \\\"{x:1596,y:357,t:1527627981528};\\\", \\\"{x:1595,y:362,t:1527627981545};\\\", \\\"{x:1595,y:366,t:1527627981561};\\\", \\\"{x:1596,y:369,t:1527627981579};\\\", \\\"{x:1597,y:370,t:1527627981596};\\\", \\\"{x:1598,y:372,t:1527627981612};\\\", \\\"{x:1599,y:373,t:1527627981629};\\\", \\\"{x:1601,y:373,t:1527627981645};\\\", \\\"{x:1602,y:373,t:1527627981661};\\\", \\\"{x:1605,y:374,t:1527627981678};\\\", \\\"{x:1606,y:374,t:1527627981701};\\\", \\\"{x:1608,y:374,t:1527627981725};\\\", \\\"{x:1609,y:374,t:1527627981749};\\\", \\\"{x:1610,y:374,t:1527627981779};\\\", \\\"{x:1611,y:374,t:1527627981861};\\\", \\\"{x:1611,y:375,t:1527627981893};\\\", \\\"{x:1611,y:376,t:1527627982302};\\\", \\\"{x:1611,y:378,t:1527627982333};\\\", \\\"{x:1611,y:379,t:1527627982534};\\\", \\\"{x:1611,y:381,t:1527627982545};\\\", \\\"{x:1611,y:385,t:1527627982563};\\\", \\\"{x:1609,y:390,t:1527627982580};\\\", \\\"{x:1607,y:398,t:1527627982595};\\\", \\\"{x:1601,y:408,t:1527627982613};\\\", \\\"{x:1595,y:429,t:1527627982629};\\\", \\\"{x:1589,y:447,t:1527627982646};\\\", \\\"{x:1582,y:466,t:1527627982663};\\\", \\\"{x:1576,y:481,t:1527627982680};\\\", \\\"{x:1574,y:492,t:1527627982696};\\\", \\\"{x:1571,y:502,t:1527627982713};\\\", \\\"{x:1569,y:510,t:1527627982730};\\\", \\\"{x:1565,y:516,t:1527627982746};\\\", \\\"{x:1562,y:521,t:1527627982762};\\\", \\\"{x:1559,y:526,t:1527627982780};\\\", \\\"{x:1556,y:531,t:1527627982796};\\\", \\\"{x:1550,y:542,t:1527627982812};\\\", \\\"{x:1527,y:568,t:1527627982830};\\\", \\\"{x:1515,y:582,t:1527627982846};\\\", \\\"{x:1500,y:600,t:1527627982864};\\\", \\\"{x:1482,y:619,t:1527627982880};\\\", \\\"{x:1464,y:636,t:1527627982896};\\\", \\\"{x:1450,y:654,t:1527627982913};\\\", \\\"{x:1435,y:670,t:1527627982929};\\\", \\\"{x:1419,y:686,t:1527627982946};\\\", \\\"{x:1403,y:700,t:1527627982963};\\\", \\\"{x:1393,y:714,t:1527627982980};\\\", \\\"{x:1387,y:724,t:1527627982997};\\\", \\\"{x:1384,y:735,t:1527627983013};\\\", \\\"{x:1383,y:747,t:1527627983029};\\\", \\\"{x:1383,y:754,t:1527627983046};\\\", \\\"{x:1383,y:758,t:1527627983063};\\\", \\\"{x:1384,y:764,t:1527627983080};\\\", \\\"{x:1385,y:771,t:1527627983097};\\\", \\\"{x:1388,y:785,t:1527627983113};\\\", \\\"{x:1390,y:790,t:1527627983130};\\\", \\\"{x:1390,y:793,t:1527627983149};\\\", \\\"{x:1390,y:795,t:1527627983163};\\\", \\\"{x:1388,y:801,t:1527627983179};\\\", \\\"{x:1388,y:802,t:1527627983270};\\\", \\\"{x:1388,y:804,t:1527627983301};\\\", \\\"{x:1387,y:806,t:1527627983313};\\\", \\\"{x:1384,y:812,t:1527627983330};\\\", \\\"{x:1381,y:814,t:1527627983347};\\\", \\\"{x:1381,y:815,t:1527627983363};\\\", \\\"{x:1381,y:816,t:1527627983380};\\\", \\\"{x:1380,y:816,t:1527627983462};\\\", \\\"{x:1380,y:814,t:1527627983477};\\\", \\\"{x:1380,y:813,t:1527627983485};\\\", \\\"{x:1380,y:812,t:1527627983516};\\\", \\\"{x:1380,y:811,t:1527627983530};\\\", \\\"{x:1381,y:808,t:1527627983565};\\\", \\\"{x:1381,y:807,t:1527627983709};\\\", \\\"{x:1380,y:810,t:1527627984509};\\\", \\\"{x:1380,y:815,t:1527627984516};\\\", \\\"{x:1380,y:824,t:1527627984530};\\\", \\\"{x:1381,y:836,t:1527627984547};\\\", \\\"{x:1380,y:850,t:1527627984563};\\\", \\\"{x:1376,y:866,t:1527627984580};\\\", \\\"{x:1371,y:881,t:1527627984596};\\\", \\\"{x:1367,y:886,t:1527627984613};\\\", \\\"{x:1364,y:889,t:1527627984631};\\\", \\\"{x:1362,y:891,t:1527627984648};\\\", \\\"{x:1359,y:894,t:1527627984664};\\\", \\\"{x:1358,y:897,t:1527627984680};\\\", \\\"{x:1356,y:898,t:1527627984698};\\\", \\\"{x:1356,y:899,t:1527627984714};\\\", \\\"{x:1355,y:899,t:1527627984730};\\\", \\\"{x:1354,y:902,t:1527627984853};\\\", \\\"{x:1353,y:907,t:1527627984884};\\\", \\\"{x:1352,y:909,t:1527627984897};\\\", \\\"{x:1352,y:911,t:1527627984933};\\\", \\\"{x:1352,y:913,t:1527627984947};\\\", \\\"{x:1352,y:917,t:1527627984964};\\\", \\\"{x:1352,y:919,t:1527627984996};\\\", \\\"{x:1351,y:920,t:1527627985150};\\\", \\\"{x:1349,y:919,t:1527627985324};\\\", \\\"{x:1349,y:918,t:1527627985333};\\\", \\\"{x:1349,y:917,t:1527627985347};\\\", \\\"{x:1349,y:916,t:1527627985638};\\\", \\\"{x:1349,y:915,t:1527627986150};\\\", \\\"{x:1349,y:914,t:1527627986165};\\\", \\\"{x:1350,y:910,t:1527627986182};\\\", \\\"{x:1353,y:904,t:1527627986199};\\\", \\\"{x:1354,y:900,t:1527627986215};\\\", \\\"{x:1357,y:895,t:1527627986232};\\\", \\\"{x:1358,y:892,t:1527627986248};\\\", \\\"{x:1359,y:891,t:1527627986265};\\\", \\\"{x:1360,y:889,t:1527627986282};\\\", \\\"{x:1361,y:889,t:1527627986298};\\\", \\\"{x:1361,y:888,t:1527627986477};\\\", \\\"{x:1362,y:886,t:1527627986485};\\\", \\\"{x:1364,y:885,t:1527627986498};\\\", \\\"{x:1369,y:879,t:1527627986515};\\\", \\\"{x:1374,y:873,t:1527627986531};\\\", \\\"{x:1379,y:868,t:1527627986548};\\\", \\\"{x:1381,y:866,t:1527627986565};\\\", \\\"{x:1383,y:863,t:1527627986581};\\\", \\\"{x:1383,y:860,t:1527627986598};\\\", \\\"{x:1385,y:857,t:1527627986616};\\\", \\\"{x:1385,y:854,t:1527627986631};\\\", \\\"{x:1388,y:851,t:1527627986649};\\\", \\\"{x:1390,y:848,t:1527627986665};\\\", \\\"{x:1392,y:842,t:1527627986681};\\\", \\\"{x:1397,y:835,t:1527627986699};\\\", \\\"{x:1402,y:827,t:1527627986716};\\\", \\\"{x:1406,y:821,t:1527627986732};\\\", \\\"{x:1415,y:804,t:1527627986750};\\\", \\\"{x:1421,y:794,t:1527627986765};\\\", \\\"{x:1427,y:784,t:1527627986783};\\\", \\\"{x:1433,y:776,t:1527627986798};\\\", \\\"{x:1439,y:767,t:1527627986816};\\\", \\\"{x:1443,y:760,t:1527627986833};\\\", \\\"{x:1448,y:751,t:1527627986849};\\\", \\\"{x:1455,y:740,t:1527627986866};\\\", \\\"{x:1461,y:728,t:1527627986883};\\\", \\\"{x:1466,y:721,t:1527627986899};\\\", \\\"{x:1470,y:715,t:1527627986916};\\\", \\\"{x:1474,y:710,t:1527627986933};\\\", \\\"{x:1480,y:698,t:1527627986949};\\\", \\\"{x:1483,y:692,t:1527627986965};\\\", \\\"{x:1487,y:683,t:1527627986983};\\\", \\\"{x:1491,y:678,t:1527627986999};\\\", \\\"{x:1496,y:672,t:1527627987016};\\\", \\\"{x:1500,y:667,t:1527627987033};\\\", \\\"{x:1504,y:659,t:1527627987049};\\\", \\\"{x:1508,y:651,t:1527627987066};\\\", \\\"{x:1513,y:641,t:1527627987083};\\\", \\\"{x:1517,y:633,t:1527627987099};\\\", \\\"{x:1522,y:622,t:1527627987116};\\\", \\\"{x:1528,y:611,t:1527627987133};\\\", \\\"{x:1532,y:604,t:1527627987150};\\\", \\\"{x:1534,y:597,t:1527627987166};\\\", \\\"{x:1536,y:589,t:1527627987183};\\\", \\\"{x:1539,y:580,t:1527627987199};\\\", \\\"{x:1541,y:570,t:1527627987216};\\\", \\\"{x:1546,y:561,t:1527627987233};\\\", \\\"{x:1551,y:550,t:1527627987250};\\\", \\\"{x:1556,y:541,t:1527627987266};\\\", \\\"{x:1564,y:528,t:1527627987283};\\\", \\\"{x:1569,y:515,t:1527627987300};\\\", \\\"{x:1574,y:507,t:1527627987316};\\\", \\\"{x:1581,y:493,t:1527627987334};\\\", \\\"{x:1588,y:483,t:1527627987349};\\\", \\\"{x:1597,y:474,t:1527627987366};\\\", \\\"{x:1603,y:466,t:1527627987383};\\\", \\\"{x:1608,y:459,t:1527627987400};\\\", \\\"{x:1611,y:454,t:1527627987416};\\\", \\\"{x:1613,y:451,t:1527627987433};\\\", \\\"{x:1614,y:448,t:1527627987450};\\\", \\\"{x:1615,y:444,t:1527627987466};\\\", \\\"{x:1616,y:442,t:1527627987483};\\\", \\\"{x:1618,y:438,t:1527627987500};\\\", \\\"{x:1620,y:430,t:1527627987516};\\\", \\\"{x:1622,y:423,t:1527627987533};\\\", \\\"{x:1622,y:420,t:1527627987550};\\\", \\\"{x:1623,y:416,t:1527627987566};\\\", \\\"{x:1623,y:413,t:1527627987583};\\\", \\\"{x:1623,y:411,t:1527627987600};\\\", \\\"{x:1623,y:408,t:1527627987616};\\\", \\\"{x:1623,y:405,t:1527627987633};\\\", \\\"{x:1624,y:402,t:1527627987661};\\\", \\\"{x:1624,y:401,t:1527627987677};\\\", \\\"{x:1624,y:399,t:1527627987693};\\\", \\\"{x:1625,y:398,t:1527627987710};\\\", \\\"{x:1625,y:397,t:1527627987718};\\\", \\\"{x:1625,y:396,t:1527627987733};\\\", \\\"{x:1625,y:395,t:1527627987750};\\\", \\\"{x:1626,y:392,t:1527627987767};\\\", \\\"{x:1626,y:391,t:1527627987790};\\\", \\\"{x:1626,y:390,t:1527627987805};\\\", \\\"{x:1626,y:389,t:1527627987845};\\\", \\\"{x:1626,y:388,t:1527627987861};\\\", \\\"{x:1626,y:387,t:1527627987885};\\\", \\\"{x:1626,y:386,t:1527627987982};\\\", \\\"{x:1626,y:384,t:1527627988045};\\\", \\\"{x:1625,y:383,t:1527627988502};\\\", \\\"{x:1624,y:384,t:1527627988774};\\\", \\\"{x:1624,y:387,t:1527627988784};\\\", \\\"{x:1624,y:396,t:1527627988801};\\\", \\\"{x:1628,y:406,t:1527627988817};\\\", \\\"{x:1632,y:414,t:1527627988834};\\\", \\\"{x:1634,y:422,t:1527627988851};\\\", \\\"{x:1636,y:425,t:1527627988867};\\\", \\\"{x:1637,y:430,t:1527627988883};\\\", \\\"{x:1640,y:437,t:1527627988901};\\\", \\\"{x:1641,y:440,t:1527627988917};\\\", \\\"{x:1642,y:443,t:1527627988935};\\\", \\\"{x:1645,y:447,t:1527627988951};\\\", \\\"{x:1648,y:452,t:1527627988967};\\\", \\\"{x:1653,y:461,t:1527627988984};\\\", \\\"{x:1658,y:470,t:1527627989001};\\\", \\\"{x:1665,y:480,t:1527627989017};\\\", \\\"{x:1673,y:491,t:1527627989034};\\\", \\\"{x:1682,y:501,t:1527627989051};\\\", \\\"{x:1698,y:523,t:1527627989067};\\\", \\\"{x:1713,y:545,t:1527627989084};\\\", \\\"{x:1732,y:572,t:1527627989101};\\\", \\\"{x:1741,y:582,t:1527627989117};\\\", \\\"{x:1745,y:589,t:1527627989134};\\\", \\\"{x:1748,y:595,t:1527627989151};\\\", \\\"{x:1750,y:599,t:1527627989167};\\\", \\\"{x:1753,y:605,t:1527627989184};\\\", \\\"{x:1755,y:610,t:1527627989201};\\\", \\\"{x:1756,y:615,t:1527627989218};\\\", \\\"{x:1758,y:619,t:1527627989234};\\\", \\\"{x:1759,y:627,t:1527627989251};\\\", \\\"{x:1761,y:635,t:1527627989268};\\\", \\\"{x:1764,y:646,t:1527627989284};\\\", \\\"{x:1770,y:665,t:1527627989301};\\\", \\\"{x:1774,y:674,t:1527627989318};\\\", \\\"{x:1775,y:684,t:1527627989334};\\\", \\\"{x:1778,y:691,t:1527627989351};\\\", \\\"{x:1782,y:704,t:1527627989368};\\\", \\\"{x:1787,y:713,t:1527627989384};\\\", \\\"{x:1792,y:724,t:1527627989401};\\\", \\\"{x:1792,y:730,t:1527627989418};\\\", \\\"{x:1796,y:737,t:1527627989434};\\\", \\\"{x:1799,y:746,t:1527627989452};\\\", \\\"{x:1802,y:758,t:1527627989469};\\\", \\\"{x:1807,y:770,t:1527627989484};\\\", \\\"{x:1810,y:779,t:1527627989501};\\\", \\\"{x:1812,y:786,t:1527627989518};\\\", \\\"{x:1813,y:790,t:1527627989534};\\\", \\\"{x:1813,y:795,t:1527627989551};\\\", \\\"{x:1814,y:800,t:1527627989568};\\\", \\\"{x:1815,y:807,t:1527627989585};\\\", \\\"{x:1818,y:818,t:1527627989601};\\\", \\\"{x:1820,y:830,t:1527627989618};\\\", \\\"{x:1821,y:839,t:1527627989634};\\\", \\\"{x:1827,y:849,t:1527627989651};\\\", \\\"{x:1828,y:857,t:1527627989668};\\\", \\\"{x:1832,y:864,t:1527627989685};\\\", \\\"{x:1835,y:869,t:1527627989701};\\\", \\\"{x:1836,y:873,t:1527627989718};\\\", \\\"{x:1838,y:877,t:1527627989735};\\\", \\\"{x:1840,y:880,t:1527627989751};\\\", \\\"{x:1841,y:883,t:1527627989768};\\\", \\\"{x:1842,y:885,t:1527627989785};\\\", \\\"{x:1844,y:890,t:1527627989800};\\\", \\\"{x:1847,y:895,t:1527627989817};\\\", \\\"{x:1851,y:900,t:1527627989835};\\\", \\\"{x:1855,y:906,t:1527627989850};\\\", \\\"{x:1860,y:914,t:1527627989868};\\\", \\\"{x:1868,y:925,t:1527627989884};\\\", \\\"{x:1872,y:931,t:1527627989900};\\\", \\\"{x:1874,y:934,t:1527627989918};\\\", \\\"{x:1875,y:936,t:1527627989934};\\\", \\\"{x:1876,y:937,t:1527627989950};\\\", \\\"{x:1874,y:935,t:1527627990038};\\\", \\\"{x:1874,y:930,t:1527627990052};\\\", \\\"{x:1863,y:908,t:1527627990069};\\\", \\\"{x:1837,y:856,t:1527627990084};\\\", \\\"{x:1811,y:815,t:1527627990102};\\\", \\\"{x:1788,y:769,t:1527627990118};\\\", \\\"{x:1763,y:722,t:1527627990134};\\\", \\\"{x:1743,y:684,t:1527627990152};\\\", \\\"{x:1726,y:645,t:1527627990168};\\\", \\\"{x:1711,y:616,t:1527627990185};\\\", \\\"{x:1701,y:592,t:1527627990202};\\\", \\\"{x:1694,y:576,t:1527627990218};\\\", \\\"{x:1688,y:562,t:1527627990235};\\\", \\\"{x:1684,y:549,t:1527627990252};\\\", \\\"{x:1679,y:539,t:1527627990268};\\\", \\\"{x:1676,y:528,t:1527627990285};\\\", \\\"{x:1673,y:520,t:1527627990301};\\\", \\\"{x:1673,y:512,t:1527627990318};\\\", \\\"{x:1673,y:505,t:1527627990334};\\\", \\\"{x:1672,y:495,t:1527627990352};\\\", \\\"{x:1669,y:483,t:1527627990367};\\\", \\\"{x:1664,y:470,t:1527627990384};\\\", \\\"{x:1659,y:464,t:1527627990402};\\\", \\\"{x:1654,y:450,t:1527627990418};\\\", \\\"{x:1649,y:434,t:1527627990434};\\\", \\\"{x:1643,y:421,t:1527627990451};\\\", \\\"{x:1639,y:411,t:1527627990467};\\\", \\\"{x:1630,y:398,t:1527627990484};\\\", \\\"{x:1624,y:390,t:1527627990502};\\\", \\\"{x:1621,y:387,t:1527627990518};\\\", \\\"{x:1621,y:386,t:1527627990535};\\\", \\\"{x:1619,y:384,t:1527627990552};\\\", \\\"{x:1617,y:382,t:1527627990569};\\\", \\\"{x:1615,y:379,t:1527627990585};\\\", \\\"{x:1615,y:378,t:1527627990602};\\\", \\\"{x:1614,y:378,t:1527627990618};\\\", \\\"{x:1613,y:377,t:1527627990717};\\\", \\\"{x:1607,y:379,t:1527627990726};\\\", \\\"{x:1600,y:388,t:1527627990735};\\\", \\\"{x:1589,y:408,t:1527627990751};\\\", \\\"{x:1573,y:443,t:1527627990768};\\\", \\\"{x:1552,y:483,t:1527627990785};\\\", \\\"{x:1538,y:516,t:1527627990802};\\\", \\\"{x:1529,y:543,t:1527627990818};\\\", \\\"{x:1523,y:567,t:1527627990834};\\\", \\\"{x:1512,y:595,t:1527627990852};\\\", \\\"{x:1505,y:622,t:1527627990868};\\\", \\\"{x:1499,y:638,t:1527627990885};\\\", \\\"{x:1496,y:648,t:1527627990901};\\\", \\\"{x:1495,y:660,t:1527627990919};\\\", \\\"{x:1494,y:672,t:1527627990935};\\\", \\\"{x:1494,y:686,t:1527627990952};\\\", \\\"{x:1494,y:701,t:1527627990968};\\\", \\\"{x:1492,y:714,t:1527627990985};\\\", \\\"{x:1491,y:720,t:1527627991002};\\\", \\\"{x:1489,y:723,t:1527627991019};\\\", \\\"{x:1487,y:726,t:1527627991035};\\\", \\\"{x:1487,y:729,t:1527627991052};\\\", \\\"{x:1483,y:733,t:1527627991069};\\\", \\\"{x:1476,y:738,t:1527627991086};\\\", \\\"{x:1467,y:744,t:1527627991102};\\\", \\\"{x:1457,y:750,t:1527627991119};\\\", \\\"{x:1447,y:756,t:1527627991136};\\\", \\\"{x:1441,y:760,t:1527627991152};\\\", \\\"{x:1435,y:764,t:1527627991169};\\\", \\\"{x:1433,y:769,t:1527627991186};\\\", \\\"{x:1430,y:772,t:1527627991202};\\\", \\\"{x:1430,y:774,t:1527627991219};\\\", \\\"{x:1429,y:776,t:1527627991236};\\\", \\\"{x:1429,y:778,t:1527627991252};\\\", \\\"{x:1429,y:781,t:1527627991269};\\\", \\\"{x:1429,y:782,t:1527627991286};\\\", \\\"{x:1429,y:783,t:1527627991357};\\\", \\\"{x:1429,y:784,t:1527627991369};\\\", \\\"{x:1429,y:789,t:1527627991387};\\\", \\\"{x:1423,y:796,t:1527627991402};\\\", \\\"{x:1411,y:805,t:1527627991419};\\\", \\\"{x:1406,y:814,t:1527627991436};\\\", \\\"{x:1400,y:819,t:1527627991452};\\\", \\\"{x:1398,y:821,t:1527627991469};\\\", \\\"{x:1396,y:822,t:1527627991486};\\\", \\\"{x:1394,y:823,t:1527627991503};\\\", \\\"{x:1393,y:823,t:1527627991519};\\\", \\\"{x:1392,y:823,t:1527627991536};\\\", \\\"{x:1392,y:825,t:1527627991693};\\\", \\\"{x:1392,y:826,t:1527627991703};\\\", \\\"{x:1391,y:829,t:1527627991719};\\\", \\\"{x:1390,y:832,t:1527627991736};\\\", \\\"{x:1390,y:835,t:1527627991753};\\\", \\\"{x:1389,y:837,t:1527627991781};\\\", \\\"{x:1388,y:839,t:1527627991805};\\\", \\\"{x:1387,y:839,t:1527627991819};\\\", \\\"{x:1385,y:841,t:1527627991836};\\\", \\\"{x:1384,y:843,t:1527627991853};\\\", \\\"{x:1383,y:846,t:1527627991869};\\\", \\\"{x:1381,y:848,t:1527627991886};\\\", \\\"{x:1379,y:853,t:1527627991904};\\\", \\\"{x:1376,y:858,t:1527627991920};\\\", \\\"{x:1372,y:862,t:1527627991936};\\\", \\\"{x:1370,y:867,t:1527627991953};\\\", \\\"{x:1369,y:869,t:1527627991970};\\\", \\\"{x:1369,y:870,t:1527627991986};\\\", \\\"{x:1369,y:871,t:1527627992003};\\\", \\\"{x:1368,y:872,t:1527627992020};\\\", \\\"{x:1367,y:873,t:1527627992317};\\\", \\\"{x:1368,y:873,t:1527627992428};\\\", \\\"{x:1368,y:874,t:1527627992477};\\\", \\\"{x:1370,y:874,t:1527627992493};\\\", \\\"{x:1374,y:873,t:1527627992503};\\\", \\\"{x:1383,y:869,t:1527627992520};\\\", \\\"{x:1397,y:858,t:1527627992537};\\\", \\\"{x:1411,y:846,t:1527627992553};\\\", \\\"{x:1425,y:830,t:1527627992570};\\\", \\\"{x:1441,y:808,t:1527627992587};\\\", \\\"{x:1482,y:759,t:1527627992603};\\\", \\\"{x:1506,y:720,t:1527627992620};\\\", \\\"{x:1553,y:650,t:1527627992637};\\\", \\\"{x:1576,y:622,t:1527627992653};\\\", \\\"{x:1587,y:610,t:1527627992670};\\\", \\\"{x:1595,y:602,t:1527627992687};\\\", \\\"{x:1602,y:593,t:1527627992703};\\\", \\\"{x:1608,y:583,t:1527627992720};\\\", \\\"{x:1612,y:573,t:1527627992737};\\\", \\\"{x:1617,y:559,t:1527627992753};\\\", \\\"{x:1622,y:546,t:1527627992771};\\\", \\\"{x:1625,y:537,t:1527627992787};\\\", \\\"{x:1629,y:526,t:1527627992803};\\\", \\\"{x:1632,y:515,t:1527627992820};\\\", \\\"{x:1636,y:491,t:1527627992837};\\\", \\\"{x:1637,y:480,t:1527627992853};\\\", \\\"{x:1639,y:471,t:1527627992870};\\\", \\\"{x:1639,y:465,t:1527627992888};\\\", \\\"{x:1641,y:458,t:1527627992904};\\\", \\\"{x:1641,y:450,t:1527627992920};\\\", \\\"{x:1641,y:444,t:1527627992937};\\\", \\\"{x:1641,y:439,t:1527627992954};\\\", \\\"{x:1641,y:432,t:1527627992970};\\\", \\\"{x:1641,y:428,t:1527627992987};\\\", \\\"{x:1641,y:423,t:1527627993004};\\\", \\\"{x:1640,y:417,t:1527627993021};\\\", \\\"{x:1637,y:411,t:1527627993037};\\\", \\\"{x:1634,y:406,t:1527627993053};\\\", \\\"{x:1633,y:401,t:1527627993070};\\\", \\\"{x:1629,y:393,t:1527627993087};\\\", \\\"{x:1628,y:388,t:1527627993104};\\\", \\\"{x:1628,y:382,t:1527627993120};\\\", \\\"{x:1628,y:378,t:1527627993137};\\\", \\\"{x:1626,y:373,t:1527627993154};\\\", \\\"{x:1624,y:369,t:1527627993170};\\\", \\\"{x:1621,y:365,t:1527627993187};\\\", \\\"{x:1620,y:363,t:1527627993204};\\\", \\\"{x:1618,y:363,t:1527627993245};\\\", \\\"{x:1616,y:363,t:1527627993253};\\\", \\\"{x:1610,y:367,t:1527627993269};\\\", \\\"{x:1605,y:370,t:1527627993287};\\\", \\\"{x:1601,y:372,t:1527627993304};\\\", \\\"{x:1598,y:378,t:1527627993321};\\\", \\\"{x:1593,y:389,t:1527627993337};\\\", \\\"{x:1584,y:402,t:1527627993354};\\\", \\\"{x:1580,y:415,t:1527627993371};\\\", \\\"{x:1576,y:430,t:1527627993387};\\\", \\\"{x:1573,y:439,t:1527627993405};\\\", \\\"{x:1573,y:447,t:1527627993422};\\\", \\\"{x:1571,y:449,t:1527627993437};\\\", \\\"{x:1570,y:450,t:1527627993454};\\\", \\\"{x:1569,y:451,t:1527627993471};\\\", \\\"{x:1569,y:453,t:1527627993487};\\\", \\\"{x:1567,y:454,t:1527627993504};\\\", \\\"{x:1565,y:458,t:1527627993522};\\\", \\\"{x:1565,y:459,t:1527627993537};\\\", \\\"{x:1562,y:464,t:1527627993554};\\\", \\\"{x:1558,y:470,t:1527627993571};\\\", \\\"{x:1553,y:483,t:1527627993587};\\\", \\\"{x:1548,y:495,t:1527627993604};\\\", \\\"{x:1544,y:515,t:1527627993621};\\\", \\\"{x:1544,y:527,t:1527627993636};\\\", \\\"{x:1544,y:533,t:1527627993654};\\\", \\\"{x:1544,y:539,t:1527627993671};\\\", \\\"{x:1543,y:544,t:1527627993687};\\\", \\\"{x:1542,y:547,t:1527627993704};\\\", \\\"{x:1542,y:550,t:1527627993721};\\\", \\\"{x:1540,y:552,t:1527627993737};\\\", \\\"{x:1540,y:553,t:1527627993754};\\\", \\\"{x:1539,y:554,t:1527627993790};\\\", \\\"{x:1538,y:554,t:1527627993813};\\\", \\\"{x:1537,y:555,t:1527627993821};\\\", \\\"{x:1535,y:557,t:1527627993838};\\\", \\\"{x:1531,y:558,t:1527627993854};\\\", \\\"{x:1526,y:560,t:1527627993871};\\\", \\\"{x:1522,y:562,t:1527627993888};\\\", \\\"{x:1512,y:567,t:1527627993904};\\\", \\\"{x:1504,y:574,t:1527627993922};\\\", \\\"{x:1498,y:580,t:1527627993938};\\\", \\\"{x:1497,y:582,t:1527627993954};\\\", \\\"{x:1496,y:584,t:1527627993971};\\\", \\\"{x:1496,y:585,t:1527627993989};\\\", \\\"{x:1495,y:585,t:1527627994046};\\\", \\\"{x:1494,y:586,t:1527627994054};\\\", \\\"{x:1490,y:587,t:1527627994071};\\\", \\\"{x:1476,y:591,t:1527627994088};\\\", \\\"{x:1450,y:597,t:1527627994104};\\\", \\\"{x:1349,y:604,t:1527627994122};\\\", \\\"{x:1227,y:607,t:1527627994139};\\\", \\\"{x:1103,y:617,t:1527627994154};\\\", \\\"{x:997,y:623,t:1527627994171};\\\", \\\"{x:913,y:623,t:1527627994188};\\\", \\\"{x:869,y:623,t:1527627994205};\\\", \\\"{x:825,y:618,t:1527627994221};\\\", \\\"{x:807,y:609,t:1527627994239};\\\", \\\"{x:796,y:602,t:1527627994255};\\\", \\\"{x:789,y:596,t:1527627994271};\\\", \\\"{x:784,y:589,t:1527627994288};\\\", \\\"{x:779,y:577,t:1527627994305};\\\", \\\"{x:776,y:571,t:1527627994321};\\\", \\\"{x:771,y:562,t:1527627994337};\\\", \\\"{x:765,y:548,t:1527627994357};\\\", \\\"{x:755,y:533,t:1527627994371};\\\", \\\"{x:742,y:520,t:1527627994388};\\\", \\\"{x:711,y:501,t:1527627994405};\\\", \\\"{x:685,y:488,t:1527627994422};\\\", \\\"{x:655,y:475,t:1527627994439};\\\", \\\"{x:621,y:460,t:1527627994455};\\\", \\\"{x:570,y:448,t:1527627994473};\\\", \\\"{x:531,y:443,t:1527627994488};\\\", \\\"{x:502,y:441,t:1527627994505};\\\", \\\"{x:482,y:441,t:1527627994522};\\\", \\\"{x:472,y:441,t:1527627994539};\\\", \\\"{x:467,y:441,t:1527627994555};\\\", \\\"{x:465,y:441,t:1527627994572};\\\", \\\"{x:460,y:444,t:1527627994589};\\\", \\\"{x:455,y:450,t:1527627994605};\\\", \\\"{x:452,y:456,t:1527627994624};\\\", \\\"{x:450,y:462,t:1527627994640};\\\", \\\"{x:448,y:465,t:1527627994654};\\\", \\\"{x:445,y:467,t:1527627994671};\\\", \\\"{x:441,y:471,t:1527627994688};\\\", \\\"{x:438,y:474,t:1527627994704};\\\", \\\"{x:433,y:478,t:1527627994721};\\\", \\\"{x:423,y:484,t:1527627994739};\\\", \\\"{x:402,y:494,t:1527627994755};\\\", \\\"{x:389,y:501,t:1527627994771};\\\", \\\"{x:365,y:509,t:1527627994788};\\\", \\\"{x:359,y:513,t:1527627994806};\\\", \\\"{x:358,y:513,t:1527627994822};\\\", \\\"{x:358,y:514,t:1527627994869};\\\", \\\"{x:357,y:515,t:1527627994892};\\\", \\\"{x:357,y:517,t:1527627994905};\\\", \\\"{x:357,y:524,t:1527627994922};\\\", \\\"{x:359,y:533,t:1527627994939};\\\", \\\"{x:362,y:537,t:1527627994955};\\\", \\\"{x:365,y:540,t:1527627994972};\\\", \\\"{x:368,y:541,t:1527627994989};\\\", \\\"{x:369,y:541,t:1527627995006};\\\", \\\"{x:371,y:542,t:1527627995109};\\\", \\\"{x:373,y:542,t:1527627995123};\\\", \\\"{x:378,y:545,t:1527627995141};\\\", \\\"{x:385,y:546,t:1527627995156};\\\", \\\"{x:387,y:546,t:1527627995171};\\\", \\\"{x:389,y:548,t:1527627995189};\\\", \\\"{x:391,y:548,t:1527627995206};\\\", \\\"{x:394,y:552,t:1527627995516};\\\", \\\"{x:397,y:557,t:1527627995525};\\\", \\\"{x:401,y:563,t:1527627995540};\\\", \\\"{x:409,y:571,t:1527627995558};\\\", \\\"{x:414,y:579,t:1527627995572};\\\", \\\"{x:417,y:585,t:1527627995590};\\\", \\\"{x:419,y:591,t:1527627995606};\\\", \\\"{x:423,y:598,t:1527627995623};\\\", \\\"{x:428,y:608,t:1527627995640};\\\", \\\"{x:432,y:614,t:1527627995656};\\\", \\\"{x:436,y:619,t:1527627995673};\\\", \\\"{x:440,y:624,t:1527627995690};\\\", \\\"{x:448,y:628,t:1527627995705};\\\", \\\"{x:453,y:632,t:1527627995722};\\\", \\\"{x:459,y:635,t:1527627995740};\\\", \\\"{x:464,y:637,t:1527627995755};\\\", \\\"{x:479,y:642,t:1527627995772};\\\", \\\"{x:491,y:647,t:1527627995790};\\\", \\\"{x:498,y:651,t:1527627995807};\\\", \\\"{x:505,y:655,t:1527627995823};\\\", \\\"{x:507,y:658,t:1527627995839};\\\", \\\"{x:508,y:659,t:1527627995855};\\\", \\\"{x:512,y:659,t:1527627996405};\\\", \\\"{x:520,y:655,t:1527627996412};\\\", \\\"{x:525,y:653,t:1527627996423};\\\", \\\"{x:533,y:649,t:1527627996440};\\\", \\\"{x:539,y:645,t:1527627996457};\\\", \\\"{x:544,y:641,t:1527627996473};\\\", \\\"{x:553,y:637,t:1527627996491};\\\", \\\"{x:556,y:634,t:1527627996507};\\\", \\\"{x:560,y:631,t:1527627996524};\\\", \\\"{x:561,y:629,t:1527627996540};\\\", \\\"{x:562,y:628,t:1527627996557};\\\", \\\"{x:563,y:628,t:1527627996574};\\\", \\\"{x:564,y:627,t:1527627996591};\\\", \\\"{x:564,y:626,t:1527627996629};\\\", \\\"{x:565,y:625,t:1527627997059};\\\" ] }, { \\\"rt\\\": 20009, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 233225, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:566,y:622,t:1527627997227};\\\", \\\"{x:567,y:621,t:1527627998869};\\\", \\\"{x:571,y:623,t:1527627998880};\\\", \\\"{x:575,y:626,t:1527627998892};\\\", \\\"{x:594,y:637,t:1527627998908};\\\", \\\"{x:613,y:649,t:1527627998924};\\\", \\\"{x:645,y:662,t:1527627998942};\\\", \\\"{x:664,y:674,t:1527627998959};\\\", \\\"{x:691,y:684,t:1527627998975};\\\", \\\"{x:697,y:689,t:1527627998992};\\\", \\\"{x:699,y:689,t:1527627999009};\\\", \\\"{x:700,y:689,t:1527627999025};\\\", \\\"{x:700,y:690,t:1527628000901};\\\", \\\"{x:700,y:692,t:1527628000910};\\\", \\\"{x:701,y:692,t:1527628000927};\\\", \\\"{x:702,y:693,t:1527628000943};\\\", \\\"{x:703,y:693,t:1527628000960};\\\", \\\"{x:707,y:696,t:1527628000977};\\\", \\\"{x:709,y:697,t:1527628000993};\\\", \\\"{x:712,y:697,t:1527628001010};\\\", \\\"{x:718,y:701,t:1527628001027};\\\", \\\"{x:720,y:701,t:1527628001044};\\\", \\\"{x:733,y:708,t:1527628001060};\\\", \\\"{x:759,y:717,t:1527628001077};\\\", \\\"{x:778,y:728,t:1527628001093};\\\", \\\"{x:799,y:737,t:1527628001110};\\\", \\\"{x:821,y:741,t:1527628001127};\\\", \\\"{x:843,y:748,t:1527628001143};\\\", \\\"{x:862,y:753,t:1527628001160};\\\", \\\"{x:886,y:760,t:1527628001177};\\\", \\\"{x:904,y:767,t:1527628001193};\\\", \\\"{x:920,y:772,t:1527628001210};\\\", \\\"{x:933,y:775,t:1527628001227};\\\", \\\"{x:936,y:776,t:1527628001244};\\\", \\\"{x:937,y:776,t:1527628001260};\\\", \\\"{x:938,y:776,t:1527628001293};\\\", \\\"{x:940,y:777,t:1527628001301};\\\", \\\"{x:944,y:779,t:1527628001310};\\\", \\\"{x:950,y:780,t:1527628001327};\\\", \\\"{x:963,y:782,t:1527628001343};\\\", \\\"{x:981,y:787,t:1527628001360};\\\", \\\"{x:997,y:791,t:1527628001376};\\\", \\\"{x:1010,y:799,t:1527628001394};\\\", \\\"{x:1016,y:800,t:1527628001410};\\\", \\\"{x:1019,y:800,t:1527628001427};\\\", \\\"{x:1021,y:800,t:1527628001443};\\\", \\\"{x:1021,y:801,t:1527628002189};\\\", \\\"{x:1021,y:802,t:1527628002197};\\\", \\\"{x:1023,y:803,t:1527628002212};\\\", \\\"{x:1026,y:804,t:1527628002227};\\\", \\\"{x:1029,y:806,t:1527628002244};\\\", \\\"{x:1039,y:811,t:1527628002261};\\\", \\\"{x:1047,y:816,t:1527628002278};\\\", \\\"{x:1055,y:819,t:1527628002294};\\\", \\\"{x:1065,y:821,t:1527628002312};\\\", \\\"{x:1074,y:824,t:1527628002329};\\\", \\\"{x:1082,y:828,t:1527628002345};\\\", \\\"{x:1096,y:830,t:1527628002362};\\\", \\\"{x:1110,y:833,t:1527628002378};\\\", \\\"{x:1123,y:836,t:1527628002394};\\\", \\\"{x:1127,y:837,t:1527628002412};\\\", \\\"{x:1130,y:839,t:1527628002428};\\\", \\\"{x:1135,y:839,t:1527628002446};\\\", \\\"{x:1139,y:839,t:1527628002462};\\\", \\\"{x:1145,y:841,t:1527628002478};\\\", \\\"{x:1151,y:842,t:1527628002495};\\\", \\\"{x:1161,y:843,t:1527628002512};\\\", \\\"{x:1169,y:843,t:1527628002528};\\\", \\\"{x:1174,y:843,t:1527628002544};\\\", \\\"{x:1177,y:843,t:1527628002561};\\\", \\\"{x:1179,y:843,t:1527628002638};\\\", \\\"{x:1180,y:843,t:1527628002661};\\\", \\\"{x:1182,y:843,t:1527628002679};\\\", \\\"{x:1183,y:842,t:1527628002694};\\\", \\\"{x:1184,y:838,t:1527628002712};\\\", \\\"{x:1187,y:834,t:1527628002728};\\\", \\\"{x:1190,y:830,t:1527628002744};\\\", \\\"{x:1195,y:824,t:1527628002761};\\\", \\\"{x:1198,y:819,t:1527628002779};\\\", \\\"{x:1202,y:815,t:1527628002795};\\\", \\\"{x:1206,y:810,t:1527628002811};\\\", \\\"{x:1208,y:807,t:1527628002829};\\\", \\\"{x:1209,y:805,t:1527628002846};\\\", \\\"{x:1210,y:803,t:1527628002893};\\\", \\\"{x:1211,y:802,t:1527628002917};\\\", \\\"{x:1211,y:801,t:1527628002929};\\\", \\\"{x:1213,y:799,t:1527628002945};\\\", \\\"{x:1213,y:798,t:1527628002961};\\\", \\\"{x:1214,y:796,t:1527628002978};\\\", \\\"{x:1215,y:795,t:1527628002995};\\\", \\\"{x:1216,y:793,t:1527628003012};\\\", \\\"{x:1216,y:792,t:1527628003028};\\\", \\\"{x:1217,y:790,t:1527628003069};\\\", \\\"{x:1216,y:789,t:1527628003182};\\\", \\\"{x:1215,y:789,t:1527628003196};\\\", \\\"{x:1208,y:793,t:1527628003211};\\\", \\\"{x:1199,y:800,t:1527628003228};\\\", \\\"{x:1195,y:805,t:1527628003245};\\\", \\\"{x:1194,y:808,t:1527628003262};\\\", \\\"{x:1194,y:809,t:1527628003278};\\\", \\\"{x:1194,y:811,t:1527628003296};\\\", \\\"{x:1193,y:811,t:1527628003312};\\\", \\\"{x:1192,y:813,t:1527628003328};\\\", \\\"{x:1190,y:815,t:1527628003349};\\\", \\\"{x:1189,y:816,t:1527628003362};\\\", \\\"{x:1187,y:820,t:1527628003379};\\\", \\\"{x:1185,y:827,t:1527628003396};\\\", \\\"{x:1184,y:829,t:1527628003412};\\\", \\\"{x:1183,y:836,t:1527628003428};\\\", \\\"{x:1176,y:844,t:1527628003445};\\\", \\\"{x:1164,y:858,t:1527628003462};\\\", \\\"{x:1159,y:872,t:1527628003478};\\\", \\\"{x:1149,y:884,t:1527628003495};\\\", \\\"{x:1143,y:888,t:1527628003513};\\\", \\\"{x:1142,y:889,t:1527628003529};\\\", \\\"{x:1141,y:895,t:1527628003546};\\\", \\\"{x:1140,y:896,t:1527628003563};\\\", \\\"{x:1141,y:896,t:1527628003579};\\\", \\\"{x:1154,y:896,t:1527628003596};\\\", \\\"{x:1175,y:881,t:1527628003613};\\\", \\\"{x:1189,y:868,t:1527628003629};\\\", \\\"{x:1194,y:859,t:1527628003645};\\\", \\\"{x:1199,y:850,t:1527628003662};\\\", \\\"{x:1202,y:840,t:1527628003679};\\\", \\\"{x:1208,y:830,t:1527628003695};\\\", \\\"{x:1214,y:821,t:1527628003712};\\\", \\\"{x:1216,y:818,t:1527628003729};\\\", \\\"{x:1218,y:816,t:1527628003746};\\\", \\\"{x:1220,y:814,t:1527628003763};\\\", \\\"{x:1219,y:814,t:1527628003861};\\\", \\\"{x:1218,y:814,t:1527628003893};\\\", \\\"{x:1218,y:812,t:1527628004006};\\\", \\\"{x:1218,y:809,t:1527628004013};\\\", \\\"{x:1221,y:806,t:1527628004028};\\\", \\\"{x:1223,y:802,t:1527628004046};\\\", \\\"{x:1223,y:801,t:1527628004063};\\\", \\\"{x:1223,y:799,t:1527628004080};\\\", \\\"{x:1224,y:798,t:1527628004095};\\\", \\\"{x:1224,y:797,t:1527628004117};\\\", \\\"{x:1224,y:796,t:1527628004129};\\\", \\\"{x:1224,y:795,t:1527628004189};\\\", \\\"{x:1224,y:794,t:1527628004206};\\\", \\\"{x:1224,y:796,t:1527628004310};\\\", \\\"{x:1224,y:798,t:1527628004317};\\\", \\\"{x:1225,y:801,t:1527628004329};\\\", \\\"{x:1230,y:813,t:1527628004346};\\\", \\\"{x:1234,y:824,t:1527628004362};\\\", \\\"{x:1239,y:833,t:1527628004380};\\\", \\\"{x:1249,y:851,t:1527628004397};\\\", \\\"{x:1254,y:861,t:1527628004413};\\\", \\\"{x:1258,y:866,t:1527628004429};\\\", \\\"{x:1261,y:870,t:1527628004447};\\\", \\\"{x:1262,y:874,t:1527628004463};\\\", \\\"{x:1266,y:880,t:1527628004479};\\\", \\\"{x:1269,y:883,t:1527628004496};\\\", \\\"{x:1271,y:887,t:1527628004513};\\\", \\\"{x:1273,y:889,t:1527628004530};\\\", \\\"{x:1275,y:893,t:1527628004547};\\\", \\\"{x:1277,y:894,t:1527628004563};\\\", \\\"{x:1279,y:897,t:1527628004579};\\\", \\\"{x:1282,y:900,t:1527628004597};\\\", \\\"{x:1282,y:901,t:1527628004621};\\\", \\\"{x:1283,y:901,t:1527628004757};\\\", \\\"{x:1284,y:902,t:1527628004830};\\\", \\\"{x:1284,y:903,t:1527628004846};\\\", \\\"{x:1284,y:904,t:1527628004877};\\\", \\\"{x:1284,y:905,t:1527628005236};\\\", \\\"{x:1285,y:906,t:1527628005477};\\\", \\\"{x:1285,y:907,t:1527628005485};\\\", \\\"{x:1286,y:907,t:1527628005497};\\\", \\\"{x:1286,y:909,t:1527628005605};\\\", \\\"{x:1286,y:910,t:1527628005629};\\\", \\\"{x:1287,y:912,t:1527628005653};\\\", \\\"{x:1287,y:913,t:1527628005677};\\\", \\\"{x:1287,y:914,t:1527628005685};\\\", \\\"{x:1287,y:915,t:1527628005696};\\\", \\\"{x:1287,y:916,t:1527628005714};\\\", \\\"{x:1287,y:918,t:1527628005731};\\\", \\\"{x:1288,y:919,t:1527628005813};\\\", \\\"{x:1288,y:920,t:1527628005925};\\\", \\\"{x:1288,y:921,t:1527628005940};\\\", \\\"{x:1288,y:922,t:1527628005957};\\\", \\\"{x:1287,y:922,t:1527628006029};\\\", \\\"{x:1287,y:921,t:1527628006061};\\\", \\\"{x:1287,y:920,t:1527628006077};\\\", \\\"{x:1287,y:919,t:1527628006092};\\\", \\\"{x:1287,y:918,t:1527628006101};\\\", \\\"{x:1287,y:916,t:1527628006117};\\\", \\\"{x:1287,y:915,t:1527628006141};\\\", \\\"{x:1286,y:914,t:1527628006238};\\\", \\\"{x:1285,y:914,t:1527628006341};\\\", \\\"{x:1284,y:913,t:1527628006725};\\\", \\\"{x:1283,y:913,t:1527628006749};\\\", \\\"{x:1283,y:912,t:1527628006821};\\\", \\\"{x:1282,y:912,t:1527628006837};\\\", \\\"{x:1282,y:911,t:1527628006869};\\\", \\\"{x:1282,y:910,t:1527628006997};\\\", \\\"{x:1282,y:909,t:1527628007052};\\\", \\\"{x:1281,y:908,t:1527628007084};\\\", \\\"{x:1281,y:907,t:1527628007212};\\\", \\\"{x:1276,y:907,t:1527628015597};\\\", \\\"{x:1265,y:905,t:1527628015604};\\\", \\\"{x:1248,y:904,t:1527628015620};\\\", \\\"{x:1131,y:870,t:1527628015637};\\\", \\\"{x:1016,y:847,t:1527628015654};\\\", \\\"{x:915,y:811,t:1527628015670};\\\", \\\"{x:840,y:763,t:1527628015686};\\\", \\\"{x:804,y:732,t:1527628015704};\\\", \\\"{x:788,y:710,t:1527628015720};\\\", \\\"{x:779,y:690,t:1527628015737};\\\", \\\"{x:777,y:677,t:1527628015753};\\\", \\\"{x:775,y:662,t:1527628015771};\\\", \\\"{x:772,y:643,t:1527628015786};\\\", \\\"{x:765,y:626,t:1527628015803};\\\", \\\"{x:751,y:608,t:1527628015820};\\\", \\\"{x:742,y:598,t:1527628015836};\\\", \\\"{x:737,y:593,t:1527628015853};\\\", \\\"{x:726,y:588,t:1527628015870};\\\", \\\"{x:716,y:582,t:1527628015888};\\\", \\\"{x:700,y:577,t:1527628015903};\\\", \\\"{x:670,y:568,t:1527628015920};\\\", \\\"{x:646,y:563,t:1527628015937};\\\", \\\"{x:618,y:556,t:1527628015954};\\\", \\\"{x:597,y:550,t:1527628015970};\\\", \\\"{x:570,y:543,t:1527628015989};\\\", \\\"{x:549,y:539,t:1527628016005};\\\", \\\"{x:531,y:534,t:1527628016022};\\\", \\\"{x:511,y:528,t:1527628016040};\\\", \\\"{x:501,y:524,t:1527628016055};\\\", \\\"{x:493,y:521,t:1527628016072};\\\", \\\"{x:488,y:519,t:1527628016089};\\\", \\\"{x:484,y:517,t:1527628016105};\\\", \\\"{x:480,y:516,t:1527628016122};\\\", \\\"{x:478,y:516,t:1527628016139};\\\", \\\"{x:477,y:516,t:1527628016156};\\\", \\\"{x:474,y:516,t:1527628016172};\\\", \\\"{x:466,y:514,t:1527628016189};\\\", \\\"{x:458,y:514,t:1527628016205};\\\", \\\"{x:454,y:514,t:1527628016223};\\\", \\\"{x:441,y:514,t:1527628016240};\\\", \\\"{x:430,y:514,t:1527628016256};\\\", \\\"{x:421,y:514,t:1527628016273};\\\", \\\"{x:410,y:514,t:1527628016290};\\\", \\\"{x:407,y:514,t:1527628016307};\\\", \\\"{x:406,y:514,t:1527628016322};\\\", \\\"{x:406,y:513,t:1527628016388};\\\", \\\"{x:407,y:516,t:1527628016724};\\\", \\\"{x:411,y:524,t:1527628016740};\\\", \\\"{x:434,y:560,t:1527628016757};\\\", \\\"{x:448,y:581,t:1527628016773};\\\", \\\"{x:459,y:599,t:1527628016790};\\\", \\\"{x:467,y:611,t:1527628016806};\\\", \\\"{x:472,y:616,t:1527628016824};\\\", \\\"{x:474,y:618,t:1527628016839};\\\", \\\"{x:475,y:619,t:1527628016868};\\\", \\\"{x:475,y:620,t:1527628016876};\\\", \\\"{x:475,y:621,t:1527628016889};\\\", \\\"{x:475,y:623,t:1527628016907};\\\", \\\"{x:477,y:624,t:1527628016924};\\\", \\\"{x:477,y:628,t:1527628016939};\\\", \\\"{x:480,y:631,t:1527628016956};\\\", \\\"{x:485,y:638,t:1527628016973};\\\", \\\"{x:496,y:650,t:1527628016990};\\\", \\\"{x:501,y:657,t:1527628017006};\\\", \\\"{x:509,y:664,t:1527628017023};\\\", \\\"{x:520,y:671,t:1527628017040};\\\", \\\"{x:522,y:675,t:1527628017057};\\\", \\\"{x:524,y:677,t:1527628017073};\\\", \\\"{x:526,y:678,t:1527628017148};\\\", \\\"{x:527,y:678,t:1527628017173};\\\", \\\"{x:527,y:678,t:1527628017255};\\\", \\\"{x:528,y:678,t:1527628017275};\\\" ] }, { \\\"rt\\\": 41081, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 275530, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -03 PM-04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:677,t:1527628020205};\\\", \\\"{x:552,y:673,t:1527628020213};\\\", \\\"{x:585,y:683,t:1527628020229};\\\", \\\"{x:610,y:695,t:1527628020246};\\\", \\\"{x:646,y:713,t:1527628020263};\\\", \\\"{x:710,y:733,t:1527628020276};\\\", \\\"{x:805,y:763,t:1527628020292};\\\", \\\"{x:929,y:792,t:1527628020309};\\\", \\\"{x:1057,y:815,t:1527628020326};\\\", \\\"{x:1149,y:849,t:1527628020343};\\\", \\\"{x:1158,y:855,t:1527628020359};\\\", \\\"{x:1158,y:856,t:1527628020375};\\\", \\\"{x:1159,y:856,t:1527628021189};\\\", \\\"{x:1162,y:857,t:1527628021245};\\\", \\\"{x:1163,y:858,t:1527628021260};\\\", \\\"{x:1168,y:859,t:1527628021277};\\\", \\\"{x:1174,y:860,t:1527628021294};\\\", \\\"{x:1176,y:860,t:1527628021310};\\\", \\\"{x:1182,y:862,t:1527628021327};\\\", \\\"{x:1186,y:863,t:1527628021344};\\\", \\\"{x:1193,y:864,t:1527628021360};\\\", \\\"{x:1198,y:868,t:1527628021377};\\\", \\\"{x:1211,y:871,t:1527628021394};\\\", \\\"{x:1220,y:874,t:1527628021410};\\\", \\\"{x:1232,y:878,t:1527628021427};\\\", \\\"{x:1261,y:882,t:1527628021444};\\\", \\\"{x:1274,y:886,t:1527628021460};\\\", \\\"{x:1313,y:887,t:1527628021477};\\\", \\\"{x:1339,y:887,t:1527628021494};\\\", \\\"{x:1359,y:887,t:1527628021510};\\\", \\\"{x:1394,y:880,t:1527628021527};\\\", \\\"{x:1444,y:872,t:1527628021544};\\\", \\\"{x:1492,y:871,t:1527628021561};\\\", \\\"{x:1537,y:871,t:1527628021577};\\\", \\\"{x:1573,y:869,t:1527628021594};\\\", \\\"{x:1596,y:869,t:1527628021611};\\\", \\\"{x:1602,y:869,t:1527628021627};\\\", \\\"{x:1604,y:869,t:1527628021644};\\\", \\\"{x:1605,y:869,t:1527628021756};\\\", \\\"{x:1605,y:870,t:1527628021780};\\\", \\\"{x:1605,y:871,t:1527628021821};\\\", \\\"{x:1606,y:873,t:1527628021828};\\\", \\\"{x:1606,y:874,t:1527628021844};\\\", \\\"{x:1607,y:877,t:1527628021861};\\\", \\\"{x:1608,y:877,t:1527628021877};\\\", \\\"{x:1608,y:879,t:1527628021900};\\\", \\\"{x:1608,y:880,t:1527628021911};\\\", \\\"{x:1608,y:881,t:1527628021933};\\\", \\\"{x:1608,y:883,t:1527628021957};\\\", \\\"{x:1608,y:885,t:1527628021989};\\\", \\\"{x:1608,y:886,t:1527628022012};\\\", \\\"{x:1608,y:887,t:1527628022027};\\\", \\\"{x:1608,y:890,t:1527628022044};\\\", \\\"{x:1609,y:892,t:1527628022069};\\\", \\\"{x:1609,y:893,t:1527628022085};\\\", \\\"{x:1610,y:895,t:1527628022100};\\\", \\\"{x:1610,y:896,t:1527628022124};\\\", \\\"{x:1611,y:896,t:1527628022132};\\\", \\\"{x:1611,y:897,t:1527628022213};\\\", \\\"{x:1612,y:898,t:1527628022317};\\\", \\\"{x:1613,y:899,t:1527628022420};\\\", \\\"{x:1613,y:900,t:1527628022436};\\\", \\\"{x:1614,y:901,t:1527628022444};\\\", \\\"{x:1615,y:902,t:1527628022476};\\\", \\\"{x:1615,y:901,t:1527628022861};\\\", \\\"{x:1613,y:894,t:1527628022878};\\\", \\\"{x:1609,y:889,t:1527628022896};\\\", \\\"{x:1604,y:879,t:1527628022912};\\\", \\\"{x:1601,y:875,t:1527628022928};\\\", \\\"{x:1600,y:872,t:1527628022945};\\\", \\\"{x:1597,y:867,t:1527628022962};\\\", \\\"{x:1596,y:864,t:1527628022978};\\\", \\\"{x:1595,y:860,t:1527628022995};\\\", \\\"{x:1592,y:854,t:1527628023013};\\\", \\\"{x:1590,y:853,t:1527628023045};\\\", \\\"{x:1585,y:847,t:1527628023061};\\\", \\\"{x:1583,y:843,t:1527628023079};\\\", \\\"{x:1579,y:838,t:1527628023095};\\\", \\\"{x:1577,y:836,t:1527628023112};\\\", \\\"{x:1573,y:830,t:1527628023129};\\\", \\\"{x:1570,y:825,t:1527628023145};\\\", \\\"{x:1566,y:822,t:1527628023162};\\\", \\\"{x:1563,y:817,t:1527628023179};\\\", \\\"{x:1559,y:810,t:1527628023194};\\\", \\\"{x:1555,y:807,t:1527628023212};\\\", \\\"{x:1554,y:805,t:1527628023229};\\\", \\\"{x:1552,y:802,t:1527628023246};\\\", \\\"{x:1551,y:801,t:1527628023261};\\\", \\\"{x:1551,y:799,t:1527628023279};\\\", \\\"{x:1551,y:798,t:1527628023309};\\\", \\\"{x:1551,y:797,t:1527628023382};\\\", \\\"{x:1551,y:795,t:1527628024037};\\\", \\\"{x:1551,y:794,t:1527628024053};\\\", \\\"{x:1551,y:793,t:1527628024063};\\\", \\\"{x:1549,y:791,t:1527628024079};\\\", \\\"{x:1549,y:789,t:1527628024095};\\\", \\\"{x:1548,y:788,t:1527628024125};\\\", \\\"{x:1548,y:786,t:1527628024189};\\\", \\\"{x:1546,y:784,t:1527628024206};\\\", \\\"{x:1546,y:782,t:1527628024213};\\\", \\\"{x:1544,y:780,t:1527628024229};\\\", \\\"{x:1542,y:776,t:1527628024246};\\\", \\\"{x:1540,y:770,t:1527628024263};\\\", \\\"{x:1539,y:766,t:1527628024280};\\\", \\\"{x:1537,y:761,t:1527628024296};\\\", \\\"{x:1533,y:755,t:1527628024313};\\\", \\\"{x:1531,y:750,t:1527628024329};\\\", \\\"{x:1529,y:747,t:1527628024345};\\\", \\\"{x:1527,y:743,t:1527628024363};\\\", \\\"{x:1526,y:740,t:1527628024380};\\\", \\\"{x:1526,y:737,t:1527628024396};\\\", \\\"{x:1522,y:732,t:1527628024413};\\\", \\\"{x:1522,y:728,t:1527628024429};\\\", \\\"{x:1518,y:721,t:1527628024446};\\\", \\\"{x:1516,y:717,t:1527628024463};\\\", \\\"{x:1513,y:710,t:1527628024481};\\\", \\\"{x:1512,y:707,t:1527628024497};\\\", \\\"{x:1510,y:703,t:1527628024513};\\\", \\\"{x:1510,y:699,t:1527628024530};\\\", \\\"{x:1507,y:695,t:1527628024546};\\\", \\\"{x:1505,y:691,t:1527628024563};\\\", \\\"{x:1504,y:690,t:1527628024579};\\\", \\\"{x:1503,y:688,t:1527628024596};\\\", \\\"{x:1501,y:686,t:1527628024613};\\\", \\\"{x:1501,y:685,t:1527628024645};\\\", \\\"{x:1501,y:684,t:1527628024654};\\\", \\\"{x:1500,y:683,t:1527628024663};\\\", \\\"{x:1499,y:682,t:1527628024685};\\\", \\\"{x:1498,y:680,t:1527628024697};\\\", \\\"{x:1497,y:679,t:1527628024712};\\\", \\\"{x:1494,y:674,t:1527628024730};\\\", \\\"{x:1492,y:670,t:1527628024747};\\\", \\\"{x:1491,y:668,t:1527628024763};\\\", \\\"{x:1490,y:667,t:1527628024780};\\\", \\\"{x:1489,y:664,t:1527628024797};\\\", \\\"{x:1487,y:661,t:1527628024813};\\\", \\\"{x:1486,y:659,t:1527628024830};\\\", \\\"{x:1486,y:658,t:1527628024853};\\\", \\\"{x:1485,y:657,t:1527628024869};\\\", \\\"{x:1485,y:656,t:1527628024926};\\\", \\\"{x:1484,y:656,t:1527628024941};\\\", \\\"{x:1484,y:655,t:1527628024990};\\\", \\\"{x:1484,y:654,t:1527628025030};\\\", \\\"{x:1483,y:653,t:1527628025047};\\\", \\\"{x:1483,y:652,t:1527628025286};\\\", \\\"{x:1482,y:652,t:1527628025297};\\\", \\\"{x:1482,y:650,t:1527628025314};\\\", \\\"{x:1481,y:649,t:1527628025330};\\\", \\\"{x:1481,y:647,t:1527628025347};\\\", \\\"{x:1481,y:646,t:1527628025363};\\\", \\\"{x:1480,y:646,t:1527628025380};\\\", \\\"{x:1480,y:645,t:1527628025397};\\\", \\\"{x:1480,y:644,t:1527628025414};\\\", \\\"{x:1479,y:643,t:1527628025565};\\\", \\\"{x:1479,y:642,t:1527628025582};\\\", \\\"{x:1478,y:641,t:1527628025598};\\\", \\\"{x:1478,y:639,t:1527628025614};\\\", \\\"{x:1477,y:638,t:1527628025631};\\\", \\\"{x:1475,y:635,t:1527628025647};\\\", \\\"{x:1475,y:634,t:1527628025677};\\\", \\\"{x:1474,y:633,t:1527628025685};\\\", \\\"{x:1473,y:632,t:1527628025701};\\\", \\\"{x:1472,y:631,t:1527628025765};\\\", \\\"{x:1472,y:630,t:1527628025814};\\\", \\\"{x:1472,y:629,t:1527628025837};\\\", \\\"{x:1471,y:627,t:1527628025861};\\\", \\\"{x:1470,y:625,t:1527628025869};\\\", \\\"{x:1469,y:624,t:1527628025893};\\\", \\\"{x:1468,y:623,t:1527628025902};\\\", \\\"{x:1468,y:621,t:1527628025915};\\\", \\\"{x:1466,y:618,t:1527628025931};\\\", \\\"{x:1466,y:617,t:1527628025948};\\\", \\\"{x:1466,y:615,t:1527628025964};\\\", \\\"{x:1465,y:614,t:1527628025981};\\\", \\\"{x:1465,y:612,t:1527628025997};\\\", \\\"{x:1465,y:610,t:1527628026014};\\\", \\\"{x:1464,y:608,t:1527628026030};\\\", \\\"{x:1463,y:606,t:1527628026053};\\\", \\\"{x:1463,y:605,t:1527628026069};\\\", \\\"{x:1462,y:604,t:1527628026081};\\\", \\\"{x:1462,y:603,t:1527628026098};\\\", \\\"{x:1462,y:602,t:1527628026117};\\\", \\\"{x:1461,y:601,t:1527628026131};\\\", \\\"{x:1459,y:598,t:1527628026148};\\\", \\\"{x:1458,y:597,t:1527628026165};\\\", \\\"{x:1458,y:595,t:1527628026181};\\\", \\\"{x:1458,y:594,t:1527628026197};\\\", \\\"{x:1456,y:592,t:1527628026214};\\\", \\\"{x:1456,y:590,t:1527628026230};\\\", \\\"{x:1454,y:588,t:1527628026248};\\\", \\\"{x:1453,y:586,t:1527628026264};\\\", \\\"{x:1453,y:585,t:1527628026281};\\\", \\\"{x:1452,y:583,t:1527628026301};\\\", \\\"{x:1451,y:581,t:1527628026333};\\\", \\\"{x:1451,y:580,t:1527628026349};\\\", \\\"{x:1451,y:578,t:1527628026373};\\\", \\\"{x:1450,y:578,t:1527628026381};\\\", \\\"{x:1450,y:577,t:1527628026398};\\\", \\\"{x:1449,y:575,t:1527628026415};\\\", \\\"{x:1449,y:574,t:1527628026431};\\\", \\\"{x:1448,y:573,t:1527628026448};\\\", \\\"{x:1447,y:570,t:1527628026465};\\\", \\\"{x:1446,y:568,t:1527628026481};\\\", \\\"{x:1444,y:564,t:1527628026498};\\\", \\\"{x:1442,y:562,t:1527628026514};\\\", \\\"{x:1442,y:561,t:1527628026531};\\\", \\\"{x:1440,y:558,t:1527628026548};\\\", \\\"{x:1440,y:557,t:1527628026564};\\\", \\\"{x:1439,y:557,t:1527628026580};\\\", \\\"{x:1439,y:556,t:1527628026604};\\\", \\\"{x:1439,y:555,t:1527628026620};\\\", \\\"{x:1438,y:554,t:1527628026669};\\\", \\\"{x:1437,y:553,t:1527628026693};\\\", \\\"{x:1436,y:552,t:1527628026700};\\\", \\\"{x:1436,y:551,t:1527628026716};\\\", \\\"{x:1435,y:550,t:1527628026798};\\\", \\\"{x:1433,y:548,t:1527628026815};\\\", \\\"{x:1432,y:545,t:1527628026832};\\\", \\\"{x:1430,y:543,t:1527628026849};\\\", \\\"{x:1430,y:541,t:1527628026865};\\\", \\\"{x:1428,y:539,t:1527628026882};\\\", \\\"{x:1426,y:535,t:1527628026898};\\\", \\\"{x:1425,y:533,t:1527628026915};\\\", \\\"{x:1422,y:530,t:1527628026932};\\\", \\\"{x:1422,y:528,t:1527628026947};\\\", \\\"{x:1421,y:525,t:1527628026965};\\\", \\\"{x:1420,y:524,t:1527628026982};\\\", \\\"{x:1420,y:523,t:1527628027006};\\\", \\\"{x:1419,y:523,t:1527628027015};\\\", \\\"{x:1419,y:521,t:1527628027032};\\\", \\\"{x:1419,y:520,t:1527628027110};\\\", \\\"{x:1419,y:518,t:1527628027261};\\\", \\\"{x:1419,y:517,t:1527628027277};\\\", \\\"{x:1419,y:516,t:1527628027284};\\\", \\\"{x:1419,y:515,t:1527628027301};\\\", \\\"{x:1418,y:515,t:1527628027678};\\\", \\\"{x:1417,y:515,t:1527628027687};\\\", \\\"{x:1416,y:515,t:1527628027698};\\\", \\\"{x:1415,y:515,t:1527628027724};\\\", \\\"{x:1414,y:515,t:1527628027732};\\\", \\\"{x:1413,y:516,t:1527628027749};\\\", \\\"{x:1412,y:517,t:1527628027766};\\\", \\\"{x:1412,y:518,t:1527628027781};\\\", \\\"{x:1412,y:519,t:1527628027821};\\\", \\\"{x:1412,y:520,t:1527628028404};\\\", \\\"{x:1412,y:521,t:1527628028733};\\\", \\\"{x:1412,y:522,t:1527628028756};\\\", \\\"{x:1411,y:522,t:1527628028796};\\\", \\\"{x:1411,y:523,t:1527628029142};\\\", \\\"{x:1410,y:523,t:1527628029157};\\\", \\\"{x:1409,y:525,t:1527628029173};\\\", \\\"{x:1409,y:527,t:1527628029183};\\\", \\\"{x:1409,y:528,t:1527628029200};\\\", \\\"{x:1407,y:530,t:1527628029217};\\\", \\\"{x:1407,y:531,t:1527628029233};\\\", \\\"{x:1407,y:532,t:1527628029250};\\\", \\\"{x:1407,y:534,t:1527628029267};\\\", \\\"{x:1406,y:536,t:1527628029284};\\\", \\\"{x:1405,y:537,t:1527628029300};\\\", \\\"{x:1405,y:538,t:1527628029317};\\\", \\\"{x:1404,y:540,t:1527628029333};\\\", \\\"{x:1404,y:542,t:1527628029373};\\\", \\\"{x:1403,y:543,t:1527628029383};\\\", \\\"{x:1402,y:547,t:1527628029400};\\\", \\\"{x:1399,y:556,t:1527628029417};\\\", \\\"{x:1394,y:571,t:1527628029434};\\\", \\\"{x:1387,y:589,t:1527628029450};\\\", \\\"{x:1378,y:609,t:1527628029467};\\\", \\\"{x:1372,y:626,t:1527628029484};\\\", \\\"{x:1369,y:637,t:1527628029500};\\\", \\\"{x:1369,y:639,t:1527628029517};\\\", \\\"{x:1370,y:639,t:1527628029629};\\\", \\\"{x:1371,y:638,t:1527628029637};\\\", \\\"{x:1372,y:638,t:1527628029653};\\\", \\\"{x:1370,y:639,t:1527628029861};\\\", \\\"{x:1368,y:641,t:1527628029870};\\\", \\\"{x:1366,y:643,t:1527628029885};\\\", \\\"{x:1358,y:654,t:1527628029901};\\\", \\\"{x:1352,y:663,t:1527628029917};\\\", \\\"{x:1346,y:672,t:1527628029934};\\\", \\\"{x:1343,y:676,t:1527628029951};\\\", \\\"{x:1339,y:681,t:1527628029967};\\\", \\\"{x:1339,y:684,t:1527628029984};\\\", \\\"{x:1339,y:687,t:1527628030001};\\\", \\\"{x:1339,y:689,t:1527628030017};\\\", \\\"{x:1339,y:690,t:1527628030034};\\\", \\\"{x:1339,y:691,t:1527628030050};\\\", \\\"{x:1337,y:691,t:1527628031701};\\\", \\\"{x:1325,y:688,t:1527628031719};\\\", \\\"{x:1302,y:679,t:1527628031735};\\\", \\\"{x:1282,y:670,t:1527628031752};\\\", \\\"{x:1245,y:655,t:1527628031769};\\\", \\\"{x:1211,y:639,t:1527628031785};\\\", \\\"{x:1159,y:622,t:1527628031802};\\\", \\\"{x:1087,y:602,t:1527628031819};\\\", \\\"{x:1037,y:586,t:1527628031835};\\\", \\\"{x:996,y:574,t:1527628031852};\\\", \\\"{x:945,y:562,t:1527628031869};\\\", \\\"{x:927,y:560,t:1527628031884};\\\", \\\"{x:918,y:557,t:1527628031903};\\\", \\\"{x:912,y:556,t:1527628031919};\\\", \\\"{x:908,y:555,t:1527628031934};\\\", \\\"{x:895,y:552,t:1527628031951};\\\", \\\"{x:875,y:549,t:1527628031968};\\\", \\\"{x:856,y:547,t:1527628031985};\\\", \\\"{x:838,y:545,t:1527628032001};\\\", \\\"{x:810,y:542,t:1527628032018};\\\", \\\"{x:787,y:542,t:1527628032035};\\\", \\\"{x:752,y:542,t:1527628032051};\\\", \\\"{x:678,y:540,t:1527628032068};\\\", \\\"{x:625,y:539,t:1527628032085};\\\", \\\"{x:592,y:539,t:1527628032102};\\\", \\\"{x:567,y:539,t:1527628032118};\\\", \\\"{x:554,y:537,t:1527628032135};\\\", \\\"{x:554,y:535,t:1527628032151};\\\", \\\"{x:554,y:533,t:1527628032404};\\\", \\\"{x:554,y:532,t:1527628032418};\\\", \\\"{x:554,y:530,t:1527628032435};\\\", \\\"{x:554,y:529,t:1527628032460};\\\", \\\"{x:554,y:527,t:1527628032468};\\\", \\\"{x:558,y:524,t:1527628032486};\\\", \\\"{x:567,y:519,t:1527628032503};\\\", \\\"{x:574,y:515,t:1527628032518};\\\", \\\"{x:584,y:511,t:1527628032535};\\\", \\\"{x:596,y:508,t:1527628032552};\\\", \\\"{x:602,y:506,t:1527628032568};\\\", \\\"{x:605,y:504,t:1527628032586};\\\", \\\"{x:608,y:503,t:1527628032601};\\\", \\\"{x:631,y:508,t:1527628033109};\\\", \\\"{x:676,y:524,t:1527628033120};\\\", \\\"{x:781,y:548,t:1527628033136};\\\", \\\"{x:887,y:568,t:1527628033153};\\\", \\\"{x:1006,y:586,t:1527628033169};\\\", \\\"{x:1156,y:610,t:1527628033186};\\\", \\\"{x:1297,y:629,t:1527628033202};\\\", \\\"{x:1419,y:646,t:1527628033219};\\\", \\\"{x:1469,y:650,t:1527628033236};\\\", \\\"{x:1488,y:652,t:1527628033252};\\\", \\\"{x:1489,y:652,t:1527628033317};\\\", \\\"{x:1489,y:650,t:1527628033365};\\\", \\\"{x:1489,y:645,t:1527628033380};\\\", \\\"{x:1489,y:639,t:1527628033389};\\\", \\\"{x:1489,y:635,t:1527628033403};\\\", \\\"{x:1485,y:622,t:1527628033421};\\\", \\\"{x:1474,y:604,t:1527628033436};\\\", \\\"{x:1457,y:579,t:1527628033453};\\\", \\\"{x:1442,y:561,t:1527628033470};\\\", \\\"{x:1437,y:553,t:1527628033486};\\\", \\\"{x:1431,y:546,t:1527628033504};\\\", \\\"{x:1428,y:543,t:1527628033520};\\\", \\\"{x:1428,y:541,t:1527628033536};\\\", \\\"{x:1426,y:539,t:1527628033553};\\\", \\\"{x:1426,y:538,t:1527628033570};\\\", \\\"{x:1423,y:536,t:1527628033587};\\\", \\\"{x:1422,y:535,t:1527628033603};\\\", \\\"{x:1421,y:534,t:1527628033620};\\\", \\\"{x:1421,y:540,t:1527628033814};\\\", \\\"{x:1424,y:547,t:1527628033821};\\\", \\\"{x:1433,y:564,t:1527628033837};\\\", \\\"{x:1441,y:580,t:1527628033853};\\\", \\\"{x:1446,y:594,t:1527628033870};\\\", \\\"{x:1451,y:613,t:1527628033889};\\\", \\\"{x:1455,y:623,t:1527628033903};\\\", \\\"{x:1456,y:628,t:1527628033921};\\\", \\\"{x:1456,y:630,t:1527628033937};\\\", \\\"{x:1456,y:632,t:1527628033953};\\\", \\\"{x:1456,y:634,t:1527628033970};\\\", \\\"{x:1458,y:638,t:1527628033987};\\\", \\\"{x:1459,y:645,t:1527628034003};\\\", \\\"{x:1463,y:658,t:1527628034020};\\\", \\\"{x:1475,y:684,t:1527628034037};\\\", \\\"{x:1487,y:708,t:1527628034055};\\\", \\\"{x:1492,y:714,t:1527628034070};\\\", \\\"{x:1497,y:720,t:1527628034088};\\\", \\\"{x:1501,y:725,t:1527628034104};\\\", \\\"{x:1501,y:728,t:1527628034120};\\\", \\\"{x:1501,y:729,t:1527628034138};\\\", \\\"{x:1500,y:731,t:1527628034157};\\\", \\\"{x:1500,y:735,t:1527628034170};\\\", \\\"{x:1504,y:739,t:1527628034188};\\\", \\\"{x:1504,y:742,t:1527628034205};\\\", \\\"{x:1504,y:744,t:1527628034220};\\\", \\\"{x:1504,y:750,t:1527628034237};\\\", \\\"{x:1506,y:750,t:1527628034509};\\\", \\\"{x:1506,y:749,t:1527628034520};\\\", \\\"{x:1507,y:749,t:1527628034549};\\\", \\\"{x:1511,y:754,t:1527628034614};\\\", \\\"{x:1514,y:761,t:1527628034621};\\\", \\\"{x:1521,y:782,t:1527628034638};\\\", \\\"{x:1527,y:803,t:1527628034654};\\\", \\\"{x:1532,y:819,t:1527628034671};\\\", \\\"{x:1534,y:836,t:1527628034689};\\\", \\\"{x:1540,y:854,t:1527628034704};\\\", \\\"{x:1543,y:871,t:1527628034721};\\\", \\\"{x:1548,y:884,t:1527628034737};\\\", \\\"{x:1550,y:889,t:1527628034754};\\\", \\\"{x:1550,y:891,t:1527628034772};\\\", \\\"{x:1550,y:892,t:1527628034789};\\\", \\\"{x:1552,y:893,t:1527628034804};\\\", \\\"{x:1552,y:894,t:1527628034821};\\\", \\\"{x:1552,y:895,t:1527628034869};\\\", \\\"{x:1552,y:897,t:1527628034877};\\\", \\\"{x:1551,y:898,t:1527628034950};\\\", \\\"{x:1551,y:899,t:1527628034957};\\\", \\\"{x:1551,y:901,t:1527628034971};\\\", \\\"{x:1551,y:905,t:1527628034987};\\\", \\\"{x:1551,y:911,t:1527628035005};\\\", \\\"{x:1559,y:919,t:1527628035021};\\\", \\\"{x:1567,y:924,t:1527628035038};\\\", \\\"{x:1573,y:926,t:1527628035054};\\\", \\\"{x:1580,y:929,t:1527628035071};\\\", \\\"{x:1584,y:929,t:1527628035088};\\\", \\\"{x:1585,y:929,t:1527628035104};\\\", \\\"{x:1586,y:929,t:1527628035121};\\\", \\\"{x:1589,y:929,t:1527628035138};\\\", \\\"{x:1590,y:928,t:1527628035154};\\\", \\\"{x:1593,y:927,t:1527628035171};\\\", \\\"{x:1596,y:926,t:1527628035189};\\\", \\\"{x:1599,y:924,t:1527628035205};\\\", \\\"{x:1603,y:921,t:1527628035221};\\\", \\\"{x:1604,y:920,t:1527628035245};\\\", \\\"{x:1605,y:920,t:1527628035254};\\\", \\\"{x:1606,y:919,t:1527628035271};\\\", \\\"{x:1609,y:918,t:1527628035289};\\\", \\\"{x:1610,y:917,t:1527628035304};\\\", \\\"{x:1612,y:917,t:1527628035321};\\\", \\\"{x:1613,y:916,t:1527628035338};\\\", \\\"{x:1614,y:915,t:1527628035355};\\\", \\\"{x:1615,y:915,t:1527628035371};\\\", \\\"{x:1615,y:914,t:1527628035388};\\\", \\\"{x:1617,y:913,t:1527628035404};\\\", \\\"{x:1618,y:911,t:1527628035422};\\\", \\\"{x:1619,y:910,t:1527628035438};\\\", \\\"{x:1619,y:909,t:1527628035454};\\\", \\\"{x:1620,y:907,t:1527628035471};\\\", \\\"{x:1620,y:906,t:1527628035489};\\\", \\\"{x:1620,y:904,t:1527628035505};\\\", \\\"{x:1620,y:902,t:1527628035521};\\\", \\\"{x:1620,y:901,t:1527628035538};\\\", \\\"{x:1620,y:900,t:1527628035557};\\\", \\\"{x:1620,y:899,t:1527628035572};\\\", \\\"{x:1620,y:897,t:1527628035588};\\\", \\\"{x:1618,y:890,t:1527628035605};\\\", \\\"{x:1615,y:884,t:1527628035622};\\\", \\\"{x:1611,y:880,t:1527628035638};\\\", \\\"{x:1609,y:877,t:1527628035655};\\\", \\\"{x:1607,y:874,t:1527628035672};\\\", \\\"{x:1606,y:871,t:1527628035689};\\\", \\\"{x:1605,y:868,t:1527628035705};\\\", \\\"{x:1602,y:863,t:1527628035721};\\\", \\\"{x:1599,y:861,t:1527628035738};\\\", \\\"{x:1597,y:858,t:1527628035755};\\\", \\\"{x:1596,y:857,t:1527628035772};\\\", \\\"{x:1595,y:855,t:1527628035788};\\\", \\\"{x:1595,y:852,t:1527628035804};\\\", \\\"{x:1595,y:851,t:1527628035822};\\\", \\\"{x:1594,y:850,t:1527628035838};\\\", \\\"{x:1593,y:847,t:1527628035855};\\\", \\\"{x:1593,y:846,t:1527628035877};\\\", \\\"{x:1593,y:845,t:1527628035893};\\\", \\\"{x:1593,y:844,t:1527628035905};\\\", \\\"{x:1592,y:842,t:1527628035920};\\\", \\\"{x:1591,y:840,t:1527628035937};\\\", \\\"{x:1591,y:838,t:1527628035954};\\\", \\\"{x:1589,y:835,t:1527628035972};\\\", \\\"{x:1586,y:830,t:1527628035988};\\\", \\\"{x:1580,y:823,t:1527628036004};\\\", \\\"{x:1575,y:818,t:1527628036021};\\\", \\\"{x:1570,y:811,t:1527628036038};\\\", \\\"{x:1567,y:809,t:1527628036055};\\\", \\\"{x:1564,y:805,t:1527628036072};\\\", \\\"{x:1562,y:800,t:1527628036088};\\\", \\\"{x:1559,y:797,t:1527628036105};\\\", \\\"{x:1557,y:794,t:1527628036122};\\\", \\\"{x:1554,y:788,t:1527628036138};\\\", \\\"{x:1552,y:786,t:1527628036156};\\\", \\\"{x:1549,y:781,t:1527628036172};\\\", \\\"{x:1543,y:776,t:1527628036188};\\\", \\\"{x:1537,y:771,t:1527628036205};\\\", \\\"{x:1535,y:768,t:1527628036223};\\\", \\\"{x:1533,y:763,t:1527628036239};\\\", \\\"{x:1529,y:757,t:1527628036255};\\\", \\\"{x:1526,y:753,t:1527628036272};\\\", \\\"{x:1524,y:749,t:1527628036289};\\\", \\\"{x:1522,y:745,t:1527628036306};\\\", \\\"{x:1522,y:742,t:1527628036322};\\\", \\\"{x:1522,y:740,t:1527628036338};\\\", \\\"{x:1522,y:738,t:1527628036356};\\\", \\\"{x:1519,y:735,t:1527628036372};\\\", \\\"{x:1518,y:731,t:1527628036388};\\\", \\\"{x:1518,y:730,t:1527628036405};\\\", \\\"{x:1518,y:729,t:1527628036423};\\\", \\\"{x:1518,y:727,t:1527628036439};\\\", \\\"{x:1518,y:726,t:1527628036469};\\\", \\\"{x:1518,y:725,t:1527628036484};\\\", \\\"{x:1518,y:723,t:1527628036493};\\\", \\\"{x:1518,y:722,t:1527628036504};\\\", \\\"{x:1518,y:719,t:1527628036521};\\\", \\\"{x:1518,y:718,t:1527628036539};\\\", \\\"{x:1518,y:716,t:1527628036554};\\\", \\\"{x:1518,y:715,t:1527628036701};\\\", \\\"{x:1518,y:714,t:1527628036797};\\\", \\\"{x:1518,y:713,t:1527628036821};\\\", \\\"{x:1518,y:712,t:1527628036839};\\\", \\\"{x:1518,y:711,t:1527628036855};\\\", \\\"{x:1518,y:710,t:1527628036873};\\\", \\\"{x:1516,y:706,t:1527628036889};\\\", \\\"{x:1516,y:705,t:1527628036906};\\\", \\\"{x:1515,y:702,t:1527628036922};\\\", \\\"{x:1513,y:699,t:1527628036939};\\\", \\\"{x:1512,y:697,t:1527628036956};\\\", \\\"{x:1511,y:696,t:1527628036973};\\\", \\\"{x:1508,y:692,t:1527628036989};\\\", \\\"{x:1507,y:689,t:1527628037006};\\\", \\\"{x:1505,y:686,t:1527628037023};\\\", \\\"{x:1504,y:684,t:1527628037039};\\\", \\\"{x:1502,y:681,t:1527628037056};\\\", \\\"{x:1499,y:678,t:1527628037073};\\\", \\\"{x:1498,y:675,t:1527628037090};\\\", \\\"{x:1496,y:672,t:1527628037106};\\\", \\\"{x:1494,y:671,t:1527628037123};\\\", \\\"{x:1494,y:668,t:1527628037140};\\\", \\\"{x:1492,y:666,t:1527628037156};\\\", \\\"{x:1492,y:664,t:1527628037173};\\\", \\\"{x:1491,y:664,t:1527628037190};\\\", \\\"{x:1490,y:662,t:1527628037212};\\\", \\\"{x:1490,y:661,t:1527628037245};\\\", \\\"{x:1489,y:661,t:1527628037332};\\\", \\\"{x:1488,y:661,t:1527628037356};\\\", \\\"{x:1487,y:662,t:1527628043133};\\\", \\\"{x:1488,y:670,t:1527628043144};\\\", \\\"{x:1503,y:691,t:1527628043160};\\\", \\\"{x:1522,y:718,t:1527628043178};\\\", \\\"{x:1540,y:745,t:1527628043193};\\\", \\\"{x:1555,y:762,t:1527628043210};\\\", \\\"{x:1568,y:777,t:1527628043227};\\\", \\\"{x:1573,y:786,t:1527628043244};\\\", \\\"{x:1576,y:788,t:1527628043261};\\\", \\\"{x:1576,y:789,t:1527628043341};\\\", \\\"{x:1576,y:790,t:1527628043525};\\\", \\\"{x:1576,y:793,t:1527628043532};\\\", \\\"{x:1576,y:796,t:1527628043544};\\\", \\\"{x:1579,y:804,t:1527628043560};\\\", \\\"{x:1580,y:812,t:1527628043578};\\\", \\\"{x:1584,y:824,t:1527628043595};\\\", \\\"{x:1586,y:839,t:1527628043611};\\\", \\\"{x:1590,y:854,t:1527628043627};\\\", \\\"{x:1598,y:870,t:1527628043645};\\\", \\\"{x:1605,y:879,t:1527628043660};\\\", \\\"{x:1610,y:887,t:1527628043677};\\\", \\\"{x:1615,y:894,t:1527628043695};\\\", \\\"{x:1620,y:897,t:1527628043711};\\\", \\\"{x:1623,y:900,t:1527628043728};\\\", \\\"{x:1624,y:903,t:1527628043744};\\\", \\\"{x:1625,y:904,t:1527628043761};\\\", \\\"{x:1624,y:904,t:1527628044629};\\\", \\\"{x:1621,y:904,t:1527628044645};\\\", \\\"{x:1619,y:904,t:1527628044661};\\\", \\\"{x:1618,y:904,t:1527628044678};\\\", \\\"{x:1619,y:904,t:1527628045069};\\\", \\\"{x:1619,y:906,t:1527628045085};\\\", \\\"{x:1620,y:907,t:1527628045095};\\\", \\\"{x:1621,y:910,t:1527628045111};\\\", \\\"{x:1623,y:913,t:1527628045129};\\\", \\\"{x:1624,y:917,t:1527628045146};\\\", \\\"{x:1625,y:920,t:1527628045161};\\\", \\\"{x:1626,y:921,t:1527628045178};\\\", \\\"{x:1626,y:923,t:1527628045195};\\\", \\\"{x:1626,y:924,t:1527628045212};\\\", \\\"{x:1626,y:926,t:1527628045229};\\\", \\\"{x:1625,y:924,t:1527628045341};\\\", \\\"{x:1624,y:923,t:1527628045349};\\\", \\\"{x:1624,y:922,t:1527628045373};\\\", \\\"{x:1623,y:921,t:1527628045379};\\\", \\\"{x:1623,y:920,t:1527628045395};\\\", \\\"{x:1623,y:919,t:1527628045428};\\\", \\\"{x:1623,y:918,t:1527628045445};\\\", \\\"{x:1623,y:917,t:1527628045462};\\\", \\\"{x:1623,y:915,t:1527628045478};\\\", \\\"{x:1623,y:913,t:1527628045495};\\\", \\\"{x:1623,y:912,t:1527628045512};\\\", \\\"{x:1622,y:911,t:1527628045528};\\\", \\\"{x:1621,y:910,t:1527628045545};\\\", \\\"{x:1621,y:909,t:1527628045562};\\\", \\\"{x:1620,y:908,t:1527628045677};\\\", \\\"{x:1621,y:907,t:1527628055780};\\\", \\\"{x:1621,y:906,t:1527628055907};\\\", \\\"{x:1621,y:905,t:1527628055919};\\\", \\\"{x:1619,y:905,t:1527628058476};\\\", \\\"{x:1613,y:905,t:1527628058487};\\\", \\\"{x:1591,y:905,t:1527628058504};\\\", \\\"{x:1550,y:895,t:1527628058521};\\\", \\\"{x:1485,y:874,t:1527628058538};\\\", \\\"{x:1437,y:859,t:1527628058554};\\\", \\\"{x:1402,y:849,t:1527628058571};\\\", \\\"{x:1395,y:846,t:1527628058588};\\\", \\\"{x:1394,y:845,t:1527628058604};\\\", \\\"{x:1393,y:843,t:1527628058651};\\\", \\\"{x:1392,y:843,t:1527628058659};\\\", \\\"{x:1391,y:842,t:1527628058672};\\\", \\\"{x:1384,y:836,t:1527628058688};\\\", \\\"{x:1373,y:830,t:1527628058704};\\\", \\\"{x:1353,y:823,t:1527628058722};\\\", \\\"{x:1329,y:811,t:1527628058738};\\\", \\\"{x:1268,y:789,t:1527628058754};\\\", \\\"{x:1112,y:740,t:1527628058771};\\\", \\\"{x:993,y:707,t:1527628058789};\\\", \\\"{x:890,y:674,t:1527628058805};\\\", \\\"{x:820,y:649,t:1527628058821};\\\", \\\"{x:779,y:635,t:1527628058838};\\\", \\\"{x:758,y:626,t:1527628058854};\\\", \\\"{x:740,y:623,t:1527628058871};\\\", \\\"{x:723,y:623,t:1527628058888};\\\", \\\"{x:711,y:623,t:1527628058904};\\\", \\\"{x:700,y:623,t:1527628058921};\\\", \\\"{x:691,y:625,t:1527628058939};\\\", \\\"{x:687,y:626,t:1527628058955};\\\", \\\"{x:681,y:626,t:1527628058971};\\\", \\\"{x:674,y:626,t:1527628058989};\\\", \\\"{x:663,y:626,t:1527628059005};\\\", \\\"{x:656,y:626,t:1527628059021};\\\", \\\"{x:654,y:627,t:1527628059039};\\\", \\\"{x:647,y:629,t:1527628059054};\\\", \\\"{x:637,y:633,t:1527628059071};\\\", \\\"{x:624,y:638,t:1527628059088};\\\", \\\"{x:615,y:642,t:1527628059106};\\\", \\\"{x:599,y:647,t:1527628059122};\\\", \\\"{x:580,y:650,t:1527628059138};\\\", \\\"{x:559,y:653,t:1527628059156};\\\", \\\"{x:551,y:654,t:1527628059171};\\\", \\\"{x:545,y:654,t:1527628059188};\\\", \\\"{x:543,y:654,t:1527628059207};\\\", \\\"{x:542,y:655,t:1527628059223};\\\", \\\"{x:539,y:655,t:1527628059323};\\\", \\\"{x:537,y:655,t:1527628059340};\\\", \\\"{x:535,y:656,t:1527628059356};\\\", \\\"{x:534,y:658,t:1527628059379};\\\", \\\"{x:537,y:658,t:1527628060139};\\\", \\\"{x:542,y:657,t:1527628060147};\\\", \\\"{x:552,y:657,t:1527628060158};\\\", \\\"{x:573,y:657,t:1527628060173};\\\", \\\"{x:596,y:657,t:1527628060190};\\\", \\\"{x:625,y:657,t:1527628060207};\\\", \\\"{x:661,y:655,t:1527628060223};\\\", \\\"{x:717,y:655,t:1527628060241};\\\", \\\"{x:773,y:655,t:1527628060257};\\\", \\\"{x:818,y:655,t:1527628060274};\\\", \\\"{x:852,y:654,t:1527628060290};\\\", \\\"{x:888,y:653,t:1527628060308};\\\", \\\"{x:904,y:652,t:1527628060324};\\\", \\\"{x:909,y:650,t:1527628060340};\\\", \\\"{x:913,y:649,t:1527628060357};\\\", \\\"{x:916,y:648,t:1527628060374};\\\", \\\"{x:916,y:647,t:1527628060475};\\\" ] }, { \\\"rt\\\": 23358, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 300116, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:917,y:648,t:1527628064005};\\\", \\\"{x:918,y:648,t:1527628064026};\\\", \\\"{x:920,y:650,t:1527628064091};\\\", \\\"{x:922,y:651,t:1527628064115};\\\", \\\"{x:923,y:653,t:1527628064139};\\\", \\\"{x:924,y:654,t:1527628064163};\\\", \\\"{x:925,y:654,t:1527628064177};\\\", \\\"{x:929,y:658,t:1527628064194};\\\", \\\"{x:931,y:659,t:1527628064211};\\\", \\\"{x:934,y:662,t:1527628064226};\\\", \\\"{x:937,y:665,t:1527628064243};\\\", \\\"{x:938,y:665,t:1527628064268};\\\", \\\"{x:939,y:665,t:1527628064300};\\\", \\\"{x:939,y:666,t:1527628064349};\\\", \\\"{x:940,y:666,t:1527628064364};\\\", \\\"{x:941,y:667,t:1527628064378};\\\", \\\"{x:944,y:669,t:1527628064394};\\\", \\\"{x:953,y:672,t:1527628064411};\\\", \\\"{x:963,y:677,t:1527628064428};\\\", \\\"{x:969,y:682,t:1527628064444};\\\", \\\"{x:972,y:686,t:1527628064461};\\\", \\\"{x:979,y:690,t:1527628064478};\\\", \\\"{x:987,y:695,t:1527628064495};\\\", \\\"{x:996,y:698,t:1527628064511};\\\", \\\"{x:1009,y:700,t:1527628064528};\\\", \\\"{x:1015,y:704,t:1527628064544};\\\", \\\"{x:1017,y:704,t:1527628064562};\\\", \\\"{x:1019,y:706,t:1527628065205};\\\", \\\"{x:1019,y:709,t:1527628065220};\\\", \\\"{x:1022,y:710,t:1527628065228};\\\", \\\"{x:1025,y:713,t:1527628065245};\\\", \\\"{x:1034,y:718,t:1527628065262};\\\", \\\"{x:1036,y:720,t:1527628065278};\\\", \\\"{x:1037,y:720,t:1527628065341};\\\", \\\"{x:1038,y:720,t:1527628065356};\\\", \\\"{x:1051,y:719,t:1527628065540};\\\", \\\"{x:1072,y:716,t:1527628065547};\\\", \\\"{x:1093,y:714,t:1527628065561};\\\", \\\"{x:1132,y:708,t:1527628065578};\\\", \\\"{x:1164,y:698,t:1527628065595};\\\", \\\"{x:1176,y:686,t:1527628065612};\\\", \\\"{x:1179,y:686,t:1527628065629};\\\", \\\"{x:1184,y:681,t:1527628065996};\\\", \\\"{x:1202,y:664,t:1527628066012};\\\", \\\"{x:1219,y:643,t:1527628066029};\\\", \\\"{x:1228,y:622,t:1527628066046};\\\", \\\"{x:1235,y:606,t:1527628066062};\\\", \\\"{x:1241,y:595,t:1527628066080};\\\", \\\"{x:1246,y:582,t:1527628066096};\\\", \\\"{x:1246,y:573,t:1527628066112};\\\", \\\"{x:1249,y:567,t:1527628066128};\\\", \\\"{x:1250,y:556,t:1527628066146};\\\", \\\"{x:1251,y:547,t:1527628066161};\\\", \\\"{x:1256,y:535,t:1527628066179};\\\", \\\"{x:1265,y:519,t:1527628066195};\\\", \\\"{x:1270,y:511,t:1527628066211};\\\", \\\"{x:1273,y:505,t:1527628066229};\\\", \\\"{x:1283,y:495,t:1527628066246};\\\", \\\"{x:1293,y:486,t:1527628066262};\\\", \\\"{x:1303,y:477,t:1527628066279};\\\", \\\"{x:1313,y:467,t:1527628066296};\\\", \\\"{x:1321,y:460,t:1527628066312};\\\", \\\"{x:1323,y:458,t:1527628066329};\\\", \\\"{x:1326,y:455,t:1527628066346};\\\", \\\"{x:1327,y:454,t:1527628066361};\\\", \\\"{x:1328,y:452,t:1527628066477};\\\", \\\"{x:1328,y:451,t:1527628066493};\\\", \\\"{x:1326,y:451,t:1527628066501};\\\", \\\"{x:1325,y:451,t:1527628066513};\\\", \\\"{x:1323,y:450,t:1527628066529};\\\", \\\"{x:1322,y:450,t:1527628066548};\\\", \\\"{x:1322,y:449,t:1527628066597};\\\", \\\"{x:1322,y:448,t:1527628067109};\\\", \\\"{x:1311,y:447,t:1527628075006};\\\", \\\"{x:1244,y:458,t:1527628075019};\\\", \\\"{x:1167,y:458,t:1527628075035};\\\", \\\"{x:1075,y:458,t:1527628075052};\\\", \\\"{x:989,y:448,t:1527628075069};\\\", \\\"{x:937,y:437,t:1527628075085};\\\", \\\"{x:902,y:430,t:1527628075101};\\\", \\\"{x:888,y:426,t:1527628075118};\\\", \\\"{x:887,y:426,t:1527628075155};\\\", \\\"{x:887,y:424,t:1527628075169};\\\", \\\"{x:887,y:423,t:1527628075186};\\\", \\\"{x:886,y:423,t:1527628075253};\\\", \\\"{x:885,y:424,t:1527628075270};\\\", \\\"{x:879,y:433,t:1527628075286};\\\", \\\"{x:865,y:450,t:1527628075304};\\\", \\\"{x:852,y:464,t:1527628075320};\\\", \\\"{x:840,y:476,t:1527628075338};\\\", \\\"{x:833,y:482,t:1527628075353};\\\", \\\"{x:828,y:485,t:1527628075368};\\\", \\\"{x:825,y:487,t:1527628075381};\\\", \\\"{x:824,y:488,t:1527628075475};\\\", \\\"{x:824,y:490,t:1527628075499};\\\", \\\"{x:832,y:492,t:1527628075844};\\\", \\\"{x:850,y:498,t:1527628075854};\\\", \\\"{x:920,y:510,t:1527628075871};\\\", \\\"{x:1015,y:540,t:1527628075886};\\\", \\\"{x:1112,y:567,t:1527628075904};\\\", \\\"{x:1174,y:590,t:1527628075919};\\\", \\\"{x:1221,y:602,t:1527628075936};\\\", \\\"{x:1247,y:607,t:1527628075953};\\\", \\\"{x:1254,y:608,t:1527628075970};\\\", \\\"{x:1260,y:604,t:1527628075986};\\\", \\\"{x:1271,y:585,t:1527628076003};\\\", \\\"{x:1282,y:565,t:1527628076019};\\\", \\\"{x:1292,y:537,t:1527628076036};\\\", \\\"{x:1294,y:505,t:1527628076053};\\\", \\\"{x:1278,y:494,t:1527628076070};\\\", \\\"{x:1272,y:484,t:1527628076086};\\\", \\\"{x:1268,y:482,t:1527628076103};\\\", \\\"{x:1267,y:480,t:1527628076121};\\\", \\\"{x:1269,y:477,t:1527628076137};\\\", \\\"{x:1273,y:476,t:1527628076154};\\\", \\\"{x:1277,y:473,t:1527628076171};\\\", \\\"{x:1279,y:473,t:1527628076186};\\\", \\\"{x:1280,y:474,t:1527628076268};\\\", \\\"{x:1282,y:475,t:1527628076276};\\\", \\\"{x:1282,y:477,t:1527628076287};\\\", \\\"{x:1283,y:480,t:1527628076303};\\\", \\\"{x:1284,y:481,t:1527628076324};\\\", \\\"{x:1285,y:482,t:1527628076336};\\\", \\\"{x:1285,y:483,t:1527628076372};\\\", \\\"{x:1287,y:483,t:1527628076492};\\\", \\\"{x:1288,y:483,t:1527628076503};\\\", \\\"{x:1292,y:483,t:1527628076521};\\\", \\\"{x:1296,y:481,t:1527628076537};\\\", \\\"{x:1299,y:479,t:1527628076554};\\\", \\\"{x:1302,y:478,t:1527628076571};\\\", \\\"{x:1307,y:475,t:1527628076588};\\\", \\\"{x:1309,y:474,t:1527628076604};\\\", \\\"{x:1310,y:474,t:1527628076620};\\\", \\\"{x:1310,y:473,t:1527628076637};\\\", \\\"{x:1312,y:472,t:1527628076772};\\\", \\\"{x:1315,y:470,t:1527628076788};\\\", \\\"{x:1317,y:467,t:1527628076803};\\\", \\\"{x:1318,y:464,t:1527628076821};\\\", \\\"{x:1318,y:463,t:1527628076837};\\\", \\\"{x:1319,y:462,t:1527628076860};\\\", \\\"{x:1319,y:461,t:1527628077092};\\\", \\\"{x:1320,y:460,t:1527628077108};\\\", \\\"{x:1320,y:459,t:1527628077121};\\\", \\\"{x:1321,y:459,t:1527628077155};\\\", \\\"{x:1321,y:458,t:1527628077396};\\\", \\\"{x:1321,y:457,t:1527628077405};\\\", \\\"{x:1321,y:456,t:1527628077421};\\\", \\\"{x:1321,y:453,t:1527628077438};\\\", \\\"{x:1320,y:449,t:1527628077455};\\\", \\\"{x:1316,y:446,t:1527628077473};\\\", \\\"{x:1312,y:445,t:1527628077488};\\\", \\\"{x:1311,y:445,t:1527628077504};\\\", \\\"{x:1309,y:443,t:1527628077522};\\\", \\\"{x:1309,y:442,t:1527628077628};\\\", \\\"{x:1310,y:442,t:1527628078787};\\\", \\\"{x:1310,y:443,t:1527628078795};\\\", \\\"{x:1311,y:444,t:1527628078811};\\\", \\\"{x:1312,y:446,t:1527628078822};\\\", \\\"{x:1313,y:448,t:1527628078838};\\\", \\\"{x:1313,y:449,t:1527628078855};\\\", \\\"{x:1313,y:450,t:1527628078872};\\\", \\\"{x:1315,y:454,t:1527628078889};\\\", \\\"{x:1315,y:456,t:1527628078905};\\\", \\\"{x:1317,y:461,t:1527628078922};\\\", \\\"{x:1317,y:465,t:1527628078939};\\\", \\\"{x:1319,y:467,t:1527628078955};\\\", \\\"{x:1319,y:468,t:1527628079011};\\\", \\\"{x:1319,y:469,t:1527628079026};\\\", \\\"{x:1319,y:470,t:1527628079039};\\\", \\\"{x:1319,y:473,t:1527628081357};\\\", \\\"{x:1319,y:478,t:1527628081375};\\\", \\\"{x:1319,y:481,t:1527628081391};\\\", \\\"{x:1319,y:486,t:1527628081408};\\\", \\\"{x:1319,y:492,t:1527628081425};\\\", \\\"{x:1320,y:496,t:1527628081441};\\\", \\\"{x:1321,y:504,t:1527628081458};\\\", \\\"{x:1323,y:511,t:1527628081475};\\\", \\\"{x:1323,y:522,t:1527628081491};\\\", \\\"{x:1323,y:525,t:1527628081508};\\\", \\\"{x:1323,y:531,t:1527628081525};\\\", \\\"{x:1323,y:541,t:1527628081542};\\\", \\\"{x:1322,y:553,t:1527628081557};\\\", \\\"{x:1321,y:560,t:1527628081575};\\\", \\\"{x:1319,y:571,t:1527628081592};\\\", \\\"{x:1317,y:583,t:1527628081608};\\\", \\\"{x:1317,y:591,t:1527628081625};\\\", \\\"{x:1317,y:598,t:1527628081642};\\\", \\\"{x:1317,y:602,t:1527628081658};\\\", \\\"{x:1317,y:603,t:1527628081675};\\\", \\\"{x:1317,y:605,t:1527628081692};\\\", \\\"{x:1316,y:608,t:1527628082285};\\\", \\\"{x:1315,y:612,t:1527628082292};\\\", \\\"{x:1314,y:626,t:1527628082309};\\\", \\\"{x:1313,y:638,t:1527628082326};\\\", \\\"{x:1313,y:649,t:1527628082341};\\\", \\\"{x:1313,y:663,t:1527628082359};\\\", \\\"{x:1313,y:678,t:1527628082375};\\\", \\\"{x:1313,y:699,t:1527628082392};\\\", \\\"{x:1314,y:715,t:1527628082409};\\\", \\\"{x:1315,y:725,t:1527628082426};\\\", \\\"{x:1319,y:733,t:1527628082442};\\\", \\\"{x:1319,y:736,t:1527628082459};\\\", \\\"{x:1320,y:737,t:1527628082476};\\\", \\\"{x:1321,y:737,t:1527628082500};\\\", \\\"{x:1322,y:738,t:1527628082509};\\\", \\\"{x:1319,y:738,t:1527628082724};\\\", \\\"{x:1319,y:737,t:1527628082739};\\\", \\\"{x:1318,y:736,t:1527628082771};\\\", \\\"{x:1314,y:733,t:1527628083393};\\\", \\\"{x:1297,y:726,t:1527628083401};\\\", \\\"{x:1272,y:718,t:1527628083415};\\\", \\\"{x:1190,y:699,t:1527628083430};\\\", \\\"{x:1102,y:690,t:1527628083448};\\\", \\\"{x:974,y:677,t:1527628083464};\\\", \\\"{x:917,y:665,t:1527628083480};\\\", \\\"{x:891,y:663,t:1527628083497};\\\", \\\"{x:874,y:662,t:1527628083514};\\\", \\\"{x:856,y:662,t:1527628083530};\\\", \\\"{x:838,y:662,t:1527628083547};\\\", \\\"{x:820,y:664,t:1527628083564};\\\", \\\"{x:794,y:671,t:1527628083582};\\\", \\\"{x:773,y:683,t:1527628083597};\\\", \\\"{x:747,y:691,t:1527628083614};\\\", \\\"{x:708,y:697,t:1527628083631};\\\", \\\"{x:661,y:703,t:1527628083647};\\\", \\\"{x:617,y:704,t:1527628083665};\\\", \\\"{x:592,y:704,t:1527628083681};\\\", \\\"{x:567,y:704,t:1527628083698};\\\", \\\"{x:545,y:703,t:1527628083715};\\\", \\\"{x:527,y:697,t:1527628083731};\\\", \\\"{x:514,y:690,t:1527628083749};\\\", \\\"{x:511,y:687,t:1527628083764};\\\", \\\"{x:511,y:686,t:1527628083781};\\\", \\\"{x:511,y:684,t:1527628083797};\\\" ] }, { \\\"rt\\\": 25500, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 326837, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"B\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -04 PM-04 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:511,y:683,t:1527628089808};\\\", \\\"{x:522,y:685,t:1527628089830};\\\", \\\"{x:532,y:690,t:1527628089831};\\\", \\\"{x:561,y:698,t:1527628089848};\\\", \\\"{x:600,y:709,t:1527628089866};\\\", \\\"{x:645,y:724,t:1527628089882};\\\", \\\"{x:677,y:735,t:1527628089898};\\\", \\\"{x:705,y:747,t:1527628089918};\\\", \\\"{x:741,y:757,t:1527628089935};\\\", \\\"{x:762,y:762,t:1527628089952};\\\", \\\"{x:781,y:769,t:1527628089968};\\\", \\\"{x:798,y:778,t:1527628089984};\\\", \\\"{x:816,y:788,t:1527628090003};\\\", \\\"{x:834,y:796,t:1527628090018};\\\", \\\"{x:851,y:806,t:1527628090035};\\\", \\\"{x:872,y:812,t:1527628090052};\\\", \\\"{x:896,y:821,t:1527628090068};\\\", \\\"{x:913,y:824,t:1527628090085};\\\", \\\"{x:932,y:831,t:1527628090102};\\\", \\\"{x:954,y:838,t:1527628090120};\\\", \\\"{x:965,y:840,t:1527628090136};\\\", \\\"{x:970,y:842,t:1527628090152};\\\", \\\"{x:975,y:843,t:1527628090169};\\\", \\\"{x:978,y:843,t:1527628090185};\\\", \\\"{x:986,y:846,t:1527628090203};\\\", \\\"{x:1001,y:847,t:1527628090219};\\\", \\\"{x:1017,y:853,t:1527628090236};\\\", \\\"{x:1028,y:858,t:1527628090253};\\\", \\\"{x:1041,y:864,t:1527628090269};\\\", \\\"{x:1052,y:868,t:1527628090286};\\\", \\\"{x:1056,y:871,t:1527628090302};\\\", \\\"{x:1059,y:872,t:1527628090319};\\\", \\\"{x:1059,y:873,t:1527628090384};\\\", \\\"{x:1059,y:874,t:1527628090569};\\\", \\\"{x:1059,y:880,t:1527628090585};\\\", \\\"{x:1064,y:883,t:1527628090603};\\\", \\\"{x:1065,y:886,t:1527628090619};\\\", \\\"{x:1067,y:890,t:1527628090636};\\\", \\\"{x:1067,y:891,t:1527628090653};\\\", \\\"{x:1067,y:892,t:1527628090670};\\\", \\\"{x:1067,y:894,t:1527628090696};\\\", \\\"{x:1067,y:895,t:1527628090720};\\\", \\\"{x:1067,y:896,t:1527628090737};\\\", \\\"{x:1067,y:897,t:1527628090752};\\\", \\\"{x:1067,y:898,t:1527628090769};\\\", \\\"{x:1067,y:899,t:1527628090787};\\\", \\\"{x:1068,y:902,t:1527628090802};\\\", \\\"{x:1068,y:904,t:1527628090820};\\\", \\\"{x:1071,y:907,t:1527628090837};\\\", \\\"{x:1072,y:909,t:1527628090855};\\\", \\\"{x:1073,y:909,t:1527628090872};\\\", \\\"{x:1073,y:910,t:1527628090887};\\\", \\\"{x:1074,y:910,t:1527628090920};\\\", \\\"{x:1073,y:911,t:1527628091993};\\\", \\\"{x:1064,y:909,t:1527628092005};\\\", \\\"{x:1020,y:890,t:1527628092021};\\\", \\\"{x:913,y:848,t:1527628092038};\\\", \\\"{x:770,y:793,t:1527628092054};\\\", \\\"{x:654,y:736,t:1527628092071};\\\", \\\"{x:545,y:662,t:1527628092089};\\\", \\\"{x:516,y:631,t:1527628092105};\\\", \\\"{x:506,y:606,t:1527628092120};\\\", \\\"{x:504,y:582,t:1527628092137};\\\", \\\"{x:504,y:558,t:1527628092155};\\\", \\\"{x:504,y:537,t:1527628092171};\\\", \\\"{x:504,y:501,t:1527628092188};\\\", \\\"{x:494,y:469,t:1527628092205};\\\", \\\"{x:482,y:446,t:1527628092221};\\\", \\\"{x:472,y:431,t:1527628092237};\\\", \\\"{x:464,y:425,t:1527628092254};\\\", \\\"{x:457,y:423,t:1527628092270};\\\", \\\"{x:447,y:420,t:1527628092288};\\\", \\\"{x:433,y:420,t:1527628092304};\\\", \\\"{x:404,y:428,t:1527628092320};\\\", \\\"{x:360,y:438,t:1527628092337};\\\", \\\"{x:318,y:444,t:1527628092354};\\\", \\\"{x:282,y:444,t:1527628092370};\\\", \\\"{x:257,y:444,t:1527628092388};\\\", \\\"{x:249,y:444,t:1527628092404};\\\", \\\"{x:246,y:444,t:1527628092420};\\\", \\\"{x:245,y:444,t:1527628092437};\\\", \\\"{x:243,y:444,t:1527628092454};\\\", \\\"{x:239,y:446,t:1527628092471};\\\", \\\"{x:234,y:447,t:1527628092487};\\\", \\\"{x:223,y:450,t:1527628092504};\\\", \\\"{x:216,y:451,t:1527628092521};\\\", \\\"{x:209,y:452,t:1527628092537};\\\", \\\"{x:205,y:452,t:1527628092554};\\\", \\\"{x:198,y:452,t:1527628092571};\\\", \\\"{x:191,y:454,t:1527628092587};\\\", \\\"{x:184,y:454,t:1527628092604};\\\", \\\"{x:177,y:454,t:1527628092621};\\\", \\\"{x:171,y:454,t:1527628092637};\\\", \\\"{x:167,y:454,t:1527628092655};\\\", \\\"{x:167,y:453,t:1527628092703};\\\", \\\"{x:167,y:452,t:1527628093055};\\\", \\\"{x:197,y:458,t:1527628093072};\\\", \\\"{x:280,y:483,t:1527628093088};\\\", \\\"{x:400,y:522,t:1527628093105};\\\", \\\"{x:522,y:560,t:1527628093122};\\\", \\\"{x:646,y:594,t:1527628093139};\\\", \\\"{x:780,y:637,t:1527628093154};\\\", \\\"{x:888,y:670,t:1527628093171};\\\", \\\"{x:975,y:701,t:1527628093188};\\\", \\\"{x:1025,y:724,t:1527628093205};\\\", \\\"{x:1063,y:738,t:1527628093221};\\\", \\\"{x:1088,y:747,t:1527628093238};\\\", \\\"{x:1111,y:754,t:1527628093254};\\\", \\\"{x:1144,y:765,t:1527628093271};\\\", \\\"{x:1159,y:767,t:1527628093288};\\\", \\\"{x:1167,y:769,t:1527628093304};\\\", \\\"{x:1172,y:771,t:1527628093321};\\\", \\\"{x:1175,y:771,t:1527628093337};\\\", \\\"{x:1176,y:772,t:1527628093354};\\\", \\\"{x:1178,y:773,t:1527628093372};\\\", \\\"{x:1183,y:776,t:1527628093387};\\\", \\\"{x:1191,y:779,t:1527628093404};\\\", \\\"{x:1205,y:784,t:1527628093421};\\\", \\\"{x:1224,y:792,t:1527628093438};\\\", \\\"{x:1249,y:801,t:1527628093455};\\\", \\\"{x:1277,y:811,t:1527628093471};\\\", \\\"{x:1288,y:815,t:1527628093488};\\\", \\\"{x:1291,y:816,t:1527628093505};\\\", \\\"{x:1293,y:816,t:1527628093522};\\\", \\\"{x:1294,y:818,t:1527628093538};\\\", \\\"{x:1298,y:818,t:1527628093555};\\\", \\\"{x:1303,y:819,t:1527628093572};\\\", \\\"{x:1308,y:822,t:1527628093588};\\\", \\\"{x:1317,y:824,t:1527628093605};\\\", \\\"{x:1323,y:827,t:1527628093622};\\\", \\\"{x:1326,y:828,t:1527628093639};\\\", \\\"{x:1329,y:830,t:1527628093655};\\\", \\\"{x:1331,y:831,t:1527628093672};\\\", \\\"{x:1331,y:832,t:1527628093705};\\\", \\\"{x:1331,y:833,t:1527628093722};\\\", \\\"{x:1331,y:834,t:1527628093753};\\\", \\\"{x:1331,y:835,t:1527628093761};\\\", \\\"{x:1331,y:836,t:1527628093771};\\\", \\\"{x:1331,y:837,t:1527628093788};\\\", \\\"{x:1331,y:840,t:1527628093816};\\\", \\\"{x:1332,y:840,t:1527628094065};\\\", \\\"{x:1334,y:836,t:1527628094073};\\\", \\\"{x:1334,y:834,t:1527628094088};\\\", \\\"{x:1336,y:832,t:1527628094104};\\\", \\\"{x:1338,y:827,t:1527628094122};\\\", \\\"{x:1339,y:824,t:1527628094139};\\\", \\\"{x:1342,y:819,t:1527628094155};\\\", \\\"{x:1343,y:815,t:1527628094171};\\\", \\\"{x:1346,y:810,t:1527628094188};\\\", \\\"{x:1347,y:807,t:1527628094205};\\\", \\\"{x:1348,y:803,t:1527628094221};\\\", \\\"{x:1350,y:799,t:1527628094238};\\\", \\\"{x:1351,y:798,t:1527628094255};\\\", \\\"{x:1352,y:796,t:1527628094272};\\\", \\\"{x:1354,y:788,t:1527628094288};\\\", \\\"{x:1356,y:781,t:1527628094305};\\\", \\\"{x:1356,y:778,t:1527628094321};\\\", \\\"{x:1356,y:773,t:1527628094339};\\\", \\\"{x:1356,y:768,t:1527628094355};\\\", \\\"{x:1356,y:762,t:1527628094371};\\\", \\\"{x:1357,y:759,t:1527628094389};\\\", \\\"{x:1357,y:756,t:1527628094404};\\\", \\\"{x:1357,y:754,t:1527628094421};\\\", \\\"{x:1357,y:752,t:1527628094438};\\\", \\\"{x:1357,y:749,t:1527628094454};\\\", \\\"{x:1357,y:748,t:1527628094471};\\\", \\\"{x:1357,y:747,t:1527628094489};\\\", \\\"{x:1355,y:748,t:1527628094553};\\\", \\\"{x:1354,y:748,t:1527628094600};\\\", \\\"{x:1355,y:748,t:1527628094680};\\\", \\\"{x:1357,y:748,t:1527628094688};\\\", \\\"{x:1359,y:745,t:1527628094704};\\\", \\\"{x:1361,y:741,t:1527628094720};\\\", \\\"{x:1361,y:740,t:1527628094738};\\\", \\\"{x:1362,y:738,t:1527628094754};\\\", \\\"{x:1363,y:735,t:1527628094771};\\\", \\\"{x:1363,y:734,t:1527628094788};\\\", \\\"{x:1363,y:732,t:1527628094804};\\\", \\\"{x:1363,y:731,t:1527628094821};\\\", \\\"{x:1363,y:729,t:1527628094838};\\\", \\\"{x:1363,y:728,t:1527628094897};\\\", \\\"{x:1363,y:727,t:1527628095055};\\\", \\\"{x:1362,y:727,t:1527628095088};\\\", \\\"{x:1360,y:727,t:1527628095104};\\\", \\\"{x:1358,y:727,t:1527628095121};\\\", \\\"{x:1357,y:727,t:1527628095136};\\\", \\\"{x:1355,y:726,t:1527628095175};\\\", \\\"{x:1355,y:725,t:1527628095200};\\\", \\\"{x:1355,y:723,t:1527628095207};\\\", \\\"{x:1355,y:721,t:1527628095223};\\\", \\\"{x:1355,y:719,t:1527628095236};\\\", \\\"{x:1353,y:718,t:1527628095254};\\\", \\\"{x:1353,y:717,t:1527628095271};\\\", \\\"{x:1352,y:717,t:1527628095305};\\\", \\\"{x:1352,y:716,t:1527628095472};\\\", \\\"{x:1352,y:715,t:1527628095529};\\\", \\\"{x:1352,y:713,t:1527628096771};\\\", \\\"{x:1350,y:714,t:1527628097913};\\\", \\\"{x:1350,y:715,t:1527628101640};\\\", \\\"{x:1344,y:718,t:1527628101652};\\\", \\\"{x:1289,y:718,t:1527628101666};\\\", \\\"{x:1171,y:690,t:1527628101682};\\\", \\\"{x:1047,y:658,t:1527628101699};\\\", \\\"{x:943,y:624,t:1527628101717};\\\", \\\"{x:856,y:591,t:1527628101732};\\\", \\\"{x:776,y:571,t:1527628101751};\\\", \\\"{x:747,y:560,t:1527628101767};\\\", \\\"{x:716,y:547,t:1527628101783};\\\", \\\"{x:696,y:539,t:1527628101794};\\\", \\\"{x:692,y:537,t:1527628101811};\\\", \\\"{x:690,y:534,t:1527628101827};\\\", \\\"{x:689,y:528,t:1527628101844};\\\", \\\"{x:687,y:516,t:1527628101860};\\\", \\\"{x:685,y:506,t:1527628101878};\\\", \\\"{x:684,y:500,t:1527628101895};\\\", \\\"{x:684,y:495,t:1527628101911};\\\", \\\"{x:693,y:490,t:1527628101928};\\\", \\\"{x:706,y:484,t:1527628101945};\\\", \\\"{x:726,y:482,t:1527628101962};\\\", \\\"{x:754,y:482,t:1527628101978};\\\", \\\"{x:809,y:486,t:1527628101995};\\\", \\\"{x:862,y:494,t:1527628102012};\\\", \\\"{x:898,y:496,t:1527628102029};\\\", \\\"{x:920,y:499,t:1527628102044};\\\", \\\"{x:922,y:500,t:1527628102062};\\\", \\\"{x:919,y:501,t:1527628102087};\\\", \\\"{x:915,y:501,t:1527628102095};\\\", \\\"{x:901,y:501,t:1527628102112};\\\", \\\"{x:886,y:501,t:1527628102129};\\\", \\\"{x:860,y:501,t:1527628102144};\\\", \\\"{x:831,y:501,t:1527628102162};\\\", \\\"{x:798,y:498,t:1527628102178};\\\", \\\"{x:775,y:492,t:1527628102196};\\\", \\\"{x:756,y:488,t:1527628102212};\\\", \\\"{x:742,y:487,t:1527628102229};\\\", \\\"{x:720,y:481,t:1527628102246};\\\", \\\"{x:693,y:479,t:1527628102261};\\\", \\\"{x:669,y:476,t:1527628102279};\\\", \\\"{x:653,y:476,t:1527628102295};\\\", \\\"{x:651,y:476,t:1527628102312};\\\", \\\"{x:650,y:476,t:1527628102329};\\\", \\\"{x:649,y:479,t:1527628102345};\\\", \\\"{x:649,y:483,t:1527628102361};\\\", \\\"{x:658,y:490,t:1527628102379};\\\", \\\"{x:678,y:498,t:1527628102396};\\\", \\\"{x:720,y:511,t:1527628102413};\\\", \\\"{x:780,y:523,t:1527628102429};\\\", \\\"{x:819,y:529,t:1527628102446};\\\", \\\"{x:833,y:531,t:1527628102461};\\\", \\\"{x:834,y:531,t:1527628102479};\\\", \\\"{x:836,y:531,t:1527628102600};\\\", \\\"{x:838,y:531,t:1527628102612};\\\", \\\"{x:839,y:531,t:1527628102629};\\\", \\\"{x:840,y:531,t:1527628102646};\\\", \\\"{x:839,y:531,t:1527628102736};\\\", \\\"{x:839,y:533,t:1527628103128};\\\", \\\"{x:854,y:542,t:1527628103137};\\\", \\\"{x:883,y:556,t:1527628103146};\\\", \\\"{x:976,y:593,t:1527628103163};\\\", \\\"{x:1090,y:629,t:1527628103179};\\\", \\\"{x:1199,y:666,t:1527628103196};\\\", \\\"{x:1312,y:699,t:1527628103213};\\\", \\\"{x:1424,y:721,t:1527628103229};\\\", \\\"{x:1474,y:732,t:1527628103246};\\\", \\\"{x:1496,y:736,t:1527628103263};\\\", \\\"{x:1501,y:738,t:1527628103279};\\\", \\\"{x:1502,y:738,t:1527628103303};\\\", \\\"{x:1503,y:738,t:1527628103319};\\\", \\\"{x:1505,y:737,t:1527628103329};\\\", \\\"{x:1506,y:736,t:1527628103346};\\\", \\\"{x:1507,y:736,t:1527628103363};\\\", \\\"{x:1509,y:736,t:1527628103423};\\\", \\\"{x:1510,y:734,t:1527628103431};\\\", \\\"{x:1511,y:734,t:1527628103464};\\\", \\\"{x:1512,y:733,t:1527628103487};\\\", \\\"{x:1513,y:732,t:1527628103633};\\\", \\\"{x:1513,y:731,t:1527628103704};\\\", \\\"{x:1513,y:730,t:1527628103714};\\\", \\\"{x:1514,y:729,t:1527628103730};\\\", \\\"{x:1514,y:728,t:1527628103761};\\\", \\\"{x:1514,y:727,t:1527628103808};\\\", \\\"{x:1513,y:727,t:1527628104097};\\\", \\\"{x:1513,y:728,t:1527628104114};\\\", \\\"{x:1512,y:732,t:1527628104131};\\\", \\\"{x:1512,y:734,t:1527628104148};\\\", \\\"{x:1511,y:735,t:1527628104164};\\\", \\\"{x:1511,y:736,t:1527628104184};\\\", \\\"{x:1510,y:737,t:1527628104472};\\\", \\\"{x:1510,y:738,t:1527628104481};\\\", \\\"{x:1509,y:743,t:1527628104497};\\\", \\\"{x:1508,y:747,t:1527628104514};\\\", \\\"{x:1506,y:751,t:1527628104531};\\\", \\\"{x:1504,y:753,t:1527628104547};\\\", \\\"{x:1504,y:754,t:1527628104564};\\\", \\\"{x:1504,y:756,t:1527628104582};\\\", \\\"{x:1503,y:757,t:1527628104597};\\\", \\\"{x:1502,y:759,t:1527628104614};\\\", \\\"{x:1502,y:761,t:1527628104631};\\\", \\\"{x:1501,y:762,t:1527628104648};\\\", \\\"{x:1501,y:763,t:1527628104664};\\\", \\\"{x:1500,y:766,t:1527628104681};\\\", \\\"{x:1499,y:766,t:1527628104697};\\\", \\\"{x:1499,y:769,t:1527628104715};\\\", \\\"{x:1496,y:774,t:1527628104731};\\\", \\\"{x:1495,y:779,t:1527628104747};\\\", \\\"{x:1493,y:785,t:1527628104765};\\\", \\\"{x:1492,y:788,t:1527628104781};\\\", \\\"{x:1490,y:793,t:1527628104796};\\\", \\\"{x:1487,y:799,t:1527628104814};\\\", \\\"{x:1487,y:801,t:1527628104831};\\\", \\\"{x:1484,y:806,t:1527628104846};\\\", \\\"{x:1482,y:812,t:1527628104863};\\\", \\\"{x:1480,y:816,t:1527628104881};\\\", \\\"{x:1477,y:822,t:1527628104896};\\\", \\\"{x:1475,y:826,t:1527628104914};\\\", \\\"{x:1471,y:834,t:1527628104931};\\\", \\\"{x:1469,y:843,t:1527628104947};\\\", \\\"{x:1467,y:851,t:1527628104964};\\\", \\\"{x:1464,y:857,t:1527628104981};\\\", \\\"{x:1462,y:861,t:1527628104998};\\\", \\\"{x:1459,y:866,t:1527628105014};\\\", \\\"{x:1459,y:867,t:1527628105031};\\\", \\\"{x:1459,y:869,t:1527628105048};\\\", \\\"{x:1459,y:873,t:1527628105064};\\\", \\\"{x:1458,y:874,t:1527628105082};\\\", \\\"{x:1457,y:875,t:1527628105098};\\\", \\\"{x:1459,y:869,t:1527628105192};\\\", \\\"{x:1463,y:857,t:1527628105199};\\\", \\\"{x:1469,y:846,t:1527628105214};\\\", \\\"{x:1480,y:815,t:1527628105231};\\\", \\\"{x:1497,y:774,t:1527628105247};\\\", \\\"{x:1504,y:757,t:1527628105264};\\\", \\\"{x:1513,y:744,t:1527628105281};\\\", \\\"{x:1516,y:740,t:1527628105298};\\\", \\\"{x:1517,y:738,t:1527628105314};\\\", \\\"{x:1518,y:738,t:1527628105351};\\\", \\\"{x:1518,y:739,t:1527628105392};\\\", \\\"{x:1518,y:744,t:1527628105399};\\\", \\\"{x:1518,y:751,t:1527628105414};\\\", \\\"{x:1518,y:757,t:1527628105431};\\\", \\\"{x:1523,y:773,t:1527628105448};\\\", \\\"{x:1533,y:791,t:1527628105465};\\\", \\\"{x:1544,y:810,t:1527628105481};\\\", \\\"{x:1559,y:831,t:1527628105498};\\\", \\\"{x:1572,y:849,t:1527628105515};\\\", \\\"{x:1585,y:863,t:1527628105531};\\\", \\\"{x:1592,y:871,t:1527628105548};\\\", \\\"{x:1596,y:875,t:1527628105565};\\\", \\\"{x:1597,y:878,t:1527628105581};\\\", \\\"{x:1597,y:879,t:1527628105598};\\\", \\\"{x:1598,y:881,t:1527628105615};\\\", \\\"{x:1599,y:883,t:1527628105631};\\\", \\\"{x:1599,y:884,t:1527628105648};\\\", \\\"{x:1599,y:886,t:1527628105666};\\\", \\\"{x:1600,y:887,t:1527628105681};\\\", \\\"{x:1602,y:892,t:1527628105698};\\\", \\\"{x:1604,y:897,t:1527628105715};\\\", \\\"{x:1607,y:904,t:1527628105731};\\\", \\\"{x:1611,y:911,t:1527628105748};\\\", \\\"{x:1613,y:917,t:1527628105766};\\\", \\\"{x:1617,y:922,t:1527628105781};\\\", \\\"{x:1622,y:930,t:1527628105798};\\\", \\\"{x:1626,y:936,t:1527628105816};\\\", \\\"{x:1627,y:937,t:1527628105832};\\\", \\\"{x:1627,y:935,t:1527628105984};\\\", \\\"{x:1627,y:929,t:1527628105999};\\\", \\\"{x:1620,y:911,t:1527628106016};\\\", \\\"{x:1592,y:867,t:1527628106033};\\\", \\\"{x:1568,y:835,t:1527628106048};\\\", \\\"{x:1546,y:808,t:1527628106066};\\\", \\\"{x:1532,y:785,t:1527628106082};\\\", \\\"{x:1520,y:762,t:1527628106099};\\\", \\\"{x:1512,y:746,t:1527628106116};\\\", \\\"{x:1505,y:735,t:1527628106133};\\\", \\\"{x:1494,y:724,t:1527628106149};\\\", \\\"{x:1486,y:720,t:1527628106165};\\\", \\\"{x:1478,y:716,t:1527628106182};\\\", \\\"{x:1469,y:714,t:1527628106199};\\\", \\\"{x:1457,y:711,t:1527628106215};\\\", \\\"{x:1440,y:711,t:1527628106232};\\\", \\\"{x:1429,y:711,t:1527628106249};\\\", \\\"{x:1416,y:711,t:1527628106266};\\\", \\\"{x:1400,y:711,t:1527628106281};\\\", \\\"{x:1383,y:711,t:1527628106298};\\\", \\\"{x:1368,y:711,t:1527628106315};\\\", \\\"{x:1360,y:711,t:1527628106332};\\\", \\\"{x:1357,y:711,t:1527628106348};\\\", \\\"{x:1356,y:711,t:1527628106681};\\\", \\\"{x:1355,y:711,t:1527628106688};\\\", \\\"{x:1354,y:711,t:1527628106700};\\\", \\\"{x:1353,y:711,t:1527628106721};\\\", \\\"{x:1352,y:711,t:1527628106732};\\\", \\\"{x:1351,y:711,t:1527628106752};\\\", \\\"{x:1350,y:711,t:1527628106792};\\\", \\\"{x:1349,y:711,t:1527628107064};\\\", \\\"{x:1348,y:712,t:1527628107072};\\\", \\\"{x:1348,y:713,t:1527628107096};\\\", \\\"{x:1348,y:714,t:1527628107488};\\\", \\\"{x:1348,y:717,t:1527628107500};\\\", \\\"{x:1348,y:720,t:1527628107517};\\\", \\\"{x:1348,y:722,t:1527628107533};\\\", \\\"{x:1347,y:726,t:1527628107550};\\\", \\\"{x:1346,y:728,t:1527628107566};\\\", \\\"{x:1345,y:733,t:1527628107584};\\\", \\\"{x:1345,y:736,t:1527628107600};\\\", \\\"{x:1344,y:738,t:1527628107616};\\\", \\\"{x:1343,y:742,t:1527628107634};\\\", \\\"{x:1341,y:744,t:1527628107650};\\\", \\\"{x:1341,y:748,t:1527628107667};\\\", \\\"{x:1340,y:749,t:1527628107683};\\\", \\\"{x:1338,y:753,t:1527628107700};\\\", \\\"{x:1337,y:756,t:1527628107717};\\\", \\\"{x:1337,y:760,t:1527628107734};\\\", \\\"{x:1333,y:766,t:1527628107749};\\\", \\\"{x:1332,y:772,t:1527628107767};\\\", \\\"{x:1330,y:783,t:1527628107783};\\\", \\\"{x:1327,y:795,t:1527628107800};\\\", \\\"{x:1322,y:808,t:1527628107817};\\\", \\\"{x:1318,y:818,t:1527628107833};\\\", \\\"{x:1315,y:829,t:1527628107851};\\\", \\\"{x:1308,y:840,t:1527628107867};\\\", \\\"{x:1304,y:842,t:1527628107884};\\\", \\\"{x:1304,y:845,t:1527628107901};\\\", \\\"{x:1301,y:850,t:1527628107917};\\\", \\\"{x:1300,y:854,t:1527628107934};\\\", \\\"{x:1299,y:856,t:1527628107951};\\\", \\\"{x:1299,y:857,t:1527628107967};\\\", \\\"{x:1298,y:859,t:1527628107984};\\\", \\\"{x:1298,y:860,t:1527628108001};\\\", \\\"{x:1301,y:855,t:1527628108184};\\\", \\\"{x:1313,y:839,t:1527628108200};\\\", \\\"{x:1321,y:816,t:1527628108216};\\\", \\\"{x:1322,y:805,t:1527628108233};\\\", \\\"{x:1325,y:792,t:1527628108251};\\\", \\\"{x:1326,y:786,t:1527628108267};\\\", \\\"{x:1328,y:782,t:1527628108283};\\\", \\\"{x:1328,y:780,t:1527628108300};\\\", \\\"{x:1328,y:779,t:1527628108316};\\\", \\\"{x:1328,y:777,t:1527628108335};\\\", \\\"{x:1328,y:776,t:1527628108350};\\\", \\\"{x:1329,y:772,t:1527628108367};\\\", \\\"{x:1333,y:764,t:1527628108383};\\\", \\\"{x:1335,y:762,t:1527628108400};\\\", \\\"{x:1336,y:759,t:1527628108417};\\\", \\\"{x:1336,y:758,t:1527628108433};\\\", \\\"{x:1338,y:755,t:1527628108450};\\\", \\\"{x:1341,y:753,t:1527628108467};\\\", \\\"{x:1344,y:750,t:1527628108483};\\\", \\\"{x:1344,y:748,t:1527628108500};\\\", \\\"{x:1345,y:746,t:1527628108518};\\\", \\\"{x:1345,y:745,t:1527628108533};\\\", \\\"{x:1334,y:739,t:1527628108550};\\\", \\\"{x:1232,y:718,t:1527628108567};\\\", \\\"{x:1166,y:703,t:1527628108583};\\\", \\\"{x:910,y:638,t:1527628108600};\\\", \\\"{x:767,y:601,t:1527628108617};\\\", \\\"{x:647,y:563,t:1527628108634};\\\", \\\"{x:563,y:532,t:1527628108650};\\\", \\\"{x:537,y:519,t:1527628108666};\\\", \\\"{x:530,y:516,t:1527628108675};\\\", \\\"{x:529,y:514,t:1527628108692};\\\", \\\"{x:528,y:510,t:1527628108710};\\\", \\\"{x:528,y:506,t:1527628108726};\\\", \\\"{x:527,y:498,t:1527628108744};\\\", \\\"{x:505,y:476,t:1527628108767};\\\", \\\"{x:488,y:458,t:1527628108784};\\\", \\\"{x:475,y:441,t:1527628108800};\\\", \\\"{x:459,y:434,t:1527628108817};\\\", \\\"{x:454,y:433,t:1527628108835};\\\", \\\"{x:452,y:433,t:1527628108850};\\\", \\\"{x:448,y:433,t:1527628108867};\\\", \\\"{x:447,y:433,t:1527628108884};\\\", \\\"{x:446,y:436,t:1527628108901};\\\", \\\"{x:444,y:439,t:1527628108917};\\\", \\\"{x:439,y:442,t:1527628108934};\\\", \\\"{x:436,y:446,t:1527628108951};\\\", \\\"{x:435,y:452,t:1527628108967};\\\", \\\"{x:434,y:456,t:1527628108984};\\\", \\\"{x:433,y:460,t:1527628109001};\\\", \\\"{x:429,y:465,t:1527628109018};\\\", \\\"{x:425,y:467,t:1527628109034};\\\", \\\"{x:418,y:469,t:1527628109051};\\\", \\\"{x:408,y:473,t:1527628109068};\\\", \\\"{x:392,y:475,t:1527628109084};\\\", \\\"{x:362,y:475,t:1527628109101};\\\", \\\"{x:298,y:477,t:1527628109117};\\\", \\\"{x:249,y:479,t:1527628109135};\\\", \\\"{x:212,y:483,t:1527628109151};\\\", \\\"{x:192,y:488,t:1527628109167};\\\", \\\"{x:181,y:495,t:1527628109184};\\\", \\\"{x:178,y:499,t:1527628109201};\\\", \\\"{x:176,y:503,t:1527628109217};\\\", \\\"{x:176,y:506,t:1527628109234};\\\", \\\"{x:173,y:511,t:1527628109252};\\\", \\\"{x:170,y:515,t:1527628109268};\\\", \\\"{x:165,y:523,t:1527628109284};\\\", \\\"{x:160,y:530,t:1527628109301};\\\", \\\"{x:159,y:535,t:1527628109318};\\\", \\\"{x:158,y:537,t:1527628109334};\\\", \\\"{x:158,y:536,t:1527628109375};\\\", \\\"{x:159,y:534,t:1527628109384};\\\", \\\"{x:161,y:528,t:1527628109401};\\\", \\\"{x:164,y:523,t:1527628109418};\\\", \\\"{x:164,y:519,t:1527628109434};\\\", \\\"{x:164,y:514,t:1527628109451};\\\", \\\"{x:164,y:511,t:1527628109468};\\\", \\\"{x:164,y:510,t:1527628109484};\\\", \\\"{x:165,y:506,t:1527628109501};\\\", \\\"{x:167,y:504,t:1527628109518};\\\", \\\"{x:168,y:503,t:1527628109534};\\\", \\\"{x:168,y:502,t:1527628109561};\\\", \\\"{x:168,y:501,t:1527628109582};\\\", \\\"{x:168,y:500,t:1527628109591};\\\", \\\"{x:168,y:498,t:1527628109607};\\\", \\\"{x:168,y:497,t:1527628109631};\\\", \\\"{x:175,y:502,t:1527628109879};\\\", \\\"{x:188,y:511,t:1527628109887};\\\", \\\"{x:208,y:522,t:1527628109901};\\\", \\\"{x:250,y:552,t:1527628109919};\\\", \\\"{x:375,y:619,t:1527628109935};\\\", \\\"{x:404,y:634,t:1527628109951};\\\", \\\"{x:409,y:638,t:1527628109968};\\\", \\\"{x:420,y:644,t:1527628109985};\\\", \\\"{x:429,y:648,t:1527628110001};\\\", \\\"{x:430,y:648,t:1527628110018};\\\", \\\"{x:429,y:648,t:1527628110063};\\\", \\\"{x:425,y:646,t:1527628110072};\\\", \\\"{x:421,y:641,t:1527628110085};\\\", \\\"{x:411,y:630,t:1527628110101};\\\", \\\"{x:403,y:620,t:1527628110119};\\\", \\\"{x:400,y:616,t:1527628110136};\\\", \\\"{x:399,y:613,t:1527628110151};\\\", \\\"{x:400,y:615,t:1527628110215};\\\", \\\"{x:401,y:619,t:1527628110224};\\\", \\\"{x:408,y:624,t:1527628110235};\\\", \\\"{x:428,y:638,t:1527628110252};\\\", \\\"{x:452,y:666,t:1527628110268};\\\", \\\"{x:472,y:673,t:1527628110285};\\\", \\\"{x:496,y:685,t:1527628110302};\\\", \\\"{x:507,y:691,t:1527628110318};\\\", \\\"{x:522,y:696,t:1527628110334};\\\", \\\"{x:523,y:696,t:1527628110351};\\\", \\\"{x:522,y:696,t:1527628110408};\\\", \\\"{x:520,y:694,t:1527628110418};\\\", \\\"{x:513,y:689,t:1527628110435};\\\", \\\"{x:499,y:683,t:1527628110452};\\\", \\\"{x:491,y:677,t:1527628110469};\\\", \\\"{x:477,y:670,t:1527628110485};\\\", \\\"{x:467,y:665,t:1527628110503};\\\", \\\"{x:466,y:665,t:1527628110520};\\\", \\\"{x:467,y:667,t:1527628110601};\\\", \\\"{x:470,y:672,t:1527628110618};\\\", \\\"{x:474,y:676,t:1527628110635};\\\", \\\"{x:479,y:680,t:1527628110651};\\\", \\\"{x:484,y:681,t:1527628110669};\\\", \\\"{x:486,y:681,t:1527628110685};\\\", \\\"{x:490,y:681,t:1527628110702};\\\", \\\"{x:493,y:680,t:1527628110719};\\\" ] }, { \\\"rt\\\": 87268, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 415328, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -11 AM-11 AM-J -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:678,t:1527628118536};\\\", \\\"{x:500,y:676,t:1527628118551};\\\", \\\"{x:512,y:673,t:1527628118568};\\\", \\\"{x:532,y:673,t:1527628118585};\\\", \\\"{x:555,y:673,t:1527628118602};\\\", \\\"{x:577,y:672,t:1527628118619};\\\", \\\"{x:604,y:672,t:1527628118635};\\\", \\\"{x:639,y:669,t:1527628118652};\\\", \\\"{x:688,y:658,t:1527628118674};\\\", \\\"{x:723,y:652,t:1527628118691};\\\", \\\"{x:765,y:646,t:1527628118708};\\\", \\\"{x:795,y:640,t:1527628118724};\\\", \\\"{x:828,y:633,t:1527628118741};\\\", \\\"{x:858,y:624,t:1527628118758};\\\", \\\"{x:916,y:616,t:1527628118774};\\\", \\\"{x:990,y:602,t:1527628118791};\\\", \\\"{x:1005,y:601,t:1527628118809};\\\", \\\"{x:1011,y:601,t:1527628118826};\\\", \\\"{x:1013,y:601,t:1527628118841};\\\", \\\"{x:1013,y:602,t:1527628118983};\\\", \\\"{x:1013,y:603,t:1527628119015};\\\", \\\"{x:1013,y:604,t:1527628119063};\\\", \\\"{x:1015,y:604,t:1527628119076};\\\", \\\"{x:1020,y:603,t:1527628119092};\\\", \\\"{x:1025,y:600,t:1527628119109};\\\", \\\"{x:1032,y:598,t:1527628119125};\\\", \\\"{x:1037,y:595,t:1527628119141};\\\", \\\"{x:1042,y:593,t:1527628119158};\\\", \\\"{x:1043,y:593,t:1527628119176};\\\", \\\"{x:1045,y:592,t:1527628119191};\\\", \\\"{x:1053,y:592,t:1527628119208};\\\", \\\"{x:1065,y:592,t:1527628119226};\\\", \\\"{x:1082,y:592,t:1527628119242};\\\", \\\"{x:1103,y:592,t:1527628119259};\\\", \\\"{x:1121,y:592,t:1527628119276};\\\", \\\"{x:1144,y:592,t:1527628119292};\\\", \\\"{x:1165,y:592,t:1527628119308};\\\", \\\"{x:1185,y:590,t:1527628119326};\\\", \\\"{x:1194,y:588,t:1527628119343};\\\", \\\"{x:1204,y:586,t:1527628119358};\\\", \\\"{x:1228,y:586,t:1527628119374};\\\", \\\"{x:1243,y:586,t:1527628119392};\\\", \\\"{x:1251,y:585,t:1527628119409};\\\", \\\"{x:1258,y:583,t:1527628119425};\\\", \\\"{x:1258,y:589,t:1527628121352};\\\", \\\"{x:1253,y:599,t:1527628121361};\\\", \\\"{x:1242,y:621,t:1527628121377};\\\", \\\"{x:1232,y:637,t:1527628121394};\\\", \\\"{x:1225,y:653,t:1527628121411};\\\", \\\"{x:1217,y:675,t:1527628121427};\\\", \\\"{x:1211,y:701,t:1527628121444};\\\", \\\"{x:1199,y:724,t:1527628121461};\\\", \\\"{x:1187,y:748,t:1527628121477};\\\", \\\"{x:1176,y:768,t:1527628121494};\\\", \\\"{x:1165,y:788,t:1527628121511};\\\", \\\"{x:1159,y:804,t:1527628121526};\\\", \\\"{x:1154,y:827,t:1527628121543};\\\", \\\"{x:1154,y:846,t:1527628121560};\\\", \\\"{x:1154,y:861,t:1527628121577};\\\", \\\"{x:1154,y:876,t:1527628121594};\\\", \\\"{x:1155,y:884,t:1527628121611};\\\", \\\"{x:1156,y:888,t:1527628121627};\\\", \\\"{x:1156,y:892,t:1527628121644};\\\", \\\"{x:1156,y:895,t:1527628121660};\\\", \\\"{x:1156,y:896,t:1527628121677};\\\", \\\"{x:1158,y:896,t:1527628121736};\\\", \\\"{x:1158,y:895,t:1527628121744};\\\", \\\"{x:1160,y:889,t:1527628121761};\\\", \\\"{x:1164,y:883,t:1527628121778};\\\", \\\"{x:1167,y:879,t:1527628121794};\\\", \\\"{x:1168,y:875,t:1527628121811};\\\", \\\"{x:1170,y:872,t:1527628121828};\\\", \\\"{x:1170,y:869,t:1527628121844};\\\", \\\"{x:1171,y:868,t:1527628121861};\\\", \\\"{x:1172,y:866,t:1527628121878};\\\", \\\"{x:1173,y:863,t:1527628121894};\\\", \\\"{x:1174,y:859,t:1527628121910};\\\", \\\"{x:1178,y:853,t:1527628121927};\\\", \\\"{x:1182,y:847,t:1527628121943};\\\", \\\"{x:1188,y:837,t:1527628121960};\\\", \\\"{x:1191,y:826,t:1527628121977};\\\", \\\"{x:1192,y:816,t:1527628121993};\\\", \\\"{x:1193,y:807,t:1527628122010};\\\", \\\"{x:1197,y:796,t:1527628122028};\\\", \\\"{x:1201,y:789,t:1527628122044};\\\", \\\"{x:1204,y:785,t:1527628122061};\\\", \\\"{x:1209,y:783,t:1527628122078};\\\", \\\"{x:1213,y:780,t:1527628122094};\\\", \\\"{x:1216,y:777,t:1527628122110};\\\", \\\"{x:1217,y:777,t:1527628122232};\\\", \\\"{x:1217,y:778,t:1527628122320};\\\", \\\"{x:1216,y:782,t:1527628122328};\\\", \\\"{x:1215,y:789,t:1527628122346};\\\", \\\"{x:1209,y:804,t:1527628122361};\\\", \\\"{x:1206,y:816,t:1527628122378};\\\", \\\"{x:1203,y:826,t:1527628122395};\\\", \\\"{x:1200,y:839,t:1527628122411};\\\", \\\"{x:1193,y:854,t:1527628122428};\\\", \\\"{x:1185,y:872,t:1527628122445};\\\", \\\"{x:1178,y:883,t:1527628122461};\\\", \\\"{x:1170,y:899,t:1527628122478};\\\", \\\"{x:1164,y:906,t:1527628122495};\\\", \\\"{x:1164,y:909,t:1527628122511};\\\", \\\"{x:1164,y:913,t:1527628122528};\\\", \\\"{x:1164,y:909,t:1527628122575};\\\", \\\"{x:1167,y:901,t:1527628122584};\\\", \\\"{x:1172,y:894,t:1527628122594};\\\", \\\"{x:1180,y:878,t:1527628122612};\\\", \\\"{x:1187,y:861,t:1527628122628};\\\", \\\"{x:1193,y:842,t:1527628122645};\\\", \\\"{x:1199,y:829,t:1527628122662};\\\", \\\"{x:1205,y:815,t:1527628122678};\\\", \\\"{x:1211,y:803,t:1527628122696};\\\", \\\"{x:1211,y:802,t:1527628122711};\\\", \\\"{x:1212,y:801,t:1527628122728};\\\", \\\"{x:1213,y:799,t:1527628122745};\\\", \\\"{x:1214,y:799,t:1527628122792};\\\", \\\"{x:1216,y:801,t:1527628122807};\\\", \\\"{x:1221,y:810,t:1527628122815};\\\", \\\"{x:1224,y:822,t:1527628122828};\\\", \\\"{x:1231,y:844,t:1527628122846};\\\", \\\"{x:1244,y:874,t:1527628122862};\\\", \\\"{x:1255,y:897,t:1527628122878};\\\", \\\"{x:1269,y:925,t:1527628122896};\\\", \\\"{x:1277,y:938,t:1527628122912};\\\", \\\"{x:1280,y:944,t:1527628122928};\\\", \\\"{x:1280,y:946,t:1527628122945};\\\", \\\"{x:1280,y:944,t:1527628123144};\\\", \\\"{x:1279,y:938,t:1527628123162};\\\", \\\"{x:1274,y:919,t:1527628123179};\\\", \\\"{x:1265,y:891,t:1527628123196};\\\", \\\"{x:1255,y:868,t:1527628123212};\\\", \\\"{x:1240,y:823,t:1527628123229};\\\", \\\"{x:1230,y:787,t:1527628123245};\\\", \\\"{x:1228,y:765,t:1527628123262};\\\", \\\"{x:1225,y:749,t:1527628123279};\\\", \\\"{x:1225,y:747,t:1527628123296};\\\", \\\"{x:1224,y:746,t:1527628123440};\\\", \\\"{x:1221,y:746,t:1527628123560};\\\", \\\"{x:1215,y:745,t:1527628123568};\\\", \\\"{x:1210,y:743,t:1527628123579};\\\", \\\"{x:1208,y:742,t:1527628123596};\\\", \\\"{x:1209,y:743,t:1527628125264};\\\", \\\"{x:1210,y:748,t:1527628125280};\\\", \\\"{x:1211,y:750,t:1527628125297};\\\", \\\"{x:1213,y:753,t:1527628125313};\\\", \\\"{x:1213,y:756,t:1527628125330};\\\", \\\"{x:1214,y:757,t:1527628125360};\\\", \\\"{x:1215,y:759,t:1527628125447};\\\", \\\"{x:1216,y:760,t:1527628125463};\\\", \\\"{x:1217,y:762,t:1527628125479};\\\", \\\"{x:1218,y:765,t:1527628125497};\\\", \\\"{x:1219,y:768,t:1527628125513};\\\", \\\"{x:1223,y:772,t:1527628125530};\\\", \\\"{x:1226,y:776,t:1527628125547};\\\", \\\"{x:1227,y:778,t:1527628125563};\\\", \\\"{x:1230,y:778,t:1527628125580};\\\", \\\"{x:1230,y:779,t:1527628125596};\\\", \\\"{x:1230,y:780,t:1527628125631};\\\", \\\"{x:1230,y:781,t:1527628133256};\\\", \\\"{x:1230,y:784,t:1527628136088};\\\", \\\"{x:1231,y:788,t:1527628136105};\\\", \\\"{x:1234,y:795,t:1527628136121};\\\", \\\"{x:1237,y:805,t:1527628136138};\\\", \\\"{x:1243,y:811,t:1527628136155};\\\", \\\"{x:1252,y:819,t:1527628136171};\\\", \\\"{x:1264,y:828,t:1527628136189};\\\", \\\"{x:1271,y:831,t:1527628136204};\\\", \\\"{x:1277,y:836,t:1527628136222};\\\", \\\"{x:1282,y:838,t:1527628136238};\\\", \\\"{x:1284,y:840,t:1527628136254};\\\", \\\"{x:1287,y:842,t:1527628136272};\\\", \\\"{x:1288,y:843,t:1527628136288};\\\", \\\"{x:1288,y:845,t:1527628136312};\\\", \\\"{x:1288,y:846,t:1527628136322};\\\", \\\"{x:1288,y:849,t:1527628136339};\\\", \\\"{x:1288,y:851,t:1527628136355};\\\", \\\"{x:1288,y:853,t:1527628136372};\\\", \\\"{x:1288,y:854,t:1527628136388};\\\", \\\"{x:1288,y:856,t:1527628136406};\\\", \\\"{x:1288,y:857,t:1527628136421};\\\", \\\"{x:1289,y:857,t:1527628136511};\\\", \\\"{x:1291,y:857,t:1527628136521};\\\", \\\"{x:1295,y:855,t:1527628136538};\\\", \\\"{x:1300,y:851,t:1527628136555};\\\", \\\"{x:1301,y:851,t:1527628136572};\\\", \\\"{x:1301,y:852,t:1527628136646};\\\", \\\"{x:1301,y:853,t:1527628136654};\\\", \\\"{x:1301,y:856,t:1527628136671};\\\", \\\"{x:1301,y:858,t:1527628136688};\\\", \\\"{x:1301,y:859,t:1527628136704};\\\", \\\"{x:1301,y:860,t:1527628136721};\\\", \\\"{x:1301,y:861,t:1527628136839};\\\", \\\"{x:1301,y:866,t:1527628136887};\\\", \\\"{x:1301,y:869,t:1527628136894};\\\", \\\"{x:1302,y:871,t:1527628136905};\\\", \\\"{x:1303,y:875,t:1527628136922};\\\", \\\"{x:1306,y:881,t:1527628136937};\\\", \\\"{x:1307,y:883,t:1527628136955};\\\", \\\"{x:1307,y:885,t:1527628136972};\\\", \\\"{x:1307,y:889,t:1527628136988};\\\", \\\"{x:1307,y:892,t:1527628137005};\\\", \\\"{x:1307,y:897,t:1527628137022};\\\", \\\"{x:1307,y:898,t:1527628137038};\\\", \\\"{x:1308,y:903,t:1527628137054};\\\", \\\"{x:1309,y:904,t:1527628137072};\\\", \\\"{x:1312,y:904,t:1527628137089};\\\", \\\"{x:1313,y:906,t:1527628137106};\\\", \\\"{x:1320,y:906,t:1527628137122};\\\", \\\"{x:1321,y:906,t:1527628137138};\\\", \\\"{x:1322,y:906,t:1527628137155};\\\", \\\"{x:1323,y:906,t:1527628137172};\\\", \\\"{x:1324,y:906,t:1527628137189};\\\", \\\"{x:1325,y:906,t:1527628137207};\\\", \\\"{x:1326,y:907,t:1527628137288};\\\", \\\"{x:1326,y:908,t:1527628137296};\\\", \\\"{x:1326,y:909,t:1527628137310};\\\", \\\"{x:1327,y:911,t:1527628137326};\\\", \\\"{x:1327,y:913,t:1527628137343};\\\", \\\"{x:1327,y:914,t:1527628137511};\\\", \\\"{x:1328,y:915,t:1527628137522};\\\", \\\"{x:1329,y:915,t:1527628137539};\\\", \\\"{x:1330,y:915,t:1527628137575};\\\", \\\"{x:1332,y:915,t:1527628137589};\\\", \\\"{x:1334,y:915,t:1527628137605};\\\", \\\"{x:1336,y:915,t:1527628137622};\\\", \\\"{x:1341,y:912,t:1527628137640};\\\", \\\"{x:1342,y:911,t:1527628137655};\\\", \\\"{x:1343,y:911,t:1527628137672};\\\", \\\"{x:1344,y:910,t:1527628137690};\\\", \\\"{x:1346,y:909,t:1527628137706};\\\", \\\"{x:1347,y:909,t:1527628137723};\\\", \\\"{x:1350,y:907,t:1527628137752};\\\", \\\"{x:1351,y:907,t:1527628137776};\\\", \\\"{x:1352,y:907,t:1527628137789};\\\", \\\"{x:1354,y:906,t:1527628137806};\\\", \\\"{x:1357,y:904,t:1527628137822};\\\", \\\"{x:1358,y:903,t:1527628137839};\\\", \\\"{x:1359,y:901,t:1527628137857};\\\", \\\"{x:1360,y:901,t:1527628137873};\\\", \\\"{x:1360,y:900,t:1527628137889};\\\", \\\"{x:1360,y:898,t:1527628137907};\\\", \\\"{x:1361,y:895,t:1527628137923};\\\", \\\"{x:1361,y:894,t:1527628137940};\\\", \\\"{x:1362,y:892,t:1527628137956};\\\", \\\"{x:1362,y:891,t:1527628137975};\\\", \\\"{x:1363,y:890,t:1527628138087};\\\", \\\"{x:1363,y:889,t:1527628138103};\\\", \\\"{x:1364,y:888,t:1527628138111};\\\", \\\"{x:1366,y:886,t:1527628138127};\\\", \\\"{x:1366,y:885,t:1527628138140};\\\", \\\"{x:1367,y:883,t:1527628138156};\\\", \\\"{x:1369,y:880,t:1527628138174};\\\", \\\"{x:1372,y:875,t:1527628138189};\\\", \\\"{x:1372,y:873,t:1527628138207};\\\", \\\"{x:1373,y:871,t:1527628138223};\\\", \\\"{x:1373,y:870,t:1527628138247};\\\", \\\"{x:1373,y:869,t:1527628138383};\\\", \\\"{x:1372,y:868,t:1527628138407};\\\", \\\"{x:1370,y:865,t:1527628138423};\\\", \\\"{x:1368,y:862,t:1527628138440};\\\", \\\"{x:1367,y:861,t:1527628138457};\\\", \\\"{x:1365,y:861,t:1527628138776};\\\", \\\"{x:1364,y:861,t:1527628139272};\\\", \\\"{x:1363,y:860,t:1527628139360};\\\", \\\"{x:1363,y:856,t:1527628139374};\\\", \\\"{x:1367,y:849,t:1527628139391};\\\", \\\"{x:1372,y:843,t:1527628139407};\\\", \\\"{x:1375,y:839,t:1527628139424};\\\", \\\"{x:1377,y:837,t:1527628139440};\\\", \\\"{x:1378,y:837,t:1527628139487};\\\", \\\"{x:1378,y:835,t:1527628140736};\\\", \\\"{x:1383,y:834,t:1527628140743};\\\", \\\"{x:1411,y:838,t:1527628140759};\\\", \\\"{x:1434,y:847,t:1527628140775};\\\", \\\"{x:1519,y:873,t:1527628140792};\\\", \\\"{x:1567,y:891,t:1527628140809};\\\", \\\"{x:1598,y:899,t:1527628140825};\\\", \\\"{x:1613,y:901,t:1527628140841};\\\", \\\"{x:1622,y:903,t:1527628140858};\\\", \\\"{x:1629,y:903,t:1527628140874};\\\", \\\"{x:1636,y:904,t:1527628140891};\\\", \\\"{x:1642,y:904,t:1527628140907};\\\", \\\"{x:1648,y:904,t:1527628140924};\\\", \\\"{x:1653,y:904,t:1527628140941};\\\", \\\"{x:1655,y:904,t:1527628140958};\\\", \\\"{x:1656,y:904,t:1527628140975};\\\", \\\"{x:1657,y:904,t:1527628141047};\\\", \\\"{x:1659,y:903,t:1527628141815};\\\", \\\"{x:1663,y:901,t:1527628141826};\\\", \\\"{x:1672,y:894,t:1527628141843};\\\", \\\"{x:1685,y:882,t:1527628141859};\\\", \\\"{x:1694,y:867,t:1527628141875};\\\", \\\"{x:1700,y:857,t:1527628141892};\\\", \\\"{x:1710,y:841,t:1527628141908};\\\", \\\"{x:1714,y:832,t:1527628141926};\\\", \\\"{x:1714,y:827,t:1527628141942};\\\", \\\"{x:1716,y:819,t:1527628141959};\\\", \\\"{x:1716,y:818,t:1527628141975};\\\", \\\"{x:1716,y:817,t:1527628141992};\\\", \\\"{x:1717,y:816,t:1527628142376};\\\", \\\"{x:1717,y:817,t:1527628142393};\\\", \\\"{x:1717,y:825,t:1527628142409};\\\", \\\"{x:1717,y:830,t:1527628142427};\\\", \\\"{x:1718,y:830,t:1527628142443};\\\", \\\"{x:1719,y:829,t:1527628144499};\\\", \\\"{x:1719,y:828,t:1527628144803};\\\", \\\"{x:1719,y:827,t:1527628144815};\\\", \\\"{x:1719,y:826,t:1527628144831};\\\", \\\"{x:1720,y:826,t:1527628144963};\\\", \\\"{x:1722,y:827,t:1527628146138};\\\", \\\"{x:1723,y:828,t:1527628146401};\\\", \\\"{x:1724,y:829,t:1527628146425};\\\", \\\"{x:1725,y:829,t:1527628146433};\\\", \\\"{x:1726,y:829,t:1527628146659};\\\", \\\"{x:1727,y:829,t:1527628146683};\\\", \\\"{x:1728,y:829,t:1527628146706};\\\", \\\"{x:1729,y:830,t:1527628146771};\\\", \\\"{x:1730,y:830,t:1527628146850};\\\", \\\"{x:1730,y:831,t:1527628148323};\\\", \\\"{x:1730,y:832,t:1527628148346};\\\", \\\"{x:1728,y:833,t:1527628148354};\\\", \\\"{x:1726,y:834,t:1527628148366};\\\", \\\"{x:1720,y:837,t:1527628148383};\\\", \\\"{x:1715,y:840,t:1527628148401};\\\", \\\"{x:1711,y:841,t:1527628148416};\\\", \\\"{x:1707,y:844,t:1527628148433};\\\", \\\"{x:1706,y:845,t:1527628148450};\\\", \\\"{x:1705,y:845,t:1527628148819};\\\", \\\"{x:1703,y:845,t:1527628148834};\\\", \\\"{x:1701,y:845,t:1527628148850};\\\", \\\"{x:1695,y:845,t:1527628148867};\\\", \\\"{x:1689,y:844,t:1527628148885};\\\", \\\"{x:1677,y:842,t:1527628148901};\\\", \\\"{x:1673,y:842,t:1527628148917};\\\", \\\"{x:1667,y:842,t:1527628148934};\\\", \\\"{x:1656,y:842,t:1527628148951};\\\", \\\"{x:1645,y:842,t:1527628148968};\\\", \\\"{x:1630,y:838,t:1527628148984};\\\", \\\"{x:1615,y:834,t:1527628149002};\\\", \\\"{x:1606,y:832,t:1527628149017};\\\", \\\"{x:1598,y:830,t:1527628149034};\\\", \\\"{x:1594,y:828,t:1527628149898};\\\", \\\"{x:1586,y:823,t:1527628149906};\\\", \\\"{x:1579,y:821,t:1527628149918};\\\", \\\"{x:1563,y:816,t:1527628149935};\\\", \\\"{x:1548,y:813,t:1527628149951};\\\", \\\"{x:1537,y:813,t:1527628149968};\\\", \\\"{x:1525,y:813,t:1527628149985};\\\", \\\"{x:1513,y:815,t:1527628150001};\\\", \\\"{x:1504,y:818,t:1527628150017};\\\", \\\"{x:1496,y:822,t:1527628150035};\\\", \\\"{x:1492,y:824,t:1527628150052};\\\", \\\"{x:1489,y:825,t:1527628150068};\\\", \\\"{x:1488,y:826,t:1527628150084};\\\", \\\"{x:1487,y:826,t:1527628150102};\\\", \\\"{x:1486,y:827,t:1527628150118};\\\", \\\"{x:1484,y:827,t:1527628150179};\\\", \\\"{x:1483,y:827,t:1527628150187};\\\", \\\"{x:1479,y:827,t:1527628150202};\\\", \\\"{x:1473,y:827,t:1527628150218};\\\", \\\"{x:1467,y:826,t:1527628150235};\\\", \\\"{x:1459,y:826,t:1527628150252};\\\", \\\"{x:1450,y:827,t:1527628150268};\\\", \\\"{x:1441,y:832,t:1527628150285};\\\", \\\"{x:1436,y:835,t:1527628150302};\\\", \\\"{x:1427,y:839,t:1527628150318};\\\", \\\"{x:1422,y:842,t:1527628150336};\\\", \\\"{x:1420,y:844,t:1527628150352};\\\", \\\"{x:1418,y:845,t:1527628150368};\\\", \\\"{x:1416,y:847,t:1527628150385};\\\", \\\"{x:1413,y:849,t:1527628150403};\\\", \\\"{x:1413,y:850,t:1527628150418};\\\", \\\"{x:1412,y:850,t:1527628150435};\\\", \\\"{x:1411,y:851,t:1527628150453};\\\", \\\"{x:1409,y:852,t:1527628150469};\\\", \\\"{x:1409,y:854,t:1527628150485};\\\", \\\"{x:1406,y:856,t:1527628150502};\\\", \\\"{x:1404,y:858,t:1527628150519};\\\", \\\"{x:1401,y:860,t:1527628150534};\\\", \\\"{x:1400,y:862,t:1527628150552};\\\", \\\"{x:1396,y:865,t:1527628150568};\\\", \\\"{x:1392,y:869,t:1527628150585};\\\", \\\"{x:1388,y:873,t:1527628150601};\\\", \\\"{x:1388,y:874,t:1527628150619};\\\", \\\"{x:1386,y:877,t:1527628150635};\\\", \\\"{x:1385,y:880,t:1527628150652};\\\", \\\"{x:1381,y:884,t:1527628150669};\\\", \\\"{x:1377,y:889,t:1527628150685};\\\", \\\"{x:1374,y:893,t:1527628150701};\\\", \\\"{x:1371,y:897,t:1527628150719};\\\", \\\"{x:1368,y:900,t:1527628150735};\\\", \\\"{x:1365,y:904,t:1527628150752};\\\", \\\"{x:1363,y:907,t:1527628150769};\\\", \\\"{x:1361,y:910,t:1527628150785};\\\", \\\"{x:1360,y:910,t:1527628150851};\\\", \\\"{x:1359,y:910,t:1527628151027};\\\", \\\"{x:1359,y:908,t:1527628151042};\\\", \\\"{x:1359,y:907,t:1527628151066};\\\", \\\"{x:1359,y:905,t:1527628151082};\\\", \\\"{x:1359,y:904,t:1527628151107};\\\", \\\"{x:1359,y:901,t:1527628151119};\\\", \\\"{x:1361,y:898,t:1527628151136};\\\", \\\"{x:1361,y:897,t:1527628151152};\\\", \\\"{x:1364,y:893,t:1527628151170};\\\", \\\"{x:1365,y:889,t:1527628151186};\\\", \\\"{x:1366,y:887,t:1527628151202};\\\", \\\"{x:1368,y:884,t:1527628151259};\\\", \\\"{x:1368,y:883,t:1527628151274};\\\", \\\"{x:1369,y:883,t:1527628151286};\\\", \\\"{x:1369,y:881,t:1527628151306};\\\", \\\"{x:1370,y:880,t:1527628151320};\\\", \\\"{x:1371,y:878,t:1527628151336};\\\", \\\"{x:1374,y:874,t:1527628151353};\\\", \\\"{x:1375,y:873,t:1527628151369};\\\", \\\"{x:1377,y:869,t:1527628151387};\\\", \\\"{x:1380,y:867,t:1527628151402};\\\", \\\"{x:1381,y:866,t:1527628151419};\\\", \\\"{x:1382,y:864,t:1527628151437};\\\", \\\"{x:1383,y:861,t:1527628151454};\\\", \\\"{x:1385,y:859,t:1527628151469};\\\", \\\"{x:1385,y:858,t:1527628151486};\\\", \\\"{x:1386,y:856,t:1527628151503};\\\", \\\"{x:1387,y:854,t:1527628151519};\\\", \\\"{x:1388,y:853,t:1527628151536};\\\", \\\"{x:1388,y:851,t:1527628151553};\\\", \\\"{x:1389,y:850,t:1527628151569};\\\", \\\"{x:1390,y:848,t:1527628151586};\\\", \\\"{x:1391,y:846,t:1527628151604};\\\", \\\"{x:1392,y:846,t:1527628151619};\\\", \\\"{x:1392,y:845,t:1527628151636};\\\", \\\"{x:1393,y:844,t:1527628151653};\\\", \\\"{x:1393,y:843,t:1527628151682};\\\", \\\"{x:1394,y:842,t:1527628151699};\\\", \\\"{x:1395,y:840,t:1527628151714};\\\", \\\"{x:1396,y:838,t:1527628151754};\\\", \\\"{x:1396,y:837,t:1527628151779};\\\", \\\"{x:1397,y:837,t:1527628151786};\\\", \\\"{x:1397,y:836,t:1527628151818};\\\", \\\"{x:1398,y:835,t:1527628151834};\\\", \\\"{x:1398,y:834,t:1527628151866};\\\", \\\"{x:1400,y:833,t:1527628152219};\\\", \\\"{x:1400,y:832,t:1527628152242};\\\", \\\"{x:1401,y:832,t:1527628152253};\\\", \\\"{x:1403,y:832,t:1527628152474};\\\", \\\"{x:1403,y:831,t:1527628152487};\\\", \\\"{x:1404,y:830,t:1527628152503};\\\", \\\"{x:1407,y:830,t:1527628152521};\\\", \\\"{x:1407,y:829,t:1527628152562};\\\", \\\"{x:1409,y:828,t:1527628152811};\\\", \\\"{x:1410,y:826,t:1527628152821};\\\", \\\"{x:1411,y:825,t:1527628152837};\\\", \\\"{x:1411,y:821,t:1527628152854};\\\", \\\"{x:1411,y:817,t:1527628152870};\\\", \\\"{x:1411,y:814,t:1527628152887};\\\", \\\"{x:1411,y:811,t:1527628152904};\\\", \\\"{x:1411,y:808,t:1527628152920};\\\", \\\"{x:1411,y:804,t:1527628152937};\\\", \\\"{x:1411,y:801,t:1527628152954};\\\", \\\"{x:1412,y:799,t:1527628152970};\\\", \\\"{x:1412,y:798,t:1527628152987};\\\", \\\"{x:1412,y:797,t:1527628153004};\\\", \\\"{x:1412,y:796,t:1527628153067};\\\", \\\"{x:1413,y:795,t:1527628155802};\\\", \\\"{x:1414,y:794,t:1527628156002};\\\", \\\"{x:1416,y:794,t:1527628156290};\\\", \\\"{x:1416,y:793,t:1527628156306};\\\", \\\"{x:1417,y:793,t:1527628156459};\\\", \\\"{x:1417,y:792,t:1527628161978};\\\", \\\"{x:1418,y:791,t:1527628164019};\\\", \\\"{x:1419,y:790,t:1527628164029};\\\", \\\"{x:1420,y:789,t:1527628164045};\\\", \\\"{x:1421,y:789,t:1527628164098};\\\", \\\"{x:1423,y:789,t:1527628164112};\\\", \\\"{x:1427,y:789,t:1527628164129};\\\", \\\"{x:1430,y:792,t:1527628164146};\\\", \\\"{x:1432,y:792,t:1527628164210};\\\", \\\"{x:1434,y:792,t:1527628164242};\\\", \\\"{x:1435,y:792,t:1527628164315};\\\", \\\"{x:1439,y:792,t:1527628165410};\\\", \\\"{x:1439,y:791,t:1527628165434};\\\", \\\"{x:1440,y:790,t:1527628165446};\\\", \\\"{x:1441,y:790,t:1527628165722};\\\", \\\"{x:1444,y:790,t:1527628165738};\\\", \\\"{x:1446,y:790,t:1527628165746};\\\", \\\"{x:1447,y:790,t:1527628165763};\\\", \\\"{x:1450,y:795,t:1527628165779};\\\", \\\"{x:1451,y:799,t:1527628165797};\\\", \\\"{x:1454,y:804,t:1527628165813};\\\", \\\"{x:1455,y:808,t:1527628165830};\\\", \\\"{x:1456,y:812,t:1527628165847};\\\", \\\"{x:1459,y:816,t:1527628165864};\\\", \\\"{x:1460,y:819,t:1527628165880};\\\", \\\"{x:1461,y:823,t:1527628165897};\\\", \\\"{x:1463,y:828,t:1527628165914};\\\", \\\"{x:1463,y:830,t:1527628165930};\\\", \\\"{x:1463,y:831,t:1527628166651};\\\", \\\"{x:1463,y:828,t:1527628169018};\\\", \\\"{x:1463,y:825,t:1527628169033};\\\", \\\"{x:1463,y:816,t:1527628169049};\\\", \\\"{x:1465,y:814,t:1527628169066};\\\", \\\"{x:1466,y:813,t:1527628174866};\\\", \\\"{x:1467,y:813,t:1527628176987};\\\", \\\"{x:1468,y:813,t:1527628176994};\\\", \\\"{x:1469,y:813,t:1527628181163};\\\", \\\"{x:1469,y:812,t:1527628191970};\\\", \\\"{x:1469,y:811,t:1527628191983};\\\", \\\"{x:1467,y:810,t:1527628192000};\\\", \\\"{x:1464,y:806,t:1527628192017};\\\", \\\"{x:1462,y:804,t:1527628192033};\\\", \\\"{x:1460,y:800,t:1527628192049};\\\", \\\"{x:1460,y:799,t:1527628192073};\\\", \\\"{x:1458,y:799,t:1527628192090};\\\", \\\"{x:1458,y:798,t:1527628192105};\\\", \\\"{x:1455,y:798,t:1527628192194};\\\", \\\"{x:1454,y:796,t:1527628192201};\\\", \\\"{x:1444,y:790,t:1527628192217};\\\", \\\"{x:1410,y:769,t:1527628192233};\\\", \\\"{x:1352,y:740,t:1527628192250};\\\", \\\"{x:1310,y:721,t:1527628192267};\\\", \\\"{x:1274,y:704,t:1527628192282};\\\", \\\"{x:1233,y:688,t:1527628192299};\\\", \\\"{x:1188,y:668,t:1527628192317};\\\", \\\"{x:1137,y:651,t:1527628192333};\\\", \\\"{x:1081,y:632,t:1527628192350};\\\", \\\"{x:1025,y:607,t:1527628192366};\\\", \\\"{x:950,y:574,t:1527628192384};\\\", \\\"{x:855,y:542,t:1527628192400};\\\", \\\"{x:761,y:500,t:1527628192416};\\\", \\\"{x:624,y:451,t:1527628192437};\\\", \\\"{x:527,y:421,t:1527628192452};\\\", \\\"{x:426,y:387,t:1527628192470};\\\", \\\"{x:348,y:365,t:1527628192486};\\\", \\\"{x:298,y:351,t:1527628192503};\\\", \\\"{x:279,y:343,t:1527628192519};\\\", \\\"{x:271,y:341,t:1527628192536};\\\", \\\"{x:268,y:340,t:1527628192553};\\\", \\\"{x:267,y:340,t:1527628192608};\\\", \\\"{x:266,y:340,t:1527628192619};\\\", \\\"{x:264,y:341,t:1527628192636};\\\", \\\"{x:262,y:343,t:1527628192653};\\\", \\\"{x:261,y:346,t:1527628192669};\\\", \\\"{x:259,y:350,t:1527628192686};\\\", \\\"{x:258,y:353,t:1527628192702};\\\", \\\"{x:257,y:354,t:1527628192719};\\\", \\\"{x:256,y:355,t:1527628192770};\\\", \\\"{x:255,y:355,t:1527628192801};\\\", \\\"{x:254,y:355,t:1527628192817};\\\", \\\"{x:253,y:355,t:1527628192840};\\\", \\\"{x:253,y:356,t:1527628192852};\\\", \\\"{x:252,y:356,t:1527628192993};\\\", \\\"{x:252,y:358,t:1527628193378};\\\", \\\"{x:253,y:364,t:1527628193385};\\\", \\\"{x:265,y:379,t:1527628193401};\\\", \\\"{x:287,y:404,t:1527628193418};\\\", \\\"{x:314,y:437,t:1527628193435};\\\", \\\"{x:357,y:478,t:1527628193450};\\\", \\\"{x:393,y:501,t:1527628193471};\\\", \\\"{x:430,y:526,t:1527628193488};\\\", \\\"{x:435,y:529,t:1527628193504};\\\", \\\"{x:441,y:536,t:1527628193521};\\\", \\\"{x:442,y:536,t:1527628193616};\\\", \\\"{x:443,y:536,t:1527628193632};\\\", \\\"{x:443,y:535,t:1527628193640};\\\", \\\"{x:444,y:535,t:1527628193654};\\\", \\\"{x:445,y:534,t:1527628193671};\\\", \\\"{x:447,y:532,t:1527628193688};\\\", \\\"{x:452,y:531,t:1527628193704};\\\", \\\"{x:469,y:530,t:1527628193721};\\\", \\\"{x:483,y:530,t:1527628193738};\\\", \\\"{x:502,y:531,t:1527628193755};\\\", \\\"{x:526,y:534,t:1527628193771};\\\", \\\"{x:547,y:539,t:1527628193787};\\\", \\\"{x:575,y:546,t:1527628193805};\\\", \\\"{x:604,y:552,t:1527628193821};\\\", \\\"{x:625,y:556,t:1527628193837};\\\", \\\"{x:639,y:559,t:1527628193854};\\\", \\\"{x:645,y:560,t:1527628193871};\\\", \\\"{x:647,y:560,t:1527628193888};\\\", \\\"{x:649,y:560,t:1527628193904};\\\", \\\"{x:654,y:558,t:1527628193920};\\\", \\\"{x:664,y:552,t:1527628193938};\\\", \\\"{x:671,y:547,t:1527628193956};\\\", \\\"{x:685,y:539,t:1527628193971};\\\", \\\"{x:694,y:534,t:1527628193988};\\\", \\\"{x:703,y:527,t:1527628194004};\\\", \\\"{x:709,y:522,t:1527628194021};\\\", \\\"{x:716,y:517,t:1527628194038};\\\", \\\"{x:718,y:516,t:1527628194054};\\\", \\\"{x:722,y:513,t:1527628194071};\\\", \\\"{x:726,y:511,t:1527628194090};\\\", \\\"{x:728,y:510,t:1527628194104};\\\", \\\"{x:729,y:510,t:1527628194128};\\\", \\\"{x:730,y:510,t:1527628194144};\\\", \\\"{x:731,y:510,t:1527628194154};\\\", \\\"{x:735,y:510,t:1527628194171};\\\", \\\"{x:738,y:510,t:1527628194188};\\\", \\\"{x:743,y:510,t:1527628194204};\\\", \\\"{x:749,y:513,t:1527628194221};\\\", \\\"{x:764,y:517,t:1527628194238};\\\", \\\"{x:775,y:521,t:1527628194255};\\\", \\\"{x:786,y:525,t:1527628194271};\\\", \\\"{x:795,y:528,t:1527628194288};\\\", \\\"{x:801,y:530,t:1527628194304};\\\", \\\"{x:807,y:533,t:1527628194321};\\\", \\\"{x:808,y:533,t:1527628194338};\\\", \\\"{x:809,y:533,t:1527628194385};\\\", \\\"{x:810,y:533,t:1527628194458};\\\", \\\"{x:811,y:533,t:1527628194471};\\\", \\\"{x:813,y:533,t:1527628194488};\\\", \\\"{x:816,y:531,t:1527628194505};\\\", \\\"{x:818,y:530,t:1527628194521};\\\", \\\"{x:821,y:529,t:1527628194539};\\\", \\\"{x:823,y:527,t:1527628194555};\\\", \\\"{x:826,y:526,t:1527628194572};\\\", \\\"{x:827,y:525,t:1527628194588};\\\", \\\"{x:829,y:524,t:1527628194605};\\\", \\\"{x:832,y:522,t:1527628194622};\\\", \\\"{x:836,y:519,t:1527628194638};\\\", \\\"{x:836,y:517,t:1527628194655};\\\", \\\"{x:836,y:516,t:1527628194672};\\\", \\\"{x:832,y:513,t:1527628194688};\\\", \\\"{x:790,y:508,t:1527628194705};\\\", \\\"{x:722,y:505,t:1527628194722};\\\", \\\"{x:648,y:511,t:1527628194738};\\\", \\\"{x:578,y:511,t:1527628194755};\\\", \\\"{x:528,y:511,t:1527628194772};\\\", \\\"{x:507,y:511,t:1527628194788};\\\", \\\"{x:502,y:511,t:1527628194805};\\\", \\\"{x:501,y:511,t:1527628194822};\\\", \\\"{x:502,y:511,t:1527628194897};\\\", \\\"{x:502,y:512,t:1527628194978};\\\", \\\"{x:499,y:515,t:1527628194989};\\\", \\\"{x:494,y:519,t:1527628195007};\\\", \\\"{x:489,y:523,t:1527628195022};\\\", \\\"{x:488,y:527,t:1527628195038};\\\", \\\"{x:488,y:534,t:1527628195056};\\\", \\\"{x:503,y:545,t:1527628195074};\\\", \\\"{x:534,y:550,t:1527628195088};\\\", \\\"{x:602,y:553,t:1527628195105};\\\", \\\"{x:645,y:553,t:1527628195121};\\\", \\\"{x:663,y:553,t:1527628195139};\\\", \\\"{x:667,y:551,t:1527628195155};\\\", \\\"{x:667,y:549,t:1527628195176};\\\", \\\"{x:667,y:547,t:1527628195188};\\\", \\\"{x:666,y:546,t:1527628195205};\\\", \\\"{x:666,y:544,t:1527628195222};\\\", \\\"{x:665,y:543,t:1527628195239};\\\", \\\"{x:657,y:539,t:1527628195256};\\\", \\\"{x:644,y:535,t:1527628195272};\\\", \\\"{x:630,y:530,t:1527628195289};\\\", \\\"{x:618,y:525,t:1527628195305};\\\", \\\"{x:608,y:521,t:1527628195322};\\\", \\\"{x:602,y:519,t:1527628195338};\\\", \\\"{x:600,y:518,t:1527628195355};\\\", \\\"{x:599,y:518,t:1527628195373};\\\", \\\"{x:598,y:518,t:1527628195409};\\\", \\\"{x:597,y:518,t:1527628195422};\\\", \\\"{x:597,y:519,t:1527628195441};\\\", \\\"{x:597,y:520,t:1527628195537};\\\", \\\"{x:597,y:523,t:1527628195544};\\\", \\\"{x:598,y:525,t:1527628195556};\\\", \\\"{x:599,y:526,t:1527628195572};\\\", \\\"{x:600,y:528,t:1527628195589};\\\", \\\"{x:601,y:528,t:1527628195672};\\\", \\\"{x:601,y:528,t:1527628195728};\\\", \\\"{x:603,y:528,t:1527628195777};\\\", \\\"{x:606,y:528,t:1527628195788};\\\", \\\"{x:611,y:527,t:1527628195806};\\\", \\\"{x:618,y:526,t:1527628195822};\\\", \\\"{x:628,y:526,t:1527628195839};\\\", \\\"{x:647,y:522,t:1527628195856};\\\", \\\"{x:669,y:522,t:1527628195872};\\\", \\\"{x:698,y:522,t:1527628195889};\\\", \\\"{x:713,y:522,t:1527628195906};\\\", \\\"{x:722,y:522,t:1527628195922};\\\", \\\"{x:724,y:522,t:1527628195940};\\\", \\\"{x:734,y:522,t:1527628195956};\\\", \\\"{x:749,y:522,t:1527628195972};\\\", \\\"{x:762,y:522,t:1527628195989};\\\", \\\"{x:772,y:522,t:1527628196006};\\\", \\\"{x:784,y:523,t:1527628196022};\\\", \\\"{x:792,y:526,t:1527628196039};\\\", \\\"{x:794,y:526,t:1527628196056};\\\", \\\"{x:795,y:526,t:1527628196081};\\\", \\\"{x:797,y:526,t:1527628196121};\\\", \\\"{x:799,y:526,t:1527628196145};\\\", \\\"{x:801,y:526,t:1527628196157};\\\", \\\"{x:804,y:525,t:1527628196172};\\\", \\\"{x:808,y:524,t:1527628196190};\\\", \\\"{x:811,y:523,t:1527628196206};\\\", \\\"{x:814,y:523,t:1527628196224};\\\", \\\"{x:815,y:522,t:1527628196239};\\\", \\\"{x:817,y:522,t:1527628196256};\\\", \\\"{x:818,y:522,t:1527628196305};\\\", \\\"{x:820,y:522,t:1527628196328};\\\", \\\"{x:821,y:522,t:1527628196339};\\\", \\\"{x:823,y:523,t:1527628196355};\\\", \\\"{x:826,y:524,t:1527628196373};\\\", \\\"{x:829,y:524,t:1527628196389};\\\", \\\"{x:832,y:525,t:1527628196406};\\\", \\\"{x:835,y:525,t:1527628196423};\\\", \\\"{x:838,y:526,t:1527628196440};\\\", \\\"{x:838,y:529,t:1527628196873};\\\", \\\"{x:832,y:547,t:1527628196892};\\\", \\\"{x:827,y:549,t:1527628196906};\\\", \\\"{x:826,y:551,t:1527628197131};\\\", \\\"{x:826,y:553,t:1527628197140};\\\", \\\"{x:826,y:556,t:1527628197157};\\\", \\\"{x:826,y:563,t:1527628197173};\\\", \\\"{x:837,y:573,t:1527628197190};\\\", \\\"{x:850,y:577,t:1527628197207};\\\", \\\"{x:861,y:580,t:1527628197223};\\\", \\\"{x:865,y:581,t:1527628197240};\\\", \\\"{x:867,y:582,t:1527628197264};\\\", \\\"{x:869,y:582,t:1527628197280};\\\", \\\"{x:870,y:582,t:1527628197329};\\\", \\\"{x:871,y:582,t:1527628197897};\\\", \\\"{x:873,y:582,t:1527628197908};\\\", \\\"{x:875,y:582,t:1527628197970};\\\", \\\"{x:876,y:585,t:1527628197977};\\\", \\\"{x:876,y:591,t:1527628197992};\\\", \\\"{x:878,y:605,t:1527628198008};\\\", \\\"{x:882,y:629,t:1527628198025};\\\", \\\"{x:882,y:645,t:1527628198041};\\\", \\\"{x:881,y:657,t:1527628198058};\\\", \\\"{x:880,y:670,t:1527628198075};\\\", \\\"{x:880,y:683,t:1527628198094};\\\", \\\"{x:877,y:688,t:1527628198107};\\\", \\\"{x:870,y:694,t:1527628198124};\\\", \\\"{x:865,y:698,t:1527628198141};\\\", \\\"{x:859,y:702,t:1527628198157};\\\", \\\"{x:851,y:705,t:1527628198174};\\\", \\\"{x:838,y:710,t:1527628198191};\\\", \\\"{x:814,y:720,t:1527628198208};\\\", \\\"{x:786,y:729,t:1527628198224};\\\", \\\"{x:760,y:731,t:1527628198241};\\\", \\\"{x:738,y:735,t:1527628198258};\\\", \\\"{x:719,y:740,t:1527628198275};\\\", \\\"{x:703,y:746,t:1527628198292};\\\", \\\"{x:688,y:750,t:1527628198308};\\\", \\\"{x:679,y:754,t:1527628198324};\\\", \\\"{x:667,y:759,t:1527628198342};\\\", \\\"{x:658,y:764,t:1527628198358};\\\", \\\"{x:644,y:766,t:1527628198374};\\\", \\\"{x:634,y:770,t:1527628198391};\\\", \\\"{x:625,y:770,t:1527628198408};\\\", \\\"{x:619,y:770,t:1527628198425};\\\", \\\"{x:618,y:770,t:1527628198442};\\\", \\\"{x:618,y:769,t:1527628198459};\\\", \\\"{x:617,y:768,t:1527628198475};\\\", \\\"{x:617,y:766,t:1527628198493};\\\", \\\"{x:617,y:763,t:1527628198509};\\\", \\\"{x:617,y:761,t:1527628198525};\\\", \\\"{x:617,y:759,t:1527628198542};\\\", \\\"{x:617,y:756,t:1527628198558};\\\", \\\"{x:617,y:753,t:1527628198575};\\\", \\\"{x:617,y:752,t:1527628198601};\\\", \\\"{x:617,y:751,t:1527628198609};\\\", \\\"{x:617,y:750,t:1527628198722};\\\", \\\"{x:611,y:745,t:1527628198729};\\\", \\\"{x:590,y:737,t:1527628198742};\\\", \\\"{x:572,y:725,t:1527628198759};\\\", \\\"{x:511,y:686,t:1527628198777};\\\", \\\"{x:456,y:651,t:1527628198791};\\\", \\\"{x:438,y:635,t:1527628198807};\\\", \\\"{x:431,y:631,t:1527628198825};\\\", \\\"{x:432,y:630,t:1527628198857};\\\", \\\"{x:434,y:629,t:1527628198872};\\\", \\\"{x:435,y:628,t:1527628198897};\\\", \\\"{x:437,y:628,t:1527628198929};\\\", \\\"{x:438,y:628,t:1527628198944};\\\", \\\"{x:441,y:630,t:1527628198961};\\\", \\\"{x:447,y:635,t:1527628198975};\\\", \\\"{x:458,y:645,t:1527628198991};\\\", \\\"{x:480,y:661,t:1527628199008};\\\", \\\"{x:497,y:673,t:1527628199026};\\\", \\\"{x:509,y:681,t:1527628199041};\\\", \\\"{x:511,y:685,t:1527628199058};\\\", \\\"{x:514,y:685,t:1527628199297};\\\", \\\"{x:514,y:685,t:1527628199357};\\\", \\\"{x:510,y:688,t:1527628199929};\\\", \\\"{x:504,y:692,t:1527628199942};\\\", \\\"{x:497,y:694,t:1527628199959};\\\" ] }, { \\\"rt\\\": 100143, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 517009, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 4.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-X -B -B -11 AM-03 PM-03 PM-B -A -A -K -K -K -06 PM-07 PM-07 PM-06 PM-10 AM-B -B -09 AM-10 AM-11 AM-12 PM-01 PM-09 AM-10 AM-11 AM-12 PM-01 PM-02 PM-03 PM-04 PM-09 AM-G -C -O -04 PM-G -G -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:499,y:692,t:1527628202417};\\\", \\\"{x:506,y:692,t:1527628202428};\\\", \\\"{x:529,y:703,t:1527628202446};\\\", \\\"{x:553,y:709,t:1527628202461};\\\", \\\"{x:569,y:709,t:1527628202477};\\\", \\\"{x:580,y:710,t:1527628202494};\\\", \\\"{x:596,y:716,t:1527628202510};\\\", \\\"{x:612,y:723,t:1527628202527};\\\", \\\"{x:635,y:737,t:1527628202544};\\\", \\\"{x:650,y:746,t:1527628202560};\\\", \\\"{x:665,y:758,t:1527628202577};\\\", \\\"{x:692,y:770,t:1527628202594};\\\", \\\"{x:721,y:779,t:1527628202610};\\\", \\\"{x:750,y:790,t:1527628202627};\\\", \\\"{x:795,y:811,t:1527628202644};\\\", \\\"{x:885,y:842,t:1527628202660};\\\", \\\"{x:976,y:867,t:1527628202677};\\\", \\\"{x:1063,y:881,t:1527628202694};\\\", \\\"{x:1151,y:892,t:1527628202710};\\\", \\\"{x:1222,y:906,t:1527628202728};\\\", \\\"{x:1278,y:912,t:1527628202745};\\\", \\\"{x:1296,y:913,t:1527628202760};\\\", \\\"{x:1303,y:913,t:1527628202777};\\\", \\\"{x:1308,y:913,t:1527628202794};\\\", \\\"{x:1311,y:912,t:1527628202810};\\\", \\\"{x:1319,y:911,t:1527628202827};\\\", \\\"{x:1332,y:911,t:1527628202844};\\\", \\\"{x:1353,y:911,t:1527628202861};\\\", \\\"{x:1366,y:911,t:1527628202878};\\\", \\\"{x:1378,y:913,t:1527628202895};\\\", \\\"{x:1399,y:918,t:1527628202911};\\\", \\\"{x:1402,y:918,t:1527628202928};\\\", \\\"{x:1403,y:918,t:1527628203971};\\\", \\\"{x:1404,y:918,t:1527628204003};\\\", \\\"{x:1406,y:918,t:1527628204043};\\\", \\\"{x:1407,y:917,t:1527628204075};\\\", \\\"{x:1408,y:915,t:1527628204092};\\\", \\\"{x:1409,y:915,t:1527628204122};\\\", \\\"{x:1411,y:914,t:1527628205163};\\\", \\\"{x:1412,y:914,t:1527628205179};\\\", \\\"{x:1413,y:914,t:1527628205226};\\\", \\\"{x:1416,y:914,t:1527628205239};\\\", \\\"{x:1430,y:909,t:1527628205256};\\\", \\\"{x:1453,y:895,t:1527628205271};\\\", \\\"{x:1480,y:873,t:1527628205288};\\\", \\\"{x:1510,y:849,t:1527628205305};\\\", \\\"{x:1521,y:834,t:1527628205321};\\\", \\\"{x:1522,y:824,t:1527628205339};\\\", \\\"{x:1522,y:817,t:1527628205355};\\\", \\\"{x:1519,y:812,t:1527628205372};\\\", \\\"{x:1509,y:801,t:1527628205389};\\\", \\\"{x:1495,y:792,t:1527628205406};\\\", \\\"{x:1487,y:789,t:1527628205421};\\\", \\\"{x:1481,y:785,t:1527628205438};\\\", \\\"{x:1477,y:783,t:1527628205455};\\\", \\\"{x:1478,y:781,t:1527628205485};\\\", \\\"{x:1481,y:779,t:1527628205504};\\\", \\\"{x:1487,y:776,t:1527628205521};\\\", \\\"{x:1489,y:775,t:1527628205537};\\\", \\\"{x:1489,y:774,t:1527628205555};\\\", \\\"{x:1490,y:774,t:1527628205571};\\\", \\\"{x:1491,y:773,t:1527628205588};\\\", \\\"{x:1492,y:772,t:1527628205609};\\\", \\\"{x:1494,y:772,t:1527628205626};\\\", \\\"{x:1496,y:771,t:1527628205638};\\\", \\\"{x:1496,y:770,t:1527628205655};\\\", \\\"{x:1498,y:770,t:1527628205672};\\\", \\\"{x:1500,y:769,t:1527628205688};\\\", \\\"{x:1501,y:768,t:1527628205706};\\\", \\\"{x:1505,y:765,t:1527628205722};\\\", \\\"{x:1505,y:764,t:1527628205738};\\\", \\\"{x:1505,y:763,t:1527628205755};\\\", \\\"{x:1505,y:761,t:1527628205787};\\\", \\\"{x:1507,y:760,t:1527628205906};\\\", \\\"{x:1511,y:758,t:1527628205922};\\\", \\\"{x:1513,y:757,t:1527628205946};\\\", \\\"{x:1512,y:757,t:1527628206099};\\\", \\\"{x:1509,y:757,t:1527628206107};\\\", \\\"{x:1501,y:757,t:1527628206122};\\\", \\\"{x:1477,y:757,t:1527628206139};\\\", \\\"{x:1457,y:757,t:1527628206155};\\\", \\\"{x:1432,y:757,t:1527628206172};\\\", \\\"{x:1408,y:754,t:1527628206188};\\\", \\\"{x:1394,y:749,t:1527628206205};\\\", \\\"{x:1388,y:746,t:1527628206222};\\\", \\\"{x:1388,y:745,t:1527628206241};\\\", \\\"{x:1389,y:745,t:1527628206255};\\\", \\\"{x:1391,y:743,t:1527628206272};\\\", \\\"{x:1392,y:743,t:1527628206289};\\\", \\\"{x:1393,y:742,t:1527628206305};\\\", \\\"{x:1393,y:740,t:1527628206338};\\\", \\\"{x:1392,y:739,t:1527628206355};\\\", \\\"{x:1389,y:737,t:1527628206371};\\\", \\\"{x:1389,y:736,t:1527628206389};\\\", \\\"{x:1389,y:732,t:1527628206405};\\\", \\\"{x:1386,y:727,t:1527628206422};\\\", \\\"{x:1382,y:720,t:1527628206439};\\\", \\\"{x:1380,y:714,t:1527628206455};\\\", \\\"{x:1377,y:708,t:1527628206472};\\\", \\\"{x:1375,y:701,t:1527628206489};\\\", \\\"{x:1373,y:698,t:1527628206505};\\\", \\\"{x:1372,y:696,t:1527628206522};\\\", \\\"{x:1371,y:696,t:1527628206553};\\\", \\\"{x:1370,y:696,t:1527628206577};\\\", \\\"{x:1368,y:696,t:1527628206593};\\\", \\\"{x:1367,y:696,t:1527628206605};\\\", \\\"{x:1363,y:696,t:1527628206622};\\\", \\\"{x:1360,y:697,t:1527628206639};\\\", \\\"{x:1358,y:698,t:1527628206655};\\\", \\\"{x:1356,y:698,t:1527628206672};\\\", \\\"{x:1355,y:699,t:1527628206689};\\\", \\\"{x:1354,y:700,t:1527628206818};\\\", \\\"{x:1353,y:701,t:1527628206859};\\\", \\\"{x:1352,y:701,t:1527628206872};\\\", \\\"{x:1350,y:702,t:1527628206889};\\\", \\\"{x:1349,y:704,t:1527628206905};\\\", \\\"{x:1347,y:706,t:1527628206922};\\\", \\\"{x:1347,y:707,t:1527628206938};\\\", \\\"{x:1346,y:709,t:1527628206955};\\\", \\\"{x:1346,y:710,t:1527628206972};\\\", \\\"{x:1345,y:710,t:1527628206989};\\\", \\\"{x:1344,y:711,t:1527628207006};\\\", \\\"{x:1344,y:712,t:1527628207025};\\\", \\\"{x:1344,y:713,t:1527628207039};\\\", \\\"{x:1342,y:717,t:1527628207056};\\\", \\\"{x:1341,y:722,t:1527628207072};\\\", \\\"{x:1340,y:729,t:1527628207089};\\\", \\\"{x:1339,y:737,t:1527628207105};\\\", \\\"{x:1338,y:745,t:1527628207122};\\\", \\\"{x:1336,y:749,t:1527628207139};\\\", \\\"{x:1333,y:757,t:1527628207156};\\\", \\\"{x:1329,y:768,t:1527628207172};\\\", \\\"{x:1323,y:782,t:1527628207189};\\\", \\\"{x:1315,y:799,t:1527628207206};\\\", \\\"{x:1305,y:816,t:1527628207222};\\\", \\\"{x:1299,y:830,t:1527628207239};\\\", \\\"{x:1288,y:847,t:1527628207256};\\\", \\\"{x:1283,y:857,t:1527628207272};\\\", \\\"{x:1278,y:866,t:1527628207289};\\\", \\\"{x:1263,y:891,t:1527628207306};\\\", \\\"{x:1254,y:908,t:1527628207322};\\\", \\\"{x:1245,y:920,t:1527628207340};\\\", \\\"{x:1239,y:930,t:1527628207356};\\\", \\\"{x:1239,y:932,t:1527628207373};\\\", \\\"{x:1238,y:933,t:1527628207389};\\\", \\\"{x:1239,y:932,t:1527628207538};\\\", \\\"{x:1239,y:928,t:1527628207557};\\\", \\\"{x:1240,y:925,t:1527628207573};\\\", \\\"{x:1241,y:923,t:1527628207589};\\\", \\\"{x:1242,y:923,t:1527628207659};\\\", \\\"{x:1244,y:923,t:1527628208649};\\\", \\\"{x:1245,y:923,t:1527628208657};\\\", \\\"{x:1246,y:924,t:1527628210154};\\\", \\\"{x:1248,y:924,t:1527628211274};\\\", \\\"{x:1267,y:916,t:1527628211292};\\\", \\\"{x:1294,y:906,t:1527628211308};\\\", \\\"{x:1323,y:895,t:1527628211325};\\\", \\\"{x:1353,y:887,t:1527628211342};\\\", \\\"{x:1385,y:881,t:1527628211358};\\\", \\\"{x:1404,y:876,t:1527628211374};\\\", \\\"{x:1420,y:871,t:1527628211391};\\\", \\\"{x:1431,y:867,t:1527628211408};\\\", \\\"{x:1440,y:862,t:1527628211424};\\\", \\\"{x:1450,y:853,t:1527628211442};\\\", \\\"{x:1463,y:837,t:1527628211458};\\\", \\\"{x:1470,y:828,t:1527628211474};\\\", \\\"{x:1477,y:824,t:1527628211492};\\\", \\\"{x:1481,y:818,t:1527628211508};\\\", \\\"{x:1483,y:812,t:1527628211525};\\\", \\\"{x:1483,y:798,t:1527628211542};\\\", \\\"{x:1481,y:793,t:1527628211557};\\\", \\\"{x:1478,y:789,t:1527628211575};\\\", \\\"{x:1479,y:789,t:1527628211843};\\\", \\\"{x:1481,y:789,t:1527628211859};\\\", \\\"{x:1483,y:789,t:1527628211875};\\\", \\\"{x:1485,y:788,t:1527628211898};\\\", \\\"{x:1486,y:788,t:1527628211915};\\\", \\\"{x:1485,y:788,t:1527628212026};\\\", \\\"{x:1484,y:788,t:1527628212067};\\\", \\\"{x:1482,y:789,t:1527628212075};\\\", \\\"{x:1482,y:804,t:1527628212091};\\\", \\\"{x:1484,y:817,t:1527628212109};\\\", \\\"{x:1489,y:830,t:1527628212124};\\\", \\\"{x:1498,y:849,t:1527628212141};\\\", \\\"{x:1506,y:863,t:1527628212159};\\\", \\\"{x:1515,y:880,t:1527628212175};\\\", \\\"{x:1521,y:889,t:1527628212192};\\\", \\\"{x:1527,y:898,t:1527628212209};\\\", \\\"{x:1529,y:902,t:1527628212225};\\\", \\\"{x:1531,y:904,t:1527628212426};\\\", \\\"{x:1531,y:907,t:1527628212442};\\\", \\\"{x:1543,y:919,t:1527628212459};\\\", \\\"{x:1547,y:926,t:1527628212475};\\\", \\\"{x:1555,y:930,t:1527628212491};\\\", \\\"{x:1557,y:932,t:1527628212509};\\\", \\\"{x:1558,y:932,t:1527628212525};\\\", \\\"{x:1557,y:932,t:1527628212699};\\\", \\\"{x:1556,y:931,t:1527628212709};\\\", \\\"{x:1556,y:930,t:1527628212730};\\\", \\\"{x:1555,y:929,t:1527628212741};\\\", \\\"{x:1555,y:928,t:1527628212759};\\\", \\\"{x:1554,y:927,t:1527628212775};\\\", \\\"{x:1553,y:926,t:1527628212791};\\\", \\\"{x:1551,y:923,t:1527628212809};\\\", \\\"{x:1542,y:912,t:1527628212826};\\\", \\\"{x:1537,y:904,t:1527628212842};\\\", \\\"{x:1519,y:879,t:1527628212859};\\\", \\\"{x:1499,y:858,t:1527628212876};\\\", \\\"{x:1481,y:839,t:1527628212892};\\\", \\\"{x:1460,y:821,t:1527628212908};\\\", \\\"{x:1447,y:810,t:1527628212926};\\\", \\\"{x:1438,y:802,t:1527628212941};\\\", \\\"{x:1424,y:794,t:1527628212958};\\\", \\\"{x:1407,y:787,t:1527628212975};\\\", \\\"{x:1392,y:778,t:1527628212991};\\\", \\\"{x:1385,y:775,t:1527628213009};\\\", \\\"{x:1385,y:774,t:1527628213025};\\\", \\\"{x:1385,y:772,t:1527628213123};\\\", \\\"{x:1385,y:770,t:1527628213138};\\\", \\\"{x:1385,y:768,t:1527628213147};\\\", \\\"{x:1384,y:765,t:1527628213161};\\\", \\\"{x:1383,y:764,t:1527628213175};\\\", \\\"{x:1382,y:762,t:1527628213190};\\\", \\\"{x:1381,y:760,t:1527628213208};\\\", \\\"{x:1379,y:755,t:1527628213225};\\\", \\\"{x:1376,y:749,t:1527628213241};\\\", \\\"{x:1369,y:743,t:1527628213258};\\\", \\\"{x:1365,y:739,t:1527628213276};\\\", \\\"{x:1359,y:731,t:1527628213291};\\\", \\\"{x:1358,y:727,t:1527628213308};\\\", \\\"{x:1357,y:724,t:1527628213325};\\\", \\\"{x:1357,y:722,t:1527628213341};\\\", \\\"{x:1356,y:720,t:1527628213358};\\\", \\\"{x:1356,y:718,t:1527628213375};\\\", \\\"{x:1355,y:716,t:1527628213391};\\\", \\\"{x:1355,y:714,t:1527628213408};\\\", \\\"{x:1355,y:713,t:1527628213426};\\\", \\\"{x:1353,y:713,t:1527628213458};\\\", \\\"{x:1349,y:713,t:1527628213477};\\\", \\\"{x:1345,y:714,t:1527628213491};\\\", \\\"{x:1335,y:721,t:1527628213509};\\\", \\\"{x:1321,y:731,t:1527628213525};\\\", \\\"{x:1308,y:745,t:1527628213541};\\\", \\\"{x:1298,y:758,t:1527628213559};\\\", \\\"{x:1289,y:769,t:1527628213576};\\\", \\\"{x:1286,y:777,t:1527628213592};\\\", \\\"{x:1283,y:785,t:1527628213608};\\\", \\\"{x:1279,y:795,t:1527628213626};\\\", \\\"{x:1277,y:803,t:1527628213642};\\\", \\\"{x:1273,y:814,t:1527628213659};\\\", \\\"{x:1270,y:820,t:1527628213676};\\\", \\\"{x:1268,y:827,t:1527628213692};\\\", \\\"{x:1267,y:832,t:1527628213709};\\\", \\\"{x:1266,y:838,t:1527628213725};\\\", \\\"{x:1265,y:848,t:1527628213743};\\\", \\\"{x:1262,y:862,t:1527628213759};\\\", \\\"{x:1259,y:881,t:1527628213776};\\\", \\\"{x:1254,y:894,t:1527628213792};\\\", \\\"{x:1252,y:904,t:1527628213808};\\\", \\\"{x:1250,y:909,t:1527628213826};\\\", \\\"{x:1249,y:910,t:1527628213843};\\\", \\\"{x:1247,y:910,t:1527628214043};\\\", \\\"{x:1241,y:910,t:1527628214058};\\\", \\\"{x:1233,y:910,t:1527628214075};\\\", \\\"{x:1227,y:910,t:1527628214093};\\\", \\\"{x:1223,y:910,t:1527628214109};\\\", \\\"{x:1222,y:910,t:1527628214125};\\\", \\\"{x:1220,y:910,t:1527628214142};\\\", \\\"{x:1219,y:910,t:1527628214159};\\\", \\\"{x:1218,y:910,t:1527628214175};\\\", \\\"{x:1217,y:911,t:1527628214192};\\\", \\\"{x:1216,y:911,t:1527628214234};\\\", \\\"{x:1215,y:911,t:1527628214347};\\\", \\\"{x:1211,y:911,t:1527628214359};\\\", \\\"{x:1205,y:911,t:1527628214376};\\\", \\\"{x:1204,y:911,t:1527628214392};\\\", \\\"{x:1203,y:911,t:1527628214409};\\\", \\\"{x:1201,y:911,t:1527628214643};\\\", \\\"{x:1179,y:911,t:1527628214659};\\\", \\\"{x:1161,y:910,t:1527628214676};\\\", \\\"{x:1148,y:905,t:1527628214693};\\\", \\\"{x:1139,y:904,t:1527628214709};\\\", \\\"{x:1138,y:903,t:1527628214725};\\\", \\\"{x:1139,y:903,t:1527628214914};\\\", \\\"{x:1140,y:903,t:1527628214962};\\\", \\\"{x:1140,y:904,t:1527628215083};\\\", \\\"{x:1140,y:905,t:1527628215130};\\\", \\\"{x:1140,y:906,t:1527628215154};\\\", \\\"{x:1140,y:907,t:1527628215187};\\\", \\\"{x:1140,y:908,t:1527628215354};\\\", \\\"{x:1139,y:908,t:1527628215419};\\\", \\\"{x:1138,y:908,t:1527628215434};\\\", \\\"{x:1137,y:908,t:1527628215443};\\\", \\\"{x:1136,y:908,t:1527628215522};\\\", \\\"{x:1135,y:908,t:1527628215530};\\\", \\\"{x:1133,y:908,t:1527628215543};\\\", \\\"{x:1125,y:908,t:1527628215560};\\\", \\\"{x:1114,y:908,t:1527628215577};\\\", \\\"{x:1103,y:908,t:1527628215593};\\\", \\\"{x:1098,y:908,t:1527628215610};\\\", \\\"{x:1097,y:908,t:1527628215811};\\\", \\\"{x:1097,y:907,t:1527628216426};\\\", \\\"{x:1097,y:905,t:1527628216483};\\\", \\\"{x:1098,y:905,t:1527628219947};\\\", \\\"{x:1102,y:904,t:1527628219962};\\\", \\\"{x:1107,y:904,t:1527628219978};\\\", \\\"{x:1113,y:904,t:1527628219995};\\\", \\\"{x:1115,y:904,t:1527628220012};\\\", \\\"{x:1116,y:904,t:1527628220050};\\\", \\\"{x:1117,y:904,t:1527628220062};\\\", \\\"{x:1119,y:904,t:1527628220078};\\\", \\\"{x:1124,y:904,t:1527628220095};\\\", \\\"{x:1126,y:904,t:1527628220112};\\\", \\\"{x:1131,y:904,t:1527628220128};\\\", \\\"{x:1132,y:904,t:1527628220145};\\\", \\\"{x:1135,y:904,t:1527628220162};\\\", \\\"{x:1136,y:904,t:1527628220179};\\\", \\\"{x:1139,y:904,t:1527628220194};\\\", \\\"{x:1140,y:904,t:1527628220226};\\\", \\\"{x:1141,y:904,t:1527628220250};\\\", \\\"{x:1143,y:905,t:1527628220683};\\\", \\\"{x:1145,y:905,t:1527628220706};\\\", \\\"{x:1145,y:906,t:1527628220715};\\\", \\\"{x:1146,y:906,t:1527628220729};\\\", \\\"{x:1148,y:908,t:1527628220745};\\\", \\\"{x:1149,y:909,t:1527628220762};\\\", \\\"{x:1149,y:910,t:1527628220779};\\\", \\\"{x:1150,y:910,t:1527628220795};\\\", \\\"{x:1150,y:911,t:1527628220812};\\\", \\\"{x:1151,y:911,t:1527628225979};\\\", \\\"{x:1152,y:911,t:1527628226314};\\\", \\\"{x:1154,y:911,t:1527628226345};\\\", \\\"{x:1154,y:910,t:1527628226369};\\\", \\\"{x:1155,y:909,t:1527628226409};\\\", \\\"{x:1157,y:909,t:1527628228514};\\\", \\\"{x:1158,y:907,t:1527628228532};\\\", \\\"{x:1159,y:907,t:1527628228658};\\\", \\\"{x:1162,y:907,t:1527628228770};\\\", \\\"{x:1166,y:907,t:1527628228782};\\\", \\\"{x:1170,y:906,t:1527628228799};\\\", \\\"{x:1178,y:903,t:1527628228816};\\\", \\\"{x:1187,y:902,t:1527628228832};\\\", \\\"{x:1202,y:900,t:1527628228849};\\\", \\\"{x:1210,y:900,t:1527628228865};\\\", \\\"{x:1211,y:899,t:1527628228882};\\\", \\\"{x:1211,y:897,t:1527628230499};\\\", \\\"{x:1211,y:888,t:1527628230517};\\\", \\\"{x:1211,y:880,t:1527628230533};\\\", \\\"{x:1214,y:871,t:1527628230549};\\\", \\\"{x:1218,y:858,t:1527628230566};\\\", \\\"{x:1224,y:848,t:1527628230584};\\\", \\\"{x:1227,y:841,t:1527628230599};\\\", \\\"{x:1231,y:833,t:1527628230616};\\\", \\\"{x:1234,y:822,t:1527628230634};\\\", \\\"{x:1237,y:820,t:1527628230650};\\\", \\\"{x:1239,y:815,t:1527628230667};\\\", \\\"{x:1241,y:811,t:1527628230683};\\\", \\\"{x:1242,y:808,t:1527628230699};\\\", \\\"{x:1244,y:804,t:1527628230716};\\\", \\\"{x:1245,y:801,t:1527628230733};\\\", \\\"{x:1245,y:798,t:1527628230749};\\\", \\\"{x:1247,y:794,t:1527628230766};\\\", \\\"{x:1248,y:789,t:1527628230783};\\\", \\\"{x:1251,y:778,t:1527628230799};\\\", \\\"{x:1253,y:771,t:1527628230816};\\\", \\\"{x:1254,y:762,t:1527628230833};\\\", \\\"{x:1256,y:755,t:1527628230849};\\\", \\\"{x:1259,y:740,t:1527628230866};\\\", \\\"{x:1261,y:732,t:1527628230884};\\\", \\\"{x:1264,y:723,t:1527628230900};\\\", \\\"{x:1265,y:719,t:1527628230917};\\\", \\\"{x:1267,y:712,t:1527628230934};\\\", \\\"{x:1268,y:707,t:1527628230950};\\\", \\\"{x:1270,y:704,t:1527628230966};\\\", \\\"{x:1270,y:701,t:1527628230983};\\\", \\\"{x:1270,y:697,t:1527628231000};\\\", \\\"{x:1272,y:694,t:1527628231017};\\\", \\\"{x:1273,y:686,t:1527628231033};\\\", \\\"{x:1273,y:684,t:1527628231050};\\\", \\\"{x:1273,y:682,t:1527628231066};\\\", \\\"{x:1273,y:680,t:1527628231083};\\\", \\\"{x:1274,y:677,t:1527628231100};\\\", \\\"{x:1276,y:673,t:1527628231116};\\\", \\\"{x:1276,y:667,t:1527628231134};\\\", \\\"{x:1276,y:662,t:1527628231150};\\\", \\\"{x:1278,y:655,t:1527628231166};\\\", \\\"{x:1278,y:648,t:1527628231184};\\\", \\\"{x:1280,y:640,t:1527628231200};\\\", \\\"{x:1282,y:633,t:1527628231216};\\\", \\\"{x:1286,y:623,t:1527628231234};\\\", \\\"{x:1286,y:619,t:1527628231250};\\\", \\\"{x:1288,y:610,t:1527628231266};\\\", \\\"{x:1289,y:602,t:1527628231283};\\\", \\\"{x:1292,y:592,t:1527628231301};\\\", \\\"{x:1294,y:585,t:1527628231316};\\\", \\\"{x:1295,y:582,t:1527628231333};\\\", \\\"{x:1298,y:578,t:1527628231350};\\\", \\\"{x:1304,y:574,t:1527628231366};\\\", \\\"{x:1314,y:568,t:1527628231384};\\\", \\\"{x:1330,y:559,t:1527628231401};\\\", \\\"{x:1336,y:556,t:1527628231416};\\\", \\\"{x:1336,y:555,t:1527628231946};\\\", \\\"{x:1336,y:554,t:1527628232138};\\\", \\\"{x:1336,y:549,t:1527628232150};\\\", \\\"{x:1339,y:543,t:1527628232168};\\\", \\\"{x:1341,y:537,t:1527628232183};\\\", \\\"{x:1343,y:530,t:1527628232201};\\\", \\\"{x:1344,y:527,t:1527628232218};\\\", \\\"{x:1344,y:524,t:1527628232234};\\\", \\\"{x:1344,y:523,t:1527628232250};\\\", \\\"{x:1345,y:522,t:1527628232507};\\\", \\\"{x:1347,y:521,t:1527628232586};\\\", \\\"{x:1349,y:519,t:1527628232610};\\\", \\\"{x:1350,y:518,t:1527628232618};\\\", \\\"{x:1352,y:516,t:1527628232634};\\\", \\\"{x:1359,y:509,t:1527628232650};\\\", \\\"{x:1366,y:501,t:1527628232667};\\\", \\\"{x:1372,y:495,t:1527628232684};\\\", \\\"{x:1378,y:486,t:1527628232701};\\\", \\\"{x:1383,y:477,t:1527628232717};\\\", \\\"{x:1385,y:471,t:1527628232734};\\\", \\\"{x:1387,y:466,t:1527628232751};\\\", \\\"{x:1387,y:464,t:1527628232768};\\\", \\\"{x:1388,y:456,t:1527628232786};\\\", \\\"{x:1389,y:453,t:1527628232800};\\\", \\\"{x:1391,y:447,t:1527628232818};\\\", \\\"{x:1396,y:436,t:1527628232834};\\\", \\\"{x:1400,y:429,t:1527628232850};\\\", \\\"{x:1401,y:419,t:1527628232867};\\\", \\\"{x:1404,y:406,t:1527628232884};\\\", \\\"{x:1407,y:397,t:1527628232900};\\\", \\\"{x:1409,y:388,t:1527628232918};\\\", \\\"{x:1410,y:381,t:1527628232935};\\\", \\\"{x:1413,y:376,t:1527628232951};\\\", \\\"{x:1414,y:373,t:1527628232967};\\\", \\\"{x:1416,y:370,t:1527628232986};\\\", \\\"{x:1416,y:369,t:1527628233002};\\\", \\\"{x:1393,y:370,t:1527628235483};\\\", \\\"{x:1330,y:387,t:1527628235490};\\\", \\\"{x:1265,y:393,t:1527628235501};\\\", \\\"{x:1124,y:415,t:1527628235519};\\\", \\\"{x:988,y:432,t:1527628235536};\\\", \\\"{x:896,y:435,t:1527628235552};\\\", \\\"{x:826,y:448,t:1527628235568};\\\", \\\"{x:786,y:450,t:1527628235585};\\\", \\\"{x:784,y:450,t:1527628235595};\\\", \\\"{x:779,y:451,t:1527628235613};\\\", \\\"{x:773,y:453,t:1527628235629};\\\", \\\"{x:766,y:458,t:1527628235646};\\\", \\\"{x:753,y:463,t:1527628235663};\\\", \\\"{x:739,y:468,t:1527628235680};\\\", \\\"{x:723,y:474,t:1527628235697};\\\", \\\"{x:710,y:482,t:1527628235714};\\\", \\\"{x:709,y:482,t:1527628235730};\\\", \\\"{x:707,y:483,t:1527628235801};\\\", \\\"{x:705,y:484,t:1527628235814};\\\", \\\"{x:697,y:487,t:1527628235831};\\\", \\\"{x:686,y:488,t:1527628235847};\\\", \\\"{x:670,y:491,t:1527628235864};\\\", \\\"{x:651,y:492,t:1527628235881};\\\", \\\"{x:644,y:492,t:1527628235897};\\\", \\\"{x:641,y:492,t:1527628235915};\\\", \\\"{x:637,y:492,t:1527628235931};\\\", \\\"{x:636,y:492,t:1527628235947};\\\", \\\"{x:635,y:492,t:1527628236002};\\\", \\\"{x:634,y:492,t:1527628236025};\\\", \\\"{x:631,y:492,t:1527628236034};\\\", \\\"{x:626,y:492,t:1527628236049};\\\", \\\"{x:614,y:492,t:1527628236065};\\\", \\\"{x:600,y:492,t:1527628236081};\\\", \\\"{x:599,y:492,t:1527628236099};\\\", \\\"{x:598,y:492,t:1527628236115};\\\", \\\"{x:599,y:492,t:1527628238938};\\\", \\\"{x:603,y:491,t:1527628238951};\\\", \\\"{x:610,y:490,t:1527628238966};\\\", \\\"{x:611,y:490,t:1527628238983};\\\", \\\"{x:613,y:489,t:1527628238999};\\\", \\\"{x:614,y:489,t:1527628239489};\\\", \\\"{x:622,y:489,t:1527628239501};\\\", \\\"{x:665,y:490,t:1527628239517};\\\", \\\"{x:731,y:498,t:1527628239533};\\\", \\\"{x:832,y:514,t:1527628239550};\\\", \\\"{x:949,y:535,t:1527628239566};\\\", \\\"{x:1070,y:549,t:1527628239583};\\\", \\\"{x:1180,y:573,t:1527628239600};\\\", \\\"{x:1220,y:576,t:1527628239616};\\\", \\\"{x:1221,y:576,t:1527628240362};\\\", \\\"{x:1222,y:575,t:1527628240457};\\\", \\\"{x:1226,y:572,t:1527628240468};\\\", \\\"{x:1234,y:564,t:1527628240486};\\\", \\\"{x:1241,y:560,t:1527628240503};\\\", \\\"{x:1247,y:557,t:1527628240518};\\\", \\\"{x:1255,y:556,t:1527628240536};\\\", \\\"{x:1272,y:553,t:1527628240553};\\\", \\\"{x:1283,y:553,t:1527628240570};\\\", \\\"{x:1297,y:553,t:1527628240586};\\\", \\\"{x:1318,y:553,t:1527628240603};\\\", \\\"{x:1348,y:553,t:1527628240620};\\\", \\\"{x:1391,y:554,t:1527628240636};\\\", \\\"{x:1431,y:554,t:1527628240653};\\\", \\\"{x:1451,y:555,t:1527628240670};\\\", \\\"{x:1473,y:555,t:1527628240686};\\\", \\\"{x:1482,y:555,t:1527628240704};\\\", \\\"{x:1485,y:555,t:1527628240720};\\\", \\\"{x:1486,y:555,t:1527628240737};\\\", \\\"{x:1485,y:556,t:1527628241458};\\\", \\\"{x:1485,y:558,t:1527628241498};\\\", \\\"{x:1481,y:563,t:1527628241506};\\\", \\\"{x:1476,y:577,t:1527628241523};\\\", \\\"{x:1466,y:595,t:1527628241540};\\\", \\\"{x:1453,y:616,t:1527628241556};\\\", \\\"{x:1439,y:656,t:1527628241572};\\\", \\\"{x:1426,y:682,t:1527628241589};\\\", \\\"{x:1413,y:711,t:1527628241606};\\\", \\\"{x:1396,y:745,t:1527628241624};\\\", \\\"{x:1376,y:775,t:1527628241640};\\\", \\\"{x:1361,y:794,t:1527628241656};\\\", \\\"{x:1345,y:813,t:1527628241673};\\\", \\\"{x:1342,y:820,t:1527628241690};\\\", \\\"{x:1339,y:824,t:1527628241706};\\\", \\\"{x:1338,y:828,t:1527628241723};\\\", \\\"{x:1333,y:835,t:1527628241740};\\\", \\\"{x:1322,y:844,t:1527628241757};\\\", \\\"{x:1303,y:853,t:1527628241774};\\\", \\\"{x:1284,y:860,t:1527628241790};\\\", \\\"{x:1275,y:866,t:1527628241806};\\\", \\\"{x:1274,y:866,t:1527628241823};\\\", \\\"{x:1264,y:865,t:1527628241840};\\\", \\\"{x:1249,y:858,t:1527628241857};\\\", \\\"{x:1236,y:855,t:1527628241873};\\\", \\\"{x:1226,y:852,t:1527628241891};\\\", \\\"{x:1220,y:849,t:1527628241907};\\\", \\\"{x:1220,y:847,t:1527628241954};\\\", \\\"{x:1221,y:845,t:1527628241961};\\\", \\\"{x:1221,y:843,t:1527628241974};\\\", \\\"{x:1223,y:839,t:1527628241991};\\\", \\\"{x:1228,y:833,t:1527628242007};\\\", \\\"{x:1230,y:831,t:1527628242024};\\\", \\\"{x:1230,y:828,t:1527628242042};\\\", \\\"{x:1232,y:826,t:1527628242058};\\\", \\\"{x:1235,y:822,t:1527628242075};\\\", \\\"{x:1244,y:812,t:1527628242092};\\\", \\\"{x:1260,y:798,t:1527628242108};\\\", \\\"{x:1269,y:786,t:1527628242125};\\\", \\\"{x:1281,y:762,t:1527628242142};\\\", \\\"{x:1296,y:718,t:1527628242159};\\\", \\\"{x:1310,y:657,t:1527628242174};\\\", \\\"{x:1329,y:591,t:1527628242191};\\\", \\\"{x:1368,y:507,t:1527628242208};\\\", \\\"{x:1384,y:471,t:1527628242225};\\\", \\\"{x:1415,y:405,t:1527628242241};\\\", \\\"{x:1443,y:361,t:1527628242259};\\\", \\\"{x:1456,y:333,t:1527628242275};\\\", \\\"{x:1466,y:308,t:1527628242291};\\\", \\\"{x:1476,y:285,t:1527628242308};\\\", \\\"{x:1483,y:261,t:1527628242325};\\\", \\\"{x:1485,y:243,t:1527628242341};\\\", \\\"{x:1488,y:233,t:1527628242358};\\\", \\\"{x:1489,y:231,t:1527628242375};\\\", \\\"{x:1489,y:230,t:1527628242392};\\\", \\\"{x:1489,y:229,t:1527628242409};\\\", \\\"{x:1489,y:228,t:1527628242425};\\\", \\\"{x:1489,y:227,t:1527628242490};\\\", \\\"{x:1488,y:227,t:1527628242498};\\\", \\\"{x:1485,y:227,t:1527628242513};\\\", \\\"{x:1484,y:227,t:1527628242526};\\\", \\\"{x:1483,y:227,t:1527628242543};\\\", \\\"{x:1481,y:227,t:1527628242559};\\\", \\\"{x:1479,y:227,t:1527628242575};\\\", \\\"{x:1478,y:228,t:1527628242593};\\\", \\\"{x:1475,y:231,t:1527628242610};\\\", \\\"{x:1475,y:232,t:1527628242635};\\\", \\\"{x:1474,y:233,t:1527628242643};\\\", \\\"{x:1474,y:234,t:1527628243034};\\\", \\\"{x:1474,y:235,t:1527628243066};\\\", \\\"{x:1474,y:236,t:1527628243082};\\\", \\\"{x:1474,y:237,t:1527628243097};\\\", \\\"{x:1474,y:238,t:1527628243114};\\\", \\\"{x:1474,y:240,t:1527628243128};\\\", \\\"{x:1475,y:242,t:1527628243145};\\\", \\\"{x:1475,y:243,t:1527628243162};\\\", \\\"{x:1475,y:245,t:1527628243178};\\\", \\\"{x:1476,y:246,t:1527628243650};\\\", \\\"{x:1477,y:246,t:1527628243662};\\\", \\\"{x:1478,y:246,t:1527628243679};\\\", \\\"{x:1479,y:246,t:1527628243696};\\\", \\\"{x:1480,y:246,t:1527628243712};\\\", \\\"{x:1481,y:249,t:1527628243930};\\\", \\\"{x:1477,y:262,t:1527628243948};\\\", \\\"{x:1471,y:283,t:1527628243963};\\\", \\\"{x:1461,y:324,t:1527628243981};\\\", \\\"{x:1446,y:384,t:1527628243997};\\\", \\\"{x:1425,y:452,t:1527628244014};\\\", \\\"{x:1394,y:511,t:1527628244031};\\\", \\\"{x:1365,y:562,t:1527628244046};\\\", \\\"{x:1338,y:611,t:1527628244064};\\\", \\\"{x:1320,y:639,t:1527628244080};\\\", \\\"{x:1311,y:650,t:1527628244097};\\\", \\\"{x:1311,y:652,t:1527628244113};\\\", \\\"{x:1310,y:652,t:1527628244250};\\\", \\\"{x:1309,y:653,t:1527628244265};\\\", \\\"{x:1306,y:654,t:1527628244281};\\\", \\\"{x:1305,y:655,t:1527628244298};\\\", \\\"{x:1297,y:659,t:1527628244314};\\\", \\\"{x:1286,y:666,t:1527628244331};\\\", \\\"{x:1278,y:675,t:1527628244347};\\\", \\\"{x:1265,y:691,t:1527628244365};\\\", \\\"{x:1253,y:709,t:1527628244381};\\\", \\\"{x:1247,y:720,t:1527628244399};\\\", \\\"{x:1244,y:729,t:1527628244415};\\\", \\\"{x:1243,y:734,t:1527628244432};\\\", \\\"{x:1241,y:741,t:1527628244448};\\\", \\\"{x:1241,y:744,t:1527628244465};\\\", \\\"{x:1234,y:759,t:1527628244482};\\\", \\\"{x:1231,y:771,t:1527628244499};\\\", \\\"{x:1226,y:780,t:1527628244516};\\\", \\\"{x:1221,y:793,t:1527628244532};\\\", \\\"{x:1215,y:806,t:1527628244548};\\\", \\\"{x:1210,y:816,t:1527628244566};\\\", \\\"{x:1203,y:828,t:1527628244582};\\\", \\\"{x:1195,y:841,t:1527628244599};\\\", \\\"{x:1186,y:852,t:1527628244616};\\\", \\\"{x:1181,y:860,t:1527628244633};\\\", \\\"{x:1179,y:863,t:1527628244649};\\\", \\\"{x:1177,y:869,t:1527628244666};\\\", \\\"{x:1175,y:872,t:1527628244683};\\\", \\\"{x:1174,y:874,t:1527628244698};\\\", \\\"{x:1172,y:875,t:1527628244721};\\\", \\\"{x:1171,y:878,t:1527628244732};\\\", \\\"{x:1168,y:882,t:1527628244750};\\\", \\\"{x:1167,y:884,t:1527628244766};\\\", \\\"{x:1169,y:884,t:1527628244866};\\\", \\\"{x:1176,y:884,t:1527628244882};\\\", \\\"{x:1188,y:882,t:1527628244899};\\\", \\\"{x:1208,y:886,t:1527628244917};\\\", \\\"{x:1221,y:887,t:1527628244933};\\\", \\\"{x:1239,y:886,t:1527628244950};\\\", \\\"{x:1260,y:889,t:1527628244967};\\\", \\\"{x:1271,y:886,t:1527628244983};\\\", \\\"{x:1275,y:883,t:1527628245000};\\\", \\\"{x:1278,y:883,t:1527628245017};\\\", \\\"{x:1298,y:867,t:1527628245033};\\\", \\\"{x:1347,y:789,t:1527628245049};\\\", \\\"{x:1407,y:667,t:1527628245067};\\\", \\\"{x:1437,y:562,t:1527628245083};\\\", \\\"{x:1441,y:502,t:1527628245101};\\\", \\\"{x:1441,y:455,t:1527628245116};\\\", \\\"{x:1440,y:404,t:1527628245133};\\\", \\\"{x:1429,y:384,t:1527628245150};\\\", \\\"{x:1418,y:366,t:1527628245167};\\\", \\\"{x:1410,y:356,t:1527628245183};\\\", \\\"{x:1408,y:348,t:1527628245200};\\\", \\\"{x:1408,y:331,t:1527628245216};\\\", \\\"{x:1408,y:318,t:1527628245233};\\\", \\\"{x:1410,y:309,t:1527628245250};\\\", \\\"{x:1412,y:304,t:1527628245267};\\\", \\\"{x:1416,y:299,t:1527628245284};\\\", \\\"{x:1423,y:296,t:1527628245300};\\\", \\\"{x:1429,y:292,t:1527628245318};\\\", \\\"{x:1439,y:287,t:1527628245334};\\\", \\\"{x:1447,y:283,t:1527628245350};\\\", \\\"{x:1455,y:280,t:1527628245367};\\\", \\\"{x:1463,y:278,t:1527628245384};\\\", \\\"{x:1475,y:271,t:1527628245400};\\\", \\\"{x:1478,y:270,t:1527628245417};\\\", \\\"{x:1479,y:270,t:1527628245434};\\\", \\\"{x:1480,y:269,t:1527628245452};\\\", \\\"{x:1482,y:269,t:1527628245468};\\\", \\\"{x:1483,y:269,t:1527628245497};\\\", \\\"{x:1485,y:269,t:1527628245505};\\\", \\\"{x:1486,y:269,t:1527628245519};\\\", \\\"{x:1495,y:277,t:1527628245535};\\\", \\\"{x:1508,y:299,t:1527628245551};\\\", \\\"{x:1526,y:320,t:1527628245568};\\\", \\\"{x:1546,y:342,t:1527628245584};\\\", \\\"{x:1583,y:385,t:1527628245601};\\\", \\\"{x:1605,y:412,t:1527628245618};\\\", \\\"{x:1621,y:430,t:1527628245636};\\\", \\\"{x:1632,y:445,t:1527628245652};\\\", \\\"{x:1636,y:453,t:1527628245668};\\\", \\\"{x:1636,y:456,t:1527628245686};\\\", \\\"{x:1636,y:462,t:1527628245702};\\\", \\\"{x:1635,y:470,t:1527628245719};\\\", \\\"{x:1634,y:478,t:1527628245736};\\\", \\\"{x:1628,y:486,t:1527628245752};\\\", \\\"{x:1619,y:496,t:1527628245768};\\\", \\\"{x:1613,y:510,t:1527628245785};\\\", \\\"{x:1609,y:517,t:1527628245803};\\\", \\\"{x:1606,y:523,t:1527628245819};\\\", \\\"{x:1605,y:530,t:1527628245836};\\\", \\\"{x:1605,y:536,t:1527628245853};\\\", \\\"{x:1605,y:539,t:1527628245870};\\\", \\\"{x:1606,y:544,t:1527628245885};\\\", \\\"{x:1609,y:548,t:1527628245903};\\\", \\\"{x:1621,y:556,t:1527628245920};\\\", \\\"{x:1626,y:560,t:1527628245936};\\\", \\\"{x:1629,y:563,t:1527628245953};\\\", \\\"{x:1639,y:579,t:1527628245970};\\\", \\\"{x:1646,y:592,t:1527628245986};\\\", \\\"{x:1654,y:607,t:1527628246003};\\\", \\\"{x:1659,y:625,t:1527628246020};\\\", \\\"{x:1666,y:647,t:1527628246037};\\\", \\\"{x:1671,y:665,t:1527628246052};\\\", \\\"{x:1673,y:686,t:1527628246070};\\\", \\\"{x:1675,y:695,t:1527628246087};\\\", \\\"{x:1675,y:702,t:1527628246104};\\\", \\\"{x:1679,y:715,t:1527628246120};\\\", \\\"{x:1688,y:736,t:1527628246137};\\\", \\\"{x:1705,y:765,t:1527628246154};\\\", \\\"{x:1724,y:781,t:1527628246171};\\\", \\\"{x:1736,y:794,t:1527628246187};\\\", \\\"{x:1745,y:802,t:1527628246204};\\\", \\\"{x:1747,y:807,t:1527628246221};\\\", \\\"{x:1749,y:812,t:1527628246237};\\\", \\\"{x:1750,y:813,t:1527628246254};\\\", \\\"{x:1750,y:815,t:1527628246338};\\\", \\\"{x:1751,y:816,t:1527628246353};\\\", \\\"{x:1751,y:817,t:1527628246401};\\\", \\\"{x:1751,y:819,t:1527628246409};\\\", \\\"{x:1751,y:821,t:1527628246421};\\\", \\\"{x:1751,y:826,t:1527628246438};\\\", \\\"{x:1751,y:834,t:1527628246455};\\\", \\\"{x:1751,y:846,t:1527628246471};\\\", \\\"{x:1751,y:856,t:1527628246488};\\\", \\\"{x:1749,y:875,t:1527628246506};\\\", \\\"{x:1749,y:881,t:1527628246521};\\\", \\\"{x:1755,y:899,t:1527628246537};\\\", \\\"{x:1758,y:905,t:1527628246554};\\\", \\\"{x:1760,y:910,t:1527628246572};\\\", \\\"{x:1762,y:912,t:1527628246588};\\\", \\\"{x:1763,y:913,t:1527628246625};\\\", \\\"{x:1763,y:914,t:1527628246642};\\\", \\\"{x:1764,y:916,t:1527628246655};\\\", \\\"{x:1765,y:916,t:1527628246672};\\\", \\\"{x:1768,y:917,t:1527628246689};\\\", \\\"{x:1777,y:919,t:1527628246706};\\\", \\\"{x:1785,y:921,t:1527628246722};\\\", \\\"{x:1794,y:924,t:1527628246739};\\\", \\\"{x:1798,y:924,t:1527628246756};\\\", \\\"{x:1801,y:924,t:1527628246817};\\\", \\\"{x:1804,y:924,t:1527628246833};\\\", \\\"{x:1805,y:923,t:1527628246841};\\\", \\\"{x:1807,y:923,t:1527628246856};\\\", \\\"{x:1807,y:922,t:1527628246872};\\\", \\\"{x:1808,y:922,t:1527628248450};\\\", \\\"{x:1810,y:922,t:1527628249346};\\\", \\\"{x:1808,y:922,t:1527628254441};\\\", \\\"{x:1808,y:920,t:1527628255049};\\\", \\\"{x:1808,y:918,t:1527628255378};\\\", \\\"{x:1808,y:917,t:1527628255569};\\\", \\\"{x:1809,y:915,t:1527628257122};\\\", \\\"{x:1810,y:915,t:1527628257136};\\\", \\\"{x:1814,y:915,t:1527628257153};\\\", \\\"{x:1817,y:915,t:1527628257170};\\\", \\\"{x:1818,y:915,t:1527628257187};\\\", \\\"{x:1819,y:916,t:1527628257689};\\\", \\\"{x:1819,y:917,t:1527628257713};\\\", \\\"{x:1819,y:919,t:1527628257906};\\\", \\\"{x:1816,y:920,t:1527628257922};\\\", \\\"{x:1808,y:920,t:1527628257939};\\\", \\\"{x:1797,y:920,t:1527628257956};\\\", \\\"{x:1786,y:920,t:1527628257973};\\\", \\\"{x:1770,y:920,t:1527628257989};\\\", \\\"{x:1763,y:920,t:1527628258007};\\\", \\\"{x:1759,y:920,t:1527628258022};\\\", \\\"{x:1754,y:920,t:1527628258039};\\\", \\\"{x:1749,y:920,t:1527628258056};\\\", \\\"{x:1739,y:920,t:1527628258073};\\\", \\\"{x:1725,y:920,t:1527628258093};\\\", \\\"{x:1716,y:918,t:1527628258105};\\\", \\\"{x:1706,y:916,t:1527628258123};\\\", \\\"{x:1699,y:915,t:1527628258138};\\\", \\\"{x:1697,y:914,t:1527628258155};\\\", \\\"{x:1695,y:914,t:1527628258172};\\\", \\\"{x:1694,y:914,t:1527628258189};\\\", \\\"{x:1692,y:914,t:1527628258205};\\\", \\\"{x:1688,y:914,t:1527628258222};\\\", \\\"{x:1686,y:915,t:1527628258240};\\\", \\\"{x:1682,y:915,t:1527628258256};\\\", \\\"{x:1675,y:915,t:1527628258273};\\\", \\\"{x:1673,y:914,t:1527628258290};\\\", \\\"{x:1669,y:914,t:1527628258307};\\\", \\\"{x:1667,y:912,t:1527628258322};\\\", \\\"{x:1663,y:912,t:1527628258339};\\\", \\\"{x:1658,y:912,t:1527628258357};\\\", \\\"{x:1655,y:912,t:1527628258373};\\\", \\\"{x:1654,y:912,t:1527628258389};\\\", \\\"{x:1653,y:912,t:1527628258407};\\\", \\\"{x:1652,y:912,t:1527628258424};\\\", \\\"{x:1650,y:912,t:1527628258440};\\\", \\\"{x:1644,y:915,t:1527628258457};\\\", \\\"{x:1643,y:915,t:1527628262553};\\\", \\\"{x:1635,y:914,t:1527628262674};\\\", \\\"{x:1628,y:911,t:1527628262686};\\\", \\\"{x:1607,y:905,t:1527628262704};\\\", \\\"{x:1586,y:899,t:1527628262721};\\\", \\\"{x:1567,y:892,t:1527628262737};\\\", \\\"{x:1537,y:880,t:1527628262753};\\\", \\\"{x:1512,y:870,t:1527628262771};\\\", \\\"{x:1488,y:861,t:1527628262787};\\\", \\\"{x:1470,y:851,t:1527628262803};\\\", \\\"{x:1448,y:839,t:1527628262821};\\\", \\\"{x:1422,y:815,t:1527628262837};\\\", \\\"{x:1409,y:800,t:1527628262854};\\\", \\\"{x:1396,y:780,t:1527628262871};\\\", \\\"{x:1387,y:768,t:1527628262888};\\\", \\\"{x:1377,y:752,t:1527628262905};\\\", \\\"{x:1377,y:750,t:1527628262921};\\\", \\\"{x:1376,y:750,t:1527628262937};\\\", \\\"{x:1375,y:750,t:1527628263018};\\\", \\\"{x:1373,y:750,t:1527628263025};\\\", \\\"{x:1372,y:750,t:1527628263038};\\\", \\\"{x:1368,y:752,t:1527628263054};\\\", \\\"{x:1367,y:752,t:1527628263071};\\\", \\\"{x:1365,y:752,t:1527628263162};\\\", \\\"{x:1363,y:752,t:1527628263171};\\\", \\\"{x:1360,y:747,t:1527628263189};\\\", \\\"{x:1360,y:745,t:1527628263206};\\\", \\\"{x:1360,y:742,t:1527628263222};\\\", \\\"{x:1360,y:739,t:1527628263239};\\\", \\\"{x:1360,y:737,t:1527628263255};\\\", \\\"{x:1360,y:735,t:1527628263272};\\\", \\\"{x:1360,y:732,t:1527628263288};\\\", \\\"{x:1360,y:728,t:1527628263305};\\\", \\\"{x:1360,y:727,t:1527628263323};\\\", \\\"{x:1360,y:725,t:1527628263338};\\\", \\\"{x:1360,y:721,t:1527628263355};\\\", \\\"{x:1359,y:721,t:1527628263372};\\\", \\\"{x:1358,y:720,t:1527628263398};\\\", \\\"{x:1358,y:719,t:1527628263419};\\\", \\\"{x:1357,y:718,t:1527628263460};\\\", \\\"{x:1356,y:718,t:1527628263467};\\\", \\\"{x:1350,y:722,t:1527628263483};\\\", \\\"{x:1336,y:738,t:1527628263500};\\\", \\\"{x:1329,y:749,t:1527628263516};\\\", \\\"{x:1326,y:756,t:1527628263533};\\\", \\\"{x:1323,y:764,t:1527628263550};\\\", \\\"{x:1321,y:770,t:1527628263567};\\\", \\\"{x:1318,y:778,t:1527628263583};\\\", \\\"{x:1315,y:789,t:1527628263600};\\\", \\\"{x:1310,y:802,t:1527628263617};\\\", \\\"{x:1303,y:816,t:1527628263633};\\\", \\\"{x:1296,y:828,t:1527628263650};\\\", \\\"{x:1288,y:840,t:1527628263667};\\\", \\\"{x:1276,y:859,t:1527628263683};\\\", \\\"{x:1268,y:869,t:1527628263699};\\\", \\\"{x:1262,y:875,t:1527628263717};\\\", \\\"{x:1251,y:883,t:1527628263734};\\\", \\\"{x:1239,y:889,t:1527628263750};\\\", \\\"{x:1228,y:894,t:1527628263767};\\\", \\\"{x:1217,y:898,t:1527628263784};\\\", \\\"{x:1207,y:903,t:1527628263801};\\\", \\\"{x:1200,y:907,t:1527628263817};\\\", \\\"{x:1194,y:909,t:1527628263834};\\\", \\\"{x:1191,y:912,t:1527628263851};\\\", \\\"{x:1188,y:914,t:1527628263868};\\\", \\\"{x:1188,y:915,t:1527628263892};\\\", \\\"{x:1188,y:916,t:1527628263901};\\\", \\\"{x:1188,y:917,t:1527628263918};\\\", \\\"{x:1188,y:920,t:1527628263934};\\\", \\\"{x:1188,y:925,t:1527628263951};\\\", \\\"{x:1195,y:932,t:1527628263967};\\\", \\\"{x:1203,y:937,t:1527628263985};\\\", \\\"{x:1207,y:937,t:1527628264001};\\\", \\\"{x:1209,y:938,t:1527628264018};\\\", \\\"{x:1210,y:938,t:1527628264035};\\\", \\\"{x:1211,y:938,t:1527628264092};\\\", \\\"{x:1212,y:938,t:1527628264108};\\\", \\\"{x:1213,y:937,t:1527628264118};\\\", \\\"{x:1213,y:936,t:1527628264134};\\\", \\\"{x:1213,y:934,t:1527628264163};\\\", \\\"{x:1212,y:932,t:1527628264197};\\\", \\\"{x:1212,y:931,t:1527628264212};\\\", \\\"{x:1212,y:930,t:1527628264220};\\\", \\\"{x:1212,y:927,t:1527628264235};\\\", \\\"{x:1212,y:924,t:1527628264259};\\\", \\\"{x:1212,y:923,t:1527628264291};\\\", \\\"{x:1212,y:922,t:1527628264302};\\\", \\\"{x:1212,y:921,t:1527628264319};\\\", \\\"{x:1213,y:921,t:1527628264335};\\\", \\\"{x:1214,y:920,t:1527628264352};\\\", \\\"{x:1216,y:918,t:1527628265051};\\\", \\\"{x:1217,y:915,t:1527628265060};\\\", \\\"{x:1220,y:913,t:1527628265071};\\\", \\\"{x:1226,y:907,t:1527628265088};\\\", \\\"{x:1232,y:902,t:1527628265105};\\\", \\\"{x:1236,y:898,t:1527628265121};\\\", \\\"{x:1238,y:897,t:1527628265138};\\\", \\\"{x:1238,y:898,t:1527628265388};\\\", \\\"{x:1238,y:900,t:1527628265405};\\\", \\\"{x:1238,y:901,t:1527628265500};\\\", \\\"{x:1239,y:901,t:1527628265507};\\\", \\\"{x:1242,y:901,t:1527628265522};\\\", \\\"{x:1249,y:897,t:1527628265539};\\\", \\\"{x:1257,y:893,t:1527628265556};\\\", \\\"{x:1264,y:888,t:1527628265573};\\\", \\\"{x:1272,y:883,t:1527628265589};\\\", \\\"{x:1282,y:873,t:1527628265605};\\\", \\\"{x:1291,y:865,t:1527628265623};\\\", \\\"{x:1299,y:860,t:1527628265639};\\\", \\\"{x:1300,y:857,t:1527628265656};\\\", \\\"{x:1302,y:854,t:1527628265673};\\\", \\\"{x:1306,y:849,t:1527628265690};\\\", \\\"{x:1310,y:843,t:1527628265707};\\\", \\\"{x:1319,y:834,t:1527628265723};\\\", \\\"{x:1333,y:818,t:1527628265740};\\\", \\\"{x:1342,y:808,t:1527628265755};\\\", \\\"{x:1347,y:798,t:1527628265773};\\\", \\\"{x:1354,y:786,t:1527628265790};\\\", \\\"{x:1359,y:772,t:1527628265807};\\\", \\\"{x:1364,y:757,t:1527628265823};\\\", \\\"{x:1365,y:744,t:1527628265840};\\\", \\\"{x:1369,y:735,t:1527628265857};\\\", \\\"{x:1370,y:731,t:1527628265873};\\\", \\\"{x:1370,y:727,t:1527628265891};\\\", \\\"{x:1371,y:721,t:1527628265908};\\\", \\\"{x:1369,y:718,t:1527628265923};\\\", \\\"{x:1364,y:715,t:1527628265940};\\\", \\\"{x:1360,y:715,t:1527628265957};\\\", \\\"{x:1358,y:714,t:1527628265974};\\\", \\\"{x:1358,y:713,t:1527628265997};\\\", \\\"{x:1357,y:713,t:1527628266012};\\\", \\\"{x:1356,y:713,t:1527628266028};\\\", \\\"{x:1355,y:712,t:1527628266052};\\\", \\\"{x:1354,y:712,t:1527628266068};\\\", \\\"{x:1353,y:712,t:1527628266100};\\\", \\\"{x:1353,y:711,t:1527628266219};\\\", \\\"{x:1353,y:710,t:1527628266227};\\\", \\\"{x:1351,y:706,t:1527628266241};\\\", \\\"{x:1348,y:702,t:1527628266259};\\\", \\\"{x:1347,y:694,t:1527628266275};\\\", \\\"{x:1347,y:688,t:1527628266291};\\\", \\\"{x:1347,y:680,t:1527628266308};\\\", \\\"{x:1347,y:678,t:1527628266324};\\\", \\\"{x:1347,y:676,t:1527628266341};\\\", \\\"{x:1347,y:674,t:1527628266363};\\\", \\\"{x:1347,y:672,t:1527628266375};\\\", \\\"{x:1354,y:664,t:1527628266392};\\\", \\\"{x:1362,y:650,t:1527628266408};\\\", \\\"{x:1370,y:639,t:1527628266425};\\\", \\\"{x:1371,y:639,t:1527628266442};\\\", \\\"{x:1372,y:637,t:1527628266459};\\\", \\\"{x:1372,y:633,t:1527628266475};\\\", \\\"{x:1369,y:633,t:1527628266500};\\\", \\\"{x:1367,y:633,t:1527628266509};\\\", \\\"{x:1358,y:634,t:1527628266525};\\\", \\\"{x:1351,y:637,t:1527628266542};\\\", \\\"{x:1341,y:645,t:1527628266560};\\\", \\\"{x:1332,y:650,t:1527628266575};\\\", \\\"{x:1325,y:656,t:1527628266592};\\\", \\\"{x:1320,y:665,t:1527628266609};\\\", \\\"{x:1315,y:685,t:1527628266626};\\\", \\\"{x:1309,y:706,t:1527628266642};\\\", \\\"{x:1309,y:728,t:1527628266659};\\\", \\\"{x:1308,y:758,t:1527628266676};\\\", \\\"{x:1308,y:776,t:1527628266693};\\\", \\\"{x:1303,y:791,t:1527628266709};\\\", \\\"{x:1299,y:807,t:1527628266726};\\\", \\\"{x:1298,y:815,t:1527628266743};\\\", \\\"{x:1293,y:825,t:1527628266759};\\\", \\\"{x:1286,y:839,t:1527628266776};\\\", \\\"{x:1277,y:849,t:1527628266793};\\\", \\\"{x:1268,y:859,t:1527628266810};\\\", \\\"{x:1262,y:864,t:1527628266826};\\\", \\\"{x:1255,y:869,t:1527628266843};\\\", \\\"{x:1250,y:870,t:1527628266859};\\\", \\\"{x:1247,y:872,t:1527628266876};\\\", \\\"{x:1243,y:875,t:1527628266893};\\\", \\\"{x:1241,y:876,t:1527628266910};\\\", \\\"{x:1236,y:880,t:1527628266927};\\\", \\\"{x:1233,y:884,t:1527628266943};\\\", \\\"{x:1229,y:888,t:1527628266960};\\\", \\\"{x:1226,y:892,t:1527628266977};\\\", \\\"{x:1224,y:894,t:1527628266993};\\\", \\\"{x:1222,y:897,t:1527628267010};\\\", \\\"{x:1221,y:899,t:1527628267027};\\\", \\\"{x:1221,y:900,t:1527628267067};\\\", \\\"{x:1221,y:901,t:1527628267124};\\\", \\\"{x:1221,y:902,t:1527628267156};\\\", \\\"{x:1222,y:902,t:1527628267188};\\\", \\\"{x:1223,y:902,t:1527628267204};\\\", \\\"{x:1224,y:902,t:1527628267220};\\\", \\\"{x:1225,y:902,t:1527628267332};\\\", \\\"{x:1225,y:901,t:1527628267344};\\\", \\\"{x:1227,y:901,t:1527628267361};\\\", \\\"{x:1227,y:899,t:1527628267378};\\\", \\\"{x:1228,y:896,t:1527628267396};\\\", \\\"{x:1228,y:895,t:1527628267411};\\\", \\\"{x:1229,y:895,t:1527628267428};\\\", \\\"{x:1229,y:897,t:1527628267597};\\\", \\\"{x:1228,y:900,t:1527628267612};\\\", \\\"{x:1227,y:901,t:1527628267629};\\\", \\\"{x:1226,y:902,t:1527628267764};\\\", \\\"{x:1220,y:902,t:1527628268883};\\\", \\\"{x:1199,y:902,t:1527628268899};\\\", \\\"{x:1166,y:902,t:1527628268916};\\\", \\\"{x:1136,y:902,t:1527628268933};\\\", \\\"{x:1117,y:902,t:1527628268948};\\\", \\\"{x:1114,y:902,t:1527628268965};\\\", \\\"{x:1110,y:904,t:1527628268982};\\\", \\\"{x:1109,y:904,t:1527628269003};\\\", \\\"{x:1109,y:905,t:1527628269019};\\\", \\\"{x:1109,y:906,t:1527628269033};\\\", \\\"{x:1110,y:906,t:1527628269100};\\\", \\\"{x:1114,y:911,t:1527628269117};\\\", \\\"{x:1117,y:913,t:1527628269134};\\\", \\\"{x:1124,y:921,t:1527628269150};\\\", \\\"{x:1136,y:925,t:1527628269167};\\\", \\\"{x:1144,y:926,t:1527628269184};\\\", \\\"{x:1155,y:927,t:1527628269200};\\\", \\\"{x:1159,y:927,t:1527628269217};\\\", \\\"{x:1160,y:927,t:1527628269235};\\\", \\\"{x:1160,y:926,t:1527628269268};\\\", \\\"{x:1160,y:925,t:1527628269284};\\\", \\\"{x:1159,y:925,t:1527628269380};\\\", \\\"{x:1160,y:925,t:1527628269780};\\\", \\\"{x:1167,y:925,t:1527628269787};\\\", \\\"{x:1176,y:925,t:1527628269803};\\\", \\\"{x:1205,y:926,t:1527628269820};\\\", \\\"{x:1227,y:926,t:1527628269835};\\\", \\\"{x:1244,y:926,t:1527628269852};\\\", \\\"{x:1254,y:926,t:1527628269869};\\\", \\\"{x:1262,y:926,t:1527628269886};\\\", \\\"{x:1267,y:924,t:1527628269902};\\\", \\\"{x:1276,y:923,t:1527628269919};\\\", \\\"{x:1289,y:921,t:1527628269936};\\\", \\\"{x:1304,y:920,t:1527628269952};\\\", \\\"{x:1322,y:919,t:1527628269969};\\\", \\\"{x:1345,y:919,t:1527628269986};\\\", \\\"{x:1365,y:919,t:1527628270002};\\\", \\\"{x:1392,y:916,t:1527628270020};\\\", \\\"{x:1407,y:916,t:1527628270036};\\\", \\\"{x:1422,y:916,t:1527628270053};\\\", \\\"{x:1435,y:916,t:1527628270069};\\\", \\\"{x:1443,y:916,t:1527628270087};\\\", \\\"{x:1448,y:916,t:1527628270104};\\\", \\\"{x:1455,y:916,t:1527628270120};\\\", \\\"{x:1469,y:914,t:1527628270137};\\\", \\\"{x:1483,y:914,t:1527628270153};\\\", \\\"{x:1494,y:914,t:1527628270170};\\\", \\\"{x:1508,y:914,t:1527628270186};\\\", \\\"{x:1527,y:914,t:1527628270203};\\\", \\\"{x:1542,y:912,t:1527628270219};\\\", \\\"{x:1552,y:912,t:1527628270236};\\\", \\\"{x:1562,y:912,t:1527628270253};\\\", \\\"{x:1572,y:912,t:1527628270271};\\\", \\\"{x:1580,y:912,t:1527628270287};\\\", \\\"{x:1587,y:912,t:1527628270303};\\\", \\\"{x:1589,y:912,t:1527628270320};\\\", \\\"{x:1591,y:912,t:1527628270337};\\\", \\\"{x:1592,y:912,t:1527628270372};\\\", \\\"{x:1593,y:912,t:1527628270388};\\\", \\\"{x:1594,y:913,t:1527628270403};\\\", \\\"{x:1596,y:913,t:1527628270419};\\\", \\\"{x:1597,y:913,t:1527628270436};\\\", \\\"{x:1600,y:913,t:1527628270453};\\\", \\\"{x:1602,y:913,t:1527628270474};\\\", \\\"{x:1603,y:913,t:1527628270499};\\\", \\\"{x:1605,y:913,t:1527628270514};\\\", \\\"{x:1606,y:913,t:1527628270530};\\\", \\\"{x:1607,y:913,t:1527628270547};\\\", \\\"{x:1608,y:913,t:1527628270603};\\\", \\\"{x:1608,y:912,t:1527628270891};\\\", \\\"{x:1608,y:911,t:1527628270972};\\\", \\\"{x:1609,y:911,t:1527628271075};\\\", \\\"{x:1611,y:911,t:1527628271204};\\\", \\\"{x:1612,y:911,t:1527628271211};\\\", \\\"{x:1613,y:911,t:1527628271223};\\\", \\\"{x:1615,y:911,t:1527628271239};\\\", \\\"{x:1617,y:911,t:1527628271256};\\\", \\\"{x:1618,y:911,t:1527628271273};\\\", \\\"{x:1619,y:911,t:1527628271290};\\\", \\\"{x:1620,y:911,t:1527628271306};\\\", \\\"{x:1621,y:911,t:1527628271323};\\\", \\\"{x:1622,y:911,t:1527628271339};\\\", \\\"{x:1623,y:911,t:1527628271356};\\\", \\\"{x:1624,y:911,t:1527628271379};\\\", \\\"{x:1625,y:911,t:1527628271397};\\\", \\\"{x:1626,y:911,t:1527628271407};\\\", \\\"{x:1627,y:911,t:1527628271423};\\\", \\\"{x:1628,y:911,t:1527628271443};\\\", \\\"{x:1629,y:911,t:1527628271459};\\\", \\\"{x:1630,y:911,t:1527628271473};\\\", \\\"{x:1632,y:911,t:1527628271490};\\\", \\\"{x:1636,y:911,t:1527628271508};\\\", \\\"{x:1637,y:911,t:1527628271523};\\\", \\\"{x:1639,y:911,t:1527628271540};\\\", \\\"{x:1640,y:911,t:1527628271557};\\\", \\\"{x:1641,y:912,t:1527628271580};\\\", \\\"{x:1642,y:912,t:1527628271591};\\\", \\\"{x:1645,y:912,t:1527628271607};\\\", \\\"{x:1647,y:912,t:1527628271624};\\\", \\\"{x:1649,y:912,t:1527628271641};\\\", \\\"{x:1652,y:912,t:1527628271657};\\\", \\\"{x:1655,y:912,t:1527628271674};\\\", \\\"{x:1661,y:912,t:1527628271692};\\\", \\\"{x:1662,y:912,t:1527628271707};\\\", \\\"{x:1663,y:912,t:1527628271724};\\\", \\\"{x:1664,y:912,t:1527628271771};\\\", \\\"{x:1665,y:912,t:1527628271804};\\\", \\\"{x:1667,y:912,t:1527628271876};\\\", \\\"{x:1669,y:912,t:1527628271891};\\\", \\\"{x:1671,y:912,t:1527628271908};\\\", \\\"{x:1672,y:912,t:1527628271925};\\\", \\\"{x:1652,y:903,t:1527628273003};\\\", \\\"{x:1621,y:890,t:1527628273011};\\\", \\\"{x:1534,y:861,t:1527628273028};\\\", \\\"{x:1530,y:860,t:1527628273045};\\\", \\\"{x:1390,y:811,t:1527628273062};\\\", \\\"{x:1261,y:757,t:1527628273078};\\\", \\\"{x:1171,y:722,t:1527628273096};\\\", \\\"{x:1145,y:697,t:1527628273112};\\\", \\\"{x:1144,y:695,t:1527628273128};\\\", \\\"{x:1147,y:689,t:1527628273145};\\\", \\\"{x:1154,y:684,t:1527628273162};\\\", \\\"{x:1158,y:678,t:1527628273179};\\\", \\\"{x:1159,y:675,t:1527628273196};\\\", \\\"{x:1160,y:673,t:1527628273213};\\\", \\\"{x:1160,y:672,t:1527628273236};\\\", \\\"{x:1160,y:671,t:1527628273246};\\\", \\\"{x:1144,y:661,t:1527628273263};\\\", \\\"{x:1098,y:643,t:1527628273279};\\\", \\\"{x:1008,y:611,t:1527628273296};\\\", \\\"{x:884,y:578,t:1527628273313};\\\", \\\"{x:792,y:548,t:1527628273328};\\\", \\\"{x:754,y:529,t:1527628273346};\\\", \\\"{x:742,y:521,t:1527628273370};\\\", \\\"{x:742,y:520,t:1527628273387};\\\", \\\"{x:742,y:518,t:1527628273403};\\\", \\\"{x:742,y:517,t:1527628273421};\\\", \\\"{x:742,y:514,t:1527628273436};\\\", \\\"{x:741,y:513,t:1527628273454};\\\", \\\"{x:739,y:511,t:1527628273470};\\\", \\\"{x:737,y:511,t:1527628273486};\\\", \\\"{x:727,y:509,t:1527628273504};\\\", \\\"{x:706,y:506,t:1527628273520};\\\", \\\"{x:676,y:502,t:1527628273537};\\\", \\\"{x:653,y:498,t:1527628273553};\\\", \\\"{x:638,y:494,t:1527628273571};\\\", \\\"{x:637,y:493,t:1527628273588};\\\", \\\"{x:635,y:493,t:1527628273603};\\\", \\\"{x:634,y:493,t:1527628273731};\\\", \\\"{x:628,y:492,t:1527628273739};\\\", \\\"{x:619,y:490,t:1527628273754};\\\", \\\"{x:596,y:484,t:1527628273772};\\\", \\\"{x:589,y:482,t:1527628273788};\\\", \\\"{x:588,y:482,t:1527628273803};\\\", \\\"{x:588,y:481,t:1527628273821};\\\", \\\"{x:588,y:480,t:1527628273838};\\\", \\\"{x:589,y:479,t:1527628273859};\\\", \\\"{x:590,y:480,t:1527628274043};\\\", \\\"{x:590,y:481,t:1527628274059};\\\", \\\"{x:592,y:481,t:1527628274652};\\\", \\\"{x:594,y:481,t:1527628274659};\\\", \\\"{x:597,y:481,t:1527628274672};\\\", \\\"{x:603,y:481,t:1527628274689};\\\", \\\"{x:609,y:481,t:1527628274705};\\\", \\\"{x:613,y:481,t:1527628274722};\\\", \\\"{x:617,y:482,t:1527628274738};\\\", \\\"{x:620,y:485,t:1527628274755};\\\", \\\"{x:621,y:485,t:1527628274772};\\\", \\\"{x:621,y:486,t:1527628274851};\\\", \\\"{x:620,y:488,t:1527628274883};\\\", \\\"{x:619,y:488,t:1527628274907};\\\", \\\"{x:619,y:489,t:1527628274923};\\\", \\\"{x:631,y:492,t:1527628275130};\\\", \\\"{x:670,y:501,t:1527628275139};\\\", \\\"{x:781,y:519,t:1527628275156};\\\", \\\"{x:914,y:536,t:1527628275172};\\\", \\\"{x:1028,y:538,t:1527628275189};\\\", \\\"{x:1124,y:532,t:1527628275205};\\\", \\\"{x:1181,y:522,t:1527628275221};\\\", \\\"{x:1217,y:513,t:1527628275239};\\\", \\\"{x:1238,y:503,t:1527628275255};\\\", \\\"{x:1252,y:491,t:1527628275271};\\\", \\\"{x:1262,y:482,t:1527628275288};\\\", \\\"{x:1269,y:477,t:1527628275306};\\\", \\\"{x:1273,y:473,t:1527628275321};\\\", \\\"{x:1280,y:465,t:1527628275339};\\\", \\\"{x:1285,y:460,t:1527628275356};\\\", \\\"{x:1287,y:457,t:1527628275372};\\\", \\\"{x:1288,y:457,t:1527628275389};\\\", \\\"{x:1289,y:457,t:1527628275418};\\\", \\\"{x:1290,y:462,t:1527628275442};\\\", \\\"{x:1290,y:474,t:1527628275455};\\\", \\\"{x:1289,y:515,t:1527628275471};\\\", \\\"{x:1289,y:596,t:1527628275489};\\\", \\\"{x:1300,y:685,t:1527628275506};\\\", \\\"{x:1319,y:752,t:1527628275522};\\\", \\\"{x:1333,y:797,t:1527628275539};\\\", \\\"{x:1334,y:811,t:1527628275556};\\\", \\\"{x:1334,y:818,t:1527628275572};\\\", \\\"{x:1334,y:822,t:1527628275589};\\\", \\\"{x:1333,y:828,t:1527628275606};\\\", \\\"{x:1327,y:836,t:1527628275622};\\\", \\\"{x:1321,y:842,t:1527628275639};\\\", \\\"{x:1314,y:847,t:1527628275656};\\\", \\\"{x:1310,y:851,t:1527628275673};\\\", \\\"{x:1301,y:855,t:1527628275689};\\\", \\\"{x:1283,y:864,t:1527628275706};\\\", \\\"{x:1264,y:876,t:1527628275723};\\\", \\\"{x:1249,y:885,t:1527628275739};\\\", \\\"{x:1229,y:896,t:1527628275757};\\\", \\\"{x:1220,y:903,t:1527628275773};\\\", \\\"{x:1214,y:907,t:1527628275789};\\\", \\\"{x:1214,y:909,t:1527628275806};\\\", \\\"{x:1213,y:910,t:1527628276365};\\\", \\\"{x:1211,y:910,t:1527628276373};\\\", \\\"{x:1207,y:910,t:1527628276390};\\\", \\\"{x:1192,y:910,t:1527628276407};\\\", \\\"{x:1177,y:910,t:1527628276423};\\\", \\\"{x:1163,y:910,t:1527628276440};\\\", \\\"{x:1159,y:910,t:1527628276456};\\\", \\\"{x:1158,y:910,t:1527628276588};\\\", \\\"{x:1158,y:912,t:1527628276596};\\\", \\\"{x:1158,y:914,t:1527628276611};\\\", \\\"{x:1158,y:916,t:1527628276660};\\\", \\\"{x:1157,y:916,t:1527628276844};\\\", \\\"{x:1159,y:917,t:1527628277428};\\\", \\\"{x:1161,y:917,t:1527628277443};\\\", \\\"{x:1162,y:917,t:1527628277457};\\\", \\\"{x:1169,y:919,t:1527628277475};\\\", \\\"{x:1177,y:920,t:1527628277491};\\\", \\\"{x:1180,y:921,t:1527628277508};\\\", \\\"{x:1183,y:921,t:1527628277524};\\\", \\\"{x:1185,y:921,t:1527628277541};\\\", \\\"{x:1187,y:921,t:1527628277558};\\\", \\\"{x:1188,y:921,t:1527628277574};\\\", \\\"{x:1191,y:920,t:1527628277596};\\\", \\\"{x:1192,y:920,t:1527628277607};\\\", \\\"{x:1195,y:920,t:1527628277624};\\\", \\\"{x:1201,y:920,t:1527628277641};\\\", \\\"{x:1209,y:920,t:1527628277658};\\\", \\\"{x:1218,y:918,t:1527628277675};\\\", \\\"{x:1240,y:917,t:1527628277691};\\\", \\\"{x:1258,y:917,t:1527628277707};\\\", \\\"{x:1272,y:917,t:1527628277725};\\\", \\\"{x:1283,y:916,t:1527628277741};\\\", \\\"{x:1293,y:916,t:1527628277758};\\\", \\\"{x:1304,y:916,t:1527628277775};\\\", \\\"{x:1313,y:916,t:1527628277791};\\\", \\\"{x:1333,y:916,t:1527628277808};\\\", \\\"{x:1353,y:916,t:1527628277824};\\\", \\\"{x:1377,y:916,t:1527628277842};\\\", \\\"{x:1401,y:916,t:1527628277859};\\\", \\\"{x:1420,y:916,t:1527628277874};\\\", \\\"{x:1438,y:916,t:1527628277892};\\\", \\\"{x:1444,y:916,t:1527628277908};\\\", \\\"{x:1448,y:916,t:1527628277925};\\\", \\\"{x:1453,y:916,t:1527628277942};\\\", \\\"{x:1457,y:916,t:1527628277959};\\\", \\\"{x:1460,y:916,t:1527628277974};\\\", \\\"{x:1463,y:916,t:1527628277992};\\\", \\\"{x:1465,y:916,t:1527628278007};\\\", \\\"{x:1471,y:916,t:1527628278024};\\\", \\\"{x:1477,y:916,t:1527628278041};\\\", \\\"{x:1487,y:916,t:1527628278057};\\\", \\\"{x:1500,y:916,t:1527628278073};\\\", \\\"{x:1509,y:916,t:1527628278090};\\\", \\\"{x:1519,y:916,t:1527628278107};\\\", \\\"{x:1530,y:916,t:1527628278123};\\\", \\\"{x:1535,y:917,t:1527628278140};\\\", \\\"{x:1548,y:917,t:1527628278158};\\\", \\\"{x:1556,y:917,t:1527628278174};\\\", \\\"{x:1563,y:917,t:1527628278191};\\\", \\\"{x:1569,y:917,t:1527628278208};\\\", \\\"{x:1577,y:917,t:1527628278224};\\\", \\\"{x:1590,y:917,t:1527628278241};\\\", \\\"{x:1601,y:917,t:1527628278259};\\\", \\\"{x:1611,y:917,t:1527628278274};\\\", \\\"{x:1618,y:917,t:1527628278291};\\\", \\\"{x:1620,y:917,t:1527628278308};\\\", \\\"{x:1621,y:916,t:1527628278325};\\\", \\\"{x:1625,y:916,t:1527628278341};\\\", \\\"{x:1630,y:916,t:1527628278358};\\\", \\\"{x:1637,y:916,t:1527628278376};\\\", \\\"{x:1643,y:916,t:1527628278391};\\\", \\\"{x:1648,y:916,t:1527628278409};\\\", \\\"{x:1650,y:916,t:1527628278426};\\\", \\\"{x:1651,y:916,t:1527628278441};\\\", \\\"{x:1652,y:916,t:1527628278458};\\\", \\\"{x:1656,y:916,t:1527628278475};\\\", \\\"{x:1659,y:914,t:1527628278491};\\\", \\\"{x:1661,y:914,t:1527628278508};\\\", \\\"{x:1663,y:913,t:1527628278525};\\\", \\\"{x:1664,y:913,t:1527628278547};\\\", \\\"{x:1666,y:912,t:1527628278563};\\\", \\\"{x:1669,y:911,t:1527628278576};\\\", \\\"{x:1670,y:910,t:1527628278592};\\\", \\\"{x:1671,y:908,t:1527628278608};\\\", \\\"{x:1673,y:907,t:1527628278625};\\\", \\\"{x:1674,y:907,t:1527628278642};\\\", \\\"{x:1676,y:906,t:1527628278667};\\\", \\\"{x:1673,y:906,t:1527628284884};\\\", \\\"{x:1662,y:907,t:1527628284897};\\\", \\\"{x:1640,y:907,t:1527628284914};\\\", \\\"{x:1624,y:907,t:1527628284931};\\\", \\\"{x:1603,y:907,t:1527628284947};\\\", \\\"{x:1595,y:907,t:1527628284963};\\\", \\\"{x:1589,y:908,t:1527628284980};\\\", \\\"{x:1577,y:909,t:1527628284996};\\\", \\\"{x:1568,y:909,t:1527628285013};\\\", \\\"{x:1554,y:909,t:1527628285030};\\\", \\\"{x:1539,y:909,t:1527628285046};\\\", \\\"{x:1528,y:909,t:1527628285062};\\\", \\\"{x:1515,y:908,t:1527628285080};\\\", \\\"{x:1495,y:906,t:1527628285096};\\\", \\\"{x:1475,y:902,t:1527628285113};\\\", \\\"{x:1458,y:899,t:1527628285130};\\\", \\\"{x:1438,y:895,t:1527628285146};\\\", \\\"{x:1416,y:886,t:1527628285163};\\\", \\\"{x:1408,y:878,t:1527628285180};\\\", \\\"{x:1404,y:869,t:1527628285197};\\\", \\\"{x:1399,y:853,t:1527628285213};\\\", \\\"{x:1394,y:833,t:1527628285230};\\\", \\\"{x:1390,y:813,t:1527628285247};\\\", \\\"{x:1389,y:802,t:1527628285263};\\\", \\\"{x:1389,y:794,t:1527628285280};\\\", \\\"{x:1389,y:785,t:1527628285297};\\\", \\\"{x:1389,y:779,t:1527628285313};\\\", \\\"{x:1390,y:773,t:1527628285331};\\\", \\\"{x:1391,y:766,t:1527628285347};\\\", \\\"{x:1391,y:762,t:1527628285364};\\\", \\\"{x:1391,y:760,t:1527628285381};\\\", \\\"{x:1391,y:758,t:1527628285398};\\\", \\\"{x:1389,y:757,t:1527628285413};\\\", \\\"{x:1380,y:752,t:1527628285430};\\\", \\\"{x:1368,y:751,t:1527628285447};\\\", \\\"{x:1358,y:750,t:1527628285464};\\\", \\\"{x:1347,y:752,t:1527628285481};\\\", \\\"{x:1335,y:762,t:1527628285497};\\\", \\\"{x:1322,y:774,t:1527628285513};\\\", \\\"{x:1317,y:784,t:1527628285531};\\\", \\\"{x:1308,y:820,t:1527628285548};\\\", \\\"{x:1304,y:842,t:1527628285563};\\\", \\\"{x:1299,y:866,t:1527628285581};\\\", \\\"{x:1297,y:884,t:1527628285597};\\\", \\\"{x:1286,y:901,t:1527628285614};\\\", \\\"{x:1248,y:926,t:1527628285630};\\\", \\\"{x:1201,y:940,t:1527628285646};\\\", \\\"{x:1153,y:954,t:1527628285664};\\\", \\\"{x:1121,y:959,t:1527628285680};\\\", \\\"{x:1101,y:960,t:1527628285697};\\\", \\\"{x:1095,y:956,t:1527628285714};\\\", \\\"{x:1109,y:940,t:1527628285730};\\\", \\\"{x:1129,y:930,t:1527628285747};\\\", \\\"{x:1153,y:919,t:1527628285764};\\\", \\\"{x:1174,y:907,t:1527628285780};\\\", \\\"{x:1183,y:900,t:1527628285797};\\\", \\\"{x:1192,y:892,t:1527628285814};\\\", \\\"{x:1202,y:879,t:1527628285830};\\\", \\\"{x:1214,y:865,t:1527628285847};\\\", \\\"{x:1224,y:851,t:1527628285864};\\\", \\\"{x:1233,y:837,t:1527628285880};\\\", \\\"{x:1243,y:826,t:1527628285897};\\\", \\\"{x:1251,y:816,t:1527628285914};\\\", \\\"{x:1263,y:800,t:1527628285930};\\\", \\\"{x:1286,y:770,t:1527628285947};\\\", \\\"{x:1301,y:752,t:1527628285965};\\\", \\\"{x:1308,y:740,t:1527628285980};\\\", \\\"{x:1313,y:731,t:1527628285998};\\\", \\\"{x:1315,y:725,t:1527628286014};\\\", \\\"{x:1319,y:719,t:1527628286031};\\\", \\\"{x:1320,y:713,t:1527628286048};\\\", \\\"{x:1321,y:710,t:1527628286065};\\\", \\\"{x:1322,y:707,t:1527628286081};\\\", \\\"{x:1322,y:705,t:1527628286098};\\\", \\\"{x:1323,y:701,t:1527628286114};\\\", \\\"{x:1325,y:695,t:1527628286131};\\\", \\\"{x:1326,y:692,t:1527628286148};\\\", \\\"{x:1328,y:687,t:1527628286165};\\\", \\\"{x:1328,y:684,t:1527628286181};\\\", \\\"{x:1331,y:680,t:1527628286198};\\\", \\\"{x:1333,y:676,t:1527628286214};\\\", \\\"{x:1336,y:671,t:1527628286232};\\\", \\\"{x:1338,y:668,t:1527628286248};\\\", \\\"{x:1339,y:666,t:1527628286265};\\\", \\\"{x:1341,y:663,t:1527628286282};\\\", \\\"{x:1343,y:661,t:1527628286297};\\\", \\\"{x:1345,y:661,t:1527628286314};\\\", \\\"{x:1348,y:658,t:1527628286331};\\\", \\\"{x:1350,y:655,t:1527628286347};\\\", \\\"{x:1351,y:655,t:1527628286365};\\\", \\\"{x:1353,y:653,t:1527628286382};\\\", \\\"{x:1355,y:652,t:1527628286398};\\\", \\\"{x:1359,y:647,t:1527628286415};\\\", \\\"{x:1361,y:639,t:1527628286431};\\\", \\\"{x:1366,y:630,t:1527628286448};\\\", \\\"{x:1368,y:623,t:1527628286465};\\\", \\\"{x:1370,y:614,t:1527628286482};\\\", \\\"{x:1374,y:604,t:1527628286498};\\\", \\\"{x:1380,y:586,t:1527628286514};\\\", \\\"{x:1383,y:579,t:1527628286531};\\\", \\\"{x:1387,y:571,t:1527628286549};\\\", \\\"{x:1387,y:568,t:1527628286565};\\\", \\\"{x:1388,y:563,t:1527628286581};\\\", \\\"{x:1388,y:560,t:1527628286598};\\\", \\\"{x:1390,y:554,t:1527628286614};\\\", \\\"{x:1392,y:550,t:1527628286631};\\\", \\\"{x:1397,y:542,t:1527628286648};\\\", \\\"{x:1399,y:535,t:1527628286664};\\\", \\\"{x:1404,y:528,t:1527628286681};\\\", \\\"{x:1408,y:520,t:1527628286698};\\\", \\\"{x:1408,y:519,t:1527628286715};\\\", \\\"{x:1408,y:516,t:1527628286731};\\\", \\\"{x:1409,y:516,t:1527628286748};\\\", \\\"{x:1410,y:515,t:1527628286770};\\\", \\\"{x:1411,y:514,t:1527628287028};\\\", \\\"{x:1412,y:516,t:1527628287050};\\\", \\\"{x:1415,y:521,t:1527628287065};\\\", \\\"{x:1419,y:529,t:1527628287082};\\\", \\\"{x:1424,y:539,t:1527628287099};\\\", \\\"{x:1428,y:546,t:1527628287115};\\\", \\\"{x:1431,y:552,t:1527628287131};\\\", \\\"{x:1432,y:555,t:1527628287148};\\\", \\\"{x:1434,y:558,t:1527628287166};\\\", \\\"{x:1435,y:559,t:1527628287181};\\\", \\\"{x:1436,y:560,t:1527628287198};\\\", \\\"{x:1436,y:562,t:1527628287215};\\\", \\\"{x:1437,y:563,t:1527628287231};\\\", \\\"{x:1438,y:564,t:1527628287249};\\\", \\\"{x:1440,y:566,t:1527628287266};\\\", \\\"{x:1442,y:569,t:1527628287281};\\\", \\\"{x:1444,y:572,t:1527628287299};\\\", \\\"{x:1446,y:575,t:1527628287315};\\\", \\\"{x:1449,y:580,t:1527628287332};\\\", \\\"{x:1453,y:586,t:1527628287349};\\\", \\\"{x:1456,y:590,t:1527628287365};\\\", \\\"{x:1457,y:592,t:1527628287383};\\\", \\\"{x:1459,y:596,t:1527628287398};\\\", \\\"{x:1461,y:598,t:1527628287416};\\\", \\\"{x:1462,y:599,t:1527628287431};\\\", \\\"{x:1463,y:600,t:1527628287448};\\\", \\\"{x:1463,y:601,t:1527628287466};\\\", \\\"{x:1466,y:606,t:1527628287482};\\\", \\\"{x:1467,y:608,t:1527628287499};\\\", \\\"{x:1469,y:612,t:1527628287515};\\\", \\\"{x:1471,y:614,t:1527628287533};\\\", \\\"{x:1475,y:622,t:1527628287549};\\\", \\\"{x:1478,y:628,t:1527628287565};\\\", \\\"{x:1482,y:634,t:1527628287583};\\\", \\\"{x:1483,y:638,t:1527628287599};\\\", \\\"{x:1485,y:641,t:1527628287616};\\\", \\\"{x:1488,y:647,t:1527628287632};\\\", \\\"{x:1491,y:651,t:1527628287648};\\\", \\\"{x:1493,y:655,t:1527628287665};\\\", \\\"{x:1495,y:661,t:1527628287683};\\\", \\\"{x:1497,y:664,t:1527628287699};\\\", \\\"{x:1499,y:668,t:1527628287716};\\\", \\\"{x:1502,y:672,t:1527628287733};\\\", \\\"{x:1504,y:676,t:1527628287749};\\\", \\\"{x:1507,y:683,t:1527628287766};\\\", \\\"{x:1510,y:688,t:1527628287782};\\\", \\\"{x:1513,y:696,t:1527628287800};\\\", \\\"{x:1519,y:706,t:1527628287816};\\\", \\\"{x:1523,y:715,t:1527628287833};\\\", \\\"{x:1529,y:724,t:1527628287849};\\\", \\\"{x:1535,y:736,t:1527628287866};\\\", \\\"{x:1540,y:746,t:1527628287883};\\\", \\\"{x:1541,y:750,t:1527628287899};\\\", \\\"{x:1543,y:754,t:1527628287916};\\\", \\\"{x:1545,y:757,t:1527628287932};\\\", \\\"{x:1545,y:758,t:1527628287956};\\\", \\\"{x:1545,y:759,t:1527628287966};\\\", \\\"{x:1546,y:762,t:1527628287982};\\\", \\\"{x:1549,y:768,t:1527628287999};\\\", \\\"{x:1550,y:775,t:1527628288016};\\\", \\\"{x:1555,y:787,t:1527628288032};\\\", \\\"{x:1558,y:796,t:1527628288049};\\\", \\\"{x:1560,y:802,t:1527628288066};\\\", \\\"{x:1562,y:807,t:1527628288083};\\\", \\\"{x:1563,y:809,t:1527628288099};\\\", \\\"{x:1563,y:810,t:1527628288115};\\\", \\\"{x:1564,y:812,t:1527628288133};\\\", \\\"{x:1565,y:813,t:1527628288149};\\\", \\\"{x:1565,y:814,t:1527628288166};\\\", \\\"{x:1566,y:815,t:1527628288182};\\\", \\\"{x:1568,y:819,t:1527628288200};\\\", \\\"{x:1568,y:821,t:1527628288217};\\\", \\\"{x:1570,y:827,t:1527628288233};\\\", \\\"{x:1572,y:833,t:1527628288250};\\\", \\\"{x:1574,y:836,t:1527628288267};\\\", \\\"{x:1576,y:838,t:1527628288283};\\\", \\\"{x:1577,y:840,t:1527628288299};\\\", \\\"{x:1578,y:842,t:1527628288323};\\\", \\\"{x:1578,y:843,t:1527628288333};\\\", \\\"{x:1580,y:846,t:1527628288350};\\\", \\\"{x:1581,y:849,t:1527628288367};\\\", \\\"{x:1583,y:852,t:1527628288382};\\\", \\\"{x:1583,y:854,t:1527628288399};\\\", \\\"{x:1585,y:857,t:1527628288419};\\\", \\\"{x:1585,y:858,t:1527628288433};\\\", \\\"{x:1586,y:860,t:1527628288450};\\\", \\\"{x:1587,y:863,t:1527628288467};\\\", \\\"{x:1588,y:865,t:1527628288483};\\\", \\\"{x:1589,y:867,t:1527628288499};\\\", \\\"{x:1589,y:868,t:1527628288517};\\\", \\\"{x:1590,y:871,t:1527628288533};\\\", \\\"{x:1592,y:874,t:1527628288550};\\\", \\\"{x:1592,y:876,t:1527628288567};\\\", \\\"{x:1593,y:878,t:1527628288583};\\\", \\\"{x:1593,y:879,t:1527628288611};\\\", \\\"{x:1594,y:881,t:1527628288619};\\\", \\\"{x:1594,y:883,t:1527628288660};\\\", \\\"{x:1596,y:885,t:1527628288667};\\\", \\\"{x:1596,y:887,t:1527628288683};\\\", \\\"{x:1596,y:888,t:1527628288700};\\\", \\\"{x:1598,y:890,t:1527628288717};\\\", \\\"{x:1599,y:892,t:1527628288733};\\\", \\\"{x:1600,y:893,t:1527628288749};\\\", \\\"{x:1600,y:894,t:1527628288767};\\\", \\\"{x:1600,y:895,t:1527628288787};\\\", \\\"{x:1600,y:896,t:1527628288811};\\\", \\\"{x:1601,y:897,t:1527628288851};\\\", \\\"{x:1602,y:899,t:1527628288899};\\\", \\\"{x:1602,y:900,t:1527628288932};\\\", \\\"{x:1602,y:901,t:1527628288947};\\\", \\\"{x:1603,y:902,t:1527628288955};\\\", \\\"{x:1603,y:903,t:1527628289003};\\\", \\\"{x:1603,y:904,t:1527628289027};\\\", \\\"{x:1603,y:905,t:1527628289043};\\\", \\\"{x:1603,y:906,t:1527628289075};\\\", \\\"{x:1603,y:907,t:1527628289083};\\\", \\\"{x:1604,y:908,t:1527628289099};\\\", \\\"{x:1605,y:910,t:1527628289117};\\\", \\\"{x:1605,y:911,t:1527628289134};\\\", \\\"{x:1605,y:912,t:1527628289151};\\\", \\\"{x:1607,y:914,t:1527628289166};\\\", \\\"{x:1607,y:915,t:1527628289203};\\\", \\\"{x:1607,y:916,t:1527628289731};\\\", \\\"{x:1609,y:918,t:1527628289747};\\\", \\\"{x:1609,y:919,t:1527628289755};\\\", \\\"{x:1611,y:919,t:1527628290115};\\\", \\\"{x:1612,y:919,t:1527628290139};\\\", \\\"{x:1603,y:920,t:1527628293764};\\\", \\\"{x:1542,y:907,t:1527628293772};\\\", \\\"{x:1351,y:852,t:1527628293787};\\\", \\\"{x:1169,y:794,t:1527628293804};\\\", \\\"{x:1013,y:739,t:1527628293821};\\\", \\\"{x:911,y:694,t:1527628293838};\\\", \\\"{x:872,y:669,t:1527628293854};\\\", \\\"{x:861,y:656,t:1527628293870};\\\", \\\"{x:861,y:642,t:1527628293888};\\\", \\\"{x:869,y:624,t:1527628293904};\\\", \\\"{x:882,y:599,t:1527628293921};\\\", \\\"{x:900,y:572,t:1527628293938};\\\", \\\"{x:908,y:547,t:1527628293954};\\\", \\\"{x:914,y:501,t:1527628293970};\\\", \\\"{x:902,y:469,t:1527628294003};\\\", \\\"{x:889,y:458,t:1527628294021};\\\", \\\"{x:872,y:452,t:1527628294036};\\\", \\\"{x:849,y:443,t:1527628294053};\\\", \\\"{x:809,y:433,t:1527628294070};\\\", \\\"{x:784,y:427,t:1527628294086};\\\", \\\"{x:757,y:423,t:1527628294103};\\\", \\\"{x:738,y:421,t:1527628294120};\\\", \\\"{x:725,y:419,t:1527628294137};\\\", \\\"{x:721,y:419,t:1527628294153};\\\", \\\"{x:714,y:419,t:1527628294323};\\\", \\\"{x:709,y:419,t:1527628294338};\\\", \\\"{x:683,y:417,t:1527628294354};\\\", \\\"{x:651,y:413,t:1527628294371};\\\", \\\"{x:650,y:413,t:1527628294387};\\\", \\\"{x:648,y:413,t:1527628294403};\\\", \\\"{x:659,y:418,t:1527628294421};\\\", \\\"{x:672,y:424,t:1527628294437};\\\", \\\"{x:695,y:430,t:1527628294453};\\\", \\\"{x:717,y:433,t:1527628294470};\\\", \\\"{x:747,y:434,t:1527628294488};\\\", \\\"{x:772,y:435,t:1527628294503};\\\", \\\"{x:796,y:435,t:1527628294520};\\\", \\\"{x:803,y:437,t:1527628294538};\\\", \\\"{x:803,y:438,t:1527628294553};\\\", \\\"{x:804,y:438,t:1527628294603};\\\", \\\"{x:804,y:440,t:1527628294621};\\\", \\\"{x:802,y:444,t:1527628294638};\\\", \\\"{x:801,y:451,t:1527628294654};\\\", \\\"{x:798,y:463,t:1527628294671};\\\", \\\"{x:799,y:477,t:1527628294689};\\\", \\\"{x:803,y:483,t:1527628294703};\\\", \\\"{x:805,y:488,t:1527628294720};\\\", \\\"{x:807,y:493,t:1527628294737};\\\", \\\"{x:811,y:497,t:1527628294753};\\\", \\\"{x:812,y:498,t:1527628294770};\\\", \\\"{x:814,y:498,t:1527628294788};\\\", \\\"{x:816,y:498,t:1527628294804};\\\", \\\"{x:817,y:498,t:1527628294820};\\\", \\\"{x:818,y:498,t:1527628294837};\\\", \\\"{x:820,y:498,t:1527628294854};\\\", \\\"{x:822,y:498,t:1527628294870};\\\", \\\"{x:826,y:496,t:1527628294888};\\\", \\\"{x:827,y:496,t:1527628294904};\\\", \\\"{x:829,y:496,t:1527628294920};\\\", \\\"{x:830,y:496,t:1527628294946};\\\", \\\"{x:839,y:498,t:1527628295266};\\\", \\\"{x:848,y:501,t:1527628295274};\\\", \\\"{x:855,y:504,t:1527628295288};\\\", \\\"{x:867,y:508,t:1527628295304};\\\", \\\"{x:880,y:512,t:1527628295322};\\\", \\\"{x:898,y:517,t:1527628295338};\\\", \\\"{x:917,y:519,t:1527628295354};\\\", \\\"{x:950,y:524,t:1527628295371};\\\", \\\"{x:1006,y:524,t:1527628295389};\\\", \\\"{x:1045,y:524,t:1527628295404};\\\", \\\"{x:1071,y:522,t:1527628295421};\\\", \\\"{x:1086,y:520,t:1527628295438};\\\", \\\"{x:1091,y:518,t:1527628295454};\\\", \\\"{x:1095,y:515,t:1527628295472};\\\", \\\"{x:1096,y:514,t:1527628295488};\\\", \\\"{x:1097,y:514,t:1527628295507};\\\", \\\"{x:1098,y:514,t:1527628295522};\\\", \\\"{x:1102,y:514,t:1527628295538};\\\", \\\"{x:1124,y:520,t:1527628295554};\\\", \\\"{x:1148,y:530,t:1527628295572};\\\", \\\"{x:1172,y:534,t:1527628295588};\\\", \\\"{x:1196,y:539,t:1527628295604};\\\", \\\"{x:1208,y:540,t:1527628295621};\\\", \\\"{x:1214,y:540,t:1527628295638};\\\", \\\"{x:1217,y:540,t:1527628295654};\\\", \\\"{x:1220,y:537,t:1527628295672};\\\", \\\"{x:1226,y:532,t:1527628295688};\\\", \\\"{x:1238,y:525,t:1527628295705};\\\", \\\"{x:1246,y:521,t:1527628295721};\\\", \\\"{x:1254,y:517,t:1527628295738};\\\", \\\"{x:1264,y:516,t:1527628295754};\\\", \\\"{x:1282,y:516,t:1527628295771};\\\", \\\"{x:1305,y:519,t:1527628295787};\\\", \\\"{x:1334,y:529,t:1527628295805};\\\", \\\"{x:1354,y:540,t:1527628295821};\\\", \\\"{x:1370,y:548,t:1527628295838};\\\", \\\"{x:1378,y:552,t:1527628295854};\\\", \\\"{x:1380,y:555,t:1527628295871};\\\", \\\"{x:1381,y:557,t:1527628295887};\\\", \\\"{x:1381,y:562,t:1527628295905};\\\", \\\"{x:1381,y:570,t:1527628295922};\\\", \\\"{x:1381,y:584,t:1527628295938};\\\", \\\"{x:1381,y:604,t:1527628295954};\\\", \\\"{x:1381,y:617,t:1527628295971};\\\", \\\"{x:1381,y:628,t:1527628295988};\\\", \\\"{x:1381,y:636,t:1527628296005};\\\", \\\"{x:1381,y:642,t:1527628296021};\\\", \\\"{x:1381,y:648,t:1527628296038};\\\", \\\"{x:1380,y:654,t:1527628296054};\\\", \\\"{x:1379,y:660,t:1527628296072};\\\", \\\"{x:1379,y:662,t:1527628296087};\\\", \\\"{x:1379,y:663,t:1527628296105};\\\", \\\"{x:1379,y:664,t:1527628296123};\\\", \\\"{x:1379,y:662,t:1527628296154};\\\", \\\"{x:1381,y:645,t:1527628296172};\\\", \\\"{x:1397,y:602,t:1527628296188};\\\", \\\"{x:1404,y:557,t:1527628296205};\\\", \\\"{x:1408,y:531,t:1527628296223};\\\", \\\"{x:1410,y:510,t:1527628296238};\\\", \\\"{x:1410,y:495,t:1527628296256};\\\", \\\"{x:1410,y:490,t:1527628296273};\\\", \\\"{x:1411,y:488,t:1527628296288};\\\", \\\"{x:1412,y:487,t:1527628296305};\\\", \\\"{x:1412,y:489,t:1527628296451};\\\", \\\"{x:1412,y:496,t:1527628296459};\\\", \\\"{x:1412,y:501,t:1527628296472};\\\", \\\"{x:1414,y:513,t:1527628296489};\\\", \\\"{x:1416,y:518,t:1527628296506};\\\", \\\"{x:1416,y:520,t:1527628296522};\\\", \\\"{x:1416,y:521,t:1527628296538};\\\", \\\"{x:1417,y:522,t:1527628296827};\\\", \\\"{x:1418,y:522,t:1527628296859};\\\", \\\"{x:1403,y:525,t:1527628300099};\\\", \\\"{x:1366,y:528,t:1527628300107};\\\", \\\"{x:1324,y:528,t:1527628300122};\\\", \\\"{x:1214,y:528,t:1527628300138};\\\", \\\"{x:1086,y:528,t:1527628300154};\\\", \\\"{x:870,y:525,t:1527628300171};\\\", \\\"{x:767,y:521,t:1527628300187};\\\", \\\"{x:694,y:521,t:1527628300209};\\\", \\\"{x:673,y:521,t:1527628300225};\\\", \\\"{x:664,y:522,t:1527628300241};\\\", \\\"{x:661,y:522,t:1527628300258};\\\", \\\"{x:659,y:524,t:1527628300282};\\\", \\\"{x:657,y:526,t:1527628300298};\\\", \\\"{x:655,y:528,t:1527628300308};\\\", \\\"{x:647,y:538,t:1527628300324};\\\", \\\"{x:640,y:551,t:1527628300342};\\\", \\\"{x:634,y:565,t:1527628300358};\\\", \\\"{x:624,y:578,t:1527628300375};\\\", \\\"{x:617,y:598,t:1527628300392};\\\", \\\"{x:603,y:620,t:1527628300408};\\\", \\\"{x:592,y:633,t:1527628300425};\\\", \\\"{x:577,y:639,t:1527628300442};\\\", \\\"{x:567,y:644,t:1527628300459};\\\", \\\"{x:561,y:646,t:1527628300475};\\\", \\\"{x:559,y:646,t:1527628300505};\\\", \\\"{x:558,y:646,t:1527628300514};\\\", \\\"{x:556,y:646,t:1527628300538};\\\", \\\"{x:554,y:646,t:1527628300554};\\\", \\\"{x:552,y:646,t:1527628300562};\\\", \\\"{x:551,y:646,t:1527628300575};\\\", \\\"{x:549,y:646,t:1527628300592};\\\", \\\"{x:543,y:650,t:1527628300608};\\\", \\\"{x:540,y:654,t:1527628300626};\\\", \\\"{x:539,y:656,t:1527628300642};\\\", \\\"{x:538,y:659,t:1527628300659};\\\", \\\"{x:538,y:660,t:1527628300675};\\\", \\\"{x:538,y:661,t:1527628300691};\\\", \\\"{x:537,y:664,t:1527628300708};\\\", \\\"{x:536,y:665,t:1527628300747};\\\", \\\"{x:536,y:666,t:1527628300759};\\\", \\\"{x:533,y:672,t:1527628300776};\\\", \\\"{x:530,y:675,t:1527628300791};\\\", \\\"{x:529,y:679,t:1527628300808};\\\", \\\"{x:528,y:681,t:1527628300825};\\\", \\\"{x:527,y:683,t:1527628300842};\\\", \\\"{x:526,y:685,t:1527628300859};\\\" ] }, { \\\"rt\\\": 120587, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 639176, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2-I -J -09 AM-I -11 AM-10 AM-09 AM-E -E -09 AM-B -J -J -09 AM-08 AM-0-0-B -M -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:530,y:688,t:1527628305995};\\\", \\\"{x:531,y:688,t:1527628306010};\\\", \\\"{x:532,y:689,t:1527628306018};\\\", \\\"{x:533,y:689,t:1527628308011};\\\", \\\"{x:535,y:689,t:1527628308027};\\\", \\\"{x:536,y:689,t:1527628308034};\\\", \\\"{x:538,y:689,t:1527628308051};\\\", \\\"{x:543,y:689,t:1527628308065};\\\", \\\"{x:558,y:692,t:1527628308082};\\\", \\\"{x:572,y:694,t:1527628308099};\\\", \\\"{x:602,y:701,t:1527628308114};\\\", \\\"{x:646,y:711,t:1527628308131};\\\", \\\"{x:681,y:716,t:1527628308142};\\\", \\\"{x:728,y:730,t:1527628308160};\\\", \\\"{x:752,y:740,t:1527628308176};\\\", \\\"{x:774,y:747,t:1527628308192};\\\", \\\"{x:799,y:752,t:1527628308209};\\\", \\\"{x:827,y:765,t:1527628308226};\\\", \\\"{x:838,y:777,t:1527628308242};\\\", \\\"{x:839,y:777,t:1527628308259};\\\", \\\"{x:849,y:777,t:1527628308939};\\\", \\\"{x:868,y:777,t:1527628308946};\\\", \\\"{x:904,y:777,t:1527628308958};\\\", \\\"{x:960,y:777,t:1527628308976};\\\", \\\"{x:997,y:779,t:1527628308993};\\\", \\\"{x:1024,y:782,t:1527628309009};\\\", \\\"{x:1045,y:782,t:1527628309025};\\\", \\\"{x:1048,y:780,t:1527628309043};\\\", \\\"{x:1048,y:779,t:1527628309059};\\\", \\\"{x:1049,y:779,t:1527628309330};\\\", \\\"{x:1050,y:779,t:1527628309343};\\\", \\\"{x:1052,y:782,t:1527628309359};\\\", \\\"{x:1062,y:784,t:1527628309375};\\\", \\\"{x:1076,y:791,t:1527628309393};\\\", \\\"{x:1093,y:795,t:1527628309409};\\\", \\\"{x:1120,y:803,t:1527628309425};\\\", \\\"{x:1142,y:807,t:1527628309443};\\\", \\\"{x:1162,y:810,t:1527628309459};\\\", \\\"{x:1178,y:814,t:1527628309475};\\\", \\\"{x:1184,y:815,t:1527628309493};\\\", \\\"{x:1190,y:816,t:1527628309509};\\\", \\\"{x:1191,y:816,t:1527628309526};\\\", \\\"{x:1193,y:816,t:1527628309543};\\\", \\\"{x:1194,y:816,t:1527628309559};\\\", \\\"{x:1194,y:815,t:1527628309576};\\\", \\\"{x:1195,y:813,t:1527628309593};\\\", \\\"{x:1198,y:808,t:1527628309609};\\\", \\\"{x:1201,y:800,t:1527628309625};\\\", \\\"{x:1201,y:797,t:1527628309643};\\\", \\\"{x:1201,y:796,t:1527628309659};\\\", \\\"{x:1202,y:795,t:1527628309682};\\\", \\\"{x:1205,y:790,t:1527628309693};\\\", \\\"{x:1205,y:788,t:1527628309709};\\\", \\\"{x:1205,y:785,t:1527628309725};\\\", \\\"{x:1205,y:782,t:1527628309743};\\\", \\\"{x:1199,y:775,t:1527628309759};\\\", \\\"{x:1185,y:771,t:1527628309776};\\\", \\\"{x:1185,y:769,t:1527628309793};\\\", \\\"{x:1185,y:768,t:1527628309857};\\\", \\\"{x:1185,y:766,t:1527628309874};\\\", \\\"{x:1185,y:764,t:1527628309881};\\\", \\\"{x:1185,y:760,t:1527628309893};\\\", \\\"{x:1186,y:754,t:1527628309909};\\\", \\\"{x:1190,y:744,t:1527628309926};\\\", \\\"{x:1191,y:738,t:1527628309943};\\\", \\\"{x:1191,y:730,t:1527628309959};\\\", \\\"{x:1191,y:723,t:1527628309976};\\\", \\\"{x:1192,y:720,t:1527628309993};\\\", \\\"{x:1192,y:716,t:1527628310009};\\\", \\\"{x:1192,y:713,t:1527628310026};\\\", \\\"{x:1192,y:712,t:1527628310043};\\\", \\\"{x:1191,y:712,t:1527628310060};\\\", \\\"{x:1190,y:711,t:1527628310179};\\\", \\\"{x:1190,y:710,t:1527628310194};\\\", \\\"{x:1188,y:710,t:1527628310210};\\\", \\\"{x:1185,y:710,t:1527628310229};\\\", \\\"{x:1182,y:710,t:1527628310243};\\\", \\\"{x:1181,y:710,t:1527628310258};\\\", \\\"{x:1179,y:710,t:1527628310290};\\\", \\\"{x:1182,y:710,t:1527628312234};\\\", \\\"{x:1187,y:709,t:1527628312242};\\\", \\\"{x:1196,y:705,t:1527628312259};\\\", \\\"{x:1203,y:701,t:1527628312275};\\\", \\\"{x:1211,y:698,t:1527628312292};\\\", \\\"{x:1214,y:695,t:1527628312309};\\\", \\\"{x:1219,y:683,t:1527628312325};\\\", \\\"{x:1225,y:671,t:1527628312343};\\\", \\\"{x:1229,y:662,t:1527628312359};\\\", \\\"{x:1234,y:650,t:1527628312375};\\\", \\\"{x:1243,y:639,t:1527628312393};\\\", \\\"{x:1246,y:629,t:1527628312409};\\\", \\\"{x:1249,y:622,t:1527628312426};\\\", \\\"{x:1253,y:610,t:1527628312442};\\\", \\\"{x:1253,y:607,t:1527628312460};\\\", \\\"{x:1255,y:600,t:1527628312476};\\\", \\\"{x:1255,y:595,t:1527628312492};\\\", \\\"{x:1257,y:587,t:1527628312509};\\\", \\\"{x:1260,y:580,t:1527628312525};\\\", \\\"{x:1261,y:575,t:1527628312542};\\\", \\\"{x:1266,y:569,t:1527628312559};\\\", \\\"{x:1267,y:564,t:1527628312575};\\\", \\\"{x:1268,y:559,t:1527628312592};\\\", \\\"{x:1270,y:552,t:1527628312609};\\\", \\\"{x:1272,y:546,t:1527628312625};\\\", \\\"{x:1276,y:540,t:1527628312642};\\\", \\\"{x:1277,y:538,t:1527628312659};\\\", \\\"{x:1279,y:534,t:1527628312675};\\\", \\\"{x:1280,y:533,t:1527628312692};\\\", \\\"{x:1280,y:530,t:1527628312709};\\\", \\\"{x:1281,y:526,t:1527628312726};\\\", \\\"{x:1282,y:525,t:1527628312742};\\\", \\\"{x:1283,y:524,t:1527628312760};\\\", \\\"{x:1283,y:523,t:1527628312775};\\\", \\\"{x:1283,y:522,t:1527628312793};\\\", \\\"{x:1283,y:520,t:1527628312809};\\\", \\\"{x:1284,y:521,t:1527628313003};\\\", \\\"{x:1284,y:522,t:1527628313010};\\\", \\\"{x:1285,y:523,t:1527628313099};\\\", \\\"{x:1285,y:524,t:1527628313110};\\\", \\\"{x:1285,y:533,t:1527628318891};\\\", \\\"{x:1271,y:574,t:1527628318908};\\\", \\\"{x:1252,y:623,t:1527628318924};\\\", \\\"{x:1226,y:684,t:1527628318942};\\\", \\\"{x:1202,y:744,t:1527628318958};\\\", \\\"{x:1179,y:790,t:1527628318975};\\\", \\\"{x:1168,y:813,t:1527628318992};\\\", \\\"{x:1160,y:828,t:1527628319009};\\\", \\\"{x:1152,y:835,t:1527628319024};\\\", \\\"{x:1152,y:836,t:1527628319042};\\\", \\\"{x:1152,y:834,t:1527628319092};\\\", \\\"{x:1157,y:826,t:1527628319108};\\\", \\\"{x:1165,y:816,t:1527628319125};\\\", \\\"{x:1176,y:804,t:1527628319142};\\\", \\\"{x:1182,y:800,t:1527628319158};\\\", \\\"{x:1187,y:796,t:1527628319175};\\\", \\\"{x:1191,y:792,t:1527628319192};\\\", \\\"{x:1195,y:789,t:1527628319207};\\\", \\\"{x:1200,y:786,t:1527628319224};\\\", \\\"{x:1204,y:783,t:1527628319242};\\\", \\\"{x:1208,y:780,t:1527628319258};\\\", \\\"{x:1209,y:779,t:1527628319275};\\\", \\\"{x:1210,y:779,t:1527628319339};\\\", \\\"{x:1210,y:777,t:1527628319587};\\\", \\\"{x:1211,y:779,t:1527628319842};\\\", \\\"{x:1209,y:784,t:1527628319859};\\\", \\\"{x:1205,y:806,t:1527628319874};\\\", \\\"{x:1201,y:826,t:1527628319892};\\\", \\\"{x:1193,y:845,t:1527628319907};\\\", \\\"{x:1189,y:862,t:1527628319925};\\\", \\\"{x:1186,y:871,t:1527628319942};\\\", \\\"{x:1185,y:882,t:1527628319957};\\\", \\\"{x:1184,y:889,t:1527628319975};\\\", \\\"{x:1184,y:894,t:1527628319991};\\\", \\\"{x:1184,y:895,t:1527628320008};\\\", \\\"{x:1184,y:896,t:1527628320075};\\\", \\\"{x:1182,y:898,t:1527628320091};\\\", \\\"{x:1177,y:900,t:1527628320108};\\\", \\\"{x:1165,y:905,t:1527628320125};\\\", \\\"{x:1156,y:908,t:1527628320141};\\\", \\\"{x:1146,y:909,t:1527628320157};\\\", \\\"{x:1136,y:911,t:1527628320176};\\\", \\\"{x:1125,y:913,t:1527628320192};\\\", \\\"{x:1121,y:915,t:1527628320207};\\\", \\\"{x:1120,y:915,t:1527628320225};\\\", \\\"{x:1120,y:916,t:1527628320242};\\\", \\\"{x:1124,y:916,t:1527628320395};\\\", \\\"{x:1132,y:916,t:1527628320408};\\\", \\\"{x:1143,y:916,t:1527628320425};\\\", \\\"{x:1157,y:916,t:1527628320441};\\\", \\\"{x:1167,y:915,t:1527628320458};\\\", \\\"{x:1172,y:911,t:1527628320475};\\\", \\\"{x:1172,y:910,t:1527628320506};\\\", \\\"{x:1169,y:907,t:1527628320514};\\\", \\\"{x:1163,y:904,t:1527628320525};\\\", \\\"{x:1143,y:903,t:1527628320541};\\\", \\\"{x:1124,y:903,t:1527628320558};\\\", \\\"{x:1109,y:903,t:1527628320575};\\\", \\\"{x:1100,y:904,t:1527628320592};\\\", \\\"{x:1094,y:905,t:1527628320607};\\\", \\\"{x:1093,y:905,t:1527628320624};\\\", \\\"{x:1092,y:907,t:1527628320641};\\\", \\\"{x:1091,y:908,t:1527628320657};\\\", \\\"{x:1089,y:910,t:1527628320674};\\\", \\\"{x:1086,y:911,t:1527628320691};\\\", \\\"{x:1081,y:912,t:1527628320707};\\\", \\\"{x:1080,y:912,t:1527628320725};\\\", \\\"{x:1079,y:912,t:1527628320741};\\\", \\\"{x:1078,y:912,t:1527628327436};\\\", \\\"{x:1078,y:910,t:1527628327450};\\\", \\\"{x:1083,y:904,t:1527628327467};\\\", \\\"{x:1090,y:894,t:1527628327484};\\\", \\\"{x:1094,y:891,t:1527628327501};\\\", \\\"{x:1101,y:883,t:1527628327516};\\\", \\\"{x:1107,y:879,t:1527628327533};\\\", \\\"{x:1117,y:871,t:1527628327549};\\\", \\\"{x:1125,y:866,t:1527628327567};\\\", \\\"{x:1128,y:864,t:1527628327584};\\\", \\\"{x:1131,y:861,t:1527628327599};\\\", \\\"{x:1134,y:858,t:1527628327617};\\\", \\\"{x:1136,y:855,t:1527628327633};\\\", \\\"{x:1138,y:852,t:1527628327650};\\\", \\\"{x:1140,y:849,t:1527628327667};\\\", \\\"{x:1144,y:844,t:1527628327683};\\\", \\\"{x:1145,y:842,t:1527628327700};\\\", \\\"{x:1146,y:839,t:1527628327716};\\\", \\\"{x:1148,y:837,t:1527628327733};\\\", \\\"{x:1149,y:835,t:1527628327749};\\\", \\\"{x:1151,y:832,t:1527628327772};\\\", \\\"{x:1151,y:831,t:1527628327795};\\\", \\\"{x:1152,y:830,t:1527628327812};\\\", \\\"{x:1153,y:829,t:1527628327852};\\\", \\\"{x:1153,y:828,t:1527628327867};\\\", \\\"{x:1153,y:827,t:1527628327916};\\\", \\\"{x:1154,y:825,t:1527628327933};\\\", \\\"{x:1154,y:824,t:1527628327950};\\\", \\\"{x:1155,y:821,t:1527628327967};\\\", \\\"{x:1155,y:819,t:1527628327983};\\\", \\\"{x:1156,y:815,t:1527628327999};\\\", \\\"{x:1158,y:815,t:1527628328724};\\\", \\\"{x:1158,y:814,t:1527628328740};\\\", \\\"{x:1158,y:812,t:1527628328750};\\\", \\\"{x:1158,y:811,t:1527628328767};\\\", \\\"{x:1158,y:809,t:1527628328783};\\\", \\\"{x:1159,y:807,t:1527628328799};\\\", \\\"{x:1159,y:805,t:1527628328815};\\\", \\\"{x:1160,y:804,t:1527628328831};\\\", \\\"{x:1161,y:804,t:1527628328849};\\\", \\\"{x:1161,y:803,t:1527628328865};\\\", \\\"{x:1161,y:801,t:1527628328881};\\\", \\\"{x:1161,y:800,t:1527628328906};\\\", \\\"{x:1161,y:799,t:1527628328939};\\\", \\\"{x:1161,y:798,t:1527628328949};\\\", \\\"{x:1161,y:797,t:1527628328966};\\\", \\\"{x:1162,y:796,t:1527628328981};\\\", \\\"{x:1162,y:795,t:1527628329035};\\\", \\\"{x:1162,y:793,t:1527628329091};\\\", \\\"{x:1164,y:792,t:1527628329172};\\\", \\\"{x:1164,y:791,t:1527628329212};\\\", \\\"{x:1165,y:790,t:1527628331036};\\\", \\\"{x:1166,y:789,t:1527628331048};\\\", \\\"{x:1166,y:786,t:1527628331066};\\\", \\\"{x:1168,y:784,t:1527628331083};\\\", \\\"{x:1168,y:780,t:1527628331100};\\\", \\\"{x:1170,y:775,t:1527628331115};\\\", \\\"{x:1171,y:772,t:1527628331133};\\\", \\\"{x:1172,y:766,t:1527628331149};\\\", \\\"{x:1175,y:760,t:1527628331166};\\\", \\\"{x:1177,y:754,t:1527628331182};\\\", \\\"{x:1178,y:751,t:1527628331199};\\\", \\\"{x:1179,y:746,t:1527628331216};\\\", \\\"{x:1181,y:742,t:1527628331233};\\\", \\\"{x:1181,y:740,t:1527628331249};\\\", \\\"{x:1182,y:738,t:1527628331266};\\\", \\\"{x:1183,y:736,t:1527628331282};\\\", \\\"{x:1184,y:733,t:1527628331300};\\\", \\\"{x:1184,y:732,t:1527628331315};\\\", \\\"{x:1184,y:731,t:1527628331348};\\\", \\\"{x:1185,y:731,t:1527628331371};\\\", \\\"{x:1186,y:729,t:1527628331387};\\\", \\\"{x:1187,y:728,t:1527628331434};\\\", \\\"{x:1187,y:727,t:1527628331467};\\\", \\\"{x:1187,y:726,t:1527628331482};\\\", \\\"{x:1187,y:725,t:1527628331499};\\\", \\\"{x:1187,y:724,t:1527628331515};\\\", \\\"{x:1188,y:722,t:1527628331533};\\\", \\\"{x:1188,y:721,t:1527628331549};\\\", \\\"{x:1189,y:719,t:1527628331566};\\\", \\\"{x:1189,y:718,t:1527628331583};\\\", \\\"{x:1190,y:716,t:1527628331598};\\\", \\\"{x:1191,y:715,t:1527628331764};\\\", \\\"{x:1192,y:713,t:1527628331828};\\\", \\\"{x:1193,y:711,t:1527628331844};\\\", \\\"{x:1193,y:710,t:1527628331859};\\\", \\\"{x:1193,y:709,t:1527628331868};\\\", \\\"{x:1193,y:708,t:1527628331882};\\\", \\\"{x:1193,y:707,t:1527628331901};\\\", \\\"{x:1194,y:706,t:1527628331924};\\\", \\\"{x:1195,y:705,t:1527628331940};\\\", \\\"{x:1194,y:705,t:1527628333228};\\\", \\\"{x:1192,y:705,t:1527628333236};\\\", \\\"{x:1189,y:704,t:1527628333248};\\\", \\\"{x:1185,y:703,t:1527628333265};\\\", \\\"{x:1182,y:702,t:1527628333282};\\\", \\\"{x:1181,y:702,t:1527628333300};\\\", \\\"{x:1181,y:703,t:1527628337252};\\\", \\\"{x:1181,y:705,t:1527628337265};\\\", \\\"{x:1181,y:712,t:1527628337281};\\\", \\\"{x:1181,y:716,t:1527628337297};\\\", \\\"{x:1182,y:723,t:1527628337317};\\\", \\\"{x:1182,y:726,t:1527628337332};\\\", \\\"{x:1183,y:729,t:1527628337348};\\\", \\\"{x:1183,y:730,t:1527628337372};\\\", \\\"{x:1183,y:731,t:1527628337382};\\\", \\\"{x:1184,y:732,t:1527628337398};\\\", \\\"{x:1185,y:733,t:1527628337415};\\\", \\\"{x:1185,y:734,t:1527628338148};\\\", \\\"{x:1190,y:745,t:1527628338165};\\\", \\\"{x:1199,y:760,t:1527628338182};\\\", \\\"{x:1204,y:772,t:1527628338198};\\\", \\\"{x:1211,y:786,t:1527628338215};\\\", \\\"{x:1216,y:796,t:1527628338231};\\\", \\\"{x:1222,y:807,t:1527628338248};\\\", \\\"{x:1225,y:811,t:1527628338265};\\\", \\\"{x:1227,y:815,t:1527628338280};\\\", \\\"{x:1227,y:819,t:1527628338298};\\\", \\\"{x:1228,y:821,t:1527628338315};\\\", \\\"{x:1232,y:826,t:1527628338331};\\\", \\\"{x:1234,y:827,t:1527628338348};\\\", \\\"{x:1236,y:830,t:1527628338365};\\\", \\\"{x:1238,y:833,t:1527628338381};\\\", \\\"{x:1239,y:836,t:1527628338398};\\\", \\\"{x:1240,y:840,t:1527628338415};\\\", \\\"{x:1244,y:850,t:1527628338431};\\\", \\\"{x:1253,y:862,t:1527628338449};\\\", \\\"{x:1263,y:876,t:1527628338465};\\\", \\\"{x:1273,y:888,t:1527628338481};\\\", \\\"{x:1277,y:896,t:1527628338498};\\\", \\\"{x:1283,y:906,t:1527628338515};\\\", \\\"{x:1288,y:913,t:1527628338532};\\\", \\\"{x:1290,y:918,t:1527628338548};\\\", \\\"{x:1292,y:920,t:1527628338565};\\\", \\\"{x:1291,y:920,t:1527628338908};\\\", \\\"{x:1290,y:920,t:1527628338923};\\\", \\\"{x:1289,y:919,t:1527628338963};\\\", \\\"{x:1289,y:918,t:1527628338981};\\\", \\\"{x:1289,y:917,t:1527628339004};\\\", \\\"{x:1289,y:915,t:1527628339027};\\\", \\\"{x:1287,y:913,t:1527628339363};\\\", \\\"{x:1284,y:910,t:1527628339382};\\\", \\\"{x:1282,y:906,t:1527628339398};\\\", \\\"{x:1278,y:901,t:1527628339414};\\\", \\\"{x:1275,y:898,t:1527628339430};\\\", \\\"{x:1274,y:897,t:1527628339447};\\\", \\\"{x:1273,y:895,t:1527628339464};\\\", \\\"{x:1272,y:894,t:1527628339480};\\\", \\\"{x:1271,y:895,t:1527628340852};\\\", \\\"{x:1271,y:897,t:1527628340867};\\\", \\\"{x:1269,y:898,t:1527628340881};\\\", \\\"{x:1260,y:903,t:1527628340900};\\\", \\\"{x:1255,y:906,t:1527628340914};\\\", \\\"{x:1222,y:916,t:1527628340932};\\\", \\\"{x:1196,y:922,t:1527628340947};\\\", \\\"{x:1156,y:929,t:1527628340965};\\\", \\\"{x:1147,y:929,t:1527628340981};\\\", \\\"{x:1133,y:928,t:1527628340998};\\\", \\\"{x:1122,y:921,t:1527628341014};\\\", \\\"{x:1116,y:915,t:1527628341031};\\\", \\\"{x:1114,y:910,t:1527628341048};\\\", \\\"{x:1114,y:903,t:1527628341064};\\\", \\\"{x:1114,y:893,t:1527628341081};\\\", \\\"{x:1121,y:881,t:1527628341099};\\\", \\\"{x:1126,y:869,t:1527628341114};\\\", \\\"{x:1136,y:855,t:1527628341130};\\\", \\\"{x:1148,y:841,t:1527628341147};\\\", \\\"{x:1177,y:821,t:1527628341163};\\\", \\\"{x:1214,y:794,t:1527628341180};\\\", \\\"{x:1264,y:761,t:1527628341197};\\\", \\\"{x:1295,y:731,t:1527628341213};\\\", \\\"{x:1320,y:697,t:1527628341231};\\\", \\\"{x:1328,y:676,t:1527628341248};\\\", \\\"{x:1333,y:656,t:1527628341264};\\\", \\\"{x:1336,y:641,t:1527628341280};\\\", \\\"{x:1337,y:627,t:1527628341298};\\\", \\\"{x:1337,y:613,t:1527628341313};\\\", \\\"{x:1337,y:590,t:1527628341331};\\\", \\\"{x:1337,y:575,t:1527628341347};\\\", \\\"{x:1337,y:562,t:1527628341363};\\\", \\\"{x:1334,y:548,t:1527628341380};\\\", \\\"{x:1328,y:536,t:1527628341397};\\\", \\\"{x:1319,y:524,t:1527628341413};\\\", \\\"{x:1309,y:512,t:1527628341430};\\\", \\\"{x:1304,y:499,t:1527628341447};\\\", \\\"{x:1299,y:490,t:1527628341463};\\\", \\\"{x:1296,y:485,t:1527628341480};\\\", \\\"{x:1294,y:484,t:1527628341498};\\\", \\\"{x:1292,y:484,t:1527628341513};\\\", \\\"{x:1287,y:484,t:1527628341530};\\\", \\\"{x:1283,y:484,t:1527628341546};\\\", \\\"{x:1282,y:485,t:1527628341563};\\\", \\\"{x:1280,y:485,t:1527628341652};\\\", \\\"{x:1280,y:486,t:1527628341667};\\\", \\\"{x:1279,y:486,t:1527628341681};\\\", \\\"{x:1279,y:487,t:1527628341697};\\\", \\\"{x:1279,y:491,t:1527628341714};\\\", \\\"{x:1279,y:495,t:1527628341731};\\\", \\\"{x:1279,y:498,t:1527628341747};\\\", \\\"{x:1279,y:500,t:1527628341764};\\\", \\\"{x:1279,y:501,t:1527628341780};\\\", \\\"{x:1279,y:502,t:1527628341796};\\\", \\\"{x:1279,y:503,t:1527628341835};\\\", \\\"{x:1279,y:506,t:1527628357965};\\\", \\\"{x:1278,y:517,t:1527628357979};\\\", \\\"{x:1274,y:526,t:1527628357994};\\\", \\\"{x:1267,y:544,t:1527628358011};\\\", \\\"{x:1258,y:562,t:1527628358029};\\\", \\\"{x:1247,y:590,t:1527628358044};\\\", \\\"{x:1238,y:617,t:1527628358061};\\\", \\\"{x:1229,y:646,t:1527628358078};\\\", \\\"{x:1222,y:668,t:1527628358095};\\\", \\\"{x:1212,y:687,t:1527628358111};\\\", \\\"{x:1203,y:703,t:1527628358128};\\\", \\\"{x:1192,y:721,t:1527628358144};\\\", \\\"{x:1175,y:739,t:1527628358161};\\\", \\\"{x:1149,y:763,t:1527628358179};\\\", \\\"{x:1129,y:776,t:1527628358194};\\\", \\\"{x:1112,y:791,t:1527628358211};\\\", \\\"{x:1092,y:805,t:1527628358229};\\\", \\\"{x:1082,y:813,t:1527628358245};\\\", \\\"{x:1067,y:824,t:1527628358262};\\\", \\\"{x:1060,y:830,t:1527628358279};\\\", \\\"{x:1049,y:841,t:1527628358295};\\\", \\\"{x:1041,y:855,t:1527628358311};\\\", \\\"{x:1034,y:871,t:1527628358328};\\\", \\\"{x:1031,y:890,t:1527628358345};\\\", \\\"{x:1031,y:905,t:1527628358362};\\\", \\\"{x:1044,y:926,t:1527628358379};\\\", \\\"{x:1055,y:940,t:1527628358395};\\\", \\\"{x:1065,y:949,t:1527628358411};\\\", \\\"{x:1070,y:954,t:1527628358428};\\\", \\\"{x:1075,y:955,t:1527628358444};\\\", \\\"{x:1080,y:956,t:1527628358461};\\\", \\\"{x:1086,y:956,t:1527628358479};\\\", \\\"{x:1095,y:950,t:1527628358495};\\\", \\\"{x:1109,y:945,t:1527628358511};\\\", \\\"{x:1123,y:934,t:1527628358529};\\\", \\\"{x:1134,y:920,t:1527628358545};\\\", \\\"{x:1140,y:909,t:1527628358562};\\\", \\\"{x:1144,y:897,t:1527628358578};\\\", \\\"{x:1145,y:891,t:1527628358595};\\\", \\\"{x:1145,y:887,t:1527628358611};\\\", \\\"{x:1145,y:882,t:1527628358628};\\\", \\\"{x:1145,y:877,t:1527628358645};\\\", \\\"{x:1146,y:871,t:1527628358661};\\\", \\\"{x:1146,y:865,t:1527628358677};\\\", \\\"{x:1147,y:860,t:1527628358695};\\\", \\\"{x:1147,y:858,t:1527628358711};\\\", \\\"{x:1148,y:854,t:1527628358728};\\\", \\\"{x:1149,y:852,t:1527628358745};\\\", \\\"{x:1152,y:847,t:1527628358761};\\\", \\\"{x:1156,y:842,t:1527628358777};\\\", \\\"{x:1158,y:837,t:1527628358795};\\\", \\\"{x:1161,y:833,t:1527628358811};\\\", \\\"{x:1164,y:828,t:1527628358829};\\\", \\\"{x:1164,y:826,t:1527628358845};\\\", \\\"{x:1167,y:820,t:1527628358861};\\\", \\\"{x:1169,y:816,t:1527628358877};\\\", \\\"{x:1173,y:809,t:1527628358895};\\\", \\\"{x:1175,y:804,t:1527628358912};\\\", \\\"{x:1177,y:799,t:1527628358928};\\\", \\\"{x:1180,y:795,t:1527628358944};\\\", \\\"{x:1181,y:792,t:1527628358962};\\\", \\\"{x:1183,y:790,t:1527628358977};\\\", \\\"{x:1183,y:788,t:1527628358994};\\\", \\\"{x:1184,y:786,t:1527628359019};\\\", \\\"{x:1185,y:784,t:1527628359043};\\\", \\\"{x:1186,y:782,t:1527628359059};\\\", \\\"{x:1187,y:781,t:1527628359067};\\\", \\\"{x:1187,y:780,t:1527628359083};\\\", \\\"{x:1188,y:778,t:1527628359095};\\\", \\\"{x:1188,y:777,t:1527628359111};\\\", \\\"{x:1188,y:775,t:1527628359127};\\\", \\\"{x:1188,y:772,t:1527628359144};\\\", \\\"{x:1188,y:769,t:1527628359161};\\\", \\\"{x:1190,y:766,t:1527628359177};\\\", \\\"{x:1190,y:761,t:1527628359194};\\\", \\\"{x:1191,y:759,t:1527628359211};\\\", \\\"{x:1192,y:755,t:1527628359227};\\\", \\\"{x:1192,y:754,t:1527628359244};\\\", \\\"{x:1193,y:752,t:1527628359262};\\\", \\\"{x:1194,y:751,t:1527628359277};\\\", \\\"{x:1197,y:754,t:1527628359475};\\\", \\\"{x:1198,y:758,t:1527628359483};\\\", \\\"{x:1199,y:761,t:1527628359495};\\\", \\\"{x:1202,y:766,t:1527628359512};\\\", \\\"{x:1203,y:770,t:1527628359527};\\\", \\\"{x:1205,y:774,t:1527628359544};\\\", \\\"{x:1206,y:775,t:1527628359562};\\\", \\\"{x:1206,y:778,t:1527628359578};\\\", \\\"{x:1207,y:781,t:1527628359595};\\\", \\\"{x:1207,y:782,t:1527628359612};\\\", \\\"{x:1208,y:785,t:1527628359628};\\\", \\\"{x:1209,y:787,t:1527628359645};\\\", \\\"{x:1209,y:791,t:1527628359662};\\\", \\\"{x:1210,y:795,t:1527628359678};\\\", \\\"{x:1214,y:799,t:1527628359695};\\\", \\\"{x:1215,y:801,t:1527628359712};\\\", \\\"{x:1217,y:806,t:1527628359727};\\\", \\\"{x:1220,y:809,t:1527628359745};\\\", \\\"{x:1223,y:812,t:1527628359761};\\\", \\\"{x:1225,y:814,t:1527628359777};\\\", \\\"{x:1229,y:819,t:1527628359795};\\\", \\\"{x:1230,y:820,t:1527628359811};\\\", \\\"{x:1231,y:821,t:1527628359940};\\\", \\\"{x:1233,y:821,t:1527628360195};\\\", \\\"{x:1235,y:821,t:1527628360219};\\\", \\\"{x:1236,y:821,t:1527628360251};\\\", \\\"{x:1238,y:821,t:1527628360699};\\\", \\\"{x:1239,y:821,t:1527628360714};\\\", \\\"{x:1240,y:821,t:1527628360727};\\\", \\\"{x:1240,y:820,t:1527628361059};\\\", \\\"{x:1241,y:820,t:1527628361867};\\\", \\\"{x:1246,y:818,t:1527628368715};\\\", \\\"{x:1259,y:810,t:1527628368727};\\\", \\\"{x:1288,y:796,t:1527628368743};\\\", \\\"{x:1306,y:794,t:1527628368760};\\\", \\\"{x:1329,y:794,t:1527628368777};\\\", \\\"{x:1344,y:795,t:1527628368793};\\\", \\\"{x:1358,y:796,t:1527628368810};\\\", \\\"{x:1362,y:798,t:1527628368827};\\\", \\\"{x:1363,y:797,t:1527628369300};\\\", \\\"{x:1363,y:796,t:1527628369315};\\\", \\\"{x:1363,y:794,t:1527628369326};\\\", \\\"{x:1365,y:785,t:1527628369343};\\\", \\\"{x:1366,y:782,t:1527628369360};\\\", \\\"{x:1366,y:776,t:1527628369376};\\\", \\\"{x:1366,y:770,t:1527628369393};\\\", \\\"{x:1366,y:765,t:1527628369409};\\\", \\\"{x:1366,y:758,t:1527628369425};\\\", \\\"{x:1366,y:748,t:1527628369442};\\\", \\\"{x:1366,y:744,t:1527628369459};\\\", \\\"{x:1366,y:741,t:1527628369475};\\\", \\\"{x:1366,y:736,t:1527628369492};\\\", \\\"{x:1366,y:731,t:1527628369510};\\\", \\\"{x:1366,y:727,t:1527628369525};\\\", \\\"{x:1366,y:720,t:1527628369542};\\\", \\\"{x:1366,y:715,t:1527628369559};\\\", \\\"{x:1366,y:707,t:1527628369575};\\\", \\\"{x:1366,y:702,t:1527628369593};\\\", \\\"{x:1366,y:700,t:1527628369610};\\\", \\\"{x:1366,y:698,t:1527628369626};\\\", \\\"{x:1366,y:696,t:1527628369642};\\\", \\\"{x:1365,y:695,t:1527628369851};\\\", \\\"{x:1363,y:695,t:1527628369860};\\\", \\\"{x:1361,y:695,t:1527628369876};\\\", \\\"{x:1360,y:695,t:1527628369893};\\\", \\\"{x:1358,y:696,t:1527628369910};\\\", \\\"{x:1356,y:697,t:1527628369926};\\\", \\\"{x:1354,y:697,t:1527628369987};\\\", \\\"{x:1353,y:698,t:1527628370027};\\\", \\\"{x:1353,y:699,t:1527628371956};\\\", \\\"{x:1353,y:701,t:1527628371963};\\\", \\\"{x:1353,y:702,t:1527628371976};\\\", \\\"{x:1352,y:704,t:1527628371993};\\\", \\\"{x:1350,y:706,t:1527628372009};\\\", \\\"{x:1350,y:708,t:1527628372026};\\\", \\\"{x:1349,y:709,t:1527628372043};\\\", \\\"{x:1349,y:711,t:1527628372067};\\\", \\\"{x:1348,y:711,t:1527628372076};\\\", \\\"{x:1348,y:712,t:1527628372138};\\\", \\\"{x:1347,y:714,t:1527628372371};\\\", \\\"{x:1346,y:716,t:1527628372379};\\\", \\\"{x:1346,y:718,t:1527628372392};\\\", \\\"{x:1343,y:722,t:1527628372409};\\\", \\\"{x:1339,y:730,t:1527628372426};\\\", \\\"{x:1339,y:733,t:1527628372442};\\\", \\\"{x:1335,y:738,t:1527628372459};\\\", \\\"{x:1331,y:746,t:1527628372476};\\\", \\\"{x:1329,y:751,t:1527628372493};\\\", \\\"{x:1320,y:762,t:1527628372509};\\\", \\\"{x:1313,y:770,t:1527628372526};\\\", \\\"{x:1306,y:780,t:1527628372543};\\\", \\\"{x:1294,y:794,t:1527628372559};\\\", \\\"{x:1285,y:803,t:1527628372576};\\\", \\\"{x:1280,y:810,t:1527628372593};\\\", \\\"{x:1272,y:820,t:1527628372609};\\\", \\\"{x:1264,y:833,t:1527628372626};\\\", \\\"{x:1262,y:836,t:1527628372643};\\\", \\\"{x:1259,y:841,t:1527628372659};\\\", \\\"{x:1258,y:846,t:1527628372676};\\\", \\\"{x:1254,y:851,t:1527628372693};\\\", \\\"{x:1252,y:856,t:1527628372709};\\\", \\\"{x:1251,y:860,t:1527628372726};\\\", \\\"{x:1250,y:867,t:1527628372742};\\\", \\\"{x:1248,y:872,t:1527628372759};\\\", \\\"{x:1248,y:879,t:1527628372776};\\\", \\\"{x:1248,y:888,t:1527628372793};\\\", \\\"{x:1251,y:898,t:1527628372809};\\\", \\\"{x:1253,y:904,t:1527628372826};\\\", \\\"{x:1253,y:906,t:1527628372842};\\\", \\\"{x:1253,y:910,t:1527628372858};\\\", \\\"{x:1255,y:913,t:1527628372876};\\\", \\\"{x:1255,y:912,t:1527628372955};\\\", \\\"{x:1256,y:906,t:1527628372963};\\\", \\\"{x:1258,y:902,t:1527628372976};\\\", \\\"{x:1263,y:889,t:1527628372992};\\\", \\\"{x:1266,y:879,t:1527628373009};\\\", \\\"{x:1267,y:868,t:1527628373026};\\\", \\\"{x:1272,y:852,t:1527628373043};\\\", \\\"{x:1276,y:843,t:1527628373059};\\\", \\\"{x:1279,y:836,t:1527628373076};\\\", \\\"{x:1281,y:829,t:1527628373092};\\\", \\\"{x:1282,y:826,t:1527628373109};\\\", \\\"{x:1283,y:822,t:1527628373125};\\\", \\\"{x:1284,y:819,t:1527628373142};\\\", \\\"{x:1284,y:818,t:1527628373158};\\\", \\\"{x:1285,y:816,t:1527628373176};\\\", \\\"{x:1286,y:815,t:1527628373192};\\\", \\\"{x:1286,y:814,t:1527628373209};\\\", \\\"{x:1287,y:812,t:1527628373226};\\\", \\\"{x:1287,y:810,t:1527628373242};\\\", \\\"{x:1289,y:807,t:1527628373258};\\\", \\\"{x:1291,y:806,t:1527628373276};\\\", \\\"{x:1291,y:805,t:1527628373300};\\\", \\\"{x:1293,y:803,t:1527628373309};\\\", \\\"{x:1294,y:800,t:1527628373326};\\\", \\\"{x:1296,y:798,t:1527628373342};\\\", \\\"{x:1297,y:794,t:1527628373359};\\\", \\\"{x:1299,y:792,t:1527628373376};\\\", \\\"{x:1299,y:790,t:1527628373395};\\\", \\\"{x:1301,y:788,t:1527628373409};\\\", \\\"{x:1301,y:787,t:1527628373426};\\\", \\\"{x:1301,y:786,t:1527628373443};\\\", \\\"{x:1303,y:784,t:1527628373467};\\\", \\\"{x:1304,y:783,t:1527628373476};\\\", \\\"{x:1305,y:782,t:1527628373492};\\\", \\\"{x:1306,y:780,t:1527628373509};\\\", \\\"{x:1308,y:779,t:1527628373526};\\\", \\\"{x:1310,y:776,t:1527628373542};\\\", \\\"{x:1311,y:774,t:1527628373559};\\\", \\\"{x:1313,y:773,t:1527628373576};\\\", \\\"{x:1314,y:771,t:1527628373592};\\\", \\\"{x:1316,y:769,t:1527628373610};\\\", \\\"{x:1319,y:765,t:1527628373626};\\\", \\\"{x:1321,y:764,t:1527628373642};\\\", \\\"{x:1322,y:762,t:1527628373659};\\\", \\\"{x:1323,y:761,t:1527628373676};\\\", \\\"{x:1323,y:760,t:1527628373692};\\\", \\\"{x:1324,y:759,t:1527628373723};\\\", \\\"{x:1326,y:757,t:1527628373795};\\\", \\\"{x:1326,y:756,t:1527628373827};\\\", \\\"{x:1327,y:755,t:1527628373843};\\\", \\\"{x:1327,y:753,t:1527628373859};\\\", \\\"{x:1329,y:752,t:1527628373876};\\\", \\\"{x:1330,y:751,t:1527628373892};\\\", \\\"{x:1331,y:749,t:1527628373909};\\\", \\\"{x:1332,y:748,t:1527628373926};\\\", \\\"{x:1333,y:746,t:1527628373942};\\\", \\\"{x:1334,y:746,t:1527628373960};\\\", \\\"{x:1335,y:744,t:1527628373976};\\\", \\\"{x:1335,y:743,t:1527628373993};\\\", \\\"{x:1337,y:741,t:1527628374009};\\\", \\\"{x:1338,y:739,t:1527628374026};\\\", \\\"{x:1339,y:739,t:1527628374043};\\\", \\\"{x:1339,y:737,t:1527628374066};\\\", \\\"{x:1340,y:737,t:1527628374101};\\\", \\\"{x:1340,y:736,t:1527628374130};\\\", \\\"{x:1340,y:734,t:1527628374171};\\\", \\\"{x:1341,y:734,t:1527628374195};\\\", \\\"{x:1342,y:733,t:1527628374209};\\\", \\\"{x:1342,y:732,t:1527628374226};\\\", \\\"{x:1343,y:731,t:1527628374250};\\\", \\\"{x:1344,y:731,t:1527628374282};\\\", \\\"{x:1345,y:730,t:1527628374292};\\\", \\\"{x:1346,y:728,t:1527628374338};\\\", \\\"{x:1346,y:727,t:1527628374411};\\\", \\\"{x:1347,y:727,t:1527628374515};\\\", \\\"{x:1339,y:727,t:1527628375003};\\\", \\\"{x:1332,y:731,t:1527628375011};\\\", \\\"{x:1326,y:735,t:1527628375025};\\\", \\\"{x:1315,y:737,t:1527628375042};\\\", \\\"{x:1302,y:740,t:1527628375058};\\\", \\\"{x:1297,y:743,t:1527628375075};\\\", \\\"{x:1293,y:744,t:1527628375092};\\\", \\\"{x:1292,y:744,t:1527628375109};\\\", \\\"{x:1290,y:745,t:1527628375125};\\\", \\\"{x:1286,y:746,t:1527628375142};\\\", \\\"{x:1279,y:747,t:1527628375159};\\\", \\\"{x:1269,y:748,t:1527628375175};\\\", \\\"{x:1257,y:753,t:1527628375192};\\\", \\\"{x:1240,y:757,t:1527628375210};\\\", \\\"{x:1221,y:763,t:1527628375225};\\\", \\\"{x:1201,y:764,t:1527628375242};\\\", \\\"{x:1176,y:768,t:1527628375258};\\\", \\\"{x:1172,y:768,t:1527628375275};\\\", \\\"{x:1174,y:768,t:1527628375475};\\\", \\\"{x:1178,y:768,t:1527628375492};\\\", \\\"{x:1182,y:769,t:1527628375509};\\\", \\\"{x:1188,y:769,t:1527628375525};\\\", \\\"{x:1189,y:769,t:1527628375542};\\\", \\\"{x:1191,y:769,t:1527628375559};\\\", \\\"{x:1192,y:769,t:1527628375578};\\\", \\\"{x:1194,y:769,t:1527628375592};\\\", \\\"{x:1197,y:769,t:1527628375609};\\\", \\\"{x:1202,y:772,t:1527628375625};\\\", \\\"{x:1212,y:775,t:1527628375642};\\\", \\\"{x:1218,y:777,t:1527628375659};\\\", \\\"{x:1219,y:777,t:1527628375675};\\\", \\\"{x:1221,y:778,t:1527628375692};\\\", \\\"{x:1221,y:779,t:1527628375818};\\\", \\\"{x:1219,y:779,t:1527628375834};\\\", \\\"{x:1218,y:779,t:1527628375841};\\\", \\\"{x:1216,y:779,t:1527628375857};\\\", \\\"{x:1213,y:782,t:1527628378363};\\\", \\\"{x:1211,y:789,t:1527628378376};\\\", \\\"{x:1205,y:801,t:1527628378391};\\\", \\\"{x:1199,y:815,t:1527628378408};\\\", \\\"{x:1192,y:828,t:1527628378426};\\\", \\\"{x:1185,y:841,t:1527628378441};\\\", \\\"{x:1172,y:861,t:1527628378458};\\\", \\\"{x:1166,y:872,t:1527628378475};\\\", \\\"{x:1162,y:884,t:1527628378491};\\\", \\\"{x:1155,y:895,t:1527628378508};\\\", \\\"{x:1150,y:904,t:1527628378526};\\\", \\\"{x:1147,y:909,t:1527628378542};\\\", \\\"{x:1145,y:912,t:1527628378559};\\\", \\\"{x:1143,y:917,t:1527628378575};\\\", \\\"{x:1139,y:924,t:1527628378591};\\\", \\\"{x:1137,y:927,t:1527628378608};\\\", \\\"{x:1133,y:931,t:1527628378625};\\\", \\\"{x:1129,y:933,t:1527628378642};\\\", \\\"{x:1122,y:933,t:1527628378659};\\\", \\\"{x:1111,y:933,t:1527628378674};\\\", \\\"{x:1090,y:926,t:1527628378691};\\\", \\\"{x:1067,y:917,t:1527628378708};\\\", \\\"{x:1037,y:902,t:1527628378726};\\\", \\\"{x:1016,y:893,t:1527628378741};\\\", \\\"{x:1009,y:891,t:1527628378758};\\\", \\\"{x:1008,y:891,t:1527628378775};\\\", \\\"{x:1010,y:891,t:1527628378803};\\\", \\\"{x:1011,y:892,t:1527628378810};\\\", \\\"{x:1014,y:893,t:1527628378825};\\\", \\\"{x:1023,y:897,t:1527628378841};\\\", \\\"{x:1043,y:904,t:1527628378858};\\\", \\\"{x:1049,y:906,t:1527628378875};\\\", \\\"{x:1061,y:906,t:1527628378891};\\\", \\\"{x:1066,y:906,t:1527628378909};\\\", \\\"{x:1067,y:906,t:1527628378925};\\\", \\\"{x:1068,y:906,t:1527628378941};\\\", \\\"{x:1069,y:906,t:1527628378962};\\\", \\\"{x:1065,y:905,t:1527628379027};\\\", \\\"{x:1061,y:904,t:1527628379042};\\\", \\\"{x:1051,y:903,t:1527628379059};\\\", \\\"{x:1047,y:903,t:1527628379074};\\\", \\\"{x:1046,y:902,t:1527628379107};\\\", \\\"{x:1046,y:899,t:1527628379114};\\\", \\\"{x:1051,y:895,t:1527628379125};\\\", \\\"{x:1065,y:883,t:1527628379141};\\\", \\\"{x:1080,y:871,t:1527628379159};\\\", \\\"{x:1100,y:854,t:1527628379176};\\\", \\\"{x:1123,y:833,t:1527628379192};\\\", \\\"{x:1146,y:806,t:1527628379208};\\\", \\\"{x:1158,y:791,t:1527628379225};\\\", \\\"{x:1162,y:786,t:1527628379241};\\\", \\\"{x:1165,y:786,t:1527628379258};\\\", \\\"{x:1165,y:782,t:1527628379626};\\\", \\\"{x:1170,y:766,t:1527628379641};\\\", \\\"{x:1191,y:726,t:1527628379658};\\\", \\\"{x:1193,y:711,t:1527628379674};\\\", \\\"{x:1194,y:698,t:1527628379691};\\\", \\\"{x:1194,y:693,t:1527628379708};\\\", \\\"{x:1194,y:687,t:1527628379724};\\\", \\\"{x:1194,y:681,t:1527628379742};\\\", \\\"{x:1194,y:675,t:1527628379759};\\\", \\\"{x:1194,y:671,t:1527628379774};\\\", \\\"{x:1194,y:662,t:1527628379791};\\\", \\\"{x:1197,y:651,t:1527628379809};\\\", \\\"{x:1204,y:635,t:1527628379824};\\\", \\\"{x:1211,y:620,t:1527628379841};\\\", \\\"{x:1224,y:600,t:1527628379858};\\\", \\\"{x:1229,y:587,t:1527628379874};\\\", \\\"{x:1234,y:574,t:1527628379892};\\\", \\\"{x:1241,y:557,t:1527628379908};\\\", \\\"{x:1245,y:546,t:1527628379925};\\\", \\\"{x:1248,y:537,t:1527628379942};\\\", \\\"{x:1251,y:528,t:1527628379959};\\\", \\\"{x:1254,y:523,t:1527628379975};\\\", \\\"{x:1256,y:518,t:1527628379991};\\\", \\\"{x:1259,y:514,t:1527628380008};\\\", \\\"{x:1261,y:511,t:1527628380025};\\\", \\\"{x:1262,y:510,t:1527628380042};\\\", \\\"{x:1263,y:510,t:1527628380459};\\\", \\\"{x:1264,y:510,t:1527628380501};\\\", \\\"{x:1266,y:510,t:1527628380515};\\\", \\\"{x:1267,y:510,t:1527628380538};\\\", \\\"{x:1269,y:510,t:1527628380554};\\\", \\\"{x:1270,y:511,t:1527628380570};\\\", \\\"{x:1271,y:511,t:1527628380603};\\\", \\\"{x:1271,y:512,t:1527628380715};\\\", \\\"{x:1273,y:513,t:1527628380730};\\\", \\\"{x:1274,y:514,t:1527628380741};\\\", \\\"{x:1275,y:516,t:1527628380758};\\\", \\\"{x:1276,y:516,t:1527628380774};\\\", \\\"{x:1277,y:517,t:1527628380792};\\\", \\\"{x:1279,y:518,t:1527628380811};\\\", \\\"{x:1280,y:519,t:1527628398605};\\\", \\\"{x:1280,y:521,t:1527628398614};\\\", \\\"{x:1280,y:522,t:1527628398632};\\\", \\\"{x:1280,y:524,t:1527628398648};\\\", \\\"{x:1280,y:525,t:1527628398665};\\\", \\\"{x:1280,y:526,t:1527628399012};\\\", \\\"{x:1280,y:527,t:1527628399036};\\\", \\\"{x:1280,y:528,t:1527628399085};\\\", \\\"{x:1280,y:529,t:1527628399165};\\\", \\\"{x:1280,y:537,t:1527628401060};\\\", \\\"{x:1280,y:548,t:1527628401068};\\\", \\\"{x:1281,y:557,t:1527628401081};\\\", \\\"{x:1285,y:573,t:1527628401097};\\\", \\\"{x:1290,y:592,t:1527628401115};\\\", \\\"{x:1293,y:604,t:1527628401131};\\\", \\\"{x:1298,y:625,t:1527628401148};\\\", \\\"{x:1302,y:634,t:1527628401164};\\\", \\\"{x:1306,y:651,t:1527628401181};\\\", \\\"{x:1313,y:671,t:1527628401198};\\\", \\\"{x:1319,y:687,t:1527628401215};\\\", \\\"{x:1322,y:698,t:1527628401230};\\\", \\\"{x:1326,y:710,t:1527628401247};\\\", \\\"{x:1329,y:722,t:1527628401265};\\\", \\\"{x:1333,y:730,t:1527628401281};\\\", \\\"{x:1336,y:735,t:1527628401297};\\\", \\\"{x:1337,y:739,t:1527628401315};\\\", \\\"{x:1339,y:742,t:1527628401331};\\\", \\\"{x:1340,y:742,t:1527628401348};\\\", \\\"{x:1341,y:740,t:1527628401436};\\\", \\\"{x:1341,y:736,t:1527628401447};\\\", \\\"{x:1342,y:732,t:1527628401465};\\\", \\\"{x:1342,y:729,t:1527628401481};\\\", \\\"{x:1342,y:726,t:1527628401497};\\\", \\\"{x:1342,y:724,t:1527628401514};\\\", \\\"{x:1342,y:723,t:1527628401530};\\\", \\\"{x:1342,y:721,t:1527628401579};\\\", \\\"{x:1342,y:720,t:1527628401676};\\\", \\\"{x:1342,y:719,t:1527628401700};\\\", \\\"{x:1342,y:718,t:1527628401715};\\\", \\\"{x:1342,y:717,t:1527628401731};\\\", \\\"{x:1343,y:716,t:1527628401748};\\\", \\\"{x:1343,y:715,t:1527628401764};\\\", \\\"{x:1344,y:714,t:1527628402021};\\\", \\\"{x:1345,y:714,t:1527628402031};\\\", \\\"{x:1345,y:713,t:1527628402075};\\\", \\\"{x:1346,y:719,t:1527628412453};\\\", \\\"{x:1347,y:727,t:1527628412463};\\\", \\\"{x:1348,y:738,t:1527628412479};\\\", \\\"{x:1350,y:750,t:1527628412497};\\\", \\\"{x:1350,y:762,t:1527628412513};\\\", \\\"{x:1350,y:771,t:1527628412530};\\\", \\\"{x:1350,y:780,t:1527628412547};\\\", \\\"{x:1350,y:790,t:1527628412563};\\\", \\\"{x:1350,y:802,t:1527628412579};\\\", \\\"{x:1349,y:809,t:1527628412596};\\\", \\\"{x:1349,y:813,t:1527628412612};\\\", \\\"{x:1347,y:817,t:1527628412629};\\\", \\\"{x:1347,y:819,t:1527628412646};\\\", \\\"{x:1347,y:820,t:1527628412666};\\\", \\\"{x:1349,y:823,t:1527628412723};\\\", \\\"{x:1350,y:824,t:1527628412730};\\\", \\\"{x:1350,y:826,t:1527628412745};\\\", \\\"{x:1352,y:829,t:1527628412761};\\\", \\\"{x:1359,y:839,t:1527628412779};\\\", \\\"{x:1368,y:846,t:1527628412795};\\\", \\\"{x:1373,y:850,t:1527628412812};\\\", \\\"{x:1377,y:854,t:1527628412828};\\\", \\\"{x:1379,y:855,t:1527628412846};\\\", \\\"{x:1380,y:856,t:1527628412862};\\\", \\\"{x:1381,y:858,t:1527628412878};\\\", \\\"{x:1382,y:859,t:1527628412896};\\\", \\\"{x:1383,y:859,t:1527628412911};\\\", \\\"{x:1383,y:860,t:1527628412929};\\\", \\\"{x:1384,y:862,t:1527628412948};\\\", \\\"{x:1385,y:862,t:1527628412971};\\\", \\\"{x:1385,y:863,t:1527628412979};\\\", \\\"{x:1386,y:864,t:1527628412997};\\\", \\\"{x:1387,y:865,t:1527628413012};\\\", \\\"{x:1388,y:869,t:1527628413029};\\\", \\\"{x:1388,y:872,t:1527628413046};\\\", \\\"{x:1390,y:875,t:1527628413062};\\\", \\\"{x:1391,y:878,t:1527628413079};\\\", \\\"{x:1391,y:880,t:1527628413109};\\\", \\\"{x:1391,y:881,t:1527628413116};\\\", \\\"{x:1392,y:883,t:1527628413130};\\\", \\\"{x:1392,y:884,t:1527628413147};\\\", \\\"{x:1394,y:888,t:1527628413163};\\\", \\\"{x:1396,y:891,t:1527628413180};\\\", \\\"{x:1397,y:892,t:1527628413196};\\\", \\\"{x:1398,y:894,t:1527628413213};\\\", \\\"{x:1400,y:895,t:1527628413229};\\\", \\\"{x:1401,y:897,t:1527628413247};\\\", \\\"{x:1402,y:898,t:1527628413262};\\\", \\\"{x:1403,y:900,t:1527628413283};\\\", \\\"{x:1403,y:901,t:1527628413316};\\\", \\\"{x:1404,y:902,t:1527628413340};\\\", \\\"{x:1404,y:903,t:1527628413396};\\\", \\\"{x:1405,y:904,t:1527628413412};\\\", \\\"{x:1405,y:905,t:1527628413476};\\\", \\\"{x:1406,y:905,t:1527628413820};\\\", \\\"{x:1407,y:905,t:1527628413835};\\\", \\\"{x:1408,y:905,t:1527628413851};\\\", \\\"{x:1408,y:906,t:1527628413862};\\\", \\\"{x:1409,y:906,t:1527628413879};\\\", \\\"{x:1409,y:907,t:1527628413896};\\\", \\\"{x:1409,y:905,t:1527628414132};\\\", \\\"{x:1409,y:904,t:1527628414163};\\\", \\\"{x:1408,y:904,t:1527628414228};\\\", \\\"{x:1408,y:903,t:1527628414252};\\\", \\\"{x:1408,y:902,t:1527628414267};\\\", \\\"{x:1407,y:902,t:1527628414284};\\\", \\\"{x:1407,y:901,t:1527628414307};\\\", \\\"{x:1406,y:900,t:1527628414331};\\\", \\\"{x:1406,y:899,t:1527628414356};\\\", \\\"{x:1404,y:898,t:1527628414380};\\\", \\\"{x:1404,y:896,t:1527628414395};\\\", \\\"{x:1404,y:891,t:1527628414412};\\\", \\\"{x:1402,y:889,t:1527628414430};\\\", \\\"{x:1402,y:885,t:1527628414445};\\\", \\\"{x:1401,y:882,t:1527628414462};\\\", \\\"{x:1400,y:879,t:1527628414479};\\\", \\\"{x:1400,y:878,t:1527628414495};\\\", \\\"{x:1399,y:876,t:1527628414512};\\\", \\\"{x:1396,y:872,t:1527628414530};\\\", \\\"{x:1395,y:870,t:1527628414545};\\\", \\\"{x:1394,y:868,t:1527628414563};\\\", \\\"{x:1394,y:866,t:1527628414580};\\\", \\\"{x:1394,y:864,t:1527628414595};\\\", \\\"{x:1394,y:862,t:1527628414612};\\\", \\\"{x:1394,y:861,t:1527628414629};\\\", \\\"{x:1394,y:859,t:1527628414645};\\\", \\\"{x:1393,y:858,t:1527628414662};\\\", \\\"{x:1393,y:857,t:1527628414680};\\\", \\\"{x:1393,y:856,t:1527628414695};\\\", \\\"{x:1393,y:854,t:1527628414713};\\\", \\\"{x:1392,y:853,t:1527628414729};\\\", \\\"{x:1391,y:852,t:1527628414755};\\\", \\\"{x:1391,y:851,t:1527628414787};\\\", \\\"{x:1390,y:850,t:1527628415036};\\\", \\\"{x:1390,y:849,t:1527628415060};\\\", \\\"{x:1389,y:847,t:1527628415067};\\\", \\\"{x:1388,y:846,t:1527628415079};\\\", \\\"{x:1388,y:845,t:1527628415096};\\\", \\\"{x:1387,y:843,t:1527628415113};\\\", \\\"{x:1386,y:841,t:1527628415128};\\\", \\\"{x:1383,y:836,t:1527628415145};\\\", \\\"{x:1382,y:834,t:1527628415161};\\\", \\\"{x:1381,y:832,t:1527628415178};\\\", \\\"{x:1380,y:832,t:1527628415194};\\\", \\\"{x:1379,y:831,t:1527628415211};\\\", \\\"{x:1378,y:830,t:1527628415228};\\\", \\\"{x:1377,y:829,t:1527628415245};\\\", \\\"{x:1376,y:828,t:1527628415275};\\\", \\\"{x:1375,y:827,t:1527628415299};\\\", \\\"{x:1375,y:826,t:1527628415331};\\\", \\\"{x:1375,y:825,t:1527628415348};\\\", \\\"{x:1375,y:824,t:1527628415364};\\\", \\\"{x:1374,y:823,t:1527628415379};\\\", \\\"{x:1373,y:822,t:1527628415396};\\\", \\\"{x:1372,y:821,t:1527628415412};\\\", \\\"{x:1372,y:820,t:1527628415430};\\\", \\\"{x:1371,y:819,t:1527628415452};\\\", \\\"{x:1371,y:817,t:1527628415468};\\\", \\\"{x:1371,y:816,t:1527628415484};\\\", \\\"{x:1370,y:816,t:1527628415495};\\\", \\\"{x:1369,y:814,t:1527628415513};\\\", \\\"{x:1368,y:812,t:1527628415530};\\\", \\\"{x:1368,y:811,t:1527628415545};\\\", \\\"{x:1366,y:810,t:1527628415563};\\\", \\\"{x:1366,y:808,t:1527628415579};\\\", \\\"{x:1365,y:808,t:1527628415595};\\\", \\\"{x:1365,y:806,t:1527628415612};\\\", \\\"{x:1363,y:804,t:1527628415629};\\\", \\\"{x:1363,y:802,t:1527628415645};\\\", \\\"{x:1363,y:801,t:1527628415662};\\\", \\\"{x:1363,y:800,t:1527628415679};\\\", \\\"{x:1362,y:799,t:1527628415695};\\\", \\\"{x:1361,y:798,t:1527628415712};\\\", \\\"{x:1361,y:795,t:1527628415747};\\\", \\\"{x:1360,y:794,t:1527628415771};\\\", \\\"{x:1359,y:793,t:1527628415788};\\\", \\\"{x:1359,y:792,t:1527628415795};\\\", \\\"{x:1359,y:791,t:1527628415812};\\\", \\\"{x:1358,y:790,t:1527628415829};\\\", \\\"{x:1357,y:788,t:1527628415845};\\\", \\\"{x:1356,y:787,t:1527628415862};\\\", \\\"{x:1356,y:785,t:1527628415879};\\\", \\\"{x:1355,y:784,t:1527628415908};\\\", \\\"{x:1354,y:783,t:1527628415915};\\\", \\\"{x:1353,y:781,t:1527628415932};\\\", \\\"{x:1352,y:781,t:1527628415948};\\\", \\\"{x:1352,y:780,t:1527628415980};\\\", \\\"{x:1352,y:779,t:1527628415995};\\\", \\\"{x:1351,y:778,t:1527628416019};\\\", \\\"{x:1351,y:777,t:1527628416068};\\\", \\\"{x:1350,y:776,t:1527628416078};\\\", \\\"{x:1350,y:775,t:1527628416099};\\\", \\\"{x:1350,y:774,t:1527628416131};\\\", \\\"{x:1349,y:773,t:1527628416146};\\\", \\\"{x:1349,y:772,t:1527628416164};\\\", \\\"{x:1348,y:770,t:1527628416179};\\\", \\\"{x:1348,y:769,t:1527628416195};\\\", \\\"{x:1347,y:769,t:1527628416212};\\\", \\\"{x:1346,y:767,t:1527628416228};\\\", \\\"{x:1345,y:766,t:1527628416251};\\\", \\\"{x:1345,y:765,t:1527628416267};\\\", \\\"{x:1345,y:764,t:1527628416279};\\\", \\\"{x:1344,y:764,t:1527628416295};\\\", \\\"{x:1344,y:761,t:1527628416312};\\\", \\\"{x:1343,y:759,t:1527628416329};\\\", \\\"{x:1343,y:758,t:1527628416346};\\\", \\\"{x:1343,y:757,t:1527628416363};\\\", \\\"{x:1342,y:756,t:1527628416379};\\\", \\\"{x:1342,y:755,t:1527628416396};\\\", \\\"{x:1341,y:754,t:1527628416411};\\\", \\\"{x:1340,y:754,t:1527628416428};\\\", \\\"{x:1340,y:753,t:1527628416451};\\\", \\\"{x:1338,y:751,t:1527628416476};\\\", \\\"{x:1338,y:750,t:1527628416492};\\\", \\\"{x:1338,y:749,t:1527628416508};\\\", \\\"{x:1337,y:748,t:1527628416516};\\\", \\\"{x:1337,y:747,t:1527628416529};\\\", \\\"{x:1335,y:744,t:1527628416546};\\\", \\\"{x:1335,y:742,t:1527628416563};\\\", \\\"{x:1334,y:740,t:1527628416578};\\\", \\\"{x:1333,y:737,t:1527628416595};\\\", \\\"{x:1332,y:736,t:1527628416620};\\\", \\\"{x:1332,y:735,t:1527628419404};\\\", \\\"{x:1332,y:734,t:1527628419436};\\\", \\\"{x:1331,y:733,t:1527628420044};\\\", \\\"{x:1331,y:736,t:1527628420067};\\\", \\\"{x:1331,y:738,t:1527628420091};\\\", \\\"{x:1331,y:740,t:1527628420124};\\\", \\\"{x:1330,y:742,t:1527628420147};\\\", \\\"{x:1330,y:744,t:1527628420196};\\\", \\\"{x:1329,y:745,t:1527628421516};\\\", \\\"{x:1321,y:747,t:1527628421528};\\\", \\\"{x:1301,y:747,t:1527628421544};\\\", \\\"{x:1276,y:735,t:1527628421562};\\\", \\\"{x:1218,y:702,t:1527628421577};\\\", \\\"{x:1170,y:676,t:1527628421594};\\\", \\\"{x:1112,y:643,t:1527628421612};\\\", \\\"{x:1093,y:634,t:1527628421628};\\\", \\\"{x:1083,y:627,t:1527628421645};\\\", \\\"{x:1076,y:621,t:1527628421661};\\\", \\\"{x:1068,y:612,t:1527628421677};\\\", \\\"{x:1058,y:600,t:1527628421695};\\\", \\\"{x:1042,y:586,t:1527628421711};\\\", \\\"{x:1021,y:570,t:1527628421728};\\\", \\\"{x:997,y:549,t:1527628421745};\\\", \\\"{x:959,y:527,t:1527628421762};\\\", \\\"{x:916,y:505,t:1527628421778};\\\", \\\"{x:878,y:484,t:1527628421796};\\\", \\\"{x:828,y:459,t:1527628421811};\\\", \\\"{x:806,y:452,t:1527628421827};\\\", \\\"{x:776,y:441,t:1527628421856};\\\", \\\"{x:757,y:436,t:1527628421873};\\\", \\\"{x:734,y:427,t:1527628421891};\\\", \\\"{x:703,y:416,t:1527628421907};\\\", \\\"{x:684,y:410,t:1527628421924};\\\", \\\"{x:672,y:409,t:1527628421941};\\\", \\\"{x:663,y:408,t:1527628421957};\\\", \\\"{x:661,y:408,t:1527628421974};\\\", \\\"{x:660,y:408,t:1527628421994};\\\", \\\"{x:658,y:409,t:1527628422007};\\\", \\\"{x:655,y:410,t:1527628422024};\\\", \\\"{x:649,y:413,t:1527628422041};\\\", \\\"{x:643,y:415,t:1527628422057};\\\", \\\"{x:635,y:420,t:1527628422074};\\\", \\\"{x:629,y:424,t:1527628422091};\\\", \\\"{x:628,y:425,t:1527628422110};\\\", \\\"{x:623,y:427,t:1527628422124};\\\", \\\"{x:619,y:429,t:1527628422141};\\\", \\\"{x:615,y:431,t:1527628422157};\\\", \\\"{x:612,y:433,t:1527628422174};\\\", \\\"{x:609,y:434,t:1527628422191};\\\", \\\"{x:607,y:435,t:1527628422207};\\\", \\\"{x:606,y:436,t:1527628422224};\\\", \\\"{x:604,y:437,t:1527628422266};\\\", \\\"{x:603,y:438,t:1527628422282};\\\", \\\"{x:603,y:439,t:1527628422298};\\\", \\\"{x:603,y:442,t:1527628422308};\\\", \\\"{x:602,y:444,t:1527628422324};\\\", \\\"{x:602,y:445,t:1527628422347};\\\", \\\"{x:595,y:456,t:1527628422595};\\\", \\\"{x:588,y:467,t:1527628422608};\\\", \\\"{x:558,y:506,t:1527628422624};\\\", \\\"{x:537,y:560,t:1527628422641};\\\", \\\"{x:522,y:603,t:1527628422658};\\\", \\\"{x:511,y:647,t:1527628422674};\\\", \\\"{x:505,y:672,t:1527628422691};\\\", \\\"{x:503,y:686,t:1527628422708};\\\", \\\"{x:502,y:696,t:1527628422724};\\\", \\\"{x:502,y:704,t:1527628422742};\\\", \\\"{x:502,y:711,t:1527628422758};\\\", \\\"{x:502,y:715,t:1527628422774};\\\", \\\"{x:503,y:716,t:1527628422791};\\\", \\\"{x:504,y:718,t:1527628422808};\\\", \\\"{x:505,y:719,t:1527628422824};\\\", \\\"{x:508,y:719,t:1527628422841};\\\", \\\"{x:512,y:718,t:1527628422858};\\\", \\\"{x:521,y:708,t:1527628422875};\\\", \\\"{x:525,y:703,t:1527628422891};\\\", \\\"{x:526,y:698,t:1527628422910};\\\", \\\"{x:527,y:696,t:1527628422925};\\\", \\\"{x:528,y:693,t:1527628422941};\\\", \\\"{x:529,y:692,t:1527628422957};\\\", \\\"{x:529,y:688,t:1527628422975};\\\", \\\"{x:533,y:680,t:1527628422992};\\\", \\\"{x:536,y:676,t:1527628423008};\\\", \\\"{x:536,y:674,t:1527628423025};\\\", \\\"{x:537,y:674,t:1527628423106};\\\", \\\"{x:537,y:674,t:1527628423209};\\\", \\\"{x:539,y:674,t:1527628423548};\\\", \\\"{x:552,y:668,t:1527628423558};\\\", \\\"{x:580,y:658,t:1527628423575};\\\", \\\"{x:606,y:647,t:1527628423592};\\\", \\\"{x:641,y:631,t:1527628423609};\\\", \\\"{x:698,y:607,t:1527628423625};\\\", \\\"{x:730,y:593,t:1527628423642};\\\", \\\"{x:749,y:583,t:1527628423658};\\\", \\\"{x:756,y:577,t:1527628423675};\\\", \\\"{x:759,y:573,t:1527628423692};\\\", \\\"{x:759,y:572,t:1527628423708};\\\", \\\"{x:760,y:570,t:1527628423725};\\\", \\\"{x:761,y:570,t:1527628423742};\\\", \\\"{x:762,y:570,t:1527628424075};\\\", \\\"{x:764,y:569,t:1527628424164};\\\" ] }, { \\\"rt\\\": 14227, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 654951, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:765,y:569,t:1527628425875};\\\", \\\"{x:768,y:570,t:1527628427323};\\\", \\\"{x:771,y:576,t:1527628427331};\\\", \\\"{x:773,y:583,t:1527628427346};\\\", \\\"{x:775,y:589,t:1527628427362};\\\", \\\"{x:775,y:594,t:1527628427378};\\\", \\\"{x:777,y:598,t:1527628427395};\\\", \\\"{x:777,y:599,t:1527628427418};\\\", \\\"{x:778,y:599,t:1527628427427};\\\", \\\"{x:779,y:601,t:1527628427444};\\\", \\\"{x:781,y:604,t:1527628427461};\\\", \\\"{x:782,y:609,t:1527628427477};\\\", \\\"{x:785,y:614,t:1527628427494};\\\", \\\"{x:791,y:621,t:1527628427511};\\\", \\\"{x:800,y:631,t:1527628427527};\\\", \\\"{x:807,y:639,t:1527628427544};\\\", \\\"{x:813,y:643,t:1527628427561};\\\", \\\"{x:817,y:647,t:1527628427577};\\\", \\\"{x:818,y:651,t:1527628427595};\\\", \\\"{x:824,y:658,t:1527628427610};\\\", \\\"{x:829,y:662,t:1527628427627};\\\", \\\"{x:834,y:669,t:1527628427644};\\\", \\\"{x:842,y:674,t:1527628427662};\\\", \\\"{x:848,y:680,t:1527628427677};\\\", \\\"{x:849,y:681,t:1527628427694};\\\", \\\"{x:850,y:681,t:1527628428452};\\\", \\\"{x:859,y:678,t:1527628428462};\\\", \\\"{x:872,y:673,t:1527628428478};\\\", \\\"{x:892,y:666,t:1527628428494};\\\", \\\"{x:913,y:661,t:1527628428511};\\\", \\\"{x:952,y:654,t:1527628428529};\\\", \\\"{x:1033,y:654,t:1527628428545};\\\", \\\"{x:1121,y:647,t:1527628428562};\\\", \\\"{x:1193,y:658,t:1527628428579};\\\", \\\"{x:1288,y:673,t:1527628428595};\\\", \\\"{x:1406,y:688,t:1527628428612};\\\", \\\"{x:1435,y:694,t:1527628428628};\\\", \\\"{x:1461,y:699,t:1527628428645};\\\", \\\"{x:1476,y:703,t:1527628428662};\\\", \\\"{x:1485,y:706,t:1527628428678};\\\", \\\"{x:1489,y:707,t:1527628428694};\\\", \\\"{x:1494,y:708,t:1527628428712};\\\", \\\"{x:1491,y:705,t:1527628428964};\\\", \\\"{x:1471,y:690,t:1527628428979};\\\", \\\"{x:1444,y:672,t:1527628428996};\\\", \\\"{x:1426,y:661,t:1527628429012};\\\", \\\"{x:1416,y:655,t:1527628429028};\\\", \\\"{x:1413,y:653,t:1527628429046};\\\", \\\"{x:1412,y:652,t:1527628429061};\\\", \\\"{x:1412,y:650,t:1527628429078};\\\", \\\"{x:1412,y:647,t:1527628429095};\\\", \\\"{x:1404,y:642,t:1527628429111};\\\", \\\"{x:1394,y:636,t:1527628429128};\\\", \\\"{x:1391,y:635,t:1527628429145};\\\", \\\"{x:1389,y:634,t:1527628429161};\\\", \\\"{x:1387,y:634,t:1527628429186};\\\", \\\"{x:1386,y:634,t:1527628429194};\\\", \\\"{x:1383,y:634,t:1527628429211};\\\", \\\"{x:1380,y:635,t:1527628429228};\\\", \\\"{x:1377,y:636,t:1527628429245};\\\", \\\"{x:1376,y:637,t:1527628429261};\\\", \\\"{x:1374,y:638,t:1527628429279};\\\", \\\"{x:1373,y:639,t:1527628429299};\\\", \\\"{x:1372,y:639,t:1527628429348};\\\", \\\"{x:1371,y:640,t:1527628429361};\\\", \\\"{x:1370,y:641,t:1527628429396};\\\", \\\"{x:1369,y:642,t:1527628429475};\\\", \\\"{x:1368,y:642,t:1527628429491};\\\", \\\"{x:1367,y:643,t:1527628429499};\\\", \\\"{x:1367,y:644,t:1527628429512};\\\", \\\"{x:1364,y:645,t:1527628429740};\\\", \\\"{x:1363,y:646,t:1527628429764};\\\", \\\"{x:1363,y:647,t:1527628433932};\\\", \\\"{x:1361,y:647,t:1527628435395};\\\", \\\"{x:1354,y:647,t:1527628435403};\\\", \\\"{x:1343,y:647,t:1527628435418};\\\", \\\"{x:1304,y:647,t:1527628435431};\\\", \\\"{x:1254,y:640,t:1527628435447};\\\", \\\"{x:1182,y:622,t:1527628435465};\\\", \\\"{x:1108,y:595,t:1527628435481};\\\", \\\"{x:1018,y:559,t:1527628435497};\\\", \\\"{x:909,y:513,t:1527628435515};\\\", \\\"{x:847,y:480,t:1527628435532};\\\", \\\"{x:809,y:458,t:1527628435547};\\\", \\\"{x:787,y:444,t:1527628435569};\\\", \\\"{x:769,y:431,t:1527628435584};\\\", \\\"{x:753,y:421,t:1527628435601};\\\", \\\"{x:728,y:407,t:1527628435618};\\\", \\\"{x:709,y:396,t:1527628435634};\\\", \\\"{x:690,y:385,t:1527628435652};\\\", \\\"{x:673,y:381,t:1527628435669};\\\", \\\"{x:658,y:377,t:1527628435685};\\\", \\\"{x:648,y:377,t:1527628435701};\\\", \\\"{x:644,y:375,t:1527628435719};\\\", \\\"{x:639,y:375,t:1527628435735};\\\", \\\"{x:636,y:375,t:1527628435752};\\\", \\\"{x:633,y:377,t:1527628435768};\\\", \\\"{x:633,y:380,t:1527628435786};\\\", \\\"{x:632,y:385,t:1527628435801};\\\", \\\"{x:630,y:389,t:1527628435819};\\\", \\\"{x:630,y:393,t:1527628435835};\\\", \\\"{x:629,y:396,t:1527628435852};\\\", \\\"{x:628,y:397,t:1527628435979};\\\", \\\"{x:628,y:398,t:1527628436019};\\\", \\\"{x:628,y:399,t:1527628436059};\\\", \\\"{x:627,y:399,t:1527628436140};\\\", \\\"{x:627,y:400,t:1527628436747};\\\", \\\"{x:635,y:403,t:1527628436755};\\\", \\\"{x:669,y:413,t:1527628436771};\\\", \\\"{x:729,y:425,t:1527628436789};\\\", \\\"{x:791,y:437,t:1527628436806};\\\", \\\"{x:826,y:438,t:1527628436820};\\\", \\\"{x:840,y:438,t:1527628436835};\\\", \\\"{x:845,y:438,t:1527628436852};\\\", \\\"{x:845,y:435,t:1527628436882};\\\", \\\"{x:841,y:433,t:1527628436890};\\\", \\\"{x:835,y:430,t:1527628436902};\\\", \\\"{x:819,y:425,t:1527628436919};\\\", \\\"{x:802,y:421,t:1527628436936};\\\", \\\"{x:765,y:419,t:1527628436952};\\\", \\\"{x:738,y:415,t:1527628436969};\\\", \\\"{x:707,y:411,t:1527628436985};\\\", \\\"{x:680,y:409,t:1527628437002};\\\", \\\"{x:673,y:409,t:1527628437020};\\\", \\\"{x:670,y:409,t:1527628437035};\\\", \\\"{x:665,y:409,t:1527628437052};\\\", \\\"{x:664,y:410,t:1527628437070};\\\", \\\"{x:663,y:413,t:1527628437085};\\\", \\\"{x:660,y:416,t:1527628437102};\\\", \\\"{x:657,y:420,t:1527628437120};\\\", \\\"{x:650,y:428,t:1527628437136};\\\", \\\"{x:643,y:432,t:1527628437152};\\\", \\\"{x:636,y:434,t:1527628437170};\\\", \\\"{x:627,y:437,t:1527628437187};\\\", \\\"{x:620,y:439,t:1527628437202};\\\", \\\"{x:615,y:441,t:1527628437220};\\\", \\\"{x:612,y:442,t:1527628437236};\\\", \\\"{x:609,y:445,t:1527628437252};\\\", \\\"{x:608,y:446,t:1527628437274};\\\", \\\"{x:608,y:447,t:1527628437339};\\\", \\\"{x:607,y:448,t:1527628437352};\\\", \\\"{x:607,y:451,t:1527628437369};\\\", \\\"{x:607,y:454,t:1527628437634};\\\", \\\"{x:607,y:458,t:1527628437642};\\\", \\\"{x:607,y:469,t:1527628437654};\\\", \\\"{x:607,y:490,t:1527628437670};\\\", \\\"{x:604,y:519,t:1527628437687};\\\", \\\"{x:598,y:550,t:1527628437704};\\\", \\\"{x:592,y:575,t:1527628437719};\\\", \\\"{x:585,y:600,t:1527628437737};\\\", \\\"{x:576,y:623,t:1527628437753};\\\", \\\"{x:571,y:636,t:1527628437769};\\\", \\\"{x:568,y:652,t:1527628437786};\\\", \\\"{x:566,y:660,t:1527628437803};\\\", \\\"{x:565,y:663,t:1527628437820};\\\", \\\"{x:565,y:664,t:1527628437837};\\\", \\\"{x:564,y:666,t:1527628437916};\\\", \\\"{x:563,y:667,t:1527628437931};\\\", \\\"{x:562,y:668,t:1527628437939};\\\", \\\"{x:561,y:669,t:1527628437956};\\\", \\\"{x:559,y:672,t:1527628437969};\\\", \\\"{x:548,y:682,t:1527628437986};\\\", \\\"{x:542,y:685,t:1527628438003};\\\", \\\"{x:540,y:686,t:1527628438020};\\\", \\\"{x:536,y:688,t:1527628438036};\\\", \\\"{x:535,y:688,t:1527628438065};\\\" ] }, { \\\"rt\\\": 5379, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 661568, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:688,t:1527628441540};\\\", \\\"{x:534,y:689,t:1527628441580};\\\", \\\"{x:534,y:691,t:1527628441589};\\\", \\\"{x:535,y:695,t:1527628441606};\\\", \\\"{x:537,y:696,t:1527628441622};\\\", \\\"{x:539,y:697,t:1527628441639};\\\", \\\"{x:539,y:698,t:1527628441682};\\\", \\\"{x:541,y:699,t:1527628441689};\\\", \\\"{x:543,y:701,t:1527628441706};\\\", \\\"{x:545,y:704,t:1527628441723};\\\", \\\"{x:549,y:706,t:1527628441740};\\\", \\\"{x:561,y:713,t:1527628441757};\\\", \\\"{x:582,y:719,t:1527628441773};\\\", \\\"{x:606,y:728,t:1527628441789};\\\", \\\"{x:622,y:736,t:1527628441806};\\\", \\\"{x:635,y:750,t:1527628441822};\\\", \\\"{x:639,y:757,t:1527628441840};\\\", \\\"{x:668,y:772,t:1527628441856};\\\", \\\"{x:683,y:781,t:1527628441872};\\\", \\\"{x:700,y:793,t:1527628441890};\\\", \\\"{x:754,y:814,t:1527628441906};\\\", \\\"{x:755,y:816,t:1527628441924};\\\", \\\"{x:768,y:820,t:1527628441940};\\\", \\\"{x:799,y:827,t:1527628441956};\\\", \\\"{x:802,y:827,t:1527628441978};\\\", \\\"{x:802,y:828,t:1527628441994};\\\", \\\"{x:803,y:828,t:1527628443467};\\\", \\\"{x:807,y:828,t:1527628443475};\\\", \\\"{x:821,y:826,t:1527628443492};\\\", \\\"{x:838,y:826,t:1527628443519};\\\", \\\"{x:852,y:825,t:1527628443535};\\\", \\\"{x:864,y:818,t:1527628443552};\\\", \\\"{x:875,y:805,t:1527628443569};\\\", \\\"{x:879,y:796,t:1527628443585};\\\", \\\"{x:879,y:780,t:1527628443602};\\\", \\\"{x:879,y:758,t:1527628443619};\\\", \\\"{x:873,y:730,t:1527628443635};\\\", \\\"{x:865,y:703,t:1527628443652};\\\", \\\"{x:850,y:667,t:1527628443669};\\\", \\\"{x:834,y:638,t:1527628443685};\\\", \\\"{x:820,y:619,t:1527628443703};\\\", \\\"{x:807,y:600,t:1527628443719};\\\", \\\"{x:794,y:583,t:1527628443736};\\\", \\\"{x:778,y:567,t:1527628443754};\\\", \\\"{x:768,y:559,t:1527628443768};\\\", \\\"{x:763,y:555,t:1527628443785};\\\", \\\"{x:759,y:552,t:1527628443802};\\\", \\\"{x:756,y:549,t:1527628443817};\\\", \\\"{x:752,y:546,t:1527628443835};\\\", \\\"{x:740,y:541,t:1527628443851};\\\", \\\"{x:729,y:536,t:1527628443868};\\\", \\\"{x:716,y:534,t:1527628443885};\\\", \\\"{x:713,y:533,t:1527628443902};\\\", \\\"{x:709,y:532,t:1527628443917};\\\", \\\"{x:701,y:529,t:1527628443934};\\\", \\\"{x:688,y:525,t:1527628443951};\\\", \\\"{x:675,y:521,t:1527628443968};\\\", \\\"{x:662,y:516,t:1527628443984};\\\", \\\"{x:641,y:510,t:1527628444002};\\\", \\\"{x:613,y:503,t:1527628444018};\\\", \\\"{x:584,y:498,t:1527628444035};\\\", \\\"{x:562,y:494,t:1527628444051};\\\", \\\"{x:529,y:488,t:1527628444068};\\\", \\\"{x:509,y:487,t:1527628444084};\\\", \\\"{x:497,y:487,t:1527628444102};\\\", \\\"{x:492,y:487,t:1527628444119};\\\", \\\"{x:490,y:489,t:1527628444135};\\\", \\\"{x:488,y:491,t:1527628444152};\\\", \\\"{x:487,y:492,t:1527628444168};\\\", \\\"{x:484,y:494,t:1527628444184};\\\", \\\"{x:483,y:494,t:1527628444253};\\\", \\\"{x:481,y:495,t:1527628444268};\\\", \\\"{x:478,y:495,t:1527628444285};\\\", \\\"{x:476,y:496,t:1527628444302};\\\", \\\"{x:472,y:496,t:1527628444319};\\\", \\\"{x:465,y:496,t:1527628444335};\\\", \\\"{x:452,y:494,t:1527628444351};\\\", \\\"{x:437,y:492,t:1527628444369};\\\", \\\"{x:428,y:491,t:1527628444384};\\\", \\\"{x:422,y:491,t:1527628444402};\\\", \\\"{x:418,y:491,t:1527628444419};\\\", \\\"{x:412,y:491,t:1527628444434};\\\", \\\"{x:409,y:491,t:1527628444451};\\\", \\\"{x:401,y:491,t:1527628444468};\\\", \\\"{x:397,y:491,t:1527628444484};\\\", \\\"{x:394,y:489,t:1527628444501};\\\", \\\"{x:389,y:489,t:1527628444519};\\\", \\\"{x:383,y:489,t:1527628444535};\\\", \\\"{x:379,y:489,t:1527628444552};\\\", \\\"{x:378,y:488,t:1527628444568};\\\", \\\"{x:377,y:488,t:1527628444585};\\\", \\\"{x:376,y:487,t:1527628444637};\\\", \\\"{x:376,y:488,t:1527628444932};\\\", \\\"{x:378,y:497,t:1527628444940};\\\", \\\"{x:381,y:510,t:1527628444953};\\\", \\\"{x:393,y:535,t:1527628444969};\\\", \\\"{x:405,y:566,t:1527628444986};\\\", \\\"{x:419,y:596,t:1527628445002};\\\", \\\"{x:431,y:613,t:1527628445019};\\\", \\\"{x:439,y:629,t:1527628445036};\\\", \\\"{x:440,y:633,t:1527628445052};\\\", \\\"{x:440,y:634,t:1527628445069};\\\", \\\"{x:443,y:638,t:1527628445086};\\\", \\\"{x:446,y:641,t:1527628445101};\\\", \\\"{x:449,y:644,t:1527628445119};\\\", \\\"{x:457,y:650,t:1527628445136};\\\", \\\"{x:469,y:656,t:1527628445153};\\\", \\\"{x:478,y:662,t:1527628445168};\\\", \\\"{x:490,y:665,t:1527628445186};\\\", \\\"{x:506,y:669,t:1527628445203};\\\", \\\"{x:527,y:674,t:1527628445219};\\\", \\\"{x:548,y:678,t:1527628445236};\\\", \\\"{x:553,y:680,t:1527628445251};\\\", \\\"{x:554,y:681,t:1527628445284};\\\", \\\"{x:555,y:681,t:1527628445356};\\\", \\\"{x:555,y:682,t:1527628445372};\\\", \\\"{x:556,y:683,t:1527628445396};\\\", \\\"{x:557,y:684,t:1527628445437};\\\", \\\"{x:557,y:685,t:1527628446397};\\\", \\\"{x:558,y:686,t:1527628446493};\\\", \\\"{x:559,y:686,t:1527628446524};\\\", \\\"{x:560,y:687,t:1527628446613};\\\" ] }, { \\\"rt\\\": 14126, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 676929, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:562,y:687,t:1527628449275};\\\", \\\"{x:563,y:687,t:1527628451301};\\\", \\\"{x:571,y:687,t:1527628451310};\\\", \\\"{x:586,y:693,t:1527628451321};\\\", \\\"{x:634,y:717,t:1527628451338};\\\", \\\"{x:709,y:739,t:1527628451353};\\\", \\\"{x:841,y:787,t:1527628451373};\\\", \\\"{x:920,y:811,t:1527628451390};\\\", \\\"{x:953,y:828,t:1527628451406};\\\", \\\"{x:978,y:835,t:1527628451424};\\\", \\\"{x:993,y:840,t:1527628451440};\\\", \\\"{x:1009,y:846,t:1527628451457};\\\", \\\"{x:1022,y:852,t:1527628451474};\\\", \\\"{x:1042,y:863,t:1527628451491};\\\", \\\"{x:1064,y:873,t:1527628451506};\\\", \\\"{x:1099,y:886,t:1527628451524};\\\", \\\"{x:1122,y:897,t:1527628451541};\\\", \\\"{x:1146,y:907,t:1527628451558};\\\", \\\"{x:1169,y:918,t:1527628451575};\\\", \\\"{x:1190,y:925,t:1527628451591};\\\", \\\"{x:1212,y:931,t:1527628451608};\\\", \\\"{x:1226,y:935,t:1527628451624};\\\", \\\"{x:1233,y:935,t:1527628451641};\\\", \\\"{x:1236,y:935,t:1527628451657};\\\", \\\"{x:1238,y:935,t:1527628451700};\\\", \\\"{x:1239,y:934,t:1527628451708};\\\", \\\"{x:1240,y:931,t:1527628451724};\\\", \\\"{x:1242,y:927,t:1527628451741};\\\", \\\"{x:1244,y:924,t:1527628451757};\\\", \\\"{x:1245,y:920,t:1527628451775};\\\", \\\"{x:1247,y:914,t:1527628451792};\\\", \\\"{x:1248,y:914,t:1527628451807};\\\", \\\"{x:1249,y:913,t:1527628452445};\\\", \\\"{x:1250,y:912,t:1527628452517};\\\", \\\"{x:1251,y:911,t:1527628452525};\\\", \\\"{x:1253,y:908,t:1527628452542};\\\", \\\"{x:1254,y:908,t:1527628452572};\\\", \\\"{x:1255,y:908,t:1527628452637};\\\", \\\"{x:1256,y:907,t:1527628452653};\\\", \\\"{x:1257,y:905,t:1527628452949};\\\", \\\"{x:1257,y:904,t:1527628452973};\\\", \\\"{x:1258,y:903,t:1527628452980};\\\", \\\"{x:1259,y:903,t:1527628452993};\\\", \\\"{x:1260,y:902,t:1527628453013};\\\", \\\"{x:1262,y:902,t:1527628453026};\\\", \\\"{x:1264,y:901,t:1527628453042};\\\", \\\"{x:1266,y:900,t:1527628453059};\\\", \\\"{x:1267,y:900,t:1527628453075};\\\", \\\"{x:1269,y:898,t:1527628453092};\\\", \\\"{x:1271,y:898,t:1527628453109};\\\", \\\"{x:1272,y:897,t:1527628453126};\\\", \\\"{x:1273,y:896,t:1527628453245};\\\", \\\"{x:1273,y:894,t:1527628453445};\\\", \\\"{x:1273,y:892,t:1527628453460};\\\", \\\"{x:1276,y:884,t:1527628453476};\\\", \\\"{x:1280,y:860,t:1527628453492};\\\", \\\"{x:1283,y:842,t:1527628453509};\\\", \\\"{x:1288,y:822,t:1527628453525};\\\", \\\"{x:1294,y:811,t:1527628453543};\\\", \\\"{x:1297,y:804,t:1527628453560};\\\", \\\"{x:1299,y:801,t:1527628453575};\\\", \\\"{x:1299,y:800,t:1527628453593};\\\", \\\"{x:1300,y:799,t:1527628453609};\\\", \\\"{x:1302,y:798,t:1527628454069};\\\", \\\"{x:1304,y:798,t:1527628454084};\\\", \\\"{x:1308,y:795,t:1527628454092};\\\", \\\"{x:1316,y:787,t:1527628454110};\\\", \\\"{x:1323,y:779,t:1527628454126};\\\", \\\"{x:1327,y:772,t:1527628454143};\\\", \\\"{x:1330,y:765,t:1527628454160};\\\", \\\"{x:1332,y:762,t:1527628454177};\\\", \\\"{x:1334,y:757,t:1527628454193};\\\", \\\"{x:1334,y:756,t:1527628454210};\\\", \\\"{x:1334,y:755,t:1527628454226};\\\", \\\"{x:1334,y:754,t:1527628454405};\\\", \\\"{x:1334,y:751,t:1527628454412};\\\", \\\"{x:1334,y:747,t:1527628454426};\\\", \\\"{x:1334,y:742,t:1527628454443};\\\", \\\"{x:1334,y:738,t:1527628454460};\\\", \\\"{x:1334,y:733,t:1527628454476};\\\", \\\"{x:1334,y:732,t:1527628454493};\\\", \\\"{x:1336,y:731,t:1527628454510};\\\", \\\"{x:1337,y:731,t:1527628454527};\\\", \\\"{x:1339,y:729,t:1527628454543};\\\", \\\"{x:1341,y:728,t:1527628454560};\\\", \\\"{x:1342,y:727,t:1527628454581};\\\", \\\"{x:1343,y:727,t:1527628454597};\\\", \\\"{x:1344,y:726,t:1527628454620};\\\", \\\"{x:1345,y:725,t:1527628454645};\\\", \\\"{x:1346,y:724,t:1527628454660};\\\", \\\"{x:1347,y:722,t:1527628454677};\\\", \\\"{x:1348,y:720,t:1527628454694};\\\", \\\"{x:1348,y:717,t:1527628454710};\\\", \\\"{x:1348,y:716,t:1527628454727};\\\", \\\"{x:1348,y:714,t:1527628454751};\\\", \\\"{x:1349,y:713,t:1527628455292};\\\", \\\"{x:1354,y:709,t:1527628455311};\\\", \\\"{x:1356,y:703,t:1527628455328};\\\", \\\"{x:1359,y:698,t:1527628455344};\\\", \\\"{x:1362,y:693,t:1527628455360};\\\", \\\"{x:1366,y:685,t:1527628455377};\\\", \\\"{x:1367,y:685,t:1527628455394};\\\", \\\"{x:1367,y:684,t:1527628455685};\\\", \\\"{x:1354,y:679,t:1527628455741};\\\", \\\"{x:1326,y:672,t:1527628455748};\\\", \\\"{x:1298,y:664,t:1527628455760};\\\", \\\"{x:1228,y:650,t:1527628455778};\\\", \\\"{x:1184,y:647,t:1527628455795};\\\", \\\"{x:1157,y:647,t:1527628455810};\\\", \\\"{x:1141,y:644,t:1527628455827};\\\", \\\"{x:1111,y:644,t:1527628455845};\\\", \\\"{x:1084,y:644,t:1527628455860};\\\", \\\"{x:1045,y:639,t:1527628455878};\\\", \\\"{x:999,y:630,t:1527628455895};\\\", \\\"{x:936,y:617,t:1527628455910};\\\", \\\"{x:875,y:608,t:1527628455927};\\\", \\\"{x:807,y:594,t:1527628455944};\\\", \\\"{x:770,y:587,t:1527628455961};\\\", \\\"{x:746,y:583,t:1527628455977};\\\", \\\"{x:725,y:579,t:1527628455995};\\\", \\\"{x:713,y:576,t:1527628456012};\\\", \\\"{x:709,y:576,t:1527628456027};\\\", \\\"{x:706,y:576,t:1527628456043};\\\", \\\"{x:703,y:576,t:1527628456245};\\\", \\\"{x:688,y:576,t:1527628456261};\\\", \\\"{x:674,y:574,t:1527628456278};\\\", \\\"{x:660,y:571,t:1527628456294};\\\", \\\"{x:647,y:568,t:1527628456311};\\\", \\\"{x:644,y:568,t:1527628456328};\\\", \\\"{x:641,y:568,t:1527628456346};\\\", \\\"{x:638,y:568,t:1527628456361};\\\", \\\"{x:637,y:568,t:1527628456378};\\\", \\\"{x:634,y:568,t:1527628456394};\\\", \\\"{x:631,y:569,t:1527628456411};\\\", \\\"{x:627,y:570,t:1527628456428};\\\", \\\"{x:624,y:572,t:1527628456444};\\\", \\\"{x:620,y:573,t:1527628456461};\\\", \\\"{x:616,y:576,t:1527628456478};\\\", \\\"{x:614,y:577,t:1527628456494};\\\", \\\"{x:613,y:578,t:1527628456511};\\\", \\\"{x:612,y:578,t:1527628456528};\\\", \\\"{x:611,y:579,t:1527628456748};\\\", \\\"{x:610,y:580,t:1527628456803};\\\", \\\"{x:608,y:579,t:1527628456981};\\\", \\\"{x:604,y:577,t:1527628456996};\\\", \\\"{x:603,y:577,t:1527628457011};\\\", \\\"{x:603,y:575,t:1527628458044};\\\", \\\"{x:604,y:575,t:1527628458099};\\\", \\\"{x:604,y:574,t:1527628458112};\\\", \\\"{x:606,y:569,t:1527628458128};\\\", \\\"{x:610,y:562,t:1527628458146};\\\", \\\"{x:613,y:555,t:1527628458161};\\\", \\\"{x:617,y:545,t:1527628458179};\\\", \\\"{x:621,y:531,t:1527628458196};\\\", \\\"{x:625,y:519,t:1527628458213};\\\", \\\"{x:627,y:510,t:1527628458229};\\\", \\\"{x:631,y:502,t:1527628458247};\\\", \\\"{x:634,y:494,t:1527628458263};\\\", \\\"{x:636,y:486,t:1527628458279};\\\", \\\"{x:636,y:481,t:1527628458296};\\\", \\\"{x:638,y:476,t:1527628458312};\\\", \\\"{x:639,y:472,t:1527628458330};\\\", \\\"{x:639,y:469,t:1527628458346};\\\", \\\"{x:638,y:465,t:1527628458363};\\\", \\\"{x:636,y:463,t:1527628458379};\\\", \\\"{x:631,y:461,t:1527628458396};\\\", \\\"{x:625,y:459,t:1527628458414};\\\", \\\"{x:619,y:457,t:1527628458430};\\\", \\\"{x:607,y:456,t:1527628458446};\\\", \\\"{x:592,y:452,t:1527628458463};\\\", \\\"{x:571,y:450,t:1527628458479};\\\", \\\"{x:553,y:449,t:1527628458496};\\\", \\\"{x:543,y:446,t:1527628458513};\\\", \\\"{x:540,y:446,t:1527628458529};\\\", \\\"{x:535,y:446,t:1527628458546};\\\", \\\"{x:532,y:446,t:1527628458563};\\\", \\\"{x:529,y:445,t:1527628458579};\\\", \\\"{x:526,y:444,t:1527628458596};\\\", \\\"{x:525,y:444,t:1527628458685};\\\", \\\"{x:523,y:444,t:1527628458700};\\\", \\\"{x:519,y:444,t:1527628458713};\\\", \\\"{x:509,y:444,t:1527628458729};\\\", \\\"{x:495,y:444,t:1527628458749};\\\", \\\"{x:473,y:444,t:1527628458764};\\\", \\\"{x:441,y:444,t:1527628458780};\\\", \\\"{x:424,y:444,t:1527628458796};\\\", \\\"{x:408,y:444,t:1527628458814};\\\", \\\"{x:395,y:445,t:1527628458830};\\\", \\\"{x:386,y:445,t:1527628458846};\\\", \\\"{x:377,y:445,t:1527628458863};\\\", \\\"{x:364,y:445,t:1527628458881};\\\", \\\"{x:338,y:445,t:1527628458896};\\\", \\\"{x:307,y:445,t:1527628458913};\\\", \\\"{x:277,y:445,t:1527628458930};\\\", \\\"{x:245,y:445,t:1527628458947};\\\", \\\"{x:219,y:447,t:1527628458963};\\\", \\\"{x:193,y:447,t:1527628458979};\\\", \\\"{x:181,y:449,t:1527628458996};\\\", \\\"{x:170,y:453,t:1527628459014};\\\", \\\"{x:166,y:455,t:1527628459029};\\\", \\\"{x:164,y:455,t:1527628459046};\\\", \\\"{x:164,y:456,t:1527628459067};\\\", \\\"{x:163,y:459,t:1527628459083};\\\", \\\"{x:163,y:461,t:1527628459096};\\\", \\\"{x:163,y:466,t:1527628459113};\\\", \\\"{x:163,y:474,t:1527628459131};\\\", \\\"{x:165,y:485,t:1527628459146};\\\", \\\"{x:168,y:493,t:1527628459163};\\\", \\\"{x:173,y:505,t:1527628459180};\\\", \\\"{x:177,y:513,t:1527628459197};\\\", \\\"{x:183,y:522,t:1527628459214};\\\", \\\"{x:183,y:523,t:1527628459230};\\\", \\\"{x:185,y:524,t:1527628459246};\\\", \\\"{x:185,y:525,t:1527628459268};\\\", \\\"{x:185,y:527,t:1527628459316};\\\", \\\"{x:185,y:530,t:1527628459332};\\\", \\\"{x:185,y:531,t:1527628459346};\\\", \\\"{x:185,y:534,t:1527628459364};\\\", \\\"{x:185,y:535,t:1527628459388};\\\", \\\"{x:188,y:538,t:1527628459429};\\\", \\\"{x:204,y:543,t:1527628459446};\\\", \\\"{x:243,y:549,t:1527628459463};\\\", \\\"{x:323,y:560,t:1527628459480};\\\", \\\"{x:411,y:577,t:1527628459497};\\\", \\\"{x:510,y:590,t:1527628459514};\\\", \\\"{x:596,y:600,t:1527628459530};\\\", \\\"{x:710,y:611,t:1527628459547};\\\", \\\"{x:780,y:614,t:1527628459563};\\\", \\\"{x:827,y:612,t:1527628459580};\\\", \\\"{x:869,y:612,t:1527628459597};\\\", \\\"{x:892,y:608,t:1527628459614};\\\", \\\"{x:914,y:604,t:1527628459630};\\\", \\\"{x:933,y:600,t:1527628459647};\\\", \\\"{x:949,y:597,t:1527628459664};\\\", \\\"{x:960,y:592,t:1527628459680};\\\", \\\"{x:962,y:587,t:1527628459697};\\\", \\\"{x:965,y:582,t:1527628459713};\\\", \\\"{x:965,y:572,t:1527628459731};\\\", \\\"{x:962,y:552,t:1527628459748};\\\", \\\"{x:959,y:543,t:1527628459765};\\\", \\\"{x:955,y:536,t:1527628459781};\\\", \\\"{x:945,y:529,t:1527628459798};\\\", \\\"{x:931,y:522,t:1527628459814};\\\", \\\"{x:913,y:513,t:1527628459830};\\\", \\\"{x:894,y:505,t:1527628459848};\\\", \\\"{x:877,y:497,t:1527628459865};\\\", \\\"{x:864,y:494,t:1527628459880};\\\", \\\"{x:851,y:492,t:1527628459897};\\\", \\\"{x:845,y:490,t:1527628459914};\\\", \\\"{x:844,y:488,t:1527628459931};\\\", \\\"{x:843,y:488,t:1527628459947};\\\", \\\"{x:840,y:488,t:1527628459980};\\\", \\\"{x:838,y:488,t:1527628459996};\\\", \\\"{x:836,y:488,t:1527628460014};\\\", \\\"{x:835,y:488,t:1527628460276};\\\", \\\"{x:830,y:492,t:1527628460283};\\\", \\\"{x:822,y:506,t:1527628460298};\\\", \\\"{x:801,y:539,t:1527628460314};\\\", \\\"{x:763,y:592,t:1527628460332};\\\", \\\"{x:749,y:608,t:1527628460347};\\\", \\\"{x:717,y:632,t:1527628460364};\\\", \\\"{x:701,y:640,t:1527628460381};\\\", \\\"{x:687,y:646,t:1527628460397};\\\", \\\"{x:674,y:653,t:1527628460414};\\\", \\\"{x:662,y:659,t:1527628460431};\\\", \\\"{x:649,y:664,t:1527628460447};\\\", \\\"{x:643,y:666,t:1527628460464};\\\", \\\"{x:638,y:667,t:1527628460481};\\\", \\\"{x:636,y:668,t:1527628460497};\\\", \\\"{x:635,y:668,t:1527628460514};\\\", \\\"{x:634,y:668,t:1527628460555};\\\", \\\"{x:632,y:668,t:1527628460564};\\\", \\\"{x:631,y:668,t:1527628460581};\\\", \\\"{x:620,y:671,t:1527628460599};\\\", \\\"{x:605,y:672,t:1527628460614};\\\", \\\"{x:589,y:673,t:1527628460632};\\\", \\\"{x:566,y:673,t:1527628460648};\\\", \\\"{x:550,y:673,t:1527628460665};\\\", \\\"{x:542,y:677,t:1527628460681};\\\", \\\"{x:535,y:679,t:1527628460697};\\\", \\\"{x:529,y:682,t:1527628460715};\\\", \\\"{x:526,y:684,t:1527628460730};\\\", \\\"{x:523,y:686,t:1527628460747};\\\", \\\"{x:520,y:688,t:1527628460764};\\\", \\\"{x:520,y:689,t:1527628460780};\\\" ] }, { \\\"rt\\\": 25057, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 703216, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -02 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:689,t:1527628462252};\\\", \\\"{x:523,y:688,t:1527628462315};\\\", \\\"{x:525,y:688,t:1527628462460};\\\", \\\"{x:527,y:688,t:1527628465461};\\\", \\\"{x:538,y:691,t:1527628465474};\\\", \\\"{x:608,y:723,t:1527628465492};\\\", \\\"{x:765,y:778,t:1527628465507};\\\", \\\"{x:826,y:808,t:1527628465524};\\\", \\\"{x:839,y:813,t:1527628465535};\\\", \\\"{x:849,y:824,t:1527628465551};\\\", \\\"{x:850,y:824,t:1527628465568};\\\", \\\"{x:851,y:824,t:1527628465585};\\\", \\\"{x:852,y:824,t:1527628465652};\\\", \\\"{x:853,y:823,t:1527628465669};\\\", \\\"{x:855,y:823,t:1527628465686};\\\", \\\"{x:871,y:822,t:1527628465702};\\\", \\\"{x:891,y:822,t:1527628465718};\\\", \\\"{x:903,y:820,t:1527628465736};\\\", \\\"{x:918,y:820,t:1527628465752};\\\", \\\"{x:925,y:820,t:1527628465768};\\\", \\\"{x:932,y:820,t:1527628465785};\\\", \\\"{x:936,y:820,t:1527628465802};\\\", \\\"{x:939,y:820,t:1527628465818};\\\", \\\"{x:946,y:822,t:1527628465835};\\\", \\\"{x:951,y:823,t:1527628465852};\\\", \\\"{x:956,y:825,t:1527628465869};\\\", \\\"{x:968,y:829,t:1527628465886};\\\", \\\"{x:980,y:838,t:1527628465902};\\\", \\\"{x:1003,y:844,t:1527628465919};\\\", \\\"{x:1017,y:846,t:1527628465936};\\\", \\\"{x:1030,y:849,t:1527628465953};\\\", \\\"{x:1036,y:850,t:1527628465969};\\\", \\\"{x:1043,y:851,t:1527628465986};\\\", \\\"{x:1055,y:854,t:1527628466003};\\\", \\\"{x:1077,y:860,t:1527628466019};\\\", \\\"{x:1127,y:869,t:1527628466037};\\\", \\\"{x:1174,y:875,t:1527628466053};\\\", \\\"{x:1249,y:885,t:1527628466069};\\\", \\\"{x:1306,y:897,t:1527628466086};\\\", \\\"{x:1392,y:908,t:1527628466103};\\\", \\\"{x:1448,y:923,t:1527628466119};\\\", \\\"{x:1450,y:923,t:1527628466136};\\\", \\\"{x:1452,y:923,t:1527628467101};\\\", \\\"{x:1453,y:923,t:1527628467116};\\\", \\\"{x:1454,y:923,t:1527628467149};\\\", \\\"{x:1454,y:921,t:1527628467181};\\\", \\\"{x:1454,y:920,t:1527628467196};\\\", \\\"{x:1455,y:920,t:1527628467205};\\\", \\\"{x:1455,y:918,t:1527628467357};\\\", \\\"{x:1455,y:916,t:1527628467370};\\\", \\\"{x:1456,y:911,t:1527628467388};\\\", \\\"{x:1456,y:905,t:1527628467405};\\\", \\\"{x:1456,y:898,t:1527628467420};\\\", \\\"{x:1456,y:893,t:1527628467437};\\\", \\\"{x:1454,y:890,t:1527628467454};\\\", \\\"{x:1454,y:889,t:1527628467477};\\\", \\\"{x:1454,y:887,t:1527628467492};\\\", \\\"{x:1454,y:884,t:1527628467504};\\\", \\\"{x:1451,y:877,t:1527628467520};\\\", \\\"{x:1445,y:863,t:1527628467537};\\\", \\\"{x:1437,y:834,t:1527628467554};\\\", \\\"{x:1425,y:802,t:1527628467570};\\\", \\\"{x:1419,y:776,t:1527628467587};\\\", \\\"{x:1418,y:741,t:1527628467604};\\\", \\\"{x:1428,y:726,t:1527628467621};\\\", \\\"{x:1439,y:708,t:1527628467637};\\\", \\\"{x:1442,y:700,t:1527628467654};\\\", \\\"{x:1443,y:692,t:1527628467671};\\\", \\\"{x:1440,y:676,t:1527628467687};\\\", \\\"{x:1435,y:670,t:1527628467704};\\\", \\\"{x:1435,y:669,t:1527628470829};\\\", \\\"{x:1437,y:667,t:1527628471133};\\\", \\\"{x:1438,y:667,t:1527628471141};\\\", \\\"{x:1442,y:665,t:1527628471156};\\\", \\\"{x:1452,y:662,t:1527628471175};\\\", \\\"{x:1475,y:657,t:1527628471190};\\\", \\\"{x:1491,y:656,t:1527628471207};\\\", \\\"{x:1499,y:655,t:1527628471223};\\\", \\\"{x:1510,y:655,t:1527628471241};\\\", \\\"{x:1520,y:653,t:1527628471256};\\\", \\\"{x:1526,y:653,t:1527628471273};\\\", \\\"{x:1529,y:653,t:1527628471290};\\\", \\\"{x:1535,y:652,t:1527628471306};\\\", \\\"{x:1538,y:651,t:1527628471323};\\\", \\\"{x:1546,y:649,t:1527628471340};\\\", \\\"{x:1552,y:648,t:1527628471356};\\\", \\\"{x:1561,y:647,t:1527628471375};\\\", \\\"{x:1572,y:647,t:1527628471390};\\\", \\\"{x:1583,y:647,t:1527628471406};\\\", \\\"{x:1590,y:647,t:1527628471423};\\\", \\\"{x:1598,y:647,t:1527628471440};\\\", \\\"{x:1602,y:647,t:1527628471456};\\\", \\\"{x:1605,y:647,t:1527628471473};\\\", \\\"{x:1606,y:647,t:1527628471549};\\\", \\\"{x:1606,y:648,t:1527628471733};\\\", \\\"{x:1607,y:648,t:1527628471740};\\\", \\\"{x:1608,y:648,t:1527628471757};\\\", \\\"{x:1609,y:649,t:1527628471788};\\\", \\\"{x:1609,y:650,t:1527628473685};\\\", \\\"{x:1608,y:652,t:1527628473692};\\\", \\\"{x:1603,y:654,t:1527628473708};\\\", \\\"{x:1596,y:657,t:1527628473725};\\\", \\\"{x:1593,y:662,t:1527628473741};\\\", \\\"{x:1590,y:668,t:1527628473758};\\\", \\\"{x:1587,y:671,t:1527628473775};\\\", \\\"{x:1587,y:678,t:1527628473792};\\\", \\\"{x:1584,y:683,t:1527628473808};\\\", \\\"{x:1584,y:687,t:1527628473825};\\\", \\\"{x:1584,y:691,t:1527628473842};\\\", \\\"{x:1584,y:697,t:1527628473858};\\\", \\\"{x:1584,y:702,t:1527628473875};\\\", \\\"{x:1584,y:708,t:1527628473892};\\\", \\\"{x:1584,y:714,t:1527628473908};\\\", \\\"{x:1584,y:719,t:1527628473925};\\\", \\\"{x:1581,y:724,t:1527628473942};\\\", \\\"{x:1581,y:727,t:1527628473959};\\\", \\\"{x:1581,y:730,t:1527628473975};\\\", \\\"{x:1581,y:733,t:1527628473992};\\\", \\\"{x:1581,y:734,t:1527628474007};\\\", \\\"{x:1581,y:735,t:1527628474024};\\\", \\\"{x:1580,y:737,t:1527628474041};\\\", \\\"{x:1579,y:738,t:1527628474075};\\\", \\\"{x:1578,y:739,t:1527628474092};\\\", \\\"{x:1576,y:740,t:1527628474107};\\\", \\\"{x:1575,y:741,t:1527628474131};\\\", \\\"{x:1574,y:741,t:1527628474147};\\\", \\\"{x:1572,y:741,t:1527628474163};\\\", \\\"{x:1572,y:742,t:1527628474175};\\\", \\\"{x:1571,y:742,t:1527628474192};\\\", \\\"{x:1570,y:745,t:1527628474208};\\\", \\\"{x:1569,y:748,t:1527628474226};\\\", \\\"{x:1568,y:750,t:1527628474242};\\\", \\\"{x:1568,y:751,t:1527628474260};\\\", \\\"{x:1567,y:753,t:1527628474276};\\\", \\\"{x:1567,y:754,t:1527628474292};\\\", \\\"{x:1567,y:756,t:1527628474309};\\\", \\\"{x:1565,y:759,t:1527628474326};\\\", \\\"{x:1564,y:761,t:1527628474342};\\\", \\\"{x:1564,y:762,t:1527628474360};\\\", \\\"{x:1564,y:763,t:1527628474375};\\\", \\\"{x:1563,y:765,t:1527628474393};\\\", \\\"{x:1562,y:768,t:1527628474409};\\\", \\\"{x:1560,y:770,t:1527628474426};\\\", \\\"{x:1558,y:774,t:1527628474442};\\\", \\\"{x:1557,y:778,t:1527628474460};\\\", \\\"{x:1557,y:780,t:1527628474476};\\\", \\\"{x:1555,y:784,t:1527628474492};\\\", \\\"{x:1555,y:785,t:1527628474510};\\\", \\\"{x:1554,y:788,t:1527628474526};\\\", \\\"{x:1553,y:790,t:1527628474542};\\\", \\\"{x:1550,y:792,t:1527628474559};\\\", \\\"{x:1543,y:795,t:1527628474575};\\\", \\\"{x:1538,y:799,t:1527628474592};\\\", \\\"{x:1531,y:804,t:1527628474609};\\\", \\\"{x:1525,y:811,t:1527628474626};\\\", \\\"{x:1520,y:820,t:1527628474642};\\\", \\\"{x:1513,y:826,t:1527628474659};\\\", \\\"{x:1511,y:829,t:1527628474675};\\\", \\\"{x:1505,y:834,t:1527628474692};\\\", \\\"{x:1504,y:836,t:1527628474709};\\\", \\\"{x:1502,y:838,t:1527628474725};\\\", \\\"{x:1500,y:845,t:1527628474743};\\\", \\\"{x:1499,y:853,t:1527628474759};\\\", \\\"{x:1496,y:864,t:1527628474776};\\\", \\\"{x:1495,y:871,t:1527628474792};\\\", \\\"{x:1493,y:881,t:1527628474809};\\\", \\\"{x:1492,y:881,t:1527628474825};\\\", \\\"{x:1491,y:883,t:1527628474841};\\\", \\\"{x:1491,y:884,t:1527628474859};\\\", \\\"{x:1491,y:885,t:1527628474875};\\\", \\\"{x:1491,y:886,t:1527628474900};\\\", \\\"{x:1491,y:887,t:1527628474948};\\\", \\\"{x:1490,y:887,t:1527628474959};\\\", \\\"{x:1490,y:888,t:1527628474976};\\\", \\\"{x:1486,y:890,t:1527628475028};\\\", \\\"{x:1485,y:891,t:1527628475044};\\\", \\\"{x:1483,y:893,t:1527628475060};\\\", \\\"{x:1481,y:893,t:1527628475084};\\\", \\\"{x:1481,y:895,t:1527628475092};\\\", \\\"{x:1481,y:896,t:1527628475116};\\\", \\\"{x:1481,y:897,t:1527628475126};\\\", \\\"{x:1481,y:898,t:1527628475204};\\\", \\\"{x:1481,y:899,t:1527628475220};\\\", \\\"{x:1481,y:900,t:1527628475228};\\\", \\\"{x:1481,y:901,t:1527628475348};\\\", \\\"{x:1481,y:902,t:1527628475358};\\\", \\\"{x:1481,y:904,t:1527628475376};\\\", \\\"{x:1481,y:905,t:1527628475395};\\\", \\\"{x:1481,y:906,t:1527628475435};\\\", \\\"{x:1481,y:907,t:1527628475740};\\\", \\\"{x:1482,y:907,t:1527628475756};\\\", \\\"{x:1483,y:906,t:1527628477220};\\\", \\\"{x:1483,y:905,t:1527628477388};\\\", \\\"{x:1483,y:904,t:1527628477405};\\\", \\\"{x:1483,y:903,t:1527628477420};\\\", \\\"{x:1484,y:903,t:1527628477429};\\\", \\\"{x:1485,y:902,t:1527628477444};\\\", \\\"{x:1485,y:901,t:1527628477476};\\\", \\\"{x:1485,y:900,t:1527628477549};\\\", \\\"{x:1476,y:894,t:1527628481092};\\\", \\\"{x:1455,y:886,t:1527628481100};\\\", \\\"{x:1433,y:871,t:1527628481113};\\\", \\\"{x:1365,y:837,t:1527628481131};\\\", \\\"{x:1225,y:769,t:1527628481148};\\\", \\\"{x:1176,y:744,t:1527628481163};\\\", \\\"{x:1009,y:669,t:1527628481180};\\\", \\\"{x:898,y:610,t:1527628481197};\\\", \\\"{x:807,y:558,t:1527628481215};\\\", \\\"{x:751,y:516,t:1527628481230};\\\", \\\"{x:722,y:495,t:1527628481247};\\\", \\\"{x:711,y:483,t:1527628481264};\\\", \\\"{x:707,y:477,t:1527628481281};\\\", \\\"{x:707,y:470,t:1527628481297};\\\", \\\"{x:703,y:462,t:1527628481314};\\\", \\\"{x:700,y:450,t:1527628481331};\\\", \\\"{x:698,y:444,t:1527628481347};\\\", \\\"{x:696,y:440,t:1527628481363};\\\", \\\"{x:694,y:436,t:1527628481381};\\\", \\\"{x:693,y:435,t:1527628481492};\\\", \\\"{x:692,y:435,t:1527628481499};\\\", \\\"{x:690,y:435,t:1527628481514};\\\", \\\"{x:685,y:437,t:1527628481531};\\\", \\\"{x:672,y:442,t:1527628481547};\\\", \\\"{x:659,y:446,t:1527628481563};\\\", \\\"{x:650,y:449,t:1527628481581};\\\", \\\"{x:643,y:449,t:1527628481597};\\\", \\\"{x:638,y:450,t:1527628481615};\\\", \\\"{x:637,y:450,t:1527628481629};\\\", \\\"{x:636,y:450,t:1527628481651};\\\", \\\"{x:634,y:451,t:1527628481683};\\\", \\\"{x:632,y:451,t:1527628481697};\\\", \\\"{x:629,y:452,t:1527628481713};\\\", \\\"{x:627,y:453,t:1527628481730};\\\", \\\"{x:625,y:454,t:1527628481746};\\\", \\\"{x:623,y:454,t:1527628481763};\\\", \\\"{x:622,y:454,t:1527628481787};\\\", \\\"{x:621,y:454,t:1527628482035};\\\", \\\"{x:628,y:454,t:1527628482051};\\\", \\\"{x:636,y:454,t:1527628482065};\\\", \\\"{x:658,y:454,t:1527628482082};\\\", \\\"{x:668,y:454,t:1527628482098};\\\", \\\"{x:677,y:454,t:1527628482115};\\\", \\\"{x:679,y:454,t:1527628482131};\\\", \\\"{x:684,y:454,t:1527628482148};\\\", \\\"{x:692,y:454,t:1527628482165};\\\", \\\"{x:705,y:454,t:1527628482182};\\\", \\\"{x:728,y:454,t:1527628482199};\\\", \\\"{x:750,y:458,t:1527628482215};\\\", \\\"{x:776,y:460,t:1527628482231};\\\", \\\"{x:798,y:464,t:1527628482248};\\\", \\\"{x:809,y:465,t:1527628482266};\\\", \\\"{x:812,y:465,t:1527628482282};\\\", \\\"{x:813,y:465,t:1527628482298};\\\", \\\"{x:815,y:465,t:1527628482323};\\\", \\\"{x:818,y:465,t:1527628482331};\\\", \\\"{x:823,y:465,t:1527628482348};\\\", \\\"{x:828,y:465,t:1527628482365};\\\", \\\"{x:830,y:464,t:1527628482383};\\\", \\\"{x:831,y:464,t:1527628482398};\\\", \\\"{x:832,y:463,t:1527628482436};\\\", \\\"{x:833,y:462,t:1527628482450};\\\", \\\"{x:834,y:462,t:1527628482465};\\\", \\\"{x:836,y:460,t:1527628482483};\\\", \\\"{x:839,y:458,t:1527628482498};\\\", \\\"{x:844,y:458,t:1527628482796};\\\", \\\"{x:862,y:459,t:1527628482804};\\\", \\\"{x:892,y:468,t:1527628482816};\\\", \\\"{x:959,y:478,t:1527628482831};\\\", \\\"{x:1067,y:492,t:1527628482849};\\\", \\\"{x:1173,y:506,t:1527628482865};\\\", \\\"{x:1267,y:517,t:1527628482883};\\\", \\\"{x:1387,y:530,t:1527628482899};\\\", \\\"{x:1413,y:533,t:1527628482915};\\\", \\\"{x:1440,y:541,t:1527628482932};\\\", \\\"{x:1465,y:546,t:1527628482949};\\\", \\\"{x:1482,y:550,t:1527628482966};\\\", \\\"{x:1498,y:558,t:1527628482982};\\\", \\\"{x:1510,y:568,t:1527628482999};\\\", \\\"{x:1522,y:580,t:1527628483016};\\\", \\\"{x:1537,y:598,t:1527628483033};\\\", \\\"{x:1551,y:612,t:1527628483049};\\\", \\\"{x:1560,y:620,t:1527628483066};\\\", \\\"{x:1562,y:626,t:1527628483083};\\\", \\\"{x:1566,y:634,t:1527628483100};\\\", \\\"{x:1566,y:636,t:1527628483117};\\\", \\\"{x:1566,y:637,t:1527628483949};\\\", \\\"{x:1568,y:640,t:1527628483956};\\\", \\\"{x:1569,y:641,t:1527628483967};\\\", \\\"{x:1576,y:644,t:1527628483983};\\\", \\\"{x:1579,y:645,t:1527628484001};\\\", \\\"{x:1580,y:645,t:1527628484017};\\\", \\\"{x:1582,y:645,t:1527628484044};\\\", \\\"{x:1584,y:645,t:1527628484052};\\\", \\\"{x:1586,y:641,t:1527628484067};\\\", \\\"{x:1588,y:638,t:1527628484084};\\\", \\\"{x:1590,y:636,t:1527628484101};\\\", \\\"{x:1593,y:633,t:1527628484116};\\\", \\\"{x:1595,y:631,t:1527628484133};\\\", \\\"{x:1597,y:631,t:1527628484150};\\\", \\\"{x:1598,y:630,t:1527628484167};\\\", \\\"{x:1599,y:630,t:1527628484184};\\\", \\\"{x:1600,y:629,t:1527628484201};\\\", \\\"{x:1602,y:629,t:1527628484217};\\\", \\\"{x:1608,y:629,t:1527628484233};\\\", \\\"{x:1618,y:633,t:1527628484249};\\\", \\\"{x:1630,y:638,t:1527628484266};\\\", \\\"{x:1638,y:642,t:1527628484282};\\\", \\\"{x:1639,y:643,t:1527628484300};\\\", \\\"{x:1637,y:644,t:1527628484403};\\\", \\\"{x:1633,y:645,t:1527628484416};\\\", \\\"{x:1621,y:645,t:1527628484433};\\\", \\\"{x:1613,y:646,t:1527628484451};\\\", \\\"{x:1609,y:646,t:1527628484467};\\\", \\\"{x:1609,y:647,t:1527628484605};\\\", \\\"{x:1609,y:648,t:1527628484660};\\\", \\\"{x:1609,y:651,t:1527628484676};\\\", \\\"{x:1609,y:652,t:1527628484684};\\\", \\\"{x:1608,y:661,t:1527628484700};\\\", \\\"{x:1599,y:676,t:1527628484717};\\\", \\\"{x:1588,y:695,t:1527628484734};\\\", \\\"{x:1576,y:714,t:1527628484751};\\\", \\\"{x:1564,y:730,t:1527628484767};\\\", \\\"{x:1553,y:739,t:1527628484784};\\\", \\\"{x:1545,y:747,t:1527628484800};\\\", \\\"{x:1541,y:756,t:1527628484818};\\\", \\\"{x:1540,y:768,t:1527628484833};\\\", \\\"{x:1538,y:784,t:1527628484851};\\\", \\\"{x:1534,y:791,t:1527628484867};\\\", \\\"{x:1532,y:794,t:1527628484885};\\\", \\\"{x:1530,y:796,t:1527628484901};\\\", \\\"{x:1530,y:797,t:1527628484918};\\\", \\\"{x:1529,y:800,t:1527628484935};\\\", \\\"{x:1529,y:804,t:1527628484951};\\\", \\\"{x:1529,y:806,t:1527628484968};\\\", \\\"{x:1529,y:809,t:1527628484984};\\\", \\\"{x:1528,y:815,t:1527628485001};\\\", \\\"{x:1526,y:820,t:1527628485018};\\\", \\\"{x:1523,y:826,t:1527628485035};\\\", \\\"{x:1515,y:837,t:1527628485050};\\\", \\\"{x:1509,y:851,t:1527628485068};\\\", \\\"{x:1503,y:863,t:1527628485083};\\\", \\\"{x:1498,y:877,t:1527628485100};\\\", \\\"{x:1491,y:892,t:1527628485118};\\\", \\\"{x:1488,y:899,t:1527628485134};\\\", \\\"{x:1482,y:913,t:1527628485151};\\\", \\\"{x:1474,y:924,t:1527628485168};\\\", \\\"{x:1464,y:934,t:1527628485185};\\\", \\\"{x:1459,y:941,t:1527628485200};\\\", \\\"{x:1455,y:946,t:1527628485217};\\\", \\\"{x:1454,y:948,t:1527628485235};\\\", \\\"{x:1453,y:948,t:1527628485252};\\\", \\\"{x:1453,y:944,t:1527628485309};\\\", \\\"{x:1454,y:941,t:1527628485317};\\\", \\\"{x:1457,y:937,t:1527628485335};\\\", \\\"{x:1457,y:934,t:1527628485352};\\\", \\\"{x:1458,y:930,t:1527628485367};\\\", \\\"{x:1460,y:927,t:1527628485385};\\\", \\\"{x:1460,y:926,t:1527628485402};\\\", \\\"{x:1462,y:924,t:1527628485418};\\\", \\\"{x:1463,y:922,t:1527628485434};\\\", \\\"{x:1466,y:918,t:1527628485451};\\\", \\\"{x:1467,y:916,t:1527628485468};\\\", \\\"{x:1469,y:915,t:1527628485485};\\\", \\\"{x:1468,y:915,t:1527628485580};\\\", \\\"{x:1467,y:915,t:1527628485604};\\\", \\\"{x:1465,y:915,t:1527628485620};\\\", \\\"{x:1464,y:912,t:1527628485636};\\\", \\\"{x:1462,y:912,t:1527628485651};\\\", \\\"{x:1460,y:908,t:1527628485668};\\\", \\\"{x:1460,y:905,t:1527628485684};\\\", \\\"{x:1460,y:901,t:1527628485702};\\\", \\\"{x:1460,y:898,t:1527628485717};\\\", \\\"{x:1460,y:896,t:1527628485734};\\\", \\\"{x:1459,y:891,t:1527628485752};\\\", \\\"{x:1456,y:881,t:1527628485769};\\\", \\\"{x:1448,y:865,t:1527628485784};\\\", \\\"{x:1437,y:843,t:1527628485801};\\\", \\\"{x:1419,y:819,t:1527628485818};\\\", \\\"{x:1391,y:791,t:1527628485834};\\\", \\\"{x:1337,y:733,t:1527628485851};\\\", \\\"{x:1315,y:699,t:1527628485868};\\\", \\\"{x:1295,y:655,t:1527628485884};\\\", \\\"{x:1276,y:605,t:1527628485901};\\\", \\\"{x:1256,y:558,t:1527628485918};\\\", \\\"{x:1240,y:539,t:1527628485934};\\\", \\\"{x:1233,y:526,t:1527628485951};\\\", \\\"{x:1222,y:511,t:1527628485968};\\\", \\\"{x:1208,y:500,t:1527628485984};\\\", \\\"{x:1193,y:487,t:1527628486001};\\\", \\\"{x:1181,y:477,t:1527628486018};\\\", \\\"{x:1169,y:472,t:1527628486034};\\\", \\\"{x:1150,y:469,t:1527628486051};\\\", \\\"{x:1132,y:469,t:1527628486068};\\\", \\\"{x:1110,y:471,t:1527628486085};\\\", \\\"{x:1075,y:480,t:1527628486101};\\\", \\\"{x:1028,y:499,t:1527628486119};\\\", \\\"{x:958,y:520,t:1527628486135};\\\", \\\"{x:911,y:534,t:1527628486152};\\\", \\\"{x:883,y:548,t:1527628486169};\\\", \\\"{x:855,y:554,t:1527628486185};\\\", \\\"{x:830,y:564,t:1527628486201};\\\", \\\"{x:806,y:572,t:1527628486218};\\\", \\\"{x:794,y:580,t:1527628486235};\\\", \\\"{x:788,y:582,t:1527628486251};\\\", \\\"{x:777,y:586,t:1527628486268};\\\", \\\"{x:770,y:588,t:1527628486285};\\\", \\\"{x:761,y:591,t:1527628486301};\\\", \\\"{x:757,y:592,t:1527628486318};\\\", \\\"{x:750,y:596,t:1527628486335};\\\", \\\"{x:744,y:599,t:1527628486351};\\\", \\\"{x:735,y:603,t:1527628486368};\\\", \\\"{x:721,y:613,t:1527628486385};\\\", \\\"{x:705,y:623,t:1527628486401};\\\", \\\"{x:682,y:636,t:1527628486418};\\\", \\\"{x:634,y:651,t:1527628486435};\\\", \\\"{x:592,y:663,t:1527628486451};\\\", \\\"{x:549,y:672,t:1527628486468};\\\", \\\"{x:487,y:681,t:1527628486485};\\\", \\\"{x:452,y:695,t:1527628486502};\\\", \\\"{x:431,y:711,t:1527628486520};\\\", \\\"{x:415,y:724,t:1527628486535};\\\", \\\"{x:407,y:731,t:1527628486552};\\\", \\\"{x:407,y:732,t:1527628486569};\\\", \\\"{x:407,y:730,t:1527628486612};\\\", \\\"{x:408,y:730,t:1527628486620};\\\", \\\"{x:420,y:723,t:1527628486636};\\\", \\\"{x:440,y:713,t:1527628486652};\\\", \\\"{x:450,y:709,t:1527628486669};\\\", \\\"{x:454,y:707,t:1527628486685};\\\", \\\"{x:463,y:703,t:1527628486702};\\\", \\\"{x:476,y:698,t:1527628486720};\\\", \\\"{x:489,y:690,t:1527628486735};\\\", \\\"{x:505,y:683,t:1527628486752};\\\", \\\"{x:512,y:680,t:1527628486769};\\\", \\\"{x:516,y:677,t:1527628486785};\\\", \\\"{x:517,y:676,t:1527628486802};\\\", \\\"{x:518,y:676,t:1527628486819};\\\", \\\"{x:519,y:676,t:1527628486899};\\\", \\\"{x:520,y:676,t:1527628487044};\\\", \\\"{x:521,y:676,t:1527628487427};\\\", \\\"{x:523,y:676,t:1527628487435};\\\", \\\"{x:540,y:676,t:1527628487452};\\\", \\\"{x:562,y:676,t:1527628487469};\\\", \\\"{x:589,y:676,t:1527628487486};\\\", \\\"{x:609,y:678,t:1527628487502};\\\", \\\"{x:635,y:680,t:1527628487519};\\\", \\\"{x:659,y:684,t:1527628487537};\\\", \\\"{x:685,y:686,t:1527628487552};\\\", \\\"{x:710,y:689,t:1527628487569};\\\", \\\"{x:724,y:691,t:1527628487586};\\\", \\\"{x:741,y:692,t:1527628487602};\\\", \\\"{x:753,y:694,t:1527628487619};\\\", \\\"{x:762,y:694,t:1527628487636};\\\", \\\"{x:771,y:696,t:1527628487652};\\\", \\\"{x:784,y:701,t:1527628487669};\\\", \\\"{x:802,y:707,t:1527628487686};\\\", \\\"{x:825,y:719,t:1527628487703};\\\", \\\"{x:830,y:720,t:1527628487719};\\\" ] }, { \\\"rt\\\": 36374, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 740876, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -M -M -X -X -03 PM-X -03 PM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:832,y:720,t:1527628490724};\\\", \\\"{x:833,y:720,t:1527628490738};\\\", \\\"{x:836,y:720,t:1527628490754};\\\", \\\"{x:854,y:720,t:1527628490771};\\\", \\\"{x:880,y:720,t:1527628490789};\\\", \\\"{x:924,y:726,t:1527628490805};\\\", \\\"{x:982,y:734,t:1527628490822};\\\", \\\"{x:1041,y:743,t:1527628490838};\\\", \\\"{x:1093,y:757,t:1527628490854};\\\", \\\"{x:1133,y:768,t:1527628490871};\\\", \\\"{x:1157,y:772,t:1527628490889};\\\", \\\"{x:1177,y:775,t:1527628490905};\\\", \\\"{x:1191,y:776,t:1527628490922};\\\", \\\"{x:1200,y:776,t:1527628490938};\\\", \\\"{x:1208,y:776,t:1527628490955};\\\", \\\"{x:1211,y:776,t:1527628490974};\\\", \\\"{x:1219,y:770,t:1527628490989};\\\", \\\"{x:1227,y:766,t:1527628491005};\\\", \\\"{x:1238,y:760,t:1527628491021};\\\", \\\"{x:1246,y:751,t:1527628491038};\\\", \\\"{x:1257,y:743,t:1527628491055};\\\", \\\"{x:1269,y:732,t:1527628491071};\\\", \\\"{x:1276,y:723,t:1527628491088};\\\", \\\"{x:1283,y:707,t:1527628491105};\\\", \\\"{x:1284,y:694,t:1527628491121};\\\", \\\"{x:1284,y:683,t:1527628491138};\\\", \\\"{x:1279,y:666,t:1527628491155};\\\", \\\"{x:1275,y:656,t:1527628491171};\\\", \\\"{x:1272,y:650,t:1527628491189};\\\", \\\"{x:1270,y:640,t:1527628491206};\\\", \\\"{x:1268,y:629,t:1527628491221};\\\", \\\"{x:1266,y:621,t:1527628491239};\\\", \\\"{x:1266,y:620,t:1527628491255};\\\", \\\"{x:1268,y:617,t:1527628491272};\\\", \\\"{x:1271,y:616,t:1527628491289};\\\", \\\"{x:1273,y:615,t:1527628491306};\\\", \\\"{x:1276,y:615,t:1527628491387};\\\", \\\"{x:1278,y:620,t:1527628491395};\\\", \\\"{x:1281,y:627,t:1527628491405};\\\", \\\"{x:1289,y:639,t:1527628491422};\\\", \\\"{x:1297,y:654,t:1527628491438};\\\", \\\"{x:1303,y:666,t:1527628491455};\\\", \\\"{x:1309,y:681,t:1527628491472};\\\", \\\"{x:1314,y:697,t:1527628491488};\\\", \\\"{x:1317,y:710,t:1527628491505};\\\", \\\"{x:1319,y:720,t:1527628491522};\\\", \\\"{x:1323,y:726,t:1527628491538};\\\", \\\"{x:1326,y:733,t:1527628491555};\\\", \\\"{x:1327,y:738,t:1527628491573};\\\", \\\"{x:1331,y:746,t:1527628491588};\\\", \\\"{x:1336,y:757,t:1527628491606};\\\", \\\"{x:1342,y:769,t:1527628491623};\\\", \\\"{x:1351,y:781,t:1527628491639};\\\", \\\"{x:1357,y:795,t:1527628491657};\\\", \\\"{x:1364,y:805,t:1527628491673};\\\", \\\"{x:1367,y:812,t:1527628491689};\\\", \\\"{x:1371,y:823,t:1527628491706};\\\", \\\"{x:1375,y:831,t:1527628491723};\\\", \\\"{x:1378,y:836,t:1527628491740};\\\", \\\"{x:1381,y:842,t:1527628491756};\\\", \\\"{x:1383,y:844,t:1527628491773};\\\", \\\"{x:1383,y:846,t:1527628491789};\\\", \\\"{x:1383,y:847,t:1527628491806};\\\", \\\"{x:1385,y:850,t:1527628491824};\\\", \\\"{x:1386,y:853,t:1527628491839};\\\", \\\"{x:1389,y:858,t:1527628491856};\\\", \\\"{x:1391,y:860,t:1527628491873};\\\", \\\"{x:1397,y:865,t:1527628491890};\\\", \\\"{x:1408,y:869,t:1527628491906};\\\", \\\"{x:1427,y:875,t:1527628491923};\\\", \\\"{x:1452,y:883,t:1527628491940};\\\", \\\"{x:1466,y:891,t:1527628491956};\\\", \\\"{x:1479,y:894,t:1527628491973};\\\", \\\"{x:1486,y:896,t:1527628491990};\\\", \\\"{x:1491,y:897,t:1527628492006};\\\", \\\"{x:1491,y:898,t:1527628492023};\\\", \\\"{x:1492,y:898,t:1527628492067};\\\", \\\"{x:1494,y:899,t:1527628492076};\\\", \\\"{x:1495,y:899,t:1527628492090};\\\", \\\"{x:1502,y:901,t:1527628492106};\\\", \\\"{x:1516,y:908,t:1527628492124};\\\", \\\"{x:1525,y:909,t:1527628492140};\\\", \\\"{x:1530,y:910,t:1527628492159};\\\", \\\"{x:1531,y:911,t:1527628492173};\\\", \\\"{x:1532,y:911,t:1527628492307};\\\", \\\"{x:1533,y:911,t:1527628492322};\\\", \\\"{x:1536,y:911,t:1527628492339};\\\", \\\"{x:1540,y:912,t:1527628492356};\\\", \\\"{x:1544,y:913,t:1527628492373};\\\", \\\"{x:1549,y:913,t:1527628492390};\\\", \\\"{x:1551,y:913,t:1527628492407};\\\", \\\"{x:1552,y:913,t:1527628492428};\\\", \\\"{x:1553,y:913,t:1527628492452};\\\", \\\"{x:1554,y:913,t:1527628492499};\\\", \\\"{x:1555,y:914,t:1527628497396};\\\", \\\"{x:1555,y:915,t:1527628497410};\\\", \\\"{x:1554,y:915,t:1527628497426};\\\", \\\"{x:1553,y:915,t:1527628497443};\\\", \\\"{x:1553,y:913,t:1527628497580};\\\", \\\"{x:1552,y:913,t:1527628497593};\\\", \\\"{x:1551,y:910,t:1527628497611};\\\", \\\"{x:1549,y:908,t:1527628497628};\\\", \\\"{x:1548,y:905,t:1527628497643};\\\", \\\"{x:1547,y:905,t:1527628497661};\\\", \\\"{x:1547,y:904,t:1527628497700};\\\", \\\"{x:1547,y:903,t:1527628500298};\\\", \\\"{x:1547,y:902,t:1527628500411};\\\", \\\"{x:1547,y:900,t:1527628500443};\\\", \\\"{x:1547,y:899,t:1527628500459};\\\", \\\"{x:1547,y:898,t:1527628500468};\\\", \\\"{x:1547,y:897,t:1527628500483};\\\", \\\"{x:1547,y:896,t:1527628500495};\\\", \\\"{x:1546,y:895,t:1527628500512};\\\", \\\"{x:1546,y:894,t:1527628500528};\\\", \\\"{x:1546,y:893,t:1527628500548};\\\", \\\"{x:1546,y:892,t:1527628500572};\\\", \\\"{x:1546,y:890,t:1527628500579};\\\", \\\"{x:1546,y:889,t:1527628500596};\\\", \\\"{x:1546,y:886,t:1527628500611};\\\", \\\"{x:1546,y:884,t:1527628500630};\\\", \\\"{x:1546,y:882,t:1527628500645};\\\", \\\"{x:1545,y:879,t:1527628500662};\\\", \\\"{x:1542,y:872,t:1527628500679};\\\", \\\"{x:1540,y:867,t:1527628500696};\\\", \\\"{x:1538,y:864,t:1527628500712};\\\", \\\"{x:1536,y:860,t:1527628500729};\\\", \\\"{x:1535,y:857,t:1527628500745};\\\", \\\"{x:1534,y:854,t:1527628500763};\\\", \\\"{x:1533,y:850,t:1527628500779};\\\", \\\"{x:1531,y:848,t:1527628500795};\\\", \\\"{x:1530,y:846,t:1527628500811};\\\", \\\"{x:1529,y:843,t:1527628500829};\\\", \\\"{x:1526,y:839,t:1527628500844};\\\", \\\"{x:1523,y:836,t:1527628500861};\\\", \\\"{x:1519,y:831,t:1527628500878};\\\", \\\"{x:1515,y:826,t:1527628500894};\\\", \\\"{x:1513,y:822,t:1527628500911};\\\", \\\"{x:1512,y:818,t:1527628500929};\\\", \\\"{x:1509,y:813,t:1527628500945};\\\", \\\"{x:1507,y:809,t:1527628500961};\\\", \\\"{x:1504,y:803,t:1527628500979};\\\", \\\"{x:1504,y:801,t:1527628500995};\\\", \\\"{x:1502,y:798,t:1527628501012};\\\", \\\"{x:1501,y:795,t:1527628501029};\\\", \\\"{x:1500,y:793,t:1527628501044};\\\", \\\"{x:1498,y:791,t:1527628501062};\\\", \\\"{x:1497,y:790,t:1527628501079};\\\", \\\"{x:1495,y:788,t:1527628501095};\\\", \\\"{x:1494,y:786,t:1527628501112};\\\", \\\"{x:1491,y:783,t:1527628501129};\\\", \\\"{x:1489,y:780,t:1527628501144};\\\", \\\"{x:1485,y:777,t:1527628501162};\\\", \\\"{x:1480,y:773,t:1527628501178};\\\", \\\"{x:1478,y:770,t:1527628501195};\\\", \\\"{x:1477,y:768,t:1527628501211};\\\", \\\"{x:1475,y:764,t:1527628501229};\\\", \\\"{x:1473,y:760,t:1527628501246};\\\", \\\"{x:1471,y:756,t:1527628501262};\\\", \\\"{x:1468,y:750,t:1527628501278};\\\", \\\"{x:1465,y:745,t:1527628501295};\\\", \\\"{x:1463,y:742,t:1527628501312};\\\", \\\"{x:1462,y:741,t:1527628501329};\\\", \\\"{x:1460,y:737,t:1527628501346};\\\", \\\"{x:1459,y:734,t:1527628501362};\\\", \\\"{x:1456,y:730,t:1527628501380};\\\", \\\"{x:1453,y:724,t:1527628501396};\\\", \\\"{x:1449,y:719,t:1527628501412};\\\", \\\"{x:1445,y:711,t:1527628501429};\\\", \\\"{x:1440,y:704,t:1527628501447};\\\", \\\"{x:1435,y:694,t:1527628501462};\\\", \\\"{x:1429,y:683,t:1527628501480};\\\", \\\"{x:1421,y:670,t:1527628501496};\\\", \\\"{x:1414,y:659,t:1527628501512};\\\", \\\"{x:1407,y:647,t:1527628501529};\\\", \\\"{x:1400,y:636,t:1527628501546};\\\", \\\"{x:1398,y:632,t:1527628501563};\\\", \\\"{x:1395,y:621,t:1527628501579};\\\", \\\"{x:1394,y:616,t:1527628501596};\\\", \\\"{x:1392,y:612,t:1527628501612};\\\", \\\"{x:1391,y:609,t:1527628501629};\\\", \\\"{x:1391,y:607,t:1527628501647};\\\", \\\"{x:1390,y:604,t:1527628501663};\\\", \\\"{x:1388,y:600,t:1527628501680};\\\", \\\"{x:1387,y:598,t:1527628501696};\\\", \\\"{x:1386,y:595,t:1527628501713};\\\", \\\"{x:1384,y:594,t:1527628501729};\\\", \\\"{x:1381,y:591,t:1527628501746};\\\", \\\"{x:1381,y:589,t:1527628501764};\\\", \\\"{x:1380,y:588,t:1527628501779};\\\", \\\"{x:1378,y:585,t:1527628501796};\\\", \\\"{x:1377,y:584,t:1527628501813};\\\", \\\"{x:1376,y:582,t:1527628501829};\\\", \\\"{x:1376,y:581,t:1527628501846};\\\", \\\"{x:1375,y:580,t:1527628501863};\\\", \\\"{x:1373,y:578,t:1527628501878};\\\", \\\"{x:1371,y:575,t:1527628501895};\\\", \\\"{x:1370,y:570,t:1527628501912};\\\", \\\"{x:1368,y:567,t:1527628501928};\\\", \\\"{x:1364,y:562,t:1527628501946};\\\", \\\"{x:1362,y:558,t:1527628501962};\\\", \\\"{x:1360,y:555,t:1527628501978};\\\", \\\"{x:1359,y:553,t:1527628501995};\\\", \\\"{x:1358,y:550,t:1527628502013};\\\", \\\"{x:1357,y:548,t:1527628502029};\\\", \\\"{x:1357,y:547,t:1527628502051};\\\", \\\"{x:1357,y:546,t:1527628502063};\\\", \\\"{x:1357,y:545,t:1527628502078};\\\", \\\"{x:1355,y:543,t:1527628502096};\\\", \\\"{x:1355,y:542,t:1527628502113};\\\", \\\"{x:1354,y:540,t:1527628502129};\\\", \\\"{x:1353,y:540,t:1527628502146};\\\", \\\"{x:1353,y:539,t:1527628502163};\\\", \\\"{x:1353,y:538,t:1527628502179};\\\", \\\"{x:1353,y:537,t:1527628502196};\\\", \\\"{x:1353,y:534,t:1527628502214};\\\", \\\"{x:1352,y:533,t:1527628502230};\\\", \\\"{x:1352,y:532,t:1527628502246};\\\", \\\"{x:1351,y:531,t:1527628502264};\\\", \\\"{x:1350,y:529,t:1527628502299};\\\", \\\"{x:1350,y:528,t:1527628502331};\\\", \\\"{x:1350,y:527,t:1527628502346};\\\", \\\"{x:1350,y:526,t:1527628502363};\\\", \\\"{x:1350,y:525,t:1527628502395};\\\", \\\"{x:1349,y:524,t:1527628502413};\\\", \\\"{x:1349,y:523,t:1527628502430};\\\", \\\"{x:1348,y:521,t:1527628502446};\\\", \\\"{x:1347,y:520,t:1527628502464};\\\", \\\"{x:1347,y:519,t:1527628502480};\\\", \\\"{x:1347,y:516,t:1527628502497};\\\", \\\"{x:1346,y:514,t:1527628502514};\\\", \\\"{x:1346,y:513,t:1527628502530};\\\", \\\"{x:1346,y:512,t:1527628502564};\\\", \\\"{x:1345,y:511,t:1527628502668};\\\", \\\"{x:1344,y:511,t:1527628502684};\\\", \\\"{x:1343,y:511,t:1527628502708};\\\", \\\"{x:1342,y:511,t:1527628502731};\\\", \\\"{x:1341,y:512,t:1527628502755};\\\", \\\"{x:1340,y:512,t:1527628502764};\\\", \\\"{x:1340,y:513,t:1527628502796};\\\", \\\"{x:1340,y:515,t:1527628505065};\\\", \\\"{x:1342,y:527,t:1527628505072};\\\", \\\"{x:1353,y:549,t:1527628505085};\\\", \\\"{x:1389,y:592,t:1527628505103};\\\", \\\"{x:1441,y:654,t:1527628505119};\\\", \\\"{x:1475,y:691,t:1527628505136};\\\", \\\"{x:1500,y:723,t:1527628505153};\\\", \\\"{x:1517,y:747,t:1527628505170};\\\", \\\"{x:1531,y:775,t:1527628505186};\\\", \\\"{x:1542,y:802,t:1527628505203};\\\", \\\"{x:1552,y:826,t:1527628505220};\\\", \\\"{x:1558,y:845,t:1527628505236};\\\", \\\"{x:1561,y:854,t:1527628505253};\\\", \\\"{x:1561,y:855,t:1527628505270};\\\", \\\"{x:1561,y:856,t:1527628505286};\\\", \\\"{x:1561,y:858,t:1527628505302};\\\", \\\"{x:1557,y:862,t:1527628505319};\\\", \\\"{x:1553,y:864,t:1527628505336};\\\", \\\"{x:1546,y:868,t:1527628505353};\\\", \\\"{x:1541,y:872,t:1527628505370};\\\", \\\"{x:1540,y:874,t:1527628505386};\\\", \\\"{x:1538,y:876,t:1527628505403};\\\", \\\"{x:1538,y:877,t:1527628505420};\\\", \\\"{x:1538,y:880,t:1527628505436};\\\", \\\"{x:1538,y:888,t:1527628505453};\\\", \\\"{x:1540,y:897,t:1527628505470};\\\", \\\"{x:1548,y:909,t:1527628505487};\\\", \\\"{x:1559,y:922,t:1527628505503};\\\", \\\"{x:1562,y:930,t:1527628505520};\\\", \\\"{x:1562,y:928,t:1527628505625};\\\", \\\"{x:1561,y:925,t:1527628505637};\\\", \\\"{x:1558,y:913,t:1527628505654};\\\", \\\"{x:1554,y:907,t:1527628505670};\\\", \\\"{x:1548,y:898,t:1527628505687};\\\", \\\"{x:1544,y:890,t:1527628505703};\\\", \\\"{x:1544,y:886,t:1527628505720};\\\", \\\"{x:1542,y:882,t:1527628505737};\\\", \\\"{x:1541,y:875,t:1527628505754};\\\", \\\"{x:1539,y:869,t:1527628505771};\\\", \\\"{x:1534,y:856,t:1527628505787};\\\", \\\"{x:1528,y:844,t:1527628505803};\\\", \\\"{x:1523,y:834,t:1527628505820};\\\", \\\"{x:1516,y:824,t:1527628505837};\\\", \\\"{x:1508,y:813,t:1527628505854};\\\", \\\"{x:1504,y:806,t:1527628505869};\\\", \\\"{x:1500,y:799,t:1527628505886};\\\", \\\"{x:1495,y:793,t:1527628505903};\\\", \\\"{x:1494,y:791,t:1527628505920};\\\", \\\"{x:1493,y:789,t:1527628505936};\\\", \\\"{x:1493,y:788,t:1527628505959};\\\", \\\"{x:1493,y:787,t:1527628505969};\\\", \\\"{x:1492,y:786,t:1527628505991};\\\", \\\"{x:1492,y:784,t:1527628506004};\\\", \\\"{x:1491,y:781,t:1527628506020};\\\", \\\"{x:1489,y:779,t:1527628506037};\\\", \\\"{x:1487,y:774,t:1527628506054};\\\", \\\"{x:1485,y:768,t:1527628506069};\\\", \\\"{x:1481,y:762,t:1527628506087};\\\", \\\"{x:1477,y:751,t:1527628506105};\\\", \\\"{x:1473,y:742,t:1527628506120};\\\", \\\"{x:1469,y:731,t:1527628506137};\\\", \\\"{x:1464,y:721,t:1527628506154};\\\", \\\"{x:1460,y:709,t:1527628506170};\\\", \\\"{x:1454,y:699,t:1527628506187};\\\", \\\"{x:1450,y:686,t:1527628506204};\\\", \\\"{x:1443,y:674,t:1527628506220};\\\", \\\"{x:1438,y:661,t:1527628506237};\\\", \\\"{x:1431,y:649,t:1527628506255};\\\", \\\"{x:1425,y:638,t:1527628506271};\\\", \\\"{x:1421,y:631,t:1527628506288};\\\", \\\"{x:1417,y:623,t:1527628506304};\\\", \\\"{x:1413,y:617,t:1527628506320};\\\", \\\"{x:1409,y:612,t:1527628506337};\\\", \\\"{x:1406,y:606,t:1527628506354};\\\", \\\"{x:1400,y:598,t:1527628506372};\\\", \\\"{x:1393,y:591,t:1527628506388};\\\", \\\"{x:1387,y:583,t:1527628506404};\\\", \\\"{x:1381,y:576,t:1527628506421};\\\", \\\"{x:1375,y:570,t:1527628506438};\\\", \\\"{x:1372,y:563,t:1527628506454};\\\", \\\"{x:1369,y:559,t:1527628506471};\\\", \\\"{x:1367,y:552,t:1527628506487};\\\", \\\"{x:1359,y:542,t:1527628506505};\\\", \\\"{x:1359,y:537,t:1527628506521};\\\", \\\"{x:1356,y:532,t:1527628506537};\\\", \\\"{x:1355,y:526,t:1527628506554};\\\", \\\"{x:1352,y:523,t:1527628506571};\\\", \\\"{x:1352,y:520,t:1527628506587};\\\", \\\"{x:1351,y:516,t:1527628506604};\\\", \\\"{x:1350,y:510,t:1527628506622};\\\", \\\"{x:1346,y:500,t:1527628506638};\\\", \\\"{x:1342,y:493,t:1527628506654};\\\", \\\"{x:1339,y:485,t:1527628506672};\\\", \\\"{x:1337,y:478,t:1527628506687};\\\", \\\"{x:1335,y:474,t:1527628506704};\\\", \\\"{x:1334,y:473,t:1527628506722};\\\", \\\"{x:1333,y:471,t:1527628506737};\\\", \\\"{x:1332,y:468,t:1527628506754};\\\", \\\"{x:1331,y:465,t:1527628506771};\\\", \\\"{x:1331,y:463,t:1527628506787};\\\", \\\"{x:1331,y:460,t:1527628506805};\\\", \\\"{x:1328,y:457,t:1527628506822};\\\", \\\"{x:1328,y:456,t:1527628506838};\\\", \\\"{x:1328,y:455,t:1527628506854};\\\", \\\"{x:1328,y:454,t:1527628506872};\\\", \\\"{x:1328,y:453,t:1527628506888};\\\", \\\"{x:1327,y:452,t:1527628506904};\\\", \\\"{x:1327,y:451,t:1527628506921};\\\", \\\"{x:1326,y:449,t:1527628506945};\\\", \\\"{x:1328,y:449,t:1527628507841};\\\", \\\"{x:1333,y:458,t:1527628507855};\\\", \\\"{x:1353,y:488,t:1527628507873};\\\", \\\"{x:1362,y:500,t:1527628507888};\\\", \\\"{x:1367,y:510,t:1527628507906};\\\", \\\"{x:1372,y:520,t:1527628507923};\\\", \\\"{x:1376,y:528,t:1527628507938};\\\", \\\"{x:1379,y:535,t:1527628507955};\\\", \\\"{x:1380,y:542,t:1527628507973};\\\", \\\"{x:1383,y:552,t:1527628507988};\\\", \\\"{x:1385,y:564,t:1527628508005};\\\", \\\"{x:1392,y:586,t:1527628508022};\\\", \\\"{x:1399,y:608,t:1527628508039};\\\", \\\"{x:1405,y:632,t:1527628508055};\\\", \\\"{x:1413,y:665,t:1527628508072};\\\", \\\"{x:1422,y:682,t:1527628508088};\\\", \\\"{x:1427,y:702,t:1527628508105};\\\", \\\"{x:1435,y:722,t:1527628508122};\\\", \\\"{x:1441,y:738,t:1527628508138};\\\", \\\"{x:1445,y:752,t:1527628508155};\\\", \\\"{x:1448,y:761,t:1527628508172};\\\", \\\"{x:1450,y:768,t:1527628508188};\\\", \\\"{x:1450,y:773,t:1527628508206};\\\", \\\"{x:1453,y:777,t:1527628508223};\\\", \\\"{x:1453,y:779,t:1527628508239};\\\", \\\"{x:1453,y:782,t:1527628508256};\\\", \\\"{x:1455,y:786,t:1527628508274};\\\", \\\"{x:1457,y:789,t:1527628508288};\\\", \\\"{x:1458,y:791,t:1527628508304};\\\", \\\"{x:1460,y:793,t:1527628508322};\\\", \\\"{x:1461,y:794,t:1527628508338};\\\", \\\"{x:1461,y:795,t:1527628508354};\\\", \\\"{x:1462,y:795,t:1527628508375};\\\", \\\"{x:1463,y:795,t:1527628508448};\\\", \\\"{x:1465,y:795,t:1527628508592};\\\", \\\"{x:1466,y:796,t:1527628508648};\\\", \\\"{x:1468,y:796,t:1527628508776};\\\", \\\"{x:1469,y:796,t:1527628508913};\\\", \\\"{x:1471,y:796,t:1527628509200};\\\", \\\"{x:1472,y:797,t:1527628509217};\\\", \\\"{x:1474,y:798,t:1527628509487};\\\", \\\"{x:1475,y:798,t:1527628509511};\\\", \\\"{x:1478,y:799,t:1527628509527};\\\", \\\"{x:1478,y:800,t:1527628509544};\\\", \\\"{x:1479,y:800,t:1527628509555};\\\", \\\"{x:1479,y:801,t:1527628509575};\\\", \\\"{x:1479,y:802,t:1527628509592};\\\", \\\"{x:1480,y:803,t:1527628509608};\\\", \\\"{x:1481,y:804,t:1527628509632};\\\", \\\"{x:1481,y:805,t:1527628509639};\\\", \\\"{x:1482,y:805,t:1527628509656};\\\", \\\"{x:1483,y:807,t:1527628509744};\\\", \\\"{x:1483,y:809,t:1527628509756};\\\", \\\"{x:1483,y:812,t:1527628509773};\\\", \\\"{x:1486,y:819,t:1527628509789};\\\", \\\"{x:1495,y:830,t:1527628509806};\\\", \\\"{x:1496,y:833,t:1527628509823};\\\", \\\"{x:1499,y:837,t:1527628509840};\\\", \\\"{x:1501,y:839,t:1527628509856};\\\", \\\"{x:1502,y:840,t:1527628509874};\\\", \\\"{x:1503,y:841,t:1527628509937};\\\", \\\"{x:1504,y:842,t:1527628509952};\\\", \\\"{x:1505,y:843,t:1527628509960};\\\", \\\"{x:1506,y:843,t:1527628509974};\\\", \\\"{x:1507,y:846,t:1527628509991};\\\", \\\"{x:1510,y:853,t:1527628510006};\\\", \\\"{x:1515,y:862,t:1527628510024};\\\", \\\"{x:1523,y:875,t:1527628510040};\\\", \\\"{x:1524,y:880,t:1527628510056};\\\", \\\"{x:1526,y:884,t:1527628510073};\\\", \\\"{x:1528,y:887,t:1527628510091};\\\", \\\"{x:1529,y:890,t:1527628510106};\\\", \\\"{x:1530,y:892,t:1527628510123};\\\", \\\"{x:1531,y:892,t:1527628510140};\\\", \\\"{x:1531,y:893,t:1527628510168};\\\", \\\"{x:1531,y:894,t:1527628510192};\\\", \\\"{x:1532,y:894,t:1527628510912};\\\", \\\"{x:1533,y:895,t:1527628510923};\\\", \\\"{x:1535,y:899,t:1527628510940};\\\", \\\"{x:1539,y:904,t:1527628510958};\\\", \\\"{x:1542,y:911,t:1527628510974};\\\", \\\"{x:1543,y:913,t:1527628510991};\\\", \\\"{x:1543,y:917,t:1527628511007};\\\", \\\"{x:1545,y:918,t:1527628511024};\\\", \\\"{x:1543,y:916,t:1527628511145};\\\", \\\"{x:1541,y:914,t:1527628511158};\\\", \\\"{x:1540,y:909,t:1527628511174};\\\", \\\"{x:1533,y:898,t:1527628511191};\\\", \\\"{x:1524,y:885,t:1527628511208};\\\", \\\"{x:1516,y:875,t:1527628511224};\\\", \\\"{x:1512,y:867,t:1527628511240};\\\", \\\"{x:1507,y:860,t:1527628511257};\\\", \\\"{x:1506,y:855,t:1527628511274};\\\", \\\"{x:1505,y:851,t:1527628511290};\\\", \\\"{x:1503,y:846,t:1527628511307};\\\", \\\"{x:1501,y:841,t:1527628511323};\\\", \\\"{x:1500,y:838,t:1527628511339};\\\", \\\"{x:1500,y:834,t:1527628511357};\\\", \\\"{x:1499,y:831,t:1527628511374};\\\", \\\"{x:1497,y:824,t:1527628511389};\\\", \\\"{x:1492,y:819,t:1527628511407};\\\", \\\"{x:1492,y:817,t:1527628511424};\\\", \\\"{x:1491,y:816,t:1527628511440};\\\", \\\"{x:1490,y:813,t:1527628511457};\\\", \\\"{x:1489,y:811,t:1527628511474};\\\", \\\"{x:1489,y:809,t:1527628511491};\\\", \\\"{x:1489,y:804,t:1527628511507};\\\", \\\"{x:1489,y:799,t:1527628511524};\\\", \\\"{x:1489,y:792,t:1527628511540};\\\", \\\"{x:1489,y:790,t:1527628511558};\\\", \\\"{x:1491,y:786,t:1527628511574};\\\", \\\"{x:1491,y:784,t:1527628511591};\\\", \\\"{x:1491,y:783,t:1527628511607};\\\", \\\"{x:1491,y:782,t:1527628511625};\\\", \\\"{x:1485,y:779,t:1527628511642};\\\", \\\"{x:1456,y:774,t:1527628511658};\\\", \\\"{x:1365,y:753,t:1527628511675};\\\", \\\"{x:1239,y:722,t:1527628511691};\\\", \\\"{x:1087,y:678,t:1527628511707};\\\", \\\"{x:961,y:633,t:1527628511724};\\\", \\\"{x:898,y:609,t:1527628511741};\\\", \\\"{x:877,y:595,t:1527628511757};\\\", \\\"{x:870,y:587,t:1527628511774};\\\", \\\"{x:869,y:579,t:1527628511791};\\\", \\\"{x:867,y:565,t:1527628511808};\\\", \\\"{x:868,y:544,t:1527628511824};\\\", \\\"{x:869,y:530,t:1527628511841};\\\", \\\"{x:872,y:519,t:1527628511860};\\\", \\\"{x:872,y:504,t:1527628511877};\\\", \\\"{x:848,y:479,t:1527628511893};\\\", \\\"{x:824,y:452,t:1527628511911};\\\", \\\"{x:795,y:437,t:1527628511927};\\\", \\\"{x:720,y:417,t:1527628511943};\\\", \\\"{x:642,y:406,t:1527628511959};\\\", \\\"{x:612,y:401,t:1527628511976};\\\", \\\"{x:601,y:401,t:1527628511993};\\\", \\\"{x:598,y:401,t:1527628512010};\\\", \\\"{x:596,y:401,t:1527628512096};\\\", \\\"{x:595,y:402,t:1527628512111};\\\", \\\"{x:587,y:406,t:1527628512127};\\\", \\\"{x:570,y:416,t:1527628512143};\\\", \\\"{x:560,y:427,t:1527628512161};\\\", \\\"{x:548,y:438,t:1527628512178};\\\", \\\"{x:535,y:451,t:1527628512194};\\\", \\\"{x:524,y:464,t:1527628512211};\\\", \\\"{x:519,y:481,t:1527628512227};\\\", \\\"{x:517,y:494,t:1527628512243};\\\", \\\"{x:517,y:499,t:1527628512260};\\\", \\\"{x:519,y:503,t:1527628512277};\\\", \\\"{x:521,y:503,t:1527628512293};\\\", \\\"{x:526,y:505,t:1527628512310};\\\", \\\"{x:536,y:506,t:1527628512327};\\\", \\\"{x:547,y:507,t:1527628512343};\\\", \\\"{x:561,y:507,t:1527628512359};\\\", \\\"{x:572,y:507,t:1527628512377};\\\", \\\"{x:587,y:507,t:1527628512393};\\\", \\\"{x:596,y:507,t:1527628512410};\\\", \\\"{x:603,y:507,t:1527628512427};\\\", \\\"{x:608,y:507,t:1527628512444};\\\", \\\"{x:613,y:509,t:1527628512461};\\\", \\\"{x:614,y:510,t:1527628512478};\\\", \\\"{x:617,y:511,t:1527628512494};\\\", \\\"{x:619,y:513,t:1527628512511};\\\", \\\"{x:620,y:513,t:1527628512526};\\\", \\\"{x:620,y:514,t:1527628512543};\\\", \\\"{x:621,y:514,t:1527628512615};\\\", \\\"{x:620,y:516,t:1527628512627};\\\", \\\"{x:613,y:518,t:1527628512643};\\\", \\\"{x:610,y:521,t:1527628512660};\\\", \\\"{x:608,y:523,t:1527628512676};\\\", \\\"{x:610,y:524,t:1527628512927};\\\", \\\"{x:657,y:546,t:1527628512944};\\\", \\\"{x:755,y:577,t:1527628512961};\\\", \\\"{x:873,y:609,t:1527628512978};\\\", \\\"{x:1000,y:643,t:1527628512994};\\\", \\\"{x:1122,y:680,t:1527628513011};\\\", \\\"{x:1221,y:721,t:1527628513028};\\\", \\\"{x:1297,y:759,t:1527628513044};\\\", \\\"{x:1338,y:785,t:1527628513061};\\\", \\\"{x:1368,y:801,t:1527628513078};\\\", \\\"{x:1385,y:814,t:1527628513094};\\\", \\\"{x:1399,y:826,t:1527628513111};\\\", \\\"{x:1406,y:836,t:1527628513127};\\\", \\\"{x:1410,y:840,t:1527628513144};\\\", \\\"{x:1415,y:843,t:1527628513161};\\\", \\\"{x:1418,y:845,t:1527628513179};\\\", \\\"{x:1419,y:847,t:1527628513194};\\\", \\\"{x:1421,y:847,t:1527628513211};\\\", \\\"{x:1423,y:849,t:1527628513228};\\\", \\\"{x:1427,y:852,t:1527628513244};\\\", \\\"{x:1429,y:853,t:1527628513261};\\\", \\\"{x:1436,y:855,t:1527628513278};\\\", \\\"{x:1443,y:860,t:1527628513294};\\\", \\\"{x:1446,y:860,t:1527628513311};\\\", \\\"{x:1451,y:864,t:1527628513328};\\\", \\\"{x:1455,y:868,t:1527628513345};\\\", \\\"{x:1459,y:873,t:1527628513362};\\\", \\\"{x:1465,y:882,t:1527628513378};\\\", \\\"{x:1474,y:893,t:1527628513395};\\\", \\\"{x:1480,y:898,t:1527628513411};\\\", \\\"{x:1481,y:903,t:1527628513428};\\\", \\\"{x:1481,y:905,t:1527628514201};\\\", \\\"{x:1486,y:907,t:1527628514212};\\\", \\\"{x:1488,y:907,t:1527628514228};\\\", \\\"{x:1489,y:907,t:1527628514245};\\\", \\\"{x:1491,y:907,t:1527628514329};\\\", \\\"{x:1492,y:907,t:1527628514345};\\\", \\\"{x:1495,y:907,t:1527628514361};\\\", \\\"{x:1498,y:907,t:1527628514379};\\\", \\\"{x:1500,y:906,t:1527628514395};\\\", \\\"{x:1501,y:906,t:1527628514411};\\\", \\\"{x:1502,y:905,t:1527628514428};\\\", \\\"{x:1503,y:905,t:1527628514445};\\\", \\\"{x:1505,y:904,t:1527628514461};\\\", \\\"{x:1509,y:903,t:1527628514478};\\\", \\\"{x:1513,y:900,t:1527628514495};\\\", \\\"{x:1518,y:900,t:1527628514512};\\\", \\\"{x:1520,y:898,t:1527628514528};\\\", \\\"{x:1521,y:898,t:1527628514609};\\\", \\\"{x:1522,y:897,t:1527628514624};\\\", \\\"{x:1523,y:897,t:1527628514640};\\\", \\\"{x:1525,y:897,t:1527628514648};\\\", \\\"{x:1526,y:897,t:1527628514661};\\\", \\\"{x:1529,y:897,t:1527628514678};\\\", \\\"{x:1536,y:897,t:1527628514694};\\\", \\\"{x:1540,y:898,t:1527628514711};\\\", \\\"{x:1542,y:899,t:1527628514728};\\\", \\\"{x:1546,y:902,t:1527628514745};\\\", \\\"{x:1548,y:905,t:1527628514762};\\\", \\\"{x:1552,y:907,t:1527628514778};\\\", \\\"{x:1554,y:909,t:1527628514795};\\\", \\\"{x:1557,y:911,t:1527628514811};\\\", \\\"{x:1558,y:912,t:1527628514828};\\\", \\\"{x:1560,y:913,t:1527628514845};\\\", \\\"{x:1560,y:912,t:1527628516305};\\\", \\\"{x:1561,y:911,t:1527628516737};\\\", \\\"{x:1564,y:911,t:1527628516746};\\\", \\\"{x:1566,y:912,t:1527628516763};\\\", \\\"{x:1567,y:912,t:1527628516780};\\\", \\\"{x:1568,y:912,t:1527628516849};\\\", \\\"{x:1569,y:912,t:1527628516912};\\\", \\\"{x:1570,y:912,t:1527628517008};\\\", \\\"{x:1571,y:912,t:1527628517241};\\\", \\\"{x:1572,y:912,t:1527628518200};\\\", \\\"{x:1573,y:912,t:1527628518214};\\\", \\\"{x:1574,y:911,t:1527628518232};\\\", \\\"{x:1574,y:910,t:1527628518248};\\\", \\\"{x:1575,y:909,t:1527628518265};\\\", \\\"{x:1576,y:909,t:1527628518295};\\\", \\\"{x:1576,y:908,t:1527628518849};\\\", \\\"{x:1574,y:908,t:1527628518864};\\\", \\\"{x:1572,y:908,t:1527628518880};\\\", \\\"{x:1570,y:909,t:1527628518897};\\\", \\\"{x:1568,y:912,t:1527628518914};\\\", \\\"{x:1567,y:913,t:1527628518931};\\\", \\\"{x:1565,y:913,t:1527628518946};\\\", \\\"{x:1564,y:913,t:1527628519000};\\\", \\\"{x:1562,y:913,t:1527628519014};\\\", \\\"{x:1559,y:913,t:1527628519030};\\\", \\\"{x:1551,y:908,t:1527628519046};\\\", \\\"{x:1542,y:902,t:1527628519064};\\\", \\\"{x:1528,y:892,t:1527628519080};\\\", \\\"{x:1516,y:886,t:1527628519097};\\\", \\\"{x:1512,y:879,t:1527628519114};\\\", \\\"{x:1512,y:873,t:1527628519131};\\\", \\\"{x:1512,y:866,t:1527628519146};\\\", \\\"{x:1518,y:858,t:1527628519163};\\\", \\\"{x:1526,y:850,t:1527628519181};\\\", \\\"{x:1529,y:846,t:1527628519197};\\\", \\\"{x:1532,y:844,t:1527628519214};\\\", \\\"{x:1533,y:840,t:1527628519230};\\\", \\\"{x:1534,y:838,t:1527628519247};\\\", \\\"{x:1534,y:833,t:1527628519264};\\\", \\\"{x:1535,y:831,t:1527628519280};\\\", \\\"{x:1535,y:830,t:1527628519304};\\\", \\\"{x:1535,y:829,t:1527628519320};\\\", \\\"{x:1535,y:828,t:1527628519336};\\\", \\\"{x:1532,y:826,t:1527628519352};\\\", \\\"{x:1530,y:826,t:1527628519364};\\\", \\\"{x:1523,y:825,t:1527628519381};\\\", \\\"{x:1515,y:822,t:1527628519397};\\\", \\\"{x:1512,y:821,t:1527628519414};\\\", \\\"{x:1509,y:820,t:1527628519431};\\\", \\\"{x:1508,y:820,t:1527628519446};\\\", \\\"{x:1506,y:820,t:1527628519504};\\\", \\\"{x:1505,y:819,t:1527628519864};\\\", \\\"{x:1505,y:818,t:1527628519929};\\\", \\\"{x:1503,y:818,t:1527628520088};\\\", \\\"{x:1501,y:818,t:1527628520098};\\\", \\\"{x:1497,y:818,t:1527628520114};\\\", \\\"{x:1492,y:820,t:1527628520131};\\\", \\\"{x:1489,y:822,t:1527628520148};\\\", \\\"{x:1488,y:822,t:1527628520164};\\\", \\\"{x:1487,y:823,t:1527628520183};\\\", \\\"{x:1486,y:823,t:1527628520224};\\\", \\\"{x:1487,y:824,t:1527628520240};\\\", \\\"{x:1489,y:824,t:1527628520256};\\\", \\\"{x:1490,y:824,t:1527628520272};\\\", \\\"{x:1492,y:825,t:1527628520281};\\\", \\\"{x:1492,y:826,t:1527628520327};\\\", \\\"{x:1492,y:827,t:1527628520504};\\\", \\\"{x:1492,y:828,t:1527628520513};\\\", \\\"{x:1492,y:829,t:1527628520544};\\\", \\\"{x:1492,y:830,t:1527628520576};\\\", \\\"{x:1492,y:831,t:1527628520592};\\\", \\\"{x:1492,y:832,t:1527628520600};\\\", \\\"{x:1491,y:832,t:1527628520614};\\\", \\\"{x:1486,y:833,t:1527628520630};\\\", \\\"{x:1475,y:833,t:1527628520647};\\\", \\\"{x:1464,y:832,t:1527628520664};\\\", \\\"{x:1452,y:828,t:1527628520680};\\\", \\\"{x:1444,y:825,t:1527628520698};\\\", \\\"{x:1434,y:821,t:1527628520715};\\\", \\\"{x:1432,y:820,t:1527628520730};\\\", \\\"{x:1431,y:819,t:1527628520747};\\\", \\\"{x:1430,y:819,t:1527628520764};\\\", \\\"{x:1430,y:817,t:1527628521713};\\\", \\\"{x:1423,y:814,t:1527628521719};\\\", \\\"{x:1419,y:814,t:1527628521731};\\\", \\\"{x:1403,y:811,t:1527628521748};\\\", \\\"{x:1397,y:811,t:1527628521765};\\\", \\\"{x:1369,y:806,t:1527628521782};\\\", \\\"{x:1318,y:798,t:1527628521798};\\\", \\\"{x:1279,y:792,t:1527628521815};\\\", \\\"{x:1240,y:784,t:1527628521832};\\\", \\\"{x:1208,y:779,t:1527628521848};\\\", \\\"{x:1177,y:773,t:1527628521865};\\\", \\\"{x:1131,y:764,t:1527628521881};\\\", \\\"{x:1089,y:757,t:1527628521897};\\\", \\\"{x:1056,y:750,t:1527628521914};\\\", \\\"{x:1031,y:745,t:1527628521931};\\\", \\\"{x:1007,y:741,t:1527628521947};\\\", \\\"{x:982,y:734,t:1527628521964};\\\", \\\"{x:954,y:724,t:1527628521981};\\\", \\\"{x:926,y:720,t:1527628521997};\\\", \\\"{x:904,y:717,t:1527628522014};\\\", \\\"{x:873,y:713,t:1527628522031};\\\", \\\"{x:855,y:712,t:1527628522047};\\\", \\\"{x:835,y:714,t:1527628522064};\\\", \\\"{x:814,y:720,t:1527628522081};\\\", \\\"{x:789,y:724,t:1527628522097};\\\", \\\"{x:766,y:727,t:1527628522114};\\\", \\\"{x:743,y:731,t:1527628522131};\\\", \\\"{x:717,y:733,t:1527628522147};\\\", \\\"{x:694,y:737,t:1527628522164};\\\", \\\"{x:675,y:738,t:1527628522182};\\\", \\\"{x:656,y:738,t:1527628522198};\\\", \\\"{x:637,y:738,t:1527628522215};\\\", \\\"{x:612,y:735,t:1527628522232};\\\", \\\"{x:602,y:734,t:1527628522247};\\\", \\\"{x:594,y:730,t:1527628522264};\\\", \\\"{x:583,y:725,t:1527628522281};\\\", \\\"{x:575,y:721,t:1527628522298};\\\", \\\"{x:565,y:713,t:1527628522314};\\\", \\\"{x:558,y:706,t:1527628522332};\\\", \\\"{x:548,y:700,t:1527628522349};\\\", \\\"{x:540,y:693,t:1527628522364};\\\", \\\"{x:529,y:688,t:1527628522380};\\\", \\\"{x:511,y:682,t:1527628522401};\\\", \\\"{x:506,y:680,t:1527628522418};\\\", \\\"{x:502,y:679,t:1527628522435};\\\", \\\"{x:500,y:678,t:1527628522452};\\\", \\\"{x:498,y:677,t:1527628522468};\\\", \\\"{x:497,y:675,t:1527628522485};\\\", \\\"{x:496,y:674,t:1527628522510};\\\", \\\"{x:495,y:674,t:1527628522519};\\\", \\\"{x:495,y:672,t:1527628522535};\\\", \\\"{x:495,y:671,t:1527628522552};\\\", \\\"{x:496,y:671,t:1527628522624};\\\", \\\"{x:497,y:671,t:1527628522640};\\\", \\\"{x:497,y:672,t:1527628522664};\\\", \\\"{x:500,y:674,t:1527628522672};\\\", \\\"{x:501,y:676,t:1527628522712};\\\", \\\"{x:502,y:677,t:1527628522727};\\\", \\\"{x:503,y:678,t:1527628522760};\\\", \\\"{x:504,y:679,t:1527628523192};\\\", \\\"{x:505,y:679,t:1527628523208};\\\", \\\"{x:506,y:679,t:1527628523224};\\\", \\\"{x:507,y:679,t:1527628523304};\\\", \\\"{x:509,y:680,t:1527628523319};\\\", \\\"{x:510,y:680,t:1527628523351};\\\", \\\"{x:511,y:680,t:1527628523369};\\\", \\\"{x:512,y:680,t:1527628523386};\\\", \\\"{x:513,y:680,t:1527628523432};\\\", \\\"{x:515,y:681,t:1527628523688};\\\", \\\"{x:516,y:681,t:1527628523712};\\\", \\\"{x:517,y:682,t:1527628523719};\\\", \\\"{x:518,y:682,t:1527628523737};\\\", \\\"{x:520,y:683,t:1527628523753};\\\", \\\"{x:521,y:683,t:1527628523770};\\\", \\\"{x:524,y:683,t:1527628523786};\\\", \\\"{x:528,y:686,t:1527628523803};\\\", \\\"{x:529,y:686,t:1527628523821};\\\", \\\"{x:530,y:687,t:1527628523836};\\\", \\\"{x:531,y:687,t:1527628523854};\\\", \\\"{x:530,y:687,t:1527628524473};\\\", \\\"{x:530,y:686,t:1527628524488};\\\", \\\"{x:531,y:684,t:1527628524503};\\\", \\\"{x:531,y:683,t:1527628524527};\\\", \\\"{x:532,y:682,t:1527628524543};\\\", \\\"{x:532,y:681,t:1527628524554};\\\", \\\"{x:533,y:680,t:1527628524608};\\\" ] }, { \\\"rt\\\": 16976, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 759126, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-02 PM-X -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:679,t:1527628527480};\\\", \\\"{x:535,y:678,t:1527628528200};\\\", \\\"{x:535,y:677,t:1527628528952};\\\", \\\"{x:539,y:677,t:1527628529920};\\\", \\\"{x:546,y:678,t:1527628529927};\\\", \\\"{x:552,y:679,t:1527628529941};\\\", \\\"{x:566,y:685,t:1527628529958};\\\", \\\"{x:587,y:690,t:1527628529974};\\\", \\\"{x:606,y:700,t:1527628529991};\\\", \\\"{x:642,y:724,t:1527628530007};\\\", \\\"{x:680,y:748,t:1527628530025};\\\", \\\"{x:711,y:765,t:1527628530041};\\\", \\\"{x:757,y:792,t:1527628530057};\\\", \\\"{x:831,y:820,t:1527628530074};\\\", \\\"{x:903,y:851,t:1527628530091};\\\", \\\"{x:978,y:885,t:1527628530107};\\\", \\\"{x:1076,y:923,t:1527628530125};\\\", \\\"{x:1177,y:955,t:1527628530142};\\\", \\\"{x:1273,y:979,t:1527628530157};\\\", \\\"{x:1350,y:988,t:1527628530174};\\\", \\\"{x:1407,y:997,t:1527628530190};\\\", \\\"{x:1450,y:997,t:1527628530208};\\\", \\\"{x:1472,y:989,t:1527628530224};\\\", \\\"{x:1488,y:980,t:1527628530241};\\\", \\\"{x:1497,y:975,t:1527628530257};\\\", \\\"{x:1506,y:969,t:1527628530275};\\\", \\\"{x:1512,y:964,t:1527628530290};\\\", \\\"{x:1517,y:960,t:1527628530307};\\\", \\\"{x:1521,y:956,t:1527628530324};\\\", \\\"{x:1524,y:953,t:1527628530341};\\\", \\\"{x:1527,y:950,t:1527628530358};\\\", \\\"{x:1532,y:947,t:1527628530375};\\\", \\\"{x:1533,y:946,t:1527628530391};\\\", \\\"{x:1535,y:945,t:1527628530408};\\\", \\\"{x:1535,y:944,t:1527628530425};\\\", \\\"{x:1535,y:943,t:1527628530471};\\\", \\\"{x:1534,y:942,t:1527628530480};\\\", \\\"{x:1533,y:942,t:1527628530491};\\\", \\\"{x:1527,y:941,t:1527628530508};\\\", \\\"{x:1519,y:940,t:1527628530525};\\\", \\\"{x:1518,y:939,t:1527628530542};\\\", \\\"{x:1509,y:934,t:1527628530558};\\\", \\\"{x:1495,y:929,t:1527628530575};\\\", \\\"{x:1483,y:922,t:1527628530592};\\\", \\\"{x:1481,y:920,t:1527628530608};\\\", \\\"{x:1481,y:918,t:1527628530624};\\\", \\\"{x:1481,y:917,t:1527628534000};\\\", \\\"{x:1481,y:913,t:1527628534011};\\\", \\\"{x:1481,y:906,t:1527628534028};\\\", \\\"{x:1481,y:899,t:1527628534044};\\\", \\\"{x:1481,y:895,t:1527628534061};\\\", \\\"{x:1481,y:892,t:1527628534077};\\\", \\\"{x:1481,y:891,t:1527628534094};\\\", \\\"{x:1481,y:890,t:1527628534111};\\\", \\\"{x:1481,y:889,t:1527628534272};\\\", \\\"{x:1481,y:888,t:1527628534280};\\\", \\\"{x:1481,y:887,t:1527628534294};\\\", \\\"{x:1481,y:883,t:1527628534311};\\\", \\\"{x:1481,y:876,t:1527628534327};\\\", \\\"{x:1481,y:871,t:1527628534344};\\\", \\\"{x:1481,y:864,t:1527628534361};\\\", \\\"{x:1481,y:860,t:1527628534378};\\\", \\\"{x:1481,y:853,t:1527628534394};\\\", \\\"{x:1481,y:846,t:1527628534411};\\\", \\\"{x:1481,y:843,t:1527628534429};\\\", \\\"{x:1481,y:837,t:1527628534444};\\\", \\\"{x:1481,y:832,t:1527628534462};\\\", \\\"{x:1481,y:831,t:1527628534478};\\\", \\\"{x:1481,y:829,t:1527628534536};\\\", \\\"{x:1481,y:827,t:1527628534551};\\\", \\\"{x:1481,y:825,t:1527628534568};\\\", \\\"{x:1481,y:823,t:1527628534578};\\\", \\\"{x:1481,y:822,t:1527628534594};\\\", \\\"{x:1481,y:819,t:1527628534612};\\\", \\\"{x:1481,y:815,t:1527628534628};\\\", \\\"{x:1481,y:812,t:1527628534644};\\\", \\\"{x:1481,y:809,t:1527628534661};\\\", \\\"{x:1481,y:807,t:1527628534678};\\\", \\\"{x:1481,y:805,t:1527628534696};\\\", \\\"{x:1481,y:804,t:1527628534711};\\\", \\\"{x:1481,y:802,t:1527628534728};\\\", \\\"{x:1482,y:801,t:1527628534746};\\\", \\\"{x:1482,y:800,t:1527628534761};\\\", \\\"{x:1484,y:798,t:1527628534778};\\\", \\\"{x:1484,y:796,t:1527628534795};\\\", \\\"{x:1484,y:793,t:1527628534811};\\\", \\\"{x:1484,y:787,t:1527628534828};\\\", \\\"{x:1484,y:784,t:1527628534845};\\\", \\\"{x:1485,y:780,t:1527628534863};\\\", \\\"{x:1485,y:777,t:1527628534878};\\\", \\\"{x:1485,y:775,t:1527628534895};\\\", \\\"{x:1485,y:773,t:1527628534911};\\\", \\\"{x:1485,y:771,t:1527628534929};\\\", \\\"{x:1485,y:770,t:1527628534947};\\\", \\\"{x:1485,y:769,t:1527628534961};\\\", \\\"{x:1485,y:768,t:1527628534978};\\\", \\\"{x:1486,y:766,t:1527628535079};\\\", \\\"{x:1486,y:764,t:1527628535096};\\\", \\\"{x:1486,y:763,t:1527628535584};\\\", \\\"{x:1486,y:759,t:1527628535607};\\\", \\\"{x:1486,y:751,t:1527628535616};\\\", \\\"{x:1486,y:740,t:1527628535629};\\\", \\\"{x:1484,y:724,t:1527628535645};\\\", \\\"{x:1482,y:713,t:1527628535662};\\\", \\\"{x:1481,y:699,t:1527628535679};\\\", \\\"{x:1480,y:697,t:1527628535696};\\\", \\\"{x:1479,y:693,t:1527628535712};\\\", \\\"{x:1479,y:690,t:1527628535729};\\\", \\\"{x:1479,y:687,t:1527628535746};\\\", \\\"{x:1479,y:682,t:1527628535762};\\\", \\\"{x:1480,y:670,t:1527628535779};\\\", \\\"{x:1482,y:653,t:1527628535795};\\\", \\\"{x:1484,y:638,t:1527628535812};\\\", \\\"{x:1485,y:621,t:1527628535830};\\\", \\\"{x:1486,y:606,t:1527628535845};\\\", \\\"{x:1486,y:587,t:1527628535862};\\\", \\\"{x:1486,y:566,t:1527628535878};\\\", \\\"{x:1487,y:560,t:1527628535894};\\\", \\\"{x:1487,y:553,t:1527628535911};\\\", \\\"{x:1487,y:548,t:1527628535928};\\\", \\\"{x:1487,y:545,t:1527628535944};\\\", \\\"{x:1487,y:543,t:1527628535962};\\\", \\\"{x:1484,y:542,t:1527628536392};\\\", \\\"{x:1473,y:547,t:1527628536400};\\\", \\\"{x:1456,y:553,t:1527628536413};\\\", \\\"{x:1388,y:569,t:1527628536429};\\\", \\\"{x:1296,y:580,t:1527628536446};\\\", \\\"{x:1208,y:580,t:1527628536462};\\\", \\\"{x:1050,y:567,t:1527628536480};\\\", \\\"{x:950,y:556,t:1527628536496};\\\", \\\"{x:886,y:535,t:1527628536514};\\\", \\\"{x:857,y:523,t:1527628536529};\\\", \\\"{x:839,y:516,t:1527628536545};\\\", \\\"{x:813,y:497,t:1527628536579};\\\", \\\"{x:800,y:486,t:1527628536597};\\\", \\\"{x:784,y:475,t:1527628536613};\\\", \\\"{x:767,y:469,t:1527628536630};\\\", \\\"{x:738,y:461,t:1527628536647};\\\", \\\"{x:716,y:460,t:1527628536664};\\\", \\\"{x:692,y:460,t:1527628536680};\\\", \\\"{x:672,y:459,t:1527628536696};\\\", \\\"{x:650,y:459,t:1527628536713};\\\", \\\"{x:627,y:459,t:1527628536730};\\\", \\\"{x:602,y:459,t:1527628536746};\\\", \\\"{x:588,y:460,t:1527628536763};\\\", \\\"{x:576,y:462,t:1527628536780};\\\", \\\"{x:570,y:463,t:1527628536796};\\\", \\\"{x:569,y:463,t:1527628536813};\\\", \\\"{x:568,y:464,t:1527628536831};\\\", \\\"{x:568,y:465,t:1527628536847};\\\", \\\"{x:568,y:466,t:1527628536944};\\\", \\\"{x:568,y:468,t:1527628536951};\\\", \\\"{x:568,y:471,t:1527628536964};\\\", \\\"{x:572,y:484,t:1527628536980};\\\", \\\"{x:583,y:502,t:1527628536997};\\\", \\\"{x:596,y:515,t:1527628537012};\\\", \\\"{x:609,y:523,t:1527628537030};\\\", \\\"{x:617,y:526,t:1527628537047};\\\", \\\"{x:619,y:526,t:1527628537064};\\\", \\\"{x:620,y:526,t:1527628537079};\\\", \\\"{x:622,y:526,t:1527628537097};\\\", \\\"{x:623,y:526,t:1527628537184};\\\", \\\"{x:622,y:525,t:1527628537197};\\\", \\\"{x:593,y:519,t:1527628537215};\\\", \\\"{x:535,y:512,t:1527628537231};\\\", \\\"{x:447,y:501,t:1527628537246};\\\", \\\"{x:420,y:499,t:1527628537263};\\\", \\\"{x:408,y:499,t:1527628537280};\\\", \\\"{x:404,y:499,t:1527628537296};\\\", \\\"{x:403,y:499,t:1527628537415};\\\", \\\"{x:403,y:500,t:1527628537431};\\\", \\\"{x:403,y:503,t:1527628537447};\\\", \\\"{x:401,y:507,t:1527628537464};\\\", \\\"{x:399,y:511,t:1527628537482};\\\", \\\"{x:397,y:515,t:1527628537497};\\\", \\\"{x:396,y:516,t:1527628537514};\\\", \\\"{x:395,y:517,t:1527628537530};\\\", \\\"{x:395,y:518,t:1527628537551};\\\", \\\"{x:394,y:519,t:1527628537563};\\\", \\\"{x:393,y:520,t:1527628537582};\\\", \\\"{x:392,y:521,t:1527628537599};\\\", \\\"{x:392,y:524,t:1527628537615};\\\", \\\"{x:392,y:527,t:1527628537631};\\\", \\\"{x:392,y:528,t:1527628537646};\\\", \\\"{x:392,y:530,t:1527628537664};\\\", \\\"{x:392,y:531,t:1527628537680};\\\", \\\"{x:392,y:533,t:1527628537711};\\\", \\\"{x:392,y:534,t:1527628537727};\\\", \\\"{x:391,y:534,t:1527628537735};\\\", \\\"{x:390,y:536,t:1527628537747};\\\", \\\"{x:390,y:537,t:1527628537764};\\\", \\\"{x:390,y:538,t:1527628537783};\\\", \\\"{x:389,y:538,t:1527628537799};\\\", \\\"{x:393,y:541,t:1527628539088};\\\", \\\"{x:423,y:548,t:1527628539099};\\\", \\\"{x:558,y:585,t:1527628539114};\\\", \\\"{x:716,y:634,t:1527628539132};\\\", \\\"{x:884,y:681,t:1527628539148};\\\", \\\"{x:1039,y:723,t:1527628539164};\\\", \\\"{x:1174,y:757,t:1527628539181};\\\", \\\"{x:1257,y:780,t:1527628539198};\\\", \\\"{x:1302,y:795,t:1527628539214};\\\", \\\"{x:1309,y:796,t:1527628539232};\\\", \\\"{x:1312,y:798,t:1527628539247};\\\", \\\"{x:1314,y:799,t:1527628539264};\\\", \\\"{x:1319,y:803,t:1527628539281};\\\", \\\"{x:1328,y:812,t:1527628539298};\\\", \\\"{x:1345,y:825,t:1527628539315};\\\", \\\"{x:1390,y:853,t:1527628539331};\\\", \\\"{x:1434,y:873,t:1527628539349};\\\", \\\"{x:1469,y:890,t:1527628539364};\\\", \\\"{x:1485,y:901,t:1527628539382};\\\", \\\"{x:1488,y:902,t:1527628539399};\\\", \\\"{x:1487,y:902,t:1527628539464};\\\", \\\"{x:1486,y:902,t:1527628539483};\\\", \\\"{x:1485,y:899,t:1527628539499};\\\", \\\"{x:1485,y:897,t:1527628539515};\\\", \\\"{x:1485,y:895,t:1527628539532};\\\", \\\"{x:1483,y:895,t:1527628539640};\\\", \\\"{x:1482,y:897,t:1527628539649};\\\", \\\"{x:1479,y:902,t:1527628539665};\\\", \\\"{x:1478,y:907,t:1527628539682};\\\", \\\"{x:1477,y:913,t:1527628539699};\\\", \\\"{x:1477,y:915,t:1527628539717};\\\", \\\"{x:1477,y:916,t:1527628539733};\\\", \\\"{x:1477,y:917,t:1527628540200};\\\", \\\"{x:1477,y:916,t:1527628540216};\\\", \\\"{x:1478,y:914,t:1527628541208};\\\", \\\"{x:1480,y:907,t:1527628541218};\\\", \\\"{x:1488,y:893,t:1527628541234};\\\", \\\"{x:1492,y:882,t:1527628541251};\\\", \\\"{x:1498,y:867,t:1527628541267};\\\", \\\"{x:1500,y:854,t:1527628541284};\\\", \\\"{x:1501,y:844,t:1527628541300};\\\", \\\"{x:1501,y:835,t:1527628541317};\\\", \\\"{x:1501,y:830,t:1527628541334};\\\", \\\"{x:1501,y:822,t:1527628541350};\\\", \\\"{x:1501,y:804,t:1527628541367};\\\", \\\"{x:1501,y:795,t:1527628541383};\\\", \\\"{x:1501,y:789,t:1527628541401};\\\", \\\"{x:1498,y:783,t:1527628541417};\\\", \\\"{x:1488,y:771,t:1527628541434};\\\", \\\"{x:1467,y:756,t:1527628541450};\\\", \\\"{x:1419,y:731,t:1527628541467};\\\", \\\"{x:1336,y:695,t:1527628541485};\\\", \\\"{x:1241,y:663,t:1527628541500};\\\", \\\"{x:1162,y:631,t:1527628541518};\\\", \\\"{x:1098,y:614,t:1527628541534};\\\", \\\"{x:1053,y:598,t:1527628541550};\\\", \\\"{x:993,y:580,t:1527628541567};\\\", \\\"{x:971,y:575,t:1527628541584};\\\", \\\"{x:957,y:573,t:1527628541599};\\\", \\\"{x:946,y:572,t:1527628541617};\\\", \\\"{x:935,y:572,t:1527628541633};\\\", \\\"{x:926,y:571,t:1527628541649};\\\", \\\"{x:916,y:571,t:1527628541664};\\\", \\\"{x:903,y:571,t:1527628541681};\\\", \\\"{x:886,y:571,t:1527628541697};\\\", \\\"{x:867,y:571,t:1527628541714};\\\", \\\"{x:843,y:571,t:1527628541730};\\\", \\\"{x:819,y:567,t:1527628541749};\\\", \\\"{x:791,y:563,t:1527628541766};\\\", \\\"{x:779,y:562,t:1527628541784};\\\", \\\"{x:773,y:561,t:1527628541800};\\\", \\\"{x:767,y:560,t:1527628541816};\\\", \\\"{x:752,y:559,t:1527628541834};\\\", \\\"{x:734,y:558,t:1527628541849};\\\", \\\"{x:716,y:558,t:1527628541867};\\\", \\\"{x:698,y:556,t:1527628541884};\\\", \\\"{x:681,y:553,t:1527628541901};\\\", \\\"{x:674,y:553,t:1527628541917};\\\", \\\"{x:666,y:553,t:1527628541934};\\\", \\\"{x:656,y:553,t:1527628541950};\\\", \\\"{x:648,y:554,t:1527628541967};\\\", \\\"{x:640,y:557,t:1527628541985};\\\", \\\"{x:632,y:560,t:1527628542001};\\\", \\\"{x:629,y:560,t:1527628542016};\\\", \\\"{x:627,y:561,t:1527628542034};\\\", \\\"{x:625,y:563,t:1527628542052};\\\", \\\"{x:622,y:563,t:1527628542067};\\\", \\\"{x:618,y:563,t:1527628542084};\\\", \\\"{x:613,y:563,t:1527628542100};\\\", \\\"{x:609,y:563,t:1527628542117};\\\", \\\"{x:608,y:563,t:1527628542134};\\\", \\\"{x:607,y:560,t:1527628542153};\\\", \\\"{x:607,y:558,t:1527628542167};\\\", \\\"{x:607,y:557,t:1527628542183};\\\", \\\"{x:607,y:555,t:1527628542200};\\\", \\\"{x:607,y:554,t:1527628542217};\\\", \\\"{x:608,y:553,t:1527628542234};\\\", \\\"{x:608,y:552,t:1527628542251};\\\", \\\"{x:610,y:551,t:1527628542267};\\\", \\\"{x:612,y:550,t:1527628542284};\\\", \\\"{x:616,y:549,t:1527628542301};\\\", \\\"{x:617,y:548,t:1527628542317};\\\", \\\"{x:617,y:550,t:1527628542639};\\\", \\\"{x:616,y:558,t:1527628542652};\\\", \\\"{x:612,y:571,t:1527628542668};\\\", \\\"{x:606,y:592,t:1527628542684};\\\", \\\"{x:595,y:616,t:1527628542701};\\\", \\\"{x:588,y:628,t:1527628542718};\\\", \\\"{x:580,y:641,t:1527628542733};\\\", \\\"{x:575,y:650,t:1527628542751};\\\", \\\"{x:574,y:650,t:1527628542767};\\\", \\\"{x:573,y:652,t:1527628542783};\\\", \\\"{x:572,y:654,t:1527628542801};\\\", \\\"{x:569,y:656,t:1527628542817};\\\", \\\"{x:566,y:658,t:1527628542834};\\\", \\\"{x:563,y:660,t:1527628542851};\\\", \\\"{x:561,y:662,t:1527628542867};\\\", \\\"{x:557,y:668,t:1527628542884};\\\", \\\"{x:554,y:673,t:1527628542901};\\\", \\\"{x:550,y:679,t:1527628542918};\\\", \\\"{x:546,y:691,t:1527628542936};\\\", \\\"{x:542,y:701,t:1527628542950};\\\", \\\"{x:541,y:704,t:1527628542968};\\\", \\\"{x:541,y:705,t:1527628542984};\\\" ] }, { \\\"rt\\\": 88198, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 848593, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Look at the diagonal line starting at 12pm to the right, and find the dots that line up on that diagonal line, so that would be M and L.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6298, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"23\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"China\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 855898, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 25883, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 882802, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 28902, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 913050, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"NN1Z0\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"NN1Z0\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 217, dom: 637, initialDom: 730",
  "javascriptErrors": []
}