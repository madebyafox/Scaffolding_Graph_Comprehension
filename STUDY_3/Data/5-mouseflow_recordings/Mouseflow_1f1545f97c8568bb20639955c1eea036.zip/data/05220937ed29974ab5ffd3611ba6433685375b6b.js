var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05220937ed29974ab5ffd3611ba6433685375b6b"] = {
  "startTime": "2018-05-22T17:21:09.814156Z",
  "websitePageUrl": "/16",
  "visitTime": 72820,
  "engagementTime": 72718,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "1f1545f97c8568bb20639955c1eea036",
    "created": "2018-05-22T17:21:09.814156+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=808YR",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "b2fd5a08e1bf3bd5a92c2f9d7fdf572c",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/1f1545f97c8568bb20639955c1eea036/play"
  },
  "events": [
    {
      "t": 2,
      "e": 2,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 249,
      "e": 249,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 249,
      "e": 249,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 1190,
      "y": 950
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 28470,
      "y": 58157,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 1140,
      "y": 906
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 1037,
      "y": 864
    },
    {
      "t": 1752,
      "e": 1752,
      "ty": 41,
      "x": 3806,
      "y": 47844,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 1802,
      "e": 1802,
      "ty": 2,
      "x": 692,
      "y": 748
    },
    {
      "t": 1894,
      "e": 1894,
      "ty": 6,
      "x": 362,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1902,
      "e": 1902,
      "ty": 2,
      "x": 362,
      "y": 602
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 2,
      "x": 244,
      "y": 557
    },
    {
      "t": 2002,
      "e": 2002,
      "ty": 41,
      "x": 16513,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2210,
      "e": 2210,
      "ty": 3,
      "x": 244,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2211,
      "e": 2211,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2283,
      "e": 2283,
      "ty": 4,
      "x": 16513,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2283,
      "e": 2283,
      "ty": 5,
      "x": 244,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6447,
      "e": 6447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 6448,
      "e": 6448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6603,
      "e": 6603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 6678,
      "e": 6678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 7351,
      "e": 7351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 7503,
      "e": 7503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 8671,
      "e": 8671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 8671,
      "e": 8671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8774,
      "e": 8774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 8775,
      "e": 8775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8822,
      "e": 8822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "on"
    },
    {
      "t": 8871,
      "e": 8871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8871,
      "e": 8871,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8918,
      "e": 8918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "on "
    },
    {
      "t": 8942,
      "e": 8942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "on "
    },
    {
      "t": 9021,
      "e": 9021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9021,
      "e": 9021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9110,
      "e": 9110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 9110,
      "e": 9110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9158,
      "e": 9158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "on th"
    },
    {
      "t": 9246,
      "e": 9246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 9247,
      "e": 9247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9255,
      "e": 9255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 9343,
      "e": 9343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9346,
      "e": 9346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9366,
      "e": 9366,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9462,
      "e": 9462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9782,
      "e": 9782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 9782,
      "e": 9782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9910,
      "e": 9910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10102,
      "e": 10102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10102,
      "e": 10102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10203,
      "e": 10203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "on the x "
    },
    {
      "t": 10238,
      "e": 10238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10487,
      "e": 10487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10488,
      "e": 10488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10603,
      "e": 10603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "on the x a"
    },
    {
      "t": 10622,
      "e": 10622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 11807,
      "e": 11807,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 11807,
      "e": 11807,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11918,
      "e": 11918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 11926,
      "e": 11926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 11926,
      "e": 11926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12062,
      "e": 12062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 12087,
      "e": 12087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 12087,
      "e": 12087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12190,
      "e": 12190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12191,
      "e": 12191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12230,
      "e": 12230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 12310,
      "e": 12310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12958,
      "e": 12958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 12959,
      "e": 12959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13054,
      "e": 13054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13054,
      "e": 13054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13078,
      "e": 13078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||go"
    },
    {
      "t": 13175,
      "e": 13175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13175,
      "e": 13175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13176,
      "e": 13176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13286,
      "e": 13286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13310,
      "e": 13310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13310,
      "e": 13310,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13390,
      "e": 13390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13391,
      "e": 13391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13438,
      "e": 13438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 13479,
      "e": 13479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13479,
      "e": 13479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13518,
      "e": 13518,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13607,
      "e": 13607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14055,
      "e": 14055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 14055,
      "e": 14055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14134,
      "e": 14134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 14134,
      "e": 14134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14241,
      "e": 14241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 14306,
      "e": 14306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14307,
      "e": 14307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14314,
      "e": 14314,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14401,
      "e": 14401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14473,
      "e": 14473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 14473,
      "e": 14473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14602,
      "e": 14602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 14843,
      "e": 14843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 14843,
      "e": 14843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15006,
      "e": 15006,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "on the x axis go to 12 pm"
    },
    {
      "t": 15050,
      "e": 15050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 15210,
      "e": 15210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15211,
      "e": 15211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15330,
      "e": 15330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15410,
      "e": 15410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15411,
      "e": 15411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15545,
      "e": 15545,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 15546,
      "e": 15546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15610,
      "e": 15610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 15610,
      "e": 15610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15618,
      "e": 15618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||and"
    },
    {
      "t": 15658,
      "e": 15658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15682,
      "e": 15682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15682,
      "e": 15682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15753,
      "e": 15753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15842,
      "e": 15842,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15842,
      "e": 15842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 15842,
      "e": 15842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15922,
      "e": 15922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15923,
      "e": 15923,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16002,
      "e": 16002,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||mo"
    },
    {
      "t": 16034,
      "e": 16034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 16034,
      "e": 16034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16049,
      "e": 16049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 16130,
      "e": 16130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16265,
      "e": 16265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16265,
      "e": 16265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16321,
      "e": 16321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16321,
      "e": 16321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16394,
      "e": 16394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 16442,
      "e": 16442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 16442,
      "e": 16442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16458,
      "e": 16458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 16562,
      "e": 16562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 16563,
      "e": 16563,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16633,
      "e": 16633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 16746,
      "e": 16746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16858,
      "e": 16858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 16860,
      "e": 16860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17008,
      "e": 17008,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "on the x axis go to 12 pm and move upw"
    },
    {
      "t": 17010,
      "e": 17010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17011,
      "e": 17011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17090,
      "e": 17090,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wa"
    },
    {
      "t": 17122,
      "e": 17122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 17123,
      "e": 17123,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17201,
      "e": 17201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 17250,
      "e": 17250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17379,
      "e": 17379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 17379,
      "e": 17379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17450,
      "e": 17450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17450,
      "e": 17450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17497,
      "e": 17497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 17521,
      "e": 17521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17521,
      "e": 17521,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17578,
      "e": 17578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17698,
      "e": 17698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19658,
      "e": 19658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 19659,
      "e": 19659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19722,
      "e": 19722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 19874,
      "e": 19874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19874,
      "e": 19874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19994,
      "e": 19994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 20002,
      "e": 20002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20003,
      "e": 20003,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20006,
      "e": 20006,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20105,
      "e": 20105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20106,
      "e": 20106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20138,
      "e": 20138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 20162,
      "e": 20162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 20162,
      "e": 20162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20233,
      "e": 20233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 20281,
      "e": 20281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20282,
      "e": 20282,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20378,
      "e": 20378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20451,
      "e": 20451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20578,
      "e": 20578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 20579,
      "e": 20579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20762,
      "e": 20762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20763,
      "e": 20763,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20785,
      "e": 20785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 20857,
      "e": 20857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20857,
      "e": 20857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20898,
      "e": 20898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 20954,
      "e": 20954,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21114,
      "e": 21114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 21115,
      "e": 21115,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21217,
      "e": 21217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 21217,
      "e": 21217,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21233,
      "e": 21233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ch"
    },
    {
      "t": 21298,
      "e": 21298,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21354,
      "e": 21354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 21355,
      "e": 21355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21466,
      "e": 21466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21466,
      "e": 21466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21498,
      "e": 21498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 21546,
      "e": 21546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 21546,
      "e": 21546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21578,
      "e": 21578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21578,
      "e": 21578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21625,
      "e": 21625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g "
    },
    {
      "t": 21634,
      "e": 21634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21690,
      "e": 21690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21738,
      "e": 21738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21739,
      "e": 21739,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21802,
      "e": 21802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21802,
      "e": 21802,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21849,
      "e": 21849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a "
    },
    {
      "t": 21906,
      "e": 21906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 21906,
      "e": 21906,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21953,
      "e": 21953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 22010,
      "e": 22010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22010,
      "e": 22010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22050,
      "e": 22050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 22129,
      "e": 22129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22234,
      "e": 22234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22235,
      "e": 22235,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22305,
      "e": 22305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 22407,
      "e": 22407,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "on the x axis go to 12 pm and move upwards until reaching a let"
    },
    {
      "t": 22410,
      "e": 22410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22410,
      "e": 22410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22514,
      "e": 22514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 22618,
      "e": 22618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22619,
      "e": 22619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22722,
      "e": 22722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22722,
      "e": 22722,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22777,
      "e": 22777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22777,
      "e": 22777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22802,
      "e": 22802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er "
    },
    {
      "t": 22866,
      "e": 22866,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22874,
      "e": 22874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22882,
      "e": 22882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22883,
      "e": 22883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23001,
      "e": 23001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23001,
      "e": 23001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23041,
      "e": 23041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 23138,
      "e": 23138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 23138,
      "e": 23138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23146,
      "e": 23146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 23209,
      "e": 23209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23209,
      "e": 23209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23258,
      "e": 23258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 23313,
      "e": 23313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23514,
      "e": 23514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 23515,
      "e": 23515,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23577,
      "e": 23577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 23889,
      "e": 23889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23889,
      "e": 23889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24001,
      "e": 24001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 24049,
      "e": 24049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24050,
      "e": 24050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24153,
      "e": 24153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24161,
      "e": 24161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24162,
      "e": 24162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24274,
      "e": 24274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24275,
      "e": 24275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24321,
      "e": 24321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 24370,
      "e": 24370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 24370,
      "e": 24370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24433,
      "e": 24433,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24433,
      "e": 24433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24465,
      "e": 24465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g "
    },
    {
      "t": 24473,
      "e": 24473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24562,
      "e": 24562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24578,
      "e": 24578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 24578,
      "e": 24578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24649,
      "e": 24649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24650,
      "e": 24650,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24681,
      "e": 24681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 24762,
      "e": 24762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24769,
      "e": 24769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24769,
      "e": 24769,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24890,
      "e": 24890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25002,
      "e": 25002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25004,
      "e": 25004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25089,
      "e": 25089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 25218,
      "e": 25218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 25219,
      "e": 25219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25273,
      "e": 25273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 25406,
      "e": 25406,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "on the x axis go to 12 pm and move upwards until reaching a letter indicating an ev"
    },
    {
      "t": 25425,
      "e": 25425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25426,
      "e": 25425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25530,
      "e": 25529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 25538,
      "e": 25537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 25538,
      "e": 25537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25625,
      "e": 25624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25625,
      "e": 25624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25633,
      "e": 25632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 25689,
      "e": 25688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25689,
      "e": 25688,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25705,
      "e": 25704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25794,
      "e": 25793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25834,
      "e": 25833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25835,
      "e": 25834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25906,
      "e": 25905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25906,
      "e": 25905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25929,
      "e": 25928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 26017,
      "e": 26016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26018,
      "e": 26017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26018,
      "e": 26017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26090,
      "e": 26089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26091,
      "e": 26090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26138,
      "e": 26137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26138,
      "e": 26137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26145,
      "e": 26144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at "
    },
    {
      "t": 26194,
      "e": 26193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26209,
      "e": 26208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26210,
      "e": 26209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26241,
      "e": 26240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 26322,
      "e": 26321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 26322,
      "e": 26321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26329,
      "e": 26328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 26410,
      "e": 26409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26410,
      "e": 26409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26417,
      "e": 26416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26497,
      "e": 26496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 26498,
      "e": 26497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26537,
      "e": 26536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 26609,
      "e": 26608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26626,
      "e": 26625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26626,
      "e": 26625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26705,
      "e": 26704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 26705,
      "e": 26704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26729,
      "e": 26728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ap"
    },
    {
      "t": 26753,
      "e": 26752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26865,
      "e": 26864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 26866,
      "e": 26865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26945,
      "e": 26944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 26953,
      "e": 26952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26953,
      "e": 26952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27009,
      "e": 27008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27010,
      "e": 27009,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27057,
      "e": 27056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 27105,
      "e": 27104,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27154,
      "e": 27153,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27155,
      "e": 27154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27249,
      "e": 27248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27250,
      "e": 27249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27281,
      "e": 27280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 27321,
      "e": 27320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 27321,
      "e": 27320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27386,
      "e": 27385,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27387,
      "e": 27386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27402,
      "e": 27401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g "
    },
    {
      "t": 27458,
      "e": 27457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27514,
      "e": 27513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27578,
      "e": 27577,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27578,
      "e": 27577,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27673,
      "e": 27672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27673,
      "e": 27672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27721,
      "e": 27720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 27793,
      "e": 27792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27793,
      "e": 27792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27818,
      "e": 27817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27930,
      "e": 27929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28122,
      "e": 28121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 28122,
      "e": 28121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28233,
      "e": 28232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 28234,
      "e": 28233,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28290,
      "e": 28289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 28370,
      "e": 28369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28794,
      "e": 28793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 28795,
      "e": 28794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28906,
      "e": 28905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 28906,
      "e": 28905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28913,
      "e": 28912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 29034,
      "e": 29033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29705,
      "e": 29704,
      "ty": 2,
      "x": 244,
      "y": 554
    },
    {
      "t": 29756,
      "e": 29755,
      "ty": 41,
      "x": 20785,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29805,
      "e": 29804,
      "ty": 2,
      "x": 293,
      "y": 567
    },
    {
      "t": 29821,
      "e": 29820,
      "ty": 7,
      "x": 321,
      "y": 608,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29904,
      "e": 29903,
      "ty": 2,
      "x": 346,
      "y": 647
    },
    {
      "t": 30005,
      "e": 30004,
      "ty": 2,
      "x": 359,
      "y": 653
    },
    {
      "t": 30005,
      "e": 30004,
      "ty": 41,
      "x": 18914,
      "y": 20489,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 30006,
      "e": 30005,
      "ty": 6,
      "x": 371,
      "y": 663,
      "ta": "#strategyButton"
    },
    {
      "t": 30105,
      "e": 30104,
      "ty": 2,
      "x": 375,
      "y": 664
    },
    {
      "t": 30205,
      "e": 30204,
      "ty": 2,
      "x": 387,
      "y": 678
    },
    {
      "t": 30206,
      "e": 30205,
      "ty": 3,
      "x": 387,
      "y": 678,
      "ta": "#strategyButton"
    },
    {
      "t": 30206,
      "e": 30205,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "on the x axis go to 12 pm and move upwards until reaching a letter indicating an event that is happening at 12pm"
    },
    {
      "t": 30207,
      "e": 30206,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30207,
      "e": 30206,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 30254,
      "e": 30253,
      "ty": 41,
      "x": 26435,
      "y": 44844,
      "ta": "#strategyButton"
    },
    {
      "t": 30277,
      "e": 30276,
      "ty": 4,
      "x": 26435,
      "y": 44844,
      "ta": "#strategyButton"
    },
    {
      "t": 30287,
      "e": 30286,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 30288,
      "e": 30287,
      "ty": 5,
      "x": 387,
      "y": 678,
      "ta": "#strategyButton"
    },
    {
      "t": 30292,
      "e": 30291,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 30505,
      "e": 30504,
      "ty": 2,
      "x": 387,
      "y": 680
    },
    {
      "t": 30505,
      "e": 30504,
      "ty": 41,
      "x": 13051,
      "y": 37226,
      "ta": "html > body"
    },
    {
      "t": 31255,
      "e": 31254,
      "ty": 41,
      "x": 13361,
      "y": 37060,
      "ta": "html > body"
    },
    {
      "t": 31290,
      "e": 31289,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 31304,
      "e": 31303,
      "ty": 2,
      "x": 399,
      "y": 671
    },
    {
      "t": 31404,
      "e": 31403,
      "ty": 2,
      "x": 409,
      "y": 659
    },
    {
      "t": 31505,
      "e": 31504,
      "ty": 2,
      "x": 456,
      "y": 634
    },
    {
      "t": 31505,
      "e": 31504,
      "ty": 41,
      "x": 15428,
      "y": 34678,
      "ta": "html > body"
    },
    {
      "t": 31557,
      "e": 31505,
      "ty": 6,
      "x": 857,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 31605,
      "e": 31553,
      "ty": 2,
      "x": 894,
      "y": 573
    },
    {
      "t": 31704,
      "e": 31652,
      "ty": 2,
      "x": 903,
      "y": 570
    },
    {
      "t": 31754,
      "e": 31702,
      "ty": 41,
      "x": 24224,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 31789,
      "e": 31737,
      "ty": 7,
      "x": 947,
      "y": 545,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 31804,
      "e": 31752,
      "ty": 2,
      "x": 947,
      "y": 545
    },
    {
      "t": 31905,
      "e": 31853,
      "ty": 2,
      "x": 961,
      "y": 534
    },
    {
      "t": 32005,
      "e": 31953,
      "ty": 41,
      "x": 33091,
      "y": 60853,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 32104,
      "e": 32052,
      "ty": 2,
      "x": 961,
      "y": 549
    },
    {
      "t": 32205,
      "e": 32153,
      "ty": 2,
      "x": 961,
      "y": 551
    },
    {
      "t": 32254,
      "e": 32202,
      "ty": 41,
      "x": 32875,
      "y": 44394,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 32263,
      "e": 32211,
      "ty": 6,
      "x": 960,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32305,
      "e": 32253,
      "ty": 2,
      "x": 960,
      "y": 557
    },
    {
      "t": 32405,
      "e": 32353,
      "ty": 2,
      "x": 956,
      "y": 566
    },
    {
      "t": 32505,
      "e": 32453,
      "ty": 41,
      "x": 32010,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32534,
      "e": 32482,
      "ty": 3,
      "x": 956,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32536,
      "e": 32484,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32605,
      "e": 32553,
      "ty": 2,
      "x": 958,
      "y": 566
    },
    {
      "t": 32629,
      "e": 32577,
      "ty": 4,
      "x": 32443,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32630,
      "e": 32578,
      "ty": 5,
      "x": 958,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32755,
      "e": 32703,
      "ty": 41,
      "x": 32443,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33474,
      "e": 33422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 33474,
      "e": 33422,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33545,
      "e": 33493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 33649,
      "e": 33597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 33650,
      "e": 33598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 33697,
      "e": 33645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 33806,
      "e": 33754,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 34204,
      "e": 34152,
      "ty": 2,
      "x": 950,
      "y": 566
    },
    {
      "t": 34242,
      "e": 34190,
      "ty": 7,
      "x": 924,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34255,
      "e": 34203,
      "ty": 41,
      "x": 25089,
      "y": 59897,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 34304,
      "e": 34252,
      "ty": 2,
      "x": 918,
      "y": 580
    },
    {
      "t": 34405,
      "e": 34353,
      "ty": 2,
      "x": 921,
      "y": 636
    },
    {
      "t": 34442,
      "e": 34390,
      "ty": 6,
      "x": 918,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34475,
      "e": 34423,
      "ty": 7,
      "x": 909,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34493,
      "e": 34441,
      "ty": 6,
      "x": 908,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 34505,
      "e": 34453,
      "ty": 2,
      "x": 908,
      "y": 677
    },
    {
      "t": 34505,
      "e": 34453,
      "ty": 41,
      "x": 6224,
      "y": 1985,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 34604,
      "e": 34552,
      "ty": 2,
      "x": 906,
      "y": 680
    },
    {
      "t": 34678,
      "e": 34626,
      "ty": 7,
      "x": 906,
      "y": 675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 34705,
      "e": 34653,
      "ty": 2,
      "x": 906,
      "y": 673
    },
    {
      "t": 34708,
      "e": 34656,
      "ty": 6,
      "x": 909,
      "y": 664,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34755,
      "e": 34703,
      "ty": 41,
      "x": 22277,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 34805,
      "e": 34753,
      "ty": 2,
      "x": 911,
      "y": 655
    },
    {
      "t": 35063,
      "e": 35011,
      "ty": 3,
      "x": 911,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35063,
      "e": 35011,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 35064,
      "e": 35012,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35065,
      "e": 35013,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35101,
      "e": 35049,
      "ty": 4,
      "x": 22277,
      "y": 24965,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35101,
      "e": 35049,
      "ty": 5,
      "x": 911,
      "y": 655,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35882,
      "e": 35830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 36002,
      "e": 35950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 36003,
      "e": 35951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36073,
      "e": 36021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 36105,
      "e": 36053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 36642,
      "e": 36590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 36643,
      "e": 36591,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36777,
      "e": 36725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 36778,
      "e": 36726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36817,
      "e": 36765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 36914,
      "e": 36862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 36914,
      "e": 36862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 36922,
      "e": 36870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 37026,
      "e": 36974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 37138,
      "e": 37086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 37138,
      "e": 37086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37234,
      "e": 37182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 37395,
      "e": 37343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 37395,
      "e": 37343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37482,
      "e": 37430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 37482,
      "e": 37430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37522,
      "e": 37470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d "
    },
    {
      "t": 37569,
      "e": 37517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 37626,
      "e": 37574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 37658,
      "e": 37606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 37658,
      "e": 37606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37737,
      "e": 37685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 37769,
      "e": 37717,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 37769,
      "e": 37717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 37809,
      "e": 37757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 37882,
      "e": 37830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 37962,
      "e": 37910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 37963,
      "e": 37911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38082,
      "e": 38030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 38083,
      "e": 38031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38105,
      "e": 38053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||at"
    },
    {
      "t": 38206,
      "e": 38154,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United Stat"
    },
    {
      "t": 38234,
      "e": 38182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 38234,
      "e": 38182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38297,
      "e": 38245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 38321,
      "e": 38269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 38322,
      "e": 38270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38402,
      "e": 38350,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 38402,
      "e": 38350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 38403,
      "e": 38351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38473,
      "e": 38421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 38489,
      "e": 38437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 38489,
      "e": 38437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38545,
      "e": 38493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||o"
    },
    {
      "t": 38602,
      "e": 38550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "70"
    },
    {
      "t": 38602,
      "e": 38550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38617,
      "e": 38565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||f"
    },
    {
      "t": 38713,
      "e": 38661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 38721,
      "e": 38669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 38721,
      "e": 38669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38785,
      "e": 38733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 38817,
      "e": 38765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 38921,
      "e": 38869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 38922,
      "e": 38870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38977,
      "e": 38925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||A"
    },
    {
      "t": 39057,
      "e": 39005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 39113,
      "e": 39061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 39114,
      "e": 39062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39202,
      "e": 39150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||m"
    },
    {
      "t": 39210,
      "e": 39158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 39211,
      "e": 39159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39265,
      "e": 39213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 39265,
      "e": 39213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39313,
      "e": 39261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||er"
    },
    {
      "t": 39377,
      "e": 39325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 39379,
      "e": 39325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39385,
      "e": 39331,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 39473,
      "e": 39419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 39521,
      "e": 39467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 39522,
      "e": 39468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39642,
      "e": 39588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||c"
    },
    {
      "t": 39706,
      "e": 39652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 39707,
      "e": 39653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39786,
      "e": 39732,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 40405,
      "e": 40351,
      "ty": 2,
      "x": 917,
      "y": 666
    },
    {
      "t": 40414,
      "e": 40360,
      "ty": 7,
      "x": 923,
      "y": 675,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40430,
      "e": 40376,
      "ty": 6,
      "x": 924,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40505,
      "e": 40451,
      "ty": 2,
      "x": 932,
      "y": 689
    },
    {
      "t": 40505,
      "e": 40451,
      "ty": 41,
      "x": 18594,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40605,
      "e": 40551,
      "ty": 2,
      "x": 937,
      "y": 696
    },
    {
      "t": 40646,
      "e": 40592,
      "ty": 3,
      "x": 937,
      "y": 696,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40646,
      "e": 40592,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States of America"
    },
    {
      "t": 40647,
      "e": 40593,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40647,
      "e": 40593,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40718,
      "e": 40664,
      "ty": 4,
      "x": 21171,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40720,
      "e": 40666,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40721,
      "e": 40667,
      "ty": 5,
      "x": 937,
      "y": 696,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40722,
      "e": 40668,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 40755,
      "e": 40701,
      "ty": 41,
      "x": 31992,
      "y": 38113,
      "ta": "html > body"
    },
    {
      "t": 41405,
      "e": 41351,
      "ty": 2,
      "x": 937,
      "y": 693
    },
    {
      "t": 41505,
      "e": 41451,
      "ty": 41,
      "x": 31992,
      "y": 37947,
      "ta": "html > body"
    },
    {
      "t": 41739,
      "e": 41685,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 42405,
      "e": 42351,
      "ty": 2,
      "x": 959,
      "y": 631
    },
    {
      "t": 42505,
      "e": 42451,
      "ty": 2,
      "x": 1050,
      "y": 241
    },
    {
      "t": 42506,
      "e": 42452,
      "ty": 41,
      "x": 54247,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 42605,
      "e": 42551,
      "ty": 2,
      "x": 1050,
      "y": 16
    },
    {
      "t": 42705,
      "e": 42651,
      "ty": 2,
      "x": 1039,
      "y": 18
    },
    {
      "t": 42756,
      "e": 42702,
      "ty": 41,
      "x": 34747,
      "y": 1495,
      "ta": "html > body"
    },
    {
      "t": 42805,
      "e": 42751,
      "ty": 2,
      "x": 1009,
      "y": 60
    },
    {
      "t": 42905,
      "e": 42851,
      "ty": 2,
      "x": 969,
      "y": 160
    },
    {
      "t": 43006,
      "e": 42952,
      "ty": 2,
      "x": 947,
      "y": 188
    },
    {
      "t": 43006,
      "e": 42952,
      "ty": 41,
      "x": 29802,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 43105,
      "e": 43051,
      "ty": 2,
      "x": 931,
      "y": 196
    },
    {
      "t": 43205,
      "e": 43151,
      "ty": 2,
      "x": 920,
      "y": 199
    },
    {
      "t": 43256,
      "e": 43202,
      "ty": 41,
      "x": 18648,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 43305,
      "e": 43251,
      "ty": 2,
      "x": 887,
      "y": 208
    },
    {
      "t": 43405,
      "e": 43351,
      "ty": 2,
      "x": 877,
      "y": 218
    },
    {
      "t": 43505,
      "e": 43451,
      "ty": 2,
      "x": 875,
      "y": 223
    },
    {
      "t": 43505,
      "e": 43451,
      "ty": 41,
      "x": 12715,
      "y": 18250,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 43605,
      "e": 43551,
      "ty": 2,
      "x": 872,
      "y": 232
    },
    {
      "t": 43705,
      "e": 43651,
      "ty": 2,
      "x": 872,
      "y": 238
    },
    {
      "t": 43756,
      "e": 43702,
      "ty": 41,
      "x": 41416,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 43905,
      "e": 43851,
      "ty": 2,
      "x": 871,
      "y": 252
    },
    {
      "t": 44004,
      "e": 43950,
      "ty": 2,
      "x": 850,
      "y": 318
    },
    {
      "t": 44004,
      "e": 43950,
      "ty": 41,
      "x": 28370,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 44105,
      "e": 44051,
      "ty": 2,
      "x": 844,
      "y": 329
    },
    {
      "t": 44205,
      "e": 44151,
      "ty": 2,
      "x": 841,
      "y": 333
    },
    {
      "t": 44255,
      "e": 44201,
      "ty": 41,
      "x": 4646,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 44334,
      "e": 44280,
      "ty": 3,
      "x": 841,
      "y": 333,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 44430,
      "e": 44376,
      "ty": 4,
      "x": 4646,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 44430,
      "e": 44376,
      "ty": 5,
      "x": 841,
      "y": 333,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 44605,
      "e": 44551,
      "ty": 2,
      "x": 841,
      "y": 332
    },
    {
      "t": 44705,
      "e": 44651,
      "ty": 2,
      "x": 841,
      "y": 330
    },
    {
      "t": 44755,
      "e": 44701,
      "ty": 41,
      "x": 19435,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 44806,
      "e": 44752,
      "ty": 2,
      "x": 841,
      "y": 328
    },
    {
      "t": 44905,
      "e": 44851,
      "ty": 2,
      "x": 841,
      "y": 326
    },
    {
      "t": 45005,
      "e": 44951,
      "ty": 2,
      "x": 840,
      "y": 323
    },
    {
      "t": 45005,
      "e": 44951,
      "ty": 41,
      "x": 18442,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 45134,
      "e": 45080,
      "ty": 3,
      "x": 840,
      "y": 323,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 45238,
      "e": 45184,
      "ty": 4,
      "x": 18442,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 45238,
      "e": 45184,
      "ty": 5,
      "x": 840,
      "y": 323,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 45240,
      "e": 45186,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 45241,
      "e": 45187,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 45505,
      "e": 45451,
      "ty": 2,
      "x": 851,
      "y": 326
    },
    {
      "t": 45506,
      "e": 45452,
      "ty": 41,
      "x": 29362,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 45605,
      "e": 45551,
      "ty": 2,
      "x": 885,
      "y": 352
    },
    {
      "t": 45756,
      "e": 45702,
      "ty": 41,
      "x": 15088,
      "y": 14272,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 45805,
      "e": 45751,
      "ty": 2,
      "x": 885,
      "y": 354
    },
    {
      "t": 45905,
      "e": 45851,
      "ty": 2,
      "x": 872,
      "y": 382
    },
    {
      "t": 46004,
      "e": 45950,
      "ty": 2,
      "x": 846,
      "y": 435
    },
    {
      "t": 46005,
      "e": 45951,
      "ty": 41,
      "x": 19631,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 46105,
      "e": 46051,
      "ty": 2,
      "x": 843,
      "y": 441
    },
    {
      "t": 46186,
      "e": 46132,
      "ty": 6,
      "x": 837,
      "y": 466,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 46205,
      "e": 46151,
      "ty": 2,
      "x": 835,
      "y": 475
    },
    {
      "t": 46218,
      "e": 46164,
      "ty": 7,
      "x": 833,
      "y": 484,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 46251,
      "e": 46197,
      "ty": 6,
      "x": 832,
      "y": 496,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 46255,
      "e": 46201,
      "ty": 41,
      "x": 28120,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 46302,
      "e": 46248,
      "ty": 7,
      "x": 831,
      "y": 507,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 46305,
      "e": 46251,
      "ty": 2,
      "x": 831,
      "y": 507
    },
    {
      "t": 46505,
      "e": 46451,
      "ty": 2,
      "x": 831,
      "y": 506
    },
    {
      "t": 46505,
      "e": 46451,
      "ty": 41,
      "x": 8596,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 46519,
      "e": 46465,
      "ty": 6,
      "x": 833,
      "y": 502,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 46605,
      "e": 46551,
      "ty": 2,
      "x": 835,
      "y": 496
    },
    {
      "t": 46705,
      "e": 46651,
      "ty": 2,
      "x": 835,
      "y": 494
    },
    {
      "t": 46737,
      "e": 46683,
      "ty": 7,
      "x": 833,
      "y": 490,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 46754,
      "e": 46700,
      "ty": 41,
      "x": 2510,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 46804,
      "e": 46750,
      "ty": 2,
      "x": 832,
      "y": 486
    },
    {
      "t": 46904,
      "e": 46850,
      "ty": 2,
      "x": 831,
      "y": 477
    },
    {
      "t": 47006,
      "e": 46952,
      "ty": 41,
      "x": 10124,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 47087,
      "e": 47033,
      "ty": 6,
      "x": 831,
      "y": 475,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 47106,
      "e": 47052,
      "ty": 2,
      "x": 831,
      "y": 473
    },
    {
      "t": 47205,
      "e": 47151,
      "ty": 2,
      "x": 831,
      "y": 472
    },
    {
      "t": 47238,
      "e": 47184,
      "ty": 3,
      "x": 831,
      "y": 472,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 47239,
      "e": 47185,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 47240,
      "e": 47186,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 47254,
      "e": 47200,
      "ty": 41,
      "x": 23079,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 47341,
      "e": 47287,
      "ty": 4,
      "x": 23079,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 47342,
      "e": 47288,
      "ty": 5,
      "x": 831,
      "y": 472,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 47342,
      "e": 47288,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 47636,
      "e": 47582,
      "ty": 7,
      "x": 830,
      "y": 479,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 47669,
      "e": 47615,
      "ty": 6,
      "x": 831,
      "y": 496,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 47685,
      "e": 47631,
      "ty": 7,
      "x": 833,
      "y": 507,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 47706,
      "e": 47652,
      "ty": 2,
      "x": 834,
      "y": 516
    },
    {
      "t": 47719,
      "e": 47665,
      "ty": 6,
      "x": 834,
      "y": 521,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 47754,
      "e": 47700,
      "ty": 41,
      "x": 43243,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 47804,
      "e": 47750,
      "ty": 2,
      "x": 835,
      "y": 529
    },
    {
      "t": 47838,
      "e": 47784,
      "ty": 7,
      "x": 838,
      "y": 536,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 47904,
      "e": 47850,
      "ty": 2,
      "x": 841,
      "y": 551
    },
    {
      "t": 48004,
      "e": 47950,
      "ty": 2,
      "x": 847,
      "y": 597
    },
    {
      "t": 48004,
      "e": 47950,
      "ty": 41,
      "x": 6070,
      "y": 32580,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 48104,
      "e": 48050,
      "ty": 2,
      "x": 850,
      "y": 631
    },
    {
      "t": 48205,
      "e": 48151,
      "ty": 2,
      "x": 848,
      "y": 649
    },
    {
      "t": 48255,
      "e": 48201,
      "ty": 41,
      "x": 5256,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 48303,
      "e": 48201,
      "ty": 6,
      "x": 838,
      "y": 699,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 48305,
      "e": 48203,
      "ty": 2,
      "x": 838,
      "y": 699
    },
    {
      "t": 48337,
      "e": 48235,
      "ty": 7,
      "x": 835,
      "y": 712,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 48404,
      "e": 48302,
      "ty": 2,
      "x": 833,
      "y": 719
    },
    {
      "t": 48504,
      "e": 48402,
      "ty": 2,
      "x": 832,
      "y": 720
    },
    {
      "t": 48505,
      "e": 48403,
      "ty": 41,
      "x": 2510,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 48805,
      "e": 48703,
      "ty": 2,
      "x": 832,
      "y": 718
    },
    {
      "t": 49005,
      "e": 48903,
      "ty": 41,
      "x": 2510,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 49105,
      "e": 49003,
      "ty": 2,
      "x": 829,
      "y": 721
    },
    {
      "t": 49205,
      "e": 49103,
      "ty": 2,
      "x": 828,
      "y": 723
    },
    {
      "t": 49254,
      "e": 49152,
      "ty": 41,
      "x": 1651,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 49367,
      "e": 49265,
      "ty": 6,
      "x": 828,
      "y": 724,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 49405,
      "e": 49303,
      "ty": 2,
      "x": 828,
      "y": 726
    },
    {
      "t": 49504,
      "e": 49402,
      "ty": 2,
      "x": 826,
      "y": 729
    },
    {
      "t": 49505,
      "e": 49403,
      "ty": 41,
      "x": 0,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 49605,
      "e": 49503,
      "ty": 2,
      "x": 826,
      "y": 731
    },
    {
      "t": 49755,
      "e": 49653,
      "ty": 41,
      "x": 0,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 49895,
      "e": 49793,
      "ty": 3,
      "x": 826,
      "y": 731,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 49896,
      "e": 49794,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 49897,
      "e": 49795,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 50005,
      "e": 49903,
      "ty": 4,
      "x": 0,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 50006,
      "e": 49904,
      "ty": 5,
      "x": 826,
      "y": 731,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 50006,
      "e": 49904,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 50305,
      "e": 50203,
      "ty": 2,
      "x": 826,
      "y": 733
    },
    {
      "t": 50338,
      "e": 50236,
      "ty": 7,
      "x": 826,
      "y": 739,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 50373,
      "e": 50271,
      "ty": 6,
      "x": 826,
      "y": 752,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 50405,
      "e": 50303,
      "ty": 2,
      "x": 827,
      "y": 760
    },
    {
      "t": 50405,
      "e": 50303,
      "ty": 7,
      "x": 827,
      "y": 768,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 50438,
      "e": 50336,
      "ty": 6,
      "x": 829,
      "y": 781,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 50472,
      "e": 50370,
      "ty": 7,
      "x": 827,
      "y": 797,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 50504,
      "e": 50402,
      "ty": 2,
      "x": 827,
      "y": 802
    },
    {
      "t": 50504,
      "e": 50402,
      "ty": 41,
      "x": 1323,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 50604,
      "e": 50502,
      "ty": 2,
      "x": 816,
      "y": 831
    },
    {
      "t": 50704,
      "e": 50602,
      "ty": 2,
      "x": 809,
      "y": 859
    },
    {
      "t": 50755,
      "e": 50653,
      "ty": 41,
      "x": 27550,
      "y": 47641,
      "ta": "html > body"
    },
    {
      "t": 50805,
      "e": 50703,
      "ty": 2,
      "x": 807,
      "y": 872
    },
    {
      "t": 50904,
      "e": 50802,
      "ty": 2,
      "x": 823,
      "y": 905
    },
    {
      "t": 51005,
      "e": 50903,
      "ty": 2,
      "x": 862,
      "y": 957
    },
    {
      "t": 51005,
      "e": 50903,
      "ty": 41,
      "x": 32824,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 51105,
      "e": 51003,
      "ty": 2,
      "x": 871,
      "y": 966
    },
    {
      "t": 51255,
      "e": 51153,
      "ty": 41,
      "x": 40104,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 51405,
      "e": 51303,
      "ty": 2,
      "x": 871,
      "y": 967
    },
    {
      "t": 51504,
      "e": 51402,
      "ty": 2,
      "x": 871,
      "y": 968
    },
    {
      "t": 51505,
      "e": 51403,
      "ty": 41,
      "x": 40104,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 51605,
      "e": 51503,
      "ty": 2,
      "x": 862,
      "y": 961
    },
    {
      "t": 51755,
      "e": 51653,
      "ty": 41,
      "x": 32824,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 51797,
      "e": 51695,
      "ty": 3,
      "x": 862,
      "y": 960,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 51797,
      "e": 51695,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 51804,
      "e": 51702,
      "ty": 2,
      "x": 862,
      "y": 960
    },
    {
      "t": 51893,
      "e": 51791,
      "ty": 4,
      "x": 32824,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 51893,
      "e": 51791,
      "ty": 5,
      "x": 862,
      "y": 960,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 51894,
      "e": 51792,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 51895,
      "e": 51793,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 52004,
      "e": 51902,
      "ty": 2,
      "x": 863,
      "y": 959
    },
    {
      "t": 52004,
      "e": 51902,
      "ty": 41,
      "x": 33633,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 52105,
      "e": 52003,
      "ty": 2,
      "x": 865,
      "y": 983
    },
    {
      "t": 52123,
      "e": 52021,
      "ty": 6,
      "x": 866,
      "y": 1013,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52157,
      "e": 52055,
      "ty": 7,
      "x": 865,
      "y": 1041,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52204,
      "e": 52102,
      "ty": 2,
      "x": 860,
      "y": 1055
    },
    {
      "t": 52254,
      "e": 52152,
      "ty": 41,
      "x": 29340,
      "y": 58000,
      "ta": "html > body"
    },
    {
      "t": 52405,
      "e": 52303,
      "ty": 2,
      "x": 859,
      "y": 1040
    },
    {
      "t": 52423,
      "e": 52321,
      "ty": 6,
      "x": 859,
      "y": 1036,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52504,
      "e": 52402,
      "ty": 2,
      "x": 859,
      "y": 1033
    },
    {
      "t": 52505,
      "e": 52403,
      "ty": 41,
      "x": 15244,
      "y": 55605,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52575,
      "e": 52473,
      "ty": 3,
      "x": 859,
      "y": 1033,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52576,
      "e": 52474,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 52576,
      "e": 52474,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52654,
      "e": 52552,
      "ty": 4,
      "x": 15244,
      "y": 55605,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52655,
      "e": 52553,
      "ty": 5,
      "x": 859,
      "y": 1033,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52661,
      "e": 52559,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 52664,
      "e": 52562,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 52666,
      "e": 52564,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 53754,
      "e": 53652,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 56004,
      "e": 55902,
      "ty": 2,
      "x": 859,
      "y": 1032
    },
    {
      "t": 56005,
      "e": 55903,
      "ty": 41,
      "x": 27823,
      "y": 62717,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 56105,
      "e": 56003,
      "ty": 2,
      "x": 864,
      "y": 1010
    },
    {
      "t": 56205,
      "e": 56103,
      "ty": 2,
      "x": 864,
      "y": 1009
    },
    {
      "t": 56255,
      "e": 56153,
      "ty": 41,
      "x": 28069,
      "y": 61124,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 57605,
      "e": 57503,
      "ty": 2,
      "x": 865,
      "y": 1009
    },
    {
      "t": 57755,
      "e": 57653,
      "ty": 41,
      "x": 28118,
      "y": 61124,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 57804,
      "e": 57702,
      "ty": 2,
      "x": 866,
      "y": 1007
    },
    {
      "t": 57905,
      "e": 57803,
      "ty": 2,
      "x": 867,
      "y": 1007
    },
    {
      "t": 58005,
      "e": 57903,
      "ty": 41,
      "x": 28216,
      "y": 60986,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 58205,
      "e": 58103,
      "ty": 2,
      "x": 868,
      "y": 1006
    },
    {
      "t": 58255,
      "e": 58153,
      "ty": 41,
      "x": 28265,
      "y": 60917,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 60005,
      "e": 59903,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 62605,
      "e": 62503,
      "ty": 2,
      "x": 867,
      "y": 1006
    },
    {
      "t": 62756,
      "e": 62654,
      "ty": 41,
      "x": 28216,
      "y": 60917,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 63205,
      "e": 63103,
      "ty": 2,
      "x": 864,
      "y": 1007
    },
    {
      "t": 63255,
      "e": 63153,
      "ty": 41,
      "x": 27724,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 63305,
      "e": 63203,
      "ty": 2,
      "x": 855,
      "y": 1008
    },
    {
      "t": 63405,
      "e": 63303,
      "ty": 2,
      "x": 853,
      "y": 1008
    },
    {
      "t": 63505,
      "e": 63403,
      "ty": 41,
      "x": 27528,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 64505,
      "e": 64403,
      "ty": 2,
      "x": 852,
      "y": 1008
    },
    {
      "t": 64506,
      "e": 64404,
      "ty": 41,
      "x": 27478,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 65105,
      "e": 65003,
      "ty": 2,
      "x": 851,
      "y": 1008
    },
    {
      "t": 65256,
      "e": 65154,
      "ty": 41,
      "x": 27429,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 65305,
      "e": 65203,
      "ty": 2,
      "x": 848,
      "y": 1008
    },
    {
      "t": 65406,
      "e": 65304,
      "ty": 2,
      "x": 846,
      "y": 1008
    },
    {
      "t": 65506,
      "e": 65404,
      "ty": 41,
      "x": 27183,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 65805,
      "e": 65703,
      "ty": 2,
      "x": 845,
      "y": 1008
    },
    {
      "t": 65905,
      "e": 65803,
      "ty": 2,
      "x": 845,
      "y": 1007
    },
    {
      "t": 66005,
      "e": 65903,
      "ty": 2,
      "x": 864,
      "y": 1014
    },
    {
      "t": 66005,
      "e": 65903,
      "ty": 41,
      "x": 28069,
      "y": 61471,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 66105,
      "e": 66003,
      "ty": 2,
      "x": 947,
      "y": 1065
    },
    {
      "t": 66155,
      "e": 66053,
      "ty": 6,
      "x": 962,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 66205,
      "e": 66103,
      "ty": 2,
      "x": 968,
      "y": 1080
    },
    {
      "t": 66256,
      "e": 66154,
      "ty": 41,
      "x": 33586,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 66305,
      "e": 66203,
      "ty": 2,
      "x": 971,
      "y": 1080
    },
    {
      "t": 68004,
      "e": 67902,
      "ty": 2,
      "x": 974,
      "y": 1076
    },
    {
      "t": 68005,
      "e": 67903,
      "ty": 41,
      "x": 35225,
      "y": 6384,
      "ta": "#start"
    },
    {
      "t": 69604,
      "e": 69502,
      "ty": 2,
      "x": 976,
      "y": 1074
    },
    {
      "t": 69755,
      "e": 69653,
      "ty": 41,
      "x": 36317,
      "y": 2529,
      "ta": "#start"
    },
    {
      "t": 69905,
      "e": 69803,
      "ty": 2,
      "x": 976,
      "y": 1073
    },
    {
      "t": 70004,
      "e": 69902,
      "ty": 2,
      "x": 977,
      "y": 1076
    },
    {
      "t": 70004,
      "e": 69902,
      "ty": 41,
      "x": 36863,
      "y": 6384,
      "ta": "#start"
    },
    {
      "t": 70005,
      "e": 69903,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70204,
      "e": 70102,
      "ty": 2,
      "x": 979,
      "y": 1078
    },
    {
      "t": 70222,
      "e": 70120,
      "ty": 3,
      "x": 979,
      "y": 1078,
      "ta": "#start"
    },
    {
      "t": 70222,
      "e": 70120,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 70255,
      "e": 70153,
      "ty": 41,
      "x": 37955,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 70349,
      "e": 70247,
      "ty": 4,
      "x": 37955,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 70350,
      "e": 70248,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 70350,
      "e": 70248,
      "ty": 5,
      "x": 979,
      "y": 1078,
      "ta": "#start"
    },
    {
      "t": 70350,
      "e": 70248,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 71387,
      "e": 71285,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 72404,
      "e": 72302,
      "ty": 2,
      "x": 1017,
      "y": 1068
    },
    {
      "t": 72505,
      "e": 72403,
      "ty": 2,
      "x": 1919,
      "y": 986
    },
    {
      "t": 72605,
      "e": 72503,
      "ty": 2,
      "x": 1915,
      "y": 1005
    },
    {
      "t": 72704,
      "e": 72602,
      "ty": 2,
      "x": 1891,
      "y": 1023
    },
    {
      "t": 72754,
      "e": 72652,
      "ty": 41,
      "x": 64742,
      "y": 56339,
      "ta": "html > body"
    },
    {
      "t": 72805,
      "e": 72703,
      "ty": 2,
      "x": 1888,
      "y": 1025
    },
    {
      "t": 72820,
      "e": 72718,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 112522, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 112528, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 6268, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 120125, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 23290, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"ECHO\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 144420, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 10521, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 156027, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 10138, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 167168, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 95264, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 263791, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-09 AM-11 AM-11 AM-11 AM-01 PM-12 PM-C -C -12 PM-11 AM-01 PM-12 PM-11 AM-01 PM-01 PM-01 PM-12 PM-A -A -F -F -F -02 PM-02 PM-02 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1127,y:845,t:1527009019224};\\\", \\\"{x:1148,y:857,t:1527009019238};\\\", \\\"{x:1234,y:896,t:1527009019254};\\\", \\\"{x:1360,y:938,t:1527009019272};\\\", \\\"{x:1470,y:983,t:1527009019288};\\\", \\\"{x:1543,y:1020,t:1527009019303};\\\", \\\"{x:1592,y:1059,t:1527009019320};\\\", \\\"{x:1612,y:1080,t:1527009019337};\\\", \\\"{x:1621,y:1093,t:1527009019354};\\\", \\\"{x:1622,y:1094,t:1527009019370};\\\", \\\"{x:1622,y:1095,t:1527009019387};\\\", \\\"{x:1622,y:1097,t:1527009019404};\\\", \\\"{x:1620,y:1098,t:1527009019420};\\\", \\\"{x:1619,y:1098,t:1527009019437};\\\", \\\"{x:1603,y:1099,t:1527009019454};\\\", \\\"{x:1582,y:1099,t:1527009019470};\\\", \\\"{x:1524,y:1093,t:1527009019487};\\\", \\\"{x:1423,y:1076,t:1527009019504};\\\", \\\"{x:1324,y:1052,t:1527009019520};\\\", \\\"{x:1244,y:1028,t:1527009019538};\\\", \\\"{x:1189,y:1013,t:1527009019554};\\\", \\\"{x:1157,y:1000,t:1527009019570};\\\", \\\"{x:1149,y:995,t:1527009019587};\\\", \\\"{x:1147,y:993,t:1527009019605};\\\", \\\"{x:1147,y:989,t:1527009019621};\\\", \\\"{x:1146,y:981,t:1527009019638};\\\", \\\"{x:1142,y:961,t:1527009019655};\\\", \\\"{x:1141,y:950,t:1527009019670};\\\", \\\"{x:1144,y:938,t:1527009019687};\\\", \\\"{x:1147,y:934,t:1527009019705};\\\", \\\"{x:1148,y:927,t:1527009019721};\\\", \\\"{x:1159,y:921,t:1527009019737};\\\", \\\"{x:1173,y:918,t:1527009019755};\\\", \\\"{x:1189,y:913,t:1527009019771};\\\", \\\"{x:1209,y:912,t:1527009019788};\\\", \\\"{x:1234,y:912,t:1527009019804};\\\", \\\"{x:1248,y:914,t:1527009019822};\\\", \\\"{x:1259,y:917,t:1527009019838};\\\", \\\"{x:1271,y:919,t:1527009019854};\\\", \\\"{x:1273,y:919,t:1527009019872};\\\", \\\"{x:1274,y:919,t:1527009021032};\\\", \\\"{x:1274,y:922,t:1527009021040};\\\", \\\"{x:1274,y:923,t:1527009021055};\\\", \\\"{x:1274,y:924,t:1527009021071};\\\", \\\"{x:1274,y:925,t:1527009021089};\\\", \\\"{x:1273,y:927,t:1527009021105};\\\", \\\"{x:1273,y:929,t:1527009021122};\\\", \\\"{x:1272,y:930,t:1527009021139};\\\", \\\"{x:1270,y:931,t:1527009021156};\\\", \\\"{x:1270,y:933,t:1527009021171};\\\", \\\"{x:1270,y:935,t:1527009021189};\\\", \\\"{x:1268,y:936,t:1527009021206};\\\", \\\"{x:1268,y:938,t:1527009021254};\\\", \\\"{x:1268,y:939,t:1527009021270};\\\", \\\"{x:1268,y:940,t:1527009021279};\\\", \\\"{x:1268,y:941,t:1527009021289};\\\", \\\"{x:1268,y:945,t:1527009021306};\\\", \\\"{x:1270,y:948,t:1527009021323};\\\", \\\"{x:1271,y:952,t:1527009021339};\\\", \\\"{x:1272,y:954,t:1527009021356};\\\", \\\"{x:1274,y:960,t:1527009021373};\\\", \\\"{x:1276,y:964,t:1527009021391};\\\", \\\"{x:1278,y:966,t:1527009021406};\\\", \\\"{x:1280,y:970,t:1527009021422};\\\", \\\"{x:1282,y:973,t:1527009021438};\\\", \\\"{x:1283,y:974,t:1527009021456};\\\", \\\"{x:1283,y:975,t:1527009021623};\\\", \\\"{x:1284,y:977,t:1527009021647};\\\", \\\"{x:1284,y:978,t:1527009021671};\\\", \\\"{x:1285,y:979,t:1527009021750};\\\", \\\"{x:1285,y:980,t:1527009021759};\\\", \\\"{x:1286,y:980,t:1527009021773};\\\", \\\"{x:1286,y:981,t:1527009021790};\\\", \\\"{x:1286,y:983,t:1527009022064};\\\", \\\"{x:1286,y:985,t:1527009022271};\\\", \\\"{x:1285,y:985,t:1527009022303};\\\", \\\"{x:1284,y:985,t:1527009023484};\\\", \\\"{x:1282,y:986,t:1527009023507};\\\", \\\"{x:1282,y:985,t:1527009023571};\\\", \\\"{x:1281,y:984,t:1527009023587};\\\", \\\"{x:1281,y:983,t:1527009023603};\\\", \\\"{x:1280,y:980,t:1527009023620};\\\", \\\"{x:1280,y:979,t:1527009023643};\\\", \\\"{x:1280,y:978,t:1527009023654};\\\", \\\"{x:1280,y:977,t:1527009023670};\\\", \\\"{x:1279,y:974,t:1527009023687};\\\", \\\"{x:1279,y:972,t:1527009023731};\\\", \\\"{x:1279,y:971,t:1527009023739};\\\", \\\"{x:1279,y:970,t:1527009023755};\\\", \\\"{x:1280,y:968,t:1527009023780};\\\", \\\"{x:1280,y:967,t:1527009023876};\\\", \\\"{x:1280,y:966,t:1527009023900};\\\", \\\"{x:1281,y:965,t:1527009023908};\\\", \\\"{x:1281,y:964,t:1527009023924};\\\", \\\"{x:1282,y:964,t:1527009023938};\\\", \\\"{x:1282,y:963,t:1527009023955};\\\", \\\"{x:1282,y:962,t:1527009023971};\\\", \\\"{x:1282,y:961,t:1527009024020};\\\", \\\"{x:1282,y:960,t:1527009024038};\\\", \\\"{x:1282,y:959,t:1527009024055};\\\", \\\"{x:1282,y:958,t:1527009024228};\\\", \\\"{x:1282,y:957,t:1527009024260};\\\", \\\"{x:1282,y:956,t:1527009024272};\\\", \\\"{x:1282,y:955,t:1527009024292};\\\", \\\"{x:1282,y:954,t:1527009024305};\\\", \\\"{x:1282,y:953,t:1527009024397};\\\", \\\"{x:1282,y:952,t:1527009024405};\\\", \\\"{x:1281,y:950,t:1527009024422};\\\", \\\"{x:1281,y:948,t:1527009024438};\\\", \\\"{x:1281,y:947,t:1527009024455};\\\", \\\"{x:1281,y:945,t:1527009024472};\\\", \\\"{x:1280,y:943,t:1527009024487};\\\", \\\"{x:1280,y:941,t:1527009024504};\\\", \\\"{x:1279,y:939,t:1527009024521};\\\", \\\"{x:1279,y:937,t:1527009024538};\\\", \\\"{x:1278,y:936,t:1527009024571};\\\", \\\"{x:1278,y:933,t:1527009024675};\\\", \\\"{x:1278,y:931,t:1527009024699};\\\", \\\"{x:1277,y:929,t:1527009024715};\\\", \\\"{x:1277,y:928,t:1527009024739};\\\", \\\"{x:1277,y:926,t:1527009024754};\\\", \\\"{x:1277,y:924,t:1527009024771};\\\", \\\"{x:1276,y:924,t:1527009024788};\\\", \\\"{x:1276,y:923,t:1527009024804};\\\", \\\"{x:1276,y:920,t:1527009024822};\\\", \\\"{x:1275,y:919,t:1527009024843};\\\", \\\"{x:1275,y:918,t:1527009024940};\\\", \\\"{x:1275,y:917,t:1527009024955};\\\", \\\"{x:1275,y:916,t:1527009024972};\\\", \\\"{x:1275,y:914,t:1527009025004};\\\", \\\"{x:1275,y:913,t:1527009025036};\\\", \\\"{x:1275,y:912,t:1527009025044};\\\", \\\"{x:1275,y:911,t:1527009025060};\\\", \\\"{x:1275,y:910,t:1527009025083};\\\", \\\"{x:1275,y:909,t:1527009025099};\\\", \\\"{x:1275,y:908,t:1527009025106};\\\", \\\"{x:1275,y:907,t:1527009025147};\\\", \\\"{x:1275,y:906,t:1527009025155};\\\", \\\"{x:1275,y:905,t:1527009025178};\\\", \\\"{x:1275,y:904,t:1527009025219};\\\", \\\"{x:1275,y:903,t:1527009025227};\\\", \\\"{x:1275,y:902,t:1527009025315};\\\", \\\"{x:1275,y:901,t:1527009025404};\\\", \\\"{x:1275,y:900,t:1527009025428};\\\", \\\"{x:1275,y:899,t:1527009025439};\\\", \\\"{x:1275,y:898,t:1527009025484};\\\", \\\"{x:1274,y:897,t:1527009025491};\\\", \\\"{x:1274,y:896,t:1527009025532};\\\", \\\"{x:1274,y:895,t:1527009025597};\\\", \\\"{x:1274,y:894,t:1527009025612};\\\", \\\"{x:1274,y:893,t:1527009025635};\\\", \\\"{x:1274,y:892,t:1527009025660};\\\", \\\"{x:1273,y:891,t:1527009025675};\\\", \\\"{x:1273,y:890,t:1527009025692};\\\", \\\"{x:1273,y:889,t:1527009025708};\\\", \\\"{x:1273,y:887,t:1527009025724};\\\", \\\"{x:1272,y:886,t:1527009025748};\\\", \\\"{x:1272,y:885,t:1527009025755};\\\", \\\"{x:1272,y:884,t:1527009025780};\\\", \\\"{x:1272,y:883,t:1527009025819};\\\", \\\"{x:1271,y:882,t:1527009025827};\\\", \\\"{x:1271,y:881,t:1527009025851};\\\", \\\"{x:1271,y:880,t:1527009025868};\\\", \\\"{x:1271,y:878,t:1527009025884};\\\", \\\"{x:1269,y:876,t:1527009025892};\\\", \\\"{x:1269,y:875,t:1527009025955};\\\", \\\"{x:1269,y:873,t:1527009025972};\\\", \\\"{x:1269,y:871,t:1527009025989};\\\", \\\"{x:1268,y:870,t:1527009026010};\\\", \\\"{x:1268,y:869,t:1527009026022};\\\", \\\"{x:1268,y:868,t:1527009026040};\\\", \\\"{x:1267,y:867,t:1527009026067};\\\", \\\"{x:1266,y:866,t:1527009026075};\\\", \\\"{x:1266,y:865,t:1527009026089};\\\", \\\"{x:1266,y:864,t:1527009026123};\\\", \\\"{x:1266,y:862,t:1527009026139};\\\", \\\"{x:1265,y:861,t:1527009026155};\\\", \\\"{x:1265,y:860,t:1527009026179};\\\", \\\"{x:1265,y:859,t:1527009026203};\\\", \\\"{x:1265,y:858,t:1527009026219};\\\", \\\"{x:1264,y:857,t:1527009026260};\\\", \\\"{x:1263,y:857,t:1527009026273};\\\", \\\"{x:1263,y:855,t:1527009026290};\\\", \\\"{x:1263,y:853,t:1527009026306};\\\", \\\"{x:1262,y:852,t:1527009026323};\\\", \\\"{x:1261,y:847,t:1527009026340};\\\", \\\"{x:1260,y:846,t:1527009026404};\\\", \\\"{x:1259,y:845,t:1527009026428};\\\", \\\"{x:1259,y:844,t:1527009026440};\\\", \\\"{x:1258,y:844,t:1527009026457};\\\", \\\"{x:1258,y:843,t:1527009026473};\\\", \\\"{x:1258,y:842,t:1527009026490};\\\", \\\"{x:1258,y:841,t:1527009026505};\\\", \\\"{x:1256,y:839,t:1527009026523};\\\", \\\"{x:1256,y:837,t:1527009026579};\\\", \\\"{x:1256,y:836,t:1527009026611};\\\", \\\"{x:1256,y:835,t:1527009026643};\\\", \\\"{x:1256,y:834,t:1527009026659};\\\", \\\"{x:1256,y:833,t:1527009026672};\\\", \\\"{x:1256,y:832,t:1527009026690};\\\", \\\"{x:1256,y:831,t:1527009026707};\\\", \\\"{x:1256,y:829,t:1527009026722};\\\", \\\"{x:1256,y:828,t:1527009026747};\\\", \\\"{x:1255,y:827,t:1527009026771};\\\", \\\"{x:1255,y:826,t:1527009026803};\\\", \\\"{x:1257,y:826,t:1527009030548};\\\", \\\"{x:1259,y:826,t:1527009030559};\\\", \\\"{x:1261,y:827,t:1527009030577};\\\", \\\"{x:1261,y:828,t:1527009030924};\\\", \\\"{x:1261,y:830,t:1527009030932};\\\", \\\"{x:1261,y:831,t:1527009030943};\\\", \\\"{x:1261,y:836,t:1527009030959};\\\", \\\"{x:1262,y:840,t:1527009030975};\\\", \\\"{x:1262,y:841,t:1527009030993};\\\", \\\"{x:1262,y:843,t:1527009031010};\\\", \\\"{x:1262,y:844,t:1527009031027};\\\", \\\"{x:1262,y:846,t:1527009031067};\\\", \\\"{x:1262,y:847,t:1527009031237};\\\", \\\"{x:1264,y:848,t:1527009031268};\\\", \\\"{x:1264,y:849,t:1527009031284};\\\", \\\"{x:1266,y:849,t:1527009031308};\\\", \\\"{x:1267,y:850,t:1527009031315};\\\", \\\"{x:1268,y:850,t:1527009031327};\\\", \\\"{x:1271,y:853,t:1527009031343};\\\", \\\"{x:1272,y:858,t:1527009031360};\\\", \\\"{x:1273,y:859,t:1527009031377};\\\", \\\"{x:1273,y:861,t:1527009032124};\\\", \\\"{x:1274,y:861,t:1527009032180};\\\", \\\"{x:1274,y:860,t:1527009032194};\\\", \\\"{x:1275,y:859,t:1527009032210};\\\", \\\"{x:1276,y:857,t:1527009032227};\\\", \\\"{x:1277,y:857,t:1527009032244};\\\", \\\"{x:1278,y:856,t:1527009032259};\\\", \\\"{x:1278,y:855,t:1527009032277};\\\", \\\"{x:1278,y:854,t:1527009032299};\\\", \\\"{x:1279,y:854,t:1527009032311};\\\", \\\"{x:1279,y:853,t:1527009032327};\\\", \\\"{x:1280,y:853,t:1527009032344};\\\", \\\"{x:1281,y:851,t:1527009032360};\\\", \\\"{x:1282,y:851,t:1527009032435};\\\", \\\"{x:1284,y:850,t:1527009032492};\\\", \\\"{x:1284,y:849,t:1527009032548};\\\", \\\"{x:1285,y:849,t:1527009032561};\\\", \\\"{x:1286,y:849,t:1527009032612};\\\", \\\"{x:1286,y:848,t:1527009033292};\\\", \\\"{x:1279,y:846,t:1527009033299};\\\", \\\"{x:1272,y:845,t:1527009033312};\\\", \\\"{x:1262,y:842,t:1527009033329};\\\", \\\"{x:1252,y:840,t:1527009033346};\\\", \\\"{x:1243,y:836,t:1527009033361};\\\", \\\"{x:1235,y:835,t:1527009033379};\\\", \\\"{x:1231,y:833,t:1527009033396};\\\", \\\"{x:1230,y:832,t:1527009033411};\\\", \\\"{x:1230,y:833,t:1527009033524};\\\", \\\"{x:1230,y:840,t:1527009033531};\\\", \\\"{x:1230,y:847,t:1527009033546};\\\", \\\"{x:1230,y:863,t:1527009033561};\\\", \\\"{x:1233,y:883,t:1527009033579};\\\", \\\"{x:1243,y:927,t:1527009033596};\\\", \\\"{x:1247,y:953,t:1527009033612};\\\", \\\"{x:1249,y:964,t:1527009033629};\\\", \\\"{x:1250,y:973,t:1527009033646};\\\", \\\"{x:1252,y:981,t:1527009033661};\\\", \\\"{x:1255,y:987,t:1527009033679};\\\", \\\"{x:1258,y:991,t:1527009033696};\\\", \\\"{x:1258,y:993,t:1527009033711};\\\", \\\"{x:1259,y:994,t:1527009033729};\\\", \\\"{x:1260,y:994,t:1527009033828};\\\", \\\"{x:1266,y:991,t:1527009033845};\\\", \\\"{x:1270,y:983,t:1527009033863};\\\", \\\"{x:1275,y:975,t:1527009033878};\\\", \\\"{x:1276,y:964,t:1527009033896};\\\", \\\"{x:1278,y:957,t:1527009033913};\\\", \\\"{x:1279,y:949,t:1527009033929};\\\", \\\"{x:1279,y:944,t:1527009033946};\\\", \\\"{x:1280,y:940,t:1527009033962};\\\", \\\"{x:1280,y:937,t:1527009033979};\\\", \\\"{x:1280,y:935,t:1527009033995};\\\", \\\"{x:1280,y:933,t:1527009034012};\\\", \\\"{x:1280,y:932,t:1527009034029};\\\", \\\"{x:1280,y:931,t:1527009034045};\\\", \\\"{x:1280,y:929,t:1527009034062};\\\", \\\"{x:1280,y:927,t:1527009034079};\\\", \\\"{x:1280,y:925,t:1527009034096};\\\", \\\"{x:1280,y:924,t:1527009034113};\\\", \\\"{x:1279,y:921,t:1527009034128};\\\", \\\"{x:1279,y:920,t:1527009034145};\\\", \\\"{x:1279,y:919,t:1527009034162};\\\", \\\"{x:1279,y:918,t:1527009034178};\\\", \\\"{x:1276,y:914,t:1527009034196};\\\", \\\"{x:1276,y:912,t:1527009034212};\\\", \\\"{x:1275,y:910,t:1527009034229};\\\", \\\"{x:1274,y:906,t:1527009034246};\\\", \\\"{x:1274,y:903,t:1527009034262};\\\", \\\"{x:1272,y:900,t:1527009034279};\\\", \\\"{x:1272,y:897,t:1527009034296};\\\", \\\"{x:1272,y:894,t:1527009034312};\\\", \\\"{x:1272,y:892,t:1527009034330};\\\", \\\"{x:1271,y:890,t:1527009034346};\\\", \\\"{x:1269,y:888,t:1527009034363};\\\", \\\"{x:1269,y:886,t:1527009034380};\\\", \\\"{x:1269,y:885,t:1527009034396};\\\", \\\"{x:1268,y:883,t:1527009034412};\\\", \\\"{x:1268,y:882,t:1527009034430};\\\", \\\"{x:1268,y:879,t:1527009034446};\\\", \\\"{x:1268,y:878,t:1527009034462};\\\", \\\"{x:1268,y:875,t:1527009034479};\\\", \\\"{x:1268,y:872,t:1527009034496};\\\", \\\"{x:1268,y:868,t:1527009034512};\\\", \\\"{x:1268,y:864,t:1527009034529};\\\", \\\"{x:1268,y:859,t:1527009034545};\\\", \\\"{x:1268,y:855,t:1527009034563};\\\", \\\"{x:1269,y:851,t:1527009034580};\\\", \\\"{x:1269,y:848,t:1527009034595};\\\", \\\"{x:1269,y:846,t:1527009034613};\\\", \\\"{x:1270,y:844,t:1527009034630};\\\", \\\"{x:1272,y:841,t:1527009034646};\\\", \\\"{x:1273,y:837,t:1527009034663};\\\", \\\"{x:1275,y:833,t:1527009034679};\\\", \\\"{x:1276,y:829,t:1527009034696};\\\", \\\"{x:1277,y:826,t:1527009034713};\\\", \\\"{x:1278,y:822,t:1527009034730};\\\", \\\"{x:1278,y:819,t:1527009034747};\\\", \\\"{x:1278,y:816,t:1527009034763};\\\", \\\"{x:1279,y:815,t:1527009034780};\\\", \\\"{x:1280,y:812,t:1527009034860};\\\", \\\"{x:1282,y:812,t:1527009034868};\\\", \\\"{x:1283,y:812,t:1527009034879};\\\", \\\"{x:1286,y:811,t:1527009034896};\\\", \\\"{x:1288,y:811,t:1527009034913};\\\", \\\"{x:1290,y:811,t:1527009034930};\\\", \\\"{x:1292,y:811,t:1527009034947};\\\", \\\"{x:1293,y:811,t:1527009034962};\\\", \\\"{x:1294,y:809,t:1527009034995};\\\", \\\"{x:1296,y:805,t:1527009035074};\\\", \\\"{x:1296,y:801,t:1527009035083};\\\", \\\"{x:1296,y:795,t:1527009035096};\\\", \\\"{x:1296,y:789,t:1527009035111};\\\", \\\"{x:1296,y:783,t:1527009035128};\\\", \\\"{x:1296,y:778,t:1527009035146};\\\", \\\"{x:1294,y:771,t:1527009035162};\\\", \\\"{x:1291,y:765,t:1527009035178};\\\", \\\"{x:1291,y:763,t:1527009035195};\\\", \\\"{x:1288,y:757,t:1527009035212};\\\", \\\"{x:1288,y:755,t:1527009035229};\\\", \\\"{x:1287,y:752,t:1527009035246};\\\", \\\"{x:1286,y:748,t:1527009035263};\\\", \\\"{x:1286,y:747,t:1527009035279};\\\", \\\"{x:1286,y:744,t:1527009035296};\\\", \\\"{x:1285,y:742,t:1527009035313};\\\", \\\"{x:1284,y:740,t:1527009035329};\\\", \\\"{x:1284,y:735,t:1527009035346};\\\", \\\"{x:1283,y:730,t:1527009035363};\\\", \\\"{x:1283,y:725,t:1527009035378};\\\", \\\"{x:1282,y:722,t:1527009035396};\\\", \\\"{x:1281,y:718,t:1527009035412};\\\", \\\"{x:1280,y:714,t:1527009035429};\\\", \\\"{x:1278,y:712,t:1527009035445};\\\", \\\"{x:1278,y:709,t:1527009035462};\\\", \\\"{x:1278,y:707,t:1527009035479};\\\", \\\"{x:1277,y:703,t:1527009035496};\\\", \\\"{x:1277,y:700,t:1527009035513};\\\", \\\"{x:1277,y:699,t:1527009035529};\\\", \\\"{x:1276,y:698,t:1527009035546};\\\", \\\"{x:1276,y:695,t:1527009035563};\\\", \\\"{x:1276,y:692,t:1527009035579};\\\", \\\"{x:1275,y:692,t:1527009035596};\\\", \\\"{x:1275,y:689,t:1527009035613};\\\", \\\"{x:1275,y:688,t:1527009035628};\\\", \\\"{x:1274,y:687,t:1527009035645};\\\", \\\"{x:1274,y:685,t:1527009035683};\\\", \\\"{x:1274,y:684,t:1527009035696};\\\", \\\"{x:1274,y:683,t:1527009035715};\\\", \\\"{x:1274,y:680,t:1527009035731};\\\", \\\"{x:1274,y:679,t:1527009035746};\\\", \\\"{x:1274,y:674,t:1527009035763};\\\", \\\"{x:1274,y:672,t:1527009035779};\\\", \\\"{x:1273,y:669,t:1527009035796};\\\", \\\"{x:1273,y:665,t:1527009035813};\\\", \\\"{x:1273,y:660,t:1527009035830};\\\", \\\"{x:1273,y:656,t:1527009035846};\\\", \\\"{x:1273,y:652,t:1527009035863};\\\", \\\"{x:1273,y:649,t:1527009035880};\\\", \\\"{x:1273,y:648,t:1527009035896};\\\", \\\"{x:1272,y:644,t:1527009035913};\\\", \\\"{x:1272,y:642,t:1527009035931};\\\", \\\"{x:1272,y:640,t:1527009035946};\\\", \\\"{x:1272,y:636,t:1527009035963};\\\", \\\"{x:1272,y:635,t:1527009035980};\\\", \\\"{x:1272,y:633,t:1527009035998};\\\", \\\"{x:1272,y:630,t:1527009036013};\\\", \\\"{x:1272,y:627,t:1527009036030};\\\", \\\"{x:1272,y:624,t:1527009036045};\\\", \\\"{x:1272,y:619,t:1527009036063};\\\", \\\"{x:1272,y:615,t:1527009036079};\\\", \\\"{x:1272,y:611,t:1527009036095};\\\", \\\"{x:1272,y:607,t:1527009036113};\\\", \\\"{x:1272,y:603,t:1527009036130};\\\", \\\"{x:1272,y:598,t:1527009036146};\\\", \\\"{x:1272,y:593,t:1527009036162};\\\", \\\"{x:1272,y:592,t:1527009036180};\\\", \\\"{x:1272,y:591,t:1527009036210};\\\", \\\"{x:1273,y:589,t:1527009036219};\\\", \\\"{x:1273,y:587,t:1527009036229};\\\", \\\"{x:1273,y:584,t:1527009036247};\\\", \\\"{x:1273,y:580,t:1527009036263};\\\", \\\"{x:1273,y:578,t:1527009036280};\\\", \\\"{x:1273,y:575,t:1527009036297};\\\", \\\"{x:1273,y:573,t:1527009036313};\\\", \\\"{x:1273,y:571,t:1527009036330};\\\", \\\"{x:1273,y:568,t:1527009036347};\\\", \\\"{x:1273,y:567,t:1527009036363};\\\", \\\"{x:1273,y:566,t:1527009036381};\\\", \\\"{x:1273,y:564,t:1527009036397};\\\", \\\"{x:1273,y:563,t:1527009036413};\\\", \\\"{x:1273,y:562,t:1527009036430};\\\", \\\"{x:1273,y:561,t:1527009036447};\\\", \\\"{x:1273,y:560,t:1527009036463};\\\", \\\"{x:1273,y:559,t:1527009036644};\\\", \\\"{x:1274,y:558,t:1527009036651};\\\", \\\"{x:1275,y:557,t:1527009036675};\\\", \\\"{x:1276,y:557,t:1527009037236};\\\", \\\"{x:1278,y:558,t:1527009037636};\\\", \\\"{x:1283,y:558,t:1527009037648};\\\", \\\"{x:1299,y:564,t:1527009037664};\\\", \\\"{x:1312,y:568,t:1527009037682};\\\", \\\"{x:1314,y:568,t:1527009037698};\\\", \\\"{x:1316,y:569,t:1527009037715};\\\", \\\"{x:1317,y:569,t:1527009037732};\\\", \\\"{x:1319,y:569,t:1527009037748};\\\", \\\"{x:1323,y:570,t:1527009037765};\\\", \\\"{x:1327,y:572,t:1527009037781};\\\", \\\"{x:1333,y:572,t:1527009037798};\\\", \\\"{x:1338,y:573,t:1527009037814};\\\", \\\"{x:1342,y:574,t:1527009037832};\\\", \\\"{x:1346,y:574,t:1527009037849};\\\", \\\"{x:1348,y:574,t:1527009037864};\\\", \\\"{x:1353,y:574,t:1527009037882};\\\", \\\"{x:1359,y:576,t:1527009037898};\\\", \\\"{x:1365,y:576,t:1527009037913};\\\", \\\"{x:1374,y:580,t:1527009037931};\\\", \\\"{x:1379,y:580,t:1527009037947};\\\", \\\"{x:1384,y:582,t:1527009037963};\\\", \\\"{x:1390,y:584,t:1527009037980};\\\", \\\"{x:1399,y:586,t:1527009037998};\\\", \\\"{x:1410,y:588,t:1527009038014};\\\", \\\"{x:1421,y:590,t:1527009038031};\\\", \\\"{x:1432,y:592,t:1527009038047};\\\", \\\"{x:1449,y:596,t:1527009038064};\\\", \\\"{x:1467,y:599,t:1527009038081};\\\", \\\"{x:1498,y:608,t:1527009038098};\\\", \\\"{x:1545,y:616,t:1527009038114};\\\", \\\"{x:1578,y:628,t:1527009038131};\\\", \\\"{x:1635,y:639,t:1527009038148};\\\", \\\"{x:1690,y:652,t:1527009038165};\\\", \\\"{x:1725,y:657,t:1527009038181};\\\", \\\"{x:1748,y:664,t:1527009038198};\\\", \\\"{x:1768,y:670,t:1527009038215};\\\", \\\"{x:1782,y:675,t:1527009038231};\\\", \\\"{x:1788,y:679,t:1527009038248};\\\", \\\"{x:1795,y:682,t:1527009038265};\\\", \\\"{x:1799,y:684,t:1527009038281};\\\", \\\"{x:1800,y:685,t:1527009038298};\\\", \\\"{x:1800,y:687,t:1527009038595};\\\", \\\"{x:1800,y:690,t:1527009038603};\\\", \\\"{x:1800,y:691,t:1527009038615};\\\", \\\"{x:1800,y:694,t:1527009038632};\\\", \\\"{x:1800,y:696,t:1527009038892};\\\", \\\"{x:1800,y:697,t:1527009039348};\\\", \\\"{x:1799,y:698,t:1527009040788};\\\", \\\"{x:1796,y:701,t:1527009040800};\\\", \\\"{x:1791,y:702,t:1527009040817};\\\", \\\"{x:1787,y:705,t:1527009040834};\\\", \\\"{x:1785,y:705,t:1527009040851};\\\", \\\"{x:1784,y:705,t:1527009040884};\\\", \\\"{x:1781,y:705,t:1527009040901};\\\", \\\"{x:1779,y:700,t:1527009040917};\\\", \\\"{x:1775,y:693,t:1527009040934};\\\", \\\"{x:1770,y:682,t:1527009040951};\\\", \\\"{x:1762,y:673,t:1527009040968};\\\", \\\"{x:1757,y:659,t:1527009040984};\\\", \\\"{x:1750,y:647,t:1527009041001};\\\", \\\"{x:1736,y:629,t:1527009041018};\\\", \\\"{x:1725,y:609,t:1527009041034};\\\", \\\"{x:1711,y:583,t:1527009041051};\\\", \\\"{x:1684,y:542,t:1527009041067};\\\", \\\"{x:1658,y:507,t:1527009041084};\\\", \\\"{x:1627,y:471,t:1527009041100};\\\", \\\"{x:1586,y:436,t:1527009041116};\\\", \\\"{x:1550,y:407,t:1527009041133};\\\", \\\"{x:1526,y:386,t:1527009041150};\\\", \\\"{x:1514,y:374,t:1527009041167};\\\", \\\"{x:1502,y:364,t:1527009041182};\\\", \\\"{x:1497,y:356,t:1527009041200};\\\", \\\"{x:1492,y:351,t:1527009041217};\\\", \\\"{x:1487,y:347,t:1527009041233};\\\", \\\"{x:1480,y:344,t:1527009041250};\\\", \\\"{x:1471,y:343,t:1527009041266};\\\", \\\"{x:1466,y:343,t:1527009041283};\\\", \\\"{x:1460,y:343,t:1527009041300};\\\", \\\"{x:1451,y:343,t:1527009041317};\\\", \\\"{x:1435,y:343,t:1527009041333};\\\", \\\"{x:1416,y:343,t:1527009041350};\\\", \\\"{x:1399,y:343,t:1527009041367};\\\", \\\"{x:1382,y:345,t:1527009041382};\\\", \\\"{x:1361,y:352,t:1527009041400};\\\", \\\"{x:1341,y:358,t:1527009041417};\\\", \\\"{x:1328,y:366,t:1527009041433};\\\", \\\"{x:1309,y:372,t:1527009041450};\\\", \\\"{x:1244,y:387,t:1527009041466};\\\", \\\"{x:1185,y:397,t:1527009041484};\\\", \\\"{x:1141,y:406,t:1527009041500};\\\", \\\"{x:1104,y:413,t:1527009041517};\\\", \\\"{x:1073,y:423,t:1527009041534};\\\", \\\"{x:1049,y:434,t:1527009041549};\\\", \\\"{x:1038,y:441,t:1527009041567};\\\", \\\"{x:1023,y:457,t:1527009041584};\\\", \\\"{x:1005,y:475,t:1527009041600};\\\", \\\"{x:982,y:496,t:1527009041617};\\\", \\\"{x:961,y:521,t:1527009041634};\\\", \\\"{x:934,y:556,t:1527009041650};\\\", \\\"{x:906,y:598,t:1527009041667};\\\", \\\"{x:861,y:665,t:1527009041686};\\\", \\\"{x:844,y:703,t:1527009041703};\\\", \\\"{x:821,y:737,t:1527009041720};\\\", \\\"{x:809,y:756,t:1527009041736};\\\", \\\"{x:804,y:768,t:1527009041753};\\\", \\\"{x:802,y:770,t:1527009041770};\\\", \\\"{x:801,y:771,t:1527009041914};\\\", \\\"{x:800,y:771,t:1527009041922};\\\", \\\"{x:798,y:772,t:1527009041937};\\\", \\\"{x:785,y:772,t:1527009041953};\\\", \\\"{x:767,y:771,t:1527009041970};\\\", \\\"{x:733,y:756,t:1527009041986};\\\", \\\"{x:709,y:747,t:1527009042003};\\\", \\\"{x:701,y:745,t:1527009042020};\\\", \\\"{x:701,y:747,t:1527009042202};\\\", \\\"{x:704,y:752,t:1527009042220};\\\", \\\"{x:709,y:756,t:1527009042237};\\\", \\\"{x:710,y:756,t:1527009042253};\\\", \\\"{x:709,y:756,t:1527009042947};\\\", \\\"{x:709,y:754,t:1527009043012};\\\", \\\"{x:709,y:753,t:1527009043022};\\\", \\\"{x:709,y:750,t:1527009043037};\\\", \\\"{x:709,y:747,t:1527009043054};\\\", \\\"{x:708,y:745,t:1527009043071};\\\", \\\"{x:708,y:744,t:1527009043091};\\\", \\\"{x:709,y:743,t:1527009043170};\\\", \\\"{x:723,y:743,t:1527009043188};\\\", \\\"{x:738,y:743,t:1527009043204};\\\", \\\"{x:767,y:747,t:1527009043221};\\\", \\\"{x:799,y:759,t:1527009043238};\\\", \\\"{x:806,y:765,t:1527009043254};\\\", \\\"{x:811,y:765,t:1527009043563};\\\", \\\"{x:817,y:763,t:1527009043571};\\\", \\\"{x:827,y:760,t:1527009043588};\\\", \\\"{x:850,y:762,t:1527009043604};\\\", \\\"{x:863,y:765,t:1527009043620};\\\", \\\"{x:877,y:769,t:1527009043638};\\\", \\\"{x:893,y:772,t:1527009043655};\\\", \\\"{x:912,y:772,t:1527009043671};\\\", \\\"{x:936,y:772,t:1527009043688};\\\", \\\"{x:972,y:772,t:1527009043705};\\\", \\\"{x:1023,y:770,t:1527009043721};\\\", \\\"{x:1093,y:768,t:1527009043738};\\\", \\\"{x:1182,y:776,t:1527009043755};\\\", \\\"{x:1252,y:787,t:1527009043771};\\\", \\\"{x:1291,y:804,t:1527009043788};\\\", \\\"{x:1320,y:816,t:1527009043805};\\\", \\\"{x:1368,y:834,t:1527009043821};\\\", \\\"{x:1407,y:850,t:1527009043838};\\\", \\\"{x:1443,y:870,t:1527009043855};\\\", \\\"{x:1465,y:887,t:1527009043873};\\\", \\\"{x:1485,y:906,t:1527009043888};\\\", \\\"{x:1507,y:926,t:1527009043905};\\\", \\\"{x:1529,y:938,t:1527009043922};\\\", \\\"{x:1547,y:948,t:1527009043938};\\\", \\\"{x:1555,y:953,t:1527009043955};\\\", \\\"{x:1555,y:956,t:1527009044011};\\\", \\\"{x:1552,y:957,t:1527009044022};\\\", \\\"{x:1537,y:957,t:1527009044038};\\\", \\\"{x:1520,y:957,t:1527009044055};\\\", \\\"{x:1504,y:957,t:1527009044072};\\\", \\\"{x:1490,y:959,t:1527009044088};\\\", \\\"{x:1481,y:961,t:1527009044105};\\\", \\\"{x:1472,y:962,t:1527009044122};\\\", \\\"{x:1465,y:964,t:1527009044138};\\\", \\\"{x:1457,y:968,t:1527009044155};\\\", \\\"{x:1453,y:970,t:1527009044172};\\\", \\\"{x:1448,y:973,t:1527009044188};\\\", \\\"{x:1443,y:975,t:1527009044205};\\\", \\\"{x:1437,y:977,t:1527009044221};\\\", \\\"{x:1431,y:979,t:1527009044239};\\\", \\\"{x:1427,y:982,t:1527009044259};\\\", \\\"{x:1424,y:982,t:1527009044272};\\\", \\\"{x:1416,y:982,t:1527009044289};\\\", \\\"{x:1408,y:982,t:1527009044305};\\\", \\\"{x:1404,y:982,t:1527009044322};\\\", \\\"{x:1395,y:982,t:1527009044338};\\\", \\\"{x:1392,y:982,t:1527009044355};\\\", \\\"{x:1391,y:981,t:1527009044372};\\\", \\\"{x:1387,y:980,t:1527009044389};\\\", \\\"{x:1380,y:979,t:1527009044405};\\\", \\\"{x:1376,y:978,t:1527009044422};\\\", \\\"{x:1374,y:978,t:1527009044439};\\\", \\\"{x:1370,y:978,t:1527009044455};\\\", \\\"{x:1369,y:978,t:1527009044499};\\\", \\\"{x:1369,y:977,t:1527009044514};\\\", \\\"{x:1367,y:977,t:1527009044522};\\\", \\\"{x:1364,y:976,t:1527009044539};\\\", \\\"{x:1359,y:973,t:1527009044554};\\\", \\\"{x:1350,y:971,t:1527009044572};\\\", \\\"{x:1342,y:969,t:1527009044589};\\\", \\\"{x:1340,y:968,t:1527009044605};\\\", \\\"{x:1339,y:966,t:1527009044622};\\\", \\\"{x:1338,y:966,t:1527009044640};\\\", \\\"{x:1337,y:964,t:1527009044723};\\\", \\\"{x:1333,y:962,t:1527009044739};\\\", \\\"{x:1332,y:961,t:1527009044756};\\\", \\\"{x:1331,y:959,t:1527009044772};\\\", \\\"{x:1329,y:959,t:1527009044789};\\\", \\\"{x:1328,y:959,t:1527009045898};\\\", \\\"{x:1326,y:959,t:1527009045906};\\\", \\\"{x:1325,y:959,t:1527009045924};\\\", \\\"{x:1324,y:959,t:1527009046131};\\\", \\\"{x:1323,y:959,t:1527009046140};\\\", \\\"{x:1322,y:959,t:1527009046251};\\\", \\\"{x:1322,y:958,t:1527009046282};\\\", \\\"{x:1322,y:957,t:1527009046298};\\\", \\\"{x:1322,y:956,t:1527009046611};\\\", \\\"{x:1322,y:955,t:1527009046707};\\\", \\\"{x:1322,y:954,t:1527009046724};\\\", \\\"{x:1323,y:953,t:1527009046742};\\\", \\\"{x:1323,y:952,t:1527009046763};\\\", \\\"{x:1325,y:952,t:1527009046778};\\\", \\\"{x:1326,y:952,t:1527009046791};\\\", \\\"{x:1329,y:951,t:1527009046807};\\\", \\\"{x:1330,y:950,t:1527009046824};\\\", \\\"{x:1332,y:950,t:1527009046841};\\\", \\\"{x:1334,y:949,t:1527009046857};\\\", \\\"{x:1335,y:949,t:1527009046874};\\\", \\\"{x:1338,y:949,t:1527009046890};\\\", \\\"{x:1339,y:949,t:1527009046907};\\\", \\\"{x:1343,y:951,t:1527009046924};\\\", \\\"{x:1347,y:952,t:1527009046941};\\\", \\\"{x:1350,y:955,t:1527009046957};\\\", \\\"{x:1352,y:956,t:1527009046974};\\\", \\\"{x:1352,y:957,t:1527009046991};\\\", \\\"{x:1353,y:958,t:1527009047026};\\\", \\\"{x:1352,y:958,t:1527009047074};\\\", \\\"{x:1349,y:958,t:1527009047091};\\\", \\\"{x:1342,y:958,t:1527009047108};\\\", \\\"{x:1340,y:958,t:1527009047124};\\\", \\\"{x:1338,y:959,t:1527009047219};\\\", \\\"{x:1339,y:960,t:1527009047435};\\\", \\\"{x:1340,y:960,t:1527009047764};\\\", \\\"{x:1341,y:960,t:1527009047776};\\\", \\\"{x:1342,y:960,t:1527009047803};\\\", \\\"{x:1344,y:959,t:1527009048116};\\\", \\\"{x:1349,y:957,t:1527009048126};\\\", \\\"{x:1361,y:952,t:1527009048142};\\\", \\\"{x:1368,y:950,t:1527009048159};\\\", \\\"{x:1374,y:946,t:1527009048176};\\\", \\\"{x:1379,y:944,t:1527009048193};\\\", \\\"{x:1381,y:943,t:1527009048209};\\\", \\\"{x:1385,y:940,t:1527009048227};\\\", \\\"{x:1390,y:940,t:1527009048244};\\\", \\\"{x:1392,y:940,t:1527009048259};\\\", \\\"{x:1410,y:938,t:1527009048276};\\\", \\\"{x:1420,y:938,t:1527009048293};\\\", \\\"{x:1426,y:938,t:1527009048309};\\\", \\\"{x:1430,y:938,t:1527009048326};\\\", \\\"{x:1431,y:938,t:1527009048343};\\\", \\\"{x:1431,y:936,t:1527009048452};\\\", \\\"{x:1431,y:935,t:1527009048460};\\\", \\\"{x:1431,y:933,t:1527009048476};\\\", \\\"{x:1430,y:932,t:1527009049325};\\\", \\\"{x:1429,y:931,t:1527009049332};\\\", \\\"{x:1429,y:929,t:1527009049343};\\\", \\\"{x:1429,y:926,t:1527009049359};\\\", \\\"{x:1428,y:922,t:1527009049377};\\\", \\\"{x:1428,y:920,t:1527009049393};\\\", \\\"{x:1427,y:917,t:1527009049409};\\\", \\\"{x:1427,y:916,t:1527009049435};\\\", \\\"{x:1426,y:915,t:1527009049459};\\\", \\\"{x:1426,y:913,t:1527009049482};\\\", \\\"{x:1423,y:910,t:1527009049493};\\\", \\\"{x:1415,y:904,t:1527009049510};\\\", \\\"{x:1387,y:893,t:1527009049526};\\\", \\\"{x:1325,y:874,t:1527009049544};\\\", \\\"{x:1245,y:852,t:1527009049560};\\\", \\\"{x:1183,y:833,t:1527009049577};\\\", \\\"{x:1134,y:814,t:1527009049594};\\\", \\\"{x:1089,y:802,t:1527009049611};\\\", \\\"{x:1081,y:799,t:1527009049626};\\\", \\\"{x:1087,y:801,t:1527009049828};\\\", \\\"{x:1104,y:805,t:1527009049844};\\\", \\\"{x:1120,y:809,t:1527009049862};\\\", \\\"{x:1140,y:814,t:1527009049878};\\\", \\\"{x:1160,y:820,t:1527009049894};\\\", \\\"{x:1174,y:823,t:1527009049911};\\\", \\\"{x:1184,y:824,t:1527009049927};\\\", \\\"{x:1187,y:825,t:1527009049944};\\\", \\\"{x:1188,y:825,t:1527009049960};\\\", \\\"{x:1189,y:825,t:1527009050020};\\\", \\\"{x:1191,y:825,t:1527009050027};\\\", \\\"{x:1193,y:827,t:1527009050043};\\\", \\\"{x:1196,y:827,t:1527009050061};\\\", \\\"{x:1200,y:829,t:1527009050077};\\\", \\\"{x:1206,y:831,t:1527009050094};\\\", \\\"{x:1209,y:832,t:1527009050113};\\\", \\\"{x:1214,y:836,t:1527009050128};\\\", \\\"{x:1216,y:836,t:1527009050143};\\\", \\\"{x:1222,y:837,t:1527009050160};\\\", \\\"{x:1230,y:839,t:1527009050177};\\\", \\\"{x:1240,y:841,t:1527009050193};\\\", \\\"{x:1248,y:846,t:1527009050211};\\\", \\\"{x:1251,y:846,t:1527009050227};\\\", \\\"{x:1249,y:846,t:1527009050307};\\\", \\\"{x:1248,y:846,t:1527009050315};\\\", \\\"{x:1245,y:846,t:1527009050328};\\\", \\\"{x:1237,y:844,t:1527009050344};\\\", \\\"{x:1227,y:843,t:1527009050360};\\\", \\\"{x:1218,y:841,t:1527009050377};\\\", \\\"{x:1215,y:840,t:1527009050394};\\\", \\\"{x:1214,y:840,t:1527009050410};\\\", \\\"{x:1213,y:839,t:1527009050595};\\\", \\\"{x:1213,y:837,t:1527009050610};\\\", \\\"{x:1213,y:836,t:1527009050627};\\\", \\\"{x:1213,y:834,t:1527009050644};\\\", \\\"{x:1213,y:833,t:1527009050660};\\\", \\\"{x:1213,y:832,t:1527009050683};\\\", \\\"{x:1213,y:831,t:1527009050714};\\\", \\\"{x:1214,y:829,t:1527009050731};\\\", \\\"{x:1215,y:828,t:1527009063483};\\\", \\\"{x:1219,y:827,t:1527009066131};\\\", \\\"{x:1228,y:827,t:1527009066143};\\\", \\\"{x:1244,y:834,t:1527009066158};\\\", \\\"{x:1261,y:840,t:1527009066175};\\\", \\\"{x:1282,y:848,t:1527009066191};\\\", \\\"{x:1300,y:858,t:1527009066207};\\\", \\\"{x:1317,y:867,t:1527009066225};\\\", \\\"{x:1338,y:878,t:1527009066242};\\\", \\\"{x:1349,y:887,t:1527009066258};\\\", \\\"{x:1360,y:898,t:1527009066275};\\\", \\\"{x:1368,y:913,t:1527009066291};\\\", \\\"{x:1370,y:922,t:1527009066307};\\\", \\\"{x:1370,y:934,t:1527009066324};\\\", \\\"{x:1370,y:945,t:1527009066341};\\\", \\\"{x:1369,y:963,t:1527009066358};\\\", \\\"{x:1366,y:975,t:1527009066375};\\\", \\\"{x:1356,y:990,t:1527009066392};\\\", \\\"{x:1345,y:1002,t:1527009066408};\\\", \\\"{x:1335,y:1013,t:1527009066425};\\\", \\\"{x:1319,y:1026,t:1527009066442};\\\", \\\"{x:1315,y:1032,t:1527009066458};\\\", \\\"{x:1300,y:1041,t:1527009066474};\\\", \\\"{x:1276,y:1051,t:1527009066491};\\\", \\\"{x:1274,y:1051,t:1527009066508};\\\", \\\"{x:1272,y:1051,t:1527009066531};\\\", \\\"{x:1272,y:1049,t:1527009066547};\\\", \\\"{x:1270,y:1047,t:1527009066558};\\\", \\\"{x:1269,y:1042,t:1527009066577};\\\", \\\"{x:1269,y:1037,t:1527009066591};\\\", \\\"{x:1269,y:1030,t:1527009066608};\\\", \\\"{x:1271,y:1020,t:1527009066624};\\\", \\\"{x:1280,y:1000,t:1527009066641};\\\", \\\"{x:1288,y:978,t:1527009066658};\\\", \\\"{x:1293,y:966,t:1527009066674};\\\", \\\"{x:1299,y:959,t:1527009066691};\\\", \\\"{x:1308,y:953,t:1527009066708};\\\", \\\"{x:1314,y:948,t:1527009066724};\\\", \\\"{x:1317,y:945,t:1527009066741};\\\", \\\"{x:1322,y:940,t:1527009066758};\\\", \\\"{x:1325,y:937,t:1527009066774};\\\", \\\"{x:1328,y:934,t:1527009066792};\\\", \\\"{x:1329,y:933,t:1527009066810};\\\", \\\"{x:1330,y:933,t:1527009066956};\\\", \\\"{x:1327,y:936,t:1527009066963};\\\", \\\"{x:1319,y:944,t:1527009066976};\\\", \\\"{x:1307,y:953,t:1527009066991};\\\", \\\"{x:1302,y:957,t:1527009067008};\\\", \\\"{x:1302,y:958,t:1527009067026};\\\", \\\"{x:1303,y:958,t:1527009067268};\\\", \\\"{x:1305,y:958,t:1527009067572};\\\", \\\"{x:1309,y:958,t:1527009067580};\\\", \\\"{x:1318,y:958,t:1527009067593};\\\", \\\"{x:1329,y:959,t:1527009067609};\\\", \\\"{x:1345,y:959,t:1527009067626};\\\", \\\"{x:1364,y:960,t:1527009067644};\\\", \\\"{x:1374,y:960,t:1527009067659};\\\", \\\"{x:1395,y:962,t:1527009067676};\\\", \\\"{x:1416,y:962,t:1527009067693};\\\", \\\"{x:1426,y:962,t:1527009067710};\\\", \\\"{x:1434,y:962,t:1527009067726};\\\", \\\"{x:1444,y:962,t:1527009067743};\\\", \\\"{x:1447,y:962,t:1527009067760};\\\", \\\"{x:1450,y:962,t:1527009067776};\\\", \\\"{x:1454,y:962,t:1527009067793};\\\", \\\"{x:1459,y:962,t:1527009067810};\\\", \\\"{x:1467,y:961,t:1527009067826};\\\", \\\"{x:1491,y:956,t:1527009067843};\\\", \\\"{x:1503,y:953,t:1527009067860};\\\", \\\"{x:1516,y:952,t:1527009067876};\\\", \\\"{x:1523,y:952,t:1527009067893};\\\", \\\"{x:1526,y:951,t:1527009067910};\\\", \\\"{x:1527,y:951,t:1527009067927};\\\", \\\"{x:1528,y:952,t:1527009068092};\\\", \\\"{x:1527,y:954,t:1527009068116};\\\", \\\"{x:1526,y:955,t:1527009068172};\\\", \\\"{x:1522,y:957,t:1527009068188};\\\", \\\"{x:1520,y:957,t:1527009068195};\\\", \\\"{x:1517,y:959,t:1527009068211};\\\", \\\"{x:1506,y:960,t:1527009068227};\\\", \\\"{x:1497,y:962,t:1527009068243};\\\", \\\"{x:1492,y:962,t:1527009068260};\\\", \\\"{x:1485,y:963,t:1527009068277};\\\", \\\"{x:1476,y:964,t:1527009068292};\\\", \\\"{x:1462,y:965,t:1527009068309};\\\", \\\"{x:1452,y:968,t:1527009068327};\\\", \\\"{x:1438,y:969,t:1527009068342};\\\", \\\"{x:1422,y:969,t:1527009068359};\\\", \\\"{x:1416,y:970,t:1527009068376};\\\", \\\"{x:1409,y:972,t:1527009068392};\\\", \\\"{x:1402,y:973,t:1527009068409};\\\", \\\"{x:1395,y:976,t:1527009068426};\\\", \\\"{x:1390,y:977,t:1527009068443};\\\", \\\"{x:1385,y:978,t:1527009068460};\\\", \\\"{x:1379,y:978,t:1527009068476};\\\", \\\"{x:1371,y:978,t:1527009068494};\\\", \\\"{x:1362,y:978,t:1527009068509};\\\", \\\"{x:1348,y:978,t:1527009068526};\\\", \\\"{x:1336,y:978,t:1527009068543};\\\", \\\"{x:1324,y:978,t:1527009068560};\\\", \\\"{x:1314,y:978,t:1527009068576};\\\", \\\"{x:1308,y:978,t:1527009068593};\\\", \\\"{x:1306,y:978,t:1527009068609};\\\", \\\"{x:1303,y:978,t:1527009068626};\\\", \\\"{x:1302,y:978,t:1527009068667};\\\", \\\"{x:1301,y:978,t:1527009068683};\\\", \\\"{x:1300,y:978,t:1527009069380};\\\", \\\"{x:1299,y:978,t:1527009069394};\\\", \\\"{x:1296,y:977,t:1527009069411};\\\", \\\"{x:1294,y:977,t:1527009069428};\\\", \\\"{x:1293,y:975,t:1527009069652};\\\", \\\"{x:1292,y:975,t:1527009069660};\\\", \\\"{x:1291,y:973,t:1527009069678};\\\", \\\"{x:1290,y:973,t:1527009069694};\\\", \\\"{x:1288,y:970,t:1527009069711};\\\", \\\"{x:1287,y:970,t:1527009069731};\\\", \\\"{x:1286,y:970,t:1527009069745};\\\", \\\"{x:1285,y:968,t:1527009069762};\\\", \\\"{x:1284,y:967,t:1527009069778};\\\", \\\"{x:1283,y:966,t:1527009069795};\\\", \\\"{x:1282,y:966,t:1527009069811};\\\", \\\"{x:1282,y:965,t:1527009069843};\\\", \\\"{x:1285,y:965,t:1527009070260};\\\", \\\"{x:1290,y:965,t:1527009070268};\\\", \\\"{x:1294,y:965,t:1527009070278};\\\", \\\"{x:1301,y:965,t:1527009070294};\\\", \\\"{x:1303,y:965,t:1527009070362};\\\", \\\"{x:1304,y:965,t:1527009070387};\\\", \\\"{x:1305,y:965,t:1527009070419};\\\", \\\"{x:1307,y:965,t:1527009070442};\\\", \\\"{x:1310,y:964,t:1527009070451};\\\", \\\"{x:1311,y:964,t:1527009070467};\\\", \\\"{x:1314,y:964,t:1527009070483};\\\", \\\"{x:1315,y:964,t:1527009070499};\\\", \\\"{x:1317,y:963,t:1527009070547};\\\", \\\"{x:1320,y:963,t:1527009070571};\\\", \\\"{x:1321,y:963,t:1527009070580};\\\", \\\"{x:1322,y:962,t:1527009070619};\\\", \\\"{x:1323,y:962,t:1527009070668};\\\", \\\"{x:1323,y:961,t:1527009070679};\\\", \\\"{x:1324,y:961,t:1527009070695};\\\", \\\"{x:1325,y:961,t:1527009070828};\\\", \\\"{x:1327,y:959,t:1527009071435};\\\", \\\"{x:1329,y:958,t:1527009071476};\\\", \\\"{x:1329,y:957,t:1527009071500};\\\", \\\"{x:1330,y:957,t:1527009071513};\\\", \\\"{x:1332,y:956,t:1527009071530};\\\", \\\"{x:1332,y:955,t:1527009071547};\\\", \\\"{x:1336,y:954,t:1527009071563};\\\", \\\"{x:1341,y:953,t:1527009071579};\\\", \\\"{x:1345,y:953,t:1527009071596};\\\", \\\"{x:1350,y:951,t:1527009071612};\\\", \\\"{x:1351,y:951,t:1527009071629};\\\", \\\"{x:1352,y:950,t:1527009071876};\\\", \\\"{x:1353,y:950,t:1527009071899};\\\", \\\"{x:1355,y:950,t:1527009071923};\\\", \\\"{x:1356,y:950,t:1527009071931};\\\", \\\"{x:1358,y:950,t:1527009071946};\\\", \\\"{x:1361,y:949,t:1527009071962};\\\", \\\"{x:1363,y:949,t:1527009071979};\\\", \\\"{x:1364,y:949,t:1527009071995};\\\", \\\"{x:1367,y:948,t:1527009072013};\\\", \\\"{x:1370,y:948,t:1527009072034};\\\", \\\"{x:1371,y:948,t:1527009072050};\\\", \\\"{x:1372,y:948,t:1527009072063};\\\", \\\"{x:1373,y:947,t:1527009072079};\\\", \\\"{x:1379,y:947,t:1527009072363};\\\", \\\"{x:1401,y:946,t:1527009072380};\\\", \\\"{x:1408,y:946,t:1527009072396};\\\", \\\"{x:1422,y:949,t:1527009072413};\\\", \\\"{x:1435,y:954,t:1527009072430};\\\", \\\"{x:1444,y:955,t:1527009072447};\\\", \\\"{x:1447,y:955,t:1527009072463};\\\", \\\"{x:1445,y:955,t:1527009072740};\\\", \\\"{x:1443,y:955,t:1527009072747};\\\", \\\"{x:1438,y:955,t:1527009072763};\\\", \\\"{x:1436,y:957,t:1527009072781};\\\", \\\"{x:1435,y:958,t:1527009072798};\\\", \\\"{x:1433,y:958,t:1527009073140};\\\", \\\"{x:1431,y:958,t:1527009073153};\\\", \\\"{x:1430,y:959,t:1527009073163};\\\", \\\"{x:1429,y:960,t:1527009073242};\\\", \\\"{x:1428,y:961,t:1527009073258};\\\", \\\"{x:1427,y:961,t:1527009073266};\\\", \\\"{x:1425,y:961,t:1527009073281};\\\", \\\"{x:1421,y:963,t:1527009073296};\\\", \\\"{x:1421,y:964,t:1527009073314};\\\", \\\"{x:1420,y:966,t:1527009073331};\\\", \\\"{x:1420,y:968,t:1527009073724};\\\", \\\"{x:1420,y:972,t:1527009073731};\\\", \\\"{x:1432,y:986,t:1527009073748};\\\", \\\"{x:1460,y:1004,t:1527009073764};\\\", \\\"{x:1470,y:1017,t:1527009073781};\\\", \\\"{x:1475,y:1023,t:1527009073798};\\\", \\\"{x:1477,y:1024,t:1527009073814};\\\", \\\"{x:1475,y:1022,t:1527009073860};\\\", \\\"{x:1469,y:1020,t:1527009073875};\\\", \\\"{x:1468,y:1019,t:1527009073883};\\\", \\\"{x:1463,y:1017,t:1527009073899};\\\", \\\"{x:1449,y:1012,t:1527009073915};\\\", \\\"{x:1446,y:1010,t:1527009073931};\\\", \\\"{x:1443,y:1008,t:1527009073948};\\\", \\\"{x:1439,y:1006,t:1527009073965};\\\", \\\"{x:1437,y:1006,t:1527009073982};\\\", \\\"{x:1434,y:1003,t:1527009073998};\\\", \\\"{x:1432,y:1002,t:1527009074015};\\\", \\\"{x:1423,y:998,t:1527009074031};\\\", \\\"{x:1415,y:992,t:1527009074048};\\\", \\\"{x:1406,y:988,t:1527009074065};\\\", \\\"{x:1402,y:985,t:1527009074082};\\\", \\\"{x:1401,y:985,t:1527009074098};\\\", \\\"{x:1400,y:984,t:1527009074147};\\\", \\\"{x:1399,y:981,t:1527009074165};\\\", \\\"{x:1396,y:975,t:1527009074181};\\\", \\\"{x:1395,y:969,t:1527009074198};\\\", \\\"{x:1395,y:968,t:1527009074933};\\\", \\\"{x:1395,y:967,t:1527009074949};\\\", \\\"{x:1395,y:966,t:1527009074980};\\\", \\\"{x:1395,y:965,t:1527009074996};\\\", \\\"{x:1395,y:964,t:1527009075003};\\\", \\\"{x:1394,y:963,t:1527009075016};\\\", \\\"{x:1393,y:963,t:1527009075032};\\\", \\\"{x:1389,y:963,t:1527009075050};\\\", \\\"{x:1386,y:963,t:1527009075067};\\\", \\\"{x:1375,y:964,t:1527009075082};\\\", \\\"{x:1365,y:966,t:1527009075098};\\\", \\\"{x:1364,y:966,t:1527009075115};\\\", \\\"{x:1361,y:968,t:1527009075131};\\\", \\\"{x:1362,y:968,t:1527009075356};\\\", \\\"{x:1372,y:968,t:1527009075367};\\\", \\\"{x:1390,y:965,t:1527009075382};\\\", \\\"{x:1395,y:961,t:1527009075400};\\\", \\\"{x:1399,y:958,t:1527009075416};\\\", \\\"{x:1402,y:957,t:1527009075433};\\\", \\\"{x:1403,y:957,t:1527009075876};\\\", \\\"{x:1404,y:957,t:1527009075947};\\\", \\\"{x:1405,y:958,t:1527009075962};\\\", \\\"{x:1406,y:958,t:1527009075971};\\\", \\\"{x:1407,y:961,t:1527009075986};\\\", \\\"{x:1408,y:961,t:1527009076011};\\\", \\\"{x:1409,y:961,t:1527009076068};\\\", \\\"{x:1409,y:962,t:1527009076099};\\\", \\\"{x:1410,y:964,t:1527009076260};\\\", \\\"{x:1410,y:965,t:1527009076316};\\\", \\\"{x:1410,y:966,t:1527009076332};\\\", \\\"{x:1411,y:967,t:1527009076347};\\\", \\\"{x:1412,y:968,t:1527009076420};\\\", \\\"{x:1412,y:969,t:1527009076468};\\\", \\\"{x:1412,y:970,t:1527009091464};\\\", \\\"{x:1411,y:971,t:1527009091476};\\\", \\\"{x:1389,y:971,t:1527009091494};\\\", \\\"{x:1367,y:969,t:1527009091509};\\\", \\\"{x:1347,y:964,t:1527009091527};\\\", \\\"{x:1329,y:962,t:1527009091543};\\\", \\\"{x:1328,y:962,t:1527009091560};\\\", \\\"{x:1326,y:962,t:1527009091624};\\\", \\\"{x:1325,y:962,t:1527009091632};\\\", \\\"{x:1323,y:962,t:1527009091644};\\\", \\\"{x:1321,y:962,t:1527009091659};\\\", \\\"{x:1318,y:962,t:1527009091677};\\\", \\\"{x:1306,y:960,t:1527009091694};\\\", \\\"{x:1298,y:959,t:1527009091710};\\\", \\\"{x:1290,y:957,t:1527009091728};\\\", \\\"{x:1288,y:957,t:1527009091744};\\\", \\\"{x:1287,y:957,t:1527009091760};\\\", \\\"{x:1285,y:957,t:1527009092561};\\\", \\\"{x:1284,y:957,t:1527009092579};\\\", \\\"{x:1282,y:957,t:1527009092594};\\\", \\\"{x:1281,y:957,t:1527009092612};\\\", \\\"{x:1280,y:957,t:1527009093840};\\\", \\\"{x:1279,y:957,t:1527009093847};\\\", \\\"{x:1279,y:956,t:1527009093862};\\\", \\\"{x:1279,y:955,t:1527009093879};\\\", \\\"{x:1279,y:954,t:1527009093894};\\\", \\\"{x:1279,y:952,t:1527009093911};\\\", \\\"{x:1279,y:951,t:1527009093929};\\\", \\\"{x:1279,y:947,t:1527009093946};\\\", \\\"{x:1279,y:946,t:1527009093961};\\\", \\\"{x:1279,y:943,t:1527009093979};\\\", \\\"{x:1279,y:942,t:1527009093996};\\\", \\\"{x:1279,y:940,t:1527009094012};\\\", \\\"{x:1279,y:939,t:1527009094029};\\\", \\\"{x:1279,y:935,t:1527009094046};\\\", \\\"{x:1281,y:931,t:1527009094062};\\\", \\\"{x:1281,y:927,t:1527009094079};\\\", \\\"{x:1281,y:920,t:1527009094096};\\\", \\\"{x:1283,y:910,t:1527009094112};\\\", \\\"{x:1285,y:899,t:1527009094129};\\\", \\\"{x:1288,y:882,t:1527009094146};\\\", \\\"{x:1291,y:855,t:1527009094162};\\\", \\\"{x:1294,y:835,t:1527009094179};\\\", \\\"{x:1296,y:816,t:1527009094196};\\\", \\\"{x:1300,y:799,t:1527009094212};\\\", \\\"{x:1302,y:785,t:1527009094229};\\\", \\\"{x:1306,y:771,t:1527009094247};\\\", \\\"{x:1308,y:764,t:1527009094263};\\\", \\\"{x:1312,y:751,t:1527009094279};\\\", \\\"{x:1317,y:734,t:1527009094297};\\\", \\\"{x:1320,y:723,t:1527009094313};\\\", \\\"{x:1321,y:716,t:1527009094329};\\\", \\\"{x:1323,y:707,t:1527009094346};\\\", \\\"{x:1324,y:702,t:1527009094363};\\\", \\\"{x:1325,y:700,t:1527009094379};\\\", \\\"{x:1325,y:699,t:1527009094397};\\\", \\\"{x:1325,y:698,t:1527009094440};\\\", \\\"{x:1325,y:697,t:1527009094449};\\\", \\\"{x:1325,y:695,t:1527009094464};\\\", \\\"{x:1325,y:691,t:1527009094479};\\\", \\\"{x:1326,y:682,t:1527009094495};\\\", \\\"{x:1326,y:673,t:1527009094513};\\\", \\\"{x:1326,y:657,t:1527009094528};\\\", \\\"{x:1324,y:641,t:1527009094546};\\\", \\\"{x:1321,y:619,t:1527009094563};\\\", \\\"{x:1321,y:601,t:1527009094579};\\\", \\\"{x:1320,y:586,t:1527009094596};\\\", \\\"{x:1317,y:573,t:1527009094613};\\\", \\\"{x:1316,y:570,t:1527009094629};\\\", \\\"{x:1314,y:566,t:1527009094645};\\\", \\\"{x:1314,y:562,t:1527009094663};\\\", \\\"{x:1314,y:560,t:1527009094679};\\\", \\\"{x:1314,y:558,t:1527009094695};\\\", \\\"{x:1313,y:556,t:1527009094713};\\\", \\\"{x:1309,y:551,t:1527009095120};\\\", \\\"{x:1308,y:550,t:1527009095129};\\\", \\\"{x:1304,y:545,t:1527009095145};\\\", \\\"{x:1297,y:542,t:1527009095163};\\\", \\\"{x:1287,y:539,t:1527009095180};\\\", \\\"{x:1283,y:539,t:1527009095196};\\\", \\\"{x:1281,y:538,t:1527009095213};\\\", \\\"{x:1280,y:538,t:1527009095230};\\\", \\\"{x:1279,y:538,t:1527009095288};\\\", \\\"{x:1278,y:539,t:1527009095304};\\\", \\\"{x:1277,y:541,t:1527009095320};\\\", \\\"{x:1277,y:542,t:1527009095344};\\\", \\\"{x:1276,y:544,t:1527009095352};\\\", \\\"{x:1275,y:546,t:1527009095363};\\\", \\\"{x:1275,y:547,t:1527009095381};\\\", \\\"{x:1274,y:551,t:1527009095397};\\\", \\\"{x:1272,y:556,t:1527009095413};\\\", \\\"{x:1272,y:560,t:1527009095431};\\\", \\\"{x:1271,y:564,t:1527009095448};\\\", \\\"{x:1271,y:570,t:1527009095463};\\\", \\\"{x:1271,y:573,t:1527009095480};\\\", \\\"{x:1271,y:574,t:1527009095497};\\\", \\\"{x:1271,y:576,t:1527009095513};\\\", \\\"{x:1271,y:577,t:1527009095530};\\\", \\\"{x:1271,y:580,t:1527009095547};\\\", \\\"{x:1271,y:581,t:1527009095563};\\\", \\\"{x:1271,y:584,t:1527009095581};\\\", \\\"{x:1271,y:587,t:1527009095597};\\\", \\\"{x:1271,y:589,t:1527009095614};\\\", \\\"{x:1271,y:592,t:1527009095630};\\\", \\\"{x:1271,y:594,t:1527009095647};\\\", \\\"{x:1275,y:597,t:1527009095664};\\\", \\\"{x:1277,y:598,t:1527009095680};\\\", \\\"{x:1277,y:599,t:1527009095696};\\\", \\\"{x:1278,y:602,t:1527009095713};\\\", \\\"{x:1278,y:605,t:1527009095730};\\\", \\\"{x:1281,y:608,t:1527009095760};\\\", \\\"{x:1281,y:611,t:1527009095767};\\\", \\\"{x:1281,y:615,t:1527009095780};\\\", \\\"{x:1280,y:623,t:1527009095797};\\\", \\\"{x:1280,y:633,t:1527009095813};\\\", \\\"{x:1280,y:648,t:1527009095830};\\\", \\\"{x:1280,y:662,t:1527009095846};\\\", \\\"{x:1280,y:689,t:1527009095863};\\\", \\\"{x:1280,y:706,t:1527009095880};\\\", \\\"{x:1281,y:728,t:1527009095897};\\\", \\\"{x:1283,y:746,t:1527009095914};\\\", \\\"{x:1288,y:769,t:1527009095930};\\\", \\\"{x:1295,y:788,t:1527009095947};\\\", \\\"{x:1307,y:808,t:1527009095964};\\\", \\\"{x:1321,y:823,t:1527009095980};\\\", \\\"{x:1334,y:832,t:1527009095996};\\\", \\\"{x:1348,y:837,t:1527009096014};\\\", \\\"{x:1350,y:839,t:1527009096031};\\\", \\\"{x:1353,y:840,t:1527009096047};\\\", \\\"{x:1353,y:841,t:1527009096064};\\\", \\\"{x:1354,y:842,t:1527009096137};\\\", \\\"{x:1354,y:843,t:1527009096152};\\\", \\\"{x:1354,y:844,t:1527009096168};\\\", \\\"{x:1354,y:845,t:1527009096192};\\\", \\\"{x:1352,y:843,t:1527009096352};\\\", \\\"{x:1347,y:838,t:1527009096365};\\\", \\\"{x:1339,y:832,t:1527009096382};\\\", \\\"{x:1329,y:822,t:1527009096398};\\\", \\\"{x:1313,y:802,t:1527009096415};\\\", \\\"{x:1274,y:761,t:1527009096432};\\\", \\\"{x:1181,y:692,t:1527009096448};\\\", \\\"{x:1149,y:669,t:1527009096464};\\\", \\\"{x:1144,y:660,t:1527009096482};\\\", \\\"{x:1143,y:659,t:1527009096499};\\\", \\\"{x:1143,y:657,t:1527009096515};\\\", \\\"{x:1143,y:654,t:1527009096531};\\\", \\\"{x:1144,y:653,t:1527009096548};\\\", \\\"{x:1145,y:652,t:1527009096565};\\\", \\\"{x:1146,y:651,t:1527009096582};\\\", \\\"{x:1148,y:651,t:1527009096608};\\\", \\\"{x:1149,y:651,t:1527009096616};\\\", \\\"{x:1150,y:651,t:1527009096631};\\\", \\\"{x:1174,y:668,t:1527009096648};\\\", \\\"{x:1205,y:690,t:1527009096664};\\\", \\\"{x:1224,y:711,t:1527009096681};\\\", \\\"{x:1252,y:743,t:1527009096699};\\\", \\\"{x:1280,y:787,t:1527009096715};\\\", \\\"{x:1296,y:826,t:1527009096732};\\\", \\\"{x:1301,y:852,t:1527009096748};\\\", \\\"{x:1301,y:874,t:1527009096765};\\\", \\\"{x:1301,y:887,t:1527009096780};\\\", \\\"{x:1301,y:900,t:1527009096798};\\\", \\\"{x:1301,y:911,t:1527009096815};\\\", \\\"{x:1301,y:918,t:1527009096831};\\\", \\\"{x:1300,y:923,t:1527009096848};\\\", \\\"{x:1300,y:925,t:1527009096865};\\\", \\\"{x:1299,y:926,t:1527009096881};\\\", \\\"{x:1299,y:928,t:1527009096898};\\\", \\\"{x:1298,y:932,t:1527009096915};\\\", \\\"{x:1297,y:933,t:1527009096931};\\\", \\\"{x:1296,y:937,t:1527009096948};\\\", \\\"{x:1296,y:938,t:1527009096965};\\\", \\\"{x:1296,y:939,t:1527009096981};\\\", \\\"{x:1295,y:941,t:1527009097000};\\\", \\\"{x:1294,y:941,t:1527009097064};\\\", \\\"{x:1294,y:942,t:1527009097104};\\\", \\\"{x:1294,y:939,t:1527009097115};\\\", \\\"{x:1293,y:931,t:1527009097131};\\\", \\\"{x:1292,y:919,t:1527009097148};\\\", \\\"{x:1292,y:904,t:1527009097165};\\\", \\\"{x:1292,y:889,t:1527009097181};\\\", \\\"{x:1292,y:873,t:1527009097199};\\\", \\\"{x:1292,y:852,t:1527009097216};\\\", \\\"{x:1290,y:826,t:1527009097232};\\\", \\\"{x:1289,y:812,t:1527009097249};\\\", \\\"{x:1287,y:799,t:1527009097265};\\\", \\\"{x:1285,y:789,t:1527009097282};\\\", \\\"{x:1284,y:780,t:1527009097298};\\\", \\\"{x:1284,y:769,t:1527009097315};\\\", \\\"{x:1280,y:756,t:1527009097331};\\\", \\\"{x:1279,y:749,t:1527009097348};\\\", \\\"{x:1278,y:741,t:1527009097364};\\\", \\\"{x:1275,y:733,t:1527009097382};\\\", \\\"{x:1274,y:721,t:1527009097398};\\\", \\\"{x:1273,y:710,t:1527009097414};\\\", \\\"{x:1266,y:690,t:1527009097431};\\\", \\\"{x:1264,y:680,t:1527009097447};\\\", \\\"{x:1258,y:667,t:1527009097465};\\\", \\\"{x:1256,y:661,t:1527009097482};\\\", \\\"{x:1254,y:657,t:1527009097498};\\\", \\\"{x:1253,y:654,t:1527009097515};\\\", \\\"{x:1253,y:652,t:1527009097532};\\\", \\\"{x:1251,y:650,t:1527009097548};\\\", \\\"{x:1251,y:648,t:1527009097565};\\\", \\\"{x:1251,y:646,t:1527009097581};\\\", \\\"{x:1251,y:644,t:1527009097598};\\\", \\\"{x:1251,y:643,t:1527009097615};\\\", \\\"{x:1251,y:642,t:1527009097632};\\\", \\\"{x:1251,y:644,t:1527009097832};\\\", \\\"{x:1252,y:662,t:1527009097849};\\\", \\\"{x:1255,y:684,t:1527009097865};\\\", \\\"{x:1260,y:705,t:1527009097882};\\\", \\\"{x:1264,y:717,t:1527009097899};\\\", \\\"{x:1265,y:723,t:1527009097915};\\\", \\\"{x:1268,y:727,t:1527009097931};\\\", \\\"{x:1268,y:732,t:1527009097948};\\\", \\\"{x:1268,y:738,t:1527009097965};\\\", \\\"{x:1269,y:741,t:1527009097982};\\\", \\\"{x:1273,y:746,t:1527009097999};\\\", \\\"{x:1274,y:750,t:1527009098015};\\\", \\\"{x:1276,y:755,t:1527009098032};\\\", \\\"{x:1276,y:756,t:1527009098049};\\\", \\\"{x:1277,y:757,t:1527009098088};\\\", \\\"{x:1279,y:758,t:1527009098103};\\\", \\\"{x:1282,y:758,t:1527009098120};\\\", \\\"{x:1285,y:758,t:1527009098132};\\\", \\\"{x:1289,y:758,t:1527009098149};\\\", \\\"{x:1296,y:758,t:1527009098166};\\\", \\\"{x:1302,y:758,t:1527009098182};\\\", \\\"{x:1308,y:758,t:1527009098199};\\\", \\\"{x:1316,y:758,t:1527009098216};\\\", \\\"{x:1320,y:758,t:1527009098232};\\\", \\\"{x:1324,y:758,t:1527009098249};\\\", \\\"{x:1326,y:757,t:1527009098266};\\\", \\\"{x:1329,y:757,t:1527009098282};\\\", \\\"{x:1330,y:757,t:1527009098299};\\\", \\\"{x:1332,y:757,t:1527009098316};\\\", \\\"{x:1333,y:757,t:1527009098336};\\\", \\\"{x:1334,y:757,t:1527009098349};\\\", \\\"{x:1343,y:762,t:1527009098366};\\\", \\\"{x:1347,y:767,t:1527009098382};\\\", \\\"{x:1353,y:775,t:1527009098399};\\\", \\\"{x:1361,y:783,t:1527009098416};\\\", \\\"{x:1365,y:789,t:1527009098432};\\\", \\\"{x:1370,y:794,t:1527009098449};\\\", \\\"{x:1374,y:806,t:1527009098466};\\\", \\\"{x:1381,y:822,t:1527009098483};\\\", \\\"{x:1387,y:836,t:1527009098499};\\\", \\\"{x:1392,y:851,t:1527009098516};\\\", \\\"{x:1395,y:861,t:1527009098533};\\\", \\\"{x:1399,y:870,t:1527009098549};\\\", \\\"{x:1399,y:878,t:1527009098566};\\\", \\\"{x:1399,y:882,t:1527009098584};\\\", \\\"{x:1399,y:886,t:1527009098600};\\\", \\\"{x:1399,y:897,t:1527009098616};\\\", \\\"{x:1399,y:907,t:1527009098634};\\\", \\\"{x:1398,y:916,t:1527009098649};\\\", \\\"{x:1396,y:925,t:1527009098666};\\\", \\\"{x:1396,y:932,t:1527009098684};\\\", \\\"{x:1393,y:940,t:1527009098699};\\\", \\\"{x:1393,y:943,t:1527009098716};\\\", \\\"{x:1393,y:947,t:1527009098733};\\\", \\\"{x:1393,y:950,t:1527009098749};\\\", \\\"{x:1393,y:954,t:1527009098767};\\\", \\\"{x:1393,y:957,t:1527009098783};\\\", \\\"{x:1393,y:958,t:1527009098800};\\\", \\\"{x:1393,y:961,t:1527009098817};\\\", \\\"{x:1393,y:960,t:1527009099153};\\\", \\\"{x:1393,y:959,t:1527009099184};\\\", \\\"{x:1393,y:958,t:1527009099257};\\\", \\\"{x:1393,y:957,t:1527009099267};\\\", \\\"{x:1393,y:956,t:1527009099328};\\\", \\\"{x:1394,y:956,t:1527009099344};\\\", \\\"{x:1397,y:956,t:1527009099352};\\\", \\\"{x:1399,y:956,t:1527009099367};\\\", \\\"{x:1400,y:956,t:1527009099383};\\\", \\\"{x:1401,y:956,t:1527009099888};\\\", \\\"{x:1402,y:957,t:1527009099901};\\\", \\\"{x:1404,y:958,t:1527009099918};\\\", \\\"{x:1405,y:959,t:1527009099935};\\\", \\\"{x:1406,y:960,t:1527009100017};\\\", \\\"{x:1407,y:960,t:1527009100273};\\\", \\\"{x:1409,y:960,t:1527009100288};\\\", \\\"{x:1408,y:960,t:1527009100609};\\\", \\\"{x:1407,y:960,t:1527009100619};\\\", \\\"{x:1406,y:960,t:1527009100635};\\\", \\\"{x:1403,y:960,t:1527009100651};\\\", \\\"{x:1401,y:960,t:1527009100672};\\\", \\\"{x:1400,y:960,t:1527009100704};\\\", \\\"{x:1398,y:960,t:1527009100718};\\\", \\\"{x:1397,y:960,t:1527009100735};\\\", \\\"{x:1393,y:960,t:1527009100752};\\\", \\\"{x:1390,y:960,t:1527009100768};\\\", \\\"{x:1388,y:960,t:1527009100785};\\\", \\\"{x:1388,y:957,t:1527009101207};\\\", \\\"{x:1388,y:956,t:1527009101218};\\\", \\\"{x:1388,y:951,t:1527009101235};\\\", \\\"{x:1388,y:944,t:1527009101251};\\\", \\\"{x:1388,y:934,t:1527009101268};\\\", \\\"{x:1388,y:923,t:1527009101285};\\\", \\\"{x:1388,y:912,t:1527009101301};\\\", \\\"{x:1389,y:903,t:1527009101318};\\\", \\\"{x:1389,y:891,t:1527009101335};\\\", \\\"{x:1389,y:874,t:1527009101351};\\\", \\\"{x:1389,y:868,t:1527009101368};\\\", \\\"{x:1387,y:856,t:1527009101385};\\\", \\\"{x:1387,y:848,t:1527009101402};\\\", \\\"{x:1381,y:834,t:1527009101418};\\\", \\\"{x:1382,y:816,t:1527009101435};\\\", \\\"{x:1382,y:796,t:1527009101452};\\\", \\\"{x:1382,y:780,t:1527009101468};\\\", \\\"{x:1382,y:762,t:1527009101485};\\\", \\\"{x:1382,y:751,t:1527009101502};\\\", \\\"{x:1382,y:741,t:1527009101518};\\\", \\\"{x:1382,y:734,t:1527009101535};\\\", \\\"{x:1382,y:725,t:1527009101552};\\\", \\\"{x:1382,y:722,t:1527009101569};\\\", \\\"{x:1382,y:721,t:1527009101585};\\\", \\\"{x:1382,y:720,t:1527009101602};\\\", \\\"{x:1382,y:723,t:1527009101760};\\\", \\\"{x:1382,y:734,t:1527009101770};\\\", \\\"{x:1382,y:753,t:1527009101785};\\\", \\\"{x:1382,y:769,t:1527009101804};\\\", \\\"{x:1383,y:781,t:1527009101819};\\\", \\\"{x:1383,y:787,t:1527009101835};\\\", \\\"{x:1383,y:788,t:1527009101852};\\\", \\\"{x:1386,y:788,t:1527009102119};\\\", \\\"{x:1404,y:798,t:1527009102135};\\\", \\\"{x:1446,y:816,t:1527009102152};\\\", \\\"{x:1508,y:849,t:1527009102169};\\\", \\\"{x:1560,y:881,t:1527009102186};\\\", \\\"{x:1596,y:913,t:1527009102202};\\\", \\\"{x:1619,y:946,t:1527009102219};\\\", \\\"{x:1647,y:984,t:1527009102236};\\\", \\\"{x:1668,y:1013,t:1527009102252};\\\", \\\"{x:1678,y:1037,t:1527009102269};\\\", \\\"{x:1685,y:1055,t:1527009102286};\\\", \\\"{x:1691,y:1071,t:1527009102302};\\\", \\\"{x:1697,y:1085,t:1527009102319};\\\", \\\"{x:1699,y:1088,t:1527009102336};\\\", \\\"{x:1695,y:1088,t:1527009102521};\\\", \\\"{x:1666,y:1062,t:1527009102536};\\\", \\\"{x:1609,y:1030,t:1527009102553};\\\", \\\"{x:1542,y:999,t:1527009102570};\\\", \\\"{x:1484,y:973,t:1527009102587};\\\", \\\"{x:1463,y:963,t:1527009102604};\\\", \\\"{x:1455,y:961,t:1527009102620};\\\", \\\"{x:1452,y:959,t:1527009102636};\\\", \\\"{x:1454,y:960,t:1527009102881};\\\", \\\"{x:1455,y:961,t:1527009102889};\\\", \\\"{x:1456,y:961,t:1527009102904};\\\", \\\"{x:1458,y:961,t:1527009102920};\\\", \\\"{x:1459,y:962,t:1527009103465};\\\", \\\"{x:1459,y:963,t:1527009103689};\\\", \\\"{x:1458,y:964,t:1527009103703};\\\", \\\"{x:1455,y:966,t:1527009103721};\\\", \\\"{x:1452,y:967,t:1527009103738};\\\", \\\"{x:1449,y:968,t:1527009103754};\\\", \\\"{x:1446,y:969,t:1527009103771};\\\", \\\"{x:1446,y:970,t:1527009103817};\\\", \\\"{x:1445,y:970,t:1527009104017};\\\", \\\"{x:1444,y:970,t:1527009104041};\\\", \\\"{x:1443,y:969,t:1527009104056};\\\", \\\"{x:1443,y:967,t:1527009104071};\\\", \\\"{x:1443,y:965,t:1527009104087};\\\", \\\"{x:1443,y:963,t:1527009104104};\\\", \\\"{x:1442,y:959,t:1527009104120};\\\", \\\"{x:1442,y:953,t:1527009104137};\\\", \\\"{x:1442,y:950,t:1527009104154};\\\", \\\"{x:1442,y:944,t:1527009104170};\\\", \\\"{x:1441,y:941,t:1527009104187};\\\", \\\"{x:1440,y:939,t:1527009104204};\\\", \\\"{x:1439,y:935,t:1527009104221};\\\", \\\"{x:1438,y:931,t:1527009104237};\\\", \\\"{x:1438,y:927,t:1527009104254};\\\", \\\"{x:1438,y:921,t:1527009104271};\\\", \\\"{x:1438,y:918,t:1527009104288};\\\", \\\"{x:1438,y:914,t:1527009104304};\\\", \\\"{x:1438,y:912,t:1527009104321};\\\", \\\"{x:1438,y:911,t:1527009104337};\\\", \\\"{x:1438,y:909,t:1527009104354};\\\", \\\"{x:1438,y:905,t:1527009104371};\\\", \\\"{x:1438,y:903,t:1527009104387};\\\", \\\"{x:1438,y:899,t:1527009104404};\\\", \\\"{x:1438,y:896,t:1527009104421};\\\", \\\"{x:1437,y:894,t:1527009104437};\\\", \\\"{x:1436,y:892,t:1527009104454};\\\", \\\"{x:1436,y:891,t:1527009104472};\\\", \\\"{x:1436,y:892,t:1527009104768};\\\", \\\"{x:1436,y:894,t:1527009104776};\\\", \\\"{x:1436,y:895,t:1527009104789};\\\", \\\"{x:1437,y:898,t:1527009104805};\\\", \\\"{x:1442,y:906,t:1527009104822};\\\", \\\"{x:1449,y:912,t:1527009104839};\\\", \\\"{x:1452,y:915,t:1527009104855};\\\", \\\"{x:1457,y:920,t:1527009104872};\\\", \\\"{x:1461,y:923,t:1527009104889};\\\", \\\"{x:1462,y:924,t:1527009104905};\\\", \\\"{x:1464,y:928,t:1527009104922};\\\", \\\"{x:1466,y:931,t:1527009104939};\\\", \\\"{x:1470,y:937,t:1527009104955};\\\", \\\"{x:1478,y:946,t:1527009104972};\\\", \\\"{x:1481,y:953,t:1527009104989};\\\", \\\"{x:1482,y:956,t:1527009105005};\\\", \\\"{x:1484,y:959,t:1527009105022};\\\", \\\"{x:1485,y:961,t:1527009105039};\\\", \\\"{x:1486,y:965,t:1527009105056};\\\", \\\"{x:1489,y:970,t:1527009105072};\\\", \\\"{x:1490,y:973,t:1527009105089};\\\", \\\"{x:1492,y:978,t:1527009105105};\\\", \\\"{x:1494,y:983,t:1527009105121};\\\", \\\"{x:1496,y:985,t:1527009105138};\\\", \\\"{x:1497,y:985,t:1527009105155};\\\", \\\"{x:1497,y:983,t:1527009105417};\\\", \\\"{x:1497,y:982,t:1527009105424};\\\", \\\"{x:1497,y:981,t:1527009105440};\\\", \\\"{x:1497,y:980,t:1527009105456};\\\", \\\"{x:1497,y:979,t:1527009105473};\\\", \\\"{x:1492,y:978,t:1527009105873};\\\", \\\"{x:1435,y:962,t:1527009105889};\\\", \\\"{x:1311,y:930,t:1527009105905};\\\", \\\"{x:1136,y:876,t:1527009105922};\\\", \\\"{x:929,y:815,t:1527009105939};\\\", \\\"{x:714,y:750,t:1527009105955};\\\", \\\"{x:518,y:701,t:1527009105973};\\\", \\\"{x:385,y:678,t:1527009105989};\\\", \\\"{x:311,y:664,t:1527009106000};\\\", \\\"{x:293,y:662,t:1527009106017};\\\", \\\"{x:293,y:661,t:1527009106033};\\\", \\\"{x:295,y:663,t:1527009106095};\\\", \\\"{x:295,y:665,t:1527009106167};\\\", \\\"{x:297,y:670,t:1527009106185};\\\", \\\"{x:300,y:674,t:1527009106201};\\\", \\\"{x:306,y:679,t:1527009106218};\\\", \\\"{x:317,y:684,t:1527009106234};\\\", \\\"{x:326,y:688,t:1527009106251};\\\", \\\"{x:341,y:689,t:1527009106268};\\\", \\\"{x:358,y:697,t:1527009106284};\\\", \\\"{x:376,y:699,t:1527009106301};\\\", \\\"{x:391,y:704,t:1527009106318};\\\", \\\"{x:399,y:707,t:1527009106334};\\\", \\\"{x:405,y:707,t:1527009106351};\\\", \\\"{x:406,y:707,t:1527009106368};\\\", \\\"{x:408,y:707,t:1527009106385};\\\", \\\"{x:409,y:707,t:1527009106432};\\\", \\\"{x:412,y:707,t:1527009106439};\\\", \\\"{x:414,y:707,t:1527009106451};\\\", \\\"{x:422,y:707,t:1527009106469};\\\", \\\"{x:433,y:707,t:1527009106485};\\\", \\\"{x:442,y:708,t:1527009106503};\\\", \\\"{x:454,y:709,t:1527009106519};\\\", \\\"{x:468,y:712,t:1527009106536};\\\", \\\"{x:480,y:712,t:1527009106554};\\\", \\\"{x:487,y:712,t:1527009106571};\\\", \\\"{x:493,y:712,t:1527009106587};\\\", \\\"{x:496,y:712,t:1527009106615};\\\", \\\"{x:498,y:712,t:1527009106632};\\\", \\\"{x:499,y:712,t:1527009106639};\\\", \\\"{x:500,y:712,t:1527009106656};\\\", \\\"{x:501,y:712,t:1527009106671};\\\", \\\"{x:502,y:712,t:1527009106696};\\\", \\\"{x:505,y:712,t:1527009107871};\\\", \\\"{x:529,y:719,t:1527009107889};\\\", \\\"{x:613,y:742,t:1527009107906};\\\", \\\"{x:707,y:767,t:1527009107923};\\\", \\\"{x:820,y:798,t:1527009107938};\\\", \\\"{x:942,y:836,t:1527009107955};\\\", \\\"{x:1048,y:869,t:1527009107973};\\\", \\\"{x:1123,y:889,t:1527009107988};\\\", \\\"{x:1144,y:896,t:1527009108005};\\\", \\\"{x:1155,y:899,t:1527009108023};\\\", \\\"{x:1157,y:899,t:1527009108038};\\\", \\\"{x:1157,y:900,t:1527009108055};\\\", \\\"{x:1157,y:901,t:1527009108799};\\\", \\\"{x:1155,y:901,t:1527009108807};\\\", \\\"{x:1151,y:901,t:1527009108822};\\\", \\\"{x:1143,y:901,t:1527009108839};\\\", \\\"{x:1142,y:901,t:1527009108856};\\\" ] }, { \\\"rt\\\": 122357, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 387708, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -D -04 PM-04 PM-04 PM-G -G -04 PM-D -04 PM-03 PM-12 PM-01 PM-08 AM-08 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1142,y:900,t:1527009113209};\\\", \\\"{x:1143,y:897,t:1527009113227};\\\", \\\"{x:1144,y:895,t:1527009113244};\\\", \\\"{x:1145,y:893,t:1527009113260};\\\", \\\"{x:1145,y:891,t:1527009113277};\\\", \\\"{x:1146,y:890,t:1527009113296};\\\", \\\"{x:1147,y:887,t:1527009113320};\\\", \\\"{x:1148,y:885,t:1527009113336};\\\", \\\"{x:1148,y:884,t:1527009113344};\\\", \\\"{x:1152,y:878,t:1527009113359};\\\", \\\"{x:1153,y:875,t:1527009113376};\\\", \\\"{x:1158,y:864,t:1527009113392};\\\", \\\"{x:1160,y:854,t:1527009113409};\\\", \\\"{x:1166,y:841,t:1527009113426};\\\", \\\"{x:1173,y:827,t:1527009113443};\\\", \\\"{x:1179,y:814,t:1527009113460};\\\", \\\"{x:1186,y:799,t:1527009113477};\\\", \\\"{x:1194,y:786,t:1527009113492};\\\", \\\"{x:1200,y:771,t:1527009113509};\\\", \\\"{x:1203,y:758,t:1527009113527};\\\", \\\"{x:1211,y:738,t:1527009113543};\\\", \\\"{x:1214,y:730,t:1527009113559};\\\", \\\"{x:1217,y:724,t:1527009113576};\\\", \\\"{x:1221,y:720,t:1527009113594};\\\", \\\"{x:1223,y:714,t:1527009113610};\\\", \\\"{x:1226,y:706,t:1527009113626};\\\", \\\"{x:1229,y:700,t:1527009113644};\\\", \\\"{x:1234,y:688,t:1527009113660};\\\", \\\"{x:1235,y:682,t:1527009113676};\\\", \\\"{x:1236,y:673,t:1527009113694};\\\", \\\"{x:1238,y:670,t:1527009113709};\\\", \\\"{x:1238,y:668,t:1527009113727};\\\", \\\"{x:1238,y:665,t:1527009113744};\\\", \\\"{x:1239,y:663,t:1527009113776};\\\", \\\"{x:1239,y:662,t:1527009113833};\\\", \\\"{x:1239,y:661,t:1527009113856};\\\", \\\"{x:1240,y:660,t:1527009113880};\\\", \\\"{x:1240,y:659,t:1527009113912};\\\", \\\"{x:1242,y:658,t:1527009113928};\\\", \\\"{x:1242,y:657,t:1527009113960};\\\", \\\"{x:1243,y:657,t:1527009113984};\\\", \\\"{x:1243,y:656,t:1527009114000};\\\", \\\"{x:1245,y:655,t:1527009114011};\\\", \\\"{x:1247,y:654,t:1527009114040};\\\", \\\"{x:1249,y:653,t:1527009114048};\\\", \\\"{x:1250,y:653,t:1527009114061};\\\", \\\"{x:1251,y:652,t:1527009114080};\\\", \\\"{x:1252,y:651,t:1527009114094};\\\", \\\"{x:1252,y:650,t:1527009114111};\\\", \\\"{x:1254,y:650,t:1527009114128};\\\", \\\"{x:1256,y:650,t:1527009114144};\\\", \\\"{x:1258,y:648,t:1527009114161};\\\", \\\"{x:1260,y:648,t:1527009114177};\\\", \\\"{x:1262,y:648,t:1527009114195};\\\", \\\"{x:1266,y:648,t:1527009114211};\\\", \\\"{x:1272,y:648,t:1527009114227};\\\", \\\"{x:1274,y:648,t:1527009114244};\\\", \\\"{x:1277,y:648,t:1527009114261};\\\", \\\"{x:1279,y:649,t:1527009114277};\\\", \\\"{x:1281,y:649,t:1527009114294};\\\", \\\"{x:1284,y:649,t:1527009114311};\\\", \\\"{x:1288,y:649,t:1527009114327};\\\", \\\"{x:1292,y:650,t:1527009114344};\\\", \\\"{x:1294,y:650,t:1527009114361};\\\", \\\"{x:1295,y:650,t:1527009114384};\\\", \\\"{x:1297,y:650,t:1527009114952};\\\", \\\"{x:1308,y:650,t:1527009114960};\\\", \\\"{x:1326,y:635,t:1527009114978};\\\", \\\"{x:1337,y:626,t:1527009114994};\\\", \\\"{x:1351,y:613,t:1527009115010};\\\", \\\"{x:1363,y:603,t:1527009115028};\\\", \\\"{x:1375,y:593,t:1527009115045};\\\", \\\"{x:1388,y:577,t:1527009115060};\\\", \\\"{x:1401,y:561,t:1527009115078};\\\", \\\"{x:1411,y:543,t:1527009115095};\\\", \\\"{x:1423,y:527,t:1527009115111};\\\", \\\"{x:1436,y:512,t:1527009115128};\\\", \\\"{x:1450,y:498,t:1527009115145};\\\", \\\"{x:1463,y:484,t:1527009115160};\\\", \\\"{x:1480,y:467,t:1527009115178};\\\", \\\"{x:1491,y:453,t:1527009115194};\\\", \\\"{x:1502,y:443,t:1527009115211};\\\", \\\"{x:1510,y:436,t:1527009115227};\\\", \\\"{x:1513,y:431,t:1527009115245};\\\", \\\"{x:1518,y:428,t:1527009115261};\\\", \\\"{x:1526,y:424,t:1527009115277};\\\", \\\"{x:1540,y:419,t:1527009115294};\\\", \\\"{x:1558,y:414,t:1527009115311};\\\", \\\"{x:1565,y:411,t:1527009115328};\\\", \\\"{x:1570,y:409,t:1527009115345};\\\", \\\"{x:1573,y:409,t:1527009115362};\\\", \\\"{x:1576,y:408,t:1527009115377};\\\", \\\"{x:1582,y:407,t:1527009115395};\\\", \\\"{x:1587,y:406,t:1527009115411};\\\", \\\"{x:1594,y:406,t:1527009115428};\\\", \\\"{x:1597,y:406,t:1527009115445};\\\", \\\"{x:1601,y:406,t:1527009115461};\\\", \\\"{x:1607,y:406,t:1527009115478};\\\", \\\"{x:1611,y:406,t:1527009115495};\\\", \\\"{x:1617,y:406,t:1527009115511};\\\", \\\"{x:1622,y:406,t:1527009115528};\\\", \\\"{x:1623,y:406,t:1527009115545};\\\", \\\"{x:1624,y:406,t:1527009115562};\\\", \\\"{x:1628,y:406,t:1527009115577};\\\", \\\"{x:1629,y:406,t:1527009115607};\\\", \\\"{x:1631,y:406,t:1527009115624};\\\", \\\"{x:1631,y:408,t:1527009115631};\\\", \\\"{x:1632,y:410,t:1527009115645};\\\", \\\"{x:1632,y:418,t:1527009115662};\\\", \\\"{x:1632,y:427,t:1527009115678};\\\", \\\"{x:1632,y:431,t:1527009115695};\\\", \\\"{x:1632,y:434,t:1527009115712};\\\", \\\"{x:1632,y:436,t:1527009115735};\\\", \\\"{x:1631,y:437,t:1527009115784};\\\", \\\"{x:1629,y:437,t:1527009116040};\\\", \\\"{x:1628,y:436,t:1527009116072};\\\", \\\"{x:1628,y:435,t:1527009116104};\\\", \\\"{x:1626,y:435,t:1527009116120};\\\", \\\"{x:1625,y:434,t:1527009116143};\\\", \\\"{x:1624,y:433,t:1527009116151};\\\", \\\"{x:1621,y:433,t:1527009116167};\\\", \\\"{x:1620,y:433,t:1527009116178};\\\", \\\"{x:1618,y:431,t:1527009116196};\\\", \\\"{x:1617,y:431,t:1527009116212};\\\", \\\"{x:1615,y:430,t:1527009116228};\\\", \\\"{x:1614,y:430,t:1527009116255};\\\", \\\"{x:1612,y:428,t:1527009116271};\\\", \\\"{x:1611,y:427,t:1527009116320};\\\", \\\"{x:1611,y:429,t:1527009117992};\\\", \\\"{x:1611,y:430,t:1527009118000};\\\", \\\"{x:1611,y:431,t:1527009118016};\\\", \\\"{x:1611,y:432,t:1527009118031};\\\", \\\"{x:1611,y:433,t:1527009118047};\\\", \\\"{x:1611,y:434,t:1527009118064};\\\", \\\"{x:1611,y:435,t:1527009118082};\\\", \\\"{x:1611,y:436,t:1527009118136};\\\", \\\"{x:1611,y:437,t:1527009118168};\\\", \\\"{x:1611,y:438,t:1527009118193};\\\", \\\"{x:1610,y:438,t:1527009118208};\\\", \\\"{x:1609,y:440,t:1527009118249};\\\", \\\"{x:1609,y:441,t:1527009118280};\\\", \\\"{x:1608,y:444,t:1527009118298};\\\", \\\"{x:1607,y:447,t:1527009118314};\\\", \\\"{x:1606,y:450,t:1527009118330};\\\", \\\"{x:1606,y:451,t:1527009118352};\\\", \\\"{x:1606,y:453,t:1527009118364};\\\", \\\"{x:1606,y:456,t:1527009118381};\\\", \\\"{x:1606,y:460,t:1527009118397};\\\", \\\"{x:1606,y:463,t:1527009118414};\\\", \\\"{x:1606,y:467,t:1527009118432};\\\", \\\"{x:1606,y:470,t:1527009118447};\\\", \\\"{x:1605,y:472,t:1527009118464};\\\", \\\"{x:1605,y:474,t:1527009118481};\\\", \\\"{x:1605,y:475,t:1527009118498};\\\", \\\"{x:1605,y:478,t:1527009118515};\\\", \\\"{x:1606,y:481,t:1527009118532};\\\", \\\"{x:1606,y:483,t:1527009118547};\\\", \\\"{x:1606,y:485,t:1527009118564};\\\", \\\"{x:1607,y:487,t:1527009118581};\\\", \\\"{x:1607,y:491,t:1527009118597};\\\", \\\"{x:1607,y:493,t:1527009118614};\\\", \\\"{x:1611,y:499,t:1527009118632};\\\", \\\"{x:1614,y:504,t:1527009118647};\\\", \\\"{x:1614,y:508,t:1527009118665};\\\", \\\"{x:1615,y:509,t:1527009118681};\\\", \\\"{x:1615,y:512,t:1527009118697};\\\", \\\"{x:1615,y:514,t:1527009118715};\\\", \\\"{x:1615,y:516,t:1527009118732};\\\", \\\"{x:1618,y:523,t:1527009118752};\\\", \\\"{x:1619,y:526,t:1527009118764};\\\", \\\"{x:1619,y:530,t:1527009118781};\\\", \\\"{x:1619,y:533,t:1527009118798};\\\", \\\"{x:1619,y:536,t:1527009118814};\\\", \\\"{x:1619,y:539,t:1527009118831};\\\", \\\"{x:1619,y:541,t:1527009118847};\\\", \\\"{x:1619,y:544,t:1527009118864};\\\", \\\"{x:1619,y:546,t:1527009118881};\\\", \\\"{x:1619,y:547,t:1527009118903};\\\", \\\"{x:1619,y:549,t:1527009118914};\\\", \\\"{x:1619,y:553,t:1527009118931};\\\", \\\"{x:1619,y:554,t:1527009118949};\\\", \\\"{x:1619,y:559,t:1527009118964};\\\", \\\"{x:1619,y:562,t:1527009118981};\\\", \\\"{x:1618,y:564,t:1527009118997};\\\", \\\"{x:1618,y:568,t:1527009119014};\\\", \\\"{x:1618,y:575,t:1527009119031};\\\", \\\"{x:1618,y:583,t:1527009119047};\\\", \\\"{x:1618,y:590,t:1527009119063};\\\", \\\"{x:1617,y:594,t:1527009119081};\\\", \\\"{x:1617,y:599,t:1527009119098};\\\", \\\"{x:1617,y:602,t:1527009119114};\\\", \\\"{x:1617,y:606,t:1527009119131};\\\", \\\"{x:1617,y:609,t:1527009119149};\\\", \\\"{x:1617,y:615,t:1527009119164};\\\", \\\"{x:1617,y:623,t:1527009119181};\\\", \\\"{x:1617,y:633,t:1527009119198};\\\", \\\"{x:1617,y:645,t:1527009119214};\\\", \\\"{x:1617,y:665,t:1527009119232};\\\", \\\"{x:1620,y:678,t:1527009119248};\\\", \\\"{x:1621,y:690,t:1527009119265};\\\", \\\"{x:1623,y:704,t:1527009119281};\\\", \\\"{x:1625,y:714,t:1527009119298};\\\", \\\"{x:1626,y:728,t:1527009119315};\\\", \\\"{x:1631,y:740,t:1527009119331};\\\", \\\"{x:1633,y:749,t:1527009119349};\\\", \\\"{x:1635,y:759,t:1527009119365};\\\", \\\"{x:1639,y:766,t:1527009119381};\\\", \\\"{x:1639,y:769,t:1527009119399};\\\", \\\"{x:1643,y:777,t:1527009119415};\\\", \\\"{x:1648,y:791,t:1527009119432};\\\", \\\"{x:1651,y:797,t:1527009119448};\\\", \\\"{x:1654,y:805,t:1527009119465};\\\", \\\"{x:1657,y:813,t:1527009119482};\\\", \\\"{x:1660,y:825,t:1527009119499};\\\", \\\"{x:1661,y:832,t:1527009119515};\\\", \\\"{x:1662,y:840,t:1527009119531};\\\", \\\"{x:1664,y:846,t:1527009119550};\\\", \\\"{x:1664,y:851,t:1527009119565};\\\", \\\"{x:1665,y:855,t:1527009119581};\\\", \\\"{x:1666,y:859,t:1527009119599};\\\", \\\"{x:1666,y:863,t:1527009119615};\\\", \\\"{x:1666,y:866,t:1527009119632};\\\", \\\"{x:1666,y:871,t:1527009119649};\\\", \\\"{x:1664,y:877,t:1527009119665};\\\", \\\"{x:1664,y:886,t:1527009119681};\\\", \\\"{x:1662,y:889,t:1527009119698};\\\", \\\"{x:1659,y:894,t:1527009119715};\\\", \\\"{x:1659,y:897,t:1527009119731};\\\", \\\"{x:1657,y:901,t:1527009119750};\\\", \\\"{x:1657,y:903,t:1527009119765};\\\", \\\"{x:1657,y:904,t:1527009119782};\\\", \\\"{x:1655,y:906,t:1527009119798};\\\", \\\"{x:1653,y:910,t:1527009119815};\\\", \\\"{x:1650,y:913,t:1527009119831};\\\", \\\"{x:1650,y:915,t:1527009119848};\\\", \\\"{x:1648,y:916,t:1527009119944};\\\", \\\"{x:1648,y:917,t:1527009119976};\\\", \\\"{x:1648,y:918,t:1527009120008};\\\", \\\"{x:1647,y:920,t:1527009120024};\\\", \\\"{x:1647,y:921,t:1527009120031};\\\", \\\"{x:1646,y:925,t:1527009120048};\\\", \\\"{x:1645,y:926,t:1527009120066};\\\", \\\"{x:1644,y:928,t:1527009120082};\\\", \\\"{x:1643,y:929,t:1527009120098};\\\", \\\"{x:1643,y:930,t:1527009120144};\\\", \\\"{x:1643,y:931,t:1527009120160};\\\", \\\"{x:1642,y:933,t:1527009120192};\\\", \\\"{x:1642,y:934,t:1527009120321};\\\", \\\"{x:1641,y:936,t:1527009120385};\\\", \\\"{x:1640,y:937,t:1527009120400};\\\", \\\"{x:1639,y:938,t:1527009120456};\\\", \\\"{x:1639,y:937,t:1527009120632};\\\", \\\"{x:1643,y:923,t:1527009120649};\\\", \\\"{x:1651,y:908,t:1527009120667};\\\", \\\"{x:1653,y:894,t:1527009120682};\\\", \\\"{x:1656,y:876,t:1527009120699};\\\", \\\"{x:1658,y:853,t:1527009120717};\\\", \\\"{x:1664,y:820,t:1527009120732};\\\", \\\"{x:1669,y:784,t:1527009120751};\\\", \\\"{x:1668,y:742,t:1527009120767};\\\", \\\"{x:1658,y:695,t:1527009120782};\\\", \\\"{x:1647,y:641,t:1527009120799};\\\", \\\"{x:1623,y:582,t:1527009120816};\\\", \\\"{x:1617,y:551,t:1527009120832};\\\", \\\"{x:1611,y:529,t:1527009120850};\\\", \\\"{x:1610,y:515,t:1527009120865};\\\", \\\"{x:1608,y:500,t:1527009120882};\\\", \\\"{x:1605,y:484,t:1527009120899};\\\", \\\"{x:1600,y:461,t:1527009120917};\\\", \\\"{x:1595,y:437,t:1527009120933};\\\", \\\"{x:1588,y:416,t:1527009120950};\\\", \\\"{x:1584,y:403,t:1527009120966};\\\", \\\"{x:1582,y:398,t:1527009120982};\\\", \\\"{x:1581,y:397,t:1527009121000};\\\", \\\"{x:1582,y:400,t:1527009121191};\\\", \\\"{x:1586,y:402,t:1527009121199};\\\", \\\"{x:1590,y:409,t:1527009121216};\\\", \\\"{x:1593,y:411,t:1527009121233};\\\", \\\"{x:1595,y:414,t:1527009121249};\\\", \\\"{x:1596,y:415,t:1527009121266};\\\", \\\"{x:1598,y:416,t:1527009121283};\\\", \\\"{x:1599,y:417,t:1527009121312};\\\", \\\"{x:1600,y:418,t:1527009121319};\\\", \\\"{x:1604,y:419,t:1527009121333};\\\", \\\"{x:1605,y:420,t:1527009121349};\\\", \\\"{x:1606,y:421,t:1527009121366};\\\", \\\"{x:1607,y:421,t:1527009121496};\\\", \\\"{x:1608,y:421,t:1527009122072};\\\", \\\"{x:1609,y:424,t:1527009122361};\\\", \\\"{x:1610,y:424,t:1527009122368};\\\", \\\"{x:1610,y:425,t:1527009122385};\\\", \\\"{x:1611,y:428,t:1527009122402};\\\", \\\"{x:1611,y:430,t:1527009122417};\\\", \\\"{x:1611,y:431,t:1527009122440};\\\", \\\"{x:1611,y:432,t:1527009122455};\\\", \\\"{x:1613,y:434,t:1527009122467};\\\", \\\"{x:1613,y:435,t:1527009122512};\\\", \\\"{x:1613,y:436,t:1527009122544};\\\", \\\"{x:1613,y:437,t:1527009123080};\\\", \\\"{x:1614,y:438,t:1527009123096};\\\", \\\"{x:1615,y:438,t:1527009123111};\\\", \\\"{x:1615,y:439,t:1527009123120};\\\", \\\"{x:1616,y:440,t:1527009123136};\\\", \\\"{x:1616,y:442,t:1527009123169};\\\", \\\"{x:1616,y:443,t:1527009123199};\\\", \\\"{x:1617,y:444,t:1527009123241};\\\", \\\"{x:1617,y:445,t:1527009123252};\\\", \\\"{x:1617,y:446,t:1527009123280};\\\", \\\"{x:1617,y:448,t:1527009123296};\\\", \\\"{x:1617,y:450,t:1527009123304};\\\", \\\"{x:1618,y:452,t:1527009123318};\\\", \\\"{x:1619,y:453,t:1527009123334};\\\", \\\"{x:1620,y:458,t:1527009123352};\\\", \\\"{x:1620,y:460,t:1527009123368};\\\", \\\"{x:1620,y:465,t:1527009123384};\\\", \\\"{x:1620,y:471,t:1527009123401};\\\", \\\"{x:1620,y:477,t:1527009123418};\\\", \\\"{x:1620,y:485,t:1527009123434};\\\", \\\"{x:1620,y:493,t:1527009123451};\\\", \\\"{x:1620,y:499,t:1527009123468};\\\", \\\"{x:1620,y:505,t:1527009123484};\\\", \\\"{x:1620,y:506,t:1527009123501};\\\", \\\"{x:1620,y:507,t:1527009123518};\\\", \\\"{x:1620,y:508,t:1527009123535};\\\", \\\"{x:1620,y:509,t:1527009123560};\\\", \\\"{x:1620,y:510,t:1527009123583};\\\", \\\"{x:1620,y:511,t:1527009123599};\\\", \\\"{x:1619,y:513,t:1527009123615};\\\", \\\"{x:1619,y:515,t:1527009123632};\\\", \\\"{x:1618,y:516,t:1527009123664};\\\", \\\"{x:1618,y:517,t:1527009123671};\\\", \\\"{x:1617,y:518,t:1527009123684};\\\", \\\"{x:1616,y:521,t:1527009123701};\\\", \\\"{x:1616,y:523,t:1527009123718};\\\", \\\"{x:1616,y:527,t:1527009123735};\\\", \\\"{x:1616,y:529,t:1527009123751};\\\", \\\"{x:1615,y:531,t:1527009123768};\\\", \\\"{x:1613,y:534,t:1527009123785};\\\", \\\"{x:1613,y:535,t:1527009123801};\\\", \\\"{x:1613,y:536,t:1527009123818};\\\", \\\"{x:1613,y:537,t:1527009123835};\\\", \\\"{x:1613,y:538,t:1527009123851};\\\", \\\"{x:1613,y:540,t:1527009123868};\\\", \\\"{x:1613,y:541,t:1527009123884};\\\", \\\"{x:1612,y:541,t:1527009123901};\\\", \\\"{x:1612,y:543,t:1527009123919};\\\", \\\"{x:1612,y:544,t:1527009123959};\\\", \\\"{x:1612,y:545,t:1527009123968};\\\", \\\"{x:1612,y:548,t:1527009123985};\\\", \\\"{x:1611,y:554,t:1527009124002};\\\", \\\"{x:1610,y:557,t:1527009124018};\\\", \\\"{x:1610,y:559,t:1527009124035};\\\", \\\"{x:1610,y:561,t:1527009124472};\\\", \\\"{x:1610,y:562,t:1527009124495};\\\", \\\"{x:1610,y:563,t:1527009124512};\\\", \\\"{x:1610,y:564,t:1527009124528};\\\", \\\"{x:1611,y:565,t:1527009124536};\\\", \\\"{x:1612,y:567,t:1527009124697};\\\", \\\"{x:1612,y:568,t:1527009124704};\\\", \\\"{x:1613,y:569,t:1527009124720};\\\", \\\"{x:1613,y:570,t:1527009124735};\\\", \\\"{x:1614,y:571,t:1527009124753};\\\", \\\"{x:1615,y:574,t:1527009124769};\\\", \\\"{x:1616,y:577,t:1527009124785};\\\", \\\"{x:1616,y:580,t:1527009124802};\\\", \\\"{x:1617,y:580,t:1527009124819};\\\", \\\"{x:1617,y:581,t:1527009124835};\\\", \\\"{x:1618,y:581,t:1527009124976};\\\", \\\"{x:1619,y:583,t:1527009124992};\\\", \\\"{x:1619,y:585,t:1527009125007};\\\", \\\"{x:1619,y:586,t:1527009125019};\\\", \\\"{x:1620,y:588,t:1527009125036};\\\", \\\"{x:1620,y:591,t:1527009125053};\\\", \\\"{x:1621,y:594,t:1527009125069};\\\", \\\"{x:1621,y:597,t:1527009125085};\\\", \\\"{x:1622,y:604,t:1527009125102};\\\", \\\"{x:1623,y:607,t:1527009125119};\\\", \\\"{x:1623,y:609,t:1527009125136};\\\", \\\"{x:1623,y:611,t:1527009125153};\\\", \\\"{x:1623,y:614,t:1527009125170};\\\", \\\"{x:1623,y:615,t:1527009125186};\\\", \\\"{x:1623,y:618,t:1527009125202};\\\", \\\"{x:1623,y:621,t:1527009125219};\\\", \\\"{x:1623,y:624,t:1527009125236};\\\", \\\"{x:1623,y:627,t:1527009125253};\\\", \\\"{x:1623,y:629,t:1527009125270};\\\", \\\"{x:1623,y:630,t:1527009125287};\\\", \\\"{x:1623,y:634,t:1527009125303};\\\", \\\"{x:1623,y:640,t:1527009125320};\\\", \\\"{x:1623,y:642,t:1527009125336};\\\", \\\"{x:1623,y:646,t:1527009125352};\\\", \\\"{x:1623,y:651,t:1527009125369};\\\", \\\"{x:1623,y:654,t:1527009125386};\\\", \\\"{x:1623,y:658,t:1527009125402};\\\", \\\"{x:1623,y:661,t:1527009125419};\\\", \\\"{x:1622,y:666,t:1527009125435};\\\", \\\"{x:1622,y:670,t:1527009125453};\\\", \\\"{x:1622,y:675,t:1527009125469};\\\", \\\"{x:1621,y:678,t:1527009125486};\\\", \\\"{x:1620,y:682,t:1527009125503};\\\", \\\"{x:1620,y:683,t:1527009125519};\\\", \\\"{x:1620,y:684,t:1527009125536};\\\", \\\"{x:1619,y:687,t:1527009125553};\\\", \\\"{x:1619,y:690,t:1527009125569};\\\", \\\"{x:1618,y:694,t:1527009125586};\\\", \\\"{x:1618,y:697,t:1527009125603};\\\", \\\"{x:1618,y:699,t:1527009125619};\\\", \\\"{x:1617,y:700,t:1527009125636};\\\", \\\"{x:1616,y:701,t:1527009125653};\\\", \\\"{x:1615,y:701,t:1527009125669};\\\", \\\"{x:1615,y:703,t:1527009125687};\\\", \\\"{x:1615,y:704,t:1527009125704};\\\", \\\"{x:1615,y:706,t:1527009125720};\\\", \\\"{x:1615,y:707,t:1527009125737};\\\", \\\"{x:1615,y:709,t:1527009125754};\\\", \\\"{x:1615,y:710,t:1527009125800};\\\", \\\"{x:1615,y:712,t:1527009125824};\\\", \\\"{x:1615,y:713,t:1527009125837};\\\", \\\"{x:1615,y:715,t:1527009125864};\\\", \\\"{x:1615,y:716,t:1527009125888};\\\", \\\"{x:1615,y:717,t:1527009125911};\\\", \\\"{x:1615,y:718,t:1527009125928};\\\", \\\"{x:1615,y:719,t:1527009125944};\\\", \\\"{x:1615,y:720,t:1527009125954};\\\", \\\"{x:1615,y:722,t:1527009125970};\\\", \\\"{x:1615,y:723,t:1527009125991};\\\", \\\"{x:1615,y:724,t:1527009126007};\\\", \\\"{x:1615,y:725,t:1527009126020};\\\", \\\"{x:1615,y:727,t:1527009126038};\\\", \\\"{x:1615,y:728,t:1527009126055};\\\", \\\"{x:1615,y:729,t:1527009126070};\\\", \\\"{x:1615,y:732,t:1527009126087};\\\", \\\"{x:1615,y:739,t:1527009126103};\\\", \\\"{x:1615,y:747,t:1527009126121};\\\", \\\"{x:1615,y:754,t:1527009126136};\\\", \\\"{x:1615,y:758,t:1527009126153};\\\", \\\"{x:1615,y:759,t:1527009126170};\\\", \\\"{x:1615,y:762,t:1527009126186};\\\", \\\"{x:1615,y:764,t:1527009126204};\\\", \\\"{x:1615,y:765,t:1527009126224};\\\", \\\"{x:1615,y:767,t:1527009126237};\\\", \\\"{x:1615,y:768,t:1527009126254};\\\", \\\"{x:1615,y:770,t:1527009126271};\\\", \\\"{x:1615,y:771,t:1527009126286};\\\", \\\"{x:1615,y:772,t:1527009126311};\\\", \\\"{x:1615,y:773,t:1527009126320};\\\", \\\"{x:1615,y:774,t:1527009126337};\\\", \\\"{x:1615,y:776,t:1527009126354};\\\", \\\"{x:1615,y:777,t:1527009126370};\\\", \\\"{x:1615,y:779,t:1527009126400};\\\", \\\"{x:1615,y:780,t:1527009126416};\\\", \\\"{x:1615,y:781,t:1527009126424};\\\", \\\"{x:1615,y:782,t:1527009126437};\\\", \\\"{x:1615,y:786,t:1527009126454};\\\", \\\"{x:1615,y:787,t:1527009126471};\\\", \\\"{x:1616,y:788,t:1527009126496};\\\", \\\"{x:1616,y:789,t:1527009126504};\\\", \\\"{x:1616,y:790,t:1527009126536};\\\", \\\"{x:1617,y:792,t:1527009126568};\\\", \\\"{x:1617,y:794,t:1527009126608};\\\", \\\"{x:1618,y:797,t:1527009126623};\\\", \\\"{x:1618,y:800,t:1527009126639};\\\", \\\"{x:1619,y:801,t:1527009126654};\\\", \\\"{x:1619,y:802,t:1527009126671};\\\", \\\"{x:1620,y:805,t:1527009126688};\\\", \\\"{x:1621,y:808,t:1527009126704};\\\", \\\"{x:1621,y:810,t:1527009126721};\\\", \\\"{x:1621,y:811,t:1527009126737};\\\", \\\"{x:1622,y:811,t:1527009126754};\\\", \\\"{x:1623,y:813,t:1527009126771};\\\", \\\"{x:1624,y:817,t:1527009126808};\\\", \\\"{x:1624,y:820,t:1527009126824};\\\", \\\"{x:1624,y:822,t:1527009126838};\\\", \\\"{x:1624,y:827,t:1527009126855};\\\", \\\"{x:1625,y:831,t:1527009126871};\\\", \\\"{x:1627,y:835,t:1527009126888};\\\", \\\"{x:1627,y:838,t:1527009126904};\\\", \\\"{x:1627,y:841,t:1527009126921};\\\", \\\"{x:1627,y:845,t:1527009126938};\\\", \\\"{x:1627,y:848,t:1527009126955};\\\", \\\"{x:1627,y:850,t:1527009126970};\\\", \\\"{x:1627,y:852,t:1527009126987};\\\", \\\"{x:1627,y:855,t:1527009127004};\\\", \\\"{x:1627,y:858,t:1527009127020};\\\", \\\"{x:1627,y:862,t:1527009127037};\\\", \\\"{x:1626,y:865,t:1527009127054};\\\", \\\"{x:1626,y:868,t:1527009127070};\\\", \\\"{x:1625,y:871,t:1527009127087};\\\", \\\"{x:1625,y:873,t:1527009127104};\\\", \\\"{x:1625,y:876,t:1527009127120};\\\", \\\"{x:1625,y:879,t:1527009127137};\\\", \\\"{x:1625,y:882,t:1527009127154};\\\", \\\"{x:1623,y:885,t:1527009127170};\\\", \\\"{x:1623,y:886,t:1527009127188};\\\", \\\"{x:1623,y:891,t:1527009127204};\\\", \\\"{x:1622,y:894,t:1527009127220};\\\", \\\"{x:1622,y:897,t:1527009127237};\\\", \\\"{x:1621,y:899,t:1527009127254};\\\", \\\"{x:1621,y:903,t:1527009127271};\\\", \\\"{x:1620,y:906,t:1527009127295};\\\", \\\"{x:1619,y:907,t:1527009127305};\\\", \\\"{x:1619,y:910,t:1527009127321};\\\", \\\"{x:1619,y:912,t:1527009127338};\\\", \\\"{x:1618,y:915,t:1527009127354};\\\", \\\"{x:1618,y:916,t:1527009127391};\\\", \\\"{x:1619,y:919,t:1527009127404};\\\", \\\"{x:1619,y:922,t:1527009127423};\\\", \\\"{x:1619,y:923,t:1527009127440};\\\", \\\"{x:1619,y:925,t:1527009127473};\\\", \\\"{x:1619,y:927,t:1527009127488};\\\", \\\"{x:1619,y:928,t:1527009127512};\\\", \\\"{x:1619,y:929,t:1527009127528};\\\", \\\"{x:1619,y:932,t:1527009127544};\\\", \\\"{x:1619,y:933,t:1527009127560};\\\", \\\"{x:1619,y:935,t:1527009127572};\\\", \\\"{x:1620,y:938,t:1527009127587};\\\", \\\"{x:1620,y:941,t:1527009127605};\\\", \\\"{x:1620,y:945,t:1527009127621};\\\", \\\"{x:1621,y:949,t:1527009127638};\\\", \\\"{x:1621,y:952,t:1527009127656};\\\", \\\"{x:1621,y:960,t:1527009127672};\\\", \\\"{x:1619,y:964,t:1527009127688};\\\", \\\"{x:1619,y:968,t:1527009127705};\\\", \\\"{x:1619,y:969,t:1527009127722};\\\", \\\"{x:1619,y:970,t:1527009127739};\\\", \\\"{x:1618,y:971,t:1527009127784};\\\", \\\"{x:1618,y:970,t:1527009130568};\\\", \\\"{x:1618,y:969,t:1527009130592};\\\", \\\"{x:1618,y:968,t:1527009130608};\\\", \\\"{x:1618,y:967,t:1527009130968};\\\", \\\"{x:1618,y:966,t:1527009131016};\\\", \\\"{x:1618,y:965,t:1527009131032};\\\", \\\"{x:1618,y:964,t:1527009131264};\\\", \\\"{x:1618,y:963,t:1527009131296};\\\", \\\"{x:1618,y:962,t:1527009133752};\\\", \\\"{x:1620,y:935,t:1527009170709};\\\", \\\"{x:1636,y:853,t:1527009170720};\\\", \\\"{x:1675,y:747,t:1527009170737};\\\", \\\"{x:1720,y:673,t:1527009170753};\\\", \\\"{x:1750,y:611,t:1527009170769};\\\", \\\"{x:1764,y:551,t:1527009170786};\\\", \\\"{x:1762,y:508,t:1527009170802};\\\", \\\"{x:1750,y:470,t:1527009170820};\\\", \\\"{x:1732,y:409,t:1527009170836};\\\", \\\"{x:1727,y:367,t:1527009170852};\\\", \\\"{x:1719,y:329,t:1527009170870};\\\", \\\"{x:1708,y:298,t:1527009170886};\\\", \\\"{x:1701,y:269,t:1527009170902};\\\", \\\"{x:1697,y:246,t:1527009170919};\\\", \\\"{x:1695,y:224,t:1527009170936};\\\", \\\"{x:1694,y:210,t:1527009170953};\\\", \\\"{x:1691,y:205,t:1527009170970};\\\", \\\"{x:1690,y:206,t:1527009171003};\\\", \\\"{x:1685,y:213,t:1527009171020};\\\", \\\"{x:1667,y:240,t:1527009171036};\\\", \\\"{x:1657,y:266,t:1527009171053};\\\", \\\"{x:1645,y:286,t:1527009171069};\\\", \\\"{x:1635,y:313,t:1527009171087};\\\", \\\"{x:1634,y:340,t:1527009171104};\\\", \\\"{x:1638,y:379,t:1527009171119};\\\", \\\"{x:1652,y:424,t:1527009171137};\\\", \\\"{x:1672,y:461,t:1527009171153};\\\", \\\"{x:1692,y:499,t:1527009171169};\\\", \\\"{x:1710,y:540,t:1527009171187};\\\", \\\"{x:1732,y:584,t:1527009171203};\\\", \\\"{x:1749,y:653,t:1527009171220};\\\", \\\"{x:1762,y:770,t:1527009171237};\\\", \\\"{x:1770,y:847,t:1527009171253};\\\", \\\"{x:1770,y:927,t:1527009171270};\\\", \\\"{x:1756,y:1006,t:1527009171287};\\\", \\\"{x:1757,y:1050,t:1527009171304};\\\", \\\"{x:1753,y:1085,t:1527009171320};\\\", \\\"{x:1747,y:1114,t:1527009171337};\\\", \\\"{x:1742,y:1135,t:1527009171354};\\\", \\\"{x:1739,y:1150,t:1527009171370};\\\", \\\"{x:1734,y:1162,t:1527009171386};\\\", \\\"{x:1732,y:1179,t:1527009171404};\\\", \\\"{x:1731,y:1181,t:1527009171420};\\\", \\\"{x:1731,y:1187,t:1527009171437};\\\", \\\"{x:1731,y:1183,t:1527009171493};\\\", \\\"{x:1728,y:1175,t:1527009171506};\\\", \\\"{x:1715,y:1157,t:1527009171522};\\\", \\\"{x:1698,y:1132,t:1527009171539};\\\", \\\"{x:1675,y:1098,t:1527009171556};\\\", \\\"{x:1658,y:1070,t:1527009171572};\\\", \\\"{x:1645,y:1038,t:1527009171589};\\\", \\\"{x:1638,y:1022,t:1527009171606};\\\", \\\"{x:1636,y:1017,t:1527009171622};\\\", \\\"{x:1636,y:1014,t:1527009171639};\\\", \\\"{x:1636,y:1012,t:1527009171813};\\\", \\\"{x:1638,y:1002,t:1527009171822};\\\", \\\"{x:1640,y:983,t:1527009171838};\\\", \\\"{x:1640,y:964,t:1527009171857};\\\", \\\"{x:1635,y:947,t:1527009171872};\\\", \\\"{x:1631,y:927,t:1527009171889};\\\", \\\"{x:1628,y:912,t:1527009171906};\\\", \\\"{x:1627,y:911,t:1527009171922};\\\", \\\"{x:1626,y:913,t:1527009172206};\\\", \\\"{x:1626,y:915,t:1527009172223};\\\", \\\"{x:1624,y:917,t:1527009172239};\\\", \\\"{x:1624,y:920,t:1527009172256};\\\", \\\"{x:1624,y:923,t:1527009172272};\\\", \\\"{x:1624,y:924,t:1527009172289};\\\", \\\"{x:1624,y:925,t:1527009172306};\\\", \\\"{x:1629,y:928,t:1527009172322};\\\", \\\"{x:1629,y:929,t:1527009173157};\\\", \\\"{x:1629,y:933,t:1527009173172};\\\", \\\"{x:1629,y:935,t:1527009173189};\\\", \\\"{x:1629,y:938,t:1527009173206};\\\", \\\"{x:1629,y:939,t:1527009173222};\\\", \\\"{x:1629,y:941,t:1527009173239};\\\", \\\"{x:1629,y:943,t:1527009173256};\\\", \\\"{x:1629,y:944,t:1527009173272};\\\", \\\"{x:1629,y:946,t:1527009173289};\\\", \\\"{x:1629,y:947,t:1527009173307};\\\", \\\"{x:1629,y:948,t:1527009173322};\\\", \\\"{x:1629,y:950,t:1527009173339};\\\", \\\"{x:1629,y:951,t:1527009173364};\\\", \\\"{x:1629,y:952,t:1527009173388};\\\", \\\"{x:1629,y:953,t:1527009173412};\\\", \\\"{x:1629,y:955,t:1527009173427};\\\", \\\"{x:1628,y:956,t:1527009173451};\\\", \\\"{x:1628,y:957,t:1527009173476};\\\", \\\"{x:1628,y:958,t:1527009173492};\\\", \\\"{x:1627,y:958,t:1527009173506};\\\", \\\"{x:1627,y:960,t:1527009173523};\\\", \\\"{x:1627,y:961,t:1527009173540};\\\", \\\"{x:1627,y:962,t:1527009173555};\\\", \\\"{x:1626,y:962,t:1527009175157};\\\", \\\"{x:1625,y:962,t:1527009175173};\\\", \\\"{x:1623,y:962,t:1527009175189};\\\", \\\"{x:1620,y:963,t:1527009175205};\\\", \\\"{x:1616,y:965,t:1527009175223};\\\", \\\"{x:1615,y:965,t:1527009175239};\\\", \\\"{x:1611,y:966,t:1527009175256};\\\", \\\"{x:1607,y:969,t:1527009175273};\\\", \\\"{x:1603,y:969,t:1527009175289};\\\", \\\"{x:1599,y:970,t:1527009175305};\\\", \\\"{x:1598,y:970,t:1527009175322};\\\", \\\"{x:1597,y:971,t:1527009175348};\\\", \\\"{x:1598,y:971,t:1527009175683};\\\", \\\"{x:1599,y:972,t:1527009175756};\\\", \\\"{x:1600,y:972,t:1527009175796};\\\", \\\"{x:1601,y:972,t:1527009175989};\\\", \\\"{x:1606,y:972,t:1527009176005};\\\", \\\"{x:1607,y:972,t:1527009176045};\\\", \\\"{x:1609,y:972,t:1527009176084};\\\", \\\"{x:1610,y:972,t:1527009176244};\\\", \\\"{x:1610,y:969,t:1527009176259};\\\", \\\"{x:1609,y:967,t:1527009176284};\\\", \\\"{x:1609,y:966,t:1527009176292};\\\", \\\"{x:1608,y:964,t:1527009176305};\\\", \\\"{x:1606,y:961,t:1527009176322};\\\", \\\"{x:1606,y:959,t:1527009176338};\\\", \\\"{x:1606,y:958,t:1527009176356};\\\", \\\"{x:1606,y:957,t:1527009176436};\\\", \\\"{x:1606,y:956,t:1527009176452};\\\", \\\"{x:1605,y:955,t:1527009176701};\\\", \\\"{x:1605,y:956,t:1527009176773};\\\", \\\"{x:1606,y:957,t:1527009176788};\\\", \\\"{x:1607,y:958,t:1527009176805};\\\", \\\"{x:1608,y:960,t:1527009176822};\\\", \\\"{x:1610,y:963,t:1527009176840};\\\", \\\"{x:1612,y:966,t:1527009176856};\\\", \\\"{x:1613,y:967,t:1527009176873};\\\", \\\"{x:1613,y:968,t:1527009176908};\\\", \\\"{x:1613,y:969,t:1527009176941};\\\", \\\"{x:1612,y:969,t:1527009177141};\\\", \\\"{x:1611,y:969,t:1527009179861};\\\", \\\"{x:1610,y:969,t:1527009179872};\\\", \\\"{x:1614,y:968,t:1527009192637};\\\", \\\"{x:1629,y:956,t:1527009192655};\\\", \\\"{x:1638,y:941,t:1527009192672};\\\", \\\"{x:1646,y:911,t:1527009192688};\\\", \\\"{x:1651,y:891,t:1527009192705};\\\", \\\"{x:1657,y:873,t:1527009192722};\\\", \\\"{x:1660,y:855,t:1527009192738};\\\", \\\"{x:1663,y:839,t:1527009192755};\\\", \\\"{x:1665,y:822,t:1527009192772};\\\", \\\"{x:1669,y:814,t:1527009192789};\\\", \\\"{x:1670,y:808,t:1527009192805};\\\", \\\"{x:1670,y:804,t:1527009192822};\\\", \\\"{x:1671,y:802,t:1527009192838};\\\", \\\"{x:1672,y:799,t:1527009192855};\\\", \\\"{x:1672,y:796,t:1527009192872};\\\", \\\"{x:1673,y:790,t:1527009192887};\\\", \\\"{x:1673,y:785,t:1527009192905};\\\", \\\"{x:1673,y:783,t:1527009192921};\\\", \\\"{x:1673,y:781,t:1527009192937};\\\", \\\"{x:1673,y:779,t:1527009192954};\\\", \\\"{x:1673,y:776,t:1527009192972};\\\", \\\"{x:1673,y:774,t:1527009192988};\\\", \\\"{x:1673,y:769,t:1527009193005};\\\", \\\"{x:1673,y:767,t:1527009193021};\\\", \\\"{x:1672,y:764,t:1527009193037};\\\", \\\"{x:1671,y:761,t:1527009193055};\\\", \\\"{x:1670,y:758,t:1527009193071};\\\", \\\"{x:1669,y:755,t:1527009193088};\\\", \\\"{x:1667,y:750,t:1527009193104};\\\", \\\"{x:1665,y:748,t:1527009193122};\\\", \\\"{x:1665,y:746,t:1527009193138};\\\", \\\"{x:1663,y:743,t:1527009193155};\\\", \\\"{x:1662,y:742,t:1527009193171};\\\", \\\"{x:1661,y:742,t:1527009193277};\\\", \\\"{x:1658,y:748,t:1527009193288};\\\", \\\"{x:1653,y:757,t:1527009193305};\\\", \\\"{x:1646,y:769,t:1527009193322};\\\", \\\"{x:1646,y:776,t:1527009193338};\\\", \\\"{x:1644,y:780,t:1527009193355};\\\", \\\"{x:1644,y:781,t:1527009193372};\\\", \\\"{x:1643,y:783,t:1527009193388};\\\", \\\"{x:1643,y:781,t:1527009193573};\\\", \\\"{x:1643,y:776,t:1527009193588};\\\", \\\"{x:1643,y:773,t:1527009193605};\\\", \\\"{x:1643,y:771,t:1527009193622};\\\", \\\"{x:1643,y:769,t:1527009193638};\\\", \\\"{x:1643,y:768,t:1527009193655};\\\", \\\"{x:1643,y:767,t:1527009193671};\\\", \\\"{x:1643,y:766,t:1527009194101};\\\", \\\"{x:1643,y:764,t:1527009194125};\\\", \\\"{x:1643,y:763,t:1527009194164};\\\", \\\"{x:1643,y:762,t:1527009194220};\\\", \\\"{x:1643,y:761,t:1527009194237};\\\", \\\"{x:1643,y:758,t:1527009194256};\\\", \\\"{x:1643,y:757,t:1527009194271};\\\", \\\"{x:1643,y:755,t:1527009194292};\\\", \\\"{x:1643,y:754,t:1527009194304};\\\", \\\"{x:1643,y:750,t:1527009194321};\\\", \\\"{x:1643,y:743,t:1527009194338};\\\", \\\"{x:1644,y:733,t:1527009194354};\\\", \\\"{x:1645,y:721,t:1527009194370};\\\", \\\"{x:1648,y:707,t:1527009194388};\\\", \\\"{x:1648,y:691,t:1527009194405};\\\", \\\"{x:1648,y:674,t:1527009194421};\\\", \\\"{x:1648,y:653,t:1527009194437};\\\", \\\"{x:1648,y:637,t:1527009194454};\\\", \\\"{x:1649,y:620,t:1527009194471};\\\", \\\"{x:1649,y:609,t:1527009194488};\\\", \\\"{x:1650,y:600,t:1527009194504};\\\", \\\"{x:1650,y:593,t:1527009194520};\\\", \\\"{x:1650,y:589,t:1527009194538};\\\", \\\"{x:1650,y:587,t:1527009194554};\\\", \\\"{x:1649,y:587,t:1527009194709};\\\", \\\"{x:1645,y:589,t:1527009194724};\\\", \\\"{x:1643,y:594,t:1527009194738};\\\", \\\"{x:1640,y:603,t:1527009194755};\\\", \\\"{x:1636,y:616,t:1527009194771};\\\", \\\"{x:1631,y:631,t:1527009194788};\\\", \\\"{x:1630,y:640,t:1527009194805};\\\", \\\"{x:1630,y:644,t:1527009194821};\\\", \\\"{x:1628,y:650,t:1527009194838};\\\", \\\"{x:1628,y:657,t:1527009194855};\\\", \\\"{x:1626,y:664,t:1527009194871};\\\", \\\"{x:1626,y:672,t:1527009194888};\\\", \\\"{x:1626,y:681,t:1527009194905};\\\", \\\"{x:1626,y:696,t:1527009194922};\\\", \\\"{x:1625,y:709,t:1527009194938};\\\", \\\"{x:1625,y:721,t:1527009194954};\\\", \\\"{x:1625,y:732,t:1527009194970};\\\", \\\"{x:1622,y:746,t:1527009194987};\\\", \\\"{x:1621,y:751,t:1527009195004};\\\", \\\"{x:1621,y:757,t:1527009195020};\\\", \\\"{x:1620,y:762,t:1527009195037};\\\", \\\"{x:1618,y:765,t:1527009195055};\\\", \\\"{x:1617,y:769,t:1527009195070};\\\", \\\"{x:1615,y:774,t:1527009195088};\\\", \\\"{x:1614,y:783,t:1527009195105};\\\", \\\"{x:1613,y:791,t:1527009195121};\\\", \\\"{x:1612,y:801,t:1527009195137};\\\", \\\"{x:1612,y:808,t:1527009195155};\\\", \\\"{x:1610,y:812,t:1527009195170};\\\", \\\"{x:1610,y:816,t:1527009195188};\\\", \\\"{x:1610,y:818,t:1527009195204};\\\", \\\"{x:1610,y:819,t:1527009195227};\\\", \\\"{x:1610,y:820,t:1527009195244};\\\", \\\"{x:1610,y:821,t:1527009195254};\\\", \\\"{x:1609,y:822,t:1527009195270};\\\", \\\"{x:1609,y:824,t:1527009195288};\\\", \\\"{x:1607,y:825,t:1527009195304};\\\", \\\"{x:1607,y:827,t:1527009195320};\\\", \\\"{x:1607,y:828,t:1527009195340};\\\", \\\"{x:1607,y:830,t:1527009195355};\\\", \\\"{x:1607,y:831,t:1527009195372};\\\", \\\"{x:1607,y:833,t:1527009195388};\\\", \\\"{x:1607,y:837,t:1527009195405};\\\", \\\"{x:1607,y:838,t:1527009195420};\\\", \\\"{x:1608,y:842,t:1527009195438};\\\", \\\"{x:1610,y:850,t:1527009195455};\\\", \\\"{x:1612,y:862,t:1527009195471};\\\", \\\"{x:1613,y:871,t:1527009195487};\\\", \\\"{x:1616,y:879,t:1527009195505};\\\", \\\"{x:1619,y:888,t:1527009195521};\\\", \\\"{x:1620,y:892,t:1527009195538};\\\", \\\"{x:1623,y:896,t:1527009195555};\\\", \\\"{x:1624,y:902,t:1527009195571};\\\", \\\"{x:1629,y:912,t:1527009195587};\\\", \\\"{x:1633,y:922,t:1527009195605};\\\", \\\"{x:1637,y:927,t:1527009195621};\\\", \\\"{x:1642,y:934,t:1527009195637};\\\", \\\"{x:1645,y:940,t:1527009195655};\\\", \\\"{x:1649,y:945,t:1527009195671};\\\", \\\"{x:1653,y:947,t:1527009195687};\\\", \\\"{x:1654,y:949,t:1527009195704};\\\", \\\"{x:1655,y:949,t:1527009195732};\\\", \\\"{x:1655,y:950,t:1527009195748};\\\", \\\"{x:1655,y:951,t:1527009195771};\\\", \\\"{x:1656,y:953,t:1527009195788};\\\", \\\"{x:1656,y:956,t:1527009195804};\\\", \\\"{x:1656,y:957,t:1527009195821};\\\", \\\"{x:1656,y:959,t:1527009195838};\\\", \\\"{x:1656,y:960,t:1527009195855};\\\", \\\"{x:1656,y:961,t:1527009195876};\\\", \\\"{x:1656,y:963,t:1527009195888};\\\", \\\"{x:1655,y:963,t:1527009195905};\\\", \\\"{x:1655,y:965,t:1527009195921};\\\", \\\"{x:1654,y:969,t:1527009195938};\\\", \\\"{x:1653,y:971,t:1527009195955};\\\", \\\"{x:1652,y:974,t:1527009195971};\\\", \\\"{x:1649,y:981,t:1527009195988};\\\", \\\"{x:1648,y:981,t:1527009196004};\\\", \\\"{x:1648,y:983,t:1527009196021};\\\", \\\"{x:1647,y:984,t:1527009196038};\\\", \\\"{x:1646,y:984,t:1527009196252};\\\", \\\"{x:1645,y:984,t:1527009196276};\\\", \\\"{x:1643,y:984,t:1527009196325};\\\", \\\"{x:1642,y:984,t:1527009196365};\\\", \\\"{x:1640,y:984,t:1527009196388};\\\", \\\"{x:1639,y:984,t:1527009196468};\\\", \\\"{x:1638,y:984,t:1527009196476};\\\", \\\"{x:1637,y:983,t:1527009196507};\\\", \\\"{x:1636,y:983,t:1527009196539};\\\", \\\"{x:1635,y:982,t:1527009196555};\\\", \\\"{x:1634,y:981,t:1527009196571};\\\", \\\"{x:1632,y:980,t:1527009196587};\\\", \\\"{x:1630,y:979,t:1527009196604};\\\", \\\"{x:1627,y:976,t:1527009196620};\\\", \\\"{x:1625,y:974,t:1527009196638};\\\", \\\"{x:1623,y:973,t:1527009196655};\\\", \\\"{x:1622,y:972,t:1527009196716};\\\", \\\"{x:1622,y:970,t:1527009206257};\\\", \\\"{x:1622,y:961,t:1527009206268};\\\", \\\"{x:1629,y:919,t:1527009206285};\\\", \\\"{x:1641,y:859,t:1527009206302};\\\", \\\"{x:1649,y:803,t:1527009206317};\\\", \\\"{x:1660,y:723,t:1527009206334};\\\", \\\"{x:1671,y:642,t:1527009206352};\\\", \\\"{x:1696,y:551,t:1527009206368};\\\", \\\"{x:1718,y:468,t:1527009206384};\\\", \\\"{x:1741,y:372,t:1527009206401};\\\", \\\"{x:1748,y:340,t:1527009206417};\\\", \\\"{x:1748,y:310,t:1527009206435};\\\", \\\"{x:1752,y:285,t:1527009206452};\\\", \\\"{x:1755,y:277,t:1527009206467};\\\", \\\"{x:1755,y:268,t:1527009206484};\\\", \\\"{x:1755,y:267,t:1527009206501};\\\", \\\"{x:1755,y:268,t:1527009206561};\\\", \\\"{x:1755,y:276,t:1527009206569};\\\", \\\"{x:1754,y:283,t:1527009206585};\\\", \\\"{x:1741,y:309,t:1527009206601};\\\", \\\"{x:1731,y:333,t:1527009206617};\\\", \\\"{x:1720,y:359,t:1527009206634};\\\", \\\"{x:1710,y:374,t:1527009206651};\\\", \\\"{x:1707,y:382,t:1527009206668};\\\", \\\"{x:1705,y:386,t:1527009206685};\\\", \\\"{x:1704,y:390,t:1527009206701};\\\", \\\"{x:1703,y:392,t:1527009206718};\\\", \\\"{x:1701,y:396,t:1527009206734};\\\", \\\"{x:1697,y:400,t:1527009206751};\\\", \\\"{x:1694,y:407,t:1527009206767};\\\", \\\"{x:1689,y:414,t:1527009206785};\\\", \\\"{x:1679,y:424,t:1527009206801};\\\", \\\"{x:1672,y:429,t:1527009206817};\\\", \\\"{x:1666,y:434,t:1527009206834};\\\", \\\"{x:1658,y:439,t:1527009206851};\\\", \\\"{x:1652,y:443,t:1527009206867};\\\", \\\"{x:1647,y:447,t:1527009206885};\\\", \\\"{x:1645,y:448,t:1527009206901};\\\", \\\"{x:1643,y:448,t:1527009206945};\\\", \\\"{x:1642,y:448,t:1527009206952};\\\", \\\"{x:1637,y:447,t:1527009206968};\\\", \\\"{x:1632,y:446,t:1527009206985};\\\", \\\"{x:1622,y:440,t:1527009207001};\\\", \\\"{x:1614,y:437,t:1527009207018};\\\", \\\"{x:1604,y:433,t:1527009207034};\\\", \\\"{x:1597,y:431,t:1527009207052};\\\", \\\"{x:1593,y:427,t:1527009207067};\\\", \\\"{x:1593,y:423,t:1527009207085};\\\", \\\"{x:1593,y:420,t:1527009207102};\\\", \\\"{x:1594,y:418,t:1527009207117};\\\", \\\"{x:1596,y:417,t:1527009207153};\\\", \\\"{x:1597,y:417,t:1527009207176};\\\", \\\"{x:1598,y:417,t:1527009207192};\\\", \\\"{x:1599,y:417,t:1527009207208};\\\", \\\"{x:1601,y:418,t:1527009207217};\\\", \\\"{x:1604,y:420,t:1527009207234};\\\", \\\"{x:1608,y:424,t:1527009207252};\\\", \\\"{x:1610,y:426,t:1527009207267};\\\", \\\"{x:1611,y:427,t:1527009207284};\\\", \\\"{x:1611,y:428,t:1527009207345};\\\", \\\"{x:1611,y:429,t:1527009207400};\\\", \\\"{x:1612,y:429,t:1527009207769};\\\", \\\"{x:1612,y:431,t:1527009208585};\\\", \\\"{x:1612,y:432,t:1527009208602};\\\", \\\"{x:1610,y:433,t:1527009208617};\\\", \\\"{x:1609,y:433,t:1527009208641};\\\", \\\"{x:1609,y:434,t:1527009214010};\\\", \\\"{x:1609,y:435,t:1527009214018};\\\", \\\"{x:1609,y:436,t:1527009214035};\\\", \\\"{x:1608,y:437,t:1527009214051};\\\", \\\"{x:1608,y:438,t:1527009214073};\\\", \\\"{x:1608,y:439,t:1527009214097};\\\", \\\"{x:1608,y:440,t:1527009214113};\\\", \\\"{x:1607,y:441,t:1527009214122};\\\", \\\"{x:1607,y:443,t:1527009214146};\\\", \\\"{x:1607,y:444,t:1527009214234};\\\", \\\"{x:1607,y:446,t:1527009214251};\\\", \\\"{x:1608,y:449,t:1527009214268};\\\", \\\"{x:1609,y:452,t:1527009214284};\\\", \\\"{x:1609,y:454,t:1527009214301};\\\", \\\"{x:1610,y:457,t:1527009214318};\\\", \\\"{x:1610,y:461,t:1527009214335};\\\", \\\"{x:1612,y:465,t:1527009214352};\\\", \\\"{x:1613,y:470,t:1527009214369};\\\", \\\"{x:1614,y:474,t:1527009214384};\\\", \\\"{x:1617,y:484,t:1527009214401};\\\", \\\"{x:1618,y:492,t:1527009214418};\\\", \\\"{x:1620,y:497,t:1527009214434};\\\", \\\"{x:1622,y:501,t:1527009214452};\\\", \\\"{x:1623,y:506,t:1527009214468};\\\", \\\"{x:1625,y:509,t:1527009214484};\\\", \\\"{x:1625,y:512,t:1527009214501};\\\", \\\"{x:1626,y:516,t:1527009214518};\\\", \\\"{x:1628,y:522,t:1527009214534};\\\", \\\"{x:1629,y:529,t:1527009214552};\\\", \\\"{x:1632,y:537,t:1527009214568};\\\", \\\"{x:1632,y:541,t:1527009214583};\\\", \\\"{x:1634,y:548,t:1527009214601};\\\", \\\"{x:1634,y:551,t:1527009214618};\\\", \\\"{x:1634,y:554,t:1527009214634};\\\", \\\"{x:1634,y:556,t:1527009214651};\\\", \\\"{x:1634,y:559,t:1527009214667};\\\", \\\"{x:1634,y:562,t:1527009214684};\\\", \\\"{x:1634,y:567,t:1527009214700};\\\", \\\"{x:1634,y:571,t:1527009214718};\\\", \\\"{x:1634,y:574,t:1527009214734};\\\", \\\"{x:1633,y:578,t:1527009214751};\\\", \\\"{x:1632,y:581,t:1527009214767};\\\", \\\"{x:1631,y:583,t:1527009214784};\\\", \\\"{x:1629,y:590,t:1527009214801};\\\", \\\"{x:1628,y:594,t:1527009214818};\\\", \\\"{x:1627,y:599,t:1527009214834};\\\", \\\"{x:1626,y:603,t:1527009214851};\\\", \\\"{x:1625,y:607,t:1527009214868};\\\", \\\"{x:1623,y:612,t:1527009214884};\\\", \\\"{x:1621,y:617,t:1527009214901};\\\", \\\"{x:1620,y:621,t:1527009214917};\\\", \\\"{x:1618,y:625,t:1527009214934};\\\", \\\"{x:1617,y:630,t:1527009214950};\\\", \\\"{x:1616,y:633,t:1527009214968};\\\", \\\"{x:1615,y:639,t:1527009214984};\\\", \\\"{x:1612,y:651,t:1527009215001};\\\", \\\"{x:1611,y:658,t:1527009215018};\\\", \\\"{x:1611,y:664,t:1527009215034};\\\", \\\"{x:1611,y:674,t:1527009215050};\\\", \\\"{x:1611,y:681,t:1527009215067};\\\", \\\"{x:1611,y:688,t:1527009215084};\\\", \\\"{x:1612,y:691,t:1527009215101};\\\", \\\"{x:1613,y:692,t:1527009215118};\\\", \\\"{x:1613,y:694,t:1527009215134};\\\", \\\"{x:1613,y:697,t:1527009215151};\\\", \\\"{x:1613,y:699,t:1527009215168};\\\", \\\"{x:1613,y:703,t:1527009215184};\\\", \\\"{x:1613,y:705,t:1527009215201};\\\", \\\"{x:1613,y:709,t:1527009215218};\\\", \\\"{x:1613,y:711,t:1527009215234};\\\", \\\"{x:1612,y:715,t:1527009215251};\\\", \\\"{x:1612,y:720,t:1527009215268};\\\", \\\"{x:1612,y:723,t:1527009215284};\\\", \\\"{x:1612,y:728,t:1527009215301};\\\", \\\"{x:1611,y:734,t:1527009215318};\\\", \\\"{x:1611,y:735,t:1527009215334};\\\", \\\"{x:1611,y:737,t:1527009215351};\\\", \\\"{x:1611,y:740,t:1527009215368};\\\", \\\"{x:1611,y:742,t:1527009215384};\\\", \\\"{x:1611,y:746,t:1527009215401};\\\", \\\"{x:1611,y:747,t:1527009215418};\\\", \\\"{x:1611,y:748,t:1527009215434};\\\", \\\"{x:1611,y:755,t:1527009215451};\\\", \\\"{x:1611,y:758,t:1527009215468};\\\", \\\"{x:1611,y:762,t:1527009215484};\\\", \\\"{x:1611,y:767,t:1527009215501};\\\", \\\"{x:1613,y:773,t:1527009215518};\\\", \\\"{x:1615,y:781,t:1527009215534};\\\", \\\"{x:1615,y:789,t:1527009215551};\\\", \\\"{x:1615,y:795,t:1527009215568};\\\", \\\"{x:1615,y:799,t:1527009215584};\\\", \\\"{x:1616,y:804,t:1527009215600};\\\", \\\"{x:1616,y:806,t:1527009215618};\\\", \\\"{x:1617,y:809,t:1527009215634};\\\", \\\"{x:1617,y:810,t:1527009215651};\\\", \\\"{x:1617,y:811,t:1527009215668};\\\", \\\"{x:1617,y:813,t:1527009215684};\\\", \\\"{x:1618,y:815,t:1527009215701};\\\", \\\"{x:1618,y:816,t:1527009215718};\\\", \\\"{x:1618,y:818,t:1527009215734};\\\", \\\"{x:1618,y:820,t:1527009215751};\\\", \\\"{x:1618,y:828,t:1527009215768};\\\", \\\"{x:1618,y:834,t:1527009215784};\\\", \\\"{x:1618,y:835,t:1527009215801};\\\", \\\"{x:1618,y:838,t:1527009215818};\\\", \\\"{x:1618,y:839,t:1527009215841};\\\", \\\"{x:1618,y:840,t:1527009215850};\\\", \\\"{x:1618,y:841,t:1527009215867};\\\", \\\"{x:1618,y:843,t:1527009215884};\\\", \\\"{x:1618,y:847,t:1527009215901};\\\", \\\"{x:1618,y:848,t:1527009215918};\\\", \\\"{x:1618,y:850,t:1527009215934};\\\", \\\"{x:1618,y:859,t:1527009215951};\\\", \\\"{x:1618,y:861,t:1527009215968};\\\", \\\"{x:1618,y:863,t:1527009215984};\\\", \\\"{x:1618,y:871,t:1527009216001};\\\", \\\"{x:1620,y:877,t:1527009216019};\\\", \\\"{x:1620,y:882,t:1527009216034};\\\", \\\"{x:1620,y:891,t:1527009216051};\\\", \\\"{x:1618,y:898,t:1527009216068};\\\", \\\"{x:1618,y:902,t:1527009216084};\\\", \\\"{x:1617,y:904,t:1527009216101};\\\", \\\"{x:1616,y:906,t:1527009216118};\\\", \\\"{x:1616,y:909,t:1527009216161};\\\", \\\"{x:1616,y:910,t:1527009216177};\\\", \\\"{x:1616,y:912,t:1527009216185};\\\", \\\"{x:1616,y:914,t:1527009216201};\\\", \\\"{x:1613,y:929,t:1527009216218};\\\", \\\"{x:1607,y:941,t:1527009216234};\\\", \\\"{x:1606,y:948,t:1527009216250};\\\", \\\"{x:1602,y:958,t:1527009216268};\\\", \\\"{x:1601,y:968,t:1527009216284};\\\", \\\"{x:1599,y:973,t:1527009216301};\\\", \\\"{x:1598,y:974,t:1527009216318};\\\", \\\"{x:1598,y:976,t:1527009216334};\\\", \\\"{x:1598,y:977,t:1527009216351};\\\", \\\"{x:1598,y:978,t:1527009216368};\\\", \\\"{x:1598,y:979,t:1527009216450};\\\", \\\"{x:1601,y:979,t:1527009216690};\\\", \\\"{x:1605,y:977,t:1527009216701};\\\", \\\"{x:1611,y:974,t:1527009216718};\\\", \\\"{x:1620,y:972,t:1527009216734};\\\", \\\"{x:1621,y:972,t:1527009216762};\\\", \\\"{x:1616,y:972,t:1527009217035};\\\", \\\"{x:1615,y:972,t:1527009217052};\\\", \\\"{x:1610,y:972,t:1527009217067};\\\", \\\"{x:1605,y:972,t:1527009217085};\\\", \\\"{x:1601,y:972,t:1527009217281};\\\", \\\"{x:1597,y:972,t:1527009217289};\\\", \\\"{x:1593,y:972,t:1527009217301};\\\", \\\"{x:1580,y:970,t:1527009217317};\\\", \\\"{x:1562,y:970,t:1527009217335};\\\", \\\"{x:1540,y:970,t:1527009217351};\\\", \\\"{x:1524,y:970,t:1527009217368};\\\", \\\"{x:1507,y:969,t:1527009217384};\\\", \\\"{x:1483,y:967,t:1527009217400};\\\", \\\"{x:1462,y:963,t:1527009217417};\\\", \\\"{x:1454,y:960,t:1527009217435};\\\", \\\"{x:1444,y:960,t:1527009217451};\\\", \\\"{x:1434,y:960,t:1527009217467};\\\", \\\"{x:1427,y:960,t:1527009217485};\\\", \\\"{x:1419,y:959,t:1527009217501};\\\", \\\"{x:1414,y:958,t:1527009217517};\\\", \\\"{x:1410,y:958,t:1527009217534};\\\", \\\"{x:1403,y:958,t:1527009217551};\\\", \\\"{x:1397,y:958,t:1527009217567};\\\", \\\"{x:1392,y:958,t:1527009217584};\\\", \\\"{x:1386,y:958,t:1527009217601};\\\", \\\"{x:1381,y:958,t:1527009217617};\\\", \\\"{x:1372,y:958,t:1527009217634};\\\", \\\"{x:1363,y:955,t:1527009217651};\\\", \\\"{x:1350,y:953,t:1527009217667};\\\", \\\"{x:1335,y:951,t:1527009217684};\\\", \\\"{x:1317,y:951,t:1527009217701};\\\", \\\"{x:1288,y:950,t:1527009217717};\\\", \\\"{x:1271,y:946,t:1527009217734};\\\", \\\"{x:1251,y:942,t:1527009217751};\\\", \\\"{x:1236,y:938,t:1527009217767};\\\", \\\"{x:1224,y:937,t:1527009217784};\\\", \\\"{x:1210,y:936,t:1527009217800};\\\", \\\"{x:1205,y:936,t:1527009217817};\\\", \\\"{x:1201,y:936,t:1527009217834};\\\", \\\"{x:1198,y:936,t:1527009217851};\\\", \\\"{x:1197,y:936,t:1527009217867};\\\", \\\"{x:1195,y:936,t:1527009217929};\\\", \\\"{x:1194,y:936,t:1527009217936};\\\", \\\"{x:1192,y:936,t:1527009218057};\\\", \\\"{x:1191,y:936,t:1527009218114};\\\", \\\"{x:1191,y:937,t:1527009218194};\\\", \\\"{x:1191,y:938,t:1527009218210};\\\", \\\"{x:1192,y:939,t:1527009220122};\\\", \\\"{x:1194,y:939,t:1527009220145};\\\", \\\"{x:1194,y:937,t:1527009220161};\\\", \\\"{x:1195,y:936,t:1527009220176};\\\", \\\"{x:1195,y:935,t:1527009220184};\\\", \\\"{x:1195,y:934,t:1527009220209};\\\", \\\"{x:1196,y:934,t:1527009220217};\\\", \\\"{x:1197,y:933,t:1527009220234};\\\", \\\"{x:1197,y:932,t:1527009220252};\\\", \\\"{x:1198,y:931,t:1527009220267};\\\", \\\"{x:1199,y:931,t:1527009220284};\\\", \\\"{x:1201,y:931,t:1527009220301};\\\", \\\"{x:1203,y:931,t:1527009220318};\\\", \\\"{x:1209,y:933,t:1527009220334};\\\", \\\"{x:1216,y:937,t:1527009220351};\\\", \\\"{x:1231,y:942,t:1527009220367};\\\", \\\"{x:1245,y:946,t:1527009220384};\\\", \\\"{x:1264,y:952,t:1527009220400};\\\", \\\"{x:1277,y:956,t:1527009220418};\\\", \\\"{x:1285,y:959,t:1527009220434};\\\", \\\"{x:1293,y:959,t:1527009220451};\\\", \\\"{x:1297,y:960,t:1527009220467};\\\", \\\"{x:1304,y:962,t:1527009220484};\\\", \\\"{x:1315,y:963,t:1527009220501};\\\", \\\"{x:1332,y:966,t:1527009220517};\\\", \\\"{x:1348,y:968,t:1527009220534};\\\", \\\"{x:1367,y:971,t:1527009220550};\\\", \\\"{x:1385,y:975,t:1527009220568};\\\", \\\"{x:1393,y:975,t:1527009220584};\\\", \\\"{x:1401,y:975,t:1527009220601};\\\", \\\"{x:1404,y:975,t:1527009220617};\\\", \\\"{x:1405,y:975,t:1527009220634};\\\", \\\"{x:1406,y:975,t:1527009220651};\\\", \\\"{x:1408,y:975,t:1527009220667};\\\", \\\"{x:1409,y:975,t:1527009220722};\\\", \\\"{x:1407,y:975,t:1527009221721};\\\", \\\"{x:1398,y:972,t:1527009221734};\\\", \\\"{x:1380,y:971,t:1527009221751};\\\", \\\"{x:1360,y:968,t:1527009221767};\\\", \\\"{x:1344,y:965,t:1527009221784};\\\", \\\"{x:1331,y:960,t:1527009221800};\\\", \\\"{x:1320,y:957,t:1527009221817};\\\", \\\"{x:1317,y:957,t:1527009221834};\\\", \\\"{x:1315,y:957,t:1527009222066};\\\", \\\"{x:1312,y:956,t:1527009222074};\\\", \\\"{x:1306,y:955,t:1527009222085};\\\", \\\"{x:1295,y:954,t:1527009222101};\\\", \\\"{x:1287,y:951,t:1527009222118};\\\", \\\"{x:1272,y:946,t:1527009222135};\\\", \\\"{x:1262,y:945,t:1527009222151};\\\", \\\"{x:1252,y:943,t:1527009222167};\\\", \\\"{x:1244,y:942,t:1527009222185};\\\", \\\"{x:1235,y:941,t:1527009222201};\\\", \\\"{x:1216,y:941,t:1527009222217};\\\", \\\"{x:1198,y:941,t:1527009222234};\\\", \\\"{x:1162,y:941,t:1527009222251};\\\", \\\"{x:1078,y:944,t:1527009222268};\\\", \\\"{x:983,y:946,t:1527009222285};\\\", \\\"{x:895,y:946,t:1527009222300};\\\", \\\"{x:856,y:942,t:1527009222317};\\\", \\\"{x:840,y:934,t:1527009222335};\\\", \\\"{x:836,y:932,t:1527009222351};\\\", \\\"{x:835,y:930,t:1527009222369};\\\", \\\"{x:836,y:929,t:1527009222393};\\\", \\\"{x:839,y:929,t:1527009222401};\\\", \\\"{x:844,y:929,t:1527009222417};\\\", \\\"{x:850,y:931,t:1527009222434};\\\", \\\"{x:858,y:931,t:1527009222450};\\\", \\\"{x:869,y:934,t:1527009222468};\\\", \\\"{x:877,y:939,t:1527009222484};\\\", \\\"{x:890,y:941,t:1527009222500};\\\", \\\"{x:914,y:945,t:1527009222517};\\\", \\\"{x:938,y:951,t:1527009222534};\\\", \\\"{x:959,y:953,t:1527009222550};\\\", \\\"{x:976,y:957,t:1527009222568};\\\", \\\"{x:991,y:962,t:1527009222584};\\\", \\\"{x:1010,y:967,t:1527009222600};\\\", \\\"{x:1026,y:971,t:1527009222617};\\\", \\\"{x:1030,y:971,t:1527009222634};\\\", \\\"{x:1031,y:972,t:1527009222650};\\\", \\\"{x:1031,y:973,t:1527009222667};\\\", \\\"{x:1032,y:973,t:1527009222705};\\\", \\\"{x:1033,y:974,t:1527009222717};\\\", \\\"{x:1038,y:974,t:1527009222734};\\\", \\\"{x:1045,y:975,t:1527009222750};\\\", \\\"{x:1056,y:979,t:1527009222767};\\\", \\\"{x:1064,y:980,t:1527009222785};\\\", \\\"{x:1071,y:982,t:1527009222800};\\\", \\\"{x:1077,y:987,t:1527009222817};\\\", \\\"{x:1080,y:987,t:1527009222834};\\\", \\\"{x:1082,y:987,t:1527009222850};\\\", \\\"{x:1084,y:988,t:1527009222867};\\\", \\\"{x:1085,y:988,t:1527009223297};\\\", \\\"{x:1086,y:987,t:1527009228666};\\\", \\\"{x:1069,y:970,t:1527009228674};\\\", \\\"{x:1043,y:945,t:1527009228684};\\\", \\\"{x:947,y:888,t:1527009228701};\\\", \\\"{x:847,y:826,t:1527009228717};\\\", \\\"{x:733,y:763,t:1527009228734};\\\", \\\"{x:627,y:713,t:1527009228751};\\\", \\\"{x:531,y:673,t:1527009228767};\\\", \\\"{x:503,y:653,t:1527009228784};\\\", \\\"{x:493,y:648,t:1527009228801};\\\", \\\"{x:491,y:648,t:1527009228856};\\\", \\\"{x:488,y:648,t:1527009228864};\\\", \\\"{x:483,y:649,t:1527009228879};\\\", \\\"{x:472,y:654,t:1527009228896};\\\", \\\"{x:458,y:661,t:1527009228912};\\\", \\\"{x:455,y:663,t:1527009228934};\\\", \\\"{x:451,y:665,t:1527009228951};\\\", \\\"{x:449,y:666,t:1527009228966};\\\", \\\"{x:447,y:667,t:1527009228983};\\\", \\\"{x:441,y:674,t:1527009229001};\\\", \\\"{x:440,y:682,t:1527009229017};\\\", \\\"{x:440,y:691,t:1527009229033};\\\", \\\"{x:440,y:696,t:1527009229051};\\\", \\\"{x:441,y:704,t:1527009229067};\\\", \\\"{x:447,y:714,t:1527009229084};\\\", \\\"{x:452,y:718,t:1527009229100};\\\", \\\"{x:460,y:723,t:1527009229117};\\\", \\\"{x:467,y:726,t:1527009229134};\\\", \\\"{x:471,y:727,t:1527009229151};\\\", \\\"{x:478,y:730,t:1527009229168};\\\", \\\"{x:480,y:730,t:1527009229183};\\\", \\\"{x:481,y:730,t:1527009229200};\\\", \\\"{x:482,y:730,t:1527009229617};\\\", \\\"{x:484,y:730,t:1527009231873};\\\", \\\"{x:485,y:730,t:1527009231886};\\\", \\\"{x:499,y:731,t:1527009231903};\\\", \\\"{x:511,y:735,t:1527009231920};\\\", \\\"{x:524,y:739,t:1527009231936};\\\", \\\"{x:546,y:746,t:1527009231953};\\\", \\\"{x:560,y:752,t:1527009231970};\\\", \\\"{x:578,y:760,t:1527009231986};\\\", \\\"{x:589,y:769,t:1527009232003};\\\", \\\"{x:603,y:775,t:1527009232019};\\\", \\\"{x:612,y:779,t:1527009232036};\\\", \\\"{x:621,y:781,t:1527009232053};\\\", \\\"{x:623,y:784,t:1527009232070};\\\", \\\"{x:624,y:784,t:1527009232086};\\\" ] }, { \\\"rt\\\": 73700, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 462966, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"I\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -12 PM-12 PM-C -12 PM-12 PM-I -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:626,y:784,t:1527009234130};\\\", \\\"{x:639,y:784,t:1527009234138};\\\", \\\"{x:695,y:775,t:1527009234155};\\\", \\\"{x:781,y:765,t:1527009234170};\\\", \\\"{x:871,y:748,t:1527009234188};\\\", \\\"{x:973,y:734,t:1527009234204};\\\", \\\"{x:978,y:732,t:1527009234221};\\\", \\\"{x:980,y:732,t:1527009234237};\\\", \\\"{x:981,y:732,t:1527009234906};\\\", \\\"{x:994,y:731,t:1527009234923};\\\", \\\"{x:1006,y:729,t:1527009234939};\\\", \\\"{x:1020,y:724,t:1527009234955};\\\", \\\"{x:1030,y:719,t:1527009234972};\\\", \\\"{x:1044,y:714,t:1527009234989};\\\", \\\"{x:1061,y:711,t:1527009235005};\\\", \\\"{x:1079,y:708,t:1527009235023};\\\", \\\"{x:1096,y:705,t:1527009235039};\\\", \\\"{x:1107,y:704,t:1527009235055};\\\", \\\"{x:1123,y:701,t:1527009235073};\\\", \\\"{x:1134,y:695,t:1527009235089};\\\", \\\"{x:1150,y:693,t:1527009235106};\\\", \\\"{x:1160,y:690,t:1527009235122};\\\", \\\"{x:1164,y:689,t:1527009235140};\\\", \\\"{x:1169,y:686,t:1527009235157};\\\", \\\"{x:1177,y:682,t:1527009235172};\\\", \\\"{x:1192,y:677,t:1527009235190};\\\", \\\"{x:1200,y:676,t:1527009235207};\\\", \\\"{x:1221,y:672,t:1527009235223};\\\", \\\"{x:1234,y:667,t:1527009235239};\\\", \\\"{x:1251,y:657,t:1527009235256};\\\", \\\"{x:1276,y:649,t:1527009235273};\\\", \\\"{x:1302,y:638,t:1527009235289};\\\", \\\"{x:1311,y:634,t:1527009235306};\\\", \\\"{x:1320,y:633,t:1527009235323};\\\", \\\"{x:1321,y:633,t:1527009235339};\\\", \\\"{x:1323,y:631,t:1527009235357};\\\", \\\"{x:1324,y:631,t:1527009235649};\\\", \\\"{x:1324,y:633,t:1527009235666};\\\", \\\"{x:1324,y:634,t:1527009235689};\\\", \\\"{x:1324,y:636,t:1527009235706};\\\", \\\"{x:1325,y:637,t:1527009235724};\\\", \\\"{x:1325,y:639,t:1527009235746};\\\", \\\"{x:1325,y:640,t:1527009235802};\\\", \\\"{x:1326,y:641,t:1527009235833};\\\", \\\"{x:1328,y:644,t:1527009236618};\\\", \\\"{x:1332,y:644,t:1527009236625};\\\", \\\"{x:1349,y:652,t:1527009236640};\\\", \\\"{x:1368,y:660,t:1527009236658};\\\", \\\"{x:1393,y:668,t:1527009236673};\\\", \\\"{x:1421,y:678,t:1527009236691};\\\", \\\"{x:1459,y:692,t:1527009236707};\\\", \\\"{x:1516,y:711,t:1527009236724};\\\", \\\"{x:1570,y:743,t:1527009236740};\\\", \\\"{x:1620,y:774,t:1527009236758};\\\", \\\"{x:1679,y:803,t:1527009236774};\\\", \\\"{x:1739,y:837,t:1527009236790};\\\", \\\"{x:1782,y:862,t:1527009236807};\\\", \\\"{x:1805,y:878,t:1527009236824};\\\", \\\"{x:1834,y:899,t:1527009236841};\\\", \\\"{x:1848,y:907,t:1527009236857};\\\", \\\"{x:1859,y:915,t:1527009236874};\\\", \\\"{x:1867,y:919,t:1527009236891};\\\", \\\"{x:1871,y:920,t:1527009236907};\\\", \\\"{x:1873,y:920,t:1527009237034};\\\", \\\"{x:1873,y:917,t:1527009237090};\\\", \\\"{x:1864,y:907,t:1527009237108};\\\", \\\"{x:1851,y:895,t:1527009237124};\\\", \\\"{x:1839,y:886,t:1527009237141};\\\", \\\"{x:1835,y:883,t:1527009237158};\\\", \\\"{x:1834,y:882,t:1527009237586};\\\", \\\"{x:1832,y:877,t:1527009237594};\\\", \\\"{x:1822,y:869,t:1527009237608};\\\", \\\"{x:1788,y:844,t:1527009237624};\\\", \\\"{x:1721,y:801,t:1527009237641};\\\", \\\"{x:1695,y:779,t:1527009237657};\\\", \\\"{x:1676,y:762,t:1527009237674};\\\", \\\"{x:1665,y:749,t:1527009237691};\\\", \\\"{x:1656,y:733,t:1527009237707};\\\", \\\"{x:1646,y:713,t:1527009237724};\\\", \\\"{x:1638,y:693,t:1527009237741};\\\", \\\"{x:1633,y:670,t:1527009237758};\\\", \\\"{x:1628,y:650,t:1527009237773};\\\", \\\"{x:1626,y:635,t:1527009237791};\\\", \\\"{x:1626,y:626,t:1527009237808};\\\", \\\"{x:1624,y:619,t:1527009237824};\\\", \\\"{x:1623,y:610,t:1527009237841};\\\", \\\"{x:1622,y:604,t:1527009237857};\\\", \\\"{x:1622,y:597,t:1527009237874};\\\", \\\"{x:1626,y:583,t:1527009237891};\\\", \\\"{x:1631,y:571,t:1527009237908};\\\", \\\"{x:1634,y:559,t:1527009237924};\\\", \\\"{x:1635,y:546,t:1527009237941};\\\", \\\"{x:1637,y:534,t:1527009237958};\\\", \\\"{x:1637,y:527,t:1527009237974};\\\", \\\"{x:1639,y:522,t:1527009237991};\\\", \\\"{x:1640,y:518,t:1527009238008};\\\", \\\"{x:1642,y:513,t:1527009238024};\\\", \\\"{x:1644,y:507,t:1527009238041};\\\", \\\"{x:1646,y:503,t:1527009238058};\\\", \\\"{x:1647,y:501,t:1527009238074};\\\", \\\"{x:1647,y:500,t:1527009238091};\\\", \\\"{x:1647,y:499,t:1527009238108};\\\", \\\"{x:1647,y:498,t:1527009238274};\\\", \\\"{x:1644,y:498,t:1527009238281};\\\", \\\"{x:1638,y:500,t:1527009238292};\\\", \\\"{x:1628,y:507,t:1527009238308};\\\", \\\"{x:1617,y:514,t:1527009238325};\\\", \\\"{x:1600,y:526,t:1527009238342};\\\", \\\"{x:1592,y:533,t:1527009238358};\\\", \\\"{x:1582,y:542,t:1527009238376};\\\", \\\"{x:1580,y:544,t:1527009238392};\\\", \\\"{x:1572,y:554,t:1527009238409};\\\", \\\"{x:1563,y:566,t:1527009238425};\\\", \\\"{x:1554,y:579,t:1527009238441};\\\", \\\"{x:1546,y:591,t:1527009238458};\\\", \\\"{x:1540,y:605,t:1527009238475};\\\", \\\"{x:1533,y:617,t:1527009238492};\\\", \\\"{x:1528,y:633,t:1527009238508};\\\", \\\"{x:1522,y:652,t:1527009238525};\\\", \\\"{x:1518,y:669,t:1527009238541};\\\", \\\"{x:1516,y:686,t:1527009238558};\\\", \\\"{x:1513,y:707,t:1527009238575};\\\", \\\"{x:1509,y:726,t:1527009238592};\\\", \\\"{x:1505,y:753,t:1527009238608};\\\", \\\"{x:1501,y:791,t:1527009238625};\\\", \\\"{x:1501,y:820,t:1527009238642};\\\", \\\"{x:1501,y:842,t:1527009238658};\\\", \\\"{x:1501,y:854,t:1527009238675};\\\", \\\"{x:1501,y:866,t:1527009238692};\\\", \\\"{x:1501,y:878,t:1527009238708};\\\", \\\"{x:1501,y:882,t:1527009238725};\\\", \\\"{x:1501,y:885,t:1527009238742};\\\", \\\"{x:1501,y:886,t:1527009238758};\\\", \\\"{x:1501,y:889,t:1527009238775};\\\", \\\"{x:1501,y:893,t:1527009238792};\\\", \\\"{x:1500,y:899,t:1527009238809};\\\", \\\"{x:1500,y:902,t:1527009238825};\\\", \\\"{x:1499,y:903,t:1527009238842};\\\", \\\"{x:1499,y:905,t:1527009238858};\\\", \\\"{x:1499,y:909,t:1527009238875};\\\", \\\"{x:1498,y:912,t:1527009238892};\\\", \\\"{x:1498,y:918,t:1527009238908};\\\", \\\"{x:1497,y:921,t:1527009238925};\\\", \\\"{x:1496,y:925,t:1527009238942};\\\", \\\"{x:1495,y:928,t:1527009238958};\\\", \\\"{x:1494,y:928,t:1527009238974};\\\", \\\"{x:1494,y:930,t:1527009238992};\\\", \\\"{x:1492,y:929,t:1527009239466};\\\", \\\"{x:1492,y:928,t:1527009239475};\\\", \\\"{x:1490,y:919,t:1527009239493};\\\", \\\"{x:1488,y:908,t:1527009239510};\\\", \\\"{x:1486,y:896,t:1527009239527};\\\", \\\"{x:1485,y:888,t:1527009239543};\\\", \\\"{x:1484,y:881,t:1527009239560};\\\", \\\"{x:1483,y:875,t:1527009239576};\\\", \\\"{x:1481,y:867,t:1527009239593};\\\", \\\"{x:1481,y:853,t:1527009239609};\\\", \\\"{x:1481,y:844,t:1527009239627};\\\", \\\"{x:1481,y:833,t:1527009239642};\\\", \\\"{x:1481,y:824,t:1527009239659};\\\", \\\"{x:1481,y:814,t:1527009239676};\\\", \\\"{x:1483,y:805,t:1527009239692};\\\", \\\"{x:1483,y:790,t:1527009239709};\\\", \\\"{x:1486,y:780,t:1527009239726};\\\", \\\"{x:1487,y:772,t:1527009239742};\\\", \\\"{x:1489,y:767,t:1527009239759};\\\", \\\"{x:1489,y:761,t:1527009239775};\\\", \\\"{x:1490,y:758,t:1527009239792};\\\", \\\"{x:1492,y:748,t:1527009239809};\\\", \\\"{x:1493,y:742,t:1527009239826};\\\", \\\"{x:1493,y:736,t:1527009239842};\\\", \\\"{x:1493,y:726,t:1527009239859};\\\", \\\"{x:1493,y:716,t:1527009239876};\\\", \\\"{x:1493,y:707,t:1527009239892};\\\", \\\"{x:1493,y:691,t:1527009239909};\\\", \\\"{x:1493,y:678,t:1527009239926};\\\", \\\"{x:1488,y:664,t:1527009239942};\\\", \\\"{x:1483,y:651,t:1527009239959};\\\", \\\"{x:1475,y:632,t:1527009239976};\\\", \\\"{x:1460,y:604,t:1527009239992};\\\", \\\"{x:1443,y:583,t:1527009240009};\\\", \\\"{x:1422,y:559,t:1527009240026};\\\", \\\"{x:1401,y:542,t:1527009240043};\\\", \\\"{x:1385,y:528,t:1527009240059};\\\", \\\"{x:1374,y:518,t:1527009240076};\\\", \\\"{x:1366,y:512,t:1527009240093};\\\", \\\"{x:1360,y:506,t:1527009240110};\\\", \\\"{x:1357,y:502,t:1527009240126};\\\", \\\"{x:1355,y:498,t:1527009240143};\\\", \\\"{x:1354,y:496,t:1527009240159};\\\", \\\"{x:1353,y:492,t:1527009240176};\\\", \\\"{x:1350,y:488,t:1527009240193};\\\", \\\"{x:1349,y:485,t:1527009240209};\\\", \\\"{x:1349,y:484,t:1527009240227};\\\", \\\"{x:1347,y:483,t:1527009240243};\\\", \\\"{x:1347,y:482,t:1527009240260};\\\", \\\"{x:1346,y:481,t:1527009240276};\\\", \\\"{x:1345,y:480,t:1527009240293};\\\", \\\"{x:1345,y:481,t:1527009240408};\\\", \\\"{x:1345,y:487,t:1527009240416};\\\", \\\"{x:1345,y:488,t:1527009240426};\\\", \\\"{x:1349,y:499,t:1527009240443};\\\", \\\"{x:1353,y:515,t:1527009240460};\\\", \\\"{x:1364,y:530,t:1527009240476};\\\", \\\"{x:1369,y:546,t:1527009240493};\\\", \\\"{x:1371,y:557,t:1527009240510};\\\", \\\"{x:1375,y:568,t:1527009240526};\\\", \\\"{x:1377,y:580,t:1527009240543};\\\", \\\"{x:1379,y:587,t:1527009240560};\\\", \\\"{x:1379,y:593,t:1527009240576};\\\", \\\"{x:1379,y:606,t:1527009240592};\\\", \\\"{x:1379,y:616,t:1527009240610};\\\", \\\"{x:1379,y:628,t:1527009240626};\\\", \\\"{x:1379,y:635,t:1527009240643};\\\", \\\"{x:1379,y:642,t:1527009240660};\\\", \\\"{x:1378,y:650,t:1527009240676};\\\", \\\"{x:1375,y:663,t:1527009240693};\\\", \\\"{x:1372,y:676,t:1527009240710};\\\", \\\"{x:1367,y:693,t:1527009240726};\\\", \\\"{x:1364,y:706,t:1527009240743};\\\", \\\"{x:1356,y:727,t:1527009240760};\\\", \\\"{x:1347,y:751,t:1527009240776};\\\", \\\"{x:1334,y:777,t:1527009240793};\\\", \\\"{x:1323,y:799,t:1527009240810};\\\", \\\"{x:1314,y:819,t:1527009240827};\\\", \\\"{x:1303,y:833,t:1527009240843};\\\", \\\"{x:1291,y:850,t:1527009240860};\\\", \\\"{x:1277,y:867,t:1527009240877};\\\", \\\"{x:1265,y:880,t:1527009240893};\\\", \\\"{x:1253,y:889,t:1527009240910};\\\", \\\"{x:1240,y:897,t:1527009240927};\\\", \\\"{x:1229,y:903,t:1527009240943};\\\", \\\"{x:1221,y:907,t:1527009240960};\\\", \\\"{x:1213,y:910,t:1527009240976};\\\", \\\"{x:1210,y:910,t:1527009240993};\\\", \\\"{x:1209,y:910,t:1527009241010};\\\", \\\"{x:1209,y:905,t:1527009241097};\\\", \\\"{x:1209,y:899,t:1527009241110};\\\", \\\"{x:1209,y:892,t:1527009241127};\\\", \\\"{x:1209,y:882,t:1527009241144};\\\", \\\"{x:1211,y:875,t:1527009241161};\\\", \\\"{x:1215,y:863,t:1527009241177};\\\", \\\"{x:1221,y:854,t:1527009241193};\\\", \\\"{x:1224,y:845,t:1527009241211};\\\", \\\"{x:1227,y:842,t:1527009241227};\\\", \\\"{x:1228,y:840,t:1527009241243};\\\", \\\"{x:1229,y:837,t:1527009241260};\\\", \\\"{x:1229,y:836,t:1527009241280};\\\", \\\"{x:1229,y:835,t:1527009241530};\\\", \\\"{x:1229,y:833,t:1527009241721};\\\", \\\"{x:1229,y:831,t:1527009241737};\\\", \\\"{x:1228,y:831,t:1527009241913};\\\", \\\"{x:1225,y:831,t:1527009241927};\\\", \\\"{x:1221,y:833,t:1527009241944};\\\", \\\"{x:1217,y:834,t:1527009241962};\\\", \\\"{x:1216,y:834,t:1527009241977};\\\", \\\"{x:1216,y:835,t:1527009241994};\\\", \\\"{x:1215,y:837,t:1527009242299};\\\", \\\"{x:1214,y:838,t:1527009242312};\\\", \\\"{x:1213,y:841,t:1527009242329};\\\", \\\"{x:1212,y:846,t:1527009242345};\\\", \\\"{x:1212,y:850,t:1527009242362};\\\", \\\"{x:1211,y:853,t:1527009242379};\\\", \\\"{x:1211,y:858,t:1527009242395};\\\", \\\"{x:1211,y:868,t:1527009242412};\\\", \\\"{x:1211,y:880,t:1527009242429};\\\", \\\"{x:1210,y:886,t:1527009242445};\\\", \\\"{x:1210,y:891,t:1527009242461};\\\", \\\"{x:1210,y:895,t:1527009242479};\\\", \\\"{x:1210,y:904,t:1527009242495};\\\", \\\"{x:1211,y:911,t:1527009242512};\\\", \\\"{x:1211,y:920,t:1527009242529};\\\", \\\"{x:1211,y:926,t:1527009242545};\\\", \\\"{x:1211,y:932,t:1527009242562};\\\", \\\"{x:1212,y:935,t:1527009242579};\\\", \\\"{x:1212,y:936,t:1527009242595};\\\", \\\"{x:1212,y:938,t:1527009242612};\\\", \\\"{x:1212,y:939,t:1527009242629};\\\", \\\"{x:1212,y:941,t:1527009242645};\\\", \\\"{x:1212,y:942,t:1527009242665};\\\", \\\"{x:1212,y:944,t:1527009242681};\\\", \\\"{x:1212,y:946,t:1527009242695};\\\", \\\"{x:1210,y:949,t:1527009242711};\\\", \\\"{x:1210,y:950,t:1527009242728};\\\", \\\"{x:1210,y:951,t:1527009242752};\\\", \\\"{x:1210,y:952,t:1527009242761};\\\", \\\"{x:1209,y:953,t:1527009242792};\\\", \\\"{x:1209,y:955,t:1527009242808};\\\", \\\"{x:1208,y:956,t:1527009242824};\\\", \\\"{x:1208,y:957,t:1527009242832};\\\", \\\"{x:1211,y:958,t:1527009242946};\\\", \\\"{x:1221,y:958,t:1527009242962};\\\", \\\"{x:1235,y:957,t:1527009242979};\\\", \\\"{x:1244,y:956,t:1527009242996};\\\", \\\"{x:1255,y:956,t:1527009243011};\\\", \\\"{x:1268,y:956,t:1527009243029};\\\", \\\"{x:1281,y:956,t:1527009243046};\\\", \\\"{x:1293,y:958,t:1527009243063};\\\", \\\"{x:1307,y:962,t:1527009243079};\\\", \\\"{x:1315,y:965,t:1527009243096};\\\", \\\"{x:1326,y:968,t:1527009243114};\\\", \\\"{x:1334,y:969,t:1527009243130};\\\", \\\"{x:1344,y:972,t:1527009243145};\\\", \\\"{x:1349,y:972,t:1527009243162};\\\", \\\"{x:1351,y:972,t:1527009243179};\\\", \\\"{x:1353,y:973,t:1527009243196};\\\", \\\"{x:1354,y:973,t:1527009243213};\\\", \\\"{x:1355,y:973,t:1527009243229};\\\", \\\"{x:1357,y:973,t:1527009243245};\\\", \\\"{x:1358,y:973,t:1527009243262};\\\", \\\"{x:1361,y:973,t:1527009243278};\\\", \\\"{x:1362,y:973,t:1527009243297};\\\", \\\"{x:1363,y:973,t:1527009243328};\\\", \\\"{x:1364,y:973,t:1527009243641};\\\", \\\"{x:1364,y:972,t:1527009243657};\\\", \\\"{x:1364,y:971,t:1527009243681};\\\", \\\"{x:1363,y:971,t:1527009243705};\\\", \\\"{x:1362,y:969,t:1527009243721};\\\", \\\"{x:1361,y:969,t:1527009243730};\\\", \\\"{x:1360,y:968,t:1527009243746};\\\", \\\"{x:1357,y:966,t:1527009243763};\\\", \\\"{x:1355,y:966,t:1527009243786};\\\", \\\"{x:1355,y:965,t:1527009244312};\\\", \\\"{x:1354,y:965,t:1527009244850};\\\", \\\"{x:1354,y:963,t:1527009244864};\\\", \\\"{x:1354,y:962,t:1527009244891};\\\", \\\"{x:1354,y:960,t:1527009244905};\\\", \\\"{x:1354,y:959,t:1527009244945};\\\", \\\"{x:1354,y:956,t:1527009244986};\\\", \\\"{x:1354,y:955,t:1527009245209};\\\", \\\"{x:1355,y:953,t:1527009245217};\\\", \\\"{x:1355,y:951,t:1527009245240};\\\", \\\"{x:1355,y:949,t:1527009245257};\\\", \\\"{x:1356,y:949,t:1527009245273};\\\", \\\"{x:1356,y:947,t:1527009245305};\\\", \\\"{x:1356,y:946,t:1527009245313};\\\", \\\"{x:1356,y:941,t:1527009245331};\\\", \\\"{x:1359,y:936,t:1527009245347};\\\", \\\"{x:1359,y:931,t:1527009245363};\\\", \\\"{x:1359,y:924,t:1527009245381};\\\", \\\"{x:1363,y:917,t:1527009245397};\\\", \\\"{x:1366,y:910,t:1527009245413};\\\", \\\"{x:1367,y:908,t:1527009245430};\\\", \\\"{x:1368,y:901,t:1527009245448};\\\", \\\"{x:1371,y:890,t:1527009245464};\\\", \\\"{x:1376,y:872,t:1527009245481};\\\", \\\"{x:1380,y:856,t:1527009245497};\\\", \\\"{x:1383,y:843,t:1527009245514};\\\", \\\"{x:1385,y:838,t:1527009245531};\\\", \\\"{x:1385,y:833,t:1527009245547};\\\", \\\"{x:1385,y:830,t:1527009245563};\\\", \\\"{x:1386,y:829,t:1527009245581};\\\", \\\"{x:1386,y:827,t:1527009245597};\\\", \\\"{x:1386,y:826,t:1527009245617};\\\", \\\"{x:1386,y:824,t:1527009245633};\\\", \\\"{x:1386,y:823,t:1527009245657};\\\", \\\"{x:1386,y:820,t:1527009245664};\\\", \\\"{x:1386,y:818,t:1527009245680};\\\", \\\"{x:1386,y:816,t:1527009245697};\\\", \\\"{x:1386,y:810,t:1527009245714};\\\", \\\"{x:1384,y:801,t:1527009245730};\\\", \\\"{x:1383,y:791,t:1527009245747};\\\", \\\"{x:1379,y:782,t:1527009245765};\\\", \\\"{x:1375,y:771,t:1527009245780};\\\", \\\"{x:1371,y:762,t:1527009245797};\\\", \\\"{x:1369,y:755,t:1527009245814};\\\", \\\"{x:1367,y:752,t:1527009245830};\\\", \\\"{x:1367,y:748,t:1527009245847};\\\", \\\"{x:1366,y:737,t:1527009245864};\\\", \\\"{x:1366,y:734,t:1527009245881};\\\", \\\"{x:1366,y:729,t:1527009245898};\\\", \\\"{x:1366,y:723,t:1527009245915};\\\", \\\"{x:1366,y:717,t:1527009245931};\\\", \\\"{x:1366,y:714,t:1527009245947};\\\", \\\"{x:1366,y:711,t:1527009245964};\\\", \\\"{x:1366,y:707,t:1527009245981};\\\", \\\"{x:1366,y:705,t:1527009245997};\\\", \\\"{x:1366,y:700,t:1527009246014};\\\", \\\"{x:1367,y:699,t:1527009246031};\\\", \\\"{x:1367,y:694,t:1527009246048};\\\", \\\"{x:1367,y:684,t:1527009246065};\\\", \\\"{x:1366,y:678,t:1527009246081};\\\", \\\"{x:1366,y:674,t:1527009246098};\\\", \\\"{x:1365,y:672,t:1527009246115};\\\", \\\"{x:1363,y:667,t:1527009246130};\\\", \\\"{x:1362,y:661,t:1527009246148};\\\", \\\"{x:1362,y:653,t:1527009246164};\\\", \\\"{x:1359,y:647,t:1527009246181};\\\", \\\"{x:1358,y:645,t:1527009246197};\\\", \\\"{x:1358,y:644,t:1527009246214};\\\", \\\"{x:1356,y:641,t:1527009246232};\\\", \\\"{x:1354,y:635,t:1527009246247};\\\", \\\"{x:1350,y:626,t:1527009246265};\\\", \\\"{x:1349,y:623,t:1527009246280};\\\", \\\"{x:1349,y:622,t:1527009246297};\\\", \\\"{x:1348,y:620,t:1527009246314};\\\", \\\"{x:1347,y:620,t:1527009246458};\\\", \\\"{x:1346,y:620,t:1527009246489};\\\", \\\"{x:1345,y:617,t:1527009246498};\\\", \\\"{x:1345,y:612,t:1527009246515};\\\", \\\"{x:1345,y:608,t:1527009246532};\\\", \\\"{x:1345,y:602,t:1527009246548};\\\", \\\"{x:1345,y:599,t:1527009246565};\\\", \\\"{x:1345,y:594,t:1527009246582};\\\", \\\"{x:1345,y:590,t:1527009246599};\\\", \\\"{x:1345,y:584,t:1527009246615};\\\", \\\"{x:1345,y:579,t:1527009246632};\\\", \\\"{x:1345,y:572,t:1527009246649};\\\", \\\"{x:1346,y:568,t:1527009246664};\\\", \\\"{x:1346,y:565,t:1527009246682};\\\", \\\"{x:1346,y:560,t:1527009246699};\\\", \\\"{x:1347,y:556,t:1527009246714};\\\", \\\"{x:1349,y:553,t:1527009246731};\\\", \\\"{x:1349,y:549,t:1527009246748};\\\", \\\"{x:1350,y:542,t:1527009246764};\\\", \\\"{x:1350,y:538,t:1527009246781};\\\", \\\"{x:1350,y:531,t:1527009246799};\\\", \\\"{x:1353,y:522,t:1527009246815};\\\", \\\"{x:1353,y:515,t:1527009246831};\\\", \\\"{x:1354,y:507,t:1527009246848};\\\", \\\"{x:1354,y:503,t:1527009246865};\\\", \\\"{x:1354,y:500,t:1527009246882};\\\", \\\"{x:1354,y:495,t:1527009246898};\\\", \\\"{x:1354,y:492,t:1527009246915};\\\", \\\"{x:1354,y:487,t:1527009246931};\\\", \\\"{x:1354,y:482,t:1527009246949};\\\", \\\"{x:1354,y:477,t:1527009246964};\\\", \\\"{x:1354,y:474,t:1527009246982};\\\", \\\"{x:1354,y:471,t:1527009246999};\\\", \\\"{x:1354,y:470,t:1527009247014};\\\", \\\"{x:1354,y:466,t:1527009247032};\\\", \\\"{x:1354,y:462,t:1527009247049};\\\", \\\"{x:1354,y:459,t:1527009247065};\\\", \\\"{x:1354,y:457,t:1527009247082};\\\", \\\"{x:1354,y:454,t:1527009247098};\\\", \\\"{x:1354,y:450,t:1527009247115};\\\", \\\"{x:1354,y:446,t:1527009247131};\\\", \\\"{x:1353,y:443,t:1527009247148};\\\", \\\"{x:1352,y:440,t:1527009247165};\\\", \\\"{x:1351,y:436,t:1527009247181};\\\", \\\"{x:1351,y:435,t:1527009247198};\\\", \\\"{x:1350,y:434,t:1527009247216};\\\", \\\"{x:1350,y:432,t:1527009247232};\\\", \\\"{x:1349,y:430,t:1527009247250};\\\", \\\"{x:1349,y:429,t:1527009247322};\\\", \\\"{x:1349,y:428,t:1527009247337};\\\", \\\"{x:1343,y:426,t:1527009283568};\\\", \\\"{x:1324,y:433,t:1527009283576};\\\", \\\"{x:1303,y:485,t:1527009283593};\\\", \\\"{x:1289,y:583,t:1527009283610};\\\", \\\"{x:1285,y:676,t:1527009283626};\\\", \\\"{x:1290,y:755,t:1527009283643};\\\", \\\"{x:1302,y:815,t:1527009283659};\\\", \\\"{x:1322,y:849,t:1527009283675};\\\", \\\"{x:1331,y:864,t:1527009283693};\\\", \\\"{x:1331,y:865,t:1527009283709};\\\", \\\"{x:1345,y:890,t:1527009283726};\\\", \\\"{x:1381,y:962,t:1527009283742};\\\", \\\"{x:1386,y:981,t:1527009283760};\\\", \\\"{x:1389,y:991,t:1527009283776};\\\", \\\"{x:1387,y:1006,t:1527009283792};\\\", \\\"{x:1379,y:1024,t:1527009283810};\\\", \\\"{x:1372,y:1035,t:1527009283826};\\\", \\\"{x:1370,y:1037,t:1527009283843};\\\", \\\"{x:1368,y:1037,t:1527009283919};\\\", \\\"{x:1366,y:1031,t:1527009283926};\\\", \\\"{x:1355,y:1015,t:1527009283942};\\\", \\\"{x:1332,y:980,t:1527009283960};\\\", \\\"{x:1306,y:931,t:1527009283977};\\\", \\\"{x:1284,y:893,t:1527009283993};\\\", \\\"{x:1271,y:878,t:1527009284010};\\\", \\\"{x:1268,y:873,t:1527009284027};\\\", \\\"{x:1265,y:868,t:1527009284043};\\\", \\\"{x:1264,y:866,t:1527009284060};\\\", \\\"{x:1263,y:866,t:1527009284095};\\\", \\\"{x:1262,y:864,t:1527009284120};\\\", \\\"{x:1262,y:862,t:1527009284127};\\\", \\\"{x:1260,y:855,t:1527009284143};\\\", \\\"{x:1260,y:845,t:1527009284160};\\\", \\\"{x:1259,y:834,t:1527009284177};\\\", \\\"{x:1256,y:828,t:1527009284192};\\\", \\\"{x:1256,y:825,t:1527009284210};\\\", \\\"{x:1255,y:824,t:1527009284227};\\\", \\\"{x:1254,y:822,t:1527009284243};\\\", \\\"{x:1254,y:821,t:1527009284279};\\\", \\\"{x:1253,y:820,t:1527009284328};\\\", \\\"{x:1245,y:820,t:1527009284343};\\\", \\\"{x:1231,y:823,t:1527009284360};\\\", \\\"{x:1221,y:824,t:1527009284377};\\\", \\\"{x:1208,y:828,t:1527009284395};\\\", \\\"{x:1199,y:829,t:1527009284410};\\\", \\\"{x:1194,y:832,t:1527009284427};\\\", \\\"{x:1192,y:833,t:1527009284444};\\\", \\\"{x:1193,y:833,t:1527009284663};\\\", \\\"{x:1194,y:833,t:1527009284679};\\\", \\\"{x:1195,y:833,t:1527009284832};\\\", \\\"{x:1196,y:833,t:1527009284843};\\\", \\\"{x:1202,y:833,t:1527009284860};\\\", \\\"{x:1206,y:832,t:1527009284876};\\\", \\\"{x:1209,y:832,t:1527009284894};\\\", \\\"{x:1210,y:832,t:1527009284910};\\\", \\\"{x:1212,y:832,t:1527009284927};\\\", \\\"{x:1213,y:831,t:1527009284982};\\\", \\\"{x:1213,y:830,t:1527009287335};\\\", \\\"{x:1214,y:829,t:1527009287383};\\\", \\\"{x:1215,y:828,t:1527009287407};\\\", \\\"{x:1216,y:828,t:1527009287423};\\\", \\\"{x:1216,y:827,t:1527009287440};\\\", \\\"{x:1217,y:827,t:1527009287447};\\\", \\\"{x:1218,y:826,t:1527009287487};\\\", \\\"{x:1220,y:826,t:1527009287511};\\\", \\\"{x:1221,y:825,t:1527009287535};\\\", \\\"{x:1222,y:824,t:1527009287574};\\\", \\\"{x:1223,y:823,t:1527009287623};\\\", \\\"{x:1224,y:823,t:1527009287631};\\\", \\\"{x:1225,y:823,t:1527009287680};\\\", \\\"{x:1227,y:823,t:1527009287856};\\\", \\\"{x:1228,y:823,t:1527009287904};\\\", \\\"{x:1229,y:823,t:1527009288104};\\\", \\\"{x:1229,y:824,t:1527009288113};\\\", \\\"{x:1231,y:828,t:1527009288131};\\\", \\\"{x:1234,y:835,t:1527009288146};\\\", \\\"{x:1239,y:846,t:1527009288163};\\\", \\\"{x:1246,y:857,t:1527009288180};\\\", \\\"{x:1255,y:863,t:1527009288197};\\\", \\\"{x:1263,y:871,t:1527009288213};\\\", \\\"{x:1267,y:874,t:1527009288230};\\\", \\\"{x:1269,y:877,t:1527009288246};\\\", \\\"{x:1269,y:878,t:1527009288312};\\\", \\\"{x:1269,y:880,t:1527009288319};\\\", \\\"{x:1268,y:881,t:1527009288342};\\\", \\\"{x:1267,y:882,t:1527009288374};\\\", \\\"{x:1267,y:881,t:1527009288632};\\\", \\\"{x:1267,y:880,t:1527009288647};\\\", \\\"{x:1267,y:878,t:1527009288664};\\\", \\\"{x:1267,y:877,t:1527009288681};\\\", \\\"{x:1265,y:874,t:1527009288697};\\\", \\\"{x:1264,y:872,t:1527009288714};\\\", \\\"{x:1263,y:871,t:1527009288730};\\\", \\\"{x:1262,y:870,t:1527009288747};\\\", \\\"{x:1261,y:869,t:1527009288764};\\\", \\\"{x:1258,y:869,t:1527009288791};\\\", \\\"{x:1258,y:868,t:1527009288807};\\\", \\\"{x:1257,y:868,t:1527009288815};\\\", \\\"{x:1256,y:868,t:1527009288830};\\\", \\\"{x:1252,y:868,t:1527009288847};\\\", \\\"{x:1250,y:868,t:1527009288864};\\\", \\\"{x:1249,y:868,t:1527009288935};\\\", \\\"{x:1247,y:868,t:1527009289055};\\\", \\\"{x:1244,y:866,t:1527009289065};\\\", \\\"{x:1242,y:863,t:1527009289080};\\\", \\\"{x:1238,y:860,t:1527009289098};\\\", \\\"{x:1236,y:858,t:1527009289114};\\\", \\\"{x:1235,y:857,t:1527009289131};\\\", \\\"{x:1233,y:855,t:1527009289147};\\\", \\\"{x:1232,y:854,t:1527009289167};\\\", \\\"{x:1231,y:851,t:1527009289181};\\\", \\\"{x:1230,y:851,t:1527009289199};\\\", \\\"{x:1229,y:850,t:1527009289215};\\\", \\\"{x:1228,y:848,t:1527009289256};\\\", \\\"{x:1228,y:847,t:1527009289272};\\\", \\\"{x:1228,y:845,t:1527009289327};\\\", \\\"{x:1228,y:844,t:1527009289432};\\\", \\\"{x:1228,y:842,t:1527009289447};\\\", \\\"{x:1228,y:841,t:1527009289464};\\\", \\\"{x:1229,y:840,t:1527009289487};\\\", \\\"{x:1230,y:840,t:1527009289560};\\\", \\\"{x:1231,y:840,t:1527009289575};\\\", \\\"{x:1232,y:840,t:1527009289583};\\\", \\\"{x:1234,y:840,t:1527009289598};\\\", \\\"{x:1238,y:840,t:1527009289614};\\\", \\\"{x:1242,y:840,t:1527009289631};\\\", \\\"{x:1243,y:840,t:1527009289648};\\\", \\\"{x:1245,y:840,t:1527009289663};\\\", \\\"{x:1246,y:840,t:1527009289681};\\\", \\\"{x:1248,y:842,t:1527009289698};\\\", \\\"{x:1249,y:844,t:1527009289726};\\\", \\\"{x:1251,y:845,t:1527009289742};\\\", \\\"{x:1252,y:847,t:1527009289750};\\\", \\\"{x:1253,y:848,t:1527009289763};\\\", \\\"{x:1254,y:849,t:1527009289781};\\\", \\\"{x:1255,y:851,t:1527009289798};\\\", \\\"{x:1255,y:852,t:1527009289847};\\\", \\\"{x:1253,y:852,t:1527009289944};\\\", \\\"{x:1247,y:851,t:1527009289951};\\\", \\\"{x:1244,y:849,t:1527009289963};\\\", \\\"{x:1233,y:844,t:1527009289981};\\\", \\\"{x:1228,y:840,t:1527009289998};\\\", \\\"{x:1223,y:836,t:1527009290014};\\\", \\\"{x:1222,y:836,t:1527009291175};\\\", \\\"{x:1222,y:835,t:1527009291232};\\\", \\\"{x:1224,y:835,t:1527009291352};\\\", \\\"{x:1225,y:835,t:1527009291383};\\\", \\\"{x:1227,y:835,t:1527009291407};\\\", \\\"{x:1229,y:835,t:1527009291423};\\\", \\\"{x:1232,y:835,t:1527009291432};\\\", \\\"{x:1232,y:834,t:1527009291449};\\\", \\\"{x:1237,y:833,t:1527009291466};\\\", \\\"{x:1247,y:833,t:1527009291481};\\\", \\\"{x:1258,y:832,t:1527009291499};\\\", \\\"{x:1271,y:832,t:1527009291516};\\\", \\\"{x:1278,y:833,t:1527009291532};\\\", \\\"{x:1286,y:835,t:1527009291548};\\\", \\\"{x:1293,y:836,t:1527009291566};\\\", \\\"{x:1294,y:838,t:1527009291582};\\\", \\\"{x:1298,y:840,t:1527009291598};\\\", \\\"{x:1299,y:840,t:1527009291615};\\\", \\\"{x:1300,y:841,t:1527009291679};\\\", \\\"{x:1301,y:841,t:1527009291687};\\\", \\\"{x:1302,y:843,t:1527009291702};\\\", \\\"{x:1303,y:843,t:1527009291716};\\\", \\\"{x:1309,y:848,t:1527009291732};\\\", \\\"{x:1314,y:850,t:1527009291749};\\\", \\\"{x:1329,y:854,t:1527009291766};\\\", \\\"{x:1337,y:859,t:1527009291782};\\\", \\\"{x:1341,y:861,t:1527009291799};\\\", \\\"{x:1342,y:861,t:1527009291824};\\\", \\\"{x:1344,y:862,t:1527009291864};\\\", \\\"{x:1346,y:862,t:1527009291879};\\\", \\\"{x:1348,y:863,t:1527009291888};\\\", \\\"{x:1350,y:864,t:1527009291899};\\\", \\\"{x:1354,y:866,t:1527009291917};\\\", \\\"{x:1360,y:869,t:1527009291934};\\\", \\\"{x:1368,y:874,t:1527009291950};\\\", \\\"{x:1378,y:878,t:1527009291967};\\\", \\\"{x:1388,y:883,t:1527009291984};\\\", \\\"{x:1392,y:886,t:1527009291999};\\\", \\\"{x:1393,y:888,t:1527009292017};\\\", \\\"{x:1396,y:891,t:1527009292033};\\\", \\\"{x:1399,y:893,t:1527009292049};\\\", \\\"{x:1402,y:895,t:1527009292065};\\\", \\\"{x:1403,y:897,t:1527009292082};\\\", \\\"{x:1403,y:898,t:1527009292103};\\\", \\\"{x:1403,y:899,t:1527009292126};\\\", \\\"{x:1403,y:900,t:1527009292158};\\\", \\\"{x:1403,y:901,t:1527009292166};\\\", \\\"{x:1403,y:902,t:1527009292191};\\\", \\\"{x:1402,y:903,t:1527009292199};\\\", \\\"{x:1400,y:903,t:1527009292216};\\\", \\\"{x:1397,y:904,t:1527009292233};\\\", \\\"{x:1396,y:905,t:1527009292249};\\\", \\\"{x:1395,y:906,t:1527009292266};\\\", \\\"{x:1394,y:906,t:1527009292283};\\\", \\\"{x:1393,y:906,t:1527009292310};\\\", \\\"{x:1392,y:906,t:1527009292327};\\\", \\\"{x:1390,y:906,t:1527009292335};\\\", \\\"{x:1388,y:906,t:1527009292351};\\\", \\\"{x:1386,y:906,t:1527009292366};\\\", \\\"{x:1381,y:906,t:1527009292384};\\\", \\\"{x:1378,y:905,t:1527009292400};\\\", \\\"{x:1374,y:904,t:1527009292416};\\\", \\\"{x:1372,y:904,t:1527009292433};\\\", \\\"{x:1370,y:902,t:1527009292450};\\\", \\\"{x:1367,y:900,t:1527009292466};\\\", \\\"{x:1362,y:898,t:1527009292483};\\\", \\\"{x:1354,y:895,t:1527009292500};\\\", \\\"{x:1345,y:894,t:1527009292517};\\\", \\\"{x:1332,y:891,t:1527009292534};\\\", \\\"{x:1329,y:889,t:1527009292550};\\\", \\\"{x:1324,y:888,t:1527009292567};\\\", \\\"{x:1324,y:890,t:1527009292671};\\\", \\\"{x:1327,y:896,t:1527009292683};\\\", \\\"{x:1336,y:911,t:1527009292700};\\\", \\\"{x:1340,y:925,t:1527009292717};\\\", \\\"{x:1343,y:947,t:1527009292734};\\\", \\\"{x:1343,y:966,t:1527009292750};\\\", \\\"{x:1343,y:996,t:1527009292767};\\\", \\\"{x:1346,y:1011,t:1527009292783};\\\", \\\"{x:1352,y:1023,t:1527009292800};\\\", \\\"{x:1353,y:1035,t:1527009292817};\\\", \\\"{x:1357,y:1043,t:1527009292833};\\\", \\\"{x:1358,y:1046,t:1527009292850};\\\", \\\"{x:1358,y:1047,t:1527009292868};\\\", \\\"{x:1358,y:1043,t:1527009292944};\\\", \\\"{x:1356,y:1036,t:1527009292951};\\\", \\\"{x:1353,y:1023,t:1527009292968};\\\", \\\"{x:1348,y:1008,t:1527009292983};\\\", \\\"{x:1345,y:997,t:1527009293001};\\\", \\\"{x:1343,y:988,t:1527009293018};\\\", \\\"{x:1340,y:980,t:1527009293034};\\\", \\\"{x:1339,y:972,t:1527009293050};\\\", \\\"{x:1339,y:963,t:1527009293068};\\\", \\\"{x:1339,y:957,t:1527009293084};\\\", \\\"{x:1338,y:953,t:1527009293100};\\\", \\\"{x:1338,y:950,t:1527009293117};\\\", \\\"{x:1338,y:947,t:1527009293133};\\\", \\\"{x:1338,y:941,t:1527009293151};\\\", \\\"{x:1338,y:937,t:1527009293167};\\\", \\\"{x:1338,y:935,t:1527009293185};\\\", \\\"{x:1338,y:933,t:1527009293201};\\\", \\\"{x:1339,y:931,t:1527009293223};\\\", \\\"{x:1341,y:926,t:1527009293235};\\\", \\\"{x:1341,y:921,t:1527009293250};\\\", \\\"{x:1342,y:916,t:1527009293267};\\\", \\\"{x:1344,y:911,t:1527009293284};\\\", \\\"{x:1344,y:908,t:1527009293300};\\\", \\\"{x:1345,y:904,t:1527009293317};\\\", \\\"{x:1345,y:902,t:1527009293334};\\\", \\\"{x:1346,y:899,t:1527009293350};\\\", \\\"{x:1346,y:895,t:1527009293367};\\\", \\\"{x:1346,y:891,t:1527009293384};\\\", \\\"{x:1346,y:889,t:1527009293400};\\\", \\\"{x:1347,y:884,t:1527009293417};\\\", \\\"{x:1347,y:883,t:1527009293434};\\\", \\\"{x:1347,y:881,t:1527009293450};\\\", \\\"{x:1348,y:878,t:1527009293467};\\\", \\\"{x:1348,y:875,t:1527009293484};\\\", \\\"{x:1348,y:873,t:1527009293500};\\\", \\\"{x:1348,y:870,t:1527009293517};\\\", \\\"{x:1348,y:867,t:1527009293534};\\\", \\\"{x:1348,y:864,t:1527009293551};\\\", \\\"{x:1348,y:863,t:1527009293566};\\\", \\\"{x:1348,y:860,t:1527009293584};\\\", \\\"{x:1348,y:856,t:1527009293601};\\\", \\\"{x:1348,y:854,t:1527009293617};\\\", \\\"{x:1348,y:852,t:1527009293634};\\\", \\\"{x:1348,y:850,t:1527009293651};\\\", \\\"{x:1347,y:847,t:1527009293667};\\\", \\\"{x:1347,y:844,t:1527009293684};\\\", \\\"{x:1346,y:840,t:1527009293701};\\\", \\\"{x:1344,y:838,t:1527009293718};\\\", \\\"{x:1344,y:834,t:1527009293734};\\\", \\\"{x:1343,y:827,t:1527009293751};\\\", \\\"{x:1341,y:822,t:1527009293767};\\\", \\\"{x:1341,y:818,t:1527009293784};\\\", \\\"{x:1341,y:814,t:1527009293801};\\\", \\\"{x:1341,y:809,t:1527009293817};\\\", \\\"{x:1341,y:804,t:1527009293834};\\\", \\\"{x:1340,y:798,t:1527009293851};\\\", \\\"{x:1340,y:794,t:1527009293867};\\\", \\\"{x:1339,y:790,t:1527009293884};\\\", \\\"{x:1338,y:785,t:1527009293901};\\\", \\\"{x:1338,y:781,t:1527009293918};\\\", \\\"{x:1337,y:776,t:1527009293935};\\\", \\\"{x:1335,y:769,t:1527009293951};\\\", \\\"{x:1334,y:763,t:1527009293968};\\\", \\\"{x:1334,y:758,t:1527009293985};\\\", \\\"{x:1333,y:751,t:1527009294002};\\\", \\\"{x:1329,y:744,t:1527009294019};\\\", \\\"{x:1329,y:735,t:1527009294034};\\\", \\\"{x:1329,y:723,t:1527009294051};\\\", \\\"{x:1327,y:708,t:1527009294069};\\\", \\\"{x:1327,y:694,t:1527009294085};\\\", \\\"{x:1327,y:677,t:1527009294101};\\\", \\\"{x:1327,y:662,t:1527009294118};\\\", \\\"{x:1325,y:646,t:1527009294134};\\\", \\\"{x:1324,y:622,t:1527009294151};\\\", \\\"{x:1324,y:608,t:1527009294168};\\\", \\\"{x:1324,y:597,t:1527009294184};\\\", \\\"{x:1324,y:586,t:1527009294202};\\\", \\\"{x:1324,y:578,t:1527009294218};\\\", \\\"{x:1324,y:571,t:1527009294235};\\\", \\\"{x:1324,y:564,t:1527009294251};\\\", \\\"{x:1324,y:558,t:1527009294268};\\\", \\\"{x:1324,y:552,t:1527009294285};\\\", \\\"{x:1324,y:546,t:1527009294302};\\\", \\\"{x:1324,y:542,t:1527009294318};\\\", \\\"{x:1325,y:538,t:1527009294335};\\\", \\\"{x:1325,y:533,t:1527009294351};\\\", \\\"{x:1325,y:530,t:1527009294368};\\\", \\\"{x:1325,y:528,t:1527009294384};\\\", \\\"{x:1325,y:525,t:1527009294401};\\\", \\\"{x:1325,y:524,t:1527009294418};\\\", \\\"{x:1325,y:522,t:1527009294435};\\\", \\\"{x:1325,y:521,t:1527009294452};\\\", \\\"{x:1325,y:519,t:1527009294469};\\\", \\\"{x:1325,y:517,t:1527009294487};\\\", \\\"{x:1325,y:516,t:1527009294501};\\\", \\\"{x:1325,y:515,t:1527009294519};\\\", \\\"{x:1325,y:514,t:1527009294535};\\\", \\\"{x:1327,y:511,t:1527009294551};\\\", \\\"{x:1327,y:510,t:1527009294599};\\\", \\\"{x:1327,y:509,t:1527009294615};\\\", \\\"{x:1327,y:508,t:1527009294639};\\\", \\\"{x:1327,y:507,t:1527009294654};\\\", \\\"{x:1327,y:506,t:1527009294686};\\\", \\\"{x:1326,y:506,t:1527009294895};\\\", \\\"{x:1326,y:507,t:1527009294903};\\\", \\\"{x:1324,y:508,t:1527009294936};\\\", \\\"{x:1323,y:509,t:1527009294952};\\\", \\\"{x:1322,y:510,t:1527009295047};\\\", \\\"{x:1321,y:510,t:1527009295055};\\\", \\\"{x:1320,y:512,t:1527009295102};\\\", \\\"{x:1319,y:512,t:1527009295142};\\\", \\\"{x:1319,y:513,t:1527009295975};\\\", \\\"{x:1315,y:519,t:1527009295986};\\\", \\\"{x:1311,y:544,t:1527009296002};\\\", \\\"{x:1303,y:584,t:1527009296019};\\\", \\\"{x:1298,y:630,t:1527009296037};\\\", \\\"{x:1298,y:684,t:1527009296053};\\\", \\\"{x:1306,y:729,t:1527009296069};\\\", \\\"{x:1310,y:815,t:1527009296087};\\\", \\\"{x:1310,y:848,t:1527009296103};\\\", \\\"{x:1310,y:956,t:1527009296119};\\\", \\\"{x:1310,y:1034,t:1527009296136};\\\", \\\"{x:1308,y:1059,t:1527009296152};\\\", \\\"{x:1310,y:1077,t:1527009296170};\\\", \\\"{x:1313,y:1084,t:1527009296187};\\\", \\\"{x:1317,y:1091,t:1527009296202};\\\", \\\"{x:1321,y:1095,t:1527009296219};\\\", \\\"{x:1321,y:1096,t:1527009296237};\\\", \\\"{x:1324,y:1096,t:1527009296287};\\\", \\\"{x:1327,y:1096,t:1527009296318};\\\", \\\"{x:1330,y:1094,t:1527009296326};\\\", \\\"{x:1333,y:1091,t:1527009296336};\\\", \\\"{x:1342,y:1078,t:1527009296353};\\\", \\\"{x:1349,y:1070,t:1527009296368};\\\", \\\"{x:1354,y:1056,t:1527009296386};\\\", \\\"{x:1358,y:1042,t:1527009296403};\\\", \\\"{x:1360,y:1024,t:1527009296419};\\\", \\\"{x:1362,y:1004,t:1527009296436};\\\", \\\"{x:1362,y:992,t:1527009296452};\\\", \\\"{x:1362,y:974,t:1527009296469};\\\", \\\"{x:1362,y:947,t:1527009296486};\\\", \\\"{x:1362,y:932,t:1527009296502};\\\", \\\"{x:1362,y:918,t:1527009296519};\\\", \\\"{x:1362,y:908,t:1527009296536};\\\", \\\"{x:1362,y:904,t:1527009296553};\\\", \\\"{x:1362,y:896,t:1527009296569};\\\", \\\"{x:1362,y:888,t:1527009296587};\\\", \\\"{x:1362,y:881,t:1527009296603};\\\", \\\"{x:1362,y:870,t:1527009296620};\\\", \\\"{x:1362,y:862,t:1527009296636};\\\", \\\"{x:1362,y:852,t:1527009296653};\\\", \\\"{x:1362,y:843,t:1527009296670};\\\", \\\"{x:1362,y:842,t:1527009296687};\\\", \\\"{x:1363,y:840,t:1527009296702};\\\", \\\"{x:1363,y:839,t:1527009296720};\\\", \\\"{x:1363,y:835,t:1527009296736};\\\", \\\"{x:1362,y:828,t:1527009296753};\\\", \\\"{x:1362,y:820,t:1527009296770};\\\", \\\"{x:1361,y:814,t:1527009296787};\\\", \\\"{x:1360,y:808,t:1527009296804};\\\", \\\"{x:1358,y:802,t:1527009296820};\\\", \\\"{x:1358,y:796,t:1527009296837};\\\", \\\"{x:1357,y:790,t:1527009296853};\\\", \\\"{x:1357,y:784,t:1527009296870};\\\", \\\"{x:1357,y:779,t:1527009296886};\\\", \\\"{x:1356,y:768,t:1527009296903};\\\", \\\"{x:1355,y:763,t:1527009296920};\\\", \\\"{x:1355,y:762,t:1527009296936};\\\", \\\"{x:1354,y:760,t:1527009296953};\\\", \\\"{x:1354,y:758,t:1527009296970};\\\", \\\"{x:1353,y:757,t:1527009296986};\\\", \\\"{x:1353,y:753,t:1527009297003};\\\", \\\"{x:1351,y:750,t:1527009297020};\\\", \\\"{x:1350,y:747,t:1527009297037};\\\", \\\"{x:1350,y:744,t:1527009297053};\\\", \\\"{x:1348,y:741,t:1527009297070};\\\", \\\"{x:1345,y:736,t:1527009297087};\\\", \\\"{x:1342,y:728,t:1527009297103};\\\", \\\"{x:1340,y:717,t:1527009297120};\\\", \\\"{x:1340,y:708,t:1527009297137};\\\", \\\"{x:1338,y:699,t:1527009297153};\\\", \\\"{x:1337,y:687,t:1527009297171};\\\", \\\"{x:1334,y:675,t:1527009297188};\\\", \\\"{x:1332,y:662,t:1527009297203};\\\", \\\"{x:1331,y:652,t:1527009297220};\\\", \\\"{x:1331,y:643,t:1527009297237};\\\", \\\"{x:1327,y:633,t:1527009297254};\\\", \\\"{x:1327,y:623,t:1527009297271};\\\", \\\"{x:1326,y:619,t:1527009297287};\\\", \\\"{x:1326,y:615,t:1527009297303};\\\", \\\"{x:1326,y:613,t:1527009297320};\\\", \\\"{x:1326,y:610,t:1527009297338};\\\", \\\"{x:1326,y:609,t:1527009297353};\\\", \\\"{x:1326,y:608,t:1527009297370};\\\", \\\"{x:1326,y:605,t:1527009297387};\\\", \\\"{x:1326,y:603,t:1527009297404};\\\", \\\"{x:1326,y:600,t:1527009297420};\\\", \\\"{x:1326,y:596,t:1527009297437};\\\", \\\"{x:1326,y:592,t:1527009297453};\\\", \\\"{x:1326,y:586,t:1527009297471};\\\", \\\"{x:1326,y:580,t:1527009297487};\\\", \\\"{x:1324,y:572,t:1527009297503};\\\", \\\"{x:1324,y:568,t:1527009297521};\\\", \\\"{x:1324,y:562,t:1527009297537};\\\", \\\"{x:1323,y:558,t:1527009297553};\\\", \\\"{x:1323,y:553,t:1527009297571};\\\", \\\"{x:1323,y:549,t:1527009297587};\\\", \\\"{x:1323,y:543,t:1527009297604};\\\", \\\"{x:1323,y:538,t:1527009297621};\\\", \\\"{x:1323,y:531,t:1527009297638};\\\", \\\"{x:1323,y:526,t:1527009297655};\\\", \\\"{x:1323,y:520,t:1527009297670};\\\", \\\"{x:1323,y:513,t:1527009297687};\\\", \\\"{x:1323,y:506,t:1527009297704};\\\", \\\"{x:1323,y:500,t:1527009297721};\\\", \\\"{x:1323,y:493,t:1527009297738};\\\", \\\"{x:1323,y:489,t:1527009297754};\\\", \\\"{x:1323,y:484,t:1527009297771};\\\", \\\"{x:1323,y:478,t:1527009297788};\\\", \\\"{x:1323,y:473,t:1527009297805};\\\", \\\"{x:1323,y:468,t:1527009297821};\\\", \\\"{x:1323,y:461,t:1527009297838};\\\", \\\"{x:1323,y:455,t:1527009297854};\\\", \\\"{x:1325,y:447,t:1527009297870};\\\", \\\"{x:1325,y:442,t:1527009297888};\\\", \\\"{x:1326,y:438,t:1527009297905};\\\", \\\"{x:1327,y:432,t:1527009297921};\\\", \\\"{x:1328,y:427,t:1527009297937};\\\", \\\"{x:1329,y:423,t:1527009297954};\\\", \\\"{x:1329,y:421,t:1527009297971};\\\", \\\"{x:1329,y:420,t:1527009297987};\\\", \\\"{x:1329,y:418,t:1527009298004};\\\", \\\"{x:1328,y:418,t:1527009298167};\\\", \\\"{x:1327,y:418,t:1527009298175};\\\", \\\"{x:1326,y:418,t:1527009298188};\\\", \\\"{x:1324,y:421,t:1527009298204};\\\", \\\"{x:1323,y:424,t:1527009298222};\\\", \\\"{x:1322,y:427,t:1527009298238};\\\", \\\"{x:1320,y:431,t:1527009298255};\\\", \\\"{x:1318,y:432,t:1527009298271};\\\", \\\"{x:1316,y:435,t:1527009298288};\\\", \\\"{x:1315,y:436,t:1527009298311};\\\", \\\"{x:1315,y:437,t:1527009298322};\\\", \\\"{x:1315,y:440,t:1527009298337};\\\", \\\"{x:1314,y:442,t:1527009298355};\\\", \\\"{x:1314,y:444,t:1527009298371};\\\", \\\"{x:1314,y:448,t:1527009298389};\\\", \\\"{x:1314,y:450,t:1527009298404};\\\", \\\"{x:1314,y:454,t:1527009298422};\\\", \\\"{x:1315,y:457,t:1527009298438};\\\", \\\"{x:1315,y:461,t:1527009298455};\\\", \\\"{x:1315,y:469,t:1527009298471};\\\", \\\"{x:1314,y:479,t:1527009298488};\\\", \\\"{x:1314,y:493,t:1527009298505};\\\", \\\"{x:1313,y:507,t:1527009298523};\\\", \\\"{x:1311,y:517,t:1527009298538};\\\", \\\"{x:1310,y:530,t:1527009298554};\\\", \\\"{x:1309,y:544,t:1527009298571};\\\", \\\"{x:1303,y:562,t:1527009298588};\\\", \\\"{x:1298,y:581,t:1527009298604};\\\", \\\"{x:1291,y:601,t:1527009298621};\\\", \\\"{x:1279,y:621,t:1527009298639};\\\", \\\"{x:1275,y:630,t:1527009298654};\\\", \\\"{x:1272,y:635,t:1527009298671};\\\", \\\"{x:1272,y:639,t:1527009298688};\\\", \\\"{x:1271,y:641,t:1527009298704};\\\", \\\"{x:1270,y:642,t:1527009298721};\\\", \\\"{x:1268,y:643,t:1527009298775};\\\", \\\"{x:1267,y:644,t:1527009298788};\\\", \\\"{x:1266,y:644,t:1527009298807};\\\", \\\"{x:1265,y:644,t:1527009298830};\\\", \\\"{x:1264,y:644,t:1527009298839};\\\", \\\"{x:1260,y:644,t:1527009298854};\\\", \\\"{x:1255,y:644,t:1527009298872};\\\", \\\"{x:1245,y:644,t:1527009298888};\\\", \\\"{x:1217,y:644,t:1527009298904};\\\", \\\"{x:1152,y:644,t:1527009298921};\\\", \\\"{x:1060,y:644,t:1527009298938};\\\", \\\"{x:938,y:644,t:1527009298955};\\\", \\\"{x:837,y:637,t:1527009298971};\\\", \\\"{x:728,y:638,t:1527009298988};\\\", \\\"{x:609,y:637,t:1527009299006};\\\", \\\"{x:476,y:637,t:1527009299022};\\\", \\\"{x:253,y:650,t:1527009299039};\\\", \\\"{x:177,y:648,t:1527009299056};\\\", \\\"{x:155,y:648,t:1527009299073};\\\", \\\"{x:154,y:648,t:1527009299089};\\\", \\\"{x:153,y:648,t:1527009299207};\\\", \\\"{x:155,y:644,t:1527009299223};\\\", \\\"{x:161,y:639,t:1527009299239};\\\", \\\"{x:172,y:629,t:1527009299256};\\\", \\\"{x:190,y:618,t:1527009299274};\\\", \\\"{x:207,y:607,t:1527009299291};\\\", \\\"{x:226,y:594,t:1527009299307};\\\", \\\"{x:242,y:587,t:1527009299324};\\\", \\\"{x:254,y:581,t:1527009299341};\\\", \\\"{x:260,y:577,t:1527009299357};\\\", \\\"{x:267,y:574,t:1527009299374};\\\", \\\"{x:269,y:573,t:1527009299390};\\\", \\\"{x:275,y:570,t:1527009299407};\\\", \\\"{x:279,y:568,t:1527009299424};\\\", \\\"{x:285,y:567,t:1527009299440};\\\", \\\"{x:287,y:566,t:1527009299457};\\\", \\\"{x:289,y:565,t:1527009299474};\\\", \\\"{x:290,y:565,t:1527009299490};\\\", \\\"{x:291,y:565,t:1527009299526};\\\", \\\"{x:292,y:564,t:1527009299550};\\\", \\\"{x:294,y:563,t:1527009299558};\\\", \\\"{x:298,y:563,t:1527009299574};\\\", \\\"{x:308,y:563,t:1527009299590};\\\", \\\"{x:322,y:564,t:1527009299607};\\\", \\\"{x:336,y:567,t:1527009299624};\\\", \\\"{x:353,y:569,t:1527009299641};\\\", \\\"{x:377,y:575,t:1527009299657};\\\", \\\"{x:397,y:576,t:1527009299674};\\\", \\\"{x:417,y:581,t:1527009299691};\\\", \\\"{x:426,y:583,t:1527009299707};\\\", \\\"{x:432,y:584,t:1527009299724};\\\", \\\"{x:444,y:585,t:1527009299741};\\\", \\\"{x:448,y:585,t:1527009299757};\\\", \\\"{x:449,y:584,t:1527009299782};\\\", \\\"{x:450,y:580,t:1527009299823};\\\", \\\"{x:450,y:574,t:1527009299842};\\\", \\\"{x:448,y:571,t:1527009299857};\\\", \\\"{x:448,y:570,t:1527009299875};\\\", \\\"{x:448,y:563,t:1527009299891};\\\", \\\"{x:448,y:561,t:1527009299907};\\\", \\\"{x:450,y:553,t:1527009299925};\\\", \\\"{x:459,y:545,t:1527009299941};\\\", \\\"{x:468,y:533,t:1527009299959};\\\", \\\"{x:474,y:529,t:1527009299974};\\\", \\\"{x:475,y:528,t:1527009300007};\\\", \\\"{x:472,y:525,t:1527009300015};\\\", \\\"{x:456,y:520,t:1527009300024};\\\", \\\"{x:379,y:511,t:1527009300041};\\\", \\\"{x:329,y:506,t:1527009300059};\\\", \\\"{x:284,y:505,t:1527009300075};\\\", \\\"{x:261,y:503,t:1527009300091};\\\", \\\"{x:247,y:503,t:1527009300107};\\\", \\\"{x:243,y:503,t:1527009300124};\\\", \\\"{x:240,y:504,t:1527009300141};\\\", \\\"{x:239,y:505,t:1527009300158};\\\", \\\"{x:238,y:505,t:1527009300174};\\\", \\\"{x:236,y:506,t:1527009300207};\\\", \\\"{x:235,y:508,t:1527009300224};\\\", \\\"{x:233,y:510,t:1527009300241};\\\", \\\"{x:233,y:512,t:1527009300257};\\\", \\\"{x:232,y:514,t:1527009300274};\\\", \\\"{x:231,y:518,t:1527009300291};\\\", \\\"{x:228,y:525,t:1527009300308};\\\", \\\"{x:223,y:536,t:1527009300324};\\\", \\\"{x:220,y:550,t:1527009300342};\\\", \\\"{x:217,y:565,t:1527009300357};\\\", \\\"{x:215,y:576,t:1527009300374};\\\", \\\"{x:215,y:578,t:1527009300391};\\\", \\\"{x:215,y:579,t:1527009300414};\\\", \\\"{x:217,y:578,t:1527009300424};\\\", \\\"{x:228,y:573,t:1527009300441};\\\", \\\"{x:242,y:562,t:1527009300458};\\\", \\\"{x:259,y:555,t:1527009300475};\\\", \\\"{x:282,y:546,t:1527009300492};\\\", \\\"{x:292,y:543,t:1527009300508};\\\", \\\"{x:303,y:541,t:1527009300525};\\\", \\\"{x:311,y:537,t:1527009300541};\\\", \\\"{x:316,y:534,t:1527009300559};\\\", \\\"{x:317,y:534,t:1527009300575};\\\", \\\"{x:318,y:534,t:1527009300686};\\\", \\\"{x:320,y:534,t:1527009300702};\\\", \\\"{x:321,y:533,t:1527009300710};\\\", \\\"{x:324,y:530,t:1527009300725};\\\", \\\"{x:328,y:528,t:1527009300742};\\\", \\\"{x:343,y:521,t:1527009300758};\\\", \\\"{x:356,y:520,t:1527009300775};\\\", \\\"{x:366,y:520,t:1527009300791};\\\", \\\"{x:371,y:520,t:1527009300808};\\\", \\\"{x:373,y:520,t:1527009300825};\\\", \\\"{x:374,y:519,t:1527009300879};\\\", \\\"{x:374,y:518,t:1527009300894};\\\", \\\"{x:376,y:517,t:1527009300910};\\\", \\\"{x:378,y:517,t:1527009301086};\\\", \\\"{x:378,y:517,t:1527009301148};\\\", \\\"{x:383,y:515,t:1527009301190};\\\", \\\"{x:387,y:515,t:1527009301199};\\\", \\\"{x:394,y:515,t:1527009301208};\\\", \\\"{x:461,y:527,t:1527009301225};\\\", \\\"{x:570,y:548,t:1527009301243};\\\", \\\"{x:686,y:562,t:1527009301258};\\\", \\\"{x:777,y:572,t:1527009301275};\\\", \\\"{x:811,y:573,t:1527009301292};\\\", \\\"{x:816,y:573,t:1527009301309};\\\", \\\"{x:818,y:573,t:1527009301325};\\\", \\\"{x:819,y:573,t:1527009301350};\\\", \\\"{x:820,y:572,t:1527009301358};\\\", \\\"{x:824,y:569,t:1527009301375};\\\", \\\"{x:828,y:567,t:1527009301393};\\\", \\\"{x:834,y:562,t:1527009301409};\\\", \\\"{x:838,y:558,t:1527009301425};\\\", \\\"{x:842,y:555,t:1527009301442};\\\", \\\"{x:844,y:551,t:1527009301459};\\\", \\\"{x:846,y:548,t:1527009301475};\\\", \\\"{x:847,y:545,t:1527009301493};\\\", \\\"{x:847,y:542,t:1527009301510};\\\", \\\"{x:847,y:540,t:1527009301583};\\\", \\\"{x:847,y:536,t:1527009301596};\\\", \\\"{x:849,y:527,t:1527009301610};\\\", \\\"{x:850,y:520,t:1527009301625};\\\", \\\"{x:851,y:513,t:1527009301642};\\\", \\\"{x:851,y:510,t:1527009301659};\\\", \\\"{x:851,y:509,t:1527009301676};\\\", \\\"{x:849,y:509,t:1527009302374};\\\", \\\"{x:846,y:509,t:1527009302383};\\\", \\\"{x:838,y:509,t:1527009302394};\\\", \\\"{x:812,y:507,t:1527009302410};\\\", \\\"{x:764,y:496,t:1527009302427};\\\", \\\"{x:698,y:490,t:1527009302443};\\\", \\\"{x:677,y:488,t:1527009302459};\\\", \\\"{x:667,y:485,t:1527009302476};\\\", \\\"{x:666,y:485,t:1527009302493};\\\", \\\"{x:665,y:485,t:1527009302510};\\\", \\\"{x:662,y:485,t:1527009302543};\\\", \\\"{x:662,y:487,t:1527009302566};\\\", \\\"{x:660,y:490,t:1527009302577};\\\", \\\"{x:660,y:491,t:1527009302594};\\\", \\\"{x:660,y:492,t:1527009302609};\\\", \\\"{x:660,y:493,t:1527009302627};\\\", \\\"{x:656,y:496,t:1527009302644};\\\", \\\"{x:652,y:499,t:1527009302659};\\\", \\\"{x:644,y:504,t:1527009302676};\\\", \\\"{x:638,y:509,t:1527009302695};\\\", \\\"{x:623,y:518,t:1527009302711};\\\", \\\"{x:613,y:526,t:1527009302726};\\\", \\\"{x:601,y:531,t:1527009302744};\\\", \\\"{x:595,y:534,t:1527009302761};\\\", \\\"{x:591,y:536,t:1527009302776};\\\", \\\"{x:598,y:532,t:1527009302951};\\\", \\\"{x:604,y:528,t:1527009302962};\\\", \\\"{x:608,y:523,t:1527009302976};\\\", \\\"{x:609,y:522,t:1527009302993};\\\", \\\"{x:610,y:521,t:1527009303010};\\\", \\\"{x:610,y:526,t:1527009303422};\\\", \\\"{x:610,y:535,t:1527009303430};\\\", \\\"{x:610,y:549,t:1527009303444};\\\", \\\"{x:606,y:578,t:1527009303460};\\\", \\\"{x:595,y:610,t:1527009303478};\\\", \\\"{x:579,y:664,t:1527009303495};\\\", \\\"{x:565,y:699,t:1527009303510};\\\", \\\"{x:554,y:730,t:1527009303528};\\\", \\\"{x:549,y:743,t:1527009303544};\\\", \\\"{x:548,y:747,t:1527009303560};\\\", \\\"{x:548,y:748,t:1527009303577};\\\", \\\"{x:548,y:750,t:1527009303606};\\\", \\\"{x:548,y:751,t:1527009303640};\\\", \\\"{x:547,y:752,t:1527009303726};\\\", \\\"{x:545,y:752,t:1527009303734};\\\", \\\"{x:540,y:752,t:1527009303745};\\\", \\\"{x:532,y:752,t:1527009303760};\\\", \\\"{x:527,y:752,t:1527009303777};\\\", \\\"{x:526,y:751,t:1527009303815};\\\", \\\"{x:526,y:750,t:1527009303827};\\\", \\\"{x:526,y:743,t:1527009303844};\\\", \\\"{x:526,y:739,t:1527009303860};\\\", \\\"{x:526,y:731,t:1527009303878};\\\", \\\"{x:526,y:710,t:1527009303894};\\\", \\\"{x:526,y:703,t:1527009303912};\\\", \\\"{x:526,y:700,t:1527009303929};\\\", \\\"{x:535,y:698,t:1527009305183};\\\", \\\"{x:556,y:697,t:1527009305195};\\\", \\\"{x:662,y:697,t:1527009305211};\\\", \\\"{x:814,y:697,t:1527009305228};\\\", \\\"{x:992,y:705,t:1527009305245};\\\", \\\"{x:1169,y:732,t:1527009305261};\\\", \\\"{x:1375,y:757,t:1527009305278};\\\", \\\"{x:1429,y:762,t:1527009305296};\\\", \\\"{x:1442,y:765,t:1527009305312};\\\", \\\"{x:1443,y:765,t:1527009305328};\\\", \\\"{x:1442,y:765,t:1527009305495};\\\", \\\"{x:1434,y:761,t:1527009305513};\\\", \\\"{x:1418,y:756,t:1527009305529};\\\", \\\"{x:1397,y:756,t:1527009305546};\\\", \\\"{x:1367,y:754,t:1527009305563};\\\", \\\"{x:1335,y:754,t:1527009305579};\\\", \\\"{x:1313,y:750,t:1527009305597};\\\", \\\"{x:1302,y:750,t:1527009305614};\\\", \\\"{x:1301,y:750,t:1527009305629};\\\", \\\"{x:1302,y:750,t:1527009305999};\\\", \\\"{x:1301,y:750,t:1527009306167};\\\", \\\"{x:1292,y:750,t:1527009306180};\\\", \\\"{x:1275,y:750,t:1527009306196};\\\", \\\"{x:1243,y:750,t:1527009306213};\\\", \\\"{x:1197,y:750,t:1527009306230};\\\", \\\"{x:1124,y:750,t:1527009306246};\\\", \\\"{x:1008,y:750,t:1527009306263};\\\", \\\"{x:935,y:750,t:1527009306280};\\\", \\\"{x:882,y:750,t:1527009306295};\\\", \\\"{x:862,y:743,t:1527009306313};\\\", \\\"{x:833,y:737,t:1527009306329};\\\", \\\"{x:804,y:731,t:1527009306345};\\\", \\\"{x:781,y:724,t:1527009306362};\\\", \\\"{x:759,y:718,t:1527009306379};\\\", \\\"{x:737,y:712,t:1527009306396};\\\", \\\"{x:720,y:706,t:1527009306412};\\\", \\\"{x:700,y:703,t:1527009306430};\\\", \\\"{x:686,y:703,t:1527009306446};\\\", \\\"{x:666,y:703,t:1527009306462};\\\", \\\"{x:649,y:703,t:1527009306480};\\\", \\\"{x:631,y:704,t:1527009306495};\\\", \\\"{x:613,y:706,t:1527009306513};\\\", \\\"{x:597,y:706,t:1527009306530};\\\", \\\"{x:586,y:708,t:1527009306545};\\\", \\\"{x:571,y:709,t:1527009306562};\\\", \\\"{x:557,y:710,t:1527009306580};\\\", \\\"{x:547,y:713,t:1527009306597};\\\", \\\"{x:543,y:713,t:1527009306613};\\\", \\\"{x:537,y:715,t:1527009306629};\\\", \\\"{x:529,y:715,t:1527009306646};\\\", \\\"{x:528,y:715,t:1527009306663};\\\", \\\"{x:526,y:715,t:1527009306679};\\\", \\\"{x:526,y:716,t:1527009306696};\\\", \\\"{x:525,y:716,t:1527009306902};\\\", \\\"{x:526,y:714,t:1527009306966};\\\", \\\"{x:530,y:714,t:1527009306980};\\\", \\\"{x:552,y:717,t:1527009306996};\\\", \\\"{x:621,y:741,t:1527009307013};\\\", \\\"{x:803,y:791,t:1527009307030};\\\", \\\"{x:971,y:838,t:1527009307046};\\\", \\\"{x:1154,y:891,t:1527009307064};\\\", \\\"{x:1300,y:928,t:1527009307080};\\\", \\\"{x:1420,y:955,t:1527009307096};\\\", \\\"{x:1472,y:966,t:1527009307113};\\\", \\\"{x:1483,y:969,t:1527009307131};\\\", \\\"{x:1484,y:969,t:1527009307146};\\\" ] }, { \\\"rt\\\": 63926, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 528415, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-04 PM-03 PM-01 PM-I -A -F -F -F -Z -H -O -Z -U -U -U -12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1492,y:969,t:1527009310271};\\\", \\\"{x:1495,y:969,t:1527009310283};\\\", \\\"{x:1492,y:971,t:1527009312000};\\\", \\\"{x:1486,y:975,t:1527009312007};\\\", \\\"{x:1482,y:979,t:1527009312017};\\\", \\\"{x:1471,y:989,t:1527009312035};\\\", \\\"{x:1464,y:995,t:1527009312051};\\\", \\\"{x:1463,y:997,t:1527009312068};\\\", \\\"{x:1463,y:998,t:1527009312127};\\\", \\\"{x:1461,y:1001,t:1527009312135};\\\", \\\"{x:1456,y:1005,t:1527009312151};\\\", \\\"{x:1452,y:1009,t:1527009312168};\\\", \\\"{x:1447,y:1013,t:1527009312185};\\\", \\\"{x:1443,y:1018,t:1527009312201};\\\", \\\"{x:1439,y:1025,t:1527009312219};\\\", \\\"{x:1437,y:1032,t:1527009312235};\\\", \\\"{x:1436,y:1034,t:1527009312251};\\\", \\\"{x:1440,y:1035,t:1527009312303};\\\", \\\"{x:1463,y:1030,t:1527009312318};\\\", \\\"{x:1469,y:1025,t:1527009312333};\\\", \\\"{x:1524,y:1004,t:1527009312351};\\\", \\\"{x:1557,y:994,t:1527009312368};\\\", \\\"{x:1578,y:982,t:1527009312384};\\\", \\\"{x:1599,y:975,t:1527009312401};\\\", \\\"{x:1609,y:971,t:1527009312418};\\\", \\\"{x:1612,y:970,t:1527009312434};\\\", \\\"{x:1613,y:964,t:1527009312688};\\\", \\\"{x:1613,y:962,t:1527009312701};\\\", \\\"{x:1613,y:955,t:1527009312718};\\\", \\\"{x:1613,y:951,t:1527009312734};\\\", \\\"{x:1613,y:948,t:1527009312750};\\\", \\\"{x:1613,y:945,t:1527009312767};\\\", \\\"{x:1612,y:943,t:1527009312784};\\\", \\\"{x:1611,y:939,t:1527009312801};\\\", \\\"{x:1611,y:937,t:1527009312818};\\\", \\\"{x:1611,y:934,t:1527009312834};\\\", \\\"{x:1609,y:931,t:1527009312851};\\\", \\\"{x:1609,y:927,t:1527009313296};\\\", \\\"{x:1609,y:920,t:1527009313303};\\\", \\\"{x:1609,y:918,t:1527009313318};\\\", \\\"{x:1609,y:905,t:1527009313336};\\\", \\\"{x:1606,y:891,t:1527009313353};\\\", \\\"{x:1603,y:877,t:1527009313368};\\\", \\\"{x:1599,y:868,t:1527009313385};\\\", \\\"{x:1594,y:859,t:1527009313402};\\\", \\\"{x:1591,y:854,t:1527009313418};\\\", \\\"{x:1590,y:850,t:1527009313435};\\\", \\\"{x:1590,y:845,t:1527009313453};\\\", \\\"{x:1589,y:840,t:1527009313468};\\\", \\\"{x:1588,y:835,t:1527009313485};\\\", \\\"{x:1587,y:828,t:1527009313503};\\\", \\\"{x:1586,y:819,t:1527009313519};\\\", \\\"{x:1586,y:813,t:1527009313536};\\\", \\\"{x:1586,y:809,t:1527009313553};\\\", \\\"{x:1586,y:802,t:1527009313570};\\\", \\\"{x:1586,y:793,t:1527009313586};\\\", \\\"{x:1586,y:784,t:1527009313602};\\\", \\\"{x:1588,y:769,t:1527009313619};\\\", \\\"{x:1591,y:758,t:1527009313636};\\\", \\\"{x:1594,y:749,t:1527009313652};\\\", \\\"{x:1596,y:738,t:1527009313670};\\\", \\\"{x:1599,y:732,t:1527009313686};\\\", \\\"{x:1603,y:723,t:1527009313703};\\\", \\\"{x:1603,y:721,t:1527009313719};\\\", \\\"{x:1606,y:716,t:1527009313736};\\\", \\\"{x:1607,y:712,t:1527009313753};\\\", \\\"{x:1609,y:708,t:1527009313769};\\\", \\\"{x:1611,y:701,t:1527009313785};\\\", \\\"{x:1611,y:696,t:1527009313802};\\\", \\\"{x:1612,y:691,t:1527009313819};\\\", \\\"{x:1612,y:685,t:1527009313835};\\\", \\\"{x:1612,y:677,t:1527009313851};\\\", \\\"{x:1612,y:674,t:1527009313868};\\\", \\\"{x:1612,y:671,t:1527009313885};\\\", \\\"{x:1612,y:667,t:1527009313901};\\\", \\\"{x:1612,y:663,t:1527009313918};\\\", \\\"{x:1610,y:659,t:1527009313935};\\\", \\\"{x:1610,y:654,t:1527009313952};\\\", \\\"{x:1608,y:643,t:1527009313968};\\\", \\\"{x:1606,y:638,t:1527009313985};\\\", \\\"{x:1605,y:630,t:1527009314002};\\\", \\\"{x:1602,y:622,t:1527009314019};\\\", \\\"{x:1601,y:614,t:1527009314036};\\\", \\\"{x:1600,y:606,t:1527009314053};\\\", \\\"{x:1597,y:601,t:1527009314069};\\\", \\\"{x:1596,y:595,t:1527009314086};\\\", \\\"{x:1594,y:586,t:1527009314102};\\\", \\\"{x:1593,y:580,t:1527009314119};\\\", \\\"{x:1592,y:574,t:1527009314136};\\\", \\\"{x:1592,y:569,t:1527009314152};\\\", \\\"{x:1589,y:565,t:1527009314169};\\\", \\\"{x:1589,y:562,t:1527009314186};\\\", \\\"{x:1588,y:559,t:1527009314202};\\\", \\\"{x:1588,y:552,t:1527009314219};\\\", \\\"{x:1588,y:548,t:1527009314236};\\\", \\\"{x:1588,y:545,t:1527009314252};\\\", \\\"{x:1588,y:543,t:1527009314269};\\\", \\\"{x:1588,y:540,t:1527009314286};\\\", \\\"{x:1588,y:537,t:1527009314302};\\\", \\\"{x:1588,y:533,t:1527009314319};\\\", \\\"{x:1588,y:531,t:1527009314336};\\\", \\\"{x:1589,y:529,t:1527009314352};\\\", \\\"{x:1589,y:528,t:1527009314369};\\\", \\\"{x:1589,y:526,t:1527009314386};\\\", \\\"{x:1589,y:524,t:1527009314403};\\\", \\\"{x:1589,y:519,t:1527009314419};\\\", \\\"{x:1589,y:516,t:1527009314437};\\\", \\\"{x:1588,y:512,t:1527009314452};\\\", \\\"{x:1587,y:510,t:1527009314469};\\\", \\\"{x:1587,y:506,t:1527009314486};\\\", \\\"{x:1587,y:502,t:1527009314503};\\\", \\\"{x:1587,y:497,t:1527009314520};\\\", \\\"{x:1587,y:495,t:1527009314537};\\\", \\\"{x:1587,y:493,t:1527009314553};\\\", \\\"{x:1587,y:489,t:1527009314570};\\\", \\\"{x:1587,y:487,t:1527009314587};\\\", \\\"{x:1587,y:483,t:1527009314603};\\\", \\\"{x:1587,y:482,t:1527009314623};\\\", \\\"{x:1587,y:480,t:1527009314636};\\\", \\\"{x:1587,y:479,t:1527009314653};\\\", \\\"{x:1587,y:478,t:1527009314669};\\\", \\\"{x:1587,y:477,t:1527009314686};\\\", \\\"{x:1587,y:486,t:1527009314783};\\\", \\\"{x:1582,y:498,t:1527009314791};\\\", \\\"{x:1578,y:514,t:1527009314803};\\\", \\\"{x:1572,y:559,t:1527009314819};\\\", \\\"{x:1569,y:595,t:1527009314837};\\\", \\\"{x:1565,y:647,t:1527009314854};\\\", \\\"{x:1565,y:697,t:1527009314870};\\\", \\\"{x:1565,y:775,t:1527009314887};\\\", \\\"{x:1565,y:850,t:1527009314903};\\\", \\\"{x:1565,y:900,t:1527009314919};\\\", \\\"{x:1564,y:937,t:1527009314936};\\\", \\\"{x:1562,y:961,t:1527009314953};\\\", \\\"{x:1558,y:978,t:1527009314970};\\\", \\\"{x:1554,y:992,t:1527009314987};\\\", \\\"{x:1549,y:1006,t:1527009315003};\\\", \\\"{x:1549,y:1013,t:1527009315020};\\\", \\\"{x:1549,y:1019,t:1527009315035};\\\", \\\"{x:1549,y:1021,t:1527009315053};\\\", \\\"{x:1549,y:1025,t:1527009315070};\\\", \\\"{x:1549,y:1026,t:1527009315085};\\\", \\\"{x:1549,y:1029,t:1527009315103};\\\", \\\"{x:1549,y:1026,t:1527009315183};\\\", \\\"{x:1550,y:1022,t:1527009315190};\\\", \\\"{x:1555,y:1014,t:1527009315203};\\\", \\\"{x:1567,y:993,t:1527009315220};\\\", \\\"{x:1575,y:976,t:1527009315236};\\\", \\\"{x:1581,y:960,t:1527009315253};\\\", \\\"{x:1584,y:947,t:1527009315270};\\\", \\\"{x:1587,y:937,t:1527009315287};\\\", \\\"{x:1588,y:932,t:1527009315304};\\\", \\\"{x:1590,y:931,t:1527009315321};\\\", \\\"{x:1592,y:931,t:1527009315512};\\\", \\\"{x:1592,y:933,t:1527009315521};\\\", \\\"{x:1595,y:940,t:1527009315538};\\\", \\\"{x:1597,y:942,t:1527009315554};\\\", \\\"{x:1598,y:944,t:1527009315570};\\\", \\\"{x:1598,y:946,t:1527009315587};\\\", \\\"{x:1598,y:947,t:1527009315623};\\\", \\\"{x:1599,y:948,t:1527009315637};\\\", \\\"{x:1600,y:948,t:1527009315663};\\\", \\\"{x:1602,y:950,t:1527009315679};\\\", \\\"{x:1604,y:951,t:1527009315702};\\\", \\\"{x:1605,y:953,t:1527009315720};\\\", \\\"{x:1608,y:955,t:1527009315737};\\\", \\\"{x:1610,y:957,t:1527009315839};\\\", \\\"{x:1613,y:957,t:1527009315854};\\\", \\\"{x:1616,y:959,t:1527009315870};\\\", \\\"{x:1619,y:961,t:1527009315888};\\\", \\\"{x:1619,y:962,t:1527009315904};\\\", \\\"{x:1620,y:962,t:1527009315982};\\\", \\\"{x:1620,y:963,t:1527009315990};\\\", \\\"{x:1620,y:964,t:1527009316006};\\\", \\\"{x:1620,y:966,t:1527009316020};\\\", \\\"{x:1619,y:964,t:1527009317368};\\\", \\\"{x:1618,y:960,t:1527009317376};\\\", \\\"{x:1616,y:955,t:1527009317389};\\\", \\\"{x:1611,y:943,t:1527009317406};\\\", \\\"{x:1606,y:933,t:1527009317422};\\\", \\\"{x:1604,y:928,t:1527009317439};\\\", \\\"{x:1603,y:926,t:1527009317456};\\\", \\\"{x:1601,y:924,t:1527009317472};\\\", \\\"{x:1601,y:923,t:1527009317489};\\\", \\\"{x:1600,y:922,t:1527009317506};\\\", \\\"{x:1600,y:921,t:1527009318856};\\\", \\\"{x:1600,y:920,t:1527009318873};\\\", \\\"{x:1598,y:915,t:1527009318890};\\\", \\\"{x:1598,y:910,t:1527009318907};\\\", \\\"{x:1597,y:907,t:1527009318923};\\\", \\\"{x:1596,y:905,t:1527009318940};\\\", \\\"{x:1595,y:905,t:1527009318956};\\\", \\\"{x:1595,y:903,t:1527009318972};\\\", \\\"{x:1595,y:902,t:1527009318990};\\\", \\\"{x:1595,y:901,t:1527009319007};\\\", \\\"{x:1595,y:900,t:1527009319023};\\\", \\\"{x:1595,y:899,t:1527009319040};\\\", \\\"{x:1595,y:898,t:1527009319056};\\\", \\\"{x:1595,y:896,t:1527009319072};\\\", \\\"{x:1595,y:895,t:1527009319089};\\\", \\\"{x:1595,y:893,t:1527009319106};\\\", \\\"{x:1596,y:891,t:1527009319122};\\\", \\\"{x:1596,y:890,t:1527009319142};\\\", \\\"{x:1596,y:888,t:1527009319158};\\\", \\\"{x:1597,y:887,t:1527009319190};\\\", \\\"{x:1598,y:885,t:1527009319206};\\\", \\\"{x:1598,y:883,t:1527009319238};\\\", \\\"{x:1599,y:883,t:1527009319246};\\\", \\\"{x:1599,y:882,t:1527009319256};\\\", \\\"{x:1599,y:881,t:1527009319704};\\\", \\\"{x:1599,y:879,t:1527009319712};\\\", \\\"{x:1599,y:876,t:1527009319723};\\\", \\\"{x:1590,y:864,t:1527009319740};\\\", \\\"{x:1586,y:859,t:1527009319756};\\\", \\\"{x:1585,y:858,t:1527009319773};\\\", \\\"{x:1583,y:855,t:1527009319790};\\\", \\\"{x:1581,y:853,t:1527009319806};\\\", \\\"{x:1579,y:852,t:1527009319824};\\\", \\\"{x:1578,y:850,t:1527009319840};\\\", \\\"{x:1576,y:848,t:1527009319856};\\\", \\\"{x:1575,y:843,t:1527009319874};\\\", \\\"{x:1566,y:835,t:1527009319890};\\\", \\\"{x:1559,y:829,t:1527009319907};\\\", \\\"{x:1557,y:827,t:1527009319923};\\\", \\\"{x:1552,y:821,t:1527009319941};\\\", \\\"{x:1544,y:816,t:1527009319957};\\\", \\\"{x:1536,y:808,t:1527009319974};\\\", \\\"{x:1522,y:796,t:1527009319990};\\\", \\\"{x:1511,y:787,t:1527009320006};\\\", \\\"{x:1503,y:781,t:1527009320024};\\\", \\\"{x:1496,y:773,t:1527009320040};\\\", \\\"{x:1479,y:759,t:1527009320057};\\\", \\\"{x:1468,y:744,t:1527009320073};\\\", \\\"{x:1446,y:728,t:1527009320090};\\\", \\\"{x:1426,y:711,t:1527009320106};\\\", \\\"{x:1415,y:698,t:1527009320123};\\\", \\\"{x:1404,y:676,t:1527009320140};\\\", \\\"{x:1389,y:655,t:1527009320157};\\\", \\\"{x:1378,y:630,t:1527009320173};\\\", \\\"{x:1360,y:597,t:1527009320191};\\\", \\\"{x:1354,y:576,t:1527009320206};\\\", \\\"{x:1344,y:557,t:1527009320224};\\\", \\\"{x:1339,y:548,t:1527009320241};\\\", \\\"{x:1337,y:540,t:1527009320257};\\\", \\\"{x:1335,y:533,t:1527009320274};\\\", \\\"{x:1334,y:530,t:1527009320291};\\\", \\\"{x:1334,y:529,t:1527009320307};\\\", \\\"{x:1334,y:527,t:1527009320324};\\\", \\\"{x:1334,y:526,t:1527009320341};\\\", \\\"{x:1334,y:525,t:1527009320358};\\\", \\\"{x:1334,y:524,t:1527009320373};\\\", \\\"{x:1334,y:523,t:1527009320391};\\\", \\\"{x:1334,y:522,t:1527009320520};\\\", \\\"{x:1338,y:522,t:1527009320527};\\\", \\\"{x:1341,y:522,t:1527009320541};\\\", \\\"{x:1352,y:522,t:1527009320558};\\\", \\\"{x:1366,y:524,t:1527009320574};\\\", \\\"{x:1389,y:531,t:1527009320591};\\\", \\\"{x:1407,y:534,t:1527009320608};\\\", \\\"{x:1419,y:536,t:1527009320624};\\\", \\\"{x:1420,y:538,t:1527009320752};\\\", \\\"{x:1422,y:540,t:1527009320767};\\\", \\\"{x:1422,y:541,t:1527009320783};\\\", \\\"{x:1422,y:544,t:1527009320791};\\\", \\\"{x:1424,y:549,t:1527009320808};\\\", \\\"{x:1424,y:555,t:1527009320825};\\\", \\\"{x:1424,y:559,t:1527009320841};\\\", \\\"{x:1424,y:562,t:1527009320858};\\\", \\\"{x:1424,y:563,t:1527009320875};\\\", \\\"{x:1424,y:565,t:1527009320892};\\\", \\\"{x:1424,y:566,t:1527009320934};\\\", \\\"{x:1422,y:568,t:1527009321575};\\\", \\\"{x:1420,y:574,t:1527009321592};\\\", \\\"{x:1419,y:576,t:1527009321608};\\\", \\\"{x:1419,y:577,t:1527009321625};\\\", \\\"{x:1419,y:578,t:1527009321643};\\\", \\\"{x:1419,y:579,t:1527009321658};\\\", \\\"{x:1418,y:582,t:1527009321675};\\\", \\\"{x:1417,y:588,t:1527009321692};\\\", \\\"{x:1415,y:594,t:1527009321709};\\\", \\\"{x:1414,y:600,t:1527009321725};\\\", \\\"{x:1413,y:606,t:1527009321742};\\\", \\\"{x:1413,y:614,t:1527009321758};\\\", \\\"{x:1412,y:619,t:1527009321775};\\\", \\\"{x:1412,y:627,t:1527009321792};\\\", \\\"{x:1411,y:635,t:1527009321809};\\\", \\\"{x:1411,y:641,t:1527009321825};\\\", \\\"{x:1410,y:648,t:1527009321842};\\\", \\\"{x:1410,y:656,t:1527009321859};\\\", \\\"{x:1409,y:665,t:1527009321875};\\\", \\\"{x:1407,y:673,t:1527009321892};\\\", \\\"{x:1407,y:678,t:1527009321908};\\\", \\\"{x:1407,y:685,t:1527009321925};\\\", \\\"{x:1407,y:688,t:1527009321941};\\\", \\\"{x:1407,y:691,t:1527009321958};\\\", \\\"{x:1407,y:693,t:1527009321974};\\\", \\\"{x:1408,y:695,t:1527009321991};\\\", \\\"{x:1408,y:698,t:1527009322009};\\\", \\\"{x:1408,y:701,t:1527009322024};\\\", \\\"{x:1408,y:705,t:1527009322041};\\\", \\\"{x:1408,y:709,t:1527009322058};\\\", \\\"{x:1408,y:713,t:1527009322074};\\\", \\\"{x:1408,y:714,t:1527009322091};\\\", \\\"{x:1410,y:719,t:1527009322108};\\\", \\\"{x:1411,y:723,t:1527009322125};\\\", \\\"{x:1414,y:728,t:1527009322141};\\\", \\\"{x:1415,y:733,t:1527009322158};\\\", \\\"{x:1416,y:737,t:1527009322174};\\\", \\\"{x:1416,y:742,t:1527009322191};\\\", \\\"{x:1417,y:744,t:1527009322209};\\\", \\\"{x:1418,y:748,t:1527009322225};\\\", \\\"{x:1418,y:750,t:1527009322242};\\\", \\\"{x:1418,y:752,t:1527009322259};\\\", \\\"{x:1419,y:755,t:1527009322276};\\\", \\\"{x:1419,y:759,t:1527009322291};\\\", \\\"{x:1419,y:762,t:1527009322308};\\\", \\\"{x:1419,y:768,t:1527009322326};\\\", \\\"{x:1422,y:777,t:1527009322342};\\\", \\\"{x:1422,y:784,t:1527009322359};\\\", \\\"{x:1422,y:786,t:1527009322375};\\\", \\\"{x:1422,y:788,t:1527009322392};\\\", \\\"{x:1422,y:789,t:1527009322409};\\\", \\\"{x:1422,y:792,t:1527009322426};\\\", \\\"{x:1422,y:798,t:1527009322441};\\\", \\\"{x:1422,y:803,t:1527009322459};\\\", \\\"{x:1423,y:812,t:1527009322476};\\\", \\\"{x:1425,y:823,t:1527009322492};\\\", \\\"{x:1425,y:828,t:1527009322509};\\\", \\\"{x:1426,y:831,t:1527009322526};\\\", \\\"{x:1426,y:833,t:1527009322542};\\\", \\\"{x:1426,y:836,t:1527009322559};\\\", \\\"{x:1427,y:840,t:1527009322576};\\\", \\\"{x:1427,y:846,t:1527009322592};\\\", \\\"{x:1429,y:850,t:1527009322608};\\\", \\\"{x:1429,y:854,t:1527009322626};\\\", \\\"{x:1429,y:860,t:1527009322643};\\\", \\\"{x:1430,y:870,t:1527009322659};\\\", \\\"{x:1431,y:884,t:1527009322676};\\\", \\\"{x:1434,y:899,t:1527009322694};\\\", \\\"{x:1434,y:908,t:1527009322709};\\\", \\\"{x:1434,y:914,t:1527009322726};\\\", \\\"{x:1434,y:920,t:1527009322743};\\\", \\\"{x:1434,y:925,t:1527009322759};\\\", \\\"{x:1434,y:931,t:1527009322776};\\\", \\\"{x:1433,y:941,t:1527009322793};\\\", \\\"{x:1430,y:951,t:1527009322809};\\\", \\\"{x:1427,y:960,t:1527009322826};\\\", \\\"{x:1425,y:963,t:1527009322844};\\\", \\\"{x:1425,y:965,t:1527009322859};\\\", \\\"{x:1425,y:966,t:1527009322887};\\\", \\\"{x:1425,y:967,t:1527009322894};\\\", \\\"{x:1424,y:967,t:1527009322919};\\\", \\\"{x:1424,y:968,t:1527009322967};\\\", \\\"{x:1424,y:969,t:1527009323055};\\\", \\\"{x:1424,y:970,t:1527009323062};\\\", \\\"{x:1422,y:972,t:1527009323136};\\\", \\\"{x:1421,y:972,t:1527009323849};\\\", \\\"{x:1421,y:967,t:1527009323858};\\\", \\\"{x:1421,y:955,t:1527009323870};\\\", \\\"{x:1413,y:926,t:1527009323887};\\\", \\\"{x:1401,y:880,t:1527009323904};\\\", \\\"{x:1388,y:828,t:1527009323920};\\\", \\\"{x:1374,y:781,t:1527009323938};\\\", \\\"{x:1366,y:757,t:1527009323953};\\\", \\\"{x:1362,y:738,t:1527009323970};\\\", \\\"{x:1358,y:722,t:1527009323987};\\\", \\\"{x:1352,y:705,t:1527009324003};\\\", \\\"{x:1350,y:686,t:1527009324020};\\\", \\\"{x:1345,y:669,t:1527009324037};\\\", \\\"{x:1341,y:649,t:1527009324053};\\\", \\\"{x:1337,y:634,t:1527009324070};\\\", \\\"{x:1335,y:625,t:1527009324087};\\\", \\\"{x:1333,y:619,t:1527009324104};\\\", \\\"{x:1331,y:614,t:1527009324120};\\\", \\\"{x:1329,y:604,t:1527009324137};\\\", \\\"{x:1327,y:591,t:1527009324153};\\\", \\\"{x:1327,y:572,t:1527009324170};\\\", \\\"{x:1327,y:557,t:1527009324187};\\\", \\\"{x:1327,y:540,t:1527009324204};\\\", \\\"{x:1327,y:529,t:1527009324220};\\\", \\\"{x:1327,y:522,t:1527009324237};\\\", \\\"{x:1327,y:512,t:1527009324254};\\\", \\\"{x:1327,y:505,t:1527009324270};\\\", \\\"{x:1325,y:499,t:1527009324287};\\\", \\\"{x:1324,y:497,t:1527009324304};\\\", \\\"{x:1323,y:495,t:1527009324320};\\\", \\\"{x:1321,y:491,t:1527009324337};\\\", \\\"{x:1321,y:490,t:1527009324354};\\\", \\\"{x:1321,y:489,t:1527009324376};\\\", \\\"{x:1320,y:488,t:1527009324392};\\\", \\\"{x:1319,y:490,t:1527009324601};\\\", \\\"{x:1318,y:494,t:1527009324611};\\\", \\\"{x:1316,y:497,t:1527009324620};\\\", \\\"{x:1316,y:499,t:1527009324636};\\\", \\\"{x:1316,y:501,t:1527009324653};\\\", \\\"{x:1316,y:502,t:1527009325306};\\\", \\\"{x:1316,y:504,t:1527009325322};\\\", \\\"{x:1316,y:505,t:1527009325338};\\\", \\\"{x:1316,y:506,t:1527009325354};\\\", \\\"{x:1316,y:508,t:1527009325371};\\\", \\\"{x:1316,y:509,t:1527009325388};\\\", \\\"{x:1316,y:511,t:1527009325404};\\\", \\\"{x:1316,y:512,t:1527009325433};\\\", \\\"{x:1316,y:513,t:1527009325457};\\\", \\\"{x:1316,y:514,t:1527009325481};\\\", \\\"{x:1316,y:515,t:1527009325553};\\\", \\\"{x:1316,y:517,t:1527009325561};\\\", \\\"{x:1317,y:519,t:1527009325585};\\\", \\\"{x:1317,y:522,t:1527009325593};\\\", \\\"{x:1317,y:523,t:1527009325605};\\\", \\\"{x:1318,y:526,t:1527009325621};\\\", \\\"{x:1318,y:530,t:1527009325638};\\\", \\\"{x:1320,y:532,t:1527009325655};\\\", \\\"{x:1320,y:534,t:1527009325671};\\\", \\\"{x:1320,y:539,t:1527009325688};\\\", \\\"{x:1320,y:545,t:1527009325705};\\\", \\\"{x:1320,y:553,t:1527009325720};\\\", \\\"{x:1319,y:564,t:1527009325737};\\\", \\\"{x:1308,y:580,t:1527009325754};\\\", \\\"{x:1301,y:597,t:1527009325770};\\\", \\\"{x:1291,y:623,t:1527009325788};\\\", \\\"{x:1275,y:650,t:1527009325804};\\\", \\\"{x:1261,y:675,t:1527009325820};\\\", \\\"{x:1252,y:691,t:1527009325837};\\\", \\\"{x:1245,y:699,t:1527009325855};\\\", \\\"{x:1243,y:704,t:1527009325870};\\\", \\\"{x:1243,y:703,t:1527009326009};\\\", \\\"{x:1243,y:699,t:1527009326020};\\\", \\\"{x:1243,y:691,t:1527009326038};\\\", \\\"{x:1244,y:685,t:1527009326055};\\\", \\\"{x:1245,y:675,t:1527009326072};\\\", \\\"{x:1246,y:672,t:1527009326088};\\\", \\\"{x:1245,y:678,t:1527009326170};\\\", \\\"{x:1241,y:687,t:1527009326177};\\\", \\\"{x:1237,y:701,t:1527009326188};\\\", \\\"{x:1227,y:742,t:1527009326205};\\\", \\\"{x:1219,y:775,t:1527009326222};\\\", \\\"{x:1209,y:824,t:1527009326238};\\\", \\\"{x:1207,y:853,t:1527009326255};\\\", \\\"{x:1203,y:872,t:1527009326272};\\\", \\\"{x:1202,y:878,t:1527009326288};\\\", \\\"{x:1202,y:879,t:1527009326337};\\\", \\\"{x:1203,y:878,t:1527009326457};\\\", \\\"{x:1204,y:875,t:1527009326472};\\\", \\\"{x:1212,y:866,t:1527009326488};\\\", \\\"{x:1220,y:855,t:1527009326504};\\\", \\\"{x:1222,y:847,t:1527009326523};\\\", \\\"{x:1226,y:834,t:1527009326539};\\\", \\\"{x:1226,y:825,t:1527009326555};\\\", \\\"{x:1230,y:817,t:1527009326572};\\\", \\\"{x:1230,y:812,t:1527009326589};\\\", \\\"{x:1232,y:808,t:1527009326606};\\\", \\\"{x:1232,y:806,t:1527009326622};\\\", \\\"{x:1233,y:804,t:1527009326639};\\\", \\\"{x:1233,y:803,t:1527009326655};\\\", \\\"{x:1235,y:802,t:1527009326785};\\\", \\\"{x:1239,y:801,t:1527009326801};\\\", \\\"{x:1245,y:796,t:1527009326809};\\\", \\\"{x:1253,y:791,t:1527009326822};\\\", \\\"{x:1272,y:779,t:1527009326839};\\\", \\\"{x:1292,y:763,t:1527009326855};\\\", \\\"{x:1308,y:747,t:1527009326872};\\\", \\\"{x:1319,y:734,t:1527009326889};\\\", \\\"{x:1323,y:729,t:1527009326905};\\\", \\\"{x:1324,y:727,t:1527009326923};\\\", \\\"{x:1325,y:727,t:1527009326939};\\\", \\\"{x:1325,y:729,t:1527009327026};\\\", \\\"{x:1324,y:735,t:1527009327039};\\\", \\\"{x:1323,y:745,t:1527009327057};\\\", \\\"{x:1320,y:757,t:1527009327072};\\\", \\\"{x:1318,y:772,t:1527009327089};\\\", \\\"{x:1318,y:775,t:1527009327106};\\\", \\\"{x:1317,y:776,t:1527009327122};\\\", \\\"{x:1317,y:778,t:1527009327330};\\\", \\\"{x:1318,y:778,t:1527009327361};\\\", \\\"{x:1318,y:777,t:1527009327377};\\\", \\\"{x:1318,y:776,t:1527009327920};\\\", \\\"{x:1316,y:773,t:1527009327928};\\\", \\\"{x:1316,y:771,t:1527009327939};\\\", \\\"{x:1315,y:768,t:1527009327955};\\\", \\\"{x:1315,y:764,t:1527009327973};\\\", \\\"{x:1314,y:762,t:1527009327990};\\\", \\\"{x:1313,y:764,t:1527009328761};\\\", \\\"{x:1312,y:767,t:1527009328773};\\\", \\\"{x:1312,y:773,t:1527009328791};\\\", \\\"{x:1312,y:777,t:1527009328807};\\\", \\\"{x:1312,y:779,t:1527009328824};\\\", \\\"{x:1312,y:781,t:1527009328841};\\\", \\\"{x:1312,y:786,t:1527009328857};\\\", \\\"{x:1312,y:792,t:1527009328873};\\\", \\\"{x:1312,y:795,t:1527009328890};\\\", \\\"{x:1312,y:799,t:1527009328906};\\\", \\\"{x:1312,y:801,t:1527009328923};\\\", \\\"{x:1312,y:803,t:1527009328939};\\\", \\\"{x:1312,y:805,t:1527009328957};\\\", \\\"{x:1312,y:810,t:1527009328973};\\\", \\\"{x:1312,y:815,t:1527009328989};\\\", \\\"{x:1312,y:821,t:1527009329006};\\\", \\\"{x:1312,y:827,t:1527009329024};\\\", \\\"{x:1312,y:834,t:1527009329040};\\\", \\\"{x:1309,y:844,t:1527009329056};\\\", \\\"{x:1309,y:849,t:1527009329074};\\\", \\\"{x:1309,y:859,t:1527009329090};\\\", \\\"{x:1309,y:866,t:1527009329107};\\\", \\\"{x:1309,y:881,t:1527009329124};\\\", \\\"{x:1309,y:892,t:1527009329139};\\\", \\\"{x:1307,y:898,t:1527009329156};\\\", \\\"{x:1306,y:901,t:1527009329174};\\\", \\\"{x:1306,y:903,t:1527009329189};\\\", \\\"{x:1305,y:904,t:1527009329207};\\\", \\\"{x:1305,y:905,t:1527009329224};\\\", \\\"{x:1305,y:906,t:1527009329240};\\\", \\\"{x:1305,y:913,t:1527009329257};\\\", \\\"{x:1306,y:916,t:1527009329274};\\\", \\\"{x:1307,y:922,t:1527009329290};\\\", \\\"{x:1308,y:925,t:1527009329306};\\\", \\\"{x:1308,y:928,t:1527009329324};\\\", \\\"{x:1309,y:929,t:1527009329340};\\\", \\\"{x:1309,y:931,t:1527009329357};\\\", \\\"{x:1310,y:935,t:1527009329373};\\\", \\\"{x:1310,y:938,t:1527009329390};\\\", \\\"{x:1310,y:941,t:1527009329407};\\\", \\\"{x:1312,y:944,t:1527009329424};\\\", \\\"{x:1314,y:950,t:1527009329440};\\\", \\\"{x:1314,y:954,t:1527009329457};\\\", \\\"{x:1317,y:960,t:1527009329474};\\\", \\\"{x:1318,y:962,t:1527009329491};\\\", \\\"{x:1320,y:964,t:1527009329507};\\\", \\\"{x:1320,y:966,t:1527009329524};\\\", \\\"{x:1321,y:967,t:1527009329540};\\\", \\\"{x:1322,y:967,t:1527009329557};\\\", \\\"{x:1329,y:954,t:1527009331585};\\\", \\\"{x:1336,y:931,t:1527009331593};\\\", \\\"{x:1350,y:898,t:1527009331609};\\\", \\\"{x:1363,y:851,t:1527009331625};\\\", \\\"{x:1374,y:819,t:1527009331642};\\\", \\\"{x:1384,y:783,t:1527009331659};\\\", \\\"{x:1391,y:758,t:1527009331675};\\\", \\\"{x:1395,y:743,t:1527009331692};\\\", \\\"{x:1397,y:734,t:1527009331709};\\\", \\\"{x:1399,y:729,t:1527009331725};\\\", \\\"{x:1400,y:729,t:1527009331752};\\\", \\\"{x:1400,y:728,t:1527009331760};\\\", \\\"{x:1401,y:728,t:1527009331824};\\\", \\\"{x:1402,y:731,t:1527009331856};\\\", \\\"{x:1402,y:742,t:1527009331864};\\\", \\\"{x:1402,y:748,t:1527009331875};\\\", \\\"{x:1402,y:763,t:1527009331892};\\\", \\\"{x:1401,y:777,t:1527009331909};\\\", \\\"{x:1396,y:788,t:1527009331926};\\\", \\\"{x:1396,y:789,t:1527009331942};\\\", \\\"{x:1396,y:788,t:1527009332073};\\\", \\\"{x:1393,y:785,t:1527009332081};\\\", \\\"{x:1392,y:778,t:1527009332092};\\\", \\\"{x:1384,y:766,t:1527009332110};\\\", \\\"{x:1375,y:751,t:1527009332127};\\\", \\\"{x:1369,y:744,t:1527009332143};\\\", \\\"{x:1368,y:742,t:1527009332159};\\\", \\\"{x:1367,y:741,t:1527009332177};\\\", \\\"{x:1367,y:742,t:1527009332305};\\\", \\\"{x:1367,y:744,t:1527009332313};\\\", \\\"{x:1367,y:745,t:1527009332329};\\\", \\\"{x:1367,y:746,t:1527009332343};\\\", \\\"{x:1369,y:746,t:1527009332514};\\\", \\\"{x:1371,y:746,t:1527009332526};\\\", \\\"{x:1372,y:746,t:1527009332544};\\\", \\\"{x:1374,y:746,t:1527009332585};\\\", \\\"{x:1376,y:747,t:1527009332593};\\\", \\\"{x:1378,y:749,t:1527009332609};\\\", \\\"{x:1382,y:752,t:1527009332626};\\\", \\\"{x:1383,y:753,t:1527009332643};\\\", \\\"{x:1383,y:754,t:1527009332761};\\\", \\\"{x:1384,y:754,t:1527009332777};\\\", \\\"{x:1384,y:755,t:1527009332962};\\\", \\\"{x:1384,y:756,t:1527009332976};\\\", \\\"{x:1382,y:761,t:1527009332994};\\\", \\\"{x:1381,y:764,t:1527009333011};\\\", \\\"{x:1381,y:766,t:1527009333026};\\\", \\\"{x:1380,y:767,t:1527009333043};\\\", \\\"{x:1380,y:768,t:1527009333265};\\\", \\\"{x:1380,y:769,t:1527009333278};\\\", \\\"{x:1380,y:772,t:1527009333294};\\\", \\\"{x:1380,y:775,t:1527009333311};\\\", \\\"{x:1380,y:776,t:1527009333327};\\\", \\\"{x:1380,y:778,t:1527009333344};\\\", \\\"{x:1380,y:779,t:1527009333360};\\\", \\\"{x:1381,y:782,t:1527009333376};\\\", \\\"{x:1381,y:783,t:1527009333394};\\\", \\\"{x:1381,y:784,t:1527009333410};\\\", \\\"{x:1381,y:785,t:1527009333427};\\\", \\\"{x:1381,y:787,t:1527009333443};\\\", \\\"{x:1382,y:787,t:1527009333577};\\\", \\\"{x:1382,y:789,t:1527009333601};\\\", \\\"{x:1382,y:790,t:1527009333610};\\\", \\\"{x:1382,y:791,t:1527009333628};\\\", \\\"{x:1382,y:794,t:1527009333644};\\\", \\\"{x:1383,y:795,t:1527009333665};\\\", \\\"{x:1384,y:796,t:1527009333689};\\\", \\\"{x:1384,y:797,t:1527009333697};\\\", \\\"{x:1384,y:798,t:1527009333711};\\\", \\\"{x:1384,y:802,t:1527009333728};\\\", \\\"{x:1383,y:807,t:1527009333744};\\\", \\\"{x:1382,y:812,t:1527009333761};\\\", \\\"{x:1382,y:817,t:1527009333777};\\\", \\\"{x:1382,y:820,t:1527009333794};\\\", \\\"{x:1382,y:823,t:1527009333810};\\\", \\\"{x:1381,y:825,t:1527009333832};\\\", \\\"{x:1380,y:827,t:1527009333844};\\\", \\\"{x:1379,y:829,t:1527009333860};\\\", \\\"{x:1378,y:831,t:1527009333877};\\\", \\\"{x:1378,y:837,t:1527009333895};\\\", \\\"{x:1378,y:841,t:1527009333910};\\\", \\\"{x:1378,y:846,t:1527009333927};\\\", \\\"{x:1375,y:853,t:1527009333944};\\\", \\\"{x:1372,y:859,t:1527009333960};\\\", \\\"{x:1369,y:871,t:1527009333977};\\\", \\\"{x:1366,y:885,t:1527009333994};\\\", \\\"{x:1362,y:897,t:1527009334010};\\\", \\\"{x:1361,y:903,t:1527009334026};\\\", \\\"{x:1361,y:905,t:1527009334044};\\\", \\\"{x:1361,y:907,t:1527009334152};\\\", \\\"{x:1361,y:908,t:1527009334160};\\\", \\\"{x:1361,y:911,t:1527009334177};\\\", \\\"{x:1361,y:913,t:1527009334194};\\\", \\\"{x:1361,y:916,t:1527009334210};\\\", \\\"{x:1361,y:917,t:1527009334304};\\\", \\\"{x:1361,y:919,t:1527009334313};\\\", \\\"{x:1362,y:921,t:1527009334327};\\\", \\\"{x:1371,y:929,t:1527009334344};\\\", \\\"{x:1378,y:934,t:1527009334361};\\\", \\\"{x:1382,y:940,t:1527009334377};\\\", \\\"{x:1383,y:945,t:1527009334394};\\\", \\\"{x:1384,y:948,t:1527009334411};\\\", \\\"{x:1384,y:953,t:1527009334427};\\\", \\\"{x:1384,y:956,t:1527009334444};\\\", \\\"{x:1385,y:959,t:1527009334462};\\\", \\\"{x:1385,y:961,t:1527009334477};\\\", \\\"{x:1385,y:963,t:1527009334494};\\\", \\\"{x:1385,y:966,t:1527009334512};\\\", \\\"{x:1386,y:968,t:1527009334527};\\\", \\\"{x:1387,y:970,t:1527009334544};\\\", \\\"{x:1388,y:972,t:1527009334560};\\\", \\\"{x:1390,y:972,t:1527009335529};\\\", \\\"{x:1392,y:971,t:1527009338008};\\\", \\\"{x:1394,y:968,t:1527009338015};\\\", \\\"{x:1395,y:965,t:1527009338030};\\\", \\\"{x:1395,y:959,t:1527009338046};\\\", \\\"{x:1395,y:953,t:1527009338063};\\\", \\\"{x:1395,y:948,t:1527009338080};\\\", \\\"{x:1395,y:940,t:1527009338097};\\\", \\\"{x:1395,y:933,t:1527009338113};\\\", \\\"{x:1395,y:928,t:1527009338130};\\\", \\\"{x:1396,y:923,t:1527009338147};\\\", \\\"{x:1398,y:915,t:1527009338163};\\\", \\\"{x:1400,y:910,t:1527009338180};\\\", \\\"{x:1406,y:898,t:1527009338197};\\\", \\\"{x:1411,y:883,t:1527009338213};\\\", \\\"{x:1412,y:880,t:1527009338229};\\\", \\\"{x:1413,y:876,t:1527009338247};\\\", \\\"{x:1413,y:874,t:1527009338263};\\\", \\\"{x:1414,y:871,t:1527009338280};\\\", \\\"{x:1414,y:870,t:1527009338297};\\\", \\\"{x:1415,y:869,t:1527009338314};\\\", \\\"{x:1416,y:869,t:1527009338330};\\\", \\\"{x:1416,y:868,t:1527009338348};\\\", \\\"{x:1417,y:867,t:1527009338377};\\\", \\\"{x:1418,y:867,t:1527009338424};\\\", \\\"{x:1418,y:866,t:1527009338457};\\\", \\\"{x:1419,y:866,t:1527009338577};\\\", \\\"{x:1420,y:864,t:1527009338584};\\\", \\\"{x:1420,y:862,t:1527009338601};\\\", \\\"{x:1420,y:860,t:1527009338615};\\\", \\\"{x:1423,y:854,t:1527009338631};\\\", \\\"{x:1424,y:846,t:1527009338648};\\\", \\\"{x:1428,y:828,t:1527009338664};\\\", \\\"{x:1431,y:812,t:1527009338681};\\\", \\\"{x:1432,y:801,t:1527009338697};\\\", \\\"{x:1433,y:785,t:1527009338714};\\\", \\\"{x:1435,y:768,t:1527009338730};\\\", \\\"{x:1435,y:754,t:1527009338748};\\\", \\\"{x:1435,y:739,t:1527009338764};\\\", \\\"{x:1435,y:728,t:1527009338781};\\\", \\\"{x:1435,y:722,t:1527009338797};\\\", \\\"{x:1435,y:717,t:1527009338815};\\\", \\\"{x:1434,y:714,t:1527009338831};\\\", \\\"{x:1433,y:711,t:1527009338848};\\\", \\\"{x:1432,y:708,t:1527009338865};\\\", \\\"{x:1432,y:704,t:1527009338881};\\\", \\\"{x:1430,y:702,t:1527009338898};\\\", \\\"{x:1430,y:698,t:1527009338914};\\\", \\\"{x:1428,y:692,t:1527009338930};\\\", \\\"{x:1428,y:687,t:1527009338947};\\\", \\\"{x:1426,y:679,t:1527009339193};\\\", \\\"{x:1427,y:675,t:1527009339201};\\\", \\\"{x:1430,y:667,t:1527009339215};\\\", \\\"{x:1437,y:650,t:1527009339232};\\\", \\\"{x:1443,y:632,t:1527009339248};\\\", \\\"{x:1451,y:603,t:1527009339265};\\\", \\\"{x:1454,y:590,t:1527009339281};\\\", \\\"{x:1459,y:580,t:1527009339298};\\\", \\\"{x:1460,y:571,t:1527009339315};\\\", \\\"{x:1458,y:565,t:1527009339332};\\\", \\\"{x:1458,y:563,t:1527009339348};\\\", \\\"{x:1458,y:562,t:1527009339365};\\\", \\\"{x:1455,y:560,t:1527009339489};\\\", \\\"{x:1453,y:559,t:1527009339498};\\\", \\\"{x:1449,y:558,t:1527009339514};\\\", \\\"{x:1446,y:555,t:1527009339531};\\\", \\\"{x:1444,y:553,t:1527009339548};\\\", \\\"{x:1442,y:553,t:1527009339564};\\\", \\\"{x:1441,y:553,t:1527009339592};\\\", \\\"{x:1440,y:553,t:1527009339608};\\\", \\\"{x:1439,y:553,t:1527009339632};\\\", \\\"{x:1435,y:553,t:1527009339648};\\\", \\\"{x:1430,y:554,t:1527009339664};\\\", \\\"{x:1422,y:558,t:1527009339681};\\\", \\\"{x:1415,y:564,t:1527009339698};\\\", \\\"{x:1408,y:567,t:1527009339715};\\\", \\\"{x:1400,y:571,t:1527009339731};\\\", \\\"{x:1391,y:578,t:1527009339749};\\\", \\\"{x:1388,y:580,t:1527009339764};\\\", \\\"{x:1384,y:583,t:1527009339781};\\\", \\\"{x:1380,y:587,t:1527009339798};\\\", \\\"{x:1376,y:589,t:1527009339814};\\\", \\\"{x:1374,y:592,t:1527009339831};\\\", \\\"{x:1369,y:598,t:1527009339848};\\\", \\\"{x:1362,y:602,t:1527009339864};\\\", \\\"{x:1352,y:606,t:1527009339881};\\\", \\\"{x:1344,y:611,t:1527009339898};\\\", \\\"{x:1332,y:620,t:1527009339915};\\\", \\\"{x:1312,y:626,t:1527009339931};\\\", \\\"{x:1288,y:632,t:1527009339949};\\\", \\\"{x:1271,y:636,t:1527009339964};\\\", \\\"{x:1250,y:641,t:1527009339981};\\\", \\\"{x:1235,y:644,t:1527009339998};\\\", \\\"{x:1232,y:646,t:1527009340015};\\\", \\\"{x:1231,y:646,t:1527009340031};\\\", \\\"{x:1230,y:646,t:1527009340273};\\\", \\\"{x:1230,y:642,t:1527009340282};\\\", \\\"{x:1233,y:637,t:1527009340298};\\\", \\\"{x:1237,y:631,t:1527009340315};\\\", \\\"{x:1239,y:629,t:1527009340331};\\\", \\\"{x:1240,y:627,t:1527009340348};\\\", \\\"{x:1243,y:628,t:1527009340681};\\\", \\\"{x:1244,y:631,t:1527009340698};\\\", \\\"{x:1245,y:631,t:1527009340715};\\\", \\\"{x:1247,y:633,t:1527009340732};\\\", \\\"{x:1248,y:634,t:1527009340748};\\\", \\\"{x:1249,y:635,t:1527009340768};\\\", \\\"{x:1250,y:635,t:1527009340782};\\\", \\\"{x:1250,y:636,t:1527009340798};\\\", \\\"{x:1250,y:637,t:1527009340840};\\\", \\\"{x:1250,y:638,t:1527009340848};\\\", \\\"{x:1251,y:640,t:1527009340872};\\\", \\\"{x:1251,y:641,t:1527009340888};\\\", \\\"{x:1251,y:643,t:1527009340898};\\\", \\\"{x:1253,y:647,t:1527009340916};\\\", \\\"{x:1254,y:651,t:1527009340932};\\\", \\\"{x:1255,y:653,t:1527009340948};\\\", \\\"{x:1256,y:656,t:1527009340965};\\\", \\\"{x:1256,y:657,t:1527009340983};\\\", \\\"{x:1256,y:659,t:1527009340999};\\\", \\\"{x:1256,y:662,t:1527009341015};\\\", \\\"{x:1256,y:666,t:1527009341033};\\\", \\\"{x:1256,y:668,t:1527009341049};\\\", \\\"{x:1256,y:670,t:1527009341066};\\\", \\\"{x:1256,y:673,t:1527009341083};\\\", \\\"{x:1256,y:676,t:1527009341099};\\\", \\\"{x:1256,y:679,t:1527009341116};\\\", \\\"{x:1256,y:683,t:1527009341133};\\\", \\\"{x:1256,y:686,t:1527009341150};\\\", \\\"{x:1256,y:689,t:1527009341166};\\\", \\\"{x:1256,y:694,t:1527009341183};\\\", \\\"{x:1256,y:697,t:1527009341200};\\\", \\\"{x:1256,y:700,t:1527009341216};\\\", \\\"{x:1256,y:706,t:1527009341233};\\\", \\\"{x:1256,y:711,t:1527009341249};\\\", \\\"{x:1256,y:716,t:1527009341266};\\\", \\\"{x:1256,y:723,t:1527009341282};\\\", \\\"{x:1256,y:731,t:1527009341299};\\\", \\\"{x:1256,y:734,t:1527009341316};\\\", \\\"{x:1256,y:740,t:1527009341332};\\\", \\\"{x:1256,y:743,t:1527009341349};\\\", \\\"{x:1255,y:749,t:1527009341365};\\\", \\\"{x:1255,y:751,t:1527009341382};\\\", \\\"{x:1253,y:755,t:1527009341400};\\\", \\\"{x:1252,y:756,t:1527009341415};\\\", \\\"{x:1252,y:758,t:1527009341433};\\\", \\\"{x:1252,y:759,t:1527009341449};\\\", \\\"{x:1250,y:760,t:1527009341466};\\\", \\\"{x:1250,y:761,t:1527009341483};\\\", \\\"{x:1250,y:763,t:1527009341500};\\\", \\\"{x:1250,y:766,t:1527009341517};\\\", \\\"{x:1250,y:768,t:1527009341532};\\\", \\\"{x:1249,y:770,t:1527009341550};\\\", \\\"{x:1249,y:772,t:1527009341566};\\\", \\\"{x:1248,y:775,t:1527009341582};\\\", \\\"{x:1247,y:780,t:1527009341600};\\\", \\\"{x:1247,y:785,t:1527009341616};\\\", \\\"{x:1246,y:789,t:1527009341632};\\\", \\\"{x:1245,y:793,t:1527009341650};\\\", \\\"{x:1245,y:797,t:1527009341666};\\\", \\\"{x:1242,y:800,t:1527009341682};\\\", \\\"{x:1242,y:803,t:1527009341699};\\\", \\\"{x:1242,y:804,t:1527009341720};\\\", \\\"{x:1242,y:805,t:1527009341732};\\\", \\\"{x:1242,y:806,t:1527009341750};\\\", \\\"{x:1242,y:807,t:1527009341766};\\\", \\\"{x:1242,y:808,t:1527009341783};\\\", \\\"{x:1242,y:809,t:1527009341800};\\\", \\\"{x:1242,y:810,t:1527009341825};\\\", \\\"{x:1242,y:812,t:1527009341832};\\\", \\\"{x:1241,y:815,t:1527009341850};\\\", \\\"{x:1241,y:817,t:1527009341867};\\\", \\\"{x:1240,y:821,t:1527009341883};\\\", \\\"{x:1240,y:823,t:1527009341900};\\\", \\\"{x:1239,y:826,t:1527009341916};\\\", \\\"{x:1239,y:827,t:1527009341933};\\\", \\\"{x:1239,y:829,t:1527009341960};\\\", \\\"{x:1239,y:830,t:1527009341992};\\\", \\\"{x:1239,y:832,t:1527009342024};\\\", \\\"{x:1239,y:833,t:1527009342088};\\\", \\\"{x:1240,y:835,t:1527009342128};\\\", \\\"{x:1240,y:837,t:1527009342145};\\\", \\\"{x:1241,y:837,t:1527009342153};\\\", \\\"{x:1242,y:840,t:1527009342166};\\\", \\\"{x:1242,y:842,t:1527009342184};\\\", \\\"{x:1243,y:846,t:1527009342200};\\\", \\\"{x:1244,y:853,t:1527009342216};\\\", \\\"{x:1245,y:856,t:1527009342234};\\\", \\\"{x:1246,y:860,t:1527009342250};\\\", \\\"{x:1246,y:864,t:1527009342267};\\\", \\\"{x:1246,y:865,t:1527009342283};\\\", \\\"{x:1246,y:867,t:1527009342299};\\\", \\\"{x:1246,y:872,t:1527009342316};\\\", \\\"{x:1246,y:881,t:1527009342333};\\\", \\\"{x:1246,y:895,t:1527009342350};\\\", \\\"{x:1246,y:903,t:1527009342367};\\\", \\\"{x:1246,y:911,t:1527009342384};\\\", \\\"{x:1245,y:914,t:1527009342400};\\\", \\\"{x:1245,y:918,t:1527009342416};\\\", \\\"{x:1245,y:920,t:1527009342434};\\\", \\\"{x:1245,y:921,t:1527009342451};\\\", \\\"{x:1244,y:923,t:1527009342467};\\\", \\\"{x:1244,y:924,t:1527009342484};\\\", \\\"{x:1243,y:928,t:1527009342501};\\\", \\\"{x:1243,y:930,t:1527009342516};\\\", \\\"{x:1243,y:933,t:1527009342534};\\\", \\\"{x:1243,y:936,t:1527009342551};\\\", \\\"{x:1243,y:937,t:1527009342567};\\\", \\\"{x:1243,y:939,t:1527009342584};\\\", \\\"{x:1243,y:940,t:1527009342601};\\\", \\\"{x:1243,y:942,t:1527009342617};\\\", \\\"{x:1241,y:945,t:1527009342633};\\\", \\\"{x:1241,y:946,t:1527009342651};\\\", \\\"{x:1241,y:950,t:1527009342667};\\\", \\\"{x:1241,y:951,t:1527009342683};\\\", \\\"{x:1241,y:953,t:1527009342701};\\\", \\\"{x:1241,y:957,t:1527009342717};\\\", \\\"{x:1241,y:960,t:1527009342733};\\\", \\\"{x:1241,y:961,t:1527009342753};\\\", \\\"{x:1241,y:963,t:1527009342770};\\\", \\\"{x:1241,y:964,t:1527009342792};\\\", \\\"{x:1242,y:965,t:1527009342809};\\\", \\\"{x:1242,y:966,t:1527009342832};\\\", \\\"{x:1242,y:967,t:1527009342851};\\\", \\\"{x:1243,y:967,t:1527009343690};\\\", \\\"{x:1243,y:968,t:1527009343701};\\\", \\\"{x:1245,y:970,t:1527009343718};\\\", \\\"{x:1246,y:973,t:1527009343734};\\\", \\\"{x:1247,y:974,t:1527009343750};\\\", \\\"{x:1251,y:973,t:1527009345441};\\\", \\\"{x:1261,y:967,t:1527009345452};\\\", \\\"{x:1275,y:963,t:1527009345469};\\\", \\\"{x:1281,y:951,t:1527009345486};\\\", \\\"{x:1285,y:948,t:1527009345504};\\\", \\\"{x:1296,y:943,t:1527009345519};\\\", \\\"{x:1313,y:937,t:1527009345536};\\\", \\\"{x:1338,y:929,t:1527009345552};\\\", \\\"{x:1354,y:922,t:1527009345569};\\\", \\\"{x:1363,y:918,t:1527009345586};\\\", \\\"{x:1365,y:917,t:1527009345603};\\\", \\\"{x:1369,y:917,t:1527009345619};\\\", \\\"{x:1374,y:914,t:1527009345636};\\\", \\\"{x:1376,y:914,t:1527009345653};\\\", \\\"{x:1381,y:914,t:1527009345669};\\\", \\\"{x:1385,y:913,t:1527009345686};\\\", \\\"{x:1389,y:910,t:1527009345704};\\\", \\\"{x:1395,y:906,t:1527009345719};\\\", \\\"{x:1399,y:904,t:1527009345736};\\\", \\\"{x:1407,y:900,t:1527009345753};\\\", \\\"{x:1410,y:897,t:1527009345770};\\\", \\\"{x:1411,y:897,t:1527009345786};\\\", \\\"{x:1418,y:895,t:1527009345803};\\\", \\\"{x:1426,y:894,t:1527009345821};\\\", \\\"{x:1437,y:889,t:1527009345836};\\\", \\\"{x:1451,y:888,t:1527009345853};\\\", \\\"{x:1457,y:888,t:1527009345871};\\\", \\\"{x:1459,y:888,t:1527009345886};\\\", \\\"{x:1460,y:888,t:1527009345921};\\\", \\\"{x:1460,y:889,t:1527009346281};\\\", \\\"{x:1460,y:891,t:1527009346297};\\\", \\\"{x:1459,y:892,t:1527009346320};\\\", \\\"{x:1458,y:894,t:1527009346393};\\\", \\\"{x:1458,y:896,t:1527009346409};\\\", \\\"{x:1458,y:897,t:1527009346425};\\\", \\\"{x:1458,y:898,t:1527009346437};\\\", \\\"{x:1458,y:900,t:1527009346453};\\\", \\\"{x:1457,y:903,t:1527009346470};\\\", \\\"{x:1456,y:905,t:1527009346487};\\\", \\\"{x:1455,y:908,t:1527009346504};\\\", \\\"{x:1453,y:912,t:1527009346520};\\\", \\\"{x:1451,y:914,t:1527009346537};\\\", \\\"{x:1451,y:915,t:1527009346617};\\\", \\\"{x:1451,y:916,t:1527009346633};\\\", \\\"{x:1451,y:917,t:1527009346657};\\\", \\\"{x:1451,y:918,t:1527009346671};\\\", \\\"{x:1450,y:922,t:1527009346687};\\\", \\\"{x:1450,y:925,t:1527009346704};\\\", \\\"{x:1449,y:928,t:1527009346720};\\\", \\\"{x:1448,y:932,t:1527009346737};\\\", \\\"{x:1447,y:935,t:1527009346753};\\\", \\\"{x:1447,y:940,t:1527009346770};\\\", \\\"{x:1444,y:944,t:1527009346787};\\\", \\\"{x:1442,y:947,t:1527009346804};\\\", \\\"{x:1442,y:949,t:1527009346820};\\\", \\\"{x:1440,y:950,t:1527009346837};\\\", \\\"{x:1439,y:952,t:1527009346854};\\\", \\\"{x:1439,y:953,t:1527009346914};\\\", \\\"{x:1436,y:955,t:1527009346945};\\\", \\\"{x:1436,y:957,t:1527009346968};\\\", \\\"{x:1436,y:961,t:1527009346987};\\\", \\\"{x:1436,y:965,t:1527009347004};\\\", \\\"{x:1436,y:970,t:1527009347020};\\\", \\\"{x:1439,y:975,t:1527009347037};\\\", \\\"{x:1439,y:976,t:1527009347054};\\\", \\\"{x:1441,y:978,t:1527009347070};\\\", \\\"{x:1441,y:979,t:1527009347087};\\\", \\\"{x:1441,y:980,t:1527009347104};\\\", \\\"{x:1441,y:981,t:1527009347120};\\\", \\\"{x:1442,y:982,t:1527009347137};\\\", \\\"{x:1442,y:984,t:1527009347154};\\\", \\\"{x:1443,y:985,t:1527009347217};\\\", \\\"{x:1444,y:985,t:1527009347273};\\\", \\\"{x:1445,y:985,t:1527009347297};\\\", \\\"{x:1447,y:984,t:1527009347313};\\\", \\\"{x:1448,y:982,t:1527009347352};\\\", \\\"{x:1449,y:982,t:1527009347369};\\\", \\\"{x:1449,y:981,t:1527009347833};\\\", \\\"{x:1449,y:980,t:1527009347984};\\\", \\\"{x:1449,y:979,t:1527009347992};\\\", \\\"{x:1448,y:975,t:1527009348016};\\\", \\\"{x:1447,y:975,t:1527009348024};\\\", \\\"{x:1447,y:973,t:1527009349345};\\\", \\\"{x:1447,y:972,t:1527009349355};\\\", \\\"{x:1447,y:968,t:1527009350249};\\\", \\\"{x:1447,y:964,t:1527009350257};\\\", \\\"{x:1447,y:952,t:1527009350273};\\\", \\\"{x:1447,y:943,t:1527009350289};\\\", \\\"{x:1447,y:939,t:1527009350306};\\\", \\\"{x:1447,y:929,t:1527009350323};\\\", \\\"{x:1447,y:921,t:1527009350339};\\\", \\\"{x:1447,y:909,t:1527009350355};\\\", \\\"{x:1447,y:897,t:1527009350373};\\\", \\\"{x:1447,y:881,t:1527009350389};\\\", \\\"{x:1448,y:867,t:1527009350405};\\\", \\\"{x:1453,y:852,t:1527009350423};\\\", \\\"{x:1457,y:834,t:1527009350439};\\\", \\\"{x:1463,y:813,t:1527009350455};\\\", \\\"{x:1473,y:761,t:1527009350472};\\\", \\\"{x:1475,y:721,t:1527009350489};\\\", \\\"{x:1475,y:676,t:1527009350506};\\\", \\\"{x:1472,y:634,t:1527009350522};\\\", \\\"{x:1464,y:604,t:1527009350538};\\\", \\\"{x:1457,y:572,t:1527009350556};\\\", \\\"{x:1448,y:550,t:1527009350573};\\\", \\\"{x:1438,y:529,t:1527009350590};\\\", \\\"{x:1432,y:513,t:1527009350605};\\\", \\\"{x:1427,y:504,t:1527009350623};\\\", \\\"{x:1424,y:496,t:1527009350639};\\\", \\\"{x:1422,y:495,t:1527009350656};\\\", \\\"{x:1422,y:497,t:1527009350761};\\\", \\\"{x:1422,y:506,t:1527009350773};\\\", \\\"{x:1423,y:526,t:1527009350790};\\\", \\\"{x:1425,y:544,t:1527009350805};\\\", \\\"{x:1427,y:553,t:1527009350823};\\\", \\\"{x:1430,y:558,t:1527009350840};\\\", \\\"{x:1430,y:569,t:1527009350856};\\\", \\\"{x:1430,y:570,t:1527009350873};\\\", \\\"{x:1430,y:568,t:1527009351017};\\\", \\\"{x:1430,y:559,t:1527009351025};\\\", \\\"{x:1430,y:551,t:1527009351040};\\\", \\\"{x:1429,y:526,t:1527009351056};\\\", \\\"{x:1417,y:499,t:1527009351073};\\\", \\\"{x:1409,y:484,t:1527009351091};\\\", \\\"{x:1406,y:474,t:1527009351106};\\\", \\\"{x:1401,y:466,t:1527009351123};\\\", \\\"{x:1397,y:458,t:1527009351139};\\\", \\\"{x:1393,y:450,t:1527009351157};\\\", \\\"{x:1390,y:444,t:1527009351172};\\\", \\\"{x:1388,y:441,t:1527009351190};\\\", \\\"{x:1385,y:436,t:1527009351206};\\\", \\\"{x:1383,y:433,t:1527009351222};\\\", \\\"{x:1379,y:428,t:1527009351240};\\\", \\\"{x:1378,y:428,t:1527009351264};\\\", \\\"{x:1376,y:428,t:1527009351273};\\\", \\\"{x:1374,y:428,t:1527009351289};\\\", \\\"{x:1369,y:428,t:1527009351307};\\\", \\\"{x:1360,y:435,t:1527009351322};\\\", \\\"{x:1349,y:445,t:1527009351340};\\\", \\\"{x:1342,y:456,t:1527009351357};\\\", \\\"{x:1336,y:468,t:1527009351373};\\\", \\\"{x:1334,y:476,t:1527009351390};\\\", \\\"{x:1330,y:487,t:1527009351407};\\\", \\\"{x:1323,y:498,t:1527009351423};\\\", \\\"{x:1320,y:504,t:1527009351440};\\\", \\\"{x:1318,y:509,t:1527009351456};\\\", \\\"{x:1317,y:511,t:1527009351472};\\\", \\\"{x:1316,y:512,t:1527009351490};\\\", \\\"{x:1315,y:514,t:1527009351785};\\\", \\\"{x:1315,y:519,t:1527009351793};\\\", \\\"{x:1315,y:524,t:1527009351808};\\\", \\\"{x:1315,y:546,t:1527009351824};\\\", \\\"{x:1315,y:554,t:1527009351840};\\\", \\\"{x:1315,y:576,t:1527009351857};\\\", \\\"{x:1315,y:588,t:1527009351874};\\\", \\\"{x:1315,y:593,t:1527009351890};\\\", \\\"{x:1315,y:597,t:1527009351907};\\\", \\\"{x:1315,y:604,t:1527009351923};\\\", \\\"{x:1315,y:611,t:1527009351939};\\\", \\\"{x:1315,y:619,t:1527009351957};\\\", \\\"{x:1313,y:632,t:1527009351974};\\\", \\\"{x:1311,y:643,t:1527009351990};\\\", \\\"{x:1311,y:661,t:1527009352007};\\\", \\\"{x:1310,y:680,t:1527009352023};\\\", \\\"{x:1310,y:693,t:1527009352040};\\\", \\\"{x:1310,y:700,t:1527009352057};\\\", \\\"{x:1312,y:710,t:1527009352073};\\\", \\\"{x:1313,y:716,t:1527009352091};\\\", \\\"{x:1314,y:722,t:1527009352107};\\\", \\\"{x:1316,y:727,t:1527009352123};\\\", \\\"{x:1318,y:732,t:1527009352141};\\\", \\\"{x:1320,y:738,t:1527009352156};\\\", \\\"{x:1322,y:742,t:1527009352174};\\\", \\\"{x:1325,y:747,t:1527009352191};\\\", \\\"{x:1327,y:752,t:1527009352207};\\\", \\\"{x:1331,y:760,t:1527009352223};\\\", \\\"{x:1333,y:763,t:1527009352240};\\\", \\\"{x:1334,y:768,t:1527009352256};\\\", \\\"{x:1336,y:772,t:1527009352274};\\\", \\\"{x:1339,y:777,t:1527009352291};\\\", \\\"{x:1341,y:782,t:1527009352307};\\\", \\\"{x:1343,y:785,t:1527009352324};\\\", \\\"{x:1344,y:787,t:1527009352340};\\\", \\\"{x:1346,y:788,t:1527009352357};\\\", \\\"{x:1346,y:789,t:1527009352374};\\\", \\\"{x:1347,y:791,t:1527009352391};\\\", \\\"{x:1347,y:792,t:1527009352406};\\\", \\\"{x:1348,y:795,t:1527009352423};\\\", \\\"{x:1348,y:798,t:1527009352441};\\\", \\\"{x:1349,y:802,t:1527009352457};\\\", \\\"{x:1350,y:805,t:1527009352474};\\\", \\\"{x:1351,y:808,t:1527009352491};\\\", \\\"{x:1351,y:812,t:1527009352507};\\\", \\\"{x:1351,y:816,t:1527009352524};\\\", \\\"{x:1354,y:822,t:1527009352541};\\\", \\\"{x:1354,y:827,t:1527009352558};\\\", \\\"{x:1355,y:832,t:1527009352574};\\\", \\\"{x:1358,y:835,t:1527009352591};\\\", \\\"{x:1358,y:838,t:1527009352608};\\\", \\\"{x:1358,y:841,t:1527009352624};\\\", \\\"{x:1358,y:845,t:1527009352649};\\\", \\\"{x:1358,y:846,t:1527009352658};\\\", \\\"{x:1358,y:851,t:1527009352674};\\\", \\\"{x:1358,y:855,t:1527009352691};\\\", \\\"{x:1358,y:857,t:1527009352707};\\\", \\\"{x:1358,y:859,t:1527009352724};\\\", \\\"{x:1358,y:862,t:1527009352741};\\\", \\\"{x:1358,y:864,t:1527009352758};\\\", \\\"{x:1358,y:866,t:1527009352774};\\\", \\\"{x:1357,y:873,t:1527009352791};\\\", \\\"{x:1355,y:882,t:1527009352808};\\\", \\\"{x:1353,y:886,t:1527009352824};\\\", \\\"{x:1353,y:889,t:1527009352841};\\\", \\\"{x:1351,y:893,t:1527009352858};\\\", \\\"{x:1349,y:896,t:1527009352874};\\\", \\\"{x:1348,y:902,t:1527009352892};\\\", \\\"{x:1347,y:907,t:1527009352908};\\\", \\\"{x:1344,y:915,t:1527009352924};\\\", \\\"{x:1343,y:918,t:1527009352941};\\\", \\\"{x:1340,y:923,t:1527009352957};\\\", \\\"{x:1340,y:926,t:1527009352974};\\\", \\\"{x:1338,y:931,t:1527009352990};\\\", \\\"{x:1336,y:935,t:1527009353008};\\\", \\\"{x:1332,y:942,t:1527009353024};\\\", \\\"{x:1330,y:947,t:1527009353041};\\\", \\\"{x:1329,y:948,t:1527009353058};\\\", \\\"{x:1329,y:950,t:1527009353075};\\\", \\\"{x:1329,y:952,t:1527009353104};\\\", \\\"{x:1330,y:952,t:1527009353665};\\\", \\\"{x:1331,y:952,t:1527009353905};\\\", \\\"{x:1332,y:952,t:1527009353968};\\\", \\\"{x:1333,y:952,t:1527009355153};\\\", \\\"{x:1330,y:945,t:1527009355160};\\\", \\\"{x:1314,y:923,t:1527009355176};\\\", \\\"{x:1280,y:886,t:1527009355192};\\\", \\\"{x:1235,y:834,t:1527009355209};\\\", \\\"{x:1194,y:784,t:1527009355226};\\\", \\\"{x:1172,y:754,t:1527009355243};\\\", \\\"{x:1163,y:742,t:1527009355260};\\\", \\\"{x:1162,y:740,t:1527009355277};\\\", \\\"{x:1163,y:738,t:1527009355313};\\\", \\\"{x:1163,y:737,t:1527009355326};\\\", \\\"{x:1164,y:733,t:1527009355343};\\\", \\\"{x:1168,y:729,t:1527009355359};\\\", \\\"{x:1170,y:724,t:1527009355376};\\\", \\\"{x:1172,y:721,t:1527009355393};\\\", \\\"{x:1174,y:720,t:1527009355410};\\\", \\\"{x:1176,y:718,t:1527009355426};\\\", \\\"{x:1181,y:716,t:1527009355444};\\\", \\\"{x:1189,y:711,t:1527009355460};\\\", \\\"{x:1194,y:708,t:1527009355477};\\\", \\\"{x:1199,y:706,t:1527009355493};\\\", \\\"{x:1200,y:704,t:1527009355511};\\\", \\\"{x:1201,y:702,t:1527009355633};\\\", \\\"{x:1197,y:695,t:1527009355644};\\\", \\\"{x:1178,y:684,t:1527009355660};\\\", \\\"{x:1139,y:663,t:1527009355677};\\\", \\\"{x:1084,y:640,t:1527009355693};\\\", \\\"{x:991,y:608,t:1527009355711};\\\", \\\"{x:899,y:577,t:1527009355727};\\\", \\\"{x:804,y:530,t:1527009355745};\\\", \\\"{x:676,y:459,t:1527009355760};\\\", \\\"{x:618,y:422,t:1527009355776};\\\", \\\"{x:590,y:401,t:1527009355790};\\\", \\\"{x:552,y:378,t:1527009355806};\\\", \\\"{x:533,y:364,t:1527009355823};\\\", \\\"{x:528,y:362,t:1527009355840};\\\", \\\"{x:527,y:363,t:1527009355953};\\\", \\\"{x:527,y:367,t:1527009355960};\\\", \\\"{x:532,y:373,t:1527009355973};\\\", \\\"{x:540,y:382,t:1527009355989};\\\", \\\"{x:556,y:388,t:1527009356006};\\\", \\\"{x:585,y:397,t:1527009356023};\\\", \\\"{x:653,y:423,t:1527009356040};\\\", \\\"{x:693,y:456,t:1527009356056};\\\", \\\"{x:725,y:498,t:1527009356073};\\\", \\\"{x:741,y:544,t:1527009356091};\\\", \\\"{x:747,y:588,t:1527009356107};\\\", \\\"{x:743,y:623,t:1527009356131};\\\", \\\"{x:732,y:640,t:1527009356147};\\\", \\\"{x:718,y:659,t:1527009356164};\\\", \\\"{x:704,y:675,t:1527009356181};\\\", \\\"{x:685,y:694,t:1527009356197};\\\", \\\"{x:676,y:708,t:1527009356215};\\\", \\\"{x:674,y:712,t:1527009356231};\\\", \\\"{x:670,y:714,t:1527009356248};\\\", \\\"{x:664,y:714,t:1527009356344};\\\", \\\"{x:663,y:714,t:1527009356352};\\\", \\\"{x:660,y:712,t:1527009356365};\\\", \\\"{x:658,y:712,t:1527009356382};\\\", \\\"{x:646,y:709,t:1527009356398};\\\", \\\"{x:641,y:709,t:1527009356415};\\\", \\\"{x:623,y:709,t:1527009356432};\\\", \\\"{x:621,y:710,t:1527009356448};\\\", \\\"{x:621,y:712,t:1527009356497};\\\", \\\"{x:629,y:711,t:1527009356769};\\\", \\\"{x:643,y:709,t:1527009356783};\\\", \\\"{x:694,y:685,t:1527009356801};\\\", \\\"{x:739,y:661,t:1527009356817};\\\", \\\"{x:787,y:626,t:1527009356833};\\\", \\\"{x:823,y:595,t:1527009356852};\\\", \\\"{x:842,y:566,t:1527009356867};\\\", \\\"{x:856,y:547,t:1527009356882};\\\", \\\"{x:864,y:531,t:1527009356898};\\\", \\\"{x:866,y:526,t:1527009356915};\\\", \\\"{x:866,y:524,t:1527009356932};\\\", \\\"{x:868,y:522,t:1527009356947};\\\", \\\"{x:868,y:521,t:1527009356965};\\\", \\\"{x:868,y:519,t:1527009356984};\\\", \\\"{x:868,y:518,t:1527009357016};\\\", \\\"{x:868,y:516,t:1527009357039};\\\", \\\"{x:865,y:517,t:1527009357129};\\\", \\\"{x:864,y:518,t:1527009357137};\\\", \\\"{x:860,y:519,t:1527009357148};\\\", \\\"{x:857,y:519,t:1527009357165};\\\", \\\"{x:855,y:519,t:1527009357183};\\\", \\\"{x:854,y:520,t:1527009357199};\\\", \\\"{x:855,y:519,t:1527009362681};\\\", \\\"{x:864,y:507,t:1527009362689};\\\", \\\"{x:871,y:499,t:1527009362703};\\\", \\\"{x:891,y:480,t:1527009362720};\\\", \\\"{x:900,y:473,t:1527009362736};\\\", \\\"{x:907,y:467,t:1527009362753};\\\", \\\"{x:907,y:466,t:1527009362770};\\\", \\\"{x:908,y:466,t:1527009362792};\\\", \\\"{x:909,y:465,t:1527009362803};\\\", \\\"{x:913,y:462,t:1527009362820};\\\", \\\"{x:921,y:454,t:1527009362836};\\\", \\\"{x:929,y:448,t:1527009362853};\\\", \\\"{x:937,y:440,t:1527009362870};\\\", \\\"{x:941,y:438,t:1527009362886};\\\", \\\"{x:942,y:437,t:1527009362903};\\\", \\\"{x:943,y:436,t:1527009362920};\\\", \\\"{x:944,y:435,t:1527009363145};\\\", \\\"{x:945,y:435,t:1527009363153};\\\", \\\"{x:947,y:434,t:1527009363170};\\\", \\\"{x:950,y:433,t:1527009363188};\\\", \\\"{x:953,y:433,t:1527009363203};\\\", \\\"{x:956,y:433,t:1527009363221};\\\", \\\"{x:959,y:432,t:1527009363240};\\\", \\\"{x:960,y:432,t:1527009363254};\\\", \\\"{x:966,y:432,t:1527009363270};\\\", \\\"{x:971,y:432,t:1527009363288};\\\", \\\"{x:973,y:432,t:1527009363336};\\\", \\\"{x:975,y:432,t:1527009363344};\\\", \\\"{x:978,y:433,t:1527009363353};\\\", \\\"{x:982,y:440,t:1527009363370};\\\", \\\"{x:986,y:449,t:1527009363387};\\\", \\\"{x:988,y:466,t:1527009363403};\\\", \\\"{x:988,y:486,t:1527009363421};\\\", \\\"{x:990,y:532,t:1527009363438};\\\", \\\"{x:993,y:594,t:1527009363453};\\\", \\\"{x:993,y:667,t:1527009363470};\\\", \\\"{x:993,y:733,t:1527009363487};\\\", \\\"{x:988,y:863,t:1527009363503};\\\", \\\"{x:970,y:964,t:1527009363520};\\\", \\\"{x:954,y:1075,t:1527009363538};\\\", \\\"{x:944,y:1188,t:1527009363554};\\\", \\\"{x:928,y:1199,t:1527009363570};\\\", \\\"{x:907,y:1199,t:1527009363587};\\\", \\\"{x:897,y:1199,t:1527009363605};\\\", \\\"{x:901,y:1199,t:1527009363623};\\\", \\\"{x:905,y:1199,t:1527009363637};\\\", \\\"{x:908,y:1199,t:1527009363654};\\\", \\\"{x:911,y:1199,t:1527009367873};\\\", \\\"{x:917,y:1197,t:1527009367882};\\\", \\\"{x:932,y:1187,t:1527009367898};\\\", \\\"{x:941,y:1177,t:1527009367915};\\\", \\\"{x:952,y:1170,t:1527009367932};\\\", \\\"{x:959,y:1166,t:1527009367940};\\\", \\\"{x:977,y:1158,t:1527009367957};\\\", \\\"{x:993,y:1151,t:1527009367974};\\\", \\\"{x:1009,y:1145,t:1527009367991};\\\", \\\"{x:1030,y:1134,t:1527009368007};\\\", \\\"{x:1033,y:1131,t:1527009368024};\\\", \\\"{x:1048,y:1121,t:1527009368040};\\\", \\\"{x:1069,y:1112,t:1527009368057};\\\", \\\"{x:1088,y:1103,t:1527009368075};\\\", \\\"{x:1104,y:1091,t:1527009368090};\\\", \\\"{x:1128,y:1077,t:1527009368107};\\\", \\\"{x:1150,y:1065,t:1527009368125};\\\", \\\"{x:1178,y:1045,t:1527009368141};\\\", \\\"{x:1212,y:1023,t:1527009368157};\\\", \\\"{x:1238,y:1001,t:1527009368175};\\\", \\\"{x:1261,y:983,t:1527009368191};\\\", \\\"{x:1289,y:957,t:1527009368207};\\\", \\\"{x:1307,y:934,t:1527009368225};\\\", \\\"{x:1318,y:914,t:1527009368242};\\\", \\\"{x:1320,y:901,t:1527009368257};\\\", \\\"{x:1320,y:892,t:1527009368275};\\\", \\\"{x:1320,y:875,t:1527009368292};\\\", \\\"{x:1325,y:849,t:1527009368307};\\\", \\\"{x:1333,y:824,t:1527009368324};\\\", \\\"{x:1345,y:797,t:1527009368342};\\\", \\\"{x:1350,y:776,t:1527009368358};\\\", \\\"{x:1352,y:770,t:1527009368375};\\\", \\\"{x:1352,y:771,t:1527009368464};\\\", \\\"{x:1349,y:781,t:1527009368475};\\\", \\\"{x:1345,y:801,t:1527009368492};\\\", \\\"{x:1341,y:820,t:1527009368507};\\\", \\\"{x:1337,y:835,t:1527009368525};\\\", \\\"{x:1336,y:847,t:1527009368541};\\\", \\\"{x:1336,y:863,t:1527009368558};\\\", \\\"{x:1336,y:886,t:1527009368575};\\\", \\\"{x:1336,y:913,t:1527009368591};\\\", \\\"{x:1336,y:923,t:1527009368607};\\\", \\\"{x:1336,y:930,t:1527009368625};\\\", \\\"{x:1338,y:935,t:1527009368642};\\\", \\\"{x:1341,y:943,t:1527009368657};\\\", \\\"{x:1344,y:952,t:1527009368675};\\\", \\\"{x:1345,y:956,t:1527009368692};\\\", \\\"{x:1345,y:957,t:1527009368712};\\\", \\\"{x:1346,y:958,t:1527009368744};\\\", \\\"{x:1346,y:960,t:1527009368784};\\\", \\\"{x:1346,y:962,t:1527009368792};\\\", \\\"{x:1346,y:969,t:1527009368808};\\\", \\\"{x:1344,y:975,t:1527009368824};\\\", \\\"{x:1344,y:976,t:1527009368842};\\\", \\\"{x:1344,y:977,t:1527009368859};\\\", \\\"{x:1344,y:978,t:1527009368875};\\\", \\\"{x:1341,y:978,t:1527009369169};\\\", \\\"{x:1328,y:972,t:1527009369176};\\\", \\\"{x:1304,y:957,t:1527009369193};\\\", \\\"{x:1200,y:910,t:1527009369209};\\\", \\\"{x:1099,y:859,t:1527009369226};\\\", \\\"{x:934,y:794,t:1527009369242};\\\", \\\"{x:757,y:730,t:1527009369259};\\\", \\\"{x:588,y:680,t:1527009369276};\\\", \\\"{x:476,y:636,t:1527009369292};\\\", \\\"{x:417,y:605,t:1527009369310};\\\", \\\"{x:402,y:594,t:1527009369326};\\\", \\\"{x:397,y:591,t:1527009369341};\\\", \\\"{x:397,y:589,t:1527009369358};\\\", \\\"{x:396,y:586,t:1527009369375};\\\", \\\"{x:394,y:583,t:1527009369392};\\\", \\\"{x:392,y:576,t:1527009369409};\\\", \\\"{x:383,y:566,t:1527009369426};\\\", \\\"{x:366,y:551,t:1527009369442};\\\", \\\"{x:334,y:525,t:1527009369459};\\\", \\\"{x:306,y:505,t:1527009369476};\\\", \\\"{x:252,y:465,t:1527009369492};\\\", \\\"{x:212,y:436,t:1527009369509};\\\", \\\"{x:186,y:415,t:1527009369526};\\\", \\\"{x:182,y:410,t:1527009369543};\\\", \\\"{x:181,y:408,t:1527009369559};\\\", \\\"{x:183,y:402,t:1527009369576};\\\", \\\"{x:191,y:395,t:1527009369591};\\\", \\\"{x:211,y:386,t:1527009369608};\\\", \\\"{x:230,y:383,t:1527009369625};\\\", \\\"{x:255,y:383,t:1527009369642};\\\", \\\"{x:274,y:385,t:1527009369658};\\\", \\\"{x:297,y:393,t:1527009369676};\\\", \\\"{x:321,y:402,t:1527009369693};\\\", \\\"{x:340,y:414,t:1527009369708};\\\", \\\"{x:352,y:423,t:1527009369725};\\\", \\\"{x:358,y:433,t:1527009369743};\\\", \\\"{x:361,y:441,t:1527009369758};\\\", \\\"{x:362,y:453,t:1527009369775};\\\", \\\"{x:362,y:463,t:1527009369792};\\\", \\\"{x:359,y:472,t:1527009369809};\\\", \\\"{x:353,y:489,t:1527009369826};\\\", \\\"{x:346,y:506,t:1527009369843};\\\", \\\"{x:346,y:520,t:1527009369858};\\\", \\\"{x:346,y:526,t:1527009369876};\\\", \\\"{x:347,y:527,t:1527009369968};\\\", \\\"{x:353,y:526,t:1527009369976};\\\", \\\"{x:362,y:523,t:1527009369993};\\\", \\\"{x:368,y:522,t:1527009370010};\\\", \\\"{x:370,y:521,t:1527009370120};\\\", \\\"{x:373,y:520,t:1527009370161};\\\", \\\"{x:377,y:524,t:1527009370337};\\\", \\\"{x:391,y:537,t:1527009370345};\\\", \\\"{x:436,y:579,t:1527009370360};\\\", \\\"{x:496,y:626,t:1527009370376};\\\", \\\"{x:547,y:667,t:1527009370393};\\\", \\\"{x:580,y:704,t:1527009370410};\\\", \\\"{x:600,y:744,t:1527009370427};\\\", \\\"{x:620,y:788,t:1527009370442};\\\", \\\"{x:629,y:821,t:1527009370459};\\\", \\\"{x:636,y:841,t:1527009370476};\\\", \\\"{x:638,y:848,t:1527009370493};\\\", \\\"{x:638,y:847,t:1527009370600};\\\", \\\"{x:633,y:842,t:1527009370611};\\\", \\\"{x:595,y:820,t:1527009370628};\\\", \\\"{x:556,y:794,t:1527009370644};\\\", \\\"{x:542,y:779,t:1527009370661};\\\", \\\"{x:534,y:775,t:1527009370678};\\\", \\\"{x:534,y:774,t:1527009370694};\\\", \\\"{x:534,y:772,t:1527009370712};\\\", \\\"{x:534,y:760,t:1527009370728};\\\", \\\"{x:535,y:742,t:1527009370744};\\\", \\\"{x:537,y:721,t:1527009370762};\\\", \\\"{x:539,y:702,t:1527009370777};\\\", \\\"{x:540,y:677,t:1527009370793};\\\", \\\"{x:540,y:660,t:1527009370810};\\\", \\\"{x:539,y:648,t:1527009370828};\\\", \\\"{x:534,y:635,t:1527009370844};\\\", \\\"{x:527,y:621,t:1527009370859};\\\", \\\"{x:521,y:614,t:1527009370877};\\\", \\\"{x:513,y:607,t:1527009370893};\\\", \\\"{x:506,y:599,t:1527009370910};\\\", \\\"{x:497,y:593,t:1527009370927};\\\", \\\"{x:471,y:574,t:1527009370944};\\\", \\\"{x:456,y:561,t:1527009370959};\\\", \\\"{x:444,y:551,t:1527009370977};\\\", \\\"{x:438,y:547,t:1527009370993};\\\", \\\"{x:437,y:546,t:1527009371010};\\\", \\\"{x:437,y:545,t:1527009371027};\\\", \\\"{x:436,y:545,t:1527009371043};\\\", \\\"{x:433,y:543,t:1527009371064};\\\", \\\"{x:430,y:540,t:1527009371076};\\\", \\\"{x:424,y:533,t:1527009371094};\\\", \\\"{x:420,y:530,t:1527009371109};\\\", \\\"{x:418,y:529,t:1527009371127};\\\", \\\"{x:417,y:527,t:1527009371144};\\\", \\\"{x:416,y:525,t:1527009371159};\\\", \\\"{x:415,y:524,t:1527009371177};\\\", \\\"{x:415,y:523,t:1527009371193};\\\", \\\"{x:414,y:522,t:1527009371210};\\\", \\\"{x:411,y:520,t:1527009371227};\\\", \\\"{x:406,y:518,t:1527009371243};\\\", \\\"{x:402,y:517,t:1527009371261};\\\", \\\"{x:401,y:516,t:1527009371280};\\\", \\\"{x:401,y:519,t:1527009371560};\\\", \\\"{x:462,y:598,t:1527009371577};\\\", \\\"{x:541,y:675,t:1527009371594};\\\", \\\"{x:603,y:771,t:1527009371611};\\\", \\\"{x:651,y:848,t:1527009371627};\\\", \\\"{x:667,y:880,t:1527009371643};\\\", \\\"{x:670,y:891,t:1527009371661};\\\", \\\"{x:670,y:894,t:1527009371678};\\\", \\\"{x:668,y:894,t:1527009371743};\\\", \\\"{x:663,y:889,t:1527009371760};\\\", \\\"{x:652,y:875,t:1527009371777};\\\", \\\"{x:638,y:859,t:1527009371793};\\\", \\\"{x:620,y:833,t:1527009371810};\\\", \\\"{x:594,y:799,t:1527009371828};\\\", \\\"{x:571,y:769,t:1527009371844};\\\", \\\"{x:558,y:752,t:1527009371861};\\\", \\\"{x:554,y:744,t:1527009371878};\\\", \\\"{x:554,y:741,t:1527009371894};\\\", \\\"{x:554,y:740,t:1527009371961};\\\", \\\"{x:553,y:738,t:1527009371984};\\\", \\\"{x:553,y:737,t:1527009371994};\\\", \\\"{x:552,y:735,t:1527009372012};\\\", \\\"{x:552,y:733,t:1527009372032};\\\", \\\"{x:552,y:732,t:1527009372064};\\\", \\\"{x:552,y:731,t:1527009372077};\\\", \\\"{x:552,y:724,t:1527009372093};\\\", \\\"{x:555,y:714,t:1527009372110};\\\", \\\"{x:556,y:708,t:1527009372125};\\\", \\\"{x:557,y:707,t:1527009372142};\\\", \\\"{x:558,y:707,t:1527009372561};\\\", \\\"{x:561,y:707,t:1527009372568};\\\", \\\"{x:575,y:709,t:1527009372577};\\\", \\\"{x:604,y:715,t:1527009372594};\\\", \\\"{x:658,y:722,t:1527009372612};\\\", \\\"{x:748,y:730,t:1527009372628};\\\", \\\"{x:861,y:742,t:1527009372645};\\\", \\\"{x:976,y:750,t:1527009372662};\\\", \\\"{x:1082,y:750,t:1527009372678};\\\", \\\"{x:1190,y:747,t:1527009372694};\\\", \\\"{x:1317,y:740,t:1527009372712};\\\", \\\"{x:1345,y:737,t:1527009372728};\\\", \\\"{x:1360,y:737,t:1527009372745};\\\", \\\"{x:1363,y:734,t:1527009372762};\\\", \\\"{x:1378,y:730,t:1527009372778};\\\", \\\"{x:1402,y:723,t:1527009372795};\\\", \\\"{x:1427,y:711,t:1527009372812};\\\", \\\"{x:1468,y:690,t:1527009372828};\\\", \\\"{x:1502,y:668,t:1527009372844};\\\", \\\"{x:1552,y:626,t:1527009372861};\\\", \\\"{x:1635,y:566,t:1527009372878};\\\", \\\"{x:1717,y:482,t:1527009372895};\\\", \\\"{x:1825,y:337,t:1527009372911};\\\", \\\"{x:1894,y:234,t:1527009372928};\\\", \\\"{x:1919,y:141,t:1527009372944};\\\", \\\"{x:1919,y:42,t:1527009372961};\\\", \\\"{x:1919,y:0,t:1527009372979};\\\", \\\"{x:1919,y:14,t:1527009373152};\\\", \\\"{x:1917,y:21,t:1527009373162};\\\" ] }, { \\\"rt\\\": 84069, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 614013, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -O -I -I -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1917,y:20,t:1527009377784};\\\", \\\"{x:1918,y:18,t:1527009377792};\\\", \\\"{x:1919,y:15,t:1527009377810};\\\", \\\"{x:1919,y:10,t:1527009377827};\\\", \\\"{x:1919,y:7,t:1527009377849};\\\", \\\"{x:1919,y:3,t:1527009377866};\\\", \\\"{x:1919,y:1,t:1527009377883};\\\", \\\"{x:1919,y:0,t:1527009377899};\\\", \\\"{x:1911,y:0,t:1527009379417};\\\", \\\"{x:1891,y:4,t:1527009379435};\\\", \\\"{x:1805,y:11,t:1527009379451};\\\", \\\"{x:1683,y:15,t:1527009379467};\\\", \\\"{x:1561,y:15,t:1527009379484};\\\", \\\"{x:1442,y:15,t:1527009379500};\\\", \\\"{x:1363,y:12,t:1527009379518};\\\", \\\"{x:1236,y:13,t:1527009379534};\\\", \\\"{x:1105,y:14,t:1527009379551};\\\", \\\"{x:1027,y:7,t:1527009379568};\\\", \\\"{x:993,y:4,t:1527009379585};\\\", \\\"{x:993,y:2,t:1527009379849};\\\", \\\"{x:1001,y:0,t:1527009379856};\\\", \\\"{x:1009,y:0,t:1527009379868};\\\", \\\"{x:1019,y:0,t:1527009379884};\\\", \\\"{x:1041,y:0,t:1527009379901};\\\", \\\"{x:1079,y:4,t:1527009379917};\\\", \\\"{x:1132,y:27,t:1527009379935};\\\", \\\"{x:1197,y:63,t:1527009379951};\\\", \\\"{x:1243,y:105,t:1527009379968};\\\", \\\"{x:1345,y:199,t:1527009379985};\\\", \\\"{x:1392,y:268,t:1527009380002};\\\", \\\"{x:1437,y:353,t:1527009380017};\\\", \\\"{x:1487,y:455,t:1527009380035};\\\", \\\"{x:1508,y:546,t:1527009380051};\\\", \\\"{x:1519,y:626,t:1527009380070};\\\", \\\"{x:1519,y:685,t:1527009380085};\\\", \\\"{x:1519,y:719,t:1527009380101};\\\", \\\"{x:1514,y:751,t:1527009380117};\\\", \\\"{x:1505,y:782,t:1527009380134};\\\", \\\"{x:1499,y:799,t:1527009380152};\\\", \\\"{x:1488,y:811,t:1527009380168};\\\", \\\"{x:1480,y:813,t:1527009380183};\\\", \\\"{x:1469,y:813,t:1527009380201};\\\", \\\"{x:1458,y:809,t:1527009380218};\\\", \\\"{x:1438,y:796,t:1527009380234};\\\", \\\"{x:1422,y:780,t:1527009380251};\\\", \\\"{x:1399,y:755,t:1527009380268};\\\", \\\"{x:1385,y:733,t:1527009380284};\\\", \\\"{x:1366,y:689,t:1527009380301};\\\", \\\"{x:1349,y:630,t:1527009380318};\\\", \\\"{x:1343,y:603,t:1527009380334};\\\", \\\"{x:1343,y:593,t:1527009380351};\\\", \\\"{x:1344,y:583,t:1527009380368};\\\", \\\"{x:1347,y:575,t:1527009380384};\\\", \\\"{x:1348,y:568,t:1527009380401};\\\", \\\"{x:1349,y:566,t:1527009380418};\\\", \\\"{x:1348,y:563,t:1527009381153};\\\", \\\"{x:1338,y:545,t:1527009381169};\\\", \\\"{x:1334,y:542,t:1527009381185};\\\", \\\"{x:1332,y:541,t:1527009381447};\\\", \\\"{x:1329,y:537,t:1527009381456};\\\", \\\"{x:1327,y:535,t:1527009381469};\\\", \\\"{x:1323,y:526,t:1527009381485};\\\", \\\"{x:1313,y:509,t:1527009381502};\\\", \\\"{x:1295,y:484,t:1527009381519};\\\", \\\"{x:1281,y:469,t:1527009381535};\\\", \\\"{x:1271,y:458,t:1527009381552};\\\", \\\"{x:1270,y:455,t:1527009381569};\\\", \\\"{x:1270,y:457,t:1527009381729};\\\", \\\"{x:1271,y:459,t:1527009381736};\\\", \\\"{x:1276,y:466,t:1527009381752};\\\", \\\"{x:1280,y:472,t:1527009381769};\\\", \\\"{x:1285,y:476,t:1527009381785};\\\", \\\"{x:1288,y:479,t:1527009381802};\\\", \\\"{x:1289,y:480,t:1527009382024};\\\", \\\"{x:1293,y:481,t:1527009382037};\\\", \\\"{x:1304,y:483,t:1527009382053};\\\", \\\"{x:1314,y:484,t:1527009382070};\\\", \\\"{x:1325,y:488,t:1527009382086};\\\", \\\"{x:1328,y:489,t:1527009382102};\\\", \\\"{x:1329,y:490,t:1527009382120};\\\", \\\"{x:1330,y:490,t:1527009382140};\\\", \\\"{x:1331,y:490,t:1527009382328};\\\", \\\"{x:1331,y:492,t:1527009382344};\\\", \\\"{x:1331,y:493,t:1527009382425};\\\", \\\"{x:1331,y:494,t:1527009382448};\\\", \\\"{x:1331,y:495,t:1527009382464};\\\", \\\"{x:1331,y:496,t:1527009382488};\\\", \\\"{x:1331,y:497,t:1527009382513};\\\", \\\"{x:1329,y:498,t:1527009382840};\\\", \\\"{x:1327,y:499,t:1527009382853};\\\", \\\"{x:1324,y:500,t:1527009382870};\\\", \\\"{x:1321,y:501,t:1527009382886};\\\", \\\"{x:1317,y:502,t:1527009382903};\\\", \\\"{x:1320,y:502,t:1527009385906};\\\", \\\"{x:1321,y:502,t:1527009385914};\\\", \\\"{x:1322,y:502,t:1527009385931};\\\", \\\"{x:1326,y:502,t:1527009385948};\\\", \\\"{x:1329,y:502,t:1527009385964};\\\", \\\"{x:1334,y:502,t:1527009385980};\\\", \\\"{x:1335,y:503,t:1527009385997};\\\", \\\"{x:1336,y:503,t:1527009386014};\\\", \\\"{x:1337,y:503,t:1527009386040};\\\", \\\"{x:1338,y:503,t:1527009386064};\\\", \\\"{x:1340,y:504,t:1527009386104};\\\", \\\"{x:1341,y:504,t:1527009386128};\\\", \\\"{x:1342,y:504,t:1527009386136};\\\", \\\"{x:1343,y:504,t:1527009386148};\\\", \\\"{x:1344,y:504,t:1527009386164};\\\", \\\"{x:1345,y:504,t:1527009386180};\\\", \\\"{x:1346,y:504,t:1527009386198};\\\", \\\"{x:1347,y:504,t:1527009386214};\\\", \\\"{x:1348,y:504,t:1527009386231};\\\", \\\"{x:1348,y:505,t:1527009386505};\\\", \\\"{x:1346,y:505,t:1527009386516};\\\", \\\"{x:1345,y:506,t:1527009386531};\\\", \\\"{x:1344,y:506,t:1527009386561};\\\", \\\"{x:1344,y:507,t:1527009386577};\\\", \\\"{x:1343,y:508,t:1527009386585};\\\", \\\"{x:1343,y:509,t:1527009386599};\\\", \\\"{x:1342,y:513,t:1527009386615};\\\", \\\"{x:1342,y:515,t:1527009386631};\\\", \\\"{x:1342,y:517,t:1527009386648};\\\", \\\"{x:1342,y:521,t:1527009386665};\\\", \\\"{x:1342,y:522,t:1527009386689};\\\", \\\"{x:1342,y:523,t:1527009386699};\\\", \\\"{x:1342,y:524,t:1527009386715};\\\", \\\"{x:1342,y:525,t:1527009386732};\\\", \\\"{x:1341,y:527,t:1527009386748};\\\", \\\"{x:1339,y:530,t:1527009386765};\\\", \\\"{x:1338,y:530,t:1527009386783};\\\", \\\"{x:1338,y:531,t:1527009386798};\\\", \\\"{x:1338,y:532,t:1527009386815};\\\", \\\"{x:1338,y:533,t:1527009386833};\\\", \\\"{x:1338,y:536,t:1527009386873};\\\", \\\"{x:1338,y:537,t:1527009386882};\\\", \\\"{x:1338,y:539,t:1527009386913};\\\", \\\"{x:1338,y:540,t:1527009386929};\\\", \\\"{x:1338,y:542,t:1527009386945};\\\", \\\"{x:1338,y:543,t:1527009386961};\\\", \\\"{x:1338,y:545,t:1527009386969};\\\", \\\"{x:1338,y:546,t:1527009386982};\\\", \\\"{x:1338,y:550,t:1527009386998};\\\", \\\"{x:1338,y:554,t:1527009387015};\\\", \\\"{x:1340,y:566,t:1527009387033};\\\", \\\"{x:1341,y:569,t:1527009387049};\\\", \\\"{x:1341,y:564,t:1527009387225};\\\", \\\"{x:1338,y:558,t:1527009387233};\\\", \\\"{x:1331,y:540,t:1527009387249};\\\", \\\"{x:1321,y:525,t:1527009387265};\\\", \\\"{x:1312,y:512,t:1527009387282};\\\", \\\"{x:1308,y:503,t:1527009387299};\\\", \\\"{x:1307,y:499,t:1527009387315};\\\", \\\"{x:1306,y:496,t:1527009387333};\\\", \\\"{x:1306,y:499,t:1527009387529};\\\", \\\"{x:1306,y:500,t:1527009387537};\\\", \\\"{x:1306,y:503,t:1527009387550};\\\", \\\"{x:1306,y:507,t:1527009387565};\\\", \\\"{x:1306,y:510,t:1527009387582};\\\", \\\"{x:1308,y:511,t:1527009387599};\\\", \\\"{x:1308,y:512,t:1527009387615};\\\", \\\"{x:1308,y:513,t:1527009387632};\\\", \\\"{x:1310,y:514,t:1527009387649};\\\", \\\"{x:1312,y:518,t:1527009387666};\\\", \\\"{x:1312,y:521,t:1527009387683};\\\", \\\"{x:1312,y:523,t:1527009387699};\\\", \\\"{x:1312,y:527,t:1527009387716};\\\", \\\"{x:1312,y:529,t:1527009387733};\\\", \\\"{x:1312,y:531,t:1527009387750};\\\", \\\"{x:1312,y:534,t:1527009387766};\\\", \\\"{x:1312,y:536,t:1527009387782};\\\", \\\"{x:1312,y:537,t:1527009387801};\\\", \\\"{x:1312,y:539,t:1527009387816};\\\", \\\"{x:1312,y:540,t:1527009387832};\\\", \\\"{x:1312,y:541,t:1527009387849};\\\", \\\"{x:1312,y:542,t:1527009387867};\\\", \\\"{x:1314,y:544,t:1527009387882};\\\", \\\"{x:1314,y:547,t:1527009387899};\\\", \\\"{x:1315,y:550,t:1527009387916};\\\", \\\"{x:1317,y:554,t:1527009387932};\\\", \\\"{x:1317,y:557,t:1527009387949};\\\", \\\"{x:1319,y:562,t:1527009387967};\\\", \\\"{x:1319,y:567,t:1527009387983};\\\", \\\"{x:1321,y:571,t:1527009387999};\\\", \\\"{x:1322,y:575,t:1527009388016};\\\", \\\"{x:1322,y:577,t:1527009388033};\\\", \\\"{x:1323,y:580,t:1527009388050};\\\", \\\"{x:1323,y:582,t:1527009388067};\\\", \\\"{x:1323,y:584,t:1527009388083};\\\", \\\"{x:1324,y:587,t:1527009388100};\\\", \\\"{x:1324,y:588,t:1527009388128};\\\", \\\"{x:1324,y:589,t:1527009388153};\\\", \\\"{x:1325,y:591,t:1527009388166};\\\", \\\"{x:1325,y:592,t:1527009388183};\\\", \\\"{x:1325,y:594,t:1527009388198};\\\", \\\"{x:1326,y:599,t:1527009388215};\\\", \\\"{x:1326,y:601,t:1527009388232};\\\", \\\"{x:1326,y:605,t:1527009388249};\\\", \\\"{x:1326,y:608,t:1527009388266};\\\", \\\"{x:1326,y:612,t:1527009388283};\\\", \\\"{x:1326,y:614,t:1527009388299};\\\", \\\"{x:1326,y:618,t:1527009388316};\\\", \\\"{x:1325,y:622,t:1527009388333};\\\", \\\"{x:1324,y:623,t:1527009388349};\\\", \\\"{x:1324,y:627,t:1527009388366};\\\", \\\"{x:1323,y:629,t:1527009388383};\\\", \\\"{x:1322,y:632,t:1527009388399};\\\", \\\"{x:1320,y:634,t:1527009388416};\\\", \\\"{x:1320,y:637,t:1527009388433};\\\", \\\"{x:1318,y:640,t:1527009388449};\\\", \\\"{x:1318,y:642,t:1527009388466};\\\", \\\"{x:1317,y:643,t:1527009388483};\\\", \\\"{x:1317,y:645,t:1527009388500};\\\", \\\"{x:1317,y:649,t:1527009388516};\\\", \\\"{x:1317,y:651,t:1527009388533};\\\", \\\"{x:1317,y:652,t:1527009388550};\\\", \\\"{x:1317,y:653,t:1527009388566};\\\", \\\"{x:1317,y:655,t:1527009388583};\\\", \\\"{x:1317,y:656,t:1527009388608};\\\", \\\"{x:1317,y:657,t:1527009388616};\\\", \\\"{x:1317,y:658,t:1527009388633};\\\", \\\"{x:1317,y:659,t:1527009388656};\\\", \\\"{x:1317,y:660,t:1527009388673};\\\", \\\"{x:1317,y:661,t:1527009388683};\\\", \\\"{x:1317,y:662,t:1527009388701};\\\", \\\"{x:1317,y:663,t:1527009388717};\\\", \\\"{x:1317,y:664,t:1527009388786};\\\", \\\"{x:1318,y:665,t:1527009388801};\\\", \\\"{x:1318,y:667,t:1527009388881};\\\", \\\"{x:1319,y:668,t:1527009388961};\\\", \\\"{x:1319,y:669,t:1527009389002};\\\", \\\"{x:1319,y:670,t:1527009389041};\\\", \\\"{x:1319,y:671,t:1527009389056};\\\", \\\"{x:1320,y:674,t:1527009389073};\\\", \\\"{x:1321,y:674,t:1527009389105};\\\", \\\"{x:1321,y:676,t:1527009389118};\\\", \\\"{x:1321,y:677,t:1527009389136};\\\", \\\"{x:1321,y:678,t:1527009389151};\\\", \\\"{x:1321,y:680,t:1527009389167};\\\", \\\"{x:1321,y:683,t:1527009389184};\\\", \\\"{x:1321,y:684,t:1527009389200};\\\", \\\"{x:1320,y:686,t:1527009389216};\\\", \\\"{x:1319,y:687,t:1527009389234};\\\", \\\"{x:1319,y:689,t:1527009389251};\\\", \\\"{x:1318,y:691,t:1527009389268};\\\", \\\"{x:1318,y:692,t:1527009389289};\\\", \\\"{x:1317,y:693,t:1527009389300};\\\", \\\"{x:1317,y:694,t:1527009389317};\\\", \\\"{x:1316,y:695,t:1527009389337};\\\", \\\"{x:1316,y:696,t:1527009389354};\\\", \\\"{x:1316,y:697,t:1527009389367};\\\", \\\"{x:1315,y:699,t:1527009389392};\\\", \\\"{x:1315,y:700,t:1527009389408};\\\", \\\"{x:1314,y:700,t:1527009389424};\\\", \\\"{x:1313,y:700,t:1527009389448};\\\", \\\"{x:1313,y:701,t:1527009389464};\\\", \\\"{x:1312,y:703,t:1527009389480};\\\", \\\"{x:1312,y:704,t:1527009389504};\\\", \\\"{x:1312,y:705,t:1527009389517};\\\", \\\"{x:1312,y:706,t:1527009389534};\\\", \\\"{x:1310,y:708,t:1527009389550};\\\", \\\"{x:1310,y:709,t:1527009389567};\\\", \\\"{x:1310,y:710,t:1527009389592};\\\", \\\"{x:1309,y:712,t:1527009389608};\\\", \\\"{x:1308,y:712,t:1527009389617};\\\", \\\"{x:1308,y:713,t:1527009389640};\\\", \\\"{x:1308,y:714,t:1527009389664};\\\", \\\"{x:1308,y:715,t:1527009389680};\\\", \\\"{x:1308,y:717,t:1527009389712};\\\", \\\"{x:1308,y:718,t:1527009389737};\\\", \\\"{x:1308,y:719,t:1527009389760};\\\", \\\"{x:1308,y:720,t:1527009389769};\\\", \\\"{x:1308,y:721,t:1527009389785};\\\", \\\"{x:1308,y:722,t:1527009389800};\\\", \\\"{x:1308,y:725,t:1527009389817};\\\", \\\"{x:1308,y:726,t:1527009389849};\\\", \\\"{x:1308,y:727,t:1527009389857};\\\", \\\"{x:1308,y:728,t:1527009389867};\\\", \\\"{x:1308,y:730,t:1527009389883};\\\", \\\"{x:1308,y:731,t:1527009389904};\\\", \\\"{x:1308,y:733,t:1527009389920};\\\", \\\"{x:1308,y:734,t:1527009389936};\\\", \\\"{x:1308,y:735,t:1527009389951};\\\", \\\"{x:1308,y:737,t:1527009389967};\\\", \\\"{x:1308,y:738,t:1527009389984};\\\", \\\"{x:1309,y:740,t:1527009390001};\\\", \\\"{x:1309,y:741,t:1527009390017};\\\", \\\"{x:1309,y:743,t:1527009390034};\\\", \\\"{x:1309,y:746,t:1527009390051};\\\", \\\"{x:1308,y:747,t:1527009390067};\\\", \\\"{x:1308,y:749,t:1527009390088};\\\", \\\"{x:1308,y:750,t:1527009390113};\\\", \\\"{x:1308,y:751,t:1527009390145};\\\", \\\"{x:1308,y:752,t:1527009390186};\\\", \\\"{x:1308,y:753,t:1527009390233};\\\", \\\"{x:1308,y:754,t:1527009390251};\\\", \\\"{x:1308,y:756,t:1527009390268};\\\", \\\"{x:1308,y:757,t:1527009390284};\\\", \\\"{x:1308,y:759,t:1527009390302};\\\", \\\"{x:1308,y:760,t:1527009390319};\\\", \\\"{x:1308,y:762,t:1527009390334};\\\", \\\"{x:1308,y:763,t:1527009390353};\\\", \\\"{x:1308,y:764,t:1527009390369};\\\", \\\"{x:1308,y:765,t:1527009390385};\\\", \\\"{x:1308,y:766,t:1527009390409};\\\", \\\"{x:1308,y:767,t:1527009390425};\\\", \\\"{x:1308,y:769,t:1527009390448};\\\", \\\"{x:1308,y:770,t:1527009390481};\\\", \\\"{x:1309,y:772,t:1527009390513};\\\", \\\"{x:1311,y:773,t:1527009390537};\\\", \\\"{x:1312,y:775,t:1527009390553};\\\", \\\"{x:1313,y:775,t:1527009390569};\\\", \\\"{x:1315,y:776,t:1527009390584};\\\", \\\"{x:1317,y:778,t:1527009390602};\\\", \\\"{x:1319,y:778,t:1527009390618};\\\", \\\"{x:1320,y:778,t:1527009390648};\\\", \\\"{x:1320,y:779,t:1527009390937};\\\", \\\"{x:1319,y:779,t:1527009390953};\\\", \\\"{x:1316,y:777,t:1527009390969};\\\", \\\"{x:1312,y:777,t:1527009390985};\\\", \\\"{x:1310,y:777,t:1527009391001};\\\", \\\"{x:1309,y:774,t:1527009391019};\\\", \\\"{x:1307,y:771,t:1527009391036};\\\", \\\"{x:1298,y:765,t:1527009391052};\\\", \\\"{x:1289,y:761,t:1527009391068};\\\", \\\"{x:1277,y:756,t:1527009391086};\\\", \\\"{x:1258,y:747,t:1527009391101};\\\", \\\"{x:1235,y:739,t:1527009391119};\\\", \\\"{x:1191,y:724,t:1527009391135};\\\", \\\"{x:1054,y:691,t:1527009391152};\\\", \\\"{x:952,y:667,t:1527009391168};\\\", \\\"{x:851,y:645,t:1527009391185};\\\", \\\"{x:765,y:623,t:1527009391203};\\\", \\\"{x:688,y:602,t:1527009391218};\\\", \\\"{x:662,y:595,t:1527009391235};\\\", \\\"{x:645,y:584,t:1527009391252};\\\", \\\"{x:622,y:577,t:1527009391269};\\\", \\\"{x:605,y:571,t:1527009391285};\\\", \\\"{x:597,y:566,t:1527009391302};\\\", \\\"{x:591,y:561,t:1527009391319};\\\", \\\"{x:580,y:553,t:1527009391335};\\\", \\\"{x:559,y:535,t:1527009391352};\\\", \\\"{x:526,y:518,t:1527009391369};\\\", \\\"{x:489,y:498,t:1527009391385};\\\", \\\"{x:454,y:481,t:1527009391402};\\\", \\\"{x:422,y:473,t:1527009391419};\\\", \\\"{x:406,y:467,t:1527009391435};\\\", \\\"{x:395,y:461,t:1527009391452};\\\", \\\"{x:391,y:459,t:1527009391468};\\\", \\\"{x:393,y:459,t:1527009391512};\\\", \\\"{x:400,y:460,t:1527009391520};\\\", \\\"{x:409,y:464,t:1527009391535};\\\", \\\"{x:427,y:469,t:1527009391552};\\\", \\\"{x:435,y:471,t:1527009391569};\\\", \\\"{x:437,y:473,t:1527009391585};\\\", \\\"{x:437,y:474,t:1527009391602};\\\", \\\"{x:437,y:476,t:1527009391619};\\\", \\\"{x:437,y:480,t:1527009391635};\\\", \\\"{x:437,y:486,t:1527009391652};\\\", \\\"{x:434,y:493,t:1527009391668};\\\", \\\"{x:431,y:498,t:1527009391684};\\\", \\\"{x:428,y:502,t:1527009391702};\\\", \\\"{x:426,y:506,t:1527009391718};\\\", \\\"{x:424,y:509,t:1527009391735};\\\", \\\"{x:423,y:511,t:1527009391752};\\\", \\\"{x:420,y:514,t:1527009391769};\\\", \\\"{x:417,y:516,t:1527009391785};\\\", \\\"{x:416,y:520,t:1527009391804};\\\", \\\"{x:416,y:523,t:1527009391818};\\\", \\\"{x:415,y:524,t:1527009391848};\\\", \\\"{x:415,y:527,t:1527009391864};\\\", \\\"{x:414,y:527,t:1527009391871};\\\", \\\"{x:414,y:528,t:1527009391886};\\\", \\\"{x:413,y:530,t:1527009391901};\\\", \\\"{x:411,y:531,t:1527009391918};\\\", \\\"{x:411,y:529,t:1527009392400};\\\", \\\"{x:411,y:528,t:1527009392488};\\\", \\\"{x:413,y:528,t:1527009392503};\\\", \\\"{x:415,y:527,t:1527009392520};\\\", \\\"{x:425,y:527,t:1527009392537};\\\", \\\"{x:449,y:527,t:1527009392553};\\\", \\\"{x:508,y:537,t:1527009392571};\\\", \\\"{x:538,y:544,t:1527009392585};\\\", \\\"{x:635,y:555,t:1527009392603};\\\", \\\"{x:739,y:565,t:1527009392620};\\\", \\\"{x:862,y:571,t:1527009392636};\\\", \\\"{x:924,y:574,t:1527009392653};\\\", \\\"{x:1027,y:586,t:1527009392671};\\\", \\\"{x:1119,y:601,t:1527009392686};\\\", \\\"{x:1175,y:611,t:1527009392703};\\\", \\\"{x:1216,y:622,t:1527009392720};\\\", \\\"{x:1231,y:624,t:1527009392736};\\\", \\\"{x:1243,y:629,t:1527009392753};\\\", \\\"{x:1256,y:634,t:1527009392770};\\\", \\\"{x:1273,y:638,t:1527009392787};\\\", \\\"{x:1299,y:644,t:1527009392804};\\\", \\\"{x:1328,y:650,t:1527009392820};\\\", \\\"{x:1360,y:656,t:1527009392836};\\\", \\\"{x:1396,y:661,t:1527009392854};\\\", \\\"{x:1426,y:667,t:1527009392870};\\\", \\\"{x:1447,y:674,t:1527009392886};\\\", \\\"{x:1464,y:679,t:1527009392903};\\\", \\\"{x:1466,y:682,t:1527009392920};\\\", \\\"{x:1467,y:682,t:1527009392936};\\\", \\\"{x:1468,y:683,t:1527009392953};\\\", \\\"{x:1469,y:685,t:1527009392970};\\\", \\\"{x:1469,y:687,t:1527009392992};\\\", \\\"{x:1469,y:688,t:1527009393009};\\\", \\\"{x:1469,y:690,t:1527009393024};\\\", \\\"{x:1469,y:692,t:1527009393037};\\\", \\\"{x:1469,y:695,t:1527009393053};\\\", \\\"{x:1466,y:698,t:1527009393071};\\\", \\\"{x:1465,y:700,t:1527009393087};\\\", \\\"{x:1461,y:702,t:1527009393103};\\\", \\\"{x:1450,y:706,t:1527009393120};\\\", \\\"{x:1447,y:707,t:1527009393137};\\\", \\\"{x:1443,y:707,t:1527009393153};\\\", \\\"{x:1441,y:707,t:1527009397857};\\\", \\\"{x:1424,y:706,t:1527009397873};\\\", \\\"{x:1314,y:688,t:1527009397888};\\\", \\\"{x:1191,y:667,t:1527009397905};\\\", \\\"{x:1095,y:643,t:1527009397922};\\\", \\\"{x:933,y:603,t:1527009397940};\\\", \\\"{x:779,y:568,t:1527009397955};\\\", \\\"{x:632,y:527,t:1527009397972};\\\", \\\"{x:533,y:503,t:1527009397991};\\\", \\\"{x:485,y:493,t:1527009398007};\\\", \\\"{x:466,y:490,t:1527009398024};\\\", \\\"{x:465,y:490,t:1527009398041};\\\", \\\"{x:463,y:490,t:1527009398064};\\\", \\\"{x:460,y:490,t:1527009398074};\\\", \\\"{x:447,y:491,t:1527009398091};\\\", \\\"{x:430,y:491,t:1527009398107};\\\", \\\"{x:417,y:493,t:1527009398124};\\\", \\\"{x:408,y:495,t:1527009398141};\\\", \\\"{x:399,y:495,t:1527009398157};\\\", \\\"{x:392,y:499,t:1527009398174};\\\", \\\"{x:390,y:500,t:1527009398191};\\\", \\\"{x:388,y:503,t:1527009398207};\\\", \\\"{x:382,y:512,t:1527009398224};\\\", \\\"{x:379,y:516,t:1527009398242};\\\", \\\"{x:379,y:518,t:1527009398257};\\\", \\\"{x:379,y:519,t:1527009398274};\\\", \\\"{x:379,y:520,t:1527009398427};\\\", \\\"{x:379,y:521,t:1527009398442};\\\", \\\"{x:378,y:522,t:1527009398505};\\\", \\\"{x:378,y:523,t:1527009398513};\\\", \\\"{x:378,y:524,t:1527009398524};\\\", \\\"{x:376,y:527,t:1527009398541};\\\", \\\"{x:376,y:528,t:1527009398558};\\\", \\\"{x:375,y:529,t:1527009398574};\\\", \\\"{x:378,y:530,t:1527009398976};\\\", \\\"{x:393,y:531,t:1527009398991};\\\", \\\"{x:505,y:525,t:1527009399009};\\\", \\\"{x:611,y:521,t:1527009399026};\\\", \\\"{x:749,y:519,t:1527009399041};\\\", \\\"{x:928,y:516,t:1527009399058};\\\", \\\"{x:1110,y:518,t:1527009399075};\\\", \\\"{x:1293,y:519,t:1527009399091};\\\", \\\"{x:1452,y:512,t:1527009399108};\\\", \\\"{x:1593,y:508,t:1527009399125};\\\", \\\"{x:1690,y:508,t:1527009399141};\\\", \\\"{x:1737,y:498,t:1527009399158};\\\", \\\"{x:1746,y:495,t:1527009399176};\\\", \\\"{x:1747,y:494,t:1527009399192};\\\", \\\"{x:1744,y:493,t:1527009399321};\\\", \\\"{x:1735,y:495,t:1527009399328};\\\", \\\"{x:1727,y:496,t:1527009399343};\\\", \\\"{x:1691,y:502,t:1527009399359};\\\", \\\"{x:1663,y:505,t:1527009399376};\\\", \\\"{x:1625,y:516,t:1527009399392};\\\", \\\"{x:1596,y:519,t:1527009399409};\\\", \\\"{x:1579,y:523,t:1527009399426};\\\", \\\"{x:1567,y:523,t:1527009399443};\\\", \\\"{x:1562,y:523,t:1527009399458};\\\", \\\"{x:1561,y:523,t:1527009399475};\\\", \\\"{x:1560,y:523,t:1527009399493};\\\", \\\"{x:1558,y:523,t:1527009399537};\\\", \\\"{x:1557,y:523,t:1527009399553};\\\", \\\"{x:1555,y:523,t:1527009399560};\\\", \\\"{x:1554,y:523,t:1527009399584};\\\", \\\"{x:1551,y:522,t:1527009399608};\\\", \\\"{x:1549,y:522,t:1527009399616};\\\", \\\"{x:1547,y:522,t:1527009399625};\\\", \\\"{x:1534,y:520,t:1527009399642};\\\", \\\"{x:1511,y:516,t:1527009399659};\\\", \\\"{x:1495,y:515,t:1527009399675};\\\", \\\"{x:1481,y:513,t:1527009399692};\\\", \\\"{x:1477,y:513,t:1527009399709};\\\", \\\"{x:1477,y:512,t:1527009399725};\\\", \\\"{x:1475,y:512,t:1527009399824};\\\", \\\"{x:1474,y:512,t:1527009408217};\\\", \\\"{x:1474,y:494,t:1527009408233};\\\", \\\"{x:1476,y:478,t:1527009408251};\\\", \\\"{x:1480,y:459,t:1527009408268};\\\", \\\"{x:1486,y:448,t:1527009408283};\\\", \\\"{x:1488,y:444,t:1527009408301};\\\", \\\"{x:1489,y:443,t:1527009408318};\\\", \\\"{x:1490,y:441,t:1527009408353};\\\", \\\"{x:1491,y:441,t:1527009408368};\\\", \\\"{x:1493,y:440,t:1527009408383};\\\", \\\"{x:1497,y:438,t:1527009408400};\\\", \\\"{x:1498,y:437,t:1527009408416};\\\", \\\"{x:1499,y:437,t:1527009408439};\\\", \\\"{x:1500,y:436,t:1527009408455};\\\", \\\"{x:1501,y:437,t:1527009408528};\\\", \\\"{x:1501,y:438,t:1527009408536};\\\", \\\"{x:1500,y:442,t:1527009408550};\\\", \\\"{x:1495,y:453,t:1527009408567};\\\", \\\"{x:1487,y:468,t:1527009408583};\\\", \\\"{x:1479,y:486,t:1527009408599};\\\", \\\"{x:1477,y:488,t:1527009408617};\\\", \\\"{x:1477,y:490,t:1527009408633};\\\", \\\"{x:1478,y:491,t:1527009408688};\\\", \\\"{x:1479,y:491,t:1527009408700};\\\", \\\"{x:1484,y:489,t:1527009408717};\\\", \\\"{x:1494,y:483,t:1527009408734};\\\", \\\"{x:1508,y:476,t:1527009408750};\\\", \\\"{x:1524,y:473,t:1527009408767};\\\", \\\"{x:1550,y:468,t:1527009408783};\\\", \\\"{x:1558,y:465,t:1527009408799};\\\", \\\"{x:1556,y:468,t:1527009408993};\\\", \\\"{x:1550,y:474,t:1527009409000};\\\", \\\"{x:1542,y:486,t:1527009409017};\\\", \\\"{x:1533,y:501,t:1527009409034};\\\", \\\"{x:1523,y:514,t:1527009409051};\\\", \\\"{x:1513,y:524,t:1527009409067};\\\", \\\"{x:1503,y:533,t:1527009409084};\\\", \\\"{x:1498,y:537,t:1527009409101};\\\", \\\"{x:1491,y:543,t:1527009409117};\\\", \\\"{x:1484,y:550,t:1527009409135};\\\", \\\"{x:1481,y:553,t:1527009409151};\\\", \\\"{x:1479,y:554,t:1527009409167};\\\", \\\"{x:1478,y:554,t:1527009409265};\\\", \\\"{x:1475,y:554,t:1527009409273};\\\", \\\"{x:1471,y:552,t:1527009409284};\\\", \\\"{x:1464,y:547,t:1527009409302};\\\", \\\"{x:1450,y:542,t:1527009409317};\\\", \\\"{x:1427,y:538,t:1527009409334};\\\", \\\"{x:1399,y:531,t:1527009409352};\\\", \\\"{x:1373,y:527,t:1527009409366};\\\", \\\"{x:1340,y:530,t:1527009409383};\\\", \\\"{x:1325,y:530,t:1527009409401};\\\", \\\"{x:1310,y:532,t:1527009409416};\\\", \\\"{x:1300,y:534,t:1527009409434};\\\", \\\"{x:1291,y:537,t:1527009409451};\\\", \\\"{x:1277,y:543,t:1527009409468};\\\", \\\"{x:1248,y:548,t:1527009409484};\\\", \\\"{x:1220,y:554,t:1527009409501};\\\", \\\"{x:1185,y:559,t:1527009409518};\\\", \\\"{x:1162,y:561,t:1527009409534};\\\", \\\"{x:1137,y:561,t:1527009409550};\\\", \\\"{x:1115,y:559,t:1527009409567};\\\", \\\"{x:1105,y:557,t:1527009409583};\\\", \\\"{x:1096,y:551,t:1527009409601};\\\", \\\"{x:1093,y:548,t:1527009409618};\\\", \\\"{x:1091,y:546,t:1527009409634};\\\", \\\"{x:1089,y:545,t:1527009409651};\\\", \\\"{x:1089,y:544,t:1527009409667};\\\", \\\"{x:1088,y:540,t:1527009409683};\\\", \\\"{x:1085,y:536,t:1527009409701};\\\", \\\"{x:1081,y:527,t:1527009409718};\\\", \\\"{x:1081,y:519,t:1527009409733};\\\", \\\"{x:1080,y:510,t:1527009409751};\\\", \\\"{x:1080,y:506,t:1527009409768};\\\", \\\"{x:1080,y:502,t:1527009409784};\\\", \\\"{x:1083,y:495,t:1527009409801};\\\", \\\"{x:1087,y:491,t:1527009409818};\\\", \\\"{x:1090,y:488,t:1527009409834};\\\", \\\"{x:1092,y:486,t:1527009409851};\\\", \\\"{x:1093,y:485,t:1527009409868};\\\", \\\"{x:1094,y:484,t:1527009409888};\\\", \\\"{x:1095,y:483,t:1527009409901};\\\", \\\"{x:1096,y:483,t:1527009409918};\\\", \\\"{x:1102,y:481,t:1527009409935};\\\", \\\"{x:1108,y:481,t:1527009409951};\\\", \\\"{x:1122,y:481,t:1527009409968};\\\", \\\"{x:1131,y:482,t:1527009409985};\\\", \\\"{x:1144,y:485,t:1527009410001};\\\", \\\"{x:1161,y:489,t:1527009410018};\\\", \\\"{x:1182,y:492,t:1527009410035};\\\", \\\"{x:1200,y:493,t:1527009410051};\\\", \\\"{x:1219,y:495,t:1527009410068};\\\", \\\"{x:1241,y:495,t:1527009410085};\\\", \\\"{x:1255,y:495,t:1527009410101};\\\", \\\"{x:1266,y:495,t:1527009410118};\\\", \\\"{x:1279,y:495,t:1527009410135};\\\", \\\"{x:1292,y:495,t:1527009410151};\\\", \\\"{x:1321,y:495,t:1527009410168};\\\", \\\"{x:1349,y:493,t:1527009410185};\\\", \\\"{x:1374,y:493,t:1527009410201};\\\", \\\"{x:1395,y:493,t:1527009410218};\\\", \\\"{x:1402,y:493,t:1527009410235};\\\", \\\"{x:1405,y:493,t:1527009410251};\\\", \\\"{x:1402,y:493,t:1527009410385};\\\", \\\"{x:1388,y:495,t:1527009410402};\\\", \\\"{x:1372,y:497,t:1527009410418};\\\", \\\"{x:1351,y:498,t:1527009410435};\\\", \\\"{x:1338,y:500,t:1527009410452};\\\", \\\"{x:1318,y:500,t:1527009410469};\\\", \\\"{x:1309,y:499,t:1527009410485};\\\", \\\"{x:1306,y:498,t:1527009410504};\\\", \\\"{x:1305,y:497,t:1527009410649};\\\", \\\"{x:1306,y:497,t:1527009410809};\\\", \\\"{x:1307,y:497,t:1527009410819};\\\", \\\"{x:1312,y:501,t:1527009410836};\\\", \\\"{x:1316,y:508,t:1527009410853};\\\", \\\"{x:1320,y:516,t:1527009410869};\\\", \\\"{x:1323,y:524,t:1527009410886};\\\", \\\"{x:1325,y:531,t:1527009410902};\\\", \\\"{x:1327,y:539,t:1527009410919};\\\", \\\"{x:1329,y:549,t:1527009410936};\\\", \\\"{x:1329,y:561,t:1527009410953};\\\", \\\"{x:1331,y:573,t:1527009410969};\\\", \\\"{x:1333,y:585,t:1527009410985};\\\", \\\"{x:1337,y:598,t:1527009411002};\\\", \\\"{x:1339,y:611,t:1527009411018};\\\", \\\"{x:1342,y:625,t:1527009411035};\\\", \\\"{x:1342,y:641,t:1527009411052};\\\", \\\"{x:1342,y:652,t:1527009411069};\\\", \\\"{x:1342,y:659,t:1527009411085};\\\", \\\"{x:1343,y:665,t:1527009411102};\\\", \\\"{x:1343,y:668,t:1527009411119};\\\", \\\"{x:1343,y:669,t:1527009411136};\\\", \\\"{x:1343,y:670,t:1527009411313};\\\", \\\"{x:1342,y:666,t:1527009411329};\\\", \\\"{x:1342,y:661,t:1527009411336};\\\", \\\"{x:1342,y:639,t:1527009411353};\\\", \\\"{x:1337,y:614,t:1527009411370};\\\", \\\"{x:1328,y:587,t:1527009411386};\\\", \\\"{x:1318,y:553,t:1527009411402};\\\", \\\"{x:1306,y:516,t:1527009411419};\\\", \\\"{x:1303,y:491,t:1527009411436};\\\", \\\"{x:1297,y:475,t:1527009411452};\\\", \\\"{x:1296,y:471,t:1527009411469};\\\", \\\"{x:1295,y:470,t:1527009411488};\\\", \\\"{x:1295,y:472,t:1527009411544};\\\", \\\"{x:1295,y:478,t:1527009411553};\\\", \\\"{x:1296,y:490,t:1527009411569};\\\", \\\"{x:1301,y:505,t:1527009411586};\\\", \\\"{x:1305,y:513,t:1527009411603};\\\", \\\"{x:1310,y:524,t:1527009411619};\\\", \\\"{x:1313,y:531,t:1527009411636};\\\", \\\"{x:1316,y:535,t:1527009411653};\\\", \\\"{x:1316,y:540,t:1527009411668};\\\", \\\"{x:1317,y:544,t:1527009411686};\\\", \\\"{x:1317,y:548,t:1527009411703};\\\", \\\"{x:1318,y:551,t:1527009411719};\\\", \\\"{x:1319,y:553,t:1527009411736};\\\", \\\"{x:1320,y:556,t:1527009411753};\\\", \\\"{x:1320,y:557,t:1527009411769};\\\", \\\"{x:1320,y:561,t:1527009411786};\\\", \\\"{x:1320,y:565,t:1527009411803};\\\", \\\"{x:1320,y:568,t:1527009411819};\\\", \\\"{x:1320,y:571,t:1527009411836};\\\", \\\"{x:1320,y:575,t:1527009411854};\\\", \\\"{x:1321,y:579,t:1527009411869};\\\", \\\"{x:1322,y:584,t:1527009411886};\\\", \\\"{x:1322,y:589,t:1527009411903};\\\", \\\"{x:1324,y:593,t:1527009411920};\\\", \\\"{x:1324,y:595,t:1527009411936};\\\", \\\"{x:1324,y:599,t:1527009411953};\\\", \\\"{x:1324,y:600,t:1527009411970};\\\", \\\"{x:1324,y:603,t:1527009411986};\\\", \\\"{x:1324,y:605,t:1527009412003};\\\", \\\"{x:1324,y:606,t:1527009412020};\\\", \\\"{x:1324,y:608,t:1527009412036};\\\", \\\"{x:1324,y:611,t:1527009412053};\\\", \\\"{x:1324,y:614,t:1527009412070};\\\", \\\"{x:1324,y:619,t:1527009412085};\\\", \\\"{x:1324,y:622,t:1527009412103};\\\", \\\"{x:1323,y:630,t:1527009412120};\\\", \\\"{x:1321,y:637,t:1527009412136};\\\", \\\"{x:1320,y:644,t:1527009412153};\\\", \\\"{x:1319,y:650,t:1527009412170};\\\", \\\"{x:1316,y:663,t:1527009412186};\\\", \\\"{x:1312,y:672,t:1527009412203};\\\", \\\"{x:1310,y:678,t:1527009412219};\\\", \\\"{x:1310,y:682,t:1527009412236};\\\", \\\"{x:1310,y:689,t:1527009412253};\\\", \\\"{x:1308,y:694,t:1527009412270};\\\", \\\"{x:1307,y:699,t:1527009412286};\\\", \\\"{x:1307,y:706,t:1527009412303};\\\", \\\"{x:1306,y:717,t:1527009412320};\\\", \\\"{x:1306,y:723,t:1527009412337};\\\", \\\"{x:1308,y:736,t:1527009412354};\\\", \\\"{x:1309,y:747,t:1527009412370};\\\", \\\"{x:1312,y:758,t:1527009412386};\\\", \\\"{x:1313,y:767,t:1527009412403};\\\", \\\"{x:1317,y:779,t:1527009412420};\\\", \\\"{x:1320,y:789,t:1527009412437};\\\", \\\"{x:1324,y:801,t:1527009412453};\\\", \\\"{x:1327,y:810,t:1527009412470};\\\", \\\"{x:1329,y:820,t:1527009412487};\\\", \\\"{x:1334,y:832,t:1527009412503};\\\", \\\"{x:1340,y:848,t:1527009412520};\\\", \\\"{x:1342,y:852,t:1527009412537};\\\", \\\"{x:1344,y:857,t:1527009412553};\\\", \\\"{x:1346,y:860,t:1527009412570};\\\", \\\"{x:1346,y:861,t:1527009412587};\\\", \\\"{x:1346,y:863,t:1527009412603};\\\", \\\"{x:1346,y:864,t:1527009412632};\\\", \\\"{x:1346,y:865,t:1527009412648};\\\", \\\"{x:1346,y:866,t:1527009412656};\\\", \\\"{x:1346,y:867,t:1527009412671};\\\", \\\"{x:1346,y:868,t:1527009412688};\\\", \\\"{x:1345,y:870,t:1527009412703};\\\", \\\"{x:1340,y:880,t:1527009412720};\\\", \\\"{x:1336,y:889,t:1527009412737};\\\", \\\"{x:1334,y:898,t:1527009412754};\\\", \\\"{x:1332,y:908,t:1527009412770};\\\", \\\"{x:1326,y:918,t:1527009412787};\\\", \\\"{x:1325,y:924,t:1527009412804};\\\", \\\"{x:1323,y:931,t:1527009412820};\\\", \\\"{x:1319,y:936,t:1527009412837};\\\", \\\"{x:1319,y:939,t:1527009412855};\\\", \\\"{x:1318,y:942,t:1527009412870};\\\", \\\"{x:1318,y:944,t:1527009412887};\\\", \\\"{x:1318,y:945,t:1527009412904};\\\", \\\"{x:1318,y:946,t:1527009413024};\\\", \\\"{x:1318,y:947,t:1527009413057};\\\", \\\"{x:1318,y:948,t:1527009413081};\\\", \\\"{x:1318,y:949,t:1527009413089};\\\", \\\"{x:1318,y:951,t:1527009413104};\\\", \\\"{x:1317,y:951,t:1527009413121};\\\", \\\"{x:1316,y:952,t:1527009413137};\\\", \\\"{x:1316,y:955,t:1527009413156};\\\", \\\"{x:1316,y:956,t:1527009413192};\\\", \\\"{x:1316,y:958,t:1527009413217};\\\", \\\"{x:1314,y:958,t:1527009413905};\\\", \\\"{x:1314,y:959,t:1527009413921};\\\", \\\"{x:1311,y:960,t:1527009413939};\\\", \\\"{x:1307,y:961,t:1527009413956};\\\", \\\"{x:1304,y:962,t:1527009413971};\\\", \\\"{x:1302,y:962,t:1527009413989};\\\", \\\"{x:1300,y:964,t:1527009414006};\\\", \\\"{x:1299,y:964,t:1527009414021};\\\", \\\"{x:1300,y:963,t:1527009414561};\\\", \\\"{x:1332,y:936,t:1527009414572};\\\", \\\"{x:1503,y:774,t:1527009414588};\\\", \\\"{x:1694,y:564,t:1527009414605};\\\", \\\"{x:1825,y:381,t:1527009414622};\\\", \\\"{x:1902,y:218,t:1527009414638};\\\", \\\"{x:1919,y:60,t:1527009414655};\\\", \\\"{x:1919,y:0,t:1527009414672};\\\", \\\"{x:1915,y:0,t:1527009414704};\\\", \\\"{x:1902,y:0,t:1527009414721};\\\", \\\"{x:1888,y:0,t:1527009414738};\\\", \\\"{x:1878,y:0,t:1527009414754};\\\", \\\"{x:1861,y:7,t:1527009414771};\\\", \\\"{x:1842,y:19,t:1527009414788};\\\", \\\"{x:1824,y:37,t:1527009414804};\\\", \\\"{x:1809,y:55,t:1527009414821};\\\", \\\"{x:1802,y:67,t:1527009414838};\\\", \\\"{x:1802,y:68,t:1527009414855};\\\", \\\"{x:1802,y:69,t:1527009415608};\\\", \\\"{x:1800,y:71,t:1527009415632};\\\", \\\"{x:1797,y:72,t:1527009415641};\\\", \\\"{x:1795,y:74,t:1527009415656};\\\", \\\"{x:1795,y:75,t:1527009415744};\\\", \\\"{x:1793,y:76,t:1527009415755};\\\", \\\"{x:1788,y:76,t:1527009415772};\\\", \\\"{x:1780,y:78,t:1527009415788};\\\", \\\"{x:1776,y:79,t:1527009415805};\\\", \\\"{x:1766,y:81,t:1527009415822};\\\", \\\"{x:1760,y:83,t:1527009415838};\\\", \\\"{x:1754,y:85,t:1527009415854};\\\", \\\"{x:1746,y:88,t:1527009415871};\\\", \\\"{x:1740,y:91,t:1527009415888};\\\", \\\"{x:1730,y:96,t:1527009415904};\\\", \\\"{x:1724,y:98,t:1527009415922};\\\", \\\"{x:1723,y:99,t:1527009415944};\\\", \\\"{x:1722,y:100,t:1527009417073};\\\", \\\"{x:1722,y:102,t:1527009417088};\\\", \\\"{x:1722,y:106,t:1527009417104};\\\", \\\"{x:1722,y:110,t:1527009417120};\\\", \\\"{x:1722,y:112,t:1527009417137};\\\", \\\"{x:1722,y:117,t:1527009417155};\\\", \\\"{x:1723,y:122,t:1527009417171};\\\", \\\"{x:1724,y:127,t:1527009417188};\\\", \\\"{x:1726,y:132,t:1527009417204};\\\", \\\"{x:1728,y:143,t:1527009417221};\\\", \\\"{x:1732,y:164,t:1527009417238};\\\", \\\"{x:1737,y:195,t:1527009417255};\\\", \\\"{x:1737,y:237,t:1527009417271};\\\", \\\"{x:1738,y:276,t:1527009417287};\\\", \\\"{x:1732,y:368,t:1527009417304};\\\", \\\"{x:1715,y:452,t:1527009417320};\\\", \\\"{x:1703,y:525,t:1527009417338};\\\", \\\"{x:1687,y:576,t:1527009417358};\\\", \\\"{x:1682,y:607,t:1527009417370};\\\", \\\"{x:1681,y:622,t:1527009417387};\\\", \\\"{x:1681,y:626,t:1527009417404};\\\", \\\"{x:1681,y:627,t:1527009417456};\\\", \\\"{x:1678,y:629,t:1527009417470};\\\", \\\"{x:1675,y:651,t:1527009417487};\\\", \\\"{x:1671,y:664,t:1527009417504};\\\", \\\"{x:1671,y:667,t:1527009417521};\\\", \\\"{x:1671,y:668,t:1527009417537};\\\", \\\"{x:1670,y:668,t:1527009417584};\\\", \\\"{x:1670,y:669,t:1527009417680};\\\", \\\"{x:1668,y:673,t:1527009417688};\\\", \\\"{x:1666,y:676,t:1527009417704};\\\", \\\"{x:1665,y:678,t:1527009417721};\\\", \\\"{x:1664,y:679,t:1527009417744};\\\", \\\"{x:1663,y:680,t:1527009417769};\\\", \\\"{x:1663,y:681,t:1527009417776};\\\", \\\"{x:1662,y:685,t:1527009417788};\\\", \\\"{x:1660,y:690,t:1527009417803};\\\", \\\"{x:1653,y:702,t:1527009417820};\\\", \\\"{x:1644,y:724,t:1527009417838};\\\", \\\"{x:1632,y:761,t:1527009417854};\\\", \\\"{x:1616,y:799,t:1527009417871};\\\", \\\"{x:1604,y:867,t:1527009417887};\\\", \\\"{x:1603,y:923,t:1527009417904};\\\", \\\"{x:1590,y:985,t:1527009417921};\\\", \\\"{x:1580,y:1018,t:1527009417938};\\\", \\\"{x:1563,y:1045,t:1527009417956};\\\", \\\"{x:1550,y:1068,t:1527009417971};\\\", \\\"{x:1539,y:1083,t:1527009417987};\\\", \\\"{x:1531,y:1091,t:1527009418003};\\\", \\\"{x:1527,y:1095,t:1527009418020};\\\", \\\"{x:1524,y:1097,t:1527009418038};\\\", \\\"{x:1520,y:1099,t:1527009418054};\\\", \\\"{x:1517,y:1100,t:1527009418070};\\\", \\\"{x:1516,y:1100,t:1527009418088};\\\", \\\"{x:1514,y:1099,t:1527009418105};\\\", \\\"{x:1514,y:1091,t:1527009418120};\\\", \\\"{x:1514,y:1081,t:1527009418138};\\\", \\\"{x:1514,y:1067,t:1527009418155};\\\", \\\"{x:1515,y:1051,t:1527009418171};\\\", \\\"{x:1516,y:1038,t:1527009418188};\\\", \\\"{x:1521,y:1021,t:1527009418204};\\\", \\\"{x:1526,y:1008,t:1527009418220};\\\", \\\"{x:1526,y:1001,t:1527009418238};\\\", \\\"{x:1526,y:993,t:1527009418254};\\\", \\\"{x:1526,y:982,t:1527009418271};\\\", \\\"{x:1526,y:966,t:1527009418288};\\\", \\\"{x:1526,y:958,t:1527009418304};\\\", \\\"{x:1526,y:929,t:1527009418320};\\\", \\\"{x:1522,y:912,t:1527009418338};\\\", \\\"{x:1519,y:893,t:1527009418356};\\\", \\\"{x:1517,y:879,t:1527009418370};\\\", \\\"{x:1517,y:872,t:1527009418387};\\\", \\\"{x:1517,y:870,t:1527009418403};\\\", \\\"{x:1517,y:869,t:1527009418424};\\\", \\\"{x:1517,y:868,t:1527009418439};\\\", \\\"{x:1517,y:867,t:1527009418453};\\\", \\\"{x:1517,y:864,t:1527009418470};\\\", \\\"{x:1517,y:863,t:1527009418487};\\\", \\\"{x:1517,y:859,t:1527009418503};\\\", \\\"{x:1516,y:855,t:1527009418520};\\\", \\\"{x:1516,y:850,t:1527009418536};\\\", \\\"{x:1516,y:845,t:1527009418554};\\\", \\\"{x:1517,y:839,t:1527009418570};\\\", \\\"{x:1518,y:833,t:1527009418586};\\\", \\\"{x:1519,y:827,t:1527009418603};\\\", \\\"{x:1521,y:825,t:1527009418620};\\\", \\\"{x:1522,y:821,t:1527009418636};\\\", \\\"{x:1523,y:816,t:1527009418653};\\\", \\\"{x:1523,y:814,t:1527009418670};\\\", \\\"{x:1525,y:811,t:1527009418686};\\\", \\\"{x:1525,y:805,t:1527009418704};\\\", \\\"{x:1525,y:796,t:1527009418720};\\\", \\\"{x:1527,y:788,t:1527009418736};\\\", \\\"{x:1529,y:783,t:1527009418755};\\\", \\\"{x:1529,y:781,t:1527009418770};\\\", \\\"{x:1529,y:779,t:1527009418787};\\\", \\\"{x:1529,y:776,t:1527009418803};\\\", \\\"{x:1529,y:774,t:1527009418821};\\\", \\\"{x:1530,y:770,t:1527009418836};\\\", \\\"{x:1530,y:765,t:1527009418854};\\\", \\\"{x:1530,y:762,t:1527009418871};\\\", \\\"{x:1531,y:757,t:1527009418887};\\\", \\\"{x:1531,y:756,t:1527009418904};\\\", \\\"{x:1531,y:751,t:1527009418920};\\\", \\\"{x:1533,y:742,t:1527009418937};\\\", \\\"{x:1533,y:741,t:1527009418956};\\\", \\\"{x:1533,y:736,t:1527009418971};\\\", \\\"{x:1533,y:733,t:1527009418987};\\\", \\\"{x:1534,y:729,t:1527009419004};\\\", \\\"{x:1534,y:727,t:1527009419021};\\\", \\\"{x:1534,y:725,t:1527009419036};\\\", \\\"{x:1534,y:722,t:1527009419054};\\\", \\\"{x:1534,y:719,t:1527009419071};\\\", \\\"{x:1534,y:716,t:1527009419087};\\\", \\\"{x:1535,y:713,t:1527009419104};\\\", \\\"{x:1535,y:712,t:1527009419128};\\\", \\\"{x:1535,y:710,t:1527009419160};\\\", \\\"{x:1535,y:709,t:1527009419193};\\\", \\\"{x:1535,y:707,t:1527009419225};\\\", \\\"{x:1535,y:705,t:1527009419241};\\\", \\\"{x:1535,y:704,t:1527009419254};\\\", \\\"{x:1535,y:703,t:1527009419289};\\\", \\\"{x:1535,y:702,t:1527009419305};\\\", \\\"{x:1535,y:701,t:1527009419319};\\\", \\\"{x:1535,y:699,t:1527009419337};\\\", \\\"{x:1535,y:697,t:1527009419357};\\\", \\\"{x:1535,y:695,t:1527009419369};\\\", \\\"{x:1535,y:694,t:1527009419387};\\\", \\\"{x:1535,y:693,t:1527009419404};\\\", \\\"{x:1535,y:692,t:1527009419420};\\\", \\\"{x:1533,y:689,t:1527009419437};\\\", \\\"{x:1533,y:686,t:1527009419454};\\\", \\\"{x:1533,y:683,t:1527009419470};\\\", \\\"{x:1532,y:679,t:1527009419487};\\\", \\\"{x:1532,y:677,t:1527009419504};\\\", \\\"{x:1532,y:674,t:1527009419520};\\\", \\\"{x:1532,y:671,t:1527009419536};\\\", \\\"{x:1532,y:670,t:1527009419556};\\\", \\\"{x:1532,y:668,t:1527009419570};\\\", \\\"{x:1533,y:665,t:1527009419587};\\\", \\\"{x:1533,y:664,t:1527009419604};\\\", \\\"{x:1533,y:663,t:1527009419624};\\\", \\\"{x:1533,y:662,t:1527009419729};\\\", \\\"{x:1533,y:661,t:1527009419737};\\\", \\\"{x:1533,y:660,t:1527009419756};\\\", \\\"{x:1534,y:659,t:1527009419770};\\\", \\\"{x:1534,y:658,t:1527009419787};\\\", \\\"{x:1536,y:657,t:1527009419804};\\\", \\\"{x:1537,y:656,t:1527009419848};\\\", \\\"{x:1537,y:655,t:1527009420209};\\\", \\\"{x:1538,y:656,t:1527009420220};\\\", \\\"{x:1542,y:667,t:1527009420237};\\\", \\\"{x:1545,y:681,t:1527009420253};\\\", \\\"{x:1547,y:692,t:1527009420270};\\\", \\\"{x:1550,y:707,t:1527009420287};\\\", \\\"{x:1551,y:717,t:1527009420303};\\\", \\\"{x:1552,y:722,t:1527009420319};\\\", \\\"{x:1555,y:730,t:1527009420336};\\\", \\\"{x:1555,y:732,t:1527009420354};\\\", \\\"{x:1558,y:738,t:1527009420370};\\\", \\\"{x:1562,y:743,t:1527009420387};\\\", \\\"{x:1562,y:748,t:1527009420403};\\\", \\\"{x:1562,y:755,t:1527009420420};\\\", \\\"{x:1564,y:759,t:1527009420437};\\\", \\\"{x:1564,y:763,t:1527009420453};\\\", \\\"{x:1565,y:766,t:1527009420470};\\\", \\\"{x:1566,y:769,t:1527009420487};\\\", \\\"{x:1566,y:771,t:1527009420503};\\\", \\\"{x:1567,y:776,t:1527009420520};\\\", \\\"{x:1570,y:786,t:1527009420536};\\\", \\\"{x:1570,y:796,t:1527009420554};\\\", \\\"{x:1570,y:807,t:1527009420570};\\\", \\\"{x:1571,y:820,t:1527009420587};\\\", \\\"{x:1571,y:832,t:1527009420604};\\\", \\\"{x:1571,y:839,t:1527009420620};\\\", \\\"{x:1571,y:848,t:1527009420637};\\\", \\\"{x:1571,y:852,t:1527009420653};\\\", \\\"{x:1571,y:862,t:1527009420670};\\\", \\\"{x:1570,y:872,t:1527009420687};\\\", \\\"{x:1569,y:885,t:1527009420703};\\\", \\\"{x:1568,y:893,t:1527009420720};\\\", \\\"{x:1566,y:905,t:1527009420736};\\\", \\\"{x:1566,y:912,t:1527009420753};\\\", \\\"{x:1565,y:918,t:1527009420770};\\\", \\\"{x:1565,y:923,t:1527009420787};\\\", \\\"{x:1565,y:930,t:1527009420803};\\\", \\\"{x:1565,y:932,t:1527009420820};\\\", \\\"{x:1566,y:934,t:1527009420837};\\\", \\\"{x:1566,y:938,t:1527009420854};\\\", \\\"{x:1566,y:943,t:1527009420870};\\\", \\\"{x:1566,y:949,t:1527009420887};\\\", \\\"{x:1566,y:952,t:1527009420903};\\\", \\\"{x:1566,y:954,t:1527009420920};\\\", \\\"{x:1566,y:955,t:1527009420936};\\\", \\\"{x:1566,y:956,t:1527009420953};\\\", \\\"{x:1564,y:961,t:1527009420970};\\\", \\\"{x:1561,y:966,t:1527009420987};\\\", \\\"{x:1561,y:967,t:1527009421003};\\\", \\\"{x:1560,y:967,t:1527009421209};\\\", \\\"{x:1558,y:967,t:1527009421232};\\\", \\\"{x:1558,y:966,t:1527009421240};\\\", \\\"{x:1556,y:963,t:1527009421253};\\\", \\\"{x:1556,y:961,t:1527009421271};\\\", \\\"{x:1556,y:959,t:1527009421286};\\\", \\\"{x:1554,y:957,t:1527009421303};\\\", \\\"{x:1554,y:956,t:1527009421320};\\\", \\\"{x:1553,y:954,t:1527009421336};\\\", \\\"{x:1552,y:954,t:1527009421353};\\\", \\\"{x:1552,y:951,t:1527009421415};\\\", \\\"{x:1551,y:950,t:1527009421423};\\\", \\\"{x:1551,y:948,t:1527009421447};\\\", \\\"{x:1551,y:947,t:1527009421464};\\\", \\\"{x:1550,y:945,t:1527009421496};\\\", \\\"{x:1550,y:944,t:1527009421528};\\\", \\\"{x:1550,y:942,t:1527009421544};\\\", \\\"{x:1550,y:941,t:1527009421568};\\\", \\\"{x:1549,y:940,t:1527009421584};\\\", \\\"{x:1548,y:937,t:1527009421769};\\\", \\\"{x:1548,y:935,t:1527009421808};\\\", \\\"{x:1548,y:934,t:1527009421819};\\\", \\\"{x:1548,y:931,t:1527009421836};\\\", \\\"{x:1547,y:929,t:1527009421853};\\\", \\\"{x:1547,y:928,t:1527009421869};\\\", \\\"{x:1547,y:924,t:1527009421886};\\\", \\\"{x:1545,y:921,t:1527009421903};\\\", \\\"{x:1545,y:920,t:1527009421919};\\\", \\\"{x:1545,y:918,t:1527009421936};\\\", \\\"{x:1545,y:917,t:1527009421953};\\\", \\\"{x:1545,y:916,t:1527009421985};\\\", \\\"{x:1545,y:914,t:1527009421992};\\\", \\\"{x:1545,y:913,t:1527009422003};\\\", \\\"{x:1545,y:911,t:1527009422019};\\\", \\\"{x:1544,y:907,t:1527009422036};\\\", \\\"{x:1544,y:905,t:1527009422052};\\\", \\\"{x:1544,y:904,t:1527009422069};\\\", \\\"{x:1544,y:903,t:1527009422086};\\\", \\\"{x:1544,y:902,t:1527009422145};\\\", \\\"{x:1544,y:900,t:1527009422416};\\\", \\\"{x:1544,y:896,t:1527009422423};\\\", \\\"{x:1542,y:889,t:1527009422436};\\\", \\\"{x:1539,y:877,t:1527009422452};\\\", \\\"{x:1537,y:866,t:1527009422468};\\\", \\\"{x:1534,y:859,t:1527009422485};\\\", \\\"{x:1534,y:855,t:1527009422502};\\\", \\\"{x:1531,y:850,t:1527009422519};\\\", \\\"{x:1531,y:848,t:1527009422536};\\\", \\\"{x:1529,y:846,t:1527009422552};\\\", \\\"{x:1529,y:845,t:1527009422568};\\\", \\\"{x:1529,y:842,t:1527009422586};\\\", \\\"{x:1529,y:841,t:1527009422602};\\\", \\\"{x:1529,y:839,t:1527009422618};\\\", \\\"{x:1528,y:838,t:1527009422635};\\\", \\\"{x:1528,y:836,t:1527009422653};\\\", \\\"{x:1528,y:835,t:1527009422669};\\\", \\\"{x:1528,y:832,t:1527009422685};\\\", \\\"{x:1528,y:829,t:1527009422702};\\\", \\\"{x:1527,y:823,t:1527009422718};\\\", \\\"{x:1527,y:819,t:1527009422736};\\\", \\\"{x:1527,y:814,t:1527009422752};\\\", \\\"{x:1527,y:809,t:1527009422769};\\\", \\\"{x:1528,y:804,t:1527009422786};\\\", \\\"{x:1528,y:802,t:1527009422802};\\\", \\\"{x:1529,y:797,t:1527009422818};\\\", \\\"{x:1530,y:795,t:1527009422836};\\\", \\\"{x:1531,y:793,t:1527009422852};\\\", \\\"{x:1531,y:791,t:1527009422869};\\\", \\\"{x:1533,y:790,t:1527009422886};\\\", \\\"{x:1534,y:789,t:1527009422902};\\\", \\\"{x:1534,y:788,t:1527009422919};\\\", \\\"{x:1534,y:787,t:1527009422936};\\\", \\\"{x:1535,y:786,t:1527009423080};\\\", \\\"{x:1535,y:785,t:1527009423249};\\\", \\\"{x:1535,y:784,t:1527009423256};\\\", \\\"{x:1535,y:783,t:1527009423269};\\\", \\\"{x:1535,y:779,t:1527009423286};\\\", \\\"{x:1535,y:777,t:1527009423302};\\\", \\\"{x:1535,y:773,t:1527009423320};\\\", \\\"{x:1535,y:770,t:1527009423336};\\\", \\\"{x:1535,y:769,t:1527009423432};\\\", \\\"{x:1525,y:759,t:1527009456986};\\\", \\\"{x:1484,y:734,t:1527009457000};\\\", \\\"{x:1307,y:689,t:1527009457017};\\\", \\\"{x:989,y:692,t:1527009457033};\\\", \\\"{x:799,y:738,t:1527009457049};\\\", \\\"{x:668,y:778,t:1527009457066};\\\", \\\"{x:635,y:792,t:1527009457084};\\\", \\\"{x:634,y:793,t:1527009457100};\\\", \\\"{x:633,y:791,t:1527009457266};\\\", \\\"{x:618,y:761,t:1527009457283};\\\", \\\"{x:600,y:743,t:1527009457299};\\\", \\\"{x:554,y:722,t:1527009457318};\\\", \\\"{x:498,y:705,t:1527009457333};\\\", \\\"{x:409,y:690,t:1527009457349};\\\", \\\"{x:323,y:681,t:1527009457366};\\\", \\\"{x:267,y:681,t:1527009457382};\\\", \\\"{x:255,y:681,t:1527009457399};\\\", \\\"{x:255,y:684,t:1527009457513};\\\", \\\"{x:264,y:690,t:1527009457520};\\\", \\\"{x:274,y:694,t:1527009457532};\\\", \\\"{x:305,y:704,t:1527009457549};\\\", \\\"{x:354,y:715,t:1527009457566};\\\", \\\"{x:429,y:725,t:1527009457583};\\\", \\\"{x:478,y:727,t:1527009457600};\\\", \\\"{x:498,y:727,t:1527009457616};\\\", \\\"{x:500,y:727,t:1527009457633};\\\", \\\"{x:501,y:727,t:1527009457952};\\\", \\\"{x:501,y:728,t:1527009458024};\\\", \\\"{x:503,y:734,t:1527009458033};\\\", \\\"{x:515,y:756,t:1527009458050};\\\", \\\"{x:539,y:786,t:1527009458066};\\\", \\\"{x:606,y:830,t:1527009458083};\\\", \\\"{x:708,y:890,t:1527009458100};\\\", \\\"{x:813,y:966,t:1527009458116};\\\", \\\"{x:922,y:1043,t:1527009458133};\\\", \\\"{x:1009,y:1112,t:1527009458150};\\\", \\\"{x:1064,y:1169,t:1527009458166};\\\", \\\"{x:1098,y:1199,t:1527009458184};\\\", \\\"{x:1116,y:1199,t:1527009458200};\\\", \\\"{x:1119,y:1199,t:1527009458217};\\\", \\\"{x:1114,y:1199,t:1527009458256};\\\", \\\"{x:1107,y:1199,t:1527009458266};\\\", \\\"{x:1105,y:1199,t:1527009458283};\\\", \\\"{x:1104,y:1198,t:1527009459088};\\\" ] }, { \\\"rt\\\": 8267, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 623910, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1103,y:1197,t:1527009460961};\\\", \\\"{x:1102,y:1197,t:1527009461010};\\\", \\\"{x:1101,y:1196,t:1527009461049};\\\", \\\"{x:1101,y:1195,t:1527009461938};\\\", \\\"{x:1109,y:1186,t:1527009461953};\\\", \\\"{x:1130,y:1171,t:1527009461971};\\\", \\\"{x:1165,y:1155,t:1527009461986};\\\", \\\"{x:1175,y:1153,t:1527009462003};\\\", \\\"{x:1178,y:1155,t:1527009462020};\\\", \\\"{x:1178,y:1153,t:1527009462049};\\\", \\\"{x:1178,y:1149,t:1527009462057};\\\", \\\"{x:1179,y:1145,t:1527009462070};\\\", \\\"{x:1184,y:1135,t:1527009462086};\\\", \\\"{x:1187,y:1129,t:1527009462103};\\\", \\\"{x:1189,y:1120,t:1527009462120};\\\", \\\"{x:1198,y:1086,t:1527009462136};\\\", \\\"{x:1205,y:1060,t:1527009462154};\\\", \\\"{x:1214,y:1028,t:1527009462170};\\\", \\\"{x:1221,y:977,t:1527009462187};\\\", \\\"{x:1234,y:901,t:1527009462204};\\\", \\\"{x:1248,y:810,t:1527009462220};\\\", \\\"{x:1250,y:729,t:1527009462237};\\\", \\\"{x:1254,y:677,t:1527009462253};\\\", \\\"{x:1256,y:612,t:1527009462270};\\\", \\\"{x:1256,y:576,t:1527009462287};\\\", \\\"{x:1256,y:552,t:1527009462304};\\\", \\\"{x:1257,y:536,t:1527009462320};\\\", \\\"{x:1260,y:524,t:1527009462336};\\\", \\\"{x:1265,y:509,t:1527009462353};\\\", \\\"{x:1270,y:495,t:1527009462370};\\\", \\\"{x:1272,y:483,t:1527009462387};\\\", \\\"{x:1280,y:475,t:1527009462403};\\\", \\\"{x:1280,y:474,t:1527009462420};\\\", \\\"{x:1287,y:473,t:1527009462437};\\\", \\\"{x:1292,y:471,t:1527009462453};\\\", \\\"{x:1297,y:471,t:1527009462471};\\\", \\\"{x:1308,y:474,t:1527009462487};\\\", \\\"{x:1318,y:483,t:1527009462504};\\\", \\\"{x:1348,y:508,t:1527009462521};\\\", \\\"{x:1366,y:526,t:1527009462537};\\\", \\\"{x:1385,y:540,t:1527009462554};\\\", \\\"{x:1397,y:550,t:1527009462571};\\\", \\\"{x:1401,y:552,t:1527009462587};\\\", \\\"{x:1402,y:553,t:1527009462604};\\\", \\\"{x:1403,y:553,t:1527009462625};\\\", \\\"{x:1403,y:555,t:1527009462890};\\\", \\\"{x:1403,y:564,t:1527009462904};\\\", \\\"{x:1403,y:599,t:1527009462921};\\\", \\\"{x:1389,y:627,t:1527009462937};\\\", \\\"{x:1361,y:665,t:1527009462954};\\\", \\\"{x:1331,y:686,t:1527009462971};\\\", \\\"{x:1255,y:707,t:1527009462988};\\\", \\\"{x:1111,y:726,t:1527009463004};\\\", \\\"{x:944,y:735,t:1527009463021};\\\", \\\"{x:770,y:734,t:1527009463038};\\\", \\\"{x:628,y:727,t:1527009463054};\\\", \\\"{x:529,y:722,t:1527009463073};\\\", \\\"{x:491,y:716,t:1527009463088};\\\", \\\"{x:474,y:714,t:1527009463103};\\\", \\\"{x:472,y:713,t:1527009463120};\\\", \\\"{x:471,y:713,t:1527009463176};\\\", \\\"{x:471,y:711,t:1527009463187};\\\", \\\"{x:473,y:697,t:1527009463205};\\\", \\\"{x:477,y:686,t:1527009463221};\\\", \\\"{x:481,y:675,t:1527009463237};\\\", \\\"{x:483,y:663,t:1527009463255};\\\", \\\"{x:488,y:652,t:1527009463270};\\\", \\\"{x:490,y:646,t:1527009463287};\\\", \\\"{x:494,y:635,t:1527009463305};\\\", \\\"{x:495,y:628,t:1527009463321};\\\", \\\"{x:498,y:622,t:1527009463337};\\\", \\\"{x:498,y:620,t:1527009463354};\\\", \\\"{x:498,y:613,t:1527009463370};\\\", \\\"{x:498,y:603,t:1527009463387};\\\", \\\"{x:498,y:597,t:1527009463405};\\\", \\\"{x:498,y:595,t:1527009463421};\\\", \\\"{x:498,y:592,t:1527009463438};\\\", \\\"{x:498,y:589,t:1527009463455};\\\", \\\"{x:497,y:588,t:1527009463488};\\\", \\\"{x:494,y:586,t:1527009463504};\\\", \\\"{x:486,y:581,t:1527009463520};\\\", \\\"{x:471,y:576,t:1527009463537};\\\", \\\"{x:461,y:571,t:1527009463554};\\\", \\\"{x:451,y:570,t:1527009463570};\\\", \\\"{x:445,y:567,t:1527009463588};\\\", \\\"{x:444,y:567,t:1527009463605};\\\", \\\"{x:444,y:566,t:1527009463621};\\\", \\\"{x:443,y:565,t:1527009463638};\\\", \\\"{x:443,y:560,t:1527009463656};\\\", \\\"{x:443,y:557,t:1527009463672};\\\", \\\"{x:443,y:550,t:1527009463688};\\\", \\\"{x:456,y:535,t:1527009463704};\\\", \\\"{x:475,y:523,t:1527009463722};\\\", \\\"{x:494,y:511,t:1527009463738};\\\", \\\"{x:516,y:505,t:1527009463754};\\\", \\\"{x:536,y:502,t:1527009463772};\\\", \\\"{x:542,y:503,t:1527009463787};\\\", \\\"{x:552,y:503,t:1527009463804};\\\", \\\"{x:560,y:503,t:1527009463821};\\\", \\\"{x:564,y:503,t:1527009463837};\\\", \\\"{x:565,y:503,t:1527009463857};\\\", \\\"{x:566,y:503,t:1527009463897};\\\", \\\"{x:567,y:502,t:1527009463904};\\\", \\\"{x:573,y:500,t:1527009463922};\\\", \\\"{x:576,y:499,t:1527009463938};\\\", \\\"{x:581,y:496,t:1527009463954};\\\", \\\"{x:584,y:495,t:1527009463971};\\\", \\\"{x:586,y:494,t:1527009463988};\\\", \\\"{x:588,y:492,t:1527009464004};\\\", \\\"{x:593,y:491,t:1527009464021};\\\", \\\"{x:594,y:490,t:1527009464038};\\\", \\\"{x:597,y:490,t:1527009464055};\\\", \\\"{x:601,y:490,t:1527009464072};\\\", \\\"{x:603,y:490,t:1527009464088};\\\", \\\"{x:604,y:490,t:1527009464194};\\\", \\\"{x:600,y:493,t:1527009464401};\\\", \\\"{x:598,y:494,t:1527009464408};\\\", \\\"{x:598,y:495,t:1527009464421};\\\", \\\"{x:597,y:496,t:1527009464438};\\\", \\\"{x:597,y:497,t:1527009464456};\\\", \\\"{x:603,y:499,t:1527009464472};\\\", \\\"{x:681,y:514,t:1527009464489};\\\", \\\"{x:776,y:533,t:1527009464506};\\\", \\\"{x:796,y:537,t:1527009464522};\\\", \\\"{x:837,y:539,t:1527009464539};\\\", \\\"{x:845,y:544,t:1527009464556};\\\", \\\"{x:846,y:544,t:1527009464571};\\\", \\\"{x:844,y:553,t:1527009465082};\\\", \\\"{x:834,y:560,t:1527009465090};\\\", \\\"{x:803,y:598,t:1527009465105};\\\", \\\"{x:759,y:648,t:1527009465122};\\\", \\\"{x:721,y:701,t:1527009465138};\\\", \\\"{x:691,y:746,t:1527009465156};\\\", \\\"{x:659,y:782,t:1527009465173};\\\", \\\"{x:632,y:811,t:1527009465188};\\\", \\\"{x:614,y:828,t:1527009465206};\\\", \\\"{x:603,y:839,t:1527009465223};\\\", \\\"{x:592,y:845,t:1527009465239};\\\", \\\"{x:584,y:848,t:1527009465255};\\\", \\\"{x:582,y:849,t:1527009465273};\\\", \\\"{x:579,y:849,t:1527009465290};\\\", \\\"{x:579,y:850,t:1527009465306};\\\", \\\"{x:578,y:850,t:1527009465323};\\\", \\\"{x:575,y:850,t:1527009465340};\\\", \\\"{x:570,y:839,t:1527009465355};\\\", \\\"{x:562,y:822,t:1527009465373};\\\", \\\"{x:555,y:804,t:1527009465390};\\\", \\\"{x:545,y:784,t:1527009465406};\\\", \\\"{x:538,y:765,t:1527009465423};\\\", \\\"{x:533,y:753,t:1527009465440};\\\", \\\"{x:532,y:741,t:1527009465456};\\\", \\\"{x:532,y:733,t:1527009465472};\\\", \\\"{x:532,y:731,t:1527009465489};\\\", \\\"{x:532,y:730,t:1527009467896};\\\", \\\"{x:545,y:729,t:1527009467908};\\\", \\\"{x:592,y:729,t:1527009467924};\\\", \\\"{x:689,y:742,t:1527009467942};\\\", \\\"{x:786,y:754,t:1527009467957};\\\", \\\"{x:906,y:772,t:1527009467975};\\\", \\\"{x:1056,y:798,t:1527009467992};\\\", \\\"{x:1191,y:832,t:1527009468008};\\\", \\\"{x:1318,y:868,t:1527009468024};\\\", \\\"{x:1341,y:876,t:1527009468042};\\\", \\\"{x:1342,y:877,t:1527009468058};\\\", \\\"{x:1343,y:878,t:1527009468872};\\\", \\\"{x:1343,y:879,t:1527009468904};\\\", \\\"{x:1342,y:881,t:1527009468912};\\\" ] }, { \\\"rt\\\": 18309, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 643440, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -Z -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1315,y:909,t:1527009469021};\\\", \\\"{x:1311,y:912,t:1527009469028};\\\", \\\"{x:1304,y:919,t:1527009469045};\\\", \\\"{x:1295,y:926,t:1527009469059};\\\", \\\"{x:1287,y:932,t:1527009469076};\\\", \\\"{x:1283,y:936,t:1527009469092};\\\", \\\"{x:1283,y:937,t:1527009469112};\\\", \\\"{x:1281,y:937,t:1527009469136};\\\", \\\"{x:1279,y:938,t:1527009469168};\\\", \\\"{x:1278,y:938,t:1527009469209};\\\", \\\"{x:1272,y:942,t:1527009470162};\\\", \\\"{x:1252,y:951,t:1527009470184};\\\", \\\"{x:1232,y:957,t:1527009470193};\\\", \\\"{x:1233,y:957,t:1527009471073};\\\", \\\"{x:1233,y:955,t:1527009471089};\\\", \\\"{x:1234,y:954,t:1527009471097};\\\", \\\"{x:1234,y:953,t:1527009471129};\\\", \\\"{x:1235,y:953,t:1527009471144};\\\", \\\"{x:1235,y:952,t:1527009471162};\\\", \\\"{x:1235,y:951,t:1527009471194};\\\", \\\"{x:1236,y:949,t:1527009471212};\\\", \\\"{x:1237,y:946,t:1527009471227};\\\", \\\"{x:1238,y:942,t:1527009471244};\\\", \\\"{x:1240,y:937,t:1527009471262};\\\", \\\"{x:1242,y:932,t:1527009471278};\\\", \\\"{x:1243,y:923,t:1527009471295};\\\", \\\"{x:1247,y:911,t:1527009471312};\\\", \\\"{x:1249,y:899,t:1527009471328};\\\", \\\"{x:1252,y:884,t:1527009471345};\\\", \\\"{x:1258,y:863,t:1527009471361};\\\", \\\"{x:1260,y:854,t:1527009471378};\\\", \\\"{x:1262,y:839,t:1527009471394};\\\", \\\"{x:1263,y:820,t:1527009471412};\\\", \\\"{x:1263,y:807,t:1527009471428};\\\", \\\"{x:1265,y:794,t:1527009471445};\\\", \\\"{x:1264,y:780,t:1527009471460};\\\", \\\"{x:1260,y:774,t:1527009471478};\\\", \\\"{x:1258,y:770,t:1527009471493};\\\", \\\"{x:1257,y:767,t:1527009471510};\\\", \\\"{x:1256,y:764,t:1527009471527};\\\", \\\"{x:1255,y:762,t:1527009471544};\\\", \\\"{x:1253,y:758,t:1527009471561};\\\", \\\"{x:1252,y:755,t:1527009471578};\\\", \\\"{x:1250,y:753,t:1527009471594};\\\", \\\"{x:1249,y:751,t:1527009471611};\\\", \\\"{x:1247,y:750,t:1527009471628};\\\", \\\"{x:1246,y:749,t:1527009471644};\\\", \\\"{x:1240,y:749,t:1527009471661};\\\", \\\"{x:1236,y:749,t:1527009471678};\\\", \\\"{x:1232,y:748,t:1527009471694};\\\", \\\"{x:1232,y:747,t:1527009472138};\\\", \\\"{x:1233,y:744,t:1527009472145};\\\", \\\"{x:1239,y:742,t:1527009472161};\\\", \\\"{x:1250,y:737,t:1527009472179};\\\", \\\"{x:1255,y:735,t:1527009472195};\\\", \\\"{x:1257,y:734,t:1527009472212};\\\", \\\"{x:1258,y:734,t:1527009472642};\\\", \\\"{x:1259,y:734,t:1527009472657};\\\", \\\"{x:1260,y:734,t:1527009472665};\\\", \\\"{x:1262,y:732,t:1527009472678};\\\", \\\"{x:1265,y:729,t:1527009472695};\\\", \\\"{x:1267,y:725,t:1527009472712};\\\", \\\"{x:1271,y:721,t:1527009472729};\\\", \\\"{x:1274,y:715,t:1527009472745};\\\", \\\"{x:1278,y:710,t:1527009472762};\\\", \\\"{x:1286,y:703,t:1527009472778};\\\", \\\"{x:1288,y:699,t:1527009472795};\\\", \\\"{x:1290,y:695,t:1527009472812};\\\", \\\"{x:1293,y:693,t:1527009472828};\\\", \\\"{x:1295,y:689,t:1527009472846};\\\", \\\"{x:1296,y:686,t:1527009472862};\\\", \\\"{x:1299,y:681,t:1527009472879};\\\", \\\"{x:1301,y:679,t:1527009472895};\\\", \\\"{x:1301,y:678,t:1527009472913};\\\", \\\"{x:1304,y:675,t:1527009473602};\\\", \\\"{x:1307,y:672,t:1527009473613};\\\", \\\"{x:1312,y:667,t:1527009473630};\\\", \\\"{x:1321,y:659,t:1527009473647};\\\", \\\"{x:1332,y:652,t:1527009473662};\\\", \\\"{x:1339,y:645,t:1527009473680};\\\", \\\"{x:1372,y:628,t:1527009473697};\\\", \\\"{x:1455,y:614,t:1527009473713};\\\", \\\"{x:1527,y:606,t:1527009473730};\\\", \\\"{x:1587,y:600,t:1527009473747};\\\", \\\"{x:1615,y:599,t:1527009473763};\\\", \\\"{x:1630,y:601,t:1527009473780};\\\", \\\"{x:1632,y:601,t:1527009473796};\\\", \\\"{x:1632,y:602,t:1527009473977};\\\", \\\"{x:1630,y:604,t:1527009473985};\\\", \\\"{x:1628,y:605,t:1527009473997};\\\", \\\"{x:1624,y:609,t:1527009474014};\\\", \\\"{x:1621,y:611,t:1527009474030};\\\", \\\"{x:1618,y:613,t:1527009474047};\\\", \\\"{x:1616,y:616,t:1527009474063};\\\", \\\"{x:1613,y:619,t:1527009474080};\\\", \\\"{x:1609,y:623,t:1527009474096};\\\", \\\"{x:1595,y:635,t:1527009474113};\\\", \\\"{x:1584,y:643,t:1527009474130};\\\", \\\"{x:1569,y:652,t:1527009474147};\\\", \\\"{x:1561,y:660,t:1527009474164};\\\", \\\"{x:1555,y:663,t:1527009474180};\\\", \\\"{x:1548,y:667,t:1527009474197};\\\", \\\"{x:1544,y:668,t:1527009474213};\\\", \\\"{x:1538,y:672,t:1527009474230};\\\", \\\"{x:1530,y:675,t:1527009474246};\\\", \\\"{x:1515,y:682,t:1527009474264};\\\", \\\"{x:1506,y:684,t:1527009474280};\\\", \\\"{x:1496,y:686,t:1527009474296};\\\", \\\"{x:1479,y:694,t:1527009474313};\\\", \\\"{x:1462,y:700,t:1527009474330};\\\", \\\"{x:1449,y:707,t:1527009474346};\\\", \\\"{x:1441,y:709,t:1527009474363};\\\", \\\"{x:1436,y:711,t:1527009474380};\\\", \\\"{x:1431,y:712,t:1527009474396};\\\", \\\"{x:1427,y:712,t:1527009474413};\\\", \\\"{x:1423,y:712,t:1527009474431};\\\", \\\"{x:1422,y:712,t:1527009474446};\\\", \\\"{x:1417,y:710,t:1527009474464};\\\", \\\"{x:1412,y:705,t:1527009474481};\\\", \\\"{x:1406,y:697,t:1527009474497};\\\", \\\"{x:1401,y:685,t:1527009474513};\\\", \\\"{x:1393,y:675,t:1527009474530};\\\", \\\"{x:1389,y:669,t:1527009474546};\\\", \\\"{x:1388,y:669,t:1527009474564};\\\", \\\"{x:1387,y:666,t:1527009474581};\\\", \\\"{x:1386,y:664,t:1527009474597};\\\", \\\"{x:1384,y:660,t:1527009474614};\\\", \\\"{x:1383,y:660,t:1527009474631};\\\", \\\"{x:1373,y:659,t:1527009474647};\\\", \\\"{x:1361,y:656,t:1527009474664};\\\", \\\"{x:1345,y:655,t:1527009474681};\\\", \\\"{x:1331,y:655,t:1527009474697};\\\", \\\"{x:1312,y:656,t:1527009474714};\\\", \\\"{x:1295,y:661,t:1527009474730};\\\", \\\"{x:1283,y:665,t:1527009474746};\\\", \\\"{x:1275,y:667,t:1527009474763};\\\", \\\"{x:1270,y:670,t:1527009474780};\\\", \\\"{x:1266,y:674,t:1527009474797};\\\", \\\"{x:1263,y:677,t:1527009474813};\\\", \\\"{x:1262,y:677,t:1527009474830};\\\", \\\"{x:1261,y:677,t:1527009474846};\\\", \\\"{x:1261,y:679,t:1527009474864};\\\", \\\"{x:1260,y:680,t:1527009474881};\\\", \\\"{x:1260,y:682,t:1527009474921};\\\", \\\"{x:1263,y:683,t:1527009474931};\\\", \\\"{x:1268,y:684,t:1527009474947};\\\", \\\"{x:1278,y:686,t:1527009474964};\\\", \\\"{x:1291,y:688,t:1527009474981};\\\", \\\"{x:1303,y:688,t:1527009474998};\\\", \\\"{x:1319,y:690,t:1527009475014};\\\", \\\"{x:1333,y:694,t:1527009475031};\\\", \\\"{x:1351,y:694,t:1527009475050};\\\", \\\"{x:1366,y:694,t:1527009475063};\\\", \\\"{x:1374,y:694,t:1527009475081};\\\", \\\"{x:1378,y:694,t:1527009475097};\\\", \\\"{x:1381,y:694,t:1527009475113};\\\", \\\"{x:1391,y:694,t:1527009475130};\\\", \\\"{x:1398,y:694,t:1527009475147};\\\", \\\"{x:1413,y:694,t:1527009475164};\\\", \\\"{x:1430,y:694,t:1527009475180};\\\", \\\"{x:1446,y:693,t:1527009475197};\\\", \\\"{x:1460,y:691,t:1527009475213};\\\", \\\"{x:1472,y:690,t:1527009475230};\\\", \\\"{x:1479,y:690,t:1527009475247};\\\", \\\"{x:1485,y:688,t:1527009475263};\\\", \\\"{x:1496,y:687,t:1527009475280};\\\", \\\"{x:1507,y:687,t:1527009475297};\\\", \\\"{x:1522,y:687,t:1527009475314};\\\", \\\"{x:1536,y:687,t:1527009475330};\\\", \\\"{x:1547,y:687,t:1527009475348};\\\", \\\"{x:1568,y:689,t:1527009475364};\\\", \\\"{x:1586,y:691,t:1527009475381};\\\", \\\"{x:1597,y:693,t:1527009475397};\\\", \\\"{x:1603,y:695,t:1527009475414};\\\", \\\"{x:1610,y:695,t:1527009475430};\\\", \\\"{x:1612,y:697,t:1527009475447};\\\", \\\"{x:1614,y:697,t:1527009475464};\\\", \\\"{x:1618,y:699,t:1527009475480};\\\", \\\"{x:1621,y:701,t:1527009475498};\\\", \\\"{x:1626,y:702,t:1527009475514};\\\", \\\"{x:1630,y:704,t:1527009475531};\\\", \\\"{x:1635,y:705,t:1527009475547};\\\", \\\"{x:1636,y:705,t:1527009475564};\\\", \\\"{x:1637,y:706,t:1527009475643};\\\", \\\"{x:1639,y:707,t:1527009475650};\\\", \\\"{x:1639,y:711,t:1527009475665};\\\", \\\"{x:1639,y:716,t:1527009475681};\\\", \\\"{x:1638,y:723,t:1527009475697};\\\", \\\"{x:1634,y:729,t:1527009475714};\\\", \\\"{x:1627,y:735,t:1527009475731};\\\", \\\"{x:1619,y:742,t:1527009475748};\\\", \\\"{x:1613,y:748,t:1527009475764};\\\", \\\"{x:1606,y:748,t:1527009475782};\\\", \\\"{x:1600,y:754,t:1527009475797};\\\", \\\"{x:1595,y:760,t:1527009475815};\\\", \\\"{x:1591,y:764,t:1527009475831};\\\", \\\"{x:1586,y:767,t:1527009475848};\\\", \\\"{x:1583,y:771,t:1527009475864};\\\", \\\"{x:1581,y:773,t:1527009475880};\\\", \\\"{x:1580,y:773,t:1527009475897};\\\", \\\"{x:1578,y:774,t:1527009475914};\\\", \\\"{x:1576,y:776,t:1527009475931};\\\", \\\"{x:1575,y:777,t:1527009475948};\\\", \\\"{x:1573,y:779,t:1527009475965};\\\", \\\"{x:1572,y:780,t:1527009475981};\\\", \\\"{x:1570,y:781,t:1527009475997};\\\", \\\"{x:1567,y:783,t:1527009476014};\\\", \\\"{x:1564,y:785,t:1527009476031};\\\", \\\"{x:1561,y:788,t:1527009476047};\\\", \\\"{x:1560,y:789,t:1527009476064};\\\", \\\"{x:1556,y:791,t:1527009476081};\\\", \\\"{x:1552,y:793,t:1527009476097};\\\", \\\"{x:1547,y:794,t:1527009476114};\\\", \\\"{x:1542,y:795,t:1527009476131};\\\", \\\"{x:1539,y:795,t:1527009476147};\\\", \\\"{x:1535,y:796,t:1527009476164};\\\", \\\"{x:1533,y:795,t:1527009476184};\\\", \\\"{x:1528,y:795,t:1527009476197};\\\", \\\"{x:1517,y:795,t:1527009476214};\\\", \\\"{x:1500,y:794,t:1527009476231};\\\", \\\"{x:1457,y:787,t:1527009476248};\\\", \\\"{x:1419,y:779,t:1527009476264};\\\", \\\"{x:1402,y:772,t:1527009476281};\\\", \\\"{x:1380,y:765,t:1527009476298};\\\", \\\"{x:1360,y:758,t:1527009476315};\\\", \\\"{x:1349,y:755,t:1527009476331};\\\", \\\"{x:1334,y:750,t:1527009476348};\\\", \\\"{x:1313,y:749,t:1527009476364};\\\", \\\"{x:1291,y:745,t:1527009476381};\\\", \\\"{x:1267,y:741,t:1527009476398};\\\", \\\"{x:1249,y:737,t:1527009476414};\\\", \\\"{x:1237,y:736,t:1527009476431};\\\", \\\"{x:1229,y:736,t:1527009476448};\\\", \\\"{x:1226,y:736,t:1527009476465};\\\", \\\"{x:1225,y:736,t:1527009476481};\\\", \\\"{x:1224,y:736,t:1527009476498};\\\", \\\"{x:1223,y:736,t:1527009476515};\\\", \\\"{x:1222,y:736,t:1527009476532};\\\", \\\"{x:1220,y:736,t:1527009476549};\\\", \\\"{x:1219,y:738,t:1527009476565};\\\", \\\"{x:1219,y:739,t:1527009476581};\\\", \\\"{x:1218,y:741,t:1527009476599};\\\", \\\"{x:1217,y:743,t:1527009476615};\\\", \\\"{x:1217,y:746,t:1527009476632};\\\", \\\"{x:1216,y:756,t:1527009476650};\\\", \\\"{x:1215,y:772,t:1527009476665};\\\", \\\"{x:1219,y:778,t:1527009476682};\\\", \\\"{x:1224,y:790,t:1527009476699};\\\", \\\"{x:1236,y:806,t:1527009476715};\\\", \\\"{x:1248,y:820,t:1527009476732};\\\", \\\"{x:1261,y:829,t:1527009476749};\\\", \\\"{x:1273,y:839,t:1527009476765};\\\", \\\"{x:1285,y:848,t:1527009476782};\\\", \\\"{x:1305,y:856,t:1527009476799};\\\", \\\"{x:1322,y:862,t:1527009476816};\\\", \\\"{x:1347,y:865,t:1527009476832};\\\", \\\"{x:1384,y:866,t:1527009476849};\\\", \\\"{x:1404,y:869,t:1527009476865};\\\", \\\"{x:1430,y:872,t:1527009476882};\\\", \\\"{x:1482,y:869,t:1527009476899};\\\", \\\"{x:1551,y:869,t:1527009476915};\\\", \\\"{x:1613,y:868,t:1527009476932};\\\", \\\"{x:1684,y:869,t:1527009476949};\\\", \\\"{x:1729,y:872,t:1527009476966};\\\", \\\"{x:1778,y:880,t:1527009476981};\\\", \\\"{x:1799,y:883,t:1527009476998};\\\", \\\"{x:1807,y:888,t:1527009477015};\\\", \\\"{x:1809,y:889,t:1527009477032};\\\", \\\"{x:1804,y:895,t:1527009477049};\\\", \\\"{x:1803,y:895,t:1527009477065};\\\", \\\"{x:1791,y:897,t:1527009477082};\\\", \\\"{x:1781,y:900,t:1527009477098};\\\", \\\"{x:1762,y:905,t:1527009477116};\\\", \\\"{x:1747,y:908,t:1527009477132};\\\", \\\"{x:1741,y:908,t:1527009477149};\\\", \\\"{x:1740,y:908,t:1527009477165};\\\", \\\"{x:1742,y:908,t:1527009477226};\\\", \\\"{x:1743,y:908,t:1527009477266};\\\", \\\"{x:1744,y:908,t:1527009477283};\\\", \\\"{x:1746,y:908,t:1527009477299};\\\", \\\"{x:1747,y:908,t:1527009477417};\\\", \\\"{x:1748,y:908,t:1527009477433};\\\", \\\"{x:1749,y:908,t:1527009477465};\\\", \\\"{x:1745,y:908,t:1527009477689};\\\", \\\"{x:1742,y:910,t:1527009477699};\\\", \\\"{x:1731,y:914,t:1527009477716};\\\", \\\"{x:1722,y:922,t:1527009477733};\\\", \\\"{x:1714,y:929,t:1527009477750};\\\", \\\"{x:1707,y:930,t:1527009477766};\\\", \\\"{x:1706,y:931,t:1527009477783};\\\", \\\"{x:1705,y:931,t:1527009477843};\\\", \\\"{x:1704,y:931,t:1527009478338};\\\", \\\"{x:1703,y:928,t:1527009478350};\\\", \\\"{x:1703,y:925,t:1527009478367};\\\", \\\"{x:1703,y:923,t:1527009478383};\\\", \\\"{x:1697,y:921,t:1527009482810};\\\", \\\"{x:1673,y:914,t:1527009482820};\\\", \\\"{x:1576,y:887,t:1527009482835};\\\", \\\"{x:1449,y:855,t:1527009482853};\\\", \\\"{x:1306,y:818,t:1527009482869};\\\", \\\"{x:1130,y:768,t:1527009482885};\\\", \\\"{x:981,y:729,t:1527009482902};\\\", \\\"{x:840,y:690,t:1527009482919};\\\", \\\"{x:716,y:656,t:1527009482935};\\\", \\\"{x:557,y:605,t:1527009482953};\\\", \\\"{x:493,y:588,t:1527009482970};\\\", \\\"{x:459,y:575,t:1527009482986};\\\", \\\"{x:431,y:567,t:1527009483003};\\\", \\\"{x:416,y:558,t:1527009483020};\\\", \\\"{x:406,y:552,t:1527009483038};\\\", \\\"{x:400,y:546,t:1527009483053};\\\", \\\"{x:393,y:541,t:1527009483070};\\\", \\\"{x:383,y:527,t:1527009483088};\\\", \\\"{x:366,y:502,t:1527009483104};\\\", \\\"{x:342,y:471,t:1527009483120};\\\", \\\"{x:329,y:455,t:1527009483137};\\\", \\\"{x:323,y:448,t:1527009483153};\\\", \\\"{x:323,y:447,t:1527009483176};\\\", \\\"{x:323,y:445,t:1527009483192};\\\", \\\"{x:325,y:444,t:1527009483203};\\\", \\\"{x:335,y:439,t:1527009483221};\\\", \\\"{x:366,y:441,t:1527009483238};\\\", \\\"{x:413,y:469,t:1527009483253};\\\", \\\"{x:520,y:508,t:1527009483272};\\\", \\\"{x:607,y:543,t:1527009483288};\\\", \\\"{x:673,y:559,t:1527009483304};\\\", \\\"{x:713,y:568,t:1527009483320};\\\", \\\"{x:715,y:569,t:1527009483338};\\\", \\\"{x:715,y:567,t:1527009483457};\\\", \\\"{x:711,y:566,t:1527009483471};\\\", \\\"{x:698,y:559,t:1527009483489};\\\", \\\"{x:669,y:543,t:1527009483504};\\\", \\\"{x:653,y:534,t:1527009483521};\\\", \\\"{x:642,y:530,t:1527009483538};\\\", \\\"{x:635,y:526,t:1527009483555};\\\", \\\"{x:632,y:524,t:1527009483572};\\\", \\\"{x:631,y:523,t:1527009483587};\\\", \\\"{x:630,y:523,t:1527009483604};\\\", \\\"{x:634,y:523,t:1527009483793};\\\", \\\"{x:641,y:523,t:1527009483805};\\\", \\\"{x:670,y:525,t:1527009483822};\\\", \\\"{x:698,y:525,t:1527009483838};\\\", \\\"{x:728,y:525,t:1527009483857};\\\", \\\"{x:747,y:525,t:1527009483871};\\\", \\\"{x:759,y:522,t:1527009483887};\\\", \\\"{x:773,y:516,t:1527009483904};\\\", \\\"{x:777,y:514,t:1527009483921};\\\", \\\"{x:777,y:512,t:1527009484025};\\\", \\\"{x:778,y:510,t:1527009484038};\\\", \\\"{x:780,y:508,t:1527009484055};\\\", \\\"{x:780,y:505,t:1527009484072};\\\", \\\"{x:781,y:504,t:1527009484087};\\\", \\\"{x:782,y:503,t:1527009484104};\\\", \\\"{x:784,y:502,t:1527009484122};\\\", \\\"{x:789,y:500,t:1527009484137};\\\", \\\"{x:794,y:497,t:1527009484154};\\\", \\\"{x:801,y:496,t:1527009484172};\\\", \\\"{x:805,y:495,t:1527009484188};\\\", \\\"{x:809,y:493,t:1527009484205};\\\", \\\"{x:810,y:493,t:1527009484225};\\\", \\\"{x:811,y:493,t:1527009484238};\\\", \\\"{x:816,y:493,t:1527009484255};\\\", \\\"{x:825,y:493,t:1527009484272};\\\", \\\"{x:840,y:494,t:1527009484289};\\\", \\\"{x:847,y:495,t:1527009484305};\\\", \\\"{x:832,y:498,t:1527009484656};\\\", \\\"{x:816,y:508,t:1527009484671};\\\", \\\"{x:726,y:524,t:1527009484689};\\\", \\\"{x:614,y:532,t:1527009484706};\\\", \\\"{x:501,y:532,t:1527009484722};\\\", \\\"{x:389,y:529,t:1527009484739};\\\", \\\"{x:320,y:529,t:1527009484756};\\\", \\\"{x:293,y:529,t:1527009484772};\\\", \\\"{x:282,y:530,t:1527009484788};\\\", \\\"{x:278,y:532,t:1527009484805};\\\", \\\"{x:276,y:534,t:1527009484821};\\\", \\\"{x:272,y:537,t:1527009484840};\\\", \\\"{x:265,y:541,t:1527009484855};\\\", \\\"{x:256,y:549,t:1527009484872};\\\", \\\"{x:254,y:551,t:1527009484889};\\\", \\\"{x:251,y:552,t:1527009484906};\\\", \\\"{x:250,y:552,t:1527009484923};\\\", \\\"{x:246,y:555,t:1527009484938};\\\", \\\"{x:242,y:558,t:1527009484956};\\\", \\\"{x:235,y:562,t:1527009484972};\\\", \\\"{x:228,y:565,t:1527009484990};\\\", \\\"{x:225,y:568,t:1527009485005};\\\", \\\"{x:222,y:569,t:1527009485023};\\\", \\\"{x:221,y:569,t:1527009485039};\\\", \\\"{x:219,y:569,t:1527009485064};\\\", \\\"{x:218,y:569,t:1527009485072};\\\", \\\"{x:215,y:567,t:1527009485089};\\\", \\\"{x:211,y:563,t:1527009485106};\\\", \\\"{x:209,y:561,t:1527009485123};\\\", \\\"{x:207,y:558,t:1527009485140};\\\", \\\"{x:207,y:557,t:1527009485156};\\\", \\\"{x:206,y:555,t:1527009485173};\\\", \\\"{x:206,y:554,t:1527009485193};\\\", \\\"{x:205,y:553,t:1527009485206};\\\", \\\"{x:204,y:550,t:1527009485223};\\\", \\\"{x:203,y:547,t:1527009485240};\\\", \\\"{x:203,y:545,t:1527009485255};\\\", \\\"{x:202,y:543,t:1527009485273};\\\", \\\"{x:202,y:542,t:1527009485296};\\\", \\\"{x:202,y:541,t:1527009485312};\\\", \\\"{x:202,y:540,t:1527009485361};\\\", \\\"{x:201,y:540,t:1527009485373};\\\", \\\"{x:209,y:543,t:1527009485865};\\\", \\\"{x:228,y:551,t:1527009485873};\\\", \\\"{x:318,y:584,t:1527009485891};\\\", \\\"{x:413,y:616,t:1527009485907};\\\", \\\"{x:500,y:645,t:1527009485923};\\\", \\\"{x:577,y:675,t:1527009485939};\\\", \\\"{x:630,y:701,t:1527009485957};\\\", \\\"{x:665,y:719,t:1527009485973};\\\", \\\"{x:677,y:727,t:1527009485990};\\\", \\\"{x:682,y:734,t:1527009486007};\\\", \\\"{x:686,y:740,t:1527009486022};\\\", \\\"{x:689,y:750,t:1527009486039};\\\", \\\"{x:697,y:767,t:1527009486056};\\\", \\\"{x:701,y:777,t:1527009486073};\\\", \\\"{x:703,y:785,t:1527009486090};\\\", \\\"{x:703,y:789,t:1527009486106};\\\", \\\"{x:703,y:791,t:1527009486122};\\\", \\\"{x:702,y:792,t:1527009486176};\\\", \\\"{x:692,y:791,t:1527009486190};\\\", \\\"{x:665,y:779,t:1527009486207};\\\", \\\"{x:612,y:763,t:1527009486224};\\\", \\\"{x:584,y:753,t:1527009486240};\\\", \\\"{x:580,y:750,t:1527009486256};\\\", \\\"{x:578,y:748,t:1527009486274};\\\", \\\"{x:576,y:748,t:1527009486577};\\\", \\\"{x:569,y:748,t:1527009486590};\\\", \\\"{x:565,y:746,t:1527009486607};\\\", \\\"{x:560,y:744,t:1527009486626};\\\", \\\"{x:558,y:743,t:1527009486641};\\\", \\\"{x:557,y:742,t:1527009486657};\\\", \\\"{x:556,y:742,t:1527009486704};\\\", \\\"{x:555,y:742,t:1527009486736};\\\", \\\"{x:553,y:741,t:1527009486768};\\\", \\\"{x:552,y:740,t:1527009486784};\\\", \\\"{x:551,y:739,t:1527009486801};\\\", \\\"{x:551,y:737,t:1527009487496};\\\", \\\"{x:555,y:735,t:1527009487507};\\\", \\\"{x:556,y:732,t:1527009487525};\\\", \\\"{x:557,y:732,t:1527009487540};\\\", \\\"{x:558,y:732,t:1527009487558};\\\" ] }, { \\\"rt\\\": 34008, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 678664, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:559,y:730,t:1527009490873};\\\", \\\"{x:564,y:725,t:1527009490880};\\\", \\\"{x:588,y:706,t:1527009490899};\\\", \\\"{x:594,y:690,t:1527009490915};\\\", \\\"{x:595,y:690,t:1527009492530};\\\", \\\"{x:600,y:688,t:1527009492545};\\\", \\\"{x:615,y:685,t:1527009492563};\\\", \\\"{x:633,y:682,t:1527009492578};\\\", \\\"{x:655,y:680,t:1527009492595};\\\", \\\"{x:668,y:680,t:1527009492612};\\\", \\\"{x:702,y:680,t:1527009492629};\\\", \\\"{x:733,y:680,t:1527009492645};\\\", \\\"{x:761,y:680,t:1527009492663};\\\", \\\"{x:805,y:680,t:1527009492679};\\\", \\\"{x:866,y:680,t:1527009492696};\\\", \\\"{x:933,y:680,t:1527009492713};\\\", \\\"{x:1053,y:680,t:1527009492729};\\\", \\\"{x:1128,y:680,t:1527009492745};\\\", \\\"{x:1220,y:683,t:1527009492762};\\\", \\\"{x:1319,y:692,t:1527009492780};\\\", \\\"{x:1422,y:706,t:1527009492796};\\\", \\\"{x:1514,y:724,t:1527009492812};\\\", \\\"{x:1594,y:731,t:1527009492829};\\\", \\\"{x:1655,y:739,t:1527009492845};\\\", \\\"{x:1682,y:741,t:1527009492862};\\\", \\\"{x:1699,y:742,t:1527009492880};\\\", \\\"{x:1708,y:742,t:1527009492895};\\\", \\\"{x:1712,y:742,t:1527009492912};\\\", \\\"{x:1713,y:742,t:1527009492937};\\\", \\\"{x:1714,y:742,t:1527009492993};\\\", \\\"{x:1715,y:742,t:1527009493009};\\\", \\\"{x:1715,y:741,t:1527009493025};\\\", \\\"{x:1716,y:740,t:1527009493033};\\\", \\\"{x:1716,y:739,t:1527009493057};\\\", \\\"{x:1716,y:738,t:1527009493065};\\\", \\\"{x:1716,y:737,t:1527009493080};\\\", \\\"{x:1712,y:726,t:1527009493097};\\\", \\\"{x:1707,y:719,t:1527009493113};\\\", \\\"{x:1704,y:716,t:1527009493130};\\\", \\\"{x:1703,y:715,t:1527009493146};\\\", \\\"{x:1702,y:715,t:1527009493169};\\\", \\\"{x:1701,y:715,t:1527009493201};\\\", \\\"{x:1700,y:715,t:1527009493212};\\\", \\\"{x:1699,y:715,t:1527009493229};\\\", \\\"{x:1698,y:715,t:1527009493247};\\\", \\\"{x:1696,y:715,t:1527009493441};\\\", \\\"{x:1693,y:710,t:1527009493449};\\\", \\\"{x:1692,y:704,t:1527009493464};\\\", \\\"{x:1689,y:695,t:1527009493480};\\\", \\\"{x:1682,y:685,t:1527009493497};\\\", \\\"{x:1678,y:679,t:1527009493513};\\\", \\\"{x:1673,y:674,t:1527009493530};\\\", \\\"{x:1662,y:669,t:1527009493547};\\\", \\\"{x:1646,y:655,t:1527009493563};\\\", \\\"{x:1623,y:638,t:1527009493580};\\\", \\\"{x:1585,y:596,t:1527009493596};\\\", \\\"{x:1506,y:524,t:1527009493613};\\\", \\\"{x:1419,y:448,t:1527009493630};\\\", \\\"{x:1359,y:399,t:1527009493647};\\\", \\\"{x:1305,y:358,t:1527009493664};\\\", \\\"{x:1257,y:325,t:1527009493680};\\\", \\\"{x:1227,y:307,t:1527009493697};\\\", \\\"{x:1220,y:300,t:1527009493713};\\\", \\\"{x:1216,y:297,t:1527009493730};\\\", \\\"{x:1214,y:296,t:1527009493746};\\\", \\\"{x:1214,y:300,t:1527009493930};\\\", \\\"{x:1219,y:317,t:1527009493947};\\\", \\\"{x:1224,y:336,t:1527009493964};\\\", \\\"{x:1229,y:354,t:1527009493980};\\\", \\\"{x:1237,y:370,t:1527009493996};\\\", \\\"{x:1244,y:380,t:1527009494013};\\\", \\\"{x:1253,y:391,t:1527009494030};\\\", \\\"{x:1263,y:400,t:1527009494046};\\\", \\\"{x:1268,y:407,t:1527009494063};\\\", \\\"{x:1276,y:413,t:1527009494080};\\\", \\\"{x:1277,y:413,t:1527009494096};\\\", \\\"{x:1278,y:414,t:1527009494128};\\\", \\\"{x:1279,y:415,t:1527009494176};\\\", \\\"{x:1281,y:415,t:1527009494889};\\\", \\\"{x:1286,y:416,t:1527009494897};\\\", \\\"{x:1295,y:418,t:1527009494915};\\\", \\\"{x:1306,y:420,t:1527009494930};\\\", \\\"{x:1312,y:421,t:1527009494947};\\\", \\\"{x:1321,y:422,t:1527009494965};\\\", \\\"{x:1326,y:422,t:1527009494981};\\\", \\\"{x:1332,y:425,t:1527009494998};\\\", \\\"{x:1336,y:425,t:1527009495015};\\\", \\\"{x:1340,y:426,t:1527009495031};\\\", \\\"{x:1345,y:426,t:1527009495048};\\\", \\\"{x:1353,y:426,t:1527009495065};\\\", \\\"{x:1361,y:428,t:1527009495081};\\\", \\\"{x:1365,y:429,t:1527009495097};\\\", \\\"{x:1367,y:432,t:1527009495114};\\\", \\\"{x:1373,y:433,t:1527009495130};\\\", \\\"{x:1381,y:434,t:1527009495147};\\\", \\\"{x:1386,y:436,t:1527009495164};\\\", \\\"{x:1389,y:437,t:1527009495181};\\\", \\\"{x:1391,y:437,t:1527009495197};\\\", \\\"{x:1395,y:438,t:1527009495214};\\\", \\\"{x:1396,y:439,t:1527009498826};\\\", \\\"{x:1396,y:441,t:1527009498833};\\\", \\\"{x:1396,y:444,t:1527009498851};\\\", \\\"{x:1396,y:446,t:1527009498868};\\\", \\\"{x:1395,y:447,t:1527009498884};\\\", \\\"{x:1395,y:449,t:1527009498901};\\\", \\\"{x:1395,y:450,t:1527009498918};\\\", \\\"{x:1395,y:452,t:1527009498934};\\\", \\\"{x:1395,y:453,t:1527009498950};\\\", \\\"{x:1395,y:455,t:1527009498969};\\\", \\\"{x:1394,y:456,t:1527009498984};\\\", \\\"{x:1394,y:457,t:1527009499001};\\\", \\\"{x:1394,y:458,t:1527009499018};\\\", \\\"{x:1394,y:460,t:1527009499034};\\\", \\\"{x:1392,y:462,t:1527009499051};\\\", \\\"{x:1391,y:464,t:1527009499068};\\\", \\\"{x:1389,y:467,t:1527009499084};\\\", \\\"{x:1388,y:469,t:1527009499100};\\\", \\\"{x:1387,y:470,t:1527009499120};\\\", \\\"{x:1387,y:471,t:1527009499144};\\\", \\\"{x:1387,y:473,t:1527009499160};\\\", \\\"{x:1387,y:474,t:1527009499192};\\\", \\\"{x:1387,y:475,t:1527009499200};\\\", \\\"{x:1387,y:476,t:1527009499224};\\\", \\\"{x:1387,y:477,t:1527009499241};\\\", \\\"{x:1387,y:478,t:1527009499250};\\\", \\\"{x:1387,y:479,t:1527009499272};\\\", \\\"{x:1387,y:480,t:1527009499284};\\\", \\\"{x:1386,y:481,t:1527009499301};\\\", \\\"{x:1384,y:484,t:1527009499320};\\\", \\\"{x:1380,y:487,t:1527009499334};\\\", \\\"{x:1378,y:490,t:1527009499350};\\\", \\\"{x:1376,y:492,t:1527009499368};\\\", \\\"{x:1372,y:498,t:1527009499384};\\\", \\\"{x:1371,y:500,t:1527009499401};\\\", \\\"{x:1369,y:504,t:1527009499417};\\\", \\\"{x:1368,y:506,t:1527009499435};\\\", \\\"{x:1366,y:509,t:1527009499450};\\\", \\\"{x:1364,y:511,t:1527009499468};\\\", \\\"{x:1363,y:513,t:1527009499484};\\\", \\\"{x:1362,y:515,t:1527009499500};\\\", \\\"{x:1361,y:516,t:1527009499518};\\\", \\\"{x:1360,y:516,t:1527009499534};\\\", \\\"{x:1360,y:517,t:1527009499551};\\\", \\\"{x:1359,y:519,t:1527009499568};\\\", \\\"{x:1357,y:521,t:1527009499585};\\\", \\\"{x:1357,y:523,t:1527009499881};\\\", \\\"{x:1357,y:527,t:1527009499889};\\\", \\\"{x:1357,y:531,t:1527009499902};\\\", \\\"{x:1357,y:539,t:1527009499918};\\\", \\\"{x:1358,y:545,t:1527009499935};\\\", \\\"{x:1360,y:550,t:1527009499952};\\\", \\\"{x:1361,y:553,t:1527009499968};\\\", \\\"{x:1361,y:555,t:1527009499984};\\\", \\\"{x:1361,y:557,t:1527009500002};\\\", \\\"{x:1361,y:558,t:1527009500019};\\\", \\\"{x:1362,y:561,t:1527009500035};\\\", \\\"{x:1362,y:566,t:1527009500052};\\\", \\\"{x:1362,y:574,t:1527009500069};\\\", \\\"{x:1365,y:586,t:1527009500085};\\\", \\\"{x:1367,y:597,t:1527009500102};\\\", \\\"{x:1367,y:607,t:1527009500119};\\\", \\\"{x:1367,y:618,t:1527009500135};\\\", \\\"{x:1367,y:631,t:1527009500152};\\\", \\\"{x:1367,y:657,t:1527009500169};\\\", \\\"{x:1367,y:673,t:1527009500186};\\\", \\\"{x:1367,y:686,t:1527009500202};\\\", \\\"{x:1367,y:697,t:1527009500219};\\\", \\\"{x:1367,y:705,t:1527009500235};\\\", \\\"{x:1366,y:710,t:1527009500252};\\\", \\\"{x:1366,y:716,t:1527009500269};\\\", \\\"{x:1365,y:719,t:1527009500285};\\\", \\\"{x:1364,y:723,t:1527009500302};\\\", \\\"{x:1364,y:725,t:1527009500319};\\\", \\\"{x:1364,y:727,t:1527009500344};\\\", \\\"{x:1364,y:729,t:1527009500362};\\\", \\\"{x:1364,y:730,t:1527009500368};\\\", \\\"{x:1364,y:734,t:1527009500384};\\\", \\\"{x:1364,y:735,t:1527009500401};\\\", \\\"{x:1364,y:738,t:1527009500418};\\\", \\\"{x:1364,y:739,t:1527009500434};\\\", \\\"{x:1360,y:739,t:1527009500488};\\\", \\\"{x:1346,y:738,t:1527009500502};\\\", \\\"{x:1325,y:733,t:1527009500518};\\\", \\\"{x:1316,y:732,t:1527009500536};\\\", \\\"{x:1303,y:732,t:1527009500552};\\\", \\\"{x:1291,y:732,t:1527009500569};\\\", \\\"{x:1286,y:733,t:1527009500586};\\\", \\\"{x:1285,y:733,t:1527009500602};\\\", \\\"{x:1283,y:733,t:1527009500688};\\\", \\\"{x:1280,y:734,t:1527009500702};\\\", \\\"{x:1275,y:734,t:1527009500719};\\\", \\\"{x:1271,y:734,t:1527009500735};\\\", \\\"{x:1269,y:735,t:1527009500751};\\\", \\\"{x:1267,y:735,t:1527009500768};\\\", \\\"{x:1263,y:735,t:1527009500785};\\\", \\\"{x:1252,y:742,t:1527009500801};\\\", \\\"{x:1241,y:745,t:1527009500818};\\\", \\\"{x:1238,y:747,t:1527009500836};\\\", \\\"{x:1237,y:747,t:1527009500880};\\\", \\\"{x:1235,y:748,t:1527009500888};\\\", \\\"{x:1235,y:750,t:1527009500902};\\\", \\\"{x:1232,y:752,t:1527009500919};\\\", \\\"{x:1229,y:755,t:1527009500935};\\\", \\\"{x:1226,y:758,t:1527009500953};\\\", \\\"{x:1221,y:762,t:1527009500968};\\\", \\\"{x:1221,y:764,t:1527009500985};\\\", \\\"{x:1215,y:766,t:1527009501002};\\\", \\\"{x:1203,y:771,t:1527009501019};\\\", \\\"{x:1191,y:775,t:1527009501036};\\\", \\\"{x:1189,y:777,t:1527009501052};\\\", \\\"{x:1184,y:779,t:1527009501069};\\\", \\\"{x:1182,y:781,t:1527009501085};\\\", \\\"{x:1182,y:778,t:1527009501369};\\\", \\\"{x:1182,y:777,t:1527009501393};\\\", \\\"{x:1182,y:776,t:1527009501403};\\\", \\\"{x:1182,y:775,t:1527009501420};\\\", \\\"{x:1182,y:773,t:1527009501441};\\\", \\\"{x:1182,y:772,t:1527009501453};\\\", \\\"{x:1182,y:770,t:1527009501469};\\\", \\\"{x:1182,y:768,t:1527009501488};\\\", \\\"{x:1182,y:767,t:1527009501528};\\\", \\\"{x:1181,y:766,t:1527009501552};\\\", \\\"{x:1180,y:766,t:1527009501697};\\\", \\\"{x:1182,y:766,t:1527009503697};\\\", \\\"{x:1184,y:768,t:1527009503713};\\\", \\\"{x:1186,y:770,t:1527009503722};\\\", \\\"{x:1191,y:773,t:1527009503738};\\\", \\\"{x:1195,y:778,t:1527009503755};\\\", \\\"{x:1202,y:786,t:1527009503771};\\\", \\\"{x:1217,y:797,t:1527009503788};\\\", \\\"{x:1235,y:813,t:1527009503805};\\\", \\\"{x:1251,y:825,t:1527009503821};\\\", \\\"{x:1266,y:836,t:1527009503838};\\\", \\\"{x:1271,y:840,t:1527009503855};\\\", \\\"{x:1273,y:841,t:1527009503871};\\\", \\\"{x:1274,y:841,t:1527009503888};\\\", \\\"{x:1276,y:841,t:1527009503905};\\\", \\\"{x:1277,y:841,t:1527009504618};\\\", \\\"{x:1277,y:840,t:1527009504706};\\\", \\\"{x:1276,y:840,t:1527009514746};\\\", \\\"{x:1273,y:836,t:1527009514757};\\\", \\\"{x:1267,y:832,t:1527009514773};\\\", \\\"{x:1253,y:826,t:1527009514789};\\\", \\\"{x:1239,y:816,t:1527009514806};\\\", \\\"{x:1211,y:803,t:1527009514823};\\\", \\\"{x:1153,y:775,t:1527009514840};\\\", \\\"{x:1081,y:744,t:1527009514856};\\\", \\\"{x:1006,y:722,t:1527009514873};\\\", \\\"{x:975,y:708,t:1527009514890};\\\", \\\"{x:969,y:705,t:1527009514906};\\\", \\\"{x:967,y:704,t:1527009514923};\\\", \\\"{x:967,y:703,t:1527009514940};\\\", \\\"{x:966,y:702,t:1527009515459};\\\", \\\"{x:964,y:702,t:1527009515473};\\\", \\\"{x:953,y:699,t:1527009515489};\\\", \\\"{x:946,y:698,t:1527009515507};\\\", \\\"{x:939,y:697,t:1527009515524};\\\", \\\"{x:931,y:695,t:1527009515540};\\\", \\\"{x:922,y:695,t:1527009515556};\\\", \\\"{x:912,y:694,t:1527009515574};\\\", \\\"{x:899,y:691,t:1527009515590};\\\", \\\"{x:878,y:688,t:1527009515607};\\\", \\\"{x:861,y:683,t:1527009515624};\\\", \\\"{x:834,y:682,t:1527009515640};\\\", \\\"{x:798,y:676,t:1527009515657};\\\", \\\"{x:755,y:671,t:1527009515674};\\\", \\\"{x:738,y:671,t:1527009515690};\\\", \\\"{x:717,y:670,t:1527009515707};\\\", \\\"{x:692,y:666,t:1527009515724};\\\", \\\"{x:665,y:661,t:1527009515740};\\\", \\\"{x:628,y:653,t:1527009515757};\\\", \\\"{x:594,y:648,t:1527009515773};\\\", \\\"{x:566,y:646,t:1527009515790};\\\", \\\"{x:548,y:643,t:1527009515807};\\\", \\\"{x:537,y:643,t:1527009515824};\\\", \\\"{x:529,y:643,t:1527009515840};\\\", \\\"{x:527,y:643,t:1527009515856};\\\", \\\"{x:526,y:643,t:1527009515873};\\\", \\\"{x:525,y:643,t:1527009515913};\\\", \\\"{x:524,y:643,t:1527009515961};\\\", \\\"{x:523,y:643,t:1527009516066};\\\", \\\"{x:522,y:643,t:1527009516130};\\\", \\\"{x:520,y:643,t:1527009516141};\\\", \\\"{x:514,y:637,t:1527009516157};\\\", \\\"{x:514,y:633,t:1527009516173};\\\", \\\"{x:514,y:627,t:1527009516192};\\\", \\\"{x:511,y:619,t:1527009516206};\\\", \\\"{x:509,y:608,t:1527009516223};\\\", \\\"{x:507,y:603,t:1527009516240};\\\", \\\"{x:505,y:600,t:1527009516258};\\\", \\\"{x:505,y:598,t:1527009516274};\\\", \\\"{x:504,y:597,t:1527009516290};\\\", \\\"{x:503,y:595,t:1527009516321};\\\", \\\"{x:502,y:595,t:1527009516329};\\\", \\\"{x:502,y:593,t:1527009516345};\\\", \\\"{x:500,y:592,t:1527009516361};\\\", \\\"{x:500,y:591,t:1527009516374};\\\", \\\"{x:499,y:591,t:1527009516391};\\\", \\\"{x:498,y:590,t:1527009516408};\\\", \\\"{x:497,y:589,t:1527009516424};\\\", \\\"{x:496,y:588,t:1527009516441};\\\", \\\"{x:491,y:583,t:1527009516457};\\\", \\\"{x:489,y:579,t:1527009516474};\\\", \\\"{x:486,y:573,t:1527009516492};\\\", \\\"{x:482,y:566,t:1527009516507};\\\", \\\"{x:480,y:563,t:1527009516524};\\\", \\\"{x:475,y:554,t:1527009516541};\\\", \\\"{x:470,y:546,t:1527009516558};\\\", \\\"{x:461,y:531,t:1527009516574};\\\", \\\"{x:446,y:517,t:1527009516592};\\\", \\\"{x:429,y:506,t:1527009516607};\\\", \\\"{x:405,y:491,t:1527009516625};\\\", \\\"{x:379,y:478,t:1527009516641};\\\", \\\"{x:374,y:475,t:1527009516657};\\\", \\\"{x:372,y:475,t:1527009516674};\\\", \\\"{x:371,y:475,t:1527009516795};\\\", \\\"{x:371,y:476,t:1527009516859};\\\", \\\"{x:371,y:483,t:1527009516875};\\\", \\\"{x:371,y:486,t:1527009516891};\\\", \\\"{x:372,y:489,t:1527009516910};\\\", \\\"{x:373,y:490,t:1527009516924};\\\", \\\"{x:365,y:496,t:1527009517490};\\\", \\\"{x:354,y:501,t:1527009517497};\\\", \\\"{x:338,y:504,t:1527009517511};\\\", \\\"{x:318,y:506,t:1527009517527};\\\", \\\"{x:308,y:506,t:1527009517543};\\\", \\\"{x:293,y:506,t:1527009517561};\\\", \\\"{x:289,y:507,t:1527009517578};\\\", \\\"{x:285,y:507,t:1527009517593};\\\", \\\"{x:278,y:507,t:1527009517611};\\\", \\\"{x:271,y:509,t:1527009517629};\\\", \\\"{x:264,y:510,t:1527009517645};\\\", \\\"{x:260,y:510,t:1527009517659};\\\", \\\"{x:257,y:510,t:1527009517676};\\\", \\\"{x:253,y:509,t:1527009517692};\\\", \\\"{x:246,y:506,t:1527009517708};\\\", \\\"{x:236,y:503,t:1527009517725};\\\", \\\"{x:230,y:502,t:1527009517742};\\\", \\\"{x:228,y:502,t:1527009517759};\\\", \\\"{x:227,y:501,t:1527009517775};\\\", \\\"{x:226,y:501,t:1527009517793};\\\", \\\"{x:224,y:499,t:1527009517809};\\\", \\\"{x:213,y:497,t:1527009517825};\\\", \\\"{x:199,y:493,t:1527009517843};\\\", \\\"{x:184,y:491,t:1527009517859};\\\", \\\"{x:163,y:489,t:1527009517876};\\\", \\\"{x:149,y:487,t:1527009517892};\\\", \\\"{x:141,y:487,t:1527009517909};\\\", \\\"{x:135,y:487,t:1527009517925};\\\", \\\"{x:132,y:487,t:1527009517942};\\\", \\\"{x:131,y:487,t:1527009517971};\\\", \\\"{x:130,y:487,t:1527009518137};\\\", \\\"{x:130,y:489,t:1527009518145};\\\", \\\"{x:133,y:492,t:1527009518345};\\\", \\\"{x:135,y:492,t:1527009518360};\\\", \\\"{x:136,y:492,t:1527009518375};\\\", \\\"{x:141,y:496,t:1527009518392};\\\", \\\"{x:146,y:497,t:1527009518409};\\\", \\\"{x:147,y:497,t:1527009518426};\\\", \\\"{x:148,y:497,t:1527009518442};\\\", \\\"{x:148,y:498,t:1527009518465};\\\", \\\"{x:149,y:498,t:1527009518570};\\\", \\\"{x:150,y:498,t:1527009518577};\\\", \\\"{x:151,y:498,t:1527009518625};\\\", \\\"{x:152,y:498,t:1527009518642};\\\", \\\"{x:153,y:498,t:1527009518659};\\\", \\\"{x:153,y:498,t:1527009518738};\\\", \\\"{x:154,y:498,t:1527009518760};\\\", \\\"{x:156,y:498,t:1527009518777};\\\", \\\"{x:157,y:498,t:1527009518818};\\\", \\\"{x:159,y:498,t:1527009518827};\\\", \\\"{x:162,y:498,t:1527009518843};\\\", \\\"{x:178,y:498,t:1527009518859};\\\", \\\"{x:213,y:497,t:1527009518877};\\\", \\\"{x:301,y:497,t:1527009518895};\\\", \\\"{x:398,y:497,t:1527009518910};\\\", \\\"{x:473,y:497,t:1527009518927};\\\", \\\"{x:503,y:497,t:1527009518945};\\\", \\\"{x:505,y:497,t:1527009518959};\\\", \\\"{x:507,y:497,t:1527009519066};\\\", \\\"{x:508,y:496,t:1527009519114};\\\", \\\"{x:503,y:494,t:1527009519127};\\\", \\\"{x:437,y:494,t:1527009519145};\\\", \\\"{x:378,y:494,t:1527009519160};\\\", \\\"{x:319,y:494,t:1527009519177};\\\", \\\"{x:258,y:500,t:1527009519194};\\\", \\\"{x:245,y:501,t:1527009519210};\\\", \\\"{x:244,y:501,t:1527009519227};\\\", \\\"{x:248,y:501,t:1527009519314};\\\", \\\"{x:259,y:501,t:1527009519327};\\\", \\\"{x:279,y:501,t:1527009519346};\\\", \\\"{x:301,y:501,t:1527009519361};\\\", \\\"{x:309,y:503,t:1527009519377};\\\", \\\"{x:311,y:504,t:1527009519394};\\\", \\\"{x:312,y:504,t:1527009519466};\\\", \\\"{x:314,y:504,t:1527009519478};\\\", \\\"{x:316,y:505,t:1527009519513};\\\", \\\"{x:317,y:505,t:1527009519611};\\\", \\\"{x:320,y:505,t:1527009519628};\\\", \\\"{x:327,y:506,t:1527009519644};\\\", \\\"{x:329,y:506,t:1527009519661};\\\", \\\"{x:334,y:506,t:1527009519678};\\\", \\\"{x:335,y:506,t:1527009519695};\\\", \\\"{x:338,y:506,t:1527009519711};\\\", \\\"{x:341,y:506,t:1527009519728};\\\", \\\"{x:342,y:507,t:1527009519745};\\\", \\\"{x:345,y:507,t:1527009519761};\\\", \\\"{x:348,y:509,t:1527009519777};\\\", \\\"{x:349,y:509,t:1527009519833};\\\", \\\"{x:352,y:509,t:1527009519873};\\\", \\\"{x:355,y:509,t:1527009519881};\\\", \\\"{x:356,y:509,t:1527009519894};\\\", \\\"{x:362,y:509,t:1527009519912};\\\", \\\"{x:363,y:509,t:1527009519928};\\\", \\\"{x:366,y:509,t:1527009519945};\\\", \\\"{x:370,y:509,t:1527009519962};\\\", \\\"{x:372,y:509,t:1527009519979};\\\", \\\"{x:374,y:509,t:1527009519996};\\\", \\\"{x:379,y:508,t:1527009520012};\\\", \\\"{x:385,y:505,t:1527009520029};\\\", \\\"{x:393,y:501,t:1527009520044};\\\", \\\"{x:402,y:499,t:1527009520061};\\\", \\\"{x:403,y:497,t:1527009520078};\\\", \\\"{x:406,y:496,t:1527009520177};\\\", \\\"{x:407,y:496,t:1527009520434};\\\", \\\"{x:405,y:496,t:1527009520473};\\\", \\\"{x:402,y:496,t:1527009520481};\\\", \\\"{x:393,y:497,t:1527009520495};\\\", \\\"{x:372,y:498,t:1527009520511};\\\", \\\"{x:343,y:499,t:1527009520527};\\\", \\\"{x:299,y:499,t:1527009520544};\\\", \\\"{x:269,y:500,t:1527009520561};\\\", \\\"{x:243,y:500,t:1527009520577};\\\", \\\"{x:233,y:500,t:1527009520594};\\\", \\\"{x:227,y:500,t:1527009520612};\\\", \\\"{x:224,y:499,t:1527009520627};\\\", \\\"{x:223,y:498,t:1527009520645};\\\", \\\"{x:222,y:498,t:1527009520661};\\\", \\\"{x:221,y:498,t:1527009520678};\\\", \\\"{x:219,y:498,t:1527009520695};\\\", \\\"{x:216,y:497,t:1527009520712};\\\", \\\"{x:213,y:496,t:1527009520727};\\\", \\\"{x:211,y:496,t:1527009520744};\\\", \\\"{x:210,y:496,t:1527009520770};\\\", \\\"{x:206,y:496,t:1527009520778};\\\", \\\"{x:197,y:496,t:1527009520795};\\\", \\\"{x:186,y:502,t:1527009520812};\\\", \\\"{x:170,y:508,t:1527009520828};\\\", \\\"{x:157,y:512,t:1527009520845};\\\", \\\"{x:149,y:515,t:1527009520863};\\\", \\\"{x:144,y:516,t:1527009520878};\\\", \\\"{x:143,y:516,t:1527009520894};\\\", \\\"{x:145,y:513,t:1527009521330};\\\", \\\"{x:145,y:512,t:1527009521345};\\\", \\\"{x:146,y:511,t:1527009521466};\\\", \\\"{x:149,y:509,t:1527009521479};\\\", \\\"{x:151,y:507,t:1527009521495};\\\", \\\"{x:153,y:507,t:1527009521675};\\\", \\\"{x:154,y:507,t:1527009521696};\\\", \\\"{x:156,y:505,t:1527009521705};\\\", \\\"{x:157,y:505,t:1527009521841};\\\", \\\"{x:161,y:505,t:1527009521850};\\\", \\\"{x:165,y:506,t:1527009521863};\\\", \\\"{x:176,y:512,t:1527009521879};\\\", \\\"{x:192,y:522,t:1527009521896};\\\", \\\"{x:203,y:530,t:1527009521913};\\\", \\\"{x:240,y:546,t:1527009521929};\\\", \\\"{x:347,y:593,t:1527009521946};\\\", \\\"{x:427,y:627,t:1527009521963};\\\", \\\"{x:494,y:658,t:1527009521979};\\\", \\\"{x:536,y:686,t:1527009521996};\\\", \\\"{x:559,y:694,t:1527009522013};\\\", \\\"{x:570,y:702,t:1527009522028};\\\", \\\"{x:577,y:707,t:1527009522046};\\\", \\\"{x:579,y:708,t:1527009522063};\\\", \\\"{x:578,y:708,t:1527009522129};\\\", \\\"{x:565,y:698,t:1527009522145};\\\", \\\"{x:504,y:674,t:1527009522163};\\\", \\\"{x:464,y:663,t:1527009522180};\\\", \\\"{x:451,y:660,t:1527009522196};\\\", \\\"{x:450,y:660,t:1527009522212};\\\", \\\"{x:450,y:661,t:1527009522266};\\\", \\\"{x:453,y:667,t:1527009522279};\\\", \\\"{x:463,y:682,t:1527009522297};\\\", \\\"{x:469,y:697,t:1527009522313};\\\", \\\"{x:479,y:724,t:1527009522329};\\\", \\\"{x:483,y:729,t:1527009522346};\\\", \\\"{x:484,y:730,t:1527009522393};\\\", \\\"{x:486,y:730,t:1527009522457};\\\" ] }, { \\\"rt\\\": 18504, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 698392, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -I -I -M -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:728,t:1527009525874};\\\", \\\"{x:546,y:718,t:1527009525888};\\\", \\\"{x:736,y:710,t:1527009525907};\\\", \\\"{x:800,y:705,t:1527009525919};\\\", \\\"{x:951,y:707,t:1527009525932};\\\", \\\"{x:1107,y:710,t:1527009525949};\\\", \\\"{x:1260,y:715,t:1527009525966};\\\", \\\"{x:1399,y:721,t:1527009525981};\\\", \\\"{x:1497,y:725,t:1527009525999};\\\", \\\"{x:1562,y:730,t:1527009526016};\\\", \\\"{x:1591,y:737,t:1527009526032};\\\", \\\"{x:1607,y:742,t:1527009526049};\\\", \\\"{x:1606,y:741,t:1527009526105};\\\", \\\"{x:1601,y:742,t:1527009526116};\\\", \\\"{x:1599,y:742,t:1527009526459};\\\", \\\"{x:1599,y:739,t:1527009526682};\\\", \\\"{x:1599,y:738,t:1527009526701};\\\", \\\"{x:1602,y:736,t:1527009526716};\\\", \\\"{x:1612,y:734,t:1527009526733};\\\", \\\"{x:1625,y:734,t:1527009526751};\\\", \\\"{x:1637,y:734,t:1527009526767};\\\", \\\"{x:1646,y:734,t:1527009526783};\\\", \\\"{x:1661,y:734,t:1527009526800};\\\", \\\"{x:1662,y:734,t:1527009526816};\\\", \\\"{x:1662,y:733,t:1527009527275};\\\", \\\"{x:1662,y:732,t:1527009527290};\\\", \\\"{x:1664,y:730,t:1527009527301};\\\", \\\"{x:1664,y:729,t:1527009527318};\\\", \\\"{x:1661,y:723,t:1527009527339};\\\", \\\"{x:1657,y:718,t:1527009527350};\\\", \\\"{x:1649,y:708,t:1527009527367};\\\", \\\"{x:1637,y:698,t:1527009527383};\\\", \\\"{x:1622,y:687,t:1527009527400};\\\", \\\"{x:1601,y:675,t:1527009527418};\\\", \\\"{x:1584,y:659,t:1527009527434};\\\", \\\"{x:1576,y:654,t:1527009527451};\\\", \\\"{x:1569,y:650,t:1527009527467};\\\", \\\"{x:1562,y:647,t:1527009527485};\\\", \\\"{x:1555,y:644,t:1527009527500};\\\", \\\"{x:1550,y:642,t:1527009527518};\\\", \\\"{x:1541,y:639,t:1527009527534};\\\", \\\"{x:1525,y:633,t:1527009527550};\\\", \\\"{x:1512,y:629,t:1527009527568};\\\", \\\"{x:1503,y:625,t:1527009527585};\\\", \\\"{x:1490,y:622,t:1527009527600};\\\", \\\"{x:1471,y:615,t:1527009527618};\\\", \\\"{x:1453,y:609,t:1527009527634};\\\", \\\"{x:1429,y:603,t:1527009527650};\\\", \\\"{x:1420,y:600,t:1527009527667};\\\", \\\"{x:1415,y:598,t:1527009527685};\\\", \\\"{x:1412,y:598,t:1527009527701};\\\", \\\"{x:1411,y:598,t:1527009527717};\\\", \\\"{x:1410,y:598,t:1527009527778};\\\", \\\"{x:1408,y:597,t:1527009527786};\\\", \\\"{x:1407,y:597,t:1527009527800};\\\", \\\"{x:1404,y:597,t:1527009527817};\\\", \\\"{x:1400,y:597,t:1527009527834};\\\", \\\"{x:1397,y:597,t:1527009527852};\\\", \\\"{x:1396,y:598,t:1527009527891};\\\", \\\"{x:1396,y:599,t:1527009527901};\\\", \\\"{x:1394,y:602,t:1527009527918};\\\", \\\"{x:1394,y:606,t:1527009527934};\\\", \\\"{x:1394,y:612,t:1527009527952};\\\", \\\"{x:1396,y:617,t:1527009527968};\\\", \\\"{x:1399,y:626,t:1527009527985};\\\", \\\"{x:1403,y:631,t:1527009528002};\\\", \\\"{x:1411,y:640,t:1527009528017};\\\", \\\"{x:1431,y:655,t:1527009528034};\\\", \\\"{x:1445,y:664,t:1527009528052};\\\", \\\"{x:1464,y:672,t:1527009528067};\\\", \\\"{x:1479,y:678,t:1527009528085};\\\", \\\"{x:1487,y:683,t:1527009528102};\\\", \\\"{x:1495,y:688,t:1527009528118};\\\", \\\"{x:1500,y:690,t:1527009528135};\\\", \\\"{x:1501,y:690,t:1527009528152};\\\", \\\"{x:1502,y:691,t:1527009528168};\\\", \\\"{x:1502,y:694,t:1527009528184};\\\", \\\"{x:1504,y:697,t:1527009528201};\\\", \\\"{x:1511,y:710,t:1527009528218};\\\", \\\"{x:1516,y:722,t:1527009528234};\\\", \\\"{x:1522,y:741,t:1527009528251};\\\", \\\"{x:1526,y:766,t:1527009528268};\\\", \\\"{x:1526,y:795,t:1527009528285};\\\", \\\"{x:1526,y:822,t:1527009528301};\\\", \\\"{x:1526,y:844,t:1527009528318};\\\", \\\"{x:1522,y:864,t:1527009528335};\\\", \\\"{x:1515,y:876,t:1527009528352};\\\", \\\"{x:1510,y:885,t:1527009528368};\\\", \\\"{x:1504,y:891,t:1527009528385};\\\", \\\"{x:1496,y:894,t:1527009528402};\\\", \\\"{x:1490,y:895,t:1527009528418};\\\", \\\"{x:1475,y:895,t:1527009528435};\\\", \\\"{x:1460,y:891,t:1527009528451};\\\", \\\"{x:1434,y:883,t:1527009528468};\\\", \\\"{x:1408,y:879,t:1527009528484};\\\", \\\"{x:1396,y:877,t:1527009528502};\\\", \\\"{x:1388,y:875,t:1527009528518};\\\", \\\"{x:1380,y:872,t:1527009528535};\\\", \\\"{x:1373,y:871,t:1527009528552};\\\", \\\"{x:1358,y:867,t:1527009528569};\\\", \\\"{x:1338,y:863,t:1527009528585};\\\", \\\"{x:1303,y:860,t:1527009528601};\\\", \\\"{x:1292,y:858,t:1527009528618};\\\", \\\"{x:1283,y:858,t:1527009528634};\\\", \\\"{x:1280,y:858,t:1527009528651};\\\", \\\"{x:1275,y:858,t:1527009528668};\\\", \\\"{x:1270,y:858,t:1527009528684};\\\", \\\"{x:1266,y:857,t:1527009528700};\\\", \\\"{x:1262,y:856,t:1527009528717};\\\", \\\"{x:1252,y:853,t:1527009528735};\\\", \\\"{x:1246,y:853,t:1527009528751};\\\", \\\"{x:1238,y:853,t:1527009528768};\\\", \\\"{x:1237,y:853,t:1527009528785};\\\", \\\"{x:1236,y:853,t:1527009528874};\\\", \\\"{x:1235,y:853,t:1527009528885};\\\", \\\"{x:1234,y:852,t:1527009528905};\\\", \\\"{x:1233,y:851,t:1527009528986};\\\", \\\"{x:1232,y:849,t:1527009529002};\\\", \\\"{x:1230,y:846,t:1527009529018};\\\", \\\"{x:1227,y:842,t:1527009529036};\\\", \\\"{x:1221,y:835,t:1527009529052};\\\", \\\"{x:1215,y:828,t:1527009529071};\\\", \\\"{x:1213,y:826,t:1527009529085};\\\", \\\"{x:1210,y:824,t:1527009529102};\\\", \\\"{x:1210,y:823,t:1527009529118};\\\", \\\"{x:1209,y:822,t:1527009529135};\\\", \\\"{x:1208,y:822,t:1527009529674};\\\", \\\"{x:1207,y:822,t:1527009529994};\\\", \\\"{x:1207,y:820,t:1527009530010};\\\", \\\"{x:1206,y:817,t:1527009530020};\\\", \\\"{x:1205,y:816,t:1527009530036};\\\", \\\"{x:1205,y:813,t:1527009530052};\\\", \\\"{x:1204,y:812,t:1527009530070};\\\", \\\"{x:1204,y:810,t:1527009530562};\\\", \\\"{x:1204,y:806,t:1527009530571};\\\", \\\"{x:1202,y:802,t:1527009530586};\\\", \\\"{x:1201,y:797,t:1527009530603};\\\", \\\"{x:1201,y:795,t:1527009530619};\\\", \\\"{x:1201,y:793,t:1527009530636};\\\", \\\"{x:1201,y:792,t:1527009530653};\\\", \\\"{x:1201,y:791,t:1527009530689};\\\", \\\"{x:1200,y:791,t:1527009530737};\\\", \\\"{x:1199,y:789,t:1527009530753};\\\", \\\"{x:1199,y:788,t:1527009530793};\\\", \\\"{x:1198,y:787,t:1527009530803};\\\", \\\"{x:1198,y:786,t:1527009530841};\\\", \\\"{x:1198,y:785,t:1527009530857};\\\", \\\"{x:1198,y:783,t:1527009530869};\\\", \\\"{x:1198,y:781,t:1527009530886};\\\", \\\"{x:1198,y:779,t:1527009530903};\\\", \\\"{x:1199,y:773,t:1527009530919};\\\", \\\"{x:1200,y:769,t:1527009530937};\\\", \\\"{x:1209,y:751,t:1527009530954};\\\", \\\"{x:1213,y:742,t:1527009530970};\\\", \\\"{x:1214,y:738,t:1527009530986};\\\", \\\"{x:1217,y:736,t:1527009533141};\\\", \\\"{x:1217,y:738,t:1527009533962};\\\", \\\"{x:1217,y:741,t:1527009533973};\\\", \\\"{x:1218,y:753,t:1527009533991};\\\", \\\"{x:1222,y:768,t:1527009534005};\\\", \\\"{x:1229,y:788,t:1527009534022};\\\", \\\"{x:1239,y:806,t:1527009534039};\\\", \\\"{x:1248,y:825,t:1527009534055};\\\", \\\"{x:1254,y:840,t:1527009534072};\\\", \\\"{x:1259,y:854,t:1527009534088};\\\", \\\"{x:1262,y:858,t:1527009534105};\\\", \\\"{x:1262,y:859,t:1527009534123};\\\", \\\"{x:1262,y:860,t:1527009534140};\\\", \\\"{x:1260,y:860,t:1527009534202};\\\", \\\"{x:1257,y:860,t:1527009534209};\\\", \\\"{x:1254,y:857,t:1527009534225};\\\", \\\"{x:1250,y:854,t:1527009534240};\\\", \\\"{x:1241,y:846,t:1527009534256};\\\", \\\"{x:1230,y:836,t:1527009534273};\\\", \\\"{x:1208,y:815,t:1527009534289};\\\", \\\"{x:1196,y:803,t:1527009534305};\\\", \\\"{x:1190,y:798,t:1527009534322};\\\", \\\"{x:1189,y:797,t:1527009534340};\\\", \\\"{x:1188,y:795,t:1527009534355};\\\", \\\"{x:1187,y:794,t:1527009534373};\\\", \\\"{x:1185,y:791,t:1527009534390};\\\", \\\"{x:1182,y:785,t:1527009534406};\\\", \\\"{x:1181,y:782,t:1527009534423};\\\", \\\"{x:1177,y:777,t:1527009534440};\\\", \\\"{x:1174,y:775,t:1527009534456};\\\", \\\"{x:1173,y:774,t:1527009534473};\\\", \\\"{x:1170,y:770,t:1527009534489};\\\", \\\"{x:1168,y:766,t:1527009534506};\\\", \\\"{x:1166,y:763,t:1527009534523};\\\", \\\"{x:1164,y:758,t:1527009534539};\\\", \\\"{x:1163,y:757,t:1527009534556};\\\", \\\"{x:1162,y:756,t:1527009534573};\\\", \\\"{x:1162,y:755,t:1527009534590};\\\", \\\"{x:1162,y:754,t:1527009534607};\\\", \\\"{x:1162,y:753,t:1527009534623};\\\", \\\"{x:1162,y:751,t:1527009534650};\\\", \\\"{x:1162,y:750,t:1527009534658};\\\", \\\"{x:1164,y:750,t:1527009534673};\\\", \\\"{x:1177,y:762,t:1527009534691};\\\", \\\"{x:1191,y:770,t:1527009534707};\\\", \\\"{x:1208,y:776,t:1527009534723};\\\", \\\"{x:1220,y:779,t:1527009534740};\\\", \\\"{x:1222,y:780,t:1527009534757};\\\", \\\"{x:1223,y:780,t:1527009534773};\\\", \\\"{x:1216,y:775,t:1527009534915};\\\", \\\"{x:1209,y:773,t:1527009534924};\\\", \\\"{x:1193,y:764,t:1527009534940};\\\", \\\"{x:1184,y:762,t:1527009534958};\\\", \\\"{x:1183,y:762,t:1527009534973};\\\", \\\"{x:1183,y:761,t:1527009535347};\\\", \\\"{x:1181,y:760,t:1527009535858};\\\", \\\"{x:1180,y:760,t:1527009535915};\\\", \\\"{x:1179,y:761,t:1527009535946};\\\", \\\"{x:1178,y:761,t:1527009535986};\\\", \\\"{x:1177,y:761,t:1527009536010};\\\", \\\"{x:1177,y:762,t:1527009537002};\\\", \\\"{x:1177,y:763,t:1527009537010};\\\", \\\"{x:1177,y:764,t:1527009537025};\\\", \\\"{x:1179,y:767,t:1527009537041};\\\", \\\"{x:1181,y:768,t:1527009537058};\\\", \\\"{x:1181,y:769,t:1527009537114};\\\", \\\"{x:1182,y:770,t:1527009537243};\\\", \\\"{x:1182,y:771,t:1527009537259};\\\", \\\"{x:1184,y:773,t:1527009537378};\\\", \\\"{x:1184,y:775,t:1527009537392};\\\", \\\"{x:1185,y:786,t:1527009537409};\\\", \\\"{x:1187,y:800,t:1527009537425};\\\", \\\"{x:1189,y:817,t:1527009537442};\\\", \\\"{x:1192,y:832,t:1527009537459};\\\", \\\"{x:1193,y:844,t:1527009537476};\\\", \\\"{x:1196,y:860,t:1527009537492};\\\", \\\"{x:1200,y:876,t:1527009537509};\\\", \\\"{x:1203,y:896,t:1527009537525};\\\", \\\"{x:1204,y:911,t:1527009537542};\\\", \\\"{x:1208,y:924,t:1527009537559};\\\", \\\"{x:1209,y:925,t:1527009537576};\\\", \\\"{x:1210,y:926,t:1527009537592};\\\", \\\"{x:1211,y:926,t:1527009537608};\\\", \\\"{x:1217,y:927,t:1527009537625};\\\", \\\"{x:1218,y:927,t:1527009537641};\\\", \\\"{x:1218,y:929,t:1527009537681};\\\", \\\"{x:1218,y:932,t:1527009537705};\\\", \\\"{x:1219,y:934,t:1527009537713};\\\", \\\"{x:1219,y:935,t:1527009537817};\\\", \\\"{x:1220,y:935,t:1527009537833};\\\", \\\"{x:1221,y:935,t:1527009538026};\\\", \\\"{x:1223,y:936,t:1527009538459};\\\", \\\"{x:1223,y:937,t:1527009538546};\\\", \\\"{x:1224,y:937,t:1527009538850};\\\", \\\"{x:1225,y:936,t:1527009538860};\\\", \\\"{x:1226,y:933,t:1527009538876};\\\", \\\"{x:1227,y:930,t:1527009538893};\\\", \\\"{x:1230,y:925,t:1527009538910};\\\", \\\"{x:1232,y:919,t:1527009538927};\\\", \\\"{x:1234,y:917,t:1527009538943};\\\", \\\"{x:1234,y:915,t:1527009538962};\\\", \\\"{x:1234,y:913,t:1527009538986};\\\", \\\"{x:1234,y:912,t:1527009539002};\\\", \\\"{x:1234,y:911,t:1527009539018};\\\", \\\"{x:1234,y:910,t:1527009539033};\\\", \\\"{x:1234,y:909,t:1527009539050};\\\", \\\"{x:1234,y:908,t:1527009539066};\\\", \\\"{x:1234,y:907,t:1527009539077};\\\", \\\"{x:1234,y:906,t:1527009539093};\\\", \\\"{x:1236,y:905,t:1527009539111};\\\", \\\"{x:1238,y:903,t:1527009539138};\\\", \\\"{x:1240,y:902,t:1527009539154};\\\", \\\"{x:1242,y:901,t:1527009539162};\\\", \\\"{x:1247,y:898,t:1527009539177};\\\", \\\"{x:1261,y:896,t:1527009539194};\\\", \\\"{x:1291,y:893,t:1527009539209};\\\", \\\"{x:1316,y:891,t:1527009539227};\\\", \\\"{x:1332,y:891,t:1527009539243};\\\", \\\"{x:1351,y:891,t:1527009539259};\\\", \\\"{x:1368,y:891,t:1527009539277};\\\", \\\"{x:1377,y:891,t:1527009539293};\\\", \\\"{x:1381,y:891,t:1527009539309};\\\", \\\"{x:1383,y:892,t:1527009539327};\\\", \\\"{x:1387,y:895,t:1527009539344};\\\", \\\"{x:1395,y:898,t:1527009539359};\\\", \\\"{x:1405,y:902,t:1527009539376};\\\", \\\"{x:1415,y:905,t:1527009539393};\\\", \\\"{x:1417,y:906,t:1527009539410};\\\", \\\"{x:1418,y:907,t:1527009539475};\\\", \\\"{x:1418,y:908,t:1527009539627};\\\", \\\"{x:1417,y:908,t:1527009539706};\\\", \\\"{x:1415,y:909,t:1527009539714};\\\", \\\"{x:1409,y:909,t:1527009539728};\\\", \\\"{x:1389,y:909,t:1527009539744};\\\", \\\"{x:1331,y:895,t:1527009539761};\\\", \\\"{x:1242,y:870,t:1527009539777};\\\", \\\"{x:1081,y:823,t:1527009539795};\\\", \\\"{x:979,y:793,t:1527009539810};\\\", \\\"{x:903,y:765,t:1527009539826};\\\", \\\"{x:832,y:740,t:1527009539843};\\\", \\\"{x:787,y:716,t:1527009539860};\\\", \\\"{x:737,y:696,t:1527009539877};\\\", \\\"{x:714,y:685,t:1527009539893};\\\", \\\"{x:679,y:669,t:1527009539911};\\\", \\\"{x:641,y:655,t:1527009539927};\\\", \\\"{x:616,y:639,t:1527009539944};\\\", \\\"{x:596,y:628,t:1527009539961};\\\", \\\"{x:581,y:621,t:1527009539977};\\\", \\\"{x:577,y:618,t:1527009539994};\\\", \\\"{x:577,y:617,t:1527009540010};\\\", \\\"{x:576,y:617,t:1527009540056};\\\", \\\"{x:576,y:615,t:1527009540065};\\\", \\\"{x:576,y:612,t:1527009540078};\\\", \\\"{x:576,y:611,t:1527009540096};\\\", \\\"{x:576,y:609,t:1527009540110};\\\", \\\"{x:576,y:605,t:1527009540127};\\\", \\\"{x:576,y:603,t:1527009540143};\\\", \\\"{x:576,y:600,t:1527009540160};\\\", \\\"{x:573,y:598,t:1527009540178};\\\", \\\"{x:573,y:595,t:1527009540195};\\\", \\\"{x:566,y:588,t:1527009540211};\\\", \\\"{x:554,y:580,t:1527009540227};\\\", \\\"{x:547,y:574,t:1527009540244};\\\", \\\"{x:542,y:568,t:1527009540261};\\\", \\\"{x:536,y:565,t:1527009540277};\\\", \\\"{x:535,y:565,t:1527009540295};\\\", \\\"{x:533,y:565,t:1527009540346};\\\", \\\"{x:529,y:563,t:1527009540361};\\\", \\\"{x:520,y:561,t:1527009540379};\\\", \\\"{x:516,y:559,t:1527009540395};\\\", \\\"{x:515,y:558,t:1527009540434};\\\", \\\"{x:510,y:558,t:1527009540445};\\\", \\\"{x:494,y:553,t:1527009540463};\\\", \\\"{x:468,y:543,t:1527009540478};\\\", \\\"{x:444,y:536,t:1527009540495};\\\", \\\"{x:424,y:528,t:1527009540511};\\\", \\\"{x:401,y:519,t:1527009540528};\\\", \\\"{x:380,y:514,t:1527009540545};\\\", \\\"{x:361,y:507,t:1527009540561};\\\", \\\"{x:336,y:502,t:1527009540577};\\\", \\\"{x:329,y:501,t:1527009540595};\\\", \\\"{x:327,y:501,t:1527009540611};\\\", \\\"{x:326,y:501,t:1527009540628};\\\", \\\"{x:325,y:501,t:1527009540645};\\\", \\\"{x:322,y:501,t:1527009540661};\\\", \\\"{x:319,y:501,t:1527009540677};\\\", \\\"{x:314,y:501,t:1527009540694};\\\", \\\"{x:308,y:501,t:1527009540712};\\\", \\\"{x:305,y:501,t:1527009540728};\\\", \\\"{x:300,y:501,t:1527009540745};\\\", \\\"{x:290,y:501,t:1527009540761};\\\", \\\"{x:280,y:501,t:1527009540777};\\\", \\\"{x:263,y:503,t:1527009540795};\\\", \\\"{x:239,y:505,t:1527009540812};\\\", \\\"{x:218,y:505,t:1527009540828};\\\", \\\"{x:192,y:506,t:1527009540845};\\\", \\\"{x:181,y:506,t:1527009540862};\\\", \\\"{x:176,y:506,t:1527009540879};\\\", \\\"{x:175,y:506,t:1527009540897};\\\", \\\"{x:177,y:506,t:1527009541353};\\\", \\\"{x:189,y:514,t:1527009541362};\\\", \\\"{x:236,y:536,t:1527009541379};\\\", \\\"{x:273,y:555,t:1527009541395};\\\", \\\"{x:309,y:572,t:1527009541412};\\\", \\\"{x:338,y:591,t:1527009541429};\\\", \\\"{x:367,y:616,t:1527009541445};\\\", \\\"{x:389,y:647,t:1527009541462};\\\", \\\"{x:418,y:675,t:1527009541479};\\\", \\\"{x:457,y:715,t:1527009541494};\\\", \\\"{x:492,y:746,t:1527009541512};\\\", \\\"{x:513,y:762,t:1527009541529};\\\", \\\"{x:516,y:766,t:1527009541545};\\\", \\\"{x:516,y:763,t:1527009541625};\\\", \\\"{x:516,y:762,t:1527009541649};\\\", \\\"{x:516,y:761,t:1527009541673};\\\", \\\"{x:516,y:760,t:1527009541689};\\\", \\\"{x:516,y:759,t:1527009541697};\\\", \\\"{x:516,y:755,t:1527009541712};\\\", \\\"{x:516,y:736,t:1527009541730};\\\", \\\"{x:516,y:722,t:1527009541747};\\\", \\\"{x:516,y:719,t:1527009541763};\\\", \\\"{x:516,y:717,t:1527009541780};\\\", \\\"{x:516,y:716,t:1527009541796};\\\", \\\"{x:515,y:718,t:1527009542026};\\\", \\\"{x:514,y:719,t:1527009542042};\\\", \\\"{x:514,y:722,t:1527009542059};\\\", \\\"{x:513,y:725,t:1527009542079};\\\", \\\"{x:513,y:727,t:1527009542095};\\\", \\\"{x:515,y:727,t:1527009542433};\\\", \\\"{x:517,y:725,t:1527009542449};\\\", \\\"{x:519,y:725,t:1527009542463};\\\", \\\"{x:523,y:724,t:1527009542480};\\\", \\\"{x:525,y:724,t:1527009542496};\\\", \\\"{x:530,y:724,t:1527009542512};\\\", \\\"{x:537,y:722,t:1527009542529};\\\", \\\"{x:539,y:722,t:1527009542545};\\\", \\\"{x:541,y:722,t:1527009542563};\\\", \\\"{x:542,y:722,t:1527009542580};\\\" ] }, { \\\"rt\\\": 15851, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 715614, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B -12 PM-01 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:546,y:719,t:1527009545972};\\\", \\\"{x:576,y:710,t:1527009545987};\\\", \\\"{x:594,y:704,t:1527009546008};\\\", \\\"{x:606,y:699,t:1527009546016};\\\", \\\"{x:635,y:687,t:1527009546032};\\\", \\\"{x:660,y:677,t:1527009546049};\\\", \\\"{x:673,y:672,t:1527009546066};\\\", \\\"{x:687,y:665,t:1527009546082};\\\", \\\"{x:704,y:657,t:1527009546099};\\\", \\\"{x:724,y:646,t:1527009546116};\\\", \\\"{x:764,y:622,t:1527009546133};\\\", \\\"{x:823,y:594,t:1527009546150};\\\", \\\"{x:843,y:583,t:1527009546166};\\\", \\\"{x:864,y:572,t:1527009546182};\\\", \\\"{x:884,y:563,t:1527009546199};\\\", \\\"{x:904,y:555,t:1527009546217};\\\", \\\"{x:953,y:549,t:1527009546234};\\\", \\\"{x:974,y:546,t:1527009546249};\\\", \\\"{x:1047,y:545,t:1527009546265};\\\", \\\"{x:1112,y:546,t:1527009546283};\\\", \\\"{x:1161,y:556,t:1527009546299};\\\", \\\"{x:1246,y:573,t:1527009546315};\\\", \\\"{x:1312,y:592,t:1527009546333};\\\", \\\"{x:1396,y:619,t:1527009546350};\\\", \\\"{x:1460,y:647,t:1527009546366};\\\", \\\"{x:1527,y:682,t:1527009546383};\\\", \\\"{x:1573,y:703,t:1527009546400};\\\", \\\"{x:1605,y:728,t:1527009546416};\\\", \\\"{x:1627,y:747,t:1527009546433};\\\", \\\"{x:1634,y:756,t:1527009546449};\\\", \\\"{x:1638,y:762,t:1527009546466};\\\", \\\"{x:1639,y:765,t:1527009546483};\\\", \\\"{x:1639,y:766,t:1527009546514};\\\", \\\"{x:1638,y:768,t:1527009546522};\\\", \\\"{x:1637,y:768,t:1527009546533};\\\", \\\"{x:1632,y:769,t:1527009546550};\\\", \\\"{x:1620,y:770,t:1527009546565};\\\", \\\"{x:1605,y:770,t:1527009546583};\\\", \\\"{x:1568,y:757,t:1527009546600};\\\", \\\"{x:1489,y:733,t:1527009546616};\\\", \\\"{x:1410,y:721,t:1527009546633};\\\", \\\"{x:1383,y:718,t:1527009546650};\\\", \\\"{x:1374,y:716,t:1527009546667};\\\", \\\"{x:1373,y:716,t:1527009546683};\\\", \\\"{x:1373,y:715,t:1527009547042};\\\", \\\"{x:1370,y:712,t:1527009547050};\\\", \\\"{x:1369,y:709,t:1527009547067};\\\", \\\"{x:1368,y:708,t:1527009547084};\\\", \\\"{x:1367,y:707,t:1527009547100};\\\", \\\"{x:1366,y:706,t:1527009547117};\\\", \\\"{x:1366,y:705,t:1527009547170};\\\", \\\"{x:1365,y:705,t:1527009547386};\\\", \\\"{x:1352,y:702,t:1527009547402};\\\", \\\"{x:1341,y:699,t:1527009547418};\\\", \\\"{x:1330,y:695,t:1527009547434};\\\", \\\"{x:1327,y:695,t:1527009547452};\\\", \\\"{x:1326,y:694,t:1527009547497};\\\", \\\"{x:1327,y:694,t:1527009547602};\\\", \\\"{x:1334,y:691,t:1527009547617};\\\", \\\"{x:1335,y:690,t:1527009547642};\\\", \\\"{x:1336,y:690,t:1527009547666};\\\", \\\"{x:1337,y:690,t:1527009547939};\\\", \\\"{x:1339,y:690,t:1527009548186};\\\", \\\"{x:1342,y:692,t:1527009548202};\\\", \\\"{x:1342,y:697,t:1527009548222};\\\", \\\"{x:1342,y:701,t:1527009548235};\\\", \\\"{x:1343,y:704,t:1527009548252};\\\", \\\"{x:1346,y:711,t:1527009548268};\\\", \\\"{x:1346,y:715,t:1527009548285};\\\", \\\"{x:1346,y:721,t:1527009548302};\\\", \\\"{x:1346,y:724,t:1527009548317};\\\", \\\"{x:1346,y:728,t:1527009548334};\\\", \\\"{x:1346,y:734,t:1527009548352};\\\", \\\"{x:1350,y:743,t:1527009548369};\\\", \\\"{x:1350,y:747,t:1527009548385};\\\", \\\"{x:1350,y:751,t:1527009548402};\\\", \\\"{x:1350,y:752,t:1527009548419};\\\", \\\"{x:1350,y:754,t:1527009548434};\\\", \\\"{x:1350,y:755,t:1527009548452};\\\", \\\"{x:1350,y:758,t:1527009548469};\\\", \\\"{x:1350,y:765,t:1527009548485};\\\", \\\"{x:1350,y:772,t:1527009548502};\\\", \\\"{x:1350,y:782,t:1527009548519};\\\", \\\"{x:1350,y:793,t:1527009548535};\\\", \\\"{x:1350,y:802,t:1527009548552};\\\", \\\"{x:1349,y:815,t:1527009548569};\\\", \\\"{x:1348,y:826,t:1527009548585};\\\", \\\"{x:1348,y:836,t:1527009548602};\\\", \\\"{x:1348,y:844,t:1527009548619};\\\", \\\"{x:1348,y:852,t:1527009548635};\\\", \\\"{x:1347,y:857,t:1527009548652};\\\", \\\"{x:1347,y:863,t:1527009548669};\\\", \\\"{x:1347,y:869,t:1527009548686};\\\", \\\"{x:1346,y:873,t:1527009548702};\\\", \\\"{x:1346,y:878,t:1527009548719};\\\", \\\"{x:1346,y:880,t:1527009548736};\\\", \\\"{x:1346,y:886,t:1527009548752};\\\", \\\"{x:1346,y:891,t:1527009548769};\\\", \\\"{x:1346,y:895,t:1527009548786};\\\", \\\"{x:1346,y:899,t:1527009548802};\\\", \\\"{x:1346,y:905,t:1527009548819};\\\", \\\"{x:1346,y:909,t:1527009548836};\\\", \\\"{x:1346,y:916,t:1527009548852};\\\", \\\"{x:1346,y:922,t:1527009548869};\\\", \\\"{x:1346,y:928,t:1527009548887};\\\", \\\"{x:1346,y:935,t:1527009548903};\\\", \\\"{x:1346,y:941,t:1527009548920};\\\", \\\"{x:1346,y:945,t:1527009548937};\\\", \\\"{x:1346,y:953,t:1527009548954};\\\", \\\"{x:1346,y:956,t:1527009548970};\\\", \\\"{x:1347,y:963,t:1527009548986};\\\", \\\"{x:1349,y:965,t:1527009549004};\\\", \\\"{x:1351,y:967,t:1527009549020};\\\", \\\"{x:1353,y:968,t:1527009549036};\\\", \\\"{x:1358,y:970,t:1527009549053};\\\", \\\"{x:1366,y:971,t:1527009549069};\\\", \\\"{x:1382,y:971,t:1527009549087};\\\", \\\"{x:1404,y:971,t:1527009549103};\\\", \\\"{x:1421,y:971,t:1527009549120};\\\", \\\"{x:1447,y:971,t:1527009549137};\\\", \\\"{x:1480,y:970,t:1527009549154};\\\", \\\"{x:1495,y:970,t:1527009549169};\\\", \\\"{x:1505,y:967,t:1527009549187};\\\", \\\"{x:1509,y:967,t:1527009549204};\\\", \\\"{x:1511,y:965,t:1527009549220};\\\", \\\"{x:1513,y:963,t:1527009549236};\\\", \\\"{x:1515,y:963,t:1527009549253};\\\", \\\"{x:1518,y:961,t:1527009549271};\\\", \\\"{x:1520,y:960,t:1527009549287};\\\", \\\"{x:1520,y:959,t:1527009549303};\\\", \\\"{x:1523,y:957,t:1527009549320};\\\", \\\"{x:1529,y:954,t:1527009549337};\\\", \\\"{x:1538,y:951,t:1527009549354};\\\", \\\"{x:1540,y:949,t:1527009549370};\\\", \\\"{x:1545,y:948,t:1527009549386};\\\", \\\"{x:1551,y:947,t:1527009549403};\\\", \\\"{x:1555,y:947,t:1527009549420};\\\", \\\"{x:1563,y:947,t:1527009549436};\\\", \\\"{x:1568,y:947,t:1527009549453};\\\", \\\"{x:1577,y:947,t:1527009549469};\\\", \\\"{x:1585,y:947,t:1527009549487};\\\", \\\"{x:1591,y:947,t:1527009549503};\\\", \\\"{x:1592,y:947,t:1527009549520};\\\", \\\"{x:1594,y:947,t:1527009549537};\\\", \\\"{x:1595,y:947,t:1527009549561};\\\", \\\"{x:1596,y:947,t:1527009549609};\\\", \\\"{x:1597,y:947,t:1527009549620};\\\", \\\"{x:1598,y:947,t:1527009549637};\\\", \\\"{x:1600,y:947,t:1527009549653};\\\", \\\"{x:1603,y:949,t:1527009549670};\\\", \\\"{x:1609,y:953,t:1527009549687};\\\", \\\"{x:1613,y:956,t:1527009549704};\\\", \\\"{x:1620,y:959,t:1527009549720};\\\", \\\"{x:1623,y:962,t:1527009549738};\\\", \\\"{x:1624,y:962,t:1527009549753};\\\", \\\"{x:1623,y:963,t:1527009550090};\\\", \\\"{x:1622,y:963,t:1527009550113};\\\", \\\"{x:1622,y:961,t:1527009551539};\\\", \\\"{x:1622,y:960,t:1527009551556};\\\", \\\"{x:1622,y:958,t:1527009551577};\\\", \\\"{x:1622,y:957,t:1527009551593};\\\", \\\"{x:1622,y:956,t:1527009551625};\\\", \\\"{x:1622,y:955,t:1527009551674};\\\", \\\"{x:1622,y:954,t:1527009551746};\\\", \\\"{x:1622,y:953,t:1527009551834};\\\", \\\"{x:1622,y:952,t:1527009551857};\\\", \\\"{x:1617,y:950,t:1527009551874};\\\", \\\"{x:1614,y:950,t:1527009551889};\\\", \\\"{x:1610,y:951,t:1527009551907};\\\", \\\"{x:1607,y:951,t:1527009551924};\\\", \\\"{x:1606,y:952,t:1527009551940};\\\", \\\"{x:1605,y:953,t:1527009551956};\\\", \\\"{x:1604,y:954,t:1527009552002};\\\", \\\"{x:1604,y:955,t:1527009552234};\\\", \\\"{x:1604,y:956,t:1527009552242};\\\", \\\"{x:1604,y:957,t:1527009552257};\\\", \\\"{x:1605,y:957,t:1527009552274};\\\", \\\"{x:1608,y:959,t:1527009552290};\\\", \\\"{x:1609,y:960,t:1527009552418};\\\", \\\"{x:1609,y:962,t:1527009552434};\\\", \\\"{x:1613,y:963,t:1527009552442};\\\", \\\"{x:1613,y:964,t:1527009552457};\\\", \\\"{x:1613,y:966,t:1527009552473};\\\", \\\"{x:1613,y:967,t:1527009552730};\\\", \\\"{x:1613,y:968,t:1527009552740};\\\", \\\"{x:1611,y:968,t:1527009556530};\\\", \\\"{x:1526,y:933,t:1527009556545};\\\", \\\"{x:1387,y:888,t:1527009556561};\\\", \\\"{x:1218,y:838,t:1527009556578};\\\", \\\"{x:1041,y:788,t:1527009556595};\\\", \\\"{x:892,y:745,t:1527009556612};\\\", \\\"{x:773,y:707,t:1527009556628};\\\", \\\"{x:721,y:688,t:1527009556645};\\\", \\\"{x:694,y:681,t:1527009556662};\\\", \\\"{x:682,y:675,t:1527009556678};\\\", \\\"{x:678,y:675,t:1527009556695};\\\", \\\"{x:659,y:668,t:1527009556713};\\\", \\\"{x:620,y:657,t:1527009556728};\\\", \\\"{x:527,y:626,t:1527009556745};\\\", \\\"{x:448,y:598,t:1527009556762};\\\", \\\"{x:365,y:571,t:1527009556779};\\\", \\\"{x:328,y:558,t:1527009556791};\\\", \\\"{x:272,y:534,t:1527009556808};\\\", \\\"{x:248,y:521,t:1527009556824};\\\", \\\"{x:245,y:521,t:1527009556841};\\\", \\\"{x:246,y:519,t:1527009556881};\\\", \\\"{x:249,y:518,t:1527009556891};\\\", \\\"{x:258,y:513,t:1527009556909};\\\", \\\"{x:265,y:510,t:1527009556925};\\\", \\\"{x:276,y:503,t:1527009556942};\\\", \\\"{x:290,y:494,t:1527009556959};\\\", \\\"{x:302,y:492,t:1527009556974};\\\", \\\"{x:327,y:488,t:1527009556991};\\\", \\\"{x:348,y:488,t:1527009557009};\\\", \\\"{x:365,y:488,t:1527009557025};\\\", \\\"{x:390,y:494,t:1527009557041};\\\", \\\"{x:403,y:497,t:1527009557058};\\\", \\\"{x:410,y:500,t:1527009557075};\\\", \\\"{x:411,y:500,t:1527009557092};\\\", \\\"{x:411,y:501,t:1527009557137};\\\", \\\"{x:409,y:504,t:1527009557145};\\\", \\\"{x:406,y:508,t:1527009557158};\\\", \\\"{x:406,y:512,t:1527009557175};\\\", \\\"{x:407,y:519,t:1527009557192};\\\", \\\"{x:409,y:525,t:1527009557209};\\\", \\\"{x:413,y:532,t:1527009557225};\\\", \\\"{x:420,y:535,t:1527009557241};\\\", \\\"{x:445,y:542,t:1527009557258};\\\", \\\"{x:473,y:544,t:1527009557275};\\\", \\\"{x:506,y:549,t:1527009557293};\\\", \\\"{x:534,y:555,t:1527009557308};\\\", \\\"{x:561,y:555,t:1527009557325};\\\", \\\"{x:571,y:555,t:1527009557341};\\\", \\\"{x:572,y:555,t:1527009557358};\\\", \\\"{x:573,y:555,t:1527009557441};\\\", \\\"{x:575,y:555,t:1527009557546};\\\", \\\"{x:578,y:555,t:1527009557559};\\\", \\\"{x:583,y:555,t:1527009557575};\\\", \\\"{x:593,y:556,t:1527009557593};\\\", \\\"{x:600,y:560,t:1527009557609};\\\", \\\"{x:601,y:562,t:1527009557649};\\\", \\\"{x:602,y:563,t:1527009557666};\\\", \\\"{x:603,y:564,t:1527009557697};\\\", \\\"{x:603,y:565,t:1527009557721};\\\", \\\"{x:604,y:565,t:1527009557729};\\\", \\\"{x:605,y:566,t:1527009557745};\\\", \\\"{x:605,y:567,t:1527009557761};\\\", \\\"{x:605,y:568,t:1527009557776};\\\", \\\"{x:607,y:571,t:1527009557793};\\\", \\\"{x:608,y:574,t:1527009557808};\\\", \\\"{x:610,y:578,t:1527009557825};\\\", \\\"{x:612,y:581,t:1527009557842};\\\", \\\"{x:612,y:582,t:1527009557937};\\\", \\\"{x:613,y:586,t:1527009558241};\\\", \\\"{x:607,y:601,t:1527009558249};\\\", \\\"{x:601,y:613,t:1527009558259};\\\", \\\"{x:590,y:635,t:1527009558276};\\\", \\\"{x:582,y:654,t:1527009558292};\\\", \\\"{x:578,y:667,t:1527009558309};\\\", \\\"{x:575,y:671,t:1527009558325};\\\", \\\"{x:575,y:675,t:1527009558342};\\\", \\\"{x:575,y:676,t:1527009558359};\\\", \\\"{x:575,y:682,t:1527009558375};\\\", \\\"{x:575,y:683,t:1527009558400};\\\", \\\"{x:575,y:686,t:1527009558408};\\\", \\\"{x:575,y:689,t:1527009558425};\\\", \\\"{x:575,y:692,t:1527009558442};\\\", \\\"{x:573,y:696,t:1527009558459};\\\", \\\"{x:573,y:697,t:1527009558497};\\\", \\\"{x:573,y:698,t:1527009558509};\\\", \\\"{x:573,y:700,t:1527009558526};\\\", \\\"{x:570,y:705,t:1527009558542};\\\", \\\"{x:569,y:711,t:1527009558559};\\\", \\\"{x:567,y:714,t:1527009558576};\\\", \\\"{x:565,y:717,t:1527009558593};\\\", \\\"{x:565,y:718,t:1527009558610};\\\", \\\"{x:565,y:719,t:1527009558722};\\\", \\\"{x:564,y:723,t:1527009558930};\\\", \\\"{x:561,y:723,t:1527009558947};\\\", \\\"{x:561,y:724,t:1527009558968};\\\", \\\"{x:560,y:724,t:1527009558977};\\\", \\\"{x:557,y:725,t:1527009559001};\\\", \\\"{x:557,y:726,t:1527009559016};\\\", \\\"{x:555,y:727,t:1527009559027};\\\", \\\"{x:550,y:727,t:1527009559043};\\\", \\\"{x:550,y:726,t:1527009559681};\\\", \\\"{x:550,y:725,t:1527009559801};\\\", \\\"{x:552,y:725,t:1527009559817};\\\", \\\"{x:554,y:724,t:1527009559828};\\\", \\\"{x:556,y:722,t:1527009559843};\\\", \\\"{x:561,y:721,t:1527009559861};\\\", \\\"{x:563,y:720,t:1527009559878};\\\" ] }, { \\\"rt\\\": 11286, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 728152, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:564,y:719,t:1527009560801};\\\", \\\"{x:565,y:717,t:1527009560824};\\\", \\\"{x:565,y:716,t:1527009560841};\\\", \\\"{x:566,y:716,t:1527009560856};\\\", \\\"{x:566,y:731,t:1527009563754};\\\", \\\"{x:570,y:728,t:1527009563766};\\\", \\\"{x:573,y:721,t:1527009563782};\\\", \\\"{x:576,y:718,t:1527009563798};\\\", \\\"{x:578,y:718,t:1527009563816};\\\", \\\"{x:580,y:715,t:1527009563832};\\\", \\\"{x:586,y:711,t:1527009563849};\\\", \\\"{x:596,y:706,t:1527009563865};\\\", \\\"{x:600,y:703,t:1527009563882};\\\", \\\"{x:603,y:699,t:1527009563899};\\\", \\\"{x:613,y:693,t:1527009563915};\\\", \\\"{x:628,y:688,t:1527009563932};\\\", \\\"{x:647,y:683,t:1527009563950};\\\", \\\"{x:677,y:674,t:1527009563965};\\\", \\\"{x:704,y:668,t:1527009563983};\\\", \\\"{x:749,y:661,t:1527009564000};\\\", \\\"{x:778,y:659,t:1527009564015};\\\", \\\"{x:833,y:658,t:1527009564033};\\\", \\\"{x:892,y:658,t:1527009564050};\\\", \\\"{x:923,y:658,t:1527009564066};\\\", \\\"{x:954,y:658,t:1527009564083};\\\", \\\"{x:996,y:658,t:1527009564100};\\\", \\\"{x:1028,y:658,t:1527009564117};\\\", \\\"{x:1050,y:658,t:1527009564141};\\\", \\\"{x:1062,y:658,t:1527009564158};\\\", \\\"{x:1078,y:658,t:1527009564175};\\\", \\\"{x:1100,y:661,t:1527009564191};\\\", \\\"{x:1117,y:666,t:1527009564208};\\\", \\\"{x:1167,y:678,t:1527009564225};\\\", \\\"{x:1208,y:686,t:1527009564241};\\\", \\\"{x:1245,y:692,t:1527009564258};\\\", \\\"{x:1275,y:697,t:1527009564275};\\\", \\\"{x:1313,y:700,t:1527009564292};\\\", \\\"{x:1346,y:706,t:1527009564308};\\\", \\\"{x:1384,y:710,t:1527009564325};\\\", \\\"{x:1433,y:721,t:1527009564342};\\\", \\\"{x:1489,y:729,t:1527009564359};\\\", \\\"{x:1547,y:736,t:1527009564375};\\\", \\\"{x:1572,y:737,t:1527009564393};\\\", \\\"{x:1593,y:741,t:1527009564409};\\\", \\\"{x:1595,y:742,t:1527009564425};\\\", \\\"{x:1597,y:744,t:1527009564441};\\\", \\\"{x:1598,y:745,t:1527009564459};\\\", \\\"{x:1600,y:748,t:1527009564475};\\\", \\\"{x:1603,y:750,t:1527009564493};\\\", \\\"{x:1605,y:753,t:1527009564509};\\\", \\\"{x:1613,y:762,t:1527009564525};\\\", \\\"{x:1625,y:778,t:1527009564543};\\\", \\\"{x:1638,y:792,t:1527009564560};\\\", \\\"{x:1648,y:808,t:1527009564575};\\\", \\\"{x:1659,y:826,t:1527009564592};\\\", \\\"{x:1668,y:850,t:1527009564609};\\\", \\\"{x:1672,y:861,t:1527009564626};\\\", \\\"{x:1674,y:872,t:1527009564643};\\\", \\\"{x:1674,y:878,t:1527009564659};\\\", \\\"{x:1674,y:879,t:1527009564676};\\\", \\\"{x:1674,y:881,t:1527009564698};\\\", \\\"{x:1674,y:882,t:1527009564729};\\\", \\\"{x:1674,y:883,t:1527009564742};\\\", \\\"{x:1674,y:884,t:1527009564759};\\\", \\\"{x:1672,y:883,t:1527009564874};\\\", \\\"{x:1669,y:880,t:1527009564890};\\\", \\\"{x:1668,y:879,t:1527009564898};\\\", \\\"{x:1664,y:876,t:1527009564909};\\\", \\\"{x:1657,y:871,t:1527009564926};\\\", \\\"{x:1654,y:869,t:1527009564944};\\\", \\\"{x:1652,y:868,t:1527009564959};\\\", \\\"{x:1650,y:868,t:1527009564976};\\\", \\\"{x:1649,y:867,t:1527009564993};\\\", \\\"{x:1647,y:867,t:1527009565123};\\\", \\\"{x:1645,y:867,t:1527009565130};\\\", \\\"{x:1642,y:869,t:1527009565146};\\\", \\\"{x:1639,y:870,t:1527009565161};\\\", \\\"{x:1626,y:882,t:1527009565178};\\\", \\\"{x:1608,y:893,t:1527009565194};\\\", \\\"{x:1588,y:909,t:1527009565211};\\\", \\\"{x:1566,y:924,t:1527009565228};\\\", \\\"{x:1546,y:935,t:1527009565244};\\\", \\\"{x:1527,y:946,t:1527009565261};\\\", \\\"{x:1519,y:951,t:1527009565277};\\\", \\\"{x:1506,y:955,t:1527009565293};\\\", \\\"{x:1501,y:956,t:1527009565310};\\\", \\\"{x:1500,y:957,t:1527009565328};\\\", \\\"{x:1498,y:959,t:1527009565345};\\\", \\\"{x:1495,y:959,t:1527009565506};\\\", \\\"{x:1489,y:959,t:1527009565515};\\\", \\\"{x:1474,y:959,t:1527009565527};\\\", \\\"{x:1436,y:959,t:1527009565544};\\\", \\\"{x:1393,y:962,t:1527009565561};\\\", \\\"{x:1367,y:965,t:1527009565577};\\\", \\\"{x:1347,y:967,t:1527009565594};\\\", \\\"{x:1337,y:968,t:1527009565611};\\\", \\\"{x:1332,y:969,t:1527009565627};\\\", \\\"{x:1330,y:969,t:1527009565644};\\\", \\\"{x:1329,y:969,t:1527009565661};\\\", \\\"{x:1323,y:969,t:1527009565677};\\\", \\\"{x:1317,y:969,t:1527009565694};\\\", \\\"{x:1315,y:969,t:1527009565711};\\\", \\\"{x:1315,y:968,t:1527009565728};\\\", \\\"{x:1314,y:967,t:1527009565753};\\\", \\\"{x:1314,y:966,t:1527009565769};\\\", \\\"{x:1314,y:965,t:1527009565785};\\\", \\\"{x:1314,y:963,t:1527009565834};\\\", \\\"{x:1314,y:962,t:1527009565857};\\\", \\\"{x:1315,y:959,t:1527009566050};\\\", \\\"{x:1317,y:957,t:1527009566062};\\\", \\\"{x:1320,y:955,t:1527009566078};\\\", \\\"{x:1322,y:949,t:1527009566096};\\\", \\\"{x:1323,y:941,t:1527009566112};\\\", \\\"{x:1323,y:924,t:1527009566129};\\\", \\\"{x:1314,y:902,t:1527009566145};\\\", \\\"{x:1308,y:888,t:1527009566162};\\\", \\\"{x:1306,y:882,t:1527009566178};\\\", \\\"{x:1304,y:876,t:1527009566196};\\\", \\\"{x:1304,y:870,t:1527009566213};\\\", \\\"{x:1304,y:862,t:1527009566228};\\\", \\\"{x:1304,y:853,t:1527009566245};\\\", \\\"{x:1306,y:840,t:1527009566263};\\\", \\\"{x:1307,y:830,t:1527009566280};\\\", \\\"{x:1310,y:821,t:1527009566295};\\\", \\\"{x:1312,y:815,t:1527009566312};\\\", \\\"{x:1320,y:800,t:1527009566329};\\\", \\\"{x:1324,y:785,t:1527009566346};\\\", \\\"{x:1331,y:769,t:1527009566362};\\\", \\\"{x:1335,y:758,t:1527009566379};\\\", \\\"{x:1338,y:745,t:1527009566395};\\\", \\\"{x:1340,y:738,t:1527009566412};\\\", \\\"{x:1342,y:733,t:1527009566429};\\\", \\\"{x:1344,y:729,t:1527009566447};\\\", \\\"{x:1345,y:728,t:1527009566462};\\\", \\\"{x:1345,y:727,t:1527009566479};\\\", \\\"{x:1346,y:726,t:1527009566496};\\\", \\\"{x:1346,y:725,t:1527009566512};\\\", \\\"{x:1346,y:724,t:1527009566586};\\\", \\\"{x:1346,y:721,t:1527009566597};\\\", \\\"{x:1346,y:714,t:1527009566612};\\\", \\\"{x:1346,y:707,t:1527009566630};\\\", \\\"{x:1346,y:701,t:1527009566648};\\\", \\\"{x:1346,y:691,t:1527009566664};\\\", \\\"{x:1343,y:682,t:1527009566679};\\\", \\\"{x:1342,y:674,t:1527009566697};\\\", \\\"{x:1338,y:662,t:1527009566713};\\\", \\\"{x:1337,y:657,t:1527009566729};\\\", \\\"{x:1337,y:653,t:1527009566746};\\\", \\\"{x:1337,y:652,t:1527009566763};\\\", \\\"{x:1335,y:650,t:1527009566781};\\\", \\\"{x:1334,y:649,t:1527009566947};\\\", \\\"{x:1321,y:649,t:1527009566954};\\\", \\\"{x:1298,y:649,t:1527009566963};\\\", \\\"{x:1179,y:635,t:1527009566980};\\\", \\\"{x:1022,y:613,t:1527009566997};\\\", \\\"{x:846,y:600,t:1527009567013};\\\", \\\"{x:661,y:573,t:1527009567031};\\\", \\\"{x:481,y:544,t:1527009567047};\\\", \\\"{x:337,y:522,t:1527009567063};\\\", \\\"{x:173,y:503,t:1527009567085};\\\", \\\"{x:120,y:503,t:1527009567102};\\\", \\\"{x:102,y:503,t:1527009567125};\\\", \\\"{x:91,y:509,t:1527009567141};\\\", \\\"{x:88,y:512,t:1527009567158};\\\", \\\"{x:86,y:513,t:1527009567175};\\\", \\\"{x:84,y:516,t:1527009567191};\\\", \\\"{x:82,y:517,t:1527009567208};\\\", \\\"{x:73,y:523,t:1527009567226};\\\", \\\"{x:69,y:524,t:1527009567241};\\\", \\\"{x:65,y:527,t:1527009567258};\\\", \\\"{x:64,y:529,t:1527009567275};\\\", \\\"{x:63,y:529,t:1527009567291};\\\", \\\"{x:62,y:530,t:1527009567308};\\\", \\\"{x:62,y:531,t:1527009567325};\\\", \\\"{x:62,y:533,t:1527009567342};\\\", \\\"{x:62,y:535,t:1527009567358};\\\", \\\"{x:70,y:541,t:1527009567375};\\\", \\\"{x:88,y:548,t:1527009567392};\\\", \\\"{x:117,y:552,t:1527009567408};\\\", \\\"{x:171,y:554,t:1527009567425};\\\", \\\"{x:189,y:555,t:1527009567442};\\\", \\\"{x:211,y:557,t:1527009567459};\\\", \\\"{x:233,y:555,t:1527009567476};\\\", \\\"{x:250,y:552,t:1527009567492};\\\", \\\"{x:264,y:552,t:1527009567508};\\\", \\\"{x:279,y:552,t:1527009567526};\\\", \\\"{x:286,y:551,t:1527009567542};\\\", \\\"{x:295,y:551,t:1527009567558};\\\", \\\"{x:297,y:550,t:1527009567575};\\\", \\\"{x:298,y:550,t:1527009567593};\\\", \\\"{x:300,y:550,t:1527009567609};\\\", \\\"{x:305,y:548,t:1527009567625};\\\", \\\"{x:307,y:547,t:1527009567642};\\\", \\\"{x:309,y:547,t:1527009567660};\\\", \\\"{x:309,y:546,t:1527009567682};\\\", \\\"{x:309,y:545,t:1527009567692};\\\", \\\"{x:306,y:542,t:1527009567709};\\\", \\\"{x:283,y:538,t:1527009567726};\\\", \\\"{x:258,y:535,t:1527009567743};\\\", \\\"{x:231,y:535,t:1527009567759};\\\", \\\"{x:204,y:543,t:1527009567775};\\\", \\\"{x:194,y:548,t:1527009567792};\\\", \\\"{x:199,y:549,t:1527009568265};\\\", \\\"{x:221,y:553,t:1527009568276};\\\", \\\"{x:310,y:554,t:1527009568293};\\\", \\\"{x:429,y:554,t:1527009568309};\\\", \\\"{x:559,y:554,t:1527009568326};\\\", \\\"{x:692,y:554,t:1527009568342};\\\", \\\"{x:786,y:554,t:1527009568360};\\\", \\\"{x:841,y:553,t:1527009568376};\\\", \\\"{x:867,y:550,t:1527009568392};\\\", \\\"{x:880,y:547,t:1527009568409};\\\", \\\"{x:880,y:546,t:1527009568521};\\\", \\\"{x:880,y:544,t:1527009568530};\\\", \\\"{x:878,y:539,t:1527009568542};\\\", \\\"{x:862,y:531,t:1527009568559};\\\", \\\"{x:842,y:521,t:1527009568577};\\\", \\\"{x:789,y:510,t:1527009568593};\\\", \\\"{x:688,y:510,t:1527009568610};\\\", \\\"{x:678,y:510,t:1527009568626};\\\", \\\"{x:677,y:510,t:1527009568642};\\\", \\\"{x:676,y:510,t:1527009568722};\\\", \\\"{x:675,y:510,t:1527009568745};\\\", \\\"{x:674,y:510,t:1527009568761};\\\", \\\"{x:673,y:510,t:1527009568778};\\\", \\\"{x:670,y:510,t:1527009568792};\\\", \\\"{x:657,y:511,t:1527009568809};\\\", \\\"{x:641,y:517,t:1527009568826};\\\", \\\"{x:636,y:519,t:1527009568843};\\\", \\\"{x:633,y:519,t:1527009568860};\\\", \\\"{x:632,y:520,t:1527009568875};\\\", \\\"{x:633,y:522,t:1527009568946};\\\", \\\"{x:640,y:523,t:1527009568959};\\\", \\\"{x:659,y:523,t:1527009568976};\\\", \\\"{x:688,y:524,t:1527009568993};\\\", \\\"{x:728,y:524,t:1527009569009};\\\", \\\"{x:772,y:524,t:1527009569026};\\\", \\\"{x:785,y:524,t:1527009569042};\\\", \\\"{x:790,y:523,t:1527009569059};\\\", \\\"{x:791,y:523,t:1527009569076};\\\", \\\"{x:792,y:522,t:1527009569092};\\\", \\\"{x:794,y:521,t:1527009569109};\\\", \\\"{x:795,y:521,t:1527009569126};\\\", \\\"{x:795,y:520,t:1527009569142};\\\", \\\"{x:798,y:519,t:1527009569158};\\\", \\\"{x:802,y:516,t:1527009569177};\\\", \\\"{x:803,y:516,t:1527009569218};\\\", \\\"{x:805,y:515,t:1527009569233};\\\", \\\"{x:806,y:513,t:1527009569243};\\\", \\\"{x:812,y:506,t:1527009569260};\\\", \\\"{x:824,y:499,t:1527009569276};\\\", \\\"{x:837,y:492,t:1527009569293};\\\", \\\"{x:843,y:491,t:1527009569310};\\\", \\\"{x:846,y:489,t:1527009569327};\\\", \\\"{x:847,y:489,t:1527009569378};\\\", \\\"{x:847,y:492,t:1527009569939};\\\", \\\"{x:846,y:492,t:1527009569945};\\\", \\\"{x:844,y:493,t:1527009569961};\\\", \\\"{x:844,y:494,t:1527009569977};\\\", \\\"{x:842,y:494,t:1527009570001};\\\", \\\"{x:842,y:495,t:1527009570010};\\\", \\\"{x:840,y:497,t:1527009570027};\\\", \\\"{x:838,y:501,t:1527009570044};\\\", \\\"{x:837,y:503,t:1527009570061};\\\", \\\"{x:836,y:504,t:1527009570077};\\\", \\\"{x:835,y:505,t:1527009570095};\\\", \\\"{x:828,y:506,t:1527009570394};\\\", \\\"{x:808,y:512,t:1527009570401};\\\", \\\"{x:774,y:513,t:1527009570411};\\\", \\\"{x:681,y:519,t:1527009570428};\\\", \\\"{x:572,y:523,t:1527009570444};\\\", \\\"{x:485,y:540,t:1527009570462};\\\", \\\"{x:455,y:545,t:1527009570477};\\\", \\\"{x:430,y:551,t:1527009570494};\\\", \\\"{x:417,y:553,t:1527009570511};\\\", \\\"{x:404,y:557,t:1527009570527};\\\", \\\"{x:386,y:558,t:1527009570545};\\\", \\\"{x:341,y:563,t:1527009570562};\\\", \\\"{x:311,y:565,t:1527009570577};\\\", \\\"{x:284,y:565,t:1527009570594};\\\", \\\"{x:263,y:565,t:1527009570612};\\\", \\\"{x:255,y:565,t:1527009570627};\\\", \\\"{x:254,y:565,t:1527009570644};\\\", \\\"{x:251,y:565,t:1527009570769};\\\", \\\"{x:246,y:565,t:1527009570778};\\\", \\\"{x:237,y:565,t:1527009570794};\\\", \\\"{x:217,y:565,t:1527009570811};\\\", \\\"{x:195,y:562,t:1527009570828};\\\", \\\"{x:183,y:557,t:1527009570844};\\\", \\\"{x:174,y:555,t:1527009570861};\\\", \\\"{x:172,y:553,t:1527009570878};\\\", \\\"{x:170,y:552,t:1527009570938};\\\", \\\"{x:169,y:549,t:1527009570954};\\\", \\\"{x:168,y:548,t:1527009570969};\\\", \\\"{x:168,y:546,t:1527009570986};\\\", \\\"{x:167,y:546,t:1527009570994};\\\", \\\"{x:166,y:544,t:1527009571011};\\\", \\\"{x:165,y:544,t:1527009571029};\\\", \\\"{x:165,y:543,t:1527009571297};\\\", \\\"{x:165,y:544,t:1527009571353};\\\", \\\"{x:170,y:547,t:1527009571361};\\\", \\\"{x:198,y:559,t:1527009571378};\\\", \\\"{x:234,y:582,t:1527009571395};\\\", \\\"{x:296,y:614,t:1527009571412};\\\", \\\"{x:372,y:644,t:1527009571429};\\\", \\\"{x:442,y:664,t:1527009571445};\\\", \\\"{x:485,y:687,t:1527009571462};\\\", \\\"{x:514,y:700,t:1527009571479};\\\", \\\"{x:529,y:708,t:1527009571496};\\\", \\\"{x:544,y:717,t:1527009571511};\\\", \\\"{x:556,y:727,t:1527009571529};\\\", \\\"{x:569,y:740,t:1527009571545};\\\", \\\"{x:577,y:748,t:1527009571561};\\\", \\\"{x:581,y:753,t:1527009571578};\\\", \\\"{x:581,y:754,t:1527009571595};\\\", \\\"{x:581,y:756,t:1527009571611};\\\", \\\"{x:581,y:758,t:1527009571629};\\\", \\\"{x:581,y:760,t:1527009571646};\\\", \\\"{x:580,y:760,t:1527009571662};\\\", \\\"{x:578,y:762,t:1527009571679};\\\", \\\"{x:574,y:762,t:1527009571696};\\\", \\\"{x:569,y:762,t:1527009571713};\\\", \\\"{x:553,y:756,t:1527009571729};\\\", \\\"{x:529,y:741,t:1527009571746};\\\", \\\"{x:520,y:735,t:1527009571763};\\\", \\\"{x:517,y:732,t:1527009571778};\\\", \\\"{x:515,y:729,t:1527009571795};\\\", \\\"{x:515,y:728,t:1527009571857};\\\" ] }, { \\\"rt\\\": 7962, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 737369, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:517,y:725,t:1527009574634};\\\", \\\"{x:522,y:722,t:1527009574645};\\\", \\\"{x:538,y:712,t:1527009574669};\\\", \\\"{x:549,y:708,t:1527009574678};\\\", \\\"{x:602,y:680,t:1527009574698};\\\", \\\"{x:692,y:663,t:1527009574714};\\\", \\\"{x:797,y:651,t:1527009574731};\\\", \\\"{x:934,y:639,t:1527009574747};\\\", \\\"{x:1084,y:639,t:1527009574765};\\\", \\\"{x:1239,y:640,t:1527009574782};\\\", \\\"{x:1383,y:639,t:1527009574798};\\\", \\\"{x:1498,y:635,t:1527009574814};\\\", \\\"{x:1567,y:635,t:1527009574832};\\\", \\\"{x:1593,y:638,t:1527009574848};\\\", \\\"{x:1597,y:639,t:1527009574864};\\\", \\\"{x:1597,y:644,t:1527009574881};\\\", \\\"{x:1591,y:642,t:1527009574898};\\\", \\\"{x:1590,y:642,t:1527009575241};\\\", \\\"{x:1587,y:643,t:1527009575273};\\\", \\\"{x:1585,y:643,t:1527009575289};\\\", \\\"{x:1577,y:643,t:1527009575298};\\\", \\\"{x:1573,y:643,t:1527009575315};\\\", \\\"{x:1565,y:642,t:1527009575332};\\\", \\\"{x:1562,y:643,t:1527009575348};\\\", \\\"{x:1554,y:643,t:1527009575364};\\\", \\\"{x:1551,y:643,t:1527009575381};\\\", \\\"{x:1546,y:643,t:1527009575399};\\\", \\\"{x:1540,y:644,t:1527009575414};\\\", \\\"{x:1531,y:648,t:1527009575432};\\\", \\\"{x:1519,y:651,t:1527009575449};\\\", \\\"{x:1508,y:653,t:1527009575464};\\\", \\\"{x:1493,y:658,t:1527009575481};\\\", \\\"{x:1487,y:661,t:1527009575499};\\\", \\\"{x:1482,y:662,t:1527009575516};\\\", \\\"{x:1479,y:665,t:1527009575532};\\\", \\\"{x:1475,y:667,t:1527009575549};\\\", \\\"{x:1471,y:670,t:1527009575566};\\\", \\\"{x:1460,y:672,t:1527009575582};\\\", \\\"{x:1440,y:677,t:1527009575599};\\\", \\\"{x:1416,y:679,t:1527009575616};\\\", \\\"{x:1394,y:680,t:1527009575632};\\\", \\\"{x:1371,y:683,t:1527009575649};\\\", \\\"{x:1329,y:691,t:1527009575666};\\\", \\\"{x:1307,y:696,t:1527009575682};\\\", \\\"{x:1286,y:701,t:1527009575699};\\\", \\\"{x:1269,y:706,t:1527009575716};\\\", \\\"{x:1260,y:708,t:1527009575732};\\\", \\\"{x:1258,y:708,t:1527009575749};\\\", \\\"{x:1258,y:709,t:1527009575851};\\\", \\\"{x:1269,y:704,t:1527009575866};\\\", \\\"{x:1288,y:702,t:1527009575882};\\\", \\\"{x:1315,y:702,t:1527009575899};\\\", \\\"{x:1334,y:699,t:1527009575916};\\\", \\\"{x:1359,y:699,t:1527009575932};\\\", \\\"{x:1368,y:698,t:1527009575950};\\\", \\\"{x:1367,y:698,t:1527009576114};\\\", \\\"{x:1363,y:698,t:1527009576122};\\\", \\\"{x:1361,y:698,t:1527009576133};\\\", \\\"{x:1355,y:698,t:1527009576149};\\\", \\\"{x:1352,y:698,t:1527009576169};\\\", \\\"{x:1351,y:698,t:1527009576183};\\\", \\\"{x:1348,y:697,t:1527009576578};\\\", \\\"{x:1339,y:694,t:1527009576587};\\\", \\\"{x:1330,y:688,t:1527009576599};\\\", \\\"{x:1308,y:679,t:1527009576616};\\\", \\\"{x:1239,y:660,t:1527009576633};\\\", \\\"{x:1086,y:626,t:1527009576648};\\\", \\\"{x:960,y:599,t:1527009576666};\\\", \\\"{x:815,y:568,t:1527009576683};\\\", \\\"{x:670,y:540,t:1527009576700};\\\", \\\"{x:532,y:508,t:1527009576717};\\\", \\\"{x:404,y:483,t:1527009576733};\\\", \\\"{x:294,y:456,t:1527009576750};\\\", \\\"{x:223,y:440,t:1527009576765};\\\", \\\"{x:200,y:435,t:1527009576783};\\\", \\\"{x:196,y:435,t:1527009576800};\\\", \\\"{x:202,y:435,t:1527009576987};\\\", \\\"{x:211,y:435,t:1527009577000};\\\", \\\"{x:229,y:435,t:1527009577018};\\\", \\\"{x:247,y:439,t:1527009577033};\\\", \\\"{x:276,y:447,t:1527009577050};\\\", \\\"{x:297,y:452,t:1527009577067};\\\", \\\"{x:310,y:459,t:1527009577083};\\\", \\\"{x:322,y:465,t:1527009577100};\\\", \\\"{x:326,y:466,t:1527009577117};\\\", \\\"{x:328,y:467,t:1527009577133};\\\", \\\"{x:329,y:468,t:1527009577154};\\\", \\\"{x:329,y:469,t:1527009577178};\\\", \\\"{x:330,y:470,t:1527009577186};\\\", \\\"{x:331,y:470,t:1527009577200};\\\", \\\"{x:331,y:472,t:1527009577217};\\\", \\\"{x:332,y:473,t:1527009577233};\\\", \\\"{x:332,y:477,t:1527009577250};\\\", \\\"{x:332,y:478,t:1527009577267};\\\", \\\"{x:332,y:479,t:1527009577346};\\\", \\\"{x:329,y:482,t:1527009577353};\\\", \\\"{x:324,y:485,t:1527009577367};\\\", \\\"{x:306,y:491,t:1527009577386};\\\", \\\"{x:280,y:498,t:1527009577400};\\\", \\\"{x:238,y:498,t:1527009577418};\\\", \\\"{x:162,y:498,t:1527009577434};\\\", \\\"{x:147,y:502,t:1527009577450};\\\", \\\"{x:138,y:504,t:1527009577467};\\\", \\\"{x:133,y:505,t:1527009577484};\\\", \\\"{x:132,y:506,t:1527009577500};\\\", \\\"{x:131,y:507,t:1527009577529};\\\", \\\"{x:130,y:507,t:1527009577537};\\\", \\\"{x:127,y:510,t:1527009577550};\\\", \\\"{x:123,y:513,t:1527009577566};\\\", \\\"{x:122,y:513,t:1527009577617};\\\", \\\"{x:122,y:515,t:1527009577641};\\\", \\\"{x:122,y:517,t:1527009577651};\\\", \\\"{x:122,y:521,t:1527009577668};\\\", \\\"{x:122,y:529,t:1527009577684};\\\", \\\"{x:125,y:533,t:1527009577701};\\\", \\\"{x:127,y:535,t:1527009577716};\\\", \\\"{x:127,y:536,t:1527009577737};\\\", \\\"{x:128,y:537,t:1527009577818};\\\", \\\"{x:130,y:537,t:1527009577834};\\\", \\\"{x:132,y:537,t:1527009577851};\\\", \\\"{x:133,y:538,t:1527009577867};\\\", \\\"{x:134,y:539,t:1527009577890};\\\", \\\"{x:135,y:539,t:1527009577901};\\\", \\\"{x:136,y:540,t:1527009577917};\\\", \\\"{x:137,y:542,t:1527009577994};\\\", \\\"{x:139,y:542,t:1527009578002};\\\", \\\"{x:140,y:542,t:1527009578017};\\\", \\\"{x:141,y:544,t:1527009578034};\\\", \\\"{x:141,y:545,t:1527009578209};\\\", \\\"{x:143,y:545,t:1527009578217};\\\", \\\"{x:147,y:549,t:1527009578906};\\\", \\\"{x:159,y:552,t:1527009578918};\\\", \\\"{x:192,y:559,t:1527009578936};\\\", \\\"{x:250,y:574,t:1527009578952};\\\", \\\"{x:289,y:585,t:1527009578970};\\\", \\\"{x:303,y:593,t:1527009578985};\\\", \\\"{x:305,y:594,t:1527009579002};\\\", \\\"{x:306,y:595,t:1527009579041};\\\", \\\"{x:305,y:595,t:1527009579057};\\\", \\\"{x:295,y:592,t:1527009579068};\\\", \\\"{x:278,y:584,t:1527009579085};\\\", \\\"{x:267,y:578,t:1527009579102};\\\", \\\"{x:265,y:577,t:1527009579118};\\\", \\\"{x:264,y:576,t:1527009579137};\\\", \\\"{x:264,y:575,t:1527009579161};\\\", \\\"{x:259,y:574,t:1527009579169};\\\", \\\"{x:253,y:571,t:1527009579185};\\\", \\\"{x:240,y:569,t:1527009579202};\\\", \\\"{x:238,y:568,t:1527009579218};\\\", \\\"{x:236,y:567,t:1527009579290};\\\", \\\"{x:230,y:564,t:1527009579302};\\\", \\\"{x:217,y:558,t:1527009579320};\\\", \\\"{x:210,y:556,t:1527009579335};\\\", \\\"{x:205,y:553,t:1527009579352};\\\", \\\"{x:202,y:553,t:1527009579369};\\\", \\\"{x:198,y:552,t:1527009579384};\\\", \\\"{x:194,y:551,t:1527009579402};\\\", \\\"{x:186,y:548,t:1527009579419};\\\", \\\"{x:176,y:545,t:1527009579435};\\\", \\\"{x:175,y:545,t:1527009579452};\\\", \\\"{x:174,y:545,t:1527009579569};\\\", \\\"{x:173,y:544,t:1527009579585};\\\", \\\"{x:170,y:542,t:1527009579602};\\\", \\\"{x:170,y:541,t:1527009579619};\\\", \\\"{x:169,y:541,t:1527009579835};\\\", \\\"{x:172,y:541,t:1527009579889};\\\", \\\"{x:175,y:541,t:1527009579902};\\\", \\\"{x:178,y:543,t:1527009579919};\\\", \\\"{x:180,y:544,t:1527009579936};\\\", \\\"{x:188,y:547,t:1527009579952};\\\", \\\"{x:200,y:552,t:1527009579969};\\\", \\\"{x:232,y:563,t:1527009579985};\\\", \\\"{x:261,y:575,t:1527009580002};\\\", \\\"{x:302,y:592,t:1527009580019};\\\", \\\"{x:355,y:628,t:1527009580037};\\\", \\\"{x:389,y:648,t:1527009580053};\\\", \\\"{x:422,y:681,t:1527009580069};\\\", \\\"{x:438,y:695,t:1527009580086};\\\", \\\"{x:448,y:701,t:1527009580102};\\\", \\\"{x:452,y:706,t:1527009580119};\\\", \\\"{x:452,y:707,t:1527009580145};\\\", \\\"{x:456,y:709,t:1527009580153};\\\", \\\"{x:456,y:711,t:1527009580169};\\\", \\\"{x:459,y:715,t:1527009580185};\\\", \\\"{x:460,y:715,t:1527009580209};\\\", \\\"{x:461,y:715,t:1527009580219};\\\", \\\"{x:462,y:716,t:1527009580235};\\\", \\\"{x:462,y:717,t:1527009580273};\\\", \\\"{x:463,y:717,t:1527009580402};\\\", \\\"{x:464,y:717,t:1527009580474};\\\", \\\"{x:465,y:720,t:1527009580523};\\\", \\\"{x:465,y:721,t:1527009580882};\\\", \\\"{x:465,y:722,t:1527009580906};\\\", \\\"{x:466,y:724,t:1527009580920};\\\", \\\"{x:466,y:727,t:1527009580936};\\\", \\\"{x:466,y:728,t:1527009580953};\\\", \\\"{x:466,y:730,t:1527009580969};\\\", \\\"{x:466,y:731,t:1527009580985};\\\", \\\"{x:466,y:733,t:1527009581002};\\\", \\\"{x:466,y:734,t:1527009581019};\\\", \\\"{x:466,y:735,t:1527009581066};\\\", \\\"{x:466,y:736,t:1527009581089};\\\", \\\"{x:466,y:737,t:1527009581102};\\\", \\\"{x:467,y:737,t:1527009581209};\\\", \\\"{x:467,y:737,t:1527009581275};\\\", \\\"{x:468,y:737,t:1527009581401};\\\", \\\"{x:468,y:736,t:1527009581433};\\\", \\\"{x:468,y:735,t:1527009581457};\\\", \\\"{x:468,y:733,t:1527009581481};\\\", \\\"{x:468,y:731,t:1527009581522};\\\", \\\"{x:468,y:728,t:1527009581538};\\\", \\\"{x:469,y:727,t:1527009581553};\\\", \\\"{x:469,y:726,t:1527009581570};\\\", \\\"{x:471,y:724,t:1527009581587};\\\", \\\"{x:471,y:723,t:1527009581604};\\\", \\\"{x:472,y:722,t:1527009581620};\\\", \\\"{x:472,y:720,t:1527009581637};\\\", \\\"{x:475,y:713,t:1527009581654};\\\", \\\"{x:475,y:710,t:1527009581706};\\\", \\\"{x:475,y:709,t:1527009581720};\\\", \\\"{x:475,y:706,t:1527009581737};\\\", \\\"{x:471,y:704,t:1527009581754};\\\", \\\"{x:469,y:701,t:1527009581770};\\\" ] }, { \\\"rt\\\": 30792, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 769432, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -Z -Z -X -F -F -F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:470,y:700,t:1527009583770};\\\", \\\"{x:506,y:676,t:1527009583778};\\\", \\\"{x:584,y:623,t:1527009583791};\\\", \\\"{x:774,y:501,t:1527009583806};\\\", \\\"{x:946,y:402,t:1527009583823};\\\", \\\"{x:1091,y:349,t:1527009583839};\\\", \\\"{x:1208,y:325,t:1527009583862};\\\", \\\"{x:1218,y:322,t:1527009583872};\\\", \\\"{x:1245,y:316,t:1527009583889};\\\", \\\"{x:1267,y:310,t:1527009583905};\\\", \\\"{x:1290,y:307,t:1527009583921};\\\", \\\"{x:1294,y:306,t:1527009583939};\\\", \\\"{x:1297,y:306,t:1527009584410};\\\", \\\"{x:1300,y:306,t:1527009584423};\\\", \\\"{x:1308,y:306,t:1527009584440};\\\", \\\"{x:1327,y:311,t:1527009584456};\\\", \\\"{x:1360,y:314,t:1527009584474};\\\", \\\"{x:1378,y:314,t:1527009584490};\\\", \\\"{x:1389,y:314,t:1527009584506};\\\", \\\"{x:1395,y:314,t:1527009584524};\\\", \\\"{x:1401,y:316,t:1527009584540};\\\", \\\"{x:1405,y:317,t:1527009584557};\\\", \\\"{x:1408,y:317,t:1527009584574};\\\", \\\"{x:1409,y:317,t:1527009584589};\\\", \\\"{x:1410,y:318,t:1527009584607};\\\", \\\"{x:1410,y:320,t:1527009584624};\\\", \\\"{x:1411,y:327,t:1527009584640};\\\", \\\"{x:1415,y:343,t:1527009584657};\\\", \\\"{x:1415,y:362,t:1527009584674};\\\", \\\"{x:1415,y:369,t:1527009584690};\\\", \\\"{x:1417,y:387,t:1527009584706};\\\", \\\"{x:1418,y:396,t:1527009584724};\\\", \\\"{x:1421,y:406,t:1527009584740};\\\", \\\"{x:1422,y:416,t:1527009584757};\\\", \\\"{x:1425,y:424,t:1527009584774};\\\", \\\"{x:1427,y:431,t:1527009584790};\\\", \\\"{x:1430,y:436,t:1527009584807};\\\", \\\"{x:1434,y:444,t:1527009584823};\\\", \\\"{x:1439,y:453,t:1527009584840};\\\", \\\"{x:1448,y:469,t:1527009584856};\\\", \\\"{x:1466,y:496,t:1527009584874};\\\", \\\"{x:1476,y:515,t:1527009584890};\\\", \\\"{x:1484,y:531,t:1527009584906};\\\", \\\"{x:1487,y:534,t:1527009584923};\\\", \\\"{x:1487,y:535,t:1527009584940};\\\", \\\"{x:1487,y:534,t:1527009586546};\\\", \\\"{x:1487,y:532,t:1527009586558};\\\", \\\"{x:1487,y:530,t:1527009586574};\\\", \\\"{x:1488,y:524,t:1527009586591};\\\", \\\"{x:1489,y:512,t:1527009586608};\\\", \\\"{x:1494,y:497,t:1527009586624};\\\", \\\"{x:1505,y:476,t:1527009586641};\\\", \\\"{x:1508,y:470,t:1527009586658};\\\", \\\"{x:1510,y:468,t:1527009586674};\\\", \\\"{x:1511,y:471,t:1527009587634};\\\", \\\"{x:1513,y:482,t:1527009587642};\\\", \\\"{x:1517,y:508,t:1527009587658};\\\", \\\"{x:1524,y:552,t:1527009587675};\\\", \\\"{x:1532,y:616,t:1527009587693};\\\", \\\"{x:1540,y:704,t:1527009587708};\\\", \\\"{x:1542,y:810,t:1527009587725};\\\", \\\"{x:1542,y:931,t:1527009587742};\\\", \\\"{x:1550,y:1041,t:1527009587759};\\\", \\\"{x:1564,y:1149,t:1527009587775};\\\", \\\"{x:1578,y:1215,t:1527009587792};\\\", \\\"{x:1593,y:1215,t:1527009587808};\\\", \\\"{x:1611,y:1215,t:1527009587825};\\\", \\\"{x:1615,y:1215,t:1527009587842};\\\", \\\"{x:1616,y:1215,t:1527009587930};\\\", \\\"{x:1616,y:1213,t:1527009587986};\\\", \\\"{x:1614,y:1210,t:1527009587993};\\\", \\\"{x:1614,y:1207,t:1527009588010};\\\", \\\"{x:1611,y:1198,t:1527009588026};\\\", \\\"{x:1610,y:1196,t:1527009588042};\\\", \\\"{x:1609,y:1194,t:1527009588058};\\\", \\\"{x:1606,y:1190,t:1527009588074};\\\", \\\"{x:1604,y:1186,t:1527009588092};\\\", \\\"{x:1602,y:1184,t:1527009588108};\\\", \\\"{x:1602,y:1182,t:1527009588124};\\\", \\\"{x:1602,y:1181,t:1527009588141};\\\", \\\"{x:1600,y:1179,t:1527009588177};\\\", \\\"{x:1600,y:1178,t:1527009588191};\\\", \\\"{x:1599,y:1172,t:1527009588207};\\\", \\\"{x:1598,y:1163,t:1527009588224};\\\", \\\"{x:1593,y:1146,t:1527009588240};\\\", \\\"{x:1592,y:1103,t:1527009588257};\\\", \\\"{x:1607,y:1055,t:1527009588274};\\\", \\\"{x:1630,y:1003,t:1527009588291};\\\", \\\"{x:1651,y:917,t:1527009588308};\\\", \\\"{x:1666,y:833,t:1527009588324};\\\", \\\"{x:1672,y:751,t:1527009588341};\\\", \\\"{x:1675,y:667,t:1527009588358};\\\", \\\"{x:1662,y:594,t:1527009588373};\\\", \\\"{x:1639,y:544,t:1527009588390};\\\", \\\"{x:1618,y:494,t:1527009588407};\\\", \\\"{x:1595,y:456,t:1527009588423};\\\", \\\"{x:1578,y:417,t:1527009588440};\\\", \\\"{x:1560,y:375,t:1527009588457};\\\", \\\"{x:1535,y:320,t:1527009588473};\\\", \\\"{x:1520,y:299,t:1527009588489};\\\", \\\"{x:1510,y:284,t:1527009588507};\\\", \\\"{x:1509,y:282,t:1527009588523};\\\", \\\"{x:1507,y:281,t:1527009588539};\\\", \\\"{x:1504,y:282,t:1527009588557};\\\", \\\"{x:1502,y:289,t:1527009588573};\\\", \\\"{x:1499,y:301,t:1527009588590};\\\", \\\"{x:1499,y:308,t:1527009588606};\\\", \\\"{x:1503,y:320,t:1527009588622};\\\", \\\"{x:1516,y:340,t:1527009588639};\\\", \\\"{x:1533,y:362,t:1527009588657};\\\", \\\"{x:1552,y:389,t:1527009588673};\\\", \\\"{x:1583,y:426,t:1527009588689};\\\", \\\"{x:1608,y:447,t:1527009588706};\\\", \\\"{x:1631,y:471,t:1527009588722};\\\", \\\"{x:1659,y:500,t:1527009588740};\\\", \\\"{x:1686,y:530,t:1527009588756};\\\", \\\"{x:1700,y:556,t:1527009588773};\\\", \\\"{x:1715,y:585,t:1527009588789};\\\", \\\"{x:1729,y:608,t:1527009588805};\\\", \\\"{x:1739,y:625,t:1527009588822};\\\", \\\"{x:1740,y:638,t:1527009588838};\\\", \\\"{x:1740,y:646,t:1527009588855};\\\", \\\"{x:1738,y:657,t:1527009588873};\\\", \\\"{x:1725,y:669,t:1527009588889};\\\", \\\"{x:1690,y:690,t:1527009588906};\\\", \\\"{x:1658,y:698,t:1527009588921};\\\", \\\"{x:1622,y:717,t:1527009588939};\\\", \\\"{x:1599,y:730,t:1527009588956};\\\", \\\"{x:1585,y:745,t:1527009588972};\\\", \\\"{x:1578,y:757,t:1527009588988};\\\", \\\"{x:1577,y:760,t:1527009589005};\\\", \\\"{x:1577,y:759,t:1527009589106};\\\", \\\"{x:1583,y:751,t:1527009589122};\\\", \\\"{x:1586,y:745,t:1527009589138};\\\", \\\"{x:1594,y:737,t:1527009589155};\\\", \\\"{x:1597,y:733,t:1527009589172};\\\", \\\"{x:1602,y:728,t:1527009589188};\\\", \\\"{x:1608,y:722,t:1527009589205};\\\", \\\"{x:1615,y:715,t:1527009589221};\\\", \\\"{x:1619,y:710,t:1527009589238};\\\", \\\"{x:1622,y:704,t:1527009589253};\\\", \\\"{x:1622,y:703,t:1527009589434};\\\", \\\"{x:1620,y:703,t:1527009589442};\\\", \\\"{x:1619,y:704,t:1527009589454};\\\", \\\"{x:1618,y:704,t:1527009589471};\\\", \\\"{x:1617,y:705,t:1527009589487};\\\", \\\"{x:1616,y:706,t:1527009589658};\\\", \\\"{x:1616,y:715,t:1527009589670};\\\", \\\"{x:1621,y:732,t:1527009589686};\\\", \\\"{x:1625,y:753,t:1527009589702};\\\", \\\"{x:1631,y:781,t:1527009589719};\\\", \\\"{x:1641,y:807,t:1527009589735};\\\", \\\"{x:1649,y:831,t:1527009589752};\\\", \\\"{x:1653,y:853,t:1527009589768};\\\", \\\"{x:1659,y:888,t:1527009589785};\\\", \\\"{x:1659,y:901,t:1527009589802};\\\", \\\"{x:1659,y:915,t:1527009589818};\\\", \\\"{x:1659,y:934,t:1527009589835};\\\", \\\"{x:1659,y:955,t:1527009589852};\\\", \\\"{x:1661,y:973,t:1527009589868};\\\", \\\"{x:1664,y:989,t:1527009589886};\\\", \\\"{x:1664,y:995,t:1527009589902};\\\", \\\"{x:1664,y:999,t:1527009589918};\\\", \\\"{x:1665,y:1001,t:1527009589936};\\\", \\\"{x:1666,y:1001,t:1527009590018};\\\", \\\"{x:1665,y:1001,t:1527009590042};\\\", \\\"{x:1664,y:1000,t:1527009590052};\\\", \\\"{x:1655,y:993,t:1527009590067};\\\", \\\"{x:1650,y:989,t:1527009590085};\\\", \\\"{x:1644,y:983,t:1527009590102};\\\", \\\"{x:1638,y:976,t:1527009590117};\\\", \\\"{x:1635,y:967,t:1527009590134};\\\", \\\"{x:1634,y:959,t:1527009590151};\\\", \\\"{x:1633,y:950,t:1527009590167};\\\", \\\"{x:1633,y:935,t:1527009590184};\\\", \\\"{x:1633,y:913,t:1527009590201};\\\", \\\"{x:1633,y:866,t:1527009590217};\\\", \\\"{x:1625,y:821,t:1527009590234};\\\", \\\"{x:1610,y:765,t:1527009590250};\\\", \\\"{x:1592,y:712,t:1527009590267};\\\", \\\"{x:1575,y:660,t:1527009590283};\\\", \\\"{x:1562,y:628,t:1527009590300};\\\", \\\"{x:1560,y:612,t:1527009590317};\\\", \\\"{x:1560,y:605,t:1527009590333};\\\", \\\"{x:1562,y:600,t:1527009590350};\\\", \\\"{x:1564,y:599,t:1527009590367};\\\", \\\"{x:1565,y:599,t:1527009590467};\\\", \\\"{x:1568,y:601,t:1527009590484};\\\", \\\"{x:1574,y:616,t:1527009590500};\\\", \\\"{x:1585,y:633,t:1527009590520};\\\", \\\"{x:1594,y:652,t:1527009590533};\\\", \\\"{x:1604,y:671,t:1527009590549};\\\", \\\"{x:1613,y:687,t:1527009590566};\\\", \\\"{x:1620,y:700,t:1527009590583};\\\", \\\"{x:1621,y:707,t:1527009590599};\\\", \\\"{x:1622,y:712,t:1527009590616};\\\", \\\"{x:1622,y:713,t:1527009590633};\\\", \\\"{x:1622,y:712,t:1527009590914};\\\", \\\"{x:1620,y:709,t:1527009590922};\\\", \\\"{x:1619,y:709,t:1527009590932};\\\", \\\"{x:1619,y:707,t:1527009590949};\\\", \\\"{x:1618,y:706,t:1527009591290};\\\", \\\"{x:1616,y:705,t:1527009591298};\\\", \\\"{x:1616,y:703,t:1527009591313};\\\", \\\"{x:1613,y:701,t:1527009591331};\\\", \\\"{x:1613,y:700,t:1527009591346};\\\", \\\"{x:1611,y:700,t:1527009591364};\\\", \\\"{x:1605,y:701,t:1527009591380};\\\", \\\"{x:1598,y:711,t:1527009591396};\\\", \\\"{x:1593,y:723,t:1527009591414};\\\", \\\"{x:1590,y:734,t:1527009591429};\\\", \\\"{x:1581,y:748,t:1527009591447};\\\", \\\"{x:1574,y:761,t:1527009591464};\\\", \\\"{x:1566,y:768,t:1527009591479};\\\", \\\"{x:1563,y:770,t:1527009591497};\\\", \\\"{x:1557,y:773,t:1527009591512};\\\", \\\"{x:1555,y:773,t:1527009591529};\\\", \\\"{x:1553,y:773,t:1527009591547};\\\", \\\"{x:1549,y:773,t:1527009591562};\\\", \\\"{x:1545,y:776,t:1527009591579};\\\", \\\"{x:1544,y:776,t:1527009591601};\\\", \\\"{x:1542,y:776,t:1527009591613};\\\", \\\"{x:1540,y:776,t:1527009591674};\\\", \\\"{x:1539,y:776,t:1527009591689};\\\", \\\"{x:1538,y:776,t:1527009591705};\\\", \\\"{x:1537,y:776,t:1527009591721};\\\", \\\"{x:1536,y:776,t:1527009591729};\\\", \\\"{x:1535,y:776,t:1527009591802};\\\", \\\"{x:1534,y:776,t:1527009591812};\\\", \\\"{x:1533,y:776,t:1527009591833};\\\", \\\"{x:1532,y:775,t:1527009591858};\\\", \\\"{x:1530,y:774,t:1527009591874};\\\", \\\"{x:1529,y:774,t:1527009591881};\\\", \\\"{x:1527,y:774,t:1527009591906};\\\", \\\"{x:1526,y:773,t:1527009591929};\\\", \\\"{x:1523,y:773,t:1527009591945};\\\", \\\"{x:1518,y:772,t:1527009591962};\\\", \\\"{x:1513,y:772,t:1527009591978};\\\", \\\"{x:1511,y:772,t:1527009591995};\\\", \\\"{x:1510,y:772,t:1527009592012};\\\", \\\"{x:1509,y:772,t:1527009592028};\\\", \\\"{x:1509,y:771,t:1527009592266};\\\", \\\"{x:1509,y:770,t:1527009592277};\\\", \\\"{x:1508,y:771,t:1527009593457};\\\", \\\"{x:1508,y:774,t:1527009593473};\\\", \\\"{x:1505,y:782,t:1527009593489};\\\", \\\"{x:1505,y:787,t:1527009593507};\\\", \\\"{x:1502,y:795,t:1527009593523};\\\", \\\"{x:1500,y:801,t:1527009593540};\\\", \\\"{x:1497,y:807,t:1527009593556};\\\", \\\"{x:1495,y:812,t:1527009593573};\\\", \\\"{x:1494,y:816,t:1527009593589};\\\", \\\"{x:1491,y:820,t:1527009593605};\\\", \\\"{x:1490,y:821,t:1527009593625};\\\", \\\"{x:1490,y:822,t:1527009593639};\\\", \\\"{x:1489,y:824,t:1527009593655};\\\", \\\"{x:1489,y:825,t:1527009593673};\\\", \\\"{x:1488,y:827,t:1527009593689};\\\", \\\"{x:1487,y:828,t:1527009593705};\\\", \\\"{x:1487,y:829,t:1527009593721};\\\", \\\"{x:1487,y:830,t:1527009593738};\\\", \\\"{x:1487,y:831,t:1527009593769};\\\", \\\"{x:1476,y:832,t:1527009598675};\\\", \\\"{x:1463,y:823,t:1527009598690};\\\", \\\"{x:1399,y:805,t:1527009598705};\\\", \\\"{x:1332,y:786,t:1527009598721};\\\", \\\"{x:1288,y:768,t:1527009598737};\\\", \\\"{x:1278,y:765,t:1527009598755};\\\", \\\"{x:1278,y:764,t:1527009598825};\\\", \\\"{x:1278,y:763,t:1527009598857};\\\", \\\"{x:1278,y:762,t:1527009598871};\\\", \\\"{x:1279,y:759,t:1527009598887};\\\", \\\"{x:1284,y:756,t:1527009598905};\\\", \\\"{x:1290,y:755,t:1527009598921};\\\", \\\"{x:1293,y:753,t:1527009598937};\\\", \\\"{x:1296,y:753,t:1527009598954};\\\", \\\"{x:1299,y:753,t:1527009598971};\\\", \\\"{x:1305,y:755,t:1527009598988};\\\", \\\"{x:1317,y:759,t:1527009599004};\\\", \\\"{x:1327,y:763,t:1527009599020};\\\", \\\"{x:1338,y:767,t:1527009599036};\\\", \\\"{x:1352,y:772,t:1527009599054};\\\", \\\"{x:1360,y:774,t:1527009599071};\\\", \\\"{x:1362,y:775,t:1527009599087};\\\", \\\"{x:1363,y:775,t:1527009599104};\\\", \\\"{x:1364,y:775,t:1527009599177};\\\", \\\"{x:1362,y:775,t:1527009599442};\\\", \\\"{x:1360,y:774,t:1527009599453};\\\", \\\"{x:1356,y:772,t:1527009599469};\\\", \\\"{x:1355,y:771,t:1527009599487};\\\", \\\"{x:1355,y:770,t:1527009599522};\\\", \\\"{x:1354,y:769,t:1527009599570};\\\", \\\"{x:1353,y:768,t:1527009605795};\\\", \\\"{x:1353,y:760,t:1527009605801};\\\", \\\"{x:1352,y:750,t:1527009605814};\\\", \\\"{x:1352,y:734,t:1527009605832};\\\", \\\"{x:1349,y:716,t:1527009605847};\\\", \\\"{x:1349,y:699,t:1527009605865};\\\", \\\"{x:1348,y:690,t:1527009605882};\\\", \\\"{x:1347,y:685,t:1527009605897};\\\", \\\"{x:1347,y:684,t:1527009605921};\\\", \\\"{x:1347,y:686,t:1527009606194};\\\", \\\"{x:1347,y:688,t:1527009606202};\\\", \\\"{x:1347,y:691,t:1527009606213};\\\", \\\"{x:1347,y:697,t:1527009606230};\\\", \\\"{x:1347,y:700,t:1527009606246};\\\", \\\"{x:1348,y:703,t:1527009606263};\\\", \\\"{x:1348,y:704,t:1527009606282};\\\", \\\"{x:1349,y:705,t:1527009606362};\\\", \\\"{x:1350,y:705,t:1527009607490};\\\", \\\"{x:1350,y:704,t:1527009607778};\\\", \\\"{x:1350,y:703,t:1527009607791};\\\", \\\"{x:1351,y:702,t:1527009607808};\\\", \\\"{x:1351,y:701,t:1527009607834};\\\", \\\"{x:1351,y:699,t:1527009607857};\\\", \\\"{x:1352,y:698,t:1527009607874};\\\", \\\"{x:1352,y:696,t:1527009608290};\\\", \\\"{x:1353,y:695,t:1527009608305};\\\", \\\"{x:1354,y:695,t:1527009608322};\\\", \\\"{x:1355,y:694,t:1527009608339};\\\", \\\"{x:1357,y:694,t:1527009608361};\\\", \\\"{x:1358,y:694,t:1527009608393};\\\", \\\"{x:1359,y:693,t:1527009608405};\\\", \\\"{x:1360,y:693,t:1527009608422};\\\", \\\"{x:1361,y:692,t:1527009608438};\\\", \\\"{x:1362,y:692,t:1527009608457};\\\", \\\"{x:1363,y:692,t:1527009608471};\\\", \\\"{x:1364,y:691,t:1527009608488};\\\", \\\"{x:1366,y:691,t:1527009608514};\\\", \\\"{x:1367,y:690,t:1527009608529};\\\", \\\"{x:1363,y:690,t:1527009608650};\\\", \\\"{x:1356,y:693,t:1527009608658};\\\", \\\"{x:1351,y:697,t:1527009608672};\\\", \\\"{x:1342,y:701,t:1527009608689};\\\", \\\"{x:1320,y:705,t:1527009608704};\\\", \\\"{x:1282,y:705,t:1527009608720};\\\", \\\"{x:1243,y:705,t:1527009608737};\\\", \\\"{x:1195,y:705,t:1527009608754};\\\", \\\"{x:1139,y:704,t:1527009608770};\\\", \\\"{x:1091,y:704,t:1527009608787};\\\", \\\"{x:1034,y:701,t:1527009608804};\\\", \\\"{x:955,y:695,t:1527009608820};\\\", \\\"{x:866,y:695,t:1527009608837};\\\", \\\"{x:772,y:695,t:1527009608853};\\\", \\\"{x:677,y:693,t:1527009608870};\\\", \\\"{x:595,y:688,t:1527009608887};\\\", \\\"{x:524,y:683,t:1527009608903};\\\", \\\"{x:458,y:676,t:1527009608920};\\\", \\\"{x:407,y:669,t:1527009608937};\\\", \\\"{x:382,y:666,t:1527009608953};\\\", \\\"{x:372,y:661,t:1527009608969};\\\", \\\"{x:347,y:649,t:1527009608992};\\\", \\\"{x:339,y:644,t:1527009609009};\\\", \\\"{x:334,y:633,t:1527009609027};\\\", \\\"{x:325,y:613,t:1527009609043};\\\", \\\"{x:311,y:589,t:1527009609060};\\\", \\\"{x:311,y:586,t:1527009609080};\\\", \\\"{x:317,y:586,t:1527009609210};\\\", \\\"{x:345,y:587,t:1527009609226};\\\", \\\"{x:374,y:592,t:1527009609243};\\\", \\\"{x:394,y:594,t:1527009609261};\\\", \\\"{x:414,y:597,t:1527009609276};\\\", \\\"{x:426,y:597,t:1527009609294};\\\", \\\"{x:430,y:597,t:1527009609310};\\\", \\\"{x:431,y:597,t:1527009609326};\\\", \\\"{x:432,y:597,t:1527009609369};\\\", \\\"{x:432,y:595,t:1527009609377};\\\", \\\"{x:432,y:590,t:1527009609395};\\\", \\\"{x:436,y:580,t:1527009609410};\\\", \\\"{x:442,y:568,t:1527009609426};\\\", \\\"{x:448,y:552,t:1527009609443};\\\", \\\"{x:455,y:541,t:1527009609460};\\\", \\\"{x:457,y:537,t:1527009609476};\\\", \\\"{x:457,y:536,t:1527009609493};\\\", \\\"{x:457,y:535,t:1527009609537};\\\", \\\"{x:451,y:533,t:1527009609545};\\\", \\\"{x:440,y:532,t:1527009609560};\\\", \\\"{x:388,y:530,t:1527009609577};\\\", \\\"{x:358,y:527,t:1527009609593};\\\", \\\"{x:340,y:525,t:1527009609610};\\\", \\\"{x:339,y:525,t:1527009609626};\\\", \\\"{x:342,y:526,t:1527009609802};\\\", \\\"{x:349,y:531,t:1527009609810};\\\", \\\"{x:358,y:536,t:1527009609827};\\\", \\\"{x:365,y:543,t:1527009609844};\\\", \\\"{x:367,y:547,t:1527009609861};\\\", \\\"{x:368,y:551,t:1527009609877};\\\", \\\"{x:369,y:553,t:1527009609894};\\\", \\\"{x:369,y:554,t:1527009609911};\\\", \\\"{x:363,y:560,t:1527009609929};\\\", \\\"{x:344,y:566,t:1527009609945};\\\", \\\"{x:331,y:571,t:1527009609959};\\\", \\\"{x:273,y:572,t:1527009609977};\\\", \\\"{x:211,y:572,t:1527009609993};\\\", \\\"{x:167,y:572,t:1527009610009};\\\", \\\"{x:154,y:572,t:1527009610027};\\\", \\\"{x:151,y:572,t:1527009610044};\\\", \\\"{x:150,y:572,t:1527009610080};\\\", \\\"{x:149,y:573,t:1527009610177};\\\", \\\"{x:149,y:579,t:1527009610195};\\\", \\\"{x:149,y:586,t:1527009610210};\\\", \\\"{x:156,y:597,t:1527009610228};\\\", \\\"{x:161,y:608,t:1527009610245};\\\", \\\"{x:167,y:615,t:1527009610260};\\\", \\\"{x:176,y:620,t:1527009610277};\\\", \\\"{x:179,y:621,t:1527009610294};\\\", \\\"{x:193,y:619,t:1527009610310};\\\", \\\"{x:211,y:615,t:1527009610327};\\\", \\\"{x:250,y:608,t:1527009610344};\\\", \\\"{x:335,y:589,t:1527009610361};\\\", \\\"{x:450,y:552,t:1527009610378};\\\", \\\"{x:544,y:541,t:1527009610395};\\\", \\\"{x:622,y:537,t:1527009610412};\\\", \\\"{x:644,y:533,t:1527009610427};\\\", \\\"{x:663,y:533,t:1527009610444};\\\", \\\"{x:669,y:533,t:1527009610462};\\\", \\\"{x:669,y:534,t:1527009610477};\\\", \\\"{x:671,y:535,t:1527009610494};\\\", \\\"{x:675,y:537,t:1527009610511};\\\", \\\"{x:680,y:540,t:1527009610528};\\\", \\\"{x:684,y:543,t:1527009610544};\\\", \\\"{x:687,y:544,t:1527009610560};\\\", \\\"{x:687,y:545,t:1527009610618};\\\", \\\"{x:681,y:546,t:1527009610629};\\\", \\\"{x:659,y:554,t:1527009610645};\\\", \\\"{x:637,y:557,t:1527009610662};\\\", \\\"{x:637,y:565,t:1527009610678};\\\", \\\"{x:634,y:567,t:1527009610695};\\\", \\\"{x:631,y:568,t:1527009610710};\\\", \\\"{x:631,y:569,t:1527009610727};\\\", \\\"{x:631,y:570,t:1527009610745};\\\", \\\"{x:631,y:571,t:1527009610761};\\\", \\\"{x:632,y:572,t:1527009610792};\\\", \\\"{x:633,y:572,t:1527009610800};\\\", \\\"{x:633,y:573,t:1527009610825};\\\", \\\"{x:634,y:574,t:1527009610930};\\\", \\\"{x:635,y:574,t:1527009611216};\\\", \\\"{x:637,y:574,t:1527009611233};\\\", \\\"{x:639,y:572,t:1527009611245};\\\", \\\"{x:640,y:571,t:1527009611261};\\\", \\\"{x:640,y:570,t:1527009611281};\\\", \\\"{x:643,y:568,t:1527009611295};\\\", \\\"{x:653,y:561,t:1527009611312};\\\", \\\"{x:679,y:547,t:1527009611329};\\\", \\\"{x:742,y:509,t:1527009611346};\\\", \\\"{x:797,y:488,t:1527009611361};\\\", \\\"{x:834,y:471,t:1527009611379};\\\", \\\"{x:844,y:463,t:1527009611395};\\\", \\\"{x:851,y:460,t:1527009611411};\\\", \\\"{x:852,y:459,t:1527009611428};\\\", \\\"{x:851,y:463,t:1527009611546};\\\", \\\"{x:844,y:473,t:1527009611562};\\\", \\\"{x:838,y:479,t:1527009611579};\\\", \\\"{x:831,y:488,t:1527009611597};\\\", \\\"{x:825,y:495,t:1527009611612};\\\", \\\"{x:822,y:499,t:1527009611628};\\\", \\\"{x:821,y:500,t:1527009611646};\\\", \\\"{x:820,y:501,t:1527009611663};\\\", \\\"{x:820,y:502,t:1527009611706};\\\", \\\"{x:821,y:502,t:1527009611846};\\\", \\\"{x:822,y:502,t:1527009611862};\\\", \\\"{x:822,y:502,t:1527009611915};\\\", \\\"{x:824,y:502,t:1527009612258};\\\", \\\"{x:825,y:502,t:1527009612337};\\\", \\\"{x:828,y:502,t:1527009612346};\\\", \\\"{x:829,y:502,t:1527009612370};\\\", \\\"{x:830,y:502,t:1527009612380};\\\", \\\"{x:831,y:502,t:1527009612425};\\\", \\\"{x:831,y:506,t:1527009612633};\\\", \\\"{x:829,y:513,t:1527009612646};\\\", \\\"{x:817,y:535,t:1527009612663};\\\", \\\"{x:795,y:562,t:1527009612680};\\\", \\\"{x:779,y:590,t:1527009612697};\\\", \\\"{x:749,y:629,t:1527009612713};\\\", \\\"{x:730,y:651,t:1527009612730};\\\", \\\"{x:715,y:663,t:1527009612746};\\\", \\\"{x:714,y:667,t:1527009612762};\\\", \\\"{x:700,y:673,t:1527009612780};\\\", \\\"{x:690,y:676,t:1527009612796};\\\", \\\"{x:679,y:678,t:1527009612813};\\\", \\\"{x:672,y:681,t:1527009612829};\\\", \\\"{x:669,y:681,t:1527009612846};\\\", \\\"{x:668,y:681,t:1527009612863};\\\", \\\"{x:665,y:681,t:1527009612879};\\\", \\\"{x:658,y:682,t:1527009612895};\\\", \\\"{x:644,y:683,t:1527009612912};\\\", \\\"{x:616,y:688,t:1527009612929};\\\", \\\"{x:604,y:691,t:1527009612946};\\\", \\\"{x:589,y:697,t:1527009612962};\\\", \\\"{x:574,y:706,t:1527009612979};\\\", \\\"{x:558,y:719,t:1527009612995};\\\", \\\"{x:543,y:729,t:1527009613013};\\\", \\\"{x:527,y:744,t:1527009613030};\\\", \\\"{x:512,y:751,t:1527009613047};\\\", \\\"{x:499,y:755,t:1527009613063};\\\", \\\"{x:489,y:755,t:1527009613080};\\\", \\\"{x:478,y:755,t:1527009613096};\\\", \\\"{x:469,y:754,t:1527009613113};\\\", \\\"{x:466,y:754,t:1527009613130};\\\", \\\"{x:464,y:753,t:1527009613147};\\\", \\\"{x:464,y:752,t:1527009613409};\\\", \\\"{x:464,y:751,t:1527009613425};\\\", \\\"{x:464,y:749,t:1527009613449};\\\", \\\"{x:464,y:748,t:1527009613463};\\\", \\\"{x:468,y:744,t:1527009613480};\\\", \\\"{x:475,y:739,t:1527009613496};\\\", \\\"{x:485,y:732,t:1527009613513};\\\", \\\"{x:487,y:730,t:1527009613714};\\\", \\\"{x:491,y:729,t:1527009613730};\\\", \\\"{x:492,y:728,t:1527009613746};\\\", \\\"{x:493,y:728,t:1527009613764};\\\", \\\"{x:494,y:728,t:1527009613825};\\\", \\\"{x:495,y:727,t:1527009613841};\\\", \\\"{x:496,y:727,t:1527009613849};\\\", \\\"{x:498,y:726,t:1527009613864};\\\", \\\"{x:500,y:725,t:1527009613881};\\\", \\\"{x:500,y:724,t:1527009613905};\\\" ] }, { \\\"rt\\\": 14114, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 784762, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:723,t:1527009615002};\\\", \\\"{x:503,y:721,t:1527009615014};\\\", \\\"{x:507,y:720,t:1527009615032};\\\", \\\"{x:511,y:717,t:1527009615122};\\\", \\\"{x:512,y:717,t:1527009615177};\\\", \\\"{x:513,y:717,t:1527009615264};\\\", \\\"{x:514,y:716,t:1527009615297};\\\", \\\"{x:515,y:715,t:1527009615345};\\\", \\\"{x:516,y:715,t:1527009615394};\\\", \\\"{x:517,y:714,t:1527009615401};\\\", \\\"{x:519,y:714,t:1527009615417};\\\", \\\"{x:522,y:712,t:1527009615432};\\\", \\\"{x:525,y:710,t:1527009615449};\\\", \\\"{x:529,y:707,t:1527009615465};\\\", \\\"{x:531,y:707,t:1527009615482};\\\", \\\"{x:537,y:706,t:1527009615498};\\\", \\\"{x:547,y:703,t:1527009615515};\\\", \\\"{x:563,y:703,t:1527009615531};\\\", \\\"{x:594,y:703,t:1527009615550};\\\", \\\"{x:628,y:703,t:1527009615566};\\\", \\\"{x:653,y:703,t:1527009615582};\\\", \\\"{x:682,y:703,t:1527009615599};\\\", \\\"{x:703,y:703,t:1527009615616};\\\", \\\"{x:715,y:702,t:1527009615632};\\\", \\\"{x:724,y:702,t:1527009615649};\\\", \\\"{x:727,y:703,t:1527009615666};\\\", \\\"{x:735,y:703,t:1527009617665};\\\", \\\"{x:785,y:702,t:1527009617684};\\\", \\\"{x:812,y:702,t:1527009617700};\\\", \\\"{x:813,y:702,t:1527009617717};\\\", \\\"{x:821,y:702,t:1527009618018};\\\", \\\"{x:846,y:700,t:1527009618034};\\\", \\\"{x:865,y:698,t:1527009618051};\\\", \\\"{x:874,y:696,t:1527009618067};\\\", \\\"{x:878,y:696,t:1527009618084};\\\", \\\"{x:880,y:696,t:1527009618169};\\\", \\\"{x:881,y:696,t:1527009618184};\\\", \\\"{x:884,y:694,t:1527009618202};\\\", \\\"{x:889,y:693,t:1527009618217};\\\", \\\"{x:895,y:692,t:1527009618234};\\\", \\\"{x:904,y:690,t:1527009618250};\\\", \\\"{x:911,y:688,t:1527009618268};\\\", \\\"{x:926,y:685,t:1527009618285};\\\", \\\"{x:946,y:682,t:1527009618301};\\\", \\\"{x:976,y:676,t:1527009618318};\\\", \\\"{x:1002,y:676,t:1527009618335};\\\", \\\"{x:1056,y:665,t:1527009618351};\\\", \\\"{x:1117,y:660,t:1527009618368};\\\", \\\"{x:1192,y:660,t:1527009618384};\\\", \\\"{x:1306,y:660,t:1527009618401};\\\", \\\"{x:1400,y:660,t:1527009618418};\\\", \\\"{x:1483,y:660,t:1527009618434};\\\", \\\"{x:1561,y:660,t:1527009618451};\\\", \\\"{x:1605,y:660,t:1527009618467};\\\", \\\"{x:1635,y:660,t:1527009618484};\\\", \\\"{x:1669,y:660,t:1527009618501};\\\", \\\"{x:1696,y:660,t:1527009618518};\\\", \\\"{x:1713,y:660,t:1527009618534};\\\", \\\"{x:1727,y:660,t:1527009618551};\\\", \\\"{x:1733,y:660,t:1527009618567};\\\", \\\"{x:1736,y:660,t:1527009618584};\\\", \\\"{x:1738,y:660,t:1527009618600};\\\", \\\"{x:1734,y:662,t:1527009618754};\\\", \\\"{x:1724,y:665,t:1527009618769};\\\", \\\"{x:1697,y:678,t:1527009618785};\\\", \\\"{x:1681,y:683,t:1527009618802};\\\", \\\"{x:1671,y:688,t:1527009618818};\\\", \\\"{x:1665,y:692,t:1527009618835};\\\", \\\"{x:1659,y:699,t:1527009618851};\\\", \\\"{x:1653,y:711,t:1527009618868};\\\", \\\"{x:1651,y:715,t:1527009618885};\\\", \\\"{x:1651,y:731,t:1527009618902};\\\", \\\"{x:1651,y:754,t:1527009618919};\\\", \\\"{x:1656,y:785,t:1527009618936};\\\", \\\"{x:1656,y:810,t:1527009618951};\\\", \\\"{x:1651,y:850,t:1527009618968};\\\", \\\"{x:1646,y:914,t:1527009618986};\\\", \\\"{x:1643,y:939,t:1527009619002};\\\", \\\"{x:1641,y:957,t:1527009619018};\\\", \\\"{x:1640,y:963,t:1527009619036};\\\", \\\"{x:1640,y:964,t:1527009619052};\\\", \\\"{x:1640,y:965,t:1527009619226};\\\", \\\"{x:1627,y:967,t:1527009619235};\\\", \\\"{x:1563,y:967,t:1527009619252};\\\", \\\"{x:1501,y:967,t:1527009619269};\\\", \\\"{x:1467,y:968,t:1527009619285};\\\", \\\"{x:1464,y:968,t:1527009619303};\\\", \\\"{x:1467,y:967,t:1527009619450};\\\", \\\"{x:1471,y:967,t:1527009619458};\\\", \\\"{x:1476,y:967,t:1527009619468};\\\", \\\"{x:1484,y:965,t:1527009619485};\\\", \\\"{x:1498,y:961,t:1527009619503};\\\", \\\"{x:1509,y:961,t:1527009619519};\\\", \\\"{x:1513,y:960,t:1527009619535};\\\", \\\"{x:1514,y:960,t:1527009619552};\\\", \\\"{x:1516,y:960,t:1527009619587};\\\", \\\"{x:1520,y:960,t:1527009619602};\\\", \\\"{x:1529,y:958,t:1527009619619};\\\", \\\"{x:1539,y:957,t:1527009619635};\\\", \\\"{x:1546,y:957,t:1527009619652};\\\", \\\"{x:1548,y:957,t:1527009619670};\\\", \\\"{x:1549,y:957,t:1527009619706};\\\", \\\"{x:1549,y:956,t:1527009619719};\\\", \\\"{x:1550,y:956,t:1527009619826};\\\", \\\"{x:1551,y:956,t:1527009619849};\\\", \\\"{x:1552,y:956,t:1527009625781};\\\", \\\"{x:1552,y:953,t:1527009625793};\\\", \\\"{x:1552,y:948,t:1527009625810};\\\", \\\"{x:1552,y:944,t:1527009625826};\\\", \\\"{x:1552,y:942,t:1527009625843};\\\", \\\"{x:1552,y:937,t:1527009625861};\\\", \\\"{x:1552,y:935,t:1527009625876};\\\", \\\"{x:1552,y:933,t:1527009625894};\\\", \\\"{x:1552,y:931,t:1527009625997};\\\", \\\"{x:1552,y:930,t:1527009626010};\\\", \\\"{x:1552,y:926,t:1527009626027};\\\", \\\"{x:1552,y:920,t:1527009626044};\\\", \\\"{x:1552,y:912,t:1527009626060};\\\", \\\"{x:1552,y:909,t:1527009626077};\\\", \\\"{x:1552,y:908,t:1527009626109};\\\", \\\"{x:1546,y:907,t:1527009626653};\\\", \\\"{x:1533,y:909,t:1527009626660};\\\", \\\"{x:1454,y:910,t:1527009626677};\\\", \\\"{x:1321,y:910,t:1527009626694};\\\", \\\"{x:1150,y:909,t:1527009626711};\\\", \\\"{x:921,y:879,t:1527009626728};\\\", \\\"{x:698,y:832,t:1527009626744};\\\", \\\"{x:484,y:778,t:1527009626761};\\\", \\\"{x:302,y:735,t:1527009626778};\\\", \\\"{x:156,y:696,t:1527009626794};\\\", \\\"{x:92,y:675,t:1527009626811};\\\", \\\"{x:80,y:667,t:1527009626829};\\\", \\\"{x:79,y:666,t:1527009626900};\\\", \\\"{x:79,y:661,t:1527009626911};\\\", \\\"{x:78,y:652,t:1527009626927};\\\", \\\"{x:78,y:634,t:1527009626944};\\\", \\\"{x:90,y:617,t:1527009626962};\\\", \\\"{x:116,y:594,t:1527009626978};\\\", \\\"{x:147,y:573,t:1527009626994};\\\", \\\"{x:186,y:547,t:1527009627011};\\\", \\\"{x:287,y:524,t:1527009627028};\\\", \\\"{x:338,y:521,t:1527009627044};\\\", \\\"{x:354,y:521,t:1527009627061};\\\", \\\"{x:362,y:524,t:1527009627078};\\\", \\\"{x:365,y:527,t:1527009627094};\\\", \\\"{x:365,y:533,t:1527009627111};\\\", \\\"{x:354,y:550,t:1527009627127};\\\", \\\"{x:341,y:565,t:1527009627146};\\\", \\\"{x:297,y:588,t:1527009627161};\\\", \\\"{x:254,y:604,t:1527009627179};\\\", \\\"{x:227,y:611,t:1527009627193};\\\", \\\"{x:213,y:612,t:1527009627211};\\\", \\\"{x:211,y:612,t:1527009627268};\\\", \\\"{x:210,y:612,t:1527009627283};\\\", \\\"{x:209,y:611,t:1527009627294};\\\", \\\"{x:209,y:609,t:1527009627331};\\\", \\\"{x:209,y:606,t:1527009627344};\\\", \\\"{x:209,y:599,t:1527009627361};\\\", \\\"{x:209,y:591,t:1527009627379};\\\", \\\"{x:209,y:577,t:1527009627395};\\\", \\\"{x:206,y:564,t:1527009627411};\\\", \\\"{x:196,y:549,t:1527009627428};\\\", \\\"{x:193,y:544,t:1527009627445};\\\", \\\"{x:191,y:542,t:1527009627461};\\\", \\\"{x:190,y:542,t:1527009627477};\\\", \\\"{x:189,y:542,t:1527009627500};\\\", \\\"{x:188,y:542,t:1527009627515};\\\", \\\"{x:186,y:542,t:1527009627532};\\\", \\\"{x:185,y:540,t:1527009627545};\\\", \\\"{x:177,y:535,t:1527009627560};\\\", \\\"{x:173,y:534,t:1527009627578};\\\", \\\"{x:171,y:534,t:1527009627595};\\\", \\\"{x:169,y:534,t:1527009627628};\\\", \\\"{x:167,y:534,t:1527009627645};\\\", \\\"{x:166,y:534,t:1527009627661};\\\", \\\"{x:166,y:536,t:1527009627996};\\\", \\\"{x:207,y:563,t:1527009628012};\\\", \\\"{x:279,y:598,t:1527009628028};\\\", \\\"{x:380,y:630,t:1527009628046};\\\", \\\"{x:469,y:660,t:1527009628063};\\\", \\\"{x:527,y:683,t:1527009628078};\\\", \\\"{x:554,y:699,t:1527009628095};\\\", \\\"{x:579,y:711,t:1527009628112};\\\", \\\"{x:603,y:729,t:1527009628128};\\\", \\\"{x:610,y:738,t:1527009628144};\\\", \\\"{x:611,y:739,t:1527009628162};\\\", \\\"{x:614,y:742,t:1527009628178};\\\", \\\"{x:605,y:735,t:1527009628277};\\\", \\\"{x:592,y:730,t:1527009628284};\\\", \\\"{x:574,y:724,t:1527009628295};\\\", \\\"{x:539,y:717,t:1527009628313};\\\", \\\"{x:523,y:717,t:1527009628329};\\\", \\\"{x:511,y:717,t:1527009628345};\\\", \\\"{x:506,y:719,t:1527009628362};\\\", \\\"{x:505,y:721,t:1527009628380};\\\", \\\"{x:504,y:722,t:1527009628395};\\\", \\\"{x:503,y:723,t:1527009628412};\\\", \\\"{x:501,y:725,t:1527009628429};\\\", \\\"{x:501,y:727,t:1527009628445};\\\", \\\"{x:501,y:730,t:1527009628462};\\\", \\\"{x:501,y:732,t:1527009628479};\\\", \\\"{x:501,y:734,t:1527009628495};\\\", \\\"{x:501,y:737,t:1527009628512};\\\", \\\"{x:501,y:739,t:1527009628529};\\\", \\\"{x:502,y:740,t:1527009628892};\\\" ] }, { \\\"rt\\\": 39007, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 824990, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-N -X -X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:740,t:1527009630180};\\\", \\\"{x:503,y:739,t:1527009631933};\\\", \\\"{x:513,y:730,t:1527009631951};\\\", \\\"{x:533,y:726,t:1527009631965};\\\", \\\"{x:554,y:726,t:1527009631982};\\\", \\\"{x:593,y:726,t:1527009631998};\\\", \\\"{x:668,y:726,t:1527009632015};\\\", \\\"{x:762,y:726,t:1527009632032};\\\", \\\"{x:884,y:726,t:1527009632049};\\\", \\\"{x:1014,y:726,t:1527009632065};\\\", \\\"{x:1165,y:741,t:1527009632082};\\\", \\\"{x:1297,y:753,t:1527009632098};\\\", \\\"{x:1425,y:770,t:1527009632115};\\\", \\\"{x:1578,y:787,t:1527009632132};\\\", \\\"{x:1651,y:800,t:1527009632148};\\\", \\\"{x:1693,y:800,t:1527009632166};\\\", \\\"{x:1708,y:804,t:1527009632182};\\\", \\\"{x:1719,y:804,t:1527009632198};\\\", \\\"{x:1720,y:804,t:1527009632215};\\\", \\\"{x:1721,y:808,t:1527009632485};\\\", \\\"{x:1721,y:812,t:1527009632499};\\\", \\\"{x:1721,y:825,t:1527009632516};\\\", \\\"{x:1721,y:830,t:1527009632533};\\\", \\\"{x:1720,y:830,t:1527009633739};\\\", \\\"{x:1719,y:830,t:1527009633756};\\\", \\\"{x:1719,y:829,t:1527009633771};\\\", \\\"{x:1719,y:828,t:1527009633784};\\\", \\\"{x:1719,y:826,t:1527009633800};\\\", \\\"{x:1718,y:824,t:1527009633816};\\\", \\\"{x:1718,y:823,t:1527009633833};\\\", \\\"{x:1718,y:822,t:1527009633883};\\\", \\\"{x:1717,y:820,t:1527009633923};\\\", \\\"{x:1716,y:819,t:1527009633933};\\\", \\\"{x:1715,y:818,t:1527009633980};\\\", \\\"{x:1714,y:818,t:1527009634004};\\\", \\\"{x:1713,y:818,t:1527009634020};\\\", \\\"{x:1710,y:817,t:1527009634034};\\\", \\\"{x:1702,y:816,t:1527009634050};\\\", \\\"{x:1689,y:815,t:1527009634066};\\\", \\\"{x:1677,y:814,t:1527009634084};\\\", \\\"{x:1650,y:810,t:1527009634101};\\\", \\\"{x:1636,y:808,t:1527009634117};\\\", \\\"{x:1631,y:807,t:1527009634134};\\\", \\\"{x:1626,y:805,t:1527009634151};\\\", \\\"{x:1622,y:799,t:1527009634167};\\\", \\\"{x:1620,y:798,t:1527009634183};\\\", \\\"{x:1618,y:796,t:1527009634201};\\\", \\\"{x:1617,y:795,t:1527009634220};\\\", \\\"{x:1616,y:795,t:1527009634236};\\\", \\\"{x:1615,y:795,t:1527009634548};\\\", \\\"{x:1613,y:795,t:1527009634829};\\\", \\\"{x:1609,y:797,t:1527009634836};\\\", \\\"{x:1605,y:802,t:1527009634851};\\\", \\\"{x:1597,y:812,t:1527009634868};\\\", \\\"{x:1586,y:824,t:1527009634885};\\\", \\\"{x:1577,y:834,t:1527009634901};\\\", \\\"{x:1570,y:841,t:1527009634919};\\\", \\\"{x:1564,y:850,t:1527009634935};\\\", \\\"{x:1556,y:856,t:1527009634951};\\\", \\\"{x:1553,y:861,t:1527009634968};\\\", \\\"{x:1550,y:865,t:1527009634985};\\\", \\\"{x:1545,y:868,t:1527009635002};\\\", \\\"{x:1544,y:870,t:1527009635018};\\\", \\\"{x:1537,y:873,t:1527009635035};\\\", \\\"{x:1533,y:877,t:1527009635052};\\\", \\\"{x:1532,y:877,t:1527009635067};\\\", \\\"{x:1531,y:877,t:1527009635141};\\\", \\\"{x:1527,y:875,t:1527009635157};\\\", \\\"{x:1525,y:872,t:1527009635172};\\\", \\\"{x:1523,y:870,t:1527009635184};\\\", \\\"{x:1518,y:867,t:1527009635202};\\\", \\\"{x:1514,y:864,t:1527009635218};\\\", \\\"{x:1511,y:861,t:1527009635235};\\\", \\\"{x:1510,y:861,t:1527009635252};\\\", \\\"{x:1509,y:860,t:1527009635268};\\\", \\\"{x:1508,y:860,t:1527009635285};\\\", \\\"{x:1506,y:859,t:1527009635302};\\\", \\\"{x:1503,y:853,t:1527009635318};\\\", \\\"{x:1499,y:844,t:1527009635335};\\\", \\\"{x:1495,y:832,t:1527009635352};\\\", \\\"{x:1490,y:824,t:1527009635368};\\\", \\\"{x:1488,y:819,t:1527009635385};\\\", \\\"{x:1487,y:817,t:1527009635402};\\\", \\\"{x:1487,y:816,t:1527009635420};\\\", \\\"{x:1486,y:814,t:1527009635435};\\\", \\\"{x:1485,y:814,t:1527009635452};\\\", \\\"{x:1485,y:812,t:1527009635469};\\\", \\\"{x:1484,y:814,t:1527009635581};\\\", \\\"{x:1484,y:818,t:1527009635588};\\\", \\\"{x:1484,y:825,t:1527009635605};\\\", \\\"{x:1483,y:838,t:1527009635619};\\\", \\\"{x:1480,y:848,t:1527009635634};\\\", \\\"{x:1479,y:856,t:1527009635651};\\\", \\\"{x:1479,y:857,t:1527009635668};\\\", \\\"{x:1479,y:856,t:1527009635836};\\\", \\\"{x:1479,y:854,t:1527009635852};\\\", \\\"{x:1481,y:847,t:1527009635869};\\\", \\\"{x:1481,y:845,t:1527009635886};\\\", \\\"{x:1481,y:843,t:1527009635902};\\\", \\\"{x:1481,y:842,t:1527009635919};\\\", \\\"{x:1481,y:841,t:1527009635936};\\\", \\\"{x:1481,y:839,t:1527009636109};\\\", \\\"{x:1481,y:837,t:1527009636141};\\\", \\\"{x:1481,y:836,t:1527009636173};\\\", \\\"{x:1481,y:834,t:1527009636894};\\\", \\\"{x:1481,y:833,t:1527009636920};\\\", \\\"{x:1481,y:831,t:1527009640573};\\\", \\\"{x:1481,y:830,t:1527009640590};\\\", \\\"{x:1481,y:829,t:1527009640606};\\\", \\\"{x:1481,y:828,t:1527009640623};\\\", \\\"{x:1481,y:827,t:1527009640781};\\\", \\\"{x:1481,y:824,t:1527009640791};\\\", \\\"{x:1481,y:820,t:1527009640806};\\\", \\\"{x:1479,y:816,t:1527009640823};\\\", \\\"{x:1479,y:811,t:1527009640840};\\\", \\\"{x:1479,y:808,t:1527009640856};\\\", \\\"{x:1478,y:804,t:1527009640873};\\\", \\\"{x:1478,y:801,t:1527009640890};\\\", \\\"{x:1478,y:798,t:1527009640906};\\\", \\\"{x:1477,y:795,t:1527009640923};\\\", \\\"{x:1477,y:791,t:1527009640940};\\\", \\\"{x:1476,y:787,t:1527009640956};\\\", \\\"{x:1476,y:784,t:1527009640973};\\\", \\\"{x:1476,y:783,t:1527009640990};\\\", \\\"{x:1476,y:781,t:1527009641008};\\\", \\\"{x:1476,y:779,t:1527009641023};\\\", \\\"{x:1475,y:778,t:1527009641040};\\\", \\\"{x:1475,y:776,t:1527009641057};\\\", \\\"{x:1475,y:775,t:1527009641073};\\\", \\\"{x:1475,y:774,t:1527009641092};\\\", \\\"{x:1474,y:774,t:1527009641108};\\\", \\\"{x:1474,y:773,t:1527009641124};\\\", \\\"{x:1474,y:772,t:1527009641157};\\\", \\\"{x:1474,y:770,t:1527009641173};\\\", \\\"{x:1474,y:769,t:1527009641191};\\\", \\\"{x:1474,y:768,t:1527009641207};\\\", \\\"{x:1474,y:767,t:1527009641223};\\\", \\\"{x:1474,y:766,t:1527009641240};\\\", \\\"{x:1474,y:764,t:1527009641277};\\\", \\\"{x:1474,y:763,t:1527009641289};\\\", \\\"{x:1474,y:762,t:1527009641306};\\\", \\\"{x:1474,y:760,t:1527009641322};\\\", \\\"{x:1474,y:759,t:1527009641340};\\\", \\\"{x:1474,y:758,t:1527009641356};\\\", \\\"{x:1474,y:757,t:1527009641388};\\\", \\\"{x:1474,y:756,t:1527009641436};\\\", \\\"{x:1474,y:755,t:1527009641452};\\\", \\\"{x:1474,y:754,t:1527009641460};\\\", \\\"{x:1474,y:753,t:1527009641484};\\\", \\\"{x:1474,y:752,t:1527009641491};\\\", \\\"{x:1474,y:751,t:1527009641507};\\\", \\\"{x:1473,y:750,t:1527009641524};\\\", \\\"{x:1472,y:749,t:1527009641540};\\\", \\\"{x:1472,y:748,t:1527009641557};\\\", \\\"{x:1471,y:746,t:1527009641580};\\\", \\\"{x:1471,y:745,t:1527009641596};\\\", \\\"{x:1471,y:744,t:1527009641620};\\\", \\\"{x:1471,y:743,t:1527009641628};\\\", \\\"{x:1471,y:742,t:1527009641659};\\\", \\\"{x:1471,y:741,t:1527009641691};\\\", \\\"{x:1471,y:740,t:1527009641707};\\\", \\\"{x:1471,y:739,t:1527009641723};\\\", \\\"{x:1471,y:738,t:1527009641748};\\\", \\\"{x:1471,y:737,t:1527009641757};\\\", \\\"{x:1471,y:736,t:1527009641773};\\\", \\\"{x:1471,y:733,t:1527009641790};\\\", \\\"{x:1471,y:731,t:1527009641806};\\\", \\\"{x:1471,y:726,t:1527009641824};\\\", \\\"{x:1471,y:722,t:1527009641841};\\\", \\\"{x:1472,y:719,t:1527009641857};\\\", \\\"{x:1472,y:716,t:1527009641874};\\\", \\\"{x:1473,y:714,t:1527009641891};\\\", \\\"{x:1473,y:711,t:1527009641907};\\\", \\\"{x:1474,y:708,t:1527009641924};\\\", \\\"{x:1475,y:708,t:1527009641941};\\\", \\\"{x:1475,y:706,t:1527009641957};\\\", \\\"{x:1475,y:705,t:1527009641974};\\\", \\\"{x:1475,y:704,t:1527009641990};\\\", \\\"{x:1476,y:703,t:1527009642006};\\\", \\\"{x:1477,y:702,t:1527009642024};\\\", \\\"{x:1477,y:700,t:1527009642041};\\\", \\\"{x:1478,y:700,t:1527009642057};\\\", \\\"{x:1478,y:699,t:1527009642076};\\\", \\\"{x:1478,y:696,t:1527009642091};\\\", \\\"{x:1478,y:695,t:1527009642108};\\\", \\\"{x:1478,y:693,t:1527009642124};\\\", \\\"{x:1478,y:691,t:1527009642141};\\\", \\\"{x:1478,y:690,t:1527009642164};\\\", \\\"{x:1477,y:689,t:1527009644581};\\\", \\\"{x:1459,y:689,t:1527009644594};\\\", \\\"{x:1368,y:689,t:1527009644609};\\\", \\\"{x:1229,y:689,t:1527009644626};\\\", \\\"{x:1054,y:678,t:1527009644643};\\\", \\\"{x:869,y:658,t:1527009644659};\\\", \\\"{x:592,y:619,t:1527009644677};\\\", \\\"{x:418,y:597,t:1527009644694};\\\", \\\"{x:256,y:566,t:1527009644709};\\\", \\\"{x:114,y:540,t:1527009644726};\\\", \\\"{x:23,y:527,t:1527009644742};\\\", \\\"{x:0,y:514,t:1527009644758};\\\", \\\"{x:0,y:504,t:1527009644776};\\\", \\\"{x:0,y:494,t:1527009644793};\\\", \\\"{x:0,y:492,t:1527009644808};\\\", \\\"{x:2,y:489,t:1527009644883};\\\", \\\"{x:11,y:485,t:1527009644893};\\\", \\\"{x:29,y:477,t:1527009644910};\\\", \\\"{x:56,y:474,t:1527009644926};\\\", \\\"{x:89,y:474,t:1527009644943};\\\", \\\"{x:116,y:474,t:1527009644960};\\\", \\\"{x:139,y:477,t:1527009644976};\\\", \\\"{x:160,y:483,t:1527009644993};\\\", \\\"{x:177,y:489,t:1527009645011};\\\", \\\"{x:191,y:495,t:1527009645027};\\\", \\\"{x:209,y:501,t:1527009645044};\\\", \\\"{x:237,y:517,t:1527009645060};\\\", \\\"{x:257,y:530,t:1527009645075};\\\", \\\"{x:272,y:537,t:1527009645093};\\\", \\\"{x:280,y:540,t:1527009645110};\\\", \\\"{x:281,y:540,t:1527009645126};\\\", \\\"{x:282,y:541,t:1527009645204};\\\", \\\"{x:282,y:542,t:1527009645220};\\\", \\\"{x:281,y:543,t:1527009645228};\\\", \\\"{x:277,y:546,t:1527009645243};\\\", \\\"{x:263,y:552,t:1527009645260};\\\", \\\"{x:247,y:558,t:1527009645276};\\\", \\\"{x:244,y:559,t:1527009645293};\\\", \\\"{x:243,y:560,t:1527009645316};\\\", \\\"{x:241,y:561,t:1527009645326};\\\", \\\"{x:240,y:562,t:1527009645344};\\\", \\\"{x:236,y:565,t:1527009645360};\\\", \\\"{x:232,y:567,t:1527009645376};\\\", \\\"{x:227,y:570,t:1527009645394};\\\", \\\"{x:220,y:574,t:1527009645410};\\\", \\\"{x:216,y:576,t:1527009645425};\\\", \\\"{x:213,y:577,t:1527009645443};\\\", \\\"{x:203,y:584,t:1527009645459};\\\", \\\"{x:197,y:589,t:1527009645476};\\\", \\\"{x:191,y:594,t:1527009645493};\\\", \\\"{x:187,y:598,t:1527009645510};\\\", \\\"{x:184,y:603,t:1527009645526};\\\", \\\"{x:181,y:605,t:1527009645542};\\\", \\\"{x:179,y:607,t:1527009645560};\\\", \\\"{x:178,y:608,t:1527009645576};\\\", \\\"{x:178,y:610,t:1527009645636};\\\", \\\"{x:177,y:610,t:1527009645644};\\\", \\\"{x:175,y:615,t:1527009645661};\\\", \\\"{x:174,y:615,t:1527009645677};\\\", \\\"{x:174,y:616,t:1527009645732};\\\", \\\"{x:177,y:616,t:1527009645743};\\\", \\\"{x:189,y:616,t:1527009645760};\\\", \\\"{x:217,y:608,t:1527009645778};\\\", \\\"{x:261,y:597,t:1527009645794};\\\", \\\"{x:316,y:585,t:1527009645810};\\\", \\\"{x:384,y:572,t:1527009645827};\\\", \\\"{x:446,y:562,t:1527009645844};\\\", \\\"{x:468,y:561,t:1527009645859};\\\", \\\"{x:473,y:561,t:1527009645877};\\\", \\\"{x:476,y:560,t:1527009645940};\\\", \\\"{x:483,y:558,t:1527009645948};\\\", \\\"{x:494,y:555,t:1527009645960};\\\", \\\"{x:513,y:548,t:1527009645978};\\\", \\\"{x:546,y:541,t:1527009645993};\\\", \\\"{x:564,y:531,t:1527009646012};\\\", \\\"{x:568,y:527,t:1527009646027};\\\", \\\"{x:564,y:528,t:1527009646115};\\\", \\\"{x:563,y:529,t:1527009646127};\\\", \\\"{x:562,y:530,t:1527009646144};\\\", \\\"{x:563,y:532,t:1527009646236};\\\", \\\"{x:571,y:533,t:1527009646243};\\\", \\\"{x:595,y:537,t:1527009646260};\\\", \\\"{x:607,y:538,t:1527009646277};\\\", \\\"{x:629,y:538,t:1527009646293};\\\", \\\"{x:649,y:538,t:1527009646310};\\\", \\\"{x:670,y:538,t:1527009646327};\\\", \\\"{x:694,y:538,t:1527009646343};\\\", \\\"{x:723,y:534,t:1527009646360};\\\", \\\"{x:743,y:530,t:1527009646378};\\\", \\\"{x:765,y:522,t:1527009646393};\\\", \\\"{x:781,y:516,t:1527009646410};\\\", \\\"{x:787,y:515,t:1527009646427};\\\", \\\"{x:790,y:514,t:1527009646444};\\\", \\\"{x:792,y:514,t:1527009646516};\\\", \\\"{x:793,y:514,t:1527009646532};\\\", \\\"{x:795,y:514,t:1527009646544};\\\", \\\"{x:796,y:514,t:1527009646561};\\\", \\\"{x:798,y:514,t:1527009646577};\\\", \\\"{x:803,y:514,t:1527009646594};\\\", \\\"{x:811,y:514,t:1527009646611};\\\", \\\"{x:827,y:516,t:1527009646628};\\\", \\\"{x:832,y:516,t:1527009646644};\\\", \\\"{x:834,y:516,t:1527009646691};\\\", \\\"{x:835,y:516,t:1527009646700};\\\", \\\"{x:837,y:516,t:1527009646923};\\\", \\\"{x:837,y:516,t:1527009646960};\\\", \\\"{x:841,y:514,t:1527009647212};\\\", \\\"{x:843,y:514,t:1527009647228};\\\", \\\"{x:850,y:511,t:1527009647245};\\\", \\\"{x:851,y:511,t:1527009647261};\\\", \\\"{x:845,y:414,t:1527009665005};\\\", \\\"{x:806,y:97,t:1527009665025};\\\", \\\"{x:747,y:16,t:1527009665042};\\\", \\\"{x:661,y:16,t:1527009665059};\\\", \\\"{x:575,y:16,t:1527009665076};\\\", \\\"{x:537,y:16,t:1527009665093};\\\", \\\"{x:514,y:16,t:1527009665108};\\\", \\\"{x:506,y:16,t:1527009665126};\\\", \\\"{x:505,y:16,t:1527009665142};\\\", \\\"{x:501,y:17,t:1527009665171};\\\", \\\"{x:495,y:22,t:1527009665179};\\\", \\\"{x:484,y:30,t:1527009665192};\\\", \\\"{x:463,y:50,t:1527009665209};\\\", \\\"{x:445,y:66,t:1527009665225};\\\", \\\"{x:415,y:77,t:1527009665242};\\\", \\\"{x:403,y:83,t:1527009665259};\\\", \\\"{x:398,y:89,t:1527009665276};\\\", \\\"{x:400,y:96,t:1527009665293};\\\", \\\"{x:408,y:101,t:1527009665309};\\\", \\\"{x:411,y:105,t:1527009665326};\\\", \\\"{x:416,y:106,t:1527009665343};\\\", \\\"{x:420,y:111,t:1527009665364};\\\", \\\"{x:425,y:119,t:1527009665659};\\\", \\\"{x:450,y:146,t:1527009665676};\\\", \\\"{x:471,y:173,t:1527009665692};\\\", \\\"{x:496,y:200,t:1527009665710};\\\", \\\"{x:522,y:227,t:1527009665726};\\\", \\\"{x:556,y:259,t:1527009665743};\\\", \\\"{x:580,y:283,t:1527009665760};\\\", \\\"{x:604,y:305,t:1527009665776};\\\", \\\"{x:631,y:338,t:1527009665793};\\\", \\\"{x:659,y:373,t:1527009665810};\\\", \\\"{x:709,y:420,t:1527009665827};\\\", \\\"{x:755,y:466,t:1527009665843};\\\", \\\"{x:792,y:511,t:1527009665860};\\\", \\\"{x:803,y:529,t:1527009665877};\\\", \\\"{x:804,y:537,t:1527009665894};\\\", \\\"{x:804,y:539,t:1527009665911};\\\", \\\"{x:804,y:540,t:1527009665926};\\\", \\\"{x:804,y:541,t:1527009665943};\\\", \\\"{x:803,y:542,t:1527009665960};\\\", \\\"{x:791,y:543,t:1527009665977};\\\", \\\"{x:772,y:543,t:1527009665993};\\\", \\\"{x:750,y:543,t:1527009666010};\\\", \\\"{x:737,y:543,t:1527009666027};\\\", \\\"{x:722,y:537,t:1527009666044};\\\", \\\"{x:696,y:527,t:1527009666060};\\\", \\\"{x:682,y:517,t:1527009666077};\\\", \\\"{x:674,y:515,t:1527009666094};\\\", \\\"{x:670,y:514,t:1527009666110};\\\", \\\"{x:670,y:513,t:1527009666127};\\\", \\\"{x:669,y:513,t:1527009666324};\\\", \\\"{x:667,y:514,t:1527009666331};\\\", \\\"{x:665,y:514,t:1527009666344};\\\", \\\"{x:662,y:514,t:1527009666852};\\\", \\\"{x:652,y:514,t:1527009666859};\\\", \\\"{x:644,y:514,t:1527009666876};\\\", \\\"{x:642,y:514,t:1527009666894};\\\", \\\"{x:641,y:514,t:1527009666956};\\\", \\\"{x:639,y:514,t:1527009667092};\\\", \\\"{x:637,y:514,t:1527009667107};\\\", \\\"{x:635,y:514,t:1527009667115};\\\", \\\"{x:633,y:514,t:1527009667128};\\\", \\\"{x:631,y:516,t:1527009667145};\\\", \\\"{x:626,y:516,t:1527009667161};\\\", \\\"{x:621,y:517,t:1527009667177};\\\", \\\"{x:615,y:517,t:1527009667195};\\\", \\\"{x:612,y:518,t:1527009667211};\\\", \\\"{x:607,y:519,t:1527009667227};\\\", \\\"{x:605,y:519,t:1527009667245};\\\", \\\"{x:604,y:520,t:1527009667268};\\\", \\\"{x:603,y:520,t:1527009667684};\\\", \\\"{x:602,y:521,t:1527009667699};\\\", \\\"{x:601,y:521,t:1527009667711};\\\", \\\"{x:598,y:523,t:1527009667728};\\\", \\\"{x:598,y:530,t:1527009667744};\\\", \\\"{x:598,y:542,t:1527009667761};\\\", \\\"{x:598,y:553,t:1527009667778};\\\", \\\"{x:598,y:579,t:1527009667796};\\\", \\\"{x:587,y:629,t:1527009667812};\\\", \\\"{x:567,y:675,t:1527009667828};\\\", \\\"{x:544,y:718,t:1527009667845};\\\", \\\"{x:525,y:747,t:1527009667862};\\\", \\\"{x:511,y:771,t:1527009667878};\\\", \\\"{x:500,y:787,t:1527009667894};\\\", \\\"{x:489,y:805,t:1527009667912};\\\", \\\"{x:479,y:821,t:1527009667928};\\\", \\\"{x:470,y:830,t:1527009667945};\\\", \\\"{x:465,y:838,t:1527009667961};\\\", \\\"{x:459,y:845,t:1527009667978};\\\", \\\"{x:456,y:847,t:1527009667995};\\\", \\\"{x:456,y:848,t:1527009668011};\\\", \\\"{x:457,y:848,t:1527009668124};\\\", \\\"{x:460,y:844,t:1527009668132};\\\", \\\"{x:462,y:837,t:1527009668145};\\\", \\\"{x:465,y:828,t:1527009668160};\\\", \\\"{x:471,y:812,t:1527009668178};\\\", \\\"{x:477,y:795,t:1527009668195};\\\", \\\"{x:480,y:786,t:1527009668211};\\\", \\\"{x:484,y:776,t:1527009668228};\\\", \\\"{x:486,y:773,t:1527009668245};\\\", \\\"{x:487,y:770,t:1527009668262};\\\", \\\"{x:488,y:769,t:1527009668380};\\\", \\\"{x:488,y:767,t:1527009668612};\\\", \\\"{x:489,y:757,t:1527009668629};\\\", \\\"{x:490,y:745,t:1527009668645};\\\", \\\"{x:490,y:738,t:1527009668662};\\\", \\\"{x:491,y:736,t:1527009668679};\\\", \\\"{x:501,y:736,t:1527009669100};\\\", \\\"{x:545,y:743,t:1527009669113};\\\", \\\"{x:669,y:775,t:1527009669129};\\\", \\\"{x:789,y:821,t:1527009669146};\\\", \\\"{x:943,y:874,t:1527009669164};\\\", \\\"{x:1050,y:915,t:1527009669180};\\\", \\\"{x:1131,y:943,t:1527009669196};\\\", \\\"{x:1170,y:959,t:1527009669213};\\\", \\\"{x:1191,y:970,t:1527009669230};\\\", \\\"{x:1204,y:977,t:1527009669246};\\\", \\\"{x:1207,y:979,t:1527009669263};\\\", \\\"{x:1210,y:983,t:1527009669280};\\\" ] }, { \\\"rt\\\": 30031, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 856325, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"on the x axis go to 12 pm and move upwards until reaching a letter indicating an event that is happening at 12pm\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 9429, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States of America\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 866758, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 10921, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 878700, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 16603, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 896387, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"808YR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"808YR\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 241, dom: 952, initialDom: 1034",
  "javascriptErrors": []
}