var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1f1545f97c8568bb20639955c1eea036",
  "created": "2018-05-22T10:21:09.814156-07:00",
  "lastActivity": "2018-05-22T10:22:22.634156-07:00",
  "pageViews": [
    {
      "id": "05220937ed29974ab5ffd3611ba6433685375b6b",
      "startTime": "2018-05-22T10:21:09.814156-07:00",
      "endTime": "2018-05-22T10:22:22.634156-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 72820,
      "engagementTime": 72718,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 72820,
  "engagementTime": 72718,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=808YR",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b2fd5a08e1bf3bd5a92c2f9d7fdf572c",
  "gdpr": false
}