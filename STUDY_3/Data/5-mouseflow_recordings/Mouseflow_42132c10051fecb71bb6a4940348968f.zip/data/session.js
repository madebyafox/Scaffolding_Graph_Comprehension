var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "42132c10051fecb71bb6a4940348968f",
  "created": "2018-06-01T11:14:07.5066876-07:00",
  "lastActivity": "2018-06-01T11:14:16.5796876-07:00",
  "pageViews": [
    {
      "id": "060107453fee6a5614240cadbad11c0e9d0e60cf",
      "startTime": "2018-06-01T11:14:07.5066876-07:00",
      "endTime": "2018-06-01T11:14:16.5796876-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 9073,
      "engagementTime": 9023,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 9073,
  "engagementTime": 9023,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=202VN",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8e9fa2b0fea728f075fe08e268bc8d92",
  "gdpr": false
}