var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1c5f536dd3479316e86c72cd2a0887c4",
  "created": "2018-05-18T11:16:38.1017534-07:00",
  "lastActivity": "2018-05-18T11:16:51.3307534-07:00",
  "pageViews": [
    {
      "id": "05183881172aa461a3da788d652a72c9f450df38",
      "startTime": "2018-05-18T11:16:38.1017534-07:00",
      "endTime": "2018-05-18T11:16:51.3307534-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 13229,
      "engagementTime": 13229,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 13229,
  "engagementTime": 13229,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.42",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=HWJDK",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e82287738ae0316ce6070c36058966bd",
  "gdpr": false
}